import bpy, mathutils

def node():
	#initialize face_centers node group
	def face_centers_node_group():
	    face_centers = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "FACE_CENTERS")
	
	    face_centers.color_tag = 'NONE'
	    face_centers.description = ""
	    face_centers.default_group_node_width = 140
	    
	
	    face_centers.is_modifier = True
	
	    #face_centers interface
	    #Socket Geometry
	    geometry_socket = face_centers.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket.attribute_domain = 'POINT'
	
	    #Socket Geometry
	    geometry_socket_1 = face_centers.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_1.attribute_domain = 'POINT'
	
	
	    #initialize face_centers nodes
	    #node Group Output
	    group_output = face_centers.nodes.new("NodeGroupOutput")
	    group_output.name = "Group Output"
	    group_output.is_active_output = True
	
	    #node Group Input
	    group_input = face_centers.nodes.new("NodeGroupInput")
	    group_input.name = "Group Input"
	
	    #node For Each Geometry Element Input
	    for_each_geometry_element_input = face_centers.nodes.new("GeometryNodeForeachGeometryElementInput")
	    for_each_geometry_element_input.name = "For Each Geometry Element Input"
	    #node For Each Geometry Element Output
	    for_each_geometry_element_output = face_centers.nodes.new("GeometryNodeForeachGeometryElementOutput")
	    for_each_geometry_element_output.name = "For Each Geometry Element Output"
	    for_each_geometry_element_output.active_generation_index = 0
	    for_each_geometry_element_output.active_input_index = 0
	    for_each_geometry_element_output.active_main_index = 0
	    for_each_geometry_element_output.domain = 'FACE'
	    for_each_geometry_element_output.generation_items.clear()
	    for_each_geometry_element_output.generation_items.new('GEOMETRY', "Geometry")
	    for_each_geometry_element_output.generation_items[0].domain = 'POINT'
	    for_each_geometry_element_output.input_items.clear()
	    for_each_geometry_element_output.inspection_index = 0
	    for_each_geometry_element_output.main_items.clear()
	
	    #node Store Named Attribute
	    store_named_attribute = face_centers.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute.name = "Store Named Attribute"
	    store_named_attribute.data_type = 'FLOAT_VECTOR'
	    store_named_attribute.domain = 'FACE'
	    #Selection
	    store_named_attribute.inputs[1].default_value = True
	    #Name
	    store_named_attribute.inputs[2].default_value = "centers"
	
	    #node Named Attribute.001
	    named_attribute_001 = face_centers.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute_001.name = "Named Attribute.001"
	    named_attribute_001.data_type = 'INT'
	    #Name
	    named_attribute_001.inputs[0].default_value = "fidx"
	
	    #node Named Attribute.004
	    named_attribute_004 = face_centers.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute_004.name = "Named Attribute.004"
	    named_attribute_004.data_type = 'FLOAT_VECTOR'
	    #Name
	    named_attribute_004.inputs[0].default_value = "fco"
	
	    #node Compare.001
	    compare_001 = face_centers.nodes.new("FunctionNodeCompare")
	    compare_001.name = "Compare.001"
	    compare_001.hide = True
	    compare_001.data_type = 'INT'
	    compare_001.mode = 'ELEMENT'
	    compare_001.operation = 'EQUAL'
	
	    #node Attribute Statistic.002
	    attribute_statistic_002 = face_centers.nodes.new("GeometryNodeAttributeStatistic")
	    attribute_statistic_002.name = "Attribute Statistic.002"
	    attribute_statistic_002.data_type = 'FLOAT_VECTOR'
	    attribute_statistic_002.domain = 'CORNER'
	    attribute_statistic_002.outputs[1].hide = True
	    attribute_statistic_002.outputs[2].hide = True
	    attribute_statistic_002.outputs[3].hide = True
	    attribute_statistic_002.outputs[4].hide = True
	    attribute_statistic_002.outputs[5].hide = True
	    attribute_statistic_002.outputs[6].hide = True
	    attribute_statistic_002.outputs[7].hide = True
	
	    #node Reroute.010
	    reroute_010 = face_centers.nodes.new("NodeReroute")
	    reroute_010.name = "Reroute.010"
	    reroute_010.socket_idname = "NodeSocketGeometry"
	
	
	    #Process zone input For Each Geometry Element Input
	    for_each_geometry_element_input.pair_with_output(for_each_geometry_element_output)
	    #Selection
	    for_each_geometry_element_input.inputs[1].default_value = True
	
	
	
	
	    #Set locations
	    group_output.location = (659.57373046875, 0.0)
	    group_input.location = (-669.57373046875, 0.0)
	    for_each_geometry_element_input.location = (-369.873779296875, 251.74090576171875)
	    for_each_geometry_element_output.location = (469.57373046875, 251.74090576171875)
	    store_named_attribute.location = (250.197998046875, 248.50677490234375)
	    named_attribute_001.location = (-405.4127197265625, 37.06463623046875)
	    named_attribute_004.location = (-403.79931640625, -97.15411376953125)
	    compare_001.location = (-188.1004638671875, 84.72480773925781)
	    attribute_statistic_002.location = (-11.463111877441406, 110.92959594726562)
	    reroute_010.location = (-485.5649719238281, -34.71746826171875)
	
	    #Set dimensions
	    group_output.width, group_output.height = 140.0, 100.0
	    group_input.width, group_input.height = 140.0, 100.0
	    for_each_geometry_element_input.width, for_each_geometry_element_input.height = 140.0, 100.0
	    for_each_geometry_element_output.width, for_each_geometry_element_output.height = 140.0, 100.0
	    store_named_attribute.width, store_named_attribute.height = 140.0, 100.0
	    named_attribute_001.width, named_attribute_001.height = 140.0, 100.0
	    named_attribute_004.width, named_attribute_004.height = 140.0, 100.0
	    compare_001.width, compare_001.height = 140.0, 100.0
	    attribute_statistic_002.width, attribute_statistic_002.height = 140.0, 100.0
	    reroute_010.width, reroute_010.height = 10.0, 100.0
	
	    #initialize face_centers links
	    #reroute_010.Output -> attribute_statistic_002.Geometry
	    face_centers.links.new(reroute_010.outputs[0], attribute_statistic_002.inputs[0])
	    #compare_001.Result -> attribute_statistic_002.Selection
	    face_centers.links.new(compare_001.outputs[0], attribute_statistic_002.inputs[1])
	    #named_attribute_004.Attribute -> attribute_statistic_002.Attribute
	    face_centers.links.new(named_attribute_004.outputs[0], attribute_statistic_002.inputs[2])
	    #named_attribute_001.Attribute -> compare_001.B
	    face_centers.links.new(named_attribute_001.outputs[0], compare_001.inputs[3])
	    #store_named_attribute.Geometry -> for_each_geometry_element_output.Geometry
	    face_centers.links.new(store_named_attribute.outputs[0], for_each_geometry_element_output.inputs[1])
	    #attribute_statistic_002.Mean -> store_named_attribute.Value
	    face_centers.links.new(attribute_statistic_002.outputs[0], store_named_attribute.inputs[3])
	    #for_each_geometry_element_input.Element -> store_named_attribute.Geometry
	    face_centers.links.new(for_each_geometry_element_input.outputs[1], store_named_attribute.inputs[0])
	    #reroute_010.Output -> for_each_geometry_element_input.Geometry
	    face_centers.links.new(reroute_010.outputs[0], for_each_geometry_element_input.inputs[0])
	    #for_each_geometry_element_input.Index -> compare_001.A
	    face_centers.links.new(for_each_geometry_element_input.outputs[0], compare_001.inputs[2])
	    #group_input.Geometry -> reroute_010.Input
	    face_centers.links.new(group_input.outputs[0], reroute_010.inputs[0])
	    #for_each_geometry_element_output.Geometry -> group_output.Geometry
	    face_centers.links.new(for_each_geometry_element_output.outputs[2], group_output.inputs[0])
	    return face_centers
	
	face_centers = face_centers_node_group()
	
	#initialize ob_data node group
	def ob_data_node_group():
	    ob_data = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "OB_DATA")
	
	    ob_data.color_tag = 'NONE'
	    ob_data.description = "Extra data for mesh object."
	    ob_data.default_group_node_width = 140
	    
	
	    ob_data.is_modifier = True
	    ob_data.is_tool = True
	    ob_data.is_mode_object = False
	    ob_data.is_mode_edit = False
	    ob_data.is_mode_sculpt = False
	    ob_data.is_type_curve = False
	    ob_data.is_type_mesh = False
	    ob_data.is_type_point_cloud = False
	
	    #ob_data interface
	    #Socket Geometry
	    geometry_socket_2 = ob_data.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_2.attribute_domain = 'POINT'
	
	    #Socket Geometry
	    geometry_socket_3 = ob_data.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_3.attribute_domain = 'POINT'
	
	
	    #initialize ob_data nodes
	    #node Group Output
	    group_output_1 = ob_data.nodes.new("NodeGroupOutput")
	    group_output_1.name = "Group Output"
	    group_output_1.is_active_output = True
	    group_output_1.inputs[1].hide = True
	
	    #node Group Input
	    group_input_1 = ob_data.nodes.new("NodeGroupInput")
	    group_input_1.name = "Group Input"
	    group_input_1.outputs[1].hide = True
	
	    #node Store Named Attribute
	    store_named_attribute_1 = ob_data.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_1.name = "Store Named Attribute"
	    store_named_attribute_1.data_type = 'FLOAT'
	    store_named_attribute_1.domain = 'FACE'
	    #Selection
	    store_named_attribute_1.inputs[1].default_value = True
	    #Name
	    store_named_attribute_1.inputs[2].default_value = "area"
	
	    #node Face Area
	    face_area = ob_data.nodes.new("GeometryNodeInputMeshFaceArea")
	    face_area.name = "Face Area"
	
	    #node Corners of Face
	    corners_of_face = ob_data.nodes.new("GeometryNodeCornersOfFace")
	    corners_of_face.name = "Corners of Face"
	    corners_of_face.inputs[0].hide = True
	    corners_of_face.inputs[1].hide = True
	    corners_of_face.inputs[2].hide = True
	    corners_of_face.outputs[0].hide = True
	    #Face Index
	    corners_of_face.inputs[0].default_value = 0
	    #Weights
	    corners_of_face.inputs[1].default_value = 0.0
	    #Sort Index
	    corners_of_face.inputs[2].default_value = 0
	
	    #node Store Named Attribute.004
	    store_named_attribute_004 = ob_data.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_004.name = "Store Named Attribute.004"
	    store_named_attribute_004.data_type = 'INT'
	    store_named_attribute_004.domain = 'FACE'
	    #Selection
	    store_named_attribute_004.inputs[1].default_value = True
	    #Name
	    store_named_attribute_004.inputs[2].default_value = "fvct"
	
	    #node Edge Vertices.001
	    edge_vertices_001 = ob_data.nodes.new("GeometryNodeInputMeshEdgeVertices")
	    edge_vertices_001.name = "Edge Vertices.001"
	
	    #node Store Named Attribute.010
	    store_named_attribute_010 = ob_data.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_010.name = "Store Named Attribute.010"
	    store_named_attribute_010.data_type = 'FLOAT_VECTOR'
	    store_named_attribute_010.domain = 'EDGE'
	    #Selection
	    store_named_attribute_010.inputs[1].default_value = True
	    #Name
	    store_named_attribute_010.inputs[2].default_value = "evec"
	
	    #node Store Named Attribute.011
	    store_named_attribute_011 = ob_data.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_011.name = "Store Named Attribute.011"
	    store_named_attribute_011.data_type = 'FLOAT'
	    store_named_attribute_011.domain = 'EDGE'
	    #Selection
	    store_named_attribute_011.inputs[1].default_value = True
	    #Name
	    store_named_attribute_011.inputs[2].default_value = "elen"
	
	    #node Vector Math
	    vector_math = ob_data.nodes.new("ShaderNodeVectorMath")
	    vector_math.name = "Vector Math"
	    vector_math.hide = True
	    vector_math.operation = 'SUBTRACT'
	
	    #node Vector Math.001
	    vector_math_001 = ob_data.nodes.new("ShaderNodeVectorMath")
	    vector_math_001.name = "Vector Math.001"
	    vector_math_001.hide = True
	    vector_math_001.operation = 'LENGTH'
	
	    #node Vertex Neighbors
	    vertex_neighbors = ob_data.nodes.new("GeometryNodeInputMeshVertexNeighbors")
	    vertex_neighbors.name = "Vertex Neighbors"
	
	    #node Store Named Attribute.002
	    store_named_attribute_002 = ob_data.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_002.name = "Store Named Attribute.002"
	    store_named_attribute_002.data_type = 'INT'
	    store_named_attribute_002.domain = 'POINT'
	    #Selection
	    store_named_attribute_002.inputs[1].default_value = True
	    #Name
	    store_named_attribute_002.inputs[2].default_value = "vct"
	
	    #node Store Named Attribute.003
	    store_named_attribute_003 = ob_data.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_003.name = "Store Named Attribute.003"
	    store_named_attribute_003.data_type = 'INT'
	    store_named_attribute_003.domain = 'POINT'
	    #Selection
	    store_named_attribute_003.inputs[1].default_value = True
	    #Name
	    store_named_attribute_003.inputs[2].default_value = "fct"
	
	    #node Corners of Vertex
	    corners_of_vertex = ob_data.nodes.new("GeometryNodeCornersOfVertex")
	    corners_of_vertex.name = "Corners of Vertex"
	    #Vertex Index
	    corners_of_vertex.inputs[0].default_value = 0
	    #Weights
	    corners_of_vertex.inputs[1].default_value = 0.0
	    #Sort Index
	    corners_of_vertex.inputs[2].default_value = 0
	
	    #node Store Named Attribute.006
	    store_named_attribute_006 = ob_data.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_006.name = "Store Named Attribute.006"
	    store_named_attribute_006.data_type = 'INT'
	    store_named_attribute_006.domain = 'POINT'
	    #Selection
	    store_named_attribute_006.inputs[1].default_value = True
	    #Name
	    store_named_attribute_006.inputs[2].default_value = "vi"
	
	    #node Face of Corner
	    face_of_corner = ob_data.nodes.new("GeometryNodeFaceOfCorner")
	    face_of_corner.name = "Face of Corner"
	    face_of_corner.inputs[0].hide = True
	    face_of_corner.outputs[1].hide = True
	    #Corner Index
	    face_of_corner.inputs[0].default_value = 0
	
	    #node Store Named Attribute.007
	    store_named_attribute_007 = ob_data.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_007.name = "Store Named Attribute.007"
	    store_named_attribute_007.data_type = 'INT'
	    store_named_attribute_007.domain = 'POINT'
	    #Selection
	    store_named_attribute_007.inputs[1].default_value = True
	    #Name
	    store_named_attribute_007.inputs[2].default_value = "iif"
	
	    #node Store Named Attribute.005
	    store_named_attribute_005 = ob_data.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_005.name = "Store Named Attribute.005"
	    store_named_attribute_005.data_type = 'INT'
	    store_named_attribute_005.domain = 'POINT'
	    #Selection
	    store_named_attribute_005.inputs[1].default_value = True
	    #Name
	    store_named_attribute_005.inputs[2].default_value = "vidx"
	
	    #node Index
	    index = ob_data.nodes.new("GeometryNodeInputIndex")
	    index.name = "Index"
	
	    #node Store Named Attribute.012
	    store_named_attribute_012 = ob_data.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_012.name = "Store Named Attribute.012"
	    store_named_attribute_012.data_type = 'INT'
	    store_named_attribute_012.domain = 'EDGE'
	    #Selection
	    store_named_attribute_012.inputs[1].default_value = True
	    #Name
	    store_named_attribute_012.inputs[2].default_value = "e1"
	
	    #node Store Named Attribute.013
	    store_named_attribute_013 = ob_data.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_013.name = "Store Named Attribute.013"
	    store_named_attribute_013.data_type = 'INT'
	    store_named_attribute_013.domain = 'EDGE'
	    #Selection
	    store_named_attribute_013.inputs[1].default_value = True
	    #Name
	    store_named_attribute_013.inputs[2].default_value = "e2"
	
	    #node Frame
	    frame = ob_data.nodes.new("NodeFrame")
	    frame.label = "Point"
	    frame.name = "Frame"
	    frame.label_size = 20
	    frame.shrink = True
	
	    #node Frame.001
	    frame_001 = ob_data.nodes.new("NodeFrame")
	    frame_001.label = "Edge"
	    frame_001.name = "Frame.001"
	    frame_001.label_size = 20
	    frame_001.shrink = True
	
	    #node Frame.002
	    frame_002 = ob_data.nodes.new("NodeFrame")
	    frame_002.label = "Face"
	    frame_002.name = "Frame.002"
	    frame_002.label_size = 20
	    frame_002.shrink = True
	
	    #node Store Named Attribute.008
	    store_named_attribute_008 = ob_data.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_008.name = "Store Named Attribute.008"
	    store_named_attribute_008.data_type = 'INT'
	    store_named_attribute_008.domain = 'CORNER'
	    #Selection
	    store_named_attribute_008.inputs[1].default_value = True
	    #Name
	    store_named_attribute_008.inputs[2].default_value = "fidx"
	
	    #node Index.001
	    index_001 = ob_data.nodes.new("GeometryNodeInputIndex")
	    index_001.name = "Index.001"
	
	    #node Face of Corner.001
	    face_of_corner_001 = ob_data.nodes.new("GeometryNodeFaceOfCorner")
	    face_of_corner_001.name = "Face of Corner.001"
	    face_of_corner_001.hide = True
	    #Corner Index
	    face_of_corner_001.inputs[0].default_value = 0
	
	    #node Store Named Attribute.009
	    store_named_attribute_009 = ob_data.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_009.name = "Store Named Attribute.009"
	    store_named_attribute_009.data_type = 'INT'
	    store_named_attribute_009.domain = 'CORNER'
	    #Selection
	    store_named_attribute_009.inputs[1].default_value = True
	    #Name
	    store_named_attribute_009.inputs[2].default_value = "iface"
	
	    #node Evaluate at Index.002
	    evaluate_at_index_002 = ob_data.nodes.new("GeometryNodeFieldAtIndex")
	    evaluate_at_index_002.name = "Evaluate at Index.002"
	    evaluate_at_index_002.hide = True
	    evaluate_at_index_002.data_type = 'FLOAT_VECTOR'
	    evaluate_at_index_002.domain = 'POINT'
	
	    #node Position
	    position = ob_data.nodes.new("GeometryNodeInputPosition")
	    position.name = "Position"
	
	    #node Store Named Attribute.014
	    store_named_attribute_014 = ob_data.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_014.name = "Store Named Attribute.014"
	    store_named_attribute_014.data_type = 'FLOAT_VECTOR'
	    store_named_attribute_014.domain = 'CORNER'
	    #Selection
	    store_named_attribute_014.inputs[1].default_value = True
	    #Name
	    store_named_attribute_014.inputs[2].default_value = "fco"
	
	    #node Store Named Attribute.015
	    store_named_attribute_015 = ob_data.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_015.name = "Store Named Attribute.015"
	    store_named_attribute_015.data_type = 'INT'
	    store_named_attribute_015.domain = 'CORNER'
	    #Selection
	    store_named_attribute_015.inputs[1].default_value = True
	    #Name
	    store_named_attribute_015.inputs[2].default_value = "fvert"
	
	    #node Named Attribute.001
	    named_attribute_001_1 = ob_data.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute_001_1.name = "Named Attribute.001"
	    named_attribute_001_1.data_type = 'INT'
	    #Name
	    named_attribute_001_1.inputs[0].default_value = "vidx"
	
	    #node Frame.003
	    frame_003 = ob_data.nodes.new("NodeFrame")
	    frame_003.label = "UV"
	    frame_003.name = "Frame.003"
	    frame_003.label_size = 20
	    frame_003.shrink = True
	
	    #node Group
	    group = ob_data.nodes.new("GeometryNodeGroup")
	    group.name = "Group"
	    group.node_tree = face_centers
	
	
	
	
	    #Set parents
	    store_named_attribute_1.parent = frame_002
	    face_area.parent = frame_002
	    corners_of_face.parent = frame_002
	    store_named_attribute_004.parent = frame_002
	    edge_vertices_001.parent = frame_001
	    store_named_attribute_010.parent = frame_001
	    store_named_attribute_011.parent = frame_001
	    vector_math.parent = frame_001
	    vector_math_001.parent = frame_001
	    vertex_neighbors.parent = frame
	    store_named_attribute_002.parent = frame
	    store_named_attribute_003.parent = frame
	    corners_of_vertex.parent = frame
	    store_named_attribute_006.parent = frame
	    face_of_corner.parent = frame
	    store_named_attribute_007.parent = frame
	    store_named_attribute_005.parent = frame
	    index.parent = frame
	    store_named_attribute_012.parent = frame_001
	    store_named_attribute_013.parent = frame_001
	    store_named_attribute_008.parent = frame_003
	    index_001.parent = frame_003
	    face_of_corner_001.parent = frame_003
	    store_named_attribute_009.parent = frame_003
	    evaluate_at_index_002.parent = frame_003
	    position.parent = frame_003
	    store_named_attribute_014.parent = frame_003
	    store_named_attribute_015.parent = frame_003
	    named_attribute_001_1.parent = frame_003
	
	    #Set locations
	    group_output_1.location = (2084.419677734375, 0.0)
	    group_input_1.location = (-1175.17578125, 0.0)
	    store_named_attribute_1.location = (31.557861328125, -39.91112518310547)
	    face_area.location = (30.0308837890625, -241.5736541748047)
	    corners_of_face.location = (207.884521484375, -240.56661987304688)
	    store_named_attribute_004.location = (211.1871337890625, -43.55321502685547)
	    edge_vertices_001.location = (30.059101104736328, -235.656494140625)
	    store_named_attribute_010.location = (379.56103515625, -39.92475128173828)
	    store_named_attribute_011.location = (559.666259765625, -39.92475128173828)
	    vector_math.location = (377.9259338378906, -247.12554931640625)
	    vector_math_001.location = (559.92236328125, -245.30450439453125)
	    vertex_neighbors.location = (225.6195068359375, -241.48486328125)
	    store_named_attribute_002.location = (230.421875, -42.65917205810547)
	    store_named_attribute_003.location = (424.875732421875, -42.65917205810547)
	    corners_of_vertex.location = (791.2051391601562, -243.86764526367188)
	    store_named_attribute_006.location = (614.2387084960938, -44.48021697998047)
	    face_of_corner.location = (609.9549560546875, -242.69467163085938)
	    store_named_attribute_007.location = (794.2388305664062, -44.48021697998047)
	    store_named_attribute_005.location = (32.19744873046875, -39.81938171386719)
	    index.location = (29.61065673828125, -237.67437744140625)
	    store_named_attribute_012.location = (30.58085823059082, -39.92475128173828)
	    store_named_attribute_013.location = (205.30517578125, -39.92475128173828)
	    frame.location = (-1011.0, 114.0)
	    frame_001.location = (-24.0, 111.0)
	    frame_002.location = (723.0, 113.0)
	    store_named_attribute_008.location = (30.084228515625, -39.91887664794922)
	    index_001.location = (399.0113525390625, -272.89666748046875)
	    face_of_corner_001.location = (31.023681640625, -240.24319458007812)
	    store_named_attribute_009.location = (210.18896484375, -39.91887664794922)
	    evaluate_at_index_002.location = (399.3846435546875, -241.97543334960938)
	    position.location = (395.73388671875, -329.0435791015625)
	    store_named_attribute_014.location = (396.99755859375, -39.91887664794922)
	    store_named_attribute_015.location = (589.268798828125, -39.91887664794922)
	    named_attribute_001_1.location = (590.27685546875, -237.64990234375)
	    frame_003.location = (1121.0, 117.0)
	    group.location = (1895.553466796875, -3.2612171173095703)
	
	    #Set dimensions
	    group_output_1.width, group_output_1.height = 140.0, 100.0
	    group_input_1.width, group_input_1.height = 140.0, 100.0
	    store_named_attribute_1.width, store_named_attribute_1.height = 140.0, 100.0
	    face_area.width, face_area.height = 140.0, 100.0
	    corners_of_face.width, corners_of_face.height = 140.0, 100.0
	    store_named_attribute_004.width, store_named_attribute_004.height = 140.0, 100.0
	    edge_vertices_001.width, edge_vertices_001.height = 140.0, 100.0
	    store_named_attribute_010.width, store_named_attribute_010.height = 140.0, 100.0
	    store_named_attribute_011.width, store_named_attribute_011.height = 140.0, 100.0
	    vector_math.width, vector_math.height = 140.0, 100.0
	    vector_math_001.width, vector_math_001.height = 140.0, 100.0
	    vertex_neighbors.width, vertex_neighbors.height = 140.0, 100.0
	    store_named_attribute_002.width, store_named_attribute_002.height = 140.0, 100.0
	    store_named_attribute_003.width, store_named_attribute_003.height = 140.0, 100.0
	    corners_of_vertex.width, corners_of_vertex.height = 140.0, 100.0
	    store_named_attribute_006.width, store_named_attribute_006.height = 140.0, 100.0
	    face_of_corner.width, face_of_corner.height = 140.0, 100.0
	    store_named_attribute_007.width, store_named_attribute_007.height = 140.0, 100.0
	    store_named_attribute_005.width, store_named_attribute_005.height = 140.0, 100.0
	    index.width, index.height = 140.0, 100.0
	    store_named_attribute_012.width, store_named_attribute_012.height = 140.0, 100.0
	    store_named_attribute_013.width, store_named_attribute_013.height = 140.0, 100.0
	    frame.width, frame.height = 964.0, 415.0
	    frame_001.width, frame_001.height = 730.0, 382.0
	    frame_002.width, frame_002.height = 381.0, 322.0
	    store_named_attribute_008.width, store_named_attribute_008.height = 140.0, 100.0
	    index_001.width, index_001.height = 140.0, 100.0
	    face_of_corner_001.width, face_of_corner_001.height = 140.0, 100.0
	    store_named_attribute_009.width, store_named_attribute_009.height = 140.0, 100.0
	    evaluate_at_index_002.width, evaluate_at_index_002.height = 140.0, 100.0
	    position.width, position.height = 140.0, 100.0
	    store_named_attribute_014.width, store_named_attribute_014.height = 140.0, 100.0
	    store_named_attribute_015.width, store_named_attribute_015.height = 140.0, 100.0
	    named_attribute_001_1.width, named_attribute_001_1.height = 140.0, 100.0
	    frame_003.width, frame_003.height = 760.0, 409.0
	    group.width, group.height = 140.0, 100.0
	
	    #initialize ob_data links
	    #store_named_attribute_010.Geometry -> store_named_attribute_011.Geometry
	    ob_data.links.new(store_named_attribute_010.outputs[0], store_named_attribute_011.inputs[0])
	    #edge_vertices_001.Position 2 -> vector_math.Vector
	    ob_data.links.new(edge_vertices_001.outputs[3], vector_math.inputs[0])
	    #edge_vertices_001.Position 1 -> vector_math.Vector
	    ob_data.links.new(edge_vertices_001.outputs[2], vector_math.inputs[1])
	    #vector_math.Vector -> store_named_attribute_010.Value
	    ob_data.links.new(vector_math.outputs[0], store_named_attribute_010.inputs[3])
	    #vector_math.Vector -> vector_math_001.Vector
	    ob_data.links.new(vector_math.outputs[0], vector_math_001.inputs[0])
	    #vector_math_001.Value -> store_named_attribute_011.Value
	    ob_data.links.new(vector_math_001.outputs[1], store_named_attribute_011.inputs[3])
	    #store_named_attribute_011.Geometry -> store_named_attribute_1.Geometry
	    ob_data.links.new(store_named_attribute_011.outputs[0], store_named_attribute_1.inputs[0])
	    #face_area.Area -> store_named_attribute_1.Value
	    ob_data.links.new(face_area.outputs[0], store_named_attribute_1.inputs[3])
	    #store_named_attribute_1.Geometry -> store_named_attribute_004.Geometry
	    ob_data.links.new(store_named_attribute_1.outputs[0], store_named_attribute_004.inputs[0])
	    #corners_of_face.Total -> store_named_attribute_004.Value
	    ob_data.links.new(corners_of_face.outputs[1], store_named_attribute_004.inputs[3])
	    #index.Index -> store_named_attribute_005.Value
	    ob_data.links.new(index.outputs[0], store_named_attribute_005.inputs[3])
	    #vertex_neighbors.Vertex Count -> store_named_attribute_002.Value
	    ob_data.links.new(vertex_neighbors.outputs[0], store_named_attribute_002.inputs[3])
	    #store_named_attribute_005.Geometry -> store_named_attribute_002.Geometry
	    ob_data.links.new(store_named_attribute_005.outputs[0], store_named_attribute_002.inputs[0])
	    #vertex_neighbors.Face Count -> store_named_attribute_003.Value
	    ob_data.links.new(vertex_neighbors.outputs[1], store_named_attribute_003.inputs[3])
	    #store_named_attribute_002.Geometry -> store_named_attribute_003.Geometry
	    ob_data.links.new(store_named_attribute_002.outputs[0], store_named_attribute_003.inputs[0])
	    #store_named_attribute_006.Geometry -> store_named_attribute_007.Geometry
	    ob_data.links.new(store_named_attribute_006.outputs[0], store_named_attribute_007.inputs[0])
	    #store_named_attribute_003.Geometry -> store_named_attribute_006.Geometry
	    ob_data.links.new(store_named_attribute_003.outputs[0], store_named_attribute_006.inputs[0])
	    #corners_of_vertex.Corner Index -> store_named_attribute_007.Value
	    ob_data.links.new(corners_of_vertex.outputs[0], store_named_attribute_007.inputs[3])
	    #face_of_corner.Face Index -> store_named_attribute_006.Value
	    ob_data.links.new(face_of_corner.outputs[0], store_named_attribute_006.inputs[3])
	    #group_input_1.Geometry -> store_named_attribute_005.Geometry
	    ob_data.links.new(group_input_1.outputs[0], store_named_attribute_005.inputs[0])
	    #store_named_attribute_013.Geometry -> store_named_attribute_010.Geometry
	    ob_data.links.new(store_named_attribute_013.outputs[0], store_named_attribute_010.inputs[0])
	    #store_named_attribute_007.Geometry -> store_named_attribute_012.Geometry
	    ob_data.links.new(store_named_attribute_007.outputs[0], store_named_attribute_012.inputs[0])
	    #store_named_attribute_012.Geometry -> store_named_attribute_013.Geometry
	    ob_data.links.new(store_named_attribute_012.outputs[0], store_named_attribute_013.inputs[0])
	    #edge_vertices_001.Vertex Index 1 -> store_named_attribute_012.Value
	    ob_data.links.new(edge_vertices_001.outputs[0], store_named_attribute_012.inputs[3])
	    #edge_vertices_001.Vertex Index 2 -> store_named_attribute_013.Value
	    ob_data.links.new(edge_vertices_001.outputs[1], store_named_attribute_013.inputs[3])
	    #face_of_corner_001.Index in Face -> store_named_attribute_009.Value
	    ob_data.links.new(face_of_corner_001.outputs[1], store_named_attribute_009.inputs[3])
	    #evaluate_at_index_002.Value -> store_named_attribute_014.Value
	    ob_data.links.new(evaluate_at_index_002.outputs[0], store_named_attribute_014.inputs[3])
	    #position.Position -> evaluate_at_index_002.Value
	    ob_data.links.new(position.outputs[0], evaluate_at_index_002.inputs[1])
	    #store_named_attribute_009.Geometry -> store_named_attribute_014.Geometry
	    ob_data.links.new(store_named_attribute_009.outputs[0], store_named_attribute_014.inputs[0])
	    #index_001.Index -> evaluate_at_index_002.Index
	    ob_data.links.new(index_001.outputs[0], evaluate_at_index_002.inputs[0])
	    #store_named_attribute_008.Geometry -> store_named_attribute_009.Geometry
	    ob_data.links.new(store_named_attribute_008.outputs[0], store_named_attribute_009.inputs[0])
	    #face_of_corner_001.Face Index -> store_named_attribute_008.Value
	    ob_data.links.new(face_of_corner_001.outputs[0], store_named_attribute_008.inputs[3])
	    #store_named_attribute_014.Geometry -> store_named_attribute_015.Geometry
	    ob_data.links.new(store_named_attribute_014.outputs[0], store_named_attribute_015.inputs[0])
	    #named_attribute_001_1.Attribute -> store_named_attribute_015.Value
	    ob_data.links.new(named_attribute_001_1.outputs[0], store_named_attribute_015.inputs[3])
	    #store_named_attribute_004.Geometry -> store_named_attribute_008.Geometry
	    ob_data.links.new(store_named_attribute_004.outputs[0], store_named_attribute_008.inputs[0])
	    #group.Geometry -> group_output_1.Geometry
	    ob_data.links.new(group.outputs[0], group_output_1.inputs[0])
	    #store_named_attribute_015.Geometry -> group.Geometry
	    ob_data.links.new(store_named_attribute_015.outputs[0], group.inputs[0])
	    return ob_data
	
	ob_data = ob_data_node_group()
	
	#initialize convex_curve_profile node group
	def convex_curve_profile_node_group():
	    convex_curve_profile = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "CONVEX_CURVE_PROFILE")
	
	    convex_curve_profile.color_tag = 'NONE'
	    convex_curve_profile.description = ""
	    convex_curve_profile.default_group_node_width = 140
	    
	
	
	    #convex_curve_profile interface
	    #Socket Geometry
	    geometry_socket_4 = convex_curve_profile.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_4.attribute_domain = 'POINT'
	
	    #Socket Geometry
	    geometry_socket_5 = convex_curve_profile.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_5.attribute_domain = 'POINT'
	
	    #Socket Surface
	    surface_socket = convex_curve_profile.interface.new_socket(name = "Surface", in_out='INPUT', socket_type = 'NodeSocketObject')
	    surface_socket.attribute_domain = 'POINT'
	
	
	    #initialize convex_curve_profile nodes
	    #node Group Output
	    group_output_2 = convex_curve_profile.nodes.new("NodeGroupOutput")
	    group_output_2.name = "Group Output"
	    group_output_2.is_active_output = True
	
	    #node Group Input
	    group_input_2 = convex_curve_profile.nodes.new("NodeGroupInput")
	    group_input_2.name = "Group Input"
	    group_input_2.outputs[0].hide = True
	    group_input_2.outputs[2].hide = True
	
	    #node Delete Geometry.001
	    delete_geometry_001 = convex_curve_profile.nodes.new("GeometryNodeDeleteGeometry")
	    delete_geometry_001.name = "Delete Geometry.001"
	    delete_geometry_001.hide = True
	    delete_geometry_001.domain = 'FACE'
	    delete_geometry_001.mode = 'ALL'
	
	    #node Sample Nearest
	    sample_nearest = convex_curve_profile.nodes.new("GeometryNodeSampleNearest")
	    sample_nearest.name = "Sample Nearest"
	    sample_nearest.hide = True
	    sample_nearest.domain = 'FACE'
	
	    #node Named Attribute.004
	    named_attribute_004_1 = convex_curve_profile.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute_004_1.name = "Named Attribute.004"
	    named_attribute_004_1.data_type = 'FLOAT_VECTOR'
	    #Name
	    named_attribute_004_1.inputs[0].default_value = "centers"
	
	    #node Sample Index
	    sample_index = convex_curve_profile.nodes.new("GeometryNodeSampleIndex")
	    sample_index.name = "Sample Index"
	    sample_index.hide = True
	    sample_index.clamp = False
	    sample_index.data_type = 'FLOAT_VECTOR'
	    sample_index.domain = 'POINT'
	
	    #node Normal
	    normal = convex_curve_profile.nodes.new("GeometryNodeInputNormal")
	    normal.name = "Normal"
	    normal.legacy_corner_normals = False
	
	    #node Compare.001
	    compare_001_1 = convex_curve_profile.nodes.new("FunctionNodeCompare")
	    compare_001_1.name = "Compare.001"
	    compare_001_1.hide = True
	    compare_001_1.data_type = 'VECTOR'
	    compare_001_1.mode = 'DOT_PRODUCT'
	    compare_001_1.operation = 'LESS_THAN'
	    compare_001_1.inputs[0].hide = True
	    compare_001_1.inputs[1].hide = True
	    compare_001_1.inputs[2].hide = True
	    compare_001_1.inputs[3].hide = True
	    compare_001_1.inputs[6].hide = True
	    compare_001_1.inputs[7].hide = True
	    compare_001_1.inputs[8].hide = True
	    compare_001_1.inputs[9].hide = True
	    compare_001_1.inputs[10].hide = True
	    compare_001_1.inputs[11].hide = True
	    compare_001_1.inputs[12].hide = True
	    #C
	    compare_001_1.inputs[10].default_value = 0.0
	
	    #node Sample Index.001
	    sample_index_001 = convex_curve_profile.nodes.new("GeometryNodeSampleIndex")
	    sample_index_001.name = "Sample Index.001"
	    sample_index_001.hide = True
	    sample_index_001.clamp = False
	    sample_index_001.data_type = 'FLOAT_VECTOR'
	    sample_index_001.domain = 'FACE'
	
	    #node Normal.001
	    normal_001 = convex_curve_profile.nodes.new("GeometryNodeInputNormal")
	    normal_001.name = "Normal.001"
	    normal_001.legacy_corner_normals = False
	
	    #node Index
	    index_1 = convex_curve_profile.nodes.new("GeometryNodeInputIndex")
	    index_1.name = "Index"
	
	    #node Delete Geometry.002
	    delete_geometry_002 = convex_curve_profile.nodes.new("GeometryNodeDeleteGeometry")
	    delete_geometry_002.name = "Delete Geometry.002"
	    delete_geometry_002.hide = True
	    delete_geometry_002.domain = 'EDGE'
	    delete_geometry_002.mode = 'EDGE_FACE'
	
	    #node Compare.002
	    compare_002 = convex_curve_profile.nodes.new("FunctionNodeCompare")
	    compare_002.name = "Compare.002"
	    compare_002.hide = True
	    compare_002.data_type = 'INT'
	    compare_002.mode = 'ELEMENT'
	    compare_002.operation = 'GREATER_THAN'
	    compare_002.inputs[0].hide = True
	    compare_002.inputs[1].hide = True
	    compare_002.inputs[3].hide = True
	    compare_002.inputs[4].hide = True
	    compare_002.inputs[5].hide = True
	    compare_002.inputs[6].hide = True
	    compare_002.inputs[7].hide = True
	    compare_002.inputs[8].hide = True
	    compare_002.inputs[9].hide = True
	    compare_002.inputs[10].hide = True
	    compare_002.inputs[11].hide = True
	    compare_002.inputs[12].hide = True
	    #B_INT
	    compare_002.inputs[3].default_value = 1
	
	    #node Edge Neighbors
	    edge_neighbors = convex_curve_profile.nodes.new("GeometryNodeInputMeshEdgeNeighbors")
	    edge_neighbors.name = "Edge Neighbors"
	
	    #node Merge by Distance.001
	    merge_by_distance_001 = convex_curve_profile.nodes.new("GeometryNodeMergeByDistance")
	    merge_by_distance_001.name = "Merge by Distance.001"
	    merge_by_distance_001.hide = True
	    merge_by_distance_001.mode = 'ALL'
	    #Selection
	    merge_by_distance_001.inputs[1].default_value = True
	    #Distance
	    merge_by_distance_001.inputs[2].default_value = 0.0010000000474974513
	
	    #node Object Info.001
	    object_info_001 = convex_curve_profile.nodes.new("GeometryNodeObjectInfo")
	    object_info_001.name = "Object Info.001"
	    object_info_001.hide = True
	    object_info_001.transform_space = 'RELATIVE'
	    object_info_001.inputs[1].hide = True
	    object_info_001.outputs[0].hide = True
	    object_info_001.outputs[1].hide = True
	    object_info_001.outputs[2].hide = True
	    object_info_001.outputs[3].hide = True
	    #As Instance
	    object_info_001.inputs[1].default_value = False
	
	    #node Mesh to Curve
	    mesh_to_curve = convex_curve_profile.nodes.new("GeometryNodeMeshToCurve")
	    mesh_to_curve.name = "Mesh to Curve"
	    mesh_to_curve.hide = True
	    mesh_to_curve.inputs[1].hide = True
	    #Selection
	    mesh_to_curve.inputs[1].default_value = True
	
	    #node Group Input.001
	    group_input_001 = convex_curve_profile.nodes.new("NodeGroupInput")
	    group_input_001.name = "Group Input.001"
	    group_input_001.outputs[1].hide = True
	    group_input_001.outputs[2].hide = True
	
	    #node Group Input.002
	    group_input_002 = convex_curve_profile.nodes.new("NodeGroupInput")
	    group_input_002.name = "Group Input.002"
	    group_input_002.outputs[1].hide = True
	    group_input_002.outputs[2].hide = True
	
	
	
	
	
	    #Set locations
	    group_output_2.location = (-131.0277099609375, -136.95811462402344)
	    group_input_2.location = (-1372.7032470703125, 0.0)
	    delete_geometry_001.location = (-493.7367858886719, -158.619873046875)
	    sample_nearest.location = (-1047.2716064453125, -74.38338470458984)
	    named_attribute_004_1.location = (-1049.729248046875, -104.1408462524414)
	    sample_index.location = (-867.6522827148438, -34.97990036010742)
	    normal.location = (-871.3107299804688, -66.765625)
	    compare_001_1.location = (-673.4129638671875, -168.19537353515625)
	    sample_index_001.location = (-858.5, -306.8774108886719)
	    normal_001.location = (-1051.0888671875, -297.31158447265625)
	    index_1.location = (-1051.08349609375, -356.73614501953125)
	    delete_geometry_002.location = (-313.3856201171875, -217.2752685546875)
	    compare_002.location = (-312.8627624511719, -254.32992553710938)
	    edge_neighbors.location = (-312.9332580566406, -286.8948669433594)
	    merge_by_distance_001.location = (-493.1096496582031, -211.0828094482422)
	    object_info_001.location = (-1184.5113525390625, -24.985580444335938)
	    mesh_to_curve.location = (-310.79290771484375, -162.5512237548828)
	    group_input_001.location = (-1051.9151611328125, -236.2948760986328)
	    group_input_002.location = (-496.93218994140625, -82.70318603515625)
	
	    #Set dimensions
	    group_output_2.width, group_output_2.height = 140.0, 100.0
	    group_input_2.width, group_input_2.height = 140.0, 100.0
	    delete_geometry_001.width, delete_geometry_001.height = 140.0, 100.0
	    sample_nearest.width, sample_nearest.height = 140.0, 100.0
	    named_attribute_004_1.width, named_attribute_004_1.height = 140.0, 100.0
	    sample_index.width, sample_index.height = 140.0, 100.0
	    normal.width, normal.height = 140.0, 100.0
	    compare_001_1.width, compare_001_1.height = 140.0, 100.0
	    sample_index_001.width, sample_index_001.height = 140.0, 100.0
	    normal_001.width, normal_001.height = 140.0, 100.0
	    index_1.width, index_1.height = 140.0, 100.0
	    delete_geometry_002.width, delete_geometry_002.height = 140.0, 100.0
	    compare_002.width, compare_002.height = 140.0, 100.0
	    edge_neighbors.width, edge_neighbors.height = 140.0, 100.0
	    merge_by_distance_001.width, merge_by_distance_001.height = 140.0, 100.0
	    object_info_001.width, object_info_001.height = 140.0, 100.0
	    mesh_to_curve.width, mesh_to_curve.height = 140.0, 100.0
	    group_input_001.width, group_input_001.height = 140.0, 100.0
	    group_input_002.width, group_input_002.height = 140.0, 100.0
	
	    #initialize convex_curve_profile links
	    #sample_index.Value -> compare_001_1.A
	    convex_curve_profile.links.new(sample_index.outputs[0], compare_001_1.inputs[4])
	    #compare_001_1.Result -> delete_geometry_001.Selection
	    convex_curve_profile.links.new(compare_001_1.outputs[0], delete_geometry_001.inputs[1])
	    #named_attribute_004_1.Attribute -> sample_nearest.Sample Position
	    convex_curve_profile.links.new(named_attribute_004_1.outputs[0], sample_nearest.inputs[1])
	    #sample_nearest.Index -> sample_index.Index
	    convex_curve_profile.links.new(sample_nearest.outputs[0], sample_index.inputs[2])
	    #object_info_001.Geometry -> sample_index.Geometry
	    convex_curve_profile.links.new(object_info_001.outputs[4], sample_index.inputs[0])
	    #normal_001.Normal -> sample_index_001.Value
	    convex_curve_profile.links.new(normal_001.outputs[0], sample_index_001.inputs[1])
	    #edge_neighbors.Face Count -> compare_002.A
	    convex_curve_profile.links.new(edge_neighbors.outputs[0], compare_002.inputs[2])
	    #index_1.Index -> sample_index_001.Index
	    convex_curve_profile.links.new(index_1.outputs[0], sample_index_001.inputs[2])
	    #compare_002.Result -> delete_geometry_002.Selection
	    convex_curve_profile.links.new(compare_002.outputs[0], delete_geometry_002.inputs[1])
	    #sample_index_001.Value -> compare_001_1.B
	    convex_curve_profile.links.new(sample_index_001.outputs[0], compare_001_1.inputs[5])
	    #merge_by_distance_001.Geometry -> delete_geometry_002.Geometry
	    convex_curve_profile.links.new(merge_by_distance_001.outputs[0], delete_geometry_002.inputs[0])
	    #object_info_001.Geometry -> sample_nearest.Geometry
	    convex_curve_profile.links.new(object_info_001.outputs[4], sample_nearest.inputs[0])
	    #normal.Normal -> sample_index.Value
	    convex_curve_profile.links.new(normal.outputs[0], sample_index.inputs[1])
	    #delete_geometry_001.Geometry -> merge_by_distance_001.Geometry
	    convex_curve_profile.links.new(delete_geometry_001.outputs[0], merge_by_distance_001.inputs[0])
	    #group_input_2.Surface -> object_info_001.Object
	    convex_curve_profile.links.new(group_input_2.outputs[1], object_info_001.inputs[0])
	    #delete_geometry_002.Geometry -> mesh_to_curve.Mesh
	    convex_curve_profile.links.new(delete_geometry_002.outputs[0], mesh_to_curve.inputs[0])
	    #mesh_to_curve.Curve -> group_output_2.Geometry
	    convex_curve_profile.links.new(mesh_to_curve.outputs[0], group_output_2.inputs[0])
	    #group_input_001.Geometry -> sample_index_001.Geometry
	    convex_curve_profile.links.new(group_input_001.outputs[0], sample_index_001.inputs[0])
	    #group_input_002.Geometry -> delete_geometry_001.Geometry
	    convex_curve_profile.links.new(group_input_002.outputs[0], delete_geometry_001.inputs[0])
	    return convex_curve_profile
	
	convex_curve_profile = convex_curve_profile_node_group()
	
	#initialize curve_from_centroids node group
	def curve_from_centroids_node_group():
	    curve_from_centroids = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "CURVE_FROM_CENTROIDS")
	
	    curve_from_centroids.color_tag = 'NONE'
	    curve_from_centroids.description = "Create new curve from centroids of multiple curves."
	    curve_from_centroids.default_group_node_width = 140
	    
	
	    curve_from_centroids.is_modifier = True
	
	    #curve_from_centroids interface
	    #Socket Geometry
	    geometry_socket_6 = curve_from_centroids.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_6.attribute_domain = 'POINT'
	    geometry_socket_6.description = "New curve along centroid."
	
	    #Socket Geometry
	    geometry_socket_7 = curve_from_centroids.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_7.attribute_domain = 'POINT'
	    geometry_socket_7.description = "Curve with multiple splines."
	
	
	    #initialize curve_from_centroids nodes
	    #node Group Output
	    group_output_3 = curve_from_centroids.nodes.new("NodeGroupOutput")
	    group_output_3.name = "Group Output"
	    group_output_3.is_active_output = True
	    group_output_3.inputs[1].hide = True
	
	    #node Group Input
	    group_input_3 = curve_from_centroids.nodes.new("NodeGroupInput")
	    group_input_3.name = "Group Input"
	    group_input_3.outputs[1].hide = True
	
	    #node Repeat Input
	    repeat_input = curve_from_centroids.nodes.new("GeometryNodeRepeatInput")
	    repeat_input.name = "Repeat Input"
	    #node Repeat Output
	    repeat_output = curve_from_centroids.nodes.new("GeometryNodeRepeatOutput")
	    repeat_output.name = "Repeat Output"
	    repeat_output.active_index = 0
	    repeat_output.inspection_index = 0
	    repeat_output.repeat_items.clear()
	    # Create item "Geometry"
	    repeat_output.repeat_items.new('GEOMETRY', "Geometry")
	
	    #node Domain Size
	    domain_size = curve_from_centroids.nodes.new("GeometryNodeAttributeDomainSize")
	    domain_size.name = "Domain Size"
	    domain_size.hide = True
	    domain_size.component = 'CURVE'
	
	    #node Math
	    math = curve_from_centroids.nodes.new("ShaderNodeMath")
	    math.name = "Math"
	    math.hide = True
	    math.operation = 'DIVIDE'
	    math.use_clamp = False
	
	    #node Attribute Statistic
	    attribute_statistic = curve_from_centroids.nodes.new("GeometryNodeAttributeStatistic")
	    attribute_statistic.name = "Attribute Statistic"
	    attribute_statistic.hide = True
	    attribute_statistic.data_type = 'FLOAT_VECTOR'
	    attribute_statistic.domain = 'POINT'
	    attribute_statistic.outputs[1].hide = True
	    attribute_statistic.outputs[2].hide = True
	    attribute_statistic.outputs[3].hide = True
	    attribute_statistic.outputs[4].hide = True
	    attribute_statistic.outputs[5].hide = True
	    attribute_statistic.outputs[6].hide = True
	    attribute_statistic.outputs[7].hide = True
	
	    #node Position
	    position_1 = curve_from_centroids.nodes.new("GeometryNodeInputPosition")
	    position_1.name = "Position"
	
	    #node Compare
	    compare = curve_from_centroids.nodes.new("FunctionNodeCompare")
	    compare.name = "Compare"
	    compare.hide = True
	    compare.data_type = 'INT'
	    compare.mode = 'ELEMENT'
	    compare.operation = 'EQUAL'
	    compare.inputs[0].hide = True
	    compare.inputs[1].hide = True
	    compare.inputs[4].hide = True
	    compare.inputs[5].hide = True
	    compare.inputs[6].hide = True
	    compare.inputs[7].hide = True
	    compare.inputs[8].hide = True
	    compare.inputs[9].hide = True
	    compare.inputs[10].hide = True
	    compare.inputs[11].hide = True
	    compare.inputs[12].hide = True
	
	    #node Index
	    index_2 = curve_from_centroids.nodes.new("GeometryNodeInputIndex")
	    index_2.name = "Index"
	
	    #node Math.001
	    math_001 = curve_from_centroids.nodes.new("ShaderNodeMath")
	    math_001.name = "Math.001"
	    math_001.hide = True
	    math_001.operation = 'FLOORED_MODULO'
	    math_001.use_clamp = False
	
	    #node Join Geometry
	    join_geometry = curve_from_centroids.nodes.new("GeometryNodeJoinGeometry")
	    join_geometry.name = "Join Geometry"
	    join_geometry.hide = True
	
	    #node Points
	    points = curve_from_centroids.nodes.new("GeometryNodePoints")
	    points.name = "Points"
	    points.hide = True
	    points.inputs[0].hide = True
	    points.inputs[2].hide = True
	    #Count
	    points.inputs[0].default_value = 1
	    #Radius
	    points.inputs[2].default_value = 0.10000000149011612
	
	    #node Points to Curves
	    points_to_curves = curve_from_centroids.nodes.new("GeometryNodePointsToCurves")
	    points_to_curves.name = "Points to Curves"
	    points_to_curves.inputs[1].hide = True
	    points_to_curves.inputs[2].hide = True
	    #Curve Group ID
	    points_to_curves.inputs[1].default_value = 0
	    #Weight
	    points_to_curves.inputs[2].default_value = 0.0
	
	    #node Group Input.001
	    group_input_001_1 = curve_from_centroids.nodes.new("NodeGroupInput")
	    group_input_001_1.name = "Group Input.001"
	    group_input_001_1.outputs[1].hide = True
	
	    #node Reroute
	    reroute = curve_from_centroids.nodes.new("NodeReroute")
	    reroute.name = "Reroute"
	    reroute.socket_idname = "NodeSocketFloat"
	    #node Reroute.001
	    reroute_001 = curve_from_centroids.nodes.new("NodeReroute")
	    reroute_001.name = "Reroute.001"
	    reroute_001.socket_idname = "NodeSocketFloat"
	
	    #Process zone input Repeat Input
	    repeat_input.pair_with_output(repeat_output)
	
	
	
	
	
	    #Set locations
	    group_output_3.location = (1302.4775390625, -33.473915100097656)
	    group_input_3.location = (-200.0, 0.0)
	    repeat_input.location = (190.50888061523438, -15.57342529296875)
	    repeat_output.location = (960.9061279296875, -56.923553466796875)
	    domain_size.location = (-17.454999923706055, -24.502897262573242)
	    math.location = (-15.655715942382812, -60.950531005859375)
	    attribute_statistic.location = (601.8110961914062, -193.2510528564453)
	    position_1.location = (603.0748901367188, -224.40174865722656)
	    compare.location = (421.454833984375, -243.2841339111328)
	    index_2.location = (420.0198974609375, -145.9272918701172)
	    math_001.location = (419.6551513671875, -207.2341766357422)
	    join_geometry.location = (780.789794921875, -82.40153503417969)
	    points.location = (778.607666015625, -120.22016906738281)
	    points_to_curves.location = (1130.0872802734375, -31.979248046875)
	    group_input_001_1.location = (600.9574584960938, -131.9265899658203)
	    reroute.location = (162.4088134765625, -72.65477752685547)
	    reroute_001.location = (165.49166870117188, -227.18580627441406)
	
	    #Set dimensions
	    group_output_3.width, group_output_3.height = 140.0, 100.0
	    group_input_3.width, group_input_3.height = 140.0, 100.0
	    repeat_input.width, repeat_input.height = 140.0, 100.0
	    repeat_output.width, repeat_output.height = 140.0, 100.0
	    domain_size.width, domain_size.height = 140.0, 100.0
	    math.width, math.height = 140.0, 100.0
	    attribute_statistic.width, attribute_statistic.height = 140.0, 100.0
	    position_1.width, position_1.height = 140.0, 100.0
	    compare.width, compare.height = 140.0, 100.0
	    index_2.width, index_2.height = 140.0, 100.0
	    math_001.width, math_001.height = 140.0, 100.0
	    join_geometry.width, join_geometry.height = 140.0, 100.0
	    points.width, points.height = 140.0, 100.0
	    points_to_curves.width, points_to_curves.height = 140.0, 100.0
	    group_input_001_1.width, group_input_001_1.height = 140.0, 100.0
	    reroute.width, reroute.height = 10.0, 100.0
	    reroute_001.width, reroute_001.height = 10.0, 100.0
	
	    #initialize curve_from_centroids links
	    #group_input_3.Geometry -> domain_size.Geometry
	    curve_from_centroids.links.new(group_input_3.outputs[0], domain_size.inputs[0])
	    #domain_size.Point Count -> math.Value
	    curve_from_centroids.links.new(domain_size.outputs[0], math.inputs[0])
	    #domain_size.Spline Count -> math.Value
	    curve_from_centroids.links.new(domain_size.outputs[4], math.inputs[1])
	    #reroute.Output -> repeat_input.Iterations
	    curve_from_centroids.links.new(reroute.outputs[0], repeat_input.inputs[0])
	    #position_1.Position -> attribute_statistic.Attribute
	    curve_from_centroids.links.new(position_1.outputs[0], attribute_statistic.inputs[2])
	    #index_2.Index -> math_001.Value
	    curve_from_centroids.links.new(index_2.outputs[0], math_001.inputs[0])
	    #reroute_001.Output -> math_001.Value
	    curve_from_centroids.links.new(reroute_001.outputs[0], math_001.inputs[1])
	    #compare.Result -> attribute_statistic.Selection
	    curve_from_centroids.links.new(compare.outputs[0], attribute_statistic.inputs[1])
	    #repeat_input.Iteration -> compare.B
	    curve_from_centroids.links.new(repeat_input.outputs[0], compare.inputs[3])
	    #math_001.Value -> compare.A
	    curve_from_centroids.links.new(math_001.outputs[0], compare.inputs[2])
	    #join_geometry.Geometry -> repeat_output.Geometry
	    curve_from_centroids.links.new(join_geometry.outputs[0], repeat_output.inputs[0])
	    #attribute_statistic.Mean -> points.Position
	    curve_from_centroids.links.new(attribute_statistic.outputs[0], points.inputs[1])
	    #points.Points -> join_geometry.Geometry
	    curve_from_centroids.links.new(points.outputs[0], join_geometry.inputs[0])
	    #repeat_output.Geometry -> points_to_curves.Points
	    curve_from_centroids.links.new(repeat_output.outputs[0], points_to_curves.inputs[0])
	    #group_input_001_1.Geometry -> attribute_statistic.Geometry
	    curve_from_centroids.links.new(group_input_001_1.outputs[0], attribute_statistic.inputs[0])
	    #points_to_curves.Curves -> group_output_3.Geometry
	    curve_from_centroids.links.new(points_to_curves.outputs[0], group_output_3.inputs[0])
	    #math.Value -> reroute.Input
	    curve_from_centroids.links.new(math.outputs[0], reroute.inputs[0])
	    #reroute.Output -> reroute_001.Input
	    curve_from_centroids.links.new(reroute.outputs[0], reroute_001.inputs[0])
	    #repeat_input.Geometry -> join_geometry.Geometry
	    curve_from_centroids.links.new(repeat_input.outputs[1], join_geometry.inputs[0])
	    return curve_from_centroids
	
	curve_from_centroids = curve_from_centroids_node_group()
	
	#initialize curve_root node group
	def curve_root_node_group():
	    curve_root = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Curve Root")
	
	    curve_root.color_tag = 'INPUT'
	    curve_root.description = "Reads information about each curve's root point"
	    curve_root.default_group_node_width = 140
	    
	
	
	    #curve_root interface
	    #Socket Root Selection
	    root_selection_socket = curve_root.interface.new_socket(name = "Root Selection", in_out='OUTPUT', socket_type = 'NodeSocketBool')
	    root_selection_socket.default_value = False
	    root_selection_socket.attribute_domain = 'POINT'
	    root_selection_socket.description = "Boolean selection of curve root points"
	
	    #Socket Root Position
	    root_position_socket = curve_root.interface.new_socket(name = "Root Position", in_out='OUTPUT', socket_type = 'NodeSocketVector')
	    root_position_socket.default_value = (0.0, 0.0, 0.0)
	    root_position_socket.min_value = -3.4028234663852886e+38
	    root_position_socket.max_value = 3.4028234663852886e+38
	    root_position_socket.subtype = 'NONE'
	    root_position_socket.attribute_domain = 'CURVE'
	    root_position_socket.description = "Position of the root point of a curve"
	
	    #Socket Root Direction
	    root_direction_socket = curve_root.interface.new_socket(name = "Root Direction", in_out='OUTPUT', socket_type = 'NodeSocketVector')
	    root_direction_socket.default_value = (0.0, 0.0, 0.0)
	    root_direction_socket.min_value = -3.4028234663852886e+38
	    root_direction_socket.max_value = 3.4028234663852886e+38
	    root_direction_socket.subtype = 'NONE'
	    root_direction_socket.attribute_domain = 'CURVE'
	    root_direction_socket.description = "Direction of the root segment of a curve"
	
	    #Socket Root Index
	    root_index_socket = curve_root.interface.new_socket(name = "Root Index", in_out='OUTPUT', socket_type = 'NodeSocketInt')
	    root_index_socket.default_value = 0
	    root_index_socket.min_value = -2147483648
	    root_index_socket.max_value = 2147483647
	    root_index_socket.subtype = 'NONE'
	    root_index_socket.attribute_domain = 'CURVE'
	    root_index_socket.description = "Index of the root point of a curve"
	
	
	    #initialize curve_root nodes
	    #node Position.002
	    position_002 = curve_root.nodes.new("GeometryNodeInputPosition")
	    position_002.name = "Position.002"
	
	    #node Interpolate Domain
	    interpolate_domain = curve_root.nodes.new("GeometryNodeFieldOnDomain")
	    interpolate_domain.name = "Interpolate Domain"
	    interpolate_domain.data_type = 'INT'
	    interpolate_domain.domain = 'CURVE'
	
	    #node Field at Index.003
	    field_at_index_003 = curve_root.nodes.new("GeometryNodeFieldAtIndex")
	    field_at_index_003.name = "Field at Index.003"
	    field_at_index_003.data_type = 'FLOAT_VECTOR'
	    field_at_index_003.domain = 'POINT'
	
	    #node Interpolate Domain.001
	    interpolate_domain_001 = curve_root.nodes.new("GeometryNodeFieldOnDomain")
	    interpolate_domain_001.name = "Interpolate Domain.001"
	    interpolate_domain_001.data_type = 'FLOAT_VECTOR'
	    interpolate_domain_001.domain = 'CURVE'
	
	    #node Curve Tangent
	    curve_tangent = curve_root.nodes.new("GeometryNodeInputTangent")
	    curve_tangent.name = "Curve Tangent"
	
	    #node Endpoint Selection
	    endpoint_selection = curve_root.nodes.new("GeometryNodeCurveEndpointSelection")
	    endpoint_selection.name = "Endpoint Selection"
	    #Start Size
	    endpoint_selection.inputs[0].default_value = 1
	    #End Size
	    endpoint_selection.inputs[1].default_value = 0
	
	    #node Field at Index.004
	    field_at_index_004 = curve_root.nodes.new("GeometryNodeFieldAtIndex")
	    field_at_index_004.name = "Field at Index.004"
	    field_at_index_004.data_type = 'FLOAT_VECTOR'
	    field_at_index_004.domain = 'POINT'
	
	    #node Interpolate Domain.002
	    interpolate_domain_002 = curve_root.nodes.new("GeometryNodeFieldOnDomain")
	    interpolate_domain_002.name = "Interpolate Domain.002"
	    interpolate_domain_002.data_type = 'FLOAT_VECTOR'
	    interpolate_domain_002.domain = 'CURVE'
	
	    #node Group Output
	    group_output_4 = curve_root.nodes.new("NodeGroupOutput")
	    group_output_4.name = "Group Output"
	    group_output_4.is_active_output = True
	
	    #node Points of Curve
	    points_of_curve = curve_root.nodes.new("GeometryNodePointsOfCurve")
	    points_of_curve.name = "Points of Curve"
	    points_of_curve.inputs[0].hide = True
	    points_of_curve.inputs[1].hide = True
	    points_of_curve.outputs[1].hide = True
	    #Curve Index
	    points_of_curve.inputs[0].default_value = 0
	    #Weights
	    points_of_curve.inputs[1].default_value = 0.0
	    #Sort Index
	    points_of_curve.inputs[2].default_value = 0
	
	
	
	
	
	    #Set locations
	    position_002.location = (-608.1627807617188, -70.55814361572266)
	    interpolate_domain.location = (-608.1627807617188, 90.18604278564453)
	    field_at_index_003.location = (-407.2325439453125, 70.09302520751953)
	    interpolate_domain_001.location = (-206.30230712890625, 70.09302520751953)
	    curve_tangent.location = (-608.1627807617188, -271.4883728027344)
	    endpoint_selection.location = (-206.30230712890625, 190.65118408203125)
	    field_at_index_004.location = (-407.2325439453125, -130.83721923828125)
	    interpolate_domain_002.location = (-206.30230712890625, -130.83721923828125)
	    group_output_4.location = (75.0, 50.0)
	    points_of_curve.location = (-789.0, 50.0)
	
	    #Set dimensions
	    position_002.width, position_002.height = 140.0, 100.0
	    interpolate_domain.width, interpolate_domain.height = 140.0, 100.0
	    field_at_index_003.width, field_at_index_003.height = 140.0, 100.0
	    interpolate_domain_001.width, interpolate_domain_001.height = 140.0, 100.0
	    curve_tangent.width, curve_tangent.height = 140.0, 100.0
	    endpoint_selection.width, endpoint_selection.height = 140.0, 100.0
	    field_at_index_004.width, field_at_index_004.height = 140.0, 100.0
	    interpolate_domain_002.width, interpolate_domain_002.height = 140.0, 100.0
	    group_output_4.width, group_output_4.height = 140.0, 100.0
	    points_of_curve.width, points_of_curve.height = 140.0, 100.0
	
	    #initialize curve_root links
	    #position_002.Position -> field_at_index_003.Value
	    curve_root.links.new(position_002.outputs[0], field_at_index_003.inputs[1])
	    #interpolate_domain_001.Value -> group_output_4.Root Position
	    curve_root.links.new(interpolate_domain_001.outputs[0], group_output_4.inputs[1])
	    #interpolate_domain.Value -> field_at_index_003.Index
	    curve_root.links.new(interpolate_domain.outputs[0], field_at_index_003.inputs[0])
	    #points_of_curve.Point Index -> interpolate_domain.Value
	    curve_root.links.new(points_of_curve.outputs[0], interpolate_domain.inputs[0])
	    #interpolate_domain.Value -> group_output_4.Root Index
	    curve_root.links.new(interpolate_domain.outputs[0], group_output_4.inputs[3])
	    #endpoint_selection.Selection -> group_output_4.Root Selection
	    curve_root.links.new(endpoint_selection.outputs[0], group_output_4.inputs[0])
	    #field_at_index_003.Value -> interpolate_domain_001.Value
	    curve_root.links.new(field_at_index_003.outputs[0], interpolate_domain_001.inputs[0])
	    #interpolate_domain_002.Value -> group_output_4.Root Direction
	    curve_root.links.new(interpolate_domain_002.outputs[0], group_output_4.inputs[2])
	    #interpolate_domain.Value -> field_at_index_004.Index
	    curve_root.links.new(interpolate_domain.outputs[0], field_at_index_004.inputs[0])
	    #curve_tangent.Tangent -> field_at_index_004.Value
	    curve_root.links.new(curve_tangent.outputs[0], field_at_index_004.inputs[1])
	    #field_at_index_004.Value -> interpolate_domain_002.Value
	    curve_root.links.new(field_at_index_004.outputs[0], interpolate_domain_002.inputs[0])
	    return curve_root
	
	curve_root = curve_root_node_group()
	
	#initialize curve_segment node group
	def curve_segment_node_group():
	    curve_segment = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Curve Segment")
	
	    curve_segment.color_tag = 'INPUT'
	    curve_segment.description = ""
	    curve_segment.default_group_node_width = 140
	    
	
	
	    #curve_segment interface
	    #Socket Segment Length
	    segment_length_socket = curve_segment.interface.new_socket(name = "Segment Length", in_out='OUTPUT', socket_type = 'NodeSocketFloat')
	    segment_length_socket.default_value = 0.0
	    segment_length_socket.min_value = -3.4028234663852886e+38
	    segment_length_socket.max_value = 3.4028234663852886e+38
	    segment_length_socket.subtype = 'NONE'
	    segment_length_socket.attribute_domain = 'POINT'
	    segment_length_socket.description = "Distance to previous point on curve"
	
	    #Socket Segment Direction
	    segment_direction_socket = curve_segment.interface.new_socket(name = "Segment Direction", in_out='OUTPUT', socket_type = 'NodeSocketVector')
	    segment_direction_socket.default_value = (0.0, 0.0, 0.0)
	    segment_direction_socket.min_value = -3.4028234663852886e+38
	    segment_direction_socket.max_value = 3.4028234663852886e+38
	    segment_direction_socket.subtype = 'NONE'
	    segment_direction_socket.attribute_domain = 'POINT'
	    segment_direction_socket.description = "Direction from previous neighboring point on segment"
	
	    #Socket Neighbor Index
	    neighbor_index_socket = curve_segment.interface.new_socket(name = "Neighbor Index", in_out='OUTPUT', socket_type = 'NodeSocketInt')
	    neighbor_index_socket.default_value = 0
	    neighbor_index_socket.min_value = -2147483648
	    neighbor_index_socket.max_value = 2147483647
	    neighbor_index_socket.subtype = 'NONE'
	    neighbor_index_socket.attribute_domain = 'POINT'
	    neighbor_index_socket.description = "Index of previous neighboring point on segment"
	
	
	    #initialize curve_segment nodes
	    #node Vector Math.009
	    vector_math_009 = curve_segment.nodes.new("ShaderNodeVectorMath")
	    vector_math_009.name = "Vector Math.009"
	    vector_math_009.operation = 'NORMALIZE'
	
	    #node Reroute.015
	    reroute_015 = curve_segment.nodes.new("NodeReroute")
	    reroute_015.name = "Reroute.015"
	    reroute_015.socket_idname = "NodeSocketVector"
	    #node Reroute.017
	    reroute_017 = curve_segment.nodes.new("NodeReroute")
	    reroute_017.name = "Reroute.017"
	    reroute_017.socket_idname = "NodeSocketVector"
	    #node Field at Index.001
	    field_at_index_001 = curve_segment.nodes.new("GeometryNodeFieldAtIndex")
	    field_at_index_001.name = "Field at Index.001"
	    field_at_index_001.data_type = 'FLOAT_VECTOR'
	    field_at_index_001.domain = 'POINT'
	
	    #node Vector Math.008
	    vector_math_008 = curve_segment.nodes.new("ShaderNodeVectorMath")
	    vector_math_008.name = "Vector Math.008"
	    vector_math_008.operation = 'SUBTRACT'
	
	    #node Reroute.018
	    reroute_018 = curve_segment.nodes.new("NodeReroute")
	    reroute_018.name = "Reroute.018"
	    reroute_018.socket_idname = "NodeSocketInt"
	    #node Interpolate Domain.002
	    interpolate_domain_002_1 = curve_segment.nodes.new("GeometryNodeFieldOnDomain")
	    interpolate_domain_002_1.name = "Interpolate Domain.002"
	    interpolate_domain_002_1.data_type = 'FLOAT_VECTOR'
	    interpolate_domain_002_1.domain = 'POINT'
	
	    #node Group Output
	    group_output_5 = curve_segment.nodes.new("NodeGroupOutput")
	    group_output_5.name = "Group Output"
	    group_output_5.is_active_output = True
	
	    #node Vector Math.007
	    vector_math_007 = curve_segment.nodes.new("ShaderNodeVectorMath")
	    vector_math_007.name = "Vector Math.007"
	    vector_math_007.operation = 'LENGTH'
	
	    #node Interpolate Domain.003
	    interpolate_domain_003 = curve_segment.nodes.new("GeometryNodeFieldOnDomain")
	    interpolate_domain_003.name = "Interpolate Domain.003"
	    interpolate_domain_003.data_type = 'INT'
	    interpolate_domain_003.domain = 'POINT'
	
	    #node Reroute
	    reroute_1 = curve_segment.nodes.new("NodeReroute")
	    reroute_1.name = "Reroute"
	    reroute_1.socket_idname = "NodeSocketBool"
	    #node Switch.004
	    switch_004 = curve_segment.nodes.new("GeometryNodeSwitch")
	    switch_004.name = "Switch.004"
	    switch_004.hide = True
	    switch_004.input_type = 'VECTOR'
	    #False
	    switch_004.inputs[1].default_value = (0.0, 0.0, 0.0)
	
	    #node Switch.003
	    switch_003 = curve_segment.nodes.new("GeometryNodeSwitch")
	    switch_003.name = "Switch.003"
	    switch_003.hide = True
	    switch_003.input_type = 'FLOAT'
	    #False
	    switch_003.inputs[1].default_value = 0.0
	
	    #node Boolean
	    boolean = curve_segment.nodes.new("FunctionNodeInputBool")
	    boolean.name = "Boolean"
	    boolean.boolean = True
	
	    #node Interpolate Domain
	    interpolate_domain_1 = curve_segment.nodes.new("GeometryNodeFieldOnDomain")
	    interpolate_domain_1.name = "Interpolate Domain"
	    interpolate_domain_1.data_type = 'BOOLEAN'
	    interpolate_domain_1.domain = 'CURVE'
	
	    #node Switch.005
	    switch_005 = curve_segment.nodes.new("GeometryNodeSwitch")
	    switch_005.name = "Switch.005"
	    switch_005.hide = True
	    switch_005.input_type = 'INT'
	    #False
	    switch_005.inputs[1].default_value = 0
	
	    #node Index.002
	    index_002 = curve_segment.nodes.new("GeometryNodeInputIndex")
	    index_002.name = "Index.002"
	
	    #node Switch.001
	    switch_001 = curve_segment.nodes.new("GeometryNodeSwitch")
	    switch_001.name = "Switch.001"
	    switch_001.input_type = 'INT'
	
	    #node Offset Point in Curve
	    offset_point_in_curve = curve_segment.nodes.new("GeometryNodeOffsetPointInCurve")
	    offset_point_in_curve.name = "Offset Point in Curve"
	    #Point Index
	    offset_point_in_curve.inputs[0].default_value = 0
	    #Offset
	    offset_point_in_curve.inputs[1].default_value = -1
	
	    #node Position.002
	    position_002_1 = curve_segment.nodes.new("GeometryNodeInputPosition")
	    position_002_1.name = "Position.002"
	
	
	
	
	
	    #Set locations
	    vector_math_009.location = (-389.8524169921875, 30.443286895751953)
	    reroute_015.location = (-456.8948974609375, 4.604297637939453)
	    reroute_017.location = (-1012.7362060546875, -9.742748260498047)
	    field_at_index_001.location = (-992.6431884765625, 70.62931823730469)
	    vector_math_008.location = (-811.805908203125, 70.62931823730469)
	    reroute_018.location = (-1032.8292236328125, 110.81541442871094)
	    interpolate_domain_002_1.location = (-630.9686279296875, 70.62931823730469)
	    group_output_5.location = (75.0, 50.0)
	    vector_math_007.location = (-389.8524169921875, 151.00144958496094)
	    interpolate_domain_003.location = (-390.85833740234375, -97.25408935546875)
	    reroute_1.location = (-342.979248046875, 193.345458984375)
	    switch_004.location = (-178.8756103515625, 10.35025405883789)
	    switch_003.location = (-178.8756103515625, 90.72234344482422)
	    boolean.location = (-781.6663208007812, 291.652587890625)
	    interpolate_domain_1.location = (-600.8291015625, 311.74560546875)
	    switch_005.location = (-178.8756103515625, -70.0218505859375)
	    index_002.location = (-1404.550048828125, 211.28048706054688)
	    switch_001.location = (-1223.712890625, 231.37350463867188)
	    offset_point_in_curve.location = (-1404.550048828125, 151.0014190673828)
	    position_002_1.location = (-1223.712890625, 30.44327163696289)
	
	    #Set dimensions
	    vector_math_009.width, vector_math_009.height = 140.0, 100.0
	    reroute_015.width, reroute_015.height = 16.0, 100.0
	    reroute_017.width, reroute_017.height = 16.0, 100.0
	    field_at_index_001.width, field_at_index_001.height = 140.0, 100.0
	    vector_math_008.width, vector_math_008.height = 140.0, 100.0
	    reroute_018.width, reroute_018.height = 16.0, 100.0
	    interpolate_domain_002_1.width, interpolate_domain_002_1.height = 140.0, 100.0
	    group_output_5.width, group_output_5.height = 140.0, 100.0
	    vector_math_007.width, vector_math_007.height = 140.0, 100.0
	    interpolate_domain_003.width, interpolate_domain_003.height = 140.0, 100.0
	    reroute_1.width, reroute_1.height = 16.0, 100.0
	    switch_004.width, switch_004.height = 140.0, 100.0
	    switch_003.width, switch_003.height = 140.0, 100.0
	    boolean.width, boolean.height = 140.0, 100.0
	    interpolate_domain_1.width, interpolate_domain_1.height = 140.0, 100.0
	    switch_005.width, switch_005.height = 140.0, 100.0
	    index_002.width, index_002.height = 140.0, 100.0
	    switch_001.width, switch_001.height = 140.0, 100.0
	    offset_point_in_curve.width, offset_point_in_curve.height = 140.0, 100.0
	    position_002_1.width, position_002_1.height = 140.0, 100.0
	
	    #initialize curve_segment links
	    #reroute_015.Output -> vector_math_007.Vector
	    curve_segment.links.new(reroute_015.outputs[0], vector_math_007.inputs[0])
	    #reroute_018.Output -> field_at_index_001.Index
	    curve_segment.links.new(reroute_018.outputs[0], field_at_index_001.inputs[0])
	    #vector_math_008.Vector -> interpolate_domain_002_1.Value
	    curve_segment.links.new(vector_math_008.outputs[0], interpolate_domain_002_1.inputs[0])
	    #reroute_017.Output -> vector_math_008.Vector
	    curve_segment.links.new(reroute_017.outputs[0], vector_math_008.inputs[0])
	    #reroute_015.Output -> vector_math_009.Vector
	    curve_segment.links.new(reroute_015.outputs[0], vector_math_009.inputs[0])
	    #reroute_017.Output -> field_at_index_001.Value
	    curve_segment.links.new(reroute_017.outputs[0], field_at_index_001.inputs[1])
	    #field_at_index_001.Value -> vector_math_008.Vector
	    curve_segment.links.new(field_at_index_001.outputs[0], vector_math_008.inputs[1])
	    #position_002_1.Position -> reroute_017.Input
	    curve_segment.links.new(position_002_1.outputs[0], reroute_017.inputs[0])
	    #interpolate_domain_002_1.Value -> reroute_015.Input
	    curve_segment.links.new(interpolate_domain_002_1.outputs[0], reroute_015.inputs[0])
	    #switch_004.Output -> group_output_5.Segment Direction
	    curve_segment.links.new(switch_004.outputs[0], group_output_5.inputs[1])
	    #switch_005.Output -> group_output_5.Neighbor Index
	    curve_segment.links.new(switch_005.outputs[0], group_output_5.inputs[2])
	    #boolean.Boolean -> interpolate_domain_1.Value
	    curve_segment.links.new(boolean.outputs[0], interpolate_domain_1.inputs[0])
	    #reroute_018.Output -> interpolate_domain_003.Value
	    curve_segment.links.new(reroute_018.outputs[0], interpolate_domain_003.inputs[0])
	    #vector_math_007.Value -> switch_003.True
	    curve_segment.links.new(vector_math_007.outputs[1], switch_003.inputs[2])
	    #reroute_1.Output -> switch_003.Switch
	    curve_segment.links.new(reroute_1.outputs[0], switch_003.inputs[0])
	    #switch_003.Output -> group_output_5.Segment Length
	    curve_segment.links.new(switch_003.outputs[0], group_output_5.inputs[0])
	    #vector_math_009.Vector -> switch_004.True
	    curve_segment.links.new(vector_math_009.outputs[0], switch_004.inputs[2])
	    #interpolate_domain_1.Value -> reroute_1.Input
	    curve_segment.links.new(interpolate_domain_1.outputs[0], reroute_1.inputs[0])
	    #reroute_1.Output -> switch_004.Switch
	    curve_segment.links.new(reroute_1.outputs[0], switch_004.inputs[0])
	    #interpolate_domain_003.Value -> switch_005.True
	    curve_segment.links.new(interpolate_domain_003.outputs[0], switch_005.inputs[2])
	    #reroute_1.Output -> switch_005.Switch
	    curve_segment.links.new(reroute_1.outputs[0], switch_005.inputs[0])
	    #offset_point_in_curve.Is Valid Offset -> switch_001.Switch
	    curve_segment.links.new(offset_point_in_curve.outputs[0], switch_001.inputs[0])
	    #offset_point_in_curve.Point Index -> switch_001.True
	    curve_segment.links.new(offset_point_in_curve.outputs[1], switch_001.inputs[2])
	    #index_002.Index -> switch_001.False
	    curve_segment.links.new(index_002.outputs[0], switch_001.inputs[1])
	    #switch_001.Output -> reroute_018.Input
	    curve_segment.links.new(switch_001.outputs[0], reroute_018.inputs[0])
	    return curve_segment
	
	curve_segment = curve_segment_node_group()
	
	#initialize restore_curve_segment_length node group
	def restore_curve_segment_length_node_group():
	    restore_curve_segment_length = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Restore Curve Segment Length")
	
	    restore_curve_segment_length.color_tag = 'GEOMETRY'
	    restore_curve_segment_length.description = "Restores the length of each curve segment using a previous state after deformation"
	    restore_curve_segment_length.default_group_node_width = 140
	    
	
	    restore_curve_segment_length.is_modifier = True
	
	    #restore_curve_segment_length interface
	    #Socket Curves
	    curves_socket = restore_curve_segment_length.interface.new_socket(name = "Curves", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    curves_socket.attribute_domain = 'POINT'
	
	    #Socket Curves
	    curves_socket_1 = restore_curve_segment_length.interface.new_socket(name = "Curves", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    curves_socket_1.attribute_domain = 'POINT'
	
	    #Socket Selection
	    selection_socket = restore_curve_segment_length.interface.new_socket(name = "Selection", in_out='INPUT', socket_type = 'NodeSocketBool')
	    selection_socket.default_value = True
	    selection_socket.attribute_domain = 'POINT'
	    selection_socket.hide_value = True
	    selection_socket.description = "Only affect selected elements"
	
	    #Socket Factor
	    factor_socket = restore_curve_segment_length.interface.new_socket(name = "Factor", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    factor_socket.default_value = 1.0
	    factor_socket.min_value = 0.0
	    factor_socket.max_value = 1.0
	    factor_socket.subtype = 'FACTOR'
	    factor_socket.attribute_domain = 'POINT'
	    factor_socket.description = "Factor to blend overall effect"
	
	    #Socket Reference Position
	    reference_position_socket = restore_curve_segment_length.interface.new_socket(name = "Reference Position", in_out='INPUT', socket_type = 'NodeSocketVector')
	    reference_position_socket.default_value = (8.146539688110352, 4.969870090484619, 9.874540328979492)
	    reference_position_socket.min_value = -3.4028234663852886e+38
	    reference_position_socket.max_value = 3.4028234663852886e+38
	    reference_position_socket.subtype = 'NONE'
	    reference_position_socket.default_attribute_name = "rest_position"
	    reference_position_socket.attribute_domain = 'POINT'
	    reference_position_socket.hide_value = True
	    reference_position_socket.description = "Reference position before deformation"
	
	    #Socket Pin at Parameter
	    pin_at_parameter_socket = restore_curve_segment_length.interface.new_socket(name = "Pin at Parameter", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    pin_at_parameter_socket.default_value = 0.0
	    pin_at_parameter_socket.min_value = 0.0
	    pin_at_parameter_socket.max_value = 1.0
	    pin_at_parameter_socket.subtype = 'FACTOR'
	    pin_at_parameter_socket.attribute_domain = 'POINT'
	    pin_at_parameter_socket.description = "Pin each curve at a certain point for the operation"
	
	
	    #initialize restore_curve_segment_length nodes
	    #node Frame.001
	    frame_001_1 = restore_curve_segment_length.nodes.new("NodeFrame")
	    frame_001_1.label = "Pin at Parameter"
	    frame_001_1.name = "Frame.001"
	    frame_001_1.label_size = 20
	    frame_001_1.shrink = True
	
	    #node Frame
	    frame_1 = restore_curve_segment_length.nodes.new("NodeFrame")
	    frame_1.label = "Restore Segment Lengths"
	    frame_1.name = "Frame"
	    frame_1.label_size = 20
	    frame_1.shrink = True
	
	    #node Frame.002
	    frame_002_1 = restore_curve_segment_length.nodes.new("NodeFrame")
	    frame_002_1.label = "Default Fallback"
	    frame_002_1.name = "Frame.002"
	    frame_002_1.label_size = 20
	    frame_002_1.shrink = True
	
	    #node Reroute.009
	    reroute_009 = restore_curve_segment_length.nodes.new("NodeReroute")
	    reroute_009.name = "Reroute.009"
	    reroute_009.socket_idname = "NodeSocketVector"
	    #node Group Input.006
	    group_input_006 = restore_curve_segment_length.nodes.new("NodeGroupInput")
	    group_input_006.name = "Group Input.006"
	    group_input_006.outputs[0].hide = True
	    group_input_006.outputs[1].hide = True
	    group_input_006.outputs[2].hide = True
	    group_input_006.outputs[3].hide = True
	    group_input_006.outputs[5].hide = True
	
	    #node Reroute.013
	    reroute_013 = restore_curve_segment_length.nodes.new("NodeReroute")
	    reroute_013.name = "Reroute.013"
	    reroute_013.socket_idname = "NodeSocketGeometry"
	    #node Index
	    index_3 = restore_curve_segment_length.nodes.new("GeometryNodeInputIndex")
	    index_3.name = "Index"
	
	    #node Sample Curve.001
	    sample_curve_001 = restore_curve_segment_length.nodes.new("GeometryNodeSampleCurve")
	    sample_curve_001.name = "Sample Curve.001"
	    sample_curve_001.data_type = 'FLOAT_VECTOR'
	    sample_curve_001.mode = 'FACTOR'
	    sample_curve_001.use_all_curves = False
	
	    #node Group Input.003
	    group_input_003 = restore_curve_segment_length.nodes.new("NodeGroupInput")
	    group_input_003.name = "Group Input.003"
	    group_input_003.outputs[0].hide = True
	    group_input_003.outputs[1].hide = True
	    group_input_003.outputs[2].hide = True
	    group_input_003.outputs[3].hide = True
	    group_input_003.outputs[5].hide = True
	
	    #node Vector Math.006
	    vector_math_006 = restore_curve_segment_length.nodes.new("ShaderNodeVectorMath")
	    vector_math_006.name = "Vector Math.006"
	    vector_math_006.hide = True
	    vector_math_006.operation = 'SUBTRACT'
	
	    #node Interpolate Domain
	    interpolate_domain_2 = restore_curve_segment_length.nodes.new("GeometryNodeFieldOnDomain")
	    interpolate_domain_2.name = "Interpolate Domain"
	    interpolate_domain_2.hide = True
	    interpolate_domain_2.data_type = 'FLOAT_VECTOR'
	    interpolate_domain_2.domain = 'CURVE'
	
	    #node Group Input.005
	    group_input_005 = restore_curve_segment_length.nodes.new("NodeGroupInput")
	    group_input_005.name = "Group Input.005"
	    group_input_005.outputs[0].hide = True
	    group_input_005.outputs[2].hide = True
	    group_input_005.outputs[3].hide = True
	    group_input_005.outputs[4].hide = True
	    group_input_005.outputs[5].hide = True
	
	    #node Boolean Math.002
	    boolean_math_002 = restore_curve_segment_length.nodes.new("FunctionNodeBooleanMath")
	    boolean_math_002.name = "Boolean Math.002"
	    boolean_math_002.hide = True
	    boolean_math_002.operation = 'AND'
	
	    #node Field at Index.002
	    field_at_index_002 = restore_curve_segment_length.nodes.new("GeometryNodeFieldAtIndex")
	    field_at_index_002.name = "Field at Index.002"
	    field_at_index_002.data_type = 'FLOAT_VECTOR'
	    field_at_index_002.domain = 'POINT'
	
	    #node Vector Math.004
	    vector_math_004 = restore_curve_segment_length.nodes.new("ShaderNodeVectorMath")
	    vector_math_004.name = "Vector Math.004"
	    vector_math_004.operation = 'DISTANCE'
	
	    #node Accumulate Field
	    accumulate_field = restore_curve_segment_length.nodes.new("GeometryNodeAccumulateField")
	    accumulate_field.name = "Accumulate Field"
	    accumulate_field.data_type = 'FLOAT_VECTOR'
	    accumulate_field.domain = 'POINT'
	    accumulate_field.outputs[1].hide = True
	    accumulate_field.outputs[2].hide = True
	
	    #node Curve of Point
	    curve_of_point = restore_curve_segment_length.nodes.new("GeometryNodeCurveOfPoint")
	    curve_of_point.name = "Curve of Point"
	    curve_of_point.inputs[0].hide = True
	    curve_of_point.outputs[1].hide = True
	    #Point Index
	    curve_of_point.inputs[0].default_value = 0
	
	    #node Vector Math
	    vector_math_1 = restore_curve_segment_length.nodes.new("ShaderNodeVectorMath")
	    vector_math_1.name = "Vector Math"
	    vector_math_1.operation = 'SCALE'
	
	    #node Index.001
	    index_001_1 = restore_curve_segment_length.nodes.new("GeometryNodeInputIndex")
	    index_001_1.name = "Index.001"
	
	    #node Curve of Point.001
	    curve_of_point_001 = restore_curve_segment_length.nodes.new("GeometryNodeCurveOfPoint")
	    curve_of_point_001.name = "Curve of Point.001"
	    curve_of_point_001.inputs[0].hide = True
	    curve_of_point_001.outputs[0].hide = True
	    #Point Index
	    curve_of_point_001.inputs[0].default_value = 0
	
	    #node Switch
	    switch = restore_curve_segment_length.nodes.new("GeometryNodeSwitch")
	    switch.name = "Switch"
	    switch.input_type = 'INT'
	
	    #node Math
	    math_1 = restore_curve_segment_length.nodes.new("ShaderNodeMath")
	    math_1.name = "Math"
	    math_1.hide = True
	    math_1.operation = 'SUBTRACT'
	    math_1.use_clamp = False
	    #Value_001
	    math_1.inputs[1].default_value = 1.0
	
	    #node Compare
	    compare_1 = restore_curve_segment_length.nodes.new("FunctionNodeCompare")
	    compare_1.name = "Compare"
	    compare_1.hide = True
	    compare_1.data_type = 'INT'
	    compare_1.mode = 'ELEMENT'
	    compare_1.operation = 'EQUAL'
	    #B_INT
	    compare_1.inputs[3].default_value = 0
	
	    #node Reroute.001
	    reroute_001_1 = restore_curve_segment_length.nodes.new("NodeReroute")
	    reroute_001_1.name = "Reroute.001"
	    reroute_001_1.socket_idname = "NodeSocketVector"
	    #node Set Position.001
	    set_position_001 = restore_curve_segment_length.nodes.new("GeometryNodeSetPosition")
	    set_position_001.name = "Set Position.001"
	
	    #node Boolean Math
	    boolean_math = restore_curve_segment_length.nodes.new("FunctionNodeBooleanMath")
	    boolean_math.name = "Boolean Math"
	    boolean_math.operation = 'AND'
	
	    #node Compare.002
	    compare_002_1 = restore_curve_segment_length.nodes.new("FunctionNodeCompare")
	    compare_002_1.name = "Compare.002"
	    compare_002_1.data_type = 'FLOAT'
	    compare_002_1.mode = 'ELEMENT'
	    compare_002_1.operation = 'GREATER_THAN'
	    #B
	    compare_002_1.inputs[1].default_value = 0.0
	
	    #node Group Input.002
	    group_input_002_1 = restore_curve_segment_length.nodes.new("NodeGroupInput")
	    group_input_002_1.name = "Group Input.002"
	    group_input_002_1.outputs[0].hide = True
	    group_input_002_1.outputs[3].hide = True
	    group_input_002_1.outputs[4].hide = True
	    group_input_002_1.outputs[5].hide = True
	
	    #node Reroute.016
	    reroute_016 = restore_curve_segment_length.nodes.new("NodeReroute")
	    reroute_016.name = "Reroute.016"
	    reroute_016.socket_idname = "NodeSocketBool"
	    #node Reroute.014
	    reroute_014 = restore_curve_segment_length.nodes.new("NodeReroute")
	    reroute_014.name = "Reroute.014"
	    reroute_014.socket_idname = "NodeSocketGeometry"
	    #node Switch.001
	    switch_001_1 = restore_curve_segment_length.nodes.new("GeometryNodeSwitch")
	    switch_001_1.name = "Switch.001"
	    switch_001_1.input_type = 'GEOMETRY'
	
	    #node Group Output
	    group_output_6 = restore_curve_segment_length.nodes.new("NodeGroupOutput")
	    group_output_6.name = "Group Output"
	    group_output_6.is_active_output = True
	
	    #node Attribute Statistic
	    attribute_statistic_1 = restore_curve_segment_length.nodes.new("GeometryNodeAttributeStatistic")
	    attribute_statistic_1.name = "Attribute Statistic"
	    attribute_statistic_1.hide = True
	    attribute_statistic_1.data_type = 'FLOAT'
	    attribute_statistic_1.domain = 'CURVE'
	    attribute_statistic_1.inputs[1].hide = True
	    attribute_statistic_1.outputs[0].hide = True
	    attribute_statistic_1.outputs[1].hide = True
	    attribute_statistic_1.outputs[2].hide = True
	    attribute_statistic_1.outputs[3].hide = True
	    attribute_statistic_1.outputs[5].hide = True
	    attribute_statistic_1.outputs[6].hide = True
	    attribute_statistic_1.outputs[7].hide = True
	    #Selection
	    attribute_statistic_1.inputs[1].default_value = True
	
	    #node Group
	    group_1 = restore_curve_segment_length.nodes.new("GeometryNodeGroup")
	    group_1.name = "Group"
	    group_1.node_tree = curve_root
	    group_1.outputs[0].hide = True
	    group_1.outputs[2].hide = True
	    group_1.outputs[3].hide = True
	
	    #node Reroute.007
	    reroute_007 = restore_curve_segment_length.nodes.new("NodeReroute")
	    reroute_007.name = "Reroute.007"
	    reroute_007.socket_idname = "NodeSocketVector"
	    #node Reroute.004
	    reroute_004 = restore_curve_segment_length.nodes.new("NodeReroute")
	    reroute_004.name = "Reroute.004"
	    reroute_004.socket_idname = "NodeSocketGeometry"
	    #node Position.001
	    position_001 = restore_curve_segment_length.nodes.new("GeometryNodeInputPosition")
	    position_001.name = "Position.001"
	
	    #node Named Attribute
	    named_attribute = restore_curve_segment_length.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute.name = "Named Attribute"
	    named_attribute.data_type = 'FLOAT_VECTOR'
	    #Name
	    named_attribute.inputs[0].default_value = "rest_position"
	
	    #node Switch.003
	    switch_003_1 = restore_curve_segment_length.nodes.new("GeometryNodeSwitch")
	    switch_003_1.name = "Switch.003"
	    switch_003_1.input_type = 'VECTOR'
	
	    #node Reroute.006
	    reroute_006 = restore_curve_segment_length.nodes.new("NodeReroute")
	    reroute_006.name = "Reroute.006"
	    reroute_006.socket_idname = "NodeSocketVector"
	    #node Switch.002
	    switch_002 = restore_curve_segment_length.nodes.new("GeometryNodeSwitch")
	    switch_002.name = "Switch.002"
	    switch_002.input_type = 'VECTOR'
	
	    #node Compare.004
	    compare_004 = restore_curve_segment_length.nodes.new("FunctionNodeCompare")
	    compare_004.name = "Compare.004"
	    compare_004.data_type = 'VECTOR'
	    compare_004.mode = 'ELEMENT'
	    compare_004.operation = 'EQUAL'
	    #B_VEC3
	    compare_004.inputs[5].default_value = (8.146539688110352, 4.969870090484619, 9.874540328979492)
	    #Epsilon
	    compare_004.inputs[12].default_value = 0.0
	
	    #node Group Input
	    group_input_4 = restore_curve_segment_length.nodes.new("NodeGroupInput")
	    group_input_4.name = "Group Input"
	    group_input_4.outputs[1].hide = True
	    group_input_4.outputs[2].hide = True
	    group_input_4.outputs[4].hide = True
	    group_input_4.outputs[5].hide = True
	
	    #node Reroute.011
	    reroute_011 = restore_curve_segment_length.nodes.new("NodeReroute")
	    reroute_011.name = "Reroute.011"
	    reroute_011.socket_idname = "NodeSocketGeometry"
	    #node Reroute.005
	    reroute_005 = restore_curve_segment_length.nodes.new("NodeReroute")
	    reroute_005.name = "Reroute.005"
	    reroute_005.socket_idname = "NodeSocketGeometry"
	    #node Reroute.008
	    reroute_008 = restore_curve_segment_length.nodes.new("NodeReroute")
	    reroute_008.name = "Reroute.008"
	    reroute_008.socket_idname = "NodeSocketVector"
	    #node Set Position.002
	    set_position_002 = restore_curve_segment_length.nodes.new("GeometryNodeSetPosition")
	    set_position_002.name = "Set Position.002"
	    set_position_002.inputs[2].hide = True
	    #Position
	    set_position_002.inputs[2].default_value = (0.0, 0.0, 0.0)
	
	    #node Reroute.012
	    reroute_012 = restore_curve_segment_length.nodes.new("NodeReroute")
	    reroute_012.name = "Reroute.012"
	    reroute_012.socket_idname = "NodeSocketGeometry"
	    #node Group Input.001
	    group_input_001_2 = restore_curve_segment_length.nodes.new("NodeGroupInput")
	    group_input_001_2.name = "Group Input.001"
	    group_input_001_2.outputs[0].hide = True
	    group_input_001_2.outputs[1].hide = True
	    group_input_001_2.outputs[3].hide = True
	    group_input_001_2.outputs[4].hide = True
	    group_input_001_2.outputs[5].hide = True
	
	    #node Mix
	    mix = restore_curve_segment_length.nodes.new("ShaderNodeMix")
	    mix.name = "Mix"
	    mix.blend_type = 'MIX'
	    mix.clamp_factor = True
	    mix.clamp_result = False
	    mix.data_type = 'FLOAT'
	    mix.factor_mode = 'UNIFORM'
	
	    #node Group.001
	    group_001 = restore_curve_segment_length.nodes.new("GeometryNodeGroup")
	    group_001.name = "Group.001"
	    group_001.node_tree = curve_segment
	    group_001.outputs[2].hide = True
	
	    #node Compare.003
	    compare_003 = restore_curve_segment_length.nodes.new("FunctionNodeCompare")
	    compare_003.name = "Compare.003"
	    compare_003.hide = True
	    compare_003.data_type = 'FLOAT'
	    compare_003.mode = 'ELEMENT'
	    compare_003.operation = 'NOT_EQUAL'
	    #B
	    compare_003.inputs[1].default_value = 0.0
	    #Epsilon
	    compare_003.inputs[12].default_value = 0.0
	
	    #node Compare.005
	    compare_005 = restore_curve_segment_length.nodes.new("FunctionNodeCompare")
	    compare_005.name = "Compare.005"
	    compare_005.hide = True
	    compare_005.data_type = 'FLOAT'
	    compare_005.mode = 'ELEMENT'
	    compare_005.operation = 'GREATER_THAN'
	    #B
	    compare_005.inputs[1].default_value = 0.0
	
	
	
	
	    #Set parents
	    group_input_006.parent = frame_001_1
	    reroute_013.parent = frame_001_1
	    index_3.parent = frame_001_1
	    sample_curve_001.parent = frame_001_1
	    group_input_003.parent = frame_001_1
	    vector_math_006.parent = frame_001_1
	    interpolate_domain_2.parent = frame_001_1
	    group_input_005.parent = frame_001_1
	    boolean_math_002.parent = frame_001_1
	    field_at_index_002.parent = frame_1
	    vector_math_004.parent = frame_1
	    accumulate_field.parent = frame_1
	    curve_of_point.parent = frame_1
	    vector_math_1.parent = frame_1
	    index_001_1.parent = frame_1
	    curve_of_point_001.parent = frame_1
	    switch.parent = frame_1
	    math_1.parent = frame_1
	    compare_1.parent = frame_1
	    reroute_001_1.parent = frame_1
	    set_position_001.parent = frame_1
	    boolean_math.parent = frame_1
	    compare_002_1.parent = frame_1
	    group_input_002_1.parent = frame_1
	    reroute_016.parent = frame_001_1
	    reroute_014.parent = frame_001_1
	    switch_001_1.parent = frame_001_1
	    attribute_statistic_1.parent = frame_001_1
	    group_1.parent = frame_1
	    reroute_004.parent = frame_1
	    position_001.parent = frame_002_1
	    named_attribute.parent = frame_002_1
	    switch_003_1.parent = frame_002_1
	    reroute_006.parent = frame_002_1
	    switch_002.parent = frame_002_1
	    compare_004.parent = frame_002_1
	    reroute_005.parent = frame_1
	    set_position_002.parent = frame_001_1
	    reroute_012.parent = frame_001_1
	    group_input_001_2.parent = frame_1
	    mix.parent = frame_1
	    group_001.parent = frame_1
	    compare_003.parent = frame_001_1
	    compare_005.parent = frame_001_1
	
	    #Set locations
	    frame_001_1.location = (-1289.059814453125, 110.20000457763672)
	    frame_1.location = (-3492.00048828125, 57.61393737792969)
	    frame_002_1.location = (-4467.1064453125, -100.04000854492188)
	    reroute_009.location = (-1431.9771728515625, -673.348876953125)
	    group_input_006.location = (218.757080078125, -140.57211303710938)
	    reroute_013.location = (178.571044921875, -120.47908020019531)
	    index_3.location = (37.919921875, -482.15350341796875)
	    sample_curve_001.location = (218.757080078125, -220.94418334960938)
	    group_input_003.location = (37.919921875, -421.87445068359375)
	    vector_math_006.location = (399.5943603515625, -261.1302490234375)
	    interpolate_domain_2.location = (580.4315795898438, -261.1302490234375)
	    group_input_005.location = (399.5943603515625, -180.75814819335938)
	    boolean_math_002.location = (580.4315795898438, -180.75814819335938)
	    field_at_index_002.location = (653.51171875, -248.73023986816406)
	    vector_math_004.location = (834.348876953125, -228.63722229003906)
	    accumulate_field.location = (1557.69775390625, -409.47442626953125)
	    curve_of_point.location = (1356.767578125, -550.1256103515625)
	    vector_math_1.location = (1356.767578125, -389.38140869140625)
	    index_001_1.location = (30.6279296875, -469.75347900390625)
	    curve_of_point_001.location = (30.6279296875, -389.38140869140625)
	    switch.location = (412.3955078125, -369.28839111328125)
	    math_1.location = (211.46533203125, -469.75347900390625)
	    compare_1.location = (211.46533203125, -429.56744384765625)
	    reroute_001_1.location = (613.32568359375, -309.0093078613281)
	    set_position_001.location = (1798.8140869140625, -148.26512145996094)
	    boolean_math.location = (1494.958251953125, -96.33775329589844)
	    compare_002_1.location = (1294.0283203125, -116.43077850341797)
	    group_input_002_1.location = (1113.19140625, -136.5238037109375)
	    reroute_016.location = (801.454833984375, -160.66513061523438)
	    reroute_014.location = (801.454833984375, -120.47908020019531)
	    switch_001_1.location = (1082.757080078125, -40.10698699951172)
	    group_output_6.location = (75.0, 50.0)
	    attribute_statistic_1.location = (861.73388671875, -60.20000457763672)
	    group_1.location = (1557.69775390625, -268.8232421875)
	    reroute_007.location = (-3762.76806640625, -251.3953857421875)
	    reroute_004.location = (1638.06982421875, -47.80000305175781)
	    position_001.location = (60.265625, -241.41067504882812)
	    named_attribute.location = (60.265625, -301.6897277832031)
	    switch_003_1.location = (241.1025390625, -221.31765747070312)
	    reroute_006.location = (37.919921875, -72.88264465332031)
	    switch_002.location = (442.03271484375, -100.75950622558594)
	    compare_004.location = (60.26611328125, -40.480438232421875)
	    group_input_4.location = (-4707.1396484375, -30.37213134765625)
	    reroute_011.location = (-3581.9306640625, -70.55816650390625)
	    reroute_005.location = (50.72119140625, -47.80000305175781)
	    reroute_008.location = (-3561.83740234375, -673.348876953125)
	    set_position_002.location = (861.73388671875, -140.57211303710938)
	    reroute_012.location = (37.919921875, -241.0372314453125)
	    group_input_001_2.location = (834.348876953125, -168.358154296875)
	    mix.location = (1115.6513671875, -329.10235595703125)
	    group_001.location = (834.348876953125, -409.47442626953125)
	    compare_003.location = (399.5943603515625, -140.57211303710938)
	    compare_005.location = (861.73388671875, -100.38605499267578)
	
	    #Set dimensions
	    frame_001_1.width, frame_001_1.height = 1252.8997802734375, 561.8800659179688
	    frame_1.width, frame_1.height = 1968.80029296875, 632.1739501953125
	    frame_002_1.width, frame_002_1.height = 612.06640625, 452.4400329589844
	    reroute_009.width, reroute_009.height = 16.0, 100.0
	    group_input_006.width, group_input_006.height = 140.0, 100.0
	    reroute_013.width, reroute_013.height = 16.0, 100.0
	    index_3.width, index_3.height = 140.0, 100.0
	    sample_curve_001.width, sample_curve_001.height = 140.0, 100.0
	    group_input_003.width, group_input_003.height = 140.0, 100.0
	    vector_math_006.width, vector_math_006.height = 140.0, 100.0
	    interpolate_domain_2.width, interpolate_domain_2.height = 140.0, 100.0
	    group_input_005.width, group_input_005.height = 140.0, 100.0
	    boolean_math_002.width, boolean_math_002.height = 140.0, 100.0
	    field_at_index_002.width, field_at_index_002.height = 140.0, 100.0
	    vector_math_004.width, vector_math_004.height = 140.0, 100.0
	    accumulate_field.width, accumulate_field.height = 140.0, 100.0
	    curve_of_point.width, curve_of_point.height = 140.0, 100.0
	    vector_math_1.width, vector_math_1.height = 140.0, 100.0
	    index_001_1.width, index_001_1.height = 140.0, 100.0
	    curve_of_point_001.width, curve_of_point_001.height = 140.0, 100.0
	    switch.width, switch.height = 140.0, 100.0
	    math_1.width, math_1.height = 140.0, 100.0
	    compare_1.width, compare_1.height = 140.0, 100.0
	    reroute_001_1.width, reroute_001_1.height = 16.0, 100.0
	    set_position_001.width, set_position_001.height = 140.0, 100.0
	    boolean_math.width, boolean_math.height = 140.0, 100.0
	    compare_002_1.width, compare_002_1.height = 140.0, 100.0
	    group_input_002_1.width, group_input_002_1.height = 140.0, 100.0
	    reroute_016.width, reroute_016.height = 16.0, 100.0
	    reroute_014.width, reroute_014.height = 16.0, 100.0
	    switch_001_1.width, switch_001_1.height = 140.0, 100.0
	    group_output_6.width, group_output_6.height = 140.0, 100.0
	    attribute_statistic_1.width, attribute_statistic_1.height = 140.0, 100.0
	    group_1.width, group_1.height = 140.0, 100.0
	    reroute_007.width, reroute_007.height = 16.0, 100.0
	    reroute_004.width, reroute_004.height = 16.0, 100.0
	    position_001.width, position_001.height = 140.0, 100.0
	    named_attribute.width, named_attribute.height = 140.0, 100.0
	    switch_003_1.width, switch_003_1.height = 140.0, 100.0
	    reroute_006.width, reroute_006.height = 16.0, 100.0
	    switch_002.width, switch_002.height = 140.0, 100.0
	    compare_004.width, compare_004.height = 140.0, 100.0
	    group_input_4.width, group_input_4.height = 140.0, 100.0
	    reroute_011.width, reroute_011.height = 16.0, 100.0
	    reroute_005.width, reroute_005.height = 16.0, 100.0
	    reroute_008.width, reroute_008.height = 16.0, 100.0
	    set_position_002.width, set_position_002.height = 140.0, 100.0
	    reroute_012.width, reroute_012.height = 16.0, 100.0
	    group_input_001_2.width, group_input_001_2.height = 140.0, 100.0
	    mix.width, mix.height = 140.0, 100.0
	    group_001.width, group_001.height = 140.0, 100.0
	    compare_003.width, compare_003.height = 140.0, 100.0
	    compare_005.width, compare_005.height = 140.0, 100.0
	
	    #initialize restore_curve_segment_length links
	    #reroute_004.Output -> set_position_001.Geometry
	    restore_curve_segment_length.links.new(reroute_004.outputs[0], set_position_001.inputs[0])
	    #curve_of_point.Curve Index -> accumulate_field.Group ID
	    restore_curve_segment_length.links.new(curve_of_point.outputs[0], accumulate_field.inputs[1])
	    #field_at_index_002.Value -> vector_math_004.Vector
	    restore_curve_segment_length.links.new(field_at_index_002.outputs[0], vector_math_004.inputs[0])
	    #reroute_001_1.Output -> vector_math_004.Vector
	    restore_curve_segment_length.links.new(reroute_001_1.outputs[0], vector_math_004.inputs[1])
	    #reroute_001_1.Output -> field_at_index_002.Value
	    restore_curve_segment_length.links.new(reroute_001_1.outputs[0], field_at_index_002.inputs[1])
	    #index_001_1.Index -> math_1.Value
	    restore_curve_segment_length.links.new(index_001_1.outputs[0], math_1.inputs[0])
	    #switch.Output -> field_at_index_002.Index
	    restore_curve_segment_length.links.new(switch.outputs[0], field_at_index_002.inputs[0])
	    #vector_math_1.Vector -> accumulate_field.Value
	    restore_curve_segment_length.links.new(vector_math_1.outputs[0], accumulate_field.inputs[0])
	    #curve_of_point_001.Index in Curve -> compare_1.A
	    restore_curve_segment_length.links.new(curve_of_point_001.outputs[1], compare_1.inputs[2])
	    #math_1.Value -> switch.False
	    restore_curve_segment_length.links.new(math_1.outputs[0], switch.inputs[1])
	    #compare_1.Result -> switch.Switch
	    restore_curve_segment_length.links.new(compare_1.outputs[0], switch.inputs[0])
	    #index_001_1.Index -> switch.True
	    restore_curve_segment_length.links.new(index_001_1.outputs[0], switch.inputs[2])
	    #reroute_006.Output -> switch_002.False
	    restore_curve_segment_length.links.new(reroute_006.outputs[0], switch_002.inputs[1])
	    #group_1.Root Position -> set_position_001.Position
	    restore_curve_segment_length.links.new(group_1.outputs[1], set_position_001.inputs[2])
	    #vector_math_004.Value -> mix.B
	    restore_curve_segment_length.links.new(vector_math_004.outputs[1], mix.inputs[3])
	    #mix.Result -> vector_math_1.Scale
	    restore_curve_segment_length.links.new(mix.outputs[0], vector_math_1.inputs[3])
	    #group_input_001_2.Factor -> mix.Factor
	    restore_curve_segment_length.links.new(group_input_001_2.outputs[2], mix.inputs[0])
	    #group_input_002_1.Factor -> compare_002_1.A
	    restore_curve_segment_length.links.new(group_input_002_1.outputs[2], compare_002_1.inputs[0])
	    #accumulate_field.Leading -> set_position_001.Offset
	    restore_curve_segment_length.links.new(accumulate_field.outputs[0], set_position_001.inputs[3])
	    #compare_002_1.Result -> boolean_math.Boolean
	    restore_curve_segment_length.links.new(compare_002_1.outputs[0], boolean_math.inputs[0])
	    #group_input_002_1.Selection -> boolean_math.Boolean
	    restore_curve_segment_length.links.new(group_input_002_1.outputs[1], boolean_math.inputs[1])
	    #reroute_005.Output -> reroute_004.Input
	    restore_curve_segment_length.links.new(reroute_005.outputs[0], reroute_004.inputs[0])
	    #reroute_012.Output -> sample_curve_001.Curves
	    restore_curve_segment_length.links.new(reroute_012.outputs[0], sample_curve_001.inputs[0])
	    #sample_curve_001.Position -> vector_math_006.Vector
	    restore_curve_segment_length.links.new(sample_curve_001.outputs[1], vector_math_006.inputs[1])
	    #sample_curve_001.Value -> vector_math_006.Vector
	    restore_curve_segment_length.links.new(sample_curve_001.outputs[0], vector_math_006.inputs[0])
	    #reroute_014.Output -> set_position_002.Geometry
	    restore_curve_segment_length.links.new(reroute_014.outputs[0], set_position_002.inputs[0])
	    #interpolate_domain_2.Value -> set_position_002.Offset
	    restore_curve_segment_length.links.new(interpolate_domain_2.outputs[0], set_position_002.inputs[3])
	    #index_3.Index -> sample_curve_001.Curve Index
	    restore_curve_segment_length.links.new(index_3.outputs[0], sample_curve_001.inputs[4])
	    #reroute_012.Output -> reroute_013.Input
	    restore_curve_segment_length.links.new(reroute_012.outputs[0], reroute_013.inputs[0])
	    #group_input_005.Selection -> boolean_math_002.Boolean
	    restore_curve_segment_length.links.new(group_input_005.outputs[1], boolean_math_002.inputs[1])
	    #compare_003.Result -> boolean_math_002.Boolean
	    restore_curve_segment_length.links.new(compare_003.outputs[0], boolean_math_002.inputs[0])
	    #reroute_011.Output -> reroute_005.Input
	    restore_curve_segment_length.links.new(reroute_011.outputs[0], reroute_005.inputs[0])
	    #group_input_003.Pin at Parameter -> sample_curve_001.Factor
	    restore_curve_segment_length.links.new(group_input_003.outputs[4], sample_curve_001.inputs[2])
	    #group_input_006.Pin at Parameter -> compare_003.A
	    restore_curve_segment_length.links.new(group_input_006.outputs[4], compare_003.inputs[0])
	    #reroute_006.Output -> compare_004.A
	    restore_curve_segment_length.links.new(reroute_006.outputs[0], compare_004.inputs[4])
	    #compare_004.Result -> switch_002.Switch
	    restore_curve_segment_length.links.new(compare_004.outputs[0], switch_002.inputs[0])
	    #named_attribute.Attribute -> switch_003_1.True
	    restore_curve_segment_length.links.new(named_attribute.outputs[0], switch_003_1.inputs[2])
	    #named_attribute.Exists -> switch_003_1.Switch
	    restore_curve_segment_length.links.new(named_attribute.outputs[1], switch_003_1.inputs[0])
	    #position_001.Position -> switch_003_1.False
	    restore_curve_segment_length.links.new(position_001.outputs[0], switch_003_1.inputs[1])
	    #switch_003_1.Output -> switch_002.True
	    restore_curve_segment_length.links.new(switch_003_1.outputs[0], switch_002.inputs[2])
	    #reroute_009.Output -> sample_curve_001.Value
	    restore_curve_segment_length.links.new(reroute_009.outputs[0], sample_curve_001.inputs[1])
	    #switch_002.Output -> reroute_007.Input
	    restore_curve_segment_length.links.new(switch_002.outputs[0], reroute_007.inputs[0])
	    #reroute_007.Output -> reroute_001_1.Input
	    restore_curve_segment_length.links.new(reroute_007.outputs[0], reroute_001_1.inputs[0])
	    #group_input_4.Reference Position -> reroute_006.Input
	    restore_curve_segment_length.links.new(group_input_4.outputs[3], reroute_006.inputs[0])
	    #reroute_007.Output -> reroute_008.Input
	    restore_curve_segment_length.links.new(reroute_007.outputs[0], reroute_008.inputs[0])
	    #reroute_008.Output -> reroute_009.Input
	    restore_curve_segment_length.links.new(reroute_008.outputs[0], reroute_009.inputs[0])
	    #group_input_4.Curves -> reroute_011.Input
	    restore_curve_segment_length.links.new(group_input_4.outputs[0], reroute_011.inputs[0])
	    #group_001.Segment Length -> mix.A
	    restore_curve_segment_length.links.new(group_001.outputs[0], mix.inputs[2])
	    #group_001.Segment Direction -> vector_math_1.Vector
	    restore_curve_segment_length.links.new(group_001.outputs[1], vector_math_1.inputs[0])
	    #vector_math_006.Vector -> interpolate_domain_2.Value
	    restore_curve_segment_length.links.new(vector_math_006.outputs[0], interpolate_domain_2.inputs[0])
	    #reroute_016.Output -> attribute_statistic_1.Attribute
	    restore_curve_segment_length.links.new(reroute_016.outputs[0], attribute_statistic_1.inputs[2])
	    #attribute_statistic_1.Max -> compare_005.A
	    restore_curve_segment_length.links.new(attribute_statistic_1.outputs[4], compare_005.inputs[0])
	    #set_position_002.Geometry -> switch_001_1.True
	    restore_curve_segment_length.links.new(set_position_002.outputs[0], switch_001_1.inputs[2])
	    #reroute_014.Output -> switch_001_1.False
	    restore_curve_segment_length.links.new(reroute_014.outputs[0], switch_001_1.inputs[1])
	    #reroute_016.Output -> set_position_002.Selection
	    restore_curve_segment_length.links.new(reroute_016.outputs[0], set_position_002.inputs[1])
	    #compare_005.Result -> switch_001_1.Switch
	    restore_curve_segment_length.links.new(compare_005.outputs[0], switch_001_1.inputs[0])
	    #reroute_014.Output -> attribute_statistic_1.Geometry
	    restore_curve_segment_length.links.new(reroute_014.outputs[0], attribute_statistic_1.inputs[0])
	    #boolean_math.Boolean -> set_position_001.Selection
	    restore_curve_segment_length.links.new(boolean_math.outputs[0], set_position_001.inputs[1])
	    #boolean_math_002.Boolean -> reroute_016.Input
	    restore_curve_segment_length.links.new(boolean_math_002.outputs[0], reroute_016.inputs[0])
	    #reroute_013.Output -> reroute_014.Input
	    restore_curve_segment_length.links.new(reroute_013.outputs[0], reroute_014.inputs[0])
	    #set_position_001.Geometry -> reroute_012.Input
	    restore_curve_segment_length.links.new(set_position_001.outputs[0], reroute_012.inputs[0])
	    #switch_001_1.Output -> group_output_6.Curves
	    restore_curve_segment_length.links.new(switch_001_1.outputs[0], group_output_6.inputs[0])
	    return restore_curve_segment_length
	
	restore_curve_segment_length = restore_curve_segment_length_node_group()
	
	#initialize mesh_magic node group
	def mesh_magic_node_group():
	    mesh_magic = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "MESH_MAGIC")
	
	    mesh_magic.color_tag = 'NONE'
	    mesh_magic.description = "Convert a set of curves to a stylized mesh."
	    mesh_magic.default_group_node_width = 140
	    
	
	    mesh_magic.is_modifier = True
	
	    #mesh_magic interface
	    #Socket Geometry
	    geometry_socket_8 = mesh_magic.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_8.attribute_domain = 'POINT'
	    geometry_socket_8.description = "Curves converted to a stylized mesh."
	
	    #Socket Geometry
	    geometry_socket_9 = mesh_magic.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_9.attribute_domain = 'POINT'
	    geometry_socket_9.description = "Set of curves."
	
	    #Socket Surface
	    surface_socket_1 = mesh_magic.interface.new_socket(name = "Surface", in_out='INPUT', socket_type = 'NodeSocketObject')
	    surface_socket_1.attribute_domain = 'POINT'
	    surface_socket_1.description = "Surface mesh."
	
	    #Socket Radius
	    radius_socket = mesh_magic.interface.new_socket(name = "Radius", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    radius_socket.default_value = 0.09999999403953552
	    radius_socket.min_value = 0.0
	    radius_socket.max_value = 3.4028234663852886e+38
	    radius_socket.subtype = 'DISTANCE'
	    radius_socket.attribute_domain = 'POINT'
	    radius_socket.description = "Mesh Radius."
	
	    #Panel Enhancement Settings
	    enhancement_settings_panel = mesh_magic.interface.new_panel("Enhancement Settings", default_closed=True)
	    enhancement_settings_panel.description = "Settings for mesh enhancements."
	    #Socket Use Enhancements
	    use_enhancements_socket = mesh_magic.interface.new_socket(name = "Use Enhancements", in_out='INPUT', socket_type = 'NodeSocketBool', parent = enhancement_settings_panel)
	    use_enhancements_socket.default_value = True
	    use_enhancements_socket.attribute_domain = 'POINT'
	    use_enhancements_socket.description = "Use Enhancement settings."
	
	    #Socket Maintain Shape Factor
	    maintain_shape_factor_socket = mesh_magic.interface.new_socket(name = "Maintain Shape Factor", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = enhancement_settings_panel)
	    maintain_shape_factor_socket.default_value = 1.0
	    maintain_shape_factor_socket.min_value = 0.0
	    maintain_shape_factor_socket.max_value = 1.0
	    maintain_shape_factor_socket.subtype = 'FACTOR'
	    maintain_shape_factor_socket.attribute_domain = 'POINT'
	    maintain_shape_factor_socket.description = "Factor to blend overall effect"
	
	    #Socket Pin at Parameter
	    pin_at_parameter_socket_1 = mesh_magic.interface.new_socket(name = "Pin at Parameter", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = enhancement_settings_panel)
	    pin_at_parameter_socket_1.default_value = 0.0
	    pin_at_parameter_socket_1.min_value = 0.0
	    pin_at_parameter_socket_1.max_value = 1.0
	    pin_at_parameter_socket_1.subtype = 'FACTOR'
	    pin_at_parameter_socket_1.attribute_domain = 'POINT'
	    pin_at_parameter_socket_1.description = "Pin each curve at a certain point for the operation"
	
	    #Socket Snap to surface
	    snap_to_surface_socket = mesh_magic.interface.new_socket(name = "Snap to surface", in_out='INPUT', socket_type = 'NodeSocketBool', parent = enhancement_settings_panel)
	    snap_to_surface_socket.default_value = False
	    snap_to_surface_socket.attribute_domain = 'POINT'
	    snap_to_surface_socket.description = "Snap mesh roots to the nearest surface point."
	
	    #Panel Subdivision Settings
	    subdivision_settings_panel = mesh_magic.interface.new_panel("Subdivision Settings")
	    subdivision_settings_panel.description = "Settings for mesh subdivision."
	    #Socket Level
	    level_socket = mesh_magic.interface.new_socket(name = "Level", in_out='INPUT', socket_type = 'NodeSocketInt', parent = subdivision_settings_panel)
	    level_socket.default_value = 1
	    level_socket.min_value = 0
	    level_socket.max_value = 6
	    level_socket.subtype = 'NONE'
	    level_socket.attribute_domain = 'POINT'
	    level_socket.description = "Subdivision level."
	
	    #Socket Edge Crease
	    edge_crease_socket = mesh_magic.interface.new_socket(name = "Edge Crease", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = subdivision_settings_panel)
	    edge_crease_socket.default_value = 0.0
	    edge_crease_socket.min_value = 0.0
	    edge_crease_socket.max_value = 1.0
	    edge_crease_socket.subtype = 'FACTOR'
	    edge_crease_socket.attribute_domain = 'POINT'
	    edge_crease_socket.description = "Edge crease factor for subdivision."
	
	    #Socket Vertex Crease
	    vertex_crease_socket = mesh_magic.interface.new_socket(name = "Vertex Crease", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = subdivision_settings_panel)
	    vertex_crease_socket.default_value = 0.0
	    vertex_crease_socket.min_value = 0.0
	    vertex_crease_socket.max_value = 1.0
	    vertex_crease_socket.subtype = 'FACTOR'
	    vertex_crease_socket.attribute_domain = 'POINT'
	    vertex_crease_socket.description = "Vertex crease factor for subdivision."
	
	    #Socket Limit Surface
	    limit_surface_socket = mesh_magic.interface.new_socket(name = "Limit Surface", in_out='INPUT', socket_type = 'NodeSocketBool', parent = subdivision_settings_panel)
	    limit_surface_socket.default_value = True
	    limit_surface_socket.attribute_domain = 'POINT'
	    limit_surface_socket.description = "Limit subdivision on surface."
	
	
	    mesh_magic.interface.move_to_parent(subdivision_settings_panel, enhancement_settings_panel, 9)
	    #Panel Merge Settings
	    merge_settings_panel = mesh_magic.interface.new_panel("Merge Settings", default_closed=True)
	    merge_settings_panel.description = "Settings for merging points."
	    #Socket Distance
	    distance_socket = mesh_magic.interface.new_socket(name = "Distance", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = merge_settings_panel)
	    distance_socket.default_value = 0.0010000000474974513
	    distance_socket.min_value = 0.0
	    distance_socket.max_value = 3.4028234663852886e+38
	    distance_socket.subtype = 'DISTANCE'
	    distance_socket.attribute_domain = 'POINT'
	    distance_socket.description = "Distance threshold to merge points."
	
	
	    mesh_magic.interface.move_to_parent(merge_settings_panel, enhancement_settings_panel, 14)
	
	
	    #initialize mesh_magic nodes
	    #node Group Output
	    group_output_7 = mesh_magic.nodes.new("NodeGroupOutput")
	    group_output_7.name = "Group Output"
	    group_output_7.is_active_output = True
	    group_output_7.inputs[1].hide = True
	
	    #node Group Input
	    group_input_5 = mesh_magic.nodes.new("NodeGroupInput")
	    group_input_5.name = "Group Input"
	    group_input_5.outputs[1].hide = True
	    group_input_5.outputs[2].hide = True
	    group_input_5.outputs[3].hide = True
	    group_input_5.outputs[4].hide = True
	    group_input_5.outputs[5].hide = True
	    group_input_5.outputs[6].hide = True
	    group_input_5.outputs[7].hide = True
	    group_input_5.outputs[8].hide = True
	    group_input_5.outputs[9].hide = True
	    group_input_5.outputs[10].hide = True
	    group_input_5.outputs[11].hide = True
	    group_input_5.outputs[12].hide = True
	
	    #node Group
	    group_2 = mesh_magic.nodes.new("GeometryNodeGroup")
	    group_2.name = "Group"
	    group_2.node_tree = ob_data
	
	    #node Group.004
	    group_004 = mesh_magic.nodes.new("GeometryNodeGroup")
	    group_004.name = "Group.004"
	    group_004.node_tree = convex_curve_profile
	
	    #node Group.005
	    group_005 = mesh_magic.nodes.new("GeometryNodeGroup")
	    group_005.name = "Group.005"
	    group_005.node_tree = curve_from_centroids
	
	    #node Curve to Mesh
	    curve_to_mesh = mesh_magic.nodes.new("GeometryNodeCurveToMesh")
	    curve_to_mesh.name = "Curve to Mesh"
	    #Fill Caps
	    curve_to_mesh.inputs[2].default_value = True
	
	    #node Set Position.001
	    set_position_001_1 = mesh_magic.nodes.new("GeometryNodeSetPosition")
	    set_position_001_1.name = "Set Position.001"
	    set_position_001_1.inputs[1].hide = True
	    set_position_001_1.inputs[3].hide = True
	    #Selection
	    set_position_001_1.inputs[1].default_value = True
	    #Offset
	    set_position_001_1.inputs[3].default_value = (0.0, 0.0, 0.0)
	
	    #node Position.002
	    position_002_2 = mesh_magic.nodes.new("GeometryNodeInputPosition")
	    position_002_2.name = "Position.002"
	
	    #node Separate XYZ
	    separate_xyz = mesh_magic.nodes.new("ShaderNodeSeparateXYZ")
	    separate_xyz.name = "Separate XYZ"
	    separate_xyz.hide = True
	    separate_xyz.outputs[2].hide = True
	
	    #node Combine XYZ
	    combine_xyz = mesh_magic.nodes.new("ShaderNodeCombineXYZ")
	    combine_xyz.name = "Combine XYZ"
	    combine_xyz.hide = True
	    combine_xyz.inputs[2].hide = True
	    #Z
	    combine_xyz.inputs[2].default_value = 0.0
	
	    #node Set Curve Radius
	    set_curve_radius = mesh_magic.nodes.new("GeometryNodeSetCurveRadius")
	    set_curve_radius.name = "Set Curve Radius"
	    set_curve_radius.inputs[1].hide = True
	    #Selection
	    set_curve_radius.inputs[1].default_value = True
	
	    #node Capture Attribute.001
	    capture_attribute_001 = mesh_magic.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_001.name = "Capture Attribute.001"
	    capture_attribute_001.hide = True
	    capture_attribute_001.active_index = 0
	    capture_attribute_001.capture_items.clear()
	    capture_attribute_001.capture_items.new('FLOAT', "Factor")
	    capture_attribute_001.capture_items["Factor"].data_type = 'FLOAT'
	    capture_attribute_001.domain = 'POINT'
	    capture_attribute_001.inputs[2].hide = True
	    capture_attribute_001.outputs[2].hide = True
	
	    #node Capture Attribute.002
	    capture_attribute_002 = mesh_magic.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_002.name = "Capture Attribute.002"
	    capture_attribute_002.hide = True
	    capture_attribute_002.active_index = 0
	    capture_attribute_002.capture_items.clear()
	    capture_attribute_002.capture_items.new('FLOAT', "Factor")
	    capture_attribute_002.capture_items["Factor"].data_type = 'FLOAT'
	    capture_attribute_002.domain = 'POINT'
	    capture_attribute_002.inputs[2].hide = True
	    capture_attribute_002.outputs[2].hide = True
	
	    #node Spline Parameter
	    spline_parameter = mesh_magic.nodes.new("GeometryNodeSplineParameter")
	    spline_parameter.name = "Spline Parameter"
	    spline_parameter.outputs[1].hide = True
	    spline_parameter.outputs[2].hide = True
	
	    #node Store Named Attribute
	    store_named_attribute_2 = mesh_magic.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_2.name = "Store Named Attribute"
	    store_named_attribute_2.data_type = 'FLOAT2'
	    store_named_attribute_2.domain = 'CORNER'
	    #Selection
	    store_named_attribute_2.inputs[1].default_value = True
	    #Name
	    store_named_attribute_2.inputs[2].default_value = "UVMap"
	
	    #node Combine XYZ.001
	    combine_xyz_001 = mesh_magic.nodes.new("ShaderNodeCombineXYZ")
	    combine_xyz_001.name = "Combine XYZ.001"
	    combine_xyz_001.hide = True
	    combine_xyz_001.inputs[2].hide = True
	    #Z
	    combine_xyz_001.inputs[2].default_value = 0.0
	
	    #node Stylized Mesh Shape
	    stylized_mesh_shape = mesh_magic.nodes.new("ShaderNodeFloatCurve")
	    stylized_mesh_shape.label = "Stylized Mesh Shape"
	    stylized_mesh_shape.name = "Stylized Mesh Shape"
	    #mapping settings
	    stylized_mesh_shape.mapping.extend = 'EXTRAPOLATED'
	    stylized_mesh_shape.mapping.tone = 'STANDARD'
	    stylized_mesh_shape.mapping.black_level = (0.0, 0.0, 0.0)
	    stylized_mesh_shape.mapping.white_level = (1.0, 1.0, 1.0)
	    stylized_mesh_shape.mapping.clip_min_x = 0.0
	    stylized_mesh_shape.mapping.clip_min_y = 0.0
	    stylized_mesh_shape.mapping.clip_max_x = 1.0
	    stylized_mesh_shape.mapping.clip_max_y = 1.0
	    stylized_mesh_shape.mapping.use_clip = True
	    #curve 0
	    stylized_mesh_shape_curve_0 = stylized_mesh_shape.mapping.curves[0]
	    stylized_mesh_shape_curve_0_point_0 = stylized_mesh_shape_curve_0.points[0]
	    stylized_mesh_shape_curve_0_point_0.location = (0.00909090880304575, 1.0)
	    stylized_mesh_shape_curve_0_point_0.handle_type = 'AUTO'
	    stylized_mesh_shape_curve_0_point_1 = stylized_mesh_shape_curve_0.points[1]
	    stylized_mesh_shape_curve_0_point_1.location = (0.27272725105285645, 0.3750000596046448)
	    stylized_mesh_shape_curve_0_point_1.handle_type = 'AUTO'
	    stylized_mesh_shape_curve_0_point_2 = stylized_mesh_shape_curve_0.points.new(0.459090918302536, 0.3562501072883606)
	    stylized_mesh_shape_curve_0_point_2.handle_type = 'AUTO'
	    stylized_mesh_shape_curve_0_point_3 = stylized_mesh_shape_curve_0.points.new(1.0, 0.0)
	    stylized_mesh_shape_curve_0_point_3.handle_type = 'AUTO'
	    #update curve after changes
	    stylized_mesh_shape.mapping.update()
	    #Factor
	    stylized_mesh_shape.inputs[0].default_value = 1.0
	
	    #node Spline Parameter.001
	    spline_parameter_001 = mesh_magic.nodes.new("GeometryNodeSplineParameter")
	    spline_parameter_001.name = "Spline Parameter.001"
	    spline_parameter_001.outputs[1].hide = True
	    spline_parameter_001.outputs[2].hide = True
	
	    #node Map Range
	    map_range = mesh_magic.nodes.new("ShaderNodeMapRange")
	    map_range.name = "Map Range"
	    map_range.hide = True
	    map_range.clamp = True
	    map_range.data_type = 'FLOAT'
	    map_range.interpolation_type = 'LINEAR'
	    map_range.inputs[1].hide = True
	    map_range.inputs[2].hide = True
	    map_range.inputs[3].hide = True
	    map_range.inputs[5].hide = True
	    map_range.inputs[6].hide = True
	    map_range.inputs[7].hide = True
	    map_range.inputs[8].hide = True
	    map_range.inputs[9].hide = True
	    map_range.inputs[10].hide = True
	    map_range.inputs[11].hide = True
	    map_range.outputs[1].hide = True
	    #From Min
	    map_range.inputs[1].default_value = 0.0
	    #From Max
	    map_range.inputs[2].default_value = 1.0
	    #To Min
	    map_range.inputs[3].default_value = 0.0
	
	    #node Group Input.001
	    group_input_001_3 = mesh_magic.nodes.new("NodeGroupInput")
	    group_input_001_3.name = "Group Input.001"
	    group_input_001_3.outputs[0].hide = True
	    group_input_001_3.outputs[1].hide = True
	    group_input_001_3.outputs[3].hide = True
	    group_input_001_3.outputs[4].hide = True
	    group_input_001_3.outputs[5].hide = True
	    group_input_001_3.outputs[6].hide = True
	    group_input_001_3.outputs[7].hide = True
	    group_input_001_3.outputs[8].hide = True
	    group_input_001_3.outputs[9].hide = True
	    group_input_001_3.outputs[10].hide = True
	    group_input_001_3.outputs[11].hide = True
	    group_input_001_3.outputs[12].hide = True
	
	    #node Group Input.002
	    group_input_002_2 = mesh_magic.nodes.new("NodeGroupInput")
	    group_input_002_2.name = "Group Input.002"
	    group_input_002_2.outputs[0].hide = True
	    group_input_002_2.outputs[2].hide = True
	    group_input_002_2.outputs[3].hide = True
	    group_input_002_2.outputs[4].hide = True
	    group_input_002_2.outputs[5].hide = True
	    group_input_002_2.outputs[6].hide = True
	    group_input_002_2.outputs[7].hide = True
	    group_input_002_2.outputs[8].hide = True
	    group_input_002_2.outputs[9].hide = True
	    group_input_002_2.outputs[10].hide = True
	    group_input_002_2.outputs[11].hide = True
	    group_input_002_2.outputs[12].hide = True
	
	    #node Group Input.003
	    group_input_003_1 = mesh_magic.nodes.new("NodeGroupInput")
	    group_input_003_1.name = "Group Input.003"
	    group_input_003_1.outputs[0].hide = True
	    group_input_003_1.outputs[2].hide = True
	    group_input_003_1.outputs[3].hide = True
	    group_input_003_1.outputs[4].hide = True
	    group_input_003_1.outputs[5].hide = True
	    group_input_003_1.outputs[6].hide = True
	    group_input_003_1.outputs[7].hide = True
	    group_input_003_1.outputs[8].hide = True
	    group_input_003_1.outputs[9].hide = True
	    group_input_003_1.outputs[10].hide = True
	    group_input_003_1.outputs[11].hide = True
	    group_input_003_1.outputs[12].hide = True
	
	    #node Set Position.002
	    set_position_002_1 = mesh_magic.nodes.new("GeometryNodeSetPosition")
	    set_position_002_1.name = "Set Position.002"
	    set_position_002_1.inputs[3].hide = True
	    #Offset
	    set_position_002_1.inputs[3].default_value = (0.0, 0.0, 0.0)
	
	    #node Geometry Proximity
	    geometry_proximity = mesh_magic.nodes.new("GeometryNodeProximity")
	    geometry_proximity.name = "Geometry Proximity"
	    geometry_proximity.hide = True
	    geometry_proximity.target_element = 'FACES'
	    geometry_proximity.inputs[1].hide = True
	    geometry_proximity.inputs[2].hide = True
	    geometry_proximity.inputs[3].hide = True
	    geometry_proximity.outputs[1].hide = True
	    geometry_proximity.outputs[2].hide = True
	    #Group ID
	    geometry_proximity.inputs[1].default_value = 0
	    #Source Position
	    geometry_proximity.inputs[2].default_value = (0.0, 0.0, 0.0)
	    #Sample Group ID
	    geometry_proximity.inputs[3].default_value = 0
	
	    #node Object Info
	    object_info = mesh_magic.nodes.new("GeometryNodeObjectInfo")
	    object_info.name = "Object Info"
	    object_info.hide = True
	    object_info.transform_space = 'RELATIVE'
	    object_info.inputs[1].hide = True
	    object_info.outputs[0].hide = True
	    object_info.outputs[1].hide = True
	    object_info.outputs[2].hide = True
	    object_info.outputs[3].hide = True
	    #As Instance
	    object_info.inputs[1].default_value = False
	
	    #node Named Attribute
	    named_attribute_1 = mesh_magic.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute_1.name = "Named Attribute"
	    named_attribute_1.data_type = 'FLOAT_VECTOR'
	    #Name
	    named_attribute_1.inputs[0].default_value = "UVMap"
	
	    #node Separate XYZ.001
	    separate_xyz_001 = mesh_magic.nodes.new("ShaderNodeSeparateXYZ")
	    separate_xyz_001.name = "Separate XYZ.001"
	    separate_xyz_001.hide = True
	    separate_xyz_001.outputs[1].hide = True
	    separate_xyz_001.outputs[2].hide = True
	
	    #node Compare
	    compare_2 = mesh_magic.nodes.new("FunctionNodeCompare")
	    compare_2.name = "Compare"
	    compare_2.hide = True
	    compare_2.data_type = 'FLOAT'
	    compare_2.mode = 'ELEMENT'
	    compare_2.operation = 'EQUAL'
	    compare_2.inputs[1].hide = True
	    compare_2.inputs[2].hide = True
	    compare_2.inputs[3].hide = True
	    compare_2.inputs[4].hide = True
	    compare_2.inputs[5].hide = True
	    compare_2.inputs[6].hide = True
	    compare_2.inputs[7].hide = True
	    compare_2.inputs[8].hide = True
	    compare_2.inputs[9].hide = True
	    compare_2.inputs[10].hide = True
	    compare_2.inputs[11].hide = True
	    compare_2.inputs[12].hide = True
	    #B
	    compare_2.inputs[1].default_value = 0.0
	    #Epsilon
	    compare_2.inputs[12].default_value = 0.0
	
	    #node Delete Geometry.001
	    delete_geometry_001_1 = mesh_magic.nodes.new("GeometryNodeDeleteGeometry")
	    delete_geometry_001_1.name = "Delete Geometry.001"
	    delete_geometry_001_1.domain = 'POINT'
	    delete_geometry_001_1.mode = 'ALL'
	
	    #node Vertex Neighbors
	    vertex_neighbors_1 = mesh_magic.nodes.new("GeometryNodeInputMeshVertexNeighbors")
	    vertex_neighbors_1.name = "Vertex Neighbors"
	    vertex_neighbors_1.outputs[0].hide = True
	
	    #node Compare.001
	    compare_001_2 = mesh_magic.nodes.new("FunctionNodeCompare")
	    compare_001_2.name = "Compare.001"
	    compare_001_2.hide = True
	    compare_001_2.data_type = 'INT'
	    compare_001_2.mode = 'ELEMENT'
	    compare_001_2.operation = 'EQUAL'
	    compare_001_2.inputs[0].hide = True
	    compare_001_2.inputs[1].hide = True
	    compare_001_2.inputs[3].hide = True
	    compare_001_2.inputs[4].hide = True
	    compare_001_2.inputs[5].hide = True
	    compare_001_2.inputs[6].hide = True
	    compare_001_2.inputs[7].hide = True
	    compare_001_2.inputs[8].hide = True
	    compare_001_2.inputs[9].hide = True
	    compare_001_2.inputs[10].hide = True
	    compare_001_2.inputs[11].hide = True
	    compare_001_2.inputs[12].hide = True
	    #B_INT
	    compare_001_2.inputs[3].default_value = 0
	
	    #node Raycast
	    raycast = mesh_magic.nodes.new("GeometryNodeRaycast")
	    raycast.name = "Raycast"
	    raycast.hide = True
	    raycast.data_type = 'FLOAT'
	    raycast.mapping = 'INTERPOLATED'
	    raycast.inputs[1].hide = True
	    raycast.inputs[2].hide = True
	    raycast.inputs[4].hide = True
	    raycast.outputs[0].hide = True
	    raycast.outputs[3].hide = True
	    raycast.outputs[4].hide = True
	    #Attribute
	    raycast.inputs[1].default_value = 0.0
	    #Source Position
	    raycast.inputs[2].default_value = (0.0, 0.0, 0.0)
	    #Ray Length
	    raycast.inputs[4].default_value = 100.0
	
	    #node Vector Math.001
	    vector_math_001_1 = mesh_magic.nodes.new("ShaderNodeVectorMath")
	    vector_math_001_1.name = "Vector Math.001"
	    vector_math_001_1.hide = True
	    vector_math_001_1.operation = 'SUBTRACT'
	
	    #node Position
	    position_2 = mesh_magic.nodes.new("GeometryNodeInputPosition")
	    position_2.name = "Position"
	
	    #node Vector Math.002
	    vector_math_002 = mesh_magic.nodes.new("ShaderNodeVectorMath")
	    vector_math_002.name = "Vector Math.002"
	    vector_math_002.hide = True
	    vector_math_002.operation = 'NORMALIZE'
	
	    #node Compare.003
	    compare_003_1 = mesh_magic.nodes.new("FunctionNodeCompare")
	    compare_003_1.name = "Compare.003"
	    compare_003_1.hide = True
	    compare_003_1.data_type = 'VECTOR'
	    compare_003_1.mode = 'DOT_PRODUCT'
	    compare_003_1.operation = 'GREATER_THAN'
	    compare_003_1.inputs[0].hide = True
	    compare_003_1.inputs[1].hide = True
	    compare_003_1.inputs[2].hide = True
	    compare_003_1.inputs[3].hide = True
	    compare_003_1.inputs[6].hide = True
	    compare_003_1.inputs[7].hide = True
	    compare_003_1.inputs[8].hide = True
	    compare_003_1.inputs[9].hide = True
	    compare_003_1.inputs[10].hide = True
	    compare_003_1.inputs[11].hide = True
	    compare_003_1.inputs[12].hide = True
	    #C
	    compare_003_1.inputs[10].default_value = 0.0
	
	    #node Merge by Distance
	    merge_by_distance = mesh_magic.nodes.new("GeometryNodeMergeByDistance")
	    merge_by_distance.name = "Merge by Distance"
	    merge_by_distance.mode = 'ALL'
	
	    #node Subdivision Surface
	    subdivision_surface = mesh_magic.nodes.new("GeometryNodeSubdivisionSurface")
	    subdivision_surface.name = "Subdivision Surface"
	    subdivision_surface.boundary_smooth = 'ALL'
	    subdivision_surface.uv_smooth = 'PRESERVE_BOUNDARIES'
	
	    #node Frame
	    frame_2 = mesh_magic.nodes.new("NodeFrame")
	    frame_2.name = "Frame"
	    frame_2.label_size = 20
	    frame_2.shrink = True
	
	    #node Geometry Proximity.001
	    geometry_proximity_001 = mesh_magic.nodes.new("GeometryNodeProximity")
	    geometry_proximity_001.name = "Geometry Proximity.001"
	    geometry_proximity_001.target_element = 'POINTS'
	    geometry_proximity_001.inputs[1].hide = True
	    geometry_proximity_001.inputs[2].hide = True
	    geometry_proximity_001.inputs[3].hide = True
	    geometry_proximity_001.outputs[1].hide = True
	    geometry_proximity_001.outputs[2].hide = True
	    #Group ID
	    geometry_proximity_001.inputs[1].default_value = 0
	    #Source Position
	    geometry_proximity_001.inputs[2].default_value = (0.0, 0.0, 0.0)
	    #Sample Group ID
	    geometry_proximity_001.inputs[3].default_value = 0
	
	    #node Reroute
	    reroute_2 = mesh_magic.nodes.new("NodeReroute")
	    reroute_2.name = "Reroute"
	    reroute_2.socket_idname = "NodeSocketVector"
	    #node Curve to Mesh.001
	    curve_to_mesh_001 = mesh_magic.nodes.new("GeometryNodeCurveToMesh")
	    curve_to_mesh_001.name = "Curve to Mesh.001"
	    curve_to_mesh_001.hide = True
	    curve_to_mesh_001.inputs[1].hide = True
	    curve_to_mesh_001.inputs[2].hide = True
	    #Fill Caps
	    curve_to_mesh_001.inputs[2].default_value = False
	
	    #node Reroute.002
	    reroute_002 = mesh_magic.nodes.new("NodeReroute")
	    reroute_002.name = "Reroute.002"
	    reroute_002.socket_idname = "NodeSocketVector"
	    #node Attribute Statistic
	    attribute_statistic_2 = mesh_magic.nodes.new("GeometryNodeAttributeStatistic")
	    attribute_statistic_2.name = "Attribute Statistic"
	    attribute_statistic_2.hide = True
	    attribute_statistic_2.data_type = 'FLOAT_VECTOR'
	    attribute_statistic_2.domain = 'POINT'
	    attribute_statistic_2.inputs[1].hide = True
	    attribute_statistic_2.outputs[1].hide = True
	    attribute_statistic_2.outputs[2].hide = True
	    attribute_statistic_2.outputs[3].hide = True
	    attribute_statistic_2.outputs[4].hide = True
	    attribute_statistic_2.outputs[5].hide = True
	    attribute_statistic_2.outputs[6].hide = True
	    attribute_statistic_2.outputs[7].hide = True
	    #Selection
	    attribute_statistic_2.inputs[1].default_value = True
	
	    #node Position.003
	    position_003 = mesh_magic.nodes.new("GeometryNodeInputPosition")
	    position_003.name = "Position.003"
	
	    #node Vector Math.003
	    vector_math_003 = mesh_magic.nodes.new("ShaderNodeVectorMath")
	    vector_math_003.name = "Vector Math.003"
	    vector_math_003.hide = True
	    vector_math_003.operation = 'SCALE'
	    vector_math_003.inputs[1].hide = True
	    vector_math_003.inputs[2].hide = True
	    vector_math_003.inputs[3].hide = True
	    vector_math_003.outputs[1].hide = True
	    #Scale
	    vector_math_003.inputs[3].default_value = -1.0
	
	    #node Sample Index
	    sample_index_1 = mesh_magic.nodes.new("GeometryNodeSampleIndex")
	    sample_index_1.name = "Sample Index"
	    sample_index_1.hide = True
	    sample_index_1.clamp = True
	    sample_index_1.data_type = 'FLOAT_VECTOR'
	    sample_index_1.domain = 'POINT'
	
	    #node Reroute.003
	    reroute_003 = mesh_magic.nodes.new("NodeReroute")
	    reroute_003.name = "Reroute.003"
	    reroute_003.socket_idname = "NodeSocketGeometry"
	    #node Index
	    index_4 = mesh_magic.nodes.new("GeometryNodeInputIndex")
	    index_4.name = "Index"
	
	    #node Transform Geometry
	    transform_geometry = mesh_magic.nodes.new("GeometryNodeTransform")
	    transform_geometry.name = "Transform Geometry"
	    transform_geometry.mode = 'COMPONENTS'
	    transform_geometry.inputs[2].hide = True
	    transform_geometry.inputs[3].hide = True
	    transform_geometry.inputs[4].hide = True
	    #Rotation
	    transform_geometry.inputs[2].default_value = (0.0, 0.0, 0.0)
	    #Scale
	    transform_geometry.inputs[3].default_value = (1.0, 1.0, 1.0)
	
	    #node Set Position.003
	    set_position_003 = mesh_magic.nodes.new("GeometryNodeSetPosition")
	    set_position_003.name = "Set Position.003"
	    set_position_003.inputs[3].hide = True
	    #Offset
	    set_position_003.inputs[3].default_value = (0.0, 0.0, 0.0)
	
	    #node Boolean Math.002
	    boolean_math_002_1 = mesh_magic.nodes.new("FunctionNodeBooleanMath")
	    boolean_math_002_1.name = "Boolean Math.002"
	    boolean_math_002_1.hide = True
	    boolean_math_002_1.operation = 'AND'
	
	    #node Reroute.001
	    reroute_001_2 = mesh_magic.nodes.new("NodeReroute")
	    reroute_001_2.name = "Reroute.001"
	    reroute_001_2.socket_idname = "NodeSocketVector"
	    #node Reroute.004
	    reroute_004_1 = mesh_magic.nodes.new("NodeReroute")
	    reroute_004_1.name = "Reroute.004"
	    reroute_004_1.socket_idname = "NodeSocketVector"
	    #node Switch
	    switch_1 = mesh_magic.nodes.new("GeometryNodeSwitch")
	    switch_1.name = "Switch"
	    switch_1.input_type = 'GEOMETRY'
	
	    #node Reroute.005
	    reroute_005_1 = mesh_magic.nodes.new("NodeReroute")
	    reroute_005_1.name = "Reroute.005"
	    reroute_005_1.socket_idname = "NodeSocketGeometry"
	    #node Reroute.006
	    reroute_006_1 = mesh_magic.nodes.new("NodeReroute")
	    reroute_006_1.name = "Reroute.006"
	    reroute_006_1.socket_idname = "NodeSocketGeometry"
	    #node Reroute.007
	    reroute_007_1 = mesh_magic.nodes.new("NodeReroute")
	    reroute_007_1.name = "Reroute.007"
	    reroute_007_1.socket_idname = "NodeSocketGeometry"
	    #node Switch.001
	    switch_001_2 = mesh_magic.nodes.new("GeometryNodeSwitch")
	    switch_001_2.name = "Switch.001"
	    switch_001_2.input_type = 'GEOMETRY'
	
	    #node Curve to Mesh.002
	    curve_to_mesh_002 = mesh_magic.nodes.new("GeometryNodeCurveToMesh")
	    curve_to_mesh_002.name = "Curve to Mesh.002"
	    curve_to_mesh_002.hide = True
	    curve_to_mesh_002.inputs[1].hide = True
	    curve_to_mesh_002.inputs[2].hide = True
	    #Fill Caps
	    curve_to_mesh_002.inputs[2].default_value = False
	
	    #node Geometry Proximity.002
	    geometry_proximity_002 = mesh_magic.nodes.new("GeometryNodeProximity")
	    geometry_proximity_002.name = "Geometry Proximity.002"
	    geometry_proximity_002.hide = True
	    geometry_proximity_002.target_element = 'EDGES'
	    geometry_proximity_002.inputs[1].hide = True
	    geometry_proximity_002.inputs[2].hide = True
	    geometry_proximity_002.inputs[3].hide = True
	    geometry_proximity_002.outputs[1].hide = True
	    geometry_proximity_002.outputs[2].hide = True
	    #Group ID
	    geometry_proximity_002.inputs[1].default_value = 0
	    #Source Position
	    geometry_proximity_002.inputs[2].default_value = (0.0, 0.0, 0.0)
	    #Sample Group ID
	    geometry_proximity_002.inputs[3].default_value = 0
	
	    #node Position.004
	    position_004 = mesh_magic.nodes.new("GeometryNodeInputPosition")
	    position_004.name = "Position.004"
	
	    #node Vector Math.004
	    vector_math_004_1 = mesh_magic.nodes.new("ShaderNodeVectorMath")
	    vector_math_004_1.name = "Vector Math.004"
	    vector_math_004_1.hide = True
	    vector_math_004_1.operation = 'SUBTRACT'
	
	    #node Compare.002
	    compare_002_2 = mesh_magic.nodes.new("FunctionNodeCompare")
	    compare_002_2.name = "Compare.002"
	    compare_002_2.hide = True
	    compare_002_2.data_type = 'VECTOR'
	    compare_002_2.mode = 'DOT_PRODUCT'
	    compare_002_2.operation = 'GREATER_THAN'
	    compare_002_2.inputs[0].hide = True
	    compare_002_2.inputs[1].hide = True
	    compare_002_2.inputs[2].hide = True
	    compare_002_2.inputs[3].hide = True
	    compare_002_2.inputs[6].hide = True
	    compare_002_2.inputs[7].hide = True
	    compare_002_2.inputs[8].hide = True
	    compare_002_2.inputs[9].hide = True
	    compare_002_2.inputs[10].hide = True
	    compare_002_2.inputs[11].hide = True
	    compare_002_2.inputs[12].hide = True
	    #C
	    compare_002_2.inputs[10].default_value = 0.0
	
	    #node Vector Math.005
	    vector_math_005 = mesh_magic.nodes.new("ShaderNodeVectorMath")
	    vector_math_005.name = "Vector Math.005"
	    vector_math_005.hide = True
	    vector_math_005.operation = 'NORMALIZE'
	
	    #node Normal
	    normal_1 = mesh_magic.nodes.new("GeometryNodeInputNormal")
	    normal_1.name = "Normal"
	    normal_1.legacy_corner_normals = False
	
	    #node Reroute.008
	    reroute_008_1 = mesh_magic.nodes.new("NodeReroute")
	    reroute_008_1.name = "Reroute.008"
	    reroute_008_1.socket_idname = "NodeSocketGeometry"
	    #node Reroute.009
	    reroute_009_1 = mesh_magic.nodes.new("NodeReroute")
	    reroute_009_1.name = "Reroute.009"
	    reroute_009_1.socket_idname = "NodeSocketGeometry"
	    #node Reroute.010
	    reroute_010_1 = mesh_magic.nodes.new("NodeReroute")
	    reroute_010_1.name = "Reroute.010"
	    reroute_010_1.socket_idname = "NodeSocketGeometry"
	    #node Group Input.005
	    group_input_005_1 = mesh_magic.nodes.new("NodeGroupInput")
	    group_input_005_1.name = "Group Input.005"
	    group_input_005_1.outputs[0].hide = True
	    group_input_005_1.outputs[1].hide = True
	    group_input_005_1.outputs[2].hide = True
	    group_input_005_1.outputs[3].hide = True
	    group_input_005_1.outputs[4].hide = True
	    group_input_005_1.outputs[5].hide = True
	    group_input_005_1.outputs[6].hide = True
	    group_input_005_1.outputs[11].hide = True
	    group_input_005_1.outputs[12].hide = True
	
	    #node Group Input.006
	    group_input_006_1 = mesh_magic.nodes.new("NodeGroupInput")
	    group_input_006_1.name = "Group Input.006"
	    group_input_006_1.outputs[0].hide = True
	    group_input_006_1.outputs[1].hide = True
	    group_input_006_1.outputs[2].hide = True
	    group_input_006_1.outputs[3].hide = True
	    group_input_006_1.outputs[4].hide = True
	    group_input_006_1.outputs[5].hide = True
	    group_input_006_1.outputs[7].hide = True
	    group_input_006_1.outputs[8].hide = True
	    group_input_006_1.outputs[9].hide = True
	    group_input_006_1.outputs[10].hide = True
	    group_input_006_1.outputs[11].hide = True
	    group_input_006_1.outputs[12].hide = True
	
	    #node Group Input.007
	    group_input_007 = mesh_magic.nodes.new("NodeGroupInput")
	    group_input_007.name = "Group Input.007"
	    group_input_007.outputs[0].hide = True
	    group_input_007.outputs[1].hide = True
	    group_input_007.outputs[2].hide = True
	    group_input_007.outputs[4].hide = True
	    group_input_007.outputs[5].hide = True
	    group_input_007.outputs[6].hide = True
	    group_input_007.outputs[7].hide = True
	    group_input_007.outputs[8].hide = True
	    group_input_007.outputs[9].hide = True
	    group_input_007.outputs[10].hide = True
	    group_input_007.outputs[11].hide = True
	    group_input_007.outputs[12].hide = True
	
	    #node Group Input.008
	    group_input_008 = mesh_magic.nodes.new("NodeGroupInput")
	    group_input_008.name = "Group Input.008"
	    group_input_008.outputs[0].hide = True
	    group_input_008.outputs[1].hide = True
	    group_input_008.outputs[2].hide = True
	    group_input_008.outputs[3].hide = True
	    group_input_008.outputs[4].hide = True
	    group_input_008.outputs[5].hide = True
	    group_input_008.outputs[6].hide = True
	    group_input_008.outputs[7].hide = True
	    group_input_008.outputs[8].hide = True
	    group_input_008.outputs[9].hide = True
	    group_input_008.outputs[10].hide = True
	    group_input_008.outputs[12].hide = True
	
	    #node Convex Hull
	    convex_hull = mesh_magic.nodes.new("GeometryNodeConvexHull")
	    convex_hull.name = "Convex Hull"
	    convex_hull.hide = True
	
	    #node Resample Curve
	    resample_curve = mesh_magic.nodes.new("GeometryNodeResampleCurve")
	    resample_curve.name = "Resample Curve"
	    resample_curve.hide = True
	    resample_curve.keep_last_segment = True
	    resample_curve.mode = 'COUNT'
	    resample_curve.inputs[1].hide = True
	    resample_curve.inputs[2].hide = True
	    resample_curve.inputs[3].hide = True
	    #Selection
	    resample_curve.inputs[1].default_value = True
	    #Count
	    resample_curve.inputs[2].default_value = 1
	
	    #node Group Input.009
	    group_input_009 = mesh_magic.nodes.new("NodeGroupInput")
	    group_input_009.name = "Group Input.009"
	    group_input_009.outputs[1].hide = True
	    group_input_009.outputs[2].hide = True
	    group_input_009.outputs[3].hide = True
	    group_input_009.outputs[4].hide = True
	    group_input_009.outputs[5].hide = True
	    group_input_009.outputs[6].hide = True
	    group_input_009.outputs[7].hide = True
	    group_input_009.outputs[8].hide = True
	    group_input_009.outputs[9].hide = True
	    group_input_009.outputs[10].hide = True
	    group_input_009.outputs[11].hide = True
	    group_input_009.outputs[12].hide = True
	
	    #node Reroute.011
	    reroute_011_1 = mesh_magic.nodes.new("NodeReroute")
	    reroute_011_1.name = "Reroute.011"
	    reroute_011_1.socket_idname = "NodeSocketGeometry"
	    #node Reroute.012
	    reroute_012_1 = mesh_magic.nodes.new("NodeReroute")
	    reroute_012_1.name = "Reroute.012"
	    reroute_012_1.socket_idname = "NodeSocketGeometry"
	    #node Reroute.013
	    reroute_013_1 = mesh_magic.nodes.new("NodeReroute")
	    reroute_013_1.name = "Reroute.013"
	    reroute_013_1.socket_idname = "NodeSocketGeometry"
	    #node Group.002
	    group_002 = mesh_magic.nodes.new("GeometryNodeGroup")
	    group_002.name = "Group.002"
	    group_002.hide = True
	    group_002.node_tree = restore_curve_segment_length
	    group_002.inputs[1].hide = True
	    #Input_4
	    group_002.inputs[1].default_value = True
	
	    #node Sample Index.003
	    sample_index_003 = mesh_magic.nodes.new("GeometryNodeSampleIndex")
	    sample_index_003.name = "Sample Index.003"
	    sample_index_003.hide = True
	    sample_index_003.clamp = False
	    sample_index_003.data_type = 'FLOAT_VECTOR'
	    sample_index_003.domain = 'POINT'
	
	    #node Index.001
	    index_001_2 = mesh_magic.nodes.new("GeometryNodeInputIndex")
	    index_001_2.name = "Index.001"
	
	    #node Position.006
	    position_006 = mesh_magic.nodes.new("GeometryNodeInputPosition")
	    position_006.name = "Position.006"
	
	    #node Group Input.004
	    group_input_004 = mesh_magic.nodes.new("NodeGroupInput")
	    group_input_004.name = "Group Input.004"
	    group_input_004.outputs[0].hide = True
	    group_input_004.outputs[1].hide = True
	    group_input_004.outputs[2].hide = True
	    group_input_004.outputs[3].hide = True
	    group_input_004.outputs[6].hide = True
	    group_input_004.outputs[7].hide = True
	    group_input_004.outputs[8].hide = True
	    group_input_004.outputs[9].hide = True
	    group_input_004.outputs[10].hide = True
	    group_input_004.outputs[11].hide = True
	    group_input_004.outputs[12].hide = True
	
	
	
	
	    #Set parents
	    merge_by_distance.parent = frame_2
	    subdivision_surface.parent = frame_2
	    curve_to_mesh_002.parent = frame_2
	    geometry_proximity_002.parent = frame_2
	    position_004.parent = frame_2
	    vector_math_004_1.parent = frame_2
	    compare_002_2.parent = frame_2
	    vector_math_005.parent = frame_2
	    normal_1.parent = frame_2
	    group_input_008.parent = frame_2
	
	    #Set locations
	    group_output_7.location = (1031.5587158203125, 81.62284851074219)
	    group_input_5.location = (-1337.7576904296875, 0.0)
	    group_2.location = (-1561.1627197265625, -444.97662353515625)
	    group_004.location = (-1387.1285400390625, -444.80096435546875)
	    group_005.location = (-1159.2635498046875, 48.164581298828125)
	    curve_to_mesh.location = (-312.4471435546875, -60.54876708984375)
	    set_position_001_1.location = (-788.6621704101562, -228.47361755371094)
	    position_002_2.location = (-792.6373901367188, -405.48309326171875)
	    separate_xyz.location = (-791.5325317382812, -374.3955078125)
	    combine_xyz.location = (-790.7725219726562, -337.9853515625)
	    set_curve_radius.location = (-975.1597900390625, 75.02672576904297)
	    capture_attribute_001.location = (-531.400146484375, -121.226318359375)
	    capture_attribute_002.location = (-533.6032104492188, -185.83802795410156)
	    spline_parameter.location = (-533.6025390625, -35.50511169433594)
	    store_named_attribute_2.location = (-132.1085205078125, -31.856613159179688)
	    combine_xyz_001.location = (-307.5316162109375, -196.94834899902344)
	    stylized_mesh_shape.location = (-1338.9588623046875, 386.1346435546875)
	    spline_parameter_001.location = (-1335.0230712890625, 69.11566925048828)
	    map_range.location = (-974.5907592773438, 125.018310546875)
	    group_input_001_3.location = (-977.0860595703125, 187.7188720703125)
	    group_input_002_2.location = (-1562.2896728515625, -548.21484375)
	    group_input_003_1.location = (-323.04083251953125, -284.2138671875)
	    set_position_002_1.location = (59.1375732421875, -6.6789703369140625)
	    geometry_proximity.location = (-124.21686553955078, -345.39385986328125)
	    object_info.location = (-317.07330322265625, -345.391845703125)
	    named_attribute_1.location = (63.2789306640625, -209.4910430908203)
	    separate_xyz_001.location = (63.2738037109375, -177.6759490966797)
	    compare_2.location = (63.2681884765625, -140.26284790039062)
	    delete_geometry_001_1.location = (410.6286315917969, 7.821929931640625)
	    vertex_neighbors_1.location = (412.1759948730469, -176.40525817871094)
	    compare_001_2.location = (412.1015319824219, -146.34869384765625)
	    raycast.location = (56.59661865234375, -342.426513671875)
	    vector_math_001_1.location = (-122.12775421142578, -379.99432373046875)
	    position_2.location = (-317.44903564453125, -374.13055419921875)
	    vector_math_002.location = (-120.57453155517578, -415.8165283203125)
	    compare_003_1.location = (63.36517333984375, -378.056884765625)
	    merge_by_distance.location = (344.03363037109375, -30.38555908203125)
	    subdivision_surface.location = (30.454833984375, -36.522369384765625)
	    frame_2.location = (621.0, -142.0)
	    geometry_proximity_001.location = (-983.087158203125, -543.2496948242188)
	    reroute_2.location = (28.21014404296875, -110.69659423828125)
	    curve_to_mesh_001.location = (-1194.0711669921875, -621.5685424804688)
	    reroute_002.location = (31.23211669921875, -243.04759216308594)
	    attribute_statistic_2.location = (-983.5204467773438, -440.9342041015625)
	    position_003.location = (-1198.7054443359375, -486.99920654296875)
	    vector_math_003.location = (-981.1094360351562, -384.22332763671875)
	    sample_index_1.location = (-982.5184936523438, -494.052734375)
	    reroute_003.location = (-1015.1716918945312, -474.0562744140625)
	    index_4.location = (-1197.283447265625, -541.866455078125)
	    transform_geometry.location = (-981.6549682617188, -253.2978057861328)
	    set_position_003.location = (244.274658203125, -105.82246398925781)
	    boolean_math_002_1.location = (244.3353271484375, -239.52256774902344)
	    reroute_001_2.location = (-389.7041015625, -577.631103515625)
	    reroute_004_1.location = (-390.2657775878906, -249.13380432128906)
	    switch_1.location = (833.3876953125, 80.71955871582031)
	    reroute_005_1.location = (601.5782470703125, -26.6990966796875)
	    reroute_006_1.location = (1102.367431640625, -101.81690979003906)
	    reroute_007_1.location = (833.978759765625, -102.31964111328125)
	    switch_001_2.location = (249.525634765625, 64.32618713378906)
	    curve_to_mesh_002.location = (36.904541015625, -387.6512451171875)
	    geometry_proximity_002.location = (347.34417724609375, -302.5712890625)
	    position_004.location = (36.405517578125, -311.45703125)
	    vector_math_004_1.location = (343.53411865234375, -249.55474853515625)
	    compare_002_2.location = (346.50726318359375, -180.98382568359375)
	    vector_math_005.location = (344.39007568359375, -215.7021484375)
	    normal_1.location = (35.951416015625, -253.07757568359375)
	    reroute_008_1.location = (606.60009765625, -287.90728759765625)
	    reroute_009_1.location = (-699.68603515625, 40.084739685058594)
	    reroute_010_1.location = (-571.5803833007812, -123.06626892089844)
	    group_input_005_1.location = (420.6587219238281, -276.055908203125)
	    group_input_006_1.location = (249.810546875, 120.62094116210938)
	    group_input_007.location = (834.636962890625, 135.9620361328125)
	    group_input_008.location = (188.27728271484375, -123.00439453125)
	    convex_hull.location = (-1747.9849853515625, -517.2109375)
	    resample_curve.location = (-1751.5504150390625, -566.2632446289062)
	    group_input_009.location = (-1751.3270263671875, -597.8270874023438)
	    reroute_011_1.location = (-571.0870361328125, 164.75799560546875)
	    reroute_012_1.location = (568.4801025390625, 178.11517333984375)
	    reroute_013_1.location = (589.6373291015625, -539.890625)
	    group_002.location = (-786.8271484375, -179.7821502685547)
	    sample_index_003.location = (-781.8150634765625, -108.58781433105469)
	    index_001_2.location = (-979.1199951171875, -89.25547790527344)
	    position_006.location = (-976.2593994140625, -34.26322937011719)
	    group_input_004.location = (-982.133056640625, -150.17100524902344)
	
	    #Set dimensions
	    group_output_7.width, group_output_7.height = 140.0, 100.0
	    group_input_5.width, group_input_5.height = 140.0, 100.0
	    group_2.width, group_2.height = 140.0, 100.0
	    group_004.width, group_004.height = 140.0, 100.0
	    group_005.width, group_005.height = 140.0, 100.0
	    curve_to_mesh.width, curve_to_mesh.height = 140.0, 100.0
	    set_position_001_1.width, set_position_001_1.height = 140.0, 100.0
	    position_002_2.width, position_002_2.height = 140.0, 100.0
	    separate_xyz.width, separate_xyz.height = 140.0, 100.0
	    combine_xyz.width, combine_xyz.height = 140.0, 100.0
	    set_curve_radius.width, set_curve_radius.height = 140.0, 100.0
	    capture_attribute_001.width, capture_attribute_001.height = 140.0, 100.0
	    capture_attribute_002.width, capture_attribute_002.height = 140.0, 100.0
	    spline_parameter.width, spline_parameter.height = 140.0, 100.0
	    store_named_attribute_2.width, store_named_attribute_2.height = 140.0, 100.0
	    combine_xyz_001.width, combine_xyz_001.height = 140.0, 100.0
	    stylized_mesh_shape.width, stylized_mesh_shape.height = 240.0, 100.0
	    spline_parameter_001.width, spline_parameter_001.height = 140.0, 100.0
	    map_range.width, map_range.height = 140.0, 100.0
	    group_input_001_3.width, group_input_001_3.height = 140.0, 100.0
	    group_input_002_2.width, group_input_002_2.height = 140.0, 100.0
	    group_input_003_1.width, group_input_003_1.height = 140.0, 100.0
	    set_position_002_1.width, set_position_002_1.height = 140.0, 100.0
	    geometry_proximity.width, geometry_proximity.height = 140.0, 100.0
	    object_info.width, object_info.height = 140.0, 100.0
	    named_attribute_1.width, named_attribute_1.height = 140.0, 100.0
	    separate_xyz_001.width, separate_xyz_001.height = 140.0, 100.0
	    compare_2.width, compare_2.height = 140.0, 100.0
	    delete_geometry_001_1.width, delete_geometry_001_1.height = 140.0, 100.0
	    vertex_neighbors_1.width, vertex_neighbors_1.height = 140.0, 100.0
	    compare_001_2.width, compare_001_2.height = 140.0, 100.0
	    raycast.width, raycast.height = 150.0, 100.0
	    vector_math_001_1.width, vector_math_001_1.height = 140.0, 100.0
	    position_2.width, position_2.height = 140.0, 100.0
	    vector_math_002.width, vector_math_002.height = 140.0, 100.0
	    compare_003_1.width, compare_003_1.height = 140.0, 100.0
	    merge_by_distance.width, merge_by_distance.height = 140.0, 100.0
	    subdivision_surface.width, subdivision_surface.height = 150.0, 100.0
	    frame_2.width, frame_2.height = 517.0, 443.0
	    geometry_proximity_001.width, geometry_proximity_001.height = 140.0, 100.0
	    reroute_2.width, reroute_2.height = 10.0, 100.0
	    curve_to_mesh_001.width, curve_to_mesh_001.height = 140.0, 100.0
	    reroute_002.width, reroute_002.height = 10.0, 100.0
	    attribute_statistic_2.width, attribute_statistic_2.height = 140.0, 100.0
	    position_003.width, position_003.height = 140.0, 100.0
	    vector_math_003.width, vector_math_003.height = 140.0, 100.0
	    sample_index_1.width, sample_index_1.height = 140.0, 100.0
	    reroute_003.width, reroute_003.height = 10.0, 100.0
	    index_4.width, index_4.height = 140.0, 100.0
	    transform_geometry.width, transform_geometry.height = 140.0, 100.0
	    set_position_003.width, set_position_003.height = 140.0, 100.0
	    boolean_math_002_1.width, boolean_math_002_1.height = 140.0, 100.0
	    reroute_001_2.width, reroute_001_2.height = 10.0, 100.0
	    reroute_004_1.width, reroute_004_1.height = 10.0, 100.0
	    switch_1.width, switch_1.height = 140.0, 100.0
	    reroute_005_1.width, reroute_005_1.height = 10.0, 100.0
	    reroute_006_1.width, reroute_006_1.height = 10.0, 100.0
	    reroute_007_1.width, reroute_007_1.height = 10.0, 100.0
	    switch_001_2.width, switch_001_2.height = 140.0, 100.0
	    curve_to_mesh_002.width, curve_to_mesh_002.height = 140.0, 100.0
	    geometry_proximity_002.width, geometry_proximity_002.height = 140.0, 100.0
	    position_004.width, position_004.height = 140.0, 100.0
	    vector_math_004_1.width, vector_math_004_1.height = 140.0, 100.0
	    compare_002_2.width, compare_002_2.height = 140.0, 100.0
	    vector_math_005.width, vector_math_005.height = 140.0, 100.0
	    normal_1.width, normal_1.height = 140.0, 100.0
	    reroute_008_1.width, reroute_008_1.height = 10.0, 100.0
	    reroute_009_1.width, reroute_009_1.height = 10.0, 100.0
	    reroute_010_1.width, reroute_010_1.height = 10.0, 100.0
	    group_input_005_1.width, group_input_005_1.height = 140.0, 100.0
	    group_input_006_1.width, group_input_006_1.height = 140.0, 100.0
	    group_input_007.width, group_input_007.height = 140.0, 100.0
	    group_input_008.width, group_input_008.height = 140.0, 100.0
	    convex_hull.width, convex_hull.height = 140.0, 100.0
	    resample_curve.width, resample_curve.height = 140.0, 100.0
	    group_input_009.width, group_input_009.height = 140.0, 100.0
	    reroute_011_1.width, reroute_011_1.height = 10.0, 100.0
	    reroute_012_1.width, reroute_012_1.height = 10.0, 100.0
	    reroute_013_1.width, reroute_013_1.height = 10.0, 100.0
	    group_002.width, group_002.height = 140.0, 100.0
	    sample_index_003.width, sample_index_003.height = 140.0, 100.0
	    index_001_2.width, index_001_2.height = 140.0, 100.0
	    position_006.width, position_006.height = 140.0, 100.0
	    group_input_004.width, group_input_004.height = 140.0, 100.0
	
	    #initialize mesh_magic links
	    #combine_xyz.Vector -> set_position_001_1.Position
	    mesh_magic.links.new(combine_xyz.outputs[0], set_position_001_1.inputs[2])
	    #position_002_2.Position -> separate_xyz.Vector
	    mesh_magic.links.new(position_002_2.outputs[0], separate_xyz.inputs[0])
	    #capture_attribute_001.Geometry -> curve_to_mesh.Curve
	    mesh_magic.links.new(capture_attribute_001.outputs[0], curve_to_mesh.inputs[0])
	    #separate_xyz.X -> combine_xyz.X
	    mesh_magic.links.new(separate_xyz.outputs[0], combine_xyz.inputs[0])
	    #group_005.Geometry -> set_curve_radius.Curve
	    mesh_magic.links.new(group_005.outputs[0], set_curve_radius.inputs[0])
	    #separate_xyz.Y -> combine_xyz.Y
	    mesh_magic.links.new(separate_xyz.outputs[1], combine_xyz.inputs[1])
	    #capture_attribute_002.Geometry -> curve_to_mesh.Profile Curve
	    mesh_magic.links.new(capture_attribute_002.outputs[0], curve_to_mesh.inputs[1])
	    #group_2.Geometry -> group_004.Geometry
	    mesh_magic.links.new(group_2.outputs[0], group_004.inputs[0])
	    #transform_geometry.Geometry -> set_position_001_1.Geometry
	    mesh_magic.links.new(transform_geometry.outputs[0], set_position_001_1.inputs[0])
	    #group_input_5.Geometry -> group_005.Geometry
	    mesh_magic.links.new(group_input_5.outputs[0], group_005.inputs[0])
	    #reroute_010_1.Output -> capture_attribute_001.Geometry
	    mesh_magic.links.new(reroute_010_1.outputs[0], capture_attribute_001.inputs[0])
	    #spline_parameter.Factor -> capture_attribute_001.Factor
	    mesh_magic.links.new(spline_parameter.outputs[0], capture_attribute_001.inputs[1])
	    #spline_parameter.Factor -> capture_attribute_002.Factor
	    mesh_magic.links.new(spline_parameter.outputs[0], capture_attribute_002.inputs[1])
	    #curve_to_mesh.Mesh -> store_named_attribute_2.Geometry
	    mesh_magic.links.new(curve_to_mesh.outputs[0], store_named_attribute_2.inputs[0])
	    #combine_xyz_001.Vector -> store_named_attribute_2.Value
	    mesh_magic.links.new(combine_xyz_001.outputs[0], store_named_attribute_2.inputs[3])
	    #capture_attribute_001.Factor -> combine_xyz_001.X
	    mesh_magic.links.new(capture_attribute_001.outputs[1], combine_xyz_001.inputs[0])
	    #capture_attribute_002.Factor -> combine_xyz_001.Y
	    mesh_magic.links.new(capture_attribute_002.outputs[1], combine_xyz_001.inputs[1])
	    #spline_parameter_001.Factor -> stylized_mesh_shape.Value
	    mesh_magic.links.new(spline_parameter_001.outputs[0], stylized_mesh_shape.inputs[1])
	    #stylized_mesh_shape.Value -> map_range.Value
	    mesh_magic.links.new(stylized_mesh_shape.outputs[0], map_range.inputs[0])
	    #map_range.Result -> set_curve_radius.Radius
	    mesh_magic.links.new(map_range.outputs[0], set_curve_radius.inputs[2])
	    #group_input_001_3.Radius -> map_range.To Max
	    mesh_magic.links.new(group_input_001_3.outputs[2], map_range.inputs[4])
	    #group_input_002_2.Surface -> group_004.Surface
	    mesh_magic.links.new(group_input_002_2.outputs[1], group_004.inputs[1])
	    #store_named_attribute_2.Geometry -> set_position_002_1.Geometry
	    mesh_magic.links.new(store_named_attribute_2.outputs[0], set_position_002_1.inputs[0])
	    #group_input_003_1.Surface -> object_info.Object
	    mesh_magic.links.new(group_input_003_1.outputs[1], object_info.inputs[0])
	    #object_info.Geometry -> geometry_proximity.Geometry
	    mesh_magic.links.new(object_info.outputs[4], geometry_proximity.inputs[0])
	    #named_attribute_1.Attribute -> separate_xyz_001.Vector
	    mesh_magic.links.new(named_attribute_1.outputs[0], separate_xyz_001.inputs[0])
	    #separate_xyz_001.X -> compare_2.A
	    mesh_magic.links.new(separate_xyz_001.outputs[0], compare_2.inputs[0])
	    #vertex_neighbors_1.Face Count -> compare_001_2.A
	    mesh_magic.links.new(vertex_neighbors_1.outputs[1], compare_001_2.inputs[2])
	    #compare_001_2.Result -> delete_geometry_001_1.Selection
	    mesh_magic.links.new(compare_001_2.outputs[0], delete_geometry_001_1.inputs[1])
	    #object_info.Geometry -> raycast.Target Geometry
	    mesh_magic.links.new(object_info.outputs[4], raycast.inputs[0])
	    #geometry_proximity.Position -> vector_math_001_1.Vector
	    mesh_magic.links.new(geometry_proximity.outputs[0], vector_math_001_1.inputs[0])
	    #position_2.Position -> vector_math_001_1.Vector
	    mesh_magic.links.new(position_2.outputs[0], vector_math_001_1.inputs[1])
	    #vector_math_001_1.Vector -> vector_math_002.Vector
	    mesh_magic.links.new(vector_math_001_1.outputs[0], vector_math_002.inputs[0])
	    #vector_math_002.Vector -> raycast.Ray Direction
	    mesh_magic.links.new(vector_math_002.outputs[0], raycast.inputs[3])
	    #vector_math_002.Vector -> compare_003_1.A
	    mesh_magic.links.new(vector_math_002.outputs[0], compare_003_1.inputs[4])
	    #raycast.Hit Normal -> compare_003_1.B
	    mesh_magic.links.new(raycast.outputs[2], compare_003_1.inputs[5])
	    #reroute_2.Output -> set_position_002_1.Position
	    mesh_magic.links.new(reroute_2.outputs[0], set_position_002_1.inputs[2])
	    #curve_to_mesh_001.Mesh -> geometry_proximity_001.Geometry
	    mesh_magic.links.new(curve_to_mesh_001.outputs[0], geometry_proximity_001.inputs[0])
	    #group_004.Geometry -> curve_to_mesh_001.Curve
	    mesh_magic.links.new(group_004.outputs[0], curve_to_mesh_001.inputs[0])
	    #reroute_004_1.Output -> reroute_002.Input
	    mesh_magic.links.new(reroute_004_1.outputs[0], reroute_002.inputs[0])
	    #reroute_002.Output -> reroute_2.Input
	    mesh_magic.links.new(reroute_002.outputs[0], reroute_2.inputs[0])
	    #reroute_003.Output -> attribute_statistic_2.Geometry
	    mesh_magic.links.new(reroute_003.outputs[0], attribute_statistic_2.inputs[0])
	    #attribute_statistic_2.Mean -> vector_math_003.Vector
	    mesh_magic.links.new(attribute_statistic_2.outputs[0], vector_math_003.inputs[0])
	    #group_004.Geometry -> reroute_003.Input
	    mesh_magic.links.new(group_004.outputs[0], reroute_003.inputs[0])
	    #reroute_003.Output -> sample_index_1.Geometry
	    mesh_magic.links.new(reroute_003.outputs[0], sample_index_1.inputs[0])
	    #index_4.Index -> sample_index_1.Index
	    mesh_magic.links.new(index_4.outputs[0], sample_index_1.inputs[2])
	    #position_003.Position -> sample_index_1.Value
	    mesh_magic.links.new(position_003.outputs[0], sample_index_1.inputs[1])
	    #sample_index_1.Value -> attribute_statistic_2.Attribute
	    mesh_magic.links.new(sample_index_1.outputs[0], attribute_statistic_2.inputs[2])
	    #group_004.Geometry -> transform_geometry.Geometry
	    mesh_magic.links.new(group_004.outputs[0], transform_geometry.inputs[0])
	    #vector_math_003.Vector -> transform_geometry.Translation
	    mesh_magic.links.new(vector_math_003.outputs[0], transform_geometry.inputs[1])
	    #compare_2.Result -> set_position_002_1.Selection
	    mesh_magic.links.new(compare_2.outputs[0], set_position_002_1.inputs[1])
	    #set_position_002_1.Geometry -> set_position_003.Geometry
	    mesh_magic.links.new(set_position_002_1.outputs[0], set_position_003.inputs[0])
	    #raycast.Hit Position -> set_position_003.Position
	    mesh_magic.links.new(raycast.outputs[1], set_position_003.inputs[2])
	    #compare_003_1.Result -> boolean_math_002_1.Boolean
	    mesh_magic.links.new(compare_003_1.outputs[0], boolean_math_002_1.inputs[1])
	    #compare_2.Result -> boolean_math_002_1.Boolean
	    mesh_magic.links.new(compare_2.outputs[0], boolean_math_002_1.inputs[0])
	    #boolean_math_002_1.Boolean -> set_position_003.Selection
	    mesh_magic.links.new(boolean_math_002_1.outputs[0], set_position_003.inputs[1])
	    #geometry_proximity_001.Position -> reroute_001_2.Input
	    mesh_magic.links.new(geometry_proximity_001.outputs[0], reroute_001_2.inputs[0])
	    #reroute_001_2.Output -> reroute_004_1.Input
	    mesh_magic.links.new(reroute_001_2.outputs[0], reroute_004_1.inputs[0])
	    #reroute_007_1.Output -> switch_1.True
	    mesh_magic.links.new(reroute_007_1.outputs[0], switch_1.inputs[2])
	    #reroute_005_1.Output -> switch_1.False
	    mesh_magic.links.new(reroute_005_1.outputs[0], switch_1.inputs[1])
	    #switch_1.Output -> group_output_7.Geometry
	    mesh_magic.links.new(switch_1.outputs[0], group_output_7.inputs[0])
	    #delete_geometry_001_1.Geometry -> reroute_005_1.Input
	    mesh_magic.links.new(delete_geometry_001_1.outputs[0], reroute_005_1.inputs[0])
	    #reroute_006_1.Output -> reroute_007_1.Input
	    mesh_magic.links.new(reroute_006_1.outputs[0], reroute_007_1.inputs[0])
	    #set_position_003.Geometry -> switch_001_2.True
	    mesh_magic.links.new(set_position_003.outputs[0], switch_001_2.inputs[2])
	    #set_position_002_1.Geometry -> switch_001_2.False
	    mesh_magic.links.new(set_position_002_1.outputs[0], switch_001_2.inputs[1])
	    #switch_001_2.Output -> delete_geometry_001_1.Geometry
	    mesh_magic.links.new(switch_001_2.outputs[0], delete_geometry_001_1.inputs[0])
	    #curve_to_mesh_002.Mesh -> geometry_proximity_002.Geometry
	    mesh_magic.links.new(curve_to_mesh_002.outputs[0], geometry_proximity_002.inputs[0])
	    #geometry_proximity_002.Position -> vector_math_004_1.Vector
	    mesh_magic.links.new(geometry_proximity_002.outputs[0], vector_math_004_1.inputs[0])
	    #vector_math_005.Vector -> compare_002_2.A
	    mesh_magic.links.new(vector_math_005.outputs[0], compare_002_2.inputs[4])
	    #subdivision_surface.Mesh -> merge_by_distance.Geometry
	    mesh_magic.links.new(subdivision_surface.outputs[0], merge_by_distance.inputs[0])
	    #merge_by_distance.Geometry -> reroute_006_1.Input
	    mesh_magic.links.new(merge_by_distance.outputs[0], reroute_006_1.inputs[0])
	    #reroute_008_1.Output -> subdivision_surface.Mesh
	    mesh_magic.links.new(reroute_008_1.outputs[0], subdivision_surface.inputs[0])
	    #position_004.Position -> vector_math_004_1.Vector
	    mesh_magic.links.new(position_004.outputs[0], vector_math_004_1.inputs[1])
	    #vector_math_004_1.Vector -> vector_math_005.Vector
	    mesh_magic.links.new(vector_math_004_1.outputs[0], vector_math_005.inputs[0])
	    #normal_1.Normal -> compare_002_2.B
	    mesh_magic.links.new(normal_1.outputs[0], compare_002_2.inputs[5])
	    #compare_002_2.Result -> merge_by_distance.Selection
	    mesh_magic.links.new(compare_002_2.outputs[0], merge_by_distance.inputs[1])
	    #reroute_005_1.Output -> reroute_008_1.Input
	    mesh_magic.links.new(reroute_005_1.outputs[0], reroute_008_1.inputs[0])
	    #set_curve_radius.Curve -> reroute_009_1.Input
	    mesh_magic.links.new(set_curve_radius.outputs[0], reroute_009_1.inputs[0])
	    #reroute_009_1.Output -> reroute_010_1.Input
	    mesh_magic.links.new(reroute_009_1.outputs[0], reroute_010_1.inputs[0])
	    #group_input_006_1.Snap to surface -> switch_001_2.Switch
	    mesh_magic.links.new(group_input_006_1.outputs[6], switch_001_2.inputs[0])
	    #group_input_007.Use Enhancements -> switch_1.Switch
	    mesh_magic.links.new(group_input_007.outputs[3], switch_1.inputs[0])
	    #group_input_005_1.Level -> subdivision_surface.Level
	    mesh_magic.links.new(group_input_005_1.outputs[7], subdivision_surface.inputs[1])
	    #group_input_005_1.Edge Crease -> subdivision_surface.Edge Crease
	    mesh_magic.links.new(group_input_005_1.outputs[8], subdivision_surface.inputs[2])
	    #group_input_005_1.Vertex Crease -> subdivision_surface.Vertex Crease
	    mesh_magic.links.new(group_input_005_1.outputs[9], subdivision_surface.inputs[3])
	    #group_input_005_1.Limit Surface -> subdivision_surface.Limit Surface
	    mesh_magic.links.new(group_input_005_1.outputs[10], subdivision_surface.inputs[4])
	    #group_input_008.Distance -> merge_by_distance.Distance
	    mesh_magic.links.new(group_input_008.outputs[11], merge_by_distance.inputs[2])
	    #resample_curve.Curve -> convex_hull.Geometry
	    mesh_magic.links.new(resample_curve.outputs[0], convex_hull.inputs[0])
	    #group_input_009.Geometry -> resample_curve.Curve
	    mesh_magic.links.new(group_input_009.outputs[0], resample_curve.inputs[0])
	    #convex_hull.Convex Hull -> group_2.Geometry
	    mesh_magic.links.new(convex_hull.outputs[0], group_2.inputs[0])
	    #reroute_011_1.Output -> reroute_012_1.Input
	    mesh_magic.links.new(reroute_011_1.outputs[0], reroute_012_1.inputs[0])
	    #reroute_013_1.Output -> curve_to_mesh_002.Curve
	    mesh_magic.links.new(reroute_013_1.outputs[0], curve_to_mesh_002.inputs[0])
	    #reroute_012_1.Output -> reroute_013_1.Input
	    mesh_magic.links.new(reroute_012_1.outputs[0], reroute_013_1.inputs[0])
	    #transform_geometry.Geometry -> sample_index_003.Geometry
	    mesh_magic.links.new(transform_geometry.outputs[0], sample_index_003.inputs[0])
	    #index_001_2.Index -> sample_index_003.Index
	    mesh_magic.links.new(index_001_2.outputs[0], sample_index_003.inputs[2])
	    #position_006.Position -> sample_index_003.Value
	    mesh_magic.links.new(position_006.outputs[0], sample_index_003.inputs[1])
	    #set_position_001_1.Geometry -> group_002.Curves
	    mesh_magic.links.new(set_position_001_1.outputs[0], group_002.inputs[0])
	    #sample_index_003.Value -> group_002.Reference Position
	    mesh_magic.links.new(sample_index_003.outputs[0], group_002.inputs[3])
	    #group_002.Curves -> capture_attribute_002.Geometry
	    mesh_magic.links.new(group_002.outputs[0], capture_attribute_002.inputs[0])
	    #group_input_004.Maintain Shape Factor -> group_002.Factor
	    mesh_magic.links.new(group_input_004.outputs[4], group_002.inputs[2])
	    #group_input_004.Pin at Parameter -> group_002.Pin at Parameter
	    mesh_magic.links.new(group_input_004.outputs[5], group_002.inputs[4])
	    #reroute_009_1.Output -> reroute_011_1.Input
	    mesh_magic.links.new(reroute_009_1.outputs[0], reroute_011_1.inputs[0])
	    return mesh_magic
	
	mesh_magic = mesh_magic_node_group()
	
	#initialize stylized_meshify_hair node group
	def stylized_meshify_hair_node_group():
	    stylized_meshify_hair = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "STYLIZED_MESHIFY_HAIR")
	
	    stylized_meshify_hair.color_tag = 'NONE'
	    stylized_meshify_hair.description = "Convert muiltiguided curves to stylized mesh."
	    stylized_meshify_hair.default_group_node_width = 140
	    
	
	    stylized_meshify_hair.is_modifier = True
	
	    #stylized_meshify_hair interface
	    #Socket Geometry
	    geometry_socket_10 = stylized_meshify_hair.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_10.attribute_domain = 'POINT'
	    geometry_socket_10.description = "Stylized mesh hair."
	
	    #Socket Geometry
	    geometry_socket_11 = stylized_meshify_hair.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_11.attribute_domain = 'POINT'
	    geometry_socket_11.description = "Multiguided curves."
	
	    #Socket Surface
	    surface_socket_2 = stylized_meshify_hair.interface.new_socket(name = "Surface", in_out='INPUT', socket_type = 'NodeSocketObject')
	    surface_socket_2.attribute_domain = 'POINT'
	    surface_socket_2.description = "Surface attached to hair."
	
	    #Socket Material
	    material_socket = stylized_meshify_hair.interface.new_socket(name = "Material", in_out='INPUT', socket_type = 'NodeSocketMaterial')
	    material_socket.attribute_domain = 'POINT'
	    material_socket.description = "Mesh Material."
	
	    #Socket Control Points
	    control_points_socket = stylized_meshify_hair.interface.new_socket(name = "Control Points", in_out='INPUT', socket_type = 'NodeSocketInt')
	    control_points_socket.default_value = 10
	    control_points_socket.min_value = 2
	    control_points_socket.max_value = 100000
	    control_points_socket.subtype = 'NONE'
	    control_points_socket.attribute_domain = 'POINT'
	    control_points_socket.description = "Amount of points to resample the curves. (Amount < 2  means no resampling)"
	
	    #Socket Radius
	    radius_socket_1 = stylized_meshify_hair.interface.new_socket(name = "Radius", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    radius_socket_1.default_value = 1.0
	    radius_socket_1.min_value = 0.0
	    radius_socket_1.max_value = 3.4028234663852886e+38
	    radius_socket_1.subtype = 'DISTANCE'
	    radius_socket_1.attribute_domain = 'POINT'
	    radius_socket_1.description = "Mesh Radius."
	
	    #Panel Enhancement Settings
	    enhancement_settings_panel_1 = stylized_meshify_hair.interface.new_panel("Enhancement Settings", default_closed=True)
	    enhancement_settings_panel_1.description = "Settings for mesh enhancements."
	    #Socket Use Enhancements
	    use_enhancements_socket_1 = stylized_meshify_hair.interface.new_socket(name = "Use Enhancements", in_out='INPUT', socket_type = 'NodeSocketBool', parent = enhancement_settings_panel_1)
	    use_enhancements_socket_1.default_value = True
	    use_enhancements_socket_1.attribute_domain = 'POINT'
	    use_enhancements_socket_1.description = "Use Enhancement settings."
	
	    #Socket Maintain Shape Factor
	    maintain_shape_factor_socket_1 = stylized_meshify_hair.interface.new_socket(name = "Maintain Shape Factor", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = enhancement_settings_panel_1)
	    maintain_shape_factor_socket_1.default_value = 1.0
	    maintain_shape_factor_socket_1.min_value = 0.0
	    maintain_shape_factor_socket_1.max_value = 1.0
	    maintain_shape_factor_socket_1.subtype = 'FACTOR'
	    maintain_shape_factor_socket_1.attribute_domain = 'POINT'
	    maintain_shape_factor_socket_1.description = "Factor to blend overall effect"
	
	    #Socket Pin at Parameter
	    pin_at_parameter_socket_2 = stylized_meshify_hair.interface.new_socket(name = "Pin at Parameter", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = enhancement_settings_panel_1)
	    pin_at_parameter_socket_2.default_value = 0.0
	    pin_at_parameter_socket_2.min_value = 0.0
	    pin_at_parameter_socket_2.max_value = 1.0
	    pin_at_parameter_socket_2.subtype = 'FACTOR'
	    pin_at_parameter_socket_2.attribute_domain = 'POINT'
	    pin_at_parameter_socket_2.description = "Pin each curve at a certain point for the operation"
	
	    #Socket Snap to surface
	    snap_to_surface_socket_1 = stylized_meshify_hair.interface.new_socket(name = "Snap to surface", in_out='INPUT', socket_type = 'NodeSocketBool', parent = enhancement_settings_panel_1)
	    snap_to_surface_socket_1.default_value = False
	    snap_to_surface_socket_1.attribute_domain = 'POINT'
	    snap_to_surface_socket_1.description = "Snap mesh roots to the nearest surface point."
	
	    #Panel Subdivision Settings
	    subdivision_settings_panel_1 = stylized_meshify_hair.interface.new_panel("Subdivision Settings", default_closed=True)
	    subdivision_settings_panel_1.description = "Settings for mesh subdivision."
	    #Socket Subdivison Level
	    subdivison_level_socket = stylized_meshify_hair.interface.new_socket(name = "Subdivison Level", in_out='INPUT', socket_type = 'NodeSocketInt', parent = subdivision_settings_panel_1)
	    subdivison_level_socket.default_value = 1
	    subdivison_level_socket.min_value = 0
	    subdivison_level_socket.max_value = 6
	    subdivison_level_socket.subtype = 'NONE'
	    subdivison_level_socket.attribute_domain = 'POINT'
	    subdivison_level_socket.description = "Subdivision level."
	
	    #Socket Edge Crease
	    edge_crease_socket_1 = stylized_meshify_hair.interface.new_socket(name = "Edge Crease", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = subdivision_settings_panel_1)
	    edge_crease_socket_1.default_value = 0.0
	    edge_crease_socket_1.min_value = 0.0
	    edge_crease_socket_1.max_value = 1.0
	    edge_crease_socket_1.subtype = 'FACTOR'
	    edge_crease_socket_1.attribute_domain = 'POINT'
	    edge_crease_socket_1.description = "Edge crease factor for subdivision."
	
	    #Socket Vertex Crease
	    vertex_crease_socket_1 = stylized_meshify_hair.interface.new_socket(name = "Vertex Crease", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = subdivision_settings_panel_1)
	    vertex_crease_socket_1.default_value = 0.0
	    vertex_crease_socket_1.min_value = 0.0
	    vertex_crease_socket_1.max_value = 1.0
	    vertex_crease_socket_1.subtype = 'FACTOR'
	    vertex_crease_socket_1.attribute_domain = 'POINT'
	    vertex_crease_socket_1.description = "Vertex crease factor for subdivision."
	
	    #Socket Limit Surface
	    limit_surface_socket_1 = stylized_meshify_hair.interface.new_socket(name = "Limit Surface", in_out='INPUT', socket_type = 'NodeSocketBool', parent = subdivision_settings_panel_1)
	    limit_surface_socket_1.default_value = True
	    limit_surface_socket_1.attribute_domain = 'POINT'
	    limit_surface_socket_1.description = "Limit subdivision on surface."
	
	
	    stylized_meshify_hair.interface.move_to_parent(subdivision_settings_panel_1, enhancement_settings_panel_1, 11)
	    #Panel Merge Settings
	    merge_settings_panel_1 = stylized_meshify_hair.interface.new_panel("Merge Settings", default_closed=True)
	    merge_settings_panel_1.description = "Settings for merging points."
	    #Socket Distance
	    distance_socket_1 = stylized_meshify_hair.interface.new_socket(name = "Distance", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = merge_settings_panel_1)
	    distance_socket_1.default_value = 0.0010000000474974513
	    distance_socket_1.min_value = 0.0
	    distance_socket_1.max_value = 3.4028234663852886e+38
	    distance_socket_1.subtype = 'DISTANCE'
	    distance_socket_1.attribute_domain = 'POINT'
	    distance_socket_1.description = "Distance threshold to merge points."
	
	
	    stylized_meshify_hair.interface.move_to_parent(merge_settings_panel_1, enhancement_settings_panel_1, 16)
	
	
	    #initialize stylized_meshify_hair nodes
	    #node Group Input
	    group_input_6 = stylized_meshify_hair.nodes.new("NodeGroupInput")
	    group_input_6.name = "Group Input"
	    group_input_6.outputs[1].hide = True
	    group_input_6.outputs[2].hide = True
	    group_input_6.outputs[3].hide = True
	    group_input_6.outputs[4].hide = True
	    group_input_6.outputs[5].hide = True
	    group_input_6.outputs[6].hide = True
	    group_input_6.outputs[7].hide = True
	    group_input_6.outputs[8].hide = True
	    group_input_6.outputs[9].hide = True
	    group_input_6.outputs[10].hide = True
	    group_input_6.outputs[11].hide = True
	    group_input_6.outputs[12].hide = True
	    group_input_6.outputs[13].hide = True
	    group_input_6.outputs[14].hide = True
	
	    #node Group Output
	    group_output_8 = stylized_meshify_hair.nodes.new("NodeGroupOutput")
	    group_output_8.name = "Group Output"
	    group_output_8.is_active_output = True
	    group_output_8.inputs[1].hide = True
	
	    #node Named Attribute
	    named_attribute_2 = stylized_meshify_hair.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute_2.name = "Named Attribute"
	    named_attribute_2.data_type = 'INT'
	    #Name
	    named_attribute_2.inputs[0].default_value = "closest_idx"
	
	    #node Compare
	    compare_3 = stylized_meshify_hair.nodes.new("FunctionNodeCompare")
	    compare_3.name = "Compare"
	    compare_3.hide = True
	    compare_3.data_type = 'INT'
	    compare_3.mode = 'ELEMENT'
	    compare_3.operation = 'EQUAL'
	
	    #node Separate Geometry
	    separate_geometry = stylized_meshify_hair.nodes.new("GeometryNodeSeparateGeometry")
	    separate_geometry.name = "Separate Geometry"
	    separate_geometry.domain = 'CURVE'
	    separate_geometry.outputs[1].hide = True
	
	    #node Attribute Statistic.001
	    attribute_statistic_001 = stylized_meshify_hair.nodes.new("GeometryNodeAttributeStatistic")
	    attribute_statistic_001.name = "Attribute Statistic.001"
	    attribute_statistic_001.hide = True
	    attribute_statistic_001.data_type = 'FLOAT'
	    attribute_statistic_001.domain = 'CURVE'
	    attribute_statistic_001.inputs[1].hide = True
	    attribute_statistic_001.outputs[0].hide = True
	    attribute_statistic_001.outputs[1].hide = True
	    attribute_statistic_001.outputs[2].hide = True
	    attribute_statistic_001.outputs[3].hide = True
	    attribute_statistic_001.outputs[5].hide = True
	    attribute_statistic_001.outputs[6].hide = True
	    attribute_statistic_001.outputs[7].hide = True
	    #Selection
	    attribute_statistic_001.inputs[1].default_value = True
	
	    #node Repeat Input
	    repeat_input_1 = stylized_meshify_hair.nodes.new("GeometryNodeRepeatInput")
	    repeat_input_1.name = "Repeat Input"
	    #node Repeat Output
	    repeat_output_1 = stylized_meshify_hair.nodes.new("GeometryNodeRepeatOutput")
	    repeat_output_1.name = "Repeat Output"
	    repeat_output_1.active_index = 1
	    repeat_output_1.inspection_index = 0
	    repeat_output_1.repeat_items.clear()
	    # Create item "Geometry"
	    repeat_output_1.repeat_items.new('GEOMETRY', "Geometry")
	    # Create item "Index"
	    repeat_output_1.repeat_items.new('INT', "Index")
	
	    #node Join Geometry.001
	    join_geometry_001 = stylized_meshify_hair.nodes.new("GeometryNodeJoinGeometry")
	    join_geometry_001.name = "Join Geometry.001"
	    join_geometry_001.hide = True
	
	    #node Math
	    math_2 = stylized_meshify_hair.nodes.new("ShaderNodeMath")
	    math_2.name = "Math"
	    math_2.hide = True
	    math_2.operation = 'ADD'
	    math_2.use_clamp = False
	    #Value_001
	    math_2.inputs[1].default_value = 1.0
	
	    #node Math.001
	    math_001_1 = stylized_meshify_hair.nodes.new("ShaderNodeMath")
	    math_001_1.name = "Math.001"
	    math_001_1.hide = True
	    math_001_1.operation = 'ADD'
	    math_001_1.use_clamp = False
	    #Value_001
	    math_001_1.inputs[1].default_value = 1.0
	
	    #node Named Attribute.003
	    named_attribute_003 = stylized_meshify_hair.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute_003.name = "Named Attribute.003"
	    named_attribute_003.data_type = 'INT'
	    #Name
	    named_attribute_003.inputs[0].default_value = "closest_idx"
	
	    #node Reroute.001
	    reroute_001_3 = stylized_meshify_hair.nodes.new("NodeReroute")
	    reroute_001_3.name = "Reroute.001"
	    reroute_001_3.socket_idname = "NodeSocketGeometry"
	    #node Reroute.002
	    reroute_002_1 = stylized_meshify_hair.nodes.new("NodeReroute")
	    reroute_002_1.name = "Reroute.002"
	    reroute_002_1.socket_idname = "NodeSocketGeometry"
	    #node Set Material
	    set_material = stylized_meshify_hair.nodes.new("GeometryNodeSetMaterial")
	    set_material.name = "Set Material"
	    set_material.inputs[1].hide = True
	    #Selection
	    set_material.inputs[1].default_value = True
	
	    #node Group Input.008
	    group_input_008_1 = stylized_meshify_hair.nodes.new("NodeGroupInput")
	    group_input_008_1.name = "Group Input.008"
	    group_input_008_1.outputs[0].hide = True
	    group_input_008_1.outputs[1].hide = True
	    group_input_008_1.outputs[3].hide = True
	    group_input_008_1.outputs[4].hide = True
	    group_input_008_1.outputs[5].hide = True
	    group_input_008_1.outputs[6].hide = True
	    group_input_008_1.outputs[7].hide = True
	    group_input_008_1.outputs[8].hide = True
	    group_input_008_1.outputs[9].hide = True
	    group_input_008_1.outputs[10].hide = True
	    group_input_008_1.outputs[11].hide = True
	    group_input_008_1.outputs[12].hide = True
	    group_input_008_1.outputs[13].hide = True
	    group_input_008_1.outputs[14].hide = True
	
	    #node Group Input.010
	    group_input_010 = stylized_meshify_hair.nodes.new("NodeGroupInput")
	    group_input_010.name = "Group Input.010"
	    group_input_010.outputs[0].hide = True
	    group_input_010.outputs[1].hide = True
	    group_input_010.outputs[2].hide = True
	    group_input_010.outputs[3].hide = True
	    group_input_010.outputs[14].hide = True
	
	    #node Group Input.005
	    group_input_005_2 = stylized_meshify_hair.nodes.new("NodeGroupInput")
	    group_input_005_2.name = "Group Input.005"
	    group_input_005_2.outputs[0].hide = True
	    group_input_005_2.outputs[2].hide = True
	    group_input_005_2.outputs[3].hide = True
	    group_input_005_2.outputs[4].hide = True
	    group_input_005_2.outputs[5].hide = True
	    group_input_005_2.outputs[6].hide = True
	    group_input_005_2.outputs[7].hide = True
	    group_input_005_2.outputs[8].hide = True
	    group_input_005_2.outputs[9].hide = True
	    group_input_005_2.outputs[10].hide = True
	    group_input_005_2.outputs[11].hide = True
	    group_input_005_2.outputs[12].hide = True
	    group_input_005_2.outputs[13].hide = True
	    group_input_005_2.outputs[14].hide = True
	
	    #node Reroute.010
	    reroute_010_2 = stylized_meshify_hair.nodes.new("NodeReroute")
	    reroute_010_2.name = "Reroute.010"
	    reroute_010_2.socket_idname = "NodeSocketGeometry"
	    #node Group.007
	    group_007 = stylized_meshify_hair.nodes.new("GeometryNodeGroup")
	    group_007.name = "Group.007"
	    group_007.node_tree = mesh_magic
	
	    #node Stylized Mesh Bake
	    stylized_mesh_bake = stylized_meshify_hair.nodes.new("GeometryNodeBake")
	    stylized_mesh_bake.label = "Stylized Mesh Bake"
	    stylized_mesh_bake.name = "Stylized Mesh Bake"
	    stylized_mesh_bake.active_index = 0
	    stylized_mesh_bake.bake_items.clear()
	    stylized_mesh_bake.bake_items.new('GEOMETRY', "Geometry")
	    stylized_mesh_bake.bake_items[0].attribute_domain = 'POINT'
	    stylized_mesh_bake.inputs[1].hide = True
	    stylized_mesh_bake.outputs[1].hide = True
	
	    #node Resample Curve.001
	    resample_curve_001 = stylized_meshify_hair.nodes.new("GeometryNodeResampleCurve")
	    resample_curve_001.name = "Resample Curve.001"
	    resample_curve_001.hide = True
	    resample_curve_001.keep_last_segment = True
	    resample_curve_001.mode = 'COUNT'
	    resample_curve_001.inputs[1].hide = True
	    resample_curve_001.inputs[3].hide = True
	    #Selection
	    resample_curve_001.inputs[1].default_value = True
	
	    #node Group Input.001
	    group_input_001_4 = stylized_meshify_hair.nodes.new("NodeGroupInput")
	    group_input_001_4.name = "Group Input.001"
	    group_input_001_4.outputs[0].hide = True
	    group_input_001_4.outputs[1].hide = True
	    group_input_001_4.outputs[2].hide = True
	    group_input_001_4.outputs[4].hide = True
	    group_input_001_4.outputs[5].hide = True
	    group_input_001_4.outputs[6].hide = True
	    group_input_001_4.outputs[7].hide = True
	    group_input_001_4.outputs[8].hide = True
	    group_input_001_4.outputs[9].hide = True
	    group_input_001_4.outputs[10].hide = True
	    group_input_001_4.outputs[11].hide = True
	    group_input_001_4.outputs[12].hide = True
	    group_input_001_4.outputs[13].hide = True
	    group_input_001_4.outputs[14].hide = True
	
	    #node Switch
	    switch_2 = stylized_meshify_hair.nodes.new("GeometryNodeSwitch")
	    switch_2.name = "Switch"
	    switch_2.hide = True
	    switch_2.input_type = 'GEOMETRY'
	
	    #node Compare.001
	    compare_001_3 = stylized_meshify_hair.nodes.new("FunctionNodeCompare")
	    compare_001_3.name = "Compare.001"
	    compare_001_3.hide = True
	    compare_001_3.data_type = 'INT'
	    compare_001_3.mode = 'ELEMENT'
	    compare_001_3.operation = 'GREATER_EQUAL'
	    compare_001_3.inputs[0].hide = True
	    compare_001_3.inputs[1].hide = True
	    compare_001_3.inputs[3].hide = True
	    compare_001_3.inputs[4].hide = True
	    compare_001_3.inputs[5].hide = True
	    compare_001_3.inputs[6].hide = True
	    compare_001_3.inputs[7].hide = True
	    compare_001_3.inputs[8].hide = True
	    compare_001_3.inputs[9].hide = True
	    compare_001_3.inputs[10].hide = True
	    compare_001_3.inputs[11].hide = True
	    compare_001_3.inputs[12].hide = True
	    #B_INT
	    compare_001_3.inputs[3].default_value = 2
	
	
	    #Process zone input Repeat Input
	    repeat_input_1.pair_with_output(repeat_output_1)
	    #Item_2
	    repeat_input_1.inputs[2].default_value = 0
	
	
	
	
	
	    #Set locations
	    group_input_6.location = (-340.0, 0.0)
	    group_output_8.location = (1549.6400146484375, -34.82880401611328)
	    named_attribute_2.location = (237.794921875, -204.86949157714844)
	    compare_3.location = (237.99490356445312, -171.7650146484375)
	    separate_geometry.location = (434.56829833984375, -276.72552490234375)
	    attribute_statistic_001.location = (-71.79378509521484, -31.660974502563477)
	    repeat_input_1.location = (99.01121520996094, -41.19667053222656)
	    repeat_output_1.location = (1002.779296875, -61.759864807128906)
	    join_geometry_001.location = (823.139892578125, -84.95603942871094)
	    math_2.location = (834.5255126953125, -123.60336303710938)
	    math_001_1.location = (-73.19247436523438, -64.9359130859375)
	    named_attribute_003.location = (-71.07884216308594, 117.17273712158203)
	    reroute_001_3.location = (-154.91433715820312, -33.560951232910156)
	    reroute_002_1.location = (-149.08628845214844, -411.6916198730469)
	    set_material.location = (1374.4747314453125, -35.82680130004883)
	    group_input_008_1.location = (1367.4078369140625, -138.275390625)
	    group_input_010.location = (433.3647766113281, -466.8764953613281)
	    group_input_005_2.location = (431.66448974609375, -405.8486022949219)
	    reroute_010_2.location = (823.3209228515625, -266.45831298828125)
	    group_007.location = (646.2728881835938, -232.4287109375)
	    stylized_mesh_bake.location = (1187.839111328125, -13.576586723327637)
	    resample_curve_001.location = (-90.34358215332031, -409.5655517578125)
	    group_input_001_4.location = (-86.76141357421875, -258.945556640625)
	    switch_2.location = (-86.4659423828125, -359.3800048828125)
	    compare_001_3.location = (-88.06952667236328, -323.3353271484375)
	
	    #Set dimensions
	    group_input_6.width, group_input_6.height = 140.0, 100.0
	    group_output_8.width, group_output_8.height = 140.0, 100.0
	    named_attribute_2.width, named_attribute_2.height = 140.0, 100.0
	    compare_3.width, compare_3.height = 140.0, 100.0
	    separate_geometry.width, separate_geometry.height = 140.0, 100.0
	    attribute_statistic_001.width, attribute_statistic_001.height = 140.0, 100.0
	    repeat_input_1.width, repeat_input_1.height = 140.0, 100.0
	    repeat_output_1.width, repeat_output_1.height = 140.0, 100.0
	    join_geometry_001.width, join_geometry_001.height = 140.0, 100.0
	    math_2.width, math_2.height = 140.0, 100.0
	    math_001_1.width, math_001_1.height = 140.0, 100.0
	    named_attribute_003.width, named_attribute_003.height = 140.0, 100.0
	    reroute_001_3.width, reroute_001_3.height = 10.0, 100.0
	    reroute_002_1.width, reroute_002_1.height = 10.0, 100.0
	    set_material.width, set_material.height = 140.0, 100.0
	    group_input_008_1.width, group_input_008_1.height = 140.0, 100.0
	    group_input_010.width, group_input_010.height = 140.0, 100.0
	    group_input_005_2.width, group_input_005_2.height = 140.0, 100.0
	    reroute_010_2.width, reroute_010_2.height = 10.0, 100.0
	    group_007.width, group_007.height = 140.0, 100.0
	    stylized_mesh_bake.width, stylized_mesh_bake.height = 140.0, 100.0
	    resample_curve_001.width, resample_curve_001.height = 140.0, 100.0
	    group_input_001_4.width, group_input_001_4.height = 140.0, 100.0
	    switch_2.width, switch_2.height = 140.0, 100.0
	    compare_001_3.width, compare_001_3.height = 140.0, 100.0
	
	    #initialize stylized_meshify_hair links
	    #named_attribute_2.Attribute -> compare_3.A
	    stylized_meshify_hair.links.new(named_attribute_2.outputs[0], compare_3.inputs[2])
	    #compare_3.Result -> separate_geometry.Selection
	    stylized_meshify_hair.links.new(compare_3.outputs[0], separate_geometry.inputs[1])
	    #join_geometry_001.Geometry -> repeat_output_1.Geometry
	    stylized_meshify_hair.links.new(join_geometry_001.outputs[0], repeat_output_1.inputs[0])
	    #math_2.Value -> repeat_output_1.Index
	    stylized_meshify_hair.links.new(math_2.outputs[0], repeat_output_1.inputs[1])
	    #repeat_input_1.Index -> math_2.Value
	    stylized_meshify_hair.links.new(repeat_input_1.outputs[2], math_2.inputs[0])
	    #reroute_001_3.Output -> attribute_statistic_001.Geometry
	    stylized_meshify_hair.links.new(reroute_001_3.outputs[0], attribute_statistic_001.inputs[0])
	    #math_001_1.Value -> repeat_input_1.Iterations
	    stylized_meshify_hair.links.new(math_001_1.outputs[0], repeat_input_1.inputs[0])
	    #attribute_statistic_001.Max -> math_001_1.Value
	    stylized_meshify_hair.links.new(attribute_statistic_001.outputs[4], math_001_1.inputs[0])
	    #named_attribute_003.Attribute -> attribute_statistic_001.Attribute
	    stylized_meshify_hair.links.new(named_attribute_003.outputs[0], attribute_statistic_001.inputs[2])
	    #repeat_input_1.Index -> compare_3.B
	    stylized_meshify_hair.links.new(repeat_input_1.outputs[2], compare_3.inputs[3])
	    #group_input_6.Geometry -> reroute_001_3.Input
	    stylized_meshify_hair.links.new(group_input_6.outputs[0], reroute_001_3.inputs[0])
	    #reroute_001_3.Output -> reroute_002_1.Input
	    stylized_meshify_hair.links.new(reroute_001_3.outputs[0], reroute_002_1.inputs[0])
	    #set_material.Geometry -> group_output_8.Geometry
	    stylized_meshify_hair.links.new(set_material.outputs[0], group_output_8.inputs[0])
	    #stylized_mesh_bake.Geometry -> set_material.Geometry
	    stylized_meshify_hair.links.new(stylized_mesh_bake.outputs[0], set_material.inputs[0])
	    #group_input_008_1.Material -> set_material.Material
	    stylized_meshify_hair.links.new(group_input_008_1.outputs[2], set_material.inputs[2])
	    #reroute_010_2.Output -> join_geometry_001.Geometry
	    stylized_meshify_hair.links.new(reroute_010_2.outputs[0], join_geometry_001.inputs[0])
	    #group_007.Geometry -> reroute_010_2.Input
	    stylized_meshify_hair.links.new(group_007.outputs[0], reroute_010_2.inputs[0])
	    #group_input_005_2.Surface -> group_007.Surface
	    stylized_meshify_hair.links.new(group_input_005_2.outputs[1], group_007.inputs[1])
	    #separate_geometry.Selection -> group_007.Geometry
	    stylized_meshify_hair.links.new(separate_geometry.outputs[0], group_007.inputs[0])
	    #repeat_output_1.Geometry -> stylized_mesh_bake.Geometry
	    stylized_meshify_hair.links.new(repeat_output_1.outputs[0], stylized_mesh_bake.inputs[0])
	    #reroute_002_1.Output -> resample_curve_001.Curve
	    stylized_meshify_hair.links.new(reroute_002_1.outputs[0], resample_curve_001.inputs[0])
	    #group_input_001_4.Control Points -> resample_curve_001.Count
	    stylized_meshify_hair.links.new(group_input_001_4.outputs[3], resample_curve_001.inputs[2])
	    #group_input_010.Subdivison Level -> group_007.Level
	    stylized_meshify_hair.links.new(group_input_010.outputs[9], group_007.inputs[7])
	    #group_input_010.Radius -> group_007.Radius
	    stylized_meshify_hair.links.new(group_input_010.outputs[4], group_007.inputs[2])
	    #group_input_010.Use Enhancements -> group_007.Use Enhancements
	    stylized_meshify_hair.links.new(group_input_010.outputs[5], group_007.inputs[3])
	    #group_input_010.Maintain Shape Factor -> group_007.Maintain Shape Factor
	    stylized_meshify_hair.links.new(group_input_010.outputs[6], group_007.inputs[4])
	    #group_input_010.Pin at Parameter -> group_007.Pin at Parameter
	    stylized_meshify_hair.links.new(group_input_010.outputs[7], group_007.inputs[5])
	    #group_input_010.Snap to surface -> group_007.Snap to surface
	    stylized_meshify_hair.links.new(group_input_010.outputs[8], group_007.inputs[6])
	    #group_input_010.Edge Crease -> group_007.Edge Crease
	    stylized_meshify_hair.links.new(group_input_010.outputs[10], group_007.inputs[8])
	    #group_input_010.Vertex Crease -> group_007.Vertex Crease
	    stylized_meshify_hair.links.new(group_input_010.outputs[11], group_007.inputs[9])
	    #group_input_010.Limit Surface -> group_007.Limit Surface
	    stylized_meshify_hair.links.new(group_input_010.outputs[12], group_007.inputs[10])
	    #group_input_010.Distance -> group_007.Distance
	    stylized_meshify_hair.links.new(group_input_010.outputs[13], group_007.inputs[11])
	    #group_input_001_4.Control Points -> compare_001_3.A
	    stylized_meshify_hair.links.new(group_input_001_4.outputs[3], compare_001_3.inputs[2])
	    #compare_001_3.Result -> switch_2.Switch
	    stylized_meshify_hair.links.new(compare_001_3.outputs[0], switch_2.inputs[0])
	    #reroute_002_1.Output -> switch_2.False
	    stylized_meshify_hair.links.new(reroute_002_1.outputs[0], switch_2.inputs[1])
	    #resample_curve_001.Curve -> switch_2.True
	    stylized_meshify_hair.links.new(resample_curve_001.outputs[0], switch_2.inputs[2])
	    #switch_2.Output -> separate_geometry.Geometry
	    stylized_meshify_hair.links.new(switch_2.outputs[0], separate_geometry.inputs[0])
	    #repeat_input_1.Geometry -> join_geometry_001.Geometry
	    stylized_meshify_hair.links.new(repeat_input_1.outputs[1], join_geometry_001.inputs[0])
	    return stylized_meshify_hair
	return stylized_meshify_hair_node_group()

	

	
