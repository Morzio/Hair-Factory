import bpy, mathutils

def node():
	#initialize curve_root node group
	def curve_root_node_group():
	    curve_root = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Curve Root")
	
	    curve_root.color_tag = 'INPUT'
	    curve_root.description = "Reads information about each curve's root point"
	    curve_root.default_group_node_width = 140
	    
	
	
	    #curve_root interface
	    #Socket Root Selection
	    root_selection_socket = curve_root.interface.new_socket(name = "Root Selection", in_out='OUTPUT', socket_type = 'NodeSocketBool')
	    root_selection_socket.default_value = False
	    root_selection_socket.attribute_domain = 'POINT'
	    root_selection_socket.description = "Boolean selection of curve root points"
	
	    #Socket Root Position
	    root_position_socket = curve_root.interface.new_socket(name = "Root Position", in_out='OUTPUT', socket_type = 'NodeSocketVector')
	    root_position_socket.default_value = (0.0, 0.0, 0.0)
	    root_position_socket.min_value = -3.4028234663852886e+38
	    root_position_socket.max_value = 3.4028234663852886e+38
	    root_position_socket.subtype = 'NONE'
	    root_position_socket.attribute_domain = 'CURVE'
	    root_position_socket.description = "Position of the root point of a curve"
	
	    #Socket Root Direction
	    root_direction_socket = curve_root.interface.new_socket(name = "Root Direction", in_out='OUTPUT', socket_type = 'NodeSocketVector')
	    root_direction_socket.default_value = (0.0, 0.0, 0.0)
	    root_direction_socket.min_value = -3.4028234663852886e+38
	    root_direction_socket.max_value = 3.4028234663852886e+38
	    root_direction_socket.subtype = 'NONE'
	    root_direction_socket.attribute_domain = 'CURVE'
	    root_direction_socket.description = "Direction of the root segment of a curve"
	
	    #Socket Root Index
	    root_index_socket = curve_root.interface.new_socket(name = "Root Index", in_out='OUTPUT', socket_type = 'NodeSocketInt')
	    root_index_socket.default_value = 0
	    root_index_socket.min_value = -2147483648
	    root_index_socket.max_value = 2147483647
	    root_index_socket.subtype = 'NONE'
	    root_index_socket.attribute_domain = 'CURVE'
	    root_index_socket.description = "Index of the root point of a curve"
	
	
	    #initialize curve_root nodes
	    #node Position.002
	    position_002 = curve_root.nodes.new("GeometryNodeInputPosition")
	    position_002.name = "Position.002"
	
	    #node Interpolate Domain
	    interpolate_domain = curve_root.nodes.new("GeometryNodeFieldOnDomain")
	    interpolate_domain.name = "Interpolate Domain"
	    interpolate_domain.data_type = 'INT'
	    interpolate_domain.domain = 'CURVE'
	
	    #node Field at Index.003
	    field_at_index_003 = curve_root.nodes.new("GeometryNodeFieldAtIndex")
	    field_at_index_003.name = "Field at Index.003"
	    field_at_index_003.data_type = 'FLOAT_VECTOR'
	    field_at_index_003.domain = 'POINT'
	
	    #node Interpolate Domain.001
	    interpolate_domain_001 = curve_root.nodes.new("GeometryNodeFieldOnDomain")
	    interpolate_domain_001.name = "Interpolate Domain.001"
	    interpolate_domain_001.data_type = 'FLOAT_VECTOR'
	    interpolate_domain_001.domain = 'CURVE'
	
	    #node Curve Tangent
	    curve_tangent = curve_root.nodes.new("GeometryNodeInputTangent")
	    curve_tangent.name = "Curve Tangent"
	
	    #node Endpoint Selection
	    endpoint_selection = curve_root.nodes.new("GeometryNodeCurveEndpointSelection")
	    endpoint_selection.name = "Endpoint Selection"
	    #Start Size
	    endpoint_selection.inputs[0].default_value = 1
	    #End Size
	    endpoint_selection.inputs[1].default_value = 0
	
	    #node Field at Index.004
	    field_at_index_004 = curve_root.nodes.new("GeometryNodeFieldAtIndex")
	    field_at_index_004.name = "Field at Index.004"
	    field_at_index_004.data_type = 'FLOAT_VECTOR'
	    field_at_index_004.domain = 'POINT'
	
	    #node Interpolate Domain.002
	    interpolate_domain_002 = curve_root.nodes.new("GeometryNodeFieldOnDomain")
	    interpolate_domain_002.name = "Interpolate Domain.002"
	    interpolate_domain_002.data_type = 'FLOAT_VECTOR'
	    interpolate_domain_002.domain = 'CURVE'
	
	    #node Group Output
	    group_output = curve_root.nodes.new("NodeGroupOutput")
	    group_output.name = "Group Output"
	    group_output.is_active_output = True
	
	    #node Points of Curve
	    points_of_curve = curve_root.nodes.new("GeometryNodePointsOfCurve")
	    points_of_curve.name = "Points of Curve"
	    points_of_curve.inputs[0].hide = True
	    points_of_curve.inputs[1].hide = True
	    points_of_curve.outputs[1].hide = True
	    #Curve Index
	    points_of_curve.inputs[0].default_value = 0
	    #Weights
	    points_of_curve.inputs[1].default_value = 0.0
	    #Sort Index
	    points_of_curve.inputs[2].default_value = 0
	
	
	
	
	
	    #Set locations
	    position_002.location = (-608.1627807617188, -70.55814361572266)
	    interpolate_domain.location = (-608.1627807617188, 90.18604278564453)
	    field_at_index_003.location = (-407.2325439453125, 70.09302520751953)
	    interpolate_domain_001.location = (-206.30230712890625, 70.09302520751953)
	    curve_tangent.location = (-608.1627807617188, -271.4883728027344)
	    endpoint_selection.location = (-206.30230712890625, 190.65118408203125)
	    field_at_index_004.location = (-407.2325439453125, -130.83721923828125)
	    interpolate_domain_002.location = (-206.30230712890625, -130.83721923828125)
	    group_output.location = (75.0, 50.0)
	    points_of_curve.location = (-789.0, 50.0)
	
	    #Set dimensions
	    position_002.width, position_002.height = 140.0, 100.0
	    interpolate_domain.width, interpolate_domain.height = 140.0, 100.0
	    field_at_index_003.width, field_at_index_003.height = 140.0, 100.0
	    interpolate_domain_001.width, interpolate_domain_001.height = 140.0, 100.0
	    curve_tangent.width, curve_tangent.height = 140.0, 100.0
	    endpoint_selection.width, endpoint_selection.height = 140.0, 100.0
	    field_at_index_004.width, field_at_index_004.height = 140.0, 100.0
	    interpolate_domain_002.width, interpolate_domain_002.height = 140.0, 100.0
	    group_output.width, group_output.height = 140.0, 100.0
	    points_of_curve.width, points_of_curve.height = 140.0, 100.0
	
	    #initialize curve_root links
	    #position_002.Position -> field_at_index_003.Value
	    curve_root.links.new(position_002.outputs[0], field_at_index_003.inputs[1])
	    #interpolate_domain_001.Value -> group_output.Root Position
	    curve_root.links.new(interpolate_domain_001.outputs[0], group_output.inputs[1])
	    #interpolate_domain.Value -> field_at_index_003.Index
	    curve_root.links.new(interpolate_domain.outputs[0], field_at_index_003.inputs[0])
	    #points_of_curve.Point Index -> interpolate_domain.Value
	    curve_root.links.new(points_of_curve.outputs[0], interpolate_domain.inputs[0])
	    #interpolate_domain.Value -> group_output.Root Index
	    curve_root.links.new(interpolate_domain.outputs[0], group_output.inputs[3])
	    #endpoint_selection.Selection -> group_output.Root Selection
	    curve_root.links.new(endpoint_selection.outputs[0], group_output.inputs[0])
	    #field_at_index_003.Value -> interpolate_domain_001.Value
	    curve_root.links.new(field_at_index_003.outputs[0], interpolate_domain_001.inputs[0])
	    #interpolate_domain_002.Value -> group_output.Root Direction
	    curve_root.links.new(interpolate_domain_002.outputs[0], group_output.inputs[2])
	    #interpolate_domain.Value -> field_at_index_004.Index
	    curve_root.links.new(interpolate_domain.outputs[0], field_at_index_004.inputs[0])
	    #curve_tangent.Tangent -> field_at_index_004.Value
	    curve_root.links.new(curve_tangent.outputs[0], field_at_index_004.inputs[1])
	    #field_at_index_004.Value -> interpolate_domain_002.Value
	    curve_root.links.new(field_at_index_004.outputs[0], interpolate_domain_002.inputs[0])
	    return curve_root
	
	curve_root = curve_root_node_group()
	
	#initialize hair_fade node group
	def hair_fade_node_group():
	    hair_fade = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "HAIR_FADE")
	
	    hair_fade.color_tag = 'NONE'
	    hair_fade.description = "Fade hair below gizmo z position."
	    hair_fade.default_group_node_width = 140
	    
	
	    hair_fade.is_modifier = True
	
	    #hair_fade interface
	    #Socket Geometry
	    geometry_socket = hair_fade.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket.attribute_domain = 'POINT'
	    geometry_socket.description = "Modified Hair."
	
	    #Socket Geometry
	    geometry_socket_1 = hair_fade.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_1.attribute_domain = 'POINT'
	    geometry_socket_1.description = "Hair Curve."
	
	    #Socket Length Control
	    length_control_socket = hair_fade.interface.new_socket(name = "Length Control", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    length_control_socket.default_value = 1.0
	    length_control_socket.min_value = 0.0
	    length_control_socket.max_value = 1.0
	    length_control_socket.subtype = 'FACTOR'
	    length_control_socket.attribute_domain = 'POINT'
	    length_control_socket.description = "Overall hair length factor."
	
	    #Socket Fade Level
	    fade_level_socket = hair_fade.interface.new_socket(name = "Fade Level", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    fade_level_socket.default_value = 0.0
	    fade_level_socket.min_value = -10000.0
	    fade_level_socket.max_value = 10000.0
	    fade_level_socket.subtype = 'NONE'
	    fade_level_socket.attribute_domain = 'POINT'
	    fade_level_socket.description = "Control the height of the fade."
	
	
	    #initialize hair_fade nodes
	    #node Group Input
	    group_input = hair_fade.nodes.new("NodeGroupInput")
	    group_input.name = "Group Input"
	    group_input.outputs[2].hide = True
	    group_input.outputs[3].hide = True
	
	    #node Group Output
	    group_output_1 = hair_fade.nodes.new("NodeGroupOutput")
	    group_output_1.name = "Group Output"
	    group_output_1.is_active_output = True
	    group_output_1.inputs[1].hide = True
	
	    #node Trim Curve
	    trim_curve = hair_fade.nodes.new("GeometryNodeTrimCurve")
	    trim_curve.name = "Trim Curve"
	    trim_curve.mode = 'FACTOR'
	    trim_curve.inputs[1].hide = True
	    trim_curve.inputs[2].hide = True
	    trim_curve.inputs[4].hide = True
	    trim_curve.inputs[5].hide = True
	    #Selection
	    trim_curve.inputs[1].default_value = True
	    #Start
	    trim_curve.inputs[2].default_value = 0.0
	
	    #node Trim Curve.001
	    trim_curve_001 = hair_fade.nodes.new("GeometryNodeTrimCurve")
	    trim_curve_001.name = "Trim Curve.001"
	    trim_curve_001.mode = 'LENGTH'
	    trim_curve_001.inputs[2].hide = True
	    trim_curve_001.inputs[3].hide = True
	    trim_curve_001.inputs[4].hide = True
	    #Start_001
	    trim_curve_001.inputs[4].default_value = 0.0
	
	    #node Group
	    group = hair_fade.nodes.new("GeometryNodeGroup")
	    group.name = "Group"
	    group.node_tree = curve_root
	    group.outputs[0].hide = True
	    group.outputs[2].hide = True
	    group.outputs[3].hide = True
	
	    #node Separate XYZ
	    separate_xyz = hair_fade.nodes.new("ShaderNodeSeparateXYZ")
	    separate_xyz.name = "Separate XYZ"
	    separate_xyz.outputs[0].hide = True
	    separate_xyz.outputs[1].hide = True
	
	    #node Compare
	    compare = hair_fade.nodes.new("FunctionNodeCompare")
	    compare.name = "Compare"
	    compare.hide = True
	    compare.data_type = 'FLOAT'
	    compare.mode = 'ELEMENT'
	    compare.operation = 'LESS_THAN'
	
	    #node Math
	    math = hair_fade.nodes.new("ShaderNodeMath")
	    math.name = "Math"
	    math.hide = True
	    math.operation = 'SUBTRACT'
	    math.use_clamp = False
	
	    #node Math.001
	    math_001 = hair_fade.nodes.new("ShaderNodeMath")
	    math_001.name = "Math.001"
	    math_001.hide = True
	    math_001.operation = 'ABSOLUTE'
	    math_001.use_clamp = False
	
	    #node Attribute Statistic
	    attribute_statistic = hair_fade.nodes.new("GeometryNodeAttributeStatistic")
	    attribute_statistic.name = "Attribute Statistic"
	    attribute_statistic.data_type = 'FLOAT'
	    attribute_statistic.domain = 'POINT'
	    attribute_statistic.inputs[1].hide = True
	    attribute_statistic.outputs[0].hide = True
	    attribute_statistic.outputs[1].hide = True
	    attribute_statistic.outputs[2].hide = True
	    attribute_statistic.outputs[4].hide = True
	    attribute_statistic.outputs[5].hide = True
	    attribute_statistic.outputs[6].hide = True
	    attribute_statistic.outputs[7].hide = True
	    #Selection
	    attribute_statistic.inputs[1].default_value = True
	
	    #node Math.002
	    math_002 = hair_fade.nodes.new("ShaderNodeMath")
	    math_002.name = "Math.002"
	    math_002.hide = True
	    math_002.operation = 'SUBTRACT'
	    math_002.use_clamp = False
	
	    #node Math.003
	    math_003 = hair_fade.nodes.new("ShaderNodeMath")
	    math_003.name = "Math.003"
	    math_003.hide = True
	    math_003.operation = 'ABSOLUTE'
	    math_003.use_clamp = False
	
	    #node Math.004
	    math_004 = hair_fade.nodes.new("ShaderNodeMath")
	    math_004.name = "Math.004"
	    math_004.hide = True
	    math_004.operation = 'DIVIDE'
	    math_004.use_clamp = False
	
	    #node Frame
	    frame = hair_fade.nodes.new("NodeFrame")
	    frame.label = "Max Distance"
	    frame.name = "Frame"
	    frame.label_size = 20
	    frame.shrink = True
	
	    #node Frame.001
	    frame_001 = hair_fade.nodes.new("NodeFrame")
	    frame_001.label = "Selection"
	    frame_001.name = "Frame.001"
	    frame_001.label_size = 20
	    frame_001.shrink = True
	
	    #node Frame.002
	    frame_002 = hair_fade.nodes.new("NodeFrame")
	    frame_002.label = "Root Distance"
	    frame_002.name = "Frame.002"
	    frame_002.label_size = 20
	    frame_002.shrink = True
	
	    #node Linear Gizmo
	    linear_gizmo = hair_fade.nodes.new("GeometryNodeGizmoLinear")
	    linear_gizmo.name = "Linear Gizmo"
	    linear_gizmo.color_id = 'PRIMARY'
	    linear_gizmo.draw_style = 'ARROW'
	    linear_gizmo.inputs[2].hide = True
	    linear_gizmo.outputs[0].hide = True
	    #Direction
	    linear_gizmo.inputs[2].default_value = (0.0, 0.0, 1.0)
	
	    #node Math.005
	    math_005 = hair_fade.nodes.new("ShaderNodeMath")
	    math_005.name = "Math.005"
	    math_005.hide = True
	    math_005.operation = 'SUBTRACT'
	    math_005.use_clamp = False
	    math_005.inputs[0].hide = True
	    math_005.inputs[2].hide = True
	    #Value
	    math_005.inputs[0].default_value = 1.0
	
	    #node Spline Length
	    spline_length = hair_fade.nodes.new("GeometryNodeSplineLength")
	    spline_length.name = "Spline Length"
	    spline_length.outputs[1].hide = True
	
	    #node Math.006
	    math_006 = hair_fade.nodes.new("ShaderNodeMath")
	    math_006.name = "Math.006"
	    math_006.hide = True
	    math_006.operation = 'MULTIPLY'
	    math_006.use_clamp = False
	
	    #node Trim Shape
	    trim_shape = hair_fade.nodes.new("ShaderNodeFloatCurve")
	    trim_shape.label = "Trim Shape"
	    trim_shape.name = "Trim Shape"
	    #mapping settings
	    trim_shape.mapping.extend = 'EXTRAPOLATED'
	    trim_shape.mapping.tone = 'STANDARD'
	    trim_shape.mapping.black_level = (0.0, 0.0, 0.0)
	    trim_shape.mapping.white_level = (1.0, 1.0, 1.0)
	    trim_shape.mapping.clip_min_x = 0.0
	    trim_shape.mapping.clip_min_y = 0.0
	    trim_shape.mapping.clip_max_x = 1.0
	    trim_shape.mapping.clip_max_y = 1.0
	    trim_shape.mapping.use_clip = True
	    #curve 0
	    trim_shape_curve_0 = trim_shape.mapping.curves[0]
	    trim_shape_curve_0_point_0 = trim_shape_curve_0.points[0]
	    trim_shape_curve_0_point_0.location = (0.0, 0.0)
	    trim_shape_curve_0_point_0.handle_type = 'AUTO'
	    trim_shape_curve_0_point_1 = trim_shape_curve_0.points[1]
	    trim_shape_curve_0_point_1.location = (1.0, 1.0)
	    trim_shape_curve_0_point_1.handle_type = 'AUTO'
	    #update curve after changes
	    trim_shape.mapping.update()
	    trim_shape.inputs[0].hide = True
	    #Factor
	    trim_shape.inputs[0].default_value = 1.0
	
	    #node Combine XYZ
	    combine_xyz = hair_fade.nodes.new("ShaderNodeCombineXYZ")
	    combine_xyz.name = "Combine XYZ"
	    combine_xyz.inputs[0].hide = True
	    combine_xyz.inputs[1].hide = True
	    #X
	    combine_xyz.inputs[0].default_value = 0.0
	    #Y
	    combine_xyz.inputs[1].default_value = 0.0
	
	    #node Group Input.002
	    group_input_002 = hair_fade.nodes.new("NodeGroupInput")
	    group_input_002.name = "Group Input.002"
	    group_input_002.outputs[0].hide = True
	    group_input_002.outputs[1].hide = True
	    group_input_002.outputs[3].hide = True
	
	    #node Group Input.003
	    group_input_003 = hair_fade.nodes.new("NodeGroupInput")
	    group_input_003.name = "Group Input.003"
	    group_input_003.outputs[0].hide = True
	    group_input_003.outputs[1].hide = True
	    group_input_003.outputs[3].hide = True
	
	    #node Frame.003
	    frame_003 = hair_fade.nodes.new("NodeFrame")
	    frame_003.label = "Gizmo"
	    frame_003.name = "Frame.003"
	    frame_003.label_size = 20
	    frame_003.shrink = True
	
	    #node Group Input.004
	    group_input_004 = hair_fade.nodes.new("NodeGroupInput")
	    group_input_004.name = "Group Input.004"
	    group_input_004.outputs[0].hide = True
	    group_input_004.outputs[1].hide = True
	    group_input_004.outputs[3].hide = True
	
	    #node Group Input.005
	    group_input_005 = hair_fade.nodes.new("NodeGroupInput")
	    group_input_005.name = "Group Input.005"
	    group_input_005.outputs[1].hide = True
	    group_input_005.outputs[3].hide = True
	
	    #node Frame.004
	    frame_004 = hair_fade.nodes.new("NodeFrame")
	    frame_004.label = "Trim Factor"
	    frame_004.name = "Frame.004"
	    frame_004.label_size = 20
	    frame_004.shrink = True
	
	    #node Reroute
	    reroute = hair_fade.nodes.new("NodeReroute")
	    reroute.name = "Reroute"
	    reroute.socket_idname = "NodeSocketBool"
	    #node Reroute.001
	    reroute_001 = hair_fade.nodes.new("NodeReroute")
	    reroute_001.name = "Reroute.001"
	    reroute_001.socket_idname = "NodeSocketBool"
	    #node Reroute.002
	    reroute_002 = hair_fade.nodes.new("NodeReroute")
	    reroute_002.name = "Reroute.002"
	    reroute_002.socket_idname = "NodeSocketBool"
	    #node Reroute.003
	    reroute_003 = hair_fade.nodes.new("NodeReroute")
	    reroute_003.name = "Reroute.003"
	    reroute_003.socket_idname = "NodeSocketBool"
	    #node Reroute.004
	    reroute_004 = hair_fade.nodes.new("NodeReroute")
	    reroute_004.name = "Reroute.004"
	    reroute_004.socket_idname = "NodeSocketFloat"
	    #node Hair Fade Bake
	    hair_fade_bake = hair_fade.nodes.new("GeometryNodeBake")
	    hair_fade_bake.label = "Hair Fade Bake"
	    hair_fade_bake.name = "Hair Fade Bake"
	    hair_fade_bake.active_index = 0
	    hair_fade_bake.bake_items.clear()
	    hair_fade_bake.bake_items.new('GEOMETRY', "Geometry")
	    hair_fade_bake.bake_items[0].attribute_domain = 'POINT'
	    hair_fade_bake.inputs[1].hide = True
	    hair_fade_bake.outputs[1].hide = True
	
	    #node Separate Components
	    separate_components = hair_fade.nodes.new("GeometryNodeSeparateComponents")
	    separate_components.name = "Separate Components"
	    separate_components.hide = True
	
	    #node Join Geometry
	    join_geometry = hair_fade.nodes.new("GeometryNodeJoinGeometry")
	    join_geometry.name = "Join Geometry"
	
	    #node Reroute.005
	    reroute_005 = hair_fade.nodes.new("NodeReroute")
	    reroute_005.name = "Reroute.005"
	    reroute_005.socket_idname = "NodeSocketGeometry"
	    #node Reroute.006
	    reroute_006 = hair_fade.nodes.new("NodeReroute")
	    reroute_006.name = "Reroute.006"
	    reroute_006.socket_idname = "NodeSocketGeometry"
	    #node Reroute.007
	    reroute_007 = hair_fade.nodes.new("NodeReroute")
	    reroute_007.name = "Reroute.007"
	    reroute_007.socket_idname = "NodeSocketGeometry"
	    #node Reroute.008
	    reroute_008 = hair_fade.nodes.new("NodeReroute")
	    reroute_008.name = "Reroute.008"
	    reroute_008.socket_idname = "NodeSocketGeometry"
	    #node Reroute.009
	    reroute_009 = hair_fade.nodes.new("NodeReroute")
	    reroute_009.name = "Reroute.009"
	    reroute_009.socket_idname = "NodeSocketGeometry"
	    #node Reroute.010
	    reroute_010 = hair_fade.nodes.new("NodeReroute")
	    reroute_010.name = "Reroute.010"
	    reroute_010.socket_idname = "NodeSocketGeometry"
	    #node Reroute.011
	    reroute_011 = hair_fade.nodes.new("NodeReroute")
	    reroute_011.name = "Reroute.011"
	    reroute_011.socket_idname = "NodeSocketGeometry"
	    #node Reroute.012
	    reroute_012 = hair_fade.nodes.new("NodeReroute")
	    reroute_012.name = "Reroute.012"
	    reroute_012.socket_idname = "NodeSocketGeometry"
	    #node Reroute.013
	    reroute_013 = hair_fade.nodes.new("NodeReroute")
	    reroute_013.name = "Reroute.013"
	    reroute_013.socket_idname = "NodeSocketGeometry"
	    #node Reroute.014
	    reroute_014 = hair_fade.nodes.new("NodeReroute")
	    reroute_014.name = "Reroute.014"
	    reroute_014.socket_idname = "NodeSocketGeometry"
	
	
	
	    #Set parents
	    separate_xyz.parent = frame_001
	    compare.parent = frame_001
	    math.parent = frame_002
	    math_001.parent = frame_002
	    math_002.parent = frame
	    math_003.parent = frame
	    linear_gizmo.parent = frame_003
	    math_005.parent = frame_004
	    spline_length.parent = frame_004
	    math_006.parent = frame_004
	    combine_xyz.parent = frame_003
	    group_input_002.parent = frame_003
	    reroute.parent = frame_001
	
	    #Set locations
	    group_input.location = (-340.0, 0.0)
	    group_output_1.location = (1739.11474609375, 120.23137664794922)
	    trim_curve.location = (-155.6723175048828, 48.863624572753906)
	    trim_curve_001.location = (1170.3863525390625, 95.86663818359375)
	    group.location = (-341.8908386230469, -343.92572021484375)
	    separate_xyz.location = (29.7142333984375, -40.14556884765625)
	    compare.location = (31.55181884765625, -128.43704223632812)
	    math.location = (30.74048614501953, -45.20567321777344)
	    math_001.location = (30.18018341064453, -80.60867309570312)
	    attribute_statistic.location = (107.27552032470703, -331.1513366699219)
	    math_002.location = (30.173431396484375, -44.53631591796875)
	    math_003.location = (31.41766357421875, -82.64785766601562)
	    math_004.location = (940.6304321289062, -412.1468200683594)
	    frame.location = (308.0, -337.0)
	    frame_001.location = (-169.0, -303.0)
	    frame_002.location = (70.0, -71.0)
	    linear_gizmo.location = (216.6988525390625, -39.5755615234375)
	    math_005.location = (29.9805908203125, -45.15364074707031)
	    spline_length.location = (31.04241943359375, -114.68858337402344)
	    math_006.location = (31.2938232421875, -82.10614013671875)
	    trim_shape.location = (649.426513671875, -142.4562530517578)
	    combine_xyz.location = (215.4642333984375, -170.11785888671875)
	    group_input_002.location = (30.3848876953125, -150.13677978515625)
	    group_input_003.location = (-155.02728271484375, -83.51127624511719)
	    frame_003.location = (1237.0, -236.0)
	    group_input_004.location = (-340.0, -426.57745361328125)
	    group_input_005.location = (103.9359359741211, -247.82127380371094)
	    frame_004.location = (306.0, -109.0)
	    reroute.location = (189.10812377929688, -138.39047241210938)
	    reroute_001.location = (22.00933837890625, -512.5830078125)
	    reroute_002.location = (1141.2362060546875, -515.4864501953125)
	    reroute_003.location = (1131.832763671875, -10.525741577148438)
	    reroute_004.location = (1075.4932861328125, -33.87214660644531)
	    hair_fade_bake.location = (1558.999755859375, 165.83641052246094)
	    separate_components.location = (-337.2942810058594, 44.87547302246094)
	    join_geometry.location = (1391.982421875, 119.50184631347656)
	    reroute_005.location = (-117.681640625, 259.8385314941406)
	    reroute_006.location = (-117.681640625, 254.57723999023438)
	    reroute_007.location = (-117.681640625, 244.56687927246094)
	    reroute_008.location = (-117.681640625, 249.53085327148438)
	    reroute_009.location = (-117.681640625, 239.6898193359375)
	    reroute_010.location = (1287.9300537109375, 245.99391174316406)
	    reroute_011.location = (1288.3916015625, 240.99485778808594)
	    reroute_012.location = (1284.247802734375, 260.9920349121094)
	    reroute_013.location = (1285.629150390625, 255.99166870117188)
	    reroute_014.location = (1286.264892578125, 250.9920654296875)
	
	    #Set dimensions
	    group_input.width, group_input.height = 140.0, 100.0
	    group_output_1.width, group_output_1.height = 140.0, 100.0
	    trim_curve.width, trim_curve.height = 140.0, 100.0
	    trim_curve_001.width, trim_curve_001.height = 140.0, 100.0
	    group.width, group.height = 140.0, 100.0
	    separate_xyz.width, separate_xyz.height = 140.0, 100.0
	    compare.width, compare.height = 140.0, 100.0
	    math.width, math.height = 140.0, 100.0
	    math_001.width, math_001.height = 140.0, 100.0
	    attribute_statistic.width, attribute_statistic.height = 140.0, 100.0
	    math_002.width, math_002.height = 140.0, 100.0
	    math_003.width, math_003.height = 140.0, 100.0
	    math_004.width, math_004.height = 140.0, 100.0
	    frame.width, frame.height = 201.0, 138.0
	    frame_001.width, frame_001.height = 224.10812377929688, 183.0
	    frame_002.width, frame_002.height = 201.0, 136.0
	    linear_gizmo.width, linear_gizmo.height = 140.0, 100.0
	    math_005.width, math_005.height = 140.0, 100.0
	    spline_length.width, spline_length.height = 140.0, 100.0
	    math_006.width, math_006.height = 140.0, 100.0
	    trim_shape.width, trim_shape.height = 240.0, 100.0
	    combine_xyz.width, combine_xyz.height = 140.0, 100.0
	    group_input_002.width, group_input_002.height = 140.0, 100.0
	    group_input_003.width, group_input_003.height = 140.0, 100.0
	    frame_003.width, frame_003.height = 387.0, 275.0
	    group_input_004.width, group_input_004.height = 140.0, 100.0
	    group_input_005.width, group_input_005.height = 140.0, 100.0
	    frame_004.width, frame_004.height = 201.0, 197.0
	    reroute.width, reroute.height = 10.0, 100.0
	    reroute_001.width, reroute_001.height = 10.0, 100.0
	    reroute_002.width, reroute_002.height = 10.0, 100.0
	    reroute_003.width, reroute_003.height = 10.0, 100.0
	    reroute_004.width, reroute_004.height = 10.0, 100.0
	    hair_fade_bake.width, hair_fade_bake.height = 140.0, 100.0
	    separate_components.width, separate_components.height = 140.0, 100.0
	    join_geometry.width, join_geometry.height = 140.0, 100.0
	    reroute_005.width, reroute_005.height = 10.0, 100.0
	    reroute_006.width, reroute_006.height = 10.0, 100.0
	    reroute_007.width, reroute_007.height = 10.0, 100.0
	    reroute_008.width, reroute_008.height = 10.0, 100.0
	    reroute_009.width, reroute_009.height = 10.0, 100.0
	    reroute_010.width, reroute_010.height = 10.0, 100.0
	    reroute_011.width, reroute_011.height = 10.0, 100.0
	    reroute_012.width, reroute_012.height = 10.0, 100.0
	    reroute_013.width, reroute_013.height = 10.0, 100.0
	    reroute_014.width, reroute_014.height = 10.0, 100.0
	
	    #initialize hair_fade links
	    #group.Root Position -> separate_xyz.Vector
	    hair_fade.links.new(group.outputs[1], separate_xyz.inputs[0])
	    #separate_xyz.Z -> compare.A
	    hair_fade.links.new(separate_xyz.outputs[2], compare.inputs[0])
	    #reroute_003.Output -> trim_curve_001.Selection
	    hair_fade.links.new(reroute_003.outputs[0], trim_curve_001.inputs[1])
	    #trim_curve.Curve -> trim_curve_001.Curve
	    hair_fade.links.new(trim_curve.outputs[0], trim_curve_001.inputs[0])
	    #hair_fade_bake.Geometry -> group_output_1.Geometry
	    hair_fade.links.new(hair_fade_bake.outputs[0], group_output_1.inputs[0])
	    #separate_xyz.Z -> math.Value
	    hair_fade.links.new(separate_xyz.outputs[2], math.inputs[1])
	    #math.Value -> math_001.Value
	    hair_fade.links.new(math.outputs[0], math_001.inputs[0])
	    #separate_xyz.Z -> attribute_statistic.Attribute
	    hair_fade.links.new(separate_xyz.outputs[2], attribute_statistic.inputs[2])
	    #math_002.Value -> math_003.Value
	    hair_fade.links.new(math_002.outputs[0], math_003.inputs[0])
	    #attribute_statistic.Min -> math_002.Value
	    hair_fade.links.new(attribute_statistic.outputs[3], math_002.inputs[1])
	    #reroute_004.Output -> trim_curve_001.End
	    hair_fade.links.new(reroute_004.outputs[0], trim_curve_001.inputs[5])
	    #group_input.Length Control -> trim_curve.End
	    hair_fade.links.new(group_input.outputs[1], trim_curve.inputs[3])
	    #math_003.Value -> math_004.Value
	    hair_fade.links.new(math_003.outputs[0], math_004.inputs[1])
	    #math_001.Value -> math_005.Value
	    hair_fade.links.new(math_001.outputs[0], math_005.inputs[1])
	    #math_005.Value -> math_006.Value
	    hair_fade.links.new(math_005.outputs[0], math_006.inputs[0])
	    #spline_length.Length -> math_006.Value
	    hair_fade.links.new(spline_length.outputs[0], math_006.inputs[1])
	    #math_006.Value -> trim_shape.Value
	    hair_fade.links.new(math_006.outputs[0], trim_shape.inputs[1])
	    #trim_shape.Value -> math_004.Value
	    hair_fade.links.new(trim_shape.outputs[0], math_004.inputs[0])
	    #combine_xyz.Vector -> linear_gizmo.Position
	    hair_fade.links.new(combine_xyz.outputs[0], linear_gizmo.inputs[1])
	    #group_input_002.Fade Level -> combine_xyz.Z
	    hair_fade.links.new(group_input_002.outputs[2], combine_xyz.inputs[2])
	    #group_input_002.Fade Level -> linear_gizmo.Value
	    hair_fade.links.new(group_input_002.outputs[2], linear_gizmo.inputs[0])
	    #group_input_003.Fade Level -> math.Value
	    hair_fade.links.new(group_input_003.outputs[2], math.inputs[0])
	    #group_input_004.Fade Level -> compare.B
	    hair_fade.links.new(group_input_004.outputs[2], compare.inputs[1])
	    #group_input_005.Fade Level -> math_002.Value
	    hair_fade.links.new(group_input_005.outputs[2], math_002.inputs[0])
	    #compare.Result -> reroute.Input
	    hair_fade.links.new(compare.outputs[0], reroute.inputs[0])
	    #reroute.Output -> reroute_001.Input
	    hair_fade.links.new(reroute.outputs[0], reroute_001.inputs[0])
	    #reroute_001.Output -> reroute_002.Input
	    hair_fade.links.new(reroute_001.outputs[0], reroute_002.inputs[0])
	    #reroute_002.Output -> reroute_003.Input
	    hair_fade.links.new(reroute_002.outputs[0], reroute_003.inputs[0])
	    #math_004.Value -> reroute_004.Input
	    hair_fade.links.new(math_004.outputs[0], reroute_004.inputs[0])
	    #group_input_005.Geometry -> attribute_statistic.Geometry
	    hair_fade.links.new(group_input_005.outputs[0], attribute_statistic.inputs[0])
	    #group_input.Geometry -> separate_components.Geometry
	    hair_fade.links.new(group_input.outputs[0], separate_components.inputs[0])
	    #separate_components.Curve -> trim_curve.Curve
	    hair_fade.links.new(separate_components.outputs[1], trim_curve.inputs[0])
	    #reroute_011.Output -> join_geometry.Geometry
	    hair_fade.links.new(reroute_011.outputs[0], join_geometry.inputs[0])
	    #separate_components.Mesh -> reroute_005.Input
	    hair_fade.links.new(separate_components.outputs[0], reroute_005.inputs[0])
	    #separate_components.Grease Pencil -> reroute_006.Input
	    hair_fade.links.new(separate_components.outputs[2], reroute_006.inputs[0])
	    #separate_components.Volume -> reroute_007.Input
	    hair_fade.links.new(separate_components.outputs[4], reroute_007.inputs[0])
	    #separate_components.Point Cloud -> reroute_008.Input
	    hair_fade.links.new(separate_components.outputs[3], reroute_008.inputs[0])
	    #separate_components.Instances -> reroute_009.Input
	    hair_fade.links.new(separate_components.outputs[5], reroute_009.inputs[0])
	    #reroute_007.Output -> reroute_010.Input
	    hair_fade.links.new(reroute_007.outputs[0], reroute_010.inputs[0])
	    #reroute_009.Output -> reroute_011.Input
	    hair_fade.links.new(reroute_009.outputs[0], reroute_011.inputs[0])
	    #reroute_005.Output -> reroute_012.Input
	    hair_fade.links.new(reroute_005.outputs[0], reroute_012.inputs[0])
	    #reroute_006.Output -> reroute_013.Input
	    hair_fade.links.new(reroute_006.outputs[0], reroute_013.inputs[0])
	    #reroute_008.Output -> reroute_014.Input
	    hair_fade.links.new(reroute_008.outputs[0], reroute_014.inputs[0])
	    #join_geometry.Geometry -> hair_fade_bake.Geometry
	    hair_fade.links.new(join_geometry.outputs[0], hair_fade_bake.inputs[0])
	    #reroute_010.Output -> join_geometry.Geometry
	    hair_fade.links.new(reroute_010.outputs[0], join_geometry.inputs[0])
	    #reroute_014.Output -> join_geometry.Geometry
	    hair_fade.links.new(reroute_014.outputs[0], join_geometry.inputs[0])
	    #reroute_013.Output -> join_geometry.Geometry
	    hair_fade.links.new(reroute_013.outputs[0], join_geometry.inputs[0])
	    #reroute_012.Output -> join_geometry.Geometry
	    hair_fade.links.new(reroute_012.outputs[0], join_geometry.inputs[0])
	    #trim_curve_001.Curve -> join_geometry.Geometry
	    hair_fade.links.new(trim_curve_001.outputs[0], join_geometry.inputs[0])
	    return hair_fade
	return hair_fade_node_group()

	

	
