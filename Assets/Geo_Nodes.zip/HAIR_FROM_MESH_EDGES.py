import bpy, mathutils

def node():
	#initialize hair_from_mesh_edges node group
	def hair_from_mesh_edges_node_group():
	    hair_from_mesh_edges = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "HAIR_FROM_MESH_EDGES")
	
	    hair_from_mesh_edges.color_tag = 'NONE'
	    hair_from_mesh_edges.description = "Use Mesh Hair edges to shape hair strands."
	    hair_from_mesh_edges.default_group_node_width = 140
	    
	
	    hair_from_mesh_edges.is_modifier = True
	
	    #hair_from_mesh_edges interface
	    #Socket Geometry
	    geometry_socket = hair_from_mesh_edges.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket.attribute_domain = 'POINT'
	    geometry_socket.description = "New hair curves."
	
	    #Socket Geometry
	    geometry_socket_1 = hair_from_mesh_edges.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_1.attribute_domain = 'POINT'
	    geometry_socket_1.description = "Hair curve with or without points. (Empty hair curve preferred.)"
	
	    #Socket Target Guide
	    target_guide_socket = hair_from_mesh_edges.interface.new_socket(name = "Target Guide", in_out='INPUT', socket_type = 'NodeSocketObject')
	    target_guide_socket.attribute_domain = 'POINT'
	    target_guide_socket.description = "Target mesh used to create hair curves from edges."
	
	
	    #initialize hair_from_mesh_edges nodes
	    #node Group Input
	    group_input = hair_from_mesh_edges.nodes.new("NodeGroupInput")
	    group_input.name = "Group Input"
	    group_input.outputs[2].hide = True
	
	    #node Group Output
	    group_output = hair_from_mesh_edges.nodes.new("NodeGroupOutput")
	    group_output.name = "Group Output"
	    group_output.is_active_output = True
	    group_output.inputs[1].hide = True
	
	    #node Object Info
	    object_info = hair_from_mesh_edges.nodes.new("GeometryNodeObjectInfo")
	    object_info.name = "Object Info"
	    object_info.hide = True
	    object_info.transform_space = 'RELATIVE'
	    object_info.inputs[1].hide = True
	    object_info.outputs[0].hide = True
	    object_info.outputs[1].hide = True
	    object_info.outputs[2].hide = True
	    object_info.outputs[3].hide = True
	    #As Instance
	    object_info.inputs[1].default_value = False
	
	    #node Mesh to Curve
	    mesh_to_curve = hair_from_mesh_edges.nodes.new("GeometryNodeMeshToCurve")
	    mesh_to_curve.name = "Mesh to Curve"
	    mesh_to_curve.hide = True
	    mesh_to_curve.inputs[1].hide = True
	    #Selection
	    mesh_to_curve.inputs[1].default_value = True
	
	    #node Domain Size
	    domain_size = hair_from_mesh_edges.nodes.new("GeometryNodeAttributeDomainSize")
	    domain_size.name = "Domain Size"
	    domain_size.hide = True
	    domain_size.component = 'MESH'
	    domain_size.outputs[1].hide = True
	    domain_size.outputs[2].hide = True
	    domain_size.outputs[3].hide = True
	    domain_size.outputs[4].hide = True
	    domain_size.outputs[5].hide = True
	    domain_size.outputs[6].hide = True
	
	    #node Compare
	    compare = hair_from_mesh_edges.nodes.new("FunctionNodeCompare")
	    compare.name = "Compare"
	    compare.hide = True
	    compare.data_type = 'INT'
	    compare.mode = 'ELEMENT'
	    compare.operation = 'NOT_EQUAL'
	    compare.inputs[0].hide = True
	    compare.inputs[1].hide = True
	    compare.inputs[3].hide = True
	    compare.inputs[4].hide = True
	    compare.inputs[5].hide = True
	    compare.inputs[6].hide = True
	    compare.inputs[7].hide = True
	    compare.inputs[8].hide = True
	    compare.inputs[9].hide = True
	    compare.inputs[10].hide = True
	    compare.inputs[11].hide = True
	    compare.inputs[12].hide = True
	    #B_INT
	    compare.inputs[3].default_value = 0
	
	    #node Switch
	    switch = hair_from_mesh_edges.nodes.new("GeometryNodeSwitch")
	    switch.name = "Switch"
	    switch.hide = True
	    switch.input_type = 'GEOMETRY'
	
	
	
	
	
	    #Set locations
	    group_input.location = (-340.0, 0.0)
	    group_output.location = (200.0, 0.0)
	    object_info.location = (-164.61679077148438, -82.82696533203125)
	    mesh_to_curve.location = (-161.58409118652344, -48.59880828857422)
	    domain_size.location = (19.193912506103516, -79.36055755615234)
	    compare.location = (17.658432006835938, 6.78057861328125)
	    switch.location = (19.1939697265625, -25.525299072265625)
	
	    #Set dimensions
	    group_input.width, group_input.height = 140.0, 100.0
	    group_output.width, group_output.height = 140.0, 100.0
	    object_info.width, object_info.height = 140.0, 100.0
	    mesh_to_curve.width, mesh_to_curve.height = 140.0, 100.0
	    domain_size.width, domain_size.height = 140.0, 100.0
	    compare.width, compare.height = 140.0, 100.0
	    switch.width, switch.height = 140.0, 100.0
	
	    #initialize hair_from_mesh_edges links
	    #group_input.Target Guide -> object_info.Object
	    hair_from_mesh_edges.links.new(group_input.outputs[1], object_info.inputs[0])
	    #object_info.Geometry -> mesh_to_curve.Mesh
	    hair_from_mesh_edges.links.new(object_info.outputs[4], mesh_to_curve.inputs[0])
	    #object_info.Geometry -> domain_size.Geometry
	    hair_from_mesh_edges.links.new(object_info.outputs[4], domain_size.inputs[0])
	    #domain_size.Point Count -> compare.A
	    hair_from_mesh_edges.links.new(domain_size.outputs[0], compare.inputs[2])
	    #compare.Result -> switch.Switch
	    hair_from_mesh_edges.links.new(compare.outputs[0], switch.inputs[0])
	    #mesh_to_curve.Curve -> switch.True
	    hair_from_mesh_edges.links.new(mesh_to_curve.outputs[0], switch.inputs[2])
	    #group_input.Geometry -> switch.False
	    hair_from_mesh_edges.links.new(group_input.outputs[0], switch.inputs[1])
	    #switch.Output -> group_output.Geometry
	    hair_from_mesh_edges.links.new(switch.outputs[0], group_output.inputs[0])
	    return hair_from_mesh_edges
	return hair_from_mesh_edges_node_group()

	

	
