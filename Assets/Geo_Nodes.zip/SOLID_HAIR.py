import bpy, mathutils

def node():
	#initialize curve_extrude_profile node group
	def curve_extrude_profile_node_group():
	    curve_extrude_profile = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "CURVE_EXTRUDE_PROFILE")
	
	    curve_extrude_profile.color_tag = 'NONE'
	    curve_extrude_profile.description = "Create a curve profile for Convert to Mesh Profile."
	    curve_extrude_profile.default_group_node_width = 140
	    
	
	    curve_extrude_profile.is_modifier = True
	
	    #curve_extrude_profile interface
	    #Socket Geometry
	    geometry_socket = curve_extrude_profile.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket.attribute_domain = 'POINT'
	    geometry_socket.description = "Curve profile."
	
	    #Socket Resolution
	    resolution_socket = curve_extrude_profile.interface.new_socket(name = "Resolution", in_out='INPUT', socket_type = 'NodeSocketInt')
	    resolution_socket.default_value = 32
	    resolution_socket.min_value = 3
	    resolution_socket.max_value = 512
	    resolution_socket.subtype = 'NONE'
	    resolution_socket.attribute_domain = 'POINT'
	    resolution_socket.description = "Curve resolution."
	
	    #Socket Translation
	    translation_socket = curve_extrude_profile.interface.new_socket(name = "Translation", in_out='INPUT', socket_type = 'NodeSocketVector')
	    translation_socket.default_value = (0.0, 0.0, 0.0)
	    translation_socket.min_value = -3.4028234663852886e+38
	    translation_socket.max_value = 3.4028234663852886e+38
	    translation_socket.subtype = 'TRANSLATION'
	    translation_socket.attribute_domain = 'POINT'
	    translation_socket.description = "Translate curve profile from origin."
	
	    #Socket Rotation
	    rotation_socket = curve_extrude_profile.interface.new_socket(name = "Rotation", in_out='INPUT', socket_type = 'NodeSocketRotation')
	    rotation_socket.default_value = (0.0, 0.0, 0.0)
	    rotation_socket.attribute_domain = 'POINT'
	    rotation_socket.description = "Rotate curve profile from origin."
	
	    #Socket Scale
	    scale_socket = curve_extrude_profile.interface.new_socket(name = "Scale", in_out='INPUT', socket_type = 'NodeSocketVector')
	    scale_socket.default_value = (1.0, 1.0, 1.0)
	    scale_socket.min_value = -3.4028234663852886e+38
	    scale_socket.max_value = 3.4028234663852886e+38
	    scale_socket.subtype = 'XYZ'
	    scale_socket.attribute_domain = 'POINT'
	    scale_socket.description = "Scale curve profile from origin."
	
	
	    #initialize curve_extrude_profile nodes
	    #node Group Input
	    group_input = curve_extrude_profile.nodes.new("NodeGroupInput")
	    group_input.name = "Group Input"
	    group_input.outputs[1].hide = True
	    group_input.outputs[2].hide = True
	    group_input.outputs[3].hide = True
	    group_input.outputs[4].hide = True
	
	    #node Group Output
	    group_output = curve_extrude_profile.nodes.new("NodeGroupOutput")
	    group_output.name = "Group Output"
	    group_output.is_active_output = True
	    group_output.inputs[1].hide = True
	
	    #node Curve Circle
	    curve_circle = curve_extrude_profile.nodes.new("GeometryNodeCurvePrimitiveCircle")
	    curve_circle.name = "Curve Circle"
	    curve_circle.hide = True
	    curve_circle.mode = 'RADIUS'
	    curve_circle.inputs[1].hide = True
	    curve_circle.inputs[2].hide = True
	    curve_circle.inputs[3].hide = True
	    curve_circle.inputs[4].hide = True
	    curve_circle.outputs[1].hide = True
	    #Radius
	    curve_circle.inputs[4].default_value = 1.0
	
	    #node Radial Offset
	    radial_offset = curve_extrude_profile.nodes.new("ShaderNodeFloatCurve")
	    radial_offset.label = "Radial Offset"
	    radial_offset.name = "Radial Offset"
	    #mapping settings
	    radial_offset.mapping.extend = 'EXTRAPOLATED'
	    radial_offset.mapping.tone = 'STANDARD'
	    radial_offset.mapping.black_level = (0.0, 0.0, 0.0)
	    radial_offset.mapping.white_level = (1.0, 1.0, 1.0)
	    radial_offset.mapping.clip_min_x = 0.0
	    radial_offset.mapping.clip_min_y = 0.0
	    radial_offset.mapping.clip_max_x = 1.0
	    radial_offset.mapping.clip_max_y = 1.0
	    radial_offset.mapping.use_clip = True
	    #curve 0
	    radial_offset_curve_0 = radial_offset.mapping.curves[0]
	    radial_offset_curve_0_point_0 = radial_offset_curve_0.points[0]
	    radial_offset_curve_0_point_0.location = (0.001054852269589901, 0.4187498390674591)
	    radial_offset_curve_0_point_0.handle_type = 'AUTO'
	    radial_offset_curve_0_point_1 = radial_offset_curve_0.points[1]
	    radial_offset_curve_0_point_1.location = (0.047468364238739014, 0.46874988079071045)
	    radial_offset_curve_0_point_1.handle_type = 'AUTO'
	    radial_offset_curve_0_point_2 = radial_offset_curve_0.points.new(0.08649790287017822, 0.5812492370605469)
	    radial_offset_curve_0_point_2.handle_type = 'AUTO'
	    radial_offset_curve_0_point_3 = radial_offset_curve_0.points.new(0.10337552428245544, 0.7875000238418579)
	    radial_offset_curve_0_point_3.handle_type = 'AUTO'
	    radial_offset_curve_0_point_4 = radial_offset_curve_0.points.new(0.13396626710891724, 0.7749997973442078)
	    radial_offset_curve_0_point_4.handle_type = 'AUTO'
	    radial_offset_curve_0_point_5 = radial_offset_curve_0.points.new(0.16772152483463287, 0.8312500715255737)
	    radial_offset_curve_0_point_5.handle_type = 'AUTO'
	    radial_offset_curve_0_point_6 = radial_offset_curve_0.points.new(0.19677962362766266, 0.787499725818634)
	    radial_offset_curve_0_point_6.handle_type = 'AUTO_CLAMPED'
	    radial_offset_curve_0_point_7 = radial_offset_curve_0.points.new(0.20991560816764832, 0.8937498927116394)
	    radial_offset_curve_0_point_7.handle_type = 'AUTO'
	    radial_offset_curve_0_point_8 = radial_offset_curve_0.points.new(0.2320675104856491, 0.9124997854232788)
	    radial_offset_curve_0_point_8.handle_type = 'AUTO'
	    radial_offset_curve_0_point_9 = radial_offset_curve_0.points.new(0.25210970640182495, 0.9124999046325684)
	    radial_offset_curve_0_point_9.handle_type = 'AUTO'
	    radial_offset_curve_0_point_10 = radial_offset_curve_0.points.new(0.26160338521003723, 0.8437498211860657)
	    radial_offset_curve_0_point_10.handle_type = 'AUTO_CLAMPED'
	    radial_offset_curve_0_point_11 = radial_offset_curve_0.points.new(0.2890295386314392, 0.7687493562698364)
	    radial_offset_curve_0_point_11.handle_type = 'AUTO_CLAMPED'
	    radial_offset_curve_0_point_12 = radial_offset_curve_0.points.new(0.3238396644592285, 0.8562501668930054)
	    radial_offset_curve_0_point_12.handle_type = 'AUTO'
	    radial_offset_curve_0_point_13 = radial_offset_curve_0.points.new(0.324894517660141, 0.5749994516372681)
	    radial_offset_curve_0_point_13.handle_type = 'AUTO_CLAMPED'
	    radial_offset_curve_0_point_14 = radial_offset_curve_0.points.new(0.35232067108154297, 0.6937500238418579)
	    radial_offset_curve_0_point_14.handle_type = 'AUTO'
	    radial_offset_curve_0_point_15 = radial_offset_curve_0.points.new(0.35232067108154297, 0.524999737739563)
	    radial_offset_curve_0_point_15.handle_type = 'AUTO_CLAMPED'
	    radial_offset_curve_0_point_16 = radial_offset_curve_0.points.new(0.3818565309047699, 0.5062499642372131)
	    radial_offset_curve_0_point_16.handle_type = 'AUTO'
	    radial_offset_curve_0_point_17 = radial_offset_curve_0.points.new(0.3913502097129822, 0.36875006556510925)
	    radial_offset_curve_0_point_17.handle_type = 'AUTO'
	    radial_offset_curve_0_point_18 = radial_offset_curve_0.points.new(0.4166666567325592, 0.35624998807907104)
	    radial_offset_curve_0_point_18.handle_type = 'AUTO'
	    radial_offset_curve_0_point_19 = radial_offset_curve_0.points.new(0.4388185739517212, 0.2812500298023224)
	    radial_offset_curve_0_point_19.handle_type = 'AUTO'
	    radial_offset_curve_0_point_20 = radial_offset_curve_0.points.new(0.4609704613685608, 0.3125)
	    radial_offset_curve_0_point_20.handle_type = 'AUTO'
	    radial_offset_curve_0_point_21 = radial_offset_curve_0.points.new(0.4820675253868103, 0.27500006556510925)
	    radial_offset_curve_0_point_21.handle_type = 'AUTO'
	    radial_offset_curve_0_point_22 = radial_offset_curve_0.points.new(0.4989451467990875, 0.3312499225139618)
	    radial_offset_curve_0_point_22.handle_type = 'AUTO'
	    radial_offset_curve_0_point_23 = radial_offset_curve_0.points.new(0.5179324746131897, 0.30000004172325134)
	    radial_offset_curve_0_point_23.handle_type = 'AUTO'
	    radial_offset_curve_0_point_24 = radial_offset_curve_0.points.new(0.5348103046417236, 0.3374999463558197)
	    radial_offset_curve_0_point_24.handle_type = 'AUTO'
	    radial_offset_curve_0_point_25 = radial_offset_curve_0.points.new(0.5537979006767273, 0.47499993443489075)
	    radial_offset_curve_0_point_25.handle_type = 'AUTO_CLAMPED'
	    radial_offset_curve_0_point_26 = radial_offset_curve_0.points.new(0.590717077255249, 0.4125000536441803)
	    radial_offset_curve_0_point_26.handle_type = 'AUTO'
	    radial_offset_curve_0_point_27 = radial_offset_curve_0.points.new(0.6097047328948975, 0.5375000238418579)
	    radial_offset_curve_0_point_27.handle_type = 'AUTO'
	    radial_offset_curve_0_point_28 = radial_offset_curve_0.points.new(0.6255272030830383, 0.631250262260437)
	    radial_offset_curve_0_point_28.handle_type = 'AUTO_CLAMPED'
	    radial_offset_curve_0_point_29 = radial_offset_curve_0.points.new(0.6540082693099976, 0.6124997138977051)
	    radial_offset_curve_0_point_29.handle_type = 'AUTO_CLAMPED'
	    radial_offset_curve_0_point_30 = radial_offset_curve_0.points.new(0.6708858013153076, 0.7999997138977051)
	    radial_offset_curve_0_point_30.handle_type = 'AUTO'
	    radial_offset_curve_0_point_31 = radial_offset_curve_0.points.new(0.6919825077056885, 0.6624998450279236)
	    radial_offset_curve_0_point_31.handle_type = 'AUTO'
	    radial_offset_curve_0_point_32 = radial_offset_curve_0.points.new(0.7014766335487366, 0.8124997615814209)
	    radial_offset_curve_0_point_32.handle_type = 'AUTO_CLAMPED'
	    radial_offset_curve_0_point_33 = radial_offset_curve_0.points.new(0.7194092273712158, 0.8999999761581421)
	    radial_offset_curve_0_point_33.handle_type = 'AUTO_CLAMPED'
	    radial_offset_curve_0_point_34 = radial_offset_curve_0.points.new(0.7362868189811707, 0.9124998450279236)
	    radial_offset_curve_0_point_34.handle_type = 'AUTO'
	    radial_offset_curve_0_point_35 = radial_offset_curve_0.points.new(0.7552741765975952, 0.9687498807907104)
	    radial_offset_curve_0_point_35.handle_type = 'AUTO'
	    radial_offset_curve_0_point_36 = radial_offset_curve_0.points.new(0.7795358300209045, 0.9249999523162842)
	    radial_offset_curve_0_point_36.handle_type = 'AUTO_CLAMPED'
	    radial_offset_curve_0_point_37 = radial_offset_curve_0.points.new(0.8016877174377441, 0.8937497735023499)
	    radial_offset_curve_0_point_37.handle_type = 'AUTO'
	    radial_offset_curve_0_point_38 = radial_offset_curve_0.points.new(0.8185654878616333, 0.8312497735023499)
	    radial_offset_curve_0_point_38.handle_type = 'AUTO_CLAMPED'
	    radial_offset_curve_0_point_39 = radial_offset_curve_0.points.new(0.8364976644515991, 0.8687500953674316)
	    radial_offset_curve_0_point_39.handle_type = 'AUTO'
	    radial_offset_curve_0_point_40 = radial_offset_curve_0.points.new(0.8523208498954773, 0.6749997735023499)
	    radial_offset_curve_0_point_40.handle_type = 'AUTO'
	    radial_offset_curve_0_point_41 = radial_offset_curve_0.points.new(0.8797467947006226, 0.6437497138977051)
	    radial_offset_curve_0_point_41.handle_type = 'AUTO_CLAMPED'
	    radial_offset_curve_0_point_42 = radial_offset_curve_0.points.new(0.9050630331039429, 0.6000002026557922)
	    radial_offset_curve_0_point_42.handle_type = 'AUTO'
	    radial_offset_curve_0_point_43 = radial_offset_curve_0.points.new(0.9356541633605957, 0.42500004172325134)
	    radial_offset_curve_0_point_43.handle_type = 'AUTO'
	    radial_offset_curve_0_point_44 = radial_offset_curve_0.points.new(0.9672994613647461, 0.41874992847442627)
	    radial_offset_curve_0_point_44.handle_type = 'AUTO'
	    radial_offset_curve_0_point_45 = radial_offset_curve_0.points.new(1.0, 0.3874998688697815)
	    radial_offset_curve_0_point_45.handle_type = 'AUTO'
	    #update curve after changes
	    radial_offset.mapping.update()
	    radial_offset.inputs[0].hide = True
	    #Factor
	    radial_offset.inputs[0].default_value = 1.0
	
	    #node Spline Parameter
	    spline_parameter = curve_extrude_profile.nodes.new("GeometryNodeSplineParameter")
	    spline_parameter.name = "Spline Parameter"
	    spline_parameter.outputs[1].hide = True
	    spline_parameter.outputs[2].hide = True
	
	    #node Set Position
	    set_position = curve_extrude_profile.nodes.new("GeometryNodeSetPosition")
	    set_position.name = "Set Position"
	    set_position.hide = True
	    set_position.inputs[1].hide = True
	    set_position.inputs[3].hide = True
	    #Selection
	    set_position.inputs[1].default_value = True
	    #Offset
	    set_position.inputs[3].default_value = (0.0, 0.0, 0.0)
	
	    #node Position
	    position = curve_extrude_profile.nodes.new("GeometryNodeInputPosition")
	    position.name = "Position"
	
	    #node Vector Math
	    vector_math = curve_extrude_profile.nodes.new("ShaderNodeVectorMath")
	    vector_math.name = "Vector Math"
	    vector_math.hide = True
	    vector_math.operation = 'SCALE'
	
	    #node Transform Geometry
	    transform_geometry = curve_extrude_profile.nodes.new("GeometryNodeTransform")
	    transform_geometry.name = "Transform Geometry"
	    transform_geometry.hide = True
	    transform_geometry.mode = 'COMPONENTS'
	
	    #node Group Input.001
	    group_input_001 = curve_extrude_profile.nodes.new("NodeGroupInput")
	    group_input_001.name = "Group Input.001"
	    group_input_001.outputs[0].hide = True
	    group_input_001.outputs[4].hide = True
	
	    #node Frame
	    frame = curve_extrude_profile.nodes.new("NodeFrame")
	    frame.label = "Radial Offset"
	    frame.name = "Frame"
	    frame.label_size = 20
	    frame.shrink = True
	
	    #node Reroute
	    reroute = curve_extrude_profile.nodes.new("NodeReroute")
	    reroute.name = "Reroute"
	    reroute.socket_idname = "NodeSocketVector"
	    #node Reroute.001
	    reroute_001 = curve_extrude_profile.nodes.new("NodeReroute")
	    reroute_001.name = "Reroute.001"
	    reroute_001.socket_idname = "NodeSocketVector"
	    #node Frame.001
	    frame_001 = curve_extrude_profile.nodes.new("NodeFrame")
	    frame_001.label = "X value is percantage of 360 deg from x positve."
	    frame_001.name = "Frame.001"
	    frame_001.label_size = 20
	    frame_001.shrink = True
	
	    #node Frame.002
	    frame_002 = curve_extrude_profile.nodes.new("NodeFrame")
	    frame_002.label = "Y value is the distance from origin. ([0,0,0])"
	    frame_002.name = "Frame.002"
	    frame_002.label_size = 20
	    frame_002.shrink = True
	
	
	
	
	    #Set parents
	    radial_offset.parent = frame
	    spline_parameter.parent = frame
	    position.parent = frame
	    vector_math.parent = frame
	
	    #Set locations
	    group_input.location = (-340.0, -22.570165634155273)
	    group_output.location = (362.9671936035156, -40.626277923583984)
	    curve_circle.location = (-166.6719512939453, -46.762123107910156)
	    radial_offset.location = (33.486419677734375, -129.11273193359375)
	    spline_parameter.location = (30.04144287109375, -424.0594482421875)
	    set_position.location = (4.4881591796875, -53.521385192871094)
	    position.location = (592.2982177734375, -74.47775268554688)
	    vector_math.location = (593.3895263671875, -44.6279296875)
	    transform_geometry.location = (185.82901000976562, -66.2401351928711)
	    group_input_001.location = (10.093160629272461, -81.2525405883789)
	    frame.location = (-352.0, -180.0)
	    reroute.location = (380.5245666503906, -181.39073181152344)
	    reroute_001.location = (5.314706802368164, -181.74554443359375)
	    frame_001.location = (422.1756591796875, -181.8056182861328)
	    frame_002.location = (422.1756591796875, -257.09149169921875)
	
	    #Set dimensions
	    group_input.width, group_input.height = 140.0, 100.0
	    group_output.width, group_output.height = 140.0, 100.0
	    curve_circle.width, curve_circle.height = 140.0, 100.0
	    radial_offset.width, radial_offset.height = 700.0, 100.0
	    spline_parameter.width, spline_parameter.height = 140.0, 100.0
	    set_position.width, set_position.height = 140.0, 100.0
	    position.width, position.height = 140.0, 100.0
	    vector_math.width, vector_math.height = 140.0, 100.0
	    transform_geometry.width, transform_geometry.height = 140.0, 100.0
	    group_input_001.width, group_input_001.height = 140.0, 100.0
	    frame.width, frame.height = 763.0, 506.0
	    reroute.width, reroute.height = 10.0, 100.0
	    reroute_001.width, reroute_001.height = 10.0, 100.0
	    frame_001.width, frame_001.height = 763.0001220703125, 58.84747314453125
	    frame_002.width, frame_002.height = 763.0001220703125, 58.84722900390625
	
	    #initialize curve_extrude_profile links
	    #spline_parameter.Factor -> radial_offset.Value
	    curve_extrude_profile.links.new(spline_parameter.outputs[0], radial_offset.inputs[1])
	    #curve_circle.Curve -> set_position.Geometry
	    curve_extrude_profile.links.new(curve_circle.outputs[0], set_position.inputs[0])
	    #position.Position -> vector_math.Vector
	    curve_extrude_profile.links.new(position.outputs[0], vector_math.inputs[0])
	    #radial_offset.Value -> vector_math.Scale
	    curve_extrude_profile.links.new(radial_offset.outputs[0], vector_math.inputs[3])
	    #reroute_001.Output -> set_position.Position
	    curve_extrude_profile.links.new(reroute_001.outputs[0], set_position.inputs[2])
	    #group_input.Resolution -> curve_circle.Resolution
	    curve_extrude_profile.links.new(group_input.outputs[0], curve_circle.inputs[0])
	    #set_position.Geometry -> transform_geometry.Geometry
	    curve_extrude_profile.links.new(set_position.outputs[0], transform_geometry.inputs[0])
	    #group_input_001.Translation -> transform_geometry.Translation
	    curve_extrude_profile.links.new(group_input_001.outputs[1], transform_geometry.inputs[1])
	    #group_input_001.Rotation -> transform_geometry.Rotation
	    curve_extrude_profile.links.new(group_input_001.outputs[2], transform_geometry.inputs[2])
	    #group_input_001.Scale -> transform_geometry.Scale
	    curve_extrude_profile.links.new(group_input_001.outputs[3], transform_geometry.inputs[3])
	    #transform_geometry.Geometry -> group_output.Geometry
	    curve_extrude_profile.links.new(transform_geometry.outputs[0], group_output.inputs[0])
	    #vector_math.Vector -> reroute.Input
	    curve_extrude_profile.links.new(vector_math.outputs[0], reroute.inputs[0])
	    #reroute.Output -> reroute_001.Input
	    curve_extrude_profile.links.new(reroute.outputs[0], reroute_001.inputs[0])
	    return curve_extrude_profile
	
	curve_extrude_profile = curve_extrude_profile_node_group()
	
	#initialize mesh_to_strands node group
	def mesh_to_strands_node_group():
	    mesh_to_strands = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "MESH_TO_STRANDS")
	
	    mesh_to_strands.color_tag = 'NONE'
	    mesh_to_strands.description = "Convert mesh with UV Map to hair curve strands."
	    mesh_to_strands.default_group_node_width = 140
	    
	
	
	    #mesh_to_strands interface
	    #Socket Geometry
	    geometry_socket_1 = mesh_to_strands.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_1.attribute_domain = 'POINT'
	    geometry_socket_1.description = "Hair Curve Strands made mesh."
	
	    #Socket Geometry
	    geometry_socket_2 = mesh_to_strands.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_2.attribute_domain = 'POINT'
	    geometry_socket_2.description = "Mesh object with UV Map."
	
	    #Socket Level
	    level_socket = mesh_to_strands.interface.new_socket(name = "Level", in_out='INPUT', socket_type = 'NodeSocketInt')
	    level_socket.default_value = 0
	    level_socket.min_value = 0
	    level_socket.max_value = 6
	    level_socket.subtype = 'NONE'
	    level_socket.attribute_domain = 'POINT'
	    level_socket.description = "Mesh subdivision level."
	
	    #Socket Material
	    material_socket = mesh_to_strands.interface.new_socket(name = "Material", in_out='INPUT', socket_type = 'NodeSocketMaterial')
	    material_socket.attribute_domain = 'POINT'
	    material_socket.description = "Curve material."
	
	    #Socket Strand Radius
	    strand_radius_socket = mesh_to_strands.interface.new_socket(name = "Strand Radius", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    strand_radius_socket.default_value = 0.003000000026077032
	    strand_radius_socket.min_value = 0.0
	    strand_radius_socket.max_value = 10000.0
	    strand_radius_socket.subtype = 'NONE'
	    strand_radius_socket.attribute_domain = 'POINT'
	    strand_radius_socket.description = "Radius for hair strands."
	
	    #Socket Trim Seed
	    trim_seed_socket = mesh_to_strands.interface.new_socket(name = "Trim Seed", in_out='INPUT', socket_type = 'NodeSocketInt')
	    trim_seed_socket.default_value = 0
	    trim_seed_socket.min_value = -10000
	    trim_seed_socket.max_value = 10000
	    trim_seed_socket.subtype = 'NONE'
	    trim_seed_socket.attribute_domain = 'POINT'
	    trim_seed_socket.description = "Random seed for hair tip trimming."
	
	    #Socket Trim Factor
	    trim_factor_socket = mesh_to_strands.interface.new_socket(name = "Trim Factor", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    trim_factor_socket.default_value = 1.0
	    trim_factor_socket.min_value = 0.0
	    trim_factor_socket.max_value = 1.0
	    trim_factor_socket.subtype = 'FACTOR'
	    trim_factor_socket.attribute_domain = 'POINT'
	    trim_factor_socket.description = "Minumal percentage of hair strand length to remain after random trim. (1=no trim, 0=potential full trim)"
	
	    #Socket UV Map
	    uv_map_socket = mesh_to_strands.interface.new_socket(name = "UV Map", in_out='INPUT', socket_type = 'NodeSocketString')
	    uv_map_socket.default_value = "UVMap"
	    uv_map_socket.subtype = 'NONE'
	    uv_map_socket.attribute_domain = 'POINT'
	    uv_map_socket.description = "UV Map used to detrmine strand direction."
	
	
	    #initialize mesh_to_strands nodes
	    #node Group Output
	    group_output_1 = mesh_to_strands.nodes.new("NodeGroupOutput")
	    group_output_1.name = "Group Output"
	    group_output_1.is_active_output = True
	    group_output_1.inputs[1].hide = True
	
	    #node Group Input
	    group_input_1 = mesh_to_strands.nodes.new("NodeGroupInput")
	    group_input_1.name = "Group Input"
	    group_input_1.outputs[2].hide = True
	    group_input_1.outputs[3].hide = True
	    group_input_1.outputs[4].hide = True
	    group_input_1.outputs[5].hide = True
	    group_input_1.outputs[6].hide = True
	    group_input_1.outputs[7].hide = True
	
	    #node Shortest Edge Paths
	    shortest_edge_paths = mesh_to_strands.nodes.new("GeometryNodeInputShortestEdgePaths")
	    shortest_edge_paths.name = "Shortest Edge Paths"
	    shortest_edge_paths.inputs[1].hide = True
	    shortest_edge_paths.outputs[0].hide = True
	    #Edge Cost
	    shortest_edge_paths.inputs[1].default_value = 1.0
	
	    #node Edge Vertices
	    edge_vertices = mesh_to_strands.nodes.new("GeometryNodeInputMeshEdgeVertices")
	    edge_vertices.name = "Edge Vertices"
	    edge_vertices.outputs[2].hide = True
	    edge_vertices.outputs[3].hide = True
	
	    #node Evaluate at Index
	    evaluate_at_index = mesh_to_strands.nodes.new("GeometryNodeFieldAtIndex")
	    evaluate_at_index.name = "Evaluate at Index"
	    evaluate_at_index.data_type = 'INT'
	    evaluate_at_index.domain = 'POINT'
	
	    #node Evaluate at Index.001
	    evaluate_at_index_001 = mesh_to_strands.nodes.new("GeometryNodeFieldAtIndex")
	    evaluate_at_index_001.name = "Evaluate at Index.001"
	    evaluate_at_index_001.data_type = 'INT'
	    evaluate_at_index_001.domain = 'POINT'
	
	    #node Compare.002
	    compare_002 = mesh_to_strands.nodes.new("FunctionNodeCompare")
	    compare_002.name = "Compare.002"
	    compare_002.data_type = 'INT'
	    compare_002.mode = 'ELEMENT'
	    compare_002.operation = 'EQUAL'
	
	    #node Named Attribute
	    named_attribute = mesh_to_strands.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute.name = "Named Attribute"
	    named_attribute.data_type = 'FLOAT_VECTOR'
	
	    #node Separate XYZ
	    separate_xyz = mesh_to_strands.nodes.new("ShaderNodeSeparateXYZ")
	    separate_xyz.name = "Separate XYZ"
	    separate_xyz.outputs[1].hide = True
	    separate_xyz.outputs[2].hide = True
	
	    #node Compare.005
	    compare_005 = mesh_to_strands.nodes.new("FunctionNodeCompare")
	    compare_005.name = "Compare.005"
	    compare_005.data_type = 'FLOAT'
	    compare_005.mode = 'ELEMENT'
	    compare_005.operation = 'EQUAL'
	    compare_005.inputs[1].hide = True
	    compare_005.inputs[2].hide = True
	    compare_005.inputs[3].hide = True
	    compare_005.inputs[4].hide = True
	    compare_005.inputs[5].hide = True
	    compare_005.inputs[6].hide = True
	    compare_005.inputs[7].hide = True
	    compare_005.inputs[8].hide = True
	    compare_005.inputs[9].hide = True
	    compare_005.inputs[10].hide = True
	    compare_005.inputs[11].hide = True
	    compare_005.inputs[12].hide = True
	    #B
	    compare_005.inputs[1].default_value = 0.0
	    #Epsilon
	    compare_005.inputs[12].default_value = 0.0
	
	    #node Delete Geometry
	    delete_geometry = mesh_to_strands.nodes.new("GeometryNodeDeleteGeometry")
	    delete_geometry.name = "Delete Geometry"
	    delete_geometry.hide = True
	    delete_geometry.domain = 'EDGE'
	    delete_geometry.mode = 'ALL'
	
	    #node Mesh to Curve
	    mesh_to_curve = mesh_to_strands.nodes.new("GeometryNodeMeshToCurve")
	    mesh_to_curve.name = "Mesh to Curve"
	    mesh_to_curve.hide = True
	    mesh_to_curve.inputs[1].hide = True
	    #Selection
	    mesh_to_curve.inputs[1].default_value = True
	
	    #node Subdivide Mesh
	    subdivide_mesh = mesh_to_strands.nodes.new("GeometryNodeSubdivideMesh")
	    subdivide_mesh.name = "Subdivide Mesh"
	
	    #node Set Material.002
	    set_material_002 = mesh_to_strands.nodes.new("GeometryNodeSetMaterial")
	    set_material_002.name = "Set Material.002"
	    set_material_002.inputs[1].hide = True
	    #Selection
	    set_material_002.inputs[1].default_value = True
	
	    #node Set Curve Radius
	    set_curve_radius = mesh_to_strands.nodes.new("GeometryNodeSetCurveRadius")
	    set_curve_radius.name = "Set Curve Radius"
	    set_curve_radius.inputs[1].hide = True
	    #Selection
	    set_curve_radius.inputs[1].default_value = True
	
	    #node Map Range
	    map_range = mesh_to_strands.nodes.new("ShaderNodeMapRange")
	    map_range.name = "Map Range"
	    map_range.hide = True
	    map_range.clamp = True
	    map_range.data_type = 'FLOAT'
	    map_range.interpolation_type = 'LINEAR'
	    map_range.inputs[1].hide = True
	    map_range.inputs[2].hide = True
	    map_range.inputs[3].hide = True
	    map_range.inputs[5].hide = True
	    map_range.inputs[6].hide = True
	    map_range.inputs[7].hide = True
	    map_range.inputs[8].hide = True
	    map_range.inputs[9].hide = True
	    map_range.inputs[10].hide = True
	    map_range.inputs[11].hide = True
	    map_range.outputs[1].hide = True
	    #From Min
	    map_range.inputs[1].default_value = 0.0
	    #From Max
	    map_range.inputs[2].default_value = 1.0
	    #To Min
	    map_range.inputs[3].default_value = 0.0
	
	    #node Map Range.001
	    map_range_001 = mesh_to_strands.nodes.new("ShaderNodeMapRange")
	    map_range_001.name = "Map Range.001"
	    map_range_001.hide = True
	    map_range_001.clamp = True
	    map_range_001.data_type = 'FLOAT'
	    map_range_001.interpolation_type = 'LINEAR'
	    map_range_001.inputs[1].hide = True
	    map_range_001.inputs[2].hide = True
	    map_range_001.inputs[4].hide = True
	    map_range_001.inputs[5].hide = True
	    map_range_001.inputs[6].hide = True
	    map_range_001.inputs[7].hide = True
	    map_range_001.inputs[8].hide = True
	    map_range_001.inputs[9].hide = True
	    map_range_001.inputs[10].hide = True
	    map_range_001.inputs[11].hide = True
	    map_range_001.outputs[1].hide = True
	    #From Min
	    map_range_001.inputs[1].default_value = 0.0
	    #From Max
	    map_range_001.inputs[2].default_value = 1.0
	    #To Max
	    map_range_001.inputs[4].default_value = 1.0
	
	    #node Trim Shape
	    trim_shape = mesh_to_strands.nodes.new("ShaderNodeFloatCurve")
	    trim_shape.label = "Trim Shape"
	    trim_shape.name = "Trim Shape"
	    #mapping settings
	    trim_shape.mapping.extend = 'EXTRAPOLATED'
	    trim_shape.mapping.tone = 'STANDARD'
	    trim_shape.mapping.black_level = (0.0, 0.0, 0.0)
	    trim_shape.mapping.white_level = (1.0, 1.0, 1.0)
	    trim_shape.mapping.clip_min_x = 0.0
	    trim_shape.mapping.clip_min_y = 0.0
	    trim_shape.mapping.clip_max_x = 1.0
	    trim_shape.mapping.clip_max_y = 1.0
	    trim_shape.mapping.use_clip = True
	    #curve 0
	    trim_shape_curve_0 = trim_shape.mapping.curves[0]
	    trim_shape_curve_0_point_0 = trim_shape_curve_0.points[0]
	    trim_shape_curve_0_point_0.location = (0.0, 0.0)
	    trim_shape_curve_0_point_0.handle_type = 'AUTO'
	    trim_shape_curve_0_point_1 = trim_shape_curve_0.points[1]
	    trim_shape_curve_0_point_1.location = (0.281818151473999, 0.16875001788139343)
	    trim_shape_curve_0_point_1.handle_type = 'AUTO'
	    trim_shape_curve_0_point_2 = trim_shape_curve_0.points.new(0.7136364579200745, 0.8625001907348633)
	    trim_shape_curve_0_point_2.handle_type = 'AUTO'
	    trim_shape_curve_0_point_3 = trim_shape_curve_0.points.new(1.0, 1.0)
	    trim_shape_curve_0_point_3.handle_type = 'AUTO'
	    #update curve after changes
	    trim_shape.mapping.update()
	    trim_shape.inputs[0].hide = True
	    #Factor
	    trim_shape.inputs[0].default_value = 1.0
	
	    #node Random Value
	    random_value = mesh_to_strands.nodes.new("FunctionNodeRandomValue")
	    random_value.name = "Random Value"
	    random_value.hide = True
	    random_value.data_type = 'FLOAT'
	    random_value.inputs[0].hide = True
	    random_value.inputs[1].hide = True
	    random_value.inputs[2].hide = True
	    random_value.inputs[3].hide = True
	    random_value.inputs[4].hide = True
	    random_value.inputs[5].hide = True
	    random_value.inputs[6].hide = True
	    random_value.inputs[7].hide = True
	    random_value.outputs[0].hide = True
	    random_value.outputs[2].hide = True
	    random_value.outputs[3].hide = True
	    #Min_001
	    random_value.inputs[2].default_value = 0.0
	    #Max_001
	    random_value.inputs[3].default_value = 1.0
	    #ID
	    random_value.inputs[7].default_value = 0
	
	    #node Strand Shape
	    strand_shape = mesh_to_strands.nodes.new("ShaderNodeFloatCurve")
	    strand_shape.label = "Strand Shape"
	    strand_shape.name = "Strand Shape"
	    #mapping settings
	    strand_shape.mapping.extend = 'EXTRAPOLATED'
	    strand_shape.mapping.tone = 'STANDARD'
	    strand_shape.mapping.black_level = (0.0, 0.0, 0.0)
	    strand_shape.mapping.white_level = (1.0, 1.0, 1.0)
	    strand_shape.mapping.clip_min_x = 0.0
	    strand_shape.mapping.clip_min_y = 0.0
	    strand_shape.mapping.clip_max_x = 1.0
	    strand_shape.mapping.clip_max_y = 1.0
	    strand_shape.mapping.use_clip = True
	    #curve 0
	    strand_shape_curve_0 = strand_shape.mapping.curves[0]
	    strand_shape_curve_0_point_0 = strand_shape_curve_0.points[0]
	    strand_shape_curve_0_point_0.location = (0.0, 1.0)
	    strand_shape_curve_0_point_0.handle_type = 'AUTO'
	    strand_shape_curve_0_point_1 = strand_shape_curve_0.points[1]
	    strand_shape_curve_0_point_1.location = (0.3227272033691406, 0.9187501072883606)
	    strand_shape_curve_0_point_1.handle_type = 'AUTO'
	    strand_shape_curve_0_point_2 = strand_shape_curve_0.points.new(0.6772727966308594, 0.15000002086162567)
	    strand_shape_curve_0_point_2.handle_type = 'AUTO'
	    strand_shape_curve_0_point_3 = strand_shape_curve_0.points.new(1.0, 0.0)
	    strand_shape_curve_0_point_3.handle_type = 'AUTO'
	    #update curve after changes
	    strand_shape.mapping.update()
	    strand_shape.inputs[0].hide = True
	    #Factor
	    strand_shape.inputs[0].default_value = 1.0
	
	    #node Hair Fadeout
	    hair_fadeout = mesh_to_strands.nodes.new("ShaderNodeValToRGB")
	    hair_fadeout.label = "Hair Fadeout"
	    hair_fadeout.name = "Hair Fadeout"
	    hair_fadeout.color_ramp.color_mode = 'RGB'
	    hair_fadeout.color_ramp.hue_interpolation = 'NEAR'
	    hair_fadeout.color_ramp.interpolation = 'LINEAR'
	
	    #initialize color ramp elements
	    hair_fadeout.color_ramp.elements.remove(hair_fadeout.color_ramp.elements[0])
	    hair_fadeout_cre_0 = hair_fadeout.color_ramp.elements[0]
	    hair_fadeout_cre_0.position = 0.0
	    hair_fadeout_cre_0.alpha = 1.0
	    hair_fadeout_cre_0.color = (0.0, 0.0, 0.0, 1.0)
	
	    hair_fadeout_cre_1 = hair_fadeout.color_ramp.elements.new(0.009999999776482582)
	    hair_fadeout_cre_1.alpha = 1.0
	    hair_fadeout_cre_1.color = (1.0, 1.0, 1.0, 1.0)
	
	    hair_fadeout_cre_2 = hair_fadeout.color_ramp.elements.new(0.949999988079071)
	    hair_fadeout_cre_2.alpha = 1.0
	    hair_fadeout_cre_2.color = (1.0, 1.0, 1.0, 1.0)
	
	    hair_fadeout_cre_3 = hair_fadeout.color_ramp.elements.new(1.0)
	    hair_fadeout_cre_3.alpha = 1.0
	    hair_fadeout_cre_3.color = (0.0, 0.0, 0.0, 1.0)
	
	    hair_fadeout.outputs[1].hide = True
	
	    #node Spline Parameter.002
	    spline_parameter_002 = mesh_to_strands.nodes.new("GeometryNodeSplineParameter")
	    spline_parameter_002.name = "Spline Parameter.002"
	    spline_parameter_002.outputs[1].hide = True
	    spline_parameter_002.outputs[2].hide = True
	
	    #node Frame.003
	    frame_003 = mesh_to_strands.nodes.new("NodeFrame")
	    frame_003.label = "Random Length | Strand Shape"
	    frame_003.name = "Frame.003"
	    frame_003.label_size = 20
	    frame_003.shrink = True
	
	    #node Map Range.002
	    map_range_002 = mesh_to_strands.nodes.new("ShaderNodeMapRange")
	    map_range_002.name = "Map Range.002"
	    map_range_002.hide = True
	    map_range_002.clamp = True
	    map_range_002.data_type = 'FLOAT'
	    map_range_002.interpolation_type = 'LINEAR'
	    map_range_002.inputs[1].hide = True
	    map_range_002.inputs[2].hide = True
	    map_range_002.inputs[3].hide = True
	    map_range_002.inputs[4].hide = True
	    map_range_002.inputs[5].hide = True
	    map_range_002.inputs[6].hide = True
	    map_range_002.inputs[7].hide = True
	    map_range_002.inputs[8].hide = True
	    map_range_002.inputs[9].hide = True
	    map_range_002.inputs[10].hide = True
	    map_range_002.inputs[11].hide = True
	    map_range_002.outputs[1].hide = True
	    #From Min
	    map_range_002.inputs[1].default_value = 0.0
	    #From Max
	    map_range_002.inputs[2].default_value = 1.0
	    #To Min
	    map_range_002.inputs[3].default_value = 1.0
	    #To Max
	    map_range_002.inputs[4].default_value = 0.0
	
	    #node Trim Curve
	    trim_curve = mesh_to_strands.nodes.new("GeometryNodeTrimCurve")
	    trim_curve.name = "Trim Curve"
	    trim_curve.mode = 'FACTOR'
	    trim_curve.inputs[1].hide = True
	    trim_curve.inputs[2].hide = True
	    trim_curve.inputs[4].hide = True
	    trim_curve.inputs[5].hide = True
	    #Selection
	    trim_curve.inputs[1].default_value = True
	    #Start
	    trim_curve.inputs[2].default_value = 0.0
	
	    #node Subdivide Bake
	    subdivide_bake = mesh_to_strands.nodes.new("GeometryNodeBake")
	    subdivide_bake.label = "Subdivide Bake"
	    subdivide_bake.name = "Subdivide Bake"
	    subdivide_bake.active_index = 0
	    subdivide_bake.bake_items.clear()
	    subdivide_bake.bake_items.new('GEOMETRY', "Geometry")
	    subdivide_bake.bake_items[0].attribute_domain = 'POINT'
	    subdivide_bake.inputs[1].hide = True
	    subdivide_bake.outputs[1].hide = True
	
	    #node Mesh to Strands Bake
	    mesh_to_strands_bake = mesh_to_strands.nodes.new("GeometryNodeBake")
	    mesh_to_strands_bake.label = "Mesh to Strands Bake"
	    mesh_to_strands_bake.name = "Mesh to Strands Bake"
	    mesh_to_strands_bake.active_index = 0
	    mesh_to_strands_bake.bake_items.clear()
	    mesh_to_strands_bake.bake_items.new('GEOMETRY', "Geometry")
	    mesh_to_strands_bake.bake_items[0].attribute_domain = 'POINT'
	    mesh_to_strands_bake.inputs[1].hide = True
	    mesh_to_strands_bake.outputs[1].hide = True
	
	    #node Group Input.001
	    group_input_001_1 = mesh_to_strands.nodes.new("NodeGroupInput")
	    group_input_001_1.name = "Group Input.001"
	    group_input_001_1.outputs[0].hide = True
	    group_input_001_1.outputs[1].hide = True
	    group_input_001_1.outputs[2].hide = True
	    group_input_001_1.outputs[4].hide = True
	    group_input_001_1.outputs[5].hide = True
	    group_input_001_1.outputs[6].hide = True
	    group_input_001_1.outputs[7].hide = True
	
	    #node Group Input.002
	    group_input_002 = mesh_to_strands.nodes.new("NodeGroupInput")
	    group_input_002.name = "Group Input.002"
	    group_input_002.outputs[0].hide = True
	    group_input_002.outputs[1].hide = True
	    group_input_002.outputs[3].hide = True
	    group_input_002.outputs[4].hide = True
	    group_input_002.outputs[5].hide = True
	    group_input_002.outputs[6].hide = True
	    group_input_002.outputs[7].hide = True
	
	    #node Group Input.003
	    group_input_003 = mesh_to_strands.nodes.new("NodeGroupInput")
	    group_input_003.name = "Group Input.003"
	    group_input_003.outputs[0].hide = True
	    group_input_003.outputs[1].hide = True
	    group_input_003.outputs[2].hide = True
	    group_input_003.outputs[3].hide = True
	    group_input_003.outputs[4].hide = True
	    group_input_003.outputs[6].hide = True
	    group_input_003.outputs[7].hide = True
	
	    #node Group Input.004
	    group_input_004 = mesh_to_strands.nodes.new("NodeGroupInput")
	    group_input_004.name = "Group Input.004"
	    group_input_004.outputs[0].hide = True
	    group_input_004.outputs[1].hide = True
	    group_input_004.outputs[2].hide = True
	    group_input_004.outputs[3].hide = True
	    group_input_004.outputs[5].hide = True
	    group_input_004.outputs[6].hide = True
	    group_input_004.outputs[7].hide = True
	
	    #node Group Input.005
	    group_input_005 = mesh_to_strands.nodes.new("NodeGroupInput")
	    group_input_005.name = "Group Input.005"
	    group_input_005.outputs[0].hide = True
	    group_input_005.outputs[1].hide = True
	    group_input_005.outputs[2].hide = True
	    group_input_005.outputs[3].hide = True
	    group_input_005.outputs[4].hide = True
	    group_input_005.outputs[5].hide = True
	    group_input_005.outputs[7].hide = True
	
	
	
	
	    #Set parents
	    map_range_001.parent = frame_003
	    trim_shape.parent = frame_003
	    random_value.parent = frame_003
	    strand_shape.parent = frame_003
	    hair_fadeout.parent = frame_003
	    spline_parameter_002.parent = frame_003
	    map_range_002.parent = frame_003
	    group_input_003.parent = frame_003
	    group_input_004.parent = frame_003
	
	    #Set locations
	    group_output_1.location = (-311.6728515625, 182.35992431640625)
	    group_input_1.location = (-1495.008056640625, -70.43521118164062)
	    shortest_edge_paths.location = (-1879.842041015625, -309.317626953125)
	    edge_vertices.location = (-1878.0546875, -216.49757385253906)
	    evaluate_at_index.location = (-1684.451904296875, -141.1178741455078)
	    evaluate_at_index_001.location = (-1684.282958984375, -305.86328125)
	    compare_002.location = (-1490.848876953125, -163.2925567626953)
	    named_attribute.location = (-2385.718017578125, -331.6299133300781)
	    separate_xyz.location = (-2211.636962890625, -353.7036437988281)
	    compare_005.location = (-2046.370361328125, -333.7033996582031)
	    delete_geometry.location = (-1312.639404296875, 103.10943603515625)
	    mesh_to_curve.location = (-1311.537109375, 139.97247314453125)
	    subdivide_mesh.location = (-1312.422119140625, -46.22938537597656)
	    set_material_002.location = (-1104.4716796875, 190.73081970214844)
	    set_curve_radius.location = (-675.178955078125, 182.86843872070312)
	    map_range.location = (-676.05224609375, 73.86978149414062)
	    map_range_001.location = (675.9549560546875, -73.31365966796875)
	    trim_shape.location = (412.5455322265625, -40.33319091796875)
	    random_value.location = (250.141845703125, -305.07757568359375)
	    strand_shape.location = (707.562744140625, -340.84307861328125)
	    hair_fadeout.location = (192.409423828125, -414.34478759765625)
	    spline_parameter_002.location = (30.21435546875, -553.3194580078125)
	    frame_003.location = (-2441.0, -479.0)
	    map_range_002.location = (528.3743896484375, -604.0279541015625)
	    trim_curve.location = (-887.9752197265625, 157.05897521972656)
	    subdivide_bake.location = (-1313.263916015625, 72.80914306640625)
	    mesh_to_strands_bake.location = (-488.5013122558594, 230.3529815673828)
	    group_input_001_1.location = (-677.0774536132812, 41.92536926269531)
	    group_input_002.location = (-1106.1558837890625, 88.88201904296875)
	    group_input_003.location = (674.4658203125, -102.9271240234375)
	    group_input_004.location = (71.07421875, -279.01458740234375)
	    group_input_005.location = (-2557.647705078125, -402.4859924316406)
	
	    #Set dimensions
	    group_output_1.width, group_output_1.height = 140.0, 100.0
	    group_input_1.width, group_input_1.height = 140.0, 100.0
	    shortest_edge_paths.width, shortest_edge_paths.height = 140.0, 100.0
	    edge_vertices.width, edge_vertices.height = 140.0, 100.0
	    evaluate_at_index.width, evaluate_at_index.height = 140.0, 100.0
	    evaluate_at_index_001.width, evaluate_at_index_001.height = 140.0, 100.0
	    compare_002.width, compare_002.height = 140.0, 100.0
	    named_attribute.width, named_attribute.height = 140.0, 100.0
	    separate_xyz.width, separate_xyz.height = 140.0, 100.0
	    compare_005.width, compare_005.height = 140.0, 100.0
	    delete_geometry.width, delete_geometry.height = 140.0, 100.0
	    mesh_to_curve.width, mesh_to_curve.height = 140.0, 100.0
	    subdivide_mesh.width, subdivide_mesh.height = 140.0, 100.0
	    set_material_002.width, set_material_002.height = 140.0, 100.0
	    set_curve_radius.width, set_curve_radius.height = 140.0, 100.0
	    map_range.width, map_range.height = 140.0, 100.0
	    map_range_001.width, map_range_001.height = 140.0, 100.0
	    trim_shape.width, trim_shape.height = 240.0, 100.0
	    random_value.width, random_value.height = 140.0, 100.0
	    strand_shape.width, strand_shape.height = 240.0, 100.0
	    hair_fadeout.width, hair_fadeout.height = 240.0, 100.0
	    spline_parameter_002.width, spline_parameter_002.height = 140.0, 100.0
	    frame_003.width, frame_003.height = 978.0, 660.0
	    map_range_002.width, map_range_002.height = 140.0, 100.0
	    trim_curve.width, trim_curve.height = 140.0, 100.0
	    subdivide_bake.width, subdivide_bake.height = 140.0, 100.0
	    mesh_to_strands_bake.width, mesh_to_strands_bake.height = 140.0, 100.0
	    group_input_001_1.width, group_input_001_1.height = 140.0, 100.0
	    group_input_002.width, group_input_002.height = 140.0, 100.0
	    group_input_003.width, group_input_003.height = 140.0, 100.0
	    group_input_004.width, group_input_004.height = 140.0, 100.0
	    group_input_005.width, group_input_005.height = 140.0, 100.0
	
	    #initialize mesh_to_strands links
	    #map_range_001.Result -> trim_curve.End
	    mesh_to_strands.links.new(map_range_001.outputs[0], trim_curve.inputs[3])
	    #compare_002.Result -> delete_geometry.Selection
	    mesh_to_strands.links.new(compare_002.outputs[0], delete_geometry.inputs[1])
	    #set_material_002.Geometry -> trim_curve.Curve
	    mesh_to_strands.links.new(set_material_002.outputs[0], trim_curve.inputs[0])
	    #shortest_edge_paths.Total Cost -> evaluate_at_index.Value
	    mesh_to_strands.links.new(shortest_edge_paths.outputs[1], evaluate_at_index.inputs[1])
	    #map_range_002.Result -> strand_shape.Value
	    mesh_to_strands.links.new(map_range_002.outputs[0], strand_shape.inputs[1])
	    #compare_005.Result -> shortest_edge_paths.End Vertex
	    mesh_to_strands.links.new(compare_005.outputs[0], shortest_edge_paths.inputs[0])
	    #hair_fadeout.Color -> map_range_002.Value
	    mesh_to_strands.links.new(hair_fadeout.outputs[0], map_range_002.inputs[0])
	    #shortest_edge_paths.Total Cost -> evaluate_at_index_001.Value
	    mesh_to_strands.links.new(shortest_edge_paths.outputs[1], evaluate_at_index_001.inputs[1])
	    #spline_parameter_002.Factor -> hair_fadeout.Fac
	    mesh_to_strands.links.new(spline_parameter_002.outputs[0], hair_fadeout.inputs[0])
	    #evaluate_at_index.Value -> compare_002.A
	    mesh_to_strands.links.new(evaluate_at_index.outputs[0], compare_002.inputs[2])
	    #random_value.Value -> trim_shape.Value
	    mesh_to_strands.links.new(random_value.outputs[1], trim_shape.inputs[1])
	    #evaluate_at_index_001.Value -> compare_002.B
	    mesh_to_strands.links.new(evaluate_at_index_001.outputs[0], compare_002.inputs[3])
	    #trim_shape.Value -> map_range_001.Value
	    mesh_to_strands.links.new(trim_shape.outputs[0], map_range_001.inputs[0])
	    #edge_vertices.Vertex Index 1 -> evaluate_at_index.Index
	    mesh_to_strands.links.new(edge_vertices.outputs[0], evaluate_at_index.inputs[0])
	    #map_range.Result -> set_curve_radius.Radius
	    mesh_to_strands.links.new(map_range.outputs[0], set_curve_radius.inputs[2])
	    #named_attribute.Attribute -> separate_xyz.Vector
	    mesh_to_strands.links.new(named_attribute.outputs[0], separate_xyz.inputs[0])
	    #subdivide_bake.Geometry -> delete_geometry.Geometry
	    mesh_to_strands.links.new(subdivide_bake.outputs[0], delete_geometry.inputs[0])
	    #mesh_to_curve.Curve -> set_material_002.Geometry
	    mesh_to_strands.links.new(mesh_to_curve.outputs[0], set_material_002.inputs[0])
	    #edge_vertices.Vertex Index 2 -> evaluate_at_index_001.Index
	    mesh_to_strands.links.new(edge_vertices.outputs[1], evaluate_at_index_001.inputs[0])
	    #subdivide_mesh.Mesh -> subdivide_bake.Geometry
	    mesh_to_strands.links.new(subdivide_mesh.outputs[0], subdivide_bake.inputs[0])
	    #delete_geometry.Geometry -> mesh_to_curve.Mesh
	    mesh_to_strands.links.new(delete_geometry.outputs[0], mesh_to_curve.inputs[0])
	    #strand_shape.Value -> map_range.Value
	    mesh_to_strands.links.new(strand_shape.outputs[0], map_range.inputs[0])
	    #separate_xyz.X -> compare_005.A
	    mesh_to_strands.links.new(separate_xyz.outputs[0], compare_005.inputs[0])
	    #group_input_1.Geometry -> subdivide_mesh.Mesh
	    mesh_to_strands.links.new(group_input_1.outputs[0], subdivide_mesh.inputs[0])
	    #group_input_1.Level -> subdivide_mesh.Level
	    mesh_to_strands.links.new(group_input_1.outputs[1], subdivide_mesh.inputs[1])
	    #trim_curve.Curve -> set_curve_radius.Curve
	    mesh_to_strands.links.new(trim_curve.outputs[0], set_curve_radius.inputs[0])
	    #mesh_to_strands_bake.Geometry -> group_output_1.Geometry
	    mesh_to_strands.links.new(mesh_to_strands_bake.outputs[0], group_output_1.inputs[0])
	    #group_input_002.Material -> set_material_002.Material
	    mesh_to_strands.links.new(group_input_002.outputs[2], set_material_002.inputs[2])
	    #group_input_001_1.Strand Radius -> map_range.To Max
	    mesh_to_strands.links.new(group_input_001_1.outputs[3], map_range.inputs[4])
	    #group_input_004.Trim Seed -> random_value.Seed
	    mesh_to_strands.links.new(group_input_004.outputs[4], random_value.inputs[8])
	    #group_input_003.Trim Factor -> map_range_001.To Min
	    mesh_to_strands.links.new(group_input_003.outputs[5], map_range_001.inputs[3])
	    #group_input_005.UV Map -> named_attribute.Name
	    mesh_to_strands.links.new(group_input_005.outputs[6], named_attribute.inputs[0])
	    #set_curve_radius.Curve -> mesh_to_strands_bake.Geometry
	    mesh_to_strands.links.new(set_curve_radius.outputs[0], mesh_to_strands_bake.inputs[0])
	    return mesh_to_strands
	
	mesh_to_strands = mesh_to_strands_node_group()
	
	#initialize curve_root node group
	def curve_root_node_group():
	    curve_root = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Curve Root")
	
	    curve_root.color_tag = 'INPUT'
	    curve_root.description = "Reads information about each curve's root point"
	    curve_root.default_group_node_width = 140
	    
	
	
	    #curve_root interface
	    #Socket Root Selection
	    root_selection_socket = curve_root.interface.new_socket(name = "Root Selection", in_out='OUTPUT', socket_type = 'NodeSocketBool')
	    root_selection_socket.default_value = False
	    root_selection_socket.attribute_domain = 'POINT'
	    root_selection_socket.description = "Boolean selection of curve root points"
	
	    #Socket Root Position
	    root_position_socket = curve_root.interface.new_socket(name = "Root Position", in_out='OUTPUT', socket_type = 'NodeSocketVector')
	    root_position_socket.default_value = (0.0, 0.0, 0.0)
	    root_position_socket.min_value = -3.4028234663852886e+38
	    root_position_socket.max_value = 3.4028234663852886e+38
	    root_position_socket.subtype = 'NONE'
	    root_position_socket.attribute_domain = 'CURVE'
	    root_position_socket.description = "Position of the root point of a curve"
	
	    #Socket Root Direction
	    root_direction_socket = curve_root.interface.new_socket(name = "Root Direction", in_out='OUTPUT', socket_type = 'NodeSocketVector')
	    root_direction_socket.default_value = (0.0, 0.0, 0.0)
	    root_direction_socket.min_value = -3.4028234663852886e+38
	    root_direction_socket.max_value = 3.4028234663852886e+38
	    root_direction_socket.subtype = 'NONE'
	    root_direction_socket.attribute_domain = 'CURVE'
	    root_direction_socket.description = "Direction of the root segment of a curve"
	
	    #Socket Root Index
	    root_index_socket = curve_root.interface.new_socket(name = "Root Index", in_out='OUTPUT', socket_type = 'NodeSocketInt')
	    root_index_socket.default_value = 0
	    root_index_socket.min_value = -2147483648
	    root_index_socket.max_value = 2147483647
	    root_index_socket.subtype = 'NONE'
	    root_index_socket.attribute_domain = 'CURVE'
	    root_index_socket.description = "Index of the root point of a curve"
	
	
	    #initialize curve_root nodes
	    #node Position.002
	    position_002 = curve_root.nodes.new("GeometryNodeInputPosition")
	    position_002.name = "Position.002"
	
	    #node Interpolate Domain
	    interpolate_domain = curve_root.nodes.new("GeometryNodeFieldOnDomain")
	    interpolate_domain.name = "Interpolate Domain"
	    interpolate_domain.data_type = 'INT'
	    interpolate_domain.domain = 'CURVE'
	
	    #node Field at Index.003
	    field_at_index_003 = curve_root.nodes.new("GeometryNodeFieldAtIndex")
	    field_at_index_003.name = "Field at Index.003"
	    field_at_index_003.data_type = 'FLOAT_VECTOR'
	    field_at_index_003.domain = 'POINT'
	
	    #node Interpolate Domain.001
	    interpolate_domain_001 = curve_root.nodes.new("GeometryNodeFieldOnDomain")
	    interpolate_domain_001.name = "Interpolate Domain.001"
	    interpolate_domain_001.data_type = 'FLOAT_VECTOR'
	    interpolate_domain_001.domain = 'CURVE'
	
	    #node Curve Tangent
	    curve_tangent = curve_root.nodes.new("GeometryNodeInputTangent")
	    curve_tangent.name = "Curve Tangent"
	
	    #node Endpoint Selection
	    endpoint_selection = curve_root.nodes.new("GeometryNodeCurveEndpointSelection")
	    endpoint_selection.name = "Endpoint Selection"
	    #Start Size
	    endpoint_selection.inputs[0].default_value = 1
	    #End Size
	    endpoint_selection.inputs[1].default_value = 0
	
	    #node Field at Index.004
	    field_at_index_004 = curve_root.nodes.new("GeometryNodeFieldAtIndex")
	    field_at_index_004.name = "Field at Index.004"
	    field_at_index_004.data_type = 'FLOAT_VECTOR'
	    field_at_index_004.domain = 'POINT'
	
	    #node Interpolate Domain.002
	    interpolate_domain_002 = curve_root.nodes.new("GeometryNodeFieldOnDomain")
	    interpolate_domain_002.name = "Interpolate Domain.002"
	    interpolate_domain_002.data_type = 'FLOAT_VECTOR'
	    interpolate_domain_002.domain = 'CURVE'
	
	    #node Group Output
	    group_output_2 = curve_root.nodes.new("NodeGroupOutput")
	    group_output_2.name = "Group Output"
	    group_output_2.is_active_output = True
	
	    #node Points of Curve
	    points_of_curve = curve_root.nodes.new("GeometryNodePointsOfCurve")
	    points_of_curve.name = "Points of Curve"
	    points_of_curve.inputs[0].hide = True
	    points_of_curve.inputs[1].hide = True
	    points_of_curve.outputs[1].hide = True
	    #Curve Index
	    points_of_curve.inputs[0].default_value = 0
	    #Weights
	    points_of_curve.inputs[1].default_value = 0.0
	    #Sort Index
	    points_of_curve.inputs[2].default_value = 0
	
	
	
	
	
	    #Set locations
	    position_002.location = (-608.1627807617188, -70.55814361572266)
	    interpolate_domain.location = (-608.1627807617188, 90.18604278564453)
	    field_at_index_003.location = (-407.2325439453125, 70.09302520751953)
	    interpolate_domain_001.location = (-206.30230712890625, 70.09302520751953)
	    curve_tangent.location = (-608.1627807617188, -271.4883728027344)
	    endpoint_selection.location = (-206.30230712890625, 190.65118408203125)
	    field_at_index_004.location = (-407.2325439453125, -130.83721923828125)
	    interpolate_domain_002.location = (-206.30230712890625, -130.83721923828125)
	    group_output_2.location = (75.0, 50.0)
	    points_of_curve.location = (-789.0, 50.0)
	
	    #Set dimensions
	    position_002.width, position_002.height = 140.0, 100.0
	    interpolate_domain.width, interpolate_domain.height = 140.0, 100.0
	    field_at_index_003.width, field_at_index_003.height = 140.0, 100.0
	    interpolate_domain_001.width, interpolate_domain_001.height = 140.0, 100.0
	    curve_tangent.width, curve_tangent.height = 140.0, 100.0
	    endpoint_selection.width, endpoint_selection.height = 140.0, 100.0
	    field_at_index_004.width, field_at_index_004.height = 140.0, 100.0
	    interpolate_domain_002.width, interpolate_domain_002.height = 140.0, 100.0
	    group_output_2.width, group_output_2.height = 140.0, 100.0
	    points_of_curve.width, points_of_curve.height = 140.0, 100.0
	
	    #initialize curve_root links
	    #position_002.Position -> field_at_index_003.Value
	    curve_root.links.new(position_002.outputs[0], field_at_index_003.inputs[1])
	    #interpolate_domain_001.Value -> group_output_2.Root Position
	    curve_root.links.new(interpolate_domain_001.outputs[0], group_output_2.inputs[1])
	    #interpolate_domain.Value -> field_at_index_003.Index
	    curve_root.links.new(interpolate_domain.outputs[0], field_at_index_003.inputs[0])
	    #points_of_curve.Point Index -> interpolate_domain.Value
	    curve_root.links.new(points_of_curve.outputs[0], interpolate_domain.inputs[0])
	    #interpolate_domain.Value -> group_output_2.Root Index
	    curve_root.links.new(interpolate_domain.outputs[0], group_output_2.inputs[3])
	    #endpoint_selection.Selection -> group_output_2.Root Selection
	    curve_root.links.new(endpoint_selection.outputs[0], group_output_2.inputs[0])
	    #field_at_index_003.Value -> interpolate_domain_001.Value
	    curve_root.links.new(field_at_index_003.outputs[0], interpolate_domain_001.inputs[0])
	    #interpolate_domain_002.Value -> group_output_2.Root Direction
	    curve_root.links.new(interpolate_domain_002.outputs[0], group_output_2.inputs[2])
	    #interpolate_domain.Value -> field_at_index_004.Index
	    curve_root.links.new(interpolate_domain.outputs[0], field_at_index_004.inputs[0])
	    #curve_tangent.Tangent -> field_at_index_004.Value
	    curve_root.links.new(curve_tangent.outputs[0], field_at_index_004.inputs[1])
	    #field_at_index_004.Value -> interpolate_domain_002.Value
	    curve_root.links.new(field_at_index_004.outputs[0], interpolate_domain_002.inputs[0])
	    return curve_root
	
	curve_root = curve_root_node_group()
	
	#initialize attach_hair_curves_to_surface node group
	def attach_hair_curves_to_surface_node_group():
	    attach_hair_curves_to_surface = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Attach Hair Curves to Surface")
	
	    attach_hair_curves_to_surface.color_tag = 'GEOMETRY'
	    attach_hair_curves_to_surface.description = "Attaches hair curves to a surface mesh"
	    attach_hair_curves_to_surface.default_group_node_width = 140
	    
	
	    attach_hair_curves_to_surface.is_modifier = True
	
	    #attach_hair_curves_to_surface interface
	    #Socket Geometry
	    geometry_socket_3 = attach_hair_curves_to_surface.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_3.attribute_domain = 'POINT'
	
	    #Socket Surface UV Coordinate
	    surface_uv_coordinate_socket = attach_hair_curves_to_surface.interface.new_socket(name = "Surface UV Coordinate", in_out='OUTPUT', socket_type = 'NodeSocketVector')
	    surface_uv_coordinate_socket.default_value = (0.0, 0.0, 0.0)
	    surface_uv_coordinate_socket.min_value = -3.4028234663852886e+38
	    surface_uv_coordinate_socket.max_value = 3.4028234663852886e+38
	    surface_uv_coordinate_socket.subtype = 'NONE'
	    surface_uv_coordinate_socket.attribute_domain = 'CURVE'
	    surface_uv_coordinate_socket.description = "Surface UV coordinates at the attachment point"
	
	    #Socket Surface Normal
	    surface_normal_socket = attach_hair_curves_to_surface.interface.new_socket(name = "Surface Normal", in_out='OUTPUT', socket_type = 'NodeSocketVector')
	    surface_normal_socket.default_value = (0.0, 0.0, 0.0)
	    surface_normal_socket.min_value = -3.4028234663852886e+38
	    surface_normal_socket.max_value = 3.4028234663852886e+38
	    surface_normal_socket.subtype = 'NONE'
	    surface_normal_socket.attribute_domain = 'CURVE'
	    surface_normal_socket.description = "Surface normal at the attachment point"
	
	    #Socket Geometry
	    geometry_socket_4 = attach_hair_curves_to_surface.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_4.attribute_domain = 'POINT'
	    geometry_socket_4.description = "Input Geometry (may include other than curves)"
	
	    #Socket Surface
	    surface_socket = attach_hair_curves_to_surface.interface.new_socket(name = "Surface", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    surface_socket.attribute_domain = 'POINT'
	    surface_socket.description = "Surface geometry to attach hair curves to"
	
	    #Socket Surface
	    surface_socket_1 = attach_hair_curves_to_surface.interface.new_socket(name = "Surface", in_out='INPUT', socket_type = 'NodeSocketObject')
	    surface_socket_1.attribute_domain = 'POINT'
	    surface_socket_1.description = "Surface Object to attach to (needs to have matching transforms)"
	
	    #Socket Surface UV Map
	    surface_uv_map_socket = attach_hair_curves_to_surface.interface.new_socket(name = "Surface UV Map", in_out='INPUT', socket_type = 'NodeSocketVector')
	    surface_uv_map_socket.default_value = (0.0, 0.0, 0.0)
	    surface_uv_map_socket.min_value = -3.4028234663852886e+38
	    surface_uv_map_socket.max_value = 3.4028234663852886e+38
	    surface_uv_map_socket.subtype = 'NONE'
	    surface_uv_map_socket.default_attribute_name = "UVMap"
	    surface_uv_map_socket.attribute_domain = 'POINT'
	    surface_uv_map_socket.hide_value = True
	    surface_uv_map_socket.description = "Surface UV map used for attachment"
	
	    #Socket Surface Rest Position
	    surface_rest_position_socket = attach_hair_curves_to_surface.interface.new_socket(name = "Surface Rest Position", in_out='INPUT', socket_type = 'NodeSocketBool')
	    surface_rest_position_socket.default_value = False
	    surface_rest_position_socket.attribute_domain = 'POINT'
	    surface_rest_position_socket.description = "Set the surface mesh into its rest position before attachment"
	
	    #Socket Sample Attachment UV
	    sample_attachment_uv_socket = attach_hair_curves_to_surface.interface.new_socket(name = "Sample Attachment UV", in_out='INPUT', socket_type = 'NodeSocketBool')
	    sample_attachment_uv_socket.default_value = True
	    sample_attachment_uv_socket.attribute_domain = 'POINT'
	    sample_attachment_uv_socket.description = "Sample the surface UV map at the attachment point"
	
	    #Socket Snap to Surface
	    snap_to_surface_socket = attach_hair_curves_to_surface.interface.new_socket(name = "Snap to Surface", in_out='INPUT', socket_type = 'NodeSocketBool')
	    snap_to_surface_socket.default_value = True
	    snap_to_surface_socket.attribute_domain = 'POINT'
	    snap_to_surface_socket.description = "Snap the root of each curve to the closest surface point"
	
	    #Socket Align to Surface Normal
	    align_to_surface_normal_socket = attach_hair_curves_to_surface.interface.new_socket(name = "Align to Surface Normal", in_out='INPUT', socket_type = 'NodeSocketBool')
	    align_to_surface_normal_socket.default_value = True
	    align_to_surface_normal_socket.attribute_domain = 'POINT'
	    align_to_surface_normal_socket.description = "Align the curve to the surface normal (needs a guide as reference)"
	
	    #Socket Blend along Curve
	    blend_along_curve_socket = attach_hair_curves_to_surface.interface.new_socket(name = "Blend along Curve", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    blend_along_curve_socket.default_value = 0.0
	    blend_along_curve_socket.min_value = 0.0
	    blend_along_curve_socket.max_value = 1.0
	    blend_along_curve_socket.subtype = 'FACTOR'
	    blend_along_curve_socket.attribute_domain = 'POINT'
	    blend_along_curve_socket.description = "Blend deformation along each curve from the root"
	
	
	    #initialize attach_hair_curves_to_surface nodes
	    #node Frame.004
	    frame_004 = attach_hair_curves_to_surface.nodes.new("NodeFrame")
	    frame_004.label = "Write Data"
	    frame_004.name = "Frame.004"
	    frame_004.label_size = 20
	    frame_004.shrink = True
	
	    #node Frame.005
	    frame_005 = attach_hair_curves_to_surface.nodes.new("NodeFrame")
	    frame_005.label = "Sample Surface"
	    frame_005.name = "Frame.005"
	    frame_005.label_size = 20
	    frame_005.shrink = True
	
	    #node Frame
	    frame_1 = attach_hair_curves_to_surface.nodes.new("NodeFrame")
	    frame_1.label = "Surface Geometry Input"
	    frame_1.name = "Frame"
	    frame_1.label_size = 20
	    frame_1.shrink = True
	
	    #node Frame.006
	    frame_006 = attach_hair_curves_to_surface.nodes.new("NodeFrame")
	    frame_006.label = "Geometry Socket with Priority"
	    frame_006.name = "Frame.006"
	    frame_006.label_size = 20
	    frame_006.shrink = True
	
	    #node Frame.007
	    frame_007 = attach_hair_curves_to_surface.nodes.new("NodeFrame")
	    frame_007.label = "Object in Local Space"
	    frame_007.name = "Frame.007"
	    frame_007.label_size = 20
	    frame_007.shrink = True
	
	    #node Frame.011
	    frame_011 = attach_hair_curves_to_surface.nodes.new("NodeFrame")
	    frame_011.label = "Sample Attachment UV"
	    frame_011.name = "Frame.011"
	    frame_011.label_size = 20
	    frame_011.shrink = True
	
	    #node Frame.001
	    frame_001_1 = attach_hair_curves_to_surface.nodes.new("NodeFrame")
	    frame_001_1.label = "Smooth Normals"
	    frame_001_1.name = "Frame.001"
	    frame_001_1.label_size = 20
	    frame_001_1.shrink = True
	
	    #node Frame.010
	    frame_010 = attach_hair_curves_to_surface.nodes.new("NodeFrame")
	    frame_010.label = "Calculate New Position"
	    frame_010.name = "Frame.010"
	    frame_010.use_custom_color = True
	    frame_010.color = (0.13328450918197632, 0.13328450918197632, 0.13328450918197632)
	    frame_010.label_size = 20
	    frame_010.shrink = True
	
	    #node Frame.003
	    frame_003_1 = attach_hair_curves_to_surface.nodes.new("NodeFrame")
	    frame_003_1.label = "Blend Deformation"
	    frame_003_1.name = "Frame.003"
	    frame_003_1.label_size = 20
	    frame_003_1.shrink = True
	
	    #node Frame.002
	    frame_002_1 = attach_hair_curves_to_surface.nodes.new("NodeFrame")
	    frame_002_1.label = "Align to Normal"
	    frame_002_1.name = "Frame.002"
	    frame_002_1.use_custom_color = True
	    frame_002_1.color = (0.08883915841579437, 0.08883915841579437, 0.08883915841579437)
	    frame_002_1.label_size = 20
	    frame_002_1.shrink = True
	
	    #node Frame.008
	    frame_008 = attach_hair_curves_to_surface.nodes.new("NodeFrame")
	    frame_008.label = "Optimize"
	    frame_008.name = "Frame.008"
	    frame_008.label_size = 20
	    frame_008.shrink = True
	
	    #node Frame.009
	    frame_009 = attach_hair_curves_to_surface.nodes.new("NodeFrame")
	    frame_009.label = "Sample from Guide"
	    frame_009.name = "Frame.009"
	    frame_009.label_size = 20
	    frame_009.shrink = True
	
	    #node Reroute.010
	    reroute_010 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_010.name = "Reroute.010"
	    reroute_010.socket_idname = "NodeSocketGeometry"
	    #node Reroute.013
	    reroute_013 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_013.name = "Reroute.013"
	    reroute_013.socket_idname = "NodeSocketBool"
	    #node Group Output
	    group_output_3 = attach_hair_curves_to_surface.nodes.new("NodeGroupOutput")
	    group_output_3.name = "Group Output"
	    group_output_3.is_active_output = True
	
	    #node Reroute.003
	    reroute_003 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_003.name = "Reroute.003"
	    reroute_003.socket_idname = "NodeSocketVector"
	    #node Switch
	    switch = attach_hair_curves_to_surface.nodes.new("GeometryNodeSwitch")
	    switch.name = "Switch"
	    switch.input_type = 'GEOMETRY'
	
	    #node Store Named Attribute
	    store_named_attribute = attach_hair_curves_to_surface.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute.name = "Store Named Attribute"
	    store_named_attribute.data_type = 'FLOAT2'
	    store_named_attribute.domain = 'CURVE'
	    #Selection
	    store_named_attribute.inputs[1].default_value = True
	    #Name
	    store_named_attribute.inputs[2].default_value = "surface_uv_coordinate"
	
	    #node Group Input.007
	    group_input_007 = attach_hair_curves_to_surface.nodes.new("NodeGroupInput")
	    group_input_007.name = "Group Input.007"
	    group_input_007.outputs[0].hide = True
	    group_input_007.outputs[1].hide = True
	    group_input_007.outputs[2].hide = True
	    group_input_007.outputs[3].hide = True
	    group_input_007.outputs[4].hide = True
	    group_input_007.outputs[6].hide = True
	    group_input_007.outputs[7].hide = True
	    group_input_007.outputs[8].hide = True
	    group_input_007.outputs[9].hide = True
	
	    #node Reroute.016
	    reroute_016 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_016.name = "Reroute.016"
	    reroute_016.socket_idname = "NodeSocketGeometry"
	    #node Reroute.005
	    reroute_005 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_005.name = "Reroute.005"
	    reroute_005.socket_idname = "NodeSocketVector"
	    #node Store Named Attribute.001
	    store_named_attribute_001 = attach_hair_curves_to_surface.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_001.name = "Store Named Attribute.001"
	    store_named_attribute_001.data_type = 'FLOAT_VECTOR'
	    store_named_attribute_001.domain = 'CURVE'
	    #Selection
	    store_named_attribute_001.inputs[1].default_value = True
	    #Name
	    store_named_attribute_001.inputs[2].default_value = "surface_normal"
	
	    #node Named Attribute.004
	    named_attribute_004 = attach_hair_curves_to_surface.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute_004.name = "Named Attribute.004"
	    named_attribute_004.data_type = 'FLOAT_VECTOR'
	    #Name
	    named_attribute_004.inputs[0].default_value = "surface_normal"
	
	    #node Reroute.012
	    reroute_012 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_012.name = "Reroute.012"
	    reroute_012.socket_idname = "NodeSocketBool"
	    #node Reroute.014
	    reroute_014 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_014.name = "Reroute.014"
	    reroute_014.socket_idname = "NodeSocketBool"
	    #node Reroute.006
	    reroute_006 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_006.name = "Reroute.006"
	    reroute_006.socket_idname = "NodeSocketGeometry"
	    #node Named Attribute.003
	    named_attribute_003 = attach_hair_curves_to_surface.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute_003.name = "Named Attribute.003"
	    named_attribute_003.data_type = 'FLOAT_VECTOR'
	    #Name
	    named_attribute_003.inputs[0].default_value = "surface_uv_coordinate"
	
	    #node Switch.008
	    switch_008 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSwitch")
	    switch_008.name = "Switch.008"
	    switch_008.input_type = 'GEOMETRY'
	
	    #node Switch.009
	    switch_009 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSwitch")
	    switch_009.name = "Switch.009"
	    switch_009.input_type = 'VECTOR'
	
	    #node Switch.010
	    switch_010 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSwitch")
	    switch_010.name = "Switch.010"
	    switch_010.input_type = 'VECTOR'
	
	    #node Set Position.001
	    set_position_001 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSetPosition")
	    set_position_001.name = "Set Position.001"
	    set_position_001.inputs[2].hide = True
	    #Position
	    set_position_001.inputs[2].default_value = (0.0, 0.0, 0.0)
	
	    #node Reroute.002
	    reroute_002 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_002.name = "Reroute.002"
	    reroute_002.socket_idname = "NodeSocketVector"
	    #node Reroute.018
	    reroute_018 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_018.name = "Reroute.018"
	    reroute_018.socket_idname = "NodeSocketVector"
	    #node Reroute.017
	    reroute_017 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_017.name = "Reroute.017"
	    reroute_017.socket_idname = "NodeSocketGeometry"
	    #node Group Input.009
	    group_input_009 = attach_hair_curves_to_surface.nodes.new("NodeGroupInput")
	    group_input_009.name = "Group Input.009"
	    group_input_009.outputs[0].hide = True
	    group_input_009.outputs[1].hide = True
	    group_input_009.outputs[2].hide = True
	    group_input_009.outputs[4].hide = True
	    group_input_009.outputs[5].hide = True
	    group_input_009.outputs[6].hide = True
	    group_input_009.outputs[7].hide = True
	    group_input_009.outputs[8].hide = True
	    group_input_009.outputs[9].hide = True
	
	    #node Position
	    position_1 = attach_hair_curves_to_surface.nodes.new("GeometryNodeInputPosition")
	    position_1.name = "Position"
	
	    #node Named Attribute.001
	    named_attribute_001 = attach_hair_curves_to_surface.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute_001.name = "Named Attribute.001"
	    named_attribute_001.data_type = 'FLOAT_VECTOR'
	    #Name
	    named_attribute_001.inputs[0].default_value = "surface_uv_coordinate"
	
	    #node Capture Attribute.001
	    capture_attribute_001 = attach_hair_curves_to_surface.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_001.name = "Capture Attribute.001"
	    capture_attribute_001.active_index = 0
	    capture_attribute_001.capture_items.clear()
	    capture_attribute_001.capture_items.new('FLOAT', "Value")
	    capture_attribute_001.capture_items["Value"].data_type = 'FLOAT_VECTOR'
	    capture_attribute_001.domain = 'CURVE'
	
	    #node Group Input.004
	    group_input_004_1 = attach_hair_curves_to_surface.nodes.new("NodeGroupInput")
	    group_input_004_1.name = "Group Input.004"
	    group_input_004_1.outputs[0].hide = True
	    group_input_004_1.outputs[2].hide = True
	    group_input_004_1.outputs[3].hide = True
	    group_input_004_1.outputs[4].hide = True
	    group_input_004_1.outputs[5].hide = True
	    group_input_004_1.outputs[6].hide = True
	    group_input_004_1.outputs[7].hide = True
	    group_input_004_1.outputs[8].hide = True
	    group_input_004_1.outputs[9].hide = True
	
	    #node Domain Size.002
	    domain_size_002 = attach_hair_curves_to_surface.nodes.new("GeometryNodeAttributeDomainSize")
	    domain_size_002.name = "Domain Size.002"
	    domain_size_002.component = 'MESH'
	    domain_size_002.outputs[0].hide = True
	    domain_size_002.outputs[1].hide = True
	    domain_size_002.outputs[3].hide = True
	    domain_size_002.outputs[4].hide = True
	    domain_size_002.outputs[5].hide = True
	
	    #node Compare.001
	    compare_001 = attach_hair_curves_to_surface.nodes.new("FunctionNodeCompare")
	    compare_001.name = "Compare.001"
	    compare_001.data_type = 'INT'
	    compare_001.mode = 'ELEMENT'
	    compare_001.operation = 'NOT_EQUAL'
	    #B_INT
	    compare_001.inputs[3].default_value = 0
	
	    #node Object Info.001
	    object_info_001 = attach_hair_curves_to_surface.nodes.new("GeometryNodeObjectInfo")
	    object_info_001.name = "Object Info.001"
	    object_info_001.transform_space = 'ORIGINAL'
	    object_info_001.inputs[1].hide = True
	    object_info_001.outputs[1].hide = True
	    object_info_001.outputs[3].hide = True
	    #As Instance
	    object_info_001.inputs[1].default_value = False
	
	    #node Group Input.002
	    group_input_002_1 = attach_hair_curves_to_surface.nodes.new("NodeGroupInput")
	    group_input_002_1.name = "Group Input.002"
	    group_input_002_1.outputs[0].hide = True
	    group_input_002_1.outputs[1].hide = True
	    group_input_002_1.outputs[3].hide = True
	    group_input_002_1.outputs[4].hide = True
	    group_input_002_1.outputs[5].hide = True
	    group_input_002_1.outputs[6].hide = True
	    group_input_002_1.outputs[7].hide = True
	    group_input_002_1.outputs[8].hide = True
	    group_input_002_1.outputs[9].hide = True
	
	    #node Switch.005
	    switch_005 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSwitch")
	    switch_005.name = "Switch.005"
	    switch_005.input_type = 'GEOMETRY'
	
	    #node Domain Size.003
	    domain_size_003 = attach_hair_curves_to_surface.nodes.new("GeometryNodeAttributeDomainSize")
	    domain_size_003.name = "Domain Size.003"
	    domain_size_003.component = 'MESH'
	    domain_size_003.outputs[0].hide = True
	    domain_size_003.outputs[1].hide = True
	    domain_size_003.outputs[3].hide = True
	    domain_size_003.outputs[4].hide = True
	    domain_size_003.outputs[5].hide = True
	
	    #node Compare.002
	    compare_002_1 = attach_hair_curves_to_surface.nodes.new("FunctionNodeCompare")
	    compare_002_1.name = "Compare.002"
	    compare_002_1.data_type = 'INT'
	    compare_002_1.mode = 'ELEMENT'
	    compare_002_1.operation = 'EQUAL'
	    #B_INT
	    compare_002_1.inputs[3].default_value = 0
	
	    #node Named Attribute
	    named_attribute_1 = attach_hair_curves_to_surface.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute_1.name = "Named Attribute"
	    named_attribute_1.data_type = 'FLOAT_VECTOR'
	    #Name
	    named_attribute_1.inputs[0].default_value = "rest_position"
	
	    #node Reroute
	    reroute_1 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_1.name = "Reroute"
	    reroute_1.socket_idname = "NodeSocketGeometry"
	    #node Group Input.005
	    group_input_005_1 = attach_hair_curves_to_surface.nodes.new("NodeGroupInput")
	    group_input_005_1.name = "Group Input.005"
	    group_input_005_1.outputs[0].hide = True
	    group_input_005_1.outputs[1].hide = True
	    group_input_005_1.outputs[2].hide = True
	    group_input_005_1.outputs[3].hide = True
	    group_input_005_1.outputs[5].hide = True
	    group_input_005_1.outputs[6].hide = True
	    group_input_005_1.outputs[7].hide = True
	    group_input_005_1.outputs[8].hide = True
	    group_input_005_1.outputs[9].hide = True
	
	    #node Set Position
	    set_position_1 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSetPosition")
	    set_position_1.name = "Set Position"
	    set_position_1.inputs[3].hide = True
	    #Offset
	    set_position_1.inputs[3].default_value = (0.0, 0.0, 0.0)
	
	    #node Switch.007
	    switch_007 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSwitch")
	    switch_007.name = "Switch.007"
	    switch_007.input_type = 'GEOMETRY'
	
	    #node Reroute.015
	    reroute_015 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_015.name = "Reroute.015"
	    reroute_015.socket_idname = "NodeSocketBool"
	    #node Reroute.011
	    reroute_011 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_011.name = "Reroute.011"
	    reroute_011.socket_idname = "NodeSocketGeometry"
	    #node Group Input
	    group_input_2 = attach_hair_curves_to_surface.nodes.new("NodeGroupInput")
	    group_input_2.name = "Group Input"
	    group_input_2.outputs[1].hide = True
	    group_input_2.outputs[2].hide = True
	    group_input_2.outputs[3].hide = True
	    group_input_2.outputs[4].hide = True
	    group_input_2.outputs[5].hide = True
	    group_input_2.outputs[6].hide = True
	    group_input_2.outputs[7].hide = True
	    group_input_2.outputs[8].hide = True
	    group_input_2.outputs[9].hide = True
	
	    #node Capture Attribute.002
	    capture_attribute_002 = attach_hair_curves_to_surface.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_002.name = "Capture Attribute.002"
	    capture_attribute_002.active_index = 0
	    capture_attribute_002.capture_items.clear()
	    capture_attribute_002.capture_items.new('FLOAT', "Value")
	    capture_attribute_002.capture_items["Value"].data_type = 'FLOAT_VECTOR'
	    capture_attribute_002.domain = 'CURVE'
	
	    #node Reroute.001
	    reroute_001_1 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_001_1.name = "Reroute.001"
	    reroute_001_1.socket_idname = "NodeSocketGeometry"
	    #node Sample Nearest Surface
	    sample_nearest_surface = attach_hair_curves_to_surface.nodes.new("GeometryNodeSampleNearestSurface")
	    sample_nearest_surface.name = "Sample Nearest Surface"
	    sample_nearest_surface.data_type = 'FLOAT_VECTOR'
	    #Group ID
	    sample_nearest_surface.inputs[2].default_value = 0
	    #Sample Group ID
	    sample_nearest_surface.inputs[4].default_value = 0
	
	    #node Group
	    group = attach_hair_curves_to_surface.nodes.new("GeometryNodeGroup")
	    group.name = "Group"
	    group.node_tree = curve_root
	    group.outputs[0].hide = True
	    group.outputs[2].hide = True
	    group.outputs[3].hide = True
	
	    #node Group Input.001
	    group_input_001_2 = attach_hair_curves_to_surface.nodes.new("NodeGroupInput")
	    group_input_001_2.name = "Group Input.001"
	    group_input_001_2.outputs[0].hide = True
	    group_input_001_2.outputs[1].hide = True
	    group_input_001_2.outputs[2].hide = True
	    group_input_001_2.outputs[4].hide = True
	    group_input_001_2.outputs[5].hide = True
	    group_input_001_2.outputs[6].hide = True
	    group_input_001_2.outputs[7].hide = True
	    group_input_001_2.outputs[8].hide = True
	    group_input_001_2.outputs[9].hide = True
	
	    #node Reroute.020
	    reroute_020 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_020.name = "Reroute.020"
	    reroute_020.socket_idname = "NodeSocketGeometry"
	    #node Normal
	    normal = attach_hair_curves_to_surface.nodes.new("GeometryNodeInputNormal")
	    normal.name = "Normal"
	    normal.legacy_corner_normals = True
	
	    #node Capture Attribute
	    capture_attribute = attach_hair_curves_to_surface.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute.name = "Capture Attribute"
	    capture_attribute.hide = True
	    capture_attribute.active_index = 0
	    capture_attribute.capture_items.clear()
	    capture_attribute.capture_items.new('FLOAT', "Value")
	    capture_attribute.capture_items["Value"].data_type = 'FLOAT_VECTOR'
	    capture_attribute.domain = 'POINT'
	
	    #node Sample UV Surface
	    sample_uv_surface = attach_hair_curves_to_surface.nodes.new("GeometryNodeSampleUVSurface")
	    sample_uv_surface.name = "Sample UV Surface"
	    sample_uv_surface.hide = True
	    sample_uv_surface.data_type = 'FLOAT_VECTOR'
	    sample_uv_surface.outputs[1].hide = True
	
	    #node Sample UV Surface.003
	    sample_uv_surface_003 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSampleUVSurface")
	    sample_uv_surface_003.name = "Sample UV Surface.003"
	    sample_uv_surface_003.hide = True
	    sample_uv_surface_003.data_type = 'FLOAT_VECTOR'
	    sample_uv_surface_003.outputs[1].hide = True
	
	    #node Reroute.004
	    reroute_004 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_004.name = "Reroute.004"
	    reroute_004.socket_idname = "NodeSocketVector"
	    #node Sample UV Surface.001
	    sample_uv_surface_001 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSampleUVSurface")
	    sample_uv_surface_001.name = "Sample UV Surface.001"
	    sample_uv_surface_001.hide = True
	    sample_uv_surface_001.data_type = 'FLOAT_VECTOR'
	    sample_uv_surface_001.outputs[1].hide = True
	
	    #node Group.001
	    group_001 = attach_hair_curves_to_surface.nodes.new("GeometryNodeGroup")
	    group_001.name = "Group.001"
	    group_001.node_tree = curve_root
	    group_001.outputs[0].hide = True
	    group_001.outputs[2].hide = True
	    group_001.outputs[3].hide = True
	
	    #node Position.001
	    position_001 = attach_hair_curves_to_surface.nodes.new("GeometryNodeInputPosition")
	    position_001.name = "Position.001"
	
	    #node Vector Math
	    vector_math_1 = attach_hair_curves_to_surface.nodes.new("ShaderNodeVectorMath")
	    vector_math_1.name = "Vector Math"
	    vector_math_1.operation = 'SUBTRACT'
	
	    #node Vector Math.001
	    vector_math_001 = attach_hair_curves_to_surface.nodes.new("ShaderNodeVectorMath")
	    vector_math_001.name = "Vector Math.001"
	    vector_math_001.operation = 'SUBTRACT'
	
	    #node Vector Math.004
	    vector_math_004 = attach_hair_curves_to_surface.nodes.new("ShaderNodeVectorMath")
	    vector_math_004.name = "Vector Math.004"
	    vector_math_004.operation = 'SUBTRACT'
	
	    #node Vector Math.003
	    vector_math_003 = attach_hair_curves_to_surface.nodes.new("ShaderNodeVectorMath")
	    vector_math_003.name = "Vector Math.003"
	    vector_math_003.operation = 'SUBTRACT'
	
	    #node Group Input.003
	    group_input_003_1 = attach_hair_curves_to_surface.nodes.new("NodeGroupInput")
	    group_input_003_1.name = "Group Input.003"
	    group_input_003_1.outputs[0].hide = True
	    group_input_003_1.outputs[1].hide = True
	    group_input_003_1.outputs[2].hide = True
	    group_input_003_1.outputs[3].hide = True
	    group_input_003_1.outputs[4].hide = True
	    group_input_003_1.outputs[5].hide = True
	    group_input_003_1.outputs[6].hide = True
	    group_input_003_1.outputs[8].hide = True
	    group_input_003_1.outputs[9].hide = True
	
	    #node Group Input.006
	    group_input_006 = attach_hair_curves_to_surface.nodes.new("NodeGroupInput")
	    group_input_006.name = "Group Input.006"
	    group_input_006.outputs[0].hide = True
	    group_input_006.outputs[1].hide = True
	    group_input_006.outputs[2].hide = True
	    group_input_006.outputs[3].hide = True
	    group_input_006.outputs[4].hide = True
	    group_input_006.outputs[5].hide = True
	    group_input_006.outputs[7].hide = True
	    group_input_006.outputs[8].hide = True
	    group_input_006.outputs[9].hide = True
	
	    #node Switch.003
	    switch_003 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSwitch")
	    switch_003.name = "Switch.003"
	    switch_003.hide = True
	    switch_003.input_type = 'VECTOR'
	    #False
	    switch_003.inputs[1].default_value = (0.0, 0.0, 0.0)
	
	    #node Switch.002
	    switch_002 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSwitch")
	    switch_002.name = "Switch.002"
	    switch_002.input_type = 'VECTOR'
	
	    #node Vector Math.002
	    vector_math_002 = attach_hair_curves_to_surface.nodes.new("ShaderNodeVectorMath")
	    vector_math_002.name = "Vector Math.002"
	    vector_math_002.operation = 'ADD'
	
	    #node Vector Math.005
	    vector_math_005 = attach_hair_curves_to_surface.nodes.new("ShaderNodeVectorMath")
	    vector_math_005.name = "Vector Math.005"
	    vector_math_005.operation = 'SCALE'
	
	    #node Boolean Math
	    boolean_math = attach_hair_curves_to_surface.nodes.new("FunctionNodeBooleanMath")
	    boolean_math.name = "Boolean Math"
	    boolean_math.operation = 'OR'
	
	    #node Spline Parameter
	    spline_parameter_1 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSplineParameter")
	    spline_parameter_1.name = "Spline Parameter"
	    spline_parameter_1.outputs[1].hide = True
	    spline_parameter_1.outputs[2].hide = True
	
	    #node Group Input.008
	    group_input_008 = attach_hair_curves_to_surface.nodes.new("NodeGroupInput")
	    group_input_008.name = "Group Input.008"
	    group_input_008.outputs[0].hide = True
	    group_input_008.outputs[1].hide = True
	    group_input_008.outputs[2].hide = True
	    group_input_008.outputs[3].hide = True
	    group_input_008.outputs[4].hide = True
	    group_input_008.outputs[5].hide = True
	    group_input_008.outputs[6].hide = True
	    group_input_008.outputs[7].hide = True
	    group_input_008.outputs[9].hide = True
	
	    #node Map Range
	    map_range_1 = attach_hair_curves_to_surface.nodes.new("ShaderNodeMapRange")
	    map_range_1.name = "Map Range"
	    map_range_1.hide = True
	    map_range_1.clamp = True
	    map_range_1.data_type = 'FLOAT'
	    map_range_1.interpolation_type = 'SMOOTHSTEP'
	    #From Min
	    map_range_1.inputs[1].default_value = 0.0
	    #To Min
	    map_range_1.inputs[3].default_value = 1.0
	    #To Max
	    map_range_1.inputs[4].default_value = 0.0
	
	    #node Compare
	    compare = attach_hair_curves_to_surface.nodes.new("FunctionNodeCompare")
	    compare.name = "Compare"
	    compare.data_type = 'FLOAT'
	    compare.mode = 'ELEMENT'
	    compare.operation = 'EQUAL'
	    #B
	    compare.inputs[1].default_value = 0.0
	    #Epsilon
	    compare.inputs[12].default_value = 0.0
	
	    #node Switch.004
	    switch_004 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSwitch")
	    switch_004.name = "Switch.004"
	    switch_004.input_type = 'FLOAT'
	    #True
	    switch_004.inputs[2].default_value = 1.0
	
	    #node Position.002
	    position_002_1 = attach_hair_curves_to_surface.nodes.new("GeometryNodeInputPosition")
	    position_002_1.name = "Position.002"
	
	    #node Evaluate on Domain
	    evaluate_on_domain = attach_hair_curves_to_surface.nodes.new("GeometryNodeFieldOnDomain")
	    evaluate_on_domain.name = "Evaluate on Domain"
	    evaluate_on_domain.data_type = 'FLOAT_VECTOR'
	    evaluate_on_domain.domain = 'CURVE'
	
	    #node Reroute.009
	    reroute_009 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_009.name = "Reroute.009"
	    reroute_009.socket_idname = "NodeSocketVector"
	    #node Evaluate on Domain.002
	    evaluate_on_domain_002 = attach_hair_curves_to_surface.nodes.new("GeometryNodeFieldOnDomain")
	    evaluate_on_domain_002.name = "Evaluate on Domain.002"
	    evaluate_on_domain_002.hide = True
	    evaluate_on_domain_002.data_type = 'FLOAT_VECTOR'
	    evaluate_on_domain_002.domain = 'CURVE'
	
	    #node Switch.006
	    switch_006 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSwitch")
	    switch_006.name = "Switch.006"
	    switch_006.input_type = 'VECTOR'
	
	    #node Vector Rotate
	    vector_rotate = attach_hair_curves_to_surface.nodes.new("ShaderNodeVectorRotate")
	    vector_rotate.name = "Vector Rotate"
	    vector_rotate.invert = False
	    vector_rotate.rotation_type = 'EULER_XYZ'
	    vector_rotate.inputs[1].hide = True
	    vector_rotate.inputs[2].hide = True
	    vector_rotate.inputs[3].hide = True
	    #Center
	    vector_rotate.inputs[1].default_value = (0.0, 0.0, 0.0)
	
	    #node Vector Rotate.003
	    vector_rotate_003 = attach_hair_curves_to_surface.nodes.new("ShaderNodeVectorRotate")
	    vector_rotate_003.name = "Vector Rotate.003"
	    vector_rotate_003.invert = True
	    vector_rotate_003.rotation_type = 'EULER_XYZ'
	    vector_rotate_003.inputs[1].hide = True
	    vector_rotate_003.inputs[2].hide = True
	    vector_rotate_003.inputs[3].hide = True
	    #Center
	    vector_rotate_003.inputs[1].default_value = (0.0, 0.0, 0.0)
	
	    #node Align Euler to Vector.003
	    align_euler_to_vector_003 = attach_hair_curves_to_surface.nodes.new("FunctionNodeAlignEulerToVector")
	    align_euler_to_vector_003.name = "Align Euler to Vector.003"
	    align_euler_to_vector_003.axis = 'Z'
	    align_euler_to_vector_003.pivot_axis = 'AUTO'
	    align_euler_to_vector_003.inputs[0].hide = True
	    align_euler_to_vector_003.inputs[1].hide = True
	    #Rotation
	    align_euler_to_vector_003.inputs[0].default_value = (0.0, 0.0, 0.0)
	    #Factor
	    align_euler_to_vector_003.inputs[1].default_value = 1.0
	
	    #node Align Euler to Vector.002
	    align_euler_to_vector_002 = attach_hair_curves_to_surface.nodes.new("FunctionNodeAlignEulerToVector")
	    align_euler_to_vector_002.name = "Align Euler to Vector.002"
	    align_euler_to_vector_002.axis = 'Z'
	    align_euler_to_vector_002.pivot_axis = 'AUTO'
	    align_euler_to_vector_002.inputs[0].hide = True
	    align_euler_to_vector_002.inputs[1].hide = True
	    #Rotation
	    align_euler_to_vector_002.inputs[0].default_value = (0.0, 0.0, 0.0)
	    #Factor
	    align_euler_to_vector_002.inputs[1].default_value = 1.0
	
	    #node Evaluate on Domain.003
	    evaluate_on_domain_003 = attach_hair_curves_to_surface.nodes.new("GeometryNodeFieldOnDomain")
	    evaluate_on_domain_003.name = "Evaluate on Domain.003"
	    evaluate_on_domain_003.hide = True
	    evaluate_on_domain_003.data_type = 'FLOAT_VECTOR'
	    evaluate_on_domain_003.domain = 'CURVE'
	
	    #node Switch.001
	    switch_001 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSwitch")
	    switch_001.name = "Switch.001"
	    switch_001.hide = True
	    switch_001.input_type = 'VECTOR'
	
	    #node Accumulate Field
	    accumulate_field = attach_hair_curves_to_surface.nodes.new("GeometryNodeAccumulateField")
	    accumulate_field.name = "Accumulate Field"
	    accumulate_field.hide = True
	    accumulate_field.data_type = 'FLOAT'
	    accumulate_field.domain = 'POINT'
	    #Group Index
	    accumulate_field.inputs[1].default_value = 0
	
	    #node Sample Index.001
	    sample_index_001 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSampleIndex")
	    sample_index_001.name = "Sample Index.001"
	    sample_index_001.hide = True
	    sample_index_001.clamp = False
	    sample_index_001.data_type = 'BOOLEAN'
	    sample_index_001.domain = 'CURVE'
	    #Index
	    sample_index_001.inputs[2].default_value = 0
	
	    #node Reroute.019
	    reroute_019 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_019.name = "Reroute.019"
	    reroute_019.socket_idname = "NodeSocketVector"
	    #node Named Attribute.002
	    named_attribute_002 = attach_hair_curves_to_surface.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute_002.name = "Named Attribute.002"
	    named_attribute_002.data_type = 'INT'
	    #Name
	    named_attribute_002.inputs[0].default_value = "guide_curve_index"
	
	    #node Reroute.007
	    reroute_007 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_007.name = "Reroute.007"
	    reroute_007.socket_idname = "NodeSocketGeometry"
	    #node Reroute.008
	    reroute_008 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_008.name = "Reroute.008"
	    reroute_008.socket_idname = "NodeSocketVector"
	    #node Sample Index
	    sample_index = attach_hair_curves_to_surface.nodes.new("GeometryNodeSampleIndex")
	    sample_index.name = "Sample Index"
	    sample_index.hide = True
	    sample_index.clamp = False
	    sample_index.data_type = 'FLOAT_VECTOR'
	    sample_index.domain = 'CURVE'
	
	
	
	
	    #Set parents
	    frame_006.parent = frame_1
	    frame_007.parent = frame_1
	    frame_003_1.parent = frame_010
	    frame_002_1.parent = frame_010
	    frame_008.parent = frame_002_1
	    frame_009.parent = frame_002_1
	    reroute_003.parent = frame_004
	    switch.parent = frame_004
	    store_named_attribute.parent = frame_004
	    group_input_007.parent = frame_004
	    reroute_016.parent = frame_004
	    reroute_005.parent = frame_004
	    store_named_attribute_001.parent = frame_004
	    named_attribute_004.parent = frame_004
	    reroute_012.parent = frame_004
	    named_attribute_003.parent = frame_004
	    switch_008.parent = frame_004
	    switch_009.parent = frame_004
	    switch_010.parent = frame_004
	    reroute_002.parent = frame_005
	    reroute_018.parent = frame_005
	    reroute_017.parent = frame_005
	    group_input_009.parent = frame_005
	    position_1.parent = frame_005
	    named_attribute_001.parent = frame_005
	    group_input_004_1.parent = frame_006
	    domain_size_002.parent = frame_006
	    compare_001.parent = frame_006
	    object_info_001.parent = frame_007
	    group_input_002_1.parent = frame_007
	    switch_005.parent = frame_1
	    domain_size_003.parent = frame_1
	    compare_002_1.parent = frame_1
	    named_attribute_1.parent = frame_1
	    reroute_1.parent = frame_1
	    group_input_005_1.parent = frame_1
	    set_position_1.parent = frame_1
	    switch_007.parent = frame_1
	    sample_nearest_surface.parent = frame_011
	    group.parent = frame_011
	    group_input_001_2.parent = frame_011
	    normal.parent = frame_001_1
	    capture_attribute.parent = frame_001_1
	    sample_uv_surface.parent = frame_005
	    sample_uv_surface_003.parent = frame_005
	    reroute_004.parent = frame_005
	    sample_uv_surface_001.parent = frame_005
	    group_001.parent = frame_010
	    position_001.parent = frame_010
	    vector_math_1.parent = frame_010
	    vector_math_001.parent = frame_010
	    vector_math_004.parent = frame_010
	    vector_math_003.parent = frame_010
	    group_input_003_1.parent = frame_010
	    group_input_006.parent = frame_010
	    switch_003.parent = frame_010
	    switch_002.parent = frame_010
	    vector_math_002.parent = frame_010
	    vector_math_005.parent = frame_010
	    boolean_math.parent = frame_010
	    spline_parameter_1.parent = frame_003_1
	    group_input_008.parent = frame_003_1
	    map_range_1.parent = frame_003_1
	    compare.parent = frame_003_1
	    switch_004.parent = frame_003_1
	    position_002_1.parent = frame_010
	    evaluate_on_domain.parent = frame_010
	    reroute_009.parent = frame_002_1
	    evaluate_on_domain_002.parent = frame_002_1
	    switch_006.parent = frame_002_1
	    vector_rotate.parent = frame_002_1
	    vector_rotate_003.parent = frame_002_1
	    align_euler_to_vector_003.parent = frame_002_1
	    align_euler_to_vector_002.parent = frame_002_1
	    evaluate_on_domain_003.parent = frame_002_1
	    switch_001.parent = frame_008
	    accumulate_field.parent = frame_008
	    sample_index_001.parent = frame_008
	    reroute_019.parent = frame_002_1
	    named_attribute_002.parent = frame_009
	    reroute_007.parent = frame_009
	    reroute_008.parent = frame_009
	    sample_index.parent = frame_009
	
	    #Set locations
	    frame_004.location = (-1215.903076171875, 262.0)
	    frame_005.location = (-4968.0, -121.0)
	    frame_1.location = (-7319.0, 140.0)
	    frame_006.location = (30.0, -355.0)
	    frame_007.location = (207.0, -181.0)
	    frame_011.location = (-5752.0, 120.0)
	    frame_001_1.location = (-5510.0, -382.0)
	    frame_010.location = (-4110.3515625, 32.0)
	    frame_003_1.location = (1565.3515625, -503.0)
	    frame_002_1.location = (29.999755859375, -437.0)
	    frame_008.location = (219.351806640625, -40.0)
	    frame_009.location = (30.0, -217.5032958984375)
	    reroute_010.location = (-798.60986328125, 472.99615478515625)
	    reroute_013.location = (-789.0, 512.1389770507812)
	    group_output_3.location = (75.0, 50.0)
	    reroute_003.location = (35.0, -292.3721618652344)
	    switch.location = (320.95263671875, -40.143096923828125)
	    store_named_attribute.location = (115.3720703125, -151.72100830078125)
	    group_input_007.location = (122.9049072265625, -39.53450012207031)
	    reroute_016.location = (45.1358642578125, -151.72100830078125)
	    reroute_005.location = (406.810302734375, -272.2791442871094)
	    store_named_attribute_001.location = (527.368408203125, -51.255889892578125)
	    named_attribute_004.location = (607.740478515625, -513.3954467773438)
	    reroute_012.location = (768.484619140625, -252.18612670898438)
	    reroute_014.location = (-507.69775390625, 311.209228515625)
	    reroute_006.location = (-547.8837890625, 291.1162109375)
	    named_attribute_003.location = (607.740478515625, -352.6512451171875)
	    switch_008.location = (808.670654296875, -71.34890747070312)
	    switch_009.location = (808.670654296875, -212.00006103515625)
	    switch_010.location = (808.670654296875, -392.8372802734375)
	    set_position_001.location = (-1472.16259765625, 230.837158203125)
	    reroute_002.location = (220.65625, -190.25262451171875)
	    reroute_018.location = (220.65625, -150.06658935546875)
	    reroute_017.location = (220.65625, -109.88055419921875)
	    group_input_009.location = (29.99072265625, -180.322021484375)
	    position_1.location = (29.99072265625, -39.67083740234375)
	    named_attribute_001.location = (29.99072265625, -260.694091796875)
	    capture_attribute_001.location = (-4365.55810546875, 210.744140625)
	    group_input_004_1.location = (29.669921875, -178.9044189453125)
	    domain_size_002.location = (207.6806640625, -80.07354736328125)
	    compare_001.location = (388.517578125, -39.88751220703125)
	    object_info_001.location = (210.88330078125, -39.64691162109375)
	    group_input_002_1.location = (30.0458984375, -79.83294677734375)
	    switch_005.location = (640.525390625, -283.5823974609375)
	    domain_size_003.location = (938.8193359375, -79.91128540039062)
	    compare_002_1.location = (1119.65625, -39.725250244140625)
	    named_attribute_1.location = (820.7041015625, -432.90301513671875)
	    reroute_1.location = (961.35546875, -332.43792724609375)
	    group_input_005_1.location = (1021.63427734375, -252.0657958984375)
	    set_position_1.location = (1021.63427734375, -352.53094482421875)
	    switch_007.location = (1222.564453125, -231.9727783203125)
	    reroute_015.location = (-5129.0927734375, 532.2319946289062)
	    reroute_011.location = (-5109.0, 492.04595947265625)
	    group_input_2.location = (-5510.8603515625, 351.395263671875)
	    capture_attribute_002.location = (-5209.46484375, 230.837158203125)
	    reroute_001_1.location = (-4887.9765625, -653.2559814453125)
	    sample_nearest_surface.location = (210.7509765625, -40.199798583984375)
	    group.location = (29.9140625, -180.85098266601562)
	    group_input_001_2.location = (29.9140625, -100.4788818359375)
	    reroute_020.location = (-4526.30224609375, -10.2791748046875)
	    normal.location = (29.5712890625, -45.01953125)
	    capture_attribute.location = (230.50146484375, -45.01953125)
	    sample_uv_surface.location = (321.1396484375, -50.02386474609375)
	    sample_uv_surface_003.location = (321.1396484375, -130.39593505859375)
	    reroute_004.location = (220.6748046875, -230.86102294921875)
	    sample_uv_surface_001.location = (321.1396484375, -210.76800537109375)
	    group_001.location = (158.627685546875, -240.71258544921875)
	    position_001.location = (339.46484375, -321.08465576171875)
	    vector_math_1.location = (339.46484375, -140.2474365234375)
	    vector_math_001.location = (540.39501953125, -321.08465576171875)
	    vector_math_004.location = (1826.3486328125, -341.17767333984375)
	    vector_math_003.location = (2027.27880859375, -200.52651977539062)
	    group_input_003_1.location = (1424.48828125, -220.79666137695312)
	    group_input_006.location = (1424.48828125, -100.238525390625)
	    switch_003.location = (1625.41845703125, -180.61062622070312)
	    switch_002.location = (1625.41845703125, -220.79666137695312)
	    vector_math_002.location = (1826.3486328125, -140.424560546875)
	    vector_math_005.location = (2248.30224609375, -200.70364379882812)
	    boolean_math.location = (1625.41845703125, -39.959442138671875)
	    spline_parameter_1.location = (32.72265625, -81.9400634765625)
	    group_input_008.location = (30.322265625, -161.4296875)
	    map_range_1.location = (205.259765625, -190.3057861328125)
	    compare.location = (205.20068359375, -39.6795654296875)
	    switch_004.location = (386.037841796875, -59.772705078125)
	    position_002_1.location = (1625.41845703125, -371.6761474609375)
	    evaluate_on_domain.location = (531.248291015625, -115.30325317382812)
	    reroute_009.location = (731.747802734375, -64.921875)
	    evaluate_on_domain_002.location = (630.95361328125, -265.85211181640625)
	    switch_006.location = (992.6279296875, -64.921875)
	    vector_rotate.location = (1173.465087890625, -64.921875)
	    vector_rotate_003.location = (811.790771484375, -165.386962890625)
	    align_euler_to_vector_003.location = (630.95361328125, -165.386962890625)
	    align_euler_to_vector_002.location = (630.95361328125, -306.0382080078125)
	    evaluate_on_domain_003.location = (630.95361328125, -406.5032958984375)
	    switch_001.location = (210.67138671875, -105.2939453125)
	    accumulate_field.location = (29.834228515625, -45.014892578125)
	    sample_index_001.location = (29.834228515625, -85.200927734375)
	    reroute_019.location = (48.255859375, -185.48004150390625)
	    named_attribute_002.location = (35.0, -105.279052734375)
	    reroute_007.location = (35.0, -45.0)
	    reroute_008.location = (35.0, -85.18603515625)
	    sample_index.location = (215.837158203125, -65.093017578125)
	
	    #Set dimensions
	    frame_004.width, frame_004.height = 978.903076171875, 664.0
	    frame_005.width, frame_005.height = 491.0, 412.0
	    frame_1.width, frame_1.height = 1393.0, 646.0
	    frame_006.width, frame_006.height = 559.0, 261.0
	    frame_007.width, frame_007.height = 381.0, 215.0
	    frame_011.width, frame_011.height = 390.33642578125, 279.0
	    frame_001_1.width, frame_001_1.height = 401.0, 125.0
	    frame_010.width, frame_010.height = 2418.3515625, 971.0
	    frame_003_1.width, frame_003_1.height = 556.0, 250.0
	    frame_002_1.width, frame_002_1.height = 1343.351806640625, 504.0
	    frame_008.width, frame_008.height = 381.0, 160.0
	    frame_009.width, frame_009.height = 385.351806640625, 256.4967041015625
	    reroute_010.width, reroute_010.height = 10.0, 100.0
	    reroute_013.width, reroute_013.height = 10.0, 100.0
	    group_output_3.width, group_output_3.height = 140.0, 100.0
	    reroute_003.width, reroute_003.height = 10.0, 100.0
	    switch.width, switch.height = 140.0, 100.0
	    store_named_attribute.width, store_named_attribute.height = 140.0, 100.0
	    group_input_007.width, group_input_007.height = 140.0, 100.0
	    reroute_016.width, reroute_016.height = 10.0, 100.0
	    reroute_005.width, reroute_005.height = 10.0, 100.0
	    store_named_attribute_001.width, store_named_attribute_001.height = 140.0, 100.0
	    named_attribute_004.width, named_attribute_004.height = 140.0, 100.0
	    reroute_012.width, reroute_012.height = 10.0, 100.0
	    reroute_014.width, reroute_014.height = 10.0, 100.0
	    reroute_006.width, reroute_006.height = 10.0, 100.0
	    named_attribute_003.width, named_attribute_003.height = 140.0, 100.0
	    switch_008.width, switch_008.height = 140.0, 100.0
	    switch_009.width, switch_009.height = 140.0, 100.0
	    switch_010.width, switch_010.height = 140.0, 100.0
	    set_position_001.width, set_position_001.height = 140.0, 100.0
	    reroute_002.width, reroute_002.height = 10.0, 100.0
	    reroute_018.width, reroute_018.height = 10.0, 100.0
	    reroute_017.width, reroute_017.height = 10.0, 100.0
	    group_input_009.width, group_input_009.height = 140.0, 100.0
	    position_1.width, position_1.height = 140.0, 100.0
	    named_attribute_001.width, named_attribute_001.height = 140.0, 100.0
	    capture_attribute_001.width, capture_attribute_001.height = 140.0, 100.0
	    group_input_004_1.width, group_input_004_1.height = 140.0, 100.0
	    domain_size_002.width, domain_size_002.height = 140.0, 100.0
	    compare_001.width, compare_001.height = 140.0, 100.0
	    object_info_001.width, object_info_001.height = 140.0, 100.0
	    group_input_002_1.width, group_input_002_1.height = 140.0, 100.0
	    switch_005.width, switch_005.height = 140.0, 100.0
	    domain_size_003.width, domain_size_003.height = 140.0, 100.0
	    compare_002_1.width, compare_002_1.height = 140.0, 100.0
	    named_attribute_1.width, named_attribute_1.height = 140.0, 100.0
	    reroute_1.width, reroute_1.height = 10.0, 100.0
	    group_input_005_1.width, group_input_005_1.height = 140.0, 100.0
	    set_position_1.width, set_position_1.height = 140.0, 100.0
	    switch_007.width, switch_007.height = 140.0, 100.0
	    reroute_015.width, reroute_015.height = 10.0, 100.0
	    reroute_011.width, reroute_011.height = 10.0, 100.0
	    group_input_2.width, group_input_2.height = 140.0, 100.0
	    capture_attribute_002.width, capture_attribute_002.height = 140.0, 100.0
	    reroute_001_1.width, reroute_001_1.height = 10.0, 100.0
	    sample_nearest_surface.width, sample_nearest_surface.height = 149.33627319335938, 100.0
	    group.width, group.height = 140.0, 100.0
	    group_input_001_2.width, group_input_001_2.height = 140.0, 100.0
	    reroute_020.width, reroute_020.height = 10.0, 100.0
	    normal.width, normal.height = 140.0, 100.0
	    capture_attribute.width, capture_attribute.height = 140.0, 100.0
	    sample_uv_surface.width, sample_uv_surface.height = 140.0, 100.0
	    sample_uv_surface_003.width, sample_uv_surface_003.height = 140.0, 100.0
	    reroute_004.width, reroute_004.height = 10.0, 100.0
	    sample_uv_surface_001.width, sample_uv_surface_001.height = 140.0, 100.0
	    group_001.width, group_001.height = 140.0, 100.0
	    position_001.width, position_001.height = 140.0, 100.0
	    vector_math_1.width, vector_math_1.height = 140.0, 100.0
	    vector_math_001.width, vector_math_001.height = 140.0, 100.0
	    vector_math_004.width, vector_math_004.height = 140.0, 100.0
	    vector_math_003.width, vector_math_003.height = 140.0, 100.0
	    group_input_003_1.width, group_input_003_1.height = 140.0, 100.0
	    group_input_006.width, group_input_006.height = 140.0, 100.0
	    switch_003.width, switch_003.height = 140.0, 100.0
	    switch_002.width, switch_002.height = 140.0, 100.0
	    vector_math_002.width, vector_math_002.height = 140.0, 100.0
	    vector_math_005.width, vector_math_005.height = 140.0, 100.0
	    boolean_math.width, boolean_math.height = 140.0, 100.0
	    spline_parameter_1.width, spline_parameter_1.height = 140.0, 100.0
	    group_input_008.width, group_input_008.height = 140.0, 100.0
	    map_range_1.width, map_range_1.height = 140.0, 100.0
	    compare.width, compare.height = 140.0, 100.0
	    switch_004.width, switch_004.height = 140.0, 100.0
	    position_002_1.width, position_002_1.height = 140.0, 100.0
	    evaluate_on_domain.width, evaluate_on_domain.height = 140.0, 100.0
	    reroute_009.width, reroute_009.height = 10.0, 100.0
	    evaluate_on_domain_002.width, evaluate_on_domain_002.height = 140.0, 100.0
	    switch_006.width, switch_006.height = 140.0, 100.0
	    vector_rotate.width, vector_rotate.height = 140.0, 100.0
	    vector_rotate_003.width, vector_rotate_003.height = 140.0, 100.0
	    align_euler_to_vector_003.width, align_euler_to_vector_003.height = 140.0, 100.0
	    align_euler_to_vector_002.width, align_euler_to_vector_002.height = 140.0, 100.0
	    evaluate_on_domain_003.width, evaluate_on_domain_003.height = 140.0, 100.0
	    switch_001.width, switch_001.height = 140.0, 100.0
	    accumulate_field.width, accumulate_field.height = 140.0, 100.0
	    sample_index_001.width, sample_index_001.height = 140.0, 100.0
	    reroute_019.width, reroute_019.height = 10.0, 100.0
	    named_attribute_002.width, named_attribute_002.height = 140.0, 100.0
	    reroute_007.width, reroute_007.height = 10.0, 100.0
	    reroute_008.width, reroute_008.height = 10.0, 100.0
	    sample_index.width, sample_index.height = 140.0, 100.0
	
	    #initialize attach_hair_curves_to_surface links
	    #domain_size_002.Face Count -> compare_001.A
	    attach_hair_curves_to_surface.links.new(domain_size_002.outputs[2], compare_001.inputs[2])
	    #compare_001.Result -> switch_005.Switch
	    attach_hair_curves_to_surface.links.new(compare_001.outputs[0], switch_005.inputs[0])
	    #group_input_002_1.Surface -> object_info_001.Object
	    attach_hair_curves_to_surface.links.new(group_input_002_1.outputs[2], object_info_001.inputs[0])
	    #group_input_004_1.Surface -> domain_size_002.Geometry
	    attach_hair_curves_to_surface.links.new(group_input_004_1.outputs[1], domain_size_002.inputs[0])
	    #group_input_004_1.Surface -> switch_005.True
	    attach_hair_curves_to_surface.links.new(group_input_004_1.outputs[1], switch_005.inputs[2])
	    #group_input_001_2.Surface UV Map -> sample_nearest_surface.Value
	    attach_hair_curves_to_surface.links.new(group_input_001_2.outputs[3], sample_nearest_surface.inputs[1])
	    #reroute_1.Output -> set_position_1.Geometry
	    attach_hair_curves_to_surface.links.new(reroute_1.outputs[0], set_position_1.inputs[0])
	    #reroute_1.Output -> switch_007.False
	    attach_hair_curves_to_surface.links.new(reroute_1.outputs[0], switch_007.inputs[1])
	    #set_position_1.Geometry -> switch_007.True
	    attach_hair_curves_to_surface.links.new(set_position_1.outputs[0], switch_007.inputs[2])
	    #switch_005.Output -> reroute_1.Input
	    attach_hair_curves_to_surface.links.new(switch_005.outputs[0], reroute_1.inputs[0])
	    #group_input_005_1.Surface Rest Position -> switch_007.Switch
	    attach_hair_curves_to_surface.links.new(group_input_005_1.outputs[4], switch_007.inputs[0])
	    #named_attribute_1.Attribute -> set_position_1.Position
	    attach_hair_curves_to_surface.links.new(named_attribute_1.outputs[0], set_position_1.inputs[2])
	    #named_attribute_1.Exists -> set_position_1.Selection
	    attach_hair_curves_to_surface.links.new(named_attribute_1.outputs[1], set_position_1.inputs[1])
	    #switch_007.Output -> sample_nearest_surface.Mesh
	    attach_hair_curves_to_surface.links.new(switch_007.outputs[0], sample_nearest_surface.inputs[0])
	    #object_info_001.Geometry -> switch_005.False
	    attach_hair_curves_to_surface.links.new(object_info_001.outputs[4], switch_005.inputs[1])
	    #group.Root Position -> sample_nearest_surface.Sample Position
	    attach_hair_curves_to_surface.links.new(group.outputs[1], sample_nearest_surface.inputs[3])
	    #reroute_002.Output -> sample_uv_surface.UV Map
	    attach_hair_curves_to_surface.links.new(reroute_002.outputs[0], sample_uv_surface.inputs[2])
	    #position_1.Position -> sample_uv_surface.Value
	    attach_hair_curves_to_surface.links.new(position_1.outputs[0], sample_uv_surface.inputs[1])
	    #reroute_004.Output -> sample_uv_surface.Sample UV
	    attach_hair_curves_to_surface.links.new(reroute_004.outputs[0], sample_uv_surface.inputs[3])
	    #capture_attribute_001.Geometry -> set_position_001.Geometry
	    attach_hair_curves_to_surface.links.new(capture_attribute_001.outputs[0], set_position_001.inputs[0])
	    #reroute_017.Output -> sample_uv_surface_001.Mesh
	    attach_hair_curves_to_surface.links.new(reroute_017.outputs[0], sample_uv_surface_001.inputs[0])
	    #reroute_004.Output -> sample_uv_surface_001.Sample UV
	    attach_hair_curves_to_surface.links.new(reroute_004.outputs[0], sample_uv_surface_001.inputs[3])
	    #reroute_002.Output -> sample_uv_surface_001.UV Map
	    attach_hair_curves_to_surface.links.new(reroute_002.outputs[0], sample_uv_surface_001.inputs[2])
	    #normal.Normal -> capture_attribute.Value
	    attach_hair_curves_to_surface.links.new(normal.outputs[0], capture_attribute.inputs[1])
	    #reroute_018.Output -> sample_uv_surface_001.Value
	    attach_hair_curves_to_surface.links.new(reroute_018.outputs[0], sample_uv_surface_001.inputs[1])
	    #sample_uv_surface.Value -> vector_math_1.Vector
	    attach_hair_curves_to_surface.links.new(sample_uv_surface.outputs[0], vector_math_1.inputs[0])
	    #group_001.Root Position -> vector_math_1.Vector
	    attach_hair_curves_to_surface.links.new(group_001.outputs[1], vector_math_1.inputs[1])
	    #vector_math_1.Vector -> evaluate_on_domain.Value
	    attach_hair_curves_to_surface.links.new(vector_math_1.outputs[0], evaluate_on_domain.inputs[0])
	    #position_001.Position -> vector_math_001.Vector
	    attach_hair_curves_to_surface.links.new(position_001.outputs[0], vector_math_001.inputs[0])
	    #group_001.Root Position -> vector_math_001.Vector
	    attach_hair_curves_to_surface.links.new(group_001.outputs[1], vector_math_001.inputs[1])
	    #switch_006.Output -> vector_rotate.Vector
	    attach_hair_curves_to_surface.links.new(switch_006.outputs[0], vector_rotate.inputs[0])
	    #reroute_007.Output -> sample_index.Geometry
	    attach_hair_curves_to_surface.links.new(reroute_007.outputs[0], sample_index.inputs[0])
	    #named_attribute_002.Attribute -> sample_index.Index
	    attach_hair_curves_to_surface.links.new(named_attribute_002.outputs[0], sample_index.inputs[2])
	    #position_002_1.Position -> vector_math_004.Vector
	    attach_hair_curves_to_surface.links.new(position_002_1.outputs[0], vector_math_004.inputs[0])
	    #vector_math_002.Vector -> vector_math_003.Vector
	    attach_hair_curves_to_surface.links.new(vector_math_002.outputs[0], vector_math_003.inputs[0])
	    #switch_003.Output -> vector_math_002.Vector
	    attach_hair_curves_to_surface.links.new(switch_003.outputs[0], vector_math_002.inputs[0])
	    #switch_002.Output -> vector_math_002.Vector
	    attach_hair_curves_to_surface.links.new(switch_002.outputs[0], vector_math_002.inputs[1])
	    #reroute_009.Output -> vector_rotate_003.Vector
	    attach_hair_curves_to_surface.links.new(reroute_009.outputs[0], vector_rotate_003.inputs[0])
	    #evaluate_on_domain_002.Value -> vector_rotate_003.Rotation
	    attach_hair_curves_to_surface.links.new(evaluate_on_domain_002.outputs[0], vector_rotate_003.inputs[4])
	    #evaluate_on_domain_003.Value -> vector_rotate.Rotation
	    attach_hair_curves_to_surface.links.new(evaluate_on_domain_003.outputs[0], vector_rotate.inputs[4])
	    #group_001.Root Position -> vector_math_004.Vector
	    attach_hair_curves_to_surface.links.new(group_001.outputs[1], vector_math_004.inputs[1])
	    #vector_math_004.Vector -> vector_math_003.Vector
	    attach_hair_curves_to_surface.links.new(vector_math_004.outputs[0], vector_math_003.inputs[1])
	    #reroute_016.Output -> store_named_attribute.Geometry
	    attach_hair_curves_to_surface.links.new(reroute_016.outputs[0], store_named_attribute.inputs[0])
	    #group_input_2.Geometry -> capture_attribute_002.Geometry
	    attach_hair_curves_to_surface.links.new(group_input_2.outputs[0], capture_attribute_002.inputs[0])
	    #reroute_003.Output -> store_named_attribute.Value
	    attach_hair_curves_to_surface.links.new(reroute_003.outputs[0], store_named_attribute.inputs[3])
	    #sample_nearest_surface.Value -> capture_attribute_002.Value
	    attach_hair_curves_to_surface.links.new(sample_nearest_surface.outputs[0], capture_attribute_002.inputs[1])
	    #capture_attribute_002.Value -> reroute_004.Input
	    attach_hair_curves_to_surface.links.new(capture_attribute_002.outputs[1], reroute_004.inputs[0])
	    #switch_007.Output -> capture_attribute.Geometry
	    attach_hair_curves_to_surface.links.new(switch_007.outputs[0], capture_attribute.inputs[0])
	    #align_euler_to_vector_003.Rotation -> evaluate_on_domain_002.Value
	    attach_hair_curves_to_surface.links.new(align_euler_to_vector_003.outputs[0], evaluate_on_domain_002.inputs[0])
	    #align_euler_to_vector_002.Rotation -> evaluate_on_domain_003.Value
	    attach_hair_curves_to_surface.links.new(align_euler_to_vector_002.outputs[0], evaluate_on_domain_003.inputs[0])
	    #capture_attribute.Geometry -> reroute_001_1.Input
	    attach_hair_curves_to_surface.links.new(capture_attribute.outputs[0], reroute_001_1.inputs[0])
	    #reroute_018.Output -> sample_uv_surface_003.Value
	    attach_hair_curves_to_surface.links.new(reroute_018.outputs[0], sample_uv_surface_003.inputs[1])
	    #reroute_002.Output -> sample_uv_surface_003.UV Map
	    attach_hair_curves_to_surface.links.new(reroute_002.outputs[0], sample_uv_surface_003.inputs[2])
	    #reroute_017.Output -> sample_uv_surface_003.Mesh
	    attach_hair_curves_to_surface.links.new(reroute_017.outputs[0], sample_uv_surface_003.inputs[0])
	    #named_attribute_001.Attribute -> sample_uv_surface_003.Sample UV
	    attach_hair_curves_to_surface.links.new(named_attribute_001.outputs[0], sample_uv_surface_003.inputs[3])
	    #reroute_019.Output -> switch_001.True
	    attach_hair_curves_to_surface.links.new(reroute_019.outputs[0], switch_001.inputs[2])
	    #reroute_020.Output -> sample_index_001.Geometry
	    attach_hair_curves_to_surface.links.new(reroute_020.outputs[0], sample_index_001.inputs[0])
	    #named_attribute_001.Exists -> accumulate_field.Value
	    attach_hair_curves_to_surface.links.new(named_attribute_001.outputs[1], accumulate_field.inputs[0])
	    #accumulate_field.Total -> sample_index_001.Value
	    attach_hair_curves_to_surface.links.new(accumulate_field.outputs[2], sample_index_001.inputs[1])
	    #sample_index_001.Value -> switch_001.Switch
	    attach_hair_curves_to_surface.links.new(sample_index_001.outputs[0], switch_001.inputs[0])
	    #reroute_008.Output -> sample_index.Value
	    attach_hair_curves_to_surface.links.new(reroute_008.outputs[0], sample_index.inputs[1])
	    #vector_rotate.Vector -> switch_002.True
	    attach_hair_curves_to_surface.links.new(vector_rotate.outputs[0], switch_002.inputs[2])
	    #vector_math_001.Vector -> switch_002.False
	    attach_hair_curves_to_surface.links.new(vector_math_001.outputs[0], switch_002.inputs[1])
	    #group_input_003_1.Align to Surface Normal -> switch_002.Switch
	    attach_hair_curves_to_surface.links.new(group_input_003_1.outputs[7], switch_002.inputs[0])
	    #vector_math_005.Vector -> set_position_001.Offset
	    attach_hair_curves_to_surface.links.new(vector_math_005.outputs[0], set_position_001.inputs[3])
	    #evaluate_on_domain.Value -> switch_003.True
	    attach_hair_curves_to_surface.links.new(evaluate_on_domain.outputs[0], switch_003.inputs[2])
	    #group_input_006.Snap to Surface -> switch_003.Switch
	    attach_hair_curves_to_surface.links.new(group_input_006.outputs[6], switch_003.inputs[0])
	    #group_input_006.Snap to Surface -> boolean_math.Boolean
	    attach_hair_curves_to_surface.links.new(group_input_006.outputs[6], boolean_math.inputs[0])
	    #group_input_003_1.Align to Surface Normal -> boolean_math.Boolean
	    attach_hair_curves_to_surface.links.new(group_input_003_1.outputs[7], boolean_math.inputs[1])
	    #boolean_math.Boolean -> set_position_001.Selection
	    attach_hair_curves_to_surface.links.new(boolean_math.outputs[0], set_position_001.inputs[1])
	    #capture_attribute_002.Value -> reroute_003.Input
	    attach_hair_curves_to_surface.links.new(capture_attribute_002.outputs[1], reroute_003.inputs[0])
	    #switch_009.Output -> group_output_3.Surface UV Coordinate
	    attach_hair_curves_to_surface.links.new(switch_009.outputs[0], group_output_3.inputs[1])
	    #store_named_attribute.Geometry -> switch.True
	    attach_hair_curves_to_surface.links.new(store_named_attribute.outputs[0], switch.inputs[2])
	    #group_input_007.Sample Attachment UV -> switch.Switch
	    attach_hair_curves_to_surface.links.new(group_input_007.outputs[5], switch.inputs[0])
	    #reroute_016.Output -> switch.False
	    attach_hair_curves_to_surface.links.new(reroute_016.outputs[0], switch.inputs[1])
	    #switch.Output -> store_named_attribute_001.Geometry
	    attach_hair_curves_to_surface.links.new(switch.outputs[0], store_named_attribute_001.inputs[0])
	    #reroute_020.Output -> capture_attribute_001.Geometry
	    attach_hair_curves_to_surface.links.new(reroute_020.outputs[0], capture_attribute_001.inputs[0])
	    #reroute_005.Output -> store_named_attribute_001.Value
	    attach_hair_curves_to_surface.links.new(reroute_005.outputs[0], store_named_attribute_001.inputs[3])
	    #capture_attribute_001.Value -> reroute_005.Input
	    attach_hair_curves_to_surface.links.new(capture_attribute_001.outputs[1], reroute_005.inputs[0])
	    #switch_010.Output -> group_output_3.Surface Normal
	    attach_hair_curves_to_surface.links.new(switch_010.outputs[0], group_output_3.inputs[2])
	    #sample_uv_surface_001.Value -> capture_attribute_001.Value
	    attach_hair_curves_to_surface.links.new(sample_uv_surface_001.outputs[0], capture_attribute_001.inputs[1])
	    #vector_math_003.Vector -> vector_math_005.Vector
	    attach_hair_curves_to_surface.links.new(vector_math_003.outputs[0], vector_math_005.inputs[0])
	    #spline_parameter_1.Factor -> map_range_1.Value
	    attach_hair_curves_to_surface.links.new(spline_parameter_1.outputs[0], map_range_1.inputs[0])
	    #group_input_008.Blend along Curve -> map_range_1.From Max
	    attach_hair_curves_to_surface.links.new(group_input_008.outputs[8], map_range_1.inputs[2])
	    #group_input_008.Blend along Curve -> compare.A
	    attach_hair_curves_to_surface.links.new(group_input_008.outputs[8], compare.inputs[0])
	    #compare.Result -> switch_004.Switch
	    attach_hair_curves_to_surface.links.new(compare.outputs[0], switch_004.inputs[0])
	    #map_range_1.Result -> switch_004.False
	    attach_hair_curves_to_surface.links.new(map_range_1.outputs[0], switch_004.inputs[1])
	    #switch_004.Output -> vector_math_005.Scale
	    attach_hair_curves_to_surface.links.new(switch_004.outputs[0], vector_math_005.inputs[3])
	    #switch_001.Output -> align_euler_to_vector_003.Vector
	    attach_hair_curves_to_surface.links.new(switch_001.outputs[0], align_euler_to_vector_003.inputs[2])
	    #sample_index.Value -> switch_001.False
	    attach_hair_curves_to_surface.links.new(sample_index.outputs[0], switch_001.inputs[1])
	    #named_attribute_002.Exists -> switch_006.Switch
	    attach_hair_curves_to_surface.links.new(named_attribute_002.outputs[1], switch_006.inputs[0])
	    #reroute_009.Output -> switch_006.False
	    attach_hair_curves_to_surface.links.new(reroute_009.outputs[0], switch_006.inputs[1])
	    #vector_rotate_003.Vector -> switch_006.True
	    attach_hair_curves_to_surface.links.new(vector_rotate_003.outputs[0], switch_006.inputs[2])
	    #vector_math_001.Vector -> reroute_009.Input
	    attach_hair_curves_to_surface.links.new(vector_math_001.outputs[0], reroute_009.inputs[0])
	    #reroute_011.Output -> reroute_010.Input
	    attach_hair_curves_to_surface.links.new(reroute_011.outputs[0], reroute_010.inputs[0])
	    #group_input_2.Geometry -> reroute_011.Input
	    attach_hair_curves_to_surface.links.new(group_input_2.outputs[0], reroute_011.inputs[0])
	    #store_named_attribute_001.Geometry -> switch_008.False
	    attach_hair_curves_to_surface.links.new(store_named_attribute_001.outputs[0], switch_008.inputs[1])
	    #reroute_006.Output -> switch_008.True
	    attach_hair_curves_to_surface.links.new(reroute_006.outputs[0], switch_008.inputs[2])
	    #switch_008.Output -> group_output_3.Geometry
	    attach_hair_curves_to_surface.links.new(switch_008.outputs[0], group_output_3.inputs[0])
	    #reroute_003.Output -> switch_009.False
	    attach_hair_curves_to_surface.links.new(reroute_003.outputs[0], switch_009.inputs[1])
	    #reroute_005.Output -> switch_010.False
	    attach_hair_curves_to_surface.links.new(reroute_005.outputs[0], switch_010.inputs[1])
	    #domain_size_003.Face Count -> compare_002_1.A
	    attach_hair_curves_to_surface.links.new(domain_size_003.outputs[2], compare_002_1.inputs[2])
	    #switch_005.Output -> domain_size_003.Geometry
	    attach_hair_curves_to_surface.links.new(switch_005.outputs[0], domain_size_003.inputs[0])
	    #reroute_012.Output -> switch_008.Switch
	    attach_hair_curves_to_surface.links.new(reroute_012.outputs[0], switch_008.inputs[0])
	    #reroute_014.Output -> reroute_012.Input
	    attach_hair_curves_to_surface.links.new(reroute_014.outputs[0], reroute_012.inputs[0])
	    #reroute_012.Output -> switch_009.Switch
	    attach_hair_curves_to_surface.links.new(reroute_012.outputs[0], switch_009.inputs[0])
	    #reroute_012.Output -> switch_010.Switch
	    attach_hair_curves_to_surface.links.new(reroute_012.outputs[0], switch_010.inputs[0])
	    #named_attribute_003.Attribute -> switch_009.True
	    attach_hair_curves_to_surface.links.new(named_attribute_003.outputs[0], switch_009.inputs[2])
	    #named_attribute_004.Attribute -> switch_010.True
	    attach_hair_curves_to_surface.links.new(named_attribute_004.outputs[0], switch_010.inputs[2])
	    #reroute_015.Output -> reroute_013.Input
	    attach_hair_curves_to_surface.links.new(reroute_015.outputs[0], reroute_013.inputs[0])
	    #reroute_013.Output -> reroute_014.Input
	    attach_hair_curves_to_surface.links.new(reroute_013.outputs[0], reroute_014.inputs[0])
	    #compare_002_1.Result -> reroute_015.Input
	    attach_hair_curves_to_surface.links.new(compare_002_1.outputs[0], reroute_015.inputs[0])
	    #set_position_001.Geometry -> reroute_016.Input
	    attach_hair_curves_to_surface.links.new(set_position_001.outputs[0], reroute_016.inputs[0])
	    #capture_attribute.Geometry -> reroute_017.Input
	    attach_hair_curves_to_surface.links.new(capture_attribute.outputs[0], reroute_017.inputs[0])
	    #capture_attribute.Value -> reroute_018.Input
	    attach_hair_curves_to_surface.links.new(capture_attribute.outputs[1], reroute_018.inputs[0])
	    #reroute_010.Output -> reroute_006.Input
	    attach_hair_curves_to_surface.links.new(reroute_010.outputs[0], reroute_006.inputs[0])
	    #reroute_001_1.Output -> reroute_007.Input
	    attach_hair_curves_to_surface.links.new(reroute_001_1.outputs[0], reroute_007.inputs[0])
	    #sample_uv_surface_001.Value -> reroute_008.Input
	    attach_hair_curves_to_surface.links.new(sample_uv_surface_001.outputs[0], reroute_008.inputs[0])
	    #reroute_008.Output -> align_euler_to_vector_002.Vector
	    attach_hair_curves_to_surface.links.new(reroute_008.outputs[0], align_euler_to_vector_002.inputs[2])
	    #sample_uv_surface_003.Value -> reroute_019.Input
	    attach_hair_curves_to_surface.links.new(sample_uv_surface_003.outputs[0], reroute_019.inputs[0])
	    #reroute_017.Output -> sample_uv_surface.Mesh
	    attach_hair_curves_to_surface.links.new(reroute_017.outputs[0], sample_uv_surface.inputs[0])
	    #group_input_009.Surface UV Map -> reroute_002.Input
	    attach_hair_curves_to_surface.links.new(group_input_009.outputs[3], reroute_002.inputs[0])
	    #capture_attribute_002.Geometry -> reroute_020.Input
	    attach_hair_curves_to_surface.links.new(capture_attribute_002.outputs[0], reroute_020.inputs[0])
	    return attach_hair_curves_to_surface
	
	attach_hair_curves_to_surface = attach_hair_curves_to_surface_node_group()
	
	#initialize solid_hair node group
	def solid_hair_node_group():
	    solid_hair = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "SOLID_HAIR")
	
	    solid_hair.color_tag = 'NONE'
	    solid_hair.description = "Convert hair to solid mesh or create more hair from the shape of the solid mesh."
	    solid_hair.default_group_node_width = 140
	    
	
	    solid_hair.is_modifier = True
	
	    #solid_hair interface
	    #Socket Geometry
	    geometry_socket_5 = solid_hair.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_5.attribute_domain = 'POINT'
	    geometry_socket_5.description = "Solid Mesh | Curve Hair."
	
	    #Socket Geometry
	    geometry_socket_6 = solid_hair.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_6.attribute_domain = 'POINT'
	    geometry_socket_6.description = "Curve Guide."
	
	    #Socket Surface
	    surface_socket_2 = solid_hair.interface.new_socket(name = "Surface", in_out='INPUT', socket_type = 'NodeSocketObject')
	    surface_socket_2.attribute_domain = 'POINT'
	    surface_socket_2.description = "Surface Object to attach to (needs to have matching transforms)"
	
	    #Socket Hair Style
	    hair_style_socket = solid_hair.interface.new_socket(name = "Hair Style", in_out='INPUT', socket_type = 'NodeSocketMenu')
	    hair_style_socket.attribute_domain = 'POINT'
	    hair_style_socket.description = "Choose Mesh or curves hair."
	
	    #Socket Control Points
	    control_points_socket = solid_hair.interface.new_socket(name = "Control Points", in_out='INPUT', socket_type = 'NodeSocketInt')
	    control_points_socket.default_value = 10
	    control_points_socket.min_value = 1
	    control_points_socket.max_value = 100000
	    control_points_socket.subtype = 'NONE'
	    control_points_socket.attribute_domain = 'POINT'
	    control_points_socket.description = "Amount of points for eeach curve."
	
	    #Socket Resolution
	    resolution_socket_1 = solid_hair.interface.new_socket(name = "Resolution", in_out='INPUT', socket_type = 'NodeSocketInt')
	    resolution_socket_1.default_value = 32
	    resolution_socket_1.min_value = 3
	    resolution_socket_1.max_value = 512
	    resolution_socket_1.subtype = 'NONE'
	    resolution_socket_1.attribute_domain = 'POINT'
	    resolution_socket_1.description = "Curve resolution."
	
	    #Socket Level
	    level_socket_1 = solid_hair.interface.new_socket(name = "Level", in_out='INPUT', socket_type = 'NodeSocketInt')
	    level_socket_1.default_value = 0
	    level_socket_1.min_value = 0
	    level_socket_1.max_value = 6
	    level_socket_1.subtype = 'NONE'
	    level_socket_1.attribute_domain = 'POINT'
	    level_socket_1.description = "Mesh subdivision level."
	
	    #Socket Material
	    material_socket_1 = solid_hair.interface.new_socket(name = "Material", in_out='INPUT', socket_type = 'NodeSocketMaterial')
	    material_socket_1.attribute_domain = 'POINT'
	    material_socket_1.description = "Curve material."
	
	    #Socket Strand Radius
	    strand_radius_socket_1 = solid_hair.interface.new_socket(name = "Strand Radius", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    strand_radius_socket_1.default_value = 0.003000000026077032
	    strand_radius_socket_1.min_value = 0.0
	    strand_radius_socket_1.max_value = 10000.0
	    strand_radius_socket_1.subtype = 'NONE'
	    strand_radius_socket_1.attribute_domain = 'POINT'
	    strand_radius_socket_1.description = "Radius for hair strands."
	
	    #Socket Trim Seed
	    trim_seed_socket_1 = solid_hair.interface.new_socket(name = "Trim Seed", in_out='INPUT', socket_type = 'NodeSocketInt')
	    trim_seed_socket_1.default_value = 0
	    trim_seed_socket_1.min_value = -10000
	    trim_seed_socket_1.max_value = 10000
	    trim_seed_socket_1.subtype = 'NONE'
	    trim_seed_socket_1.attribute_domain = 'POINT'
	    trim_seed_socket_1.description = "Random seed for hair tip trimming."
	
	    #Socket Trim Factor
	    trim_factor_socket_1 = solid_hair.interface.new_socket(name = "Trim Factor", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    trim_factor_socket_1.default_value = 1.0
	    trim_factor_socket_1.min_value = 0.0
	    trim_factor_socket_1.max_value = 1.0
	    trim_factor_socket_1.subtype = 'FACTOR'
	    trim_factor_socket_1.attribute_domain = 'POINT'
	    trim_factor_socket_1.description = "Minumal percentage of hair strand length to remain after random trim. (1=no trim, 0=potential full trim)"
	
	    #Socket UV Map
	    uv_map_socket_1 = solid_hair.interface.new_socket(name = "UV Map", in_out='INPUT', socket_type = 'NodeSocketString')
	    uv_map_socket_1.default_value = "UVMap"
	    uv_map_socket_1.subtype = 'NONE'
	    uv_map_socket_1.attribute_domain = 'POINT'
	    uv_map_socket_1.description = "UV Map used to detrmine strand direction."
	
	    #Panel Mesh Settings
	    mesh_settings_panel = solid_hair.interface.new_panel("Mesh Settings", default_closed=True)
	    mesh_settings_panel.description = "Settings for Solid Mesh Hair."
	    #Socket Mesh Material
	    mesh_material_socket = solid_hair.interface.new_socket(name = "Mesh Material", in_out='INPUT', socket_type = 'NodeSocketMaterial', parent = mesh_settings_panel)
	    mesh_material_socket.attribute_domain = 'POINT'
	    mesh_material_socket.description = "Material for Solid Mesh."
	
	    #Socket Profile Curve
	    profile_curve_socket = solid_hair.interface.new_socket(name = "Profile Curve", in_out='INPUT', socket_type = 'NodeSocketObject', parent = mesh_settings_panel)
	    profile_curve_socket.attribute_domain = 'POINT'
	    profile_curve_socket.description = "Curve Profile object used for Solid Mesh Hair Style. (Optional)"
	
	    #Socket Profile Height
	    profile_height_socket = solid_hair.interface.new_socket(name = "Profile Height", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = mesh_settings_panel)
	    profile_height_socket.default_value = 0.019999999552965164
	    profile_height_socket.min_value = 0.0
	    profile_height_socket.max_value = 10000.0
	    profile_height_socket.subtype = 'NONE'
	    profile_height_socket.attribute_domain = 'POINT'
	    profile_height_socket.description = "Height scale for profile object."
	
	    #Socket Profile Width
	    profile_width_socket = solid_hair.interface.new_socket(name = "Profile Width", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = mesh_settings_panel)
	    profile_width_socket.default_value = 0.05000000074505806
	    profile_width_socket.min_value = 0.0
	    profile_width_socket.max_value = 10000.0
	    profile_width_socket.subtype = 'NONE'
	    profile_width_socket.attribute_domain = 'POINT'
	    profile_width_socket.description = "Width scale for profile object."
	
	
	
	    #initialize solid_hair nodes
	    #node Group Output
	    group_output_4 = solid_hair.nodes.new("NodeGroupOutput")
	    group_output_4.name = "Group Output"
	    group_output_4.is_active_output = True
	    group_output_4.inputs[1].hide = True
	
	    #node Group Input
	    group_input_3 = solid_hair.nodes.new("NodeGroupInput")
	    group_input_3.name = "Group Input"
	    group_input_3.outputs[0].hide = True
	    group_input_3.outputs[1].hide = True
	    group_input_3.outputs[2].hide = True
	    group_input_3.outputs[3].hide = True
	    group_input_3.outputs[4].hide = True
	    group_input_3.outputs[11].hide = True
	    group_input_3.outputs[12].hide = True
	    group_input_3.outputs[13].hide = True
	    group_input_3.outputs[14].hide = True
	    group_input_3.outputs[15].hide = True
	
	    #node Group.003
	    group_003 = solid_hair.nodes.new("GeometryNodeGroup")
	    group_003.name = "Group.003"
	    group_003.node_tree = curve_extrude_profile
	    group_003.inputs[1].hide = True
	    group_003.inputs[2].hide = True
	    #Socket_2
	    group_003.inputs[1].default_value = (0.0, 0.0, 0.0)
	    #Socket_3
	    group_003.inputs[2].default_value = (0.0, 0.0, 0.0)
	
	    #node Curve to Mesh
	    curve_to_mesh = solid_hair.nodes.new("GeometryNodeCurveToMesh")
	    curve_to_mesh.name = "Curve to Mesh"
	    #Fill Caps
	    curve_to_mesh.inputs[2].default_value = True
	
	    #node Switch
	    switch_1 = solid_hair.nodes.new("GeometryNodeSwitch")
	    switch_1.name = "Switch"
	    switch_1.input_type = 'GEOMETRY'
	
	    #node Object Info
	    object_info = solid_hair.nodes.new("GeometryNodeObjectInfo")
	    object_info.name = "Object Info"
	    object_info.hide = True
	    object_info.transform_space = 'RELATIVE'
	    object_info.inputs[1].hide = True
	    object_info.outputs[0].hide = True
	    object_info.outputs[1].hide = True
	    object_info.outputs[2].hide = True
	    object_info.outputs[3].hide = True
	    #As Instance
	    object_info.inputs[1].default_value = False
	
	    #node Domain Size
	    domain_size = solid_hair.nodes.new("GeometryNodeAttributeDomainSize")
	    domain_size.name = "Domain Size"
	    domain_size.hide = True
	    domain_size.component = 'CURVE'
	    domain_size.outputs[1].hide = True
	    domain_size.outputs[2].hide = True
	    domain_size.outputs[3].hide = True
	    domain_size.outputs[4].hide = True
	    domain_size.outputs[5].hide = True
	    domain_size.outputs[6].hide = True
	
	    #node Compare
	    compare_1 = solid_hair.nodes.new("FunctionNodeCompare")
	    compare_1.name = "Compare"
	    compare_1.hide = True
	    compare_1.data_type = 'INT'
	    compare_1.mode = 'ELEMENT'
	    compare_1.operation = 'EQUAL'
	    compare_1.inputs[0].hide = True
	    compare_1.inputs[1].hide = True
	    compare_1.inputs[3].hide = True
	    compare_1.inputs[4].hide = True
	    compare_1.inputs[5].hide = True
	    compare_1.inputs[6].hide = True
	    compare_1.inputs[7].hide = True
	    compare_1.inputs[8].hide = True
	    compare_1.inputs[9].hide = True
	    compare_1.inputs[10].hide = True
	    compare_1.inputs[11].hide = True
	    compare_1.inputs[12].hide = True
	    #B_INT
	    compare_1.inputs[3].default_value = 0
	
	    #node Combine XYZ
	    combine_xyz = solid_hair.nodes.new("ShaderNodeCombineXYZ")
	    combine_xyz.name = "Combine XYZ"
	    combine_xyz.hide = True
	    combine_xyz.inputs[2].hide = True
	    #Z
	    combine_xyz.inputs[2].default_value = 1.0
	
	    #node Transform Geometry
	    transform_geometry_1 = solid_hair.nodes.new("GeometryNodeTransform")
	    transform_geometry_1.name = "Transform Geometry"
	    transform_geometry_1.hide = True
	    transform_geometry_1.mode = 'COMPONENTS'
	    transform_geometry_1.inputs[1].hide = True
	    transform_geometry_1.inputs[2].hide = True
	    transform_geometry_1.inputs[4].hide = True
	    #Translation
	    transform_geometry_1.inputs[1].default_value = (0.0, 0.0, 0.0)
	    #Rotation
	    transform_geometry_1.inputs[2].default_value = (0.0, 0.0, 0.0)
	
	    #node Resample Curve
	    resample_curve = solid_hair.nodes.new("GeometryNodeResampleCurve")
	    resample_curve.name = "Resample Curve"
	    resample_curve.hide = True
	    resample_curve.keep_last_segment = True
	    resample_curve.mode = 'COUNT'
	    resample_curve.inputs[1].hide = True
	    resample_curve.inputs[3].hide = True
	    #Selection
	    resample_curve.inputs[1].default_value = True
	
	    #node Named Attribute.001
	    named_attribute_001_1 = solid_hair.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute_001_1.name = "Named Attribute.001"
	    named_attribute_001_1.hide = True
	    named_attribute_001_1.data_type = 'FLOAT_VECTOR'
	
	    #node Set Curve Radius
	    set_curve_radius_1 = solid_hair.nodes.new("GeometryNodeSetCurveRadius")
	    set_curve_radius_1.name = "Set Curve Radius"
	    #Selection
	    set_curve_radius_1.inputs[1].default_value = True
	
	    #node Solid Mesh Shape
	    solid_mesh_shape = solid_hair.nodes.new("ShaderNodeFloatCurve")
	    solid_mesh_shape.label = "Solid Mesh Shape"
	    solid_mesh_shape.name = "Solid Mesh Shape"
	    #mapping settings
	    solid_mesh_shape.mapping.extend = 'EXTRAPOLATED'
	    solid_mesh_shape.mapping.tone = 'STANDARD'
	    solid_mesh_shape.mapping.black_level = (0.0, 0.0, 0.0)
	    solid_mesh_shape.mapping.white_level = (1.0, 1.0, 1.0)
	    solid_mesh_shape.mapping.clip_min_x = 0.0
	    solid_mesh_shape.mapping.clip_min_y = 0.0
	    solid_mesh_shape.mapping.clip_max_x = 1.0
	    solid_mesh_shape.mapping.clip_max_y = 1.0
	    solid_mesh_shape.mapping.use_clip = True
	    #curve 0
	    solid_mesh_shape_curve_0 = solid_mesh_shape.mapping.curves[0]
	    solid_mesh_shape_curve_0_point_0 = solid_mesh_shape_curve_0.points[0]
	    solid_mesh_shape_curve_0_point_0.location = (0.0, 1.0)
	    solid_mesh_shape_curve_0_point_0.handle_type = 'AUTO'
	    solid_mesh_shape_curve_0_point_1 = solid_mesh_shape_curve_0.points[1]
	    solid_mesh_shape_curve_0_point_1.location = (1.0, 1.0)
	    solid_mesh_shape_curve_0_point_1.handle_type = 'AUTO'
	    #update curve after changes
	    solid_mesh_shape.mapping.update()
	    solid_mesh_shape.inputs[0].hide = True
	    #Factor
	    solid_mesh_shape.inputs[0].default_value = 1.0
	
	    #node Spline Parameter
	    spline_parameter_2 = solid_hair.nodes.new("GeometryNodeSplineParameter")
	    spline_parameter_2.name = "Spline Parameter"
	    spline_parameter_2.outputs[1].hide = True
	    spline_parameter_2.outputs[2].hide = True
	
	    #node Group.007
	    group_007 = solid_hair.nodes.new("GeometryNodeGroup")
	    group_007.name = "Group.007"
	    group_007.node_tree = mesh_to_strands
	
	    #node Capture Attribute
	    capture_attribute_1 = solid_hair.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_1.name = "Capture Attribute"
	    capture_attribute_1.hide = True
	    capture_attribute_1.active_index = 0
	    capture_attribute_1.capture_items.clear()
	    capture_attribute_1.capture_items.new('FLOAT', "Factor")
	    capture_attribute_1.capture_items["Factor"].data_type = 'FLOAT'
	    capture_attribute_1.domain = 'POINT'
	
	    #node Spline Parameter.001
	    spline_parameter_001 = solid_hair.nodes.new("GeometryNodeSplineParameter")
	    spline_parameter_001.name = "Spline Parameter.001"
	    spline_parameter_001.outputs[1].hide = True
	    spline_parameter_001.outputs[2].hide = True
	
	    #node Capture Attribute.001
	    capture_attribute_001_1 = solid_hair.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_001_1.name = "Capture Attribute.001"
	    capture_attribute_001_1.hide = True
	    capture_attribute_001_1.active_index = 0
	    capture_attribute_001_1.capture_items.clear()
	    capture_attribute_001_1.capture_items.new('FLOAT', "Factor")
	    capture_attribute_001_1.capture_items["Factor"].data_type = 'FLOAT'
	    capture_attribute_001_1.domain = 'POINT'
	
	    #node Store Named Attribute.001
	    store_named_attribute_001_1 = solid_hair.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_001_1.name = "Store Named Attribute.001"
	    store_named_attribute_001_1.data_type = 'FLOAT2'
	    store_named_attribute_001_1.domain = 'CORNER'
	    #Selection
	    store_named_attribute_001_1.inputs[1].default_value = True
	    #Name
	    store_named_attribute_001_1.inputs[2].default_value = "UVMap"
	
	    #node Combine XYZ.001
	    combine_xyz_001 = solid_hair.nodes.new("ShaderNodeCombineXYZ")
	    combine_xyz_001.name = "Combine XYZ.001"
	    combine_xyz_001.hide = True
	    combine_xyz_001.inputs[2].hide = True
	    #Z
	    combine_xyz_001.inputs[2].default_value = 0.0
	
	    #node Group.008
	    group_008 = solid_hair.nodes.new("GeometryNodeGroup")
	    group_008.name = "Group.008"
	    group_008.node_tree = attach_hair_curves_to_surface
	    group_008.inputs[1].hide = True
	    group_008.inputs[4].hide = True
	    group_008.inputs[5].hide = True
	    group_008.inputs[6].hide = True
	    group_008.inputs[7].hide = True
	    group_008.inputs[8].hide = True
	    group_008.outputs[1].hide = True
	    group_008.outputs[2].hide = True
	    #Input_6
	    group_008.inputs[4].default_value = False
	    #Input_10
	    group_008.inputs[5].default_value = True
	    #Input_8
	    group_008.inputs[6].default_value = True
	    #Input_7
	    group_008.inputs[7].default_value = False
	    #Input_12
	    group_008.inputs[8].default_value = 0.0
	
	    #node Hair Style
	    hair_style = solid_hair.nodes.new("GeometryNodeMenuSwitch")
	    hair_style.label = "Hair Style"
	    hair_style.name = "Hair Style"
	    hair_style.active_index = 0
	    hair_style.data_type = 'GEOMETRY'
	    hair_style.enum_items.clear()
	    hair_style.enum_items.new("Solid Mesh")
	    hair_style.enum_items[0].description = "Mesh Hair."
	    hair_style.enum_items.new("Solid Curve")
	    hair_style.enum_items[1].description = "Hair Curves."
	    hair_style.inputs[3].hide = True
	
	    #node Group Input.001
	    group_input_001_3 = solid_hair.nodes.new("NodeGroupInput")
	    group_input_001_3.name = "Group Input.001"
	    group_input_001_3.outputs[0].hide = True
	    group_input_001_3.outputs[1].hide = True
	    group_input_001_3.outputs[2].hide = True
	    group_input_001_3.outputs[3].hide = True
	    group_input_001_3.outputs[4].hide = True
	    group_input_001_3.outputs[5].hide = True
	    group_input_001_3.outputs[6].hide = True
	    group_input_001_3.outputs[7].hide = True
	    group_input_001_3.outputs[8].hide = True
	    group_input_001_3.outputs[9].hide = True
	    group_input_001_3.outputs[11].hide = True
	    group_input_001_3.outputs[12].hide = True
	    group_input_001_3.outputs[13].hide = True
	    group_input_001_3.outputs[14].hide = True
	    group_input_001_3.outputs[15].hide = True
	
	    #node Group Input.002
	    group_input_002_2 = solid_hair.nodes.new("NodeGroupInput")
	    group_input_002_2.name = "Group Input.002"
	    group_input_002_2.outputs[0].hide = True
	    group_input_002_2.outputs[2].hide = True
	    group_input_002_2.outputs[3].hide = True
	    group_input_002_2.outputs[4].hide = True
	    group_input_002_2.outputs[5].hide = True
	    group_input_002_2.outputs[6].hide = True
	    group_input_002_2.outputs[7].hide = True
	    group_input_002_2.outputs[8].hide = True
	    group_input_002_2.outputs[9].hide = True
	    group_input_002_2.outputs[10].hide = True
	    group_input_002_2.outputs[11].hide = True
	    group_input_002_2.outputs[12].hide = True
	    group_input_002_2.outputs[13].hide = True
	    group_input_002_2.outputs[14].hide = True
	    group_input_002_2.outputs[15].hide = True
	
	    #node Group Input.003
	    group_input_003_2 = solid_hair.nodes.new("NodeGroupInput")
	    group_input_003_2.name = "Group Input.003"
	    group_input_003_2.outputs[1].hide = True
	    group_input_003_2.outputs[2].hide = True
	    group_input_003_2.outputs[3].hide = True
	    group_input_003_2.outputs[4].hide = True
	    group_input_003_2.outputs[5].hide = True
	    group_input_003_2.outputs[6].hide = True
	    group_input_003_2.outputs[7].hide = True
	    group_input_003_2.outputs[8].hide = True
	    group_input_003_2.outputs[9].hide = True
	    group_input_003_2.outputs[10].hide = True
	    group_input_003_2.outputs[11].hide = True
	    group_input_003_2.outputs[12].hide = True
	    group_input_003_2.outputs[13].hide = True
	    group_input_003_2.outputs[14].hide = True
	    group_input_003_2.outputs[15].hide = True
	
	    #node Group Input.004
	    group_input_004_2 = solid_hair.nodes.new("NodeGroupInput")
	    group_input_004_2.name = "Group Input.004"
	    group_input_004_2.outputs[0].hide = True
	    group_input_004_2.outputs[1].hide = True
	    group_input_004_2.outputs[2].hide = True
	    group_input_004_2.outputs[3].hide = True
	    group_input_004_2.outputs[4].hide = True
	    group_input_004_2.outputs[5].hide = True
	    group_input_004_2.outputs[6].hide = True
	    group_input_004_2.outputs[7].hide = True
	    group_input_004_2.outputs[8].hide = True
	    group_input_004_2.outputs[9].hide = True
	    group_input_004_2.outputs[10].hide = True
	    group_input_004_2.outputs[11].hide = True
	    group_input_004_2.outputs[13].hide = True
	    group_input_004_2.outputs[14].hide = True
	    group_input_004_2.outputs[15].hide = True
	
	    #node Group Input.005
	    group_input_005_2 = solid_hair.nodes.new("NodeGroupInput")
	    group_input_005_2.name = "Group Input.005"
	    group_input_005_2.outputs[0].hide = True
	    group_input_005_2.outputs[1].hide = True
	    group_input_005_2.outputs[2].hide = True
	    group_input_005_2.outputs[4].hide = True
	    group_input_005_2.outputs[5].hide = True
	    group_input_005_2.outputs[6].hide = True
	    group_input_005_2.outputs[7].hide = True
	    group_input_005_2.outputs[8].hide = True
	    group_input_005_2.outputs[9].hide = True
	    group_input_005_2.outputs[10].hide = True
	    group_input_005_2.outputs[11].hide = True
	    group_input_005_2.outputs[12].hide = True
	    group_input_005_2.outputs[13].hide = True
	    group_input_005_2.outputs[14].hide = True
	    group_input_005_2.outputs[15].hide = True
	
	    #node Group Input.006
	    group_input_006_1 = solid_hair.nodes.new("NodeGroupInput")
	    group_input_006_1.name = "Group Input.006"
	    group_input_006_1.outputs[0].hide = True
	    group_input_006_1.outputs[1].hide = True
	    group_input_006_1.outputs[2].hide = True
	    group_input_006_1.outputs[3].hide = True
	    group_input_006_1.outputs[5].hide = True
	    group_input_006_1.outputs[6].hide = True
	    group_input_006_1.outputs[7].hide = True
	    group_input_006_1.outputs[8].hide = True
	    group_input_006_1.outputs[9].hide = True
	    group_input_006_1.outputs[10].hide = True
	    group_input_006_1.outputs[11].hide = True
	    group_input_006_1.outputs[12].hide = True
	    group_input_006_1.outputs[13].hide = True
	    group_input_006_1.outputs[14].hide = True
	    group_input_006_1.outputs[15].hide = True
	
	    #node Group Input.007
	    group_input_007_1 = solid_hair.nodes.new("NodeGroupInput")
	    group_input_007_1.name = "Group Input.007"
	    group_input_007_1.outputs[0].hide = True
	    group_input_007_1.outputs[1].hide = True
	    group_input_007_1.outputs[2].hide = True
	    group_input_007_1.outputs[3].hide = True
	    group_input_007_1.outputs[4].hide = True
	    group_input_007_1.outputs[5].hide = True
	    group_input_007_1.outputs[6].hide = True
	    group_input_007_1.outputs[7].hide = True
	    group_input_007_1.outputs[8].hide = True
	    group_input_007_1.outputs[9].hide = True
	    group_input_007_1.outputs[10].hide = True
	    group_input_007_1.outputs[11].hide = True
	    group_input_007_1.outputs[12].hide = True
	    group_input_007_1.outputs[15].hide = True
	
	    #node Separate Components
	    separate_components = solid_hair.nodes.new("GeometryNodeSeparateComponents")
	    separate_components.name = "Separate Components"
	    separate_components.hide = True
	
	    #node Join Geometry
	    join_geometry = solid_hair.nodes.new("GeometryNodeJoinGeometry")
	    join_geometry.name = "Join Geometry"
	    join_geometry.hide = True
	
	    #node Reroute
	    reroute_2 = solid_hair.nodes.new("NodeReroute")
	    reroute_2.name = "Reroute"
	    reroute_2.socket_idname = "NodeSocketGeometry"
	    #node Reroute.001
	    reroute_001_2 = solid_hair.nodes.new("NodeReroute")
	    reroute_001_2.name = "Reroute.001"
	    reroute_001_2.socket_idname = "NodeSocketGeometry"
	    #node Reroute.002
	    reroute_002_1 = solid_hair.nodes.new("NodeReroute")
	    reroute_002_1.name = "Reroute.002"
	    reroute_002_1.socket_idname = "NodeSocketGeometry"
	    #node Reroute.003
	    reroute_003_1 = solid_hair.nodes.new("NodeReroute")
	    reroute_003_1.name = "Reroute.003"
	    reroute_003_1.socket_idname = "NodeSocketGeometry"
	    #node Reroute.004
	    reroute_004_1 = solid_hair.nodes.new("NodeReroute")
	    reroute_004_1.name = "Reroute.004"
	    reroute_004_1.socket_idname = "NodeSocketGeometry"
	    #node Reroute.005
	    reroute_005_1 = solid_hair.nodes.new("NodeReroute")
	    reroute_005_1.name = "Reroute.005"
	    reroute_005_1.socket_idname = "NodeSocketGeometry"
	    #node Reroute.006
	    reroute_006_1 = solid_hair.nodes.new("NodeReroute")
	    reroute_006_1.name = "Reroute.006"
	    reroute_006_1.socket_idname = "NodeSocketGeometry"
	    #node Reroute.007
	    reroute_007_1 = solid_hair.nodes.new("NodeReroute")
	    reroute_007_1.name = "Reroute.007"
	    reroute_007_1.socket_idname = "NodeSocketGeometry"
	    #node Reroute.008
	    reroute_008_1 = solid_hair.nodes.new("NodeReroute")
	    reroute_008_1.name = "Reroute.008"
	    reroute_008_1.socket_idname = "NodeSocketGeometry"
	    #node Reroute.009
	    reroute_009_1 = solid_hair.nodes.new("NodeReroute")
	    reroute_009_1.name = "Reroute.009"
	    reroute_009_1.socket_idname = "NodeSocketGeometry"
	    #node Group Input.008
	    group_input_008_1 = solid_hair.nodes.new("NodeGroupInput")
	    group_input_008_1.name = "Group Input.008"
	    group_input_008_1.outputs[0].hide = True
	    group_input_008_1.outputs[1].hide = True
	    group_input_008_1.outputs[3].hide = True
	    group_input_008_1.outputs[4].hide = True
	    group_input_008_1.outputs[5].hide = True
	    group_input_008_1.outputs[6].hide = True
	    group_input_008_1.outputs[7].hide = True
	    group_input_008_1.outputs[8].hide = True
	    group_input_008_1.outputs[9].hide = True
	    group_input_008_1.outputs[10].hide = True
	    group_input_008_1.outputs[11].hide = True
	    group_input_008_1.outputs[12].hide = True
	    group_input_008_1.outputs[13].hide = True
	    group_input_008_1.outputs[14].hide = True
	    group_input_008_1.outputs[15].hide = True
	
	    #node Solid Hair Bake
	    solid_hair_bake = solid_hair.nodes.new("GeometryNodeBake")
	    solid_hair_bake.label = "Solid Hair Bake"
	    solid_hair_bake.name = "Solid Hair Bake"
	    solid_hair_bake.active_index = 0
	    solid_hair_bake.bake_items.clear()
	    solid_hair_bake.bake_items.new('GEOMETRY', "Geometry")
	    solid_hair_bake.bake_items[0].attribute_domain = 'POINT'
	    solid_hair_bake.inputs[1].hide = True
	    solid_hair_bake.outputs[1].hide = True
	
	    #node Set Material
	    set_material = solid_hair.nodes.new("GeometryNodeSetMaterial")
	    set_material.name = "Set Material"
	    set_material.hide = True
	    set_material.inputs[1].hide = True
	    #Selection
	    set_material.inputs[1].default_value = True
	
	    #node Group Input.009
	    group_input_009_1 = solid_hair.nodes.new("NodeGroupInput")
	    group_input_009_1.name = "Group Input.009"
	    group_input_009_1.outputs[0].hide = True
	    group_input_009_1.outputs[1].hide = True
	    group_input_009_1.outputs[2].hide = True
	    group_input_009_1.outputs[3].hide = True
	    group_input_009_1.outputs[4].hide = True
	    group_input_009_1.outputs[5].hide = True
	    group_input_009_1.outputs[6].hide = True
	    group_input_009_1.outputs[7].hide = True
	    group_input_009_1.outputs[8].hide = True
	    group_input_009_1.outputs[9].hide = True
	    group_input_009_1.outputs[10].hide = True
	    group_input_009_1.outputs[12].hide = True
	    group_input_009_1.outputs[13].hide = True
	    group_input_009_1.outputs[14].hide = True
	    group_input_009_1.outputs[15].hide = True
	
	
	
	
	
	    #Set locations
	    group_output_4.location = (1280.774658203125, 295.33013916015625)
	    group_input_3.location = (278.5207824707031, 47.580963134765625)
	    group_003.location = (-756.8720703125, 50.59716796875)
	    curve_to_mesh.location = (92.21954345703125, 242.70693969726562)
	    switch_1.location = (-337.56024169921875, 195.2990264892578)
	    object_info.location = (-755.584716796875, 93.88079833984375)
	    domain_size.location = (-755.6057739257812, 128.4407958984375)
	    compare_1.location = (-751.5472412109375, 179.81700134277344)
	    combine_xyz.location = (-759.5336303710938, -75.28973388671875)
	    transform_geometry_1.location = (-564.5932006835938, 100.62359619140625)
	    resample_curve.location = (-564.5931396484375, 65.34988403320312)
	    named_attribute_001_1.location = (731.6569213867188, -0.87237548828125)
	    set_curve_radius_1.location = (-336.9681701660156, 323.5440979003906)
	    solid_mesh_shape.location = (-574.9011840820312, -28.028167724609375)
	    spline_parameter_2.location = (-579.2069091796875, -323.5440673828125)
	    group_007.location = (502.6057434082031, 115.25497436523438)
	    capture_attribute_1.location = (-146.37628173828125, 163.34063720703125)
	    spline_parameter_001.location = (-146.30029296875, 253.9871826171875)
	    capture_attribute_001_1.location = (-146.37628173828125, 291.3163146972656)
	    store_named_attribute_001_1.location = (277.25927734375, 243.03366088867188)
	    combine_xyz_001.location = (92.98468017578125, 113.7286376953125)
	    group_008.location = (731.3937377929688, 164.62374877929688)
	    hair_style.location = (922.3916015625, 295.33013916015625)
	    group_input_001_3.location = (731.107666015625, -29.532989501953125)
	    group_input_002_2.location = (503.1744689941406, -116.49130249023438)
	    group_input_003_2.location = (-338.04669189453125, 382.28839111328125)
	    group_input_004_2.location = (-939.85595703125, 118.132080078125)
	    group_input_005_2.location = (-565.9798583984375, 31.17372703552246)
	    group_input_006_1.location = (-939.85595703125, 18.047950744628906)
	    group_input_007_1.location = (-941.4957275390625, -37.73663330078125)
	    separate_components.location = (-336.98040771484375, 419.2779541015625)
	    join_geometry.location = (732.1738891601562, 220.75042724609375)
	    reroute_2.location = (-87.18391418457031, 540.9283447265625)
	    reroute_001_2.location = (-82.810302734375, 521.6121215820312)
	    reroute_002_1.location = (-84.75792694091797, 531.1514282226562)
	    reroute_003_1.location = (-84.4501953125, 526.2174072265625)
	    reroute_004_1.location = (-86.090087890625, 535.912841796875)
	    reroute_005_1.location = (452.7733459472656, 526.9942016601562)
	    reroute_006_1.location = (453.4066467285156, 536.9928588867188)
	    reroute_007_1.location = (453.4066467285156, 541.9927978515625)
	    reroute_008_1.location = (451.7667541503906, 521.9966430664062)
	    reroute_009_1.location = (453.4066467285156, 531.9943237304688)
	    group_input_008_1.location = (921.3253173828125, 351.1147766113281)
	    solid_hair_bake.location = (1105.7052001953125, 341.85260009765625)
	    set_material.location = (506.28656005859375, 218.56195068359375)
	    group_input_009_1.location = (502.41510009765625, 188.19219970703125)
	
	    #Set dimensions
	    group_output_4.width, group_output_4.height = 140.0, 100.0
	    group_input_3.width, group_input_3.height = 140.0, 100.0
	    group_003.width, group_003.height = 140.0, 100.0
	    curve_to_mesh.width, curve_to_mesh.height = 140.0, 100.0
	    switch_1.width, switch_1.height = 140.0, 100.0
	    object_info.width, object_info.height = 140.0, 100.0
	    domain_size.width, domain_size.height = 140.0, 100.0
	    compare_1.width, compare_1.height = 140.0, 100.0
	    combine_xyz.width, combine_xyz.height = 140.0, 100.0
	    transform_geometry_1.width, transform_geometry_1.height = 140.0, 100.0
	    resample_curve.width, resample_curve.height = 140.0, 100.0
	    named_attribute_001_1.width, named_attribute_001_1.height = 140.0, 100.0
	    set_curve_radius_1.width, set_curve_radius_1.height = 140.0, 100.0
	    solid_mesh_shape.width, solid_mesh_shape.height = 240.0, 100.0
	    spline_parameter_2.width, spline_parameter_2.height = 140.0, 100.0
	    group_007.width, group_007.height = 140.0, 100.0
	    capture_attribute_1.width, capture_attribute_1.height = 140.0, 100.0
	    spline_parameter_001.width, spline_parameter_001.height = 140.0, 100.0
	    capture_attribute_001_1.width, capture_attribute_001_1.height = 140.0, 100.0
	    store_named_attribute_001_1.width, store_named_attribute_001_1.height = 140.0, 100.0
	    combine_xyz_001.width, combine_xyz_001.height = 140.0, 100.0
	    group_008.width, group_008.height = 140.0, 100.0
	    hair_style.width, hair_style.height = 140.0, 100.0
	    group_input_001_3.width, group_input_001_3.height = 140.0, 100.0
	    group_input_002_2.width, group_input_002_2.height = 140.0, 100.0
	    group_input_003_2.width, group_input_003_2.height = 140.0, 100.0
	    group_input_004_2.width, group_input_004_2.height = 140.0, 100.0
	    group_input_005_2.width, group_input_005_2.height = 140.0, 100.0
	    group_input_006_1.width, group_input_006_1.height = 140.0, 100.0
	    group_input_007_1.width, group_input_007_1.height = 140.0, 100.0
	    separate_components.width, separate_components.height = 140.0, 100.0
	    join_geometry.width, join_geometry.height = 140.0, 100.0
	    reroute_2.width, reroute_2.height = 10.0, 100.0
	    reroute_001_2.width, reroute_001_2.height = 10.0, 100.0
	    reroute_002_1.width, reroute_002_1.height = 10.0, 100.0
	    reroute_003_1.width, reroute_003_1.height = 10.0, 100.0
	    reroute_004_1.width, reroute_004_1.height = 10.0, 100.0
	    reroute_005_1.width, reroute_005_1.height = 10.0, 100.0
	    reroute_006_1.width, reroute_006_1.height = 10.0, 100.0
	    reroute_007_1.width, reroute_007_1.height = 10.0, 100.0
	    reroute_008_1.width, reroute_008_1.height = 10.0, 100.0
	    reroute_009_1.width, reroute_009_1.height = 10.0, 100.0
	    group_input_008_1.width, group_input_008_1.height = 140.0, 100.0
	    solid_hair_bake.width, solid_hair_bake.height = 140.0, 100.0
	    set_material.width, set_material.height = 140.0, 100.0
	    group_input_009_1.width, group_input_009_1.height = 140.0, 100.0
	
	    #initialize solid_hair links
	    #store_named_attribute_001_1.Geometry -> group_007.Geometry
	    solid_hair.links.new(store_named_attribute_001_1.outputs[0], group_007.inputs[0])
	    #spline_parameter_001.Factor -> capture_attribute_001_1.Factor
	    solid_hair.links.new(spline_parameter_001.outputs[0], capture_attribute_001_1.inputs[1])
	    #capture_attribute_1.Geometry -> curve_to_mesh.Profile Curve
	    solid_hair.links.new(capture_attribute_1.outputs[0], curve_to_mesh.inputs[1])
	    #combine_xyz_001.Vector -> store_named_attribute_001_1.Value
	    solid_hair.links.new(combine_xyz_001.outputs[0], store_named_attribute_001_1.inputs[3])
	    #switch_1.Output -> capture_attribute_1.Geometry
	    solid_hair.links.new(switch_1.outputs[0], capture_attribute_1.inputs[0])
	    #combine_xyz.Vector -> group_003.Scale
	    solid_hair.links.new(combine_xyz.outputs[0], group_003.inputs[3])
	    #capture_attribute_1.Factor -> combine_xyz_001.Y
	    solid_hair.links.new(capture_attribute_1.outputs[1], combine_xyz_001.inputs[1])
	    #named_attribute_001_1.Attribute -> group_008.Surface UV Map
	    solid_hair.links.new(named_attribute_001_1.outputs[0], group_008.inputs[3])
	    #compare_1.Result -> switch_1.Switch
	    solid_hair.links.new(compare_1.outputs[0], switch_1.inputs[0])
	    #capture_attribute_001_1.Factor -> combine_xyz_001.X
	    solid_hair.links.new(capture_attribute_001_1.outputs[1], combine_xyz_001.inputs[0])
	    #set_curve_radius_1.Curve -> capture_attribute_001_1.Geometry
	    solid_hair.links.new(set_curve_radius_1.outputs[0], capture_attribute_001_1.inputs[0])
	    #resample_curve.Curve -> switch_1.False
	    solid_hair.links.new(resample_curve.outputs[0], switch_1.inputs[1])
	    #domain_size.Point Count -> compare_1.A
	    solid_hair.links.new(domain_size.outputs[0], compare_1.inputs[2])
	    #group_007.Geometry -> group_008.Geometry
	    solid_hair.links.new(group_007.outputs[0], group_008.inputs[0])
	    #object_info.Geometry -> domain_size.Geometry
	    solid_hair.links.new(object_info.outputs[4], domain_size.inputs[0])
	    #curve_to_mesh.Mesh -> store_named_attribute_001_1.Geometry
	    solid_hair.links.new(curve_to_mesh.outputs[0], store_named_attribute_001_1.inputs[0])
	    #transform_geometry_1.Geometry -> resample_curve.Curve
	    solid_hair.links.new(transform_geometry_1.outputs[0], resample_curve.inputs[0])
	    #capture_attribute_001_1.Geometry -> curve_to_mesh.Curve
	    solid_hair.links.new(capture_attribute_001_1.outputs[0], curve_to_mesh.inputs[0])
	    #spline_parameter_2.Factor -> solid_mesh_shape.Value
	    solid_hair.links.new(spline_parameter_2.outputs[0], solid_mesh_shape.inputs[1])
	    #object_info.Geometry -> transform_geometry_1.Geometry
	    solid_hair.links.new(object_info.outputs[4], transform_geometry_1.inputs[0])
	    #solid_mesh_shape.Value -> set_curve_radius_1.Radius
	    solid_hair.links.new(solid_mesh_shape.outputs[0], set_curve_radius_1.inputs[2])
	    #group_003.Geometry -> switch_1.True
	    solid_hair.links.new(group_003.outputs[0], switch_1.inputs[2])
	    #combine_xyz.Vector -> transform_geometry_1.Scale
	    solid_hair.links.new(combine_xyz.outputs[0], transform_geometry_1.inputs[3])
	    #spline_parameter_001.Factor -> capture_attribute_1.Factor
	    solid_hair.links.new(spline_parameter_001.outputs[0], capture_attribute_1.inputs[1])
	    #group_input_3.Level -> group_007.Level
	    solid_hair.links.new(group_input_3.outputs[5], group_007.inputs[1])
	    #group_input_3.Material -> group_007.Material
	    solid_hair.links.new(group_input_3.outputs[6], group_007.inputs[2])
	    #group_input_3.UV Map -> group_007.UV Map
	    solid_hair.links.new(group_input_3.outputs[10], group_007.inputs[6])
	    #group_input_3.Trim Factor -> group_007.Trim Factor
	    solid_hair.links.new(group_input_3.outputs[9], group_007.inputs[5])
	    #group_input_3.Strand Radius -> group_007.Strand Radius
	    solid_hair.links.new(group_input_3.outputs[7], group_007.inputs[3])
	    #group_input_3.Trim Seed -> group_007.Trim Seed
	    solid_hair.links.new(group_input_3.outputs[8], group_007.inputs[4])
	    #group_008.Geometry -> hair_style.Solid Curve
	    solid_hair.links.new(group_008.outputs[0], hair_style.inputs[2])
	    #solid_hair_bake.Geometry -> group_output_4.Geometry
	    solid_hair.links.new(solid_hair_bake.outputs[0], group_output_4.inputs[0])
	    #group_input_001_3.UV Map -> named_attribute_001_1.Name
	    solid_hair.links.new(group_input_001_3.outputs[10], named_attribute_001_1.inputs[0])
	    #group_input_002_2.Surface -> group_008.Surface
	    solid_hair.links.new(group_input_002_2.outputs[1], group_008.inputs[2])
	    #group_input_004_2.Profile Curve -> object_info.Object
	    solid_hair.links.new(group_input_004_2.outputs[12], object_info.inputs[0])
	    #group_input_005_2.Control Points -> resample_curve.Count
	    solid_hair.links.new(group_input_005_2.outputs[3], resample_curve.inputs[2])
	    #group_input_006_1.Resolution -> group_003.Resolution
	    solid_hair.links.new(group_input_006_1.outputs[4], group_003.inputs[0])
	    #group_input_007_1.Profile Height -> combine_xyz.X
	    solid_hair.links.new(group_input_007_1.outputs[13], combine_xyz.inputs[0])
	    #group_input_007_1.Profile Width -> combine_xyz.Y
	    solid_hair.links.new(group_input_007_1.outputs[14], combine_xyz.inputs[1])
	    #group_input_003_2.Geometry -> separate_components.Geometry
	    solid_hair.links.new(group_input_003_2.outputs[0], separate_components.inputs[0])
	    #separate_components.Curve -> set_curve_radius_1.Curve
	    solid_hair.links.new(separate_components.outputs[1], set_curve_radius_1.inputs[0])
	    #reroute_008_1.Output -> join_geometry.Geometry
	    solid_hair.links.new(reroute_008_1.outputs[0], join_geometry.inputs[0])
	    #separate_components.Mesh -> reroute_2.Input
	    solid_hair.links.new(separate_components.outputs[0], reroute_2.inputs[0])
	    #separate_components.Instances -> reroute_001_2.Input
	    solid_hair.links.new(separate_components.outputs[5], reroute_001_2.inputs[0])
	    #separate_components.Point Cloud -> reroute_002_1.Input
	    solid_hair.links.new(separate_components.outputs[3], reroute_002_1.inputs[0])
	    #separate_components.Volume -> reroute_003_1.Input
	    solid_hair.links.new(separate_components.outputs[4], reroute_003_1.inputs[0])
	    #separate_components.Grease Pencil -> reroute_004_1.Input
	    solid_hair.links.new(separate_components.outputs[2], reroute_004_1.inputs[0])
	    #reroute_003_1.Output -> reroute_005_1.Input
	    solid_hair.links.new(reroute_003_1.outputs[0], reroute_005_1.inputs[0])
	    #reroute_004_1.Output -> reroute_006_1.Input
	    solid_hair.links.new(reroute_004_1.outputs[0], reroute_006_1.inputs[0])
	    #reroute_2.Output -> reroute_007_1.Input
	    solid_hair.links.new(reroute_2.outputs[0], reroute_007_1.inputs[0])
	    #reroute_001_2.Output -> reroute_008_1.Input
	    solid_hair.links.new(reroute_001_2.outputs[0], reroute_008_1.inputs[0])
	    #reroute_002_1.Output -> reroute_009_1.Input
	    solid_hair.links.new(reroute_002_1.outputs[0], reroute_009_1.inputs[0])
	    #join_geometry.Geometry -> hair_style.Solid Mesh
	    solid_hair.links.new(join_geometry.outputs[0], hair_style.inputs[1])
	    #group_input_008_1.Hair Style -> hair_style.Menu
	    solid_hair.links.new(group_input_008_1.outputs[2], hair_style.inputs[0])
	    #hair_style.Output -> solid_hair_bake.Geometry
	    solid_hair.links.new(hair_style.outputs[0], solid_hair_bake.inputs[0])
	    #store_named_attribute_001_1.Geometry -> set_material.Geometry
	    solid_hair.links.new(store_named_attribute_001_1.outputs[0], set_material.inputs[0])
	    #group_input_009_1.Mesh Material -> set_material.Material
	    solid_hair.links.new(group_input_009_1.outputs[11], set_material.inputs[2])
	    #reroute_005_1.Output -> join_geometry.Geometry
	    solid_hair.links.new(reroute_005_1.outputs[0], join_geometry.inputs[0])
	    #reroute_009_1.Output -> join_geometry.Geometry
	    solid_hair.links.new(reroute_009_1.outputs[0], join_geometry.inputs[0])
	    #reroute_006_1.Output -> join_geometry.Geometry
	    solid_hair.links.new(reroute_006_1.outputs[0], join_geometry.inputs[0])
	    #reroute_007_1.Output -> join_geometry.Geometry
	    solid_hair.links.new(reroute_007_1.outputs[0], join_geometry.inputs[0])
	    #set_material.Geometry -> join_geometry.Geometry
	    solid_hair.links.new(set_material.outputs[0], join_geometry.inputs[0])
	    hair_style_socket.default_value = 'Solid Mesh'
	    return solid_hair
	return solid_hair_node_group()

	

	
