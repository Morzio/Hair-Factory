import bpy, mathutils

def node():
	#initialize curve_extrude_profile node group
	def curve_extrude_profile_node_group():
	    curve_extrude_profile = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "CURVE_EXTRUDE_PROFILE")
	
	    curve_extrude_profile.color_tag = 'NONE'
	    curve_extrude_profile.description = "Create a curve profile for Convert to Mesh Profile."
	    curve_extrude_profile.default_group_node_width = 140
	    
	
	    curve_extrude_profile.is_modifier = True
	
	    #curve_extrude_profile interface
	    #Socket Geometry
	    geometry_socket = curve_extrude_profile.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket.attribute_domain = 'POINT'
	    geometry_socket.description = "Curve profile."
	
	    #Socket Resolution
	    resolution_socket = curve_extrude_profile.interface.new_socket(name = "Resolution", in_out='INPUT', socket_type = 'NodeSocketInt')
	    resolution_socket.default_value = 32
	    resolution_socket.min_value = 3
	    resolution_socket.max_value = 512
	    resolution_socket.subtype = 'NONE'
	    resolution_socket.attribute_domain = 'POINT'
	    resolution_socket.description = "Curve resolution."
	
	    #Socket Translation
	    translation_socket = curve_extrude_profile.interface.new_socket(name = "Translation", in_out='INPUT', socket_type = 'NodeSocketVector')
	    translation_socket.default_value = (0.0, 0.0, 0.0)
	    translation_socket.min_value = -3.4028234663852886e+38
	    translation_socket.max_value = 3.4028234663852886e+38
	    translation_socket.subtype = 'TRANSLATION'
	    translation_socket.attribute_domain = 'POINT'
	    translation_socket.description = "Translate curve profile from origin."
	
	    #Socket Rotation
	    rotation_socket = curve_extrude_profile.interface.new_socket(name = "Rotation", in_out='INPUT', socket_type = 'NodeSocketRotation')
	    rotation_socket.default_value = (0.0, 0.0, 0.0)
	    rotation_socket.attribute_domain = 'POINT'
	    rotation_socket.description = "Rotate curve profile from origin."
	
	    #Socket Scale
	    scale_socket = curve_extrude_profile.interface.new_socket(name = "Scale", in_out='INPUT', socket_type = 'NodeSocketVector')
	    scale_socket.default_value = (1.0, 1.0, 1.0)
	    scale_socket.min_value = -3.4028234663852886e+38
	    scale_socket.max_value = 3.4028234663852886e+38
	    scale_socket.subtype = 'XYZ'
	    scale_socket.attribute_domain = 'POINT'
	    scale_socket.description = "Scale curve profile from origin."
	
	
	    #initialize curve_extrude_profile nodes
	    #node Group Input
	    group_input = curve_extrude_profile.nodes.new("NodeGroupInput")
	    group_input.name = "Group Input"
	    group_input.outputs[1].hide = True
	    group_input.outputs[2].hide = True
	    group_input.outputs[3].hide = True
	    group_input.outputs[4].hide = True
	
	    #node Group Output
	    group_output = curve_extrude_profile.nodes.new("NodeGroupOutput")
	    group_output.name = "Group Output"
	    group_output.is_active_output = True
	    group_output.inputs[1].hide = True
	
	    #node Curve Circle
	    curve_circle = curve_extrude_profile.nodes.new("GeometryNodeCurvePrimitiveCircle")
	    curve_circle.name = "Curve Circle"
	    curve_circle.hide = True
	    curve_circle.mode = 'RADIUS'
	    curve_circle.inputs[1].hide = True
	    curve_circle.inputs[2].hide = True
	    curve_circle.inputs[3].hide = True
	    curve_circle.inputs[4].hide = True
	    curve_circle.outputs[1].hide = True
	    #Radius
	    curve_circle.inputs[4].default_value = 1.0
	
	    #node Radial Offset
	    radial_offset = curve_extrude_profile.nodes.new("ShaderNodeFloatCurve")
	    radial_offset.label = "Radial Offset"
	    radial_offset.name = "Radial Offset"
	    #mapping settings
	    radial_offset.mapping.extend = 'EXTRAPOLATED'
	    radial_offset.mapping.tone = 'STANDARD'
	    radial_offset.mapping.black_level = (0.0, 0.0, 0.0)
	    radial_offset.mapping.white_level = (1.0, 1.0, 1.0)
	    radial_offset.mapping.clip_min_x = 0.0
	    radial_offset.mapping.clip_min_y = 0.0
	    radial_offset.mapping.clip_max_x = 1.0
	    radial_offset.mapping.clip_max_y = 1.0
	    radial_offset.mapping.use_clip = True
	    #curve 0
	    radial_offset_curve_0 = radial_offset.mapping.curves[0]
	    radial_offset_curve_0_point_0 = radial_offset_curve_0.points[0]
	    radial_offset_curve_0_point_0.location = (0.0, 1.0)
	    radial_offset_curve_0_point_0.handle_type = 'AUTO'
	    radial_offset_curve_0_point_1 = radial_offset_curve_0.points[1]
	    radial_offset_curve_0_point_1.location = (0.25, 1.0)
	    radial_offset_curve_0_point_1.handle_type = 'AUTO'
	    radial_offset_curve_0_point_2 = radial_offset_curve_0.points.new(0.5, 1.0)
	    radial_offset_curve_0_point_2.handle_type = 'AUTO'
	    radial_offset_curve_0_point_3 = radial_offset_curve_0.points.new(0.75, 1.0)
	    radial_offset_curve_0_point_3.handle_type = 'AUTO'
	    radial_offset_curve_0_point_4 = radial_offset_curve_0.points.new(1.0, 1.0)
	    radial_offset_curve_0_point_4.handle_type = 'AUTO'
	    #update curve after changes
	    radial_offset.mapping.update()
	    radial_offset.inputs[0].hide = True
	    #Factor
	    radial_offset.inputs[0].default_value = 1.0
	
	    #node Spline Parameter
	    spline_parameter = curve_extrude_profile.nodes.new("GeometryNodeSplineParameter")
	    spline_parameter.name = "Spline Parameter"
	    spline_parameter.outputs[1].hide = True
	    spline_parameter.outputs[2].hide = True
	
	    #node Set Position
	    set_position = curve_extrude_profile.nodes.new("GeometryNodeSetPosition")
	    set_position.name = "Set Position"
	    set_position.hide = True
	    set_position.inputs[1].hide = True
	    set_position.inputs[3].hide = True
	    #Selection
	    set_position.inputs[1].default_value = True
	    #Offset
	    set_position.inputs[3].default_value = (0.0, 0.0, 0.0)
	
	    #node Position
	    position = curve_extrude_profile.nodes.new("GeometryNodeInputPosition")
	    position.name = "Position"
	
	    #node Vector Math
	    vector_math = curve_extrude_profile.nodes.new("ShaderNodeVectorMath")
	    vector_math.name = "Vector Math"
	    vector_math.hide = True
	    vector_math.operation = 'SCALE'
	
	    #node Transform Geometry
	    transform_geometry = curve_extrude_profile.nodes.new("GeometryNodeTransform")
	    transform_geometry.name = "Transform Geometry"
	    transform_geometry.hide = True
	    transform_geometry.mode = 'COMPONENTS'
	
	    #node Group Input.001
	    group_input_001 = curve_extrude_profile.nodes.new("NodeGroupInput")
	    group_input_001.name = "Group Input.001"
	    group_input_001.outputs[0].hide = True
	    group_input_001.outputs[4].hide = True
	
	    #node Frame
	    frame = curve_extrude_profile.nodes.new("NodeFrame")
	    frame.label = "Radial Offset"
	    frame.name = "Frame"
	    frame.label_size = 20
	    frame.shrink = True
	
	    #node Reroute
	    reroute = curve_extrude_profile.nodes.new("NodeReroute")
	    reroute.name = "Reroute"
	    reroute.socket_idname = "NodeSocketVector"
	    #node Reroute.001
	    reroute_001 = curve_extrude_profile.nodes.new("NodeReroute")
	    reroute_001.name = "Reroute.001"
	    reroute_001.socket_idname = "NodeSocketVector"
	    #node Frame.001
	    frame_001 = curve_extrude_profile.nodes.new("NodeFrame")
	    frame_001.label = "X value is percantage of 360 deg from x positve."
	    frame_001.name = "Frame.001"
	    frame_001.label_size = 20
	    frame_001.shrink = True
	
	    #node Frame.002
	    frame_002 = curve_extrude_profile.nodes.new("NodeFrame")
	    frame_002.label = "Y value is the distance from origin. ([0,0,0])"
	    frame_002.name = "Frame.002"
	    frame_002.label_size = 20
	    frame_002.shrink = True
	
	
	
	
	    #Set parents
	    radial_offset.parent = frame
	    spline_parameter.parent = frame
	    position.parent = frame
	    vector_math.parent = frame
	
	    #Set locations
	    group_input.location = (-340.0, -22.570165634155273)
	    group_output.location = (362.9671936035156, -40.626277923583984)
	    curve_circle.location = (-166.6719512939453, -46.762123107910156)
	    radial_offset.location = (33.486419677734375, -129.11273193359375)
	    spline_parameter.location = (30.04144287109375, -424.0594482421875)
	    set_position.location = (4.4881591796875, -53.521385192871094)
	    position.location = (592.2982177734375, -74.47775268554688)
	    vector_math.location = (593.3895263671875, -44.6279296875)
	    transform_geometry.location = (185.82901000976562, -66.2401351928711)
	    group_input_001.location = (10.093160629272461, -81.2525405883789)
	    frame.location = (-352.0, -180.0)
	    reroute.location = (380.5245666503906, -181.39073181152344)
	    reroute_001.location = (5.314706802368164, -181.74554443359375)
	    frame_001.location = (422.1756591796875, -181.8056182861328)
	    frame_002.location = (422.1756591796875, -257.09149169921875)
	
	    #Set dimensions
	    group_input.width, group_input.height = 140.0, 100.0
	    group_output.width, group_output.height = 140.0, 100.0
	    curve_circle.width, curve_circle.height = 140.0, 100.0
	    radial_offset.width, radial_offset.height = 700.0, 100.0
	    spline_parameter.width, spline_parameter.height = 140.0, 100.0
	    set_position.width, set_position.height = 140.0, 100.0
	    position.width, position.height = 140.0, 100.0
	    vector_math.width, vector_math.height = 140.0, 100.0
	    transform_geometry.width, transform_geometry.height = 140.0, 100.0
	    group_input_001.width, group_input_001.height = 140.0, 100.0
	    frame.width, frame.height = 763.0, 506.0
	    reroute.width, reroute.height = 10.0, 100.0
	    reroute_001.width, reroute_001.height = 10.0, 100.0
	    frame_001.width, frame_001.height = 763.0001220703125, 58.84747314453125
	    frame_002.width, frame_002.height = 763.0001220703125, 58.84722900390625
	
	    #initialize curve_extrude_profile links
	    #spline_parameter.Factor -> radial_offset.Value
	    curve_extrude_profile.links.new(spline_parameter.outputs[0], radial_offset.inputs[1])
	    #curve_circle.Curve -> set_position.Geometry
	    curve_extrude_profile.links.new(curve_circle.outputs[0], set_position.inputs[0])
	    #position.Position -> vector_math.Vector
	    curve_extrude_profile.links.new(position.outputs[0], vector_math.inputs[0])
	    #radial_offset.Value -> vector_math.Scale
	    curve_extrude_profile.links.new(radial_offset.outputs[0], vector_math.inputs[3])
	    #reroute_001.Output -> set_position.Position
	    curve_extrude_profile.links.new(reroute_001.outputs[0], set_position.inputs[2])
	    #group_input.Resolution -> curve_circle.Resolution
	    curve_extrude_profile.links.new(group_input.outputs[0], curve_circle.inputs[0])
	    #set_position.Geometry -> transform_geometry.Geometry
	    curve_extrude_profile.links.new(set_position.outputs[0], transform_geometry.inputs[0])
	    #group_input_001.Translation -> transform_geometry.Translation
	    curve_extrude_profile.links.new(group_input_001.outputs[1], transform_geometry.inputs[1])
	    #group_input_001.Rotation -> transform_geometry.Rotation
	    curve_extrude_profile.links.new(group_input_001.outputs[2], transform_geometry.inputs[2])
	    #group_input_001.Scale -> transform_geometry.Scale
	    curve_extrude_profile.links.new(group_input_001.outputs[3], transform_geometry.inputs[3])
	    #transform_geometry.Geometry -> group_output.Geometry
	    curve_extrude_profile.links.new(transform_geometry.outputs[0], group_output.inputs[0])
	    #vector_math.Vector -> reroute.Input
	    curve_extrude_profile.links.new(vector_math.outputs[0], reroute.inputs[0])
	    #reroute.Output -> reroute_001.Input
	    curve_extrude_profile.links.new(reroute.outputs[0], reroute_001.inputs[0])
	    return curve_extrude_profile
	return curve_extrude_profile_node_group()

	

	
