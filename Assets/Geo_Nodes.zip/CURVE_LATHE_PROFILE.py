import bpy, mathutils

def node():
	#initialize curve_lathe_profile node group
	def curve_lathe_profile_node_group():
	    curve_lathe_profile = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "CURVE_LATHE_PROFILE")
	
	    curve_lathe_profile.color_tag = 'NONE'
	    curve_lathe_profile.description = "Create a lathe curve profile."
	    curve_lathe_profile.default_group_node_width = 140
	    
	
	    curve_lathe_profile.is_modifier = True
	
	    #curve_lathe_profile interface
	    #Socket Geometry
	    geometry_socket = curve_lathe_profile.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket.attribute_domain = 'POINT'
	    geometry_socket.description = "Curve Profile."
	
	    #Socket Control Points
	    control_points_socket = curve_lathe_profile.interface.new_socket(name = "Control Points", in_out='INPUT', socket_type = 'NodeSocketInt')
	    control_points_socket.default_value = 10
	    control_points_socket.min_value = 1
	    control_points_socket.max_value = 100000
	    control_points_socket.subtype = 'NONE'
	    control_points_socket.attribute_domain = 'POINT'
	    control_points_socket.description = "Amount of points for each curve."
	
	
	    #initialize curve_lathe_profile nodes
	    #node Group Output
	    group_output = curve_lathe_profile.nodes.new("NodeGroupOutput")
	    group_output.name = "Group Output"
	    group_output.is_active_output = True
	    group_output.inputs[1].hide = True
	
	    #node Curve Line
	    curve_line = curve_lathe_profile.nodes.new("GeometryNodeCurvePrimitiveLine")
	    curve_line.name = "Curve Line"
	    curve_line.hide = True
	    curve_line.mode = 'DIRECTION'
	    curve_line.inputs[0].hide = True
	    curve_line.inputs[1].hide = True
	    curve_line.inputs[2].hide = True
	    curve_line.inputs[3].hide = True
	    #Start
	    curve_line.inputs[0].default_value = (0.0, 0.0, 0.0)
	    #Direction
	    curve_line.inputs[2].default_value = (1.0, 0.0, 0.0)
	    #Length
	    curve_line.inputs[3].default_value = 1.0
	
	    #node Curve Line.001
	    curve_line_001 = curve_lathe_profile.nodes.new("GeometryNodeCurvePrimitiveLine")
	    curve_line_001.name = "Curve Line.001"
	    curve_line_001.hide = True
	    curve_line_001.mode = 'DIRECTION'
	    curve_line_001.inputs[1].hide = True
	    curve_line_001.inputs[2].hide = True
	    #Direction
	    curve_line_001.inputs[2].default_value = (0.0, -1.0, 0.0)
	
	    #node Resample Curve
	    resample_curve = curve_lathe_profile.nodes.new("GeometryNodeResampleCurve")
	    resample_curve.name = "Resample Curve"
	    resample_curve.hide = True
	    resample_curve.keep_last_segment = True
	    resample_curve.mode = 'COUNT'
	    resample_curve.inputs[1].hide = True
	    resample_curve.inputs[3].hide = True
	    #Selection
	    resample_curve.inputs[1].default_value = True
	
	    #node Resample Curve.001
	    resample_curve_001 = curve_lathe_profile.nodes.new("GeometryNodeResampleCurve")
	    resample_curve_001.name = "Resample Curve.001"
	    resample_curve_001.hide = True
	    resample_curve_001.keep_last_segment = True
	    resample_curve_001.mode = 'COUNT'
	    resample_curve_001.inputs[1].hide = True
	    resample_curve_001.inputs[3].hide = True
	    #Selection
	    resample_curve_001.inputs[1].default_value = True
	
	    #node Side Profile
	    side_profile = curve_lathe_profile.nodes.new("ShaderNodeFloatCurve")
	    side_profile.label = "Side Profile"
	    side_profile.name = "Side Profile"
	    #mapping settings
	    side_profile.mapping.extend = 'EXTRAPOLATED'
	    side_profile.mapping.tone = 'STANDARD'
	    side_profile.mapping.black_level = (0.0, 0.0, 0.0)
	    side_profile.mapping.white_level = (1.0, 1.0, 1.0)
	    side_profile.mapping.clip_min_x = 0.0
	    side_profile.mapping.clip_min_y = 0.0
	    side_profile.mapping.clip_max_x = 1.0
	    side_profile.mapping.clip_max_y = 1.0
	    side_profile.mapping.use_clip = True
	    #curve 0
	    side_profile_curve_0 = side_profile.mapping.curves[0]
	    side_profile_curve_0_point_0 = side_profile_curve_0.points[0]
	    side_profile_curve_0_point_0.location = (0.0, 0.0)
	    side_profile_curve_0_point_0.handle_type = 'AUTO'
	    side_profile_curve_0_point_1 = side_profile_curve_0.points[1]
	    side_profile_curve_0_point_1.location = (0.33181822299957275, 0.7687497735023499)
	    side_profile_curve_0_point_1.handle_type = 'AUTO'
	    side_profile_curve_0_point_2 = side_profile_curve_0.points.new(0.7090910077095032, 0.9249997735023499)
	    side_profile_curve_0_point_2.handle_type = 'AUTO'
	    side_profile_curve_0_point_3 = side_profile_curve_0.points.new(1.0, 1.0)
	    side_profile_curve_0_point_3.handle_type = 'AUTO'
	    #update curve after changes
	    side_profile.mapping.update()
	    side_profile.inputs[0].hide = True
	    #Factor
	    side_profile.inputs[0].default_value = 1.0
	
	    #node Spline Parameter
	    spline_parameter = curve_lathe_profile.nodes.new("GeometryNodeSplineParameter")
	    spline_parameter.name = "Spline Parameter"
	    spline_parameter.outputs[1].hide = True
	    spline_parameter.outputs[2].hide = True
	
	    #node Set Position
	    set_position = curve_lathe_profile.nodes.new("GeometryNodeSetPosition")
	    set_position.name = "Set Position"
	    set_position.hide = True
	    set_position.inputs[1].hide = True
	    set_position.inputs[2].hide = True
	    #Selection
	    set_position.inputs[1].default_value = True
	    #Position
	    set_position.inputs[2].default_value = (0.0, 0.0, 0.0)
	
	    #node Combine XYZ
	    combine_xyz = curve_lathe_profile.nodes.new("ShaderNodeCombineXYZ")
	    combine_xyz.name = "Combine XYZ"
	    combine_xyz.hide = True
	    combine_xyz.inputs[0].hide = True
	    combine_xyz.inputs[2].hide = True
	    #X
	    combine_xyz.inputs[0].default_value = 0.0
	    #Z
	    combine_xyz.inputs[2].default_value = 0.0
	
	    #node Top Profile
	    top_profile = curve_lathe_profile.nodes.new("ShaderNodeFloatCurve")
	    top_profile.label = "Top Profile"
	    top_profile.name = "Top Profile"
	    #mapping settings
	    top_profile.mapping.extend = 'EXTRAPOLATED'
	    top_profile.mapping.tone = 'STANDARD'
	    top_profile.mapping.black_level = (0.0, 0.0, 0.0)
	    top_profile.mapping.white_level = (1.0, 1.0, 1.0)
	    top_profile.mapping.clip_min_x = 0.0
	    top_profile.mapping.clip_min_y = 0.0
	    top_profile.mapping.clip_max_x = 1.0
	    top_profile.mapping.clip_max_y = 1.0
	    top_profile.mapping.use_clip = True
	    #curve 0
	    top_profile_curve_0 = top_profile.mapping.curves[0]
	    top_profile_curve_0_point_0 = top_profile_curve_0.points[0]
	    top_profile_curve_0_point_0.location = (0.0, 0.0)
	    top_profile_curve_0_point_0.handle_type = 'AUTO'
	    top_profile_curve_0_point_1 = top_profile_curve_0.points[1]
	    top_profile_curve_0_point_1.location = (0.059090904891490936, 0.7062501907348633)
	    top_profile_curve_0_point_1.handle_type = 'AUTO'
	    top_profile_curve_0_point_2 = top_profile_curve_0.points.new(0.2090909332036972, 0.8562501072883606)
	    top_profile_curve_0_point_2.handle_type = 'AUTO'
	    top_profile_curve_0_point_3 = top_profile_curve_0.points.new(0.6227271556854248, 1.0)
	    top_profile_curve_0_point_3.handle_type = 'AUTO'
	    top_profile_curve_0_point_4 = top_profile_curve_0.points.new(0.8772727251052856, 0.9562499523162842)
	    top_profile_curve_0_point_4.handle_type = 'AUTO'
	    top_profile_curve_0_point_5 = top_profile_curve_0.points.new(1.0, 0.7625001668930054)
	    top_profile_curve_0_point_5.handle_type = 'AUTO'
	    #update curve after changes
	    top_profile.mapping.update()
	    top_profile.inputs[0].hide = True
	    #Factor
	    top_profile.inputs[0].default_value = 1.0
	
	    #node Spline Parameter.001
	    spline_parameter_001 = curve_lathe_profile.nodes.new("GeometryNodeSplineParameter")
	    spline_parameter_001.name = "Spline Parameter.001"
	    spline_parameter_001.outputs[1].hide = True
	    spline_parameter_001.outputs[2].hide = True
	
	    #node Combine XYZ.001
	    combine_xyz_001 = curve_lathe_profile.nodes.new("ShaderNodeCombineXYZ")
	    combine_xyz_001.name = "Combine XYZ.001"
	    combine_xyz_001.hide = True
	    combine_xyz_001.inputs[1].hide = True
	    combine_xyz_001.inputs[2].hide = True
	    #Y
	    combine_xyz_001.inputs[1].default_value = 0.0
	    #Z
	    combine_xyz_001.inputs[2].default_value = 0.0
	
	    #node Set Position.001
	    set_position_001 = curve_lathe_profile.nodes.new("GeometryNodeSetPosition")
	    set_position_001.name = "Set Position.001"
	    set_position_001.hide = True
	    set_position_001.inputs[1].hide = True
	    set_position_001.inputs[2].hide = True
	    #Selection
	    set_position_001.inputs[1].default_value = True
	    #Position
	    set_position_001.inputs[2].default_value = (0.0, 0.0, 0.0)
	
	    #node Join Geometry
	    join_geometry = curve_lathe_profile.nodes.new("GeometryNodeJoinGeometry")
	    join_geometry.name = "Join Geometry"
	    join_geometry.hide = True
	
	    #node Sample Curve
	    sample_curve = curve_lathe_profile.nodes.new("GeometryNodeSampleCurve")
	    sample_curve.name = "Sample Curve"
	    sample_curve.hide = True
	    sample_curve.data_type = 'FLOAT'
	    sample_curve.mode = 'FACTOR'
	    sample_curve.use_all_curves = False
	    sample_curve.inputs[1].hide = True
	    sample_curve.inputs[2].hide = True
	    sample_curve.inputs[3].hide = True
	    sample_curve.inputs[4].hide = True
	    sample_curve.outputs[0].hide = True
	    sample_curve.outputs[2].hide = True
	    sample_curve.outputs[3].hide = True
	    #Value
	    sample_curve.inputs[1].default_value = 0.0
	    #Factor
	    sample_curve.inputs[2].default_value = 1.0
	    #Curve Index
	    sample_curve.inputs[4].default_value = 0
	
	    #node Separate XYZ
	    separate_xyz = curve_lathe_profile.nodes.new("ShaderNodeSeparateXYZ")
	    separate_xyz.name = "Separate XYZ"
	    separate_xyz.hide = True
	    separate_xyz.outputs[0].hide = True
	    separate_xyz.outputs[2].hide = True
	
	    #node Curve to Points
	    curve_to_points = curve_lathe_profile.nodes.new("GeometryNodeCurveToPoints")
	    curve_to_points.name = "Curve to Points"
	    curve_to_points.hide = True
	    curve_to_points.mode = 'COUNT'
	    curve_to_points.inputs[1].hide = True
	    curve_to_points.inputs[2].hide = True
	    curve_to_points.outputs[1].hide = True
	    curve_to_points.outputs[2].hide = True
	    curve_to_points.outputs[3].hide = True
	    #Count
	    curve_to_points.inputs[1].default_value = 10
	
	    #node Merge by Distance
	    merge_by_distance = curve_lathe_profile.nodes.new("GeometryNodeMergeByDistance")
	    merge_by_distance.name = "Merge by Distance"
	    merge_by_distance.hide = True
	    merge_by_distance.mode = 'ALL'
	    merge_by_distance.inputs[1].hide = True
	    merge_by_distance.inputs[2].hide = True
	    #Selection
	    merge_by_distance.inputs[1].default_value = True
	    #Distance
	    merge_by_distance.inputs[2].default_value = 0.0010000000474974513
	
	    #node Points to Curves
	    points_to_curves = curve_lathe_profile.nodes.new("GeometryNodePointsToCurves")
	    points_to_curves.name = "Points to Curves"
	    points_to_curves.hide = True
	    points_to_curves.inputs[1].hide = True
	    points_to_curves.inputs[2].hide = True
	    #Curve Group ID
	    points_to_curves.inputs[1].default_value = 0
	    #Weight
	    points_to_curves.inputs[2].default_value = 0.0
	
	    #node Group Input.001
	    group_input_001 = curve_lathe_profile.nodes.new("NodeGroupInput")
	    group_input_001.name = "Group Input.001"
	    group_input_001.outputs[1].hide = True
	
	    #node Group Input.002
	    group_input_002 = curve_lathe_profile.nodes.new("NodeGroupInput")
	    group_input_002.name = "Group Input.002"
	    group_input_002.outputs[1].hide = True
	
	    #node Resample Curve.002
	    resample_curve_002 = curve_lathe_profile.nodes.new("GeometryNodeResampleCurve")
	    resample_curve_002.name = "Resample Curve.002"
	    resample_curve_002.hide = True
	    resample_curve_002.keep_last_segment = True
	    resample_curve_002.mode = 'COUNT'
	    resample_curve_002.inputs[1].hide = True
	    resample_curve_002.inputs[3].hide = True
	    #Selection
	    resample_curve_002.inputs[1].default_value = True
	
	    #node Group Input.003
	    group_input_003 = curve_lathe_profile.nodes.new("NodeGroupInput")
	    group_input_003.name = "Group Input.003"
	    group_input_003.outputs[1].hide = True
	
	    #node Frame
	    frame = curve_lathe_profile.nodes.new("NodeFrame")
	    frame.label = "Side Profile"
	    frame.name = "Frame"
	    frame.label_size = 20
	    frame.shrink = True
	
	    #node Frame.001
	    frame_001 = curve_lathe_profile.nodes.new("NodeFrame")
	    frame_001.label = "Top Profile"
	    frame_001.name = "Frame.001"
	    frame_001.label_size = 20
	    frame_001.shrink = True
	
	    #node Transform Geometry
	    transform_geometry = curve_lathe_profile.nodes.new("GeometryNodeTransform")
	    transform_geometry.name = "Transform Geometry"
	    transform_geometry.hide = True
	    transform_geometry.mode = 'COMPONENTS'
	    transform_geometry.inputs[1].hide = True
	    transform_geometry.inputs[2].hide = True
	    transform_geometry.inputs[3].hide = True
	    transform_geometry.inputs[4].hide = True
	    #Translation
	    transform_geometry.inputs[1].default_value = (0.0, 0.0, 0.0)
	    #Rotation
	    transform_geometry.inputs[2].default_value = (0.0, 0.0, 0.0)
	    #Scale
	    transform_geometry.inputs[3].default_value = (0.5, 0.5, 0.5)
	
	
	
	
	    #Set parents
	    curve_line.parent = frame
	    curve_line_001.parent = frame_001
	    resample_curve.parent = frame
	    resample_curve_001.parent = frame_001
	    side_profile.parent = frame
	    spline_parameter.parent = frame
	    set_position.parent = frame
	    combine_xyz.parent = frame
	    top_profile.parent = frame_001
	    spline_parameter_001.parent = frame_001
	    combine_xyz_001.parent = frame_001
	    set_position_001.parent = frame_001
	    sample_curve.parent = frame_001
	    separate_xyz.parent = frame_001
	    group_input_001.parent = frame
	    group_input_002.parent = frame_001
	
	    #Set locations
	    group_output.location = (847.0892944335938, -1.7403374910354614)
	    curve_line.location = (213.19046020507812, -45.48004150390625)
	    curve_line_001.location = (211.72186279296875, -140.15972900390625)
	    resample_curve.location = (214.90252685546875, -102.06854248046875)
	    resample_curve_001.location = (209.9552001953125, -194.2918701171875)
	    side_profile.location = (106.04864501953125, -225.49862670898438)
	    spline_parameter.location = (100.9949951171875, -517.876220703125)
	    set_position.location = (209.33721923828125, -152.04647827148438)
	    combine_xyz.location = (210.1273193359375, -190.44638061523438)
	    top_profile.location = (108.05885314941406, -317.6383056640625)
	    spline_parameter_001.location = (103.00517272949219, -613.4969482421875)
	    combine_xyz_001.location = (210.39794921875, -284.3277587890625)
	    set_position_001.location = (211.3472900390625, -247.856689453125)
	    join_geometry.location = (476.5655822753906, -257.0146484375)
	    sample_curve.location = (209.058349609375, -44.90753173828125)
	    separate_xyz.location = (211.63897705078125, -81.11376953125)
	    curve_to_points.location = (479.4990234375, -197.56622314453125)
	    merge_by_distance.location = (477.83453369140625, -140.28204345703125)
	    points_to_curves.location = (476.49298095703125, -80.60548400878906)
	    group_input_001.location = (29.713897705078125, -86.81039428710938)
	    group_input_002.location = (29.986236572265625, -178.015380859375)
	    resample_curve_002.location = (478.0709228515625, -26.751327514648438)
	    group_input_003.location = (475.1464538574219, 55.57201385498047)
	    frame.location = (-348.0, -99.0)
	    frame_001.location = (51.0, -323.0)
	    transform_geometry.location = (667.0406494140625, -27.41928482055664)
	
	    #Set dimensions
	    group_output.width, group_output.height = 140.0, 100.0
	    curve_line.width, curve_line.height = 140.0, 100.0
	    curve_line_001.width, curve_line_001.height = 140.0, 100.0
	    resample_curve.width, resample_curve.height = 140.0, 100.0
	    resample_curve_001.width, resample_curve_001.height = 140.0, 100.0
	    side_profile.width, side_profile.height = 240.0, 100.0
	    spline_parameter.width, spline_parameter.height = 140.0, 100.0
	    set_position.width, set_position.height = 140.0, 100.0
	    combine_xyz.width, combine_xyz.height = 140.0, 100.0
	    top_profile.width, top_profile.height = 240.0, 100.0
	    spline_parameter_001.width, spline_parameter_001.height = 140.0, 100.0
	    combine_xyz_001.width, combine_xyz_001.height = 140.0, 100.0
	    set_position_001.width, set_position_001.height = 140.0, 100.0
	    join_geometry.width, join_geometry.height = 140.0, 100.0
	    sample_curve.width, sample_curve.height = 140.0, 100.0
	    separate_xyz.width, separate_xyz.height = 140.0, 100.0
	    curve_to_points.width, curve_to_points.height = 140.0, 100.0
	    merge_by_distance.width, merge_by_distance.height = 140.0, 100.0
	    points_to_curves.width, points_to_curves.height = 140.0, 100.0
	    group_input_001.width, group_input_001.height = 140.0, 100.0
	    group_input_002.width, group_input_002.height = 140.0, 100.0
	    resample_curve_002.width, resample_curve_002.height = 140.0, 100.0
	    group_input_003.width, group_input_003.height = 140.0, 100.0
	    frame.width, frame.height = 385.0, 600.0
	    frame_001.width, frame_001.height = 382.0, 695.0
	    transform_geometry.width, transform_geometry.height = 140.0, 100.0
	
	    #initialize curve_lathe_profile links
	    #curve_line.Curve -> resample_curve.Curve
	    curve_lathe_profile.links.new(curve_line.outputs[0], resample_curve.inputs[0])
	    #curve_line_001.Curve -> resample_curve_001.Curve
	    curve_lathe_profile.links.new(curve_line_001.outputs[0], resample_curve_001.inputs[0])
	    #spline_parameter.Factor -> side_profile.Value
	    curve_lathe_profile.links.new(spline_parameter.outputs[0], side_profile.inputs[1])
	    #resample_curve.Curve -> set_position.Geometry
	    curve_lathe_profile.links.new(resample_curve.outputs[0], set_position.inputs[0])
	    #spline_parameter_001.Factor -> top_profile.Value
	    curve_lathe_profile.links.new(spline_parameter_001.outputs[0], top_profile.inputs[1])
	    #resample_curve_001.Curve -> set_position_001.Geometry
	    curve_lathe_profile.links.new(resample_curve_001.outputs[0], set_position_001.inputs[0])
	    #set_position_001.Geometry -> join_geometry.Geometry
	    curve_lathe_profile.links.new(set_position_001.outputs[0], join_geometry.inputs[0])
	    #side_profile.Value -> combine_xyz.Y
	    curve_lathe_profile.links.new(side_profile.outputs[0], combine_xyz.inputs[1])
	    #combine_xyz.Vector -> set_position.Offset
	    curve_lathe_profile.links.new(combine_xyz.outputs[0], set_position.inputs[3])
	    #set_position.Geometry -> sample_curve.Curves
	    curve_lathe_profile.links.new(set_position.outputs[0], sample_curve.inputs[0])
	    #sample_curve.Position -> curve_line_001.Start
	    curve_lathe_profile.links.new(sample_curve.outputs[1], curve_line_001.inputs[0])
	    #sample_curve.Position -> separate_xyz.Vector
	    curve_lathe_profile.links.new(sample_curve.outputs[1], separate_xyz.inputs[0])
	    #separate_xyz.Y -> curve_line_001.Length
	    curve_lathe_profile.links.new(separate_xyz.outputs[1], curve_line_001.inputs[3])
	    #top_profile.Value -> combine_xyz_001.X
	    curve_lathe_profile.links.new(top_profile.outputs[0], combine_xyz_001.inputs[0])
	    #combine_xyz_001.Vector -> set_position_001.Offset
	    curve_lathe_profile.links.new(combine_xyz_001.outputs[0], set_position_001.inputs[3])
	    #transform_geometry.Geometry -> group_output.Geometry
	    curve_lathe_profile.links.new(transform_geometry.outputs[0], group_output.inputs[0])
	    #join_geometry.Geometry -> curve_to_points.Curve
	    curve_lathe_profile.links.new(join_geometry.outputs[0], curve_to_points.inputs[0])
	    #curve_to_points.Points -> merge_by_distance.Geometry
	    curve_lathe_profile.links.new(curve_to_points.outputs[0], merge_by_distance.inputs[0])
	    #merge_by_distance.Geometry -> points_to_curves.Points
	    curve_lathe_profile.links.new(merge_by_distance.outputs[0], points_to_curves.inputs[0])
	    #group_input_001.Control Points -> resample_curve.Count
	    curve_lathe_profile.links.new(group_input_001.outputs[0], resample_curve.inputs[2])
	    #group_input_002.Control Points -> resample_curve_001.Count
	    curve_lathe_profile.links.new(group_input_002.outputs[0], resample_curve_001.inputs[2])
	    #points_to_curves.Curves -> resample_curve_002.Curve
	    curve_lathe_profile.links.new(points_to_curves.outputs[0], resample_curve_002.inputs[0])
	    #group_input_003.Control Points -> resample_curve_002.Count
	    curve_lathe_profile.links.new(group_input_003.outputs[0], resample_curve_002.inputs[2])
	    #resample_curve_002.Curve -> transform_geometry.Geometry
	    curve_lathe_profile.links.new(resample_curve_002.outputs[0], transform_geometry.inputs[0])
	    #set_position.Geometry -> join_geometry.Geometry
	    curve_lathe_profile.links.new(set_position.outputs[0], join_geometry.inputs[0])
	    return curve_lathe_profile
	return curve_lathe_profile_node_group()

	

	
