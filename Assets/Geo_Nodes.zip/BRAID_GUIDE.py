import bpy, mathutils

def node():
	#initialize curve_root_001 node group
	def curve_root_001_node_group():
	    curve_root_001 = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Curve Root.001")
	
	    curve_root_001.color_tag = 'NONE'
	    curve_root_001.description = "Reads information about each curve's root point"
	    curve_root_001.default_group_node_width = 140
	    
	
	
	    #curve_root_001 interface
	    #Socket Root Selection
	    root_selection_socket = curve_root_001.interface.new_socket(name = "Root Selection", in_out='OUTPUT', socket_type = 'NodeSocketBool')
	    root_selection_socket.default_value = False
	    root_selection_socket.attribute_domain = 'POINT'
	    root_selection_socket.description = "Boolean selection of curve root points"
	
	    #Socket Root Position
	    root_position_socket = curve_root_001.interface.new_socket(name = "Root Position", in_out='OUTPUT', socket_type = 'NodeSocketVector')
	    root_position_socket.default_value = (0.0, 0.0, 0.0)
	    root_position_socket.min_value = -3.4028234663852886e+38
	    root_position_socket.max_value = 3.4028234663852886e+38
	    root_position_socket.subtype = 'NONE'
	    root_position_socket.attribute_domain = 'CURVE'
	    root_position_socket.description = "Position of the root point of a curve"
	
	    #Socket Root Direction
	    root_direction_socket = curve_root_001.interface.new_socket(name = "Root Direction", in_out='OUTPUT', socket_type = 'NodeSocketVector')
	    root_direction_socket.default_value = (0.0, 0.0, 0.0)
	    root_direction_socket.min_value = -3.4028234663852886e+38
	    root_direction_socket.max_value = 3.4028234663852886e+38
	    root_direction_socket.subtype = 'NONE'
	    root_direction_socket.attribute_domain = 'CURVE'
	    root_direction_socket.description = "Direction of the root segment of a curve"
	
	    #Socket Root Index
	    root_index_socket = curve_root_001.interface.new_socket(name = "Root Index", in_out='OUTPUT', socket_type = 'NodeSocketInt')
	    root_index_socket.default_value = 0
	    root_index_socket.min_value = -2147483648
	    root_index_socket.max_value = 2147483647
	    root_index_socket.subtype = 'NONE'
	    root_index_socket.attribute_domain = 'CURVE'
	    root_index_socket.description = "Index of the root point of a curve"
	
	
	    #initialize curve_root_001 nodes
	    #node Position.002
	    position_002 = curve_root_001.nodes.new("GeometryNodeInputPosition")
	    position_002.name = "Position.002"
	
	    #node Interpolate Domain
	    interpolate_domain = curve_root_001.nodes.new("GeometryNodeFieldOnDomain")
	    interpolate_domain.name = "Interpolate Domain"
	    interpolate_domain.data_type = 'INT'
	    interpolate_domain.domain = 'CURVE'
	
	    #node Field at Index.003
	    field_at_index_003 = curve_root_001.nodes.new("GeometryNodeFieldAtIndex")
	    field_at_index_003.name = "Field at Index.003"
	    field_at_index_003.data_type = 'FLOAT_VECTOR'
	    field_at_index_003.domain = 'POINT'
	
	    #node Interpolate Domain.001
	    interpolate_domain_001 = curve_root_001.nodes.new("GeometryNodeFieldOnDomain")
	    interpolate_domain_001.name = "Interpolate Domain.001"
	    interpolate_domain_001.data_type = 'FLOAT_VECTOR'
	    interpolate_domain_001.domain = 'CURVE'
	
	    #node Curve Tangent
	    curve_tangent = curve_root_001.nodes.new("GeometryNodeInputTangent")
	    curve_tangent.name = "Curve Tangent"
	
	    #node Endpoint Selection
	    endpoint_selection = curve_root_001.nodes.new("GeometryNodeCurveEndpointSelection")
	    endpoint_selection.name = "Endpoint Selection"
	    #Start Size
	    endpoint_selection.inputs[0].default_value = 1
	    #End Size
	    endpoint_selection.inputs[1].default_value = 0
	
	    #node Field at Index.004
	    field_at_index_004 = curve_root_001.nodes.new("GeometryNodeFieldAtIndex")
	    field_at_index_004.name = "Field at Index.004"
	    field_at_index_004.data_type = 'FLOAT_VECTOR'
	    field_at_index_004.domain = 'POINT'
	
	    #node Interpolate Domain.002
	    interpolate_domain_002 = curve_root_001.nodes.new("GeometryNodeFieldOnDomain")
	    interpolate_domain_002.name = "Interpolate Domain.002"
	    interpolate_domain_002.data_type = 'FLOAT_VECTOR'
	    interpolate_domain_002.domain = 'CURVE'
	
	    #node Group Output
	    group_output = curve_root_001.nodes.new("NodeGroupOutput")
	    group_output.name = "Group Output"
	    group_output.is_active_output = True
	
	    #node Points of Curve
	    points_of_curve = curve_root_001.nodes.new("GeometryNodePointsOfCurve")
	    points_of_curve.name = "Points of Curve"
	    points_of_curve.inputs[0].hide = True
	    points_of_curve.inputs[1].hide = True
	    points_of_curve.outputs[1].hide = True
	    #Curve Index
	    points_of_curve.inputs[0].default_value = 0
	    #Weights
	    points_of_curve.inputs[1].default_value = 0.0
	    #Sort Index
	    points_of_curve.inputs[2].default_value = 0
	
	
	
	
	
	    #Set locations
	    position_002.location = (-608.1627807617188, -70.55814361572266)
	    interpolate_domain.location = (-608.1627807617188, 90.18604278564453)
	    field_at_index_003.location = (-407.2325439453125, 70.09302520751953)
	    interpolate_domain_001.location = (-206.30230712890625, 70.09302520751953)
	    curve_tangent.location = (-608.1627807617188, -271.4883728027344)
	    endpoint_selection.location = (-206.30230712890625, 190.65118408203125)
	    field_at_index_004.location = (-407.2325439453125, -130.83721923828125)
	    interpolate_domain_002.location = (-206.30230712890625, -130.83721923828125)
	    group_output.location = (75.0, 50.0)
	    points_of_curve.location = (-789.0, 50.0)
	
	    #Set dimensions
	    position_002.width, position_002.height = 140.0, 100.0
	    interpolate_domain.width, interpolate_domain.height = 140.0, 100.0
	    field_at_index_003.width, field_at_index_003.height = 140.0, 100.0
	    interpolate_domain_001.width, interpolate_domain_001.height = 140.0, 100.0
	    curve_tangent.width, curve_tangent.height = 140.0, 100.0
	    endpoint_selection.width, endpoint_selection.height = 140.0, 100.0
	    field_at_index_004.width, field_at_index_004.height = 140.0, 100.0
	    interpolate_domain_002.width, interpolate_domain_002.height = 140.0, 100.0
	    group_output.width, group_output.height = 140.0, 100.0
	    points_of_curve.width, points_of_curve.height = 140.0, 100.0
	
	    #initialize curve_root_001 links
	    #position_002.Position -> field_at_index_003.Value
	    curve_root_001.links.new(position_002.outputs[0], field_at_index_003.inputs[1])
	    #interpolate_domain_001.Value -> group_output.Root Position
	    curve_root_001.links.new(interpolate_domain_001.outputs[0], group_output.inputs[1])
	    #interpolate_domain.Value -> field_at_index_003.Index
	    curve_root_001.links.new(interpolate_domain.outputs[0], field_at_index_003.inputs[0])
	    #points_of_curve.Point Index -> interpolate_domain.Value
	    curve_root_001.links.new(points_of_curve.outputs[0], interpolate_domain.inputs[0])
	    #interpolate_domain.Value -> group_output.Root Index
	    curve_root_001.links.new(interpolate_domain.outputs[0], group_output.inputs[3])
	    #endpoint_selection.Selection -> group_output.Root Selection
	    curve_root_001.links.new(endpoint_selection.outputs[0], group_output.inputs[0])
	    #field_at_index_003.Value -> interpolate_domain_001.Value
	    curve_root_001.links.new(field_at_index_003.outputs[0], interpolate_domain_001.inputs[0])
	    #interpolate_domain_002.Value -> group_output.Root Direction
	    curve_root_001.links.new(interpolate_domain_002.outputs[0], group_output.inputs[2])
	    #interpolate_domain.Value -> field_at_index_004.Index
	    curve_root_001.links.new(interpolate_domain.outputs[0], field_at_index_004.inputs[0])
	    #curve_tangent.Tangent -> field_at_index_004.Value
	    curve_root_001.links.new(curve_tangent.outputs[0], field_at_index_004.inputs[1])
	    #field_at_index_004.Value -> interpolate_domain_002.Value
	    curve_root_001.links.new(field_at_index_004.outputs[0], interpolate_domain_002.inputs[0])
	    return curve_root_001
	
	curve_root_001 = curve_root_001_node_group()
	
	#initialize curve_tip_001 node group
	def curve_tip_001_node_group():
	    curve_tip_001 = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Curve Tip.001")
	
	    curve_tip_001.color_tag = 'NONE'
	    curve_tip_001.description = "Reads information about each curve's tip point"
	    curve_tip_001.default_group_node_width = 140
	    
	
	
	    #curve_tip_001 interface
	    #Socket Tip Selection
	    tip_selection_socket = curve_tip_001.interface.new_socket(name = "Tip Selection", in_out='OUTPUT', socket_type = 'NodeSocketBool')
	    tip_selection_socket.default_value = False
	    tip_selection_socket.attribute_domain = 'POINT'
	    tip_selection_socket.description = "Boolean selection of curve tip points"
	
	    #Socket Tip Position
	    tip_position_socket = curve_tip_001.interface.new_socket(name = "Tip Position", in_out='OUTPUT', socket_type = 'NodeSocketVector')
	    tip_position_socket.default_value = (0.0, 0.0, 0.0)
	    tip_position_socket.min_value = -3.4028234663852886e+38
	    tip_position_socket.max_value = 3.4028234663852886e+38
	    tip_position_socket.subtype = 'NONE'
	    tip_position_socket.attribute_domain = 'CURVE'
	    tip_position_socket.description = "Position of the tip point of a curve"
	
	    #Socket Tip Direction
	    tip_direction_socket = curve_tip_001.interface.new_socket(name = "Tip Direction", in_out='OUTPUT', socket_type = 'NodeSocketVector')
	    tip_direction_socket.default_value = (0.0, 0.0, 0.0)
	    tip_direction_socket.min_value = -3.4028234663852886e+38
	    tip_direction_socket.max_value = 3.4028234663852886e+38
	    tip_direction_socket.subtype = 'NONE'
	    tip_direction_socket.attribute_domain = 'CURVE'
	    tip_direction_socket.description = "Direction of the tip segment of a curve"
	
	    #Socket Tip Index
	    tip_index_socket = curve_tip_001.interface.new_socket(name = "Tip Index", in_out='OUTPUT', socket_type = 'NodeSocketInt')
	    tip_index_socket.default_value = 0
	    tip_index_socket.min_value = -2147483648
	    tip_index_socket.max_value = 2147483647
	    tip_index_socket.subtype = 'NONE'
	    tip_index_socket.attribute_domain = 'CURVE'
	    tip_index_socket.description = "Index of the tip point of a curve"
	
	
	    #initialize curve_tip_001 nodes
	    #node Position.002
	    position_002_1 = curve_tip_001.nodes.new("GeometryNodeInputPosition")
	    position_002_1.name = "Position.002"
	
	    #node Interpolate Domain
	    interpolate_domain_1 = curve_tip_001.nodes.new("GeometryNodeFieldOnDomain")
	    interpolate_domain_1.name = "Interpolate Domain"
	    interpolate_domain_1.data_type = 'INT'
	    interpolate_domain_1.domain = 'CURVE'
	
	    #node Interpolate Domain.001
	    interpolate_domain_001_1 = curve_tip_001.nodes.new("GeometryNodeFieldOnDomain")
	    interpolate_domain_001_1.name = "Interpolate Domain.001"
	    interpolate_domain_001_1.data_type = 'FLOAT_VECTOR'
	    interpolate_domain_001_1.domain = 'CURVE'
	
	    #node Field at Index.003
	    field_at_index_003_1 = curve_tip_001.nodes.new("GeometryNodeFieldAtIndex")
	    field_at_index_003_1.name = "Field at Index.003"
	    field_at_index_003_1.data_type = 'FLOAT_VECTOR'
	    field_at_index_003_1.domain = 'POINT'
	
	    #node Curve Tangent
	    curve_tangent_1 = curve_tip_001.nodes.new("GeometryNodeInputTangent")
	    curve_tangent_1.name = "Curve Tangent"
	
	    #node Endpoint Selection
	    endpoint_selection_1 = curve_tip_001.nodes.new("GeometryNodeCurveEndpointSelection")
	    endpoint_selection_1.name = "Endpoint Selection"
	    #Start Size
	    endpoint_selection_1.inputs[0].default_value = 0
	    #End Size
	    endpoint_selection_1.inputs[1].default_value = 1
	
	    #node Field at Index.004
	    field_at_index_004_1 = curve_tip_001.nodes.new("GeometryNodeFieldAtIndex")
	    field_at_index_004_1.name = "Field at Index.004"
	    field_at_index_004_1.data_type = 'FLOAT_VECTOR'
	    field_at_index_004_1.domain = 'POINT'
	
	    #node Interpolate Domain.002
	    interpolate_domain_002_1 = curve_tip_001.nodes.new("GeometryNodeFieldOnDomain")
	    interpolate_domain_002_1.name = "Interpolate Domain.002"
	    interpolate_domain_002_1.data_type = 'FLOAT_VECTOR'
	    interpolate_domain_002_1.domain = 'CURVE'
	
	    #node Group Output
	    group_output_1 = curve_tip_001.nodes.new("NodeGroupOutput")
	    group_output_1.name = "Group Output"
	    group_output_1.is_active_output = True
	
	    #node Points of Curve
	    points_of_curve_1 = curve_tip_001.nodes.new("GeometryNodePointsOfCurve")
	    points_of_curve_1.name = "Points of Curve"
	    points_of_curve_1.inputs[0].hide = True
	    points_of_curve_1.inputs[1].hide = True
	    points_of_curve_1.outputs[1].hide = True
	    #Curve Index
	    points_of_curve_1.inputs[0].default_value = 0
	    #Weights
	    points_of_curve_1.inputs[1].default_value = 0.0
	    #Sort Index
	    points_of_curve_1.inputs[2].default_value = -1
	
	
	
	
	
	    #Set locations
	    position_002_1.location = (-628.2557983398438, -70.55813598632812)
	    interpolate_domain_1.location = (-628.2557983398438, 90.18605041503906)
	    interpolate_domain_001_1.location = (-246.4883575439453, 90.18605041503906)
	    field_at_index_003_1.location = (-427.3255615234375, 90.18605041503906)
	    curve_tangent_1.location = (-628.2557983398438, -231.3023223876953)
	    endpoint_selection_1.location = (-246.4883575439453, 210.7441864013672)
	    field_at_index_004_1.location = (-427.3255615234375, -90.65116882324219)
	    interpolate_domain_002_1.location = (-246.4883575439453, -90.65116882324219)
	    group_output_1.location = (75.0, 50.0)
	    points_of_curve_1.location = (-829.18603515625, 50.0)
	
	    #Set dimensions
	    position_002_1.width, position_002_1.height = 140.0, 100.0
	    interpolate_domain_1.width, interpolate_domain_1.height = 140.0, 100.0
	    interpolate_domain_001_1.width, interpolate_domain_001_1.height = 140.0, 100.0
	    field_at_index_003_1.width, field_at_index_003_1.height = 140.0, 100.0
	    curve_tangent_1.width, curve_tangent_1.height = 140.0, 100.0
	    endpoint_selection_1.width, endpoint_selection_1.height = 140.0, 100.0
	    field_at_index_004_1.width, field_at_index_004_1.height = 140.0, 100.0
	    interpolate_domain_002_1.width, interpolate_domain_002_1.height = 140.0, 100.0
	    group_output_1.width, group_output_1.height = 140.0, 100.0
	    points_of_curve_1.width, points_of_curve_1.height = 140.0, 100.0
	
	    #initialize curve_tip_001 links
	    #position_002_1.Position -> field_at_index_003_1.Value
	    curve_tip_001.links.new(position_002_1.outputs[0], field_at_index_003_1.inputs[1])
	    #interpolate_domain_1.Value -> field_at_index_003_1.Index
	    curve_tip_001.links.new(interpolate_domain_1.outputs[0], field_at_index_003_1.inputs[0])
	    #points_of_curve_1.Point Index -> interpolate_domain_1.Value
	    curve_tip_001.links.new(points_of_curve_1.outputs[0], interpolate_domain_1.inputs[0])
	    #interpolate_domain_001_1.Value -> group_output_1.Tip Position
	    curve_tip_001.links.new(interpolate_domain_001_1.outputs[0], group_output_1.inputs[1])
	    #interpolate_domain_1.Value -> group_output_1.Tip Index
	    curve_tip_001.links.new(interpolate_domain_1.outputs[0], group_output_1.inputs[3])
	    #endpoint_selection_1.Selection -> group_output_1.Tip Selection
	    curve_tip_001.links.new(endpoint_selection_1.outputs[0], group_output_1.inputs[0])
	    #field_at_index_003_1.Value -> interpolate_domain_001_1.Value
	    curve_tip_001.links.new(field_at_index_003_1.outputs[0], interpolate_domain_001_1.inputs[0])
	    #interpolate_domain_002_1.Value -> group_output_1.Tip Direction
	    curve_tip_001.links.new(interpolate_domain_002_1.outputs[0], group_output_1.inputs[2])
	    #curve_tangent_1.Tangent -> field_at_index_004_1.Value
	    curve_tip_001.links.new(curve_tangent_1.outputs[0], field_at_index_004_1.inputs[1])
	    #interpolate_domain_1.Value -> field_at_index_004_1.Index
	    curve_tip_001.links.new(interpolate_domain_1.outputs[0], field_at_index_004_1.inputs[0])
	    #field_at_index_004_1.Value -> interpolate_domain_002_1.Value
	    curve_tip_001.links.new(field_at_index_004_1.outputs[0], interpolate_domain_002_1.inputs[0])
	    return curve_tip_001
	
	curve_tip_001 = curve_tip_001_node_group()
	
	#initialize curve_info_001 node group
	def curve_info_001_node_group():
	    curve_info_001 = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Curve Info.001")
	
	    curve_info_001.color_tag = 'NONE'
	    curve_info_001.description = "Reads information about each curve"
	    curve_info_001.default_group_node_width = 140
	    
	
	
	    #curve_info_001 interface
	    #Socket Curve Index
	    curve_index_socket = curve_info_001.interface.new_socket(name = "Curve Index", in_out='OUTPUT', socket_type = 'NodeSocketInt')
	    curve_index_socket.default_value = 0
	    curve_index_socket.min_value = -2147483648
	    curve_index_socket.max_value = 2147483647
	    curve_index_socket.subtype = 'NONE'
	    curve_index_socket.attribute_domain = 'CURVE'
	    curve_index_socket.description = "Index of each Curve"
	
	    #Socket Curve ID
	    curve_id_socket = curve_info_001.interface.new_socket(name = "Curve ID", in_out='OUTPUT', socket_type = 'NodeSocketInt')
	    curve_id_socket.default_value = 0
	    curve_id_socket.min_value = -2147483648
	    curve_id_socket.max_value = 2147483647
	    curve_id_socket.subtype = 'NONE'
	    curve_id_socket.attribute_domain = 'CURVE'
	    curve_id_socket.description = "ID of each curve"
	
	    #Socket Length
	    length_socket = curve_info_001.interface.new_socket(name = "Length", in_out='OUTPUT', socket_type = 'NodeSocketFloat')
	    length_socket.default_value = 0.0
	    length_socket.min_value = -3.4028234663852886e+38
	    length_socket.max_value = 3.4028234663852886e+38
	    length_socket.subtype = 'NONE'
	    length_socket.attribute_domain = 'CURVE'
	    length_socket.description = "Length of each curve"
	
	    #Socket Direction
	    direction_socket = curve_info_001.interface.new_socket(name = "Direction", in_out='OUTPUT', socket_type = 'NodeSocketVector')
	    direction_socket.default_value = (0.0, 0.0, 0.0)
	    direction_socket.min_value = -3.4028234663852886e+38
	    direction_socket.max_value = 3.4028234663852886e+38
	    direction_socket.subtype = 'NONE'
	    direction_socket.attribute_domain = 'CURVE'
	    direction_socket.description = "Direction from root to tip of each curve"
	
	    #Socket Random
	    random_socket = curve_info_001.interface.new_socket(name = "Random", in_out='OUTPUT', socket_type = 'NodeSocketFloat')
	    random_socket.default_value = 0.0
	    random_socket.min_value = -3.4028234663852886e+38
	    random_socket.max_value = 3.4028234663852886e+38
	    random_socket.subtype = 'NONE'
	    random_socket.attribute_domain = 'CURVE'
	    random_socket.description = "Random vector for each curve"
	
	    #Socket Surface UV
	    surface_uv_socket = curve_info_001.interface.new_socket(name = "Surface UV", in_out='OUTPUT', socket_type = 'NodeSocketVector')
	    surface_uv_socket.default_value = (0.0, 0.0, 0.0)
	    surface_uv_socket.min_value = -3.4028234663852886e+38
	    surface_uv_socket.max_value = 3.4028234663852886e+38
	    surface_uv_socket.subtype = 'NONE'
	    surface_uv_socket.attribute_domain = 'CURVE'
	    surface_uv_socket.description = "Attachment surface UV coordinates of each curve"
	
	
	    #initialize curve_info_001 nodes
	    #node Frame
	    frame = curve_info_001.nodes.new("NodeFrame")
	    frame.label = "ID per Curve"
	    frame.name = "Frame"
	    frame.label_size = 20
	    frame.shrink = True
	
	    #node Group Output
	    group_output_2 = curve_info_001.nodes.new("NodeGroupOutput")
	    group_output_2.name = "Group Output"
	    group_output_2.is_active_output = True
	
	    #node Named Attribute
	    named_attribute = curve_info_001.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute.name = "Named Attribute"
	    named_attribute.data_type = 'FLOAT_VECTOR'
	    #Name
	    named_attribute.inputs[0].default_value = "surface_uv_coordinate"
	
	    #node Group.002
	    group_002 = curve_info_001.nodes.new("GeometryNodeGroup")
	    group_002.name = "Group.002"
	    group_002.node_tree = curve_tip_001
	    group_002.outputs[0].hide = True
	    group_002.outputs[2].hide = True
	    group_002.outputs[3].hide = True
	
	    #node Group.001
	    group_001 = curve_info_001.nodes.new("GeometryNodeGroup")
	    group_001.name = "Group.001"
	    group_001.node_tree = curve_root_001
	    group_001.outputs[0].hide = True
	    group_001.outputs[2].hide = True
	    group_001.outputs[3].hide = True
	
	    #node Evaluate at Index
	    evaluate_at_index = curve_info_001.nodes.new("GeometryNodeFieldAtIndex")
	    evaluate_at_index.name = "Evaluate at Index"
	    evaluate_at_index.data_type = 'FLOAT'
	    evaluate_at_index.domain = 'POINT'
	
	    #node Evaluate on Domain.001
	    evaluate_on_domain_001 = curve_info_001.nodes.new("GeometryNodeFieldOnDomain")
	    evaluate_on_domain_001.name = "Evaluate on Domain.001"
	    evaluate_on_domain_001.data_type = 'FLOAT'
	    evaluate_on_domain_001.domain = 'CURVE'
	
	    #node Group.003
	    group_003 = curve_info_001.nodes.new("GeometryNodeGroup")
	    group_003.name = "Group.003"
	    group_003.node_tree = curve_root_001
	    group_003.outputs[0].hide = True
	    group_003.outputs[1].hide = True
	    group_003.outputs[2].hide = True
	
	    #node Random Value.002
	    random_value_002 = curve_info_001.nodes.new("FunctionNodeRandomValue")
	    random_value_002.name = "Random Value.002"
	    random_value_002.data_type = 'FLOAT'
	    #Min_001
	    random_value_002.inputs[2].default_value = 0.0
	    #Max_001
	    random_value_002.inputs[3].default_value = 1.0
	    #Seed
	    random_value_002.inputs[8].default_value = 0
	
	    #node Reroute
	    reroute = curve_info_001.nodes.new("NodeReroute")
	    reroute.name = "Reroute"
	    reroute.socket_idname = "NodeSocketInt"
	    #node Vector Math
	    vector_math = curve_info_001.nodes.new("ShaderNodeVectorMath")
	    vector_math.name = "Vector Math"
	    vector_math.operation = 'SUBTRACT'
	
	    #node Vector Math.001
	    vector_math_001 = curve_info_001.nodes.new("ShaderNodeVectorMath")
	    vector_math_001.name = "Vector Math.001"
	    vector_math_001.operation = 'NORMALIZE'
	
	    #node Evaluate on Domain
	    evaluate_on_domain = curve_info_001.nodes.new("GeometryNodeFieldOnDomain")
	    evaluate_on_domain.name = "Evaluate on Domain"
	    evaluate_on_domain.hide = True
	    evaluate_on_domain.data_type = 'INT'
	    evaluate_on_domain.domain = 'CURVE'
	
	    #node Index.001
	    index_001 = curve_info_001.nodes.new("GeometryNodeInputIndex")
	    index_001.name = "Index.001"
	
	    #node Spline Length
	    spline_length = curve_info_001.nodes.new("GeometryNodeSplineLength")
	    spline_length.name = "Spline Length"
	    spline_length.outputs[1].hide = True
	
	    #node Evaluate at Index.001
	    evaluate_at_index_001 = curve_info_001.nodes.new("GeometryNodeFieldAtIndex")
	    evaluate_at_index_001.name = "Evaluate at Index.001"
	    evaluate_at_index_001.data_type = 'INT'
	    evaluate_at_index_001.domain = 'POINT'
	
	    #node Evaluate on Domain.002
	    evaluate_on_domain_002 = curve_info_001.nodes.new("GeometryNodeFieldOnDomain")
	    evaluate_on_domain_002.name = "Evaluate on Domain.002"
	    evaluate_on_domain_002.data_type = 'INT'
	    evaluate_on_domain_002.domain = 'CURVE'
	
	    #node Group
	    group = curve_info_001.nodes.new("GeometryNodeGroup")
	    group.name = "Group"
	    group.node_tree = curve_root_001
	    group.outputs[0].hide = True
	    group.outputs[1].hide = True
	    group.outputs[2].hide = True
	
	    #node ID
	    id = curve_info_001.nodes.new("GeometryNodeInputID")
	    id.name = "ID"
	
	
	
	
	    #Set parents
	    evaluate_at_index_001.parent = frame
	    evaluate_on_domain_002.parent = frame
	    group.parent = frame
	    id.parent = frame
	
	    #Set locations
	    frame.location = (-1200.55810546875, 150.5814208984375)
	    group_output_2.location = (75.0, 50.0)
	    named_attribute.location = (-166.11627197265625, -371.9534912109375)
	    group_002.location = (-527.7907104492188, -90.65116882324219)
	    group_001.location = (-527.7907104492188, -171.02325439453125)
	    evaluate_at_index.location = (-346.9534912109375, -211.2093048095703)
	    evaluate_on_domain_001.location = (-166.11627197265625, -211.2093048095703)
	    group_003.location = (-527.7907104492188, -251.39535522460938)
	    random_value_002.location = (-527.7907104492188, -331.7674560546875)
	    reroute.location = (-608.162841796875, 29.906982421875)
	    vector_math.location = (-346.9534912109375, -70.55814361572266)
	    vector_math_001.location = (-166.11627197265625, -70.55814361572266)
	    evaluate_on_domain.location = (-166.11627197265625, 70.093017578125)
	    index_001.location = (-346.9534912109375, 110.27906799316406)
	    spline_length.location = (-166.11627197265625, -10.279067993164062)
	    evaluate_at_index_001.location = (210.62786865234375, -40.30235290527344)
	    evaluate_on_domain_002.location = (391.465087890625, -40.30235290527344)
	    group.location = (29.7906494140625, -60.3953857421875)
	    id.location = (29.7906494140625, -140.76747131347656)
	
	    #Set dimensions
	    frame.width, frame.height = 561.9534301757812, 225.93026733398438
	    group_output_2.width, group_output_2.height = 140.0, 100.0
	    named_attribute.width, named_attribute.height = 140.0, 100.0
	    group_002.width, group_002.height = 140.0, 100.0
	    group_001.width, group_001.height = 140.0, 100.0
	    evaluate_at_index.width, evaluate_at_index.height = 140.0, 100.0
	    evaluate_on_domain_001.width, evaluate_on_domain_001.height = 140.0, 100.0
	    group_003.width, group_003.height = 140.0, 100.0
	    random_value_002.width, random_value_002.height = 140.0, 100.0
	    reroute.width, reroute.height = 100.0, 100.0
	    vector_math.width, vector_math.height = 140.0, 100.0
	    vector_math_001.width, vector_math_001.height = 140.0, 100.0
	    evaluate_on_domain.width, evaluate_on_domain.height = 140.0, 100.0
	    index_001.width, index_001.height = 140.0, 100.0
	    spline_length.width, spline_length.height = 140.0, 100.0
	    evaluate_at_index_001.width, evaluate_at_index_001.height = 140.0, 100.0
	    evaluate_on_domain_002.width, evaluate_on_domain_002.height = 140.0, 100.0
	    group.width, group.height = 140.0, 100.0
	    id.width, id.height = 140.0, 100.0
	
	    #initialize curve_info_001 links
	    #index_001.Index -> evaluate_on_domain.Value
	    curve_info_001.links.new(index_001.outputs[0], evaluate_on_domain.inputs[0])
	    #evaluate_on_domain.Value -> group_output_2.Curve Index
	    curve_info_001.links.new(evaluate_on_domain.outputs[0], group_output_2.inputs[0])
	    #named_attribute.Attribute -> group_output_2.Surface UV
	    curve_info_001.links.new(named_attribute.outputs[0], group_output_2.inputs[5])
	    #evaluate_at_index_001.Value -> evaluate_on_domain_002.Value
	    curve_info_001.links.new(evaluate_at_index_001.outputs[0], evaluate_on_domain_002.inputs[0])
	    #group.Root Index -> evaluate_at_index_001.Index
	    curve_info_001.links.new(group.outputs[3], evaluate_at_index_001.inputs[0])
	    #reroute.Output -> group_output_2.Curve ID
	    curve_info_001.links.new(reroute.outputs[0], group_output_2.inputs[1])
	    #id.ID -> evaluate_at_index_001.Value
	    curve_info_001.links.new(id.outputs[0], evaluate_at_index_001.inputs[1])
	    #spline_length.Length -> group_output_2.Length
	    curve_info_001.links.new(spline_length.outputs[0], group_output_2.inputs[2])
	    #group_002.Tip Position -> vector_math.Vector
	    curve_info_001.links.new(group_002.outputs[1], vector_math.inputs[0])
	    #group_001.Root Position -> vector_math.Vector
	    curve_info_001.links.new(group_001.outputs[1], vector_math.inputs[1])
	    #vector_math_001.Vector -> group_output_2.Direction
	    curve_info_001.links.new(vector_math_001.outputs[0], group_output_2.inputs[3])
	    #vector_math.Vector -> vector_math_001.Vector
	    curve_info_001.links.new(vector_math.outputs[0], vector_math_001.inputs[0])
	    #reroute.Output -> random_value_002.ID
	    curve_info_001.links.new(reroute.outputs[0], random_value_002.inputs[7])
	    #evaluate_at_index.Value -> evaluate_on_domain_001.Value
	    curve_info_001.links.new(evaluate_at_index.outputs[0], evaluate_on_domain_001.inputs[0])
	    #evaluate_on_domain_001.Value -> group_output_2.Random
	    curve_info_001.links.new(evaluate_on_domain_001.outputs[0], group_output_2.inputs[4])
	    #random_value_002.Value -> evaluate_at_index.Value
	    curve_info_001.links.new(random_value_002.outputs[1], evaluate_at_index.inputs[1])
	    #group_003.Root Index -> evaluate_at_index.Index
	    curve_info_001.links.new(group_003.outputs[3], evaluate_at_index.inputs[0])
	    #evaluate_on_domain_002.Value -> reroute.Input
	    curve_info_001.links.new(evaluate_on_domain_002.outputs[0], reroute.inputs[0])
	    return curve_info_001
	
	curve_info_001 = curve_info_001_node_group()
	
	#initialize duplicate_hair_curves node group
	def duplicate_hair_curves_node_group():
	    duplicate_hair_curves = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Duplicate Hair Curves")
	
	    duplicate_hair_curves.color_tag = 'NONE'
	    duplicate_hair_curves.description = "Duplicates hair curves a certain number of times within a radius"
	    duplicate_hair_curves.default_group_node_width = 140
	    
	
	    duplicate_hair_curves.is_modifier = True
	
	    #duplicate_hair_curves interface
	    #Socket Geometry
	    geometry_socket = duplicate_hair_curves.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket.attribute_domain = 'POINT'
	
	    #Socket Guide Index
	    guide_index_socket = duplicate_hair_curves.interface.new_socket(name = "Guide Index", in_out='OUTPUT', socket_type = 'NodeSocketInt')
	    guide_index_socket.default_value = 0
	    guide_index_socket.min_value = -2147483648
	    guide_index_socket.max_value = 2147483647
	    guide_index_socket.subtype = 'NONE'
	    guide_index_socket.attribute_domain = 'CURVE'
	    guide_index_socket.description = "Guide index map that was used for the operation"
	
	    #Socket Geometry
	    geometry_socket_1 = duplicate_hair_curves.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_1.attribute_domain = 'POINT'
	    geometry_socket_1.description = "Input Geometry (May include other than curves)"
	
	    #Socket Amount
	    amount_socket = duplicate_hair_curves.interface.new_socket(name = "Amount", in_out='INPUT', socket_type = 'NodeSocketInt')
	    amount_socket.default_value = 10
	    amount_socket.min_value = 0
	    amount_socket.max_value = 2147483647
	    amount_socket.subtype = 'NONE'
	    amount_socket.attribute_domain = 'POINT'
	    amount_socket.description = "Amount of duplicates per curve"
	
	    #Socket Viewport Amount
	    viewport_amount_socket = duplicate_hair_curves.interface.new_socket(name = "Viewport Amount", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    viewport_amount_socket.default_value = 1.0
	    viewport_amount_socket.min_value = 0.0
	    viewport_amount_socket.max_value = 1.0
	    viewport_amount_socket.subtype = 'FACTOR'
	    viewport_amount_socket.attribute_domain = 'POINT'
	    viewport_amount_socket.description = "Percentage of amount used for the viewport"
	
	    #Socket Radius
	    radius_socket = duplicate_hair_curves.interface.new_socket(name = "Radius", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    radius_socket.default_value = 0.10000000149011612
	    radius_socket.min_value = 0.0
	    radius_socket.max_value = 3.4028234663852886e+38
	    radius_socket.subtype = 'DISTANCE'
	    radius_socket.attribute_domain = 'POINT'
	    radius_socket.description = "Radius in which the duplicate curves are offset from the guides"
	
	    #Socket Distribution Shape
	    distribution_shape_socket = duplicate_hair_curves.interface.new_socket(name = "Distribution Shape", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    distribution_shape_socket.default_value = 0.0
	    distribution_shape_socket.min_value = -10.0
	    distribution_shape_socket.max_value = 10.0
	    distribution_shape_socket.subtype = 'NONE'
	    distribution_shape_socket.attribute_domain = 'POINT'
	    distribution_shape_socket.description = "Shape of distribution from center to the edge around the guide"
	
	    #Socket Tip Roundness
	    tip_roundness_socket = duplicate_hair_curves.interface.new_socket(name = "Tip Roundness", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    tip_roundness_socket.default_value = 0.0
	    tip_roundness_socket.min_value = 0.0
	    tip_roundness_socket.max_value = 1.0
	    tip_roundness_socket.subtype = 'FACTOR'
	    tip_roundness_socket.attribute_domain = 'POINT'
	    tip_roundness_socket.description = "Offset of the curves to round the tip"
	
	    #Socket Even Thickness
	    even_thickness_socket = duplicate_hair_curves.interface.new_socket(name = "Even Thickness", in_out='INPUT', socket_type = 'NodeSocketBool')
	    even_thickness_socket.default_value = False
	    even_thickness_socket.attribute_domain = 'POINT'
	    even_thickness_socket.description = "Keep an even thickness of the distribution of duplicates"
	
	    #Socket Seed
	    seed_socket = duplicate_hair_curves.interface.new_socket(name = "Seed", in_out='INPUT', socket_type = 'NodeSocketInt')
	    seed_socket.default_value = 0
	    seed_socket.min_value = -10000
	    seed_socket.max_value = 10000
	    seed_socket.subtype = 'NONE'
	    seed_socket.attribute_domain = 'POINT'
	    seed_socket.description = "Random Seed for the operation"
	
	
	    #initialize duplicate_hair_curves nodes
	    #node Frame.002
	    frame_002 = duplicate_hair_curves.nodes.new("NodeFrame")
	    frame_002.label = "Random Disc Position"
	    frame_002.name = "Frame.002"
	    frame_002.label_size = 20
	    frame_002.shrink = True
	
	    #node Frame.001
	    frame_001 = duplicate_hair_curves.nodes.new("NodeFrame")
	    frame_001.label = "Tangent Space per Point"
	    frame_001.name = "Frame.001"
	    frame_001.label_size = 20
	    frame_001.shrink = True
	
	    #node Frame
	    frame_1 = duplicate_hair_curves.nodes.new("NodeFrame")
	    frame_1.label = "Tangent Space of Root Point"
	    frame_1.name = "Frame"
	    frame_1.label_size = 20
	    frame_1.shrink = True
	
	    #node Frame.004
	    frame_004 = duplicate_hair_curves.nodes.new("NodeFrame")
	    frame_004.label = "Duplicate Curves"
	    frame_004.name = "Frame.004"
	    frame_004.label_size = 20
	    frame_004.shrink = True
	
	    #node Frame.003
	    frame_003 = duplicate_hair_curves.nodes.new("NodeFrame")
	    frame_003.label = "Random Vector per Curve"
	    frame_003.name = "Frame.003"
	    frame_003.label_size = 20
	    frame_003.shrink = True
	
	    #node Reroute.016
	    reroute_016 = duplicate_hair_curves.nodes.new("NodeReroute")
	    reroute_016.name = "Reroute.016"
	    reroute_016.socket_idname = "NodeSocketGeometry"
	    #node Reroute.017
	    reroute_017 = duplicate_hair_curves.nodes.new("NodeReroute")
	    reroute_017.name = "Reroute.017"
	    reroute_017.socket_idname = "NodeSocketGeometry"
	    #node Reroute.019
	    reroute_019 = duplicate_hair_curves.nodes.new("NodeReroute")
	    reroute_019.name = "Reroute.019"
	    reroute_019.socket_idname = "NodeSocketGeometry"
	    #node Reroute.018
	    reroute_018 = duplicate_hair_curves.nodes.new("NodeReroute")
	    reroute_018.name = "Reroute.018"
	    reroute_018.socket_idname = "NodeSocketGeometry"
	    #node Group Input
	    group_input = duplicate_hair_curves.nodes.new("NodeGroupInput")
	    group_input.name = "Group Input"
	    group_input.outputs[1].hide = True
	    group_input.outputs[2].hide = True
	    group_input.outputs[3].hide = True
	    group_input.outputs[4].hide = True
	    group_input.outputs[5].hide = True
	    group_input.outputs[6].hide = True
	    group_input.outputs[7].hide = True
	    group_input.outputs[8].hide = True
	
	    #node Group Output
	    group_output_3 = duplicate_hair_curves.nodes.new("NodeGroupOutput")
	    group_output_3.name = "Group Output"
	    group_output_3.is_active_output = True
	
	    #node Separate Components
	    separate_components = duplicate_hair_curves.nodes.new("GeometryNodeSeparateComponents")
	    separate_components.name = "Separate Components"
	    separate_components.hide = True
	
	    #node Math.053
	    math_053 = duplicate_hair_curves.nodes.new("ShaderNodeMath")
	    math_053.name = "Math.053"
	    math_053.hide = True
	    math_053.operation = 'ARCCOSINE'
	    math_053.use_clamp = False
	
	    #node Math.055
	    math_055 = duplicate_hair_curves.nodes.new("ShaderNodeMath")
	    math_055.name = "Math.055"
	    math_055.hide = True
	    math_055.operation = 'DIVIDE'
	    math_055.use_clamp = False
	    #Value_001
	    math_055.inputs[1].default_value = 1.5707963705062866
	
	    #node Math.056
	    math_056 = duplicate_hair_curves.nodes.new("ShaderNodeMath")
	    math_056.name = "Math.056"
	    math_056.hide = True
	    math_056.operation = 'POWER'
	    math_056.use_clamp = False
	    #Value
	    math_056.inputs[0].default_value = 2.0
	
	    #node Group Input.006
	    group_input_006 = duplicate_hair_curves.nodes.new("NodeGroupInput")
	    group_input_006.name = "Group Input.006"
	    group_input_006.outputs[0].hide = True
	    group_input_006.outputs[1].hide = True
	    group_input_006.outputs[2].hide = True
	    group_input_006.outputs[3].hide = True
	    group_input_006.outputs[5].hide = True
	    group_input_006.outputs[6].hide = True
	    group_input_006.outputs[7].hide = True
	    group_input_006.outputs[8].hide = True
	
	    #node Separate XYZ.002
	    separate_xyz_002 = duplicate_hair_curves.nodes.new("ShaderNodeSeparateXYZ")
	    separate_xyz_002.name = "Separate XYZ.002"
	
	    #node Math.054
	    math_054 = duplicate_hair_curves.nodes.new("ShaderNodeMath")
	    math_054.name = "Math.054"
	    math_054.operation = 'POWER'
	    math_054.use_clamp = False
	
	    #node Math.052
	    math_052 = duplicate_hair_curves.nodes.new("ShaderNodeMath")
	    math_052.name = "Math.052"
	    math_052.hide = True
	    math_052.operation = 'MULTIPLY'
	    math_052.use_clamp = False
	    #Value_001
	    math_052.inputs[1].default_value = 6.2831854820251465
	
	    #node Combine XYZ.002
	    combine_xyz_002 = duplicate_hair_curves.nodes.new("ShaderNodeCombineXYZ")
	    combine_xyz_002.name = "Combine XYZ.002"
	    combine_xyz_002.inputs[1].hide = True
	    combine_xyz_002.inputs[2].hide = True
	    #Y
	    combine_xyz_002.inputs[1].default_value = 0.0
	    #Z
	    combine_xyz_002.inputs[2].default_value = 0.0
	
	    #node Math.059
	    math_059 = duplicate_hair_curves.nodes.new("ShaderNodeMath")
	    math_059.name = "Math.059"
	    math_059.hide = True
	    math_059.operation = 'SUBTRACT'
	    math_059.use_clamp = False
	    #Value_001
	    math_059.inputs[1].default_value = 0.5
	
	    #node Math.058
	    math_058 = duplicate_hair_curves.nodes.new("ShaderNodeMath")
	    math_058.name = "Math.058"
	    math_058.hide = True
	    math_058.operation = 'POWER'
	    math_058.use_clamp = False
	    #Value_001
	    math_058.inputs[1].default_value = 2.0
	
	    #node Vector Rotate
	    vector_rotate = duplicate_hair_curves.nodes.new("ShaderNodeVectorRotate")
	    vector_rotate.name = "Vector Rotate"
	    vector_rotate.invert = False
	    vector_rotate.rotation_type = 'Z_AXIS'
	    vector_rotate.inputs[1].hide = True
	    vector_rotate.inputs[2].hide = True
	    vector_rotate.inputs[4].hide = True
	    #Center
	    vector_rotate.inputs[1].default_value = (0.0, 0.0, 0.0)
	
	    #node Math.057
	    math_057 = duplicate_hair_curves.nodes.new("ShaderNodeMath")
	    math_057.name = "Math.057"
	    math_057.operation = 'ADD'
	    math_057.use_clamp = False
	
	    #node Group Input.007
	    group_input_007 = duplicate_hair_curves.nodes.new("NodeGroupInput")
	    group_input_007.name = "Group Input.007"
	    group_input_007.outputs[0].hide = True
	    group_input_007.outputs[1].hide = True
	    group_input_007.outputs[2].hide = True
	    group_input_007.outputs[3].hide = True
	    group_input_007.outputs[4].hide = True
	    group_input_007.outputs[6].hide = True
	    group_input_007.outputs[7].hide = True
	    group_input_007.outputs[8].hide = True
	
	    #node Combine XYZ
	    combine_xyz = duplicate_hair_curves.nodes.new("ShaderNodeCombineXYZ")
	    combine_xyz.name = "Combine XYZ"
	    combine_xyz.inputs[0].hide = True
	    combine_xyz.inputs[1].hide = True
	    #X
	    combine_xyz.inputs[0].default_value = 0.0
	    #Y
	    combine_xyz.inputs[1].default_value = 0.0
	
	    #node Vector Math.014
	    vector_math_014 = duplicate_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_014.name = "Vector Math.014"
	    vector_math_014.operation = 'SCALE'
	
	    #node Vector Math.013
	    vector_math_013 = duplicate_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_013.name = "Vector Math.013"
	    vector_math_013.operation = 'SUBTRACT'
	
	    #node Reroute.001
	    reroute_001 = duplicate_hair_curves.nodes.new("NodeReroute")
	    reroute_001.name = "Reroute.001"
	    reroute_001.socket_idname = "NodeSocketGeometry"
	    #node Reroute.003
	    reroute_003 = duplicate_hair_curves.nodes.new("NodeReroute")
	    reroute_003.name = "Reroute.003"
	    reroute_003.socket_idname = "NodeSocketBool"
	    #node Set Position
	    set_position = duplicate_hair_curves.nodes.new("GeometryNodeSetPosition")
	    set_position.name = "Set Position"
	    #Position
	    set_position.inputs[2].default_value = (0.0, 0.0, 0.0)
	
	    #node Set Position.001
	    set_position_001 = duplicate_hair_curves.nodes.new("GeometryNodeSetPosition")
	    set_position_001.name = "Set Position.001"
	    #Position
	    set_position_001.inputs[2].default_value = (0.0, 0.0, 0.0)
	
	    #node Normal
	    normal = duplicate_hair_curves.nodes.new("GeometryNodeInputNormal")
	    normal.name = "Normal"
	    normal.legacy_corner_normals = True
	
	    #node Curve Tangent
	    curve_tangent_2 = duplicate_hair_curves.nodes.new("GeometryNodeInputTangent")
	    curve_tangent_2.name = "Curve Tangent"
	
	    #node Separate XYZ
	    separate_xyz = duplicate_hair_curves.nodes.new("ShaderNodeSeparateXYZ")
	    separate_xyz.name = "Separate XYZ"
	
	    #node Vector Math.001
	    vector_math_001_1 = duplicate_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_001_1.name = "Vector Math.001"
	    vector_math_001_1.operation = 'SCALE'
	
	    #node Vector Math.003
	    vector_math_003 = duplicate_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_003.name = "Vector Math.003"
	    vector_math_003.operation = 'ADD'
	
	    #node Vector Math.002
	    vector_math_002 = duplicate_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_002.name = "Vector Math.002"
	    vector_math_002.operation = 'SCALE'
	
	    #node Vector Math.009
	    vector_math_009 = duplicate_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_009.name = "Vector Math.009"
	    vector_math_009.operation = 'ADD'
	
	    #node Vector Math.010
	    vector_math_010 = duplicate_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_010.name = "Vector Math.010"
	    vector_math_010.operation = 'SCALE'
	
	    #node Vector Math
	    vector_math_1 = duplicate_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_1.name = "Vector Math"
	    vector_math_1.operation = 'CROSS_PRODUCT'
	
	    #node Group.001
	    group_001_1 = duplicate_hair_curves.nodes.new("GeometryNodeGroup")
	    group_001_1.name = "Group.001"
	    group_001_1.node_tree = curve_root_001
	    group_001_1.outputs[0].hide = True
	    group_001_1.outputs[1].hide = True
	    group_001_1.outputs[2].hide = True
	
	    #node Evaluate on Domain.002
	    evaluate_on_domain_002_1 = duplicate_hair_curves.nodes.new("GeometryNodeFieldOnDomain")
	    evaluate_on_domain_002_1.name = "Evaluate on Domain.002"
	    evaluate_on_domain_002_1.data_type = 'FLOAT_VECTOR'
	    evaluate_on_domain_002_1.domain = 'CURVE'
	
	    #node Separate XYZ.001
	    separate_xyz_001 = duplicate_hair_curves.nodes.new("ShaderNodeSeparateXYZ")
	    separate_xyz_001.name = "Separate XYZ.001"
	
	    #node Vector Math.011
	    vector_math_011 = duplicate_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_011.name = "Vector Math.011"
	    vector_math_011.operation = 'ADD'
	
	    #node Vector Math.005
	    vector_math_005 = duplicate_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_005.name = "Vector Math.005"
	    vector_math_005.operation = 'ADD'
	
	    #node Vector Math.007
	    vector_math_007 = duplicate_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_007.name = "Vector Math.007"
	    vector_math_007.operation = 'SCALE'
	
	    #node Vector Math.008
	    vector_math_008 = duplicate_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_008.name = "Vector Math.008"
	    vector_math_008.operation = 'CROSS_PRODUCT'
	
	    #node Evaluate at Index
	    evaluate_at_index_1 = duplicate_hair_curves.nodes.new("GeometryNodeFieldAtIndex")
	    evaluate_at_index_1.name = "Evaluate at Index"
	    evaluate_at_index_1.data_type = 'FLOAT_VECTOR'
	    evaluate_at_index_1.domain = 'POINT'
	
	    #node Vector Math.012
	    vector_math_012 = duplicate_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_012.name = "Vector Math.012"
	    vector_math_012.operation = 'SCALE'
	
	    #node Vector Math.006
	    vector_math_006 = duplicate_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_006.name = "Vector Math.006"
	    vector_math_006.operation = 'SCALE'
	
	    #node Evaluate on Domain.001
	    evaluate_on_domain_001_1 = duplicate_hair_curves.nodes.new("GeometryNodeFieldOnDomain")
	    evaluate_on_domain_001_1.name = "Evaluate on Domain.001"
	    evaluate_on_domain_001_1.hide = True
	    evaluate_on_domain_001_1.data_type = 'FLOAT_VECTOR'
	    evaluate_on_domain_001_1.domain = 'POINT'
	
	    #node Curve Tangent.001
	    curve_tangent_001 = duplicate_hair_curves.nodes.new("GeometryNodeInputTangent")
	    curve_tangent_001.name = "Curve Tangent.001"
	
	    #node Normal.001
	    normal_001 = duplicate_hair_curves.nodes.new("GeometryNodeInputNormal")
	    normal_001.name = "Normal.001"
	    normal_001.legacy_corner_normals = True
	
	    #node Reroute.014
	    reroute_014 = duplicate_hair_curves.nodes.new("NodeReroute")
	    reroute_014.name = "Reroute.014"
	    reroute_014.socket_idname = "NodeSocketGeometry"
	    #node Reroute.015
	    reroute_015 = duplicate_hair_curves.nodes.new("NodeReroute")
	    reroute_015.name = "Reroute.015"
	    reroute_015.socket_idname = "NodeSocketGeometry"
	    #node Reroute.013
	    reroute_013 = duplicate_hair_curves.nodes.new("NodeReroute")
	    reroute_013.name = "Reroute.013"
	    reroute_013.socket_idname = "NodeSocketGeometry"
	    #node Reroute.012
	    reroute_012 = duplicate_hair_curves.nodes.new("NodeReroute")
	    reroute_012.name = "Reroute.012"
	    reroute_012.socket_idname = "NodeSocketGeometry"
	    #node Is Viewport
	    is_viewport = duplicate_hair_curves.nodes.new("GeometryNodeIsViewport")
	    is_viewport.name = "Is Viewport"
	
	    #node Switch
	    switch = duplicate_hair_curves.nodes.new("GeometryNodeSwitch")
	    switch.name = "Switch"
	    switch.input_type = 'INT'
	
	    #node ID
	    id_1 = duplicate_hair_curves.nodes.new("GeometryNodeInputID")
	    id_1.name = "ID"
	
	    #node Reroute.004
	    reroute_004 = duplicate_hair_curves.nodes.new("NodeReroute")
	    reroute_004.name = "Reroute.004"
	    reroute_004.socket_idname = "NodeSocketInt"
	    #node Reroute.002
	    reroute_002 = duplicate_hair_curves.nodes.new("NodeReroute")
	    reroute_002.name = "Reroute.002"
	    reroute_002.socket_idname = "NodeSocketGeometry"
	    #node Join Geometry
	    join_geometry = duplicate_hair_curves.nodes.new("GeometryNodeJoinGeometry")
	    join_geometry.name = "Join Geometry"
	
	    #node Set ID
	    set_id = duplicate_hair_curves.nodes.new("GeometryNodeSetID")
	    set_id.name = "Set ID"
	    #Selection
	    set_id.inputs[1].default_value = True
	
	    #node Store Named Attribute
	    store_named_attribute = duplicate_hair_curves.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute.name = "Store Named Attribute"
	    store_named_attribute.data_type = 'INT'
	    store_named_attribute.domain = 'CURVE'
	    #Selection
	    store_named_attribute.inputs[1].default_value = True
	    #Name
	    store_named_attribute.inputs[2].default_value = "guide_curve_index"
	
	    #node Math
	    math = duplicate_hair_curves.nodes.new("ShaderNodeMath")
	    math.name = "Math"
	    math.hide = True
	    math.operation = 'MULTIPLY'
	    math.use_clamp = False
	
	    #node Group Input.002
	    group_input_002 = duplicate_hair_curves.nodes.new("NodeGroupInput")
	    group_input_002.name = "Group Input.002"
	    group_input_002.outputs[0].hide = True
	    group_input_002.outputs[1].hide = True
	    group_input_002.outputs[3].hide = True
	    group_input_002.outputs[4].hide = True
	    group_input_002.outputs[5].hide = True
	    group_input_002.outputs[6].hide = True
	    group_input_002.outputs[7].hide = True
	    group_input_002.outputs[8].hide = True
	
	    #node Group Input.004
	    group_input_004 = duplicate_hair_curves.nodes.new("NodeGroupInput")
	    group_input_004.name = "Group Input.004"
	    group_input_004.outputs[0].hide = True
	    group_input_004.outputs[2].hide = True
	    group_input_004.outputs[3].hide = True
	    group_input_004.outputs[4].hide = True
	    group_input_004.outputs[5].hide = True
	    group_input_004.outputs[6].hide = True
	    group_input_004.outputs[7].hide = True
	    group_input_004.outputs[8].hide = True
	
	    #node Capture Attribute.002
	    capture_attribute_002 = duplicate_hair_curves.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_002.name = "Capture Attribute.002"
	    capture_attribute_002.active_index = 0
	    capture_attribute_002.capture_items.clear()
	    capture_attribute_002.capture_items.new('FLOAT', "Value")
	    capture_attribute_002.capture_items["Value"].data_type = 'BOOLEAN'
	    capture_attribute_002.domain = 'POINT'
	    #Value
	    capture_attribute_002.inputs[1].default_value = True
	
	    #node Vector Math.004
	    vector_math_004 = duplicate_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_004.name = "Vector Math.004"
	    vector_math_004.operation = 'SCALE'
	
	    #node Group Input.003
	    group_input_003 = duplicate_hair_curves.nodes.new("NodeGroupInput")
	    group_input_003.name = "Group Input.003"
	    group_input_003.outputs[0].hide = True
	    group_input_003.outputs[1].hide = True
	    group_input_003.outputs[2].hide = True
	    group_input_003.outputs[4].hide = True
	    group_input_003.outputs[5].hide = True
	    group_input_003.outputs[6].hide = True
	    group_input_003.outputs[7].hide = True
	    group_input_003.outputs[8].hide = True
	
	    #node Random Value.001
	    random_value_001 = duplicate_hair_curves.nodes.new("FunctionNodeRandomValue")
	    random_value_001.name = "Random Value.001"
	    random_value_001.data_type = 'FLOAT_VECTOR'
	    #Min
	    random_value_001.inputs[0].default_value = (0.0, 0.0, 0.0)
	    #Max
	    random_value_001.inputs[1].default_value = (1.0, 1.0, 1.0)
	
	    #node Capture Attribute
	    capture_attribute = duplicate_hair_curves.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute.name = "Capture Attribute"
	    capture_attribute.active_index = 0
	    capture_attribute.capture_items.clear()
	    capture_attribute.capture_items.new('FLOAT', "Value")
	    capture_attribute.capture_items["Value"].data_type = 'INT'
	    capture_attribute.domain = 'POINT'
	
	    #node Duplicate Elements
	    duplicate_elements = duplicate_hair_curves.nodes.new("GeometryNodeDuplicateElements")
	    duplicate_elements.name = "Duplicate Elements"
	    duplicate_elements.domain = 'SPLINE'
	    #Selection
	    duplicate_elements.inputs[1].default_value = True
	
	    #node Join Geometry.001
	    join_geometry_001 = duplicate_hair_curves.nodes.new("GeometryNodeJoinGeometry")
	    join_geometry_001.name = "Join Geometry.001"
	
	    #node Random Value
	    random_value = duplicate_hair_curves.nodes.new("FunctionNodeRandomValue")
	    random_value.name = "Random Value"
	    random_value.data_type = 'INT'
	    #Min_002
	    random_value.inputs[4].default_value = -1073741823
	    #Max_002
	    random_value.inputs[5].default_value = 1073741823
	
	    #node Reroute.020
	    reroute_020 = duplicate_hair_curves.nodes.new("NodeReroute")
	    reroute_020.name = "Reroute.020"
	    reroute_020.socket_idname = "NodeSocketGeometry"
	    #node Index
	    index = duplicate_hair_curves.nodes.new("GeometryNodeInputIndex")
	    index.name = "Index"
	
	    #node Capture Attribute.001
	    capture_attribute_001 = duplicate_hair_curves.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_001.name = "Capture Attribute.001"
	    capture_attribute_001.active_index = 0
	    capture_attribute_001.capture_items.clear()
	    capture_attribute_001.capture_items.new('FLOAT', "Value")
	    capture_attribute_001.capture_items["Value"].data_type = 'INT'
	    capture_attribute_001.domain = 'CURVE'
	
	    #node Switch.001
	    switch_001 = duplicate_hair_curves.nodes.new("GeometryNodeSwitch")
	    switch_001.name = "Switch.001"
	    switch_001.input_type = 'GEOMETRY'
	
	    #node Group
	    group_1 = duplicate_hair_curves.nodes.new("GeometryNodeGroup")
	    group_1.name = "Group"
	    group_1.node_tree = curve_info_001
	    group_1.outputs[0].hide = True
	    group_1.outputs[2].hide = True
	    group_1.outputs[3].hide = True
	    group_1.outputs[4].hide = True
	    group_1.outputs[5].hide = True
	
	    #node Group Input.001
	    group_input_001 = duplicate_hair_curves.nodes.new("NodeGroupInput")
	    group_input_001.name = "Group Input.001"
	    group_input_001.outputs[0].hide = True
	    group_input_001.outputs[1].hide = True
	    group_input_001.outputs[2].hide = True
	    group_input_001.outputs[3].hide = True
	    group_input_001.outputs[4].hide = True
	    group_input_001.outputs[5].hide = True
	    group_input_001.outputs[6].hide = True
	    group_input_001.outputs[8].hide = True
	
	    #node Group Input.005
	    group_input_005 = duplicate_hair_curves.nodes.new("NodeGroupInput")
	    group_input_005.name = "Group Input.005"
	    group_input_005.outputs[0].hide = True
	    group_input_005.outputs[1].hide = True
	    group_input_005.outputs[2].hide = True
	    group_input_005.outputs[3].hide = True
	    group_input_005.outputs[4].hide = True
	    group_input_005.outputs[5].hide = True
	    group_input_005.outputs[7].hide = True
	    group_input_005.outputs[8].hide = True
	
	    #node Random Value.004
	    random_value_004 = duplicate_hair_curves.nodes.new("FunctionNodeRandomValue")
	    random_value_004.name = "Random Value.004"
	    random_value_004.data_type = 'INT'
	    #Min_002
	    random_value_004.inputs[4].default_value = -1073741823
	    #Max_002
	    random_value_004.inputs[5].default_value = 1073741823
	    #Seed
	    random_value_004.inputs[8].default_value = 296
	
	
	
	
	    #Set parents
	    math_053.parent = frame_002
	    math_055.parent = frame_002
	    math_056.parent = frame_002
	    group_input_006.parent = frame_002
	    separate_xyz_002.parent = frame_002
	    math_054.parent = frame_002
	    math_052.parent = frame_002
	    combine_xyz_002.parent = frame_002
	    math_059.parent = frame_002
	    math_058.parent = frame_002
	    vector_rotate.parent = frame_002
	    math_057.parent = frame_002
	    group_input_007.parent = frame_002
	    combine_xyz.parent = frame_002
	    vector_math_014.parent = frame_002
	    vector_math_013.parent = frame_002
	    normal.parent = frame_001
	    curve_tangent_2.parent = frame_001
	    separate_xyz.parent = frame_001
	    vector_math_001_1.parent = frame_001
	    vector_math_003.parent = frame_001
	    vector_math_002.parent = frame_001
	    vector_math_009.parent = frame_001
	    vector_math_010.parent = frame_001
	    vector_math_1.parent = frame_001
	    group_001_1.parent = frame_1
	    evaluate_on_domain_002_1.parent = frame_1
	    separate_xyz_001.parent = frame_1
	    vector_math_011.parent = frame_1
	    vector_math_005.parent = frame_1
	    vector_math_007.parent = frame_1
	    vector_math_008.parent = frame_1
	    evaluate_at_index_1.parent = frame_1
	    vector_math_012.parent = frame_1
	    vector_math_006.parent = frame_1
	    evaluate_on_domain_001_1.parent = frame_1
	    curve_tangent_001.parent = frame_1
	    normal_001.parent = frame_1
	    is_viewport.parent = frame_004
	    switch.parent = frame_004
	    id_1.parent = frame_004
	    reroute_004.parent = frame_004
	    reroute_002.parent = frame_004
	    join_geometry.parent = frame_004
	    set_id.parent = frame_004
	    store_named_attribute.parent = frame_004
	    math.parent = frame_004
	    group_input_002.parent = frame_004
	    group_input_004.parent = frame_004
	    capture_attribute_002.parent = frame_004
	    random_value_001.parent = frame_003
	    capture_attribute.parent = frame_004
	    duplicate_elements.parent = frame_004
	    random_value.parent = frame_004
	    group_1.parent = frame_003
	    group_input_001.parent = frame_003
	    random_value_004.parent = frame_003
	
	    #Set locations
	    frame_002.location = (-4255.0, -613.0)
	    frame_001.location = (-1965.0, -734.0)
	    frame_1.location = (-2265.0, -272.0)
	    frame_004.location = (-2910.0, 228.0)
	    frame_003.location = (-4868.0, -613.0)
	    reroute_016.location = (-431.521728515625, 395.1722106933594)
	    reroute_017.location = (-431.521728515625, 354.9861755371094)
	    reroute_019.location = (-431.521728515625, 314.8001403808594)
	    reroute_018.location = (-431.521728515625, 274.6141052246094)
	    group_input.location = (-3843.1396484375, 29.906982421875)
	    group_output_3.location = (75.0, 50.0)
	    separate_components.location = (-3652.255859375, 19.86041259765625)
	    math_053.location = (230.622802734375, -60.3717041015625)
	    math_055.location = (230.622802734375, -100.5577392578125)
	    math_056.location = (190.436767578125, -221.11590576171875)
	    group_input_006.location = (29.6923828125, -221.11590576171875)
	    separate_xyz_002.location = (29.6923828125, -60.3717041015625)
	    math_054.location = (411.4599609375, -80.4647216796875)
	    math_052.location = (411.4599609375, -201.02288818359375)
	    combine_xyz_002.location = (592.29736328125, -40.2786865234375)
	    math_059.location = (592.29736328125, -281.39495849609375)
	    math_058.location = (592.29736328125, -241.20892333984375)
	    vector_rotate.location = (773.13427734375, -60.3717041015625)
	    math_057.location = (773.13427734375, -201.02288818359375)
	    group_input_007.location = (953.9716796875, -301.48797607421875)
	    combine_xyz.location = (953.9716796875, -201.02288818359375)
	    vector_math_014.location = (1134.808837890625, -221.11590576171875)
	    vector_math_013.location = (1335.739013671875, -140.7437744140625)
	    reroute_001.location = (-839.232666015625, -160.97679138183594)
	    reroute_003.location = (-839.232666015625, -281.5349426269531)
	    set_position.location = (-738.7674560546875, -241.348876953125)
	    set_position_001.location = (-738.7674560546875, -80.60469055175781)
	    normal.location = (30.2864990234375, -160.773193359375)
	    curve_tangent_2.location = (30.2864990234375, -100.494140625)
	    separate_xyz.location = (231.216796875, -221.05230712890625)
	    vector_math_001_1.location = (412.053955078125, -40.215087890625)
	    vector_math_003.location = (592.8912353515625, -40.215087890625)
	    vector_math_002.location = (412.053955078125, -180.86627197265625)
	    vector_math_009.location = (793.8214111328125, -40.215087890625)
	    vector_math_010.location = (592.8912353515625, -200.95928955078125)
	    vector_math_1.location = (231.216796875, -40.215087890625)
	    group_001_1.location = (743.9742431640625, -60.11541748046875)
	    evaluate_on_domain_002_1.location = (1105.648681640625, -40.02239990234375)
	    separate_xyz_001.location = (201.46240234375, -261.045654296875)
	    vector_math_011.location = (743.9742431640625, -140.487548828125)
	    vector_math_005.location = (563.136962890625, -140.487548828125)
	    vector_math_007.location = (382.2998046875, -120.39453125)
	    vector_math_008.location = (201.46240234375, -120.39453125)
	    evaluate_at_index_1.location = (924.8114013671875, -40.02239990234375)
	    vector_math_012.location = (563.136962890625, -301.231689453125)
	    vector_math_006.location = (382.2998046875, -261.045654296875)
	    evaluate_on_domain_001_1.location = (29.70654296875, -339.79510498046875)
	    curve_tangent_001.location = (29.70654296875, -118.77178955078125)
	    normal_001.location = (29.70654296875, -179.0509033203125)
	    reroute_014.location = (-3230.302490234375, 341.3487854003906)
	    reroute_015.location = (-3230.302490234375, 301.1627502441406)
	    reroute_013.location = (-3230.302490234375, 260.9767150878906)
	    reroute_012.location = (-3230.302490234375, 381.5348815917969)
	    is_viewport.location = (280.716064453125, -275.73028564453125)
	    switch.location = (461.55322265625, -235.54425048828125)
	    id_1.location = (29.55322265625, -205.40472412109375)
	    reroute_004.location = (1375.44677734375, -241.39447021484375)
	    reroute_002.location = (571.725830078125, -100.7432861328125)
	    join_geometry.location = (1074.0513916015625, -60.5572509765625)
	    set_id.location = (1274.981689453125, -60.5572509765625)
	    store_named_attribute.location = (1475.911865234375, -40.464202880859375)
	    math.location = (290.423583984375, -382.0456237792969)
	    group_input_002.location = (89.4931640625, -382.0456237792969)
	    group_input_004.location = (89.4931640625, -321.76654052734375)
	    capture_attribute_002.location = (843.28857421875, -131.15524291992188)
	    vector_math_004.location = (-2506.95361328125, -703.4884033203125)
	    group_input_003.location = (-2687.790771484375, -824.0465698242188)
	    random_value_001.location = (381.48486328125, -40.2786865234375)
	    capture_attribute.location = (224.854736328125, -51.218994140625)
	    duplicate_elements.location = (652.097900390625, -120.83633422851562)
	    join_geometry_001.location = (-130.127197265625, 53.59075927734375)
	    random_value.location = (1074.0513916015625, -161.02236938476562)
	    reroute_020.location = (-223.732666015625, -87.405517578125)
	    index.location = (-3431.232666015625, -100.69772338867188)
	    capture_attribute_001.location = (-3210.20947265625, 60.046478271484375)
	    switch_001.location = (-507.69775390625, -50.46514892578125)
	    group_1.location = (211.0927734375, -211.04656982421875)
	    group_input_001.location = (30.255859375, -331.604736328125)
	    group_input_005.location = (-738.7674560546875, -0.23260498046875)
	    random_value_004.location = (211.0927734375, -291.418701171875)
	
	    #Set dimensions
	    frame_002.width, frame_002.height = 1506.0, 383.0
	    frame_001.width, frame_001.height = 964.0, 370.0
	    frame_1.width, frame_1.height = 1276.0, 430.0
	    frame_004.width, frame_004.height = 1646.0, 464.0
	    frame_003.width, frame_003.height = 551.0, 464.0
	    reroute_016.width, reroute_016.height = 100.0, 100.0
	    reroute_017.width, reroute_017.height = 100.0, 100.0
	    reroute_019.width, reroute_019.height = 100.0, 100.0
	    reroute_018.width, reroute_018.height = 100.0, 100.0
	    group_input.width, group_input.height = 140.0, 100.0
	    group_output_3.width, group_output_3.height = 140.0, 100.0
	    separate_components.width, separate_components.height = 140.0, 100.0
	    math_053.width, math_053.height = 140.0, 100.0
	    math_055.width, math_055.height = 140.0, 100.0
	    math_056.width, math_056.height = 140.0, 100.0
	    group_input_006.width, group_input_006.height = 140.0, 100.0
	    separate_xyz_002.width, separate_xyz_002.height = 140.0, 100.0
	    math_054.width, math_054.height = 140.0, 100.0
	    math_052.width, math_052.height = 140.0, 100.0
	    combine_xyz_002.width, combine_xyz_002.height = 140.0, 100.0
	    math_059.width, math_059.height = 140.0, 100.0
	    math_058.width, math_058.height = 140.0, 100.0
	    vector_rotate.width, vector_rotate.height = 140.0, 100.0
	    math_057.width, math_057.height = 140.0, 100.0
	    group_input_007.width, group_input_007.height = 140.0, 100.0
	    combine_xyz.width, combine_xyz.height = 140.0, 100.0
	    vector_math_014.width, vector_math_014.height = 140.0, 100.0
	    vector_math_013.width, vector_math_013.height = 140.0, 100.0
	    reroute_001.width, reroute_001.height = 100.0, 100.0
	    reroute_003.width, reroute_003.height = 100.0, 100.0
	    set_position.width, set_position.height = 140.0, 100.0
	    set_position_001.width, set_position_001.height = 140.0, 100.0
	    normal.width, normal.height = 140.0, 100.0
	    curve_tangent_2.width, curve_tangent_2.height = 140.0, 100.0
	    separate_xyz.width, separate_xyz.height = 140.0, 100.0
	    vector_math_001_1.width, vector_math_001_1.height = 140.0, 100.0
	    vector_math_003.width, vector_math_003.height = 140.0, 100.0
	    vector_math_002.width, vector_math_002.height = 140.0, 100.0
	    vector_math_009.width, vector_math_009.height = 140.0, 100.0
	    vector_math_010.width, vector_math_010.height = 140.0, 100.0
	    vector_math_1.width, vector_math_1.height = 140.0, 100.0
	    group_001_1.width, group_001_1.height = 140.0, 100.0
	    evaluate_on_domain_002_1.width, evaluate_on_domain_002_1.height = 140.0, 100.0
	    separate_xyz_001.width, separate_xyz_001.height = 140.0, 100.0
	    vector_math_011.width, vector_math_011.height = 140.0, 100.0
	    vector_math_005.width, vector_math_005.height = 140.0, 100.0
	    vector_math_007.width, vector_math_007.height = 140.0, 100.0
	    vector_math_008.width, vector_math_008.height = 140.0, 100.0
	    evaluate_at_index_1.width, evaluate_at_index_1.height = 140.0, 100.0
	    vector_math_012.width, vector_math_012.height = 140.0, 100.0
	    vector_math_006.width, vector_math_006.height = 140.0, 100.0
	    evaluate_on_domain_001_1.width, evaluate_on_domain_001_1.height = 140.0, 100.0
	    curve_tangent_001.width, curve_tangent_001.height = 140.0, 100.0
	    normal_001.width, normal_001.height = 140.0, 100.0
	    reroute_014.width, reroute_014.height = 100.0, 100.0
	    reroute_015.width, reroute_015.height = 100.0, 100.0
	    reroute_013.width, reroute_013.height = 100.0, 100.0
	    reroute_012.width, reroute_012.height = 100.0, 100.0
	    is_viewport.width, is_viewport.height = 140.0, 100.0
	    switch.width, switch.height = 140.0, 100.0
	    id_1.width, id_1.height = 140.0, 100.0
	    reroute_004.width, reroute_004.height = 100.0, 100.0
	    reroute_002.width, reroute_002.height = 100.0, 100.0
	    join_geometry.width, join_geometry.height = 140.0, 100.0
	    set_id.width, set_id.height = 140.0, 100.0
	    store_named_attribute.width, store_named_attribute.height = 140.0, 100.0
	    math.width, math.height = 140.0, 100.0
	    group_input_002.width, group_input_002.height = 140.0, 100.0
	    group_input_004.width, group_input_004.height = 140.0, 100.0
	    capture_attribute_002.width, capture_attribute_002.height = 140.0, 100.0
	    vector_math_004.width, vector_math_004.height = 140.0, 100.0
	    group_input_003.width, group_input_003.height = 140.0, 100.0
	    random_value_001.width, random_value_001.height = 140.0, 100.0
	    capture_attribute.width, capture_attribute.height = 140.0, 100.0
	    duplicate_elements.width, duplicate_elements.height = 140.0, 100.0
	    join_geometry_001.width, join_geometry_001.height = 140.0, 100.0
	    random_value.width, random_value.height = 140.0, 100.0
	    reroute_020.width, reroute_020.height = 100.0, 100.0
	    index.width, index.height = 140.0, 100.0
	    capture_attribute_001.width, capture_attribute_001.height = 140.0, 100.0
	    switch_001.width, switch_001.height = 140.0, 100.0
	    group_1.width, group_1.height = 140.0, 100.0
	    group_input_001.width, group_input_001.height = 140.0, 100.0
	    group_input_005.width, group_input_005.height = 140.0, 100.0
	    random_value_004.width, random_value_004.height = 140.0, 100.0
	
	    #initialize duplicate_hair_curves links
	    #join_geometry_001.Geometry -> group_output_3.Geometry
	    duplicate_hair_curves.links.new(join_geometry_001.outputs[0], group_output_3.inputs[0])
	    #reroute_002.Output -> duplicate_elements.Geometry
	    duplicate_hair_curves.links.new(reroute_002.outputs[0], duplicate_elements.inputs[0])
	    #capture_attribute_001.Geometry -> capture_attribute.Geometry
	    duplicate_hair_curves.links.new(capture_attribute_001.outputs[0], capture_attribute.inputs[0])
	    #random_value.Value -> set_id.ID
	    duplicate_hair_curves.links.new(random_value.outputs[2], set_id.inputs[2])
	    #capture_attribute.Value -> random_value.ID
	    duplicate_hair_curves.links.new(capture_attribute.outputs[1], random_value.inputs[7])
	    #duplicate_elements.Duplicate Index -> random_value.Seed
	    duplicate_hair_curves.links.new(duplicate_elements.outputs[1], random_value.inputs[8])
	    #random_value_001.Value -> separate_xyz_002.Vector
	    duplicate_hair_curves.links.new(random_value_001.outputs[0], separate_xyz_002.inputs[0])
	    #math_052.Value -> vector_rotate.Angle
	    duplicate_hair_curves.links.new(math_052.outputs[0], vector_rotate.inputs[3])
	    #combine_xyz_002.Vector -> vector_rotate.Vector
	    duplicate_hair_curves.links.new(combine_xyz_002.outputs[0], vector_rotate.inputs[0])
	    #separate_xyz_002.Y -> math_052.Value
	    duplicate_hair_curves.links.new(separate_xyz_002.outputs[1], math_052.inputs[0])
	    #separate_xyz_002.X -> math_053.Value
	    duplicate_hair_curves.links.new(separate_xyz_002.outputs[0], math_053.inputs[0])
	    #math_054.Value -> combine_xyz_002.X
	    duplicate_hair_curves.links.new(math_054.outputs[0], combine_xyz_002.inputs[0])
	    #group_1.Curve ID -> random_value_001.ID
	    duplicate_hair_curves.links.new(group_1.outputs[1], random_value_001.inputs[7])
	    #vector_math_004.Vector -> separate_xyz.Vector
	    duplicate_hair_curves.links.new(vector_math_004.outputs[0], separate_xyz.inputs[0])
	    #reroute_001.Output -> set_position.Geometry
	    duplicate_hair_curves.links.new(reroute_001.outputs[0], set_position.inputs[0])
	    #curve_tangent_2.Tangent -> vector_math_1.Vector
	    duplicate_hair_curves.links.new(curve_tangent_2.outputs[0], vector_math_1.inputs[0])
	    #normal.Normal -> vector_math_1.Vector
	    duplicate_hair_curves.links.new(normal.outputs[0], vector_math_1.inputs[1])
	    #vector_math_1.Vector -> vector_math_001_1.Vector
	    duplicate_hair_curves.links.new(vector_math_1.outputs[0], vector_math_001_1.inputs[0])
	    #vector_math_001_1.Vector -> vector_math_003.Vector
	    duplicate_hair_curves.links.new(vector_math_001_1.outputs[0], vector_math_003.inputs[0])
	    #vector_math_002.Vector -> vector_math_003.Vector
	    duplicate_hair_curves.links.new(vector_math_002.outputs[0], vector_math_003.inputs[1])
	    #separate_xyz.X -> vector_math_001_1.Scale
	    duplicate_hair_curves.links.new(separate_xyz.outputs[0], vector_math_001_1.inputs[3])
	    #separate_xyz.Y -> vector_math_002.Scale
	    duplicate_hair_curves.links.new(separate_xyz.outputs[1], vector_math_002.inputs[3])
	    #normal.Normal -> vector_math_002.Vector
	    duplicate_hair_curves.links.new(normal.outputs[0], vector_math_002.inputs[0])
	    #index.Index -> capture_attribute_001.Value
	    duplicate_hair_curves.links.new(index.outputs[0], capture_attribute_001.inputs[1])
	    #set_id.Geometry -> store_named_attribute.Geometry
	    duplicate_hair_curves.links.new(set_id.outputs[0], store_named_attribute.inputs[0])
	    #capture_attribute_002.Geometry -> join_geometry.Geometry
	    duplicate_hair_curves.links.new(capture_attribute_002.outputs[0], join_geometry.inputs[0])
	    #reroute_004.Output -> store_named_attribute.Value
	    duplicate_hair_curves.links.new(reroute_004.outputs[0], store_named_attribute.inputs[3])
	    #group_input_004.Amount -> switch.False
	    duplicate_hair_curves.links.new(group_input_004.outputs[1], switch.inputs[1])
	    #switch.Output -> duplicate_elements.Amount
	    duplicate_hair_curves.links.new(switch.outputs[0], duplicate_elements.inputs[2])
	    #is_viewport.Is Viewport -> switch.Switch
	    duplicate_hair_curves.links.new(is_viewport.outputs[0], switch.inputs[0])
	    #group_input_004.Amount -> math.Value
	    duplicate_hair_curves.links.new(group_input_004.outputs[1], math.inputs[0])
	    #math.Value -> switch.True
	    duplicate_hair_curves.links.new(math.outputs[0], switch.inputs[2])
	    #group_input_002.Viewport Amount -> math.Value
	    duplicate_hair_curves.links.new(group_input_002.outputs[2], math.inputs[1])
	    #id_1.ID -> capture_attribute.Value
	    duplicate_hair_curves.links.new(id_1.outputs[0], capture_attribute.inputs[1])
	    #vector_math_009.Vector -> set_position.Offset
	    duplicate_hair_curves.links.new(vector_math_009.outputs[0], set_position.inputs[3])
	    #group_input_005.Even Thickness -> switch_001.Switch
	    duplicate_hair_curves.links.new(group_input_005.outputs[6], switch_001.inputs[0])
	    #vector_math_007.Vector -> vector_math_005.Vector
	    duplicate_hair_curves.links.new(vector_math_007.outputs[0], vector_math_005.inputs[0])
	    #vector_math_006.Vector -> vector_math_005.Vector
	    duplicate_hair_curves.links.new(vector_math_006.outputs[0], vector_math_005.inputs[1])
	    #separate_xyz_001.X -> vector_math_007.Scale
	    duplicate_hair_curves.links.new(separate_xyz_001.outputs[0], vector_math_007.inputs[3])
	    #separate_xyz_001.Y -> vector_math_006.Scale
	    duplicate_hair_curves.links.new(separate_xyz_001.outputs[1], vector_math_006.inputs[3])
	    #evaluate_on_domain_002_1.Value -> set_position_001.Offset
	    duplicate_hair_curves.links.new(evaluate_on_domain_002_1.outputs[0], set_position_001.inputs[3])
	    #curve_tangent_001.Tangent -> vector_math_008.Vector
	    duplicate_hair_curves.links.new(curve_tangent_001.outputs[0], vector_math_008.inputs[0])
	    #normal_001.Normal -> vector_math_008.Vector
	    duplicate_hair_curves.links.new(normal_001.outputs[0], vector_math_008.inputs[1])
	    #evaluate_at_index_1.Value -> evaluate_on_domain_002_1.Value
	    duplicate_hair_curves.links.new(evaluate_at_index_1.outputs[0], evaluate_on_domain_002_1.inputs[0])
	    #vector_math_008.Vector -> vector_math_007.Vector
	    duplicate_hair_curves.links.new(vector_math_008.outputs[0], vector_math_007.inputs[0])
	    #normal_001.Normal -> vector_math_006.Vector
	    duplicate_hair_curves.links.new(normal_001.outputs[0], vector_math_006.inputs[0])
	    #evaluate_on_domain_001_1.Value -> separate_xyz_001.Vector
	    duplicate_hair_curves.links.new(evaluate_on_domain_001_1.outputs[0], separate_xyz_001.inputs[0])
	    #store_named_attribute.Geometry -> reroute_001.Input
	    duplicate_hair_curves.links.new(store_named_attribute.outputs[0], reroute_001.inputs[0])
	    #reroute_001.Output -> set_position_001.Geometry
	    duplicate_hair_curves.links.new(reroute_001.outputs[0], set_position_001.inputs[0])
	    #vector_math_011.Vector -> evaluate_at_index_1.Value
	    duplicate_hair_curves.links.new(vector_math_011.outputs[0], evaluate_at_index_1.inputs[1])
	    #group_001_1.Root Index -> evaluate_at_index_1.Index
	    duplicate_hair_curves.links.new(group_001_1.outputs[3], evaluate_at_index_1.inputs[0])
	    #capture_attribute.Geometry -> reroute_002.Input
	    duplicate_hair_curves.links.new(capture_attribute.outputs[0], reroute_002.inputs[0])
	    #math_055.Value -> math_054.Value
	    duplicate_hair_curves.links.new(math_055.outputs[0], math_054.inputs[0])
	    #math_053.Value -> math_055.Value
	    duplicate_hair_curves.links.new(math_053.outputs[0], math_055.inputs[0])
	    #math_056.Value -> math_054.Value
	    duplicate_hair_curves.links.new(math_056.outputs[0], math_054.inputs[1])
	    #group_input_006.Distribution Shape -> math_056.Value
	    duplicate_hair_curves.links.new(group_input_006.outputs[4], math_056.inputs[1])
	    #vector_math_003.Vector -> vector_math_009.Vector
	    duplicate_hair_curves.links.new(vector_math_003.outputs[0], vector_math_009.inputs[0])
	    #separate_xyz.Z -> vector_math_010.Scale
	    duplicate_hair_curves.links.new(separate_xyz.outputs[2], vector_math_010.inputs[3])
	    #curve_tangent_2.Tangent -> vector_math_010.Vector
	    duplicate_hair_curves.links.new(curve_tangent_2.outputs[0], vector_math_010.inputs[0])
	    #vector_math_010.Vector -> vector_math_009.Vector
	    duplicate_hair_curves.links.new(vector_math_010.outputs[0], vector_math_009.inputs[1])
	    #vector_math_005.Vector -> vector_math_011.Vector
	    duplicate_hair_curves.links.new(vector_math_005.outputs[0], vector_math_011.inputs[0])
	    #vector_math_012.Vector -> vector_math_011.Vector
	    duplicate_hair_curves.links.new(vector_math_012.outputs[0], vector_math_011.inputs[1])
	    #separate_xyz_001.Z -> vector_math_012.Scale
	    duplicate_hair_curves.links.new(separate_xyz_001.outputs[2], vector_math_012.inputs[3])
	    #curve_tangent_001.Tangent -> vector_math_012.Vector
	    duplicate_hair_curves.links.new(curve_tangent_001.outputs[0], vector_math_012.inputs[0])
	    #vector_rotate.Vector -> vector_math_013.Vector
	    duplicate_hair_curves.links.new(vector_rotate.outputs[0], vector_math_013.inputs[0])
	    #vector_math_014.Vector -> vector_math_013.Vector
	    duplicate_hair_curves.links.new(vector_math_014.outputs[0], vector_math_013.inputs[1])
	    #math_057.Value -> combine_xyz.Z
	    duplicate_hair_curves.links.new(math_057.outputs[0], combine_xyz.inputs[2])
	    #vector_math_013.Vector -> vector_math_004.Vector
	    duplicate_hair_curves.links.new(vector_math_013.outputs[0], vector_math_004.inputs[0])
	    #group_input_003.Radius -> vector_math_004.Scale
	    duplicate_hair_curves.links.new(group_input_003.outputs[3], vector_math_004.inputs[3])
	    #math_058.Value -> math_057.Value
	    duplicate_hair_curves.links.new(math_058.outputs[0], math_057.inputs[0])
	    #math_059.Value -> math_057.Value
	    duplicate_hair_curves.links.new(math_059.outputs[0], math_057.inputs[1])
	    #math_054.Value -> math_058.Value
	    duplicate_hair_curves.links.new(math_054.outputs[0], math_058.inputs[0])
	    #combine_xyz.Vector -> vector_math_014.Vector
	    duplicate_hair_curves.links.new(combine_xyz.outputs[0], vector_math_014.inputs[0])
	    #group_input_007.Tip Roundness -> vector_math_014.Scale
	    duplicate_hair_curves.links.new(group_input_007.outputs[5], vector_math_014.inputs[3])
	    #separate_xyz_002.Z -> math_059.Value
	    duplicate_hair_curves.links.new(separate_xyz_002.outputs[2], math_059.inputs[0])
	    #set_position_001.Geometry -> switch_001.False
	    duplicate_hair_curves.links.new(set_position_001.outputs[0], switch_001.inputs[1])
	    #set_position.Geometry -> switch_001.True
	    duplicate_hair_curves.links.new(set_position.outputs[0], switch_001.inputs[2])
	    #reroute_003.Output -> set_position.Selection
	    duplicate_hair_curves.links.new(reroute_003.outputs[0], set_position.inputs[1])
	    #reroute_003.Output -> set_position_001.Selection
	    duplicate_hair_curves.links.new(reroute_003.outputs[0], set_position_001.inputs[1])
	    #capture_attribute_002.Value -> reroute_003.Input
	    duplicate_hair_curves.links.new(capture_attribute_002.outputs[1], reroute_003.inputs[0])
	    #capture_attribute_001.Value -> reroute_004.Input
	    duplicate_hair_curves.links.new(capture_attribute_001.outputs[1], reroute_004.inputs[0])
	    #join_geometry.Geometry -> set_id.Geometry
	    duplicate_hair_curves.links.new(join_geometry.outputs[0], set_id.inputs[0])
	    #duplicate_elements.Geometry -> capture_attribute_002.Geometry
	    duplicate_hair_curves.links.new(duplicate_elements.outputs[0], capture_attribute_002.inputs[0])
	    #group_input_001.Seed -> random_value_004.ID
	    duplicate_hair_curves.links.new(group_input_001.outputs[7], random_value_004.inputs[7])
	    #random_value_004.Value -> random_value_001.Seed
	    duplicate_hair_curves.links.new(random_value_004.outputs[2], random_value_001.inputs[8])
	    #vector_math_004.Vector -> evaluate_on_domain_001_1.Value
	    duplicate_hair_curves.links.new(vector_math_004.outputs[0], evaluate_on_domain_001_1.inputs[0])
	    #reroute_018.Output -> join_geometry_001.Geometry
	    duplicate_hair_curves.links.new(reroute_018.outputs[0], join_geometry_001.inputs[0])
	    #separate_components.Mesh -> reroute_012.Input
	    duplicate_hair_curves.links.new(separate_components.outputs[0], reroute_012.inputs[0])
	    #separate_components.Instances -> reroute_013.Input
	    duplicate_hair_curves.links.new(separate_components.outputs[5], reroute_013.inputs[0])
	    #separate_components.Point Cloud -> reroute_014.Input
	    duplicate_hair_curves.links.new(separate_components.outputs[3], reroute_014.inputs[0])
	    #separate_components.Volume -> reroute_015.Input
	    duplicate_hair_curves.links.new(separate_components.outputs[4], reroute_015.inputs[0])
	    #reroute_012.Output -> reroute_016.Input
	    duplicate_hair_curves.links.new(reroute_012.outputs[0], reroute_016.inputs[0])
	    #reroute_014.Output -> reroute_017.Input
	    duplicate_hair_curves.links.new(reroute_014.outputs[0], reroute_017.inputs[0])
	    #reroute_013.Output -> reroute_018.Input
	    duplicate_hair_curves.links.new(reroute_013.outputs[0], reroute_018.inputs[0])
	    #reroute_015.Output -> reroute_019.Input
	    duplicate_hair_curves.links.new(reroute_015.outputs[0], reroute_019.inputs[0])
	    #switch_001.Output -> reroute_020.Input
	    duplicate_hair_curves.links.new(switch_001.outputs[0], reroute_020.inputs[0])
	    #group_input.Geometry -> separate_components.Geometry
	    duplicate_hair_curves.links.new(group_input.outputs[0], separate_components.inputs[0])
	    #separate_components.Curve -> capture_attribute_001.Geometry
	    duplicate_hair_curves.links.new(separate_components.outputs[1], capture_attribute_001.inputs[0])
	    #reroute_004.Output -> group_output_3.Guide Index
	    duplicate_hair_curves.links.new(reroute_004.outputs[0], group_output_3.inputs[1])
	    #reroute_002.Output -> join_geometry.Geometry
	    duplicate_hair_curves.links.new(reroute_002.outputs[0], join_geometry.inputs[0])
	    #reroute_019.Output -> join_geometry_001.Geometry
	    duplicate_hair_curves.links.new(reroute_019.outputs[0], join_geometry_001.inputs[0])
	    #reroute_020.Output -> join_geometry_001.Geometry
	    duplicate_hair_curves.links.new(reroute_020.outputs[0], join_geometry_001.inputs[0])
	    #reroute_017.Output -> join_geometry_001.Geometry
	    duplicate_hair_curves.links.new(reroute_017.outputs[0], join_geometry_001.inputs[0])
	    #reroute_016.Output -> join_geometry_001.Geometry
	    duplicate_hair_curves.links.new(reroute_016.outputs[0], join_geometry_001.inputs[0])
	    return duplicate_hair_curves
	
	duplicate_hair_curves = duplicate_hair_curves_node_group()
	
	#initialize braid_loop node group
	def braid_loop_node_group():
	    braid_loop = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Braid Loop")
	
	    braid_loop.color_tag = 'NONE'
	    braid_loop.description = "Single braid loop template."
	    braid_loop.default_group_node_width = 140
	    
	
	
	    #braid_loop interface
	    #Socket Geometry
	    geometry_socket_2 = braid_loop.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_2.attribute_domain = 'POINT'
	    geometry_socket_2.description = "Braid loop."
	
	    #Socket Length
	    length_socket_1 = braid_loop.interface.new_socket(name = "Length", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    length_socket_1.default_value = 1.0
	    length_socket_1.min_value = 9.999999747378752e-05
	    length_socket_1.max_value = 10000.0
	    length_socket_1.subtype = 'NONE'
	    length_socket_1.attribute_domain = 'POINT'
	    length_socket_1.description = "Braid Length."
	
	    #Socket Frequency
	    frequency_socket = braid_loop.interface.new_socket(name = "Frequency", in_out='INPUT', socket_type = 'NodeSocketInt')
	    frequency_socket.default_value = 1
	    frequency_socket.min_value = 1
	    frequency_socket.max_value = 10000
	    frequency_socket.subtype = 'NONE'
	    frequency_socket.attribute_domain = 'POINT'
	    frequency_socket.description = "Frequency of braid twists."
	
	    #Socket Scale
	    scale_socket = braid_loop.interface.new_socket(name = "Scale", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    scale_socket.default_value = 1.0
	    scale_socket.min_value = 9.999999747378752e-05
	    scale_socket.max_value = 10000.0
	    scale_socket.subtype = 'NONE'
	    scale_socket.attribute_domain = 'POINT'
	    scale_socket.description = "Braid scale."
	
	    #Socket Offset
	    offset_socket = braid_loop.interface.new_socket(name = "Offset", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    offset_socket.default_value = 0.0
	    offset_socket.min_value = -3.4028234663852886e+38
	    offset_socket.max_value = 3.4028234663852886e+38
	    offset_socket.subtype = 'NONE'
	    offset_socket.attribute_domain = 'POINT'
	    offset_socket.hide_value = True
	    offset_socket.description = "Offset along curve."
	
	
	    #initialize braid_loop nodes
	    #node Group Output
	    group_output_4 = braid_loop.nodes.new("NodeGroupOutput")
	    group_output_4.name = "Group Output"
	    group_output_4.is_active_output = True
	
	    #node Group Input
	    group_input_1 = braid_loop.nodes.new("NodeGroupInput")
	    group_input_1.name = "Group Input"
	
	    #node Combine XYZ
	    combine_xyz_1 = braid_loop.nodes.new("ShaderNodeCombineXYZ")
	    combine_xyz_1.name = "Combine XYZ"
	    combine_xyz_1.hide = True
	    #Y
	    combine_xyz_1.inputs[1].default_value = 0.0
	    #Z
	    combine_xyz_1.inputs[2].default_value = 0.0
	
	    #node Math.001
	    math_001 = braid_loop.nodes.new("ShaderNodeMath")
	    math_001.name = "Math.001"
	    math_001.hide = True
	    math_001.operation = 'RADIANS'
	    math_001.use_clamp = False
	    #Value
	    math_001.inputs[0].default_value = 180.0
	
	    #node Bézier Segment
	    b_zier_segment = braid_loop.nodes.new("GeometryNodeCurvePrimitiveBezierSegment")
	    b_zier_segment.name = "Bézier Segment"
	    b_zier_segment.hide = True
	    b_zier_segment.mode = 'OFFSET'
	    #Resolution
	    b_zier_segment.inputs[0].default_value = 16
	    #Start
	    b_zier_segment.inputs[1].default_value = (0.0, 0.0, 0.0)
	
	    #node Vector.002
	    vector_002 = braid_loop.nodes.new("FunctionNodeInputVector")
	    vector_002.name = "Vector.002"
	    vector_002.hide = True
	    vector_002.vector = (-0.4999999403953552, -0.6000000238418579, -0.5)
	
	    #node Vector Math.002
	    vector_math_002_1 = braid_loop.nodes.new("ShaderNodeVectorMath")
	    vector_math_002_1.name = "Vector Math.002"
	    vector_math_002_1.hide = True
	    vector_math_002_1.operation = 'SCALE'
	    #Scale
	    vector_math_002_1.inputs[3].default_value = 2.7750000953674316
	
	    #node Vector.003
	    vector_003 = braid_loop.nodes.new("FunctionNodeInputVector")
	    vector_003.name = "Vector.003"
	    vector_003.hide = True
	    vector_003.vector = (0.7071070075035095, 0.8999999761581421, -0.7071070075035095)
	
	    #node Vector Math.003
	    vector_math_003_1 = braid_loop.nodes.new("ShaderNodeVectorMath")
	    vector_math_003_1.name = "Vector Math.003"
	    vector_math_003_1.hide = True
	    vector_math_003_1.operation = 'SCALE'
	    #Scale
	    vector_math_003_1.inputs[3].default_value = 1.875
	
	    #node Combine XYZ.001
	    combine_xyz_001 = braid_loop.nodes.new("ShaderNodeCombineXYZ")
	    combine_xyz_001.name = "Combine XYZ.001"
	    combine_xyz_001.hide = True
	    #Y
	    combine_xyz_001.inputs[1].default_value = 0.0
	    #Z
	    combine_xyz_001.inputs[2].default_value = 0.0
	
	    #node Math.003
	    math_003 = braid_loop.nodes.new("ShaderNodeMath")
	    math_003.name = "Math.003"
	    math_003.hide = True
	    math_003.operation = 'RADIANS'
	    math_003.use_clamp = False
	    #Value
	    math_003.inputs[0].default_value = 360.0
	
	    #node Bézier Segment.001
	    b_zier_segment_001 = braid_loop.nodes.new("GeometryNodeCurvePrimitiveBezierSegment")
	    b_zier_segment_001.name = "Bézier Segment.001"
	    b_zier_segment_001.hide = True
	    b_zier_segment_001.mode = 'OFFSET'
	    #Resolution
	    b_zier_segment_001.inputs[0].default_value = 16
	
	    #node Vector.004
	    vector_004 = braid_loop.nodes.new("FunctionNodeInputVector")
	    vector_004.name = "Vector.004"
	    vector_004.hide = True
	    vector_004.vector = (-0.5, -0.6000000238418579, 0.5)
	
	    #node Vector Math.004
	    vector_math_004_1 = braid_loop.nodes.new("ShaderNodeVectorMath")
	    vector_math_004_1.name = "Vector Math.004"
	    vector_math_004_1.hide = True
	    vector_math_004_1.operation = 'SCALE'
	    #Scale
	    vector_math_004_1.inputs[3].default_value = 2.7750000953674316
	
	    #node Vector.005
	    vector_005 = braid_loop.nodes.new("FunctionNodeInputVector")
	    vector_005.name = "Vector.005"
	    vector_005.hide = True
	    vector_005.vector = (0.6000000238418579, 0.8999999761581421, 0.699999988079071)
	
	    #node Vector Math.005
	    vector_math_005_1 = braid_loop.nodes.new("ShaderNodeVectorMath")
	    vector_math_005_1.name = "Vector Math.005"
	    vector_math_005_1.hide = True
	    vector_math_005_1.operation = 'SCALE'
	    #Scale
	    vector_math_005_1.inputs[3].default_value = 1.875
	
	    #node Mesh Line
	    mesh_line = braid_loop.nodes.new("GeometryNodeMeshLine")
	    mesh_line.name = "Mesh Line"
	    mesh_line.hide = True
	    mesh_line.count_mode = 'TOTAL'
	    mesh_line.mode = 'OFFSET'
	
	    #node Mesh to Points
	    mesh_to_points = braid_loop.nodes.new("GeometryNodeMeshToPoints")
	    mesh_to_points.name = "Mesh to Points"
	    mesh_to_points.hide = True
	    mesh_to_points.mode = 'VERTICES'
	    #Selection
	    mesh_to_points.inputs[1].default_value = True
	    #Position
	    mesh_to_points.inputs[2].default_value = (0.0, 0.0, 0.0)
	    #Radius
	    mesh_to_points.inputs[3].default_value = 0.05000000074505806
	
	    #node Instance on Points
	    instance_on_points = braid_loop.nodes.new("GeometryNodeInstanceOnPoints")
	    instance_on_points.name = "Instance on Points"
	    instance_on_points.hide = True
	    #Selection
	    instance_on_points.inputs[1].default_value = True
	    #Pick Instance
	    instance_on_points.inputs[3].default_value = False
	    #Instance Index
	    instance_on_points.inputs[4].default_value = 0
	    #Rotation
	    instance_on_points.inputs[5].default_value = (0.0, 0.0, 0.0)
	
	    #node Vector Math.006
	    vector_math_006_1 = braid_loop.nodes.new("ShaderNodeVectorMath")
	    vector_math_006_1.name = "Vector Math.006"
	    vector_math_006_1.hide = True
	    vector_math_006_1.operation = 'SCALE'
	
	    #node Realize Instances
	    realize_instances = braid_loop.nodes.new("GeometryNodeRealizeInstances")
	    realize_instances.name = "Realize Instances"
	    realize_instances.hide = True
	    #Selection
	    realize_instances.inputs[1].default_value = True
	    #Realize All
	    realize_instances.inputs[2].default_value = True
	    #Depth
	    realize_instances.inputs[3].default_value = 0
	
	    #node Combine XYZ.002
	    combine_xyz_002_1 = braid_loop.nodes.new("ShaderNodeCombineXYZ")
	    combine_xyz_002_1.name = "Combine XYZ.002"
	    combine_xyz_002_1.hide = True
	
	    #node Math.004
	    math_004 = braid_loop.nodes.new("ShaderNodeMath")
	    math_004.name = "Math.004"
	    math_004.hide = True
	    math_004.operation = 'DIVIDE'
	    math_004.use_clamp = False
	
	    #node Math.007
	    math_007 = braid_loop.nodes.new("ShaderNodeMath")
	    math_007.name = "Math.007"
	    math_007.hide = True
	    math_007.operation = 'DIVIDE'
	    math_007.use_clamp = False
	
	    #node Math.005
	    math_005 = braid_loop.nodes.new("ShaderNodeMath")
	    math_005.name = "Math.005"
	    math_005.hide = True
	    math_005.operation = 'MULTIPLY'
	    math_005.use_clamp = False
	    #Value_001
	    math_005.inputs[1].default_value = 0.10000000149011612
	
	    #node Combine XYZ.003
	    combine_xyz_003 = braid_loop.nodes.new("ShaderNodeCombineXYZ")
	    combine_xyz_003.name = "Combine XYZ.003"
	    combine_xyz_003.hide = True
	    #Y
	    combine_xyz_003.inputs[1].default_value = 0.0
	    #Z
	    combine_xyz_003.inputs[2].default_value = 0.0
	
	    #node Math.006
	    math_006 = braid_loop.nodes.new("ShaderNodeMath")
	    math_006.name = "Math.006"
	    math_006.hide = True
	    math_006.operation = 'MULTIPLY'
	    math_006.use_clamp = False
	    #Value_001
	    math_006.inputs[1].default_value = 0.10000000149011612
	
	    #node Frame
	    frame_2 = braid_loop.nodes.new("NodeFrame")
	    frame_2.name = "Frame"
	    frame_2.label_size = 20
	    frame_2.shrink = True
	
	    #node Frame.001
	    frame_001_1 = braid_loop.nodes.new("NodeFrame")
	    frame_001_1.name = "Frame.001"
	    frame_001_1.label_size = 20
	    frame_001_1.shrink = True
	
	    #node Geometry to Instance
	    geometry_to_instance = braid_loop.nodes.new("GeometryNodeGeometryToInstance")
	    geometry_to_instance.name = "Geometry to Instance"
	    geometry_to_instance.hide = True
	
	    #node Transform Geometry
	    transform_geometry = braid_loop.nodes.new("GeometryNodeTransform")
	    transform_geometry.name = "Transform Geometry"
	    transform_geometry.hide = True
	    transform_geometry.mode = 'COMPONENTS'
	    transform_geometry.inputs[1].hide = True
	    transform_geometry.inputs[2].hide = True
	    transform_geometry.inputs[3].hide = True
	    transform_geometry.inputs[4].hide = True
	    #Translation
	    transform_geometry.inputs[1].default_value = (0.0, 0.0, 0.0)
	    #Rotation
	    transform_geometry.inputs[2].default_value = (1.5707963705062866, 0.0, 0.0)
	    #Scale
	    transform_geometry.inputs[3].default_value = (1.0, 1.0, 1.0)
	
	
	
	
	    #Set parents
	    combine_xyz_1.parent = frame_2
	    math_001.parent = frame_2
	    vector_002.parent = frame_2
	    vector_math_002_1.parent = frame_2
	    vector_003.parent = frame_2
	    vector_math_003_1.parent = frame_2
	    vector_004.parent = frame_2
	    vector_math_004_1.parent = frame_2
	    vector_005.parent = frame_2
	    vector_math_005_1.parent = frame_2
	    math_004.parent = frame_001_1
	    math_005.parent = frame_001_1
	    combine_xyz_003.parent = frame_001_1
	    math_006.parent = frame_001_1
	
	    #Set locations
	    group_output_4.location = (358.23931884765625, -112.9077377319336)
	    group_input_1.location = (-755.9024658203125, -197.47576904296875)
	    combine_xyz_1.location = (214.88531494140625, -138.00257873535156)
	    math_001.location = (31.3377685546875, -131.35328674316406)
	    b_zier_segment.location = (-247.53013610839844, 169.12091064453125)
	    vector_002.location = (33.2281494140625, -82.77070617675781)
	    vector_math_002_1.location = (214.8314208984375, -90.62178039550781)
	    vector_003.location = (33.40655517578125, -35.232421875)
	    vector_math_003_1.location = (214.67327880859375, -42.74798583984375)
	    combine_xyz_001.location = (-563.736328125, -88.40079498291016)
	    math_003.location = (-754.074462890625, -109.81692504882812)
	    b_zier_segment_001.location = (-245.2041473388672, 81.3502197265625)
	    vector_004.location = (31.11883544921875, -230.06410217285156)
	    vector_math_004_1.location = (216.88238525390625, -235.23118591308594)
	    vector_005.location = (30.25701904296875, -181.81781005859375)
	    vector_math_005_1.location = (217.03009033203125, -188.32688903808594)
	    mesh_line.location = (-56.76719665527344, -107.69709014892578)
	    mesh_to_points.location = (-51.753761291503906, -69.88888549804688)
	    instance_on_points.location = (172.5809326171875, -87.81344604492188)
	    vector_math_006_1.location = (-56.636497497558594, -143.2117156982422)
	    realize_instances.location = (175.63006591796875, -138.87982177734375)
	    combine_xyz_002_1.location = (-101.25711059570312, -261.7208251953125)
	    math_004.location = (31.215179443359375, -34.523590087890625)
	    math_007.location = (-562.8865966796875, -132.55389404296875)
	    math_005.location = (29.73724365234375, -112.9375)
	    combine_xyz_003.location = (31.12005615234375, -150.62237548828125)
	    math_006.location = (29.73724365234375, -74.18731689453125)
	    frame_2.location = (-732.0, 267.0)
	    frame_001_1.location = (-349.0, -187.0)
	    geometry_to_instance.location = (-59.687599182128906, 114.20475006103516)
	    transform_geometry.location = (-49.989013671875, 77.83651733398438)
	
	    #Set dimensions
	    group_output_4.width, group_output_4.height = 140.0, 100.0
	    group_input_1.width, group_input_1.height = 140.0, 100.0
	    combine_xyz_1.width, combine_xyz_1.height = 140.0, 100.0
	    math_001.width, math_001.height = 140.0, 100.0
	    b_zier_segment.width, b_zier_segment.height = 140.0, 100.0
	    vector_002.width, vector_002.height = 140.0, 100.0
	    vector_math_002_1.width, vector_math_002_1.height = 140.0, 100.0
	    vector_003.width, vector_003.height = 140.0, 100.0
	    vector_math_003_1.width, vector_math_003_1.height = 140.0, 100.0
	    combine_xyz_001.width, combine_xyz_001.height = 140.0, 100.0
	    math_003.width, math_003.height = 140.0, 100.0
	    b_zier_segment_001.width, b_zier_segment_001.height = 140.0, 100.0
	    vector_004.width, vector_004.height = 140.0, 100.0
	    vector_math_004_1.width, vector_math_004_1.height = 140.0, 100.0
	    vector_005.width, vector_005.height = 140.0, 100.0
	    vector_math_005_1.width, vector_math_005_1.height = 140.0, 100.0
	    mesh_line.width, mesh_line.height = 140.0, 100.0
	    mesh_to_points.width, mesh_to_points.height = 140.0, 100.0
	    instance_on_points.width, instance_on_points.height = 140.0, 100.0
	    vector_math_006_1.width, vector_math_006_1.height = 140.0, 100.0
	    realize_instances.width, realize_instances.height = 140.0, 100.0
	    combine_xyz_002_1.width, combine_xyz_002_1.height = 140.0, 100.0
	    math_004.width, math_004.height = 140.0, 100.0
	    math_007.width, math_007.height = 140.0, 100.0
	    math_005.width, math_005.height = 140.0, 100.0
	    combine_xyz_003.width, combine_xyz_003.height = 140.0, 100.0
	    math_006.width, math_006.height = 140.0, 100.0
	    frame_2.width, frame_2.height = 387.0, 290.0
	    frame_001_1.width, frame_001_1.height = 201.0, 206.0
	    geometry_to_instance.width, geometry_to_instance.height = 160.0, 100.0
	    transform_geometry.width, transform_geometry.height = 140.0, 100.0
	
	    #initialize braid_loop links
	    #vector_math_004_1.Vector -> b_zier_segment_001.End Handle
	    braid_loop.links.new(vector_math_004_1.outputs[0], b_zier_segment_001.inputs[3])
	    #math_004.Value -> vector_math_006_1.Scale
	    braid_loop.links.new(math_004.outputs[0], vector_math_006_1.inputs[3])
	    #vector_004.Vector -> vector_math_004_1.Vector
	    braid_loop.links.new(vector_004.outputs[0], vector_math_004_1.inputs[0])
	    #math_004.Value -> combine_xyz_002_1.X
	    braid_loop.links.new(math_004.outputs[0], combine_xyz_002_1.inputs[0])
	    #mesh_to_points.Points -> instance_on_points.Points
	    braid_loop.links.new(mesh_to_points.outputs[0], instance_on_points.inputs[0])
	    #combine_xyz_001.Vector -> b_zier_segment_001.End
	    braid_loop.links.new(combine_xyz_001.outputs[0], b_zier_segment_001.inputs[4])
	    #mesh_line.Mesh -> mesh_to_points.Mesh
	    braid_loop.links.new(mesh_line.outputs[0], mesh_to_points.inputs[0])
	    #combine_xyz_1.Vector -> b_zier_segment.End
	    braid_loop.links.new(combine_xyz_1.outputs[0], b_zier_segment.inputs[4])
	    #math_003.Value -> combine_xyz_001.X
	    braid_loop.links.new(math_003.outputs[0], combine_xyz_001.inputs[0])
	    #vector_math_006_1.Vector -> mesh_line.Offset
	    braid_loop.links.new(vector_math_006_1.outputs[0], mesh_line.inputs[3])
	    #math_001.Value -> combine_xyz_1.X
	    braid_loop.links.new(math_001.outputs[0], combine_xyz_1.inputs[0])
	    #math_007.Value -> math_004.Value
	    braid_loop.links.new(math_007.outputs[0], math_004.inputs[0])
	    #vector_math_003_1.Vector -> b_zier_segment.Start Handle
	    braid_loop.links.new(vector_math_003_1.outputs[0], b_zier_segment.inputs[2])
	    #combine_xyz_1.Vector -> b_zier_segment_001.Start
	    braid_loop.links.new(combine_xyz_1.outputs[0], b_zier_segment_001.inputs[1])
	    #vector_003.Vector -> vector_math_003_1.Vector
	    braid_loop.links.new(vector_003.outputs[0], vector_math_003_1.inputs[0])
	    #vector_math_002_1.Vector -> b_zier_segment.End Handle
	    braid_loop.links.new(vector_math_002_1.outputs[0], b_zier_segment.inputs[3])
	    #combine_xyz_001.Vector -> vector_math_006_1.Vector
	    braid_loop.links.new(combine_xyz_001.outputs[0], vector_math_006_1.inputs[0])
	    #vector_math_005_1.Vector -> b_zier_segment_001.Start Handle
	    braid_loop.links.new(vector_math_005_1.outputs[0], b_zier_segment_001.inputs[2])
	    #vector_002.Vector -> vector_math_002_1.Vector
	    braid_loop.links.new(vector_002.outputs[0], vector_math_002_1.inputs[0])
	    #combine_xyz_002_1.Vector -> instance_on_points.Scale
	    braid_loop.links.new(combine_xyz_002_1.outputs[0], instance_on_points.inputs[6])
	    #vector_005.Vector -> vector_math_005_1.Vector
	    braid_loop.links.new(vector_005.outputs[0], vector_math_005_1.inputs[0])
	    #math_003.Value -> math_007.Value
	    braid_loop.links.new(math_003.outputs[0], math_007.inputs[1])
	    #group_input_1.Frequency -> mesh_line.Count
	    braid_loop.links.new(group_input_1.outputs[1], mesh_line.inputs[0])
	    #group_input_1.Frequency -> math_004.Value
	    braid_loop.links.new(group_input_1.outputs[1], math_004.inputs[1])
	    #group_input_1.Length -> math_007.Value
	    braid_loop.links.new(group_input_1.outputs[0], math_007.inputs[0])
	    #combine_xyz_003.Vector -> mesh_line.Start Location
	    braid_loop.links.new(combine_xyz_003.outputs[0], mesh_line.inputs[2])
	    #group_input_1.Scale -> math_005.Value
	    braid_loop.links.new(group_input_1.outputs[2], math_005.inputs[0])
	    #math_005.Value -> combine_xyz_002_1.Z
	    braid_loop.links.new(math_005.outputs[0], combine_xyz_002_1.inputs[2])
	    #group_input_1.Offset -> combine_xyz_003.X
	    braid_loop.links.new(group_input_1.outputs[3], combine_xyz_003.inputs[0])
	    #group_input_1.Scale -> math_006.Value
	    braid_loop.links.new(group_input_1.outputs[2], math_006.inputs[0])
	    #math_006.Value -> combine_xyz_002_1.Y
	    braid_loop.links.new(math_006.outputs[0], combine_xyz_002_1.inputs[1])
	    #realize_instances.Geometry -> group_output_4.Geometry
	    braid_loop.links.new(realize_instances.outputs[0], group_output_4.inputs[0])
	    #b_zier_segment_001.Curve -> geometry_to_instance.Geometry
	    braid_loop.links.new(b_zier_segment_001.outputs[0], geometry_to_instance.inputs[0])
	    #instance_on_points.Instances -> realize_instances.Geometry
	    braid_loop.links.new(instance_on_points.outputs[0], realize_instances.inputs[0])
	    #geometry_to_instance.Instances -> transform_geometry.Geometry
	    braid_loop.links.new(geometry_to_instance.outputs[0], transform_geometry.inputs[0])
	    #transform_geometry.Geometry -> instance_on_points.Instance
	    braid_loop.links.new(transform_geometry.outputs[0], instance_on_points.inputs[2])
	    #b_zier_segment.Curve -> geometry_to_instance.Geometry
	    braid_loop.links.new(b_zier_segment.outputs[0], geometry_to_instance.inputs[0])
	    return braid_loop
	
	braid_loop = braid_loop_node_group()
	
	#initialize braid_engine node group
	def braid_engine_node_group():
	    braid_engine = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Braid Engine")
	
	    braid_engine.color_tag = 'NONE'
	    braid_engine.description = "Create braid curve guides."
	    braid_engine.default_group_node_width = 140
	    
	
	
	    #braid_engine interface
	    #Socket Braid 1
	    braid_1_socket = braid_engine.interface.new_socket(name = "Braid 1", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    braid_1_socket.attribute_domain = 'POINT'
	    braid_1_socket.description = "First braid loop."
	
	    #Socket Braid 2
	    braid_2_socket = braid_engine.interface.new_socket(name = "Braid 2", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    braid_2_socket.attribute_domain = 'POINT'
	    braid_2_socket.description = "Second braid loop."
	
	    #Socket Braid 3
	    braid_3_socket = braid_engine.interface.new_socket(name = "Braid 3", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    braid_3_socket.attribute_domain = 'POINT'
	    braid_3_socket.description = "Third braid loop."
	
	    #Socket Length
	    length_socket_2 = braid_engine.interface.new_socket(name = "Length", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    length_socket_2.default_value = 0.5
	    length_socket_2.min_value = 9.999999747378752e-05
	    length_socket_2.max_value = 10000.0
	    length_socket_2.subtype = 'NONE'
	    length_socket_2.attribute_domain = 'POINT'
	    length_socket_2.description = "Curve Guide Length."
	
	    #Socket Frequency
	    frequency_socket_1 = braid_engine.interface.new_socket(name = "Frequency", in_out='INPUT', socket_type = 'NodeSocketInt')
	    frequency_socket_1.default_value = 1
	    frequency_socket_1.min_value = 1
	    frequency_socket_1.max_value = 10000
	    frequency_socket_1.subtype = 'NONE'
	    frequency_socket_1.attribute_domain = 'POINT'
	    frequency_socket_1.description = "Amount of braid twists."
	
	    #Socket Scale
	    scale_socket_1 = braid_engine.interface.new_socket(name = "Scale", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    scale_socket_1.default_value = 0.0
	    scale_socket_1.min_value = 9.999999747378752e-05
	    scale_socket_1.max_value = 10000.0
	    scale_socket_1.subtype = 'NONE'
	    scale_socket_1.attribute_domain = 'POINT'
	    scale_socket_1.description = "Braid scale."
	
	    #Socket Extend Root
	    extend_root_socket = braid_engine.interface.new_socket(name = "Extend Root", in_out='INPUT', socket_type = 'NodeSocketBool')
	    extend_root_socket.default_value = True
	    extend_root_socket.attribute_domain = 'POINT'
	    extend_root_socket.description = "Extend hair roots."
	
	
	    #initialize braid_engine nodes
	    #node Group Output
	    group_output_5 = braid_engine.nodes.new("NodeGroupOutput")
	    group_output_5.name = "Group Output"
	    group_output_5.is_active_output = True
	    group_output_5.inputs[3].hide = True
	
	    #node Group Input
	    group_input_2 = braid_engine.nodes.new("NodeGroupInput")
	    group_input_2.name = "Group Input"
	    group_input_2.outputs[3].hide = True
	    group_input_2.outputs[4].hide = True
	
	    #node Braid Loop
	    braid_loop_1 = braid_engine.nodes.new("GeometryNodeGroup")
	    braid_loop_1.label = "Braid Loop"
	    braid_loop_1.name = "Braid Loop"
	    braid_loop_1.hide = True
	    braid_loop_1.node_tree = braid_loop
	    braid_loop_1.inputs[3].hide = True
	    #Socket_4
	    braid_loop_1.inputs[3].default_value = 0.0
	
	    #node Math
	    math_1 = braid_engine.nodes.new("ShaderNodeMath")
	    math_1.name = "Math"
	    math_1.hide = True
	    math_1.operation = 'RADIANS'
	    math_1.use_clamp = False
	    #Value
	    math_1.inputs[0].default_value = 180.0
	
	    #node Math.001
	    math_001_1 = braid_engine.nodes.new("ShaderNodeMath")
	    math_001_1.name = "Math.001"
	    math_001_1.hide = True
	    math_001_1.operation = 'DIVIDE'
	    math_001_1.use_clamp = False
	    #Value_001
	    math_001_1.inputs[1].default_value = 3.0
	
	    #node Math.002
	    math_002 = braid_engine.nodes.new("ShaderNodeMath")
	    math_002.name = "Math.002"
	    math_002.hide = True
	    math_002.operation = 'MULTIPLY'
	    math_002.use_clamp = False
	
	    #node Math.003
	    math_003_1 = braid_engine.nodes.new("ShaderNodeMath")
	    math_003_1.name = "Math.003"
	    math_003_1.hide = True
	    math_003_1.operation = 'MULTIPLY'
	    math_003_1.use_clamp = False
	    #Value_001
	    math_003_1.inputs[1].default_value = 2.0
	
	    #node Math.004
	    math_004_1 = braid_engine.nodes.new("ShaderNodeMath")
	    math_004_1.name = "Math.004"
	    math_004_1.hide = True
	    math_004_1.operation = 'DIVIDE'
	    math_004_1.use_clamp = False
	    #Value_001
	    math_004_1.inputs[1].default_value = 6.0
	
	    #node Math.005
	    math_005_1 = braid_engine.nodes.new("ShaderNodeMath")
	    math_005_1.name = "Math.005"
	    math_005_1.hide = True
	    math_005_1.operation = 'MULTIPLY'
	    math_005_1.use_clamp = False
	
	    #node Math.006
	    math_006_1 = braid_engine.nodes.new("ShaderNodeMath")
	    math_006_1.name = "Math.006"
	    math_006_1.hide = True
	    math_006_1.operation = 'RADIANS'
	    math_006_1.use_clamp = False
	    #Value
	    math_006_1.inputs[0].default_value = 360.0
	
	    #node Math.007
	    math_007_1 = braid_engine.nodes.new("ShaderNodeMath")
	    math_007_1.name = "Math.007"
	    math_007_1.hide = True
	    math_007_1.operation = 'DIVIDE'
	    math_007_1.use_clamp = False
	
	    #node Math.008
	    math_008 = braid_engine.nodes.new("ShaderNodeMath")
	    math_008.name = "Math.008"
	    math_008.hide = True
	    math_008.operation = 'DIVIDE'
	    math_008.use_clamp = False
	
	    #node Set Position
	    set_position_1 = braid_engine.nodes.new("GeometryNodeSetPosition")
	    set_position_1.name = "Set Position"
	    set_position_1.hide = True
	    set_position_1.inputs[1].hide = True
	    set_position_1.inputs[2].hide = True
	    #Selection
	    set_position_1.inputs[1].default_value = True
	    #Position
	    set_position_1.inputs[2].default_value = (0.0, 0.0, 0.0)
	
	    #node Combine XYZ
	    combine_xyz_2 = braid_engine.nodes.new("ShaderNodeCombineXYZ")
	    combine_xyz_2.name = "Combine XYZ"
	    combine_xyz_2.hide = True
	    combine_xyz_2.inputs[1].hide = True
	    combine_xyz_2.inputs[2].hide = True
	    #Y
	    combine_xyz_2.inputs[1].default_value = 0.0
	    #Z
	    combine_xyz_2.inputs[2].default_value = 0.0
	
	    #node Set Position.001
	    set_position_001_1 = braid_engine.nodes.new("GeometryNodeSetPosition")
	    set_position_001_1.name = "Set Position.001"
	    set_position_001_1.hide = True
	    set_position_001_1.inputs[1].hide = True
	    set_position_001_1.inputs[2].hide = True
	    #Selection
	    set_position_001_1.inputs[1].default_value = True
	    #Position
	    set_position_001_1.inputs[2].default_value = (0.0, 0.0, 0.0)
	
	    #node Combine XYZ.001
	    combine_xyz_001_1 = braid_engine.nodes.new("ShaderNodeCombineXYZ")
	    combine_xyz_001_1.name = "Combine XYZ.001"
	    combine_xyz_001_1.hide = True
	    combine_xyz_001_1.inputs[1].hide = True
	    combine_xyz_001_1.inputs[2].hide = True
	    #Y
	    combine_xyz_001_1.inputs[1].default_value = 0.0
	    #Z
	    combine_xyz_001_1.inputs[2].default_value = 0.0
	
	    #node Transform Geometry
	    transform_geometry_1 = braid_engine.nodes.new("GeometryNodeTransform")
	    transform_geometry_1.name = "Transform Geometry"
	    transform_geometry_1.hide = True
	    transform_geometry_1.mode = 'COMPONENTS'
	    transform_geometry_1.inputs[1].hide = True
	    transform_geometry_1.inputs[2].hide = True
	    transform_geometry_1.inputs[3].hide = True
	    transform_geometry_1.inputs[4].hide = True
	    #Translation
	    transform_geometry_1.inputs[1].default_value = (0.0, 0.0, 0.0)
	    #Rotation
	    transform_geometry_1.inputs[2].default_value = (0.0, 0.0, 0.0)
	    #Scale
	    transform_geometry_1.inputs[3].default_value = (1.0, -1.0, 1.0)
	
	    #node Join Geometry
	    join_geometry_1 = braid_engine.nodes.new("GeometryNodeJoinGeometry")
	    join_geometry_1.name = "Join Geometry"
	    join_geometry_1.hide = True
	
	    #node Join Geometry.001
	    join_geometry_001_1 = braid_engine.nodes.new("GeometryNodeJoinGeometry")
	    join_geometry_001_1.name = "Join Geometry.001"
	    join_geometry_001_1.hide = True
	
	    #node Join Geometry.002
	    join_geometry_002 = braid_engine.nodes.new("GeometryNodeJoinGeometry")
	    join_geometry_002.name = "Join Geometry.002"
	    join_geometry_002.hide = True
	
	    #node Frame.002
	    frame_002_1 = braid_engine.nodes.new("NodeFrame")
	    frame_002_1.name = "Frame.002"
	    frame_002_1.label_size = 20
	    frame_002_1.shrink = True
	
	    #node Frame.003
	    frame_003_1 = braid_engine.nodes.new("NodeFrame")
	    frame_003_1.name = "Frame.003"
	    frame_003_1.label_size = 20
	    frame_003_1.shrink = True
	
	    #node Group Input.001
	    group_input_001_1 = braid_engine.nodes.new("NodeGroupInput")
	    group_input_001_1.name = "Group Input.001"
	    group_input_001_1.outputs[2].hide = True
	    group_input_001_1.outputs[3].hide = True
	    group_input_001_1.outputs[4].hide = True
	
	    #node Reroute
	    reroute_1 = braid_engine.nodes.new("NodeReroute")
	    reroute_1.name = "Reroute"
	    reroute_1.socket_idname = "NodeSocketFloat"
	    #node Reroute.001
	    reroute_001_1 = braid_engine.nodes.new("NodeReroute")
	    reroute_001_1.name = "Reroute.001"
	    reroute_001_1.socket_idname = "NodeSocketFloat"
	    #node Compare
	    compare = braid_engine.nodes.new("FunctionNodeCompare")
	    compare.name = "Compare"
	    compare.hide = True
	    compare.data_type = 'FLOAT'
	    compare.mode = 'ELEMENT'
	    compare.operation = 'GREATER_THAN'
	
	    #node Position
	    position = braid_engine.nodes.new("GeometryNodeInputPosition")
	    position.name = "Position"
	
	    #node Separate XYZ.001
	    separate_xyz_001_1 = braid_engine.nodes.new("ShaderNodeSeparateXYZ")
	    separate_xyz_001_1.name = "Separate XYZ.001"
	    separate_xyz_001_1.hide = True
	    separate_xyz_001_1.outputs[1].hide = True
	    separate_xyz_001_1.outputs[2].hide = True
	
	    #node Curve to Mesh
	    curve_to_mesh = braid_engine.nodes.new("GeometryNodeCurveToMesh")
	    curve_to_mesh.name = "Curve to Mesh"
	    curve_to_mesh.hide = True
	    curve_to_mesh.inputs[1].hide = True
	    curve_to_mesh.inputs[2].hide = True
	    #Fill Caps
	    curve_to_mesh.inputs[2].default_value = False
	
	    #node Delete Geometry.001
	    delete_geometry_001 = braid_engine.nodes.new("GeometryNodeDeleteGeometry")
	    delete_geometry_001.name = "Delete Geometry.001"
	    delete_geometry_001.hide = True
	    delete_geometry_001.domain = 'POINT'
	    delete_geometry_001.mode = 'ALL'
	
	    #node Mesh to Curve
	    mesh_to_curve = braid_engine.nodes.new("GeometryNodeMeshToCurve")
	    mesh_to_curve.name = "Mesh to Curve"
	    mesh_to_curve.hide = True
	    mesh_to_curve.inputs[1].hide = True
	    #Selection
	    mesh_to_curve.inputs[1].default_value = True
	
	    #node Reroute.002
	    reroute_002_1 = braid_engine.nodes.new("NodeReroute")
	    reroute_002_1.name = "Reroute.002"
	    reroute_002_1.socket_idname = "NodeSocketGeometry"
	    #node Compare.002
	    compare_002 = braid_engine.nodes.new("FunctionNodeCompare")
	    compare_002.name = "Compare.002"
	    compare_002.hide = True
	    compare_002.data_type = 'FLOAT'
	    compare_002.mode = 'ELEMENT'
	    compare_002.operation = 'GREATER_THAN'
	
	    #node Position.001
	    position_001 = braid_engine.nodes.new("GeometryNodeInputPosition")
	    position_001.name = "Position.001"
	
	    #node Separate XYZ.003
	    separate_xyz_003 = braid_engine.nodes.new("ShaderNodeSeparateXYZ")
	    separate_xyz_003.name = "Separate XYZ.003"
	    separate_xyz_003.hide = True
	    separate_xyz_003.outputs[1].hide = True
	    separate_xyz_003.outputs[2].hide = True
	
	    #node Curve to Mesh.001
	    curve_to_mesh_001 = braid_engine.nodes.new("GeometryNodeCurveToMesh")
	    curve_to_mesh_001.name = "Curve to Mesh.001"
	    curve_to_mesh_001.hide = True
	    curve_to_mesh_001.inputs[1].hide = True
	    curve_to_mesh_001.inputs[2].hide = True
	    #Fill Caps
	    curve_to_mesh_001.inputs[2].default_value = False
	
	    #node Delete Geometry.002
	    delete_geometry_002 = braid_engine.nodes.new("GeometryNodeDeleteGeometry")
	    delete_geometry_002.name = "Delete Geometry.002"
	    delete_geometry_002.hide = True
	    delete_geometry_002.domain = 'POINT'
	    delete_geometry_002.mode = 'ALL'
	
	    #node Mesh to Curve.001
	    mesh_to_curve_001 = braid_engine.nodes.new("GeometryNodeMeshToCurve")
	    mesh_to_curve_001.name = "Mesh to Curve.001"
	    mesh_to_curve_001.hide = True
	    mesh_to_curve_001.inputs[1].hide = True
	    #Selection
	    mesh_to_curve_001.inputs[1].default_value = True
	
	    #node Transform Geometry.002
	    transform_geometry_002 = braid_engine.nodes.new("GeometryNodeTransform")
	    transform_geometry_002.name = "Transform Geometry.002"
	    transform_geometry_002.hide = True
	    transform_geometry_002.mode = 'COMPONENTS'
	    transform_geometry_002.inputs[2].hide = True
	    transform_geometry_002.inputs[3].hide = True
	    transform_geometry_002.inputs[4].hide = True
	    #Rotation
	    transform_geometry_002.inputs[2].default_value = (0.0, 0.0, 3.1415927410125732)
	    #Scale
	    transform_geometry_002.inputs[3].default_value = (1.0, -1.0, -1.0)
	
	    #node Transform Geometry.003
	    transform_geometry_003 = braid_engine.nodes.new("GeometryNodeTransform")
	    transform_geometry_003.name = "Transform Geometry.003"
	    transform_geometry_003.hide = True
	    transform_geometry_003.mode = 'COMPONENTS'
	    transform_geometry_003.inputs[2].hide = True
	    transform_geometry_003.inputs[3].hide = True
	    transform_geometry_003.inputs[4].hide = True
	    #Rotation
	    transform_geometry_003.inputs[2].default_value = (0.0, 0.0, 3.1415927410125732)
	    #Scale
	    transform_geometry_003.inputs[3].default_value = (1.0, 1.0, -1.0)
	
	    #node Reverse Curve
	    reverse_curve = braid_engine.nodes.new("GeometryNodeReverseCurve")
	    reverse_curve.name = "Reverse Curve"
	    reverse_curve.hide = True
	    reverse_curve.inputs[1].hide = True
	    #Selection
	    reverse_curve.inputs[1].default_value = True
	
	    #node Reverse Curve.001
	    reverse_curve_001 = braid_engine.nodes.new("GeometryNodeReverseCurve")
	    reverse_curve_001.name = "Reverse Curve.001"
	    reverse_curve_001.hide = True
	    reverse_curve_001.inputs[1].hide = True
	    #Selection
	    reverse_curve_001.inputs[1].default_value = True
	
	    #node Reroute.003
	    reroute_003_1 = braid_engine.nodes.new("NodeReroute")
	    reroute_003_1.name = "Reroute.003"
	    reroute_003_1.socket_idname = "NodeSocketGeometry"
	    #node Switch
	    switch_1 = braid_engine.nodes.new("GeometryNodeSwitch")
	    switch_1.name = "Switch"
	    switch_1.hide = True
	    switch_1.input_type = 'GEOMETRY'
	
	    #node Group Input.002
	    group_input_002_1 = braid_engine.nodes.new("NodeGroupInput")
	    group_input_002_1.name = "Group Input.002"
	    group_input_002_1.outputs[0].hide = True
	    group_input_002_1.outputs[1].hide = True
	    group_input_002_1.outputs[2].hide = True
	    group_input_002_1.outputs[4].hide = True
	
	    #node Switch.001
	    switch_001_1 = braid_engine.nodes.new("GeometryNodeSwitch")
	    switch_001_1.name = "Switch.001"
	    switch_001_1.hide = True
	    switch_001_1.input_type = 'GEOMETRY'
	
	
	
	
	    #Set parents
	    math_1.parent = frame_003_1
	    math_001_1.parent = frame_003_1
	    math_002.parent = frame_003_1
	    math_003_1.parent = frame_002_1
	    math_004_1.parent = frame_003_1
	    math_005_1.parent = frame_002_1
	    math_006_1.parent = frame_002_1
	    math_007_1.parent = frame_002_1
	    math_008.parent = frame_002_1
	    group_input_001_1.parent = frame_002_1
	
	    #Set locations
	    group_output_5.location = (504.38592529296875, -80.60475158691406)
	    group_input_2.location = (-1238.9970703125, -34.95726776123047)
	    braid_loop_1.location = (-657.676025390625, -80.4629135131836)
	    math_1.location = (29.6240234375, -68.38217163085938)
	    math_001_1.location = (238.9371337890625, -35.29443359375)
	    math_002.location = (411.62738037109375, -41.186187744140625)
	    math_003_1.location = (233.0909423828125, -43.19122314453125)
	    math_004_1.location = (235.0401611328125, -81.30215454101562)
	    math_005_1.location = (401.0029296875, -35.473724365234375)
	    math_006_1.location = (37.565185546875, -118.76513671875)
	    math_007_1.location = (234.76904296875, -113.80584716796875)
	    math_008.location = (235.1378173828125, -78.14889526367188)
	    set_position_1.location = (72.96780395507812, -125.54069519042969)
	    combine_xyz_2.location = (-669.5271606445312, -236.16004943847656)
	    set_position_001_1.location = (66.2459716796875, -264.74041748046875)
	    combine_xyz_001_1.location = (-668.5697021484375, -377.8883361816406)
	    transform_geometry_1.location = (69.63076782226562, -226.95346069335938)
	    join_geometry_1.location = (330.21295166015625, -74.31793212890625)
	    join_geometry_001_1.location = (325.1912841796875, -315.5576477050781)
	    join_geometry_002.location = (317.8753662109375, -206.20240783691406)
	    frame_002_1.location = (-1269.0, -343.0)
	    frame_003_1.location = (-1272.0, -196.0)
	    group_input_001_1.location = (30.0029296875, -29.63861083984375)
	    reroute_1.location = (-722.8416748046875, -1036.0657958984375)
	    reroute_001_1.location = (-675.8378295898438, -602.8939819335938)
	    compare.location = (-385.27288818359375, -594.35595703125)
	    position.location = (-388.24334716796875, -668.4110107421875)
	    separate_xyz_001_1.location = (-389.18084716796875, -634.5350952148438)
	    curve_to_mesh.location = (-385.16064453125, -457.1847229003906)
	    delete_geometry_001.location = (-386.508056640625, -558.6692504882812)
	    mesh_to_curve.location = (-386.43096923828125, -511.587890625)
	    reroute_002_1.location = (-511.0681457519531, -890.076416015625)
	    compare_002.location = (-385.2723388671875, -1019.016845703125)
	    position_001.location = (-388.2427978515625, -1093.0718994140625)
	    separate_xyz_003.location = (-389.1802978515625, -1059.1959228515625)
	    curve_to_mesh_001.location = (-385.16009521484375, -881.8455810546875)
	    delete_geometry_002.location = (-386.50750732421875, -983.330078125)
	    mesh_to_curve_001.location = (-386.430419921875, -936.248779296875)
	    transform_geometry_002.location = (66.59149169921875, -371.182373046875)
	    transform_geometry_003.location = (65.98056030273438, -309.28302001953125)
	    reverse_curve.location = (-201.1391143798828, -427.042236328125)
	    reverse_curve_001.location = (-174.97718811035156, -573.8084716796875)
	    reroute_003_1.location = (-513.5703735351562, -469.245849609375)
	    switch_1.location = (319.1125183105469, -171.26058959960938)
	    group_input_002_1.location = (65.95100402832031, -154.4392547607422)
	    switch_001_1.location = (323.42877197265625, -279.22625732421875)
	
	    #Set dimensions
	    group_output_5.width, group_output_5.height = 140.0, 100.0
	    group_input_2.width, group_input_2.height = 140.0, 100.0
	    braid_loop_1.width, braid_loop_1.height = 140.0, 100.0
	    math_1.width, math_1.height = 140.0, 100.0
	    math_001_1.width, math_001_1.height = 140.0, 100.0
	    math_002.width, math_002.height = 140.0, 100.0
	    math_003_1.width, math_003_1.height = 140.0, 100.0
	    math_004_1.width, math_004_1.height = 140.0, 100.0
	    math_005_1.width, math_005_1.height = 140.0, 100.0
	    math_006_1.width, math_006_1.height = 140.0, 100.0
	    math_007_1.width, math_007_1.height = 140.0, 100.0
	    math_008.width, math_008.height = 140.0, 100.0
	    set_position_1.width, set_position_1.height = 140.0, 100.0
	    combine_xyz_2.width, combine_xyz_2.height = 140.0, 100.0
	    set_position_001_1.width, set_position_001_1.height = 140.0, 100.0
	    combine_xyz_001_1.width, combine_xyz_001_1.height = 140.0, 100.0
	    transform_geometry_1.width, transform_geometry_1.height = 140.0, 100.0
	    join_geometry_1.width, join_geometry_1.height = 140.0, 100.0
	    join_geometry_001_1.width, join_geometry_001_1.height = 140.0, 100.0
	    join_geometry_002.width, join_geometry_002.height = 140.0, 100.0
	    frame_002_1.width, frame_002_1.height = 571.0, 174.0
	    frame_003_1.width, frame_003_1.height = 582.0, 136.0
	    group_input_001_1.width, group_input_001_1.height = 140.0, 100.0
	    reroute_1.width, reroute_1.height = 100.0, 100.0
	    reroute_001_1.width, reroute_001_1.height = 100.0, 100.0
	    compare.width, compare.height = 140.0, 100.0
	    position.width, position.height = 140.0, 100.0
	    separate_xyz_001_1.width, separate_xyz_001_1.height = 140.0, 100.0
	    curve_to_mesh.width, curve_to_mesh.height = 140.0, 100.0
	    delete_geometry_001.width, delete_geometry_001.height = 140.0, 100.0
	    mesh_to_curve.width, mesh_to_curve.height = 140.0, 100.0
	    reroute_002_1.width, reroute_002_1.height = 100.0, 100.0
	    compare_002.width, compare_002.height = 140.0, 100.0
	    position_001.width, position_001.height = 140.0, 100.0
	    separate_xyz_003.width, separate_xyz_003.height = 140.0, 100.0
	    curve_to_mesh_001.width, curve_to_mesh_001.height = 140.0, 100.0
	    delete_geometry_002.width, delete_geometry_002.height = 140.0, 100.0
	    mesh_to_curve_001.width, mesh_to_curve_001.height = 140.0, 100.0
	    transform_geometry_002.width, transform_geometry_002.height = 140.0, 100.0
	    transform_geometry_003.width, transform_geometry_003.height = 140.0, 100.0
	    reverse_curve.width, reverse_curve.height = 140.0, 100.0
	    reverse_curve_001.width, reverse_curve_001.height = 140.0, 100.0
	    reroute_003_1.width, reroute_003_1.height = 100.0, 100.0
	    switch_1.width, switch_1.height = 140.0, 100.0
	    group_input_002_1.width, group_input_002_1.height = 140.0, 100.0
	    switch_001_1.width, switch_001_1.height = 140.0, 100.0
	
	    #initialize braid_engine links
	    #group_input_2.Frequency -> braid_loop_1.Frequency
	    braid_engine.links.new(group_input_2.outputs[1], braid_loop_1.inputs[1])
	    #group_input_2.Scale -> braid_loop_1.Scale
	    braid_engine.links.new(group_input_2.outputs[2], braid_loop_1.inputs[2])
	    #group_input_2.Length -> braid_loop_1.Length
	    braid_engine.links.new(group_input_2.outputs[0], braid_loop_1.inputs[0])
	    #math_1.Value -> math_001_1.Value
	    braid_engine.links.new(math_1.outputs[0], math_001_1.inputs[0])
	    #math_001_1.Value -> math_002.Value
	    braid_engine.links.new(math_001_1.outputs[0], math_002.inputs[0])
	    #math_003_1.Value -> math_002.Value
	    braid_engine.links.new(math_003_1.outputs[0], math_002.inputs[1])
	    #math_004_1.Value -> math_005_1.Value
	    braid_engine.links.new(math_004_1.outputs[0], math_005_1.inputs[0])
	    #math_003_1.Value -> math_005_1.Value
	    braid_engine.links.new(math_003_1.outputs[0], math_005_1.inputs[1])
	    #math_1.Value -> math_004_1.Value
	    braid_engine.links.new(math_1.outputs[0], math_004_1.inputs[0])
	    #math_006_1.Value -> math_007_1.Value
	    braid_engine.links.new(math_006_1.outputs[0], math_007_1.inputs[1])
	    #math_008.Value -> math_003_1.Value
	    braid_engine.links.new(math_008.outputs[0], math_003_1.inputs[0])
	    #math_007_1.Value -> math_008.Value
	    braid_engine.links.new(math_007_1.outputs[0], math_008.inputs[0])
	    #braid_loop_1.Geometry -> set_position_1.Geometry
	    braid_engine.links.new(braid_loop_1.outputs[0], set_position_1.inputs[0])
	    #combine_xyz_2.Vector -> set_position_1.Offset
	    braid_engine.links.new(combine_xyz_2.outputs[0], set_position_1.inputs[3])
	    #math_002.Value -> combine_xyz_2.X
	    braid_engine.links.new(math_002.outputs[0], combine_xyz_2.inputs[0])
	    #braid_loop_1.Geometry -> set_position_001_1.Geometry
	    braid_engine.links.new(braid_loop_1.outputs[0], set_position_001_1.inputs[0])
	    #combine_xyz_001_1.Vector -> set_position_001_1.Offset
	    braid_engine.links.new(combine_xyz_001_1.outputs[0], set_position_001_1.inputs[3])
	    #math_005_1.Value -> combine_xyz_001_1.X
	    braid_engine.links.new(math_005_1.outputs[0], combine_xyz_001_1.inputs[0])
	    #set_position_001_1.Geometry -> transform_geometry_1.Geometry
	    braid_engine.links.new(set_position_001_1.outputs[0], transform_geometry_1.inputs[0])
	    #braid_loop_1.Geometry -> join_geometry_1.Geometry
	    braid_engine.links.new(braid_loop_1.outputs[0], join_geometry_1.inputs[0])
	    #set_position_1.Geometry -> join_geometry_002.Geometry
	    braid_engine.links.new(set_position_1.outputs[0], join_geometry_002.inputs[0])
	    #group_input_001_1.Frequency -> math_008.Value
	    braid_engine.links.new(group_input_001_1.outputs[1], math_008.inputs[1])
	    #group_input_001_1.Length -> math_007_1.Value
	    braid_engine.links.new(group_input_001_1.outputs[0], math_007_1.inputs[0])
	    #math_005_1.Value -> reroute_1.Input
	    braid_engine.links.new(math_005_1.outputs[0], reroute_1.inputs[0])
	    #math_002.Value -> reroute_001_1.Input
	    braid_engine.links.new(math_002.outputs[0], reroute_001_1.inputs[0])
	    #transform_geometry_1.Geometry -> join_geometry_001_1.Geometry
	    braid_engine.links.new(transform_geometry_1.outputs[0], join_geometry_001_1.inputs[0])
	    #compare.Result -> delete_geometry_001.Selection
	    braid_engine.links.new(compare.outputs[0], delete_geometry_001.inputs[1])
	    #curve_to_mesh.Mesh -> mesh_to_curve.Mesh
	    braid_engine.links.new(curve_to_mesh.outputs[0], mesh_to_curve.inputs[0])
	    #mesh_to_curve.Curve -> delete_geometry_001.Geometry
	    braid_engine.links.new(mesh_to_curve.outputs[0], delete_geometry_001.inputs[0])
	    #position.Position -> separate_xyz_001_1.Vector
	    braid_engine.links.new(position.outputs[0], separate_xyz_001_1.inputs[0])
	    #separate_xyz_001_1.X -> compare.A
	    braid_engine.links.new(separate_xyz_001_1.outputs[0], compare.inputs[0])
	    #reroute_001_1.Output -> compare.B
	    braid_engine.links.new(reroute_001_1.outputs[0], compare.inputs[1])
	    #reroute_003_1.Output -> reroute_002_1.Input
	    braid_engine.links.new(reroute_003_1.outputs[0], reroute_002_1.inputs[0])
	    #compare_002.Result -> delete_geometry_002.Selection
	    braid_engine.links.new(compare_002.outputs[0], delete_geometry_002.inputs[1])
	    #curve_to_mesh_001.Mesh -> mesh_to_curve_001.Mesh
	    braid_engine.links.new(curve_to_mesh_001.outputs[0], mesh_to_curve_001.inputs[0])
	    #mesh_to_curve_001.Curve -> delete_geometry_002.Geometry
	    braid_engine.links.new(mesh_to_curve_001.outputs[0], delete_geometry_002.inputs[0])
	    #position_001.Position -> separate_xyz_003.Vector
	    braid_engine.links.new(position_001.outputs[0], separate_xyz_003.inputs[0])
	    #separate_xyz_003.X -> compare_002.A
	    braid_engine.links.new(separate_xyz_003.outputs[0], compare_002.inputs[0])
	    #reroute_002_1.Output -> curve_to_mesh_001.Curve
	    braid_engine.links.new(reroute_002_1.outputs[0], curve_to_mesh_001.inputs[0])
	    #reroute_1.Output -> compare_002.B
	    braid_engine.links.new(reroute_1.outputs[0], compare_002.inputs[1])
	    #reverse_curve_001.Curve -> transform_geometry_002.Geometry
	    braid_engine.links.new(reverse_curve_001.outputs[0], transform_geometry_002.inputs[0])
	    #combine_xyz_001_1.Vector -> transform_geometry_002.Translation
	    braid_engine.links.new(combine_xyz_001_1.outputs[0], transform_geometry_002.inputs[1])
	    #reverse_curve.Curve -> transform_geometry_003.Geometry
	    braid_engine.links.new(reverse_curve.outputs[0], transform_geometry_003.inputs[0])
	    #combine_xyz_2.Vector -> transform_geometry_003.Translation
	    braid_engine.links.new(combine_xyz_2.outputs[0], transform_geometry_003.inputs[1])
	    #join_geometry_1.Geometry -> group_output_5.Braid 1
	    braid_engine.links.new(join_geometry_1.outputs[0], group_output_5.inputs[0])
	    #delete_geometry_001.Geometry -> reverse_curve.Curve
	    braid_engine.links.new(delete_geometry_001.outputs[0], reverse_curve.inputs[0])
	    #delete_geometry_002.Geometry -> reverse_curve_001.Curve
	    braid_engine.links.new(delete_geometry_002.outputs[0], reverse_curve_001.inputs[0])
	    #braid_loop_1.Geometry -> reroute_003_1.Input
	    braid_engine.links.new(braid_loop_1.outputs[0], reroute_003_1.inputs[0])
	    #reroute_003_1.Output -> curve_to_mesh.Curve
	    braid_engine.links.new(reroute_003_1.outputs[0], curve_to_mesh.inputs[0])
	    #group_input_002_1.Extend Root -> switch_1.Switch
	    braid_engine.links.new(group_input_002_1.outputs[3], switch_1.inputs[0])
	    #join_geometry_002.Geometry -> switch_1.True
	    braid_engine.links.new(join_geometry_002.outputs[0], switch_1.inputs[2])
	    #set_position_1.Geometry -> switch_1.False
	    braid_engine.links.new(set_position_1.outputs[0], switch_1.inputs[1])
	    #switch_1.Output -> group_output_5.Braid 2
	    braid_engine.links.new(switch_1.outputs[0], group_output_5.inputs[1])
	    #join_geometry_001_1.Geometry -> switch_001_1.True
	    braid_engine.links.new(join_geometry_001_1.outputs[0], switch_001_1.inputs[2])
	    #transform_geometry_1.Geometry -> switch_001_1.False
	    braid_engine.links.new(transform_geometry_1.outputs[0], switch_001_1.inputs[1])
	    #switch_001_1.Output -> group_output_5.Braid 3
	    braid_engine.links.new(switch_001_1.outputs[0], group_output_5.inputs[2])
	    #group_input_002_1.Extend Root -> switch_001_1.Switch
	    braid_engine.links.new(group_input_002_1.outputs[3], switch_001_1.inputs[0])
	    #transform_geometry_002.Geometry -> join_geometry_001_1.Geometry
	    braid_engine.links.new(transform_geometry_002.outputs[0], join_geometry_001_1.inputs[0])
	    #transform_geometry_003.Geometry -> join_geometry_002.Geometry
	    braid_engine.links.new(transform_geometry_003.outputs[0], join_geometry_002.inputs[0])
	    return braid_engine
	
	braid_engine = braid_engine_node_group()
	
	#initialize curve_deform_group node group
	def curve_deform_group_node_group():
	    curve_deform_group = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Curve Deform Group")
	
	    curve_deform_group.color_tag = 'NONE'
	    curve_deform_group.description = "Curve deform target object."
	    curve_deform_group.default_group_node_width = 140
	    
	
	
	    #curve_deform_group interface
	    #Socket Vector
	    vector_socket = curve_deform_group.interface.new_socket(name = "Vector", in_out='OUTPUT', socket_type = 'NodeSocketVector')
	    vector_socket.default_value = (0.0, 0.0, 0.0)
	    vector_socket.min_value = -3.4028234663852886e+38
	    vector_socket.max_value = 3.4028234663852886e+38
	    vector_socket.subtype = 'NONE'
	    vector_socket.attribute_domain = 'POINT'
	    vector_socket.description = "Point deformation data."
	
	    #Socket Curves
	    curves_socket = curve_deform_group.interface.new_socket(name = "Curves", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    curves_socket.attribute_domain = 'POINT'
	    curves_socket.description = "Curve Guide."
	
	    #Socket Axis X | Y | Z
	    axis_x___y___z_socket = curve_deform_group.interface.new_socket(name = "Axis X | Y | Z", in_out='INPUT', socket_type = 'NodeSocketInt')
	    axis_x___y___z_socket.default_value = 0
	    axis_x___y___z_socket.min_value = 0
	    axis_x___y___z_socket.max_value = 2
	    axis_x___y___z_socket.subtype = 'FACTOR'
	    axis_x___y___z_socket.attribute_domain = 'POINT'
	    axis_x___y___z_socket.description = "Target Object Axis used to place along curve."
	
	    #Socket From Min
	    from_min_socket = curve_deform_group.interface.new_socket(name = "From Min", in_out='INPUT', socket_type = 'NodeSocketVector')
	    from_min_socket.default_value = (0.0, 0.0, 0.0)
	    from_min_socket.min_value = -3.4028234663852886e+38
	    from_min_socket.max_value = 3.4028234663852886e+38
	    from_min_socket.subtype = 'NONE'
	    from_min_socket.attribute_domain = 'POINT'
	    from_min_socket.hide_value = True
	    from_min_socket.hide_in_modifier = True
	    from_min_socket.description = "Target Object bounding box min."
	
	    #Socket From Max
	    from_max_socket = curve_deform_group.interface.new_socket(name = "From Max", in_out='INPUT', socket_type = 'NodeSocketVector')
	    from_max_socket.default_value = (1.0, 1.0, 1.0)
	    from_max_socket.min_value = -3.4028234663852886e+38
	    from_max_socket.max_value = 3.4028234663852886e+38
	    from_max_socket.subtype = 'NONE'
	    from_max_socket.attribute_domain = 'POINT'
	    from_max_socket.hide_value = True
	    from_max_socket.hide_in_modifier = True
	    from_max_socket.description = "Target Object bounding box max."
	
	    #Socket Group ID
	    group_id_socket = curve_deform_group.interface.new_socket(name = "Group ID", in_out='INPUT', socket_type = 'NodeSocketInt')
	    group_id_socket.default_value = 0
	    group_id_socket.min_value = -2147483648
	    group_id_socket.max_value = 2147483647
	    group_id_socket.subtype = 'NONE'
	    group_id_socket.attribute_domain = 'POINT'
	    group_id_socket.description = "ID for target object. (Such as index)"
	
	
	    #initialize curve_deform_group nodes
	    #node Group Output
	    group_output_6 = curve_deform_group.nodes.new("NodeGroupOutput")
	    group_output_6.name = "Group Output"
	    group_output_6.is_active_output = True
	
	    #node Group Input
	    group_input_3 = curve_deform_group.nodes.new("NodeGroupInput")
	    group_input_3.name = "Group Input"
	
	    #node Sample Curve
	    sample_curve = curve_deform_group.nodes.new("GeometryNodeSampleCurve")
	    sample_curve.name = "Sample Curve"
	    sample_curve.data_type = 'FLOAT'
	    sample_curve.mode = 'FACTOR'
	    sample_curve.use_all_curves = False
	
	    #node Map Range
	    map_range = curve_deform_group.nodes.new("ShaderNodeMapRange")
	    map_range.name = "Map Range"
	    map_range.clamp = True
	    map_range.data_type = 'FLOAT_VECTOR'
	    map_range.interpolation_type = 'LINEAR'
	    #To_Min_FLOAT3
	    map_range.inputs[9].default_value = (0.0, 0.0, 0.0)
	    #To_Max_FLOAT3
	    map_range.inputs[10].default_value = (1.0, 1.0, 1.0)
	
	    #node Position
	    position_1 = curve_deform_group.nodes.new("GeometryNodeInputPosition")
	    position_1.name = "Position"
	
	    #node Separate XYZ
	    separate_xyz_1 = curve_deform_group.nodes.new("ShaderNodeSeparateXYZ")
	    separate_xyz_1.name = "Separate XYZ"
	
	    #node Position.001
	    position_001_1 = curve_deform_group.nodes.new("GeometryNodeInputPosition")
	    position_001_1.name = "Position.001"
	
	    #node Separate XYZ.001
	    separate_xyz_001_2 = curve_deform_group.nodes.new("ShaderNodeSeparateXYZ")
	    separate_xyz_001_2.name = "Separate XYZ.001"
	
	    #node Vector Math
	    vector_math_2 = curve_deform_group.nodes.new("ShaderNodeVectorMath")
	    vector_math_2.name = "Vector Math"
	    vector_math_2.operation = 'SCALE'
	
	    #node Vector Math.001
	    vector_math_001_2 = curve_deform_group.nodes.new("ShaderNodeVectorMath")
	    vector_math_001_2.name = "Vector Math.001"
	    vector_math_001_2.operation = 'ADD'
	
	    #node Vector Math.002
	    vector_math_002_2 = curve_deform_group.nodes.new("ShaderNodeVectorMath")
	    vector_math_002_2.name = "Vector Math.002"
	    vector_math_002_2.operation = 'SCALE'
	
	    #node Vector Math.003
	    vector_math_003_2 = curve_deform_group.nodes.new("ShaderNodeVectorMath")
	    vector_math_003_2.name = "Vector Math.003"
	    vector_math_003_2.operation = 'CROSS_PRODUCT'
	
	    #node Vector Math.004
	    vector_math_004_2 = curve_deform_group.nodes.new("ShaderNodeVectorMath")
	    vector_math_004_2.name = "Vector Math.004"
	    vector_math_004_2.operation = 'ADD'
	
	    #node Vector Math.005
	    vector_math_005_2 = curve_deform_group.nodes.new("ShaderNodeVectorMath")
	    vector_math_005_2.name = "Vector Math.005"
	    vector_math_005_2.operation = 'SCALE'
	
	    #node Radius
	    radius = curve_deform_group.nodes.new("GeometryNodeInputRadius")
	    radius.name = "Radius"
	
	    #node Realize Instances
	    realize_instances_1 = curve_deform_group.nodes.new("GeometryNodeRealizeInstances")
	    realize_instances_1.name = "Realize Instances"
	    #Selection
	    realize_instances_1.inputs[1].default_value = True
	    #Realize All
	    realize_instances_1.inputs[2].default_value = True
	    #Depth
	    realize_instances_1.inputs[3].default_value = 0
	
	    #node Group Input.001
	    group_input_001_2 = curve_deform_group.nodes.new("NodeGroupInput")
	    group_input_001_2.name = "Group Input.001"
	
	    #node Switch
	    switch_2 = curve_deform_group.nodes.new("GeometryNodeSwitch")
	    switch_2.name = "Switch"
	    switch_2.input_type = 'FLOAT'
	
	    #node Switch.001
	    switch_001_2 = curve_deform_group.nodes.new("GeometryNodeSwitch")
	    switch_001_2.name = "Switch.001"
	    switch_001_2.input_type = 'FLOAT'
	
	    #node Compare
	    compare_1 = curve_deform_group.nodes.new("FunctionNodeCompare")
	    compare_1.name = "Compare"
	    compare_1.data_type = 'INT'
	    compare_1.mode = 'ELEMENT'
	    compare_1.operation = 'EQUAL'
	    #B_INT
	    compare_1.inputs[3].default_value = 1
	
	    #node Compare.001
	    compare_001 = curve_deform_group.nodes.new("FunctionNodeCompare")
	    compare_001.name = "Compare.001"
	    compare_001.data_type = 'INT'
	    compare_001.mode = 'ELEMENT'
	    compare_001.operation = 'EQUAL'
	    #B_INT
	    compare_001.inputs[3].default_value = 2
	
	    #node Group Input.002
	    group_input_002_2 = curve_deform_group.nodes.new("NodeGroupInput")
	    group_input_002_2.name = "Group Input.002"
	
	    #node Switch.002
	    switch_002 = curve_deform_group.nodes.new("GeometryNodeSwitch")
	    switch_002.name = "Switch.002"
	    switch_002.hide = True
	    switch_002.input_type = 'FLOAT'
	
	    #node Switch.003
	    switch_003 = curve_deform_group.nodes.new("GeometryNodeSwitch")
	    switch_003.name = "Switch.003"
	    switch_003.hide = True
	    switch_003.input_type = 'FLOAT'
	
	    #node Compare.002
	    compare_002_1 = curve_deform_group.nodes.new("FunctionNodeCompare")
	    compare_002_1.name = "Compare.002"
	    compare_002_1.data_type = 'INT'
	    compare_002_1.mode = 'ELEMENT'
	    compare_002_1.operation = 'EQUAL'
	    #B_INT
	    compare_002_1.inputs[3].default_value = 1
	
	    #node Compare.003
	    compare_003 = curve_deform_group.nodes.new("FunctionNodeCompare")
	    compare_003.name = "Compare.003"
	    compare_003.data_type = 'INT'
	    compare_003.mode = 'ELEMENT'
	    compare_003.operation = 'EQUAL'
	    #B_INT
	    compare_003.inputs[3].default_value = 2
	
	    #node Switch.004
	    switch_004 = curve_deform_group.nodes.new("GeometryNodeSwitch")
	    switch_004.name = "Switch.004"
	    switch_004.hide = True
	    switch_004.input_type = 'FLOAT'
	
	    #node Switch.005
	    switch_005 = curve_deform_group.nodes.new("GeometryNodeSwitch")
	    switch_005.name = "Switch.005"
	    switch_005.hide = True
	    switch_005.input_type = 'FLOAT'
	
	
	
	
	
	    #Set locations
	    group_output_6.location = (1339.0166015625, 235.3651885986328)
	    group_input_3.location = (-1429.0684814453125, 135.07945251464844)
	    sample_curve.location = (-191.83419799804688, 256.83599853515625)
	    map_range.location = (-1026.9373779296875, -85.57986450195312)
	    position_1.location = (-1369.4580078125, -177.0890655517578)
	    separate_xyz_1.location = (-847.6444091796875, -44.67005920410156)
	    position_001_1.location = (-478.6365966796875, -453.92779541015625)
	    separate_xyz_001_2.location = (-246.65237426757812, -311.75701904296875)
	    vector_math_2.location = (548.912353515625, 75.15472412109375)
	    vector_math_001_2.location = (739.1762084960938, -33.193817138671875)
	    vector_math_002_2.location = (558.2716674804688, -69.48199462890625)
	    vector_math_003_2.location = (330.2403869628906, -63.67213439941406)
	    vector_math_004_2.location = (1109.239501953125, 241.4366912841797)
	    vector_math_005_2.location = (945.3640747070312, 94.00572204589844)
	    radius.location = (-418.45941162109375, -89.7308120727539)
	    realize_instances_1.location = (-420.674072265625, 153.94482421875)
	    group_input_001_2.location = (-1247.6466064453125, -644.3953857421875)
	    switch_2.location = (-620.6170043945312, -173.04718017578125)
	    switch_001_2.location = (-439.1888427734375, -177.47601318359375)
	    compare_1.location = (-1025.511474609375, -485.2097473144531)
	    compare_001.location = (-1034.3939208984375, -653.5054321289062)
	    group_input_002_2.location = (-465.2469177246094, -601.8021240234375)
	    switch_002.location = (119.2609634399414, -278.110595703125)
	    switch_003.location = (292.1847839355469, -282.5394287109375)
	    compare_002_1.location = (-243.11178588867188, -442.616455078125)
	    compare_003.location = (-251.99423217773438, -610.9121704101562)
	    switch_004.location = (110.75662994384766, -329.2225341796875)
	    switch_005.location = (289.3500061035156, -327.97222900390625)
	
	    #Set dimensions
	    group_output_6.width, group_output_6.height = 140.0, 100.0
	    group_input_3.width, group_input_3.height = 140.0, 100.0
	    sample_curve.width, sample_curve.height = 140.0, 100.0
	    map_range.width, map_range.height = 140.0, 100.0
	    position_1.width, position_1.height = 140.0, 100.0
	    separate_xyz_1.width, separate_xyz_1.height = 140.0, 100.0
	    position_001_1.width, position_001_1.height = 140.0, 100.0
	    separate_xyz_001_2.width, separate_xyz_001_2.height = 140.0, 100.0
	    vector_math_2.width, vector_math_2.height = 140.0, 100.0
	    vector_math_001_2.width, vector_math_001_2.height = 140.0, 100.0
	    vector_math_002_2.width, vector_math_002_2.height = 140.0, 100.0
	    vector_math_003_2.width, vector_math_003_2.height = 140.0, 100.0
	    vector_math_004_2.width, vector_math_004_2.height = 140.0, 100.0
	    vector_math_005_2.width, vector_math_005_2.height = 140.0, 100.0
	    radius.width, radius.height = 140.0, 100.0
	    realize_instances_1.width, realize_instances_1.height = 140.0, 100.0
	    group_input_001_2.width, group_input_001_2.height = 140.0, 100.0
	    switch_2.width, switch_2.height = 140.0, 100.0
	    switch_001_2.width, switch_001_2.height = 140.0, 100.0
	    compare_1.width, compare_1.height = 140.0, 100.0
	    compare_001.width, compare_001.height = 140.0, 100.0
	    group_input_002_2.width, group_input_002_2.height = 140.0, 100.0
	    switch_002.width, switch_002.height = 140.0, 100.0
	    switch_003.width, switch_003.height = 140.0, 100.0
	    compare_002_1.width, compare_002_1.height = 140.0, 100.0
	    compare_003.width, compare_003.height = 140.0, 100.0
	    switch_004.width, switch_004.height = 140.0, 100.0
	    switch_005.width, switch_005.height = 140.0, 100.0
	
	    #initialize curve_deform_group links
	    #vector_math_003_2.Vector -> vector_math_002_2.Vector
	    curve_deform_group.links.new(vector_math_003_2.outputs[0], vector_math_002_2.inputs[0])
	    #position_001_1.Position -> separate_xyz_001_2.Vector
	    curve_deform_group.links.new(position_001_1.outputs[0], separate_xyz_001_2.inputs[0])
	    #vector_math_2.Vector -> vector_math_001_2.Vector
	    curve_deform_group.links.new(vector_math_2.outputs[0], vector_math_001_2.inputs[0])
	    #sample_curve.Normal -> vector_math_2.Vector
	    curve_deform_group.links.new(sample_curve.outputs[3], vector_math_2.inputs[0])
	    #sample_curve.Normal -> vector_math_003_2.Vector
	    curve_deform_group.links.new(sample_curve.outputs[3], vector_math_003_2.inputs[1])
	    #radius.Radius -> sample_curve.Value
	    curve_deform_group.links.new(radius.outputs[0], sample_curve.inputs[1])
	    #map_range.Vector -> separate_xyz_1.Vector
	    curve_deform_group.links.new(map_range.outputs[1], separate_xyz_1.inputs[0])
	    #position_1.Position -> map_range.Vector
	    curve_deform_group.links.new(position_1.outputs[0], map_range.inputs[6])
	    #vector_math_005_2.Vector -> vector_math_004_2.Vector
	    curve_deform_group.links.new(vector_math_005_2.outputs[0], vector_math_004_2.inputs[1])
	    #vector_math_002_2.Vector -> vector_math_001_2.Vector
	    curve_deform_group.links.new(vector_math_002_2.outputs[0], vector_math_001_2.inputs[1])
	    #sample_curve.Value -> vector_math_005_2.Scale
	    curve_deform_group.links.new(sample_curve.outputs[0], vector_math_005_2.inputs[3])
	    #sample_curve.Position -> vector_math_004_2.Vector
	    curve_deform_group.links.new(sample_curve.outputs[1], vector_math_004_2.inputs[0])
	    #sample_curve.Tangent -> vector_math_003_2.Vector
	    curve_deform_group.links.new(sample_curve.outputs[2], vector_math_003_2.inputs[0])
	    #vector_math_001_2.Vector -> vector_math_005_2.Vector
	    curve_deform_group.links.new(vector_math_001_2.outputs[0], vector_math_005_2.inputs[0])
	    #realize_instances_1.Geometry -> sample_curve.Curves
	    curve_deform_group.links.new(realize_instances_1.outputs[0], sample_curve.inputs[0])
	    #group_input_3.From Max -> map_range.From Max
	    curve_deform_group.links.new(group_input_3.outputs[3], map_range.inputs[8])
	    #group_input_3.From Min -> map_range.From Min
	    curve_deform_group.links.new(group_input_3.outputs[2], map_range.inputs[7])
	    #vector_math_004_2.Vector -> group_output_6.Vector
	    curve_deform_group.links.new(vector_math_004_2.outputs[0], group_output_6.inputs[0])
	    #group_input_3.Group ID -> sample_curve.Curve Index
	    curve_deform_group.links.new(group_input_3.outputs[4], sample_curve.inputs[4])
	    #group_input_3.Curves -> realize_instances_1.Geometry
	    curve_deform_group.links.new(group_input_3.outputs[0], realize_instances_1.inputs[0])
	    #separate_xyz_1.X -> switch_2.False
	    curve_deform_group.links.new(separate_xyz_1.outputs[0], switch_2.inputs[1])
	    #separate_xyz_1.Y -> switch_2.True
	    curve_deform_group.links.new(separate_xyz_1.outputs[1], switch_2.inputs[2])
	    #switch_2.Output -> switch_001_2.False
	    curve_deform_group.links.new(switch_2.outputs[0], switch_001_2.inputs[1])
	    #switch_001_2.Output -> sample_curve.Factor
	    curve_deform_group.links.new(switch_001_2.outputs[0], sample_curve.inputs[2])
	    #group_input_001_2.Axis X | Y | Z -> compare_1.A
	    curve_deform_group.links.new(group_input_001_2.outputs[1], compare_1.inputs[2])
	    #compare_1.Result -> switch_2.Switch
	    curve_deform_group.links.new(compare_1.outputs[0], switch_2.inputs[0])
	    #group_input_001_2.Axis X | Y | Z -> compare_001.A
	    curve_deform_group.links.new(group_input_001_2.outputs[1], compare_001.inputs[2])
	    #compare_001.Result -> switch_001_2.Switch
	    curve_deform_group.links.new(compare_001.outputs[0], switch_001_2.inputs[0])
	    #separate_xyz_1.Z -> switch_001_2.True
	    curve_deform_group.links.new(separate_xyz_1.outputs[2], switch_001_2.inputs[2])
	    #switch_002.Output -> switch_003.False
	    curve_deform_group.links.new(switch_002.outputs[0], switch_003.inputs[1])
	    #group_input_002_2.Axis X | Y | Z -> compare_002_1.A
	    curve_deform_group.links.new(group_input_002_2.outputs[1], compare_002_1.inputs[2])
	    #compare_002_1.Result -> switch_002.Switch
	    curve_deform_group.links.new(compare_002_1.outputs[0], switch_002.inputs[0])
	    #group_input_002_2.Axis X | Y | Z -> compare_003.A
	    curve_deform_group.links.new(group_input_002_2.outputs[1], compare_003.inputs[2])
	    #compare_003.Result -> switch_003.Switch
	    curve_deform_group.links.new(compare_003.outputs[0], switch_003.inputs[0])
	    #switch_004.Output -> switch_005.False
	    curve_deform_group.links.new(switch_004.outputs[0], switch_005.inputs[1])
	    #compare_002_1.Result -> switch_004.Switch
	    curve_deform_group.links.new(compare_002_1.outputs[0], switch_004.inputs[0])
	    #compare_003.Result -> switch_005.Switch
	    curve_deform_group.links.new(compare_003.outputs[0], switch_005.inputs[0])
	    #separate_xyz_001_2.Y -> switch_002.False
	    curve_deform_group.links.new(separate_xyz_001_2.outputs[1], switch_002.inputs[1])
	    #separate_xyz_001_2.Z -> switch_004.False
	    curve_deform_group.links.new(separate_xyz_001_2.outputs[2], switch_004.inputs[1])
	    #separate_xyz_001_2.Z -> switch_002.True
	    curve_deform_group.links.new(separate_xyz_001_2.outputs[2], switch_002.inputs[2])
	    #separate_xyz_001_2.X -> switch_004.True
	    curve_deform_group.links.new(separate_xyz_001_2.outputs[0], switch_004.inputs[2])
	    #separate_xyz_001_2.X -> switch_003.True
	    curve_deform_group.links.new(separate_xyz_001_2.outputs[0], switch_003.inputs[2])
	    #separate_xyz_001_2.Y -> switch_005.True
	    curve_deform_group.links.new(separate_xyz_001_2.outputs[1], switch_005.inputs[2])
	    #switch_003.Output -> vector_math_2.Scale
	    curve_deform_group.links.new(switch_003.outputs[0], vector_math_2.inputs[3])
	    #switch_005.Output -> vector_math_002_2.Scale
	    curve_deform_group.links.new(switch_005.outputs[0], vector_math_002_2.inputs[3])
	    return curve_deform_group
	
	curve_deform_group = curve_deform_group_node_group()
	
	#initialize braid_production node group
	def braid_production_node_group():
	    braid_production = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Braid Production")
	
	    braid_production.color_tag = 'NONE'
	    braid_production.description = "Create braid loops along curve guide."
	    braid_production.default_group_node_width = 140
	    
	
	
	    #braid_production interface
	    #Socket Braid 1
	    braid_1_socket_1 = braid_production.interface.new_socket(name = "Braid 1", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    braid_1_socket_1.attribute_domain = 'POINT'
	    braid_1_socket_1.description = "First braid loop."
	
	    #Socket Braid 2
	    braid_2_socket_1 = braid_production.interface.new_socket(name = "Braid 2", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    braid_2_socket_1.attribute_domain = 'POINT'
	    braid_2_socket_1.description = "Second braid loop."
	
	    #Socket Braid 3
	    braid_3_socket_1 = braid_production.interface.new_socket(name = "Braid 3", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    braid_3_socket_1.attribute_domain = 'POINT'
	    braid_3_socket_1.description = "Third braid loop."
	
	    #Socket Curve Guide
	    curve_guide_socket = braid_production.interface.new_socket(name = "Curve Guide", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    curve_guide_socket.attribute_domain = 'POINT'
	    curve_guide_socket.description = "Curve to place braids along."
	
	    #Socket Frequency
	    frequency_socket_2 = braid_production.interface.new_socket(name = "Frequency", in_out='INPUT', socket_type = 'NodeSocketInt')
	    frequency_socket_2.default_value = 1
	    frequency_socket_2.min_value = 1
	    frequency_socket_2.max_value = 10000
	    frequency_socket_2.subtype = 'NONE'
	    frequency_socket_2.attribute_domain = 'POINT'
	    frequency_socket_2.description = "Amount of braid twists."
	
	    #Socket Scale
	    scale_socket_2 = braid_production.interface.new_socket(name = "Scale", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    scale_socket_2.default_value = 0.0
	    scale_socket_2.min_value = 9.999999747378752e-05
	    scale_socket_2.max_value = 10000.0
	    scale_socket_2.subtype = 'NONE'
	    scale_socket_2.attribute_domain = 'POINT'
	    scale_socket_2.description = "Radial distance between braid loop centers."
	
	    #Socket Radius
	    radius_socket_1 = braid_production.interface.new_socket(name = "Radius", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    radius_socket_1.default_value = 1.0
	    radius_socket_1.min_value = 0.0
	    radius_socket_1.max_value = 3.4028234663852886e+38
	    radius_socket_1.subtype = 'DISTANCE'
	    radius_socket_1.attribute_domain = 'POINT'
	    radius_socket_1.description = "Radius of loops."
	
	    #Socket Curve Guide Index
	    curve_guide_index_socket = braid_production.interface.new_socket(name = "Curve Guide Index", in_out='INPUT', socket_type = 'NodeSocketInt')
	    curve_guide_index_socket.default_value = 0
	    curve_guide_index_socket.min_value = 0
	    curve_guide_index_socket.max_value = 2147483647
	    curve_guide_index_socket.subtype = 'NONE'
	    curve_guide_index_socket.attribute_domain = 'POINT'
	    curve_guide_index_socket.description = "Curve guide index."
	
	    #Socket Extend Root
	    extend_root_socket_1 = braid_production.interface.new_socket(name = "Extend Root", in_out='INPUT', socket_type = 'NodeSocketBool')
	    extend_root_socket_1.default_value = True
	    extend_root_socket_1.attribute_domain = 'POINT'
	    extend_root_socket_1.description = "Extend hair roots."
	
	
	    #initialize braid_production nodes
	    #node Group Output
	    group_output_7 = braid_production.nodes.new("NodeGroupOutput")
	    group_output_7.name = "Group Output"
	    group_output_7.is_active_output = True
	
	    #node Braid Production
	    braid_production_1 = braid_production.nodes.new("NodeGroupInput")
	    braid_production_1.label = "Braid Production"
	    braid_production_1.name = "Braid Production"
	    braid_production_1.outputs[3].hide = True
	    braid_production_1.outputs[6].hide = True
	
	    #node Braid Engine
	    braid_engine_1 = braid_production.nodes.new("GeometryNodeGroup")
	    braid_engine_1.label = "Braid Engine"
	    braid_engine_1.name = "Braid Engine"
	    braid_engine_1.hide = True
	    braid_engine_1.node_tree = braid_engine
	
	    #node Group
	    group_2 = braid_production.nodes.new("GeometryNodeGroup")
	    group_2.name = "Group"
	    group_2.hide = True
	    group_2.node_tree = curve_deform_group
	    #Socket_2
	    group_2.inputs[1].default_value = 0
	
	    #node Bounding Box
	    bounding_box = braid_production.nodes.new("GeometryNodeBoundBox")
	    bounding_box.name = "Bounding Box"
	    bounding_box.hide = True
	
	    #node Set Position
	    set_position_2 = braid_production.nodes.new("GeometryNodeSetPosition")
	    set_position_2.name = "Set Position"
	    set_position_2.hide = True
	    #Selection
	    set_position_2.inputs[1].default_value = True
	    #Offset
	    set_position_2.inputs[3].default_value = (0.0, 0.0, 0.0)
	
	    #node Join Geometry
	    join_geometry_2 = braid_production.nodes.new("GeometryNodeJoinGeometry")
	    join_geometry_2.name = "Join Geometry"
	    join_geometry_2.hide = True
	
	    #node Set Position.001
	    set_position_001_2 = braid_production.nodes.new("GeometryNodeSetPosition")
	    set_position_001_2.name = "Set Position.001"
	    set_position_001_2.hide = True
	    #Selection
	    set_position_001_2.inputs[1].default_value = True
	    #Offset
	    set_position_001_2.inputs[3].default_value = (0.0, 0.0, 0.0)
	
	    #node Set Position.002
	    set_position_002 = braid_production.nodes.new("GeometryNodeSetPosition")
	    set_position_002.name = "Set Position.002"
	    set_position_002.hide = True
	    #Selection
	    set_position_002.inputs[1].default_value = True
	    #Offset
	    set_position_002.inputs[3].default_value = (0.0, 0.0, 0.0)
	
	    #node Curve to Points
	    curve_to_points = braid_production.nodes.new("GeometryNodeCurveToPoints")
	    curve_to_points.name = "Curve to Points"
	    curve_to_points.hide = True
	    curve_to_points.mode = 'COUNT'
	    #Count
	    curve_to_points.inputs[1].default_value = 10
	
	    #node Points to Curves
	    points_to_curves = braid_production.nodes.new("GeometryNodePointsToCurves")
	    points_to_curves.name = "Points to Curves"
	    points_to_curves.hide = True
	    #Curve Group ID
	    points_to_curves.inputs[1].default_value = 0
	    #Weight
	    points_to_curves.inputs[2].default_value = 0.0
	
	    #node Curve to Points.001
	    curve_to_points_001 = braid_production.nodes.new("GeometryNodeCurveToPoints")
	    curve_to_points_001.name = "Curve to Points.001"
	    curve_to_points_001.hide = True
	    curve_to_points_001.mode = 'COUNT'
	    #Count
	    curve_to_points_001.inputs[1].default_value = 10
	
	    #node Points to Curves.001
	    points_to_curves_001 = braid_production.nodes.new("GeometryNodePointsToCurves")
	    points_to_curves_001.name = "Points to Curves.001"
	    points_to_curves_001.hide = True
	    #Curve Group ID
	    points_to_curves_001.inputs[1].default_value = 0
	    #Weight
	    points_to_curves_001.inputs[2].default_value = 0.0
	
	    #node Curve to Points.002
	    curve_to_points_002 = braid_production.nodes.new("GeometryNodeCurveToPoints")
	    curve_to_points_002.name = "Curve to Points.002"
	    curve_to_points_002.hide = True
	    curve_to_points_002.mode = 'COUNT'
	    #Count
	    curve_to_points_002.inputs[1].default_value = 10
	
	    #node Points to Curves.002
	    points_to_curves_002 = braid_production.nodes.new("GeometryNodePointsToCurves")
	    points_to_curves_002.name = "Points to Curves.002"
	    points_to_curves_002.hide = True
	    #Curve Group ID
	    points_to_curves_002.inputs[1].default_value = 0
	    #Weight
	    points_to_curves_002.inputs[2].default_value = 0.0
	
	    #node Sample Curve
	    sample_curve_1 = braid_production.nodes.new("GeometryNodeSampleCurve")
	    sample_curve_1.name = "Sample Curve"
	    sample_curve_1.hide = True
	    sample_curve_1.data_type = 'FLOAT'
	    sample_curve_1.mode = 'FACTOR'
	    sample_curve_1.use_all_curves = False
	    #Factor
	    sample_curve_1.inputs[2].default_value = 0.0
	
	    #node Spline Length
	    spline_length_1 = braid_production.nodes.new("GeometryNodeSplineLength")
	    spline_length_1.name = "Spline Length"
	    spline_length_1.hide = True
	
	    #node Set Curve Radius
	    set_curve_radius = braid_production.nodes.new("GeometryNodeSetCurveRadius")
	    set_curve_radius.name = "Set Curve Radius"
	    set_curve_radius.hide = True
	    #Selection
	    set_curve_radius.inputs[1].default_value = True
	
	    #node Braid Production.001
	    braid_production_001 = braid_production.nodes.new("NodeGroupInput")
	    braid_production_001.label = "Braid Production"
	    braid_production_001.name = "Braid Production.001"
	    braid_production_001.outputs[1].hide = True
	    braid_production_001.outputs[2].hide = True
	    braid_production_001.outputs[4].hide = True
	    braid_production_001.outputs[5].hide = True
	    braid_production_001.outputs[6].hide = True
	
	    #node Braid Production.004
	    braid_production_004 = braid_production.nodes.new("NodeGroupInput")
	    braid_production_004.label = "Braid Production"
	    braid_production_004.name = "Braid Production.004"
	    braid_production_004.outputs[0].hide = True
	    braid_production_004.outputs[1].hide = True
	    braid_production_004.outputs[2].hide = True
	    braid_production_004.outputs[3].hide = True
	    braid_production_004.outputs[5].hide = True
	    braid_production_004.outputs[6].hide = True
	
	
	
	
	
	    #Set locations
	    group_output_7.location = (256.40985107421875, -42.73731994628906)
	    braid_production_1.location = (-991.1095581054688, 24.759601593017578)
	    braid_engine_1.location = (-799.0633544921875, -60.11033630371094)
	    group_2.location = (-160.87445068359375, 19.151765823364258)
	    bounding_box.location = (-339.31146240234375, 96.23235321044922)
	    set_position_2.location = (66.409912109375, -52.33226776123047)
	    join_geometry_2.location = (-501.72698974609375, 96.03256225585938)
	    set_position_001_2.location = (66.79315185546875, -99.47391510009766)
	    set_position_002.location = (64.59832763671875, -148.42874145507812)
	    curve_to_points.location = (-347.34014892578125, -38.18697738647461)
	    points_to_curves.location = (-165.17010498046875, -37.38173294067383)
	    curve_to_points_001.location = (-342.95050048828125, -143.79541015625)
	    points_to_curves_001.location = (-160.78045654296875, -142.9901580810547)
	    curve_to_points_002.location = (-345.14532470703125, -88.79100036621094)
	    points_to_curves_002.location = (-162.97528076171875, -87.98576354980469)
	    sample_curve_1.location = (-799.4370727539062, -8.57685375213623)
	    spline_length_1.location = (-799.34912109375, 47.08891296386719)
	    set_curve_radius.location = (-340.9910888671875, 33.85443115234375)
	    braid_production_001.location = (-501.981689453125, 64.3448715209961)
	    braid_production_004.location = (-162.55633544921875, 89.0697021484375)
	
	    #Set dimensions
	    group_output_7.width, group_output_7.height = 140.0, 100.0
	    braid_production_1.width, braid_production_1.height = 140.0, 100.0
	    braid_engine_1.width, braid_engine_1.height = 139.9998779296875, 100.0
	    group_2.width, group_2.height = 140.0, 100.0
	    bounding_box.width, bounding_box.height = 140.0, 100.0
	    set_position_2.width, set_position_2.height = 140.0, 100.0
	    join_geometry_2.width, join_geometry_2.height = 140.0, 100.0
	    set_position_001_2.width, set_position_001_2.height = 140.0, 100.0
	    set_position_002.width, set_position_002.height = 140.0, 100.0
	    curve_to_points.width, curve_to_points.height = 140.0, 100.0
	    points_to_curves.width, points_to_curves.height = 140.0, 100.0
	    curve_to_points_001.width, curve_to_points_001.height = 140.0, 100.0
	    points_to_curves_001.width, points_to_curves_001.height = 140.0, 100.0
	    curve_to_points_002.width, curve_to_points_002.height = 140.0, 100.0
	    points_to_curves_002.width, points_to_curves_002.height = 140.0, 100.0
	    sample_curve_1.width, sample_curve_1.height = 140.0, 100.0
	    spline_length_1.width, spline_length_1.height = 140.0, 100.0
	    set_curve_radius.width, set_curve_radius.height = 140.0, 100.0
	    braid_production_001.width, braid_production_001.height = 140.0, 100.0
	    braid_production_004.width, braid_production_004.height = 140.0, 100.0
	
	    #initialize braid_production links
	    #braid_engine_1.Braid 3 -> join_geometry_2.Geometry
	    braid_production.links.new(braid_engine_1.outputs[2], join_geometry_2.inputs[0])
	    #group_2.Vector -> set_position_001_2.Position
	    braid_production.links.new(group_2.outputs[0], set_position_001_2.inputs[2])
	    #group_2.Vector -> set_position_2.Position
	    braid_production.links.new(group_2.outputs[0], set_position_2.inputs[2])
	    #points_to_curves.Curves -> set_position_2.Geometry
	    braid_production.links.new(points_to_curves.outputs[0], set_position_2.inputs[0])
	    #bounding_box.Min -> group_2.From Min
	    braid_production.links.new(bounding_box.outputs[1], group_2.inputs[2])
	    #group_2.Vector -> set_position_002.Position
	    braid_production.links.new(group_2.outputs[0], set_position_002.inputs[2])
	    #join_geometry_2.Geometry -> bounding_box.Geometry
	    braid_production.links.new(join_geometry_2.outputs[0], bounding_box.inputs[0])
	    #bounding_box.Max -> group_2.From Max
	    braid_production.links.new(bounding_box.outputs[2], group_2.inputs[3])
	    #braid_production_1.Frequency -> braid_engine_1.Frequency
	    braid_production.links.new(braid_production_1.outputs[1], braid_engine_1.inputs[1])
	    #set_curve_radius.Curve -> group_2.Curves
	    braid_production.links.new(set_curve_radius.outputs[0], group_2.inputs[0])
	    #braid_production_1.Scale -> braid_engine_1.Scale
	    braid_production.links.new(braid_production_1.outputs[2], braid_engine_1.inputs[2])
	    #set_position_2.Geometry -> group_output_7.Braid 1
	    braid_production.links.new(set_position_2.outputs[0], group_output_7.inputs[0])
	    #set_position_001_2.Geometry -> group_output_7.Braid 2
	    braid_production.links.new(set_position_001_2.outputs[0], group_output_7.inputs[1])
	    #set_position_002.Geometry -> group_output_7.Braid 3
	    braid_production.links.new(set_position_002.outputs[0], group_output_7.inputs[2])
	    #braid_engine_1.Braid 1 -> curve_to_points.Curve
	    braid_production.links.new(braid_engine_1.outputs[0], curve_to_points.inputs[0])
	    #curve_to_points.Points -> points_to_curves.Points
	    braid_production.links.new(curve_to_points.outputs[0], points_to_curves.inputs[0])
	    #curve_to_points_001.Points -> points_to_curves_001.Points
	    braid_production.links.new(curve_to_points_001.outputs[0], points_to_curves_001.inputs[0])
	    #curve_to_points_002.Points -> points_to_curves_002.Points
	    braid_production.links.new(curve_to_points_002.outputs[0], points_to_curves_002.inputs[0])
	    #braid_engine_1.Braid 2 -> curve_to_points_002.Curve
	    braid_production.links.new(braid_engine_1.outputs[1], curve_to_points_002.inputs[0])
	    #points_to_curves_002.Curves -> set_position_001_2.Geometry
	    braid_production.links.new(points_to_curves_002.outputs[0], set_position_001_2.inputs[0])
	    #braid_engine_1.Braid 3 -> curve_to_points_001.Curve
	    braid_production.links.new(braid_engine_1.outputs[2], curve_to_points_001.inputs[0])
	    #points_to_curves_001.Curves -> set_position_002.Geometry
	    braid_production.links.new(points_to_curves_001.outputs[0], set_position_002.inputs[0])
	    #spline_length_1.Length -> sample_curve_1.Value
	    braid_production.links.new(spline_length_1.outputs[0], sample_curve_1.inputs[1])
	    #sample_curve_1.Value -> braid_engine_1.Length
	    braid_production.links.new(sample_curve_1.outputs[0], braid_engine_1.inputs[0])
	    #braid_production_004.Curve Guide Index -> group_2.Group ID
	    braid_production.links.new(braid_production_004.outputs[4], group_2.inputs[4])
	    #braid_production_001.Radius -> set_curve_radius.Radius
	    braid_production.links.new(braid_production_001.outputs[3], set_curve_radius.inputs[2])
	    #braid_production_1.Curve Guide -> sample_curve_1.Curves
	    braid_production.links.new(braid_production_1.outputs[0], sample_curve_1.inputs[0])
	    #braid_production_1.Curve Guide Index -> sample_curve_1.Curve Index
	    braid_production.links.new(braid_production_1.outputs[4], sample_curve_1.inputs[4])
	    #braid_production_001.Curve Guide -> set_curve_radius.Curve
	    braid_production.links.new(braid_production_001.outputs[0], set_curve_radius.inputs[0])
	    #braid_production_1.Extend Root -> braid_engine_1.Extend Root
	    braid_production.links.new(braid_production_1.outputs[5], braid_engine_1.inputs[3])
	    #braid_engine_1.Braid 2 -> join_geometry_2.Geometry
	    braid_production.links.new(braid_engine_1.outputs[1], join_geometry_2.inputs[0])
	    #braid_engine_1.Braid 1 -> join_geometry_2.Geometry
	    braid_production.links.new(braid_engine_1.outputs[0], join_geometry_2.inputs[0])
	    return braid_production
	
	braid_production = braid_production_node_group()
	
	#initialize curve_root_002 node group
	def curve_root_002_node_group():
	    curve_root_002 = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Curve Root.002")
	
	    curve_root_002.color_tag = 'INPUT'
	    curve_root_002.description = "Reads information about each curve's root point"
	    curve_root_002.default_group_node_width = 140
	    
	
	
	    #curve_root_002 interface
	    #Socket Root Selection
	    root_selection_socket_1 = curve_root_002.interface.new_socket(name = "Root Selection", in_out='OUTPUT', socket_type = 'NodeSocketBool')
	    root_selection_socket_1.default_value = False
	    root_selection_socket_1.attribute_domain = 'POINT'
	    root_selection_socket_1.description = "Boolean selection of curve root points"
	
	    #Socket Root Position
	    root_position_socket_1 = curve_root_002.interface.new_socket(name = "Root Position", in_out='OUTPUT', socket_type = 'NodeSocketVector')
	    root_position_socket_1.default_value = (0.0, 0.0, 0.0)
	    root_position_socket_1.min_value = -3.4028234663852886e+38
	    root_position_socket_1.max_value = 3.4028234663852886e+38
	    root_position_socket_1.subtype = 'NONE'
	    root_position_socket_1.attribute_domain = 'CURVE'
	    root_position_socket_1.description = "Position of the root point of a curve"
	
	    #Socket Root Direction
	    root_direction_socket_1 = curve_root_002.interface.new_socket(name = "Root Direction", in_out='OUTPUT', socket_type = 'NodeSocketVector')
	    root_direction_socket_1.default_value = (0.0, 0.0, 0.0)
	    root_direction_socket_1.min_value = -3.4028234663852886e+38
	    root_direction_socket_1.max_value = 3.4028234663852886e+38
	    root_direction_socket_1.subtype = 'NONE'
	    root_direction_socket_1.attribute_domain = 'CURVE'
	    root_direction_socket_1.description = "Direction of the root segment of a curve"
	
	    #Socket Root Index
	    root_index_socket_1 = curve_root_002.interface.new_socket(name = "Root Index", in_out='OUTPUT', socket_type = 'NodeSocketInt')
	    root_index_socket_1.default_value = 0
	    root_index_socket_1.min_value = -2147483648
	    root_index_socket_1.max_value = 2147483647
	    root_index_socket_1.subtype = 'NONE'
	    root_index_socket_1.attribute_domain = 'CURVE'
	    root_index_socket_1.description = "Index of the root point of a curve"
	
	
	    #initialize curve_root_002 nodes
	    #node Position.002
	    position_002_2 = curve_root_002.nodes.new("GeometryNodeInputPosition")
	    position_002_2.name = "Position.002"
	
	    #node Interpolate Domain
	    interpolate_domain_2 = curve_root_002.nodes.new("GeometryNodeFieldOnDomain")
	    interpolate_domain_2.name = "Interpolate Domain"
	    interpolate_domain_2.data_type = 'INT'
	    interpolate_domain_2.domain = 'CURVE'
	
	    #node Field at Index.003
	    field_at_index_003_2 = curve_root_002.nodes.new("GeometryNodeFieldAtIndex")
	    field_at_index_003_2.name = "Field at Index.003"
	    field_at_index_003_2.data_type = 'FLOAT_VECTOR'
	    field_at_index_003_2.domain = 'POINT'
	
	    #node Interpolate Domain.001
	    interpolate_domain_001_2 = curve_root_002.nodes.new("GeometryNodeFieldOnDomain")
	    interpolate_domain_001_2.name = "Interpolate Domain.001"
	    interpolate_domain_001_2.data_type = 'FLOAT_VECTOR'
	    interpolate_domain_001_2.domain = 'CURVE'
	
	    #node Curve Tangent
	    curve_tangent_3 = curve_root_002.nodes.new("GeometryNodeInputTangent")
	    curve_tangent_3.name = "Curve Tangent"
	
	    #node Endpoint Selection
	    endpoint_selection_2 = curve_root_002.nodes.new("GeometryNodeCurveEndpointSelection")
	    endpoint_selection_2.name = "Endpoint Selection"
	    #Start Size
	    endpoint_selection_2.inputs[0].default_value = 1
	    #End Size
	    endpoint_selection_2.inputs[1].default_value = 0
	
	    #node Field at Index.004
	    field_at_index_004_2 = curve_root_002.nodes.new("GeometryNodeFieldAtIndex")
	    field_at_index_004_2.name = "Field at Index.004"
	    field_at_index_004_2.data_type = 'FLOAT_VECTOR'
	    field_at_index_004_2.domain = 'POINT'
	
	    #node Interpolate Domain.002
	    interpolate_domain_002_2 = curve_root_002.nodes.new("GeometryNodeFieldOnDomain")
	    interpolate_domain_002_2.name = "Interpolate Domain.002"
	    interpolate_domain_002_2.data_type = 'FLOAT_VECTOR'
	    interpolate_domain_002_2.domain = 'CURVE'
	
	    #node Group Output
	    group_output_8 = curve_root_002.nodes.new("NodeGroupOutput")
	    group_output_8.name = "Group Output"
	    group_output_8.is_active_output = True
	
	    #node Points of Curve
	    points_of_curve_2 = curve_root_002.nodes.new("GeometryNodePointsOfCurve")
	    points_of_curve_2.name = "Points of Curve"
	    points_of_curve_2.inputs[0].hide = True
	    points_of_curve_2.inputs[1].hide = True
	    points_of_curve_2.outputs[1].hide = True
	    #Curve Index
	    points_of_curve_2.inputs[0].default_value = 0
	    #Weights
	    points_of_curve_2.inputs[1].default_value = 0.0
	    #Sort Index
	    points_of_curve_2.inputs[2].default_value = 0
	
	
	
	
	
	    #Set locations
	    position_002_2.location = (-608.1627807617188, -70.55814361572266)
	    interpolate_domain_2.location = (-608.1627807617188, 90.18604278564453)
	    field_at_index_003_2.location = (-407.2325439453125, 70.09302520751953)
	    interpolate_domain_001_2.location = (-206.30230712890625, 70.09302520751953)
	    curve_tangent_3.location = (-608.1627807617188, -271.4883728027344)
	    endpoint_selection_2.location = (-206.30230712890625, 190.65118408203125)
	    field_at_index_004_2.location = (-407.2325439453125, -130.83721923828125)
	    interpolate_domain_002_2.location = (-206.30230712890625, -130.83721923828125)
	    group_output_8.location = (75.0, 50.0)
	    points_of_curve_2.location = (-789.0, 50.0)
	
	    #Set dimensions
	    position_002_2.width, position_002_2.height = 140.0, 100.0
	    interpolate_domain_2.width, interpolate_domain_2.height = 140.0, 100.0
	    field_at_index_003_2.width, field_at_index_003_2.height = 140.0, 100.0
	    interpolate_domain_001_2.width, interpolate_domain_001_2.height = 140.0, 100.0
	    curve_tangent_3.width, curve_tangent_3.height = 140.0, 100.0
	    endpoint_selection_2.width, endpoint_selection_2.height = 140.0, 100.0
	    field_at_index_004_2.width, field_at_index_004_2.height = 140.0, 100.0
	    interpolate_domain_002_2.width, interpolate_domain_002_2.height = 140.0, 100.0
	    group_output_8.width, group_output_8.height = 140.0, 100.0
	    points_of_curve_2.width, points_of_curve_2.height = 140.0, 100.0
	
	    #initialize curve_root_002 links
	    #position_002_2.Position -> field_at_index_003_2.Value
	    curve_root_002.links.new(position_002_2.outputs[0], field_at_index_003_2.inputs[1])
	    #interpolate_domain_001_2.Value -> group_output_8.Root Position
	    curve_root_002.links.new(interpolate_domain_001_2.outputs[0], group_output_8.inputs[1])
	    #interpolate_domain_2.Value -> field_at_index_003_2.Index
	    curve_root_002.links.new(interpolate_domain_2.outputs[0], field_at_index_003_2.inputs[0])
	    #points_of_curve_2.Point Index -> interpolate_domain_2.Value
	    curve_root_002.links.new(points_of_curve_2.outputs[0], interpolate_domain_2.inputs[0])
	    #interpolate_domain_2.Value -> group_output_8.Root Index
	    curve_root_002.links.new(interpolate_domain_2.outputs[0], group_output_8.inputs[3])
	    #endpoint_selection_2.Selection -> group_output_8.Root Selection
	    curve_root_002.links.new(endpoint_selection_2.outputs[0], group_output_8.inputs[0])
	    #field_at_index_003_2.Value -> interpolate_domain_001_2.Value
	    curve_root_002.links.new(field_at_index_003_2.outputs[0], interpolate_domain_001_2.inputs[0])
	    #interpolate_domain_002_2.Value -> group_output_8.Root Direction
	    curve_root_002.links.new(interpolate_domain_002_2.outputs[0], group_output_8.inputs[2])
	    #interpolate_domain_2.Value -> field_at_index_004_2.Index
	    curve_root_002.links.new(interpolate_domain_2.outputs[0], field_at_index_004_2.inputs[0])
	    #curve_tangent_3.Tangent -> field_at_index_004_2.Value
	    curve_root_002.links.new(curve_tangent_3.outputs[0], field_at_index_004_2.inputs[1])
	    #field_at_index_004_2.Value -> interpolate_domain_002_2.Value
	    curve_root_002.links.new(field_at_index_004_2.outputs[0], interpolate_domain_002_2.inputs[0])
	    return curve_root_002
	
	curve_root_002 = curve_root_002_node_group()
	
	#initialize attach_hair_curves_to_surface node group
	def attach_hair_curves_to_surface_node_group():
	    attach_hair_curves_to_surface = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Attach Hair Curves to Surface")
	
	    attach_hair_curves_to_surface.color_tag = 'GEOMETRY'
	    attach_hair_curves_to_surface.description = "Attaches hair curves to a surface mesh"
	    attach_hair_curves_to_surface.default_group_node_width = 140
	    
	
	    attach_hair_curves_to_surface.is_modifier = True
	
	    #attach_hair_curves_to_surface interface
	    #Socket Geometry
	    geometry_socket_3 = attach_hair_curves_to_surface.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_3.attribute_domain = 'POINT'
	
	    #Socket Surface UV Coordinate
	    surface_uv_coordinate_socket = attach_hair_curves_to_surface.interface.new_socket(name = "Surface UV Coordinate", in_out='OUTPUT', socket_type = 'NodeSocketVector')
	    surface_uv_coordinate_socket.default_value = (0.0, 0.0, 0.0)
	    surface_uv_coordinate_socket.min_value = -3.4028234663852886e+38
	    surface_uv_coordinate_socket.max_value = 3.4028234663852886e+38
	    surface_uv_coordinate_socket.subtype = 'NONE'
	    surface_uv_coordinate_socket.attribute_domain = 'CURVE'
	    surface_uv_coordinate_socket.description = "Surface UV coordinates at the attachment point"
	
	    #Socket Surface Normal
	    surface_normal_socket = attach_hair_curves_to_surface.interface.new_socket(name = "Surface Normal", in_out='OUTPUT', socket_type = 'NodeSocketVector')
	    surface_normal_socket.default_value = (0.0, 0.0, 0.0)
	    surface_normal_socket.min_value = -3.4028234663852886e+38
	    surface_normal_socket.max_value = 3.4028234663852886e+38
	    surface_normal_socket.subtype = 'NONE'
	    surface_normal_socket.attribute_domain = 'CURVE'
	    surface_normal_socket.description = "Surface normal at the attachment point"
	
	    #Socket Geometry
	    geometry_socket_4 = attach_hair_curves_to_surface.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_4.attribute_domain = 'POINT'
	    geometry_socket_4.description = "Input Geometry (may include other than curves)"
	
	    #Socket Surface
	    surface_socket = attach_hair_curves_to_surface.interface.new_socket(name = "Surface", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    surface_socket.attribute_domain = 'POINT'
	    surface_socket.description = "Surface geometry to attach hair curves to"
	
	    #Socket Surface
	    surface_socket_1 = attach_hair_curves_to_surface.interface.new_socket(name = "Surface", in_out='INPUT', socket_type = 'NodeSocketObject')
	    surface_socket_1.attribute_domain = 'POINT'
	    surface_socket_1.description = "Surface Object to attach to (needs to have matching transforms)"
	
	    #Socket Surface UV Map
	    surface_uv_map_socket = attach_hair_curves_to_surface.interface.new_socket(name = "Surface UV Map", in_out='INPUT', socket_type = 'NodeSocketVector')
	    surface_uv_map_socket.default_value = (0.0, 0.0, 0.0)
	    surface_uv_map_socket.min_value = -3.4028234663852886e+38
	    surface_uv_map_socket.max_value = 3.4028234663852886e+38
	    surface_uv_map_socket.subtype = 'NONE'
	    surface_uv_map_socket.default_attribute_name = "UVMap"
	    surface_uv_map_socket.attribute_domain = 'POINT'
	    surface_uv_map_socket.hide_value = True
	    surface_uv_map_socket.description = "Surface UV map used for attachment"
	
	    #Socket Surface Rest Position
	    surface_rest_position_socket = attach_hair_curves_to_surface.interface.new_socket(name = "Surface Rest Position", in_out='INPUT', socket_type = 'NodeSocketBool')
	    surface_rest_position_socket.default_value = False
	    surface_rest_position_socket.attribute_domain = 'POINT'
	    surface_rest_position_socket.description = "Set the surface mesh into its rest position before attachment"
	
	    #Socket Sample Attachment UV
	    sample_attachment_uv_socket = attach_hair_curves_to_surface.interface.new_socket(name = "Sample Attachment UV", in_out='INPUT', socket_type = 'NodeSocketBool')
	    sample_attachment_uv_socket.default_value = True
	    sample_attachment_uv_socket.attribute_domain = 'POINT'
	    sample_attachment_uv_socket.description = "Sample the surface UV map at the attachment point"
	
	    #Socket Snap to Surface
	    snap_to_surface_socket = attach_hair_curves_to_surface.interface.new_socket(name = "Snap to Surface", in_out='INPUT', socket_type = 'NodeSocketBool')
	    snap_to_surface_socket.default_value = True
	    snap_to_surface_socket.attribute_domain = 'POINT'
	    snap_to_surface_socket.description = "Snap the root of each curve to the closest surface point"
	
	    #Socket Align to Surface Normal
	    align_to_surface_normal_socket = attach_hair_curves_to_surface.interface.new_socket(name = "Align to Surface Normal", in_out='INPUT', socket_type = 'NodeSocketBool')
	    align_to_surface_normal_socket.default_value = True
	    align_to_surface_normal_socket.attribute_domain = 'POINT'
	    align_to_surface_normal_socket.description = "Align the curve to the surface normal (needs a guide as reference)"
	
	    #Socket Blend along Curve
	    blend_along_curve_socket = attach_hair_curves_to_surface.interface.new_socket(name = "Blend along Curve", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    blend_along_curve_socket.default_value = 0.0
	    blend_along_curve_socket.min_value = 0.0
	    blend_along_curve_socket.max_value = 1.0
	    blend_along_curve_socket.subtype = 'FACTOR'
	    blend_along_curve_socket.attribute_domain = 'POINT'
	    blend_along_curve_socket.description = "Blend deformation along each curve from the root"
	
	
	    #initialize attach_hair_curves_to_surface nodes
	    #node Frame.004
	    frame_004_1 = attach_hair_curves_to_surface.nodes.new("NodeFrame")
	    frame_004_1.label = "Write Data"
	    frame_004_1.name = "Frame.004"
	    frame_004_1.label_size = 20
	    frame_004_1.shrink = True
	
	    #node Frame.005
	    frame_005 = attach_hair_curves_to_surface.nodes.new("NodeFrame")
	    frame_005.label = "Sample Surface"
	    frame_005.name = "Frame.005"
	    frame_005.label_size = 20
	    frame_005.shrink = True
	
	    #node Frame
	    frame_3 = attach_hair_curves_to_surface.nodes.new("NodeFrame")
	    frame_3.label = "Surface Geometry Input"
	    frame_3.name = "Frame"
	    frame_3.label_size = 20
	    frame_3.shrink = True
	
	    #node Frame.006
	    frame_006 = attach_hair_curves_to_surface.nodes.new("NodeFrame")
	    frame_006.label = "Geometry Socket with Priority"
	    frame_006.name = "Frame.006"
	    frame_006.label_size = 20
	    frame_006.shrink = True
	
	    #node Frame.007
	    frame_007 = attach_hair_curves_to_surface.nodes.new("NodeFrame")
	    frame_007.label = "Object in Local Space"
	    frame_007.name = "Frame.007"
	    frame_007.label_size = 20
	    frame_007.shrink = True
	
	    #node Frame.011
	    frame_011 = attach_hair_curves_to_surface.nodes.new("NodeFrame")
	    frame_011.label = "Sample Attachment UV"
	    frame_011.name = "Frame.011"
	    frame_011.label_size = 20
	    frame_011.shrink = True
	
	    #node Frame.001
	    frame_001_2 = attach_hair_curves_to_surface.nodes.new("NodeFrame")
	    frame_001_2.label = "Smooth Normals"
	    frame_001_2.name = "Frame.001"
	    frame_001_2.label_size = 20
	    frame_001_2.shrink = True
	
	    #node Frame.010
	    frame_010 = attach_hair_curves_to_surface.nodes.new("NodeFrame")
	    frame_010.label = "Calculate New Position"
	    frame_010.name = "Frame.010"
	    frame_010.use_custom_color = True
	    frame_010.color = (0.13328450918197632, 0.13328450918197632, 0.13328450918197632)
	    frame_010.label_size = 20
	    frame_010.shrink = True
	
	    #node Frame.003
	    frame_003_2 = attach_hair_curves_to_surface.nodes.new("NodeFrame")
	    frame_003_2.label = "Blend Deformation"
	    frame_003_2.name = "Frame.003"
	    frame_003_2.label_size = 20
	    frame_003_2.shrink = True
	
	    #node Frame.002
	    frame_002_2 = attach_hair_curves_to_surface.nodes.new("NodeFrame")
	    frame_002_2.label = "Align to Normal"
	    frame_002_2.name = "Frame.002"
	    frame_002_2.use_custom_color = True
	    frame_002_2.color = (0.08883915841579437, 0.08883915841579437, 0.08883915841579437)
	    frame_002_2.label_size = 20
	    frame_002_2.shrink = True
	
	    #node Frame.008
	    frame_008 = attach_hair_curves_to_surface.nodes.new("NodeFrame")
	    frame_008.label = "Optimize"
	    frame_008.name = "Frame.008"
	    frame_008.label_size = 20
	    frame_008.shrink = True
	
	    #node Frame.009
	    frame_009 = attach_hair_curves_to_surface.nodes.new("NodeFrame")
	    frame_009.label = "Sample from Guide"
	    frame_009.name = "Frame.009"
	    frame_009.label_size = 20
	    frame_009.shrink = True
	
	    #node Reroute.010
	    reroute_010 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_010.name = "Reroute.010"
	    reroute_010.socket_idname = "NodeSocketGeometry"
	    #node Reroute.013
	    reroute_013_1 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_013_1.name = "Reroute.013"
	    reroute_013_1.socket_idname = "NodeSocketBool"
	    #node Group Output
	    group_output_9 = attach_hair_curves_to_surface.nodes.new("NodeGroupOutput")
	    group_output_9.name = "Group Output"
	    group_output_9.is_active_output = True
	
	    #node Reroute.003
	    reroute_003_2 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_003_2.name = "Reroute.003"
	    reroute_003_2.socket_idname = "NodeSocketVector"
	    #node Switch
	    switch_3 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSwitch")
	    switch_3.name = "Switch"
	    switch_3.input_type = 'GEOMETRY'
	
	    #node Store Named Attribute
	    store_named_attribute_1 = attach_hair_curves_to_surface.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_1.name = "Store Named Attribute"
	    store_named_attribute_1.data_type = 'FLOAT2'
	    store_named_attribute_1.domain = 'CURVE'
	    #Selection
	    store_named_attribute_1.inputs[1].default_value = True
	    #Name
	    store_named_attribute_1.inputs[2].default_value = "surface_uv_coordinate"
	
	    #node Group Input.007
	    group_input_007_1 = attach_hair_curves_to_surface.nodes.new("NodeGroupInput")
	    group_input_007_1.name = "Group Input.007"
	    group_input_007_1.outputs[0].hide = True
	    group_input_007_1.outputs[1].hide = True
	    group_input_007_1.outputs[2].hide = True
	    group_input_007_1.outputs[3].hide = True
	    group_input_007_1.outputs[4].hide = True
	    group_input_007_1.outputs[6].hide = True
	    group_input_007_1.outputs[7].hide = True
	    group_input_007_1.outputs[8].hide = True
	    group_input_007_1.outputs[9].hide = True
	
	    #node Reroute.016
	    reroute_016_1 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_016_1.name = "Reroute.016"
	    reroute_016_1.socket_idname = "NodeSocketGeometry"
	    #node Reroute.005
	    reroute_005 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_005.name = "Reroute.005"
	    reroute_005.socket_idname = "NodeSocketVector"
	    #node Store Named Attribute.001
	    store_named_attribute_001 = attach_hair_curves_to_surface.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_001.name = "Store Named Attribute.001"
	    store_named_attribute_001.data_type = 'FLOAT_VECTOR'
	    store_named_attribute_001.domain = 'CURVE'
	    #Selection
	    store_named_attribute_001.inputs[1].default_value = True
	    #Name
	    store_named_attribute_001.inputs[2].default_value = "surface_normal"
	
	    #node Named Attribute.004
	    named_attribute_004 = attach_hair_curves_to_surface.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute_004.name = "Named Attribute.004"
	    named_attribute_004.data_type = 'FLOAT_VECTOR'
	    #Name
	    named_attribute_004.inputs[0].default_value = "surface_normal"
	
	    #node Reroute.012
	    reroute_012_1 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_012_1.name = "Reroute.012"
	    reroute_012_1.socket_idname = "NodeSocketBool"
	    #node Reroute.014
	    reroute_014_1 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_014_1.name = "Reroute.014"
	    reroute_014_1.socket_idname = "NodeSocketBool"
	    #node Reroute.006
	    reroute_006 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_006.name = "Reroute.006"
	    reroute_006.socket_idname = "NodeSocketGeometry"
	    #node Named Attribute.003
	    named_attribute_003 = attach_hair_curves_to_surface.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute_003.name = "Named Attribute.003"
	    named_attribute_003.data_type = 'FLOAT_VECTOR'
	    #Name
	    named_attribute_003.inputs[0].default_value = "surface_uv_coordinate"
	
	    #node Switch.008
	    switch_008 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSwitch")
	    switch_008.name = "Switch.008"
	    switch_008.input_type = 'GEOMETRY'
	
	    #node Switch.009
	    switch_009 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSwitch")
	    switch_009.name = "Switch.009"
	    switch_009.input_type = 'VECTOR'
	
	    #node Switch.010
	    switch_010 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSwitch")
	    switch_010.name = "Switch.010"
	    switch_010.input_type = 'VECTOR'
	
	    #node Set Position.001
	    set_position_001_3 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSetPosition")
	    set_position_001_3.name = "Set Position.001"
	    set_position_001_3.inputs[2].hide = True
	    #Position
	    set_position_001_3.inputs[2].default_value = (0.0, 0.0, 0.0)
	
	    #node Reroute.002
	    reroute_002_2 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_002_2.name = "Reroute.002"
	    reroute_002_2.socket_idname = "NodeSocketVector"
	    #node Reroute.018
	    reroute_018_1 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_018_1.name = "Reroute.018"
	    reroute_018_1.socket_idname = "NodeSocketVector"
	    #node Reroute.017
	    reroute_017_1 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_017_1.name = "Reroute.017"
	    reroute_017_1.socket_idname = "NodeSocketGeometry"
	    #node Group Input.009
	    group_input_009 = attach_hair_curves_to_surface.nodes.new("NodeGroupInput")
	    group_input_009.name = "Group Input.009"
	    group_input_009.outputs[0].hide = True
	    group_input_009.outputs[1].hide = True
	    group_input_009.outputs[2].hide = True
	    group_input_009.outputs[4].hide = True
	    group_input_009.outputs[5].hide = True
	    group_input_009.outputs[6].hide = True
	    group_input_009.outputs[7].hide = True
	    group_input_009.outputs[8].hide = True
	    group_input_009.outputs[9].hide = True
	
	    #node Position
	    position_2 = attach_hair_curves_to_surface.nodes.new("GeometryNodeInputPosition")
	    position_2.name = "Position"
	
	    #node Named Attribute.001
	    named_attribute_001 = attach_hair_curves_to_surface.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute_001.name = "Named Attribute.001"
	    named_attribute_001.data_type = 'FLOAT_VECTOR'
	    #Name
	    named_attribute_001.inputs[0].default_value = "surface_uv_coordinate"
	
	    #node Capture Attribute.001
	    capture_attribute_001_1 = attach_hair_curves_to_surface.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_001_1.name = "Capture Attribute.001"
	    capture_attribute_001_1.active_index = 0
	    capture_attribute_001_1.capture_items.clear()
	    capture_attribute_001_1.capture_items.new('FLOAT', "Value")
	    capture_attribute_001_1.capture_items["Value"].data_type = 'FLOAT_VECTOR'
	    capture_attribute_001_1.domain = 'CURVE'
	
	    #node Group Input.004
	    group_input_004_1 = attach_hair_curves_to_surface.nodes.new("NodeGroupInput")
	    group_input_004_1.name = "Group Input.004"
	    group_input_004_1.outputs[0].hide = True
	    group_input_004_1.outputs[2].hide = True
	    group_input_004_1.outputs[3].hide = True
	    group_input_004_1.outputs[4].hide = True
	    group_input_004_1.outputs[5].hide = True
	    group_input_004_1.outputs[6].hide = True
	    group_input_004_1.outputs[7].hide = True
	    group_input_004_1.outputs[8].hide = True
	    group_input_004_1.outputs[9].hide = True
	
	    #node Domain Size.002
	    domain_size_002 = attach_hair_curves_to_surface.nodes.new("GeometryNodeAttributeDomainSize")
	    domain_size_002.name = "Domain Size.002"
	    domain_size_002.component = 'MESH'
	    domain_size_002.outputs[0].hide = True
	    domain_size_002.outputs[1].hide = True
	    domain_size_002.outputs[3].hide = True
	    domain_size_002.outputs[4].hide = True
	    domain_size_002.outputs[5].hide = True
	
	    #node Compare.001
	    compare_001_1 = attach_hair_curves_to_surface.nodes.new("FunctionNodeCompare")
	    compare_001_1.name = "Compare.001"
	    compare_001_1.data_type = 'INT'
	    compare_001_1.mode = 'ELEMENT'
	    compare_001_1.operation = 'NOT_EQUAL'
	    #B_INT
	    compare_001_1.inputs[3].default_value = 0
	
	    #node Object Info.001
	    object_info_001 = attach_hair_curves_to_surface.nodes.new("GeometryNodeObjectInfo")
	    object_info_001.name = "Object Info.001"
	    object_info_001.transform_space = 'ORIGINAL'
	    object_info_001.inputs[1].hide = True
	    object_info_001.outputs[1].hide = True
	    object_info_001.outputs[3].hide = True
	    #As Instance
	    object_info_001.inputs[1].default_value = False
	
	    #node Group Input.002
	    group_input_002_3 = attach_hair_curves_to_surface.nodes.new("NodeGroupInput")
	    group_input_002_3.name = "Group Input.002"
	    group_input_002_3.outputs[0].hide = True
	    group_input_002_3.outputs[1].hide = True
	    group_input_002_3.outputs[3].hide = True
	    group_input_002_3.outputs[4].hide = True
	    group_input_002_3.outputs[5].hide = True
	    group_input_002_3.outputs[6].hide = True
	    group_input_002_3.outputs[7].hide = True
	    group_input_002_3.outputs[8].hide = True
	    group_input_002_3.outputs[9].hide = True
	
	    #node Switch.005
	    switch_005_1 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSwitch")
	    switch_005_1.name = "Switch.005"
	    switch_005_1.input_type = 'GEOMETRY'
	
	    #node Domain Size.003
	    domain_size_003 = attach_hair_curves_to_surface.nodes.new("GeometryNodeAttributeDomainSize")
	    domain_size_003.name = "Domain Size.003"
	    domain_size_003.component = 'MESH'
	    domain_size_003.outputs[0].hide = True
	    domain_size_003.outputs[1].hide = True
	    domain_size_003.outputs[3].hide = True
	    domain_size_003.outputs[4].hide = True
	    domain_size_003.outputs[5].hide = True
	
	    #node Compare.002
	    compare_002_2 = attach_hair_curves_to_surface.nodes.new("FunctionNodeCompare")
	    compare_002_2.name = "Compare.002"
	    compare_002_2.data_type = 'INT'
	    compare_002_2.mode = 'ELEMENT'
	    compare_002_2.operation = 'EQUAL'
	    #B_INT
	    compare_002_2.inputs[3].default_value = 0
	
	    #node Named Attribute
	    named_attribute_1 = attach_hair_curves_to_surface.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute_1.name = "Named Attribute"
	    named_attribute_1.data_type = 'FLOAT_VECTOR'
	    #Name
	    named_attribute_1.inputs[0].default_value = "rest_position"
	
	    #node Reroute
	    reroute_2 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_2.name = "Reroute"
	    reroute_2.socket_idname = "NodeSocketGeometry"
	    #node Group Input.005
	    group_input_005_1 = attach_hair_curves_to_surface.nodes.new("NodeGroupInput")
	    group_input_005_1.name = "Group Input.005"
	    group_input_005_1.outputs[0].hide = True
	    group_input_005_1.outputs[1].hide = True
	    group_input_005_1.outputs[2].hide = True
	    group_input_005_1.outputs[3].hide = True
	    group_input_005_1.outputs[5].hide = True
	    group_input_005_1.outputs[6].hide = True
	    group_input_005_1.outputs[7].hide = True
	    group_input_005_1.outputs[8].hide = True
	    group_input_005_1.outputs[9].hide = True
	
	    #node Set Position
	    set_position_3 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSetPosition")
	    set_position_3.name = "Set Position"
	    set_position_3.inputs[3].hide = True
	    #Offset
	    set_position_3.inputs[3].default_value = (0.0, 0.0, 0.0)
	
	    #node Switch.007
	    switch_007 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSwitch")
	    switch_007.name = "Switch.007"
	    switch_007.input_type = 'GEOMETRY'
	
	    #node Reroute.015
	    reroute_015_1 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_015_1.name = "Reroute.015"
	    reroute_015_1.socket_idname = "NodeSocketBool"
	    #node Reroute.011
	    reroute_011 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_011.name = "Reroute.011"
	    reroute_011.socket_idname = "NodeSocketGeometry"
	    #node Group Input
	    group_input_4 = attach_hair_curves_to_surface.nodes.new("NodeGroupInput")
	    group_input_4.name = "Group Input"
	    group_input_4.outputs[1].hide = True
	    group_input_4.outputs[2].hide = True
	    group_input_4.outputs[3].hide = True
	    group_input_4.outputs[4].hide = True
	    group_input_4.outputs[5].hide = True
	    group_input_4.outputs[6].hide = True
	    group_input_4.outputs[7].hide = True
	    group_input_4.outputs[8].hide = True
	    group_input_4.outputs[9].hide = True
	
	    #node Capture Attribute.002
	    capture_attribute_002_1 = attach_hair_curves_to_surface.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_002_1.name = "Capture Attribute.002"
	    capture_attribute_002_1.active_index = 0
	    capture_attribute_002_1.capture_items.clear()
	    capture_attribute_002_1.capture_items.new('FLOAT', "Value")
	    capture_attribute_002_1.capture_items["Value"].data_type = 'FLOAT_VECTOR'
	    capture_attribute_002_1.domain = 'CURVE'
	
	    #node Reroute.001
	    reroute_001_2 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_001_2.name = "Reroute.001"
	    reroute_001_2.socket_idname = "NodeSocketGeometry"
	    #node Sample Nearest Surface
	    sample_nearest_surface = attach_hair_curves_to_surface.nodes.new("GeometryNodeSampleNearestSurface")
	    sample_nearest_surface.name = "Sample Nearest Surface"
	    sample_nearest_surface.data_type = 'FLOAT_VECTOR'
	    #Group ID
	    sample_nearest_surface.inputs[2].default_value = 0
	    #Sample Group ID
	    sample_nearest_surface.inputs[4].default_value = 0
	
	    #node Group
	    group_3 = attach_hair_curves_to_surface.nodes.new("GeometryNodeGroup")
	    group_3.name = "Group"
	    group_3.node_tree = curve_root_002
	    group_3.outputs[0].hide = True
	    group_3.outputs[2].hide = True
	    group_3.outputs[3].hide = True
	
	    #node Group Input.001
	    group_input_001_3 = attach_hair_curves_to_surface.nodes.new("NodeGroupInput")
	    group_input_001_3.name = "Group Input.001"
	    group_input_001_3.outputs[0].hide = True
	    group_input_001_3.outputs[1].hide = True
	    group_input_001_3.outputs[2].hide = True
	    group_input_001_3.outputs[4].hide = True
	    group_input_001_3.outputs[5].hide = True
	    group_input_001_3.outputs[6].hide = True
	    group_input_001_3.outputs[7].hide = True
	    group_input_001_3.outputs[8].hide = True
	    group_input_001_3.outputs[9].hide = True
	
	    #node Reroute.020
	    reroute_020_1 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_020_1.name = "Reroute.020"
	    reroute_020_1.socket_idname = "NodeSocketGeometry"
	    #node Normal
	    normal_1 = attach_hair_curves_to_surface.nodes.new("GeometryNodeInputNormal")
	    normal_1.name = "Normal"
	    normal_1.legacy_corner_normals = True
	
	    #node Capture Attribute
	    capture_attribute_1 = attach_hair_curves_to_surface.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_1.name = "Capture Attribute"
	    capture_attribute_1.hide = True
	    capture_attribute_1.active_index = 0
	    capture_attribute_1.capture_items.clear()
	    capture_attribute_1.capture_items.new('FLOAT', "Value")
	    capture_attribute_1.capture_items["Value"].data_type = 'FLOAT_VECTOR'
	    capture_attribute_1.domain = 'POINT'
	
	    #node Sample UV Surface
	    sample_uv_surface = attach_hair_curves_to_surface.nodes.new("GeometryNodeSampleUVSurface")
	    sample_uv_surface.name = "Sample UV Surface"
	    sample_uv_surface.hide = True
	    sample_uv_surface.data_type = 'FLOAT_VECTOR'
	    sample_uv_surface.outputs[1].hide = True
	
	    #node Sample UV Surface.003
	    sample_uv_surface_003 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSampleUVSurface")
	    sample_uv_surface_003.name = "Sample UV Surface.003"
	    sample_uv_surface_003.hide = True
	    sample_uv_surface_003.data_type = 'FLOAT_VECTOR'
	    sample_uv_surface_003.outputs[1].hide = True
	
	    #node Reroute.004
	    reroute_004_1 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_004_1.name = "Reroute.004"
	    reroute_004_1.socket_idname = "NodeSocketVector"
	    #node Sample UV Surface.001
	    sample_uv_surface_001 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSampleUVSurface")
	    sample_uv_surface_001.name = "Sample UV Surface.001"
	    sample_uv_surface_001.hide = True
	    sample_uv_surface_001.data_type = 'FLOAT_VECTOR'
	    sample_uv_surface_001.outputs[1].hide = True
	
	    #node Group.001
	    group_001_2 = attach_hair_curves_to_surface.nodes.new("GeometryNodeGroup")
	    group_001_2.name = "Group.001"
	    group_001_2.node_tree = curve_root_002
	    group_001_2.outputs[0].hide = True
	    group_001_2.outputs[2].hide = True
	    group_001_2.outputs[3].hide = True
	
	    #node Position.001
	    position_001_2 = attach_hair_curves_to_surface.nodes.new("GeometryNodeInputPosition")
	    position_001_2.name = "Position.001"
	
	    #node Vector Math
	    vector_math_3 = attach_hair_curves_to_surface.nodes.new("ShaderNodeVectorMath")
	    vector_math_3.name = "Vector Math"
	    vector_math_3.operation = 'SUBTRACT'
	
	    #node Vector Math.001
	    vector_math_001_3 = attach_hair_curves_to_surface.nodes.new("ShaderNodeVectorMath")
	    vector_math_001_3.name = "Vector Math.001"
	    vector_math_001_3.operation = 'SUBTRACT'
	
	    #node Vector Math.004
	    vector_math_004_3 = attach_hair_curves_to_surface.nodes.new("ShaderNodeVectorMath")
	    vector_math_004_3.name = "Vector Math.004"
	    vector_math_004_3.operation = 'SUBTRACT'
	
	    #node Vector Math.003
	    vector_math_003_3 = attach_hair_curves_to_surface.nodes.new("ShaderNodeVectorMath")
	    vector_math_003_3.name = "Vector Math.003"
	    vector_math_003_3.operation = 'SUBTRACT'
	
	    #node Group Input.003
	    group_input_003_1 = attach_hair_curves_to_surface.nodes.new("NodeGroupInput")
	    group_input_003_1.name = "Group Input.003"
	    group_input_003_1.outputs[0].hide = True
	    group_input_003_1.outputs[1].hide = True
	    group_input_003_1.outputs[2].hide = True
	    group_input_003_1.outputs[3].hide = True
	    group_input_003_1.outputs[4].hide = True
	    group_input_003_1.outputs[5].hide = True
	    group_input_003_1.outputs[6].hide = True
	    group_input_003_1.outputs[8].hide = True
	    group_input_003_1.outputs[9].hide = True
	
	    #node Group Input.006
	    group_input_006_1 = attach_hair_curves_to_surface.nodes.new("NodeGroupInput")
	    group_input_006_1.name = "Group Input.006"
	    group_input_006_1.outputs[0].hide = True
	    group_input_006_1.outputs[1].hide = True
	    group_input_006_1.outputs[2].hide = True
	    group_input_006_1.outputs[3].hide = True
	    group_input_006_1.outputs[4].hide = True
	    group_input_006_1.outputs[5].hide = True
	    group_input_006_1.outputs[7].hide = True
	    group_input_006_1.outputs[8].hide = True
	    group_input_006_1.outputs[9].hide = True
	
	    #node Switch.003
	    switch_003_1 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSwitch")
	    switch_003_1.name = "Switch.003"
	    switch_003_1.hide = True
	    switch_003_1.input_type = 'VECTOR'
	    #False
	    switch_003_1.inputs[1].default_value = (0.0, 0.0, 0.0)
	
	    #node Switch.002
	    switch_002_1 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSwitch")
	    switch_002_1.name = "Switch.002"
	    switch_002_1.input_type = 'VECTOR'
	
	    #node Vector Math.002
	    vector_math_002_3 = attach_hair_curves_to_surface.nodes.new("ShaderNodeVectorMath")
	    vector_math_002_3.name = "Vector Math.002"
	    vector_math_002_3.operation = 'ADD'
	
	    #node Vector Math.005
	    vector_math_005_3 = attach_hair_curves_to_surface.nodes.new("ShaderNodeVectorMath")
	    vector_math_005_3.name = "Vector Math.005"
	    vector_math_005_3.operation = 'SCALE'
	
	    #node Boolean Math
	    boolean_math = attach_hair_curves_to_surface.nodes.new("FunctionNodeBooleanMath")
	    boolean_math.name = "Boolean Math"
	    boolean_math.operation = 'OR'
	
	    #node Spline Parameter
	    spline_parameter = attach_hair_curves_to_surface.nodes.new("GeometryNodeSplineParameter")
	    spline_parameter.name = "Spline Parameter"
	    spline_parameter.outputs[1].hide = True
	    spline_parameter.outputs[2].hide = True
	
	    #node Group Input.008
	    group_input_008 = attach_hair_curves_to_surface.nodes.new("NodeGroupInput")
	    group_input_008.name = "Group Input.008"
	    group_input_008.outputs[0].hide = True
	    group_input_008.outputs[1].hide = True
	    group_input_008.outputs[2].hide = True
	    group_input_008.outputs[3].hide = True
	    group_input_008.outputs[4].hide = True
	    group_input_008.outputs[5].hide = True
	    group_input_008.outputs[6].hide = True
	    group_input_008.outputs[7].hide = True
	    group_input_008.outputs[9].hide = True
	
	    #node Map Range
	    map_range_1 = attach_hair_curves_to_surface.nodes.new("ShaderNodeMapRange")
	    map_range_1.name = "Map Range"
	    map_range_1.hide = True
	    map_range_1.clamp = True
	    map_range_1.data_type = 'FLOAT'
	    map_range_1.interpolation_type = 'SMOOTHSTEP'
	    #From Min
	    map_range_1.inputs[1].default_value = 0.0
	    #To Min
	    map_range_1.inputs[3].default_value = 1.0
	    #To Max
	    map_range_1.inputs[4].default_value = 0.0
	
	    #node Compare
	    compare_2 = attach_hair_curves_to_surface.nodes.new("FunctionNodeCompare")
	    compare_2.name = "Compare"
	    compare_2.data_type = 'FLOAT'
	    compare_2.mode = 'ELEMENT'
	    compare_2.operation = 'EQUAL'
	    #B
	    compare_2.inputs[1].default_value = 0.0
	    #Epsilon
	    compare_2.inputs[12].default_value = 0.0
	
	    #node Switch.004
	    switch_004_1 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSwitch")
	    switch_004_1.name = "Switch.004"
	    switch_004_1.input_type = 'FLOAT'
	    #True
	    switch_004_1.inputs[2].default_value = 1.0
	
	    #node Position.002
	    position_002_3 = attach_hair_curves_to_surface.nodes.new("GeometryNodeInputPosition")
	    position_002_3.name = "Position.002"
	
	    #node Evaluate on Domain
	    evaluate_on_domain_1 = attach_hair_curves_to_surface.nodes.new("GeometryNodeFieldOnDomain")
	    evaluate_on_domain_1.name = "Evaluate on Domain"
	    evaluate_on_domain_1.data_type = 'FLOAT_VECTOR'
	    evaluate_on_domain_1.domain = 'CURVE'
	
	    #node Reroute.009
	    reroute_009 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_009.name = "Reroute.009"
	    reroute_009.socket_idname = "NodeSocketVector"
	    #node Evaluate on Domain.002
	    evaluate_on_domain_002_2 = attach_hair_curves_to_surface.nodes.new("GeometryNodeFieldOnDomain")
	    evaluate_on_domain_002_2.name = "Evaluate on Domain.002"
	    evaluate_on_domain_002_2.hide = True
	    evaluate_on_domain_002_2.data_type = 'FLOAT_VECTOR'
	    evaluate_on_domain_002_2.domain = 'CURVE'
	
	    #node Switch.006
	    switch_006 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSwitch")
	    switch_006.name = "Switch.006"
	    switch_006.input_type = 'VECTOR'
	
	    #node Vector Rotate
	    vector_rotate_1 = attach_hair_curves_to_surface.nodes.new("ShaderNodeVectorRotate")
	    vector_rotate_1.name = "Vector Rotate"
	    vector_rotate_1.invert = False
	    vector_rotate_1.rotation_type = 'EULER_XYZ'
	    vector_rotate_1.inputs[1].hide = True
	    vector_rotate_1.inputs[2].hide = True
	    vector_rotate_1.inputs[3].hide = True
	    #Center
	    vector_rotate_1.inputs[1].default_value = (0.0, 0.0, 0.0)
	
	    #node Vector Rotate.003
	    vector_rotate_003 = attach_hair_curves_to_surface.nodes.new("ShaderNodeVectorRotate")
	    vector_rotate_003.name = "Vector Rotate.003"
	    vector_rotate_003.invert = True
	    vector_rotate_003.rotation_type = 'EULER_XYZ'
	    vector_rotate_003.inputs[1].hide = True
	    vector_rotate_003.inputs[2].hide = True
	    vector_rotate_003.inputs[3].hide = True
	    #Center
	    vector_rotate_003.inputs[1].default_value = (0.0, 0.0, 0.0)
	
	    #node Align Euler to Vector.003
	    align_euler_to_vector_003 = attach_hair_curves_to_surface.nodes.new("FunctionNodeAlignEulerToVector")
	    align_euler_to_vector_003.name = "Align Euler to Vector.003"
	    align_euler_to_vector_003.axis = 'Z'
	    align_euler_to_vector_003.pivot_axis = 'AUTO'
	    align_euler_to_vector_003.inputs[0].hide = True
	    align_euler_to_vector_003.inputs[1].hide = True
	    #Rotation
	    align_euler_to_vector_003.inputs[0].default_value = (0.0, 0.0, 0.0)
	    #Factor
	    align_euler_to_vector_003.inputs[1].default_value = 1.0
	
	    #node Align Euler to Vector.002
	    align_euler_to_vector_002 = attach_hair_curves_to_surface.nodes.new("FunctionNodeAlignEulerToVector")
	    align_euler_to_vector_002.name = "Align Euler to Vector.002"
	    align_euler_to_vector_002.axis = 'Z'
	    align_euler_to_vector_002.pivot_axis = 'AUTO'
	    align_euler_to_vector_002.inputs[0].hide = True
	    align_euler_to_vector_002.inputs[1].hide = True
	    #Rotation
	    align_euler_to_vector_002.inputs[0].default_value = (0.0, 0.0, 0.0)
	    #Factor
	    align_euler_to_vector_002.inputs[1].default_value = 1.0
	
	    #node Evaluate on Domain.003
	    evaluate_on_domain_003 = attach_hair_curves_to_surface.nodes.new("GeometryNodeFieldOnDomain")
	    evaluate_on_domain_003.name = "Evaluate on Domain.003"
	    evaluate_on_domain_003.hide = True
	    evaluate_on_domain_003.data_type = 'FLOAT_VECTOR'
	    evaluate_on_domain_003.domain = 'CURVE'
	
	    #node Switch.001
	    switch_001_3 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSwitch")
	    switch_001_3.name = "Switch.001"
	    switch_001_3.hide = True
	    switch_001_3.input_type = 'VECTOR'
	
	    #node Accumulate Field
	    accumulate_field = attach_hair_curves_to_surface.nodes.new("GeometryNodeAccumulateField")
	    accumulate_field.name = "Accumulate Field"
	    accumulate_field.hide = True
	    accumulate_field.data_type = 'FLOAT'
	    accumulate_field.domain = 'POINT'
	    #Group Index
	    accumulate_field.inputs[1].default_value = 0
	
	    #node Sample Index.001
	    sample_index_001 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSampleIndex")
	    sample_index_001.name = "Sample Index.001"
	    sample_index_001.hide = True
	    sample_index_001.clamp = False
	    sample_index_001.data_type = 'BOOLEAN'
	    sample_index_001.domain = 'CURVE'
	    #Index
	    sample_index_001.inputs[2].default_value = 0
	
	    #node Reroute.019
	    reroute_019_1 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_019_1.name = "Reroute.019"
	    reroute_019_1.socket_idname = "NodeSocketVector"
	    #node Named Attribute.002
	    named_attribute_002 = attach_hair_curves_to_surface.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute_002.name = "Named Attribute.002"
	    named_attribute_002.data_type = 'INT'
	    #Name
	    named_attribute_002.inputs[0].default_value = "guide_curve_index"
	
	    #node Reroute.007
	    reroute_007 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_007.name = "Reroute.007"
	    reroute_007.socket_idname = "NodeSocketGeometry"
	    #node Reroute.008
	    reroute_008 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_008.name = "Reroute.008"
	    reroute_008.socket_idname = "NodeSocketVector"
	    #node Sample Index
	    sample_index = attach_hair_curves_to_surface.nodes.new("GeometryNodeSampleIndex")
	    sample_index.name = "Sample Index"
	    sample_index.hide = True
	    sample_index.clamp = False
	    sample_index.data_type = 'FLOAT_VECTOR'
	    sample_index.domain = 'CURVE'
	
	
	
	
	    #Set parents
	    frame_006.parent = frame_3
	    frame_007.parent = frame_3
	    frame_003_2.parent = frame_010
	    frame_002_2.parent = frame_010
	    frame_008.parent = frame_002_2
	    frame_009.parent = frame_002_2
	    reroute_003_2.parent = frame_004_1
	    switch_3.parent = frame_004_1
	    store_named_attribute_1.parent = frame_004_1
	    group_input_007_1.parent = frame_004_1
	    reroute_016_1.parent = frame_004_1
	    reroute_005.parent = frame_004_1
	    store_named_attribute_001.parent = frame_004_1
	    named_attribute_004.parent = frame_004_1
	    reroute_012_1.parent = frame_004_1
	    named_attribute_003.parent = frame_004_1
	    switch_008.parent = frame_004_1
	    switch_009.parent = frame_004_1
	    switch_010.parent = frame_004_1
	    reroute_002_2.parent = frame_005
	    reroute_018_1.parent = frame_005
	    reroute_017_1.parent = frame_005
	    group_input_009.parent = frame_005
	    position_2.parent = frame_005
	    named_attribute_001.parent = frame_005
	    group_input_004_1.parent = frame_006
	    domain_size_002.parent = frame_006
	    compare_001_1.parent = frame_006
	    object_info_001.parent = frame_007
	    group_input_002_3.parent = frame_007
	    switch_005_1.parent = frame_3
	    domain_size_003.parent = frame_3
	    compare_002_2.parent = frame_3
	    named_attribute_1.parent = frame_3
	    reroute_2.parent = frame_3
	    group_input_005_1.parent = frame_3
	    set_position_3.parent = frame_3
	    switch_007.parent = frame_3
	    sample_nearest_surface.parent = frame_011
	    group_3.parent = frame_011
	    group_input_001_3.parent = frame_011
	    normal_1.parent = frame_001_2
	    capture_attribute_1.parent = frame_001_2
	    sample_uv_surface.parent = frame_005
	    sample_uv_surface_003.parent = frame_005
	    reroute_004_1.parent = frame_005
	    sample_uv_surface_001.parent = frame_005
	    group_001_2.parent = frame_010
	    position_001_2.parent = frame_010
	    vector_math_3.parent = frame_010
	    vector_math_001_3.parent = frame_010
	    vector_math_004_3.parent = frame_010
	    vector_math_003_3.parent = frame_010
	    group_input_003_1.parent = frame_010
	    group_input_006_1.parent = frame_010
	    switch_003_1.parent = frame_010
	    switch_002_1.parent = frame_010
	    vector_math_002_3.parent = frame_010
	    vector_math_005_3.parent = frame_010
	    boolean_math.parent = frame_010
	    spline_parameter.parent = frame_003_2
	    group_input_008.parent = frame_003_2
	    map_range_1.parent = frame_003_2
	    compare_2.parent = frame_003_2
	    switch_004_1.parent = frame_003_2
	    position_002_3.parent = frame_010
	    evaluate_on_domain_1.parent = frame_010
	    reroute_009.parent = frame_002_2
	    evaluate_on_domain_002_2.parent = frame_002_2
	    switch_006.parent = frame_002_2
	    vector_rotate_1.parent = frame_002_2
	    vector_rotate_003.parent = frame_002_2
	    align_euler_to_vector_003.parent = frame_002_2
	    align_euler_to_vector_002.parent = frame_002_2
	    evaluate_on_domain_003.parent = frame_002_2
	    switch_001_3.parent = frame_008
	    accumulate_field.parent = frame_008
	    sample_index_001.parent = frame_008
	    reroute_019_1.parent = frame_002_2
	    named_attribute_002.parent = frame_009
	    reroute_007.parent = frame_009
	    reroute_008.parent = frame_009
	    sample_index.parent = frame_009
	
	    #Set locations
	    frame_004_1.location = (-1215.903076171875, 262.0)
	    frame_005.location = (-4968.0, -121.0)
	    frame_3.location = (-7319.0, 140.0)
	    frame_006.location = (30.0, -355.0)
	    frame_007.location = (207.0, -181.0)
	    frame_011.location = (-5752.0, 120.0)
	    frame_001_2.location = (-5510.0, -382.0)
	    frame_010.location = (-4110.3515625, 32.0)
	    frame_003_2.location = (1565.3515625, -503.0)
	    frame_002_2.location = (29.999755859375, -437.0)
	    frame_008.location = (219.351806640625, -40.0)
	    frame_009.location = (30.0, -217.5032958984375)
	    reroute_010.location = (-798.60986328125, 472.99615478515625)
	    reroute_013_1.location = (-789.0, 512.1389770507812)
	    group_output_9.location = (75.0, 50.0)
	    reroute_003_2.location = (35.0, -292.3721618652344)
	    switch_3.location = (320.95263671875, -40.143096923828125)
	    store_named_attribute_1.location = (115.3720703125, -151.72100830078125)
	    group_input_007_1.location = (122.9049072265625, -39.53450012207031)
	    reroute_016_1.location = (45.1358642578125, -151.72100830078125)
	    reroute_005.location = (406.810302734375, -272.2791442871094)
	    store_named_attribute_001.location = (527.368408203125, -51.255889892578125)
	    named_attribute_004.location = (607.740478515625, -513.3954467773438)
	    reroute_012_1.location = (768.484619140625, -252.18612670898438)
	    reroute_014_1.location = (-507.69775390625, 311.209228515625)
	    reroute_006.location = (-547.8837890625, 291.1162109375)
	    named_attribute_003.location = (607.740478515625, -352.6512451171875)
	    switch_008.location = (808.670654296875, -71.34890747070312)
	    switch_009.location = (808.670654296875, -212.00006103515625)
	    switch_010.location = (808.670654296875, -392.8372802734375)
	    set_position_001_3.location = (-1472.16259765625, 230.837158203125)
	    reroute_002_2.location = (220.65625, -190.25262451171875)
	    reroute_018_1.location = (220.65625, -150.06658935546875)
	    reroute_017_1.location = (220.65625, -109.88055419921875)
	    group_input_009.location = (29.99072265625, -180.322021484375)
	    position_2.location = (29.99072265625, -39.67083740234375)
	    named_attribute_001.location = (29.99072265625, -260.694091796875)
	    capture_attribute_001_1.location = (-4365.55810546875, 210.744140625)
	    group_input_004_1.location = (29.669921875, -178.9044189453125)
	    domain_size_002.location = (207.6806640625, -80.07354736328125)
	    compare_001_1.location = (388.517578125, -39.88751220703125)
	    object_info_001.location = (210.88330078125, -39.64691162109375)
	    group_input_002_3.location = (30.0458984375, -79.83294677734375)
	    switch_005_1.location = (640.525390625, -283.5823974609375)
	    domain_size_003.location = (938.8193359375, -79.91128540039062)
	    compare_002_2.location = (1119.65625, -39.725250244140625)
	    named_attribute_1.location = (820.7041015625, -432.90301513671875)
	    reroute_2.location = (961.35546875, -332.43792724609375)
	    group_input_005_1.location = (1021.63427734375, -252.0657958984375)
	    set_position_3.location = (1021.63427734375, -352.53094482421875)
	    switch_007.location = (1222.564453125, -231.9727783203125)
	    reroute_015_1.location = (-5129.0927734375, 532.2319946289062)
	    reroute_011.location = (-5109.0, 492.04595947265625)
	    group_input_4.location = (-5510.8603515625, 351.395263671875)
	    capture_attribute_002_1.location = (-5209.46484375, 230.837158203125)
	    reroute_001_2.location = (-4887.9765625, -653.2559814453125)
	    sample_nearest_surface.location = (210.7509765625, -40.199798583984375)
	    group_3.location = (29.9140625, -180.85098266601562)
	    group_input_001_3.location = (29.9140625, -100.4788818359375)
	    reroute_020_1.location = (-4526.30224609375, -10.2791748046875)
	    normal_1.location = (29.5712890625, -45.01953125)
	    capture_attribute_1.location = (230.50146484375, -45.01953125)
	    sample_uv_surface.location = (321.1396484375, -50.02386474609375)
	    sample_uv_surface_003.location = (321.1396484375, -130.39593505859375)
	    reroute_004_1.location = (220.6748046875, -230.86102294921875)
	    sample_uv_surface_001.location = (321.1396484375, -210.76800537109375)
	    group_001_2.location = (158.627685546875, -240.71258544921875)
	    position_001_2.location = (339.46484375, -321.08465576171875)
	    vector_math_3.location = (339.46484375, -140.2474365234375)
	    vector_math_001_3.location = (540.39501953125, -321.08465576171875)
	    vector_math_004_3.location = (1826.3486328125, -341.17767333984375)
	    vector_math_003_3.location = (2027.27880859375, -200.52651977539062)
	    group_input_003_1.location = (1424.48828125, -220.79666137695312)
	    group_input_006_1.location = (1424.48828125, -100.238525390625)
	    switch_003_1.location = (1625.41845703125, -180.61062622070312)
	    switch_002_1.location = (1625.41845703125, -220.79666137695312)
	    vector_math_002_3.location = (1826.3486328125, -140.424560546875)
	    vector_math_005_3.location = (2248.30224609375, -200.70364379882812)
	    boolean_math.location = (1625.41845703125, -39.959442138671875)
	    spline_parameter.location = (32.72265625, -81.9400634765625)
	    group_input_008.location = (30.322265625, -161.4296875)
	    map_range_1.location = (205.259765625, -190.3057861328125)
	    compare_2.location = (205.20068359375, -39.6795654296875)
	    switch_004_1.location = (386.037841796875, -59.772705078125)
	    position_002_3.location = (1625.41845703125, -371.6761474609375)
	    evaluate_on_domain_1.location = (531.248291015625, -115.30325317382812)
	    reroute_009.location = (731.747802734375, -64.921875)
	    evaluate_on_domain_002_2.location = (630.95361328125, -265.85211181640625)
	    switch_006.location = (992.6279296875, -64.921875)
	    vector_rotate_1.location = (1173.465087890625, -64.921875)
	    vector_rotate_003.location = (811.790771484375, -165.386962890625)
	    align_euler_to_vector_003.location = (630.95361328125, -165.386962890625)
	    align_euler_to_vector_002.location = (630.95361328125, -306.0382080078125)
	    evaluate_on_domain_003.location = (630.95361328125, -406.5032958984375)
	    switch_001_3.location = (210.67138671875, -105.2939453125)
	    accumulate_field.location = (29.834228515625, -45.014892578125)
	    sample_index_001.location = (29.834228515625, -85.200927734375)
	    reroute_019_1.location = (48.255859375, -185.48004150390625)
	    named_attribute_002.location = (35.0, -105.279052734375)
	    reroute_007.location = (35.0, -45.0)
	    reroute_008.location = (35.0, -85.18603515625)
	    sample_index.location = (215.837158203125, -65.093017578125)
	
	    #Set dimensions
	    frame_004_1.width, frame_004_1.height = 978.903076171875, 664.0
	    frame_005.width, frame_005.height = 491.0, 412.0
	    frame_3.width, frame_3.height = 1393.0, 646.0
	    frame_006.width, frame_006.height = 559.0, 261.0
	    frame_007.width, frame_007.height = 381.0, 215.0
	    frame_011.width, frame_011.height = 390.33642578125, 279.0
	    frame_001_2.width, frame_001_2.height = 401.0, 125.0
	    frame_010.width, frame_010.height = 2418.3515625, 971.0
	    frame_003_2.width, frame_003_2.height = 556.0, 250.0
	    frame_002_2.width, frame_002_2.height = 1343.351806640625, 504.0
	    frame_008.width, frame_008.height = 381.0, 160.0
	    frame_009.width, frame_009.height = 385.351806640625, 256.4967041015625
	    reroute_010.width, reroute_010.height = 100.0, 100.0
	    reroute_013_1.width, reroute_013_1.height = 100.0, 100.0
	    group_output_9.width, group_output_9.height = 140.0, 100.0
	    reroute_003_2.width, reroute_003_2.height = 100.0, 100.0
	    switch_3.width, switch_3.height = 140.0, 100.0
	    store_named_attribute_1.width, store_named_attribute_1.height = 140.0, 100.0
	    group_input_007_1.width, group_input_007_1.height = 140.0, 100.0
	    reroute_016_1.width, reroute_016_1.height = 100.0, 100.0
	    reroute_005.width, reroute_005.height = 100.0, 100.0
	    store_named_attribute_001.width, store_named_attribute_001.height = 140.0, 100.0
	    named_attribute_004.width, named_attribute_004.height = 140.0, 100.0
	    reroute_012_1.width, reroute_012_1.height = 100.0, 100.0
	    reroute_014_1.width, reroute_014_1.height = 100.0, 100.0
	    reroute_006.width, reroute_006.height = 100.0, 100.0
	    named_attribute_003.width, named_attribute_003.height = 140.0, 100.0
	    switch_008.width, switch_008.height = 140.0, 100.0
	    switch_009.width, switch_009.height = 140.0, 100.0
	    switch_010.width, switch_010.height = 140.0, 100.0
	    set_position_001_3.width, set_position_001_3.height = 140.0, 100.0
	    reroute_002_2.width, reroute_002_2.height = 100.0, 100.0
	    reroute_018_1.width, reroute_018_1.height = 100.0, 100.0
	    reroute_017_1.width, reroute_017_1.height = 100.0, 100.0
	    group_input_009.width, group_input_009.height = 140.0, 100.0
	    position_2.width, position_2.height = 140.0, 100.0
	    named_attribute_001.width, named_attribute_001.height = 140.0, 100.0
	    capture_attribute_001_1.width, capture_attribute_001_1.height = 140.0, 100.0
	    group_input_004_1.width, group_input_004_1.height = 140.0, 100.0
	    domain_size_002.width, domain_size_002.height = 140.0, 100.0
	    compare_001_1.width, compare_001_1.height = 140.0, 100.0
	    object_info_001.width, object_info_001.height = 140.0, 100.0
	    group_input_002_3.width, group_input_002_3.height = 140.0, 100.0
	    switch_005_1.width, switch_005_1.height = 140.0, 100.0
	    domain_size_003.width, domain_size_003.height = 140.0, 100.0
	    compare_002_2.width, compare_002_2.height = 140.0, 100.0
	    named_attribute_1.width, named_attribute_1.height = 140.0, 100.0
	    reroute_2.width, reroute_2.height = 100.0, 100.0
	    group_input_005_1.width, group_input_005_1.height = 140.0, 100.0
	    set_position_3.width, set_position_3.height = 140.0, 100.0
	    switch_007.width, switch_007.height = 140.0, 100.0
	    reroute_015_1.width, reroute_015_1.height = 100.0, 100.0
	    reroute_011.width, reroute_011.height = 100.0, 100.0
	    group_input_4.width, group_input_4.height = 140.0, 100.0
	    capture_attribute_002_1.width, capture_attribute_002_1.height = 140.0, 100.0
	    reroute_001_2.width, reroute_001_2.height = 100.0, 100.0
	    sample_nearest_surface.width, sample_nearest_surface.height = 149.33627319335938, 100.0
	    group_3.width, group_3.height = 140.0, 100.0
	    group_input_001_3.width, group_input_001_3.height = 140.0, 100.0
	    reroute_020_1.width, reroute_020_1.height = 100.0, 100.0
	    normal_1.width, normal_1.height = 140.0, 100.0
	    capture_attribute_1.width, capture_attribute_1.height = 140.0, 100.0
	    sample_uv_surface.width, sample_uv_surface.height = 140.0, 100.0
	    sample_uv_surface_003.width, sample_uv_surface_003.height = 140.0, 100.0
	    reroute_004_1.width, reroute_004_1.height = 100.0, 100.0
	    sample_uv_surface_001.width, sample_uv_surface_001.height = 140.0, 100.0
	    group_001_2.width, group_001_2.height = 140.0, 100.0
	    position_001_2.width, position_001_2.height = 140.0, 100.0
	    vector_math_3.width, vector_math_3.height = 140.0, 100.0
	    vector_math_001_3.width, vector_math_001_3.height = 140.0, 100.0
	    vector_math_004_3.width, vector_math_004_3.height = 140.0, 100.0
	    vector_math_003_3.width, vector_math_003_3.height = 140.0, 100.0
	    group_input_003_1.width, group_input_003_1.height = 140.0, 100.0
	    group_input_006_1.width, group_input_006_1.height = 140.0, 100.0
	    switch_003_1.width, switch_003_1.height = 140.0, 100.0
	    switch_002_1.width, switch_002_1.height = 140.0, 100.0
	    vector_math_002_3.width, vector_math_002_3.height = 140.0, 100.0
	    vector_math_005_3.width, vector_math_005_3.height = 140.0, 100.0
	    boolean_math.width, boolean_math.height = 140.0, 100.0
	    spline_parameter.width, spline_parameter.height = 140.0, 100.0
	    group_input_008.width, group_input_008.height = 140.0, 100.0
	    map_range_1.width, map_range_1.height = 140.0, 100.0
	    compare_2.width, compare_2.height = 140.0, 100.0
	    switch_004_1.width, switch_004_1.height = 140.0, 100.0
	    position_002_3.width, position_002_3.height = 140.0, 100.0
	    evaluate_on_domain_1.width, evaluate_on_domain_1.height = 140.0, 100.0
	    reroute_009.width, reroute_009.height = 100.0, 100.0
	    evaluate_on_domain_002_2.width, evaluate_on_domain_002_2.height = 140.0, 100.0
	    switch_006.width, switch_006.height = 140.0, 100.0
	    vector_rotate_1.width, vector_rotate_1.height = 140.0, 100.0
	    vector_rotate_003.width, vector_rotate_003.height = 140.0, 100.0
	    align_euler_to_vector_003.width, align_euler_to_vector_003.height = 140.0, 100.0
	    align_euler_to_vector_002.width, align_euler_to_vector_002.height = 140.0, 100.0
	    evaluate_on_domain_003.width, evaluate_on_domain_003.height = 140.0, 100.0
	    switch_001_3.width, switch_001_3.height = 140.0, 100.0
	    accumulate_field.width, accumulate_field.height = 140.0, 100.0
	    sample_index_001.width, sample_index_001.height = 140.0, 100.0
	    reroute_019_1.width, reroute_019_1.height = 100.0, 100.0
	    named_attribute_002.width, named_attribute_002.height = 140.0, 100.0
	    reroute_007.width, reroute_007.height = 100.0, 100.0
	    reroute_008.width, reroute_008.height = 100.0, 100.0
	    sample_index.width, sample_index.height = 140.0, 100.0
	
	    #initialize attach_hair_curves_to_surface links
	    #domain_size_002.Face Count -> compare_001_1.A
	    attach_hair_curves_to_surface.links.new(domain_size_002.outputs[2], compare_001_1.inputs[2])
	    #compare_001_1.Result -> switch_005_1.Switch
	    attach_hair_curves_to_surface.links.new(compare_001_1.outputs[0], switch_005_1.inputs[0])
	    #group_input_002_3.Surface -> object_info_001.Object
	    attach_hair_curves_to_surface.links.new(group_input_002_3.outputs[2], object_info_001.inputs[0])
	    #group_input_004_1.Surface -> domain_size_002.Geometry
	    attach_hair_curves_to_surface.links.new(group_input_004_1.outputs[1], domain_size_002.inputs[0])
	    #group_input_004_1.Surface -> switch_005_1.True
	    attach_hair_curves_to_surface.links.new(group_input_004_1.outputs[1], switch_005_1.inputs[2])
	    #group_input_001_3.Surface UV Map -> sample_nearest_surface.Value
	    attach_hair_curves_to_surface.links.new(group_input_001_3.outputs[3], sample_nearest_surface.inputs[1])
	    #reroute_2.Output -> set_position_3.Geometry
	    attach_hair_curves_to_surface.links.new(reroute_2.outputs[0], set_position_3.inputs[0])
	    #reroute_2.Output -> switch_007.False
	    attach_hair_curves_to_surface.links.new(reroute_2.outputs[0], switch_007.inputs[1])
	    #set_position_3.Geometry -> switch_007.True
	    attach_hair_curves_to_surface.links.new(set_position_3.outputs[0], switch_007.inputs[2])
	    #switch_005_1.Output -> reroute_2.Input
	    attach_hair_curves_to_surface.links.new(switch_005_1.outputs[0], reroute_2.inputs[0])
	    #group_input_005_1.Surface Rest Position -> switch_007.Switch
	    attach_hair_curves_to_surface.links.new(group_input_005_1.outputs[4], switch_007.inputs[0])
	    #named_attribute_1.Attribute -> set_position_3.Position
	    attach_hair_curves_to_surface.links.new(named_attribute_1.outputs[0], set_position_3.inputs[2])
	    #named_attribute_1.Exists -> set_position_3.Selection
	    attach_hair_curves_to_surface.links.new(named_attribute_1.outputs[1], set_position_3.inputs[1])
	    #switch_007.Output -> sample_nearest_surface.Mesh
	    attach_hair_curves_to_surface.links.new(switch_007.outputs[0], sample_nearest_surface.inputs[0])
	    #object_info_001.Geometry -> switch_005_1.False
	    attach_hair_curves_to_surface.links.new(object_info_001.outputs[4], switch_005_1.inputs[1])
	    #group_3.Root Position -> sample_nearest_surface.Sample Position
	    attach_hair_curves_to_surface.links.new(group_3.outputs[1], sample_nearest_surface.inputs[3])
	    #reroute_002_2.Output -> sample_uv_surface.UV Map
	    attach_hair_curves_to_surface.links.new(reroute_002_2.outputs[0], sample_uv_surface.inputs[2])
	    #position_2.Position -> sample_uv_surface.Value
	    attach_hair_curves_to_surface.links.new(position_2.outputs[0], sample_uv_surface.inputs[1])
	    #reroute_004_1.Output -> sample_uv_surface.Sample UV
	    attach_hair_curves_to_surface.links.new(reroute_004_1.outputs[0], sample_uv_surface.inputs[3])
	    #capture_attribute_001_1.Geometry -> set_position_001_3.Geometry
	    attach_hair_curves_to_surface.links.new(capture_attribute_001_1.outputs[0], set_position_001_3.inputs[0])
	    #reroute_017_1.Output -> sample_uv_surface_001.Mesh
	    attach_hair_curves_to_surface.links.new(reroute_017_1.outputs[0], sample_uv_surface_001.inputs[0])
	    #reroute_004_1.Output -> sample_uv_surface_001.Sample UV
	    attach_hair_curves_to_surface.links.new(reroute_004_1.outputs[0], sample_uv_surface_001.inputs[3])
	    #reroute_002_2.Output -> sample_uv_surface_001.UV Map
	    attach_hair_curves_to_surface.links.new(reroute_002_2.outputs[0], sample_uv_surface_001.inputs[2])
	    #normal_1.Normal -> capture_attribute_1.Value
	    attach_hair_curves_to_surface.links.new(normal_1.outputs[0], capture_attribute_1.inputs[1])
	    #reroute_018_1.Output -> sample_uv_surface_001.Value
	    attach_hair_curves_to_surface.links.new(reroute_018_1.outputs[0], sample_uv_surface_001.inputs[1])
	    #sample_uv_surface.Value -> vector_math_3.Vector
	    attach_hair_curves_to_surface.links.new(sample_uv_surface.outputs[0], vector_math_3.inputs[0])
	    #group_001_2.Root Position -> vector_math_3.Vector
	    attach_hair_curves_to_surface.links.new(group_001_2.outputs[1], vector_math_3.inputs[1])
	    #vector_math_3.Vector -> evaluate_on_domain_1.Value
	    attach_hair_curves_to_surface.links.new(vector_math_3.outputs[0], evaluate_on_domain_1.inputs[0])
	    #position_001_2.Position -> vector_math_001_3.Vector
	    attach_hair_curves_to_surface.links.new(position_001_2.outputs[0], vector_math_001_3.inputs[0])
	    #group_001_2.Root Position -> vector_math_001_3.Vector
	    attach_hair_curves_to_surface.links.new(group_001_2.outputs[1], vector_math_001_3.inputs[1])
	    #switch_006.Output -> vector_rotate_1.Vector
	    attach_hair_curves_to_surface.links.new(switch_006.outputs[0], vector_rotate_1.inputs[0])
	    #reroute_007.Output -> sample_index.Geometry
	    attach_hair_curves_to_surface.links.new(reroute_007.outputs[0], sample_index.inputs[0])
	    #named_attribute_002.Attribute -> sample_index.Index
	    attach_hair_curves_to_surface.links.new(named_attribute_002.outputs[0], sample_index.inputs[2])
	    #position_002_3.Position -> vector_math_004_3.Vector
	    attach_hair_curves_to_surface.links.new(position_002_3.outputs[0], vector_math_004_3.inputs[0])
	    #vector_math_002_3.Vector -> vector_math_003_3.Vector
	    attach_hair_curves_to_surface.links.new(vector_math_002_3.outputs[0], vector_math_003_3.inputs[0])
	    #switch_003_1.Output -> vector_math_002_3.Vector
	    attach_hair_curves_to_surface.links.new(switch_003_1.outputs[0], vector_math_002_3.inputs[0])
	    #switch_002_1.Output -> vector_math_002_3.Vector
	    attach_hair_curves_to_surface.links.new(switch_002_1.outputs[0], vector_math_002_3.inputs[1])
	    #reroute_009.Output -> vector_rotate_003.Vector
	    attach_hair_curves_to_surface.links.new(reroute_009.outputs[0], vector_rotate_003.inputs[0])
	    #evaluate_on_domain_002_2.Value -> vector_rotate_003.Rotation
	    attach_hair_curves_to_surface.links.new(evaluate_on_domain_002_2.outputs[0], vector_rotate_003.inputs[4])
	    #evaluate_on_domain_003.Value -> vector_rotate_1.Rotation
	    attach_hair_curves_to_surface.links.new(evaluate_on_domain_003.outputs[0], vector_rotate_1.inputs[4])
	    #group_001_2.Root Position -> vector_math_004_3.Vector
	    attach_hair_curves_to_surface.links.new(group_001_2.outputs[1], vector_math_004_3.inputs[1])
	    #vector_math_004_3.Vector -> vector_math_003_3.Vector
	    attach_hair_curves_to_surface.links.new(vector_math_004_3.outputs[0], vector_math_003_3.inputs[1])
	    #reroute_016_1.Output -> store_named_attribute_1.Geometry
	    attach_hair_curves_to_surface.links.new(reroute_016_1.outputs[0], store_named_attribute_1.inputs[0])
	    #group_input_4.Geometry -> capture_attribute_002_1.Geometry
	    attach_hair_curves_to_surface.links.new(group_input_4.outputs[0], capture_attribute_002_1.inputs[0])
	    #reroute_003_2.Output -> store_named_attribute_1.Value
	    attach_hair_curves_to_surface.links.new(reroute_003_2.outputs[0], store_named_attribute_1.inputs[3])
	    #sample_nearest_surface.Value -> capture_attribute_002_1.Value
	    attach_hair_curves_to_surface.links.new(sample_nearest_surface.outputs[0], capture_attribute_002_1.inputs[1])
	    #capture_attribute_002_1.Value -> reroute_004_1.Input
	    attach_hair_curves_to_surface.links.new(capture_attribute_002_1.outputs[1], reroute_004_1.inputs[0])
	    #switch_007.Output -> capture_attribute_1.Geometry
	    attach_hair_curves_to_surface.links.new(switch_007.outputs[0], capture_attribute_1.inputs[0])
	    #align_euler_to_vector_003.Rotation -> evaluate_on_domain_002_2.Value
	    attach_hair_curves_to_surface.links.new(align_euler_to_vector_003.outputs[0], evaluate_on_domain_002_2.inputs[0])
	    #align_euler_to_vector_002.Rotation -> evaluate_on_domain_003.Value
	    attach_hair_curves_to_surface.links.new(align_euler_to_vector_002.outputs[0], evaluate_on_domain_003.inputs[0])
	    #capture_attribute_1.Geometry -> reroute_001_2.Input
	    attach_hair_curves_to_surface.links.new(capture_attribute_1.outputs[0], reroute_001_2.inputs[0])
	    #reroute_018_1.Output -> sample_uv_surface_003.Value
	    attach_hair_curves_to_surface.links.new(reroute_018_1.outputs[0], sample_uv_surface_003.inputs[1])
	    #reroute_002_2.Output -> sample_uv_surface_003.UV Map
	    attach_hair_curves_to_surface.links.new(reroute_002_2.outputs[0], sample_uv_surface_003.inputs[2])
	    #reroute_017_1.Output -> sample_uv_surface_003.Mesh
	    attach_hair_curves_to_surface.links.new(reroute_017_1.outputs[0], sample_uv_surface_003.inputs[0])
	    #named_attribute_001.Attribute -> sample_uv_surface_003.Sample UV
	    attach_hair_curves_to_surface.links.new(named_attribute_001.outputs[0], sample_uv_surface_003.inputs[3])
	    #reroute_019_1.Output -> switch_001_3.True
	    attach_hair_curves_to_surface.links.new(reroute_019_1.outputs[0], switch_001_3.inputs[2])
	    #reroute_020_1.Output -> sample_index_001.Geometry
	    attach_hair_curves_to_surface.links.new(reroute_020_1.outputs[0], sample_index_001.inputs[0])
	    #named_attribute_001.Exists -> accumulate_field.Value
	    attach_hair_curves_to_surface.links.new(named_attribute_001.outputs[1], accumulate_field.inputs[0])
	    #accumulate_field.Total -> sample_index_001.Value
	    attach_hair_curves_to_surface.links.new(accumulate_field.outputs[2], sample_index_001.inputs[1])
	    #sample_index_001.Value -> switch_001_3.Switch
	    attach_hair_curves_to_surface.links.new(sample_index_001.outputs[0], switch_001_3.inputs[0])
	    #reroute_008.Output -> sample_index.Value
	    attach_hair_curves_to_surface.links.new(reroute_008.outputs[0], sample_index.inputs[1])
	    #vector_rotate_1.Vector -> switch_002_1.True
	    attach_hair_curves_to_surface.links.new(vector_rotate_1.outputs[0], switch_002_1.inputs[2])
	    #vector_math_001_3.Vector -> switch_002_1.False
	    attach_hair_curves_to_surface.links.new(vector_math_001_3.outputs[0], switch_002_1.inputs[1])
	    #group_input_003_1.Align to Surface Normal -> switch_002_1.Switch
	    attach_hair_curves_to_surface.links.new(group_input_003_1.outputs[7], switch_002_1.inputs[0])
	    #vector_math_005_3.Vector -> set_position_001_3.Offset
	    attach_hair_curves_to_surface.links.new(vector_math_005_3.outputs[0], set_position_001_3.inputs[3])
	    #evaluate_on_domain_1.Value -> switch_003_1.True
	    attach_hair_curves_to_surface.links.new(evaluate_on_domain_1.outputs[0], switch_003_1.inputs[2])
	    #group_input_006_1.Snap to Surface -> switch_003_1.Switch
	    attach_hair_curves_to_surface.links.new(group_input_006_1.outputs[6], switch_003_1.inputs[0])
	    #group_input_006_1.Snap to Surface -> boolean_math.Boolean
	    attach_hair_curves_to_surface.links.new(group_input_006_1.outputs[6], boolean_math.inputs[0])
	    #group_input_003_1.Align to Surface Normal -> boolean_math.Boolean
	    attach_hair_curves_to_surface.links.new(group_input_003_1.outputs[7], boolean_math.inputs[1])
	    #boolean_math.Boolean -> set_position_001_3.Selection
	    attach_hair_curves_to_surface.links.new(boolean_math.outputs[0], set_position_001_3.inputs[1])
	    #capture_attribute_002_1.Value -> reroute_003_2.Input
	    attach_hair_curves_to_surface.links.new(capture_attribute_002_1.outputs[1], reroute_003_2.inputs[0])
	    #switch_009.Output -> group_output_9.Surface UV Coordinate
	    attach_hair_curves_to_surface.links.new(switch_009.outputs[0], group_output_9.inputs[1])
	    #store_named_attribute_1.Geometry -> switch_3.True
	    attach_hair_curves_to_surface.links.new(store_named_attribute_1.outputs[0], switch_3.inputs[2])
	    #group_input_007_1.Sample Attachment UV -> switch_3.Switch
	    attach_hair_curves_to_surface.links.new(group_input_007_1.outputs[5], switch_3.inputs[0])
	    #reroute_016_1.Output -> switch_3.False
	    attach_hair_curves_to_surface.links.new(reroute_016_1.outputs[0], switch_3.inputs[1])
	    #switch_3.Output -> store_named_attribute_001.Geometry
	    attach_hair_curves_to_surface.links.new(switch_3.outputs[0], store_named_attribute_001.inputs[0])
	    #reroute_020_1.Output -> capture_attribute_001_1.Geometry
	    attach_hair_curves_to_surface.links.new(reroute_020_1.outputs[0], capture_attribute_001_1.inputs[0])
	    #reroute_005.Output -> store_named_attribute_001.Value
	    attach_hair_curves_to_surface.links.new(reroute_005.outputs[0], store_named_attribute_001.inputs[3])
	    #capture_attribute_001_1.Value -> reroute_005.Input
	    attach_hair_curves_to_surface.links.new(capture_attribute_001_1.outputs[1], reroute_005.inputs[0])
	    #switch_010.Output -> group_output_9.Surface Normal
	    attach_hair_curves_to_surface.links.new(switch_010.outputs[0], group_output_9.inputs[2])
	    #sample_uv_surface_001.Value -> capture_attribute_001_1.Value
	    attach_hair_curves_to_surface.links.new(sample_uv_surface_001.outputs[0], capture_attribute_001_1.inputs[1])
	    #vector_math_003_3.Vector -> vector_math_005_3.Vector
	    attach_hair_curves_to_surface.links.new(vector_math_003_3.outputs[0], vector_math_005_3.inputs[0])
	    #spline_parameter.Factor -> map_range_1.Value
	    attach_hair_curves_to_surface.links.new(spline_parameter.outputs[0], map_range_1.inputs[0])
	    #group_input_008.Blend along Curve -> map_range_1.From Max
	    attach_hair_curves_to_surface.links.new(group_input_008.outputs[8], map_range_1.inputs[2])
	    #group_input_008.Blend along Curve -> compare_2.A
	    attach_hair_curves_to_surface.links.new(group_input_008.outputs[8], compare_2.inputs[0])
	    #compare_2.Result -> switch_004_1.Switch
	    attach_hair_curves_to_surface.links.new(compare_2.outputs[0], switch_004_1.inputs[0])
	    #map_range_1.Result -> switch_004_1.False
	    attach_hair_curves_to_surface.links.new(map_range_1.outputs[0], switch_004_1.inputs[1])
	    #switch_004_1.Output -> vector_math_005_3.Scale
	    attach_hair_curves_to_surface.links.new(switch_004_1.outputs[0], vector_math_005_3.inputs[3])
	    #switch_001_3.Output -> align_euler_to_vector_003.Vector
	    attach_hair_curves_to_surface.links.new(switch_001_3.outputs[0], align_euler_to_vector_003.inputs[2])
	    #sample_index.Value -> switch_001_3.False
	    attach_hair_curves_to_surface.links.new(sample_index.outputs[0], switch_001_3.inputs[1])
	    #named_attribute_002.Exists -> switch_006.Switch
	    attach_hair_curves_to_surface.links.new(named_attribute_002.outputs[1], switch_006.inputs[0])
	    #reroute_009.Output -> switch_006.False
	    attach_hair_curves_to_surface.links.new(reroute_009.outputs[0], switch_006.inputs[1])
	    #vector_rotate_003.Vector -> switch_006.True
	    attach_hair_curves_to_surface.links.new(vector_rotate_003.outputs[0], switch_006.inputs[2])
	    #vector_math_001_3.Vector -> reroute_009.Input
	    attach_hair_curves_to_surface.links.new(vector_math_001_3.outputs[0], reroute_009.inputs[0])
	    #reroute_011.Output -> reroute_010.Input
	    attach_hair_curves_to_surface.links.new(reroute_011.outputs[0], reroute_010.inputs[0])
	    #group_input_4.Geometry -> reroute_011.Input
	    attach_hair_curves_to_surface.links.new(group_input_4.outputs[0], reroute_011.inputs[0])
	    #store_named_attribute_001.Geometry -> switch_008.False
	    attach_hair_curves_to_surface.links.new(store_named_attribute_001.outputs[0], switch_008.inputs[1])
	    #reroute_006.Output -> switch_008.True
	    attach_hair_curves_to_surface.links.new(reroute_006.outputs[0], switch_008.inputs[2])
	    #switch_008.Output -> group_output_9.Geometry
	    attach_hair_curves_to_surface.links.new(switch_008.outputs[0], group_output_9.inputs[0])
	    #reroute_003_2.Output -> switch_009.False
	    attach_hair_curves_to_surface.links.new(reroute_003_2.outputs[0], switch_009.inputs[1])
	    #reroute_005.Output -> switch_010.False
	    attach_hair_curves_to_surface.links.new(reroute_005.outputs[0], switch_010.inputs[1])
	    #domain_size_003.Face Count -> compare_002_2.A
	    attach_hair_curves_to_surface.links.new(domain_size_003.outputs[2], compare_002_2.inputs[2])
	    #switch_005_1.Output -> domain_size_003.Geometry
	    attach_hair_curves_to_surface.links.new(switch_005_1.outputs[0], domain_size_003.inputs[0])
	    #reroute_012_1.Output -> switch_008.Switch
	    attach_hair_curves_to_surface.links.new(reroute_012_1.outputs[0], switch_008.inputs[0])
	    #reroute_014_1.Output -> reroute_012_1.Input
	    attach_hair_curves_to_surface.links.new(reroute_014_1.outputs[0], reroute_012_1.inputs[0])
	    #reroute_012_1.Output -> switch_009.Switch
	    attach_hair_curves_to_surface.links.new(reroute_012_1.outputs[0], switch_009.inputs[0])
	    #reroute_012_1.Output -> switch_010.Switch
	    attach_hair_curves_to_surface.links.new(reroute_012_1.outputs[0], switch_010.inputs[0])
	    #named_attribute_003.Attribute -> switch_009.True
	    attach_hair_curves_to_surface.links.new(named_attribute_003.outputs[0], switch_009.inputs[2])
	    #named_attribute_004.Attribute -> switch_010.True
	    attach_hair_curves_to_surface.links.new(named_attribute_004.outputs[0], switch_010.inputs[2])
	    #reroute_015_1.Output -> reroute_013_1.Input
	    attach_hair_curves_to_surface.links.new(reroute_015_1.outputs[0], reroute_013_1.inputs[0])
	    #reroute_013_1.Output -> reroute_014_1.Input
	    attach_hair_curves_to_surface.links.new(reroute_013_1.outputs[0], reroute_014_1.inputs[0])
	    #compare_002_2.Result -> reroute_015_1.Input
	    attach_hair_curves_to_surface.links.new(compare_002_2.outputs[0], reroute_015_1.inputs[0])
	    #set_position_001_3.Geometry -> reroute_016_1.Input
	    attach_hair_curves_to_surface.links.new(set_position_001_3.outputs[0], reroute_016_1.inputs[0])
	    #capture_attribute_1.Geometry -> reroute_017_1.Input
	    attach_hair_curves_to_surface.links.new(capture_attribute_1.outputs[0], reroute_017_1.inputs[0])
	    #capture_attribute_1.Value -> reroute_018_1.Input
	    attach_hair_curves_to_surface.links.new(capture_attribute_1.outputs[1], reroute_018_1.inputs[0])
	    #reroute_010.Output -> reroute_006.Input
	    attach_hair_curves_to_surface.links.new(reroute_010.outputs[0], reroute_006.inputs[0])
	    #reroute_001_2.Output -> reroute_007.Input
	    attach_hair_curves_to_surface.links.new(reroute_001_2.outputs[0], reroute_007.inputs[0])
	    #sample_uv_surface_001.Value -> reroute_008.Input
	    attach_hair_curves_to_surface.links.new(sample_uv_surface_001.outputs[0], reroute_008.inputs[0])
	    #reroute_008.Output -> align_euler_to_vector_002.Vector
	    attach_hair_curves_to_surface.links.new(reroute_008.outputs[0], align_euler_to_vector_002.inputs[2])
	    #sample_uv_surface_003.Value -> reroute_019_1.Input
	    attach_hair_curves_to_surface.links.new(sample_uv_surface_003.outputs[0], reroute_019_1.inputs[0])
	    #reroute_017_1.Output -> sample_uv_surface.Mesh
	    attach_hair_curves_to_surface.links.new(reroute_017_1.outputs[0], sample_uv_surface.inputs[0])
	    #group_input_009.Surface UV Map -> reroute_002_2.Input
	    attach_hair_curves_to_surface.links.new(group_input_009.outputs[3], reroute_002_2.inputs[0])
	    #capture_attribute_002_1.Geometry -> reroute_020_1.Input
	    attach_hair_curves_to_surface.links.new(capture_attribute_002_1.outputs[0], reroute_020_1.inputs[0])
	    return attach_hair_curves_to_surface
	
	attach_hair_curves_to_surface = attach_hair_curves_to_surface_node_group()
	
	#initialize attach_hair node group
	def attach_hair_node_group():
	    attach_hair = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "ATTACH_HAIR")
	
	    attach_hair.color_tag = 'NONE'
	    attach_hair.description = ""
	    attach_hair.default_group_node_width = 140
	    
	
	    attach_hair.is_modifier = True
	
	    #attach_hair interface
	    #Socket Geometry
	    geometry_socket_5 = attach_hair.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_5.attribute_domain = 'POINT'
	
	    #Socket Geometry
	    geometry_socket_6 = attach_hair.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_6.attribute_domain = 'POINT'
	
	    #Socket Surface
	    surface_socket_2 = attach_hair.interface.new_socket(name = "Surface", in_out='INPUT', socket_type = 'NodeSocketObject')
	    surface_socket_2.attribute_domain = 'POINT'
	    surface_socket_2.description = "Surface Object to attach to (needs to have matching transforms)"
	
	    #Socket UV Map
	    uv_map_socket = attach_hair.interface.new_socket(name = "UV Map", in_out='INPUT', socket_type = 'NodeSocketString')
	    uv_map_socket.default_value = "UVMap"
	    uv_map_socket.subtype = 'NONE'
	    uv_map_socket.attribute_domain = 'POINT'
	    uv_map_socket.description = "Surface UV Map used to attach hair."
	
	    #Socket Blend along Curve
	    blend_along_curve_socket_1 = attach_hair.interface.new_socket(name = "Blend along Curve", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    blend_along_curve_socket_1.default_value = 0.05000000074505806
	    blend_along_curve_socket_1.min_value = 0.0
	    blend_along_curve_socket_1.max_value = 1.0
	    blend_along_curve_socket_1.subtype = 'FACTOR'
	    blend_along_curve_socket_1.attribute_domain = 'POINT'
	    blend_along_curve_socket_1.description = "Blend deformation along each curve from the root"
	
	
	    #initialize attach_hair nodes
	    #node Group Input
	    group_input_5 = attach_hair.nodes.new("NodeGroupInput")
	    group_input_5.name = "Group Input"
	    group_input_5.outputs[4].hide = True
	
	    #node Group Output
	    group_output_10 = attach_hair.nodes.new("NodeGroupOutput")
	    group_output_10.name = "Group Output"
	    group_output_10.is_active_output = True
	    group_output_10.inputs[1].hide = True
	
	    #node Group
	    group_4 = attach_hair.nodes.new("GeometryNodeGroup")
	    group_4.name = "Group"
	    group_4.node_tree = attach_hair_curves_to_surface
	    group_4.inputs[1].hide = True
	    group_4.inputs[4].hide = True
	    group_4.inputs[5].hide = True
	    group_4.inputs[6].hide = True
	    group_4.inputs[7].hide = True
	    group_4.outputs[1].hide = True
	    group_4.outputs[2].hide = True
	    #Socket_7
	    group_4.inputs[4].default_value = False
	    #Socket_8
	    group_4.inputs[5].default_value = True
	    #Socket_9
	    group_4.inputs[6].default_value = True
	    #Socket_10
	    group_4.inputs[7].default_value = False
	
	    #node Named Attribute
	    named_attribute_2 = attach_hair.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute_2.name = "Named Attribute"
	    named_attribute_2.hide = True
	    named_attribute_2.data_type = 'FLOAT_VECTOR'
	
	
	
	
	
	    #Set locations
	    group_input_5.location = (-340.0, 0.0)
	    group_output_10.location = (82.01471710205078, 24.076622009277344)
	    group_4.location = (-156.17784118652344, 22.037841796875)
	    named_attribute_2.location = (-333.9075622558594, -146.13522338867188)
	
	    #Set dimensions
	    group_input_5.width, group_input_5.height = 140.0, 100.0
	    group_output_10.width, group_output_10.height = 140.0, 100.0
	    group_4.width, group_4.height = 197.8995361328125, 100.0
	    named_attribute_2.width, named_attribute_2.height = 140.0, 100.0
	
	    #initialize attach_hair links
	    #group_4.Geometry -> group_output_10.Geometry
	    attach_hair.links.new(group_4.outputs[0], group_output_10.inputs[0])
	    #group_input_5.Geometry -> group_4.Geometry
	    attach_hair.links.new(group_input_5.outputs[0], group_4.inputs[0])
	    #named_attribute_2.Attribute -> group_4.Surface UV Map
	    attach_hair.links.new(named_attribute_2.outputs[0], group_4.inputs[3])
	    #group_input_5.Surface -> group_4.Surface
	    attach_hair.links.new(group_input_5.outputs[1], group_4.inputs[2])
	    #group_input_5.UV Map -> named_attribute_2.Name
	    attach_hair.links.new(group_input_5.outputs[2], named_attribute_2.inputs[0])
	    #group_input_5.Blend along Curve -> group_4.Blend along Curve
	    attach_hair.links.new(group_input_5.outputs[3], group_4.inputs[8])
	    return attach_hair
	
	attach_hair = attach_hair_node_group()
	
	#initialize braid_guide node group
	def braid_guide_node_group():
	    braid_guide = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "BRAID_GUIDE")
	
	    braid_guide.color_tag = 'NONE'
	    braid_guide.description = "Basic braid twists to use as guide for more complex hair designs."
	    braid_guide.default_group_node_width = 140
	    
	
	    braid_guide.is_modifier = True
	
	    #braid_guide interface
	    #Socket Geometry
	    geometry_socket_7 = braid_guide.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_7.attribute_domain = 'POINT'
	    geometry_socket_7.description = "Hair guides."
	
	    #Socket Geometry
	    geometry_socket_8 = braid_guide.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_8.attribute_domain = 'POINT'
	    geometry_socket_8.description = "Hair Curve to guide this braid guide."
	
	    #Socket Frequency
	    frequency_socket_3 = braid_guide.interface.new_socket(name = "Frequency", in_out='INPUT', socket_type = 'NodeSocketInt')
	    frequency_socket_3.default_value = 5
	    frequency_socket_3.min_value = 1
	    frequency_socket_3.max_value = 10000
	    frequency_socket_3.subtype = 'NONE'
	    frequency_socket_3.attribute_domain = 'POINT'
	    frequency_socket_3.description = "Frequency of braid twists."
	
	    #Socket Scale
	    scale_socket_3 = braid_guide.interface.new_socket(name = "Scale", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    scale_socket_3.default_value = 1.0
	    scale_socket_3.min_value = 9.999999747378752e-05
	    scale_socket_3.max_value = 10000.0
	    scale_socket_3.subtype = 'NONE'
	    scale_socket_3.attribute_domain = 'POINT'
	    scale_socket_3.description = "Radius between centers of braid loops."
	
	    #Socket Overall Shape Scale
	    overall_shape_scale_socket = braid_guide.interface.new_socket(name = "Overall Shape Scale", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    overall_shape_scale_socket.default_value = 1.0
	    overall_shape_scale_socket.min_value = 0.0
	    overall_shape_scale_socket.max_value = 3.4028234663852886e+38
	    overall_shape_scale_socket.subtype = 'DISTANCE'
	    overall_shape_scale_socket.attribute_domain = 'POINT'
	    overall_shape_scale_socket.description = "Scale used for overall shape curve."
	
	    #Socket Use Loop 1
	    use_loop_1_socket = braid_guide.interface.new_socket(name = "Use Loop 1", in_out='INPUT', socket_type = 'NodeSocketBool')
	    use_loop_1_socket.default_value = True
	    use_loop_1_socket.attribute_domain = 'POINT'
	    use_loop_1_socket.description = "Use the first braid loop."
	
	    #Socket Use Loop 2
	    use_loop_2_socket = braid_guide.interface.new_socket(name = "Use Loop 2", in_out='INPUT', socket_type = 'NodeSocketBool')
	    use_loop_2_socket.default_value = True
	    use_loop_2_socket.attribute_domain = 'POINT'
	    use_loop_2_socket.description = "Use the second braid loop."
	
	    #Socket Use Loop 3
	    use_loop_3_socket = braid_guide.interface.new_socket(name = "Use Loop 3", in_out='INPUT', socket_type = 'NodeSocketBool')
	    use_loop_3_socket.default_value = True
	    use_loop_3_socket.attribute_domain = 'POINT'
	    use_loop_3_socket.description = "Use the third braid loop."
	
	    #Socket Extend Root
	    extend_root_socket_2 = braid_guide.interface.new_socket(name = "Extend Root", in_out='INPUT', socket_type = 'NodeSocketBool')
	    extend_root_socket_2.default_value = True
	    extend_root_socket_2.attribute_domain = 'POINT'
	    extend_root_socket_2.description = "Extend hair roots."
	
	    #Panel Surface Attach Settings
	    surface_attach_settings_panel = braid_guide.interface.new_panel("Surface Attach Settings", default_closed=True)
	    surface_attach_settings_panel.description = "Settings for attaching curve to surface mesh."
	    #Socket Surface
	    surface_socket_3 = braid_guide.interface.new_socket(name = "Surface", in_out='INPUT', socket_type = 'NodeSocketObject', parent = surface_attach_settings_panel)
	    surface_socket_3.attribute_domain = 'POINT'
	    surface_socket_3.description = "Surface Object to attach to (needs to have matching transforms)"
	
	    #Socket UV Map
	    uv_map_socket_1 = braid_guide.interface.new_socket(name = "UV Map", in_out='INPUT', socket_type = 'NodeSocketString', parent = surface_attach_settings_panel)
	    uv_map_socket_1.default_value = "UVMap"
	    uv_map_socket_1.subtype = 'NONE'
	    uv_map_socket_1.attribute_domain = 'POINT'
	    uv_map_socket_1.description = "Surface UV Map used to attach hair."
	
	    #Socket Blend along Curve
	    blend_along_curve_socket_2 = braid_guide.interface.new_socket(name = "Blend along Curve", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = surface_attach_settings_panel)
	    blend_along_curve_socket_2.default_value = 0.05000000074505806
	    blend_along_curve_socket_2.min_value = 0.0
	    blend_along_curve_socket_2.max_value = 1.0
	    blend_along_curve_socket_2.subtype = 'FACTOR'
	    blend_along_curve_socket_2.attribute_domain = 'POINT'
	    blend_along_curve_socket_2.description = "Blend deformation along each curve from the root"
	
	
	    #Panel Children Settings
	    children_settings_panel = braid_guide.interface.new_panel("Children Settings", default_closed=True)
	    children_settings_panel.description = "Settings for duplicate guides."
	    #Socket Amount
	    amount_socket_1 = braid_guide.interface.new_socket(name = "Amount", in_out='INPUT', socket_type = 'NodeSocketInt', parent = children_settings_panel)
	    amount_socket_1.default_value = 0
	    amount_socket_1.min_value = 0
	    amount_socket_1.max_value = 2147483647
	    amount_socket_1.subtype = 'NONE'
	    amount_socket_1.attribute_domain = 'POINT'
	    amount_socket_1.description = "Amount of duplicates per curve"
	
	    #Socket Viewport Amount
	    viewport_amount_socket_1 = braid_guide.interface.new_socket(name = "Viewport Amount", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = children_settings_panel)
	    viewport_amount_socket_1.default_value = 1.0
	    viewport_amount_socket_1.min_value = 0.0
	    viewport_amount_socket_1.max_value = 1.0
	    viewport_amount_socket_1.subtype = 'FACTOR'
	    viewport_amount_socket_1.attribute_domain = 'POINT'
	    viewport_amount_socket_1.description = "Percentage of amount used for the viewport"
	
	    #Socket Radius
	    radius_socket_2 = braid_guide.interface.new_socket(name = "Radius", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = children_settings_panel)
	    radius_socket_2.default_value = 0.10000000149011612
	    radius_socket_2.min_value = 0.0
	    radius_socket_2.max_value = 3.4028234663852886e+38
	    radius_socket_2.subtype = 'DISTANCE'
	    radius_socket_2.attribute_domain = 'POINT'
	    radius_socket_2.description = "Radius in which the duplicate curves are offset from the guides"
	
	    #Socket Distribution Shape
	    distribution_shape_socket_1 = braid_guide.interface.new_socket(name = "Distribution Shape", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = children_settings_panel)
	    distribution_shape_socket_1.default_value = 0.0
	    distribution_shape_socket_1.min_value = -10.0
	    distribution_shape_socket_1.max_value = 10.0
	    distribution_shape_socket_1.subtype = 'NONE'
	    distribution_shape_socket_1.attribute_domain = 'POINT'
	    distribution_shape_socket_1.description = "Shape of distribution from center to the edge around the guide"
	
	    #Socket Even Thickness
	    even_thickness_socket_1 = braid_guide.interface.new_socket(name = "Even Thickness", in_out='INPUT', socket_type = 'NodeSocketBool', parent = children_settings_panel)
	    even_thickness_socket_1.default_value = True
	    even_thickness_socket_1.attribute_domain = 'POINT'
	    even_thickness_socket_1.description = "Keep an even thickness of the distribution of duplicates"
	
	    #Socket Seed
	    seed_socket_1 = braid_guide.interface.new_socket(name = "Seed", in_out='INPUT', socket_type = 'NodeSocketInt', parent = children_settings_panel)
	    seed_socket_1.default_value = 0
	    seed_socket_1.min_value = -10000
	    seed_socket_1.max_value = 10000
	    seed_socket_1.subtype = 'NONE'
	    seed_socket_1.attribute_domain = 'POINT'
	    seed_socket_1.description = "Random Seed for the operation"
	
	
	
	    #initialize braid_guide nodes
	    #node Group Input
	    group_input_6 = braid_guide.nodes.new("NodeGroupInput")
	    group_input_6.name = "Group Input"
	    group_input_6.outputs[1].hide = True
	    group_input_6.outputs[2].hide = True
	    group_input_6.outputs[3].hide = True
	    group_input_6.outputs[4].hide = True
	    group_input_6.outputs[5].hide = True
	    group_input_6.outputs[6].hide = True
	    group_input_6.outputs[7].hide = True
	    group_input_6.outputs[8].hide = True
	    group_input_6.outputs[9].hide = True
	    group_input_6.outputs[10].hide = True
	    group_input_6.outputs[11].hide = True
	    group_input_6.outputs[12].hide = True
	    group_input_6.outputs[13].hide = True
	    group_input_6.outputs[14].hide = True
	    group_input_6.outputs[15].hide = True
	    group_input_6.outputs[16].hide = True
	    group_input_6.outputs[17].hide = True
	
	    #node Group Output
	    group_output_11 = braid_guide.nodes.new("NodeGroupOutput")
	    group_output_11.name = "Group Output"
	    group_output_11.is_active_output = True
	    group_output_11.inputs[1].hide = True
	
	    #node Repeat Input
	    repeat_input = braid_guide.nodes.new("GeometryNodeRepeatInput")
	    repeat_input.name = "Repeat Input"
	    repeat_input.hide = True
	    #node Repeat Output
	    repeat_output = braid_guide.nodes.new("GeometryNodeRepeatOutput")
	    repeat_output.name = "Repeat Output"
	    repeat_output.hide = True
	    repeat_output.active_index = 1
	    repeat_output.inspection_index = 0
	    repeat_output.repeat_items.clear()
	    # Create item "Geometry"
	    repeat_output.repeat_items.new('GEOMETRY', "Geometry")
	    # Create item "Count"
	    repeat_output.repeat_items.new('INT', "Count")
	
	    #node Math
	    math_2 = braid_guide.nodes.new("ShaderNodeMath")
	    math_2.name = "Math"
	    math_2.hide = True
	    math_2.operation = 'ADD'
	    math_2.use_clamp = False
	    math_2.inputs[1].hide = True
	    math_2.inputs[2].hide = True
	    #Value_001
	    math_2.inputs[1].default_value = 1.0
	
	    #node Domain Size
	    domain_size = braid_guide.nodes.new("GeometryNodeAttributeDomainSize")
	    domain_size.name = "Domain Size"
	    domain_size.hide = True
	    domain_size.component = 'CURVE'
	
	    #node Set Spline Type
	    set_spline_type = braid_guide.nodes.new("GeometryNodeCurveSplineType")
	    set_spline_type.name = "Set Spline Type"
	    set_spline_type.hide = True
	    set_spline_type.spline_type = 'POLY'
	    #Selection
	    set_spline_type.inputs[1].default_value = True
	
	    #node Join Geometry
	    join_geometry_3 = braid_guide.nodes.new("GeometryNodeJoinGeometry")
	    join_geometry_3.name = "Join Geometry"
	    join_geometry_3.hide = True
	
	    #node Final Bake
	    final_bake = braid_guide.nodes.new("GeometryNodeBake")
	    final_bake.label = "Final Bake"
	    final_bake.name = "Final Bake"
	    final_bake.active_index = 0
	    final_bake.bake_items.clear()
	    final_bake.bake_items.new('GEOMETRY', "Geometry")
	    final_bake.bake_items[0].attribute_domain = 'POINT'
	    final_bake.inputs[1].hide = True
	    final_bake.outputs[1].hide = True
	
	    #node Switch
	    switch_4 = braid_guide.nodes.new("GeometryNodeSwitch")
	    switch_4.name = "Switch"
	    switch_4.hide = True
	    switch_4.input_type = 'GEOMETRY'
	    switch_4.inputs[1].hide = True
	
	    #node Switch.001
	    switch_001_4 = braid_guide.nodes.new("GeometryNodeSwitch")
	    switch_001_4.name = "Switch.001"
	    switch_001_4.hide = True
	    switch_001_4.input_type = 'GEOMETRY'
	    switch_001_4.inputs[1].hide = True
	
	    #node Switch.002
	    switch_002_2 = braid_guide.nodes.new("GeometryNodeSwitch")
	    switch_002_2.name = "Switch.002"
	    switch_002_2.hide = True
	    switch_002_2.input_type = 'GEOMETRY'
	    switch_002_2.inputs[1].hide = True
	
	    #node Group Input.001
	    group_input_001_4 = braid_guide.nodes.new("NodeGroupInput")
	    group_input_001_4.name = "Group Input.001"
	    group_input_001_4.outputs[4].hide = True
	    group_input_001_4.outputs[5].hide = True
	    group_input_001_4.outputs[6].hide = True
	    group_input_001_4.outputs[8].hide = True
	    group_input_001_4.outputs[9].hide = True
	    group_input_001_4.outputs[10].hide = True
	    group_input_001_4.outputs[11].hide = True
	    group_input_001_4.outputs[12].hide = True
	    group_input_001_4.outputs[13].hide = True
	    group_input_001_4.outputs[14].hide = True
	    group_input_001_4.outputs[15].hide = True
	    group_input_001_4.outputs[16].hide = True
	    group_input_001_4.outputs[17].hide = True
	
	    #node Group Input.003
	    group_input_003_2 = braid_guide.nodes.new("NodeGroupInput")
	    group_input_003_2.name = "Group Input.003"
	    group_input_003_2.outputs[0].hide = True
	    group_input_003_2.outputs[1].hide = True
	    group_input_003_2.outputs[2].hide = True
	    group_input_003_2.outputs[3].hide = True
	    group_input_003_2.outputs[5].hide = True
	    group_input_003_2.outputs[6].hide = True
	    group_input_003_2.outputs[7].hide = True
	    group_input_003_2.outputs[8].hide = True
	    group_input_003_2.outputs[9].hide = True
	    group_input_003_2.outputs[10].hide = True
	    group_input_003_2.outputs[11].hide = True
	    group_input_003_2.outputs[12].hide = True
	    group_input_003_2.outputs[13].hide = True
	    group_input_003_2.outputs[14].hide = True
	    group_input_003_2.outputs[15].hide = True
	    group_input_003_2.outputs[16].hide = True
	    group_input_003_2.outputs[17].hide = True
	
	    #node Group Input.004
	    group_input_004_2 = braid_guide.nodes.new("NodeGroupInput")
	    group_input_004_2.name = "Group Input.004"
	    group_input_004_2.outputs[0].hide = True
	    group_input_004_2.outputs[1].hide = True
	    group_input_004_2.outputs[2].hide = True
	    group_input_004_2.outputs[3].hide = True
	    group_input_004_2.outputs[4].hide = True
	    group_input_004_2.outputs[6].hide = True
	    group_input_004_2.outputs[7].hide = True
	    group_input_004_2.outputs[8].hide = True
	    group_input_004_2.outputs[9].hide = True
	    group_input_004_2.outputs[10].hide = True
	    group_input_004_2.outputs[11].hide = True
	    group_input_004_2.outputs[12].hide = True
	    group_input_004_2.outputs[13].hide = True
	    group_input_004_2.outputs[14].hide = True
	    group_input_004_2.outputs[15].hide = True
	    group_input_004_2.outputs[16].hide = True
	    group_input_004_2.outputs[17].hide = True
	
	    #node Group Input.005
	    group_input_005_2 = braid_guide.nodes.new("NodeGroupInput")
	    group_input_005_2.name = "Group Input.005"
	    group_input_005_2.outputs[0].hide = True
	    group_input_005_2.outputs[1].hide = True
	    group_input_005_2.outputs[2].hide = True
	    group_input_005_2.outputs[3].hide = True
	    group_input_005_2.outputs[4].hide = True
	    group_input_005_2.outputs[5].hide = True
	    group_input_005_2.outputs[7].hide = True
	    group_input_005_2.outputs[8].hide = True
	    group_input_005_2.outputs[9].hide = True
	    group_input_005_2.outputs[10].hide = True
	    group_input_005_2.outputs[11].hide = True
	    group_input_005_2.outputs[12].hide = True
	    group_input_005_2.outputs[13].hide = True
	    group_input_005_2.outputs[14].hide = True
	    group_input_005_2.outputs[15].hide = True
	    group_input_005_2.outputs[16].hide = True
	    group_input_005_2.outputs[17].hide = True
	
	    #node Overall Shape
	    overall_shape = braid_guide.nodes.new("ShaderNodeFloatCurve")
	    overall_shape.label = "Overall Shape"
	    overall_shape.name = "Overall Shape"
	    #mapping settings
	    overall_shape.mapping.extend = 'EXTRAPOLATED'
	    overall_shape.mapping.tone = 'STANDARD'
	    overall_shape.mapping.black_level = (0.0, 0.0, 0.0)
	    overall_shape.mapping.white_level = (1.0, 1.0, 1.0)
	    overall_shape.mapping.clip_min_x = 0.0
	    overall_shape.mapping.clip_min_y = 0.0
	    overall_shape.mapping.clip_max_x = 1.0
	    overall_shape.mapping.clip_max_y = 1.0
	    overall_shape.mapping.use_clip = True
	    #curve 0
	    overall_shape_curve_0 = overall_shape.mapping.curves[0]
	    overall_shape_curve_0_point_0 = overall_shape_curve_0.points[0]
	    overall_shape_curve_0_point_0.location = (0.0, 1.0)
	    overall_shape_curve_0_point_0.handle_type = 'AUTO'
	    overall_shape_curve_0_point_1 = overall_shape_curve_0.points[1]
	    overall_shape_curve_0_point_1.location = (0.8863636255264282, 0.9937499761581421)
	    overall_shape_curve_0_point_1.handle_type = 'VECTOR'
	    overall_shape_curve_0_point_2 = overall_shape_curve_0.points.new(1.0, 0.2562495470046997)
	    overall_shape_curve_0_point_2.handle_type = 'AUTO'
	    #update curve after changes
	    overall_shape.mapping.update()
	    #Factor
	    overall_shape.inputs[0].default_value = 1.0
	
	    #node Spline Parameter
	    spline_parameter_1 = braid_guide.nodes.new("GeometryNodeSplineParameter")
	    spline_parameter_1.name = "Spline Parameter"
	    spline_parameter_1.hide = True
	    spline_parameter_1.outputs[1].hide = True
	    spline_parameter_1.outputs[2].hide = True
	
	    #node Map Range
	    map_range_2 = braid_guide.nodes.new("ShaderNodeMapRange")
	    map_range_2.name = "Map Range"
	    map_range_2.hide = True
	    map_range_2.clamp = True
	    map_range_2.data_type = 'FLOAT'
	    map_range_2.interpolation_type = 'LINEAR'
	    map_range_2.inputs[1].hide = True
	    map_range_2.inputs[2].hide = True
	    map_range_2.inputs[3].hide = True
	    map_range_2.inputs[5].hide = True
	    map_range_2.inputs[6].hide = True
	    map_range_2.inputs[7].hide = True
	    map_range_2.inputs[8].hide = True
	    map_range_2.inputs[9].hide = True
	    map_range_2.inputs[10].hide = True
	    map_range_2.inputs[11].hide = True
	    map_range_2.outputs[1].hide = True
	    #From Min
	    map_range_2.inputs[1].default_value = 0.0
	    #From Max
	    map_range_2.inputs[2].default_value = 1.0
	    #To Min
	    map_range_2.inputs[3].default_value = 0.0
	
	    #node Frame
	    frame_4 = braid_guide.nodes.new("NodeFrame")
	    frame_4.label = "Overall Shape"
	    frame_4.name = "Frame"
	    frame_4.label_size = 20
	    frame_4.shrink = True
	
	    #node Group.001
	    group_001_3 = braid_guide.nodes.new("GeometryNodeGroup")
	    group_001_3.name = "Group.001"
	    group_001_3.node_tree = duplicate_hair_curves
	    group_001_3.inputs[5].hide = True
	    #Socket_7
	    group_001_3.inputs[5].default_value = 0.0
	
	    #node Group Input.006
	    group_input_006_2 = braid_guide.nodes.new("NodeGroupInput")
	    group_input_006_2.name = "Group Input.006"
	    group_input_006_2.outputs[0].hide = True
	    group_input_006_2.outputs[1].hide = True
	    group_input_006_2.outputs[2].hide = True
	    group_input_006_2.outputs[3].hide = True
	    group_input_006_2.outputs[4].hide = True
	    group_input_006_2.outputs[5].hide = True
	    group_input_006_2.outputs[6].hide = True
	    group_input_006_2.outputs[7].hide = True
	    group_input_006_2.outputs[8].hide = True
	    group_input_006_2.outputs[9].hide = True
	    group_input_006_2.outputs[10].hide = True
	    group_input_006_2.outputs[17].hide = True
	
	    #node Switch.003
	    switch_003_2 = braid_guide.nodes.new("GeometryNodeSwitch")
	    switch_003_2.name = "Switch.003"
	    switch_003_2.input_type = 'GEOMETRY'
	
	    #node All Braids Bake
	    all_braids_bake = braid_guide.nodes.new("GeometryNodeBake")
	    all_braids_bake.label = "All Braids Bake"
	    all_braids_bake.name = "All Braids Bake"
	    all_braids_bake.active_index = 0
	    all_braids_bake.bake_items.clear()
	    all_braids_bake.bake_items.new('GEOMETRY', "Geometry")
	    all_braids_bake.bake_items[0].attribute_domain = 'POINT'
	    all_braids_bake.inputs[1].hide = True
	    all_braids_bake.outputs[1].hide = True
	
	    #node Group Input.007
	    group_input_007_2 = braid_guide.nodes.new("NodeGroupInput")
	    group_input_007_2.name = "Group Input.007"
	    group_input_007_2.outputs[0].hide = True
	    group_input_007_2.outputs[1].hide = True
	    group_input_007_2.outputs[2].hide = True
	    group_input_007_2.outputs[3].hide = True
	    group_input_007_2.outputs[4].hide = True
	    group_input_007_2.outputs[5].hide = True
	    group_input_007_2.outputs[6].hide = True
	    group_input_007_2.outputs[7].hide = True
	    group_input_007_2.outputs[8].hide = True
	    group_input_007_2.outputs[9].hide = True
	    group_input_007_2.outputs[10].hide = True
	    group_input_007_2.outputs[12].hide = True
	    group_input_007_2.outputs[13].hide = True
	    group_input_007_2.outputs[14].hide = True
	    group_input_007_2.outputs[15].hide = True
	    group_input_007_2.outputs[16].hide = True
	    group_input_007_2.outputs[17].hide = True
	
	    #node Compare
	    compare_3 = braid_guide.nodes.new("FunctionNodeCompare")
	    compare_3.name = "Compare"
	    compare_3.hide = True
	    compare_3.data_type = 'INT'
	    compare_3.mode = 'ELEMENT'
	    compare_3.operation = 'GREATER_THAN'
	    compare_3.inputs[0].hide = True
	    compare_3.inputs[1].hide = True
	    compare_3.inputs[3].hide = True
	    compare_3.inputs[4].hide = True
	    compare_3.inputs[5].hide = True
	    compare_3.inputs[6].hide = True
	    compare_3.inputs[7].hide = True
	    compare_3.inputs[8].hide = True
	    compare_3.inputs[9].hide = True
	    compare_3.inputs[10].hide = True
	    compare_3.inputs[11].hide = True
	    compare_3.inputs[12].hide = True
	    #B_INT
	    compare_3.inputs[3].default_value = 0
	
	    #node Group.002
	    group_002_1 = braid_guide.nodes.new("GeometryNodeGroup")
	    group_002_1.name = "Group.002"
	    group_002_1.node_tree = braid_production
	
	    #node Group
	    group_5 = braid_guide.nodes.new("GeometryNodeGroup")
	    group_5.name = "Group"
	    group_5.node_tree = attach_hair
	
	    #node Group Input.009
	    group_input_009_1 = braid_guide.nodes.new("NodeGroupInput")
	    group_input_009_1.name = "Group Input.009"
	    group_input_009_1.outputs[0].hide = True
	    group_input_009_1.outputs[1].hide = True
	    group_input_009_1.outputs[2].hide = True
	    group_input_009_1.outputs[3].hide = True
	    group_input_009_1.outputs[4].hide = True
	    group_input_009_1.outputs[5].hide = True
	    group_input_009_1.outputs[6].hide = True
	    group_input_009_1.outputs[7].hide = True
	    group_input_009_1.outputs[11].hide = True
	    group_input_009_1.outputs[12].hide = True
	    group_input_009_1.outputs[13].hide = True
	    group_input_009_1.outputs[14].hide = True
	    group_input_009_1.outputs[15].hide = True
	    group_input_009_1.outputs[16].hide = True
	    group_input_009_1.outputs[17].hide = True
	
	    #node Store Named Attribute
	    store_named_attribute_2 = braid_guide.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_2.name = "Store Named Attribute"
	    store_named_attribute_2.data_type = 'INT'
	    store_named_attribute_2.domain = 'CURVE'
	    #Selection
	    store_named_attribute_2.inputs[1].default_value = True
	    #Name
	    store_named_attribute_2.inputs[2].default_value = "guide_index"
	
	    #node Separate Components
	    separate_components_1 = braid_guide.nodes.new("GeometryNodeSeparateComponents")
	    separate_components_1.name = "Separate Components"
	    separate_components_1.hide = True
	
	    #node Join Geometry.001
	    join_geometry_001_2 = braid_guide.nodes.new("GeometryNodeJoinGeometry")
	    join_geometry_001_2.name = "Join Geometry.001"
	
	    #node Reroute
	    reroute_3 = braid_guide.nodes.new("NodeReroute")
	    reroute_3.name = "Reroute"
	    reroute_3.socket_idname = "NodeSocketGeometry"
	    #node Reroute.001
	    reroute_001_3 = braid_guide.nodes.new("NodeReroute")
	    reroute_001_3.name = "Reroute.001"
	    reroute_001_3.socket_idname = "NodeSocketGeometry"
	    #node Reroute.002
	    reroute_002_3 = braid_guide.nodes.new("NodeReroute")
	    reroute_002_3.name = "Reroute.002"
	    reroute_002_3.socket_idname = "NodeSocketGeometry"
	    #node Reroute.003
	    reroute_003_3 = braid_guide.nodes.new("NodeReroute")
	    reroute_003_3.name = "Reroute.003"
	    reroute_003_3.socket_idname = "NodeSocketGeometry"
	    #node Reroute.004
	    reroute_004_2 = braid_guide.nodes.new("NodeReroute")
	    reroute_004_2.name = "Reroute.004"
	    reroute_004_2.socket_idname = "NodeSocketGeometry"
	    #node Reroute.005
	    reroute_005_1 = braid_guide.nodes.new("NodeReroute")
	    reroute_005_1.name = "Reroute.005"
	    reroute_005_1.socket_idname = "NodeSocketGeometry"
	    #node Reroute.006
	    reroute_006_1 = braid_guide.nodes.new("NodeReroute")
	    reroute_006_1.name = "Reroute.006"
	    reroute_006_1.socket_idname = "NodeSocketGeometry"
	    #node Reroute.007
	    reroute_007_1 = braid_guide.nodes.new("NodeReroute")
	    reroute_007_1.name = "Reroute.007"
	    reroute_007_1.socket_idname = "NodeSocketGeometry"
	    #node Reroute.008
	    reroute_008_1 = braid_guide.nodes.new("NodeReroute")
	    reroute_008_1.name = "Reroute.008"
	    reroute_008_1.socket_idname = "NodeSocketGeometry"
	    #node Reroute.009
	    reroute_009_1 = braid_guide.nodes.new("NodeReroute")
	    reroute_009_1.name = "Reroute.009"
	    reroute_009_1.socket_idname = "NodeSocketGeometry"
	
	    #Process zone input Repeat Input
	    repeat_input.pair_with_output(repeat_output)
	    #Item_2
	    repeat_input.inputs[2].default_value = 0
	
	
	
	
	    #Set parents
	    overall_shape.parent = frame_4
	    spline_parameter_1.parent = frame_4
	
	    #Set locations
	    group_input_6.location = (-340.0, -83.59526062011719)
	    group_output_11.location = (2070.8935546875, 65.15959167480469)
	    repeat_input.location = (-115.1871337890625, -102.63359069824219)
	    repeat_output.location = (691.7540893554688, -110.70162963867188)
	    math_2.location = (530.6305541992188, -135.35345458984375)
	    domain_size.location = (-114.5814208984375, -68.85625457763672)
	    set_spline_type.location = (-116.36692810058594, -33.97276306152344)
	    join_geometry_3.location = (519.3112182617188, -98.60324096679688)
	    final_bake.location = (1895.64892578125, 112.33377075195312)
	    switch_4.location = (324.9697265625, -193.5776824951172)
	    switch_001_4.location = (326.8701171875, -287.88153076171875)
	    switch_002_2.location = (328.77056884765625, -382.31304931640625)
	    group_input_001_4.location = (-105.29757690429688, -266.25567626953125)
	    group_input_003_2.location = (323.24713134765625, -131.20126342773438)
	    group_input_004_2.location = (323.24713134765625, -225.32376098632812)
	    group_input_005_2.location = (323.24713134765625, -318.4955139160156)
	    overall_shape.location = (29.883453369140625, -40.349151611328125)
	    spline_parameter_1.location = (32.18414306640625, -357.4111328125)
	    map_range_2.location = (105.1512451171875, -435.3072814941406)
	    frame_4.location = (-414.0, -362.0)
	    group_001_3.location = (874.2831420898438, -145.77464294433594)
	    group_input_006_2.location = (698.5977172851562, -237.10818481445312)
	    switch_003_2.location = (1162.7373046875, -6.316375732421875)
	    all_braids_bake.location = (872.0, -28.10268783569336)
	    group_input_007_2.location = (1160.021728515625, 88.10610961914062)
	    compare_3.location = (1163.5584716796875, 26.043365478515625)
	    group_002_1.location = (100.11276245117188, -174.39273071289062)
	    group_5.location = (1491.4158935546875, 40.88140869140625)
	    group_input_009_1.location = (1316.994140625, -56.91368103027344)
	    store_named_attribute_2.location = (1162.8626708984375, -160.41880798339844)
	    separate_components_1.location = (-337.11566162109375, -41.61572265625)
	    join_geometry_001_2.location = (1715.87939453125, 64.62376403808594)
	    reroute_3.location = (-102.10568237304688, 195.31814575195312)
	    reroute_001_3.location = (-100.66519165039062, 180.68775939941406)
	    reroute_002_3.location = (-101.59965515136719, 190.24533081054688)
	    reroute_003_3.location = (-100.66519165039062, 185.66261291503906)
	    reroute_004_2.location = (-100.66519165039062, 175.7826385498047)
	    reroute_005_1.location = (1593.370361328125, 181.9987335205078)
	    reroute_006_1.location = (1593.370361328125, 191.9983367919922)
	    reroute_007_1.location = (1593.370361328125, 196.99844360351562)
	    reroute_008_1.location = (1593.370361328125, 176.9988250732422)
	    reroute_009_1.location = (1593.370361328125, 186.99871826171875)
	
	    #Set dimensions
	    group_input_6.width, group_input_6.height = 140.0, 100.0
	    group_output_11.width, group_output_11.height = 140.0, 100.0
	    repeat_input.width, repeat_input.height = 140.0, 100.0
	    repeat_output.width, repeat_output.height = 140.0, 100.0
	    math_2.width, math_2.height = 140.0, 100.0
	    domain_size.width, domain_size.height = 140.0, 100.0
	    set_spline_type.width, set_spline_type.height = 140.0, 100.0
	    join_geometry_3.width, join_geometry_3.height = 140.0, 100.0
	    final_bake.width, final_bake.height = 140.0, 100.0
	    switch_4.width, switch_4.height = 140.0, 100.0
	    switch_001_4.width, switch_001_4.height = 140.0, 100.0
	    switch_002_2.width, switch_002_2.height = 140.0, 100.0
	    group_input_001_4.width, group_input_001_4.height = 140.0, 100.0
	    group_input_003_2.width, group_input_003_2.height = 140.0, 100.0
	    group_input_004_2.width, group_input_004_2.height = 140.0, 100.0
	    group_input_005_2.width, group_input_005_2.height = 140.0, 100.0
	    overall_shape.width, overall_shape.height = 240.0, 100.0
	    spline_parameter_1.width, spline_parameter_1.height = 140.0, 100.0
	    map_range_2.width, map_range_2.height = 140.0, 100.0
	    frame_4.width, frame_4.height = 300.0, 412.0
	    group_001_3.width, group_001_3.height = 140.0, 100.0
	    group_input_006_2.width, group_input_006_2.height = 140.0, 100.0
	    switch_003_2.width, switch_003_2.height = 140.0, 100.0
	    all_braids_bake.width, all_braids_bake.height = 140.0, 100.0
	    group_input_007_2.width, group_input_007_2.height = 140.0, 100.0
	    compare_3.width, compare_3.height = 140.0, 100.0
	    group_002_1.width, group_002_1.height = 140.0, 100.0
	    group_5.width, group_5.height = 140.0, 100.0
	    group_input_009_1.width, group_input_009_1.height = 140.0, 100.0
	    store_named_attribute_2.width, store_named_attribute_2.height = 140.0, 100.0
	    separate_components_1.width, separate_components_1.height = 140.0, 100.0
	    join_geometry_001_2.width, join_geometry_001_2.height = 140.0, 100.0
	    reroute_3.width, reroute_3.height = 10.0, 100.0
	    reroute_001_3.width, reroute_001_3.height = 10.0, 100.0
	    reroute_002_3.width, reroute_002_3.height = 10.0, 100.0
	    reroute_003_3.width, reroute_003_3.height = 10.0, 100.0
	    reroute_004_2.width, reroute_004_2.height = 10.0, 100.0
	    reroute_005_1.width, reroute_005_1.height = 10.0, 100.0
	    reroute_006_1.width, reroute_006_1.height = 10.0, 100.0
	    reroute_007_1.width, reroute_007_1.height = 10.0, 100.0
	    reroute_008_1.width, reroute_008_1.height = 10.0, 100.0
	    reroute_009_1.width, reroute_009_1.height = 10.0, 100.0
	
	    #initialize braid_guide links
	    #domain_size.Spline Count -> repeat_input.Iterations
	    braid_guide.links.new(domain_size.outputs[4], repeat_input.inputs[0])
	    #math_2.Value -> repeat_output.Count
	    braid_guide.links.new(math_2.outputs[0], repeat_output.inputs[1])
	    #join_geometry_3.Geometry -> repeat_output.Geometry
	    braid_guide.links.new(join_geometry_3.outputs[0], repeat_output.inputs[0])
	    #set_spline_type.Curve -> domain_size.Geometry
	    braid_guide.links.new(set_spline_type.outputs[0], domain_size.inputs[0])
	    #final_bake.Geometry -> group_output_11.Geometry
	    braid_guide.links.new(final_bake.outputs[0], group_output_11.inputs[0])
	    #repeat_input.Count -> math_2.Value
	    braid_guide.links.new(repeat_input.outputs[2], math_2.inputs[0])
	    #switch_002_2.Output -> join_geometry_3.Geometry
	    braid_guide.links.new(switch_002_2.outputs[0], join_geometry_3.inputs[0])
	    #group_input_003_2.Use Loop 1 -> switch_4.Switch
	    braid_guide.links.new(group_input_003_2.outputs[4], switch_4.inputs[0])
	    #group_input_004_2.Use Loop 2 -> switch_001_4.Switch
	    braid_guide.links.new(group_input_004_2.outputs[5], switch_001_4.inputs[0])
	    #group_input_005_2.Use Loop 3 -> switch_002_2.Switch
	    braid_guide.links.new(group_input_005_2.outputs[6], switch_002_2.inputs[0])
	    #spline_parameter_1.Factor -> overall_shape.Value
	    braid_guide.links.new(spline_parameter_1.outputs[0], overall_shape.inputs[1])
	    #overall_shape.Value -> map_range_2.Value
	    braid_guide.links.new(overall_shape.outputs[0], map_range_2.inputs[0])
	    #group_input_001_4.Overall Shape Scale -> map_range_2.To Max
	    braid_guide.links.new(group_input_001_4.outputs[3], map_range_2.inputs[4])
	    #all_braids_bake.Geometry -> group_001_3.Geometry
	    braid_guide.links.new(all_braids_bake.outputs[0], group_001_3.inputs[0])
	    #group_input_006_2.Amount -> group_001_3.Amount
	    braid_guide.links.new(group_input_006_2.outputs[11], group_001_3.inputs[1])
	    #group_input_006_2.Viewport Amount -> group_001_3.Viewport Amount
	    braid_guide.links.new(group_input_006_2.outputs[12], group_001_3.inputs[2])
	    #group_input_006_2.Radius -> group_001_3.Radius
	    braid_guide.links.new(group_input_006_2.outputs[13], group_001_3.inputs[3])
	    #group_input_006_2.Distribution Shape -> group_001_3.Distribution Shape
	    braid_guide.links.new(group_input_006_2.outputs[14], group_001_3.inputs[4])
	    #group_input_006_2.Even Thickness -> group_001_3.Even Thickness
	    braid_guide.links.new(group_input_006_2.outputs[15], group_001_3.inputs[6])
	    #group_input_006_2.Seed -> group_001_3.Seed
	    braid_guide.links.new(group_input_006_2.outputs[16], group_001_3.inputs[7])
	    #repeat_output.Geometry -> all_braids_bake.Geometry
	    braid_guide.links.new(repeat_output.outputs[0], all_braids_bake.inputs[0])
	    #group_input_007_2.Amount -> compare_3.A
	    braid_guide.links.new(group_input_007_2.outputs[11], compare_3.inputs[2])
	    #compare_3.Result -> switch_003_2.Switch
	    braid_guide.links.new(compare_3.outputs[0], switch_003_2.inputs[0])
	    #all_braids_bake.Geometry -> switch_003_2.False
	    braid_guide.links.new(all_braids_bake.outputs[0], switch_003_2.inputs[1])
	    #store_named_attribute_2.Geometry -> switch_003_2.True
	    braid_guide.links.new(store_named_attribute_2.outputs[0], switch_003_2.inputs[2])
	    #map_range_2.Result -> group_002_1.Radius
	    braid_guide.links.new(map_range_2.outputs[0], group_002_1.inputs[3])
	    #group_input_001_4.Scale -> group_002_1.Scale
	    braid_guide.links.new(group_input_001_4.outputs[2], group_002_1.inputs[2])
	    #group_input_001_4.Frequency -> group_002_1.Frequency
	    braid_guide.links.new(group_input_001_4.outputs[1], group_002_1.inputs[1])
	    #repeat_input.Count -> group_002_1.Curve Guide Index
	    braid_guide.links.new(repeat_input.outputs[2], group_002_1.inputs[4])
	    #group_input_001_4.Geometry -> group_002_1.Curve Guide
	    braid_guide.links.new(group_input_001_4.outputs[0], group_002_1.inputs[0])
	    #group_002_1.Braid 1 -> switch_4.True
	    braid_guide.links.new(group_002_1.outputs[0], switch_4.inputs[2])
	    #group_002_1.Braid 2 -> switch_001_4.True
	    braid_guide.links.new(group_002_1.outputs[1], switch_001_4.inputs[2])
	    #group_002_1.Braid 3 -> switch_002_2.True
	    braid_guide.links.new(group_002_1.outputs[2], switch_002_2.inputs[2])
	    #group_input_001_4.Extend Root -> group_002_1.Extend Root
	    braid_guide.links.new(group_input_001_4.outputs[7], group_002_1.inputs[5])
	    #switch_003_2.Output -> group_5.Geometry
	    braid_guide.links.new(switch_003_2.outputs[0], group_5.inputs[0])
	    #group_input_009_1.Surface -> group_5.Surface
	    braid_guide.links.new(group_input_009_1.outputs[8], group_5.inputs[1])
	    #group_input_009_1.UV Map -> group_5.UV Map
	    braid_guide.links.new(group_input_009_1.outputs[9], group_5.inputs[2])
	    #group_input_009_1.Blend along Curve -> group_5.Blend along Curve
	    braid_guide.links.new(group_input_009_1.outputs[10], group_5.inputs[3])
	    #group_001_3.Geometry -> store_named_attribute_2.Geometry
	    braid_guide.links.new(group_001_3.outputs[0], store_named_attribute_2.inputs[0])
	    #group_001_3.Guide Index -> store_named_attribute_2.Value
	    braid_guide.links.new(group_001_3.outputs[1], store_named_attribute_2.inputs[3])
	    #group_input_6.Geometry -> separate_components_1.Geometry
	    braid_guide.links.new(group_input_6.outputs[0], separate_components_1.inputs[0])
	    #separate_components_1.Curve -> set_spline_type.Curve
	    braid_guide.links.new(separate_components_1.outputs[1], set_spline_type.inputs[0])
	    #reroute_008_1.Output -> join_geometry_001_2.Geometry
	    braid_guide.links.new(reroute_008_1.outputs[0], join_geometry_001_2.inputs[0])
	    #separate_components_1.Mesh -> reroute_3.Input
	    braid_guide.links.new(separate_components_1.outputs[0], reroute_3.inputs[0])
	    #separate_components_1.Volume -> reroute_001_3.Input
	    braid_guide.links.new(separate_components_1.outputs[4], reroute_001_3.inputs[0])
	    #separate_components_1.Grease Pencil -> reroute_002_3.Input
	    braid_guide.links.new(separate_components_1.outputs[2], reroute_002_3.inputs[0])
	    #separate_components_1.Point Cloud -> reroute_003_3.Input
	    braid_guide.links.new(separate_components_1.outputs[3], reroute_003_3.inputs[0])
	    #separate_components_1.Instances -> reroute_004_2.Input
	    braid_guide.links.new(separate_components_1.outputs[5], reroute_004_2.inputs[0])
	    #reroute_001_3.Output -> reroute_005_1.Input
	    braid_guide.links.new(reroute_001_3.outputs[0], reroute_005_1.inputs[0])
	    #reroute_002_3.Output -> reroute_006_1.Input
	    braid_guide.links.new(reroute_002_3.outputs[0], reroute_006_1.inputs[0])
	    #reroute_3.Output -> reroute_007_1.Input
	    braid_guide.links.new(reroute_3.outputs[0], reroute_007_1.inputs[0])
	    #reroute_004_2.Output -> reroute_008_1.Input
	    braid_guide.links.new(reroute_004_2.outputs[0], reroute_008_1.inputs[0])
	    #reroute_003_3.Output -> reroute_009_1.Input
	    braid_guide.links.new(reroute_003_3.outputs[0], reroute_009_1.inputs[0])
	    #join_geometry_001_2.Geometry -> final_bake.Geometry
	    braid_guide.links.new(join_geometry_001_2.outputs[0], final_bake.inputs[0])
	    #switch_001_4.Output -> join_geometry_3.Geometry
	    braid_guide.links.new(switch_001_4.outputs[0], join_geometry_3.inputs[0])
	    #reroute_005_1.Output -> join_geometry_001_2.Geometry
	    braid_guide.links.new(reroute_005_1.outputs[0], join_geometry_001_2.inputs[0])
	    #switch_4.Output -> join_geometry_3.Geometry
	    braid_guide.links.new(switch_4.outputs[0], join_geometry_3.inputs[0])
	    #reroute_009_1.Output -> join_geometry_001_2.Geometry
	    braid_guide.links.new(reroute_009_1.outputs[0], join_geometry_001_2.inputs[0])
	    #repeat_input.Geometry -> join_geometry_3.Geometry
	    braid_guide.links.new(repeat_input.outputs[1], join_geometry_3.inputs[0])
	    #reroute_006_1.Output -> join_geometry_001_2.Geometry
	    braid_guide.links.new(reroute_006_1.outputs[0], join_geometry_001_2.inputs[0])
	    #reroute_007_1.Output -> join_geometry_001_2.Geometry
	    braid_guide.links.new(reroute_007_1.outputs[0], join_geometry_001_2.inputs[0])
	    #group_5.Geometry -> join_geometry_001_2.Geometry
	    braid_guide.links.new(group_5.outputs[0], join_geometry_001_2.inputs[0])
	    return braid_guide
	return braid_guide_node_group()

	

	
