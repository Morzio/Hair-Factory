import bpy, mathutils

def node():
	#initialize hair_surface_alignment node group
	def hair_surface_alignment_node_group():
	    hair_surface_alignment = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "HAIR_SURFACE_ALIGNMENT")
	
	    hair_surface_alignment.color_tag = 'NONE'
	    hair_surface_alignment.description = "Align Curve tilt to match nearest surface normals."
	    hair_surface_alignment.default_group_node_width = 140
	    
	
	    hair_surface_alignment.is_modifier = True
	
	    #hair_surface_alignment interface
	    #Socket Geometry
	    geometry_socket = hair_surface_alignment.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket.attribute_domain = 'POINT'
	    geometry_socket.description = "Modified hair curve geometry."
	
	    #Socket Geometry
	    geometry_socket_1 = hair_surface_alignment.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_1.attribute_domain = 'POINT'
	    geometry_socket_1.description = "Hair Curve."
	
	    #Socket Surface
	    surface_socket = hair_surface_alignment.interface.new_socket(name = "Surface", in_out='INPUT', socket_type = 'NodeSocketObject')
	    surface_socket.attribute_domain = 'POINT'
	    surface_socket.description = "Surface mesh for alignment."
	
	    #Socket Surface Align Factor
	    surface_align_factor_socket = hair_surface_alignment.interface.new_socket(name = "Surface Align Factor", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    surface_align_factor_socket.default_value = 1.0
	    surface_align_factor_socket.min_value = 0.0
	    surface_align_factor_socket.max_value = 1.0
	    surface_align_factor_socket.subtype = 'FACTOR'
	    surface_align_factor_socket.attribute_domain = 'POINT'
	    surface_align_factor_socket.description = "Percentage of alignment to use."
	
	    #Socket Adjust 90 Degrees
	    adjust_90_degrees_socket = hair_surface_alignment.interface.new_socket(name = "Adjust 90 Degrees", in_out='INPUT', socket_type = 'NodeSocketBool')
	    adjust_90_degrees_socket.default_value = False
	    adjust_90_degrees_socket.attribute_domain = 'POINT'
	    adjust_90_degrees_socket.description = "Tilt curve an additional 90 degrees."
	
	
	    #initialize hair_surface_alignment nodes
	    #node Group Output
	    group_output = hair_surface_alignment.nodes.new("NodeGroupOutput")
	    group_output.name = "Group Output"
	    group_output.is_active_output = True
	    group_output.inputs[1].hide = True
	
	    #node Group Input
	    group_input = hair_surface_alignment.nodes.new("NodeGroupInput")
	    group_input.name = "Group Input"
	    group_input.outputs[0].hide = True
	    group_input.outputs[2].hide = True
	    group_input.outputs[3].hide = True
	    group_input.outputs[4].hide = True
	
	    #node Sample Nearest.003
	    sample_nearest_003 = hair_surface_alignment.nodes.new("GeometryNodeSampleNearest")
	    sample_nearest_003.name = "Sample Nearest.003"
	    sample_nearest_003.hide = True
	    sample_nearest_003.domain = 'POINT'
	    #Sample Position
	    sample_nearest_003.inputs[1].default_value = (0.0, 0.0, 0.0)
	
	    #node Sample Index.003
	    sample_index_003 = hair_surface_alignment.nodes.new("GeometryNodeSampleIndex")
	    sample_index_003.name = "Sample Index.003"
	    sample_index_003.hide = True
	    sample_index_003.clamp = False
	    sample_index_003.data_type = 'FLOAT_VECTOR'
	    sample_index_003.domain = 'POINT'
	
	    #node Normal.006
	    normal_006 = hair_surface_alignment.nodes.new("GeometryNodeInputNormal")
	    normal_006.name = "Normal.006"
	    normal_006.legacy_corner_normals = True
	
	    #node Reroute
	    reroute = hair_surface_alignment.nodes.new("NodeReroute")
	    reroute.name = "Reroute"
	    reroute.socket_idname = "NodeSocketGeometry"
	    #node Map Range
	    map_range = hair_surface_alignment.nodes.new("ShaderNodeMapRange")
	    map_range.name = "Map Range"
	    map_range.hide = True
	    map_range.clamp = False
	    map_range.data_type = 'FLOAT'
	    map_range.interpolation_type = 'LINEAR'
	    map_range.inputs[1].hide = True
	    map_range.inputs[2].hide = True
	    map_range.inputs[3].hide = True
	    map_range.inputs[5].hide = True
	    map_range.inputs[6].hide = True
	    map_range.inputs[7].hide = True
	    map_range.inputs[8].hide = True
	    map_range.inputs[9].hide = True
	    map_range.inputs[10].hide = True
	    map_range.inputs[11].hide = True
	    map_range.outputs[1].hide = True
	    #From Min
	    map_range.inputs[1].default_value = 0.0
	    #From Max
	    map_range.inputs[2].default_value = 1.0
	    #To Min
	    map_range.inputs[3].default_value = 0.0
	
	    #node Group Input.001
	    group_input_001 = hair_surface_alignment.nodes.new("NodeGroupInput")
	    group_input_001.name = "Group Input.001"
	    group_input_001.outputs[0].hide = True
	    group_input_001.outputs[1].hide = True
	    group_input_001.outputs[3].hide = True
	    group_input_001.outputs[4].hide = True
	
	    #node Object Info
	    object_info = hair_surface_alignment.nodes.new("GeometryNodeObjectInfo")
	    object_info.name = "Object Info"
	    object_info.hide = True
	    object_info.transform_space = 'RELATIVE'
	    object_info.inputs[1].hide = True
	    object_info.outputs[0].hide = True
	    object_info.outputs[1].hide = True
	    object_info.outputs[2].hide = True
	    object_info.outputs[3].hide = True
	    #As Instance
	    object_info.inputs[1].default_value = False
	
	    #node Normal.007
	    normal_007 = hair_surface_alignment.nodes.new("GeometryNodeInputNormal")
	    normal_007.name = "Normal.007"
	    normal_007.hide = True
	    normal_007.legacy_corner_normals = True
	
	    #node Curve Tangent.003
	    curve_tangent_003 = hair_surface_alignment.nodes.new("GeometryNodeInputTangent")
	    curve_tangent_003.name = "Curve Tangent.003"
	    curve_tangent_003.hide = True
	
	    #node Vector Math
	    vector_math = hair_surface_alignment.nodes.new("ShaderNodeVectorMath")
	    vector_math.name = "Vector Math"
	    vector_math.operation = 'CROSS_PRODUCT'
	
	    #node Set Spline Type
	    set_spline_type = hair_surface_alignment.nodes.new("GeometryNodeCurveSplineType")
	    set_spline_type.name = "Set Spline Type"
	    set_spline_type.spline_type = 'POLY'
	    set_spline_type.inputs[1].hide = True
	    #Selection
	    set_spline_type.inputs[1].default_value = True
	
	    #node Vector Math.001
	    vector_math_001 = hair_surface_alignment.nodes.new("ShaderNodeVectorMath")
	    vector_math_001.name = "Vector Math.001"
	    vector_math_001.operation = 'CROSS_PRODUCT'
	
	    #node Vector Math.002
	    vector_math_002 = hair_surface_alignment.nodes.new("ShaderNodeVectorMath")
	    vector_math_002.name = "Vector Math.002"
	    vector_math_002.operation = 'DOT_PRODUCT'
	
	    #node Vector Math.003
	    vector_math_003 = hair_surface_alignment.nodes.new("ShaderNodeVectorMath")
	    vector_math_003.name = "Vector Math.003"
	    vector_math_003.operation = 'DOT_PRODUCT'
	
	    #node Curve Tangent.004
	    curve_tangent_004 = hair_surface_alignment.nodes.new("GeometryNodeInputTangent")
	    curve_tangent_004.name = "Curve Tangent.004"
	    curve_tangent_004.hide = True
	
	    #node Math
	    math = hair_surface_alignment.nodes.new("ShaderNodeMath")
	    math.name = "Math"
	    math.operation = 'ARCTAN2'
	    math.use_clamp = False
	
	    #node Math.001
	    math_001 = hair_surface_alignment.nodes.new("ShaderNodeMath")
	    math_001.name = "Math.001"
	    math_001.operation = 'ADD'
	    math_001.use_clamp = False
	
	    #node Curve Tilt
	    curve_tilt = hair_surface_alignment.nodes.new("GeometryNodeInputCurveTilt")
	    curve_tilt.name = "Curve Tilt"
	
	    #node Frame
	    frame = hair_surface_alignment.nodes.new("NodeFrame")
	    frame.label = "Surface Normals"
	    frame.name = "Frame"
	    frame.label_size = 20
	    frame.shrink = True
	
	    #node Frame.001
	    frame_001 = hair_surface_alignment.nodes.new("NodeFrame")
	    frame_001.label = "Tilt Offset"
	    frame_001.name = "Frame.001"
	    frame_001.label_size = 20
	    frame_001.shrink = True
	
	    #node Reroute.001
	    reroute_001 = hair_surface_alignment.nodes.new("NodeReroute")
	    reroute_001.name = "Reroute.001"
	    reroute_001.socket_idname = "NodeSocketVector"
	    #node Reroute.002
	    reroute_002 = hair_surface_alignment.nodes.new("NodeReroute")
	    reroute_002.name = "Reroute.002"
	    reroute_002.socket_idname = "NodeSocketVector"
	    #node Reroute.003
	    reroute_003 = hair_surface_alignment.nodes.new("NodeReroute")
	    reroute_003.name = "Reroute.003"
	    reroute_003.socket_idname = "NodeSocketVector"
	    #node Reroute.004
	    reroute_004 = hair_surface_alignment.nodes.new("NodeReroute")
	    reroute_004.name = "Reroute.004"
	    reroute_004.socket_idname = "NodeSocketVector"
	    #node Reroute.005
	    reroute_005 = hair_surface_alignment.nodes.new("NodeReroute")
	    reroute_005.name = "Reroute.005"
	    reroute_005.socket_idname = "NodeSocketVector"
	    #node Reroute.006
	    reroute_006 = hair_surface_alignment.nodes.new("NodeReroute")
	    reroute_006.name = "Reroute.006"
	    reroute_006.socket_idname = "NodeSocketVector"
	    #node Set Curve Tilt
	    set_curve_tilt = hair_surface_alignment.nodes.new("GeometryNodeSetCurveTilt")
	    set_curve_tilt.name = "Set Curve Tilt"
	    set_curve_tilt.inputs[1].hide = True
	    #Selection
	    set_curve_tilt.inputs[1].default_value = True
	
	    #node Tilt Alignment Curve
	    tilt_alignment_curve = hair_surface_alignment.nodes.new("ShaderNodeFloatCurve")
	    tilt_alignment_curve.label = "Tilt Alignment Curve"
	    tilt_alignment_curve.name = "Tilt Alignment Curve"
	    #mapping settings
	    tilt_alignment_curve.mapping.extend = 'EXTRAPOLATED'
	    tilt_alignment_curve.mapping.tone = 'STANDARD'
	    tilt_alignment_curve.mapping.black_level = (0.0, 0.0, 0.0)
	    tilt_alignment_curve.mapping.white_level = (1.0, 1.0, 1.0)
	    tilt_alignment_curve.mapping.clip_min_x = 0.0
	    tilt_alignment_curve.mapping.clip_min_y = 0.0
	    tilt_alignment_curve.mapping.clip_max_x = 1.0
	    tilt_alignment_curve.mapping.clip_max_y = 1.0
	    tilt_alignment_curve.mapping.use_clip = True
	    #curve 0
	    tilt_alignment_curve_curve_0 = tilt_alignment_curve.mapping.curves[0]
	    tilt_alignment_curve_curve_0_point_0 = tilt_alignment_curve_curve_0.points[0]
	    tilt_alignment_curve_curve_0_point_0.location = (0.0, 1.0)
	    tilt_alignment_curve_curve_0_point_0.handle_type = 'AUTO'
	    tilt_alignment_curve_curve_0_point_1 = tilt_alignment_curve_curve_0.points[1]
	    tilt_alignment_curve_curve_0_point_1.location = (1.0, 1.0)
	    tilt_alignment_curve_curve_0_point_1.handle_type = 'AUTO'
	    #update curve after changes
	    tilt_alignment_curve.mapping.update()
	    tilt_alignment_curve.inputs[0].hide = True
	    #Factor
	    tilt_alignment_curve.inputs[0].default_value = 1.0
	
	    #node Map Range.001
	    map_range_001 = hair_surface_alignment.nodes.new("ShaderNodeMapRange")
	    map_range_001.name = "Map Range.001"
	    map_range_001.hide = True
	    map_range_001.clamp = False
	    map_range_001.data_type = 'FLOAT'
	    map_range_001.interpolation_type = 'LINEAR'
	    map_range_001.inputs[1].hide = True
	    map_range_001.inputs[2].hide = True
	    map_range_001.inputs[3].hide = True
	    map_range_001.inputs[5].hide = True
	    map_range_001.inputs[6].hide = True
	    map_range_001.inputs[7].hide = True
	    map_range_001.inputs[8].hide = True
	    map_range_001.inputs[9].hide = True
	    map_range_001.inputs[10].hide = True
	    map_range_001.inputs[11].hide = True
	    map_range_001.outputs[1].hide = True
	    #From Min
	    map_range_001.inputs[1].default_value = 0.0
	    #From Max
	    map_range_001.inputs[2].default_value = 1.0
	    #To Min
	    map_range_001.inputs[3].default_value = 0.0
	
	    #node Spline Parameter
	    spline_parameter = hair_surface_alignment.nodes.new("GeometryNodeSplineParameter")
	    spline_parameter.name = "Spline Parameter"
	    spline_parameter.hide = True
	    spline_parameter.outputs[1].hide = True
	    spline_parameter.outputs[2].hide = True
	
	    #node Math.002
	    math_002 = hair_surface_alignment.nodes.new("ShaderNodeMath")
	    math_002.name = "Math.002"
	    math_002.hide = True
	    math_002.operation = 'ADD'
	    math_002.use_clamp = False
	
	    #node Group Input.002
	    group_input_002 = hair_surface_alignment.nodes.new("NodeGroupInput")
	    group_input_002.name = "Group Input.002"
	    group_input_002.outputs[1].hide = True
	    group_input_002.outputs[2].hide = True
	    group_input_002.outputs[4].hide = True
	
	    #node Tilt Adjustment
	    tilt_adjustment = hair_surface_alignment.nodes.new("ShaderNodeFloatCurve")
	    tilt_adjustment.label = "Tilt Adjustment"
	    tilt_adjustment.name = "Tilt Adjustment"
	    #mapping settings
	    tilt_adjustment.mapping.extend = 'EXTRAPOLATED'
	    tilt_adjustment.mapping.tone = 'STANDARD'
	    tilt_adjustment.mapping.black_level = (0.0, 0.0, 0.0)
	    tilt_adjustment.mapping.white_level = (1.0, 1.0, 1.0)
	    tilt_adjustment.mapping.clip_min_x = 0.0
	    tilt_adjustment.mapping.clip_min_y = 0.0
	    tilt_adjustment.mapping.clip_max_x = 1.0
	    tilt_adjustment.mapping.clip_max_y = 1.0
	    tilt_adjustment.mapping.use_clip = True
	    #curve 0
	    tilt_adjustment_curve_0 = tilt_adjustment.mapping.curves[0]
	    tilt_adjustment_curve_0_point_0 = tilt_adjustment_curve_0.points[0]
	    tilt_adjustment_curve_0_point_0.location = (0.0, 0.5)
	    tilt_adjustment_curve_0_point_0.handle_type = 'AUTO'
	    tilt_adjustment_curve_0_point_1 = tilt_adjustment_curve_0.points[1]
	    tilt_adjustment_curve_0_point_1.location = (1.0, 0.5)
	    tilt_adjustment_curve_0_point_1.handle_type = 'AUTO'
	    #update curve after changes
	    tilt_adjustment.mapping.update()
	    tilt_adjustment.inputs[0].hide = True
	    #Factor
	    tilt_adjustment.inputs[0].default_value = 1.0
	
	    #node Spline Parameter.001
	    spline_parameter_001 = hair_surface_alignment.nodes.new("GeometryNodeSplineParameter")
	    spline_parameter_001.name = "Spline Parameter.001"
	    spline_parameter_001.hide = True
	    spline_parameter_001.outputs[1].hide = True
	    spline_parameter_001.outputs[2].hide = True
	
	    #node Map Range.002
	    map_range_002 = hair_surface_alignment.nodes.new("ShaderNodeMapRange")
	    map_range_002.name = "Map Range.002"
	    map_range_002.hide = True
	    map_range_002.clamp = False
	    map_range_002.data_type = 'FLOAT'
	    map_range_002.interpolation_type = 'LINEAR'
	    map_range_002.inputs[1].hide = True
	    map_range_002.inputs[2].hide = True
	    map_range_002.inputs[3].hide = True
	    map_range_002.inputs[4].hide = True
	    map_range_002.inputs[5].hide = True
	    map_range_002.inputs[6].hide = True
	    map_range_002.inputs[7].hide = True
	    map_range_002.inputs[8].hide = True
	    map_range_002.inputs[9].hide = True
	    map_range_002.inputs[10].hide = True
	    map_range_002.inputs[11].hide = True
	    map_range_002.outputs[1].hide = True
	    #From Min
	    map_range_002.inputs[1].default_value = 0.0
	    #From Max
	    map_range_002.inputs[2].default_value = 1.0
	    #To Min
	    map_range_002.inputs[3].default_value = -3.1415927410125732
	    #To Max
	    map_range_002.inputs[4].default_value = 3.1415927410125732
	
	    #node Math.003
	    math_003 = hair_surface_alignment.nodes.new("ShaderNodeMath")
	    math_003.name = "Math.003"
	    math_003.hide = True
	    math_003.operation = 'RADIANS'
	    math_003.use_clamp = False
	
	    #node Math.004
	    math_004 = hair_surface_alignment.nodes.new("ShaderNodeMath")
	    math_004.name = "Math.004"
	    math_004.hide = True
	    math_004.operation = 'ADD'
	    math_004.use_clamp = False
	    math_004.inputs[1].hide = True
	    math_004.inputs[2].hide = True
	    #Value_001
	    math_004.inputs[1].default_value = 1.5707963705062866
	
	    #node Switch
	    switch = hair_surface_alignment.nodes.new("GeometryNodeSwitch")
	    switch.name = "Switch"
	    switch.hide = True
	    switch.input_type = 'FLOAT'
	
	    #node Separate Components
	    separate_components = hair_surface_alignment.nodes.new("GeometryNodeSeparateComponents")
	    separate_components.name = "Separate Components"
	    separate_components.hide = True
	
	    #node Join Geometry
	    join_geometry = hair_surface_alignment.nodes.new("GeometryNodeJoinGeometry")
	    join_geometry.name = "Join Geometry"
	
	    #node Reroute.007
	    reroute_007 = hair_surface_alignment.nodes.new("NodeReroute")
	    reroute_007.name = "Reroute.007"
	    reroute_007.socket_idname = "NodeSocketGeometry"
	    #node Reroute.008
	    reroute_008 = hair_surface_alignment.nodes.new("NodeReroute")
	    reroute_008.name = "Reroute.008"
	    reroute_008.socket_idname = "NodeSocketGeometry"
	    #node Reroute.009
	    reroute_009 = hair_surface_alignment.nodes.new("NodeReroute")
	    reroute_009.name = "Reroute.009"
	    reroute_009.socket_idname = "NodeSocketGeometry"
	    #node Reroute.010
	    reroute_010 = hair_surface_alignment.nodes.new("NodeReroute")
	    reroute_010.name = "Reroute.010"
	    reroute_010.socket_idname = "NodeSocketGeometry"
	    #node Reroute.011
	    reroute_011 = hair_surface_alignment.nodes.new("NodeReroute")
	    reroute_011.name = "Reroute.011"
	    reroute_011.socket_idname = "NodeSocketGeometry"
	    #node Reroute.012
	    reroute_012 = hair_surface_alignment.nodes.new("NodeReroute")
	    reroute_012.name = "Reroute.012"
	    reroute_012.socket_idname = "NodeSocketGeometry"
	    #node Reroute.013
	    reroute_013 = hair_surface_alignment.nodes.new("NodeReroute")
	    reroute_013.name = "Reroute.013"
	    reroute_013.socket_idname = "NodeSocketGeometry"
	    #node Reroute.014
	    reroute_014 = hair_surface_alignment.nodes.new("NodeReroute")
	    reroute_014.name = "Reroute.014"
	    reroute_014.socket_idname = "NodeSocketGeometry"
	    #node Reroute.015
	    reroute_015 = hair_surface_alignment.nodes.new("NodeReroute")
	    reroute_015.name = "Reroute.015"
	    reroute_015.socket_idname = "NodeSocketGeometry"
	    #node Reroute.016
	    reroute_016 = hair_surface_alignment.nodes.new("NodeReroute")
	    reroute_016.name = "Reroute.016"
	    reroute_016.socket_idname = "NodeSocketGeometry"
	    #node Hair Surface Alignment Bake
	    hair_surface_alignment_bake = hair_surface_alignment.nodes.new("GeometryNodeBake")
	    hair_surface_alignment_bake.label = "Hair Surface Alignment Bake"
	    hair_surface_alignment_bake.name = "Hair Surface Alignment Bake"
	    hair_surface_alignment_bake.active_index = 0
	    hair_surface_alignment_bake.bake_items.clear()
	    hair_surface_alignment_bake.bake_items.new('GEOMETRY', "Geometry")
	    hair_surface_alignment_bake.bake_items[0].attribute_domain = 'POINT'
	    hair_surface_alignment_bake.inputs[1].hide = True
	    hair_surface_alignment_bake.outputs[1].hide = True
	
	
	
	
	    #Set parents
	    group_input.parent = frame
	    sample_nearest_003.parent = frame
	    sample_index_003.parent = frame
	    normal_006.parent = frame
	    reroute.parent = frame
	    object_info.parent = frame
	    normal_007.parent = frame_001
	    curve_tangent_003.parent = frame_001
	    vector_math.parent = frame_001
	    vector_math_001.parent = frame_001
	    vector_math_002.parent = frame_001
	    vector_math_003.parent = frame_001
	    curve_tangent_004.parent = frame_001
	    math.parent = frame_001
	    math_001.parent = frame_001
	    curve_tilt.parent = frame_001
	    reroute_001.parent = frame_001
	    reroute_003.parent = frame_001
	    reroute_004.parent = frame_001
	    reroute_005.parent = frame_001
	    reroute_006.parent = frame_001
	    tilt_adjustment.parent = frame_001
	    spline_parameter_001.parent = frame_001
	    map_range_002.parent = frame_001
	
	    #Set locations
	    group_output.location = (1766.2362060546875, -58.17168045043945)
	    group_input.location = (30.374053955078125, -96.40690612792969)
	    sample_nearest_003.location = (229.60983276367188, -45.36302947998047)
	    sample_index_003.location = (229.49765014648438, -85.8040771484375)
	    normal_006.location = (227.42202758789062, -123.82649230957031)
	    reroute.location = (192.0732879638672, -74.14251708984375)
	    map_range.location = (948.035400390625, -359.7928466796875)
	    group_input_001.location = (944.666015625, -392.99176025390625)
	    object_info.location = (33.00262451171875, -63.75152587890625)
	    normal_007.location = (29.79510498046875, -319.975341796875)
	    curve_tangent_003.location = (29.79510498046875, -356.0633544921875)
	    vector_math.location = (209.37625122070312, -248.7354736328125)
	    set_spline_type.location = (1053.5963134765625, -108.40625)
	    vector_math_001.location = (535.6417236328125, -140.51602172851562)
	    vector_math_002.location = (742.26171875, -146.87136840820312)
	    vector_math_003.location = (750.4005126953125, -287.6363525390625)
	    curve_tangent_004.location = (534.1580810546875, -283.842041015625)
	    math.location = (938.2330932617188, -159.55422973632812)
	    math_001.location = (1118.5933837890625, -40.013885498046875)
	    curve_tilt.location = (936.494873046875, -93.68789672851562)
	    frame.location = (-384.0, -77.0)
	    frame_001.location = (-384.0, -300.0)
	    reroute_001.location = (428.298095703125, -393.26318359375)
	    reroute_002.location = (44.78921127319336, -173.88510131835938)
	    reroute_003.location = (388.9779968261719, -282.9173583984375)
	    reroute_004.location = (386.8365173339844, -227.5872802734375)
	    reroute_005.location = (390.8068542480469, -369.8052978515625)
	    reroute_006.location = (428.40765380859375, -250.347900390625)
	    set_curve_tilt.location = (1222.911376953125, -82.55923461914062)
	    tilt_alignment_curve.location = (595.8515014648438, 0.543701171875)
	    map_range_001.location = (946.897705078125, -323.3677673339844)
	    spline_parameter.location = (426.27239990234375, -264.02740478515625)
	    math_002.location = (1223.798583984375, -296.9053955078125)
	    group_input_002.location = (1052.2080078125, -215.87109375)
	    tilt_adjustment.location = (1314.604248046875, -208.987548828125)
	    spline_parameter_001.location = (1145.025146484375, -473.55865478515625)
	    map_range_002.location = (1412.8052978515625, -174.2080078125)
	    math_003.location = (1225.4798583984375, -262.2320556640625)
	    math_004.location = (1225.23388671875, -226.44403076171875)
	    switch.location = (1225.47998046875, -191.50772094726562)
	    separate_components.location = (1053.09375, -47.49076843261719)
	    join_geometry.location = (1422.7620849609375, -58.7969856262207)
	    reroute_007.location = (1227.4351806640625, -9.160255432128906)
	    reroute_008.location = (1228.4376220703125, -29.11749267578125)
	    reroute_009.location = (1227.4351806640625, -14.320548057556152)
	    reroute_010.location = (1227.4351806640625, -19.381196975708008)
	    reroute_011.location = (1227.4351806640625, -24.383094787597656)
	    reroute_012.location = (1363.0343017578125, -14.006662368774414)
	    reroute_013.location = (1363.0343017578125, -29.002506256103516)
	    reroute_014.location = (1362.8636474609375, -9.00357437133789)
	    reroute_015.location = (1363.0343017578125, -19.007877349853516)
	    reroute_016.location = (1363.0343017578125, -24.00791358947754)
	    hair_surface_alignment_bake.location = (1586.0, -10.960269927978516)
	
	    #Set dimensions
	    group_output.width, group_output.height = 140.0, 100.0
	    group_input.width, group_input.height = 140.0, 100.0
	    sample_nearest_003.width, sample_nearest_003.height = 140.0, 100.0
	    sample_index_003.width, sample_index_003.height = 140.0, 100.0
	    normal_006.width, normal_006.height = 140.0, 100.0
	    reroute.width, reroute.height = 10.0, 100.0
	    map_range.width, map_range.height = 140.0, 100.0
	    group_input_001.width, group_input_001.height = 140.0, 100.0
	    object_info.width, object_info.height = 140.0, 100.0
	    normal_007.width, normal_007.height = 140.0, 100.0
	    curve_tangent_003.width, curve_tangent_003.height = 140.0, 100.0
	    vector_math.width, vector_math.height = 140.0, 100.0
	    set_spline_type.width, set_spline_type.height = 140.0, 100.0
	    vector_math_001.width, vector_math_001.height = 140.0, 100.0
	    vector_math_002.width, vector_math_002.height = 140.0, 100.0
	    vector_math_003.width, vector_math_003.height = 140.0, 100.0
	    curve_tangent_004.width, curve_tangent_004.height = 140.0, 100.0
	    math.width, math.height = 140.0, 100.0
	    math_001.width, math_001.height = 140.0, 100.0
	    curve_tilt.width, curve_tilt.height = 140.0, 100.0
	    frame.width, frame.height = 400.0, 204.0
	    frame_001.width, frame_001.height = 1585.0, 529.0
	    reroute_001.width, reroute_001.height = 10.0, 100.0
	    reroute_002.width, reroute_002.height = 10.0, 100.0
	    reroute_003.width, reroute_003.height = 10.0, 100.0
	    reroute_004.width, reroute_004.height = 10.0, 100.0
	    reroute_005.width, reroute_005.height = 10.0, 100.0
	    reroute_006.width, reroute_006.height = 10.0, 100.0
	    set_curve_tilt.width, set_curve_tilt.height = 140.0, 100.0
	    tilt_alignment_curve.width, tilt_alignment_curve.height = 240.0, 100.0
	    map_range_001.width, map_range_001.height = 140.0, 100.0
	    spline_parameter.width, spline_parameter.height = 140.0, 100.0
	    math_002.width, math_002.height = 140.0, 100.0
	    group_input_002.width, group_input_002.height = 140.0, 100.0
	    tilt_adjustment.width, tilt_adjustment.height = 240.0, 100.0
	    spline_parameter_001.width, spline_parameter_001.height = 140.0, 100.0
	    map_range_002.width, map_range_002.height = 140.0, 100.0
	    math_003.width, math_003.height = 140.0, 100.0
	    math_004.width, math_004.height = 140.0, 100.0
	    switch.width, switch.height = 140.0, 100.0
	    separate_components.width, separate_components.height = 140.0, 100.0
	    join_geometry.width, join_geometry.height = 140.0, 100.0
	    reroute_007.width, reroute_007.height = 10.0, 100.0
	    reroute_008.width, reroute_008.height = 10.0, 100.0
	    reroute_009.width, reroute_009.height = 10.0, 100.0
	    reroute_010.width, reroute_010.height = 10.0, 100.0
	    reroute_011.width, reroute_011.height = 10.0, 100.0
	    reroute_012.width, reroute_012.height = 10.0, 100.0
	    reroute_013.width, reroute_013.height = 10.0, 100.0
	    reroute_014.width, reroute_014.height = 10.0, 100.0
	    reroute_015.width, reroute_015.height = 10.0, 100.0
	    reroute_016.width, reroute_016.height = 10.0, 100.0
	    hair_surface_alignment_bake.width, hair_surface_alignment_bake.height = 140.0, 100.0
	
	    #initialize hair_surface_alignment links
	    #reroute.Output -> sample_nearest_003.Geometry
	    hair_surface_alignment.links.new(reroute.outputs[0], sample_nearest_003.inputs[0])
	    #normal_006.Normal -> sample_index_003.Value
	    hair_surface_alignment.links.new(normal_006.outputs[0], sample_index_003.inputs[1])
	    #reroute.Output -> sample_index_003.Geometry
	    hair_surface_alignment.links.new(reroute.outputs[0], sample_index_003.inputs[0])
	    #sample_nearest_003.Index -> sample_index_003.Index
	    hair_surface_alignment.links.new(sample_nearest_003.outputs[0], sample_index_003.inputs[2])
	    #group_input_001.Surface Align Factor -> map_range.Value
	    hair_surface_alignment.links.new(group_input_001.outputs[2], map_range.inputs[0])
	    #group_input.Surface -> object_info.Object
	    hair_surface_alignment.links.new(group_input.outputs[1], object_info.inputs[0])
	    #object_info.Geometry -> reroute.Input
	    hair_surface_alignment.links.new(object_info.outputs[4], reroute.inputs[0])
	    #hair_surface_alignment_bake.Geometry -> group_output.Geometry
	    hair_surface_alignment.links.new(hair_surface_alignment_bake.outputs[0], group_output.inputs[0])
	    #normal_007.Normal -> vector_math.Vector
	    hair_surface_alignment.links.new(normal_007.outputs[0], vector_math.inputs[0])
	    #curve_tangent_003.Tangent -> vector_math.Vector
	    hair_surface_alignment.links.new(curve_tangent_003.outputs[0], vector_math.inputs[1])
	    #reroute_004.Output -> vector_math_001.Vector
	    hair_surface_alignment.links.new(reroute_004.outputs[0], vector_math_001.inputs[0])
	    #vector_math_001.Vector -> vector_math_002.Vector
	    hair_surface_alignment.links.new(vector_math_001.outputs[0], vector_math_002.inputs[0])
	    #curve_tangent_004.Tangent -> vector_math_002.Vector
	    hair_surface_alignment.links.new(curve_tangent_004.outputs[0], vector_math_002.inputs[1])
	    #reroute_005.Output -> vector_math_003.Vector
	    hair_surface_alignment.links.new(reroute_005.outputs[0], vector_math_003.inputs[0])
	    #reroute_001.Output -> vector_math_003.Vector
	    hair_surface_alignment.links.new(reroute_001.outputs[0], vector_math_003.inputs[1])
	    #vector_math_002.Value -> math.Value
	    hair_surface_alignment.links.new(vector_math_002.outputs[1], math.inputs[0])
	    #vector_math_003.Value -> math.Value
	    hair_surface_alignment.links.new(vector_math_003.outputs[1], math.inputs[1])
	    #math.Value -> math_001.Value
	    hair_surface_alignment.links.new(math.outputs[0], math_001.inputs[1])
	    #curve_tilt.Tilt -> math_001.Value
	    hair_surface_alignment.links.new(curve_tilt.outputs[0], math_001.inputs[0])
	    #math_001.Value -> map_range.To Max
	    hair_surface_alignment.links.new(math_001.outputs[0], map_range.inputs[4])
	    #reroute_006.Output -> reroute_001.Input
	    hair_surface_alignment.links.new(reroute_006.outputs[0], reroute_001.inputs[0])
	    #sample_index_003.Value -> reroute_002.Input
	    hair_surface_alignment.links.new(sample_index_003.outputs[0], reroute_002.inputs[0])
	    #vector_math.Vector -> reroute_003.Input
	    hair_surface_alignment.links.new(vector_math.outputs[0], reroute_003.inputs[0])
	    #reroute_003.Output -> reroute_004.Input
	    hair_surface_alignment.links.new(reroute_003.outputs[0], reroute_004.inputs[0])
	    #reroute_003.Output -> reroute_005.Input
	    hair_surface_alignment.links.new(reroute_003.outputs[0], reroute_005.inputs[0])
	    #reroute_002.Output -> reroute_006.Input
	    hair_surface_alignment.links.new(reroute_002.outputs[0], reroute_006.inputs[0])
	    #reroute_006.Output -> vector_math_001.Vector
	    hair_surface_alignment.links.new(reroute_006.outputs[0], vector_math_001.inputs[1])
	    #set_spline_type.Curve -> set_curve_tilt.Curve
	    hair_surface_alignment.links.new(set_spline_type.outputs[0], set_curve_tilt.inputs[0])
	    #spline_parameter.Factor -> tilt_alignment_curve.Value
	    hair_surface_alignment.links.new(spline_parameter.outputs[0], tilt_alignment_curve.inputs[1])
	    #tilt_alignment_curve.Value -> map_range_001.Value
	    hair_surface_alignment.links.new(tilt_alignment_curve.outputs[0], map_range_001.inputs[0])
	    #map_range.Result -> map_range_001.To Max
	    hair_surface_alignment.links.new(map_range.outputs[0], map_range_001.inputs[4])
	    #spline_parameter_001.Factor -> tilt_adjustment.Value
	    hair_surface_alignment.links.new(spline_parameter_001.outputs[0], tilt_adjustment.inputs[1])
	    #tilt_adjustment.Value -> map_range_002.Value
	    hair_surface_alignment.links.new(tilt_adjustment.outputs[0], map_range_002.inputs[0])
	    #map_range_002.Result -> math_002.Value
	    hair_surface_alignment.links.new(map_range_002.outputs[0], math_002.inputs[1])
	    #map_range_001.Result -> math_002.Value
	    hair_surface_alignment.links.new(map_range_001.outputs[0], math_002.inputs[0])
	    #math_002.Value -> math_003.Value
	    hair_surface_alignment.links.new(math_002.outputs[0], math_003.inputs[0])
	    #math_003.Value -> math_004.Value
	    hair_surface_alignment.links.new(math_003.outputs[0], math_004.inputs[0])
	    #math_003.Value -> switch.False
	    hair_surface_alignment.links.new(math_003.outputs[0], switch.inputs[1])
	    #math_004.Value -> switch.True
	    hair_surface_alignment.links.new(math_004.outputs[0], switch.inputs[2])
	    #switch.Output -> set_curve_tilt.Tilt
	    hair_surface_alignment.links.new(switch.outputs[0], set_curve_tilt.inputs[2])
	    #group_input_002.Adjust 90 Degrees -> switch.Switch
	    hair_surface_alignment.links.new(group_input_002.outputs[3], switch.inputs[0])
	    #group_input_002.Geometry -> separate_components.Geometry
	    hair_surface_alignment.links.new(group_input_002.outputs[0], separate_components.inputs[0])
	    #separate_components.Curve -> set_spline_type.Curve
	    hair_surface_alignment.links.new(separate_components.outputs[1], set_spline_type.inputs[0])
	    #reroute_013.Output -> join_geometry.Geometry
	    hair_surface_alignment.links.new(reroute_013.outputs[0], join_geometry.inputs[0])
	    #separate_components.Mesh -> reroute_007.Input
	    hair_surface_alignment.links.new(separate_components.outputs[0], reroute_007.inputs[0])
	    #separate_components.Instances -> reroute_008.Input
	    hair_surface_alignment.links.new(separate_components.outputs[5], reroute_008.inputs[0])
	    #separate_components.Grease Pencil -> reroute_009.Input
	    hair_surface_alignment.links.new(separate_components.outputs[2], reroute_009.inputs[0])
	    #separate_components.Point Cloud -> reroute_010.Input
	    hair_surface_alignment.links.new(separate_components.outputs[3], reroute_010.inputs[0])
	    #separate_components.Volume -> reroute_011.Input
	    hair_surface_alignment.links.new(separate_components.outputs[4], reroute_011.inputs[0])
	    #reroute_009.Output -> reroute_012.Input
	    hair_surface_alignment.links.new(reroute_009.outputs[0], reroute_012.inputs[0])
	    #reroute_008.Output -> reroute_013.Input
	    hair_surface_alignment.links.new(reroute_008.outputs[0], reroute_013.inputs[0])
	    #reroute_007.Output -> reroute_014.Input
	    hair_surface_alignment.links.new(reroute_007.outputs[0], reroute_014.inputs[0])
	    #reroute_010.Output -> reroute_015.Input
	    hair_surface_alignment.links.new(reroute_010.outputs[0], reroute_015.inputs[0])
	    #reroute_011.Output -> reroute_016.Input
	    hair_surface_alignment.links.new(reroute_011.outputs[0], reroute_016.inputs[0])
	    #join_geometry.Geometry -> hair_surface_alignment_bake.Geometry
	    hair_surface_alignment.links.new(join_geometry.outputs[0], hair_surface_alignment_bake.inputs[0])
	    #reroute_016.Output -> join_geometry.Geometry
	    hair_surface_alignment.links.new(reroute_016.outputs[0], join_geometry.inputs[0])
	    #reroute_015.Output -> join_geometry.Geometry
	    hair_surface_alignment.links.new(reroute_015.outputs[0], join_geometry.inputs[0])
	    #reroute_012.Output -> join_geometry.Geometry
	    hair_surface_alignment.links.new(reroute_012.outputs[0], join_geometry.inputs[0])
	    #reroute_014.Output -> join_geometry.Geometry
	    hair_surface_alignment.links.new(reroute_014.outputs[0], join_geometry.inputs[0])
	    #set_curve_tilt.Curve -> join_geometry.Geometry
	    hair_surface_alignment.links.new(set_curve_tilt.outputs[0], join_geometry.inputs[0])
	    return hair_surface_alignment
	return hair_surface_alignment_node_group()

	

	
