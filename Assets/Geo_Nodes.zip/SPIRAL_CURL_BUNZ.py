import bpy, mathutils

def node():
	#initialize curve_root_004 node group
	def curve_root_004_node_group():
	    curve_root_004 = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Curve Root.004")
	
	    curve_root_004.color_tag = 'NONE'
	    curve_root_004.description = "Reads information about each curve's root point"
	    curve_root_004.default_group_node_width = 140
	    
	
	
	    #curve_root_004 interface
	    #Socket Root Selection
	    root_selection_socket = curve_root_004.interface.new_socket(name = "Root Selection", in_out='OUTPUT', socket_type = 'NodeSocketBool')
	    root_selection_socket.default_value = False
	    root_selection_socket.attribute_domain = 'POINT'
	    root_selection_socket.description = "Boolean selection of curve root points"
	
	    #Socket Root Position
	    root_position_socket = curve_root_004.interface.new_socket(name = "Root Position", in_out='OUTPUT', socket_type = 'NodeSocketVector')
	    root_position_socket.default_value = (0.0, 0.0, 0.0)
	    root_position_socket.min_value = -3.4028234663852886e+38
	    root_position_socket.max_value = 3.4028234663852886e+38
	    root_position_socket.subtype = 'NONE'
	    root_position_socket.attribute_domain = 'CURVE'
	    root_position_socket.description = "Position of the root point of a curve"
	
	    #Socket Root Direction
	    root_direction_socket = curve_root_004.interface.new_socket(name = "Root Direction", in_out='OUTPUT', socket_type = 'NodeSocketVector')
	    root_direction_socket.default_value = (0.0, 0.0, 0.0)
	    root_direction_socket.min_value = -3.4028234663852886e+38
	    root_direction_socket.max_value = 3.4028234663852886e+38
	    root_direction_socket.subtype = 'NONE'
	    root_direction_socket.attribute_domain = 'CURVE'
	    root_direction_socket.description = "Direction of the root segment of a curve"
	
	    #Socket Root Index
	    root_index_socket = curve_root_004.interface.new_socket(name = "Root Index", in_out='OUTPUT', socket_type = 'NodeSocketInt')
	    root_index_socket.default_value = 0
	    root_index_socket.min_value = -2147483648
	    root_index_socket.max_value = 2147483647
	    root_index_socket.subtype = 'NONE'
	    root_index_socket.attribute_domain = 'CURVE'
	    root_index_socket.description = "Index of the root point of a curve"
	
	
	    #initialize curve_root_004 nodes
	    #node Position.002
	    position_002 = curve_root_004.nodes.new("GeometryNodeInputPosition")
	    position_002.name = "Position.002"
	
	    #node Interpolate Domain
	    interpolate_domain = curve_root_004.nodes.new("GeometryNodeFieldOnDomain")
	    interpolate_domain.name = "Interpolate Domain"
	    interpolate_domain.data_type = 'INT'
	    interpolate_domain.domain = 'CURVE'
	
	    #node Field at Index.003
	    field_at_index_003 = curve_root_004.nodes.new("GeometryNodeFieldAtIndex")
	    field_at_index_003.name = "Field at Index.003"
	    field_at_index_003.data_type = 'FLOAT_VECTOR'
	    field_at_index_003.domain = 'POINT'
	
	    #node Interpolate Domain.001
	    interpolate_domain_001 = curve_root_004.nodes.new("GeometryNodeFieldOnDomain")
	    interpolate_domain_001.name = "Interpolate Domain.001"
	    interpolate_domain_001.data_type = 'FLOAT_VECTOR'
	    interpolate_domain_001.domain = 'CURVE'
	
	    #node Curve Tangent
	    curve_tangent = curve_root_004.nodes.new("GeometryNodeInputTangent")
	    curve_tangent.name = "Curve Tangent"
	
	    #node Endpoint Selection
	    endpoint_selection = curve_root_004.nodes.new("GeometryNodeCurveEndpointSelection")
	    endpoint_selection.name = "Endpoint Selection"
	    #Start Size
	    endpoint_selection.inputs[0].default_value = 1
	    #End Size
	    endpoint_selection.inputs[1].default_value = 0
	
	    #node Field at Index.004
	    field_at_index_004 = curve_root_004.nodes.new("GeometryNodeFieldAtIndex")
	    field_at_index_004.name = "Field at Index.004"
	    field_at_index_004.data_type = 'FLOAT_VECTOR'
	    field_at_index_004.domain = 'POINT'
	
	    #node Interpolate Domain.002
	    interpolate_domain_002 = curve_root_004.nodes.new("GeometryNodeFieldOnDomain")
	    interpolate_domain_002.name = "Interpolate Domain.002"
	    interpolate_domain_002.data_type = 'FLOAT_VECTOR'
	    interpolate_domain_002.domain = 'CURVE'
	
	    #node Group Output
	    group_output = curve_root_004.nodes.new("NodeGroupOutput")
	    group_output.name = "Group Output"
	    group_output.is_active_output = True
	
	    #node Points of Curve
	    points_of_curve = curve_root_004.nodes.new("GeometryNodePointsOfCurve")
	    points_of_curve.name = "Points of Curve"
	    points_of_curve.inputs[0].hide = True
	    points_of_curve.inputs[1].hide = True
	    points_of_curve.outputs[1].hide = True
	    #Curve Index
	    points_of_curve.inputs[0].default_value = 0
	    #Weights
	    points_of_curve.inputs[1].default_value = 0.0
	    #Sort Index
	    points_of_curve.inputs[2].default_value = 0
	
	
	
	
	
	    #Set locations
	    position_002.location = (-608.1627807617188, -70.55814361572266)
	    interpolate_domain.location = (-608.1627807617188, 90.18604278564453)
	    field_at_index_003.location = (-407.2325439453125, 70.09302520751953)
	    interpolate_domain_001.location = (-206.30230712890625, 70.09302520751953)
	    curve_tangent.location = (-608.1627807617188, -271.4883728027344)
	    endpoint_selection.location = (-206.30230712890625, 190.65118408203125)
	    field_at_index_004.location = (-407.2325439453125, -130.83721923828125)
	    interpolate_domain_002.location = (-206.30230712890625, -130.83721923828125)
	    group_output.location = (75.0, 50.0)
	    points_of_curve.location = (-789.0, 50.0)
	
	    #Set dimensions
	    position_002.width, position_002.height = 140.0, 100.0
	    interpolate_domain.width, interpolate_domain.height = 140.0, 100.0
	    field_at_index_003.width, field_at_index_003.height = 140.0, 100.0
	    interpolate_domain_001.width, interpolate_domain_001.height = 140.0, 100.0
	    curve_tangent.width, curve_tangent.height = 140.0, 100.0
	    endpoint_selection.width, endpoint_selection.height = 140.0, 100.0
	    field_at_index_004.width, field_at_index_004.height = 140.0, 100.0
	    interpolate_domain_002.width, interpolate_domain_002.height = 140.0, 100.0
	    group_output.width, group_output.height = 140.0, 100.0
	    points_of_curve.width, points_of_curve.height = 140.0, 100.0
	
	    #initialize curve_root_004 links
	    #position_002.Position -> field_at_index_003.Value
	    curve_root_004.links.new(position_002.outputs[0], field_at_index_003.inputs[1])
	    #interpolate_domain_001.Value -> group_output.Root Position
	    curve_root_004.links.new(interpolate_domain_001.outputs[0], group_output.inputs[1])
	    #interpolate_domain.Value -> field_at_index_003.Index
	    curve_root_004.links.new(interpolate_domain.outputs[0], field_at_index_003.inputs[0])
	    #points_of_curve.Point Index -> interpolate_domain.Value
	    curve_root_004.links.new(points_of_curve.outputs[0], interpolate_domain.inputs[0])
	    #interpolate_domain.Value -> group_output.Root Index
	    curve_root_004.links.new(interpolate_domain.outputs[0], group_output.inputs[3])
	    #endpoint_selection.Selection -> group_output.Root Selection
	    curve_root_004.links.new(endpoint_selection.outputs[0], group_output.inputs[0])
	    #field_at_index_003.Value -> interpolate_domain_001.Value
	    curve_root_004.links.new(field_at_index_003.outputs[0], interpolate_domain_001.inputs[0])
	    #interpolate_domain_002.Value -> group_output.Root Direction
	    curve_root_004.links.new(interpolate_domain_002.outputs[0], group_output.inputs[2])
	    #interpolate_domain.Value -> field_at_index_004.Index
	    curve_root_004.links.new(interpolate_domain.outputs[0], field_at_index_004.inputs[0])
	    #curve_tangent.Tangent -> field_at_index_004.Value
	    curve_root_004.links.new(curve_tangent.outputs[0], field_at_index_004.inputs[1])
	    #field_at_index_004.Value -> interpolate_domain_002.Value
	    curve_root_004.links.new(field_at_index_004.outputs[0], interpolate_domain_002.inputs[0])
	    return curve_root_004
	
	curve_root_004 = curve_root_004_node_group()
	
	#initialize curve_tip_002 node group
	def curve_tip_002_node_group():
	    curve_tip_002 = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Curve Tip.002")
	
	    curve_tip_002.color_tag = 'NONE'
	    curve_tip_002.description = "Reads information about each curve's tip point"
	    curve_tip_002.default_group_node_width = 140
	    
	
	
	    #curve_tip_002 interface
	    #Socket Tip Selection
	    tip_selection_socket = curve_tip_002.interface.new_socket(name = "Tip Selection", in_out='OUTPUT', socket_type = 'NodeSocketBool')
	    tip_selection_socket.default_value = False
	    tip_selection_socket.attribute_domain = 'POINT'
	    tip_selection_socket.description = "Boolean selection of curve tip points"
	
	    #Socket Tip Position
	    tip_position_socket = curve_tip_002.interface.new_socket(name = "Tip Position", in_out='OUTPUT', socket_type = 'NodeSocketVector')
	    tip_position_socket.default_value = (0.0, 0.0, 0.0)
	    tip_position_socket.min_value = -3.4028234663852886e+38
	    tip_position_socket.max_value = 3.4028234663852886e+38
	    tip_position_socket.subtype = 'NONE'
	    tip_position_socket.attribute_domain = 'CURVE'
	    tip_position_socket.description = "Position of the tip point of a curve"
	
	    #Socket Tip Direction
	    tip_direction_socket = curve_tip_002.interface.new_socket(name = "Tip Direction", in_out='OUTPUT', socket_type = 'NodeSocketVector')
	    tip_direction_socket.default_value = (0.0, 0.0, 0.0)
	    tip_direction_socket.min_value = -3.4028234663852886e+38
	    tip_direction_socket.max_value = 3.4028234663852886e+38
	    tip_direction_socket.subtype = 'NONE'
	    tip_direction_socket.attribute_domain = 'CURVE'
	    tip_direction_socket.description = "Direction of the tip segment of a curve"
	
	    #Socket Tip Index
	    tip_index_socket = curve_tip_002.interface.new_socket(name = "Tip Index", in_out='OUTPUT', socket_type = 'NodeSocketInt')
	    tip_index_socket.default_value = 0
	    tip_index_socket.min_value = -2147483648
	    tip_index_socket.max_value = 2147483647
	    tip_index_socket.subtype = 'NONE'
	    tip_index_socket.attribute_domain = 'CURVE'
	    tip_index_socket.description = "Index of the tip point of a curve"
	
	
	    #initialize curve_tip_002 nodes
	    #node Position.002
	    position_002_1 = curve_tip_002.nodes.new("GeometryNodeInputPosition")
	    position_002_1.name = "Position.002"
	
	    #node Interpolate Domain
	    interpolate_domain_1 = curve_tip_002.nodes.new("GeometryNodeFieldOnDomain")
	    interpolate_domain_1.name = "Interpolate Domain"
	    interpolate_domain_1.data_type = 'INT'
	    interpolate_domain_1.domain = 'CURVE'
	
	    #node Interpolate Domain.001
	    interpolate_domain_001_1 = curve_tip_002.nodes.new("GeometryNodeFieldOnDomain")
	    interpolate_domain_001_1.name = "Interpolate Domain.001"
	    interpolate_domain_001_1.data_type = 'FLOAT_VECTOR'
	    interpolate_domain_001_1.domain = 'CURVE'
	
	    #node Field at Index.003
	    field_at_index_003_1 = curve_tip_002.nodes.new("GeometryNodeFieldAtIndex")
	    field_at_index_003_1.name = "Field at Index.003"
	    field_at_index_003_1.data_type = 'FLOAT_VECTOR'
	    field_at_index_003_1.domain = 'POINT'
	
	    #node Curve Tangent
	    curve_tangent_1 = curve_tip_002.nodes.new("GeometryNodeInputTangent")
	    curve_tangent_1.name = "Curve Tangent"
	
	    #node Endpoint Selection
	    endpoint_selection_1 = curve_tip_002.nodes.new("GeometryNodeCurveEndpointSelection")
	    endpoint_selection_1.name = "Endpoint Selection"
	    #Start Size
	    endpoint_selection_1.inputs[0].default_value = 0
	    #End Size
	    endpoint_selection_1.inputs[1].default_value = 1
	
	    #node Field at Index.004
	    field_at_index_004_1 = curve_tip_002.nodes.new("GeometryNodeFieldAtIndex")
	    field_at_index_004_1.name = "Field at Index.004"
	    field_at_index_004_1.data_type = 'FLOAT_VECTOR'
	    field_at_index_004_1.domain = 'POINT'
	
	    #node Interpolate Domain.002
	    interpolate_domain_002_1 = curve_tip_002.nodes.new("GeometryNodeFieldOnDomain")
	    interpolate_domain_002_1.name = "Interpolate Domain.002"
	    interpolate_domain_002_1.data_type = 'FLOAT_VECTOR'
	    interpolate_domain_002_1.domain = 'CURVE'
	
	    #node Group Output
	    group_output_1 = curve_tip_002.nodes.new("NodeGroupOutput")
	    group_output_1.name = "Group Output"
	    group_output_1.is_active_output = True
	
	    #node Points of Curve
	    points_of_curve_1 = curve_tip_002.nodes.new("GeometryNodePointsOfCurve")
	    points_of_curve_1.name = "Points of Curve"
	    points_of_curve_1.inputs[0].hide = True
	    points_of_curve_1.inputs[1].hide = True
	    points_of_curve_1.outputs[1].hide = True
	    #Curve Index
	    points_of_curve_1.inputs[0].default_value = 0
	    #Weights
	    points_of_curve_1.inputs[1].default_value = 0.0
	    #Sort Index
	    points_of_curve_1.inputs[2].default_value = -1
	
	
	
	
	
	    #Set locations
	    position_002_1.location = (-628.2557983398438, -70.55813598632812)
	    interpolate_domain_1.location = (-628.2557983398438, 90.18605041503906)
	    interpolate_domain_001_1.location = (-246.4883575439453, 90.18605041503906)
	    field_at_index_003_1.location = (-427.3255615234375, 90.18605041503906)
	    curve_tangent_1.location = (-628.2557983398438, -231.3023223876953)
	    endpoint_selection_1.location = (-246.4883575439453, 210.7441864013672)
	    field_at_index_004_1.location = (-427.3255615234375, -90.65116882324219)
	    interpolate_domain_002_1.location = (-246.4883575439453, -90.65116882324219)
	    group_output_1.location = (75.0, 50.0)
	    points_of_curve_1.location = (-829.18603515625, 50.0)
	
	    #Set dimensions
	    position_002_1.width, position_002_1.height = 140.0, 100.0
	    interpolate_domain_1.width, interpolate_domain_1.height = 140.0, 100.0
	    interpolate_domain_001_1.width, interpolate_domain_001_1.height = 140.0, 100.0
	    field_at_index_003_1.width, field_at_index_003_1.height = 140.0, 100.0
	    curve_tangent_1.width, curve_tangent_1.height = 140.0, 100.0
	    endpoint_selection_1.width, endpoint_selection_1.height = 140.0, 100.0
	    field_at_index_004_1.width, field_at_index_004_1.height = 140.0, 100.0
	    interpolate_domain_002_1.width, interpolate_domain_002_1.height = 140.0, 100.0
	    group_output_1.width, group_output_1.height = 140.0, 100.0
	    points_of_curve_1.width, points_of_curve_1.height = 140.0, 100.0
	
	    #initialize curve_tip_002 links
	    #position_002_1.Position -> field_at_index_003_1.Value
	    curve_tip_002.links.new(position_002_1.outputs[0], field_at_index_003_1.inputs[1])
	    #interpolate_domain_1.Value -> field_at_index_003_1.Index
	    curve_tip_002.links.new(interpolate_domain_1.outputs[0], field_at_index_003_1.inputs[0])
	    #points_of_curve_1.Point Index -> interpolate_domain_1.Value
	    curve_tip_002.links.new(points_of_curve_1.outputs[0], interpolate_domain_1.inputs[0])
	    #interpolate_domain_001_1.Value -> group_output_1.Tip Position
	    curve_tip_002.links.new(interpolate_domain_001_1.outputs[0], group_output_1.inputs[1])
	    #interpolate_domain_1.Value -> group_output_1.Tip Index
	    curve_tip_002.links.new(interpolate_domain_1.outputs[0], group_output_1.inputs[3])
	    #endpoint_selection_1.Selection -> group_output_1.Tip Selection
	    curve_tip_002.links.new(endpoint_selection_1.outputs[0], group_output_1.inputs[0])
	    #field_at_index_003_1.Value -> interpolate_domain_001_1.Value
	    curve_tip_002.links.new(field_at_index_003_1.outputs[0], interpolate_domain_001_1.inputs[0])
	    #interpolate_domain_002_1.Value -> group_output_1.Tip Direction
	    curve_tip_002.links.new(interpolate_domain_002_1.outputs[0], group_output_1.inputs[2])
	    #curve_tangent_1.Tangent -> field_at_index_004_1.Value
	    curve_tip_002.links.new(curve_tangent_1.outputs[0], field_at_index_004_1.inputs[1])
	    #interpolate_domain_1.Value -> field_at_index_004_1.Index
	    curve_tip_002.links.new(interpolate_domain_1.outputs[0], field_at_index_004_1.inputs[0])
	    #field_at_index_004_1.Value -> interpolate_domain_002_1.Value
	    curve_tip_002.links.new(field_at_index_004_1.outputs[0], interpolate_domain_002_1.inputs[0])
	    return curve_tip_002
	
	curve_tip_002 = curve_tip_002_node_group()
	
	#initialize curve_info_002 node group
	def curve_info_002_node_group():
	    curve_info_002 = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Curve Info.002")
	
	    curve_info_002.color_tag = 'NONE'
	    curve_info_002.description = "Reads information about each curve"
	    curve_info_002.default_group_node_width = 140
	    
	
	
	    #curve_info_002 interface
	    #Socket Curve Index
	    curve_index_socket = curve_info_002.interface.new_socket(name = "Curve Index", in_out='OUTPUT', socket_type = 'NodeSocketInt')
	    curve_index_socket.default_value = 0
	    curve_index_socket.min_value = -2147483648
	    curve_index_socket.max_value = 2147483647
	    curve_index_socket.subtype = 'NONE'
	    curve_index_socket.attribute_domain = 'CURVE'
	    curve_index_socket.description = "Index of each Curve"
	
	    #Socket Curve ID
	    curve_id_socket = curve_info_002.interface.new_socket(name = "Curve ID", in_out='OUTPUT', socket_type = 'NodeSocketInt')
	    curve_id_socket.default_value = 0
	    curve_id_socket.min_value = -2147483648
	    curve_id_socket.max_value = 2147483647
	    curve_id_socket.subtype = 'NONE'
	    curve_id_socket.attribute_domain = 'CURVE'
	    curve_id_socket.description = "ID of each curve"
	
	    #Socket Length
	    length_socket = curve_info_002.interface.new_socket(name = "Length", in_out='OUTPUT', socket_type = 'NodeSocketFloat')
	    length_socket.default_value = 0.0
	    length_socket.min_value = -3.4028234663852886e+38
	    length_socket.max_value = 3.4028234663852886e+38
	    length_socket.subtype = 'NONE'
	    length_socket.attribute_domain = 'CURVE'
	    length_socket.description = "Length of each curve"
	
	    #Socket Direction
	    direction_socket = curve_info_002.interface.new_socket(name = "Direction", in_out='OUTPUT', socket_type = 'NodeSocketVector')
	    direction_socket.default_value = (0.0, 0.0, 0.0)
	    direction_socket.min_value = -3.4028234663852886e+38
	    direction_socket.max_value = 3.4028234663852886e+38
	    direction_socket.subtype = 'NONE'
	    direction_socket.attribute_domain = 'CURVE'
	    direction_socket.description = "Direction from root to tip of each curve"
	
	    #Socket Random
	    random_socket = curve_info_002.interface.new_socket(name = "Random", in_out='OUTPUT', socket_type = 'NodeSocketFloat')
	    random_socket.default_value = 0.0
	    random_socket.min_value = -3.4028234663852886e+38
	    random_socket.max_value = 3.4028234663852886e+38
	    random_socket.subtype = 'NONE'
	    random_socket.attribute_domain = 'CURVE'
	    random_socket.description = "Random vector for each curve"
	
	    #Socket Surface UV
	    surface_uv_socket = curve_info_002.interface.new_socket(name = "Surface UV", in_out='OUTPUT', socket_type = 'NodeSocketVector')
	    surface_uv_socket.default_value = (0.0, 0.0, 0.0)
	    surface_uv_socket.min_value = -3.4028234663852886e+38
	    surface_uv_socket.max_value = 3.4028234663852886e+38
	    surface_uv_socket.subtype = 'NONE'
	    surface_uv_socket.attribute_domain = 'CURVE'
	    surface_uv_socket.description = "Attachment surface UV coordinates of each curve"
	
	
	    #initialize curve_info_002 nodes
	    #node Frame
	    frame = curve_info_002.nodes.new("NodeFrame")
	    frame.label = "ID per Curve"
	    frame.name = "Frame"
	    frame.label_size = 20
	    frame.shrink = True
	
	    #node Group Output
	    group_output_2 = curve_info_002.nodes.new("NodeGroupOutput")
	    group_output_2.name = "Group Output"
	    group_output_2.is_active_output = True
	
	    #node Named Attribute
	    named_attribute = curve_info_002.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute.name = "Named Attribute"
	    named_attribute.data_type = 'FLOAT_VECTOR'
	    #Name
	    named_attribute.inputs[0].default_value = "surface_uv_coordinate"
	
	    #node Group.002
	    group_002 = curve_info_002.nodes.new("GeometryNodeGroup")
	    group_002.name = "Group.002"
	    group_002.node_tree = curve_tip_002
	    group_002.outputs[0].hide = True
	    group_002.outputs[2].hide = True
	    group_002.outputs[3].hide = True
	
	    #node Group.001
	    group_001 = curve_info_002.nodes.new("GeometryNodeGroup")
	    group_001.name = "Group.001"
	    group_001.node_tree = curve_root_004
	    group_001.outputs[0].hide = True
	    group_001.outputs[2].hide = True
	    group_001.outputs[3].hide = True
	
	    #node Evaluate at Index
	    evaluate_at_index = curve_info_002.nodes.new("GeometryNodeFieldAtIndex")
	    evaluate_at_index.name = "Evaluate at Index"
	    evaluate_at_index.data_type = 'FLOAT'
	    evaluate_at_index.domain = 'POINT'
	
	    #node Evaluate on Domain.001
	    evaluate_on_domain_001 = curve_info_002.nodes.new("GeometryNodeFieldOnDomain")
	    evaluate_on_domain_001.name = "Evaluate on Domain.001"
	    evaluate_on_domain_001.data_type = 'FLOAT'
	    evaluate_on_domain_001.domain = 'CURVE'
	
	    #node Group.003
	    group_003 = curve_info_002.nodes.new("GeometryNodeGroup")
	    group_003.name = "Group.003"
	    group_003.node_tree = curve_root_004
	    group_003.outputs[0].hide = True
	    group_003.outputs[1].hide = True
	    group_003.outputs[2].hide = True
	
	    #node Random Value.002
	    random_value_002 = curve_info_002.nodes.new("FunctionNodeRandomValue")
	    random_value_002.name = "Random Value.002"
	    random_value_002.data_type = 'FLOAT'
	    #Min_001
	    random_value_002.inputs[2].default_value = 0.0
	    #Max_001
	    random_value_002.inputs[3].default_value = 1.0
	    #Seed
	    random_value_002.inputs[8].default_value = 0
	
	    #node Reroute
	    reroute = curve_info_002.nodes.new("NodeReroute")
	    reroute.name = "Reroute"
	    reroute.socket_idname = "NodeSocketInt"
	    #node Vector Math
	    vector_math = curve_info_002.nodes.new("ShaderNodeVectorMath")
	    vector_math.name = "Vector Math"
	    vector_math.operation = 'SUBTRACT'
	
	    #node Vector Math.001
	    vector_math_001 = curve_info_002.nodes.new("ShaderNodeVectorMath")
	    vector_math_001.name = "Vector Math.001"
	    vector_math_001.operation = 'NORMALIZE'
	
	    #node Evaluate on Domain
	    evaluate_on_domain = curve_info_002.nodes.new("GeometryNodeFieldOnDomain")
	    evaluate_on_domain.name = "Evaluate on Domain"
	    evaluate_on_domain.hide = True
	    evaluate_on_domain.data_type = 'INT'
	    evaluate_on_domain.domain = 'CURVE'
	
	    #node Index.001
	    index_001 = curve_info_002.nodes.new("GeometryNodeInputIndex")
	    index_001.name = "Index.001"
	
	    #node Spline Length
	    spline_length = curve_info_002.nodes.new("GeometryNodeSplineLength")
	    spline_length.name = "Spline Length"
	    spline_length.outputs[1].hide = True
	
	    #node Evaluate at Index.001
	    evaluate_at_index_001 = curve_info_002.nodes.new("GeometryNodeFieldAtIndex")
	    evaluate_at_index_001.name = "Evaluate at Index.001"
	    evaluate_at_index_001.data_type = 'INT'
	    evaluate_at_index_001.domain = 'POINT'
	
	    #node Evaluate on Domain.002
	    evaluate_on_domain_002 = curve_info_002.nodes.new("GeometryNodeFieldOnDomain")
	    evaluate_on_domain_002.name = "Evaluate on Domain.002"
	    evaluate_on_domain_002.data_type = 'INT'
	    evaluate_on_domain_002.domain = 'CURVE'
	
	    #node Group
	    group = curve_info_002.nodes.new("GeometryNodeGroup")
	    group.name = "Group"
	    group.node_tree = curve_root_004
	    group.outputs[0].hide = True
	    group.outputs[1].hide = True
	    group.outputs[2].hide = True
	
	    #node ID
	    id = curve_info_002.nodes.new("GeometryNodeInputID")
	    id.name = "ID"
	
	
	
	
	    #Set parents
	    evaluate_at_index_001.parent = frame
	    evaluate_on_domain_002.parent = frame
	    group.parent = frame
	    id.parent = frame
	
	    #Set locations
	    frame.location = (-1200.55810546875, 150.5814208984375)
	    group_output_2.location = (75.0, 50.0)
	    named_attribute.location = (-166.11627197265625, -371.9534912109375)
	    group_002.location = (-527.7907104492188, -90.65116882324219)
	    group_001.location = (-527.7907104492188, -171.02325439453125)
	    evaluate_at_index.location = (-346.9534912109375, -211.2093048095703)
	    evaluate_on_domain_001.location = (-166.11627197265625, -211.2093048095703)
	    group_003.location = (-527.7907104492188, -251.39535522460938)
	    random_value_002.location = (-527.7907104492188, -331.7674560546875)
	    reroute.location = (-608.162841796875, 29.906982421875)
	    vector_math.location = (-346.9534912109375, -70.55814361572266)
	    vector_math_001.location = (-166.11627197265625, -70.55814361572266)
	    evaluate_on_domain.location = (-166.11627197265625, 70.093017578125)
	    index_001.location = (-346.9534912109375, 110.27906799316406)
	    spline_length.location = (-166.11627197265625, -10.279067993164062)
	    evaluate_at_index_001.location = (210.62786865234375, -40.30235290527344)
	    evaluate_on_domain_002.location = (391.465087890625, -40.30235290527344)
	    group.location = (29.7906494140625, -60.3953857421875)
	    id.location = (29.7906494140625, -140.76747131347656)
	
	    #Set dimensions
	    frame.width, frame.height = 561.9534301757812, 225.93026733398438
	    group_output_2.width, group_output_2.height = 140.0, 100.0
	    named_attribute.width, named_attribute.height = 140.0, 100.0
	    group_002.width, group_002.height = 140.0, 100.0
	    group_001.width, group_001.height = 140.0, 100.0
	    evaluate_at_index.width, evaluate_at_index.height = 140.0, 100.0
	    evaluate_on_domain_001.width, evaluate_on_domain_001.height = 140.0, 100.0
	    group_003.width, group_003.height = 140.0, 100.0
	    random_value_002.width, random_value_002.height = 140.0, 100.0
	    reroute.width, reroute.height = 100.0, 100.0
	    vector_math.width, vector_math.height = 140.0, 100.0
	    vector_math_001.width, vector_math_001.height = 140.0, 100.0
	    evaluate_on_domain.width, evaluate_on_domain.height = 140.0, 100.0
	    index_001.width, index_001.height = 140.0, 100.0
	    spline_length.width, spline_length.height = 140.0, 100.0
	    evaluate_at_index_001.width, evaluate_at_index_001.height = 140.0, 100.0
	    evaluate_on_domain_002.width, evaluate_on_domain_002.height = 140.0, 100.0
	    group.width, group.height = 140.0, 100.0
	    id.width, id.height = 140.0, 100.0
	
	    #initialize curve_info_002 links
	    #index_001.Index -> evaluate_on_domain.Value
	    curve_info_002.links.new(index_001.outputs[0], evaluate_on_domain.inputs[0])
	    #evaluate_on_domain.Value -> group_output_2.Curve Index
	    curve_info_002.links.new(evaluate_on_domain.outputs[0], group_output_2.inputs[0])
	    #named_attribute.Attribute -> group_output_2.Surface UV
	    curve_info_002.links.new(named_attribute.outputs[0], group_output_2.inputs[5])
	    #evaluate_at_index_001.Value -> evaluate_on_domain_002.Value
	    curve_info_002.links.new(evaluate_at_index_001.outputs[0], evaluate_on_domain_002.inputs[0])
	    #group.Root Index -> evaluate_at_index_001.Index
	    curve_info_002.links.new(group.outputs[3], evaluate_at_index_001.inputs[0])
	    #reroute.Output -> group_output_2.Curve ID
	    curve_info_002.links.new(reroute.outputs[0], group_output_2.inputs[1])
	    #id.ID -> evaluate_at_index_001.Value
	    curve_info_002.links.new(id.outputs[0], evaluate_at_index_001.inputs[1])
	    #spline_length.Length -> group_output_2.Length
	    curve_info_002.links.new(spline_length.outputs[0], group_output_2.inputs[2])
	    #group_002.Tip Position -> vector_math.Vector
	    curve_info_002.links.new(group_002.outputs[1], vector_math.inputs[0])
	    #group_001.Root Position -> vector_math.Vector
	    curve_info_002.links.new(group_001.outputs[1], vector_math.inputs[1])
	    #vector_math_001.Vector -> group_output_2.Direction
	    curve_info_002.links.new(vector_math_001.outputs[0], group_output_2.inputs[3])
	    #vector_math.Vector -> vector_math_001.Vector
	    curve_info_002.links.new(vector_math.outputs[0], vector_math_001.inputs[0])
	    #reroute.Output -> random_value_002.ID
	    curve_info_002.links.new(reroute.outputs[0], random_value_002.inputs[7])
	    #evaluate_at_index.Value -> evaluate_on_domain_001.Value
	    curve_info_002.links.new(evaluate_at_index.outputs[0], evaluate_on_domain_001.inputs[0])
	    #evaluate_on_domain_001.Value -> group_output_2.Random
	    curve_info_002.links.new(evaluate_on_domain_001.outputs[0], group_output_2.inputs[4])
	    #random_value_002.Value -> evaluate_at_index.Value
	    curve_info_002.links.new(random_value_002.outputs[1], evaluate_at_index.inputs[1])
	    #group_003.Root Index -> evaluate_at_index.Index
	    curve_info_002.links.new(group_003.outputs[3], evaluate_at_index.inputs[0])
	    #evaluate_on_domain_002.Value -> reroute.Input
	    curve_info_002.links.new(evaluate_on_domain_002.outputs[0], reroute.inputs[0])
	    return curve_info_002
	
	curve_info_002 = curve_info_002_node_group()
	
	#initialize duplicate_hair_curves node group
	def duplicate_hair_curves_node_group():
	    duplicate_hair_curves = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Duplicate Hair Curves")
	
	    duplicate_hair_curves.color_tag = 'NONE'
	    duplicate_hair_curves.description = "Duplicates hair curves a certain number of times within a radius"
	    duplicate_hair_curves.default_group_node_width = 140
	    
	
	    duplicate_hair_curves.is_modifier = True
	
	    #duplicate_hair_curves interface
	    #Socket Geometry
	    geometry_socket = duplicate_hair_curves.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket.attribute_domain = 'POINT'
	
	    #Socket Guide Index
	    guide_index_socket = duplicate_hair_curves.interface.new_socket(name = "Guide Index", in_out='OUTPUT', socket_type = 'NodeSocketInt')
	    guide_index_socket.default_value = 0
	    guide_index_socket.min_value = -2147483648
	    guide_index_socket.max_value = 2147483647
	    guide_index_socket.subtype = 'NONE'
	    guide_index_socket.attribute_domain = 'CURVE'
	    guide_index_socket.description = "Guide index map that was used for the operation"
	
	    #Socket Geometry
	    geometry_socket_1 = duplicate_hair_curves.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_1.attribute_domain = 'POINT'
	    geometry_socket_1.description = "Input Geometry (May include other than curves)"
	
	    #Socket Amount
	    amount_socket = duplicate_hair_curves.interface.new_socket(name = "Amount", in_out='INPUT', socket_type = 'NodeSocketInt')
	    amount_socket.default_value = 10
	    amount_socket.min_value = 0
	    amount_socket.max_value = 2147483647
	    amount_socket.subtype = 'NONE'
	    amount_socket.attribute_domain = 'POINT'
	    amount_socket.description = "Amount of duplicates per curve"
	
	    #Socket Viewport Amount
	    viewport_amount_socket = duplicate_hair_curves.interface.new_socket(name = "Viewport Amount", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    viewport_amount_socket.default_value = 1.0
	    viewport_amount_socket.min_value = 0.0
	    viewport_amount_socket.max_value = 1.0
	    viewport_amount_socket.subtype = 'FACTOR'
	    viewport_amount_socket.attribute_domain = 'POINT'
	    viewport_amount_socket.description = "Percentage of amount used for the viewport"
	
	    #Socket Radius
	    radius_socket = duplicate_hair_curves.interface.new_socket(name = "Radius", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    radius_socket.default_value = 0.10000000149011612
	    radius_socket.min_value = 0.0
	    radius_socket.max_value = 3.4028234663852886e+38
	    radius_socket.subtype = 'DISTANCE'
	    radius_socket.attribute_domain = 'POINT'
	    radius_socket.description = "Radius in which the duplicate curves are offset from the guides"
	
	    #Socket Distribution Shape
	    distribution_shape_socket = duplicate_hair_curves.interface.new_socket(name = "Distribution Shape", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    distribution_shape_socket.default_value = 0.0
	    distribution_shape_socket.min_value = -10.0
	    distribution_shape_socket.max_value = 10.0
	    distribution_shape_socket.subtype = 'NONE'
	    distribution_shape_socket.attribute_domain = 'POINT'
	    distribution_shape_socket.description = "Shape of distribution from center to the edge around the guide"
	
	    #Socket Tip Roundness
	    tip_roundness_socket = duplicate_hair_curves.interface.new_socket(name = "Tip Roundness", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    tip_roundness_socket.default_value = 0.0
	    tip_roundness_socket.min_value = 0.0
	    tip_roundness_socket.max_value = 1.0
	    tip_roundness_socket.subtype = 'FACTOR'
	    tip_roundness_socket.attribute_domain = 'POINT'
	    tip_roundness_socket.description = "Offset of the curves to round the tip"
	
	    #Socket Even Thickness
	    even_thickness_socket = duplicate_hair_curves.interface.new_socket(name = "Even Thickness", in_out='INPUT', socket_type = 'NodeSocketBool')
	    even_thickness_socket.default_value = False
	    even_thickness_socket.attribute_domain = 'POINT'
	    even_thickness_socket.description = "Keep an even thickness of the distribution of duplicates"
	
	    #Socket Seed
	    seed_socket = duplicate_hair_curves.interface.new_socket(name = "Seed", in_out='INPUT', socket_type = 'NodeSocketInt')
	    seed_socket.default_value = 0
	    seed_socket.min_value = -10000
	    seed_socket.max_value = 10000
	    seed_socket.subtype = 'NONE'
	    seed_socket.attribute_domain = 'POINT'
	    seed_socket.description = "Random Seed for the operation"
	
	
	    #initialize duplicate_hair_curves nodes
	    #node Frame.002
	    frame_002 = duplicate_hair_curves.nodes.new("NodeFrame")
	    frame_002.label = "Random Disc Position"
	    frame_002.name = "Frame.002"
	    frame_002.label_size = 20
	    frame_002.shrink = True
	
	    #node Frame.001
	    frame_001 = duplicate_hair_curves.nodes.new("NodeFrame")
	    frame_001.label = "Tangent Space per Point"
	    frame_001.name = "Frame.001"
	    frame_001.label_size = 20
	    frame_001.shrink = True
	
	    #node Frame
	    frame_1 = duplicate_hair_curves.nodes.new("NodeFrame")
	    frame_1.label = "Tangent Space of Root Point"
	    frame_1.name = "Frame"
	    frame_1.label_size = 20
	    frame_1.shrink = True
	
	    #node Frame.004
	    frame_004 = duplicate_hair_curves.nodes.new("NodeFrame")
	    frame_004.label = "Duplicate Curves"
	    frame_004.name = "Frame.004"
	    frame_004.label_size = 20
	    frame_004.shrink = True
	
	    #node Frame.003
	    frame_003 = duplicate_hair_curves.nodes.new("NodeFrame")
	    frame_003.label = "Random Vector per Curve"
	    frame_003.name = "Frame.003"
	    frame_003.label_size = 20
	    frame_003.shrink = True
	
	    #node Reroute.016
	    reroute_016 = duplicate_hair_curves.nodes.new("NodeReroute")
	    reroute_016.name = "Reroute.016"
	    reroute_016.socket_idname = "NodeSocketGeometry"
	    #node Reroute.017
	    reroute_017 = duplicate_hair_curves.nodes.new("NodeReroute")
	    reroute_017.name = "Reroute.017"
	    reroute_017.socket_idname = "NodeSocketGeometry"
	    #node Reroute.019
	    reroute_019 = duplicate_hair_curves.nodes.new("NodeReroute")
	    reroute_019.name = "Reroute.019"
	    reroute_019.socket_idname = "NodeSocketGeometry"
	    #node Reroute.018
	    reroute_018 = duplicate_hair_curves.nodes.new("NodeReroute")
	    reroute_018.name = "Reroute.018"
	    reroute_018.socket_idname = "NodeSocketGeometry"
	    #node Group Input
	    group_input = duplicate_hair_curves.nodes.new("NodeGroupInput")
	    group_input.name = "Group Input"
	    group_input.outputs[1].hide = True
	    group_input.outputs[2].hide = True
	    group_input.outputs[3].hide = True
	    group_input.outputs[4].hide = True
	    group_input.outputs[5].hide = True
	    group_input.outputs[6].hide = True
	    group_input.outputs[7].hide = True
	    group_input.outputs[8].hide = True
	
	    #node Group Output
	    group_output_3 = duplicate_hair_curves.nodes.new("NodeGroupOutput")
	    group_output_3.name = "Group Output"
	    group_output_3.is_active_output = True
	
	    #node Separate Components
	    separate_components = duplicate_hair_curves.nodes.new("GeometryNodeSeparateComponents")
	    separate_components.name = "Separate Components"
	    separate_components.hide = True
	
	    #node Math.053
	    math_053 = duplicate_hair_curves.nodes.new("ShaderNodeMath")
	    math_053.name = "Math.053"
	    math_053.hide = True
	    math_053.operation = 'ARCCOSINE'
	    math_053.use_clamp = False
	
	    #node Math.055
	    math_055 = duplicate_hair_curves.nodes.new("ShaderNodeMath")
	    math_055.name = "Math.055"
	    math_055.hide = True
	    math_055.operation = 'DIVIDE'
	    math_055.use_clamp = False
	    #Value_001
	    math_055.inputs[1].default_value = 1.5707963705062866
	
	    #node Math.056
	    math_056 = duplicate_hair_curves.nodes.new("ShaderNodeMath")
	    math_056.name = "Math.056"
	    math_056.hide = True
	    math_056.operation = 'POWER'
	    math_056.use_clamp = False
	    #Value
	    math_056.inputs[0].default_value = 2.0
	
	    #node Group Input.006
	    group_input_006 = duplicate_hair_curves.nodes.new("NodeGroupInput")
	    group_input_006.name = "Group Input.006"
	    group_input_006.outputs[0].hide = True
	    group_input_006.outputs[1].hide = True
	    group_input_006.outputs[2].hide = True
	    group_input_006.outputs[3].hide = True
	    group_input_006.outputs[5].hide = True
	    group_input_006.outputs[6].hide = True
	    group_input_006.outputs[7].hide = True
	    group_input_006.outputs[8].hide = True
	
	    #node Separate XYZ.002
	    separate_xyz_002 = duplicate_hair_curves.nodes.new("ShaderNodeSeparateXYZ")
	    separate_xyz_002.name = "Separate XYZ.002"
	
	    #node Math.054
	    math_054 = duplicate_hair_curves.nodes.new("ShaderNodeMath")
	    math_054.name = "Math.054"
	    math_054.operation = 'POWER'
	    math_054.use_clamp = False
	
	    #node Math.052
	    math_052 = duplicate_hair_curves.nodes.new("ShaderNodeMath")
	    math_052.name = "Math.052"
	    math_052.hide = True
	    math_052.operation = 'MULTIPLY'
	    math_052.use_clamp = False
	    #Value_001
	    math_052.inputs[1].default_value = 6.2831854820251465
	
	    #node Combine XYZ.002
	    combine_xyz_002 = duplicate_hair_curves.nodes.new("ShaderNodeCombineXYZ")
	    combine_xyz_002.name = "Combine XYZ.002"
	    combine_xyz_002.inputs[1].hide = True
	    combine_xyz_002.inputs[2].hide = True
	    #Y
	    combine_xyz_002.inputs[1].default_value = 0.0
	    #Z
	    combine_xyz_002.inputs[2].default_value = 0.0
	
	    #node Math.059
	    math_059 = duplicate_hair_curves.nodes.new("ShaderNodeMath")
	    math_059.name = "Math.059"
	    math_059.hide = True
	    math_059.operation = 'SUBTRACT'
	    math_059.use_clamp = False
	    #Value_001
	    math_059.inputs[1].default_value = 0.5
	
	    #node Math.058
	    math_058 = duplicate_hair_curves.nodes.new("ShaderNodeMath")
	    math_058.name = "Math.058"
	    math_058.hide = True
	    math_058.operation = 'POWER'
	    math_058.use_clamp = False
	    #Value_001
	    math_058.inputs[1].default_value = 2.0
	
	    #node Vector Rotate
	    vector_rotate = duplicate_hair_curves.nodes.new("ShaderNodeVectorRotate")
	    vector_rotate.name = "Vector Rotate"
	    vector_rotate.invert = False
	    vector_rotate.rotation_type = 'Z_AXIS'
	    vector_rotate.inputs[1].hide = True
	    vector_rotate.inputs[2].hide = True
	    vector_rotate.inputs[4].hide = True
	    #Center
	    vector_rotate.inputs[1].default_value = (0.0, 0.0, 0.0)
	
	    #node Math.057
	    math_057 = duplicate_hair_curves.nodes.new("ShaderNodeMath")
	    math_057.name = "Math.057"
	    math_057.operation = 'ADD'
	    math_057.use_clamp = False
	
	    #node Group Input.007
	    group_input_007 = duplicate_hair_curves.nodes.new("NodeGroupInput")
	    group_input_007.name = "Group Input.007"
	    group_input_007.outputs[0].hide = True
	    group_input_007.outputs[1].hide = True
	    group_input_007.outputs[2].hide = True
	    group_input_007.outputs[3].hide = True
	    group_input_007.outputs[4].hide = True
	    group_input_007.outputs[6].hide = True
	    group_input_007.outputs[7].hide = True
	    group_input_007.outputs[8].hide = True
	
	    #node Combine XYZ
	    combine_xyz = duplicate_hair_curves.nodes.new("ShaderNodeCombineXYZ")
	    combine_xyz.name = "Combine XYZ"
	    combine_xyz.inputs[0].hide = True
	    combine_xyz.inputs[1].hide = True
	    #X
	    combine_xyz.inputs[0].default_value = 0.0
	    #Y
	    combine_xyz.inputs[1].default_value = 0.0
	
	    #node Vector Math.014
	    vector_math_014 = duplicate_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_014.name = "Vector Math.014"
	    vector_math_014.operation = 'SCALE'
	
	    #node Vector Math.013
	    vector_math_013 = duplicate_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_013.name = "Vector Math.013"
	    vector_math_013.operation = 'SUBTRACT'
	
	    #node Reroute.001
	    reroute_001 = duplicate_hair_curves.nodes.new("NodeReroute")
	    reroute_001.name = "Reroute.001"
	    reroute_001.socket_idname = "NodeSocketGeometry"
	    #node Reroute.003
	    reroute_003 = duplicate_hair_curves.nodes.new("NodeReroute")
	    reroute_003.name = "Reroute.003"
	    reroute_003.socket_idname = "NodeSocketBool"
	    #node Set Position
	    set_position = duplicate_hair_curves.nodes.new("GeometryNodeSetPosition")
	    set_position.name = "Set Position"
	    #Position
	    set_position.inputs[2].default_value = (0.0, 0.0, 0.0)
	
	    #node Set Position.001
	    set_position_001 = duplicate_hair_curves.nodes.new("GeometryNodeSetPosition")
	    set_position_001.name = "Set Position.001"
	    #Position
	    set_position_001.inputs[2].default_value = (0.0, 0.0, 0.0)
	
	    #node Normal
	    normal = duplicate_hair_curves.nodes.new("GeometryNodeInputNormal")
	    normal.name = "Normal"
	    normal.legacy_corner_normals = True
	
	    #node Curve Tangent
	    curve_tangent_2 = duplicate_hair_curves.nodes.new("GeometryNodeInputTangent")
	    curve_tangent_2.name = "Curve Tangent"
	
	    #node Separate XYZ
	    separate_xyz = duplicate_hair_curves.nodes.new("ShaderNodeSeparateXYZ")
	    separate_xyz.name = "Separate XYZ"
	
	    #node Vector Math.001
	    vector_math_001_1 = duplicate_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_001_1.name = "Vector Math.001"
	    vector_math_001_1.operation = 'SCALE'
	
	    #node Vector Math.003
	    vector_math_003 = duplicate_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_003.name = "Vector Math.003"
	    vector_math_003.operation = 'ADD'
	
	    #node Vector Math.002
	    vector_math_002 = duplicate_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_002.name = "Vector Math.002"
	    vector_math_002.operation = 'SCALE'
	
	    #node Vector Math.009
	    vector_math_009 = duplicate_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_009.name = "Vector Math.009"
	    vector_math_009.operation = 'ADD'
	
	    #node Vector Math.010
	    vector_math_010 = duplicate_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_010.name = "Vector Math.010"
	    vector_math_010.operation = 'SCALE'
	
	    #node Vector Math
	    vector_math_1 = duplicate_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_1.name = "Vector Math"
	    vector_math_1.operation = 'CROSS_PRODUCT'
	
	    #node Group.001
	    group_001_1 = duplicate_hair_curves.nodes.new("GeometryNodeGroup")
	    group_001_1.name = "Group.001"
	    group_001_1.node_tree = curve_root_004
	    group_001_1.outputs[0].hide = True
	    group_001_1.outputs[1].hide = True
	    group_001_1.outputs[2].hide = True
	
	    #node Evaluate on Domain.002
	    evaluate_on_domain_002_1 = duplicate_hair_curves.nodes.new("GeometryNodeFieldOnDomain")
	    evaluate_on_domain_002_1.name = "Evaluate on Domain.002"
	    evaluate_on_domain_002_1.data_type = 'FLOAT_VECTOR'
	    evaluate_on_domain_002_1.domain = 'CURVE'
	
	    #node Separate XYZ.001
	    separate_xyz_001 = duplicate_hair_curves.nodes.new("ShaderNodeSeparateXYZ")
	    separate_xyz_001.name = "Separate XYZ.001"
	
	    #node Vector Math.011
	    vector_math_011 = duplicate_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_011.name = "Vector Math.011"
	    vector_math_011.operation = 'ADD'
	
	    #node Vector Math.005
	    vector_math_005 = duplicate_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_005.name = "Vector Math.005"
	    vector_math_005.operation = 'ADD'
	
	    #node Vector Math.007
	    vector_math_007 = duplicate_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_007.name = "Vector Math.007"
	    vector_math_007.operation = 'SCALE'
	
	    #node Vector Math.008
	    vector_math_008 = duplicate_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_008.name = "Vector Math.008"
	    vector_math_008.operation = 'CROSS_PRODUCT'
	
	    #node Evaluate at Index
	    evaluate_at_index_1 = duplicate_hair_curves.nodes.new("GeometryNodeFieldAtIndex")
	    evaluate_at_index_1.name = "Evaluate at Index"
	    evaluate_at_index_1.data_type = 'FLOAT_VECTOR'
	    evaluate_at_index_1.domain = 'POINT'
	
	    #node Vector Math.012
	    vector_math_012 = duplicate_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_012.name = "Vector Math.012"
	    vector_math_012.operation = 'SCALE'
	
	    #node Vector Math.006
	    vector_math_006 = duplicate_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_006.name = "Vector Math.006"
	    vector_math_006.operation = 'SCALE'
	
	    #node Evaluate on Domain.001
	    evaluate_on_domain_001_1 = duplicate_hair_curves.nodes.new("GeometryNodeFieldOnDomain")
	    evaluate_on_domain_001_1.name = "Evaluate on Domain.001"
	    evaluate_on_domain_001_1.hide = True
	    evaluate_on_domain_001_1.data_type = 'FLOAT_VECTOR'
	    evaluate_on_domain_001_1.domain = 'POINT'
	
	    #node Curve Tangent.001
	    curve_tangent_001 = duplicate_hair_curves.nodes.new("GeometryNodeInputTangent")
	    curve_tangent_001.name = "Curve Tangent.001"
	
	    #node Normal.001
	    normal_001 = duplicate_hair_curves.nodes.new("GeometryNodeInputNormal")
	    normal_001.name = "Normal.001"
	    normal_001.legacy_corner_normals = True
	
	    #node Reroute.014
	    reroute_014 = duplicate_hair_curves.nodes.new("NodeReroute")
	    reroute_014.name = "Reroute.014"
	    reroute_014.socket_idname = "NodeSocketGeometry"
	    #node Reroute.015
	    reroute_015 = duplicate_hair_curves.nodes.new("NodeReroute")
	    reroute_015.name = "Reroute.015"
	    reroute_015.socket_idname = "NodeSocketGeometry"
	    #node Reroute.013
	    reroute_013 = duplicate_hair_curves.nodes.new("NodeReroute")
	    reroute_013.name = "Reroute.013"
	    reroute_013.socket_idname = "NodeSocketGeometry"
	    #node Reroute.012
	    reroute_012 = duplicate_hair_curves.nodes.new("NodeReroute")
	    reroute_012.name = "Reroute.012"
	    reroute_012.socket_idname = "NodeSocketGeometry"
	    #node Is Viewport
	    is_viewport = duplicate_hair_curves.nodes.new("GeometryNodeIsViewport")
	    is_viewport.name = "Is Viewport"
	
	    #node Switch
	    switch = duplicate_hair_curves.nodes.new("GeometryNodeSwitch")
	    switch.name = "Switch"
	    switch.input_type = 'INT'
	
	    #node ID
	    id_1 = duplicate_hair_curves.nodes.new("GeometryNodeInputID")
	    id_1.name = "ID"
	
	    #node Reroute.004
	    reroute_004 = duplicate_hair_curves.nodes.new("NodeReroute")
	    reroute_004.name = "Reroute.004"
	    reroute_004.socket_idname = "NodeSocketInt"
	    #node Reroute.002
	    reroute_002 = duplicate_hair_curves.nodes.new("NodeReroute")
	    reroute_002.name = "Reroute.002"
	    reroute_002.socket_idname = "NodeSocketGeometry"
	    #node Join Geometry
	    join_geometry = duplicate_hair_curves.nodes.new("GeometryNodeJoinGeometry")
	    join_geometry.name = "Join Geometry"
	
	    #node Set ID
	    set_id = duplicate_hair_curves.nodes.new("GeometryNodeSetID")
	    set_id.name = "Set ID"
	    #Selection
	    set_id.inputs[1].default_value = True
	
	    #node Store Named Attribute
	    store_named_attribute = duplicate_hair_curves.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute.name = "Store Named Attribute"
	    store_named_attribute.data_type = 'INT'
	    store_named_attribute.domain = 'CURVE'
	    #Selection
	    store_named_attribute.inputs[1].default_value = True
	    #Name
	    store_named_attribute.inputs[2].default_value = "guide_curve_index"
	
	    #node Math
	    math = duplicate_hair_curves.nodes.new("ShaderNodeMath")
	    math.name = "Math"
	    math.hide = True
	    math.operation = 'MULTIPLY'
	    math.use_clamp = False
	
	    #node Group Input.002
	    group_input_002 = duplicate_hair_curves.nodes.new("NodeGroupInput")
	    group_input_002.name = "Group Input.002"
	    group_input_002.outputs[0].hide = True
	    group_input_002.outputs[1].hide = True
	    group_input_002.outputs[3].hide = True
	    group_input_002.outputs[4].hide = True
	    group_input_002.outputs[5].hide = True
	    group_input_002.outputs[6].hide = True
	    group_input_002.outputs[7].hide = True
	    group_input_002.outputs[8].hide = True
	
	    #node Group Input.004
	    group_input_004 = duplicate_hair_curves.nodes.new("NodeGroupInput")
	    group_input_004.name = "Group Input.004"
	    group_input_004.outputs[0].hide = True
	    group_input_004.outputs[2].hide = True
	    group_input_004.outputs[3].hide = True
	    group_input_004.outputs[4].hide = True
	    group_input_004.outputs[5].hide = True
	    group_input_004.outputs[6].hide = True
	    group_input_004.outputs[7].hide = True
	    group_input_004.outputs[8].hide = True
	
	    #node Capture Attribute.002
	    capture_attribute_002 = duplicate_hair_curves.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_002.name = "Capture Attribute.002"
	    capture_attribute_002.active_index = 0
	    capture_attribute_002.capture_items.clear()
	    capture_attribute_002.capture_items.new('FLOAT', "Value")
	    capture_attribute_002.capture_items["Value"].data_type = 'BOOLEAN'
	    capture_attribute_002.domain = 'POINT'
	    #Value
	    capture_attribute_002.inputs[1].default_value = True
	
	    #node Vector Math.004
	    vector_math_004 = duplicate_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_004.name = "Vector Math.004"
	    vector_math_004.operation = 'SCALE'
	
	    #node Group Input.003
	    group_input_003 = duplicate_hair_curves.nodes.new("NodeGroupInput")
	    group_input_003.name = "Group Input.003"
	    group_input_003.outputs[0].hide = True
	    group_input_003.outputs[1].hide = True
	    group_input_003.outputs[2].hide = True
	    group_input_003.outputs[4].hide = True
	    group_input_003.outputs[5].hide = True
	    group_input_003.outputs[6].hide = True
	    group_input_003.outputs[7].hide = True
	    group_input_003.outputs[8].hide = True
	
	    #node Random Value.001
	    random_value_001 = duplicate_hair_curves.nodes.new("FunctionNodeRandomValue")
	    random_value_001.name = "Random Value.001"
	    random_value_001.data_type = 'FLOAT_VECTOR'
	    #Min
	    random_value_001.inputs[0].default_value = (0.0, 0.0, 0.0)
	    #Max
	    random_value_001.inputs[1].default_value = (1.0, 1.0, 1.0)
	
	    #node Capture Attribute
	    capture_attribute = duplicate_hair_curves.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute.name = "Capture Attribute"
	    capture_attribute.active_index = 0
	    capture_attribute.capture_items.clear()
	    capture_attribute.capture_items.new('FLOAT', "Value")
	    capture_attribute.capture_items["Value"].data_type = 'INT'
	    capture_attribute.domain = 'POINT'
	
	    #node Duplicate Elements
	    duplicate_elements = duplicate_hair_curves.nodes.new("GeometryNodeDuplicateElements")
	    duplicate_elements.name = "Duplicate Elements"
	    duplicate_elements.domain = 'SPLINE'
	    #Selection
	    duplicate_elements.inputs[1].default_value = True
	
	    #node Join Geometry.001
	    join_geometry_001 = duplicate_hair_curves.nodes.new("GeometryNodeJoinGeometry")
	    join_geometry_001.name = "Join Geometry.001"
	
	    #node Random Value
	    random_value = duplicate_hair_curves.nodes.new("FunctionNodeRandomValue")
	    random_value.name = "Random Value"
	    random_value.data_type = 'INT'
	    #Min_002
	    random_value.inputs[4].default_value = -1073741823
	    #Max_002
	    random_value.inputs[5].default_value = 1073741823
	
	    #node Reroute.020
	    reroute_020 = duplicate_hair_curves.nodes.new("NodeReroute")
	    reroute_020.name = "Reroute.020"
	    reroute_020.socket_idname = "NodeSocketGeometry"
	    #node Index
	    index = duplicate_hair_curves.nodes.new("GeometryNodeInputIndex")
	    index.name = "Index"
	
	    #node Capture Attribute.001
	    capture_attribute_001 = duplicate_hair_curves.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_001.name = "Capture Attribute.001"
	    capture_attribute_001.active_index = 0
	    capture_attribute_001.capture_items.clear()
	    capture_attribute_001.capture_items.new('FLOAT', "Value")
	    capture_attribute_001.capture_items["Value"].data_type = 'INT'
	    capture_attribute_001.domain = 'CURVE'
	
	    #node Switch.001
	    switch_001 = duplicate_hair_curves.nodes.new("GeometryNodeSwitch")
	    switch_001.name = "Switch.001"
	    switch_001.input_type = 'GEOMETRY'
	
	    #node Group
	    group_1 = duplicate_hair_curves.nodes.new("GeometryNodeGroup")
	    group_1.name = "Group"
	    group_1.node_tree = curve_info_002
	    group_1.outputs[0].hide = True
	    group_1.outputs[2].hide = True
	    group_1.outputs[3].hide = True
	    group_1.outputs[4].hide = True
	    group_1.outputs[5].hide = True
	
	    #node Group Input.001
	    group_input_001 = duplicate_hair_curves.nodes.new("NodeGroupInput")
	    group_input_001.name = "Group Input.001"
	    group_input_001.outputs[0].hide = True
	    group_input_001.outputs[1].hide = True
	    group_input_001.outputs[2].hide = True
	    group_input_001.outputs[3].hide = True
	    group_input_001.outputs[4].hide = True
	    group_input_001.outputs[5].hide = True
	    group_input_001.outputs[6].hide = True
	    group_input_001.outputs[8].hide = True
	
	    #node Group Input.005
	    group_input_005 = duplicate_hair_curves.nodes.new("NodeGroupInput")
	    group_input_005.name = "Group Input.005"
	    group_input_005.outputs[0].hide = True
	    group_input_005.outputs[1].hide = True
	    group_input_005.outputs[2].hide = True
	    group_input_005.outputs[3].hide = True
	    group_input_005.outputs[4].hide = True
	    group_input_005.outputs[5].hide = True
	    group_input_005.outputs[7].hide = True
	    group_input_005.outputs[8].hide = True
	
	    #node Random Value.004
	    random_value_004 = duplicate_hair_curves.nodes.new("FunctionNodeRandomValue")
	    random_value_004.name = "Random Value.004"
	    random_value_004.data_type = 'INT'
	    #Min_002
	    random_value_004.inputs[4].default_value = -1073741823
	    #Max_002
	    random_value_004.inputs[5].default_value = 1073741823
	    #Seed
	    random_value_004.inputs[8].default_value = 296
	
	
	
	
	    #Set parents
	    math_053.parent = frame_002
	    math_055.parent = frame_002
	    math_056.parent = frame_002
	    group_input_006.parent = frame_002
	    separate_xyz_002.parent = frame_002
	    math_054.parent = frame_002
	    math_052.parent = frame_002
	    combine_xyz_002.parent = frame_002
	    math_059.parent = frame_002
	    math_058.parent = frame_002
	    vector_rotate.parent = frame_002
	    math_057.parent = frame_002
	    group_input_007.parent = frame_002
	    combine_xyz.parent = frame_002
	    vector_math_014.parent = frame_002
	    vector_math_013.parent = frame_002
	    normal.parent = frame_001
	    curve_tangent_2.parent = frame_001
	    separate_xyz.parent = frame_001
	    vector_math_001_1.parent = frame_001
	    vector_math_003.parent = frame_001
	    vector_math_002.parent = frame_001
	    vector_math_009.parent = frame_001
	    vector_math_010.parent = frame_001
	    vector_math_1.parent = frame_001
	    group_001_1.parent = frame_1
	    evaluate_on_domain_002_1.parent = frame_1
	    separate_xyz_001.parent = frame_1
	    vector_math_011.parent = frame_1
	    vector_math_005.parent = frame_1
	    vector_math_007.parent = frame_1
	    vector_math_008.parent = frame_1
	    evaluate_at_index_1.parent = frame_1
	    vector_math_012.parent = frame_1
	    vector_math_006.parent = frame_1
	    evaluate_on_domain_001_1.parent = frame_1
	    curve_tangent_001.parent = frame_1
	    normal_001.parent = frame_1
	    is_viewport.parent = frame_004
	    switch.parent = frame_004
	    id_1.parent = frame_004
	    reroute_004.parent = frame_004
	    reroute_002.parent = frame_004
	    join_geometry.parent = frame_004
	    set_id.parent = frame_004
	    store_named_attribute.parent = frame_004
	    math.parent = frame_004
	    group_input_002.parent = frame_004
	    group_input_004.parent = frame_004
	    capture_attribute_002.parent = frame_004
	    random_value_001.parent = frame_003
	    capture_attribute.parent = frame_004
	    duplicate_elements.parent = frame_004
	    random_value.parent = frame_004
	    group_1.parent = frame_003
	    group_input_001.parent = frame_003
	    random_value_004.parent = frame_003
	
	    #Set locations
	    frame_002.location = (-4255.0, -613.0)
	    frame_001.location = (-1965.0, -734.0)
	    frame_1.location = (-2265.0, -272.0)
	    frame_004.location = (-2910.0, 228.0)
	    frame_003.location = (-4868.0, -613.0)
	    reroute_016.location = (-431.521728515625, 395.1722106933594)
	    reroute_017.location = (-431.521728515625, 354.9861755371094)
	    reroute_019.location = (-431.521728515625, 314.8001403808594)
	    reroute_018.location = (-431.521728515625, 274.6141052246094)
	    group_input.location = (-3843.1396484375, 29.906982421875)
	    group_output_3.location = (75.0, 50.0)
	    separate_components.location = (-3652.255859375, 19.86041259765625)
	    math_053.location = (230.622802734375, -60.3717041015625)
	    math_055.location = (230.622802734375, -100.5577392578125)
	    math_056.location = (190.436767578125, -221.11590576171875)
	    group_input_006.location = (29.6923828125, -221.11590576171875)
	    separate_xyz_002.location = (29.6923828125, -60.3717041015625)
	    math_054.location = (411.4599609375, -80.4647216796875)
	    math_052.location = (411.4599609375, -201.02288818359375)
	    combine_xyz_002.location = (592.29736328125, -40.2786865234375)
	    math_059.location = (592.29736328125, -281.39495849609375)
	    math_058.location = (592.29736328125, -241.20892333984375)
	    vector_rotate.location = (773.13427734375, -60.3717041015625)
	    math_057.location = (773.13427734375, -201.02288818359375)
	    group_input_007.location = (953.9716796875, -301.48797607421875)
	    combine_xyz.location = (953.9716796875, -201.02288818359375)
	    vector_math_014.location = (1134.808837890625, -221.11590576171875)
	    vector_math_013.location = (1335.739013671875, -140.7437744140625)
	    reroute_001.location = (-839.232666015625, -160.97679138183594)
	    reroute_003.location = (-839.232666015625, -281.5349426269531)
	    set_position.location = (-738.7674560546875, -241.348876953125)
	    set_position_001.location = (-738.7674560546875, -80.60469055175781)
	    normal.location = (30.2864990234375, -160.773193359375)
	    curve_tangent_2.location = (30.2864990234375, -100.494140625)
	    separate_xyz.location = (231.216796875, -221.05230712890625)
	    vector_math_001_1.location = (412.053955078125, -40.215087890625)
	    vector_math_003.location = (592.8912353515625, -40.215087890625)
	    vector_math_002.location = (412.053955078125, -180.86627197265625)
	    vector_math_009.location = (793.8214111328125, -40.215087890625)
	    vector_math_010.location = (592.8912353515625, -200.95928955078125)
	    vector_math_1.location = (231.216796875, -40.215087890625)
	    group_001_1.location = (743.9742431640625, -60.11541748046875)
	    evaluate_on_domain_002_1.location = (1105.648681640625, -40.02239990234375)
	    separate_xyz_001.location = (201.46240234375, -261.045654296875)
	    vector_math_011.location = (743.9742431640625, -140.487548828125)
	    vector_math_005.location = (563.136962890625, -140.487548828125)
	    vector_math_007.location = (382.2998046875, -120.39453125)
	    vector_math_008.location = (201.46240234375, -120.39453125)
	    evaluate_at_index_1.location = (924.8114013671875, -40.02239990234375)
	    vector_math_012.location = (563.136962890625, -301.231689453125)
	    vector_math_006.location = (382.2998046875, -261.045654296875)
	    evaluate_on_domain_001_1.location = (29.70654296875, -339.79510498046875)
	    curve_tangent_001.location = (29.70654296875, -118.77178955078125)
	    normal_001.location = (29.70654296875, -179.0509033203125)
	    reroute_014.location = (-3230.302490234375, 341.3487854003906)
	    reroute_015.location = (-3230.302490234375, 301.1627502441406)
	    reroute_013.location = (-3230.302490234375, 260.9767150878906)
	    reroute_012.location = (-3230.302490234375, 381.5348815917969)
	    is_viewport.location = (280.716064453125, -275.73028564453125)
	    switch.location = (461.55322265625, -235.54425048828125)
	    id_1.location = (29.55322265625, -205.40472412109375)
	    reroute_004.location = (1375.44677734375, -241.39447021484375)
	    reroute_002.location = (571.725830078125, -100.7432861328125)
	    join_geometry.location = (1074.0513916015625, -60.5572509765625)
	    set_id.location = (1274.981689453125, -60.5572509765625)
	    store_named_attribute.location = (1475.911865234375, -40.464202880859375)
	    math.location = (290.423583984375, -382.0456237792969)
	    group_input_002.location = (89.4931640625, -382.0456237792969)
	    group_input_004.location = (89.4931640625, -321.76654052734375)
	    capture_attribute_002.location = (843.28857421875, -131.15524291992188)
	    vector_math_004.location = (-2506.95361328125, -703.4884033203125)
	    group_input_003.location = (-2687.790771484375, -824.0465698242188)
	    random_value_001.location = (381.48486328125, -40.2786865234375)
	    capture_attribute.location = (224.854736328125, -51.218994140625)
	    duplicate_elements.location = (652.097900390625, -120.83633422851562)
	    join_geometry_001.location = (-130.127197265625, 53.59075927734375)
	    random_value.location = (1074.0513916015625, -161.02236938476562)
	    reroute_020.location = (-223.732666015625, -87.405517578125)
	    index.location = (-3431.232666015625, -100.69772338867188)
	    capture_attribute_001.location = (-3210.20947265625, 60.046478271484375)
	    switch_001.location = (-507.69775390625, -50.46514892578125)
	    group_1.location = (211.0927734375, -211.04656982421875)
	    group_input_001.location = (30.255859375, -331.604736328125)
	    group_input_005.location = (-738.7674560546875, -0.23260498046875)
	    random_value_004.location = (211.0927734375, -291.418701171875)
	
	    #Set dimensions
	    frame_002.width, frame_002.height = 1506.0, 383.0
	    frame_001.width, frame_001.height = 964.0, 370.0
	    frame_1.width, frame_1.height = 1276.0, 454.0
	    frame_004.width, frame_004.height = 1646.0, 464.0
	    frame_003.width, frame_003.height = 551.0, 488.0
	    reroute_016.width, reroute_016.height = 100.0, 100.0
	    reroute_017.width, reroute_017.height = 100.0, 100.0
	    reroute_019.width, reroute_019.height = 100.0, 100.0
	    reroute_018.width, reroute_018.height = 100.0, 100.0
	    group_input.width, group_input.height = 140.0, 100.0
	    group_output_3.width, group_output_3.height = 140.0, 100.0
	    separate_components.width, separate_components.height = 140.0, 100.0
	    math_053.width, math_053.height = 140.0, 100.0
	    math_055.width, math_055.height = 140.0, 100.0
	    math_056.width, math_056.height = 140.0, 100.0
	    group_input_006.width, group_input_006.height = 140.0, 100.0
	    separate_xyz_002.width, separate_xyz_002.height = 140.0, 100.0
	    math_054.width, math_054.height = 140.0, 100.0
	    math_052.width, math_052.height = 140.0, 100.0
	    combine_xyz_002.width, combine_xyz_002.height = 140.0, 100.0
	    math_059.width, math_059.height = 140.0, 100.0
	    math_058.width, math_058.height = 140.0, 100.0
	    vector_rotate.width, vector_rotate.height = 140.0, 100.0
	    math_057.width, math_057.height = 140.0, 100.0
	    group_input_007.width, group_input_007.height = 140.0, 100.0
	    combine_xyz.width, combine_xyz.height = 140.0, 100.0
	    vector_math_014.width, vector_math_014.height = 140.0, 100.0
	    vector_math_013.width, vector_math_013.height = 140.0, 100.0
	    reroute_001.width, reroute_001.height = 100.0, 100.0
	    reroute_003.width, reroute_003.height = 100.0, 100.0
	    set_position.width, set_position.height = 140.0, 100.0
	    set_position_001.width, set_position_001.height = 140.0, 100.0
	    normal.width, normal.height = 140.0, 100.0
	    curve_tangent_2.width, curve_tangent_2.height = 140.0, 100.0
	    separate_xyz.width, separate_xyz.height = 140.0, 100.0
	    vector_math_001_1.width, vector_math_001_1.height = 140.0, 100.0
	    vector_math_003.width, vector_math_003.height = 140.0, 100.0
	    vector_math_002.width, vector_math_002.height = 140.0, 100.0
	    vector_math_009.width, vector_math_009.height = 140.0, 100.0
	    vector_math_010.width, vector_math_010.height = 140.0, 100.0
	    vector_math_1.width, vector_math_1.height = 140.0, 100.0
	    group_001_1.width, group_001_1.height = 140.0, 100.0
	    evaluate_on_domain_002_1.width, evaluate_on_domain_002_1.height = 140.0, 100.0
	    separate_xyz_001.width, separate_xyz_001.height = 140.0, 100.0
	    vector_math_011.width, vector_math_011.height = 140.0, 100.0
	    vector_math_005.width, vector_math_005.height = 140.0, 100.0
	    vector_math_007.width, vector_math_007.height = 140.0, 100.0
	    vector_math_008.width, vector_math_008.height = 140.0, 100.0
	    evaluate_at_index_1.width, evaluate_at_index_1.height = 140.0, 100.0
	    vector_math_012.width, vector_math_012.height = 140.0, 100.0
	    vector_math_006.width, vector_math_006.height = 140.0, 100.0
	    evaluate_on_domain_001_1.width, evaluate_on_domain_001_1.height = 140.0, 100.0
	    curve_tangent_001.width, curve_tangent_001.height = 140.0, 100.0
	    normal_001.width, normal_001.height = 140.0, 100.0
	    reroute_014.width, reroute_014.height = 100.0, 100.0
	    reroute_015.width, reroute_015.height = 100.0, 100.0
	    reroute_013.width, reroute_013.height = 100.0, 100.0
	    reroute_012.width, reroute_012.height = 100.0, 100.0
	    is_viewport.width, is_viewport.height = 140.0, 100.0
	    switch.width, switch.height = 140.0, 100.0
	    id_1.width, id_1.height = 140.0, 100.0
	    reroute_004.width, reroute_004.height = 100.0, 100.0
	    reroute_002.width, reroute_002.height = 100.0, 100.0
	    join_geometry.width, join_geometry.height = 140.0, 100.0
	    set_id.width, set_id.height = 140.0, 100.0
	    store_named_attribute.width, store_named_attribute.height = 140.0, 100.0
	    math.width, math.height = 140.0, 100.0
	    group_input_002.width, group_input_002.height = 140.0, 100.0
	    group_input_004.width, group_input_004.height = 140.0, 100.0
	    capture_attribute_002.width, capture_attribute_002.height = 140.0, 100.0
	    vector_math_004.width, vector_math_004.height = 140.0, 100.0
	    group_input_003.width, group_input_003.height = 140.0, 100.0
	    random_value_001.width, random_value_001.height = 140.0, 100.0
	    capture_attribute.width, capture_attribute.height = 140.0, 100.0
	    duplicate_elements.width, duplicate_elements.height = 140.0, 100.0
	    join_geometry_001.width, join_geometry_001.height = 140.0, 100.0
	    random_value.width, random_value.height = 140.0, 100.0
	    reroute_020.width, reroute_020.height = 100.0, 100.0
	    index.width, index.height = 140.0, 100.0
	    capture_attribute_001.width, capture_attribute_001.height = 140.0, 100.0
	    switch_001.width, switch_001.height = 140.0, 100.0
	    group_1.width, group_1.height = 140.0, 100.0
	    group_input_001.width, group_input_001.height = 140.0, 100.0
	    group_input_005.width, group_input_005.height = 140.0, 100.0
	    random_value_004.width, random_value_004.height = 140.0, 100.0
	
	    #initialize duplicate_hair_curves links
	    #join_geometry_001.Geometry -> group_output_3.Geometry
	    duplicate_hair_curves.links.new(join_geometry_001.outputs[0], group_output_3.inputs[0])
	    #reroute_002.Output -> duplicate_elements.Geometry
	    duplicate_hair_curves.links.new(reroute_002.outputs[0], duplicate_elements.inputs[0])
	    #capture_attribute_001.Geometry -> capture_attribute.Geometry
	    duplicate_hair_curves.links.new(capture_attribute_001.outputs[0], capture_attribute.inputs[0])
	    #random_value.Value -> set_id.ID
	    duplicate_hair_curves.links.new(random_value.outputs[2], set_id.inputs[2])
	    #capture_attribute.Value -> random_value.ID
	    duplicate_hair_curves.links.new(capture_attribute.outputs[1], random_value.inputs[7])
	    #duplicate_elements.Duplicate Index -> random_value.Seed
	    duplicate_hair_curves.links.new(duplicate_elements.outputs[1], random_value.inputs[8])
	    #random_value_001.Value -> separate_xyz_002.Vector
	    duplicate_hair_curves.links.new(random_value_001.outputs[0], separate_xyz_002.inputs[0])
	    #math_052.Value -> vector_rotate.Angle
	    duplicate_hair_curves.links.new(math_052.outputs[0], vector_rotate.inputs[3])
	    #combine_xyz_002.Vector -> vector_rotate.Vector
	    duplicate_hair_curves.links.new(combine_xyz_002.outputs[0], vector_rotate.inputs[0])
	    #separate_xyz_002.Y -> math_052.Value
	    duplicate_hair_curves.links.new(separate_xyz_002.outputs[1], math_052.inputs[0])
	    #separate_xyz_002.X -> math_053.Value
	    duplicate_hair_curves.links.new(separate_xyz_002.outputs[0], math_053.inputs[0])
	    #math_054.Value -> combine_xyz_002.X
	    duplicate_hair_curves.links.new(math_054.outputs[0], combine_xyz_002.inputs[0])
	    #group_1.Curve ID -> random_value_001.ID
	    duplicate_hair_curves.links.new(group_1.outputs[1], random_value_001.inputs[7])
	    #vector_math_004.Vector -> separate_xyz.Vector
	    duplicate_hair_curves.links.new(vector_math_004.outputs[0], separate_xyz.inputs[0])
	    #reroute_001.Output -> set_position.Geometry
	    duplicate_hair_curves.links.new(reroute_001.outputs[0], set_position.inputs[0])
	    #curve_tangent_2.Tangent -> vector_math_1.Vector
	    duplicate_hair_curves.links.new(curve_tangent_2.outputs[0], vector_math_1.inputs[0])
	    #normal.Normal -> vector_math_1.Vector
	    duplicate_hair_curves.links.new(normal.outputs[0], vector_math_1.inputs[1])
	    #vector_math_1.Vector -> vector_math_001_1.Vector
	    duplicate_hair_curves.links.new(vector_math_1.outputs[0], vector_math_001_1.inputs[0])
	    #vector_math_001_1.Vector -> vector_math_003.Vector
	    duplicate_hair_curves.links.new(vector_math_001_1.outputs[0], vector_math_003.inputs[0])
	    #vector_math_002.Vector -> vector_math_003.Vector
	    duplicate_hair_curves.links.new(vector_math_002.outputs[0], vector_math_003.inputs[1])
	    #separate_xyz.X -> vector_math_001_1.Scale
	    duplicate_hair_curves.links.new(separate_xyz.outputs[0], vector_math_001_1.inputs[3])
	    #separate_xyz.Y -> vector_math_002.Scale
	    duplicate_hair_curves.links.new(separate_xyz.outputs[1], vector_math_002.inputs[3])
	    #normal.Normal -> vector_math_002.Vector
	    duplicate_hair_curves.links.new(normal.outputs[0], vector_math_002.inputs[0])
	    #index.Index -> capture_attribute_001.Value
	    duplicate_hair_curves.links.new(index.outputs[0], capture_attribute_001.inputs[1])
	    #set_id.Geometry -> store_named_attribute.Geometry
	    duplicate_hair_curves.links.new(set_id.outputs[0], store_named_attribute.inputs[0])
	    #capture_attribute_002.Geometry -> join_geometry.Geometry
	    duplicate_hair_curves.links.new(capture_attribute_002.outputs[0], join_geometry.inputs[0])
	    #reroute_004.Output -> store_named_attribute.Value
	    duplicate_hair_curves.links.new(reroute_004.outputs[0], store_named_attribute.inputs[3])
	    #group_input_004.Amount -> switch.False
	    duplicate_hair_curves.links.new(group_input_004.outputs[1], switch.inputs[1])
	    #switch.Output -> duplicate_elements.Amount
	    duplicate_hair_curves.links.new(switch.outputs[0], duplicate_elements.inputs[2])
	    #is_viewport.Is Viewport -> switch.Switch
	    duplicate_hair_curves.links.new(is_viewport.outputs[0], switch.inputs[0])
	    #group_input_004.Amount -> math.Value
	    duplicate_hair_curves.links.new(group_input_004.outputs[1], math.inputs[0])
	    #math.Value -> switch.True
	    duplicate_hair_curves.links.new(math.outputs[0], switch.inputs[2])
	    #group_input_002.Viewport Amount -> math.Value
	    duplicate_hair_curves.links.new(group_input_002.outputs[2], math.inputs[1])
	    #id_1.ID -> capture_attribute.Value
	    duplicate_hair_curves.links.new(id_1.outputs[0], capture_attribute.inputs[1])
	    #vector_math_009.Vector -> set_position.Offset
	    duplicate_hair_curves.links.new(vector_math_009.outputs[0], set_position.inputs[3])
	    #group_input_005.Even Thickness -> switch_001.Switch
	    duplicate_hair_curves.links.new(group_input_005.outputs[6], switch_001.inputs[0])
	    #vector_math_007.Vector -> vector_math_005.Vector
	    duplicate_hair_curves.links.new(vector_math_007.outputs[0], vector_math_005.inputs[0])
	    #vector_math_006.Vector -> vector_math_005.Vector
	    duplicate_hair_curves.links.new(vector_math_006.outputs[0], vector_math_005.inputs[1])
	    #separate_xyz_001.X -> vector_math_007.Scale
	    duplicate_hair_curves.links.new(separate_xyz_001.outputs[0], vector_math_007.inputs[3])
	    #separate_xyz_001.Y -> vector_math_006.Scale
	    duplicate_hair_curves.links.new(separate_xyz_001.outputs[1], vector_math_006.inputs[3])
	    #evaluate_on_domain_002_1.Value -> set_position_001.Offset
	    duplicate_hair_curves.links.new(evaluate_on_domain_002_1.outputs[0], set_position_001.inputs[3])
	    #curve_tangent_001.Tangent -> vector_math_008.Vector
	    duplicate_hair_curves.links.new(curve_tangent_001.outputs[0], vector_math_008.inputs[0])
	    #normal_001.Normal -> vector_math_008.Vector
	    duplicate_hair_curves.links.new(normal_001.outputs[0], vector_math_008.inputs[1])
	    #evaluate_at_index_1.Value -> evaluate_on_domain_002_1.Value
	    duplicate_hair_curves.links.new(evaluate_at_index_1.outputs[0], evaluate_on_domain_002_1.inputs[0])
	    #vector_math_008.Vector -> vector_math_007.Vector
	    duplicate_hair_curves.links.new(vector_math_008.outputs[0], vector_math_007.inputs[0])
	    #normal_001.Normal -> vector_math_006.Vector
	    duplicate_hair_curves.links.new(normal_001.outputs[0], vector_math_006.inputs[0])
	    #evaluate_on_domain_001_1.Value -> separate_xyz_001.Vector
	    duplicate_hair_curves.links.new(evaluate_on_domain_001_1.outputs[0], separate_xyz_001.inputs[0])
	    #store_named_attribute.Geometry -> reroute_001.Input
	    duplicate_hair_curves.links.new(store_named_attribute.outputs[0], reroute_001.inputs[0])
	    #reroute_001.Output -> set_position_001.Geometry
	    duplicate_hair_curves.links.new(reroute_001.outputs[0], set_position_001.inputs[0])
	    #vector_math_011.Vector -> evaluate_at_index_1.Value
	    duplicate_hair_curves.links.new(vector_math_011.outputs[0], evaluate_at_index_1.inputs[1])
	    #group_001_1.Root Index -> evaluate_at_index_1.Index
	    duplicate_hair_curves.links.new(group_001_1.outputs[3], evaluate_at_index_1.inputs[0])
	    #capture_attribute.Geometry -> reroute_002.Input
	    duplicate_hair_curves.links.new(capture_attribute.outputs[0], reroute_002.inputs[0])
	    #math_055.Value -> math_054.Value
	    duplicate_hair_curves.links.new(math_055.outputs[0], math_054.inputs[0])
	    #math_053.Value -> math_055.Value
	    duplicate_hair_curves.links.new(math_053.outputs[0], math_055.inputs[0])
	    #math_056.Value -> math_054.Value
	    duplicate_hair_curves.links.new(math_056.outputs[0], math_054.inputs[1])
	    #group_input_006.Distribution Shape -> math_056.Value
	    duplicate_hair_curves.links.new(group_input_006.outputs[4], math_056.inputs[1])
	    #vector_math_003.Vector -> vector_math_009.Vector
	    duplicate_hair_curves.links.new(vector_math_003.outputs[0], vector_math_009.inputs[0])
	    #separate_xyz.Z -> vector_math_010.Scale
	    duplicate_hair_curves.links.new(separate_xyz.outputs[2], vector_math_010.inputs[3])
	    #curve_tangent_2.Tangent -> vector_math_010.Vector
	    duplicate_hair_curves.links.new(curve_tangent_2.outputs[0], vector_math_010.inputs[0])
	    #vector_math_010.Vector -> vector_math_009.Vector
	    duplicate_hair_curves.links.new(vector_math_010.outputs[0], vector_math_009.inputs[1])
	    #vector_math_005.Vector -> vector_math_011.Vector
	    duplicate_hair_curves.links.new(vector_math_005.outputs[0], vector_math_011.inputs[0])
	    #vector_math_012.Vector -> vector_math_011.Vector
	    duplicate_hair_curves.links.new(vector_math_012.outputs[0], vector_math_011.inputs[1])
	    #separate_xyz_001.Z -> vector_math_012.Scale
	    duplicate_hair_curves.links.new(separate_xyz_001.outputs[2], vector_math_012.inputs[3])
	    #curve_tangent_001.Tangent -> vector_math_012.Vector
	    duplicate_hair_curves.links.new(curve_tangent_001.outputs[0], vector_math_012.inputs[0])
	    #vector_rotate.Vector -> vector_math_013.Vector
	    duplicate_hair_curves.links.new(vector_rotate.outputs[0], vector_math_013.inputs[0])
	    #vector_math_014.Vector -> vector_math_013.Vector
	    duplicate_hair_curves.links.new(vector_math_014.outputs[0], vector_math_013.inputs[1])
	    #math_057.Value -> combine_xyz.Z
	    duplicate_hair_curves.links.new(math_057.outputs[0], combine_xyz.inputs[2])
	    #vector_math_013.Vector -> vector_math_004.Vector
	    duplicate_hair_curves.links.new(vector_math_013.outputs[0], vector_math_004.inputs[0])
	    #group_input_003.Radius -> vector_math_004.Scale
	    duplicate_hair_curves.links.new(group_input_003.outputs[3], vector_math_004.inputs[3])
	    #math_058.Value -> math_057.Value
	    duplicate_hair_curves.links.new(math_058.outputs[0], math_057.inputs[0])
	    #math_059.Value -> math_057.Value
	    duplicate_hair_curves.links.new(math_059.outputs[0], math_057.inputs[1])
	    #math_054.Value -> math_058.Value
	    duplicate_hair_curves.links.new(math_054.outputs[0], math_058.inputs[0])
	    #combine_xyz.Vector -> vector_math_014.Vector
	    duplicate_hair_curves.links.new(combine_xyz.outputs[0], vector_math_014.inputs[0])
	    #group_input_007.Tip Roundness -> vector_math_014.Scale
	    duplicate_hair_curves.links.new(group_input_007.outputs[5], vector_math_014.inputs[3])
	    #separate_xyz_002.Z -> math_059.Value
	    duplicate_hair_curves.links.new(separate_xyz_002.outputs[2], math_059.inputs[0])
	    #set_position_001.Geometry -> switch_001.False
	    duplicate_hair_curves.links.new(set_position_001.outputs[0], switch_001.inputs[1])
	    #set_position.Geometry -> switch_001.True
	    duplicate_hair_curves.links.new(set_position.outputs[0], switch_001.inputs[2])
	    #reroute_003.Output -> set_position.Selection
	    duplicate_hair_curves.links.new(reroute_003.outputs[0], set_position.inputs[1])
	    #reroute_003.Output -> set_position_001.Selection
	    duplicate_hair_curves.links.new(reroute_003.outputs[0], set_position_001.inputs[1])
	    #capture_attribute_002.Value -> reroute_003.Input
	    duplicate_hair_curves.links.new(capture_attribute_002.outputs[1], reroute_003.inputs[0])
	    #capture_attribute_001.Value -> reroute_004.Input
	    duplicate_hair_curves.links.new(capture_attribute_001.outputs[1], reroute_004.inputs[0])
	    #join_geometry.Geometry -> set_id.Geometry
	    duplicate_hair_curves.links.new(join_geometry.outputs[0], set_id.inputs[0])
	    #duplicate_elements.Geometry -> capture_attribute_002.Geometry
	    duplicate_hair_curves.links.new(duplicate_elements.outputs[0], capture_attribute_002.inputs[0])
	    #group_input_001.Seed -> random_value_004.ID
	    duplicate_hair_curves.links.new(group_input_001.outputs[7], random_value_004.inputs[7])
	    #random_value_004.Value -> random_value_001.Seed
	    duplicate_hair_curves.links.new(random_value_004.outputs[2], random_value_001.inputs[8])
	    #vector_math_004.Vector -> evaluate_on_domain_001_1.Value
	    duplicate_hair_curves.links.new(vector_math_004.outputs[0], evaluate_on_domain_001_1.inputs[0])
	    #reroute_018.Output -> join_geometry_001.Geometry
	    duplicate_hair_curves.links.new(reroute_018.outputs[0], join_geometry_001.inputs[0])
	    #separate_components.Mesh -> reroute_012.Input
	    duplicate_hair_curves.links.new(separate_components.outputs[0], reroute_012.inputs[0])
	    #separate_components.Instances -> reroute_013.Input
	    duplicate_hair_curves.links.new(separate_components.outputs[5], reroute_013.inputs[0])
	    #separate_components.Point Cloud -> reroute_014.Input
	    duplicate_hair_curves.links.new(separate_components.outputs[3], reroute_014.inputs[0])
	    #separate_components.Volume -> reroute_015.Input
	    duplicate_hair_curves.links.new(separate_components.outputs[4], reroute_015.inputs[0])
	    #reroute_012.Output -> reroute_016.Input
	    duplicate_hair_curves.links.new(reroute_012.outputs[0], reroute_016.inputs[0])
	    #reroute_014.Output -> reroute_017.Input
	    duplicate_hair_curves.links.new(reroute_014.outputs[0], reroute_017.inputs[0])
	    #reroute_013.Output -> reroute_018.Input
	    duplicate_hair_curves.links.new(reroute_013.outputs[0], reroute_018.inputs[0])
	    #reroute_015.Output -> reroute_019.Input
	    duplicate_hair_curves.links.new(reroute_015.outputs[0], reroute_019.inputs[0])
	    #switch_001.Output -> reroute_020.Input
	    duplicate_hair_curves.links.new(switch_001.outputs[0], reroute_020.inputs[0])
	    #group_input.Geometry -> separate_components.Geometry
	    duplicate_hair_curves.links.new(group_input.outputs[0], separate_components.inputs[0])
	    #separate_components.Curve -> capture_attribute_001.Geometry
	    duplicate_hair_curves.links.new(separate_components.outputs[1], capture_attribute_001.inputs[0])
	    #reroute_004.Output -> group_output_3.Guide Index
	    duplicate_hair_curves.links.new(reroute_004.outputs[0], group_output_3.inputs[1])
	    #reroute_002.Output -> join_geometry.Geometry
	    duplicate_hair_curves.links.new(reroute_002.outputs[0], join_geometry.inputs[0])
	    #reroute_019.Output -> join_geometry_001.Geometry
	    duplicate_hair_curves.links.new(reroute_019.outputs[0], join_geometry_001.inputs[0])
	    #reroute_020.Output -> join_geometry_001.Geometry
	    duplicate_hair_curves.links.new(reroute_020.outputs[0], join_geometry_001.inputs[0])
	    #reroute_017.Output -> join_geometry_001.Geometry
	    duplicate_hair_curves.links.new(reroute_017.outputs[0], join_geometry_001.inputs[0])
	    #reroute_016.Output -> join_geometry_001.Geometry
	    duplicate_hair_curves.links.new(reroute_016.outputs[0], join_geometry_001.inputs[0])
	    return duplicate_hair_curves
	
	duplicate_hair_curves = duplicate_hair_curves_node_group()
	
	#initialize spiral_twist node group
	def spiral_twist_node_group():
	    spiral_twist = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Spiral_Twist")
	
	    spiral_twist.color_tag = 'NONE'
	    spiral_twist.description = "Create spiral twists."
	    spiral_twist.default_group_node_width = 140
	    
	
	    spiral_twist.is_modifier = True
	
	    #spiral_twist interface
	    #Socket Geometry
	    geometry_socket_2 = spiral_twist.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_2.attribute_domain = 'POINT'
	    geometry_socket_2.description = "Spiral twist curve."
	
	    #Socket Resolution
	    resolution_socket = spiral_twist.interface.new_socket(name = "Resolution", in_out='INPUT', socket_type = 'NodeSocketInt')
	    resolution_socket.default_value = 32
	    resolution_socket.min_value = 1
	    resolution_socket.max_value = 1024
	    resolution_socket.subtype = 'NONE'
	    resolution_socket.attribute_domain = 'POINT'
	    resolution_socket.description = "Control mesh smoothness by add and removing points along curve."
	
	    #Socket Tip Height
	    tip_height_socket = spiral_twist.interface.new_socket(name = "Tip Height", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    tip_height_socket.default_value = 0.10000000149011612
	    tip_height_socket.min_value = -3.4028234663852886e+38
	    tip_height_socket.max_value = 3.4028234663852886e+38
	    tip_height_socket.subtype = 'DISTANCE'
	    tip_height_socket.attribute_domain = 'POINT'
	    tip_height_socket.description = "Height of the spiral tip region."
	
	    #Socket Upper Height
	    upper_height_socket = spiral_twist.interface.new_socket(name = "Upper Height", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    upper_height_socket.default_value = 0.20000000298023224
	    upper_height_socket.min_value = -3.4028234663852886e+38
	    upper_height_socket.max_value = 3.4028234663852886e+38
	    upper_height_socket.subtype = 'DISTANCE'
	    upper_height_socket.attribute_domain = 'POINT'
	    upper_height_socket.description = "Height of the spiral upper region. In between the tiip and lower regions."
	
	    #Socket Lower Height
	    lower_height_socket = spiral_twist.interface.new_socket(name = "Lower Height", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    lower_height_socket.default_value = 0.20000000298023224
	    lower_height_socket.min_value = -3.402820018375656e+38
	    lower_height_socket.max_value = 3.4028234663852886e+38
	    lower_height_socket.subtype = 'DISTANCE'
	    lower_height_socket.attribute_domain = 'POINT'
	    lower_height_socket.description = "Height of the spiral lower region. In between the upper and root regions."
	
	    #Socket Root Height
	    root_height_socket = spiral_twist.interface.new_socket(name = "Root Height", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    root_height_socket.default_value = 0.0
	    root_height_socket.min_value = 0.0
	    root_height_socket.max_value = 3.4028234663852886e+38
	    root_height_socket.subtype = 'DISTANCE'
	    root_height_socket.attribute_domain = 'POINT'
	    root_height_socket.description = "Height of the spiral root region."
	
	    #Socket Tip Radius
	    tip_radius_socket = spiral_twist.interface.new_socket(name = "Tip Radius", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    tip_radius_socket.default_value = 0.10000000149011612
	    tip_radius_socket.min_value = -3.4028234663852886e+38
	    tip_radius_socket.max_value = 3.4028234663852886e+38
	    tip_radius_socket.subtype = 'DISTANCE'
	    tip_radius_socket.attribute_domain = 'POINT'
	    tip_radius_socket.description = "Radius of the spiral tip region."
	
	    #Socket Upper Radius
	    upper_radius_socket = spiral_twist.interface.new_socket(name = "Upper Radius", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    upper_radius_socket.default_value = 0.20000000298023224
	    upper_radius_socket.min_value = -3.4028234663852886e+38
	    upper_radius_socket.max_value = 3.4028234663852886e+38
	    upper_radius_socket.subtype = 'DISTANCE'
	    upper_radius_socket.attribute_domain = 'POINT'
	    upper_radius_socket.description = "Radius of the spiral upper region. In between the tiip and lower regions."
	
	    #Socket Lower Radius
	    lower_radius_socket = spiral_twist.interface.new_socket(name = "Lower Radius", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    lower_radius_socket.default_value = 0.20000000298023224
	    lower_radius_socket.min_value = -3.4028234663852886e+38
	    lower_radius_socket.max_value = 3.4028234663852886e+38
	    lower_radius_socket.subtype = 'DISTANCE'
	    lower_radius_socket.attribute_domain = 'POINT'
	    lower_radius_socket.description = "Radius of the spiral lower region. In between the upper and root regions."
	
	    #Socket Root Radius
	    root_radius_socket = spiral_twist.interface.new_socket(name = "Root Radius", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    root_radius_socket.default_value = 0.10000000149011612
	    root_radius_socket.min_value = -3.4028234663852886e+38
	    root_radius_socket.max_value = 3.4028234663852886e+38
	    root_radius_socket.subtype = 'DISTANCE'
	    root_radius_socket.attribute_domain = 'POINT'
	    root_radius_socket.description = "Radius of the spiral root region."
	
	    #Socket Tip Rotations
	    tip_rotations_socket = spiral_twist.interface.new_socket(name = "Tip Rotations", in_out='INPUT', socket_type = 'NodeSocketInt')
	    tip_rotations_socket.default_value = 1
	    tip_rotations_socket.min_value = 1
	    tip_rotations_socket.max_value = 2147483647
	    tip_rotations_socket.subtype = 'NONE'
	    tip_rotations_socket.attribute_domain = 'POINT'
	    tip_rotations_socket.description = "Rotations of the spiral tip region."
	
	    #Socket Upper Rotations
	    upper_rotations_socket = spiral_twist.interface.new_socket(name = "Upper Rotations", in_out='INPUT', socket_type = 'NodeSocketInt')
	    upper_rotations_socket.default_value = 1
	    upper_rotations_socket.min_value = 1
	    upper_rotations_socket.max_value = 2147483647
	    upper_rotations_socket.subtype = 'NONE'
	    upper_rotations_socket.attribute_domain = 'POINT'
	    upper_rotations_socket.description = "Rotations of the spiral upper region. In between the tiip and lower regions."
	
	    #Socket Lower Rotations
	    lower_rotations_socket = spiral_twist.interface.new_socket(name = "Lower Rotations", in_out='INPUT', socket_type = 'NodeSocketInt')
	    lower_rotations_socket.default_value = 1
	    lower_rotations_socket.min_value = 1
	    lower_rotations_socket.max_value = 2147483647
	    lower_rotations_socket.subtype = 'NONE'
	    lower_rotations_socket.attribute_domain = 'POINT'
	    lower_rotations_socket.description = "Rotations of the spiral lower region. In between the upper and root regions."
	
	    #Socket Root Rotations
	    root_rotations_socket = spiral_twist.interface.new_socket(name = "Root Rotations", in_out='INPUT', socket_type = 'NodeSocketInt')
	    root_rotations_socket.default_value = 1
	    root_rotations_socket.min_value = 1
	    root_rotations_socket.max_value = 2147483647
	    root_rotations_socket.subtype = 'NONE'
	    root_rotations_socket.attribute_domain = 'POINT'
	    root_rotations_socket.description = "Rotations of the spiral lower region. In between the upper and root regions."
	
	
	    #initialize spiral_twist nodes
	    #node Group Input
	    group_input_1 = spiral_twist.nodes.new("NodeGroupInput")
	    group_input_1.name = "Group Input"
	    group_input_1.outputs[1].hide = True
	    group_input_1.outputs[2].hide = True
	    group_input_1.outputs[3].hide = True
	    group_input_1.outputs[5].hide = True
	    group_input_1.outputs[6].hide = True
	    group_input_1.outputs[7].hide = True
	    group_input_1.outputs[9].hide = True
	    group_input_1.outputs[10].hide = True
	    group_input_1.outputs[11].hide = True
	    group_input_1.outputs[13].hide = True
	
	    #node Group Output
	    group_output_4 = spiral_twist.nodes.new("NodeGroupOutput")
	    group_output_4.name = "Group Output"
	    group_output_4.is_active_output = True
	
	    #node Spiral
	    spiral = spiral_twist.nodes.new("GeometryNodeCurveSpiral")
	    spiral.name = "Spiral"
	    spiral.inputs[2].hide = True
	    spiral.inputs[5].hide = True
	    #Start Radius
	    spiral.inputs[2].default_value = 0.0
	    #Reverse
	    spiral.inputs[5].default_value = False
	
	    #node Spiral.001
	    spiral_001 = spiral_twist.nodes.new("GeometryNodeCurveSpiral")
	    spiral_001.name = "Spiral.001"
	    spiral_001.inputs[5].hide = True
	    #Reverse
	    spiral_001.inputs[5].default_value = False
	
	    #node Spiral.002
	    spiral_002 = spiral_twist.nodes.new("GeometryNodeCurveSpiral")
	    spiral_002.name = "Spiral.002"
	    spiral_002.inputs[5].hide = True
	    #Reverse
	    spiral_002.inputs[5].default_value = False
	
	    #node Spiral.003
	    spiral_003 = spiral_twist.nodes.new("GeometryNodeCurveSpiral")
	    spiral_003.name = "Spiral.003"
	    spiral_003.inputs[5].hide = True
	    #Reverse
	    spiral_003.inputs[5].default_value = False
	
	    #node Join Geometry
	    join_geometry_1 = spiral_twist.nodes.new("GeometryNodeJoinGeometry")
	    join_geometry_1.name = "Join Geometry"
	    join_geometry_1.hide = True
	
	    #node Transform Geometry
	    transform_geometry = spiral_twist.nodes.new("GeometryNodeTransform")
	    transform_geometry.name = "Transform Geometry"
	    transform_geometry.hide = True
	    transform_geometry.mode = 'COMPONENTS'
	    transform_geometry.inputs[2].hide = True
	    transform_geometry.inputs[3].hide = True
	    transform_geometry.inputs[4].hide = True
	    #Rotation
	    transform_geometry.inputs[2].default_value = (0.0, 0.0, 0.0)
	    #Scale
	    transform_geometry.inputs[3].default_value = (1.0, 1.0, 1.0)
	
	    #node Combine XYZ
	    combine_xyz_1 = spiral_twist.nodes.new("ShaderNodeCombineXYZ")
	    combine_xyz_1.name = "Combine XYZ"
	    combine_xyz_1.hide = True
	    combine_xyz_1.inputs[0].hide = True
	    combine_xyz_1.inputs[1].hide = True
	    #X
	    combine_xyz_1.inputs[0].default_value = 0.0
	    #Y
	    combine_xyz_1.inputs[1].default_value = 0.0
	
	    #node Transform Geometry.001
	    transform_geometry_001 = spiral_twist.nodes.new("GeometryNodeTransform")
	    transform_geometry_001.name = "Transform Geometry.001"
	    transform_geometry_001.hide = True
	    transform_geometry_001.mode = 'COMPONENTS'
	    transform_geometry_001.inputs[2].hide = True
	    transform_geometry_001.inputs[3].hide = True
	    transform_geometry_001.inputs[4].hide = True
	    #Rotation
	    transform_geometry_001.inputs[2].default_value = (0.0, 0.0, 0.0)
	    #Scale
	    transform_geometry_001.inputs[3].default_value = (1.0, 1.0, 1.0)
	
	    #node Combine XYZ.001
	    combine_xyz_001 = spiral_twist.nodes.new("ShaderNodeCombineXYZ")
	    combine_xyz_001.name = "Combine XYZ.001"
	    combine_xyz_001.hide = True
	    combine_xyz_001.inputs[0].hide = True
	    combine_xyz_001.inputs[1].hide = True
	    #X
	    combine_xyz_001.inputs[0].default_value = 0.0
	    #Y
	    combine_xyz_001.inputs[1].default_value = 0.0
	
	    #node Transform Geometry.002
	    transform_geometry_002 = spiral_twist.nodes.new("GeometryNodeTransform")
	    transform_geometry_002.name = "Transform Geometry.002"
	    transform_geometry_002.hide = True
	    transform_geometry_002.mode = 'COMPONENTS'
	    transform_geometry_002.inputs[2].hide = True
	    transform_geometry_002.inputs[3].hide = True
	    transform_geometry_002.inputs[4].hide = True
	    #Rotation
	    transform_geometry_002.inputs[2].default_value = (0.0, 0.0, 0.0)
	    #Scale
	    transform_geometry_002.inputs[3].default_value = (1.0, 1.0, 1.0)
	
	    #node Combine XYZ.002
	    combine_xyz_002_1 = spiral_twist.nodes.new("ShaderNodeCombineXYZ")
	    combine_xyz_002_1.name = "Combine XYZ.002"
	    combine_xyz_002_1.hide = True
	    combine_xyz_002_1.inputs[0].hide = True
	    combine_xyz_002_1.inputs[1].hide = True
	    #X
	    combine_xyz_002_1.inputs[0].default_value = 0.0
	    #Y
	    combine_xyz_002_1.inputs[1].default_value = 0.0
	
	    #node Math
	    math_1 = spiral_twist.nodes.new("ShaderNodeMath")
	    math_1.name = "Math"
	    math_1.hide = True
	    math_1.operation = 'ADD'
	    math_1.use_clamp = False
	
	    #node Group Input.001
	    group_input_001_1 = spiral_twist.nodes.new("NodeGroupInput")
	    group_input_001_1.name = "Group Input.001"
	    group_input_001_1.outputs[0].hide = True
	    group_input_001_1.outputs[1].hide = True
	    group_input_001_1.outputs[5].hide = True
	    group_input_001_1.outputs[6].hide = True
	    group_input_001_1.outputs[7].hide = True
	    group_input_001_1.outputs[8].hide = True
	    group_input_001_1.outputs[9].hide = True
	    group_input_001_1.outputs[10].hide = True
	    group_input_001_1.outputs[11].hide = True
	    group_input_001_1.outputs[12].hide = True
	    group_input_001_1.outputs[13].hide = True
	
	    #node Math.001
	    math_001 = spiral_twist.nodes.new("ShaderNodeMath")
	    math_001.name = "Math.001"
	    math_001.hide = True
	    math_001.operation = 'ADD'
	    math_001.use_clamp = False
	
	    #node Group Input.005
	    group_input_005_1 = spiral_twist.nodes.new("NodeGroupInput")
	    group_input_005_1.name = "Group Input.005"
	    group_input_005_1.outputs[2].hide = True
	    group_input_005_1.outputs[3].hide = True
	    group_input_005_1.outputs[4].hide = True
	    group_input_005_1.outputs[7].hide = True
	    group_input_005_1.outputs[8].hide = True
	    group_input_005_1.outputs[10].hide = True
	    group_input_005_1.outputs[11].hide = True
	    group_input_005_1.outputs[12].hide = True
	    group_input_005_1.outputs[13].hide = True
	
	    #node Group Input.006
	    group_input_006_1 = spiral_twist.nodes.new("NodeGroupInput")
	    group_input_006_1.name = "Group Input.006"
	    group_input_006_1.outputs[1].hide = True
	    group_input_006_1.outputs[3].hide = True
	    group_input_006_1.outputs[4].hide = True
	    group_input_006_1.outputs[5].hide = True
	    group_input_006_1.outputs[8].hide = True
	    group_input_006_1.outputs[9].hide = True
	    group_input_006_1.outputs[11].hide = True
	    group_input_006_1.outputs[12].hide = True
	    group_input_006_1.outputs[13].hide = True
	
	    #node Group Input.007
	    group_input_007_1 = spiral_twist.nodes.new("NodeGroupInput")
	    group_input_007_1.name = "Group Input.007"
	    group_input_007_1.outputs[1].hide = True
	    group_input_007_1.outputs[2].hide = True
	    group_input_007_1.outputs[4].hide = True
	    group_input_007_1.outputs[5].hide = True
	    group_input_007_1.outputs[6].hide = True
	    group_input_007_1.outputs[9].hide = True
	    group_input_007_1.outputs[10].hide = True
	    group_input_007_1.outputs[12].hide = True
	    group_input_007_1.outputs[13].hide = True
	
	    #node Merge by Distance
	    merge_by_distance = spiral_twist.nodes.new("GeometryNodeMergeByDistance")
	    merge_by_distance.name = "Merge by Distance"
	    merge_by_distance.hide = True
	    merge_by_distance.mode = 'CONNECTED'
	    merge_by_distance.inputs[1].hide = True
	    merge_by_distance.inputs[2].hide = True
	    #Selection
	    merge_by_distance.inputs[1].default_value = True
	    #Distance
	    merge_by_distance.inputs[2].default_value = 9.999999747378752e-05
	
	    #node Curve to Points.001
	    curve_to_points_001 = spiral_twist.nodes.new("GeometryNodeCurveToPoints")
	    curve_to_points_001.name = "Curve to Points.001"
	    curve_to_points_001.hide = True
	    curve_to_points_001.mode = 'COUNT'
	    curve_to_points_001.inputs[2].hide = True
	    curve_to_points_001.outputs[1].hide = True
	    curve_to_points_001.outputs[2].hide = True
	    curve_to_points_001.outputs[3].hide = True
	
	    #node Domain Size
	    domain_size = spiral_twist.nodes.new("GeometryNodeAttributeDomainSize")
	    domain_size.name = "Domain Size"
	    domain_size.hide = True
	    domain_size.component = 'CURVE'
	
	    #node Math.002
	    math_002 = spiral_twist.nodes.new("ShaderNodeMath")
	    math_002.name = "Math.002"
	    math_002.hide = True
	    math_002.operation = 'DIVIDE'
	    math_002.use_clamp = False
	
	    #node Points to Curves
	    points_to_curves = spiral_twist.nodes.new("GeometryNodePointsToCurves")
	    points_to_curves.name = "Points to Curves"
	    points_to_curves.hide = True
	    points_to_curves.inputs[1].hide = True
	    points_to_curves.inputs[2].hide = True
	    #Curve Group ID
	    points_to_curves.inputs[1].default_value = 0
	    #Weight
	    points_to_curves.inputs[2].default_value = 0.0
	
	
	
	
	
	    #Set locations
	    group_input_1.location = (-340.0, -161.6362762451172)
	    group_output_4.location = (1474.5970458984375, -38.929779052734375)
	    spiral.location = (-54.95956039428711, -137.89122009277344)
	    spiral_001.location = (-61.661155700683594, -484.4914855957031)
	    spiral_002.location = (-58.310302734375, -299.9337158203125)
	    spiral_003.location = (-65.01189422607422, -668.887939453125)
	    join_geometry_1.location = (996.3770141601562, -162.5578155517578)
	    transform_geometry.location = (579.7070922851562, -334.7420959472656)
	    combine_xyz_1.location = (308.9586181640625, -370.1322937011719)
	    transform_geometry_001.location = (582.5951538085938, -512.6197509765625)
	    combine_xyz_001.location = (583.3531494140625, -460.41937255859375)
	    transform_geometry_002.location = (583.4724731445312, -699.6058959960938)
	    combine_xyz_002_1.location = (584.23046875, -645.39306640625)
	    math_1.location = (313.34515380859375, -404.9423828125)
	    group_input_001_1.location = (109.98817443847656, -361.2451171875)
	    math_001.location = (311.3342590332031, -441.9976806640625)
	    group_input_005_1.location = (-340.0, -696.0903930664062)
	    group_input_006_1.location = (-340.0, -508.6611633300781)
	    group_input_007_1.location = (-340.0, -322.95135498046875)
	    merge_by_distance.location = (1300.7469482421875, -117.73745727539062)
	    curve_to_points_001.location = (1298.654052734375, -170.1835479736328)
	    domain_size.location = (1137.493896484375, -207.94483947753906)
	    math_002.location = (1300.7470703125, -207.9447784423828)
	    points_to_curves.location = (1296.56103515625, -62.8614616394043)
	
	    #Set dimensions
	    group_input_1.width, group_input_1.height = 140.0, 100.0
	    group_output_4.width, group_output_4.height = 140.0, 100.0
	    spiral.width, spiral.height = 140.0, 100.0
	    spiral_001.width, spiral_001.height = 140.0, 100.0
	    spiral_002.width, spiral_002.height = 140.0, 100.0
	    spiral_003.width, spiral_003.height = 140.0, 100.0
	    join_geometry_1.width, join_geometry_1.height = 140.0, 100.0
	    transform_geometry.width, transform_geometry.height = 140.0, 100.0
	    combine_xyz_1.width, combine_xyz_1.height = 140.0, 100.0
	    transform_geometry_001.width, transform_geometry_001.height = 140.0, 100.0
	    combine_xyz_001.width, combine_xyz_001.height = 140.0, 100.0
	    transform_geometry_002.width, transform_geometry_002.height = 140.0, 100.0
	    combine_xyz_002_1.width, combine_xyz_002_1.height = 140.0, 100.0
	    math_1.width, math_1.height = 140.0, 100.0
	    group_input_001_1.width, group_input_001_1.height = 140.0, 100.0
	    math_001.width, math_001.height = 140.0, 100.0
	    group_input_005_1.width, group_input_005_1.height = 140.0, 100.0
	    group_input_006_1.width, group_input_006_1.height = 140.0, 100.0
	    group_input_007_1.width, group_input_007_1.height = 140.0, 100.0
	    merge_by_distance.width, merge_by_distance.height = 140.0, 100.0
	    curve_to_points_001.width, curve_to_points_001.height = 140.0, 100.0
	    domain_size.width, domain_size.height = 140.0, 100.0
	    math_002.width, math_002.height = 140.0, 100.0
	    points_to_curves.width, points_to_curves.height = 140.0, 100.0
	
	    #initialize spiral_twist links
	    #group_input_1.Resolution -> spiral.Resolution
	    spiral_twist.links.new(group_input_1.outputs[0], spiral.inputs[0])
	    #combine_xyz_1.Vector -> transform_geometry.Translation
	    spiral_twist.links.new(combine_xyz_1.outputs[0], transform_geometry.inputs[1])
	    #group_input_1.Root Height -> spiral.Height
	    spiral_twist.links.new(group_input_1.outputs[4], spiral.inputs[4])
	    #spiral_002.Curve -> transform_geometry.Geometry
	    spiral_twist.links.new(spiral_002.outputs[0], transform_geometry.inputs[0])
	    #combine_xyz_001.Vector -> transform_geometry_001.Translation
	    spiral_twist.links.new(combine_xyz_001.outputs[0], transform_geometry_001.inputs[1])
	    #combine_xyz_002_1.Vector -> transform_geometry_002.Translation
	    spiral_twist.links.new(combine_xyz_002_1.outputs[0], transform_geometry_002.inputs[1])
	    #group_input_001_1.Root Height -> math_1.Value
	    spiral_twist.links.new(group_input_001_1.outputs[4], math_1.inputs[0])
	    #group_input_001_1.Lower Height -> math_1.Value
	    spiral_twist.links.new(group_input_001_1.outputs[3], math_1.inputs[1])
	    #math_1.Value -> combine_xyz_001.Z
	    spiral_twist.links.new(math_1.outputs[0], combine_xyz_001.inputs[2])
	    #spiral_001.Curve -> transform_geometry_001.Geometry
	    spiral_twist.links.new(spiral_001.outputs[0], transform_geometry_001.inputs[0])
	    #math_1.Value -> math_001.Value
	    spiral_twist.links.new(math_1.outputs[0], math_001.inputs[0])
	    #group_input_001_1.Upper Height -> math_001.Value
	    spiral_twist.links.new(group_input_001_1.outputs[2], math_001.inputs[1])
	    #math_001.Value -> combine_xyz_002_1.Z
	    spiral_twist.links.new(math_001.outputs[0], combine_xyz_002_1.inputs[2])
	    #spiral_003.Curve -> transform_geometry_002.Geometry
	    spiral_twist.links.new(spiral_003.outputs[0], transform_geometry_002.inputs[0])
	    #transform_geometry_002.Geometry -> join_geometry_1.Geometry
	    spiral_twist.links.new(transform_geometry_002.outputs[0], join_geometry_1.inputs[0])
	    #group_input_001_1.Root Height -> combine_xyz_1.Z
	    spiral_twist.links.new(group_input_001_1.outputs[4], combine_xyz_1.inputs[2])
	    #group_input_005_1.Tip Rotations -> spiral_003.Rotations
	    spiral_twist.links.new(group_input_005_1.outputs[9], spiral_003.inputs[1])
	    #group_input_005_1.Resolution -> spiral_003.Resolution
	    spiral_twist.links.new(group_input_005_1.outputs[0], spiral_003.inputs[0])
	    #group_input_005_1.Tip Radius -> spiral_003.End Radius
	    spiral_twist.links.new(group_input_005_1.outputs[5], spiral_003.inputs[3])
	    #group_input_005_1.Upper Radius -> spiral_003.Start Radius
	    spiral_twist.links.new(group_input_005_1.outputs[6], spiral_003.inputs[2])
	    #group_input_005_1.Tip Height -> spiral_003.Height
	    spiral_twist.links.new(group_input_005_1.outputs[1], spiral_003.inputs[4])
	    #group_input_006_1.Resolution -> spiral_001.Resolution
	    spiral_twist.links.new(group_input_006_1.outputs[0], spiral_001.inputs[0])
	    #group_input_006_1.Upper Rotations -> spiral_001.Rotations
	    spiral_twist.links.new(group_input_006_1.outputs[10], spiral_001.inputs[1])
	    #group_input_006_1.Lower Radius -> spiral_001.Start Radius
	    spiral_twist.links.new(group_input_006_1.outputs[7], spiral_001.inputs[2])
	    #group_input_006_1.Upper Radius -> spiral_001.End Radius
	    spiral_twist.links.new(group_input_006_1.outputs[6], spiral_001.inputs[3])
	    #group_input_006_1.Upper Height -> spiral_001.Height
	    spiral_twist.links.new(group_input_006_1.outputs[2], spiral_001.inputs[4])
	    #group_input_007_1.Resolution -> spiral_002.Resolution
	    spiral_twist.links.new(group_input_007_1.outputs[0], spiral_002.inputs[0])
	    #group_input_007_1.Lower Rotations -> spiral_002.Rotations
	    spiral_twist.links.new(group_input_007_1.outputs[11], spiral_002.inputs[1])
	    #group_input_007_1.Root Radius -> spiral_002.Start Radius
	    spiral_twist.links.new(group_input_007_1.outputs[8], spiral_002.inputs[2])
	    #group_input_007_1.Lower Radius -> spiral_002.End Radius
	    spiral_twist.links.new(group_input_007_1.outputs[7], spiral_002.inputs[3])
	    #group_input_007_1.Lower Height -> spiral_002.Height
	    spiral_twist.links.new(group_input_007_1.outputs[3], spiral_002.inputs[4])
	    #group_input_1.Root Rotations -> spiral.Rotations
	    spiral_twist.links.new(group_input_1.outputs[12], spiral.inputs[1])
	    #group_input_1.Root Radius -> spiral.End Radius
	    spiral_twist.links.new(group_input_1.outputs[8], spiral.inputs[3])
	    #domain_size.Point Count -> math_002.Value
	    spiral_twist.links.new(domain_size.outputs[0], math_002.inputs[0])
	    #domain_size.Spline Count -> math_002.Value
	    spiral_twist.links.new(domain_size.outputs[4], math_002.inputs[1])
	    #math_002.Value -> curve_to_points_001.Count
	    spiral_twist.links.new(math_002.outputs[0], curve_to_points_001.inputs[1])
	    #curve_to_points_001.Points -> merge_by_distance.Geometry
	    spiral_twist.links.new(curve_to_points_001.outputs[0], merge_by_distance.inputs[0])
	    #merge_by_distance.Geometry -> points_to_curves.Points
	    spiral_twist.links.new(merge_by_distance.outputs[0], points_to_curves.inputs[0])
	    #join_geometry_1.Geometry -> domain_size.Geometry
	    spiral_twist.links.new(join_geometry_1.outputs[0], domain_size.inputs[0])
	    #join_geometry_1.Geometry -> curve_to_points_001.Curve
	    spiral_twist.links.new(join_geometry_1.outputs[0], curve_to_points_001.inputs[0])
	    #points_to_curves.Curves -> group_output_4.Geometry
	    spiral_twist.links.new(points_to_curves.outputs[0], group_output_4.inputs[0])
	    #transform_geometry_001.Geometry -> join_geometry_1.Geometry
	    spiral_twist.links.new(transform_geometry_001.outputs[0], join_geometry_1.inputs[0])
	    #transform_geometry.Geometry -> join_geometry_1.Geometry
	    spiral_twist.links.new(transform_geometry.outputs[0], join_geometry_1.inputs[0])
	    #spiral.Curve -> join_geometry_1.Geometry
	    spiral_twist.links.new(spiral.outputs[0], join_geometry_1.inputs[0])
	    return spiral_twist
	
	spiral_twist = spiral_twist_node_group()
	
	#initialize skew_3d node group
	def skew_3d_node_group():
	    skew_3d = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "SKEW_3D")
	
	    skew_3d.color_tag = 'NONE'
	    skew_3d.description = "Strectch an object in 3D."
	    skew_3d.default_group_node_width = 140
	    
	
	    skew_3d.is_modifier = True
	
	    #skew_3d interface
	    #Socket Geometry
	    geometry_socket_3 = skew_3d.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_3.attribute_domain = 'POINT'
	    geometry_socket_3.description = "Skewed object."
	
	    #Socket Geometry
	    geometry_socket_4 = skew_3d.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_4.attribute_domain = 'POINT'
	    geometry_socket_4.description = "Input Geometry."
	
	    #Socket XY Angle
	    xy_angle_socket = skew_3d.interface.new_socket(name = "XY Angle", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    xy_angle_socket.default_value = 0.0
	    xy_angle_socket.min_value = -10000.0
	    xy_angle_socket.max_value = 10000.0
	    xy_angle_socket.subtype = 'NONE'
	    xy_angle_socket.attribute_domain = 'POINT'
	    xy_angle_socket.description = "X to Y skew angle."
	
	    #Socket XZ Angle
	    xz_angle_socket = skew_3d.interface.new_socket(name = "XZ Angle", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    xz_angle_socket.default_value = 0.0
	    xz_angle_socket.min_value = -10000.0
	    xz_angle_socket.max_value = 10000.0
	    xz_angle_socket.subtype = 'NONE'
	    xz_angle_socket.attribute_domain = 'POINT'
	    xz_angle_socket.description = "X to Z skew angle."
	
	
	    #initialize skew_3d nodes
	    #node Group Output
	    group_output_5 = skew_3d.nodes.new("NodeGroupOutput")
	    group_output_5.name = "Group Output"
	    group_output_5.is_active_output = True
	    group_output_5.inputs[1].hide = True
	
	    #node Group Input
	    group_input_2 = skew_3d.nodes.new("NodeGroupInput")
	    group_input_2.name = "Group Input"
	    group_input_2.outputs[3].hide = True
	
	    #node Combine Matrix.001
	    combine_matrix_001 = skew_3d.nodes.new("FunctionNodeCombineMatrix")
	    combine_matrix_001.name = "Combine Matrix.001"
	    #Column 1 Row 1
	    combine_matrix_001.inputs[0].default_value = 1.0
	    #Column 1 Row 2
	    combine_matrix_001.inputs[1].default_value = 0.0
	    #Column 1 Row 3
	    combine_matrix_001.inputs[2].default_value = 0.0
	    #Column 1 Row 4
	    combine_matrix_001.inputs[3].default_value = 0.0
	    #Column 2 Row 2
	    combine_matrix_001.inputs[5].default_value = 1.0
	    #Column 2 Row 4
	    combine_matrix_001.inputs[7].default_value = 0.0
	    #Column 3 Row 1
	    combine_matrix_001.inputs[8].default_value = 0.0
	    #Column 3 Row 2
	    combine_matrix_001.inputs[9].default_value = 0.0
	    #Column 3 Row 3
	    combine_matrix_001.inputs[10].default_value = 1.0
	    #Column 3 Row 4
	    combine_matrix_001.inputs[11].default_value = 0.0
	    #Column 4 Row 1
	    combine_matrix_001.inputs[12].default_value = 0.0
	    #Column 4 Row 2
	    combine_matrix_001.inputs[13].default_value = 0.0
	    #Column 4 Row 3
	    combine_matrix_001.inputs[14].default_value = 0.0
	    #Column 4 Row 4
	    combine_matrix_001.inputs[15].default_value = 1.0
	
	    #node Math.003
	    math_003 = skew_3d.nodes.new("ShaderNodeMath")
	    math_003.name = "Math.003"
	    math_003.hide = True
	    math_003.operation = 'TANGENT'
	    math_003.use_clamp = False
	
	    #node Math.004
	    math_004 = skew_3d.nodes.new("ShaderNodeMath")
	    math_004.name = "Math.004"
	    math_004.hide = True
	    math_004.operation = 'TANGENT'
	    math_004.use_clamp = False
	
	    #node Transform Geometry.001
	    transform_geometry_001_1 = skew_3d.nodes.new("GeometryNodeTransform")
	    transform_geometry_001_1.name = "Transform Geometry.001"
	    transform_geometry_001_1.mode = 'MATRIX'
	
	    #node Math.005
	    math_005 = skew_3d.nodes.new("ShaderNodeMath")
	    math_005.name = "Math.005"
	    math_005.hide = True
	    math_005.operation = 'RADIANS'
	    math_005.use_clamp = False
	
	    #node Math.006
	    math_006 = skew_3d.nodes.new("ShaderNodeMath")
	    math_006.name = "Math.006"
	    math_006.hide = True
	    math_006.operation = 'RADIANS'
	    math_006.use_clamp = False
	
	
	
	
	
	    #Set locations
	    group_output_5.location = (206.5, 48.85986328125)
	    group_input_2.location = (-610.1239013671875, 0.0)
	    combine_matrix_001.location = (-175.7845916748047, -46.071861267089844)
	    math_003.location = (-390.14459228515625, -110.47016906738281)
	    math_004.location = (-390.9370422363281, -145.8095703125)
	    transform_geometry_001_1.location = (16.5, 49.026458740234375)
	    math_005.location = (-390.9570007324219, -179.31942749023438)
	    math_006.location = (-396.8058166503906, -72.93868255615234)
	
	    #Set dimensions
	    group_output_5.width, group_output_5.height = 140.0, 100.0
	    group_input_2.width, group_input_2.height = 140.0, 100.0
	    combine_matrix_001.width, combine_matrix_001.height = 140.0, 100.0
	    math_003.width, math_003.height = 140.0, 100.0
	    math_004.width, math_004.height = 140.0, 100.0
	    transform_geometry_001_1.width, transform_geometry_001_1.height = 140.0, 100.0
	    math_005.width, math_005.height = 140.0, 100.0
	    math_006.width, math_006.height = 140.0, 100.0
	
	    #initialize skew_3d links
	    #math_004.Value -> combine_matrix_001.Column 2 Row 3
	    skew_3d.links.new(math_004.outputs[0], combine_matrix_001.inputs[6])
	    #math_005.Value -> math_004.Value
	    skew_3d.links.new(math_005.outputs[0], math_004.inputs[0])
	    #combine_matrix_001.Matrix -> transform_geometry_001_1.Transform
	    skew_3d.links.new(combine_matrix_001.outputs[0], transform_geometry_001_1.inputs[4])
	    #math_003.Value -> combine_matrix_001.Column 2 Row 1
	    skew_3d.links.new(math_003.outputs[0], combine_matrix_001.inputs[4])
	    #math_006.Value -> math_003.Value
	    skew_3d.links.new(math_006.outputs[0], math_003.inputs[0])
	    #transform_geometry_001_1.Geometry -> group_output_5.Geometry
	    skew_3d.links.new(transform_geometry_001_1.outputs[0], group_output_5.inputs[0])
	    #group_input_2.XY Angle -> math_006.Value
	    skew_3d.links.new(group_input_2.outputs[1], math_006.inputs[0])
	    #group_input_2.XZ Angle -> math_005.Value
	    skew_3d.links.new(group_input_2.outputs[2], math_005.inputs[0])
	    #group_input_2.Geometry -> transform_geometry_001_1.Geometry
	    skew_3d.links.new(group_input_2.outputs[0], transform_geometry_001_1.inputs[0])
	    return skew_3d
	
	skew_3d = skew_3d_node_group()
	
	#initialize spiral_twist_1 node group
	def spiral_twist_1_node_group():
	    spiral_twist_1 = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "SPIRAL_TWIST")
	
	    spiral_twist_1.color_tag = 'NONE'
	    spiral_twist_1.description = "Place spiral bun | curl objects on curve guides."
	    spiral_twist_1.default_group_node_width = 140
	    
	
	    spiral_twist_1.is_modifier = True
	
	    #spiral_twist_1 interface
	    #Socket Geometry
	    geometry_socket_5 = spiral_twist_1.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_5.attribute_domain = 'POINT'
	    geometry_socket_5.description = "Spiral Bun | Curl object."
	
	    #Socket Geometry
	    geometry_socket_6 = spiral_twist_1.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_6.attribute_domain = 'POINT'
	    geometry_socket_6.description = "Curve Guide."
	
	    #Socket Spiral Style
	    spiral_style_socket = spiral_twist_1.interface.new_socket(name = "Spiral Style", in_out='INPUT', socket_type = 'NodeSocketMenu')
	    spiral_style_socket.attribute_domain = 'POINT'
	    spiral_style_socket.description = "Select Spiral Hair Style."
	
	    #Socket Resolution
	    resolution_socket_1 = spiral_twist_1.interface.new_socket(name = "Resolution", in_out='INPUT', socket_type = 'NodeSocketInt')
	    resolution_socket_1.default_value = 32
	    resolution_socket_1.min_value = 1
	    resolution_socket_1.max_value = 1024
	    resolution_socket_1.subtype = 'NONE'
	    resolution_socket_1.attribute_domain = 'POINT'
	    resolution_socket_1.description = "Control mesh smoothness by add and removing points along curve."
	
	    #Socket Tip Height
	    tip_height_socket_1 = spiral_twist_1.interface.new_socket(name = "Tip Height", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    tip_height_socket_1.default_value = 0.10000000149011612
	    tip_height_socket_1.min_value = -3.4028234663852886e+38
	    tip_height_socket_1.max_value = 3.4028234663852886e+38
	    tip_height_socket_1.subtype = 'DISTANCE'
	    tip_height_socket_1.attribute_domain = 'POINT'
	    tip_height_socket_1.description = "Height of the spiral tip region."
	
	    #Socket Upper Height
	    upper_height_socket_1 = spiral_twist_1.interface.new_socket(name = "Upper Height", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    upper_height_socket_1.default_value = 0.20000000298023224
	    upper_height_socket_1.min_value = -3.4028234663852886e+38
	    upper_height_socket_1.max_value = 3.4028234663852886e+38
	    upper_height_socket_1.subtype = 'DISTANCE'
	    upper_height_socket_1.attribute_domain = 'POINT'
	    upper_height_socket_1.description = "Height of the spiral upper region. In between the tiip and lower regions."
	
	    #Socket Lower Height
	    lower_height_socket_1 = spiral_twist_1.interface.new_socket(name = "Lower Height", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    lower_height_socket_1.default_value = 0.20000000298023224
	    lower_height_socket_1.min_value = -3.402820018375656e+38
	    lower_height_socket_1.max_value = 3.4028234663852886e+38
	    lower_height_socket_1.subtype = 'DISTANCE'
	    lower_height_socket_1.attribute_domain = 'POINT'
	    lower_height_socket_1.description = "Height of the spiral lower region. In between the upper and root regions."
	
	    #Socket Root Height
	    root_height_socket_1 = spiral_twist_1.interface.new_socket(name = "Root Height", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    root_height_socket_1.default_value = 0.0
	    root_height_socket_1.min_value = 0.0
	    root_height_socket_1.max_value = 3.4028234663852886e+38
	    root_height_socket_1.subtype = 'DISTANCE'
	    root_height_socket_1.attribute_domain = 'POINT'
	    root_height_socket_1.description = "Height of the spiral root region."
	
	    #Socket Tip Radius
	    tip_radius_socket_1 = spiral_twist_1.interface.new_socket(name = "Tip Radius", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    tip_radius_socket_1.default_value = 0.10000000149011612
	    tip_radius_socket_1.min_value = -3.4028234663852886e+38
	    tip_radius_socket_1.max_value = 3.4028234663852886e+38
	    tip_radius_socket_1.subtype = 'DISTANCE'
	    tip_radius_socket_1.attribute_domain = 'POINT'
	    tip_radius_socket_1.description = "Radius of the spiral tip region."
	
	    #Socket Upper Radius
	    upper_radius_socket_1 = spiral_twist_1.interface.new_socket(name = "Upper Radius", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    upper_radius_socket_1.default_value = 0.20000000298023224
	    upper_radius_socket_1.min_value = -3.4028234663852886e+38
	    upper_radius_socket_1.max_value = 3.4028234663852886e+38
	    upper_radius_socket_1.subtype = 'DISTANCE'
	    upper_radius_socket_1.attribute_domain = 'POINT'
	    upper_radius_socket_1.description = "Radius of the spiral upper region. In between the tiip and lower regions."
	
	    #Socket Lower Radius
	    lower_radius_socket_1 = spiral_twist_1.interface.new_socket(name = "Lower Radius", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    lower_radius_socket_1.default_value = 0.20000000298023224
	    lower_radius_socket_1.min_value = -3.4028234663852886e+38
	    lower_radius_socket_1.max_value = 3.4028234663852886e+38
	    lower_radius_socket_1.subtype = 'DISTANCE'
	    lower_radius_socket_1.attribute_domain = 'POINT'
	    lower_radius_socket_1.description = "Radius of the spiral lower region. In between the upper and root regions."
	
	    #Socket Root Radius
	    root_radius_socket_1 = spiral_twist_1.interface.new_socket(name = "Root Radius", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    root_radius_socket_1.default_value = 0.10000000149011612
	    root_radius_socket_1.min_value = -3.4028234663852886e+38
	    root_radius_socket_1.max_value = 3.4028234663852886e+38
	    root_radius_socket_1.subtype = 'DISTANCE'
	    root_radius_socket_1.attribute_domain = 'POINT'
	    root_radius_socket_1.description = "Radius of the spiral root region."
	
	    #Socket Tip Rotations
	    tip_rotations_socket_1 = spiral_twist_1.interface.new_socket(name = "Tip Rotations", in_out='INPUT', socket_type = 'NodeSocketInt')
	    tip_rotations_socket_1.default_value = 1
	    tip_rotations_socket_1.min_value = 1
	    tip_rotations_socket_1.max_value = 2147483647
	    tip_rotations_socket_1.subtype = 'NONE'
	    tip_rotations_socket_1.attribute_domain = 'POINT'
	    tip_rotations_socket_1.description = "Rotations of the spiral tip region."
	
	    #Socket Upper Rotations
	    upper_rotations_socket_1 = spiral_twist_1.interface.new_socket(name = "Upper Rotations", in_out='INPUT', socket_type = 'NodeSocketInt')
	    upper_rotations_socket_1.default_value = 1
	    upper_rotations_socket_1.min_value = 1
	    upper_rotations_socket_1.max_value = 2147483647
	    upper_rotations_socket_1.subtype = 'NONE'
	    upper_rotations_socket_1.attribute_domain = 'POINT'
	    upper_rotations_socket_1.description = "Rotations of the spiral upper region. In between the tiip and lower regions."
	
	    #Socket Lower Rotations
	    lower_rotations_socket_1 = spiral_twist_1.interface.new_socket(name = "Lower Rotations", in_out='INPUT', socket_type = 'NodeSocketInt')
	    lower_rotations_socket_1.default_value = 1
	    lower_rotations_socket_1.min_value = 1
	    lower_rotations_socket_1.max_value = 2147483647
	    lower_rotations_socket_1.subtype = 'NONE'
	    lower_rotations_socket_1.attribute_domain = 'POINT'
	    lower_rotations_socket_1.description = "Rotations of the spiral lower region. In between the upper and root regions."
	
	    #Socket Root Rotations
	    root_rotations_socket_1 = spiral_twist_1.interface.new_socket(name = "Root Rotations", in_out='INPUT', socket_type = 'NodeSocketInt')
	    root_rotations_socket_1.default_value = 1
	    root_rotations_socket_1.min_value = 1
	    root_rotations_socket_1.max_value = 2147483647
	    root_rotations_socket_1.subtype = 'NONE'
	    root_rotations_socket_1.attribute_domain = 'POINT'
	    root_rotations_socket_1.description = "Rotations of the spiral root region."
	
	    #Socket Curl XY Angle
	    curl_xy_angle_socket = spiral_twist_1.interface.new_socket(name = "Curl XY Angle", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    curl_xy_angle_socket.default_value = 0.0
	    curl_xy_angle_socket.min_value = -10000.0
	    curl_xy_angle_socket.max_value = 10000.0
	    curl_xy_angle_socket.subtype = 'NONE'
	    curl_xy_angle_socket.attribute_domain = 'POINT'
	    curl_xy_angle_socket.description = "X to Y skew angle. (Spiral Style=Spiral Curl)"
	
	    #Socket Curl XZ Angle
	    curl_xz_angle_socket = spiral_twist_1.interface.new_socket(name = "Curl XZ Angle", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    curl_xz_angle_socket.default_value = 60.0
	    curl_xz_angle_socket.min_value = -10000.0
	    curl_xz_angle_socket.max_value = 10000.0
	    curl_xz_angle_socket.subtype = 'NONE'
	    curl_xz_angle_socket.attribute_domain = 'POINT'
	    curl_xz_angle_socket.description = "X to Z skew angle. (Spiral Style=Spiral Curl)"
	
	    #Socket Curl Rotation
	    curl_rotation_socket = spiral_twist_1.interface.new_socket(name = "Curl Rotation", in_out='INPUT', socket_type = 'NodeSocketRotation')
	    curl_rotation_socket.default_value = (0.0, 0.0, 0.0)
	    curl_rotation_socket.attribute_domain = 'POINT'
	    curl_rotation_socket.description = "Spiral curl rotations. (Spiral Style=Spiral Curl)"
	
	    #Socket Curl Scale
	    curl_scale_socket = spiral_twist_1.interface.new_socket(name = "Curl Scale", in_out='INPUT', socket_type = 'NodeSocketVector')
	    curl_scale_socket.default_value = (1.0, 0.5, 1.0)
	    curl_scale_socket.min_value = -3.4028234663852886e+38
	    curl_scale_socket.max_value = 3.4028234663852886e+38
	    curl_scale_socket.subtype = 'XYZ'
	    curl_scale_socket.attribute_domain = 'POINT'
	    curl_scale_socket.description = "Scale used for spiral curl. (Spiral Style=Spiral Curl)"
	
	
	    #initialize spiral_twist_1 nodes
	    #node Group Input
	    group_input_3 = spiral_twist_1.nodes.new("NodeGroupInput")
	    group_input_3.name = "Group Input"
	    group_input_3.outputs[0].hide = True
	    group_input_3.outputs[1].hide = True
	    group_input_3.outputs[15].hide = True
	    group_input_3.outputs[16].hide = True
	    group_input_3.outputs[17].hide = True
	    group_input_3.outputs[18].hide = True
	    group_input_3.outputs[19].hide = True
	
	    #node Group Output
	    group_output_6 = spiral_twist_1.nodes.new("NodeGroupOutput")
	    group_output_6.name = "Group Output"
	    group_output_6.is_active_output = True
	
	    #node Group
	    group_2 = spiral_twist_1.nodes.new("GeometryNodeGroup")
	    group_2.name = "Group"
	    group_2.node_tree = spiral_twist
	
	    #node Curve to Points
	    curve_to_points = spiral_twist_1.nodes.new("GeometryNodeCurveToPoints")
	    curve_to_points.name = "Curve to Points"
	    curve_to_points.mode = 'COUNT'
	    curve_to_points.inputs[1].hide = True
	    curve_to_points.inputs[2].hide = True
	    curve_to_points.outputs[1].hide = True
	    curve_to_points.outputs[2].hide = True
	    #Count
	    curve_to_points.inputs[1].default_value = 1
	
	    #node Instance on Points
	    instance_on_points = spiral_twist_1.nodes.new("GeometryNodeInstanceOnPoints")
	    instance_on_points.name = "Instance on Points"
	    instance_on_points.inputs[1].hide = True
	    instance_on_points.inputs[3].hide = True
	    instance_on_points.inputs[4].hide = True
	    instance_on_points.inputs[6].hide = True
	    #Selection
	    instance_on_points.inputs[1].default_value = True
	    #Pick Instance
	    instance_on_points.inputs[3].default_value = False
	    #Instance Index
	    instance_on_points.inputs[4].default_value = 0
	    #Scale
	    instance_on_points.inputs[6].default_value = (1.0, 1.0, 1.0)
	
	    #node Realize Instances
	    realize_instances = spiral_twist_1.nodes.new("GeometryNodeRealizeInstances")
	    realize_instances.name = "Realize Instances"
	    realize_instances.inputs[1].hide = True
	    realize_instances.inputs[2].hide = True
	    realize_instances.inputs[3].hide = True
	    #Selection
	    realize_instances.inputs[1].default_value = True
	    #Realize All
	    realize_instances.inputs[2].default_value = True
	    #Depth
	    realize_instances.inputs[3].default_value = 0
	
	    #node Group.001
	    group_001_2 = spiral_twist_1.nodes.new("GeometryNodeGroup")
	    group_001_2.name = "Group.001"
	    group_001_2.node_tree = skew_3d
	
	    #node Transform Geometry.002
	    transform_geometry_002_1 = spiral_twist_1.nodes.new("GeometryNodeTransform")
	    transform_geometry_002_1.name = "Transform Geometry.002"
	    transform_geometry_002_1.mode = 'COMPONENTS'
	    transform_geometry_002_1.inputs[1].hide = True
	    transform_geometry_002_1.inputs[4].hide = True
	    #Translation
	    transform_geometry_002_1.inputs[1].default_value = (0.0, 0.0, 0.0)
	
	    #node Group Input.001
	    group_input_001_2 = spiral_twist_1.nodes.new("NodeGroupInput")
	    group_input_001_2.name = "Group Input.001"
	    group_input_001_2.outputs[0].hide = True
	    group_input_001_2.outputs[1].hide = True
	    group_input_001_2.outputs[2].hide = True
	    group_input_001_2.outputs[3].hide = True
	    group_input_001_2.outputs[4].hide = True
	    group_input_001_2.outputs[5].hide = True
	    group_input_001_2.outputs[6].hide = True
	    group_input_001_2.outputs[7].hide = True
	    group_input_001_2.outputs[8].hide = True
	    group_input_001_2.outputs[9].hide = True
	    group_input_001_2.outputs[10].hide = True
	    group_input_001_2.outputs[11].hide = True
	    group_input_001_2.outputs[12].hide = True
	    group_input_001_2.outputs[13].hide = True
	    group_input_001_2.outputs[14].hide = True
	    group_input_001_2.outputs[19].hide = True
	
	    #node Group Input.002
	    group_input_002_1 = spiral_twist_1.nodes.new("NodeGroupInput")
	    group_input_002_1.name = "Group Input.002"
	    group_input_002_1.outputs[1].hide = True
	    group_input_002_1.outputs[2].hide = True
	    group_input_002_1.outputs[3].hide = True
	    group_input_002_1.outputs[4].hide = True
	    group_input_002_1.outputs[5].hide = True
	    group_input_002_1.outputs[6].hide = True
	    group_input_002_1.outputs[7].hide = True
	    group_input_002_1.outputs[8].hide = True
	    group_input_002_1.outputs[9].hide = True
	    group_input_002_1.outputs[10].hide = True
	    group_input_002_1.outputs[11].hide = True
	    group_input_002_1.outputs[12].hide = True
	    group_input_002_1.outputs[13].hide = True
	    group_input_002_1.outputs[14].hide = True
	    group_input_002_1.outputs[15].hide = True
	    group_input_002_1.outputs[16].hide = True
	    group_input_002_1.outputs[17].hide = True
	    group_input_002_1.outputs[18].hide = True
	    group_input_002_1.outputs[19].hide = True
	
	    #node Spiral Style
	    spiral_style = spiral_twist_1.nodes.new("GeometryNodeMenuSwitch")
	    spiral_style.label = "Spiral Style"
	    spiral_style.name = "Spiral Style"
	    spiral_style.hide = True
	    spiral_style.active_index = 1
	    spiral_style.data_type = 'GEOMETRY'
	    spiral_style.enum_items.clear()
	    spiral_style.enum_items.new("Spiral Bun")
	    spiral_style.enum_items[0].description = "Spiral bun hair style."
	    spiral_style.enum_items.new("Spiral Curl")
	    spiral_style.enum_items[1].description = "Spiral curl hair style."
	
	    #node Group Input.003
	    group_input_003_1 = spiral_twist_1.nodes.new("NodeGroupInput")
	    group_input_003_1.name = "Group Input.003"
	    group_input_003_1.outputs[0].hide = True
	    group_input_003_1.outputs[2].hide = True
	    group_input_003_1.outputs[3].hide = True
	    group_input_003_1.outputs[4].hide = True
	    group_input_003_1.outputs[5].hide = True
	    group_input_003_1.outputs[6].hide = True
	    group_input_003_1.outputs[7].hide = True
	    group_input_003_1.outputs[8].hide = True
	    group_input_003_1.outputs[9].hide = True
	    group_input_003_1.outputs[10].hide = True
	    group_input_003_1.outputs[11].hide = True
	    group_input_003_1.outputs[12].hide = True
	    group_input_003_1.outputs[13].hide = True
	    group_input_003_1.outputs[14].hide = True
	    group_input_003_1.outputs[15].hide = True
	    group_input_003_1.outputs[16].hide = True
	    group_input_003_1.outputs[17].hide = True
	    group_input_003_1.outputs[18].hide = True
	    group_input_003_1.outputs[19].hide = True
	
	
	
	
	
	    #Set locations
	    group_input_3.location = (-340.0, -121.91022491455078)
	    group_output_6.location = (762.492919921875, 98.59891510009766)
	    group_2.location = (-144.75747680664062, -75.05451202392578)
	    curve_to_points.location = (-143.13772583007812, 70.34009552001953)
	    instance_on_points.location = (405.6299743652344, 75.7812728881836)
	    realize_instances.location = (571.0704345703125, 100.74640655517578)
	    group_001_2.location = (236.890869140625, -132.84759521484375)
	    transform_geometry_002_1.location = (57.17261505126953, -108.34765625)
	    group_input_001_2.location = (56.79279327392578, -258.6079406738281)
	    group_input_002_1.location = (-340.0, -1.7927932739257812)
	    spiral_style.location = (238.92837524414062, -101.02430725097656)
	    group_input_003_1.location = (237.86143493652344, -37.38909912109375)
	
	    #Set dimensions
	    group_input_3.width, group_input_3.height = 140.0, 100.0
	    group_output_6.width, group_output_6.height = 140.0, 100.0
	    group_2.width, group_2.height = 140.0, 100.0
	    curve_to_points.width, curve_to_points.height = 140.0, 100.0
	    instance_on_points.width, instance_on_points.height = 140.0, 100.0
	    realize_instances.width, realize_instances.height = 140.0, 100.0
	    group_001_2.width, group_001_2.height = 140.0, 100.0
	    transform_geometry_002_1.width, transform_geometry_002_1.height = 140.0, 100.0
	    group_input_001_2.width, group_input_001_2.height = 140.0, 100.0
	    group_input_002_1.width, group_input_002_1.height = 140.0, 100.0
	    spiral_style.width, spiral_style.height = 140.0, 100.0
	    group_input_003_1.width, group_input_003_1.height = 140.0, 100.0
	
	    #initialize spiral_twist_1 links
	    #curve_to_points.Points -> instance_on_points.Points
	    spiral_twist_1.links.new(curve_to_points.outputs[0], instance_on_points.inputs[0])
	    #curve_to_points.Rotation -> instance_on_points.Rotation
	    spiral_twist_1.links.new(curve_to_points.outputs[3], instance_on_points.inputs[5])
	    #instance_on_points.Instances -> realize_instances.Geometry
	    spiral_twist_1.links.new(instance_on_points.outputs[0], realize_instances.inputs[0])
	    #realize_instances.Geometry -> group_output_6.Geometry
	    spiral_twist_1.links.new(realize_instances.outputs[0], group_output_6.inputs[0])
	    #group_input_3.Resolution -> group_2.Resolution
	    spiral_twist_1.links.new(group_input_3.outputs[2], group_2.inputs[0])
	    #group_input_3.Root Height -> group_2.Root Height
	    spiral_twist_1.links.new(group_input_3.outputs[6], group_2.inputs[4])
	    #group_input_3.Lower Height -> group_2.Lower Height
	    spiral_twist_1.links.new(group_input_3.outputs[5], group_2.inputs[3])
	    #group_input_3.Upper Height -> group_2.Upper Height
	    spiral_twist_1.links.new(group_input_3.outputs[4], group_2.inputs[2])
	    #group_input_3.Tip Height -> group_2.Tip Height
	    spiral_twist_1.links.new(group_input_3.outputs[3], group_2.inputs[1])
	    #group_input_3.Root Radius -> group_2.Root Radius
	    spiral_twist_1.links.new(group_input_3.outputs[10], group_2.inputs[8])
	    #group_input_3.Lower Radius -> group_2.Lower Radius
	    spiral_twist_1.links.new(group_input_3.outputs[9], group_2.inputs[7])
	    #group_input_3.Upper Radius -> group_2.Upper Radius
	    spiral_twist_1.links.new(group_input_3.outputs[8], group_2.inputs[6])
	    #group_input_3.Tip Radius -> group_2.Tip Radius
	    spiral_twist_1.links.new(group_input_3.outputs[7], group_2.inputs[5])
	    #group_input_3.Root Rotations -> group_2.Root Rotations
	    spiral_twist_1.links.new(group_input_3.outputs[14], group_2.inputs[12])
	    #group_input_3.Lower Rotations -> group_2.Lower Rotations
	    spiral_twist_1.links.new(group_input_3.outputs[13], group_2.inputs[11])
	    #group_input_3.Upper Rotations -> group_2.Upper Rotations
	    spiral_twist_1.links.new(group_input_3.outputs[12], group_2.inputs[10])
	    #group_input_3.Tip Rotations -> group_2.Tip Rotations
	    spiral_twist_1.links.new(group_input_3.outputs[11], group_2.inputs[9])
	    #transform_geometry_002_1.Geometry -> group_001_2.Geometry
	    spiral_twist_1.links.new(transform_geometry_002_1.outputs[0], group_001_2.inputs[0])
	    #group_2.Geometry -> transform_geometry_002_1.Geometry
	    spiral_twist_1.links.new(group_2.outputs[0], transform_geometry_002_1.inputs[0])
	    #group_input_001_2.Curl XY Angle -> group_001_2.XY Angle
	    spiral_twist_1.links.new(group_input_001_2.outputs[15], group_001_2.inputs[1])
	    #group_input_001_2.Curl XZ Angle -> group_001_2.XZ Angle
	    spiral_twist_1.links.new(group_input_001_2.outputs[16], group_001_2.inputs[2])
	    #group_input_001_2.Curl Rotation -> transform_geometry_002_1.Rotation
	    spiral_twist_1.links.new(group_input_001_2.outputs[17], transform_geometry_002_1.inputs[2])
	    #group_input_001_2.Curl Scale -> transform_geometry_002_1.Scale
	    spiral_twist_1.links.new(group_input_001_2.outputs[18], transform_geometry_002_1.inputs[3])
	    #group_input_002_1.Geometry -> curve_to_points.Curve
	    spiral_twist_1.links.new(group_input_002_1.outputs[0], curve_to_points.inputs[0])
	    #group_input_003_1.Spiral Style -> spiral_style.Menu
	    spiral_twist_1.links.new(group_input_003_1.outputs[1], spiral_style.inputs[0])
	    #group_2.Geometry -> spiral_style.Spiral Bun
	    spiral_twist_1.links.new(group_2.outputs[0], spiral_style.inputs[1])
	    #group_001_2.Geometry -> spiral_style.Spiral Curl
	    spiral_twist_1.links.new(group_001_2.outputs[0], spiral_style.inputs[2])
	    #spiral_style.Output -> instance_on_points.Instance
	    spiral_twist_1.links.new(spiral_style.outputs[0], instance_on_points.inputs[2])
	    spiral_style_socket.default_value = 'Spiral Bun'
	    return spiral_twist_1
	
	spiral_twist_1 = spiral_twist_1_node_group()
	
	#initialize curve_root node group
	def curve_root_node_group():
	    curve_root = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Curve Root")
	
	    curve_root.color_tag = 'INPUT'
	    curve_root.description = "Reads information about each curve's root point"
	    curve_root.default_group_node_width = 140
	    
	
	
	    #curve_root interface
	    #Socket Root Selection
	    root_selection_socket_1 = curve_root.interface.new_socket(name = "Root Selection", in_out='OUTPUT', socket_type = 'NodeSocketBool')
	    root_selection_socket_1.default_value = False
	    root_selection_socket_1.attribute_domain = 'POINT'
	    root_selection_socket_1.description = "Boolean selection of curve root points"
	
	    #Socket Root Position
	    root_position_socket_1 = curve_root.interface.new_socket(name = "Root Position", in_out='OUTPUT', socket_type = 'NodeSocketVector')
	    root_position_socket_1.default_value = (0.0, 0.0, 0.0)
	    root_position_socket_1.min_value = -3.4028234663852886e+38
	    root_position_socket_1.max_value = 3.4028234663852886e+38
	    root_position_socket_1.subtype = 'NONE'
	    root_position_socket_1.attribute_domain = 'CURVE'
	    root_position_socket_1.description = "Position of the root point of a curve"
	
	    #Socket Root Direction
	    root_direction_socket_1 = curve_root.interface.new_socket(name = "Root Direction", in_out='OUTPUT', socket_type = 'NodeSocketVector')
	    root_direction_socket_1.default_value = (0.0, 0.0, 0.0)
	    root_direction_socket_1.min_value = -3.4028234663852886e+38
	    root_direction_socket_1.max_value = 3.4028234663852886e+38
	    root_direction_socket_1.subtype = 'NONE'
	    root_direction_socket_1.attribute_domain = 'CURVE'
	    root_direction_socket_1.description = "Direction of the root segment of a curve"
	
	    #Socket Root Index
	    root_index_socket_1 = curve_root.interface.new_socket(name = "Root Index", in_out='OUTPUT', socket_type = 'NodeSocketInt')
	    root_index_socket_1.default_value = 0
	    root_index_socket_1.min_value = -2147483648
	    root_index_socket_1.max_value = 2147483647
	    root_index_socket_1.subtype = 'NONE'
	    root_index_socket_1.attribute_domain = 'CURVE'
	    root_index_socket_1.description = "Index of the root point of a curve"
	
	
	    #initialize curve_root nodes
	    #node Position.002
	    position_002_2 = curve_root.nodes.new("GeometryNodeInputPosition")
	    position_002_2.name = "Position.002"
	
	    #node Interpolate Domain
	    interpolate_domain_2 = curve_root.nodes.new("GeometryNodeFieldOnDomain")
	    interpolate_domain_2.name = "Interpolate Domain"
	    interpolate_domain_2.data_type = 'INT'
	    interpolate_domain_2.domain = 'CURVE'
	
	    #node Field at Index.003
	    field_at_index_003_2 = curve_root.nodes.new("GeometryNodeFieldAtIndex")
	    field_at_index_003_2.name = "Field at Index.003"
	    field_at_index_003_2.data_type = 'FLOAT_VECTOR'
	    field_at_index_003_2.domain = 'POINT'
	
	    #node Interpolate Domain.001
	    interpolate_domain_001_2 = curve_root.nodes.new("GeometryNodeFieldOnDomain")
	    interpolate_domain_001_2.name = "Interpolate Domain.001"
	    interpolate_domain_001_2.data_type = 'FLOAT_VECTOR'
	    interpolate_domain_001_2.domain = 'CURVE'
	
	    #node Curve Tangent
	    curve_tangent_3 = curve_root.nodes.new("GeometryNodeInputTangent")
	    curve_tangent_3.name = "Curve Tangent"
	
	    #node Endpoint Selection
	    endpoint_selection_2 = curve_root.nodes.new("GeometryNodeCurveEndpointSelection")
	    endpoint_selection_2.name = "Endpoint Selection"
	    #Start Size
	    endpoint_selection_2.inputs[0].default_value = 1
	    #End Size
	    endpoint_selection_2.inputs[1].default_value = 0
	
	    #node Field at Index.004
	    field_at_index_004_2 = curve_root.nodes.new("GeometryNodeFieldAtIndex")
	    field_at_index_004_2.name = "Field at Index.004"
	    field_at_index_004_2.data_type = 'FLOAT_VECTOR'
	    field_at_index_004_2.domain = 'POINT'
	
	    #node Interpolate Domain.002
	    interpolate_domain_002_2 = curve_root.nodes.new("GeometryNodeFieldOnDomain")
	    interpolate_domain_002_2.name = "Interpolate Domain.002"
	    interpolate_domain_002_2.data_type = 'FLOAT_VECTOR'
	    interpolate_domain_002_2.domain = 'CURVE'
	
	    #node Group Output
	    group_output_7 = curve_root.nodes.new("NodeGroupOutput")
	    group_output_7.name = "Group Output"
	    group_output_7.is_active_output = True
	
	    #node Points of Curve
	    points_of_curve_2 = curve_root.nodes.new("GeometryNodePointsOfCurve")
	    points_of_curve_2.name = "Points of Curve"
	    points_of_curve_2.inputs[0].hide = True
	    points_of_curve_2.inputs[1].hide = True
	    points_of_curve_2.outputs[1].hide = True
	    #Curve Index
	    points_of_curve_2.inputs[0].default_value = 0
	    #Weights
	    points_of_curve_2.inputs[1].default_value = 0.0
	    #Sort Index
	    points_of_curve_2.inputs[2].default_value = 0
	
	
	
	
	
	    #Set locations
	    position_002_2.location = (-608.1627807617188, -70.55814361572266)
	    interpolate_domain_2.location = (-608.1627807617188, 90.18604278564453)
	    field_at_index_003_2.location = (-407.2325439453125, 70.09302520751953)
	    interpolate_domain_001_2.location = (-206.30230712890625, 70.09302520751953)
	    curve_tangent_3.location = (-608.1627807617188, -271.4883728027344)
	    endpoint_selection_2.location = (-206.30230712890625, 190.65118408203125)
	    field_at_index_004_2.location = (-407.2325439453125, -130.83721923828125)
	    interpolate_domain_002_2.location = (-206.30230712890625, -130.83721923828125)
	    group_output_7.location = (75.0, 50.0)
	    points_of_curve_2.location = (-789.0, 50.0)
	
	    #Set dimensions
	    position_002_2.width, position_002_2.height = 140.0, 100.0
	    interpolate_domain_2.width, interpolate_domain_2.height = 140.0, 100.0
	    field_at_index_003_2.width, field_at_index_003_2.height = 140.0, 100.0
	    interpolate_domain_001_2.width, interpolate_domain_001_2.height = 140.0, 100.0
	    curve_tangent_3.width, curve_tangent_3.height = 140.0, 100.0
	    endpoint_selection_2.width, endpoint_selection_2.height = 140.0, 100.0
	    field_at_index_004_2.width, field_at_index_004_2.height = 140.0, 100.0
	    interpolate_domain_002_2.width, interpolate_domain_002_2.height = 140.0, 100.0
	    group_output_7.width, group_output_7.height = 140.0, 100.0
	    points_of_curve_2.width, points_of_curve_2.height = 140.0, 100.0
	
	    #initialize curve_root links
	    #position_002_2.Position -> field_at_index_003_2.Value
	    curve_root.links.new(position_002_2.outputs[0], field_at_index_003_2.inputs[1])
	    #interpolate_domain_001_2.Value -> group_output_7.Root Position
	    curve_root.links.new(interpolate_domain_001_2.outputs[0], group_output_7.inputs[1])
	    #interpolate_domain_2.Value -> field_at_index_003_2.Index
	    curve_root.links.new(interpolate_domain_2.outputs[0], field_at_index_003_2.inputs[0])
	    #points_of_curve_2.Point Index -> interpolate_domain_2.Value
	    curve_root.links.new(points_of_curve_2.outputs[0], interpolate_domain_2.inputs[0])
	    #interpolate_domain_2.Value -> group_output_7.Root Index
	    curve_root.links.new(interpolate_domain_2.outputs[0], group_output_7.inputs[3])
	    #endpoint_selection_2.Selection -> group_output_7.Root Selection
	    curve_root.links.new(endpoint_selection_2.outputs[0], group_output_7.inputs[0])
	    #field_at_index_003_2.Value -> interpolate_domain_001_2.Value
	    curve_root.links.new(field_at_index_003_2.outputs[0], interpolate_domain_001_2.inputs[0])
	    #interpolate_domain_002_2.Value -> group_output_7.Root Direction
	    curve_root.links.new(interpolate_domain_002_2.outputs[0], group_output_7.inputs[2])
	    #interpolate_domain_2.Value -> field_at_index_004_2.Index
	    curve_root.links.new(interpolate_domain_2.outputs[0], field_at_index_004_2.inputs[0])
	    #curve_tangent_3.Tangent -> field_at_index_004_2.Value
	    curve_root.links.new(curve_tangent_3.outputs[0], field_at_index_004_2.inputs[1])
	    #field_at_index_004_2.Value -> interpolate_domain_002_2.Value
	    curve_root.links.new(field_at_index_004_2.outputs[0], interpolate_domain_002_2.inputs[0])
	    return curve_root
	
	curve_root = curve_root_node_group()
	
	#initialize attach_hair_curves_to_surface node group
	def attach_hair_curves_to_surface_node_group():
	    attach_hair_curves_to_surface = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Attach Hair Curves to Surface")
	
	    attach_hair_curves_to_surface.color_tag = 'GEOMETRY'
	    attach_hair_curves_to_surface.description = "Attaches hair curves to a surface mesh"
	    attach_hair_curves_to_surface.default_group_node_width = 140
	    
	
	    attach_hair_curves_to_surface.is_modifier = True
	
	    #attach_hair_curves_to_surface interface
	    #Socket Geometry
	    geometry_socket_7 = attach_hair_curves_to_surface.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_7.attribute_domain = 'POINT'
	
	    #Socket Surface UV Coordinate
	    surface_uv_coordinate_socket = attach_hair_curves_to_surface.interface.new_socket(name = "Surface UV Coordinate", in_out='OUTPUT', socket_type = 'NodeSocketVector')
	    surface_uv_coordinate_socket.default_value = (0.0, 0.0, 0.0)
	    surface_uv_coordinate_socket.min_value = -3.4028234663852886e+38
	    surface_uv_coordinate_socket.max_value = 3.4028234663852886e+38
	    surface_uv_coordinate_socket.subtype = 'NONE'
	    surface_uv_coordinate_socket.attribute_domain = 'CURVE'
	    surface_uv_coordinate_socket.description = "Surface UV coordinates at the attachment point"
	
	    #Socket Surface Normal
	    surface_normal_socket = attach_hair_curves_to_surface.interface.new_socket(name = "Surface Normal", in_out='OUTPUT', socket_type = 'NodeSocketVector')
	    surface_normal_socket.default_value = (0.0, 0.0, 0.0)
	    surface_normal_socket.min_value = -3.4028234663852886e+38
	    surface_normal_socket.max_value = 3.4028234663852886e+38
	    surface_normal_socket.subtype = 'NONE'
	    surface_normal_socket.attribute_domain = 'CURVE'
	    surface_normal_socket.description = "Surface normal at the attachment point"
	
	    #Socket Geometry
	    geometry_socket_8 = attach_hair_curves_to_surface.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_8.attribute_domain = 'POINT'
	    geometry_socket_8.description = "Input Geometry (may include other than curves)"
	
	    #Socket Surface
	    surface_socket = attach_hair_curves_to_surface.interface.new_socket(name = "Surface", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    surface_socket.attribute_domain = 'POINT'
	    surface_socket.description = "Surface geometry to attach hair curves to"
	
	    #Socket Surface
	    surface_socket_1 = attach_hair_curves_to_surface.interface.new_socket(name = "Surface", in_out='INPUT', socket_type = 'NodeSocketObject')
	    surface_socket_1.attribute_domain = 'POINT'
	    surface_socket_1.description = "Surface Object to attach to (needs to have matching transforms)"
	
	    #Socket Surface UV Map
	    surface_uv_map_socket = attach_hair_curves_to_surface.interface.new_socket(name = "Surface UV Map", in_out='INPUT', socket_type = 'NodeSocketVector')
	    surface_uv_map_socket.default_value = (0.0, 0.0, 0.0)
	    surface_uv_map_socket.min_value = -3.4028234663852886e+38
	    surface_uv_map_socket.max_value = 3.4028234663852886e+38
	    surface_uv_map_socket.subtype = 'NONE'
	    surface_uv_map_socket.default_attribute_name = "UVMap"
	    surface_uv_map_socket.attribute_domain = 'POINT'
	    surface_uv_map_socket.hide_value = True
	    surface_uv_map_socket.description = "Surface UV map used for attachment"
	
	    #Socket Surface Rest Position
	    surface_rest_position_socket = attach_hair_curves_to_surface.interface.new_socket(name = "Surface Rest Position", in_out='INPUT', socket_type = 'NodeSocketBool')
	    surface_rest_position_socket.default_value = False
	    surface_rest_position_socket.attribute_domain = 'POINT'
	    surface_rest_position_socket.description = "Set the surface mesh into its rest position before attachment"
	
	    #Socket Sample Attachment UV
	    sample_attachment_uv_socket = attach_hair_curves_to_surface.interface.new_socket(name = "Sample Attachment UV", in_out='INPUT', socket_type = 'NodeSocketBool')
	    sample_attachment_uv_socket.default_value = True
	    sample_attachment_uv_socket.attribute_domain = 'POINT'
	    sample_attachment_uv_socket.description = "Sample the surface UV map at the attachment point"
	
	    #Socket Snap to Surface
	    snap_to_surface_socket = attach_hair_curves_to_surface.interface.new_socket(name = "Snap to Surface", in_out='INPUT', socket_type = 'NodeSocketBool')
	    snap_to_surface_socket.default_value = True
	    snap_to_surface_socket.attribute_domain = 'POINT'
	    snap_to_surface_socket.description = "Snap the root of each curve to the closest surface point"
	
	    #Socket Align to Surface Normal
	    align_to_surface_normal_socket = attach_hair_curves_to_surface.interface.new_socket(name = "Align to Surface Normal", in_out='INPUT', socket_type = 'NodeSocketBool')
	    align_to_surface_normal_socket.default_value = True
	    align_to_surface_normal_socket.attribute_domain = 'POINT'
	    align_to_surface_normal_socket.description = "Align the curve to the surface normal (needs a guide as reference)"
	
	    #Socket Blend along Curve
	    blend_along_curve_socket = attach_hair_curves_to_surface.interface.new_socket(name = "Blend along Curve", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    blend_along_curve_socket.default_value = 0.0
	    blend_along_curve_socket.min_value = 0.0
	    blend_along_curve_socket.max_value = 1.0
	    blend_along_curve_socket.subtype = 'FACTOR'
	    blend_along_curve_socket.attribute_domain = 'POINT'
	    blend_along_curve_socket.description = "Blend deformation along each curve from the root"
	
	
	    #initialize attach_hair_curves_to_surface nodes
	    #node Frame.004
	    frame_004_1 = attach_hair_curves_to_surface.nodes.new("NodeFrame")
	    frame_004_1.label = "Write Data"
	    frame_004_1.name = "Frame.004"
	    frame_004_1.label_size = 20
	    frame_004_1.shrink = True
	
	    #node Frame.005
	    frame_005 = attach_hair_curves_to_surface.nodes.new("NodeFrame")
	    frame_005.label = "Sample Surface"
	    frame_005.name = "Frame.005"
	    frame_005.label_size = 20
	    frame_005.shrink = True
	
	    #node Frame
	    frame_2 = attach_hair_curves_to_surface.nodes.new("NodeFrame")
	    frame_2.label = "Surface Geometry Input"
	    frame_2.name = "Frame"
	    frame_2.label_size = 20
	    frame_2.shrink = True
	
	    #node Frame.006
	    frame_006 = attach_hair_curves_to_surface.nodes.new("NodeFrame")
	    frame_006.label = "Geometry Socket with Priority"
	    frame_006.name = "Frame.006"
	    frame_006.label_size = 20
	    frame_006.shrink = True
	
	    #node Frame.007
	    frame_007 = attach_hair_curves_to_surface.nodes.new("NodeFrame")
	    frame_007.label = "Object in Local Space"
	    frame_007.name = "Frame.007"
	    frame_007.label_size = 20
	    frame_007.shrink = True
	
	    #node Frame.011
	    frame_011 = attach_hair_curves_to_surface.nodes.new("NodeFrame")
	    frame_011.label = "Sample Attachment UV"
	    frame_011.name = "Frame.011"
	    frame_011.label_size = 20
	    frame_011.shrink = True
	
	    #node Frame.001
	    frame_001_1 = attach_hair_curves_to_surface.nodes.new("NodeFrame")
	    frame_001_1.label = "Smooth Normals"
	    frame_001_1.name = "Frame.001"
	    frame_001_1.label_size = 20
	    frame_001_1.shrink = True
	
	    #node Frame.010
	    frame_010 = attach_hair_curves_to_surface.nodes.new("NodeFrame")
	    frame_010.label = "Calculate New Position"
	    frame_010.name = "Frame.010"
	    frame_010.use_custom_color = True
	    frame_010.color = (0.13328450918197632, 0.13328450918197632, 0.13328450918197632)
	    frame_010.label_size = 20
	    frame_010.shrink = True
	
	    #node Frame.003
	    frame_003_1 = attach_hair_curves_to_surface.nodes.new("NodeFrame")
	    frame_003_1.label = "Blend Deformation"
	    frame_003_1.name = "Frame.003"
	    frame_003_1.label_size = 20
	    frame_003_1.shrink = True
	
	    #node Frame.002
	    frame_002_1 = attach_hair_curves_to_surface.nodes.new("NodeFrame")
	    frame_002_1.label = "Align to Normal"
	    frame_002_1.name = "Frame.002"
	    frame_002_1.use_custom_color = True
	    frame_002_1.color = (0.08883915841579437, 0.08883915841579437, 0.08883915841579437)
	    frame_002_1.label_size = 20
	    frame_002_1.shrink = True
	
	    #node Frame.008
	    frame_008 = attach_hair_curves_to_surface.nodes.new("NodeFrame")
	    frame_008.label = "Optimize"
	    frame_008.name = "Frame.008"
	    frame_008.label_size = 20
	    frame_008.shrink = True
	
	    #node Frame.009
	    frame_009 = attach_hair_curves_to_surface.nodes.new("NodeFrame")
	    frame_009.label = "Sample from Guide"
	    frame_009.name = "Frame.009"
	    frame_009.label_size = 20
	    frame_009.shrink = True
	
	    #node Reroute.010
	    reroute_010 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_010.name = "Reroute.010"
	    reroute_010.socket_idname = "NodeSocketGeometry"
	    #node Reroute.013
	    reroute_013_1 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_013_1.name = "Reroute.013"
	    reroute_013_1.socket_idname = "NodeSocketBool"
	    #node Group Output
	    group_output_8 = attach_hair_curves_to_surface.nodes.new("NodeGroupOutput")
	    group_output_8.name = "Group Output"
	    group_output_8.is_active_output = True
	
	    #node Reroute.003
	    reroute_003_1 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_003_1.name = "Reroute.003"
	    reroute_003_1.socket_idname = "NodeSocketVector"
	    #node Switch
	    switch_1 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSwitch")
	    switch_1.name = "Switch"
	    switch_1.input_type = 'GEOMETRY'
	
	    #node Store Named Attribute
	    store_named_attribute_1 = attach_hair_curves_to_surface.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_1.name = "Store Named Attribute"
	    store_named_attribute_1.data_type = 'FLOAT2'
	    store_named_attribute_1.domain = 'CURVE'
	    #Selection
	    store_named_attribute_1.inputs[1].default_value = True
	    #Name
	    store_named_attribute_1.inputs[2].default_value = "surface_uv_coordinate"
	
	    #node Group Input.007
	    group_input_007_2 = attach_hair_curves_to_surface.nodes.new("NodeGroupInput")
	    group_input_007_2.name = "Group Input.007"
	    group_input_007_2.outputs[0].hide = True
	    group_input_007_2.outputs[1].hide = True
	    group_input_007_2.outputs[2].hide = True
	    group_input_007_2.outputs[3].hide = True
	    group_input_007_2.outputs[4].hide = True
	    group_input_007_2.outputs[6].hide = True
	    group_input_007_2.outputs[7].hide = True
	    group_input_007_2.outputs[8].hide = True
	    group_input_007_2.outputs[9].hide = True
	
	    #node Reroute.016
	    reroute_016_1 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_016_1.name = "Reroute.016"
	    reroute_016_1.socket_idname = "NodeSocketGeometry"
	    #node Reroute.005
	    reroute_005 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_005.name = "Reroute.005"
	    reroute_005.socket_idname = "NodeSocketVector"
	    #node Store Named Attribute.001
	    store_named_attribute_001 = attach_hair_curves_to_surface.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_001.name = "Store Named Attribute.001"
	    store_named_attribute_001.data_type = 'FLOAT_VECTOR'
	    store_named_attribute_001.domain = 'CURVE'
	    #Selection
	    store_named_attribute_001.inputs[1].default_value = True
	    #Name
	    store_named_attribute_001.inputs[2].default_value = "surface_normal"
	
	    #node Named Attribute.004
	    named_attribute_004 = attach_hair_curves_to_surface.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute_004.name = "Named Attribute.004"
	    named_attribute_004.data_type = 'FLOAT_VECTOR'
	    #Name
	    named_attribute_004.inputs[0].default_value = "surface_normal"
	
	    #node Reroute.012
	    reroute_012_1 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_012_1.name = "Reroute.012"
	    reroute_012_1.socket_idname = "NodeSocketBool"
	    #node Reroute.014
	    reroute_014_1 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_014_1.name = "Reroute.014"
	    reroute_014_1.socket_idname = "NodeSocketBool"
	    #node Reroute.006
	    reroute_006 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_006.name = "Reroute.006"
	    reroute_006.socket_idname = "NodeSocketGeometry"
	    #node Named Attribute.003
	    named_attribute_003 = attach_hair_curves_to_surface.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute_003.name = "Named Attribute.003"
	    named_attribute_003.data_type = 'FLOAT_VECTOR'
	    #Name
	    named_attribute_003.inputs[0].default_value = "surface_uv_coordinate"
	
	    #node Switch.008
	    switch_008 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSwitch")
	    switch_008.name = "Switch.008"
	    switch_008.input_type = 'GEOMETRY'
	
	    #node Switch.009
	    switch_009 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSwitch")
	    switch_009.name = "Switch.009"
	    switch_009.input_type = 'VECTOR'
	
	    #node Switch.010
	    switch_010 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSwitch")
	    switch_010.name = "Switch.010"
	    switch_010.input_type = 'VECTOR'
	
	    #node Set Position.001
	    set_position_001_1 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSetPosition")
	    set_position_001_1.name = "Set Position.001"
	    set_position_001_1.inputs[2].hide = True
	    #Position
	    set_position_001_1.inputs[2].default_value = (0.0, 0.0, 0.0)
	
	    #node Reroute.002
	    reroute_002_1 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_002_1.name = "Reroute.002"
	    reroute_002_1.socket_idname = "NodeSocketVector"
	    #node Reroute.018
	    reroute_018_1 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_018_1.name = "Reroute.018"
	    reroute_018_1.socket_idname = "NodeSocketVector"
	    #node Reroute.017
	    reroute_017_1 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_017_1.name = "Reroute.017"
	    reroute_017_1.socket_idname = "NodeSocketGeometry"
	    #node Group Input.009
	    group_input_009 = attach_hair_curves_to_surface.nodes.new("NodeGroupInput")
	    group_input_009.name = "Group Input.009"
	    group_input_009.outputs[0].hide = True
	    group_input_009.outputs[1].hide = True
	    group_input_009.outputs[2].hide = True
	    group_input_009.outputs[4].hide = True
	    group_input_009.outputs[5].hide = True
	    group_input_009.outputs[6].hide = True
	    group_input_009.outputs[7].hide = True
	    group_input_009.outputs[8].hide = True
	    group_input_009.outputs[9].hide = True
	
	    #node Position
	    position = attach_hair_curves_to_surface.nodes.new("GeometryNodeInputPosition")
	    position.name = "Position"
	
	    #node Named Attribute.001
	    named_attribute_001 = attach_hair_curves_to_surface.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute_001.name = "Named Attribute.001"
	    named_attribute_001.data_type = 'FLOAT_VECTOR'
	    #Name
	    named_attribute_001.inputs[0].default_value = "surface_uv_coordinate"
	
	    #node Capture Attribute.001
	    capture_attribute_001_1 = attach_hair_curves_to_surface.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_001_1.name = "Capture Attribute.001"
	    capture_attribute_001_1.active_index = 0
	    capture_attribute_001_1.capture_items.clear()
	    capture_attribute_001_1.capture_items.new('FLOAT', "Value")
	    capture_attribute_001_1.capture_items["Value"].data_type = 'FLOAT_VECTOR'
	    capture_attribute_001_1.domain = 'CURVE'
	
	    #node Group Input.004
	    group_input_004_1 = attach_hair_curves_to_surface.nodes.new("NodeGroupInput")
	    group_input_004_1.name = "Group Input.004"
	    group_input_004_1.outputs[0].hide = True
	    group_input_004_1.outputs[2].hide = True
	    group_input_004_1.outputs[3].hide = True
	    group_input_004_1.outputs[4].hide = True
	    group_input_004_1.outputs[5].hide = True
	    group_input_004_1.outputs[6].hide = True
	    group_input_004_1.outputs[7].hide = True
	    group_input_004_1.outputs[8].hide = True
	    group_input_004_1.outputs[9].hide = True
	
	    #node Domain Size.002
	    domain_size_002 = attach_hair_curves_to_surface.nodes.new("GeometryNodeAttributeDomainSize")
	    domain_size_002.name = "Domain Size.002"
	    domain_size_002.component = 'MESH'
	    domain_size_002.outputs[0].hide = True
	    domain_size_002.outputs[1].hide = True
	    domain_size_002.outputs[3].hide = True
	    domain_size_002.outputs[4].hide = True
	    domain_size_002.outputs[5].hide = True
	
	    #node Compare.001
	    compare_001 = attach_hair_curves_to_surface.nodes.new("FunctionNodeCompare")
	    compare_001.name = "Compare.001"
	    compare_001.data_type = 'INT'
	    compare_001.mode = 'ELEMENT'
	    compare_001.operation = 'NOT_EQUAL'
	    #B_INT
	    compare_001.inputs[3].default_value = 0
	
	    #node Object Info.001
	    object_info_001 = attach_hair_curves_to_surface.nodes.new("GeometryNodeObjectInfo")
	    object_info_001.name = "Object Info.001"
	    object_info_001.transform_space = 'ORIGINAL'
	    object_info_001.inputs[1].hide = True
	    object_info_001.outputs[1].hide = True
	    object_info_001.outputs[3].hide = True
	    #As Instance
	    object_info_001.inputs[1].default_value = False
	
	    #node Group Input.002
	    group_input_002_2 = attach_hair_curves_to_surface.nodes.new("NodeGroupInput")
	    group_input_002_2.name = "Group Input.002"
	    group_input_002_2.outputs[0].hide = True
	    group_input_002_2.outputs[1].hide = True
	    group_input_002_2.outputs[3].hide = True
	    group_input_002_2.outputs[4].hide = True
	    group_input_002_2.outputs[5].hide = True
	    group_input_002_2.outputs[6].hide = True
	    group_input_002_2.outputs[7].hide = True
	    group_input_002_2.outputs[8].hide = True
	    group_input_002_2.outputs[9].hide = True
	
	    #node Switch.005
	    switch_005 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSwitch")
	    switch_005.name = "Switch.005"
	    switch_005.input_type = 'GEOMETRY'
	
	    #node Domain Size.003
	    domain_size_003 = attach_hair_curves_to_surface.nodes.new("GeometryNodeAttributeDomainSize")
	    domain_size_003.name = "Domain Size.003"
	    domain_size_003.component = 'MESH'
	    domain_size_003.outputs[0].hide = True
	    domain_size_003.outputs[1].hide = True
	    domain_size_003.outputs[3].hide = True
	    domain_size_003.outputs[4].hide = True
	    domain_size_003.outputs[5].hide = True
	
	    #node Compare.002
	    compare_002 = attach_hair_curves_to_surface.nodes.new("FunctionNodeCompare")
	    compare_002.name = "Compare.002"
	    compare_002.data_type = 'INT'
	    compare_002.mode = 'ELEMENT'
	    compare_002.operation = 'EQUAL'
	    #B_INT
	    compare_002.inputs[3].default_value = 0
	
	    #node Named Attribute
	    named_attribute_1 = attach_hair_curves_to_surface.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute_1.name = "Named Attribute"
	    named_attribute_1.data_type = 'FLOAT_VECTOR'
	    #Name
	    named_attribute_1.inputs[0].default_value = "rest_position"
	
	    #node Reroute
	    reroute_1 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_1.name = "Reroute"
	    reroute_1.socket_idname = "NodeSocketGeometry"
	    #node Group Input.005
	    group_input_005_2 = attach_hair_curves_to_surface.nodes.new("NodeGroupInput")
	    group_input_005_2.name = "Group Input.005"
	    group_input_005_2.outputs[0].hide = True
	    group_input_005_2.outputs[1].hide = True
	    group_input_005_2.outputs[2].hide = True
	    group_input_005_2.outputs[3].hide = True
	    group_input_005_2.outputs[5].hide = True
	    group_input_005_2.outputs[6].hide = True
	    group_input_005_2.outputs[7].hide = True
	    group_input_005_2.outputs[8].hide = True
	    group_input_005_2.outputs[9].hide = True
	
	    #node Set Position
	    set_position_1 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSetPosition")
	    set_position_1.name = "Set Position"
	    set_position_1.inputs[3].hide = True
	    #Offset
	    set_position_1.inputs[3].default_value = (0.0, 0.0, 0.0)
	
	    #node Switch.007
	    switch_007 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSwitch")
	    switch_007.name = "Switch.007"
	    switch_007.input_type = 'GEOMETRY'
	
	    #node Reroute.015
	    reroute_015_1 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_015_1.name = "Reroute.015"
	    reroute_015_1.socket_idname = "NodeSocketBool"
	    #node Reroute.011
	    reroute_011 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_011.name = "Reroute.011"
	    reroute_011.socket_idname = "NodeSocketGeometry"
	    #node Group Input
	    group_input_4 = attach_hair_curves_to_surface.nodes.new("NodeGroupInput")
	    group_input_4.name = "Group Input"
	    group_input_4.outputs[1].hide = True
	    group_input_4.outputs[2].hide = True
	    group_input_4.outputs[3].hide = True
	    group_input_4.outputs[4].hide = True
	    group_input_4.outputs[5].hide = True
	    group_input_4.outputs[6].hide = True
	    group_input_4.outputs[7].hide = True
	    group_input_4.outputs[8].hide = True
	    group_input_4.outputs[9].hide = True
	
	    #node Capture Attribute.002
	    capture_attribute_002_1 = attach_hair_curves_to_surface.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_002_1.name = "Capture Attribute.002"
	    capture_attribute_002_1.active_index = 0
	    capture_attribute_002_1.capture_items.clear()
	    capture_attribute_002_1.capture_items.new('FLOAT', "Value")
	    capture_attribute_002_1.capture_items["Value"].data_type = 'FLOAT_VECTOR'
	    capture_attribute_002_1.domain = 'CURVE'
	
	    #node Reroute.001
	    reroute_001_1 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_001_1.name = "Reroute.001"
	    reroute_001_1.socket_idname = "NodeSocketGeometry"
	    #node Sample Nearest Surface
	    sample_nearest_surface = attach_hair_curves_to_surface.nodes.new("GeometryNodeSampleNearestSurface")
	    sample_nearest_surface.name = "Sample Nearest Surface"
	    sample_nearest_surface.data_type = 'FLOAT_VECTOR'
	    #Group ID
	    sample_nearest_surface.inputs[2].default_value = 0
	    #Sample Group ID
	    sample_nearest_surface.inputs[4].default_value = 0
	
	    #node Group
	    group_3 = attach_hair_curves_to_surface.nodes.new("GeometryNodeGroup")
	    group_3.name = "Group"
	    group_3.node_tree = curve_root
	    group_3.outputs[0].hide = True
	    group_3.outputs[2].hide = True
	    group_3.outputs[3].hide = True
	
	    #node Group Input.001
	    group_input_001_3 = attach_hair_curves_to_surface.nodes.new("NodeGroupInput")
	    group_input_001_3.name = "Group Input.001"
	    group_input_001_3.outputs[0].hide = True
	    group_input_001_3.outputs[1].hide = True
	    group_input_001_3.outputs[2].hide = True
	    group_input_001_3.outputs[4].hide = True
	    group_input_001_3.outputs[5].hide = True
	    group_input_001_3.outputs[6].hide = True
	    group_input_001_3.outputs[7].hide = True
	    group_input_001_3.outputs[8].hide = True
	    group_input_001_3.outputs[9].hide = True
	
	    #node Reroute.020
	    reroute_020_1 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_020_1.name = "Reroute.020"
	    reroute_020_1.socket_idname = "NodeSocketGeometry"
	    #node Normal
	    normal_1 = attach_hair_curves_to_surface.nodes.new("GeometryNodeInputNormal")
	    normal_1.name = "Normal"
	    normal_1.legacy_corner_normals = True
	
	    #node Capture Attribute
	    capture_attribute_1 = attach_hair_curves_to_surface.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_1.name = "Capture Attribute"
	    capture_attribute_1.hide = True
	    capture_attribute_1.active_index = 0
	    capture_attribute_1.capture_items.clear()
	    capture_attribute_1.capture_items.new('FLOAT', "Value")
	    capture_attribute_1.capture_items["Value"].data_type = 'FLOAT_VECTOR'
	    capture_attribute_1.domain = 'POINT'
	
	    #node Sample UV Surface
	    sample_uv_surface = attach_hair_curves_to_surface.nodes.new("GeometryNodeSampleUVSurface")
	    sample_uv_surface.name = "Sample UV Surface"
	    sample_uv_surface.hide = True
	    sample_uv_surface.data_type = 'FLOAT_VECTOR'
	    sample_uv_surface.outputs[1].hide = True
	
	    #node Sample UV Surface.003
	    sample_uv_surface_003 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSampleUVSurface")
	    sample_uv_surface_003.name = "Sample UV Surface.003"
	    sample_uv_surface_003.hide = True
	    sample_uv_surface_003.data_type = 'FLOAT_VECTOR'
	    sample_uv_surface_003.outputs[1].hide = True
	
	    #node Reroute.004
	    reroute_004_1 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_004_1.name = "Reroute.004"
	    reroute_004_1.socket_idname = "NodeSocketVector"
	    #node Sample UV Surface.001
	    sample_uv_surface_001 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSampleUVSurface")
	    sample_uv_surface_001.name = "Sample UV Surface.001"
	    sample_uv_surface_001.hide = True
	    sample_uv_surface_001.data_type = 'FLOAT_VECTOR'
	    sample_uv_surface_001.outputs[1].hide = True
	
	    #node Group.001
	    group_001_3 = attach_hair_curves_to_surface.nodes.new("GeometryNodeGroup")
	    group_001_3.name = "Group.001"
	    group_001_3.node_tree = curve_root
	    group_001_3.outputs[0].hide = True
	    group_001_3.outputs[2].hide = True
	    group_001_3.outputs[3].hide = True
	
	    #node Position.001
	    position_001 = attach_hair_curves_to_surface.nodes.new("GeometryNodeInputPosition")
	    position_001.name = "Position.001"
	
	    #node Vector Math
	    vector_math_2 = attach_hair_curves_to_surface.nodes.new("ShaderNodeVectorMath")
	    vector_math_2.name = "Vector Math"
	    vector_math_2.operation = 'SUBTRACT'
	
	    #node Vector Math.001
	    vector_math_001_2 = attach_hair_curves_to_surface.nodes.new("ShaderNodeVectorMath")
	    vector_math_001_2.name = "Vector Math.001"
	    vector_math_001_2.operation = 'SUBTRACT'
	
	    #node Vector Math.004
	    vector_math_004_1 = attach_hair_curves_to_surface.nodes.new("ShaderNodeVectorMath")
	    vector_math_004_1.name = "Vector Math.004"
	    vector_math_004_1.operation = 'SUBTRACT'
	
	    #node Vector Math.003
	    vector_math_003_1 = attach_hair_curves_to_surface.nodes.new("ShaderNodeVectorMath")
	    vector_math_003_1.name = "Vector Math.003"
	    vector_math_003_1.operation = 'SUBTRACT'
	
	    #node Group Input.003
	    group_input_003_2 = attach_hair_curves_to_surface.nodes.new("NodeGroupInput")
	    group_input_003_2.name = "Group Input.003"
	    group_input_003_2.outputs[0].hide = True
	    group_input_003_2.outputs[1].hide = True
	    group_input_003_2.outputs[2].hide = True
	    group_input_003_2.outputs[3].hide = True
	    group_input_003_2.outputs[4].hide = True
	    group_input_003_2.outputs[5].hide = True
	    group_input_003_2.outputs[6].hide = True
	    group_input_003_2.outputs[8].hide = True
	    group_input_003_2.outputs[9].hide = True
	
	    #node Group Input.006
	    group_input_006_2 = attach_hair_curves_to_surface.nodes.new("NodeGroupInput")
	    group_input_006_2.name = "Group Input.006"
	    group_input_006_2.outputs[0].hide = True
	    group_input_006_2.outputs[1].hide = True
	    group_input_006_2.outputs[2].hide = True
	    group_input_006_2.outputs[3].hide = True
	    group_input_006_2.outputs[4].hide = True
	    group_input_006_2.outputs[5].hide = True
	    group_input_006_2.outputs[7].hide = True
	    group_input_006_2.outputs[8].hide = True
	    group_input_006_2.outputs[9].hide = True
	
	    #node Switch.003
	    switch_003 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSwitch")
	    switch_003.name = "Switch.003"
	    switch_003.hide = True
	    switch_003.input_type = 'VECTOR'
	    #False
	    switch_003.inputs[1].default_value = (0.0, 0.0, 0.0)
	
	    #node Switch.002
	    switch_002 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSwitch")
	    switch_002.name = "Switch.002"
	    switch_002.input_type = 'VECTOR'
	
	    #node Vector Math.002
	    vector_math_002_1 = attach_hair_curves_to_surface.nodes.new("ShaderNodeVectorMath")
	    vector_math_002_1.name = "Vector Math.002"
	    vector_math_002_1.operation = 'ADD'
	
	    #node Vector Math.005
	    vector_math_005_1 = attach_hair_curves_to_surface.nodes.new("ShaderNodeVectorMath")
	    vector_math_005_1.name = "Vector Math.005"
	    vector_math_005_1.operation = 'SCALE'
	
	    #node Boolean Math
	    boolean_math = attach_hair_curves_to_surface.nodes.new("FunctionNodeBooleanMath")
	    boolean_math.name = "Boolean Math"
	    boolean_math.operation = 'OR'
	
	    #node Spline Parameter
	    spline_parameter = attach_hair_curves_to_surface.nodes.new("GeometryNodeSplineParameter")
	    spline_parameter.name = "Spline Parameter"
	    spline_parameter.outputs[1].hide = True
	    spline_parameter.outputs[2].hide = True
	
	    #node Group Input.008
	    group_input_008 = attach_hair_curves_to_surface.nodes.new("NodeGroupInput")
	    group_input_008.name = "Group Input.008"
	    group_input_008.outputs[0].hide = True
	    group_input_008.outputs[1].hide = True
	    group_input_008.outputs[2].hide = True
	    group_input_008.outputs[3].hide = True
	    group_input_008.outputs[4].hide = True
	    group_input_008.outputs[5].hide = True
	    group_input_008.outputs[6].hide = True
	    group_input_008.outputs[7].hide = True
	    group_input_008.outputs[9].hide = True
	
	    #node Map Range
	    map_range = attach_hair_curves_to_surface.nodes.new("ShaderNodeMapRange")
	    map_range.name = "Map Range"
	    map_range.hide = True
	    map_range.clamp = True
	    map_range.data_type = 'FLOAT'
	    map_range.interpolation_type = 'SMOOTHSTEP'
	    #From Min
	    map_range.inputs[1].default_value = 0.0
	    #To Min
	    map_range.inputs[3].default_value = 1.0
	    #To Max
	    map_range.inputs[4].default_value = 0.0
	
	    #node Compare
	    compare = attach_hair_curves_to_surface.nodes.new("FunctionNodeCompare")
	    compare.name = "Compare"
	    compare.data_type = 'FLOAT'
	    compare.mode = 'ELEMENT'
	    compare.operation = 'EQUAL'
	    #B
	    compare.inputs[1].default_value = 0.0
	    #Epsilon
	    compare.inputs[12].default_value = 0.0
	
	    #node Switch.004
	    switch_004 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSwitch")
	    switch_004.name = "Switch.004"
	    switch_004.input_type = 'FLOAT'
	    #True
	    switch_004.inputs[2].default_value = 1.0
	
	    #node Position.002
	    position_002_3 = attach_hair_curves_to_surface.nodes.new("GeometryNodeInputPosition")
	    position_002_3.name = "Position.002"
	
	    #node Evaluate on Domain
	    evaluate_on_domain_1 = attach_hair_curves_to_surface.nodes.new("GeometryNodeFieldOnDomain")
	    evaluate_on_domain_1.name = "Evaluate on Domain"
	    evaluate_on_domain_1.data_type = 'FLOAT_VECTOR'
	    evaluate_on_domain_1.domain = 'CURVE'
	
	    #node Reroute.009
	    reroute_009 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_009.name = "Reroute.009"
	    reroute_009.socket_idname = "NodeSocketVector"
	    #node Evaluate on Domain.002
	    evaluate_on_domain_002_2 = attach_hair_curves_to_surface.nodes.new("GeometryNodeFieldOnDomain")
	    evaluate_on_domain_002_2.name = "Evaluate on Domain.002"
	    evaluate_on_domain_002_2.hide = True
	    evaluate_on_domain_002_2.data_type = 'FLOAT_VECTOR'
	    evaluate_on_domain_002_2.domain = 'CURVE'
	
	    #node Switch.006
	    switch_006 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSwitch")
	    switch_006.name = "Switch.006"
	    switch_006.input_type = 'VECTOR'
	
	    #node Vector Rotate
	    vector_rotate_1 = attach_hair_curves_to_surface.nodes.new("ShaderNodeVectorRotate")
	    vector_rotate_1.name = "Vector Rotate"
	    vector_rotate_1.invert = False
	    vector_rotate_1.rotation_type = 'EULER_XYZ'
	    vector_rotate_1.inputs[1].hide = True
	    vector_rotate_1.inputs[2].hide = True
	    vector_rotate_1.inputs[3].hide = True
	    #Center
	    vector_rotate_1.inputs[1].default_value = (0.0, 0.0, 0.0)
	
	    #node Vector Rotate.003
	    vector_rotate_003 = attach_hair_curves_to_surface.nodes.new("ShaderNodeVectorRotate")
	    vector_rotate_003.name = "Vector Rotate.003"
	    vector_rotate_003.invert = True
	    vector_rotate_003.rotation_type = 'EULER_XYZ'
	    vector_rotate_003.inputs[1].hide = True
	    vector_rotate_003.inputs[2].hide = True
	    vector_rotate_003.inputs[3].hide = True
	    #Center
	    vector_rotate_003.inputs[1].default_value = (0.0, 0.0, 0.0)
	
	    #node Align Euler to Vector.003
	    align_euler_to_vector_003 = attach_hair_curves_to_surface.nodes.new("FunctionNodeAlignEulerToVector")
	    align_euler_to_vector_003.name = "Align Euler to Vector.003"
	    align_euler_to_vector_003.axis = 'Z'
	    align_euler_to_vector_003.pivot_axis = 'AUTO'
	    align_euler_to_vector_003.inputs[0].hide = True
	    align_euler_to_vector_003.inputs[1].hide = True
	    #Rotation
	    align_euler_to_vector_003.inputs[0].default_value = (0.0, 0.0, 0.0)
	    #Factor
	    align_euler_to_vector_003.inputs[1].default_value = 1.0
	
	    #node Align Euler to Vector.002
	    align_euler_to_vector_002 = attach_hair_curves_to_surface.nodes.new("FunctionNodeAlignEulerToVector")
	    align_euler_to_vector_002.name = "Align Euler to Vector.002"
	    align_euler_to_vector_002.axis = 'Z'
	    align_euler_to_vector_002.pivot_axis = 'AUTO'
	    align_euler_to_vector_002.inputs[0].hide = True
	    align_euler_to_vector_002.inputs[1].hide = True
	    #Rotation
	    align_euler_to_vector_002.inputs[0].default_value = (0.0, 0.0, 0.0)
	    #Factor
	    align_euler_to_vector_002.inputs[1].default_value = 1.0
	
	    #node Evaluate on Domain.003
	    evaluate_on_domain_003 = attach_hair_curves_to_surface.nodes.new("GeometryNodeFieldOnDomain")
	    evaluate_on_domain_003.name = "Evaluate on Domain.003"
	    evaluate_on_domain_003.hide = True
	    evaluate_on_domain_003.data_type = 'FLOAT_VECTOR'
	    evaluate_on_domain_003.domain = 'CURVE'
	
	    #node Switch.001
	    switch_001_1 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSwitch")
	    switch_001_1.name = "Switch.001"
	    switch_001_1.hide = True
	    switch_001_1.input_type = 'VECTOR'
	
	    #node Accumulate Field
	    accumulate_field = attach_hair_curves_to_surface.nodes.new("GeometryNodeAccumulateField")
	    accumulate_field.name = "Accumulate Field"
	    accumulate_field.hide = True
	    accumulate_field.data_type = 'FLOAT'
	    accumulate_field.domain = 'POINT'
	    #Group Index
	    accumulate_field.inputs[1].default_value = 0
	
	    #node Sample Index.001
	    sample_index_001 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSampleIndex")
	    sample_index_001.name = "Sample Index.001"
	    sample_index_001.hide = True
	    sample_index_001.clamp = False
	    sample_index_001.data_type = 'BOOLEAN'
	    sample_index_001.domain = 'CURVE'
	    #Index
	    sample_index_001.inputs[2].default_value = 0
	
	    #node Reroute.019
	    reroute_019_1 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_019_1.name = "Reroute.019"
	    reroute_019_1.socket_idname = "NodeSocketVector"
	    #node Named Attribute.002
	    named_attribute_002 = attach_hair_curves_to_surface.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute_002.name = "Named Attribute.002"
	    named_attribute_002.data_type = 'INT'
	    #Name
	    named_attribute_002.inputs[0].default_value = "guide_curve_index"
	
	    #node Reroute.007
	    reroute_007 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_007.name = "Reroute.007"
	    reroute_007.socket_idname = "NodeSocketGeometry"
	    #node Reroute.008
	    reroute_008 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_008.name = "Reroute.008"
	    reroute_008.socket_idname = "NodeSocketVector"
	    #node Sample Index
	    sample_index = attach_hair_curves_to_surface.nodes.new("GeometryNodeSampleIndex")
	    sample_index.name = "Sample Index"
	    sample_index.hide = True
	    sample_index.clamp = False
	    sample_index.data_type = 'FLOAT_VECTOR'
	    sample_index.domain = 'CURVE'
	
	
	
	
	    #Set parents
	    frame_006.parent = frame_2
	    frame_007.parent = frame_2
	    frame_003_1.parent = frame_010
	    frame_002_1.parent = frame_010
	    frame_008.parent = frame_002_1
	    frame_009.parent = frame_002_1
	    reroute_003_1.parent = frame_004_1
	    switch_1.parent = frame_004_1
	    store_named_attribute_1.parent = frame_004_1
	    group_input_007_2.parent = frame_004_1
	    reroute_016_1.parent = frame_004_1
	    reroute_005.parent = frame_004_1
	    store_named_attribute_001.parent = frame_004_1
	    named_attribute_004.parent = frame_004_1
	    reroute_012_1.parent = frame_004_1
	    named_attribute_003.parent = frame_004_1
	    switch_008.parent = frame_004_1
	    switch_009.parent = frame_004_1
	    switch_010.parent = frame_004_1
	    reroute_002_1.parent = frame_005
	    reroute_018_1.parent = frame_005
	    reroute_017_1.parent = frame_005
	    group_input_009.parent = frame_005
	    position.parent = frame_005
	    named_attribute_001.parent = frame_005
	    group_input_004_1.parent = frame_006
	    domain_size_002.parent = frame_006
	    compare_001.parent = frame_006
	    object_info_001.parent = frame_007
	    group_input_002_2.parent = frame_007
	    switch_005.parent = frame_2
	    domain_size_003.parent = frame_2
	    compare_002.parent = frame_2
	    named_attribute_1.parent = frame_2
	    reroute_1.parent = frame_2
	    group_input_005_2.parent = frame_2
	    set_position_1.parent = frame_2
	    switch_007.parent = frame_2
	    sample_nearest_surface.parent = frame_011
	    group_3.parent = frame_011
	    group_input_001_3.parent = frame_011
	    normal_1.parent = frame_001_1
	    capture_attribute_1.parent = frame_001_1
	    sample_uv_surface.parent = frame_005
	    sample_uv_surface_003.parent = frame_005
	    reroute_004_1.parent = frame_005
	    sample_uv_surface_001.parent = frame_005
	    group_001_3.parent = frame_010
	    position_001.parent = frame_010
	    vector_math_2.parent = frame_010
	    vector_math_001_2.parent = frame_010
	    vector_math_004_1.parent = frame_010
	    vector_math_003_1.parent = frame_010
	    group_input_003_2.parent = frame_010
	    group_input_006_2.parent = frame_010
	    switch_003.parent = frame_010
	    switch_002.parent = frame_010
	    vector_math_002_1.parent = frame_010
	    vector_math_005_1.parent = frame_010
	    boolean_math.parent = frame_010
	    spline_parameter.parent = frame_003_1
	    group_input_008.parent = frame_003_1
	    map_range.parent = frame_003_1
	    compare.parent = frame_003_1
	    switch_004.parent = frame_003_1
	    position_002_3.parent = frame_010
	    evaluate_on_domain_1.parent = frame_010
	    reroute_009.parent = frame_002_1
	    evaluate_on_domain_002_2.parent = frame_002_1
	    switch_006.parent = frame_002_1
	    vector_rotate_1.parent = frame_002_1
	    vector_rotate_003.parent = frame_002_1
	    align_euler_to_vector_003.parent = frame_002_1
	    align_euler_to_vector_002.parent = frame_002_1
	    evaluate_on_domain_003.parent = frame_002_1
	    switch_001_1.parent = frame_008
	    accumulate_field.parent = frame_008
	    sample_index_001.parent = frame_008
	    reroute_019_1.parent = frame_002_1
	    named_attribute_002.parent = frame_009
	    reroute_007.parent = frame_009
	    reroute_008.parent = frame_009
	    sample_index.parent = frame_009
	
	    #Set locations
	    frame_004_1.location = (-1215.903076171875, 262.0)
	    frame_005.location = (-4968.0, -121.0)
	    frame_2.location = (-7319.0, 140.0)
	    frame_006.location = (30.0, -355.0)
	    frame_007.location = (207.0, -181.0)
	    frame_011.location = (-5752.0, 120.0)
	    frame_001_1.location = (-5510.0, -382.0)
	    frame_010.location = (-4110.3515625, 32.0)
	    frame_003_1.location = (1565.3515625, -503.0)
	    frame_002_1.location = (29.999755859375, -437.0)
	    frame_008.location = (219.351806640625, -40.0)
	    frame_009.location = (30.0, -217.5032958984375)
	    reroute_010.location = (-798.60986328125, 472.99615478515625)
	    reroute_013_1.location = (-789.0, 512.1389770507812)
	    group_output_8.location = (75.0, 50.0)
	    reroute_003_1.location = (35.0, -292.3721618652344)
	    switch_1.location = (320.95263671875, -40.143096923828125)
	    store_named_attribute_1.location = (115.3720703125, -151.72100830078125)
	    group_input_007_2.location = (122.9049072265625, -39.53450012207031)
	    reroute_016_1.location = (45.1358642578125, -151.72100830078125)
	    reroute_005.location = (406.810302734375, -272.2791442871094)
	    store_named_attribute_001.location = (527.368408203125, -51.255889892578125)
	    named_attribute_004.location = (607.740478515625, -513.3954467773438)
	    reroute_012_1.location = (768.484619140625, -252.18612670898438)
	    reroute_014_1.location = (-507.69775390625, 311.209228515625)
	    reroute_006.location = (-547.8837890625, 291.1162109375)
	    named_attribute_003.location = (607.740478515625, -352.6512451171875)
	    switch_008.location = (808.670654296875, -71.34890747070312)
	    switch_009.location = (808.670654296875, -212.00006103515625)
	    switch_010.location = (808.670654296875, -392.8372802734375)
	    set_position_001_1.location = (-1472.16259765625, 230.837158203125)
	    reroute_002_1.location = (220.65625, -190.25262451171875)
	    reroute_018_1.location = (220.65625, -150.06658935546875)
	    reroute_017_1.location = (220.65625, -109.88055419921875)
	    group_input_009.location = (29.99072265625, -180.322021484375)
	    position.location = (29.99072265625, -39.67083740234375)
	    named_attribute_001.location = (29.99072265625, -260.694091796875)
	    capture_attribute_001_1.location = (-4365.55810546875, 210.744140625)
	    group_input_004_1.location = (29.669921875, -178.9044189453125)
	    domain_size_002.location = (207.6806640625, -80.07354736328125)
	    compare_001.location = (388.517578125, -39.88751220703125)
	    object_info_001.location = (210.88330078125, -39.64691162109375)
	    group_input_002_2.location = (30.0458984375, -79.83294677734375)
	    switch_005.location = (640.525390625, -283.5823974609375)
	    domain_size_003.location = (938.8193359375, -79.91128540039062)
	    compare_002.location = (1119.65625, -39.725250244140625)
	    named_attribute_1.location = (820.7041015625, -432.90301513671875)
	    reroute_1.location = (961.35546875, -332.43792724609375)
	    group_input_005_2.location = (1021.63427734375, -252.0657958984375)
	    set_position_1.location = (1021.63427734375, -352.53094482421875)
	    switch_007.location = (1222.564453125, -231.9727783203125)
	    reroute_015_1.location = (-5129.0927734375, 532.2319946289062)
	    reroute_011.location = (-5109.0, 492.04595947265625)
	    group_input_4.location = (-5510.8603515625, 351.395263671875)
	    capture_attribute_002_1.location = (-5209.46484375, 230.837158203125)
	    reroute_001_1.location = (-4887.9765625, -653.2559814453125)
	    sample_nearest_surface.location = (210.7509765625, -40.199798583984375)
	    group_3.location = (29.9140625, -180.85098266601562)
	    group_input_001_3.location = (29.9140625, -100.4788818359375)
	    reroute_020_1.location = (-4526.30224609375, -10.2791748046875)
	    normal_1.location = (29.5712890625, -45.01953125)
	    capture_attribute_1.location = (230.50146484375, -45.01953125)
	    sample_uv_surface.location = (321.1396484375, -50.02386474609375)
	    sample_uv_surface_003.location = (321.1396484375, -130.39593505859375)
	    reroute_004_1.location = (220.6748046875, -230.86102294921875)
	    sample_uv_surface_001.location = (321.1396484375, -210.76800537109375)
	    group_001_3.location = (158.627685546875, -240.71258544921875)
	    position_001.location = (339.46484375, -321.08465576171875)
	    vector_math_2.location = (339.46484375, -140.2474365234375)
	    vector_math_001_2.location = (540.39501953125, -321.08465576171875)
	    vector_math_004_1.location = (1826.3486328125, -341.17767333984375)
	    vector_math_003_1.location = (2027.27880859375, -200.52651977539062)
	    group_input_003_2.location = (1424.48828125, -220.79666137695312)
	    group_input_006_2.location = (1424.48828125, -100.238525390625)
	    switch_003.location = (1625.41845703125, -180.61062622070312)
	    switch_002.location = (1625.41845703125, -220.79666137695312)
	    vector_math_002_1.location = (1826.3486328125, -140.424560546875)
	    vector_math_005_1.location = (2248.30224609375, -200.70364379882812)
	    boolean_math.location = (1625.41845703125, -39.959442138671875)
	    spline_parameter.location = (32.72265625, -81.9400634765625)
	    group_input_008.location = (30.322265625, -161.4296875)
	    map_range.location = (205.259765625, -190.3057861328125)
	    compare.location = (205.20068359375, -39.6795654296875)
	    switch_004.location = (386.037841796875, -59.772705078125)
	    position_002_3.location = (1625.41845703125, -371.6761474609375)
	    evaluate_on_domain_1.location = (531.248291015625, -115.30325317382812)
	    reroute_009.location = (731.747802734375, -64.921875)
	    evaluate_on_domain_002_2.location = (630.95361328125, -265.85211181640625)
	    switch_006.location = (992.6279296875, -64.921875)
	    vector_rotate_1.location = (1173.465087890625, -64.921875)
	    vector_rotate_003.location = (811.790771484375, -165.386962890625)
	    align_euler_to_vector_003.location = (630.95361328125, -165.386962890625)
	    align_euler_to_vector_002.location = (630.95361328125, -306.0382080078125)
	    evaluate_on_domain_003.location = (630.95361328125, -406.5032958984375)
	    switch_001_1.location = (210.67138671875, -105.2939453125)
	    accumulate_field.location = (29.834228515625, -45.014892578125)
	    sample_index_001.location = (29.834228515625, -85.200927734375)
	    reroute_019_1.location = (48.255859375, -185.48004150390625)
	    named_attribute_002.location = (35.0, -105.279052734375)
	    reroute_007.location = (35.0, -45.0)
	    reroute_008.location = (35.0, -85.18603515625)
	    sample_index.location = (215.837158203125, -65.093017578125)
	
	    #Set dimensions
	    frame_004_1.width, frame_004_1.height = 978.903076171875, 664.0
	    frame_005.width, frame_005.height = 491.0, 412.0
	    frame_2.width, frame_2.height = 1393.0, 646.0
	    frame_006.width, frame_006.height = 559.0, 261.0
	    frame_007.width, frame_007.height = 381.0, 215.0
	    frame_011.width, frame_011.height = 390.33642578125, 279.0
	    frame_001_1.width, frame_001_1.height = 401.0, 125.0
	    frame_010.width, frame_010.height = 2418.3515625, 971.0
	    frame_003_1.width, frame_003_1.height = 556.0, 250.0
	    frame_002_1.width, frame_002_1.height = 1343.351806640625, 504.0
	    frame_008.width, frame_008.height = 381.0, 160.0
	    frame_009.width, frame_009.height = 385.351806640625, 256.4967041015625
	    reroute_010.width, reroute_010.height = 100.0, 100.0
	    reroute_013_1.width, reroute_013_1.height = 100.0, 100.0
	    group_output_8.width, group_output_8.height = 140.0, 100.0
	    reroute_003_1.width, reroute_003_1.height = 100.0, 100.0
	    switch_1.width, switch_1.height = 140.0, 100.0
	    store_named_attribute_1.width, store_named_attribute_1.height = 140.0, 100.0
	    group_input_007_2.width, group_input_007_2.height = 140.0, 100.0
	    reroute_016_1.width, reroute_016_1.height = 100.0, 100.0
	    reroute_005.width, reroute_005.height = 100.0, 100.0
	    store_named_attribute_001.width, store_named_attribute_001.height = 140.0, 100.0
	    named_attribute_004.width, named_attribute_004.height = 140.0, 100.0
	    reroute_012_1.width, reroute_012_1.height = 100.0, 100.0
	    reroute_014_1.width, reroute_014_1.height = 100.0, 100.0
	    reroute_006.width, reroute_006.height = 100.0, 100.0
	    named_attribute_003.width, named_attribute_003.height = 140.0, 100.0
	    switch_008.width, switch_008.height = 140.0, 100.0
	    switch_009.width, switch_009.height = 140.0, 100.0
	    switch_010.width, switch_010.height = 140.0, 100.0
	    set_position_001_1.width, set_position_001_1.height = 140.0, 100.0
	    reroute_002_1.width, reroute_002_1.height = 100.0, 100.0
	    reroute_018_1.width, reroute_018_1.height = 100.0, 100.0
	    reroute_017_1.width, reroute_017_1.height = 100.0, 100.0
	    group_input_009.width, group_input_009.height = 140.0, 100.0
	    position.width, position.height = 140.0, 100.0
	    named_attribute_001.width, named_attribute_001.height = 140.0, 100.0
	    capture_attribute_001_1.width, capture_attribute_001_1.height = 140.0, 100.0
	    group_input_004_1.width, group_input_004_1.height = 140.0, 100.0
	    domain_size_002.width, domain_size_002.height = 140.0, 100.0
	    compare_001.width, compare_001.height = 140.0, 100.0
	    object_info_001.width, object_info_001.height = 140.0, 100.0
	    group_input_002_2.width, group_input_002_2.height = 140.0, 100.0
	    switch_005.width, switch_005.height = 140.0, 100.0
	    domain_size_003.width, domain_size_003.height = 140.0, 100.0
	    compare_002.width, compare_002.height = 140.0, 100.0
	    named_attribute_1.width, named_attribute_1.height = 140.0, 100.0
	    reroute_1.width, reroute_1.height = 100.0, 100.0
	    group_input_005_2.width, group_input_005_2.height = 140.0, 100.0
	    set_position_1.width, set_position_1.height = 140.0, 100.0
	    switch_007.width, switch_007.height = 140.0, 100.0
	    reroute_015_1.width, reroute_015_1.height = 100.0, 100.0
	    reroute_011.width, reroute_011.height = 100.0, 100.0
	    group_input_4.width, group_input_4.height = 140.0, 100.0
	    capture_attribute_002_1.width, capture_attribute_002_1.height = 140.0, 100.0
	    reroute_001_1.width, reroute_001_1.height = 100.0, 100.0
	    sample_nearest_surface.width, sample_nearest_surface.height = 149.33627319335938, 100.0
	    group_3.width, group_3.height = 140.0, 100.0
	    group_input_001_3.width, group_input_001_3.height = 140.0, 100.0
	    reroute_020_1.width, reroute_020_1.height = 100.0, 100.0
	    normal_1.width, normal_1.height = 140.0, 100.0
	    capture_attribute_1.width, capture_attribute_1.height = 140.0, 100.0
	    sample_uv_surface.width, sample_uv_surface.height = 140.0, 100.0
	    sample_uv_surface_003.width, sample_uv_surface_003.height = 140.0, 100.0
	    reroute_004_1.width, reroute_004_1.height = 100.0, 100.0
	    sample_uv_surface_001.width, sample_uv_surface_001.height = 140.0, 100.0
	    group_001_3.width, group_001_3.height = 140.0, 100.0
	    position_001.width, position_001.height = 140.0, 100.0
	    vector_math_2.width, vector_math_2.height = 140.0, 100.0
	    vector_math_001_2.width, vector_math_001_2.height = 140.0, 100.0
	    vector_math_004_1.width, vector_math_004_1.height = 140.0, 100.0
	    vector_math_003_1.width, vector_math_003_1.height = 140.0, 100.0
	    group_input_003_2.width, group_input_003_2.height = 140.0, 100.0
	    group_input_006_2.width, group_input_006_2.height = 140.0, 100.0
	    switch_003.width, switch_003.height = 140.0, 100.0
	    switch_002.width, switch_002.height = 140.0, 100.0
	    vector_math_002_1.width, vector_math_002_1.height = 140.0, 100.0
	    vector_math_005_1.width, vector_math_005_1.height = 140.0, 100.0
	    boolean_math.width, boolean_math.height = 140.0, 100.0
	    spline_parameter.width, spline_parameter.height = 140.0, 100.0
	    group_input_008.width, group_input_008.height = 140.0, 100.0
	    map_range.width, map_range.height = 140.0, 100.0
	    compare.width, compare.height = 140.0, 100.0
	    switch_004.width, switch_004.height = 140.0, 100.0
	    position_002_3.width, position_002_3.height = 140.0, 100.0
	    evaluate_on_domain_1.width, evaluate_on_domain_1.height = 140.0, 100.0
	    reroute_009.width, reroute_009.height = 100.0, 100.0
	    evaluate_on_domain_002_2.width, evaluate_on_domain_002_2.height = 140.0, 100.0
	    switch_006.width, switch_006.height = 140.0, 100.0
	    vector_rotate_1.width, vector_rotate_1.height = 140.0, 100.0
	    vector_rotate_003.width, vector_rotate_003.height = 140.0, 100.0
	    align_euler_to_vector_003.width, align_euler_to_vector_003.height = 140.0, 100.0
	    align_euler_to_vector_002.width, align_euler_to_vector_002.height = 140.0, 100.0
	    evaluate_on_domain_003.width, evaluate_on_domain_003.height = 140.0, 100.0
	    switch_001_1.width, switch_001_1.height = 140.0, 100.0
	    accumulate_field.width, accumulate_field.height = 140.0, 100.0
	    sample_index_001.width, sample_index_001.height = 140.0, 100.0
	    reroute_019_1.width, reroute_019_1.height = 100.0, 100.0
	    named_attribute_002.width, named_attribute_002.height = 140.0, 100.0
	    reroute_007.width, reroute_007.height = 100.0, 100.0
	    reroute_008.width, reroute_008.height = 100.0, 100.0
	    sample_index.width, sample_index.height = 140.0, 100.0
	
	    #initialize attach_hair_curves_to_surface links
	    #domain_size_002.Face Count -> compare_001.A
	    attach_hair_curves_to_surface.links.new(domain_size_002.outputs[2], compare_001.inputs[2])
	    #compare_001.Result -> switch_005.Switch
	    attach_hair_curves_to_surface.links.new(compare_001.outputs[0], switch_005.inputs[0])
	    #group_input_002_2.Surface -> object_info_001.Object
	    attach_hair_curves_to_surface.links.new(group_input_002_2.outputs[2], object_info_001.inputs[0])
	    #group_input_004_1.Surface -> domain_size_002.Geometry
	    attach_hair_curves_to_surface.links.new(group_input_004_1.outputs[1], domain_size_002.inputs[0])
	    #group_input_004_1.Surface -> switch_005.True
	    attach_hair_curves_to_surface.links.new(group_input_004_1.outputs[1], switch_005.inputs[2])
	    #group_input_001_3.Surface UV Map -> sample_nearest_surface.Value
	    attach_hair_curves_to_surface.links.new(group_input_001_3.outputs[3], sample_nearest_surface.inputs[1])
	    #reroute_1.Output -> set_position_1.Geometry
	    attach_hair_curves_to_surface.links.new(reroute_1.outputs[0], set_position_1.inputs[0])
	    #reroute_1.Output -> switch_007.False
	    attach_hair_curves_to_surface.links.new(reroute_1.outputs[0], switch_007.inputs[1])
	    #set_position_1.Geometry -> switch_007.True
	    attach_hair_curves_to_surface.links.new(set_position_1.outputs[0], switch_007.inputs[2])
	    #switch_005.Output -> reroute_1.Input
	    attach_hair_curves_to_surface.links.new(switch_005.outputs[0], reroute_1.inputs[0])
	    #group_input_005_2.Surface Rest Position -> switch_007.Switch
	    attach_hair_curves_to_surface.links.new(group_input_005_2.outputs[4], switch_007.inputs[0])
	    #named_attribute_1.Attribute -> set_position_1.Position
	    attach_hair_curves_to_surface.links.new(named_attribute_1.outputs[0], set_position_1.inputs[2])
	    #named_attribute_1.Exists -> set_position_1.Selection
	    attach_hair_curves_to_surface.links.new(named_attribute_1.outputs[1], set_position_1.inputs[1])
	    #switch_007.Output -> sample_nearest_surface.Mesh
	    attach_hair_curves_to_surface.links.new(switch_007.outputs[0], sample_nearest_surface.inputs[0])
	    #object_info_001.Geometry -> switch_005.False
	    attach_hair_curves_to_surface.links.new(object_info_001.outputs[4], switch_005.inputs[1])
	    #group_3.Root Position -> sample_nearest_surface.Sample Position
	    attach_hair_curves_to_surface.links.new(group_3.outputs[1], sample_nearest_surface.inputs[3])
	    #reroute_002_1.Output -> sample_uv_surface.UV Map
	    attach_hair_curves_to_surface.links.new(reroute_002_1.outputs[0], sample_uv_surface.inputs[2])
	    #position.Position -> sample_uv_surface.Value
	    attach_hair_curves_to_surface.links.new(position.outputs[0], sample_uv_surface.inputs[1])
	    #reroute_004_1.Output -> sample_uv_surface.Sample UV
	    attach_hair_curves_to_surface.links.new(reroute_004_1.outputs[0], sample_uv_surface.inputs[3])
	    #capture_attribute_001_1.Geometry -> set_position_001_1.Geometry
	    attach_hair_curves_to_surface.links.new(capture_attribute_001_1.outputs[0], set_position_001_1.inputs[0])
	    #reroute_017_1.Output -> sample_uv_surface_001.Mesh
	    attach_hair_curves_to_surface.links.new(reroute_017_1.outputs[0], sample_uv_surface_001.inputs[0])
	    #reroute_004_1.Output -> sample_uv_surface_001.Sample UV
	    attach_hair_curves_to_surface.links.new(reroute_004_1.outputs[0], sample_uv_surface_001.inputs[3])
	    #reroute_002_1.Output -> sample_uv_surface_001.UV Map
	    attach_hair_curves_to_surface.links.new(reroute_002_1.outputs[0], sample_uv_surface_001.inputs[2])
	    #normal_1.Normal -> capture_attribute_1.Value
	    attach_hair_curves_to_surface.links.new(normal_1.outputs[0], capture_attribute_1.inputs[1])
	    #reroute_018_1.Output -> sample_uv_surface_001.Value
	    attach_hair_curves_to_surface.links.new(reroute_018_1.outputs[0], sample_uv_surface_001.inputs[1])
	    #sample_uv_surface.Value -> vector_math_2.Vector
	    attach_hair_curves_to_surface.links.new(sample_uv_surface.outputs[0], vector_math_2.inputs[0])
	    #group_001_3.Root Position -> vector_math_2.Vector
	    attach_hair_curves_to_surface.links.new(group_001_3.outputs[1], vector_math_2.inputs[1])
	    #vector_math_2.Vector -> evaluate_on_domain_1.Value
	    attach_hair_curves_to_surface.links.new(vector_math_2.outputs[0], evaluate_on_domain_1.inputs[0])
	    #position_001.Position -> vector_math_001_2.Vector
	    attach_hair_curves_to_surface.links.new(position_001.outputs[0], vector_math_001_2.inputs[0])
	    #group_001_3.Root Position -> vector_math_001_2.Vector
	    attach_hair_curves_to_surface.links.new(group_001_3.outputs[1], vector_math_001_2.inputs[1])
	    #switch_006.Output -> vector_rotate_1.Vector
	    attach_hair_curves_to_surface.links.new(switch_006.outputs[0], vector_rotate_1.inputs[0])
	    #reroute_007.Output -> sample_index.Geometry
	    attach_hair_curves_to_surface.links.new(reroute_007.outputs[0], sample_index.inputs[0])
	    #named_attribute_002.Attribute -> sample_index.Index
	    attach_hair_curves_to_surface.links.new(named_attribute_002.outputs[0], sample_index.inputs[2])
	    #position_002_3.Position -> vector_math_004_1.Vector
	    attach_hair_curves_to_surface.links.new(position_002_3.outputs[0], vector_math_004_1.inputs[0])
	    #vector_math_002_1.Vector -> vector_math_003_1.Vector
	    attach_hair_curves_to_surface.links.new(vector_math_002_1.outputs[0], vector_math_003_1.inputs[0])
	    #switch_003.Output -> vector_math_002_1.Vector
	    attach_hair_curves_to_surface.links.new(switch_003.outputs[0], vector_math_002_1.inputs[0])
	    #switch_002.Output -> vector_math_002_1.Vector
	    attach_hair_curves_to_surface.links.new(switch_002.outputs[0], vector_math_002_1.inputs[1])
	    #reroute_009.Output -> vector_rotate_003.Vector
	    attach_hair_curves_to_surface.links.new(reroute_009.outputs[0], vector_rotate_003.inputs[0])
	    #evaluate_on_domain_002_2.Value -> vector_rotate_003.Rotation
	    attach_hair_curves_to_surface.links.new(evaluate_on_domain_002_2.outputs[0], vector_rotate_003.inputs[4])
	    #evaluate_on_domain_003.Value -> vector_rotate_1.Rotation
	    attach_hair_curves_to_surface.links.new(evaluate_on_domain_003.outputs[0], vector_rotate_1.inputs[4])
	    #group_001_3.Root Position -> vector_math_004_1.Vector
	    attach_hair_curves_to_surface.links.new(group_001_3.outputs[1], vector_math_004_1.inputs[1])
	    #vector_math_004_1.Vector -> vector_math_003_1.Vector
	    attach_hair_curves_to_surface.links.new(vector_math_004_1.outputs[0], vector_math_003_1.inputs[1])
	    #reroute_016_1.Output -> store_named_attribute_1.Geometry
	    attach_hair_curves_to_surface.links.new(reroute_016_1.outputs[0], store_named_attribute_1.inputs[0])
	    #group_input_4.Geometry -> capture_attribute_002_1.Geometry
	    attach_hair_curves_to_surface.links.new(group_input_4.outputs[0], capture_attribute_002_1.inputs[0])
	    #reroute_003_1.Output -> store_named_attribute_1.Value
	    attach_hair_curves_to_surface.links.new(reroute_003_1.outputs[0], store_named_attribute_1.inputs[3])
	    #sample_nearest_surface.Value -> capture_attribute_002_1.Value
	    attach_hair_curves_to_surface.links.new(sample_nearest_surface.outputs[0], capture_attribute_002_1.inputs[1])
	    #capture_attribute_002_1.Value -> reroute_004_1.Input
	    attach_hair_curves_to_surface.links.new(capture_attribute_002_1.outputs[1], reroute_004_1.inputs[0])
	    #switch_007.Output -> capture_attribute_1.Geometry
	    attach_hair_curves_to_surface.links.new(switch_007.outputs[0], capture_attribute_1.inputs[0])
	    #align_euler_to_vector_003.Rotation -> evaluate_on_domain_002_2.Value
	    attach_hair_curves_to_surface.links.new(align_euler_to_vector_003.outputs[0], evaluate_on_domain_002_2.inputs[0])
	    #align_euler_to_vector_002.Rotation -> evaluate_on_domain_003.Value
	    attach_hair_curves_to_surface.links.new(align_euler_to_vector_002.outputs[0], evaluate_on_domain_003.inputs[0])
	    #capture_attribute_1.Geometry -> reroute_001_1.Input
	    attach_hair_curves_to_surface.links.new(capture_attribute_1.outputs[0], reroute_001_1.inputs[0])
	    #reroute_018_1.Output -> sample_uv_surface_003.Value
	    attach_hair_curves_to_surface.links.new(reroute_018_1.outputs[0], sample_uv_surface_003.inputs[1])
	    #reroute_002_1.Output -> sample_uv_surface_003.UV Map
	    attach_hair_curves_to_surface.links.new(reroute_002_1.outputs[0], sample_uv_surface_003.inputs[2])
	    #reroute_017_1.Output -> sample_uv_surface_003.Mesh
	    attach_hair_curves_to_surface.links.new(reroute_017_1.outputs[0], sample_uv_surface_003.inputs[0])
	    #named_attribute_001.Attribute -> sample_uv_surface_003.Sample UV
	    attach_hair_curves_to_surface.links.new(named_attribute_001.outputs[0], sample_uv_surface_003.inputs[3])
	    #reroute_019_1.Output -> switch_001_1.True
	    attach_hair_curves_to_surface.links.new(reroute_019_1.outputs[0], switch_001_1.inputs[2])
	    #reroute_020_1.Output -> sample_index_001.Geometry
	    attach_hair_curves_to_surface.links.new(reroute_020_1.outputs[0], sample_index_001.inputs[0])
	    #named_attribute_001.Exists -> accumulate_field.Value
	    attach_hair_curves_to_surface.links.new(named_attribute_001.outputs[1], accumulate_field.inputs[0])
	    #accumulate_field.Total -> sample_index_001.Value
	    attach_hair_curves_to_surface.links.new(accumulate_field.outputs[2], sample_index_001.inputs[1])
	    #sample_index_001.Value -> switch_001_1.Switch
	    attach_hair_curves_to_surface.links.new(sample_index_001.outputs[0], switch_001_1.inputs[0])
	    #reroute_008.Output -> sample_index.Value
	    attach_hair_curves_to_surface.links.new(reroute_008.outputs[0], sample_index.inputs[1])
	    #vector_rotate_1.Vector -> switch_002.True
	    attach_hair_curves_to_surface.links.new(vector_rotate_1.outputs[0], switch_002.inputs[2])
	    #vector_math_001_2.Vector -> switch_002.False
	    attach_hair_curves_to_surface.links.new(vector_math_001_2.outputs[0], switch_002.inputs[1])
	    #group_input_003_2.Align to Surface Normal -> switch_002.Switch
	    attach_hair_curves_to_surface.links.new(group_input_003_2.outputs[7], switch_002.inputs[0])
	    #vector_math_005_1.Vector -> set_position_001_1.Offset
	    attach_hair_curves_to_surface.links.new(vector_math_005_1.outputs[0], set_position_001_1.inputs[3])
	    #evaluate_on_domain_1.Value -> switch_003.True
	    attach_hair_curves_to_surface.links.new(evaluate_on_domain_1.outputs[0], switch_003.inputs[2])
	    #group_input_006_2.Snap to Surface -> switch_003.Switch
	    attach_hair_curves_to_surface.links.new(group_input_006_2.outputs[6], switch_003.inputs[0])
	    #group_input_006_2.Snap to Surface -> boolean_math.Boolean
	    attach_hair_curves_to_surface.links.new(group_input_006_2.outputs[6], boolean_math.inputs[0])
	    #group_input_003_2.Align to Surface Normal -> boolean_math.Boolean
	    attach_hair_curves_to_surface.links.new(group_input_003_2.outputs[7], boolean_math.inputs[1])
	    #boolean_math.Boolean -> set_position_001_1.Selection
	    attach_hair_curves_to_surface.links.new(boolean_math.outputs[0], set_position_001_1.inputs[1])
	    #capture_attribute_002_1.Value -> reroute_003_1.Input
	    attach_hair_curves_to_surface.links.new(capture_attribute_002_1.outputs[1], reroute_003_1.inputs[0])
	    #switch_009.Output -> group_output_8.Surface UV Coordinate
	    attach_hair_curves_to_surface.links.new(switch_009.outputs[0], group_output_8.inputs[1])
	    #store_named_attribute_1.Geometry -> switch_1.True
	    attach_hair_curves_to_surface.links.new(store_named_attribute_1.outputs[0], switch_1.inputs[2])
	    #group_input_007_2.Sample Attachment UV -> switch_1.Switch
	    attach_hair_curves_to_surface.links.new(group_input_007_2.outputs[5], switch_1.inputs[0])
	    #reroute_016_1.Output -> switch_1.False
	    attach_hair_curves_to_surface.links.new(reroute_016_1.outputs[0], switch_1.inputs[1])
	    #switch_1.Output -> store_named_attribute_001.Geometry
	    attach_hair_curves_to_surface.links.new(switch_1.outputs[0], store_named_attribute_001.inputs[0])
	    #reroute_020_1.Output -> capture_attribute_001_1.Geometry
	    attach_hair_curves_to_surface.links.new(reroute_020_1.outputs[0], capture_attribute_001_1.inputs[0])
	    #reroute_005.Output -> store_named_attribute_001.Value
	    attach_hair_curves_to_surface.links.new(reroute_005.outputs[0], store_named_attribute_001.inputs[3])
	    #capture_attribute_001_1.Value -> reroute_005.Input
	    attach_hair_curves_to_surface.links.new(capture_attribute_001_1.outputs[1], reroute_005.inputs[0])
	    #switch_010.Output -> group_output_8.Surface Normal
	    attach_hair_curves_to_surface.links.new(switch_010.outputs[0], group_output_8.inputs[2])
	    #sample_uv_surface_001.Value -> capture_attribute_001_1.Value
	    attach_hair_curves_to_surface.links.new(sample_uv_surface_001.outputs[0], capture_attribute_001_1.inputs[1])
	    #vector_math_003_1.Vector -> vector_math_005_1.Vector
	    attach_hair_curves_to_surface.links.new(vector_math_003_1.outputs[0], vector_math_005_1.inputs[0])
	    #spline_parameter.Factor -> map_range.Value
	    attach_hair_curves_to_surface.links.new(spline_parameter.outputs[0], map_range.inputs[0])
	    #group_input_008.Blend along Curve -> map_range.From Max
	    attach_hair_curves_to_surface.links.new(group_input_008.outputs[8], map_range.inputs[2])
	    #group_input_008.Blend along Curve -> compare.A
	    attach_hair_curves_to_surface.links.new(group_input_008.outputs[8], compare.inputs[0])
	    #compare.Result -> switch_004.Switch
	    attach_hair_curves_to_surface.links.new(compare.outputs[0], switch_004.inputs[0])
	    #map_range.Result -> switch_004.False
	    attach_hair_curves_to_surface.links.new(map_range.outputs[0], switch_004.inputs[1])
	    #switch_004.Output -> vector_math_005_1.Scale
	    attach_hair_curves_to_surface.links.new(switch_004.outputs[0], vector_math_005_1.inputs[3])
	    #switch_001_1.Output -> align_euler_to_vector_003.Vector
	    attach_hair_curves_to_surface.links.new(switch_001_1.outputs[0], align_euler_to_vector_003.inputs[2])
	    #sample_index.Value -> switch_001_1.False
	    attach_hair_curves_to_surface.links.new(sample_index.outputs[0], switch_001_1.inputs[1])
	    #named_attribute_002.Exists -> switch_006.Switch
	    attach_hair_curves_to_surface.links.new(named_attribute_002.outputs[1], switch_006.inputs[0])
	    #reroute_009.Output -> switch_006.False
	    attach_hair_curves_to_surface.links.new(reroute_009.outputs[0], switch_006.inputs[1])
	    #vector_rotate_003.Vector -> switch_006.True
	    attach_hair_curves_to_surface.links.new(vector_rotate_003.outputs[0], switch_006.inputs[2])
	    #vector_math_001_2.Vector -> reroute_009.Input
	    attach_hair_curves_to_surface.links.new(vector_math_001_2.outputs[0], reroute_009.inputs[0])
	    #reroute_011.Output -> reroute_010.Input
	    attach_hair_curves_to_surface.links.new(reroute_011.outputs[0], reroute_010.inputs[0])
	    #group_input_4.Geometry -> reroute_011.Input
	    attach_hair_curves_to_surface.links.new(group_input_4.outputs[0], reroute_011.inputs[0])
	    #store_named_attribute_001.Geometry -> switch_008.False
	    attach_hair_curves_to_surface.links.new(store_named_attribute_001.outputs[0], switch_008.inputs[1])
	    #reroute_006.Output -> switch_008.True
	    attach_hair_curves_to_surface.links.new(reroute_006.outputs[0], switch_008.inputs[2])
	    #switch_008.Output -> group_output_8.Geometry
	    attach_hair_curves_to_surface.links.new(switch_008.outputs[0], group_output_8.inputs[0])
	    #reroute_003_1.Output -> switch_009.False
	    attach_hair_curves_to_surface.links.new(reroute_003_1.outputs[0], switch_009.inputs[1])
	    #reroute_005.Output -> switch_010.False
	    attach_hair_curves_to_surface.links.new(reroute_005.outputs[0], switch_010.inputs[1])
	    #domain_size_003.Face Count -> compare_002.A
	    attach_hair_curves_to_surface.links.new(domain_size_003.outputs[2], compare_002.inputs[2])
	    #switch_005.Output -> domain_size_003.Geometry
	    attach_hair_curves_to_surface.links.new(switch_005.outputs[0], domain_size_003.inputs[0])
	    #reroute_012_1.Output -> switch_008.Switch
	    attach_hair_curves_to_surface.links.new(reroute_012_1.outputs[0], switch_008.inputs[0])
	    #reroute_014_1.Output -> reroute_012_1.Input
	    attach_hair_curves_to_surface.links.new(reroute_014_1.outputs[0], reroute_012_1.inputs[0])
	    #reroute_012_1.Output -> switch_009.Switch
	    attach_hair_curves_to_surface.links.new(reroute_012_1.outputs[0], switch_009.inputs[0])
	    #reroute_012_1.Output -> switch_010.Switch
	    attach_hair_curves_to_surface.links.new(reroute_012_1.outputs[0], switch_010.inputs[0])
	    #named_attribute_003.Attribute -> switch_009.True
	    attach_hair_curves_to_surface.links.new(named_attribute_003.outputs[0], switch_009.inputs[2])
	    #named_attribute_004.Attribute -> switch_010.True
	    attach_hair_curves_to_surface.links.new(named_attribute_004.outputs[0], switch_010.inputs[2])
	    #reroute_015_1.Output -> reroute_013_1.Input
	    attach_hair_curves_to_surface.links.new(reroute_015_1.outputs[0], reroute_013_1.inputs[0])
	    #reroute_013_1.Output -> reroute_014_1.Input
	    attach_hair_curves_to_surface.links.new(reroute_013_1.outputs[0], reroute_014_1.inputs[0])
	    #compare_002.Result -> reroute_015_1.Input
	    attach_hair_curves_to_surface.links.new(compare_002.outputs[0], reroute_015_1.inputs[0])
	    #set_position_001_1.Geometry -> reroute_016_1.Input
	    attach_hair_curves_to_surface.links.new(set_position_001_1.outputs[0], reroute_016_1.inputs[0])
	    #capture_attribute_1.Geometry -> reroute_017_1.Input
	    attach_hair_curves_to_surface.links.new(capture_attribute_1.outputs[0], reroute_017_1.inputs[0])
	    #capture_attribute_1.Value -> reroute_018_1.Input
	    attach_hair_curves_to_surface.links.new(capture_attribute_1.outputs[1], reroute_018_1.inputs[0])
	    #reroute_010.Output -> reroute_006.Input
	    attach_hair_curves_to_surface.links.new(reroute_010.outputs[0], reroute_006.inputs[0])
	    #reroute_001_1.Output -> reroute_007.Input
	    attach_hair_curves_to_surface.links.new(reroute_001_1.outputs[0], reroute_007.inputs[0])
	    #sample_uv_surface_001.Value -> reroute_008.Input
	    attach_hair_curves_to_surface.links.new(sample_uv_surface_001.outputs[0], reroute_008.inputs[0])
	    #reroute_008.Output -> align_euler_to_vector_002.Vector
	    attach_hair_curves_to_surface.links.new(reroute_008.outputs[0], align_euler_to_vector_002.inputs[2])
	    #sample_uv_surface_003.Value -> reroute_019_1.Input
	    attach_hair_curves_to_surface.links.new(sample_uv_surface_003.outputs[0], reroute_019_1.inputs[0])
	    #reroute_017_1.Output -> sample_uv_surface.Mesh
	    attach_hair_curves_to_surface.links.new(reroute_017_1.outputs[0], sample_uv_surface.inputs[0])
	    #group_input_009.Surface UV Map -> reroute_002_1.Input
	    attach_hair_curves_to_surface.links.new(group_input_009.outputs[3], reroute_002_1.inputs[0])
	    #capture_attribute_002_1.Geometry -> reroute_020_1.Input
	    attach_hair_curves_to_surface.links.new(capture_attribute_002_1.outputs[0], reroute_020_1.inputs[0])
	    return attach_hair_curves_to_surface
	
	attach_hair_curves_to_surface = attach_hair_curves_to_surface_node_group()
	
	#initialize attach_hair node group
	def attach_hair_node_group():
	    attach_hair = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "ATTACH_HAIR")
	
	    attach_hair.color_tag = 'NONE'
	    attach_hair.description = ""
	    attach_hair.default_group_node_width = 140
	    
	
	    attach_hair.is_modifier = True
	
	    #attach_hair interface
	    #Socket Geometry
	    geometry_socket_9 = attach_hair.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_9.attribute_domain = 'POINT'
	
	    #Socket Geometry
	    geometry_socket_10 = attach_hair.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_10.attribute_domain = 'POINT'
	
	    #Socket Surface
	    surface_socket_2 = attach_hair.interface.new_socket(name = "Surface", in_out='INPUT', socket_type = 'NodeSocketObject')
	    surface_socket_2.attribute_domain = 'POINT'
	    surface_socket_2.description = "Surface Object to attach to (needs to have matching transforms)"
	
	    #Socket UV Map
	    uv_map_socket = attach_hair.interface.new_socket(name = "UV Map", in_out='INPUT', socket_type = 'NodeSocketString')
	    uv_map_socket.default_value = "UVMap"
	    uv_map_socket.subtype = 'NONE'
	    uv_map_socket.attribute_domain = 'POINT'
	    uv_map_socket.description = "Surface UV Map used to attach hair."
	
	    #Socket Blend along Curve
	    blend_along_curve_socket_1 = attach_hair.interface.new_socket(name = "Blend along Curve", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    blend_along_curve_socket_1.default_value = 0.05000000074505806
	    blend_along_curve_socket_1.min_value = 0.0
	    blend_along_curve_socket_1.max_value = 1.0
	    blend_along_curve_socket_1.subtype = 'FACTOR'
	    blend_along_curve_socket_1.attribute_domain = 'POINT'
	    blend_along_curve_socket_1.description = "Blend deformation along each curve from the root"
	
	
	    #initialize attach_hair nodes
	    #node Group Input
	    group_input_5 = attach_hair.nodes.new("NodeGroupInput")
	    group_input_5.name = "Group Input"
	    group_input_5.outputs[4].hide = True
	
	    #node Group Output
	    group_output_9 = attach_hair.nodes.new("NodeGroupOutput")
	    group_output_9.name = "Group Output"
	    group_output_9.is_active_output = True
	    group_output_9.inputs[1].hide = True
	
	    #node Group
	    group_4 = attach_hair.nodes.new("GeometryNodeGroup")
	    group_4.name = "Group"
	    group_4.node_tree = attach_hair_curves_to_surface
	    group_4.inputs[1].hide = True
	    group_4.inputs[4].hide = True
	    group_4.inputs[5].hide = True
	    group_4.inputs[6].hide = True
	    group_4.inputs[7].hide = True
	    group_4.outputs[1].hide = True
	    group_4.outputs[2].hide = True
	    #Socket_7
	    group_4.inputs[4].default_value = False
	    #Socket_8
	    group_4.inputs[5].default_value = True
	    #Socket_9
	    group_4.inputs[6].default_value = True
	    #Socket_10
	    group_4.inputs[7].default_value = False
	
	    #node Named Attribute
	    named_attribute_2 = attach_hair.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute_2.name = "Named Attribute"
	    named_attribute_2.hide = True
	    named_attribute_2.data_type = 'FLOAT_VECTOR'
	
	
	
	
	
	    #Set locations
	    group_input_5.location = (-340.0, 0.0)
	    group_output_9.location = (82.01471710205078, 24.076622009277344)
	    group_4.location = (-156.17784118652344, 22.037841796875)
	    named_attribute_2.location = (-333.9075622558594, -146.13522338867188)
	
	    #Set dimensions
	    group_input_5.width, group_input_5.height = 140.0, 100.0
	    group_output_9.width, group_output_9.height = 140.0, 100.0
	    group_4.width, group_4.height = 197.8995361328125, 100.0
	    named_attribute_2.width, named_attribute_2.height = 140.0, 100.0
	
	    #initialize attach_hair links
	    #group_4.Geometry -> group_output_9.Geometry
	    attach_hair.links.new(group_4.outputs[0], group_output_9.inputs[0])
	    #group_input_5.Geometry -> group_4.Geometry
	    attach_hair.links.new(group_input_5.outputs[0], group_4.inputs[0])
	    #named_attribute_2.Attribute -> group_4.Surface UV Map
	    attach_hair.links.new(named_attribute_2.outputs[0], group_4.inputs[3])
	    #group_input_5.Surface -> group_4.Surface
	    attach_hair.links.new(group_input_5.outputs[1], group_4.inputs[2])
	    #group_input_5.UV Map -> named_attribute_2.Name
	    attach_hair.links.new(group_input_5.outputs[2], named_attribute_2.inputs[0])
	    #group_input_5.Blend along Curve -> group_4.Blend along Curve
	    attach_hair.links.new(group_input_5.outputs[3], group_4.inputs[8])
	    return attach_hair
	
	attach_hair = attach_hair_node_group()
	
	#initialize dot_product_angle node group
	def dot_product_angle_node_group():
	    dot_product_angle = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Dot_Product_Angle")
	
	    dot_product_angle.color_tag = 'NONE'
	    dot_product_angle.description = ""
	    dot_product_angle.default_group_node_width = 140
	    
	
	
	    #dot_product_angle interface
	    #Socket Dot Product
	    dot_product_socket = dot_product_angle.interface.new_socket(name = "Dot Product", in_out='OUTPUT', socket_type = 'NodeSocketFloat')
	    dot_product_socket.default_value = 0.0
	    dot_product_socket.min_value = -3.4028234663852886e+38
	    dot_product_socket.max_value = 3.4028234663852886e+38
	    dot_product_socket.subtype = 'NONE'
	    dot_product_socket.attribute_domain = 'POINT'
	
	    #Socket Angle
	    angle_socket = dot_product_angle.interface.new_socket(name = "Angle", in_out='OUTPUT', socket_type = 'NodeSocketFloat')
	    angle_socket.default_value = 0.0
	    angle_socket.min_value = -3.4028234663852886e+38
	    angle_socket.max_value = 3.4028234663852886e+38
	    angle_socket.subtype = 'NONE'
	    angle_socket.attribute_domain = 'POINT'
	
	    #Socket Vector
	    vector_socket = dot_product_angle.interface.new_socket(name = "Vector", in_out='INPUT', socket_type = 'NodeSocketVector')
	    vector_socket.default_value = (0.0, 0.0, 0.0)
	    vector_socket.min_value = -10000.0
	    vector_socket.max_value = 10000.0
	    vector_socket.subtype = 'NONE'
	    vector_socket.attribute_domain = 'POINT'
	
	
	    #initialize dot_product_angle nodes
	    #node Group Output
	    group_output_10 = dot_product_angle.nodes.new("NodeGroupOutput")
	    group_output_10.name = "Group Output"
	    group_output_10.is_active_output = True
	    group_output_10.inputs[2].hide = True
	
	    #node Group Input
	    group_input_6 = dot_product_angle.nodes.new("NodeGroupInput")
	    group_input_6.name = "Group Input"
	    group_input_6.outputs[1].hide = True
	
	    #node Vector Math
	    vector_math_3 = dot_product_angle.nodes.new("ShaderNodeVectorMath")
	    vector_math_3.name = "Vector Math"
	    vector_math_3.hide = True
	    vector_math_3.operation = 'DOT_PRODUCT'
	    vector_math_3.inputs[0].hide = True
	    vector_math_3.inputs[2].hide = True
	    vector_math_3.inputs[3].hide = True
	    vector_math_3.outputs[0].hide = True
	    #Vector
	    vector_math_3.inputs[0].default_value = (0.0, 0.0, 1.0)
	
	    #node Vector Math.001
	    vector_math_001_3 = dot_product_angle.nodes.new("ShaderNodeVectorMath")
	    vector_math_001_3.name = "Vector Math.001"
	    vector_math_001_3.hide = True
	    vector_math_001_3.operation = 'NORMALIZE'
	
	    #node Math
	    math_2 = dot_product_angle.nodes.new("ShaderNodeMath")
	    math_2.name = "Math"
	    math_2.hide = True
	    math_2.operation = 'ARCCOSINE'
	    math_2.use_clamp = False
	
	
	
	
	
	    #Set locations
	    group_output_10.location = (162.45455932617188, -44.41817092895508)
	    group_input_6.location = (-200.0, 0.0)
	    vector_math_3.location = (-22.367019653320312, -62.39254379272461)
	    vector_math_001_3.location = (-22.180742263793945, -24.884807586669922)
	    math_2.location = (-21.054946899414062, -97.90547180175781)
	
	    #Set dimensions
	    group_output_10.width, group_output_10.height = 140.0, 100.0
	    group_input_6.width, group_input_6.height = 140.0, 100.0
	    vector_math_3.width, vector_math_3.height = 140.0, 100.0
	    vector_math_001_3.width, vector_math_001_3.height = 140.0, 100.0
	    math_2.width, math_2.height = 140.0, 100.0
	
	    #initialize dot_product_angle links
	    #vector_math_001_3.Vector -> vector_math_3.Vector
	    dot_product_angle.links.new(vector_math_001_3.outputs[0], vector_math_3.inputs[1])
	    #vector_math_3.Value -> math_2.Value
	    dot_product_angle.links.new(vector_math_3.outputs[1], math_2.inputs[0])
	    #group_input_6.Vector -> vector_math_001_3.Vector
	    dot_product_angle.links.new(group_input_6.outputs[0], vector_math_001_3.inputs[0])
	    #vector_math_3.Value -> group_output_10.Dot Product
	    dot_product_angle.links.new(vector_math_3.outputs[1], group_output_10.inputs[0])
	    #math_2.Value -> group_output_10.Angle
	    dot_product_angle.links.new(math_2.outputs[0], group_output_10.inputs[1])
	    return dot_product_angle
	
	dot_product_angle = dot_product_angle_node_group()
	
	#initialize trim_by_surface_norm node group
	def trim_by_surface_norm_node_group():
	    trim_by_surface_norm = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "TRIM_BY_SURFACE_NORM")
	
	    trim_by_surface_norm.color_tag = 'NONE'
	    trim_by_surface_norm.description = "Trim hair by surface normal. Hairs pointing up are trimmed less than hairs pointing down."
	    trim_by_surface_norm.default_group_node_width = 140
	    
	
	    trim_by_surface_norm.is_modifier = True
	
	    #trim_by_surface_norm interface
	    #Socket Geometry
	    geometry_socket_11 = trim_by_surface_norm.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_11.attribute_domain = 'POINT'
	    geometry_socket_11.description = "Trimmed Hair."
	
	    #Socket Geometry
	    geometry_socket_12 = trim_by_surface_norm.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_12.attribute_domain = 'POINT'
	    geometry_socket_12.description = "Hair Curve."
	
	    #Socket Surface
	    surface_socket_3 = trim_by_surface_norm.interface.new_socket(name = "Surface", in_out='INPUT', socket_type = 'NodeSocketObject')
	    surface_socket_3.attribute_domain = 'POINT'
	    surface_socket_3.description = "Surface Object to attach to (needs to have matching transforms)"
	
	    #Socket UV Map
	    uv_map_socket_1 = trim_by_surface_norm.interface.new_socket(name = "UV Map", in_out='INPUT', socket_type = 'NodeSocketString')
	    uv_map_socket_1.default_value = "UVMap"
	    uv_map_socket_1.subtype = 'NONE'
	    uv_map_socket_1.attribute_domain = 'POINT'
	    uv_map_socket_1.description = "Surface UV Map used to attach hair."
	
	    #Socket Blend along Curve
	    blend_along_curve_socket_2 = trim_by_surface_norm.interface.new_socket(name = "Blend along Curve", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    blend_along_curve_socket_2.default_value = 0.05000000074505806
	    blend_along_curve_socket_2.min_value = 0.0
	    blend_along_curve_socket_2.max_value = 1.0
	    blend_along_curve_socket_2.subtype = 'FACTOR'
	    blend_along_curve_socket_2.attribute_domain = 'POINT'
	    blend_along_curve_socket_2.description = "Blend deformation along each curve from the root"
	
	
	    #initialize trim_by_surface_norm nodes
	    #node Group Input
	    group_input_7 = trim_by_surface_norm.nodes.new("NodeGroupInput")
	    group_input_7.name = "Group Input"
	    group_input_7.outputs[4].hide = True
	
	    #node Group Output
	    group_output_11 = trim_by_surface_norm.nodes.new("NodeGroupOutput")
	    group_output_11.name = "Group Output"
	    group_output_11.is_active_output = True
	    group_output_11.inputs[1].hide = True
	
	    #node Group.001
	    group_001_4 = trim_by_surface_norm.nodes.new("GeometryNodeGroup")
	    group_001_4.name = "Group.001"
	    group_001_4.node_tree = attach_hair
	
	    #node Group.002
	    group_002_1 = trim_by_surface_norm.nodes.new("GeometryNodeGroup")
	    group_002_1.name = "Group.002"
	    group_002_1.node_tree = dot_product_angle
	    group_002_1.outputs[1].hide = True
	
	    #node Named Attribute.001
	    named_attribute_001_1 = trim_by_surface_norm.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute_001_1.name = "Named Attribute.001"
	    named_attribute_001_1.data_type = 'FLOAT_VECTOR'
	    #Name
	    named_attribute_001_1.inputs[0].default_value = "surface_normal"
	
	    #node Trim Curve.001
	    trim_curve_001 = trim_by_surface_norm.nodes.new("GeometryNodeTrimCurve")
	    trim_curve_001.name = "Trim Curve.001"
	    trim_curve_001.hide = True
	    trim_curve_001.mode = 'FACTOR'
	    trim_curve_001.inputs[1].hide = True
	    trim_curve_001.inputs[2].hide = True
	    trim_curve_001.inputs[4].hide = True
	    trim_curve_001.inputs[5].hide = True
	    #Selection
	    trim_curve_001.inputs[1].default_value = True
	    #Start
	    trim_curve_001.inputs[2].default_value = 0.0
	
	    #node Math
	    math_3 = trim_by_surface_norm.nodes.new("ShaderNodeMath")
	    math_3.name = "Math"
	    math_3.hide = True
	    math_3.operation = 'MAXIMUM'
	    math_3.use_clamp = False
	    math_3.inputs[1].hide = True
	    math_3.inputs[2].hide = True
	    #Value_001
	    math_3.inputs[1].default_value = 0.0
	
	    #node Trim by Surface Norm Bake
	    trim_by_surface_norm_bake = trim_by_surface_norm.nodes.new("GeometryNodeBake")
	    trim_by_surface_norm_bake.label = "Trim by Surface Norm Bake"
	    trim_by_surface_norm_bake.name = "Trim by Surface Norm Bake"
	    trim_by_surface_norm_bake.active_index = 0
	    trim_by_surface_norm_bake.bake_items.clear()
	    trim_by_surface_norm_bake.bake_items.new('GEOMETRY', "Geometry")
	    trim_by_surface_norm_bake.bake_items[0].attribute_domain = 'POINT'
	    trim_by_surface_norm_bake.inputs[1].hide = True
	    trim_by_surface_norm_bake.outputs[1].hide = True
	
	    #node Separate Components
	    separate_components_1 = trim_by_surface_norm.nodes.new("GeometryNodeSeparateComponents")
	    separate_components_1.name = "Separate Components"
	    separate_components_1.hide = True
	
	    #node Join Geometry
	    join_geometry_2 = trim_by_surface_norm.nodes.new("GeometryNodeJoinGeometry")
	    join_geometry_2.name = "Join Geometry"
	
	    #node Reroute
	    reroute_2 = trim_by_surface_norm.nodes.new("NodeReroute")
	    reroute_2.name = "Reroute"
	    reroute_2.socket_idname = "NodeSocketGeometry"
	    #node Reroute.001
	    reroute_001_2 = trim_by_surface_norm.nodes.new("NodeReroute")
	    reroute_001_2.name = "Reroute.001"
	    reroute_001_2.socket_idname = "NodeSocketGeometry"
	    #node Reroute.002
	    reroute_002_2 = trim_by_surface_norm.nodes.new("NodeReroute")
	    reroute_002_2.name = "Reroute.002"
	    reroute_002_2.socket_idname = "NodeSocketGeometry"
	    #node Reroute.003
	    reroute_003_2 = trim_by_surface_norm.nodes.new("NodeReroute")
	    reroute_003_2.name = "Reroute.003"
	    reroute_003_2.socket_idname = "NodeSocketGeometry"
	    #node Reroute.004
	    reroute_004_2 = trim_by_surface_norm.nodes.new("NodeReroute")
	    reroute_004_2.name = "Reroute.004"
	    reroute_004_2.socket_idname = "NodeSocketGeometry"
	    #node Reroute.005
	    reroute_005_1 = trim_by_surface_norm.nodes.new("NodeReroute")
	    reroute_005_1.name = "Reroute.005"
	    reroute_005_1.socket_idname = "NodeSocketGeometry"
	    #node Reroute.006
	    reroute_006_1 = trim_by_surface_norm.nodes.new("NodeReroute")
	    reroute_006_1.name = "Reroute.006"
	    reroute_006_1.socket_idname = "NodeSocketGeometry"
	    #node Reroute.007
	    reroute_007_1 = trim_by_surface_norm.nodes.new("NodeReroute")
	    reroute_007_1.name = "Reroute.007"
	    reroute_007_1.socket_idname = "NodeSocketGeometry"
	    #node Reroute.008
	    reroute_008_1 = trim_by_surface_norm.nodes.new("NodeReroute")
	    reroute_008_1.name = "Reroute.008"
	    reroute_008_1.socket_idname = "NodeSocketGeometry"
	    #node Reroute.009
	    reroute_009_1 = trim_by_surface_norm.nodes.new("NodeReroute")
	    reroute_009_1.name = "Reroute.009"
	    reroute_009_1.socket_idname = "NodeSocketGeometry"
	
	
	
	
	    #Set locations
	    group_input_7.location = (-340.0, 0.0)
	    group_output_11.location = (687.7236938476562, 42.9378776550293)
	    group_001_4.location = (-90.69696044921875, 47.75927734375)
	    group_002_1.location = (94.12109375, -74.90239715576172)
	    named_attribute_001_1.location = (92.64111328125, -180.02545166015625)
	    trim_curve_001.location = (97.08056640625, 17.172042846679688)
	    math_3.location = (95.600830078125, -23.970413208007812)
	    trim_by_surface_norm_bake.location = (508.05780029296875, 90.07472229003906)
	    separate_components_1.location = (-339.0893859863281, 38.30577087402344)
	    join_geometry_2.location = (337.3001708984375, 42.53268814086914)
	    reroute_2.location = (-92.1536865234375, 117.7878189086914)
	    reroute_001_2.location = (-94.90316772460938, 133.0744171142578)
	    reroute_002_2.location = (-95.732421875, 139.9412078857422)
	    reroute_003_2.location = (-92.1666488647461, 123.06124877929688)
	    reroute_004_2.location = (-93.45851135253906, 128.24288940429688)
	    reroute_005_1.location = (220.98974609375, 139.02525329589844)
	    reroute_006_1.location = (222.779052734375, 123.97970581054688)
	    reroute_007_1.location = (222.779052734375, 118.97404479980469)
	    reroute_008_1.location = (220.98974609375, 128.97938537597656)
	    reroute_009_1.location = (220.98974609375, 133.97508239746094)
	
	    #Set dimensions
	    group_input_7.width, group_input_7.height = 140.0, 100.0
	    group_output_11.width, group_output_11.height = 140.0, 100.0
	    group_001_4.width, group_001_4.height = 140.0, 100.0
	    group_002_1.width, group_002_1.height = 140.0, 100.0
	    named_attribute_001_1.width, named_attribute_001_1.height = 140.0, 100.0
	    trim_curve_001.width, trim_curve_001.height = 140.0, 100.0
	    math_3.width, math_3.height = 140.0, 100.0
	    trim_by_surface_norm_bake.width, trim_by_surface_norm_bake.height = 140.0, 100.0
	    separate_components_1.width, separate_components_1.height = 140.0, 100.0
	    join_geometry_2.width, join_geometry_2.height = 140.0, 100.0
	    reroute_2.width, reroute_2.height = 100.0, 100.0
	    reroute_001_2.width, reroute_001_2.height = 100.0, 100.0
	    reroute_002_2.width, reroute_002_2.height = 100.0, 100.0
	    reroute_003_2.width, reroute_003_2.height = 100.0, 100.0
	    reroute_004_2.width, reroute_004_2.height = 100.0, 100.0
	    reroute_005_1.width, reroute_005_1.height = 100.0, 100.0
	    reroute_006_1.width, reroute_006_1.height = 100.0, 100.0
	    reroute_007_1.width, reroute_007_1.height = 100.0, 100.0
	    reroute_008_1.width, reroute_008_1.height = 100.0, 100.0
	    reroute_009_1.width, reroute_009_1.height = 100.0, 100.0
	
	    #initialize trim_by_surface_norm links
	    #named_attribute_001_1.Attribute -> group_002_1.Vector
	    trim_by_surface_norm.links.new(named_attribute_001_1.outputs[0], group_002_1.inputs[0])
	    #math_3.Value -> trim_curve_001.End
	    trim_by_surface_norm.links.new(math_3.outputs[0], trim_curve_001.inputs[3])
	    #group_002_1.Dot Product -> math_3.Value
	    trim_by_surface_norm.links.new(group_002_1.outputs[0], math_3.inputs[0])
	    #group_input_7.Surface -> group_001_4.Surface
	    trim_by_surface_norm.links.new(group_input_7.outputs[1], group_001_4.inputs[1])
	    #group_input_7.UV Map -> group_001_4.UV Map
	    trim_by_surface_norm.links.new(group_input_7.outputs[2], group_001_4.inputs[2])
	    #group_input_7.Blend along Curve -> group_001_4.Blend along Curve
	    trim_by_surface_norm.links.new(group_input_7.outputs[3], group_001_4.inputs[3])
	    #group_001_4.Geometry -> trim_curve_001.Curve
	    trim_by_surface_norm.links.new(group_001_4.outputs[0], trim_curve_001.inputs[0])
	    #trim_by_surface_norm_bake.Geometry -> group_output_11.Geometry
	    trim_by_surface_norm.links.new(trim_by_surface_norm_bake.outputs[0], group_output_11.inputs[0])
	    #group_input_7.Geometry -> separate_components_1.Geometry
	    trim_by_surface_norm.links.new(group_input_7.outputs[0], separate_components_1.inputs[0])
	    #separate_components_1.Curve -> group_001_4.Geometry
	    trim_by_surface_norm.links.new(separate_components_1.outputs[1], group_001_4.inputs[0])
	    #reroute_007_1.Output -> join_geometry_2.Geometry
	    trim_by_surface_norm.links.new(reroute_007_1.outputs[0], join_geometry_2.inputs[0])
	    #separate_components_1.Instances -> reroute_2.Input
	    trim_by_surface_norm.links.new(separate_components_1.outputs[5], reroute_2.inputs[0])
	    #separate_components_1.Grease Pencil -> reroute_001_2.Input
	    trim_by_surface_norm.links.new(separate_components_1.outputs[2], reroute_001_2.inputs[0])
	    #separate_components_1.Mesh -> reroute_002_2.Input
	    trim_by_surface_norm.links.new(separate_components_1.outputs[0], reroute_002_2.inputs[0])
	    #separate_components_1.Volume -> reroute_003_2.Input
	    trim_by_surface_norm.links.new(separate_components_1.outputs[4], reroute_003_2.inputs[0])
	    #separate_components_1.Point Cloud -> reroute_004_2.Input
	    trim_by_surface_norm.links.new(separate_components_1.outputs[3], reroute_004_2.inputs[0])
	    #reroute_002_2.Output -> reroute_005_1.Input
	    trim_by_surface_norm.links.new(reroute_002_2.outputs[0], reroute_005_1.inputs[0])
	    #reroute_003_2.Output -> reroute_006_1.Input
	    trim_by_surface_norm.links.new(reroute_003_2.outputs[0], reroute_006_1.inputs[0])
	    #reroute_2.Output -> reroute_007_1.Input
	    trim_by_surface_norm.links.new(reroute_2.outputs[0], reroute_007_1.inputs[0])
	    #reroute_004_2.Output -> reroute_008_1.Input
	    trim_by_surface_norm.links.new(reroute_004_2.outputs[0], reroute_008_1.inputs[0])
	    #reroute_001_2.Output -> reroute_009_1.Input
	    trim_by_surface_norm.links.new(reroute_001_2.outputs[0], reroute_009_1.inputs[0])
	    #join_geometry_2.Geometry -> trim_by_surface_norm_bake.Geometry
	    trim_by_surface_norm.links.new(join_geometry_2.outputs[0], trim_by_surface_norm_bake.inputs[0])
	    #reroute_006_1.Output -> join_geometry_2.Geometry
	    trim_by_surface_norm.links.new(reroute_006_1.outputs[0], join_geometry_2.inputs[0])
	    #reroute_008_1.Output -> join_geometry_2.Geometry
	    trim_by_surface_norm.links.new(reroute_008_1.outputs[0], join_geometry_2.inputs[0])
	    #reroute_009_1.Output -> join_geometry_2.Geometry
	    trim_by_surface_norm.links.new(reroute_009_1.outputs[0], join_geometry_2.inputs[0])
	    #reroute_005_1.Output -> join_geometry_2.Geometry
	    trim_by_surface_norm.links.new(reroute_005_1.outputs[0], join_geometry_2.inputs[0])
	    #trim_curve_001.Curve -> join_geometry_2.Geometry
	    trim_by_surface_norm.links.new(trim_curve_001.outputs[0], join_geometry_2.inputs[0])
	    return trim_by_surface_norm
	
	trim_by_surface_norm = trim_by_surface_norm_node_group()
	
	#initialize hair_card node group
	def hair_card_node_group():
	    hair_card = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Hair_Card")
	
	    hair_card.color_tag = 'NONE'
	    hair_card.description = ""
	    hair_card.default_group_node_width = 140
	    
	
	    hair_card.is_modifier = True
	
	    #hair_card interface
	    #Socket Geometry
	    geometry_socket_13 = hair_card.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_13.attribute_domain = 'POINT'
	
	    #Socket Geometry
	    geometry_socket_14 = hair_card.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_14.attribute_domain = 'POINT'
	
	    #Socket Material
	    material_socket = hair_card.interface.new_socket(name = "Material", in_out='INPUT', socket_type = 'NodeSocketMaterial')
	    material_socket.attribute_domain = 'POINT'
	
	    #Socket Curve Radius
	    curve_radius_socket = hair_card.interface.new_socket(name = "Curve Radius", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    curve_radius_socket.default_value = 1.0
	    curve_radius_socket.min_value = 0.0
	    curve_radius_socket.max_value = 3.4028234663852886e+38
	    curve_radius_socket.subtype = 'DISTANCE'
	    curve_radius_socket.attribute_domain = 'POINT'
	    curve_radius_socket.hide_value = True
	    curve_radius_socket.hide_in_modifier = True
	
	    #Socket Resolution
	    resolution_socket_2 = hair_card.interface.new_socket(name = "Resolution", in_out='INPUT', socket_type = 'NodeSocketInt')
	    resolution_socket_2.default_value = 0
	    resolution_socket_2.min_value = 2
	    resolution_socket_2.max_value = 512
	    resolution_socket_2.subtype = 'NONE'
	    resolution_socket_2.attribute_domain = 'POINT'
	
	    #Socket Width
	    width_socket = hair_card.interface.new_socket(name = "Width", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    width_socket.default_value = 0.10000000149011612
	    width_socket.min_value = 0.0
	    width_socket.max_value = 3.4028234663852886e+38
	    width_socket.subtype = 'DISTANCE'
	    width_socket.attribute_domain = 'POINT'
	
	    #Socket Angle
	    angle_socket_1 = hair_card.interface.new_socket(name = "Angle", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    angle_socket_1.default_value = 45.0
	    angle_socket_1.min_value = -90.0
	    angle_socket_1.max_value = 90.0
	    angle_socket_1.subtype = 'ANGLE'
	    angle_socket_1.attribute_domain = 'POINT'
	
	
	    #initialize hair_card nodes
	    #node Group Input
	    group_input_8 = hair_card.nodes.new("NodeGroupInput")
	    group_input_8.name = "Group Input"
	    group_input_8.outputs[1].hide = True
	    group_input_8.outputs[2].hide = True
	    group_input_8.outputs[5].hide = True
	    group_input_8.outputs[6].hide = True
	
	    #node Group Output
	    group_output_12 = hair_card.nodes.new("NodeGroupOutput")
	    group_output_12.name = "Group Output"
	    group_output_12.is_active_output = True
	
	    #node Curve to Mesh
	    curve_to_mesh = hair_card.nodes.new("GeometryNodeCurveToMesh")
	    curve_to_mesh.name = "Curve to Mesh"
	    curve_to_mesh.hide = True
	    #Fill Caps
	    curve_to_mesh.inputs[2].default_value = False
	
	    #node Capture Attribute
	    capture_attribute_2 = hair_card.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_2.name = "Capture Attribute"
	    capture_attribute_2.hide = True
	    capture_attribute_2.active_index = 0
	    capture_attribute_2.capture_items.clear()
	    capture_attribute_2.capture_items.new('FLOAT', "Factor")
	    capture_attribute_2.capture_items["Factor"].data_type = 'FLOAT'
	    capture_attribute_2.domain = 'POINT'
	
	    #node Spline Parameter
	    spline_parameter_1 = hair_card.nodes.new("GeometryNodeSplineParameter")
	    spline_parameter_1.name = "Spline Parameter"
	    spline_parameter_1.hide = True
	
	    #node Combine XYZ
	    combine_xyz_2 = hair_card.nodes.new("ShaderNodeCombineXYZ")
	    combine_xyz_2.name = "Combine XYZ"
	    combine_xyz_2.hide = True
	    #Z
	    combine_xyz_2.inputs[2].default_value = 0.0
	
	    #node Store Named Attribute
	    store_named_attribute_2 = hair_card.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_2.name = "Store Named Attribute"
	    store_named_attribute_2.data_type = 'FLOAT2'
	    store_named_attribute_2.domain = 'CORNER'
	    #Selection
	    store_named_attribute_2.inputs[1].default_value = True
	    #Name
	    store_named_attribute_2.inputs[2].default_value = "hair_card_UV"
	
	    #node Set Material
	    set_material = hair_card.nodes.new("GeometryNodeSetMaterial")
	    set_material.name = "Set Material"
	    set_material.hide = True
	    #Selection
	    set_material.inputs[1].default_value = True
	
	    #node Capture Attribute.002
	    capture_attribute_002_2 = hair_card.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_002_2.name = "Capture Attribute.002"
	    capture_attribute_002_2.hide = True
	    capture_attribute_002_2.active_index = 0
	    capture_attribute_002_2.capture_items.clear()
	    capture_attribute_002_2.capture_items.new('FLOAT', "Factor")
	    capture_attribute_002_2.capture_items["Factor"].data_type = 'FLOAT'
	    capture_attribute_002_2.domain = 'POINT'
	
	    #node Reroute
	    reroute_3 = hair_card.nodes.new("NodeReroute")
	    reroute_3.name = "Reroute"
	    reroute_3.socket_idname = "NodeSocketFloat"
	    #node Group Input.001
	    group_input_001_4 = hair_card.nodes.new("NodeGroupInput")
	    group_input_001_4.name = "Group Input.001"
	    group_input_001_4.outputs[0].hide = True
	    group_input_001_4.outputs[2].hide = True
	    group_input_001_4.outputs[3].hide = True
	    group_input_001_4.outputs[4].hide = True
	    group_input_001_4.outputs[5].hide = True
	    group_input_001_4.outputs[6].hide = True
	
	    #node Reroute.001
	    reroute_001_3 = hair_card.nodes.new("NodeReroute")
	    reroute_001_3.name = "Reroute.001"
	    reroute_001_3.socket_idname = "NodeSocketFloatDistance"
	    #node Resample Curve
	    resample_curve = hair_card.nodes.new("GeometryNodeResampleCurve")
	    resample_curve.name = "Resample Curve"
	    resample_curve.hide = True
	    resample_curve.keep_last_segment = False
	    resample_curve.mode = 'COUNT'
	    #Selection
	    resample_curve.inputs[1].default_value = True
	
	    #node Switch
	    switch_2 = hair_card.nodes.new("GeometryNodeSwitch")
	    switch_2.name = "Switch"
	    switch_2.hide = True
	    switch_2.input_type = 'GEOMETRY'
	
	    #node Group Input.002
	    group_input_002_3 = hair_card.nodes.new("NodeGroupInput")
	    group_input_002_3.name = "Group Input.002"
	    group_input_002_3.outputs[0].hide = True
	    group_input_002_3.outputs[1].hide = True
	    group_input_002_3.outputs[2].hide = True
	    group_input_002_3.outputs[4].hide = True
	    group_input_002_3.outputs[5].hide = True
	    group_input_002_3.outputs[6].hide = True
	
	    #node Compare
	    compare_1 = hair_card.nodes.new("FunctionNodeCompare")
	    compare_1.name = "Compare"
	    compare_1.hide = True
	    compare_1.data_type = 'INT'
	    compare_1.mode = 'ELEMENT'
	    compare_1.operation = 'LESS_THAN'
	    #B_INT
	    compare_1.inputs[3].default_value = 2
	
	    #node Reroute.002
	    reroute_002_3 = hair_card.nodes.new("NodeReroute")
	    reroute_002_3.name = "Reroute.002"
	    reroute_002_3.socket_idname = "NodeSocketGeometry"
	    #node Group Input.003
	    group_input_003_3 = hair_card.nodes.new("NodeGroupInput")
	    group_input_003_3.name = "Group Input.003"
	    group_input_003_3.outputs[0].hide = True
	    group_input_003_3.outputs[1].hide = True
	    group_input_003_3.outputs[2].hide = True
	    group_input_003_3.outputs[3].hide = True
	    group_input_003_3.outputs[4].hide = True
	    group_input_003_3.outputs[6].hide = True
	
	    #node Points
	    points = hair_card.nodes.new("GeometryNodePoints")
	    points.name = "Points"
	    points.hide = True
	    #Count
	    points.inputs[0].default_value = 1
	    #Position
	    points.inputs[1].default_value = (0.0, 0.0, 0.0)
	    #Radius
	    points.inputs[2].default_value = 0.10000000149011612
	
	    #node Points.001
	    points_001 = hair_card.nodes.new("GeometryNodePoints")
	    points_001.name = "Points.001"
	    points_001.hide = True
	    #Count
	    points_001.inputs[0].default_value = 1
	    #Radius
	    points_001.inputs[2].default_value = 0.10000000149011612
	
	    #node Points.002
	    points_002 = hair_card.nodes.new("GeometryNodePoints")
	    points_002.name = "Points.002"
	    points_002.hide = True
	    #Count
	    points_002.inputs[0].default_value = 1
	    #Radius
	    points_002.inputs[2].default_value = 0.10000000149011612
	
	    #node Points to Curves
	    points_to_curves_1 = hair_card.nodes.new("GeometryNodePointsToCurves")
	    points_to_curves_1.name = "Points to Curves"
	    points_to_curves_1.hide = True
	    #Curve Group ID
	    points_to_curves_1.inputs[1].default_value = 0
	    #Weight
	    points_to_curves_1.inputs[2].default_value = 0.0
	
	    #node Join Geometry
	    join_geometry_3 = hair_card.nodes.new("GeometryNodeJoinGeometry")
	    join_geometry_3.name = "Join Geometry"
	    join_geometry_3.hide = True
	
	    #node Vector Rotate
	    vector_rotate_2 = hair_card.nodes.new("ShaderNodeVectorRotate")
	    vector_rotate_2.name = "Vector Rotate"
	    vector_rotate_2.hide = True
	    vector_rotate_2.invert = False
	    vector_rotate_2.rotation_type = 'AXIS_ANGLE'
	    #Center
	    vector_rotate_2.inputs[1].default_value = (0.0, 0.0, 0.0)
	    #Axis
	    vector_rotate_2.inputs[2].default_value = (0.0, 0.0, 1.0)
	
	    #node Combine XYZ.003
	    combine_xyz_003 = hair_card.nodes.new("ShaderNodeCombineXYZ")
	    combine_xyz_003.name = "Combine XYZ.003"
	    combine_xyz_003.hide = True
	    #Y
	    combine_xyz_003.inputs[1].default_value = 0.0
	    #Z
	    combine_xyz_003.inputs[2].default_value = 0.0
	
	    #node Vector Math
	    vector_math_4 = hair_card.nodes.new("ShaderNodeVectorMath")
	    vector_math_4.name = "Vector Math"
	    vector_math_4.hide = True
	    vector_math_4.operation = 'MULTIPLY'
	    #Vector_001
	    vector_math_4.inputs[1].default_value = (-1.0, 1.0, 1.0)
	
	    #node Set Curve Radius
	    set_curve_radius = hair_card.nodes.new("GeometryNodeSetCurveRadius")
	    set_curve_radius.name = "Set Curve Radius"
	    set_curve_radius.hide = True
	    #Selection
	    set_curve_radius.inputs[1].default_value = True
	
	    #node Group Input.004
	    group_input_004_2 = hair_card.nodes.new("NodeGroupInput")
	    group_input_004_2.name = "Group Input.004"
	    group_input_004_2.outputs[0].hide = True
	    group_input_004_2.outputs[1].hide = True
	    group_input_004_2.outputs[3].hide = True
	    group_input_004_2.outputs[4].hide = True
	    group_input_004_2.outputs[5].hide = True
	    group_input_004_2.outputs[6].hide = True
	
	    #node Reroute.003
	    reroute_003_3 = hair_card.nodes.new("NodeReroute")
	    reroute_003_3.name = "Reroute.003"
	    reroute_003_3.socket_idname = "NodeSocketFloatDistance"
	    #node Reroute.004
	    reroute_004_3 = hair_card.nodes.new("NodeReroute")
	    reroute_004_3.name = "Reroute.004"
	    reroute_004_3.socket_idname = "NodeSocketFloatDistance"
	
	
	
	
	    #Set locations
	    group_input_8.location = (-340.0, 0.0)
	    group_output_12.location = (1204.581787109375, 58.388336181640625)
	    curve_to_mesh.location = (717.3101196289062, -30.657630920410156)
	    capture_attribute_2.location = (532.3717651367188, -13.901289939880371)
	    spline_parameter_1.location = (329.8749084472656, -144.0863800048828)
	    combine_xyz_2.location = (717.11865234375, -93.34249114990234)
	    store_named_attribute_2.location = (883.1387329101562, 66.61811828613281)
	    set_material.location = (1044.3658447265625, 32.40200424194336)
	    capture_attribute_002_2.location = (534.5352783203125, -74.45401000976562)
	    reroute_3.location = (496.6486511230469, -141.76992797851562)
	    group_input_001_4.location = (1041.4315185546875, 1.5365350246429443)
	    reroute_001_3.location = (-187.22337341308594, -77.96863555908203)
	    resample_curve.location = (-5.360104560852051, -28.505603790283203)
	    switch_2.location = (-5.43592643737793, 6.486942291259766)
	    group_input_002_3.location = (-336.779052734375, 70.9764633178711)
	    compare_1.location = (-8.656487464904785, 41.045326232910156)
	    reroute_002_3.location = (-99.20211791992188, -32.54893493652344)
	    group_input_003_3.location = (-339.9999694824219, -103.2856674194336)
	    points.location = (156.70631408691406, -123.0439224243164)
	    points_001.location = (156.70632934570312, -81.72965240478516)
	    points_002.location = (158.99679565429688, -168.9486846923828)
	    points_to_curves_1.location = (321.6205749511719, -74.84392547607422)
	    join_geometry_3.location = (328.4919128417969, -106.97728729248047)
	    vector_rotate_2.location = (-8.371872901916504, -97.79617309570312)
	    combine_xyz_003.location = (-168.62094116210938, -79.79706573486328)
	    vector_math_4.location = (-6.081514358520508, -135.33193969726562)
	    set_curve_radius.location = (320.7674560546875, -1.0603179931640625)
	    group_input_004_2.location = (-334.8185729980469, 133.8203125)
	    reroute_003_3.location = (237.70924377441406, 97.4658203125)
	    reroute_004_3.location = (241.74778747558594, -21.909408569335938)
	
	    #Set dimensions
	    group_input_8.width, group_input_8.height = 140.0, 100.0
	    group_output_12.width, group_output_12.height = 140.0, 100.0
	    curve_to_mesh.width, curve_to_mesh.height = 140.0, 100.0
	    capture_attribute_2.width, capture_attribute_2.height = 140.0, 100.0
	    spline_parameter_1.width, spline_parameter_1.height = 140.0, 100.0
	    combine_xyz_2.width, combine_xyz_2.height = 140.0, 100.0
	    store_named_attribute_2.width, store_named_attribute_2.height = 140.0, 100.0
	    set_material.width, set_material.height = 140.0, 100.0
	    capture_attribute_002_2.width, capture_attribute_002_2.height = 140.0, 100.0
	    reroute_3.width, reroute_3.height = 100.0, 100.0
	    group_input_001_4.width, group_input_001_4.height = 140.0, 100.0
	    reroute_001_3.width, reroute_001_3.height = 100.0, 100.0
	    resample_curve.width, resample_curve.height = 140.0, 100.0
	    switch_2.width, switch_2.height = 140.0, 100.0
	    group_input_002_3.width, group_input_002_3.height = 140.0, 100.0
	    compare_1.width, compare_1.height = 140.0, 100.0
	    reroute_002_3.width, reroute_002_3.height = 100.0, 100.0
	    group_input_003_3.width, group_input_003_3.height = 140.0, 100.0
	    points.width, points.height = 140.0, 100.0
	    points_001.width, points_001.height = 140.0, 100.0
	    points_002.width, points_002.height = 140.0, 100.0
	    points_to_curves_1.width, points_to_curves_1.height = 140.0, 100.0
	    join_geometry_3.width, join_geometry_3.height = 140.0, 100.0
	    vector_rotate_2.width, vector_rotate_2.height = 140.0, 100.0
	    combine_xyz_003.width, combine_xyz_003.height = 140.0, 100.0
	    vector_math_4.width, vector_math_4.height = 140.0, 100.0
	    set_curve_radius.width, set_curve_radius.height = 140.0, 100.0
	    group_input_004_2.width, group_input_004_2.height = 140.0, 100.0
	    reroute_003_3.width, reroute_003_3.height = 100.0, 100.0
	    reroute_004_3.width, reroute_004_3.height = 100.0, 100.0
	
	    #initialize hair_card links
	    #set_material.Geometry -> group_output_12.Geometry
	    hair_card.links.new(set_material.outputs[0], group_output_12.inputs[0])
	    #capture_attribute_2.Geometry -> curve_to_mesh.Curve
	    hair_card.links.new(capture_attribute_2.outputs[0], curve_to_mesh.inputs[0])
	    #reroute_3.Output -> capture_attribute_2.Factor
	    hair_card.links.new(reroute_3.outputs[0], capture_attribute_2.inputs[1])
	    #capture_attribute_2.Factor -> combine_xyz_2.X
	    hair_card.links.new(capture_attribute_2.outputs[1], combine_xyz_2.inputs[0])
	    #curve_to_mesh.Mesh -> store_named_attribute_2.Geometry
	    hair_card.links.new(curve_to_mesh.outputs[0], store_named_attribute_2.inputs[0])
	    #combine_xyz_2.Vector -> store_named_attribute_2.Value
	    hair_card.links.new(combine_xyz_2.outputs[0], store_named_attribute_2.inputs[3])
	    #store_named_attribute_2.Geometry -> set_material.Geometry
	    hair_card.links.new(store_named_attribute_2.outputs[0], set_material.inputs[0])
	    #reroute_3.Output -> capture_attribute_002_2.Factor
	    hair_card.links.new(reroute_3.outputs[0], capture_attribute_002_2.inputs[1])
	    #capture_attribute_002_2.Factor -> combine_xyz_2.Y
	    hair_card.links.new(capture_attribute_002_2.outputs[1], combine_xyz_2.inputs[1])
	    #spline_parameter_1.Factor -> reroute_3.Input
	    hair_card.links.new(spline_parameter_1.outputs[0], reroute_3.inputs[0])
	    #group_input_001_4.Material -> set_material.Material
	    hair_card.links.new(group_input_001_4.outputs[1], set_material.inputs[2])
	    #group_input_8.Width -> reroute_001_3.Input
	    hair_card.links.new(group_input_8.outputs[4], reroute_001_3.inputs[0])
	    #reroute_002_3.Output -> resample_curve.Curve
	    hair_card.links.new(reroute_002_3.outputs[0], resample_curve.inputs[0])
	    #group_input_8.Resolution -> resample_curve.Count
	    hair_card.links.new(group_input_8.outputs[3], resample_curve.inputs[2])
	    #group_input_002_3.Resolution -> compare_1.A
	    hair_card.links.new(group_input_002_3.outputs[3], compare_1.inputs[2])
	    #compare_1.Result -> switch_2.Switch
	    hair_card.links.new(compare_1.outputs[0], switch_2.inputs[0])
	    #set_curve_radius.Curve -> capture_attribute_2.Geometry
	    hair_card.links.new(set_curve_radius.outputs[0], capture_attribute_2.inputs[0])
	    #group_input_8.Geometry -> reroute_002_3.Input
	    hair_card.links.new(group_input_8.outputs[0], reroute_002_3.inputs[0])
	    #reroute_002_3.Output -> switch_2.True
	    hair_card.links.new(reroute_002_3.outputs[0], switch_2.inputs[2])
	    #resample_curve.Curve -> switch_2.False
	    hair_card.links.new(resample_curve.outputs[0], switch_2.inputs[1])
	    #join_geometry_3.Geometry -> points_to_curves_1.Points
	    hair_card.links.new(join_geometry_3.outputs[0], points_to_curves_1.inputs[0])
	    #points_002.Points -> join_geometry_3.Geometry
	    hair_card.links.new(points_002.outputs[0], join_geometry_3.inputs[0])
	    #group_input_003_3.Angle -> vector_rotate_2.Angle
	    hair_card.links.new(group_input_003_3.outputs[5], vector_rotate_2.inputs[3])
	    #vector_rotate_2.Vector -> vector_math_4.Vector
	    hair_card.links.new(vector_rotate_2.outputs[0], vector_math_4.inputs[0])
	    #vector_rotate_2.Vector -> points_001.Position
	    hair_card.links.new(vector_rotate_2.outputs[0], points_001.inputs[1])
	    #vector_math_4.Vector -> points_002.Position
	    hair_card.links.new(vector_math_4.outputs[0], points_002.inputs[1])
	    #combine_xyz_003.Vector -> vector_rotate_2.Vector
	    hair_card.links.new(combine_xyz_003.outputs[0], vector_rotate_2.inputs[0])
	    #reroute_001_3.Output -> combine_xyz_003.X
	    hair_card.links.new(reroute_001_3.outputs[0], combine_xyz_003.inputs[0])
	    #points_to_curves_1.Curves -> capture_attribute_002_2.Geometry
	    hair_card.links.new(points_to_curves_1.outputs[0], capture_attribute_002_2.inputs[0])
	    #capture_attribute_002_2.Geometry -> curve_to_mesh.Profile Curve
	    hair_card.links.new(capture_attribute_002_2.outputs[0], curve_to_mesh.inputs[1])
	    #switch_2.Output -> set_curve_radius.Curve
	    hair_card.links.new(switch_2.outputs[0], set_curve_radius.inputs[0])
	    #reroute_004_3.Output -> set_curve_radius.Radius
	    hair_card.links.new(reroute_004_3.outputs[0], set_curve_radius.inputs[2])
	    #group_input_004_2.Curve Radius -> reroute_003_3.Input
	    hair_card.links.new(group_input_004_2.outputs[2], reroute_003_3.inputs[0])
	    #reroute_003_3.Output -> reroute_004_3.Input
	    hair_card.links.new(reroute_003_3.outputs[0], reroute_004_3.inputs[0])
	    #points.Points -> join_geometry_3.Geometry
	    hair_card.links.new(points.outputs[0], join_geometry_3.inputs[0])
	    #points_001.Points -> join_geometry_3.Geometry
	    hair_card.links.new(points_001.outputs[0], join_geometry_3.inputs[0])
	    return hair_card
	
	hair_card = hair_card_node_group()
	
	#initialize stylized_hair node group
	def stylized_hair_node_group():
	    stylized_hair = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Stylized_Hair")
	
	    stylized_hair.color_tag = 'NONE'
	    stylized_hair.description = ""
	    stylized_hair.default_group_node_width = 140
	    
	
	    stylized_hair.is_modifier = True
	
	    #stylized_hair interface
	    #Socket Geometry
	    geometry_socket_15 = stylized_hair.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_15.attribute_domain = 'POINT'
	
	    #Socket Geometry
	    geometry_socket_16 = stylized_hair.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_16.attribute_domain = 'POINT'
	
	    #Socket Profile
	    profile_socket = stylized_hair.interface.new_socket(name = "Profile", in_out='INPUT', socket_type = 'NodeSocketObject')
	    profile_socket.attribute_domain = 'POINT'
	
	    #Socket Material
	    material_socket_1 = stylized_hair.interface.new_socket(name = "Material", in_out='INPUT', socket_type = 'NodeSocketMaterial')
	    material_socket_1.attribute_domain = 'POINT'
	
	    #Socket Curve Radius
	    curve_radius_socket_1 = stylized_hair.interface.new_socket(name = "Curve Radius", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    curve_radius_socket_1.default_value = 1.0
	    curve_radius_socket_1.min_value = 0.0
	    curve_radius_socket_1.max_value = 3.4028234663852886e+38
	    curve_radius_socket_1.subtype = 'DISTANCE'
	    curve_radius_socket_1.attribute_domain = 'POINT'
	    curve_radius_socket_1.hide_value = True
	    curve_radius_socket_1.hide_in_modifier = True
	
	    #Socket Resolution
	    resolution_socket_3 = stylized_hair.interface.new_socket(name = "Resolution", in_out='INPUT', socket_type = 'NodeSocketInt')
	    resolution_socket_3.default_value = 10
	    resolution_socket_3.min_value = 1
	    resolution_socket_3.max_value = 100000
	    resolution_socket_3.subtype = 'NONE'
	    resolution_socket_3.attribute_domain = 'POINT'
	
	    #Socket Fill Caps
	    fill_caps_socket = stylized_hair.interface.new_socket(name = "Fill Caps", in_out='INPUT', socket_type = 'NodeSocketBool')
	    fill_caps_socket.default_value = True
	    fill_caps_socket.attribute_domain = 'POINT'
	
	    #Socket Translation
	    translation_socket = stylized_hair.interface.new_socket(name = "Translation", in_out='INPUT', socket_type = 'NodeSocketVector')
	    translation_socket.default_value = (0.0, 0.0, 0.0)
	    translation_socket.min_value = -3.4028234663852886e+38
	    translation_socket.max_value = 3.4028234663852886e+38
	    translation_socket.subtype = 'TRANSLATION'
	    translation_socket.attribute_domain = 'POINT'
	
	    #Socket Rotation
	    rotation_socket = stylized_hair.interface.new_socket(name = "Rotation", in_out='INPUT', socket_type = 'NodeSocketRotation')
	    rotation_socket.default_value = (0.0, 0.0, 0.0)
	    rotation_socket.attribute_domain = 'POINT'
	
	    #Socket Scale
	    scale_socket = stylized_hair.interface.new_socket(name = "Scale", in_out='INPUT', socket_type = 'NodeSocketVector')
	    scale_socket.default_value = (1.0, 1.0, 1.0)
	    scale_socket.min_value = -3.4028234663852886e+38
	    scale_socket.max_value = 3.4028234663852886e+38
	    scale_socket.subtype = 'XYZ'
	    scale_socket.attribute_domain = 'POINT'
	
	
	    #initialize stylized_hair nodes
	    #node Group Input
	    group_input_9 = stylized_hair.nodes.new("NodeGroupInput")
	    group_input_9.name = "Group Input"
	    group_input_9.outputs[2].hide = True
	    group_input_9.outputs[3].hide = True
	    group_input_9.outputs[4].hide = True
	    group_input_9.outputs[5].hide = True
	    group_input_9.outputs[6].hide = True
	    group_input_9.outputs[7].hide = True
	    group_input_9.outputs[8].hide = True
	    group_input_9.outputs[9].hide = True
	
	    #node Group Output
	    group_output_13 = stylized_hair.nodes.new("NodeGroupOutput")
	    group_output_13.name = "Group Output"
	    group_output_13.is_active_output = True
	
	    #node Curve to Mesh
	    curve_to_mesh_1 = stylized_hair.nodes.new("GeometryNodeCurveToMesh")
	    curve_to_mesh_1.name = "Curve to Mesh"
	    curve_to_mesh_1.hide = True
	
	    #node Capture Attribute
	    capture_attribute_3 = stylized_hair.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_3.name = "Capture Attribute"
	    capture_attribute_3.hide = True
	    capture_attribute_3.active_index = 0
	    capture_attribute_3.capture_items.clear()
	    capture_attribute_3.capture_items.new('FLOAT', "Factor")
	    capture_attribute_3.capture_items["Factor"].data_type = 'FLOAT'
	    capture_attribute_3.domain = 'POINT'
	
	    #node Spline Parameter
	    spline_parameter_2 = stylized_hair.nodes.new("GeometryNodeSplineParameter")
	    spline_parameter_2.name = "Spline Parameter"
	    spline_parameter_2.hide = True
	
	    #node Combine XYZ
	    combine_xyz_3 = stylized_hair.nodes.new("ShaderNodeCombineXYZ")
	    combine_xyz_3.name = "Combine XYZ"
	    combine_xyz_3.hide = True
	    #Z
	    combine_xyz_3.inputs[2].default_value = 0.0
	
	    #node Store Named Attribute
	    store_named_attribute_3 = stylized_hair.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_3.name = "Store Named Attribute"
	    store_named_attribute_3.data_type = 'FLOAT2'
	    store_named_attribute_3.domain = 'CORNER'
	    #Selection
	    store_named_attribute_3.inputs[1].default_value = True
	    #Name
	    store_named_attribute_3.inputs[2].default_value = "stylized_hair_UV"
	
	    #node Set Material
	    set_material_1 = stylized_hair.nodes.new("GeometryNodeSetMaterial")
	    set_material_1.name = "Set Material"
	    set_material_1.hide = True
	    #Selection
	    set_material_1.inputs[1].default_value = True
	
	    #node Capture Attribute.002
	    capture_attribute_002_3 = stylized_hair.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_002_3.name = "Capture Attribute.002"
	    capture_attribute_002_3.hide = True
	    capture_attribute_002_3.active_index = 0
	    capture_attribute_002_3.capture_items.clear()
	    capture_attribute_002_3.capture_items.new('FLOAT', "Factor")
	    capture_attribute_002_3.capture_items["Factor"].data_type = 'FLOAT'
	    capture_attribute_002_3.domain = 'POINT'
	
	    #node Reroute
	    reroute_4 = stylized_hair.nodes.new("NodeReroute")
	    reroute_4.name = "Reroute"
	    reroute_4.socket_idname = "NodeSocketFloat"
	    #node Group Input.001
	    group_input_001_5 = stylized_hair.nodes.new("NodeGroupInput")
	    group_input_001_5.name = "Group Input.001"
	    group_input_001_5.outputs[0].hide = True
	    group_input_001_5.outputs[1].hide = True
	    group_input_001_5.outputs[3].hide = True
	    group_input_001_5.outputs[4].hide = True
	    group_input_001_5.outputs[5].hide = True
	    group_input_001_5.outputs[6].hide = True
	    group_input_001_5.outputs[7].hide = True
	    group_input_001_5.outputs[8].hide = True
	    group_input_001_5.outputs[9].hide = True
	
	    #node Group Input.002
	    group_input_002_4 = stylized_hair.nodes.new("NodeGroupInput")
	    group_input_002_4.name = "Group Input.002"
	    group_input_002_4.outputs[0].hide = True
	    group_input_002_4.outputs[1].hide = True
	    group_input_002_4.outputs[2].hide = True
	    group_input_002_4.outputs[3].hide = True
	    group_input_002_4.outputs[4].hide = True
	    group_input_002_4.outputs[6].hide = True
	    group_input_002_4.outputs[7].hide = True
	    group_input_002_4.outputs[8].hide = True
	    group_input_002_4.outputs[9].hide = True
	
	    #node Object Info
	    object_info = stylized_hair.nodes.new("GeometryNodeObjectInfo")
	    object_info.name = "Object Info"
	    object_info.hide = True
	    object_info.transform_space = 'RELATIVE'
	    #As Instance
	    object_info.inputs[1].default_value = False
	
	    #node Transform Geometry
	    transform_geometry_1 = stylized_hair.nodes.new("GeometryNodeTransform")
	    transform_geometry_1.name = "Transform Geometry"
	    transform_geometry_1.hide = True
	    transform_geometry_1.mode = 'COMPONENTS'
	
	    #node Group Input.003
	    group_input_003_4 = stylized_hair.nodes.new("NodeGroupInput")
	    group_input_003_4.name = "Group Input.003"
	    group_input_003_4.outputs[0].hide = True
	    group_input_003_4.outputs[1].hide = True
	    group_input_003_4.outputs[2].hide = True
	    group_input_003_4.outputs[4].hide = True
	    group_input_003_4.outputs[5].hide = True
	    group_input_003_4.outputs[6].hide = True
	    group_input_003_4.outputs[7].hide = True
	    group_input_003_4.outputs[8].hide = True
	    group_input_003_4.outputs[9].hide = True
	
	    #node Group Input.004
	    group_input_004_3 = stylized_hair.nodes.new("NodeGroupInput")
	    group_input_004_3.name = "Group Input.004"
	    group_input_004_3.outputs[0].hide = True
	    group_input_004_3.outputs[1].hide = True
	    group_input_004_3.outputs[2].hide = True
	    group_input_004_3.outputs[3].hide = True
	    group_input_004_3.outputs[4].hide = True
	    group_input_004_3.outputs[5].hide = True
	    group_input_004_3.outputs[9].hide = True
	
	    #node Set Curve Radius
	    set_curve_radius_1 = stylized_hair.nodes.new("GeometryNodeSetCurveRadius")
	    set_curve_radius_1.name = "Set Curve Radius"
	    set_curve_radius_1.hide = True
	    #Selection
	    set_curve_radius_1.inputs[1].default_value = True
	
	    #node Reroute.001
	    reroute_001_4 = stylized_hair.nodes.new("NodeReroute")
	    reroute_001_4.name = "Reroute.001"
	    reroute_001_4.socket_idname = "NodeSocketGeometry"
	    #node Reroute.002
	    reroute_002_4 = stylized_hair.nodes.new("NodeReroute")
	    reroute_002_4.name = "Reroute.002"
	    reroute_002_4.socket_idname = "NodeSocketGeometry"
	    #node Resample Curve
	    resample_curve_1 = stylized_hair.nodes.new("GeometryNodeResampleCurve")
	    resample_curve_1.name = "Resample Curve"
	    resample_curve_1.hide = True
	    resample_curve_1.keep_last_segment = False
	    resample_curve_1.mode = 'COUNT'
	    #Selection
	    resample_curve_1.inputs[1].default_value = True
	
	    #node Switch
	    switch_3 = stylized_hair.nodes.new("GeometryNodeSwitch")
	    switch_3.name = "Switch"
	    switch_3.hide = True
	    switch_3.input_type = 'GEOMETRY'
	
	    #node Compare
	    compare_2 = stylized_hair.nodes.new("FunctionNodeCompare")
	    compare_2.name = "Compare"
	    compare_2.hide = True
	    compare_2.data_type = 'INT'
	    compare_2.mode = 'ELEMENT'
	    compare_2.operation = 'LESS_THAN'
	    #B_INT
	    compare_2.inputs[3].default_value = 2
	
	    #node Reroute.005
	    reroute_005_2 = stylized_hair.nodes.new("NodeReroute")
	    reroute_005_2.name = "Reroute.005"
	    reroute_005_2.socket_idname = "NodeSocketGeometry"
	    #node Group Input.005
	    group_input_005_3 = stylized_hair.nodes.new("NodeGroupInput")
	    group_input_005_3.name = "Group Input.005"
	    group_input_005_3.outputs[0].hide = True
	    group_input_005_3.outputs[1].hide = True
	    group_input_005_3.outputs[2].hide = True
	    group_input_005_3.outputs[3].hide = True
	    group_input_005_3.outputs[5].hide = True
	    group_input_005_3.outputs[6].hide = True
	    group_input_005_3.outputs[7].hide = True
	    group_input_005_3.outputs[8].hide = True
	    group_input_005_3.outputs[9].hide = True
	
	
	
	
	
	    #Set locations
	    group_input_9.location = (-340.0, -125.68765258789062)
	    group_output_13.location = (1046.0562744140625, -35.87745666503906)
	    curve_to_mesh_1.location = (546.74853515625, -108.79241180419922)
	    capture_attribute_3.location = (361.8101501464844, -82.63687133789062)
	    spline_parameter_2.location = (156.93017578125, -142.56178283691406)
	    combine_xyz_3.location = (546.5570068359375, -195.67379760742188)
	    store_named_attribute_3.location = (712.5771484375, -27.647676467895508)
	    set_material_1.location = (873.80419921875, -61.86378860473633)
	    capture_attribute_002_3.location = (363.9737243652344, -168.7198028564453)
	    reroute_4.location = (319.04217529296875, -141.52703857421875)
	    group_input_001_5.location = (870.8699951171875, -92.72925567626953)
	    group_input_002_4.location = (542.2694702148438, -137.2887725830078)
	    object_info.location = (-173.28436279296875, -181.30752563476562)
	    transform_geometry_1.location = (156.43304443359375, -206.8249053955078)
	    group_input_003_4.location = (-339.0907897949219, -62.643611907958984)
	    group_input_004_3.location = (-338.4869689941406, -211.2111053466797)
	    set_curve_radius_1.location = (158.24813842773438, -76.21592712402344)
	    reroute_001_4.location = (-164.16294860839844, -159.83448791503906)
	    reroute_002_4.location = (-164.90399169921875, -71.62743377685547)
	    resample_curve_1.location = (-36.965057373046875, -67.16246032714844)
	    switch_3.location = (-37.0408821105957, -32.16990661621094)
	    compare_2.location = (-40.26144027709961, 2.388460159301758)
	    reroute_005_2.location = (-130.80706787109375, -71.2057876586914)
	    group_input_005_3.location = (-338.4869689941406, -2.108567237854004)
	
	    #Set dimensions
	    group_input_9.width, group_input_9.height = 140.0, 100.0
	    group_output_13.width, group_output_13.height = 140.0, 100.0
	    curve_to_mesh_1.width, curve_to_mesh_1.height = 140.0, 100.0
	    capture_attribute_3.width, capture_attribute_3.height = 140.0, 100.0
	    spline_parameter_2.width, spline_parameter_2.height = 140.0, 100.0
	    combine_xyz_3.width, combine_xyz_3.height = 140.0, 100.0
	    store_named_attribute_3.width, store_named_attribute_3.height = 140.0, 100.0
	    set_material_1.width, set_material_1.height = 140.0, 100.0
	    capture_attribute_002_3.width, capture_attribute_002_3.height = 140.0, 100.0
	    reroute_4.width, reroute_4.height = 100.0, 100.0
	    group_input_001_5.width, group_input_001_5.height = 140.0, 100.0
	    group_input_002_4.width, group_input_002_4.height = 140.0, 100.0
	    object_info.width, object_info.height = 140.0, 100.0
	    transform_geometry_1.width, transform_geometry_1.height = 140.0, 100.0
	    group_input_003_4.width, group_input_003_4.height = 140.0, 100.0
	    group_input_004_3.width, group_input_004_3.height = 140.0, 100.0
	    set_curve_radius_1.width, set_curve_radius_1.height = 140.0, 100.0
	    reroute_001_4.width, reroute_001_4.height = 100.0, 100.0
	    reroute_002_4.width, reroute_002_4.height = 100.0, 100.0
	    resample_curve_1.width, resample_curve_1.height = 140.0, 100.0
	    switch_3.width, switch_3.height = 140.0, 100.0
	    compare_2.width, compare_2.height = 140.0, 100.0
	    reroute_005_2.width, reroute_005_2.height = 100.0, 100.0
	    group_input_005_3.width, group_input_005_3.height = 140.0, 100.0
	
	    #initialize stylized_hair links
	    #set_material_1.Geometry -> group_output_13.Geometry
	    stylized_hair.links.new(set_material_1.outputs[0], group_output_13.inputs[0])
	    #capture_attribute_3.Geometry -> curve_to_mesh_1.Curve
	    stylized_hair.links.new(capture_attribute_3.outputs[0], curve_to_mesh_1.inputs[0])
	    #set_curve_radius_1.Curve -> capture_attribute_3.Geometry
	    stylized_hair.links.new(set_curve_radius_1.outputs[0], capture_attribute_3.inputs[0])
	    #reroute_4.Output -> capture_attribute_3.Factor
	    stylized_hair.links.new(reroute_4.outputs[0], capture_attribute_3.inputs[1])
	    #capture_attribute_3.Factor -> combine_xyz_3.X
	    stylized_hair.links.new(capture_attribute_3.outputs[1], combine_xyz_3.inputs[0])
	    #curve_to_mesh_1.Mesh -> store_named_attribute_3.Geometry
	    stylized_hair.links.new(curve_to_mesh_1.outputs[0], store_named_attribute_3.inputs[0])
	    #combine_xyz_3.Vector -> store_named_attribute_3.Value
	    stylized_hair.links.new(combine_xyz_3.outputs[0], store_named_attribute_3.inputs[3])
	    #store_named_attribute_3.Geometry -> set_material_1.Geometry
	    stylized_hair.links.new(store_named_attribute_3.outputs[0], set_material_1.inputs[0])
	    #reroute_4.Output -> capture_attribute_002_3.Factor
	    stylized_hair.links.new(reroute_4.outputs[0], capture_attribute_002_3.inputs[1])
	    #capture_attribute_002_3.Factor -> combine_xyz_3.Y
	    stylized_hair.links.new(capture_attribute_002_3.outputs[1], combine_xyz_3.inputs[1])
	    #capture_attribute_002_3.Geometry -> curve_to_mesh_1.Profile Curve
	    stylized_hair.links.new(capture_attribute_002_3.outputs[0], curve_to_mesh_1.inputs[1])
	    #spline_parameter_2.Factor -> reroute_4.Input
	    stylized_hair.links.new(spline_parameter_2.outputs[0], reroute_4.inputs[0])
	    #group_input_001_5.Material -> set_material_1.Material
	    stylized_hair.links.new(group_input_001_5.outputs[2], set_material_1.inputs[2])
	    #group_input_002_4.Fill Caps -> curve_to_mesh_1.Fill Caps
	    stylized_hair.links.new(group_input_002_4.outputs[5], curve_to_mesh_1.inputs[2])
	    #group_input_9.Profile -> object_info.Object
	    stylized_hair.links.new(group_input_9.outputs[1], object_info.inputs[0])
	    #object_info.Geometry -> transform_geometry_1.Geometry
	    stylized_hair.links.new(object_info.outputs[4], transform_geometry_1.inputs[0])
	    #transform_geometry_1.Geometry -> capture_attribute_002_3.Geometry
	    stylized_hair.links.new(transform_geometry_1.outputs[0], capture_attribute_002_3.inputs[0])
	    #group_input_003_4.Curve Radius -> set_curve_radius_1.Radius
	    stylized_hair.links.new(group_input_003_4.outputs[3], set_curve_radius_1.inputs[2])
	    #group_input_004_3.Translation -> transform_geometry_1.Translation
	    stylized_hair.links.new(group_input_004_3.outputs[6], transform_geometry_1.inputs[1])
	    #group_input_004_3.Rotation -> transform_geometry_1.Rotation
	    stylized_hair.links.new(group_input_004_3.outputs[7], transform_geometry_1.inputs[2])
	    #group_input_004_3.Scale -> transform_geometry_1.Scale
	    stylized_hair.links.new(group_input_004_3.outputs[8], transform_geometry_1.inputs[3])
	    #group_input_9.Geometry -> reroute_001_4.Input
	    stylized_hair.links.new(group_input_9.outputs[0], reroute_001_4.inputs[0])
	    #reroute_001_4.Output -> reroute_002_4.Input
	    stylized_hair.links.new(reroute_001_4.outputs[0], reroute_002_4.inputs[0])
	    #reroute_005_2.Output -> resample_curve_1.Curve
	    stylized_hair.links.new(reroute_005_2.outputs[0], resample_curve_1.inputs[0])
	    #compare_2.Result -> switch_3.Switch
	    stylized_hair.links.new(compare_2.outputs[0], switch_3.inputs[0])
	    #reroute_005_2.Output -> switch_3.True
	    stylized_hair.links.new(reroute_005_2.outputs[0], switch_3.inputs[2])
	    #resample_curve_1.Curve -> switch_3.False
	    stylized_hair.links.new(resample_curve_1.outputs[0], switch_3.inputs[1])
	    #group_input_005_3.Resolution -> resample_curve_1.Count
	    stylized_hair.links.new(group_input_005_3.outputs[4], resample_curve_1.inputs[2])
	    #group_input_005_3.Resolution -> compare_2.A
	    stylized_hair.links.new(group_input_005_3.outputs[4], compare_2.inputs[2])
	    #switch_3.Output -> set_curve_radius_1.Curve
	    stylized_hair.links.new(switch_3.outputs[0], set_curve_radius_1.inputs[0])
	    #reroute_002_4.Output -> reroute_005_2.Input
	    stylized_hair.links.new(reroute_002_4.outputs[0], reroute_005_2.inputs[0])
	    return stylized_hair
	
	stylized_hair = stylized_hair_node_group()
	
	#initialize tube_mesh node group
	def tube_mesh_node_group():
	    tube_mesh = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Tube_Mesh")
	
	    tube_mesh.color_tag = 'NONE'
	    tube_mesh.description = ""
	    tube_mesh.default_group_node_width = 140
	    
	
	    tube_mesh.is_modifier = True
	
	    #tube_mesh interface
	    #Socket Geometry
	    geometry_socket_17 = tube_mesh.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_17.attribute_domain = 'POINT'
	
	    #Socket Geometry
	    geometry_socket_18 = tube_mesh.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_18.attribute_domain = 'POINT'
	
	    #Socket Material
	    material_socket_2 = tube_mesh.interface.new_socket(name = "Material", in_out='INPUT', socket_type = 'NodeSocketMaterial')
	    material_socket_2.attribute_domain = 'POINT'
	
	    #Socket Curve Radius
	    curve_radius_socket_2 = tube_mesh.interface.new_socket(name = "Curve Radius", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    curve_radius_socket_2.default_value = 1.0
	    curve_radius_socket_2.min_value = 0.0
	    curve_radius_socket_2.max_value = 3.4028234663852886e+38
	    curve_radius_socket_2.subtype = 'DISTANCE'
	    curve_radius_socket_2.attribute_domain = 'POINT'
	    curve_radius_socket_2.hide_value = True
	    curve_radius_socket_2.hide_in_modifier = True
	
	    #Socket Resolution
	    resolution_socket_4 = tube_mesh.interface.new_socket(name = "Resolution", in_out='INPUT', socket_type = 'NodeSocketInt')
	    resolution_socket_4.default_value = 32
	    resolution_socket_4.min_value = 3
	    resolution_socket_4.max_value = 512
	    resolution_socket_4.subtype = 'NONE'
	    resolution_socket_4.attribute_domain = 'POINT'
	
	    #Socket Width
	    width_socket_1 = tube_mesh.interface.new_socket(name = "Width", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    width_socket_1.default_value = 0.10000000149011612
	    width_socket_1.min_value = 0.0
	    width_socket_1.max_value = 3.4028234663852886e+38
	    width_socket_1.subtype = 'DISTANCE'
	    width_socket_1.attribute_domain = 'POINT'
	
	    #Socket Fill Caps
	    fill_caps_socket_1 = tube_mesh.interface.new_socket(name = "Fill Caps", in_out='INPUT', socket_type = 'NodeSocketBool')
	    fill_caps_socket_1.default_value = True
	    fill_caps_socket_1.attribute_domain = 'POINT'
	
	
	    #initialize tube_mesh nodes
	    #node Group Input
	    group_input_10 = tube_mesh.nodes.new("NodeGroupInput")
	    group_input_10.name = "Group Input"
	    group_input_10.outputs[1].hide = True
	    group_input_10.outputs[2].hide = True
	    group_input_10.outputs[5].hide = True
	    group_input_10.outputs[6].hide = True
	
	    #node Group Output
	    group_output_14 = tube_mesh.nodes.new("NodeGroupOutput")
	    group_output_14.name = "Group Output"
	    group_output_14.is_active_output = True
	
	    #node Curve to Mesh
	    curve_to_mesh_2 = tube_mesh.nodes.new("GeometryNodeCurveToMesh")
	    curve_to_mesh_2.name = "Curve to Mesh"
	    curve_to_mesh_2.hide = True
	
	    #node Capture Attribute
	    capture_attribute_4 = tube_mesh.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_4.name = "Capture Attribute"
	    capture_attribute_4.hide = True
	    capture_attribute_4.active_index = 0
	    capture_attribute_4.capture_items.clear()
	    capture_attribute_4.capture_items.new('FLOAT', "Factor")
	    capture_attribute_4.capture_items["Factor"].data_type = 'FLOAT'
	    capture_attribute_4.domain = 'POINT'
	
	    #node Spline Parameter
	    spline_parameter_3 = tube_mesh.nodes.new("GeometryNodeSplineParameter")
	    spline_parameter_3.name = "Spline Parameter"
	    spline_parameter_3.hide = True
	
	    #node Combine XYZ
	    combine_xyz_4 = tube_mesh.nodes.new("ShaderNodeCombineXYZ")
	    combine_xyz_4.name = "Combine XYZ"
	    combine_xyz_4.hide = True
	    #Z
	    combine_xyz_4.inputs[2].default_value = 0.0
	
	    #node Store Named Attribute
	    store_named_attribute_4 = tube_mesh.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_4.name = "Store Named Attribute"
	    store_named_attribute_4.data_type = 'FLOAT2'
	    store_named_attribute_4.domain = 'CORNER'
	    #Selection
	    store_named_attribute_4.inputs[1].default_value = True
	    #Name
	    store_named_attribute_4.inputs[2].default_value = "tube_mesh_UV"
	
	    #node Set Material
	    set_material_2 = tube_mesh.nodes.new("GeometryNodeSetMaterial")
	    set_material_2.name = "Set Material"
	    set_material_2.hide = True
	    #Selection
	    set_material_2.inputs[1].default_value = True
	
	    #node Curve Circle
	    curve_circle = tube_mesh.nodes.new("GeometryNodeCurvePrimitiveCircle")
	    curve_circle.name = "Curve Circle"
	    curve_circle.hide = True
	    curve_circle.mode = 'RADIUS'
	    #Resolution
	    curve_circle.inputs[0].default_value = 16
	
	    #node Capture Attribute.002
	    capture_attribute_002_4 = tube_mesh.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_002_4.name = "Capture Attribute.002"
	    capture_attribute_002_4.hide = True
	    capture_attribute_002_4.active_index = 0
	    capture_attribute_002_4.capture_items.clear()
	    capture_attribute_002_4.capture_items.new('FLOAT', "Factor")
	    capture_attribute_002_4.capture_items["Factor"].data_type = 'FLOAT'
	    capture_attribute_002_4.domain = 'POINT'
	
	    #node Reroute
	    reroute_5 = tube_mesh.nodes.new("NodeReroute")
	    reroute_5.name = "Reroute"
	    reroute_5.socket_idname = "NodeSocketFloat"
	    #node Group Input.001
	    group_input_001_6 = tube_mesh.nodes.new("NodeGroupInput")
	    group_input_001_6.name = "Group Input.001"
	    group_input_001_6.outputs[0].hide = True
	    group_input_001_6.outputs[2].hide = True
	    group_input_001_6.outputs[3].hide = True
	    group_input_001_6.outputs[4].hide = True
	    group_input_001_6.outputs[5].hide = True
	    group_input_001_6.outputs[6].hide = True
	
	    #node Group Input.002
	    group_input_002_5 = tube_mesh.nodes.new("NodeGroupInput")
	    group_input_002_5.name = "Group Input.002"
	    group_input_002_5.outputs[0].hide = True
	    group_input_002_5.outputs[1].hide = True
	    group_input_002_5.outputs[2].hide = True
	    group_input_002_5.outputs[3].hide = True
	    group_input_002_5.outputs[4].hide = True
	    group_input_002_5.outputs[6].hide = True
	
	    #node Set Curve Radius
	    set_curve_radius_2 = tube_mesh.nodes.new("GeometryNodeSetCurveRadius")
	    set_curve_radius_2.name = "Set Curve Radius"
	    set_curve_radius_2.hide = True
	    #Selection
	    set_curve_radius_2.inputs[1].default_value = True
	
	    #node Group Input.003
	    group_input_003_5 = tube_mesh.nodes.new("NodeGroupInput")
	    group_input_003_5.name = "Group Input.003"
	    group_input_003_5.outputs[0].hide = True
	    group_input_003_5.outputs[1].hide = True
	    group_input_003_5.outputs[3].hide = True
	    group_input_003_5.outputs[4].hide = True
	    group_input_003_5.outputs[5].hide = True
	    group_input_003_5.outputs[6].hide = True
	
	    #node Resample Curve
	    resample_curve_2 = tube_mesh.nodes.new("GeometryNodeResampleCurve")
	    resample_curve_2.name = "Resample Curve"
	    resample_curve_2.hide = True
	    resample_curve_2.keep_last_segment = False
	    resample_curve_2.mode = 'COUNT'
	    #Selection
	    resample_curve_2.inputs[1].default_value = True
	
	    #node Switch
	    switch_4 = tube_mesh.nodes.new("GeometryNodeSwitch")
	    switch_4.name = "Switch"
	    switch_4.hide = True
	    switch_4.input_type = 'GEOMETRY'
	
	    #node Compare
	    compare_3 = tube_mesh.nodes.new("FunctionNodeCompare")
	    compare_3.name = "Compare"
	    compare_3.hide = True
	    compare_3.data_type = 'INT'
	    compare_3.mode = 'ELEMENT'
	    compare_3.operation = 'LESS_THAN'
	    #B_INT
	    compare_3.inputs[3].default_value = 2
	
	    #node Reroute.003
	    reroute_003_4 = tube_mesh.nodes.new("NodeReroute")
	    reroute_003_4.name = "Reroute.003"
	    reroute_003_4.socket_idname = "NodeSocketGeometry"
	    #node Group Input.004
	    group_input_004_4 = tube_mesh.nodes.new("NodeGroupInput")
	    group_input_004_4.name = "Group Input.004"
	    group_input_004_4.outputs[0].hide = True
	    group_input_004_4.outputs[1].hide = True
	    group_input_004_4.outputs[2].hide = True
	    group_input_004_4.outputs[4].hide = True
	    group_input_004_4.outputs[5].hide = True
	    group_input_004_4.outputs[6].hide = True
	
	    #node Reroute.006
	    reroute_006_2 = tube_mesh.nodes.new("NodeReroute")
	    reroute_006_2.name = "Reroute.006"
	    reroute_006_2.socket_idname = "NodeSocketFloatDistance"
	    #node Reroute.007
	    reroute_007_2 = tube_mesh.nodes.new("NodeReroute")
	    reroute_007_2.name = "Reroute.007"
	    reroute_007_2.socket_idname = "NodeSocketFloatDistance"
	    #node Reroute.008
	    reroute_008_2 = tube_mesh.nodes.new("NodeReroute")
	    reroute_008_2.name = "Reroute.008"
	    reroute_008_2.socket_idname = "NodeSocketInt"
	    #node Reroute.009
	    reroute_009_2 = tube_mesh.nodes.new("NodeReroute")
	    reroute_009_2.name = "Reroute.009"
	    reroute_009_2.socket_idname = "NodeSocketInt"
	
	
	
	
	    #Set locations
	    group_input_10.location = (-340.0, 0.0)
	    group_output_14.location = (953.9598388671875, 58.388336181640625)
	    curve_to_mesh_2.location = (466.6881408691406, -14.526612281799316)
	    capture_attribute_4.location = (281.749755859375, -33.53998565673828)
	    spline_parameter_3.location = (84.9455795288086, -92.41136169433594)
	    combine_xyz_4.location = (466.4966735839844, -101.40799713134766)
	    store_named_attribute_4.location = (632.5167846679688, 66.61811828613281)
	    set_material_2.location = (793.743896484375, 32.40200424194336)
	    curve_circle.location = (87.1727523803711, -56.81591033935547)
	    capture_attribute_002_4.location = (283.9133605957031, -74.45401000976562)
	    reroute_5.location = (247.05758666992188, -91.37664031982422)
	    group_input_001_6.location = (790.8096313476562, 1.5365350246429443)
	    group_input_002_5.location = (462.2091369628906, -43.022979736328125)
	    set_curve_radius_2.location = (93.72252655029297, -22.188615798950195)
	    group_input_003_5.location = (-339.80987548828125, 120.61366271972656)
	    resample_curve_2.location = (-105.32349395751953, -15.050445556640625)
	    switch_4.location = (-105.3993148803711, 19.942108154296875)
	    compare_3.location = (-108.61988830566406, 54.5004768371582)
	    reroute_003_4.location = (-169.31845092773438, -19.093738555908203)
	    group_input_004_4.location = (-340.0, 59.733726501464844)
	    reroute_006_2.location = (58.51203918457031, -44.47895431518555)
	    reroute_007_2.location = (51.51875686645508, 91.57743072509766)
	    reroute_008_2.location = (-135.7594451904297, -35.677268981933594)
	    reroute_009_2.location = (-140.79913330078125, 26.496713638305664)
	
	    #Set dimensions
	    group_input_10.width, group_input_10.height = 140.0, 100.0
	    group_output_14.width, group_output_14.height = 140.0, 100.0
	    curve_to_mesh_2.width, curve_to_mesh_2.height = 140.0, 100.0
	    capture_attribute_4.width, capture_attribute_4.height = 140.0, 100.0
	    spline_parameter_3.width, spline_parameter_3.height = 140.0, 100.0
	    combine_xyz_4.width, combine_xyz_4.height = 140.0, 100.0
	    store_named_attribute_4.width, store_named_attribute_4.height = 140.0, 100.0
	    set_material_2.width, set_material_2.height = 140.0, 100.0
	    curve_circle.width, curve_circle.height = 140.0, 100.0
	    capture_attribute_002_4.width, capture_attribute_002_4.height = 140.0, 100.0
	    reroute_5.width, reroute_5.height = 100.0, 100.0
	    group_input_001_6.width, group_input_001_6.height = 140.0, 100.0
	    group_input_002_5.width, group_input_002_5.height = 140.0, 100.0
	    set_curve_radius_2.width, set_curve_radius_2.height = 140.0, 100.0
	    group_input_003_5.width, group_input_003_5.height = 140.0, 100.0
	    resample_curve_2.width, resample_curve_2.height = 140.0, 100.0
	    switch_4.width, switch_4.height = 140.0, 100.0
	    compare_3.width, compare_3.height = 140.0, 100.0
	    reroute_003_4.width, reroute_003_4.height = 100.0, 100.0
	    group_input_004_4.width, group_input_004_4.height = 140.0, 100.0
	    reroute_006_2.width, reroute_006_2.height = 100.0, 100.0
	    reroute_007_2.width, reroute_007_2.height = 100.0, 100.0
	    reroute_008_2.width, reroute_008_2.height = 100.0, 100.0
	    reroute_009_2.width, reroute_009_2.height = 100.0, 100.0
	
	    #initialize tube_mesh links
	    #set_material_2.Geometry -> group_output_14.Geometry
	    tube_mesh.links.new(set_material_2.outputs[0], group_output_14.inputs[0])
	    #capture_attribute_4.Geometry -> curve_to_mesh_2.Curve
	    tube_mesh.links.new(capture_attribute_4.outputs[0], curve_to_mesh_2.inputs[0])
	    #set_curve_radius_2.Curve -> capture_attribute_4.Geometry
	    tube_mesh.links.new(set_curve_radius_2.outputs[0], capture_attribute_4.inputs[0])
	    #reroute_5.Output -> capture_attribute_4.Factor
	    tube_mesh.links.new(reroute_5.outputs[0], capture_attribute_4.inputs[1])
	    #capture_attribute_4.Factor -> combine_xyz_4.X
	    tube_mesh.links.new(capture_attribute_4.outputs[1], combine_xyz_4.inputs[0])
	    #curve_to_mesh_2.Mesh -> store_named_attribute_4.Geometry
	    tube_mesh.links.new(curve_to_mesh_2.outputs[0], store_named_attribute_4.inputs[0])
	    #combine_xyz_4.Vector -> store_named_attribute_4.Value
	    tube_mesh.links.new(combine_xyz_4.outputs[0], store_named_attribute_4.inputs[3])
	    #store_named_attribute_4.Geometry -> set_material_2.Geometry
	    tube_mesh.links.new(store_named_attribute_4.outputs[0], set_material_2.inputs[0])
	    #curve_circle.Curve -> capture_attribute_002_4.Geometry
	    tube_mesh.links.new(curve_circle.outputs[0], capture_attribute_002_4.inputs[0])
	    #reroute_5.Output -> capture_attribute_002_4.Factor
	    tube_mesh.links.new(reroute_5.outputs[0], capture_attribute_002_4.inputs[1])
	    #capture_attribute_002_4.Factor -> combine_xyz_4.Y
	    tube_mesh.links.new(capture_attribute_002_4.outputs[1], combine_xyz_4.inputs[1])
	    #capture_attribute_002_4.Geometry -> curve_to_mesh_2.Profile Curve
	    tube_mesh.links.new(capture_attribute_002_4.outputs[0], curve_to_mesh_2.inputs[1])
	    #group_input_10.Width -> curve_circle.Radius
	    tube_mesh.links.new(group_input_10.outputs[4], curve_circle.inputs[4])
	    #spline_parameter_3.Factor -> reroute_5.Input
	    tube_mesh.links.new(spline_parameter_3.outputs[0], reroute_5.inputs[0])
	    #group_input_001_6.Material -> set_material_2.Material
	    tube_mesh.links.new(group_input_001_6.outputs[1], set_material_2.inputs[2])
	    #group_input_002_5.Fill Caps -> curve_to_mesh_2.Fill Caps
	    tube_mesh.links.new(group_input_002_5.outputs[5], curve_to_mesh_2.inputs[2])
	    #reroute_006_2.Output -> set_curve_radius_2.Radius
	    tube_mesh.links.new(reroute_006_2.outputs[0], set_curve_radius_2.inputs[2])
	    #reroute_003_4.Output -> resample_curve_2.Curve
	    tube_mesh.links.new(reroute_003_4.outputs[0], resample_curve_2.inputs[0])
	    #compare_3.Result -> switch_4.Switch
	    tube_mesh.links.new(compare_3.outputs[0], switch_4.inputs[0])
	    #reroute_003_4.Output -> switch_4.True
	    tube_mesh.links.new(reroute_003_4.outputs[0], switch_4.inputs[2])
	    #resample_curve_2.Curve -> switch_4.False
	    tube_mesh.links.new(resample_curve_2.outputs[0], switch_4.inputs[1])
	    #reroute_008_2.Output -> resample_curve_2.Count
	    tube_mesh.links.new(reroute_008_2.outputs[0], resample_curve_2.inputs[2])
	    #group_input_10.Geometry -> reroute_003_4.Input
	    tube_mesh.links.new(group_input_10.outputs[0], reroute_003_4.inputs[0])
	    #reroute_007_2.Output -> reroute_006_2.Input
	    tube_mesh.links.new(reroute_007_2.outputs[0], reroute_006_2.inputs[0])
	    #group_input_003_5.Curve Radius -> reroute_007_2.Input
	    tube_mesh.links.new(group_input_003_5.outputs[2], reroute_007_2.inputs[0])
	    #reroute_009_2.Output -> reroute_008_2.Input
	    tube_mesh.links.new(reroute_009_2.outputs[0], reroute_008_2.inputs[0])
	    #group_input_004_4.Resolution -> reroute_009_2.Input
	    tube_mesh.links.new(group_input_004_4.outputs[3], reroute_009_2.inputs[0])
	    #reroute_009_2.Output -> compare_3.A
	    tube_mesh.links.new(reroute_009_2.outputs[0], compare_3.inputs[2])
	    #switch_4.Output -> set_curve_radius_2.Curve
	    tube_mesh.links.new(switch_4.outputs[0], set_curve_radius_2.inputs[0])
	    return tube_mesh
	
	tube_mesh = tube_mesh_node_group()
	
	#initialize tube_ribbon node group
	def tube_ribbon_node_group():
	    tube_ribbon = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Tube_Ribbon")
	
	    tube_ribbon.color_tag = 'NONE'
	    tube_ribbon.description = ""
	    tube_ribbon.default_group_node_width = 140
	    
	
	    tube_ribbon.is_modifier = True
	
	    #tube_ribbon interface
	    #Socket Geometry
	    geometry_socket_19 = tube_ribbon.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_19.attribute_domain = 'POINT'
	
	    #Socket Geometry
	    geometry_socket_20 = tube_ribbon.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_20.attribute_domain = 'POINT'
	
	    #Socket Material
	    material_socket_3 = tube_ribbon.interface.new_socket(name = "Material", in_out='INPUT', socket_type = 'NodeSocketMaterial')
	    material_socket_3.attribute_domain = 'POINT'
	
	    #Socket Curve Radius
	    curve_radius_socket_3 = tube_ribbon.interface.new_socket(name = "Curve Radius", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    curve_radius_socket_3.default_value = 1.0
	    curve_radius_socket_3.min_value = 0.0
	    curve_radius_socket_3.max_value = 3.4028234663852886e+38
	    curve_radius_socket_3.subtype = 'DISTANCE'
	    curve_radius_socket_3.attribute_domain = 'POINT'
	    curve_radius_socket_3.hide_value = True
	    curve_radius_socket_3.hide_in_modifier = True
	
	    #Socket Ribbon Count
	    ribbon_count_socket = tube_ribbon.interface.new_socket(name = "Ribbon Count", in_out='INPUT', socket_type = 'NodeSocketInt')
	    ribbon_count_socket.default_value = 8
	    ribbon_count_socket.min_value = 1
	    ribbon_count_socket.max_value = 180
	    ribbon_count_socket.subtype = 'NONE'
	    ribbon_count_socket.attribute_domain = 'POINT'
	
	    #Socket Resolution
	    resolution_socket_5 = tube_ribbon.interface.new_socket(name = "Resolution", in_out='INPUT', socket_type = 'NodeSocketInt')
	    resolution_socket_5.default_value = 0
	    resolution_socket_5.min_value = 2
	    resolution_socket_5.max_value = 512
	    resolution_socket_5.subtype = 'NONE'
	    resolution_socket_5.attribute_domain = 'POINT'
	
	    #Socket Width
	    width_socket_2 = tube_ribbon.interface.new_socket(name = "Width", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    width_socket_2.default_value = 0.10000000149011612
	    width_socket_2.min_value = 0.0
	    width_socket_2.max_value = 3.4028234663852886e+38
	    width_socket_2.subtype = 'DISTANCE'
	    width_socket_2.attribute_domain = 'POINT'
	
	
	    #initialize tube_ribbon nodes
	    #node Group Input
	    group_input_11 = tube_ribbon.nodes.new("NodeGroupInput")
	    group_input_11.name = "Group Input"
	    group_input_11.outputs[1].hide = True
	    group_input_11.outputs[2].hide = True
	    group_input_11.outputs[3].hide = True
	    group_input_11.outputs[6].hide = True
	
	    #node Group Output
	    group_output_15 = tube_ribbon.nodes.new("NodeGroupOutput")
	    group_output_15.name = "Group Output"
	    group_output_15.is_active_output = True
	
	    #node Curve to Mesh
	    curve_to_mesh_3 = tube_ribbon.nodes.new("GeometryNodeCurveToMesh")
	    curve_to_mesh_3.name = "Curve to Mesh"
	    curve_to_mesh_3.hide = True
	    #Fill Caps
	    curve_to_mesh_3.inputs[2].default_value = True
	
	    #node Capture Attribute
	    capture_attribute_5 = tube_ribbon.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_5.name = "Capture Attribute"
	    capture_attribute_5.hide = True
	    capture_attribute_5.active_index = 0
	    capture_attribute_5.capture_items.clear()
	    capture_attribute_5.capture_items.new('FLOAT', "Factor")
	    capture_attribute_5.capture_items["Factor"].data_type = 'FLOAT'
	    capture_attribute_5.domain = 'POINT'
	
	    #node Spline Parameter
	    spline_parameter_4 = tube_ribbon.nodes.new("GeometryNodeSplineParameter")
	    spline_parameter_4.name = "Spline Parameter"
	    spline_parameter_4.hide = True
	
	    #node Combine XYZ
	    combine_xyz_5 = tube_ribbon.nodes.new("ShaderNodeCombineXYZ")
	    combine_xyz_5.name = "Combine XYZ"
	    combine_xyz_5.hide = True
	    #Z
	    combine_xyz_5.inputs[2].default_value = 0.0
	
	    #node Store Named Attribute
	    store_named_attribute_5 = tube_ribbon.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_5.name = "Store Named Attribute"
	    store_named_attribute_5.data_type = 'FLOAT2'
	    store_named_attribute_5.domain = 'CORNER'
	    #Selection
	    store_named_attribute_5.inputs[1].default_value = True
	    #Name
	    store_named_attribute_5.inputs[2].default_value = "ribbon_mesh_UV"
	
	    #node Set Material
	    set_material_3 = tube_ribbon.nodes.new("GeometryNodeSetMaterial")
	    set_material_3.name = "Set Material"
	    set_material_3.hide = True
	    #Selection
	    set_material_3.inputs[1].default_value = True
	
	    #node Capture Attribute.002
	    capture_attribute_002_5 = tube_ribbon.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_002_5.name = "Capture Attribute.002"
	    capture_attribute_002_5.hide = True
	    capture_attribute_002_5.active_index = 0
	    capture_attribute_002_5.capture_items.clear()
	    capture_attribute_002_5.capture_items.new('FLOAT', "Factor")
	    capture_attribute_002_5.capture_items["Factor"].data_type = 'FLOAT'
	    capture_attribute_002_5.domain = 'POINT'
	
	    #node Reroute
	    reroute_6 = tube_ribbon.nodes.new("NodeReroute")
	    reroute_6.name = "Reroute"
	    reroute_6.socket_idname = "NodeSocketFloat"
	    #node Group Input.001
	    group_input_001_7 = tube_ribbon.nodes.new("NodeGroupInput")
	    group_input_001_7.name = "Group Input.001"
	    group_input_001_7.outputs[0].hide = True
	    group_input_001_7.outputs[2].hide = True
	    group_input_001_7.outputs[3].hide = True
	    group_input_001_7.outputs[4].hide = True
	    group_input_001_7.outputs[5].hide = True
	    group_input_001_7.outputs[6].hide = True
	
	    #node Curve Line
	    curve_line = tube_ribbon.nodes.new("GeometryNodeCurvePrimitiveLine")
	    curve_line.name = "Curve Line"
	    curve_line.hide = True
	    curve_line.mode = 'POINTS'
	
	    #node Combine XYZ.001
	    combine_xyz_001_1 = tube_ribbon.nodes.new("ShaderNodeCombineXYZ")
	    combine_xyz_001_1.name = "Combine XYZ.001"
	    combine_xyz_001_1.hide = True
	    #Y
	    combine_xyz_001_1.inputs[1].default_value = 0.0
	    #Z
	    combine_xyz_001_1.inputs[2].default_value = 0.0
	
	    #node Math.001
	    math_001_1 = tube_ribbon.nodes.new("ShaderNodeMath")
	    math_001_1.name = "Math.001"
	    math_001_1.hide = True
	    math_001_1.operation = 'MULTIPLY'
	    math_001_1.use_clamp = False
	    #Value_001
	    math_001_1.inputs[1].default_value = -1.0
	
	    #node Combine XYZ.002
	    combine_xyz_002_2 = tube_ribbon.nodes.new("ShaderNodeCombineXYZ")
	    combine_xyz_002_2.name = "Combine XYZ.002"
	    combine_xyz_002_2.hide = True
	    #Y
	    combine_xyz_002_2.inputs[1].default_value = 0.0
	    #Z
	    combine_xyz_002_2.inputs[2].default_value = 0.0
	
	    #node Reroute.001
	    reroute_001_5 = tube_ribbon.nodes.new("NodeReroute")
	    reroute_001_5.name = "Reroute.001"
	    reroute_001_5.socket_idname = "NodeSocketFloatDistance"
	    #node Resample Curve
	    resample_curve_3 = tube_ribbon.nodes.new("GeometryNodeResampleCurve")
	    resample_curve_3.name = "Resample Curve"
	    resample_curve_3.hide = True
	    resample_curve_3.keep_last_segment = False
	    resample_curve_3.mode = 'COUNT'
	    #Selection
	    resample_curve_3.inputs[1].default_value = True
	
	    #node Switch
	    switch_5 = tube_ribbon.nodes.new("GeometryNodeSwitch")
	    switch_5.name = "Switch"
	    switch_5.hide = True
	    switch_5.input_type = 'GEOMETRY'
	
	    #node Group Input.002
	    group_input_002_6 = tube_ribbon.nodes.new("NodeGroupInput")
	    group_input_002_6.name = "Group Input.002"
	    group_input_002_6.outputs[0].hide = True
	    group_input_002_6.outputs[1].hide = True
	    group_input_002_6.outputs[2].hide = True
	    group_input_002_6.outputs[3].hide = True
	    group_input_002_6.outputs[5].hide = True
	    group_input_002_6.outputs[6].hide = True
	
	    #node Compare
	    compare_4 = tube_ribbon.nodes.new("FunctionNodeCompare")
	    compare_4.name = "Compare"
	    compare_4.hide = True
	    compare_4.data_type = 'INT'
	    compare_4.mode = 'ELEMENT'
	    compare_4.operation = 'LESS_THAN'
	    #B_INT
	    compare_4.inputs[3].default_value = 2
	
	    #node Reroute.002
	    reroute_002_5 = tube_ribbon.nodes.new("NodeReroute")
	    reroute_002_5.name = "Reroute.002"
	    reroute_002_5.socket_idname = "NodeSocketGeometry"
	    #node Frame
	    frame_3 = tube_ribbon.nodes.new("NodeFrame")
	    frame_3.name = "Frame"
	    frame_3.label_size = 20
	    frame_3.shrink = True
	
	    #node Join Geometry
	    join_geometry_4 = tube_ribbon.nodes.new("GeometryNodeJoinGeometry")
	    join_geometry_4.name = "Join Geometry"
	
	    #node Set Curve Tilt
	    set_curve_tilt = tube_ribbon.nodes.new("GeometryNodeSetCurveTilt")
	    set_curve_tilt.name = "Set Curve Tilt"
	    #Selection
	    set_curve_tilt.inputs[1].default_value = True
	
	    #node Repeat Input
	    repeat_input = tube_ribbon.nodes.new("GeometryNodeRepeatInput")
	    repeat_input.name = "Repeat Input"
	    #node Repeat Output
	    repeat_output = tube_ribbon.nodes.new("GeometryNodeRepeatOutput")
	    repeat_output.name = "Repeat Output"
	    repeat_output.active_index = 1
	    repeat_output.inspection_index = 0
	    repeat_output.repeat_items.clear()
	    # Create item "Geometry"
	    repeat_output.repeat_items.new('GEOMETRY', "Geometry")
	    # Create item "Index"
	    repeat_output.repeat_items.new('INT', "Index")
	
	    #node Math.002
	    math_002_1 = tube_ribbon.nodes.new("ShaderNodeMath")
	    math_002_1.name = "Math.002"
	    math_002_1.hide = True
	    math_002_1.operation = 'DIVIDE'
	    math_002_1.use_clamp = False
	    #Value
	    math_002_1.inputs[0].default_value = 180.0
	
	    #node Group Input.003
	    group_input_003_6 = tube_ribbon.nodes.new("NodeGroupInput")
	    group_input_003_6.name = "Group Input.003"
	    group_input_003_6.outputs[0].hide = True
	    group_input_003_6.outputs[1].hide = True
	    group_input_003_6.outputs[2].hide = True
	    group_input_003_6.outputs[4].hide = True
	    group_input_003_6.outputs[5].hide = True
	    group_input_003_6.outputs[6].hide = True
	
	    #node Group Input.004
	    group_input_004_5 = tube_ribbon.nodes.new("NodeGroupInput")
	    group_input_004_5.name = "Group Input.004"
	    group_input_004_5.outputs[0].hide = True
	    group_input_004_5.outputs[1].hide = True
	    group_input_004_5.outputs[2].hide = True
	    group_input_004_5.outputs[4].hide = True
	    group_input_004_5.outputs[5].hide = True
	    group_input_004_5.outputs[6].hide = True
	
	    #node Math.003
	    math_003_1 = tube_ribbon.nodes.new("ShaderNodeMath")
	    math_003_1.name = "Math.003"
	    math_003_1.hide = True
	    math_003_1.operation = 'ADD'
	    math_003_1.use_clamp = False
	    #Value_001
	    math_003_1.inputs[1].default_value = 1.0
	
	    #node Math.004
	    math_004_1 = tube_ribbon.nodes.new("ShaderNodeMath")
	    math_004_1.name = "Math.004"
	    math_004_1.hide = True
	    math_004_1.operation = 'MULTIPLY'
	    math_004_1.use_clamp = False
	
	    #node Reroute.003
	    reroute_003_5 = tube_ribbon.nodes.new("NodeReroute")
	    reroute_003_5.name = "Reroute.003"
	    reroute_003_5.socket_idname = "NodeSocketInt"
	    #node Curve Tilt
	    curve_tilt = tube_ribbon.nodes.new("GeometryNodeInputCurveTilt")
	    curve_tilt.name = "Curve Tilt"
	    curve_tilt.hide = True
	
	    #node Math.005
	    math_005_1 = tube_ribbon.nodes.new("ShaderNodeMath")
	    math_005_1.name = "Math.005"
	    math_005_1.hide = True
	    math_005_1.operation = 'ADD'
	    math_005_1.use_clamp = False
	
	    #node Set Curve Radius
	    set_curve_radius_3 = tube_ribbon.nodes.new("GeometryNodeSetCurveRadius")
	    set_curve_radius_3.name = "Set Curve Radius"
	    set_curve_radius_3.hide = True
	    #Selection
	    set_curve_radius_3.inputs[1].default_value = True
	
	    #node Group Input.005
	    group_input_005_4 = tube_ribbon.nodes.new("NodeGroupInput")
	    group_input_005_4.name = "Group Input.005"
	    group_input_005_4.outputs[0].hide = True
	    group_input_005_4.outputs[1].hide = True
	    group_input_005_4.outputs[3].hide = True
	    group_input_005_4.outputs[4].hide = True
	    group_input_005_4.outputs[5].hide = True
	    group_input_005_4.outputs[6].hide = True
	
	    #node Reroute.004
	    reroute_004_4 = tube_ribbon.nodes.new("NodeReroute")
	    reroute_004_4.name = "Reroute.004"
	    reroute_004_4.socket_idname = "NodeSocketFloatDistance"
	    #node Reroute.005
	    reroute_005_3 = tube_ribbon.nodes.new("NodeReroute")
	    reroute_005_3.name = "Reroute.005"
	    reroute_005_3.socket_idname = "NodeSocketFloatDistance"
	
	    #Process zone input Repeat Input
	    repeat_input.pair_with_output(repeat_output)
	    #Item_2
	    repeat_input.inputs[2].default_value = 0
	
	
	
	
	    #Set parents
	    group_input_11.parent = frame_3
	    curve_to_mesh_3.parent = frame_3
	    capture_attribute_5.parent = frame_3
	    spline_parameter_4.parent = frame_3
	    combine_xyz_5.parent = frame_3
	    store_named_attribute_5.parent = frame_3
	    set_material_3.parent = frame_3
	    capture_attribute_002_5.parent = frame_3
	    reroute_6.parent = frame_3
	    group_input_001_7.parent = frame_3
	    curve_line.parent = frame_3
	    combine_xyz_001_1.parent = frame_3
	    math_001_1.parent = frame_3
	    combine_xyz_002_2.parent = frame_3
	    reroute_001_5.parent = frame_3
	    resample_curve_3.parent = frame_3
	    switch_5.parent = frame_3
	    group_input_002_6.parent = frame_3
	    compare_4.parent = frame_3
	    reroute_002_5.parent = frame_3
	    set_curve_tilt.parent = frame_3
	    math_004_1.parent = frame_3
	    math_005_1.parent = frame_3
	    set_curve_radius_3.parent = frame_3
	    group_input_005_4.parent = frame_3
	    reroute_004_4.parent = frame_3
	    reroute_005_3.parent = frame_3
	
	    #Set locations
	    group_input_11.location = (46.5567626953125, -187.68907165527344)
	    group_output_15.location = (1687.6083984375, 27.941242218017578)
	    curve_to_mesh_3.location = (937.7008666992188, -218.34669494628906)
	    capture_attribute_5.location = (764.834716796875, -223.1929168701172)
	    spline_parameter_4.location = (408.7358093261719, -288.16595458984375)
	    combine_xyz_5.location = (937.5093383789062, -281.03155517578125)
	    store_named_attribute_5.location = (1093.46923828125, -121.07095336914062)
	    set_material_3.location = (1254.6962890625, -155.2870635986328)
	    capture_attribute_002_5.location = (766.9982299804688, -262.14312744140625)
	    reroute_6.location = (566.0176391601562, -285.51812744140625)
	    group_input_001_7.location = (1251.76220703125, -186.1525421142578)
	    curve_line.location = (409.7470397949219, -252.2234649658203)
	    combine_xyz_001_1.location = (242.35899353027344, -260.64910888671875)
	    math_001_1.location = (247.1505889892578, -332.52447509765625)
	    combine_xyz_002_2.location = (245.62991333007812, -296.69708251953125)
	    reroute_001_5.location = (199.33338928222656, -265.65771484375)
	    resample_curve_3.location = (380.4243469238281, -216.19468688964844)
	    switch_5.location = (380.3485412597656, -181.20213317871094)
	    group_input_002_6.location = (375.72821044921875, -86.50663757324219)
	    compare_4.location = (377.1279602050781, -146.6437530517578)
	    reroute_002_5.location = (333.6315612792969, -213.35231018066406)
	    frame_3.location = (-58.76470947265625, -48.17646789550781)
	    join_geometry_4.location = (1331.0086669921875, 47.14059066772461)
	    set_curve_tilt.location = (192.23997497558594, -54.01100158691406)
	    repeat_input.location = (-184.79876708984375, 46.944000244140625)
	    repeat_output.location = (1511.4083251953125, 27.655336380004883)
	    math_002_1.location = (-195.4779510498047, -161.6897735595703)
	    group_input_003_6.location = (-346.3707580566406, 47.1754035949707)
	    group_input_004_5.location = (-353.25665283203125, -145.0489044189453)
	    math_003_1.location = (1134.1580810546875, -24.601409912109375)
	    math_004_1.location = (30.277496337890625, -106.62132263183594)
	    reroute_003_5.location = (-25.963211059570312, -31.35608673095703)
	    curve_tilt.location = (-197.5312957763672, -198.6190185546875)
	    math_005_1.location = (31.753875732421875, -145.03323364257812)
	    set_curve_radius_3.location = (591.83837890625, -194.33396911621094)
	    group_input_005_4.location = (377.0597229003906, -29.650436401367188)
	    reroute_004_4.location = (563.5545654296875, -215.4977264404297)
	    reroute_005_3.location = (561.7288208007812, -64.61457824707031)
	
	    #Set dimensions
	    group_input_11.width, group_input_11.height = 140.0, 100.0
	    group_output_15.width, group_output_15.height = 140.0, 100.0
	    curve_to_mesh_3.width, curve_to_mesh_3.height = 140.0, 100.0
	    capture_attribute_5.width, capture_attribute_5.height = 140.0, 100.0
	    spline_parameter_4.width, spline_parameter_4.height = 140.0, 100.0
	    combine_xyz_5.width, combine_xyz_5.height = 140.0, 100.0
	    store_named_attribute_5.width, store_named_attribute_5.height = 140.0, 100.0
	    set_material_3.width, set_material_3.height = 140.0, 100.0
	    capture_attribute_002_5.width, capture_attribute_002_5.height = 140.0, 100.0
	    reroute_6.width, reroute_6.height = 100.0, 100.0
	    group_input_001_7.width, group_input_001_7.height = 140.0, 100.0
	    curve_line.width, curve_line.height = 140.0, 100.0
	    combine_xyz_001_1.width, combine_xyz_001_1.height = 140.0, 100.0
	    math_001_1.width, math_001_1.height = 140.0, 100.0
	    combine_xyz_002_2.width, combine_xyz_002_2.height = 140.0, 100.0
	    reroute_001_5.width, reroute_001_5.height = 100.0, 100.0
	    resample_curve_3.width, resample_curve_3.height = 140.0, 100.0
	    switch_5.width, switch_5.height = 140.0, 100.0
	    group_input_002_6.width, group_input_002_6.height = 140.0, 100.0
	    compare_4.width, compare_4.height = 140.0, 100.0
	    reroute_002_5.width, reroute_002_5.height = 100.0, 100.0
	    frame_3.width, frame_3.height = 1424.3529052734375, 388.32354736328125
	    join_geometry_4.width, join_geometry_4.height = 140.0, 100.0
	    set_curve_tilt.width, set_curve_tilt.height = 140.0, 100.0
	    repeat_input.width, repeat_input.height = 140.0, 100.0
	    repeat_output.width, repeat_output.height = 140.0, 100.0
	    math_002_1.width, math_002_1.height = 140.0, 100.0
	    group_input_003_6.width, group_input_003_6.height = 140.0, 100.0
	    group_input_004_5.width, group_input_004_5.height = 140.0, 100.0
	    math_003_1.width, math_003_1.height = 140.0, 100.0
	    math_004_1.width, math_004_1.height = 140.0, 100.0
	    reroute_003_5.width, reroute_003_5.height = 100.0, 100.0
	    curve_tilt.width, curve_tilt.height = 140.0, 100.0
	    math_005_1.width, math_005_1.height = 140.0, 100.0
	    set_curve_radius_3.width, set_curve_radius_3.height = 140.0, 100.0
	    group_input_005_4.width, group_input_005_4.height = 140.0, 100.0
	    reroute_004_4.width, reroute_004_4.height = 100.0, 100.0
	    reroute_005_3.width, reroute_005_3.height = 100.0, 100.0
	
	    #initialize tube_ribbon links
	    #capture_attribute_5.Geometry -> curve_to_mesh_3.Curve
	    tube_ribbon.links.new(capture_attribute_5.outputs[0], curve_to_mesh_3.inputs[0])
	    #reroute_6.Output -> capture_attribute_5.Factor
	    tube_ribbon.links.new(reroute_6.outputs[0], capture_attribute_5.inputs[1])
	    #capture_attribute_5.Factor -> combine_xyz_5.X
	    tube_ribbon.links.new(capture_attribute_5.outputs[1], combine_xyz_5.inputs[0])
	    #curve_to_mesh_3.Mesh -> store_named_attribute_5.Geometry
	    tube_ribbon.links.new(curve_to_mesh_3.outputs[0], store_named_attribute_5.inputs[0])
	    #combine_xyz_5.Vector -> store_named_attribute_5.Value
	    tube_ribbon.links.new(combine_xyz_5.outputs[0], store_named_attribute_5.inputs[3])
	    #store_named_attribute_5.Geometry -> set_material_3.Geometry
	    tube_ribbon.links.new(store_named_attribute_5.outputs[0], set_material_3.inputs[0])
	    #reroute_6.Output -> capture_attribute_002_5.Factor
	    tube_ribbon.links.new(reroute_6.outputs[0], capture_attribute_002_5.inputs[1])
	    #capture_attribute_002_5.Factor -> combine_xyz_5.Y
	    tube_ribbon.links.new(capture_attribute_002_5.outputs[1], combine_xyz_5.inputs[1])
	    #capture_attribute_002_5.Geometry -> curve_to_mesh_3.Profile Curve
	    tube_ribbon.links.new(capture_attribute_002_5.outputs[0], curve_to_mesh_3.inputs[1])
	    #spline_parameter_4.Factor -> reroute_6.Input
	    tube_ribbon.links.new(spline_parameter_4.outputs[0], reroute_6.inputs[0])
	    #group_input_001_7.Material -> set_material_3.Material
	    tube_ribbon.links.new(group_input_001_7.outputs[1], set_material_3.inputs[2])
	    #combine_xyz_001_1.Vector -> curve_line.Start
	    tube_ribbon.links.new(combine_xyz_001_1.outputs[0], curve_line.inputs[0])
	    #math_001_1.Value -> combine_xyz_002_2.X
	    tube_ribbon.links.new(math_001_1.outputs[0], combine_xyz_002_2.inputs[0])
	    #combine_xyz_002_2.Vector -> curve_line.End
	    tube_ribbon.links.new(combine_xyz_002_2.outputs[0], curve_line.inputs[1])
	    #reroute_001_5.Output -> math_001_1.Value
	    tube_ribbon.links.new(reroute_001_5.outputs[0], math_001_1.inputs[0])
	    #curve_line.Curve -> capture_attribute_002_5.Geometry
	    tube_ribbon.links.new(curve_line.outputs[0], capture_attribute_002_5.inputs[0])
	    #group_input_11.Width -> reroute_001_5.Input
	    tube_ribbon.links.new(group_input_11.outputs[5], reroute_001_5.inputs[0])
	    #reroute_002_5.Output -> resample_curve_3.Curve
	    tube_ribbon.links.new(reroute_002_5.outputs[0], resample_curve_3.inputs[0])
	    #group_input_11.Resolution -> resample_curve_3.Count
	    tube_ribbon.links.new(group_input_11.outputs[4], resample_curve_3.inputs[2])
	    #group_input_002_6.Resolution -> compare_4.A
	    tube_ribbon.links.new(group_input_002_6.outputs[4], compare_4.inputs[2])
	    #compare_4.Result -> switch_5.Switch
	    tube_ribbon.links.new(compare_4.outputs[0], switch_5.inputs[0])
	    #set_curve_radius_3.Curve -> capture_attribute_5.Geometry
	    tube_ribbon.links.new(set_curve_radius_3.outputs[0], capture_attribute_5.inputs[0])
	    #reroute_002_5.Output -> switch_5.True
	    tube_ribbon.links.new(reroute_002_5.outputs[0], switch_5.inputs[2])
	    #resample_curve_3.Curve -> switch_5.False
	    tube_ribbon.links.new(resample_curve_3.outputs[0], switch_5.inputs[1])
	    #group_input_11.Geometry -> set_curve_tilt.Curve
	    tube_ribbon.links.new(group_input_11.outputs[0], set_curve_tilt.inputs[0])
	    #set_curve_tilt.Curve -> reroute_002_5.Input
	    tube_ribbon.links.new(set_curve_tilt.outputs[0], reroute_002_5.inputs[0])
	    #join_geometry_4.Geometry -> repeat_output.Geometry
	    tube_ribbon.links.new(join_geometry_4.outputs[0], repeat_output.inputs[0])
	    #group_input_003_6.Ribbon Count -> repeat_input.Iterations
	    tube_ribbon.links.new(group_input_003_6.outputs[3], repeat_input.inputs[0])
	    #math_003_1.Value -> repeat_output.Index
	    tube_ribbon.links.new(math_003_1.outputs[0], repeat_output.inputs[1])
	    #repeat_output.Geometry -> group_output_15.Geometry
	    tube_ribbon.links.new(repeat_output.outputs[0], group_output_15.inputs[0])
	    #reroute_003_5.Output -> math_003_1.Value
	    tube_ribbon.links.new(reroute_003_5.outputs[0], math_003_1.inputs[0])
	    #group_input_004_5.Ribbon Count -> math_002_1.Value
	    tube_ribbon.links.new(group_input_004_5.outputs[3], math_002_1.inputs[1])
	    #math_002_1.Value -> math_004_1.Value
	    tube_ribbon.links.new(math_002_1.outputs[0], math_004_1.inputs[1])
	    #reroute_003_5.Output -> math_004_1.Value
	    tube_ribbon.links.new(reroute_003_5.outputs[0], math_004_1.inputs[0])
	    #repeat_input.Index -> reroute_003_5.Input
	    tube_ribbon.links.new(repeat_input.outputs[2], reroute_003_5.inputs[0])
	    #set_material_3.Geometry -> join_geometry_4.Geometry
	    tube_ribbon.links.new(set_material_3.outputs[0], join_geometry_4.inputs[0])
	    #curve_tilt.Tilt -> math_005_1.Value
	    tube_ribbon.links.new(curve_tilt.outputs[0], math_005_1.inputs[1])
	    #math_004_1.Value -> math_005_1.Value
	    tube_ribbon.links.new(math_004_1.outputs[0], math_005_1.inputs[0])
	    #math_005_1.Value -> set_curve_tilt.Tilt
	    tube_ribbon.links.new(math_005_1.outputs[0], set_curve_tilt.inputs[2])
	    #switch_5.Output -> set_curve_radius_3.Curve
	    tube_ribbon.links.new(switch_5.outputs[0], set_curve_radius_3.inputs[0])
	    #reroute_004_4.Output -> set_curve_radius_3.Radius
	    tube_ribbon.links.new(reroute_004_4.outputs[0], set_curve_radius_3.inputs[2])
	    #reroute_005_3.Output -> reroute_004_4.Input
	    tube_ribbon.links.new(reroute_005_3.outputs[0], reroute_004_4.inputs[0])
	    #group_input_005_4.Curve Radius -> reroute_005_3.Input
	    tube_ribbon.links.new(group_input_005_4.outputs[2], reroute_005_3.inputs[0])
	    #reroute_001_5.Output -> combine_xyz_001_1.X
	    tube_ribbon.links.new(reroute_001_5.outputs[0], combine_xyz_001_1.inputs[0])
	    #repeat_input.Geometry -> join_geometry_4.Geometry
	    tube_ribbon.links.new(repeat_input.outputs[1], join_geometry_4.inputs[0])
	    return tube_ribbon
	
	tube_ribbon = tube_ribbon_node_group()
	
	#initialize mesh_hair_selector node group
	def mesh_hair_selector_node_group():
	    mesh_hair_selector = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "MESH_HAIR_SELECTOR")
	
	    mesh_hair_selector.color_tag = 'NONE'
	    mesh_hair_selector.description = "Convert hair to mesh object."
	    mesh_hair_selector.default_group_node_width = 140
	    
	
	    mesh_hair_selector.is_modifier = True
	
	    #mesh_hair_selector interface
	    #Socket Geometry
	    geometry_socket_21 = mesh_hair_selector.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_21.attribute_domain = 'POINT'
	    geometry_socket_21.description = "Mesh object."
	
	    #Socket Geometry
	    geometry_socket_22 = mesh_hair_selector.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_22.attribute_domain = 'POINT'
	    geometry_socket_22.description = "Curve object"
	
	    #Socket Style Select
	    style_select_socket = mesh_hair_selector.interface.new_socket(name = "Style Select", in_out='INPUT', socket_type = 'NodeSocketMenu')
	    style_select_socket.attribute_domain = 'POINT'
	    style_select_socket.description = "Mesh style to convert curve."
	
	    #Socket Material
	    material_socket_4 = mesh_hair_selector.interface.new_socket(name = "Material", in_out='INPUT', socket_type = 'NodeSocketMaterial')
	    material_socket_4.attribute_domain = 'POINT'
	    material_socket_4.description = "Material used for mesh."
	
	    #Socket Resolution
	    resolution_socket_6 = mesh_hair_selector.interface.new_socket(name = "Resolution", in_out='INPUT', socket_type = 'NodeSocketInt')
	    resolution_socket_6.default_value = 0
	    resolution_socket_6.min_value = 2
	    resolution_socket_6.max_value = 512
	    resolution_socket_6.subtype = 'NONE'
	    resolution_socket_6.attribute_domain = 'POINT'
	    resolution_socket_6.description = "Control mesh smoothness by add and removing points along curve."
	
	    #Socket Width
	    width_socket_3 = mesh_hair_selector.interface.new_socket(name = "Width", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    width_socket_3.default_value = 0.10000000149011612
	    width_socket_3.min_value = 0.0
	    width_socket_3.max_value = 3.4028234663852886e+38
	    width_socket_3.subtype = 'DISTANCE'
	    width_socket_3.attribute_domain = 'POINT'
	    width_socket_3.description = "Width of mesh object."
	
	    #Socket Fill Caps
	    fill_caps_socket_2 = mesh_hair_selector.interface.new_socket(name = "Fill Caps", in_out='INPUT', socket_type = 'NodeSocketBool')
	    fill_caps_socket_2.default_value = False
	    fill_caps_socket_2.attribute_domain = 'POINT'
	    fill_caps_socket_2.description = "Fill openings with mesh surface. (Used only for [Tube Mesh | Stylized] mesh styles)"
	
	    #Socket Shade Smooth
	    shade_smooth_socket = mesh_hair_selector.interface.new_socket(name = "Shade Smooth", in_out='INPUT', socket_type = 'NodeSocketBool')
	    shade_smooth_socket.default_value = False
	    shade_smooth_socket.attribute_domain = 'POINT'
	    shade_smooth_socket.description = "Use Smooth Shade for mesh."
	
	    #Socket Hair Card Angle
	    hair_card_angle_socket = mesh_hair_selector.interface.new_socket(name = "Hair Card Angle", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    hair_card_angle_socket.default_value = 0.0
	    hair_card_angle_socket.min_value = -90.0
	    hair_card_angle_socket.max_value = 90.0
	    hair_card_angle_socket.subtype = 'ANGLE'
	    hair_card_angle_socket.attribute_domain = 'POINT'
	    hair_card_angle_socket.description = "Angle used to bend hair card. (Mesh Style=Hair Card)"
	
	    #Socket Tube Ribbon Count
	    tube_ribbon_count_socket = mesh_hair_selector.interface.new_socket(name = "Tube Ribbon Count", in_out='INPUT', socket_type = 'NodeSocketInt')
	    tube_ribbon_count_socket.default_value = 8
	    tube_ribbon_count_socket.min_value = 1
	    tube_ribbon_count_socket.max_value = 180
	    tube_ribbon_count_socket.subtype = 'NONE'
	    tube_ribbon_count_socket.attribute_domain = 'POINT'
	    tube_ribbon_count_socket.description = "Amount of billboard like hair cards used to shape hair. (Mesh Style=Tube Ribbon)"
	
	    #Socket Profile Curve
	    profile_curve_socket = mesh_hair_selector.interface.new_socket(name = "Profile Curve", in_out='INPUT', socket_type = 'NodeSocketObject')
	    profile_curve_socket.attribute_domain = 'POINT'
	    profile_curve_socket.description = "Curve object used as the profile for stylized hair. (Mesh Style=Stylized)"
	
	    #Socket Profile Translation
	    profile_translation_socket = mesh_hair_selector.interface.new_socket(name = "Profile Translation", in_out='INPUT', socket_type = 'NodeSocketVector')
	    profile_translation_socket.default_value = (0.0, 0.0, 0.0)
	    profile_translation_socket.min_value = -3.4028234663852886e+38
	    profile_translation_socket.max_value = 3.4028234663852886e+38
	    profile_translation_socket.subtype = 'TRANSLATION'
	    profile_translation_socket.attribute_domain = 'POINT'
	    profile_translation_socket.description = "Move position of stylized profile from origin. (Mesh Style=Stylized)"
	
	    #Socket Profile Rotation
	    profile_rotation_socket = mesh_hair_selector.interface.new_socket(name = "Profile Rotation", in_out='INPUT', socket_type = 'NodeSocketRotation')
	    profile_rotation_socket.default_value = (0.0, 0.0, 0.0)
	    profile_rotation_socket.attribute_domain = 'POINT'
	    profile_rotation_socket.description = "Rotate the stylized profile from origin. (Mesh Style=Stylized)"
	
	    #Socket Profile Scale
	    profile_scale_socket = mesh_hair_selector.interface.new_socket(name = "Profile Scale", in_out='INPUT', socket_type = 'NodeSocketVector')
	    profile_scale_socket.default_value = (1.0, 1.0, 1.0)
	    profile_scale_socket.min_value = -3.4028234663852886e+38
	    profile_scale_socket.max_value = 3.4028234663852886e+38
	    profile_scale_socket.subtype = 'XYZ'
	    profile_scale_socket.attribute_domain = 'POINT'
	    profile_scale_socket.description = "Scale the stylized profile from origin. (Mesh Style=Stylized)"
	
	    #Socket Mesh Index
	    mesh_index_socket = mesh_hair_selector.interface.new_socket(name = "Mesh Index", in_out='INPUT', socket_type = 'NodeSocketInt')
	    mesh_index_socket.default_value = 0
	    mesh_index_socket.min_value = 0
	    mesh_index_socket.max_value = 2147483647
	    mesh_index_socket.subtype = 'NONE'
	    mesh_index_socket.attribute_domain = 'POINT'
	    mesh_index_socket.description = "Index used to offset uv coords."
	
	
	    #initialize mesh_hair_selector nodes
	    #node Group Output
	    group_output_16 = mesh_hair_selector.nodes.new("NodeGroupOutput")
	    group_output_16.name = "Group Output"
	    group_output_16.is_active_output = True
	    group_output_16.inputs[1].hide = True
	
	    #node Group
	    group_5 = mesh_hair_selector.nodes.new("GeometryNodeGroup")
	    group_5.name = "Group"
	    group_5.node_tree = hair_card
	
	    #node Group.001
	    group_001_5 = mesh_hair_selector.nodes.new("GeometryNodeGroup")
	    group_001_5.name = "Group.001"
	    group_001_5.node_tree = stylized_hair
	
	    #node Group.002
	    group_002_2 = mesh_hair_selector.nodes.new("GeometryNodeGroup")
	    group_002_2.name = "Group.002"
	    group_002_2.node_tree = tube_mesh
	
	    #node Group.003
	    group_003_1 = mesh_hair_selector.nodes.new("GeometryNodeGroup")
	    group_003_1.name = "Group.003"
	    group_003_1.node_tree = tube_ribbon
	
	    #node Group Input.001
	    group_input_001_8 = mesh_hair_selector.nodes.new("NodeGroupInput")
	    group_input_001_8.name = "Group Input.001"
	    group_input_001_8.outputs[1].hide = True
	    group_input_001_8.outputs[5].hide = True
	    group_input_001_8.outputs[6].hide = True
	    group_input_001_8.outputs[8].hide = True
	    group_input_001_8.outputs[9].hide = True
	    group_input_001_8.outputs[10].hide = True
	    group_input_001_8.outputs[11].hide = True
	    group_input_001_8.outputs[12].hide = True
	    group_input_001_8.outputs[13].hide = True
	    group_input_001_8.outputs[14].hide = True
	
	    #node Group Input.002
	    group_input_002_7 = mesh_hair_selector.nodes.new("NodeGroupInput")
	    group_input_002_7.name = "Group Input.002"
	    group_input_002_7.outputs[1].hide = True
	    group_input_002_7.outputs[6].hide = True
	    group_input_002_7.outputs[7].hide = True
	    group_input_002_7.outputs[8].hide = True
	    group_input_002_7.outputs[9].hide = True
	    group_input_002_7.outputs[10].hide = True
	    group_input_002_7.outputs[11].hide = True
	    group_input_002_7.outputs[12].hide = True
	    group_input_002_7.outputs[13].hide = True
	    group_input_002_7.outputs[14].hide = True
	
	    #node Group Input.003
	    group_input_003_7 = mesh_hair_selector.nodes.new("NodeGroupInput")
	    group_input_003_7.name = "Group Input.003"
	    group_input_003_7.outputs[1].hide = True
	    group_input_003_7.outputs[5].hide = True
	    group_input_003_7.outputs[6].hide = True
	    group_input_003_7.outputs[7].hide = True
	    group_input_003_7.outputs[9].hide = True
	    group_input_003_7.outputs[10].hide = True
	    group_input_003_7.outputs[11].hide = True
	    group_input_003_7.outputs[12].hide = True
	    group_input_003_7.outputs[13].hide = True
	    group_input_003_7.outputs[14].hide = True
	
	    #node Group Input.004
	    group_input_004_6 = mesh_hair_selector.nodes.new("NodeGroupInput")
	    group_input_004_6.name = "Group Input.004"
	    group_input_004_6.outputs[1].hide = True
	    group_input_004_6.outputs[4].hide = True
	    group_input_004_6.outputs[6].hide = True
	    group_input_004_6.outputs[7].hide = True
	    group_input_004_6.outputs[8].hide = True
	    group_input_004_6.outputs[9].hide = True
	    group_input_004_6.outputs[13].hide = True
	    group_input_004_6.outputs[14].hide = True
	
	    #node Menu Switch.001
	    menu_switch_001 = mesh_hair_selector.nodes.new("GeometryNodeMenuSwitch")
	    menu_switch_001.name = "Menu Switch.001"
	    menu_switch_001.active_index = 3
	    menu_switch_001.data_type = 'STRING'
	    menu_switch_001.enum_items.clear()
	    menu_switch_001.enum_items.new("Hair Card")
	    menu_switch_001.enum_items[0].description = ""
	    menu_switch_001.enum_items.new("Tube Mesh")
	    menu_switch_001.enum_items[1].description = ""
	    menu_switch_001.enum_items.new("Tube Ribbon")
	    menu_switch_001.enum_items[2].description = ""
	    menu_switch_001.enum_items.new("Stylized")
	    menu_switch_001.enum_items[3].description = ""
	    menu_switch_001.inputs[5].hide = True
	
	    #node Store Named Attribute
	    store_named_attribute_6 = mesh_hair_selector.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_6.name = "Store Named Attribute"
	    store_named_attribute_6.data_type = 'FLOAT2'
	    store_named_attribute_6.domain = 'CORNER'
	    #Selection
	    store_named_attribute_6.inputs[1].default_value = True
	    #Name
	    store_named_attribute_6.inputs[2].default_value = "UVMap"
	
	    #node Named Attribute
	    named_attribute_3 = mesh_hair_selector.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute_3.name = "Named Attribute"
	    named_attribute_3.data_type = 'FLOAT_VECTOR'
	
	    #node Group Input.005
	    group_input_005_5 = mesh_hair_selector.nodes.new("NodeGroupInput")
	    group_input_005_5.name = "Group Input.005"
	    group_input_005_5.outputs[0].hide = True
	    group_input_005_5.outputs[2].hide = True
	    group_input_005_5.outputs[3].hide = True
	    group_input_005_5.outputs[4].hide = True
	    group_input_005_5.outputs[5].hide = True
	    group_input_005_5.outputs[6].hide = True
	    group_input_005_5.outputs[7].hide = True
	    group_input_005_5.outputs[8].hide = True
	    group_input_005_5.outputs[9].hide = True
	    group_input_005_5.outputs[10].hide = True
	    group_input_005_5.outputs[11].hide = True
	    group_input_005_5.outputs[12].hide = True
	    group_input_005_5.outputs[13].hide = True
	    group_input_005_5.outputs[14].hide = True
	
	    #node Group Input.006
	    group_input_006_3 = mesh_hair_selector.nodes.new("NodeGroupInput")
	    group_input_006_3.name = "Group Input.006"
	    group_input_006_3.outputs[0].hide = True
	    group_input_006_3.outputs[1].hide = True
	    group_input_006_3.outputs[2].hide = True
	    group_input_006_3.outputs[3].hide = True
	    group_input_006_3.outputs[4].hide = True
	    group_input_006_3.outputs[5].hide = True
	    group_input_006_3.outputs[6].hide = True
	    group_input_006_3.outputs[7].hide = True
	    group_input_006_3.outputs[8].hide = True
	    group_input_006_3.outputs[10].hide = True
	    group_input_006_3.outputs[11].hide = True
	    group_input_006_3.outputs[12].hide = True
	    group_input_006_3.outputs[13].hide = True
	    group_input_006_3.outputs[14].hide = True
	
	    #node Compare
	    compare_5 = mesh_hair_selector.nodes.new("FunctionNodeCompare")
	    compare_5.name = "Compare"
	    compare_5.hide = True
	    compare_5.data_type = 'STRING'
	    compare_5.mode = 'ELEMENT'
	    compare_5.operation = 'EQUAL'
	
	    #node Switch
	    switch_6 = mesh_hair_selector.nodes.new("GeometryNodeSwitch")
	    switch_6.name = "Switch"
	    switch_6.hide = True
	    switch_6.input_type = 'GEOMETRY'
	
	    #node Compare.001
	    compare_001_1 = mesh_hair_selector.nodes.new("FunctionNodeCompare")
	    compare_001_1.name = "Compare.001"
	    compare_001_1.hide = True
	    compare_001_1.data_type = 'STRING'
	    compare_001_1.mode = 'ELEMENT'
	    compare_001_1.operation = 'EQUAL'
	
	    #node Switch.001
	    switch_001_2 = mesh_hair_selector.nodes.new("GeometryNodeSwitch")
	    switch_001_2.name = "Switch.001"
	    switch_001_2.hide = True
	    switch_001_2.input_type = 'GEOMETRY'
	
	    #node Compare.002
	    compare_002_1 = mesh_hair_selector.nodes.new("FunctionNodeCompare")
	    compare_002_1.name = "Compare.002"
	    compare_002_1.hide = True
	    compare_002_1.data_type = 'STRING'
	    compare_002_1.mode = 'ELEMENT'
	    compare_002_1.operation = 'EQUAL'
	
	    #node Switch.002
	    switch_002_1 = mesh_hair_selector.nodes.new("GeometryNodeSwitch")
	    switch_002_1.name = "Switch.002"
	    switch_002_1.hide = True
	    switch_002_1.input_type = 'GEOMETRY'
	
	    #node Compare.003
	    compare_003 = mesh_hair_selector.nodes.new("FunctionNodeCompare")
	    compare_003.name = "Compare.003"
	    compare_003.hide = True
	    compare_003.data_type = 'STRING'
	    compare_003.mode = 'ELEMENT'
	    compare_003.operation = 'EQUAL'
	
	    #node Switch.003
	    switch_003_1 = mesh_hair_selector.nodes.new("GeometryNodeSwitch")
	    switch_003_1.name = "Switch.003"
	    switch_003_1.hide = True
	    switch_003_1.input_type = 'GEOMETRY'
	
	    #node String
	    string = mesh_hair_selector.nodes.new("FunctionNodeInputString")
	    string.name = "String"
	    string.string = "hair_card_UV"
	
	    #node String.001
	    string_001 = mesh_hair_selector.nodes.new("FunctionNodeInputString")
	    string_001.name = "String.001"
	    string_001.string = "tube_mesh_UV"
	
	    #node String.002
	    string_002 = mesh_hair_selector.nodes.new("FunctionNodeInputString")
	    string_002.name = "String.002"
	    string_002.string = "ribbon_mesh_UV"
	
	    #node String.003
	    string_003 = mesh_hair_selector.nodes.new("FunctionNodeInputString")
	    string_003.name = "String.003"
	    string_003.string = "stylized_hair_UV"
	
	    #node Reroute
	    reroute_7 = mesh_hair_selector.nodes.new("NodeReroute")
	    reroute_7.name = "Reroute"
	    reroute_7.socket_idname = "NodeSocketString"
	    #node Reroute.001
	    reroute_001_6 = mesh_hair_selector.nodes.new("NodeReroute")
	    reroute_001_6.name = "Reroute.001"
	    reroute_001_6.socket_idname = "NodeSocketString"
	    #node Reroute.002
	    reroute_002_6 = mesh_hair_selector.nodes.new("NodeReroute")
	    reroute_002_6.name = "Reroute.002"
	    reroute_002_6.socket_idname = "NodeSocketString"
	    #node Reroute.003
	    reroute_003_6 = mesh_hair_selector.nodes.new("NodeReroute")
	    reroute_003_6.name = "Reroute.003"
	    reroute_003_6.socket_idname = "NodeSocketString"
	    #node Reroute.004
	    reroute_004_5 = mesh_hair_selector.nodes.new("NodeReroute")
	    reroute_004_5.name = "Reroute.004"
	    reroute_004_5.socket_idname = "NodeSocketString"
	    #node Reroute.005
	    reroute_005_4 = mesh_hair_selector.nodes.new("NodeReroute")
	    reroute_005_4.name = "Reroute.005"
	    reroute_005_4.socket_idname = "NodeSocketString"
	    #node Reroute.006
	    reroute_006_3 = mesh_hair_selector.nodes.new("NodeReroute")
	    reroute_006_3.name = "Reroute.006"
	    reroute_006_3.socket_idname = "NodeSocketString"
	    #node Reroute.007
	    reroute_007_3 = mesh_hair_selector.nodes.new("NodeReroute")
	    reroute_007_3.name = "Reroute.007"
	    reroute_007_3.socket_idname = "NodeSocketString"
	    #node Reroute.008
	    reroute_008_3 = mesh_hair_selector.nodes.new("NodeReroute")
	    reroute_008_3.name = "Reroute.008"
	    reroute_008_3.socket_idname = "NodeSocketString"
	    #node Reroute.009
	    reroute_009_3 = mesh_hair_selector.nodes.new("NodeReroute")
	    reroute_009_3.name = "Reroute.009"
	    reroute_009_3.socket_idname = "NodeSocketString"
	    #node Reroute.010
	    reroute_010_1 = mesh_hair_selector.nodes.new("NodeReroute")
	    reroute_010_1.name = "Reroute.010"
	    reroute_010_1.socket_idname = "NodeSocketString"
	    #node Reroute.011
	    reroute_011_1 = mesh_hair_selector.nodes.new("NodeReroute")
	    reroute_011_1.name = "Reroute.011"
	    reroute_011_1.socket_idname = "NodeSocketString"
	    #node Reroute.012
	    reroute_012_2 = mesh_hair_selector.nodes.new("NodeReroute")
	    reroute_012_2.name = "Reroute.012"
	    reroute_012_2.socket_idname = "NodeSocketString"
	    #node Reroute.013
	    reroute_013_2 = mesh_hair_selector.nodes.new("NodeReroute")
	    reroute_013_2.name = "Reroute.013"
	    reroute_013_2.socket_idname = "NodeSocketString"
	    #node Reroute.014
	    reroute_014_2 = mesh_hair_selector.nodes.new("NodeReroute")
	    reroute_014_2.name = "Reroute.014"
	    reroute_014_2.socket_idname = "NodeSocketString"
	    #node Group Input.007
	    group_input_007_3 = mesh_hair_selector.nodes.new("NodeGroupInput")
	    group_input_007_3.name = "Group Input.007"
	    group_input_007_3.outputs[0].hide = True
	    group_input_007_3.outputs[1].hide = True
	    group_input_007_3.outputs[2].hide = True
	    group_input_007_3.outputs[3].hide = True
	    group_input_007_3.outputs[4].hide = True
	    group_input_007_3.outputs[5].hide = True
	    group_input_007_3.outputs[6].hide = True
	    group_input_007_3.outputs[7].hide = True
	    group_input_007_3.outputs[8].hide = True
	    group_input_007_3.outputs[9].hide = True
	    group_input_007_3.outputs[10].hide = True
	    group_input_007_3.outputs[11].hide = True
	    group_input_007_3.outputs[12].hide = True
	    group_input_007_3.outputs[14].hide = True
	
	    #node Store Named Attribute.001
	    store_named_attribute_001_1 = mesh_hair_selector.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_001_1.name = "Store Named Attribute.001"
	    store_named_attribute_001_1.data_type = 'INT'
	    store_named_attribute_001_1.domain = 'CORNER'
	    #Selection
	    store_named_attribute_001_1.inputs[1].default_value = True
	    #Name
	    store_named_attribute_001_1.inputs[2].default_value = "mesh_idx"
	
	    #node Remove Named Attribute
	    remove_named_attribute = mesh_hair_selector.nodes.new("GeometryNodeRemoveAttribute")
	    remove_named_attribute.name = "Remove Named Attribute"
	    remove_named_attribute.pattern_mode = 'EXACT'
	
	    #node Reroute.015
	    reroute_015_2 = mesh_hair_selector.nodes.new("NodeReroute")
	    reroute_015_2.name = "Reroute.015"
	    reroute_015_2.socket_idname = "NodeSocketString"
	    #node Reroute.016
	    reroute_016_2 = mesh_hair_selector.nodes.new("NodeReroute")
	    reroute_016_2.name = "Reroute.016"
	    reroute_016_2.socket_idname = "NodeSocketString"
	    #node Set Shade Smooth
	    set_shade_smooth = mesh_hair_selector.nodes.new("GeometryNodeSetShadeSmooth")
	    set_shade_smooth.name = "Set Shade Smooth"
	    set_shade_smooth.domain = 'FACE'
	    set_shade_smooth.inputs[1].hide = True
	    #Selection
	    set_shade_smooth.inputs[1].default_value = True
	
	    #node Use Mesh Bake
	    use_mesh_bake = mesh_hair_selector.nodes.new("GeometryNodeBake")
	    use_mesh_bake.label = "Use Mesh Bake"
	    use_mesh_bake.name = "Use Mesh Bake"
	    use_mesh_bake.active_index = 0
	    use_mesh_bake.bake_items.clear()
	    use_mesh_bake.bake_items.new('GEOMETRY', "Geometry")
	    use_mesh_bake.bake_items[0].attribute_domain = 'POINT'
	    use_mesh_bake.inputs[1].hide = True
	    use_mesh_bake.outputs[1].hide = True
	
	    #node Group Input.008
	    group_input_008_1 = mesh_hair_selector.nodes.new("NodeGroupInput")
	    group_input_008_1.name = "Group Input.008"
	    group_input_008_1.outputs[0].hide = True
	    group_input_008_1.outputs[1].hide = True
	    group_input_008_1.outputs[2].hide = True
	    group_input_008_1.outputs[3].hide = True
	    group_input_008_1.outputs[4].hide = True
	    group_input_008_1.outputs[5].hide = True
	    group_input_008_1.outputs[7].hide = True
	    group_input_008_1.outputs[8].hide = True
	    group_input_008_1.outputs[9].hide = True
	    group_input_008_1.outputs[10].hide = True
	    group_input_008_1.outputs[11].hide = True
	    group_input_008_1.outputs[12].hide = True
	    group_input_008_1.outputs[13].hide = True
	    group_input_008_1.outputs[14].hide = True
	
	    #node Mesh Overall Shape
	    mesh_overall_shape = mesh_hair_selector.nodes.new("ShaderNodeFloatCurve")
	    mesh_overall_shape.label = "Mesh Overall Shape"
	    mesh_overall_shape.name = "Mesh Overall Shape"
	    #mapping settings
	    mesh_overall_shape.mapping.extend = 'EXTRAPOLATED'
	    mesh_overall_shape.mapping.tone = 'STANDARD'
	    mesh_overall_shape.mapping.black_level = (0.0, 0.0, 0.0)
	    mesh_overall_shape.mapping.white_level = (1.0, 1.0, 1.0)
	    mesh_overall_shape.mapping.clip_min_x = 0.0
	    mesh_overall_shape.mapping.clip_min_y = 0.0
	    mesh_overall_shape.mapping.clip_max_x = 1.0
	    mesh_overall_shape.mapping.clip_max_y = 1.0
	    mesh_overall_shape.mapping.use_clip = True
	    #curve 0
	    mesh_overall_shape_curve_0 = mesh_overall_shape.mapping.curves[0]
	    mesh_overall_shape_curve_0_point_0 = mesh_overall_shape_curve_0.points[0]
	    mesh_overall_shape_curve_0_point_0.location = (0.0, 1.0)
	    mesh_overall_shape_curve_0_point_0.handle_type = 'AUTO'
	    mesh_overall_shape_curve_0_point_1 = mesh_overall_shape_curve_0.points[1]
	    mesh_overall_shape_curve_0_point_1.location = (1.0, 1.0)
	    mesh_overall_shape_curve_0_point_1.handle_type = 'AUTO'
	    #update curve after changes
	    mesh_overall_shape.mapping.update()
	    #Factor
	    mesh_overall_shape.inputs[0].default_value = 1.0
	
	    #node Spline Parameter.001
	    spline_parameter_001 = mesh_hair_selector.nodes.new("GeometryNodeSplineParameter")
	    spline_parameter_001.name = "Spline Parameter.001"
	    spline_parameter_001.outputs[1].hide = True
	    spline_parameter_001.outputs[2].hide = True
	
	    #node Switch.004
	    switch_004_1 = mesh_hair_selector.nodes.new("GeometryNodeSwitch")
	    switch_004_1.name = "Switch.004"
	    switch_004_1.hide = True
	    switch_004_1.input_type = 'FLOAT'
	
	    #node Group Input.009
	    group_input_009_1 = mesh_hair_selector.nodes.new("NodeGroupInput")
	    group_input_009_1.name = "Group Input.009"
	    group_input_009_1.outputs[0].hide = True
	    group_input_009_1.outputs[1].hide = True
	    group_input_009_1.outputs[2].hide = True
	    group_input_009_1.outputs[3].hide = True
	    group_input_009_1.outputs[4].hide = True
	    group_input_009_1.outputs[6].hide = True
	    group_input_009_1.outputs[7].hide = True
	    group_input_009_1.outputs[8].hide = True
	    group_input_009_1.outputs[9].hide = True
	    group_input_009_1.outputs[10].hide = True
	    group_input_009_1.outputs[11].hide = True
	    group_input_009_1.outputs[12].hide = True
	    group_input_009_1.outputs[13].hide = True
	    group_input_009_1.outputs[14].hide = True
	
	    #node Attribute Statistic
	    attribute_statistic = mesh_hair_selector.nodes.new("GeometryNodeAttributeStatistic")
	    attribute_statistic.name = "Attribute Statistic"
	    attribute_statistic.hide = True
	    attribute_statistic.data_type = 'FLOAT'
	    attribute_statistic.domain = 'POINT'
	    attribute_statistic.inputs[1].hide = True
	    attribute_statistic.outputs[0].hide = True
	    attribute_statistic.outputs[1].hide = True
	    attribute_statistic.outputs[3].hide = True
	    attribute_statistic.outputs[4].hide = True
	    attribute_statistic.outputs[5].hide = True
	    attribute_statistic.outputs[6].hide = True
	    attribute_statistic.outputs[7].hide = True
	    #Selection
	    attribute_statistic.inputs[1].default_value = True
	
	    #node Store Named Attribute.002
	    store_named_attribute_002 = mesh_hair_selector.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_002.name = "Store Named Attribute.002"
	    store_named_attribute_002.hide = True
	    store_named_attribute_002.data_type = 'FLOAT'
	    store_named_attribute_002.domain = 'POINT'
	    store_named_attribute_002.inputs[1].hide = True
	    store_named_attribute_002.inputs[2].hide = True
	    #Selection
	    store_named_attribute_002.inputs[1].default_value = True
	    #Name
	    store_named_attribute_002.inputs[2].default_value = "mcr"
	
	    #node Compare.005
	    compare_005 = mesh_hair_selector.nodes.new("FunctionNodeCompare")
	    compare_005.name = "Compare.005"
	    compare_005.hide = True
	    compare_005.data_type = 'FLOAT'
	    compare_005.mode = 'ELEMENT'
	    compare_005.operation = 'EQUAL'
	    compare_005.inputs[1].hide = True
	    compare_005.inputs[2].hide = True
	    compare_005.inputs[3].hide = True
	    compare_005.inputs[4].hide = True
	    compare_005.inputs[5].hide = True
	    compare_005.inputs[6].hide = True
	    compare_005.inputs[7].hide = True
	    compare_005.inputs[8].hide = True
	    compare_005.inputs[9].hide = True
	    compare_005.inputs[10].hide = True
	    compare_005.inputs[11].hide = True
	    compare_005.inputs[12].hide = True
	    #B
	    compare_005.inputs[1].default_value = 0.0
	    #Epsilon
	    compare_005.inputs[12].default_value = 0.0
	
	    #node Named Attribute.001
	    named_attribute_001_2 = mesh_hair_selector.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute_001_2.name = "Named Attribute.001"
	    named_attribute_001_2.hide = True
	    named_attribute_001_2.data_type = 'FLOAT'
	    #Name
	    named_attribute_001_2.inputs[0].default_value = "mcr"
	
	    #node Group Input.010
	    group_input_010 = mesh_hair_selector.nodes.new("NodeGroupInput")
	    group_input_010.name = "Group Input.010"
	    group_input_010.outputs[1].hide = True
	    group_input_010.outputs[2].hide = True
	    group_input_010.outputs[3].hide = True
	    group_input_010.outputs[4].hide = True
	    group_input_010.outputs[5].hide = True
	    group_input_010.outputs[6].hide = True
	    group_input_010.outputs[7].hide = True
	    group_input_010.outputs[8].hide = True
	    group_input_010.outputs[9].hide = True
	    group_input_010.outputs[10].hide = True
	    group_input_010.outputs[11].hide = True
	    group_input_010.outputs[12].hide = True
	    group_input_010.outputs[13].hide = True
	    group_input_010.outputs[14].hide = True
	
	
	
	
	
	    #Set locations
	    group_output_16.location = (2610.42724609375, -19.416736602783203)
	    group_5.location = (-79.76215362548828, -110.40367889404297)
	    group_001_5.location = (-81.79773712158203, -748.9313354492188)
	    group_002_2.location = (-78.79950714111328, -318.1512451171875)
	    group_003_1.location = (-78.67485809326172, -526.0662231445312)
	    group_input_001_8.location = (-338.60595703125, -155.34437561035156)
	    group_input_002_7.location = (-338.60595703125, -362.43890380859375)
	    group_input_003_7.location = (-338.60595703125, -569.8320922851562)
	    group_input_004_6.location = (-338.60595703125, -815.11083984375)
	    menu_switch_001.location = (469.07684326171875, 163.7274627685547)
	    store_named_attribute_6.location = (1647.7332763671875, -19.652393341064453)
	    named_attribute_3.location = (1475.844482421875, -157.7658233642578)
	    group_input_005_5.location = (265.0098571777344, 135.95323181152344)
	    group_input_006_3.location = (-338.60595703125, -756.4561767578125)
	    compare_5.location = (1238.7310791015625, -84.21184539794922)
	    switch_6.location = (1238.74365234375, -117.19403076171875)
	    compare_001_1.location = (1099.1707763671875, -299.4894104003906)
	    switch_001_2.location = (1106.2532958984375, -334.8301696777344)
	    compare_002_1.location = (970.40234375, -499.8262634277344)
	    switch_002_1.location = (975.1282958984375, -535.1670532226562)
	    compare_003.location = (837.8390502929688, -724.1065063476562)
	    switch_003_1.location = (840.2083740234375, -760.2830810546875)
	    string.location = (84.04959869384766, -54.475547790527344)
	    string_001.location = (82.85930633544922, -258.00762939453125)
	    string_002.location = (79.31243896484375, -471.3780517578125)
	    string_003.location = (76.95584106445312, -696.93603515625)
	    reroute_7.location = (266.1946716308594, -90.37294006347656)
	    reroute_001_6.location = (330.2995910644531, -295.4872741699219)
	    reroute_002_6.location = (386.08740234375, -507.37738037109375)
	    reroute_003_6.location = (432.0370178222656, -735.281005859375)
	    reroute_004_5.location = (267.64080810546875, 58.478363037109375)
	    reroute_005_4.location = (328.94110107421875, 33.61994552612305)
	    reroute_006_3.location = (388.06353759765625, 12.934127807617188)
	    reroute_007_3.location = (434.48321533203125, -6.701620101928711)
	    reroute_008_3.location = (790.6254272460938, 129.04226684570312)
	    reroute_009_3.location = (800.4947509765625, -727.48974609375)
	    reroute_010_1.location = (796.8050537109375, -498.8685607910156)
	    reroute_011_1.location = (792.9110107421875, -293.6495361328125)
	    reroute_012_2.location = (790.7710571289062, -80.90033721923828)
	    reroute_013_2.location = (1415.17578125, -264.01324462890625)
	    reroute_014_2.location = (1401.7613525390625, 129.6073760986328)
	    group_input_007_3.location = (1837.3367919921875, -221.13070678710938)
	    store_named_attribute_001_1.location = (1841.328125, -19.652393341064453)
	    remove_named_attribute.location = (2020.999755859375, -18.566680908203125)
	    reroute_015_2.location = (1997.9866943359375, 132.55369567871094)
	    reroute_016_2.location = (2003.16845703125, -126.52413940429688)
	    set_shade_smooth.location = (2246.024658203125, -17.58367919921875)
	    use_mesh_bake.location = (2430.91064453125, 27.558258056640625)
	    group_input_008_1.location = (2049.84326171875, -148.66607666015625)
	    mesh_overall_shape.location = (-786.2078247070312, -580.0576171875)
	    spline_parameter_001.location = (-789.681640625, -897.3448486328125)
	    switch_004_1.location = (-544.74169921875, -402.336669921875)
	    group_input_009_1.location = (-785.4437255859375, -520.33056640625)
	    attribute_statistic.location = (-783.7899169921875, -440.627197265625)
	    store_named_attribute_002.location = (-791.8580932617188, -495.2635498046875)
	    compare_005.location = (-545.5264892578125, -440.481689453125)
	    named_attribute_001_2.location = (-786.9500732421875, -383.8218994140625)
	    group_input_010.location = (-959.9534912109375, -463.28759765625)
	
	    #Set dimensions
	    group_output_16.width, group_output_16.height = 140.0, 100.0
	    group_5.width, group_5.height = 140.0, 100.0
	    group_001_5.width, group_001_5.height = 140.0, 100.0
	    group_002_2.width, group_002_2.height = 140.0, 100.0
	    group_003_1.width, group_003_1.height = 140.0, 100.0
	    group_input_001_8.width, group_input_001_8.height = 140.0, 100.0
	    group_input_002_7.width, group_input_002_7.height = 140.0, 100.0
	    group_input_003_7.width, group_input_003_7.height = 140.0, 100.0
	    group_input_004_6.width, group_input_004_6.height = 140.0, 100.0
	    menu_switch_001.width, menu_switch_001.height = 245.18148803710938, 100.0
	    store_named_attribute_6.width, store_named_attribute_6.height = 140.0, 100.0
	    named_attribute_3.width, named_attribute_3.height = 140.0, 100.0
	    group_input_005_5.width, group_input_005_5.height = 140.0, 100.0
	    group_input_006_3.width, group_input_006_3.height = 140.0, 100.0
	    compare_5.width, compare_5.height = 140.0, 100.0
	    switch_6.width, switch_6.height = 140.0, 100.0
	    compare_001_1.width, compare_001_1.height = 140.0, 100.0
	    switch_001_2.width, switch_001_2.height = 140.0, 100.0
	    compare_002_1.width, compare_002_1.height = 140.0, 100.0
	    switch_002_1.width, switch_002_1.height = 140.0, 100.0
	    compare_003.width, compare_003.height = 140.0, 100.0
	    switch_003_1.width, switch_003_1.height = 140.0, 100.0
	    string.width, string.height = 140.0, 100.0
	    string_001.width, string_001.height = 140.0, 100.0
	    string_002.width, string_002.height = 140.0, 100.0
	    string_003.width, string_003.height = 140.0, 100.0
	    reroute_7.width, reroute_7.height = 10.0, 100.0
	    reroute_001_6.width, reroute_001_6.height = 10.0, 100.0
	    reroute_002_6.width, reroute_002_6.height = 10.0, 100.0
	    reroute_003_6.width, reroute_003_6.height = 10.0, 100.0
	    reroute_004_5.width, reroute_004_5.height = 10.0, 100.0
	    reroute_005_4.width, reroute_005_4.height = 10.0, 100.0
	    reroute_006_3.width, reroute_006_3.height = 10.0, 100.0
	    reroute_007_3.width, reroute_007_3.height = 10.0, 100.0
	    reroute_008_3.width, reroute_008_3.height = 10.0, 100.0
	    reroute_009_3.width, reroute_009_3.height = 10.0, 100.0
	    reroute_010_1.width, reroute_010_1.height = 10.0, 100.0
	    reroute_011_1.width, reroute_011_1.height = 10.0, 100.0
	    reroute_012_2.width, reroute_012_2.height = 10.0, 100.0
	    reroute_013_2.width, reroute_013_2.height = 10.0, 100.0
	    reroute_014_2.width, reroute_014_2.height = 10.0, 100.0
	    group_input_007_3.width, group_input_007_3.height = 140.0, 100.0
	    store_named_attribute_001_1.width, store_named_attribute_001_1.height = 140.0, 100.0
	    remove_named_attribute.width, remove_named_attribute.height = 170.0, 100.0
	    reroute_015_2.width, reroute_015_2.height = 10.0, 100.0
	    reroute_016_2.width, reroute_016_2.height = 10.0, 100.0
	    set_shade_smooth.width, set_shade_smooth.height = 140.0, 100.0
	    use_mesh_bake.width, use_mesh_bake.height = 140.0, 100.0
	    group_input_008_1.width, group_input_008_1.height = 140.0, 100.0
	    mesh_overall_shape.width, mesh_overall_shape.height = 240.0, 100.0
	    spline_parameter_001.width, spline_parameter_001.height = 140.0, 100.0
	    switch_004_1.width, switch_004_1.height = 140.0, 100.0
	    group_input_009_1.width, group_input_009_1.height = 140.0, 100.0
	    attribute_statistic.width, attribute_statistic.height = 140.0, 100.0
	    store_named_attribute_002.width, store_named_attribute_002.height = 140.0, 100.0
	    compare_005.width, compare_005.height = 140.0, 100.0
	    named_attribute_001_2.width, named_attribute_001_2.height = 140.0, 100.0
	    group_input_010.width, group_input_010.height = 140.0, 100.0
	
	    #initialize mesh_hair_selector links
	    #use_mesh_bake.Geometry -> group_output_16.Geometry
	    mesh_hair_selector.links.new(use_mesh_bake.outputs[0], group_output_16.inputs[0])
	    #group_input_001_8.Geometry -> group_5.Geometry
	    mesh_hair_selector.links.new(group_input_001_8.outputs[0], group_5.inputs[0])
	    #group_input_002_7.Geometry -> group_002_2.Geometry
	    mesh_hair_selector.links.new(group_input_002_7.outputs[0], group_002_2.inputs[0])
	    #group_input_003_7.Geometry -> group_003_1.Geometry
	    mesh_hair_selector.links.new(group_input_003_7.outputs[0], group_003_1.inputs[0])
	    #group_input_004_6.Geometry -> group_001_5.Geometry
	    mesh_hair_selector.links.new(group_input_004_6.outputs[0], group_001_5.inputs[0])
	    #group_input_001_8.Material -> group_5.Material
	    mesh_hair_selector.links.new(group_input_001_8.outputs[2], group_5.inputs[1])
	    #named_attribute_3.Attribute -> store_named_attribute_6.Value
	    mesh_hair_selector.links.new(named_attribute_3.outputs[0], store_named_attribute_6.inputs[3])
	    #reroute_013_2.Output -> named_attribute_3.Name
	    mesh_hair_selector.links.new(reroute_013_2.outputs[0], named_attribute_3.inputs[0])
	    #group_input_005_5.Style Select -> menu_switch_001.Menu
	    mesh_hair_selector.links.new(group_input_005_5.outputs[1], menu_switch_001.inputs[0])
	    #group_input_001_8.Resolution -> group_5.Resolution
	    mesh_hair_selector.links.new(group_input_001_8.outputs[3], group_5.inputs[3])
	    #group_input_001_8.Width -> group_5.Width
	    mesh_hair_selector.links.new(group_input_001_8.outputs[4], group_5.inputs[4])
	    #group_input_001_8.Hair Card Angle -> group_5.Angle
	    mesh_hair_selector.links.new(group_input_001_8.outputs[7], group_5.inputs[5])
	    #group_input_002_7.Material -> group_002_2.Material
	    mesh_hair_selector.links.new(group_input_002_7.outputs[2], group_002_2.inputs[1])
	    #group_input_002_7.Resolution -> group_002_2.Resolution
	    mesh_hair_selector.links.new(group_input_002_7.outputs[3], group_002_2.inputs[3])
	    #group_input_002_7.Width -> group_002_2.Width
	    mesh_hair_selector.links.new(group_input_002_7.outputs[4], group_002_2.inputs[4])
	    #group_input_002_7.Fill Caps -> group_002_2.Fill Caps
	    mesh_hair_selector.links.new(group_input_002_7.outputs[5], group_002_2.inputs[5])
	    #group_input_003_7.Material -> group_003_1.Material
	    mesh_hair_selector.links.new(group_input_003_7.outputs[2], group_003_1.inputs[1])
	    #group_input_003_7.Resolution -> group_003_1.Resolution
	    mesh_hair_selector.links.new(group_input_003_7.outputs[3], group_003_1.inputs[4])
	    #group_input_003_7.Width -> group_003_1.Width
	    mesh_hair_selector.links.new(group_input_003_7.outputs[4], group_003_1.inputs[5])
	    #group_input_003_7.Tube Ribbon Count -> group_003_1.Ribbon Count
	    mesh_hair_selector.links.new(group_input_003_7.outputs[8], group_003_1.inputs[3])
	    #group_input_004_6.Material -> group_001_5.Material
	    mesh_hair_selector.links.new(group_input_004_6.outputs[2], group_001_5.inputs[2])
	    #group_input_004_6.Fill Caps -> group_001_5.Fill Caps
	    mesh_hair_selector.links.new(group_input_004_6.outputs[5], group_001_5.inputs[5])
	    #group_input_004_6.Profile Translation -> group_001_5.Translation
	    mesh_hair_selector.links.new(group_input_004_6.outputs[10], group_001_5.inputs[6])
	    #group_input_004_6.Profile Rotation -> group_001_5.Rotation
	    mesh_hair_selector.links.new(group_input_004_6.outputs[11], group_001_5.inputs[7])
	    #group_input_004_6.Profile Scale -> group_001_5.Scale
	    mesh_hair_selector.links.new(group_input_004_6.outputs[12], group_001_5.inputs[8])
	    #group_input_006_3.Profile Curve -> group_001_5.Profile
	    mesh_hair_selector.links.new(group_input_006_3.outputs[9], group_001_5.inputs[1])
	    #group_input_004_6.Resolution -> group_001_5.Resolution
	    mesh_hair_selector.links.new(group_input_004_6.outputs[3], group_001_5.inputs[4])
	    #compare_5.Result -> switch_6.Switch
	    mesh_hair_selector.links.new(compare_5.outputs[0], switch_6.inputs[0])
	    #compare_001_1.Result -> switch_001_2.Switch
	    mesh_hair_selector.links.new(compare_001_1.outputs[0], switch_001_2.inputs[0])
	    #compare_002_1.Result -> switch_002_1.Switch
	    mesh_hair_selector.links.new(compare_002_1.outputs[0], switch_002_1.inputs[0])
	    #reroute_009_3.Output -> compare_003.A
	    mesh_hair_selector.links.new(reroute_009_3.outputs[0], compare_003.inputs[8])
	    #compare_003.Result -> switch_003_1.Switch
	    mesh_hair_selector.links.new(compare_003.outputs[0], switch_003_1.inputs[0])
	    #switch_001_2.Output -> switch_6.False
	    mesh_hair_selector.links.new(switch_001_2.outputs[0], switch_6.inputs[1])
	    #switch_002_1.Output -> switch_001_2.False
	    mesh_hair_selector.links.new(switch_002_1.outputs[0], switch_001_2.inputs[1])
	    #switch_003_1.Output -> switch_002_1.False
	    mesh_hair_selector.links.new(switch_003_1.outputs[0], switch_002_1.inputs[1])
	    #reroute_004_5.Output -> menu_switch_001.Hair Card
	    mesh_hair_selector.links.new(reroute_004_5.outputs[0], menu_switch_001.inputs[1])
	    #reroute_7.Output -> compare_5.B
	    mesh_hair_selector.links.new(reroute_7.outputs[0], compare_5.inputs[9])
	    #group_5.Geometry -> switch_6.True
	    mesh_hair_selector.links.new(group_5.outputs[0], switch_6.inputs[2])
	    #reroute_005_4.Output -> menu_switch_001.Tube Mesh
	    mesh_hair_selector.links.new(reroute_005_4.outputs[0], menu_switch_001.inputs[2])
	    #reroute_001_6.Output -> compare_001_1.B
	    mesh_hair_selector.links.new(reroute_001_6.outputs[0], compare_001_1.inputs[9])
	    #group_002_2.Geometry -> switch_001_2.True
	    mesh_hair_selector.links.new(group_002_2.outputs[0], switch_001_2.inputs[2])
	    #reroute_006_3.Output -> menu_switch_001.Tube Ribbon
	    mesh_hair_selector.links.new(reroute_006_3.outputs[0], menu_switch_001.inputs[3])
	    #reroute_002_6.Output -> compare_002_1.B
	    mesh_hair_selector.links.new(reroute_002_6.outputs[0], compare_002_1.inputs[9])
	    #group_003_1.Geometry -> switch_002_1.True
	    mesh_hair_selector.links.new(group_003_1.outputs[0], switch_002_1.inputs[2])
	    #reroute_007_3.Output -> menu_switch_001.Stylized
	    mesh_hair_selector.links.new(reroute_007_3.outputs[0], menu_switch_001.inputs[4])
	    #reroute_003_6.Output -> compare_003.B
	    mesh_hair_selector.links.new(reroute_003_6.outputs[0], compare_003.inputs[9])
	    #group_001_5.Geometry -> switch_003_1.True
	    mesh_hair_selector.links.new(group_001_5.outputs[0], switch_003_1.inputs[2])
	    #switch_6.Output -> store_named_attribute_6.Geometry
	    mesh_hair_selector.links.new(switch_6.outputs[0], store_named_attribute_6.inputs[0])
	    #string.String -> reroute_7.Input
	    mesh_hair_selector.links.new(string.outputs[0], reroute_7.inputs[0])
	    #string_001.String -> reroute_001_6.Input
	    mesh_hair_selector.links.new(string_001.outputs[0], reroute_001_6.inputs[0])
	    #string_002.String -> reroute_002_6.Input
	    mesh_hair_selector.links.new(string_002.outputs[0], reroute_002_6.inputs[0])
	    #string_003.String -> reroute_003_6.Input
	    mesh_hair_selector.links.new(string_003.outputs[0], reroute_003_6.inputs[0])
	    #reroute_7.Output -> reroute_004_5.Input
	    mesh_hair_selector.links.new(reroute_7.outputs[0], reroute_004_5.inputs[0])
	    #reroute_001_6.Output -> reroute_005_4.Input
	    mesh_hair_selector.links.new(reroute_001_6.outputs[0], reroute_005_4.inputs[0])
	    #reroute_002_6.Output -> reroute_006_3.Input
	    mesh_hair_selector.links.new(reroute_002_6.outputs[0], reroute_006_3.inputs[0])
	    #reroute_003_6.Output -> reroute_007_3.Input
	    mesh_hair_selector.links.new(reroute_003_6.outputs[0], reroute_007_3.inputs[0])
	    #menu_switch_001.Output -> reroute_008_3.Input
	    mesh_hair_selector.links.new(menu_switch_001.outputs[0], reroute_008_3.inputs[0])
	    #reroute_010_1.Output -> reroute_009_3.Input
	    mesh_hair_selector.links.new(reroute_010_1.outputs[0], reroute_009_3.inputs[0])
	    #reroute_011_1.Output -> reroute_010_1.Input
	    mesh_hair_selector.links.new(reroute_011_1.outputs[0], reroute_010_1.inputs[0])
	    #reroute_010_1.Output -> compare_002_1.A
	    mesh_hair_selector.links.new(reroute_010_1.outputs[0], compare_002_1.inputs[8])
	    #reroute_012_2.Output -> reroute_011_1.Input
	    mesh_hair_selector.links.new(reroute_012_2.outputs[0], reroute_011_1.inputs[0])
	    #reroute_008_3.Output -> reroute_012_2.Input
	    mesh_hair_selector.links.new(reroute_008_3.outputs[0], reroute_012_2.inputs[0])
	    #reroute_011_1.Output -> compare_001_1.A
	    mesh_hair_selector.links.new(reroute_011_1.outputs[0], compare_001_1.inputs[8])
	    #reroute_012_2.Output -> compare_5.A
	    mesh_hair_selector.links.new(reroute_012_2.outputs[0], compare_5.inputs[8])
	    #reroute_014_2.Output -> reroute_013_2.Input
	    mesh_hair_selector.links.new(reroute_014_2.outputs[0], reroute_013_2.inputs[0])
	    #reroute_008_3.Output -> reroute_014_2.Input
	    mesh_hair_selector.links.new(reroute_008_3.outputs[0], reroute_014_2.inputs[0])
	    #store_named_attribute_6.Geometry -> store_named_attribute_001_1.Geometry
	    mesh_hair_selector.links.new(store_named_attribute_6.outputs[0], store_named_attribute_001_1.inputs[0])
	    #group_input_007_3.Mesh Index -> store_named_attribute_001_1.Value
	    mesh_hair_selector.links.new(group_input_007_3.outputs[13], store_named_attribute_001_1.inputs[3])
	    #store_named_attribute_001_1.Geometry -> remove_named_attribute.Geometry
	    mesh_hair_selector.links.new(store_named_attribute_001_1.outputs[0], remove_named_attribute.inputs[0])
	    #reroute_016_2.Output -> remove_named_attribute.Name
	    mesh_hair_selector.links.new(reroute_016_2.outputs[0], remove_named_attribute.inputs[1])
	    #reroute_014_2.Output -> reroute_015_2.Input
	    mesh_hair_selector.links.new(reroute_014_2.outputs[0], reroute_015_2.inputs[0])
	    #reroute_015_2.Output -> reroute_016_2.Input
	    mesh_hair_selector.links.new(reroute_015_2.outputs[0], reroute_016_2.inputs[0])
	    #set_shade_smooth.Geometry -> use_mesh_bake.Geometry
	    mesh_hair_selector.links.new(set_shade_smooth.outputs[0], use_mesh_bake.inputs[0])
	    #remove_named_attribute.Geometry -> set_shade_smooth.Geometry
	    mesh_hair_selector.links.new(remove_named_attribute.outputs[0], set_shade_smooth.inputs[0])
	    #group_input_008_1.Shade Smooth -> set_shade_smooth.Shade Smooth
	    mesh_hair_selector.links.new(group_input_008_1.outputs[6], set_shade_smooth.inputs[2])
	    #spline_parameter_001.Factor -> mesh_overall_shape.Value
	    mesh_hair_selector.links.new(spline_parameter_001.outputs[0], mesh_overall_shape.inputs[1])
	    #group_input_009_1.Fill Caps -> store_named_attribute_002.Value
	    mesh_hair_selector.links.new(group_input_009_1.outputs[5], store_named_attribute_002.inputs[3])
	    #store_named_attribute_002.Geometry -> attribute_statistic.Geometry
	    mesh_hair_selector.links.new(store_named_attribute_002.outputs[0], attribute_statistic.inputs[0])
	    #attribute_statistic.Sum -> compare_005.A
	    mesh_hair_selector.links.new(attribute_statistic.outputs[2], compare_005.inputs[0])
	    #compare_005.Result -> switch_004_1.Switch
	    mesh_hair_selector.links.new(compare_005.outputs[0], switch_004_1.inputs[0])
	    #named_attribute_001_2.Attribute -> attribute_statistic.Attribute
	    mesh_hair_selector.links.new(named_attribute_001_2.outputs[0], attribute_statistic.inputs[2])
	    #mesh_overall_shape.Value -> switch_004_1.True
	    mesh_hair_selector.links.new(mesh_overall_shape.outputs[0], switch_004_1.inputs[2])
	    #group_input_009_1.Fill Caps -> switch_004_1.False
	    mesh_hair_selector.links.new(group_input_009_1.outputs[5], switch_004_1.inputs[1])
	    #group_input_010.Geometry -> store_named_attribute_002.Geometry
	    mesh_hair_selector.links.new(group_input_010.outputs[0], store_named_attribute_002.inputs[0])
	    #switch_004_1.Output -> group_5.Curve Radius
	    mesh_hair_selector.links.new(switch_004_1.outputs[0], group_5.inputs[2])
	    #switch_004_1.Output -> group_002_2.Curve Radius
	    mesh_hair_selector.links.new(switch_004_1.outputs[0], group_002_2.inputs[2])
	    #switch_004_1.Output -> group_003_1.Curve Radius
	    mesh_hair_selector.links.new(switch_004_1.outputs[0], group_003_1.inputs[2])
	    #switch_004_1.Output -> group_001_5.Curve Radius
	    mesh_hair_selector.links.new(switch_004_1.outputs[0], group_001_5.inputs[3])
	    style_select_socket.default_value = 'Hair Card'
	    return mesh_hair_selector
	
	mesh_hair_selector = mesh_hair_selector_node_group()
	
	#initialize spiral_curl_bunz node group
	def spiral_curl_bunz_node_group():
	    spiral_curl_bunz = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "SPIRAL_CURL_BUNZ")
	
	    spiral_curl_bunz.color_tag = 'NONE'
	    spiral_curl_bunz.description = "Create spiral bun | curl from curve."
	    spiral_curl_bunz.default_group_node_width = 140
	    
	
	    spiral_curl_bunz.is_modifier = True
	
	    #spiral_curl_bunz interface
	    #Socket Geometry
	    geometry_socket_23 = spiral_curl_bunz.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_23.attribute_domain = 'POINT'
	    geometry_socket_23.description = "Spiral Buns | Curls."
	
	    #Socket Geometry
	    geometry_socket_24 = spiral_curl_bunz.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_24.attribute_domain = 'POINT'
	    geometry_socket_24.description = "Curve Guide."
	
	    #Socket Surface
	    surface_socket_4 = spiral_curl_bunz.interface.new_socket(name = "Surface", in_out='INPUT', socket_type = 'NodeSocketObject')
	    surface_socket_4.attribute_domain = 'POINT'
	    surface_socket_4.description = "Surface Object to attach to (needs to have matching transforms)"
	
	    #Socket Spiral Style
	    spiral_style_socket_1 = spiral_curl_bunz.interface.new_socket(name = "Spiral Style", in_out='INPUT', socket_type = 'NodeSocketMenu')
	    spiral_style_socket_1.attribute_domain = 'POINT'
	    spiral_style_socket_1.description = "Select Spiral Hair Style."
	
	    #Socket Control Points
	    control_points_socket = spiral_curl_bunz.interface.new_socket(name = "Control Points", in_out='INPUT', socket_type = 'NodeSocketInt')
	    control_points_socket.default_value = 12
	    control_points_socket.min_value = 1
	    control_points_socket.max_value = 1024
	    control_points_socket.subtype = 'NONE'
	    control_points_socket.attribute_domain = 'POINT'
	    control_points_socket.description = "Amount of points for each spiral."
	
	    #Socket Strand Radius
	    strand_radius_socket = spiral_curl_bunz.interface.new_socket(name = "Strand Radius", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    strand_radius_socket.default_value = 0.004999999888241291
	    strand_radius_socket.min_value = 0.0
	    strand_radius_socket.max_value = 3.4028234663852886e+38
	    strand_radius_socket.subtype = 'DISTANCE'
	    strand_radius_socket.attribute_domain = 'POINT'
	    strand_radius_socket.description = "Radius of hair strand."
	
	    #Socket Curve Material
	    curve_material_socket = spiral_curl_bunz.interface.new_socket(name = "Curve Material", in_out='INPUT', socket_type = 'NodeSocketMaterial')
	    curve_material_socket.attribute_domain = 'POINT'
	    curve_material_socket.description = "Material used for hair curve."
	
	    #Socket UV Map
	    uv_map_socket_2 = spiral_curl_bunz.interface.new_socket(name = "UV Map", in_out='INPUT', socket_type = 'NodeSocketString')
	    uv_map_socket_2.default_value = "UVMap"
	    uv_map_socket_2.subtype = 'NONE'
	    uv_map_socket_2.attribute_domain = 'POINT'
	    uv_map_socket_2.description = "Surface UV Map used to attach hair."
	
	    #Socket Blend along Curve
	    blend_along_curve_socket_3 = spiral_curl_bunz.interface.new_socket(name = "Blend along Curve", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    blend_along_curve_socket_3.default_value = 0.05000000074505806
	    blend_along_curve_socket_3.min_value = 0.0
	    blend_along_curve_socket_3.max_value = 1.0
	    blend_along_curve_socket_3.subtype = 'FACTOR'
	    blend_along_curve_socket_3.attribute_domain = 'POINT'
	    blend_along_curve_socket_3.description = "Blend deformation along each curve from the root"
	
	    #Socket Trim Factor
	    trim_factor_socket = spiral_curl_bunz.interface.new_socket(name = "Trim Factor", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    trim_factor_socket.default_value = 1.0
	    trim_factor_socket.min_value = 0.0
	    trim_factor_socket.max_value = 1.0
	    trim_factor_socket.subtype = 'FACTOR'
	    trim_factor_socket.attribute_domain = 'POINT'
	    trim_factor_socket.description = "Percentage of spiral to trim off."
	
	    #Socket Trim by Surface Normal
	    trim_by_surface_normal_socket = spiral_curl_bunz.interface.new_socket(name = "Trim by Surface Normal", in_out='INPUT', socket_type = 'NodeSocketBool')
	    trim_by_surface_normal_socket.default_value = False
	    trim_by_surface_normal_socket.attribute_domain = 'POINT'
	    trim_by_surface_normal_socket.description = "Trim hair by surface normal. Hairs pointing up are trimmed less than hairs pointing down."
	
	    #Panel Curl Settings
	    curl_settings_panel = spiral_curl_bunz.interface.new_panel("Curl Settings", default_closed=True)
	    curl_settings_panel.description = "Settings for Spiral Curls."
	    #Socket Curl XY Angle
	    curl_xy_angle_socket_1 = spiral_curl_bunz.interface.new_socket(name = "Curl XY Angle", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = curl_settings_panel)
	    curl_xy_angle_socket_1.default_value = 0.0
	    curl_xy_angle_socket_1.min_value = -89.0
	    curl_xy_angle_socket_1.max_value = 89.0
	    curl_xy_angle_socket_1.subtype = 'NONE'
	    curl_xy_angle_socket_1.attribute_domain = 'POINT'
	    curl_xy_angle_socket_1.description = "X to Y skew angle. (Spiral Style=Spiral Curl)"
	
	    #Socket Curl XZ Angle
	    curl_xz_angle_socket_1 = spiral_curl_bunz.interface.new_socket(name = "Curl XZ Angle", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = curl_settings_panel)
	    curl_xz_angle_socket_1.default_value = 60.0
	    curl_xz_angle_socket_1.min_value = -89.0
	    curl_xz_angle_socket_1.max_value = 89.0
	    curl_xz_angle_socket_1.subtype = 'NONE'
	    curl_xz_angle_socket_1.attribute_domain = 'POINT'
	    curl_xz_angle_socket_1.description = "X to Z skew angle. (Spiral Style=Spiral Curl)"
	
	    #Socket Curl Rotation
	    curl_rotation_socket_1 = spiral_curl_bunz.interface.new_socket(name = "Curl Rotation", in_out='INPUT', socket_type = 'NodeSocketRotation', parent = curl_settings_panel)
	    curl_rotation_socket_1.default_value = (0.0, 0.0, 0.0)
	    curl_rotation_socket_1.attribute_domain = 'POINT'
	    curl_rotation_socket_1.description = "Spiral curl rotations. (Spiral Style=Spiral Curl)"
	
	    #Socket Curl Scale
	    curl_scale_socket_1 = spiral_curl_bunz.interface.new_socket(name = "Curl Scale", in_out='INPUT', socket_type = 'NodeSocketVector', parent = curl_settings_panel)
	    curl_scale_socket_1.default_value = (1.0, 0.5, 2.3999998569488525)
	    curl_scale_socket_1.min_value = -3.4028234663852886e+38
	    curl_scale_socket_1.max_value = 3.4028234663852886e+38
	    curl_scale_socket_1.subtype = 'XYZ'
	    curl_scale_socket_1.attribute_domain = 'POINT'
	    curl_scale_socket_1.description = "Scale used for spiral curl. (Spiral Style=Spiral Curl)"
	
	
	    #Panel Height Settings
	    height_settings_panel = spiral_curl_bunz.interface.new_panel("Height Settings", default_closed=True)
	    height_settings_panel.description = "Settings for spiral heights."
	    #Socket Tip Height
	    tip_height_socket_2 = spiral_curl_bunz.interface.new_socket(name = "Tip Height", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = height_settings_panel)
	    tip_height_socket_2.default_value = 0.10000000149011612
	    tip_height_socket_2.min_value = -3.4028234663852886e+38
	    tip_height_socket_2.max_value = 3.4028234663852886e+38
	    tip_height_socket_2.subtype = 'DISTANCE'
	    tip_height_socket_2.attribute_domain = 'POINT'
	    tip_height_socket_2.description = "Height of the spiral tip region."
	
	    #Socket Upper Height
	    upper_height_socket_2 = spiral_curl_bunz.interface.new_socket(name = "Upper Height", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = height_settings_panel)
	    upper_height_socket_2.default_value = 0.20000000298023224
	    upper_height_socket_2.min_value = -3.4028234663852886e+38
	    upper_height_socket_2.max_value = 3.4028234663852886e+38
	    upper_height_socket_2.subtype = 'DISTANCE'
	    upper_height_socket_2.attribute_domain = 'POINT'
	    upper_height_socket_2.description = "Height of the spiral upper region. In between the tiip and lower regions."
	
	    #Socket Lower Height
	    lower_height_socket_2 = spiral_curl_bunz.interface.new_socket(name = "Lower Height", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = height_settings_panel)
	    lower_height_socket_2.default_value = 0.20000000298023224
	    lower_height_socket_2.min_value = -3.402820018375656e+38
	    lower_height_socket_2.max_value = 3.4028234663852886e+38
	    lower_height_socket_2.subtype = 'DISTANCE'
	    lower_height_socket_2.attribute_domain = 'POINT'
	    lower_height_socket_2.description = "Height of the spiral lower region. In between the upper and root regions."
	
	    #Socket Root Height
	    root_height_socket_2 = spiral_curl_bunz.interface.new_socket(name = "Root Height", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = height_settings_panel)
	    root_height_socket_2.default_value = 0.0
	    root_height_socket_2.min_value = 0.0
	    root_height_socket_2.max_value = 3.4028234663852886e+38
	    root_height_socket_2.subtype = 'DISTANCE'
	    root_height_socket_2.attribute_domain = 'POINT'
	    root_height_socket_2.description = "Height of the spiral root region."
	
	
	    #Panel Radius Settings
	    radius_settings_panel = spiral_curl_bunz.interface.new_panel("Radius Settings", default_closed=True)
	    radius_settings_panel.description = "Settings for the spiral radius."
	    #Socket Tip Radius
	    tip_radius_socket_2 = spiral_curl_bunz.interface.new_socket(name = "Tip Radius", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = radius_settings_panel)
	    tip_radius_socket_2.default_value = 0.10000000149011612
	    tip_radius_socket_2.min_value = -3.4028234663852886e+38
	    tip_radius_socket_2.max_value = 3.4028234663852886e+38
	    tip_radius_socket_2.subtype = 'DISTANCE'
	    tip_radius_socket_2.attribute_domain = 'POINT'
	    tip_radius_socket_2.description = "Radius of the spiral tip region."
	
	    #Socket Upper Radius
	    upper_radius_socket_2 = spiral_curl_bunz.interface.new_socket(name = "Upper Radius", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = radius_settings_panel)
	    upper_radius_socket_2.default_value = 0.20000000298023224
	    upper_radius_socket_2.min_value = -3.4028234663852886e+38
	    upper_radius_socket_2.max_value = 3.4028234663852886e+38
	    upper_radius_socket_2.subtype = 'DISTANCE'
	    upper_radius_socket_2.attribute_domain = 'POINT'
	    upper_radius_socket_2.description = "Radius of the spiral upper region. In between the tiip and lower regions."
	
	    #Socket Lower Radius
	    lower_radius_socket_2 = spiral_curl_bunz.interface.new_socket(name = "Lower Radius", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = radius_settings_panel)
	    lower_radius_socket_2.default_value = 0.20000000298023224
	    lower_radius_socket_2.min_value = -3.4028234663852886e+38
	    lower_radius_socket_2.max_value = 3.4028234663852886e+38
	    lower_radius_socket_2.subtype = 'DISTANCE'
	    lower_radius_socket_2.attribute_domain = 'POINT'
	    lower_radius_socket_2.description = "Radius of the spiral lower region. In between the upper and root regions."
	
	    #Socket Root Radius
	    root_radius_socket_2 = spiral_curl_bunz.interface.new_socket(name = "Root Radius", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = radius_settings_panel)
	    root_radius_socket_2.default_value = 0.10000000149011612
	    root_radius_socket_2.min_value = -3.4028234663852886e+38
	    root_radius_socket_2.max_value = 3.4028234663852886e+38
	    root_radius_socket_2.subtype = 'DISTANCE'
	    root_radius_socket_2.attribute_domain = 'POINT'
	    root_radius_socket_2.description = "Radius of the spiral root region."
	
	
	    #Panel Rotations Settings
	    rotations_settings_panel = spiral_curl_bunz.interface.new_panel("Rotations Settings", default_closed=True)
	    rotations_settings_panel.description = "Settings for the amount of rotations. (twists)"
	    #Socket Tip Rotations
	    tip_rotations_socket_2 = spiral_curl_bunz.interface.new_socket(name = "Tip Rotations", in_out='INPUT', socket_type = 'NodeSocketInt', parent = rotations_settings_panel)
	    tip_rotations_socket_2.default_value = 1
	    tip_rotations_socket_2.min_value = 1
	    tip_rotations_socket_2.max_value = 2147483647
	    tip_rotations_socket_2.subtype = 'NONE'
	    tip_rotations_socket_2.attribute_domain = 'POINT'
	    tip_rotations_socket_2.description = "Rotations of the spiral tip region."
	
	    #Socket Upper Rotations
	    upper_rotations_socket_2 = spiral_curl_bunz.interface.new_socket(name = "Upper Rotations", in_out='INPUT', socket_type = 'NodeSocketInt', parent = rotations_settings_panel)
	    upper_rotations_socket_2.default_value = 1
	    upper_rotations_socket_2.min_value = 1
	    upper_rotations_socket_2.max_value = 2147483647
	    upper_rotations_socket_2.subtype = 'NONE'
	    upper_rotations_socket_2.attribute_domain = 'POINT'
	    upper_rotations_socket_2.description = "Rotations of the spiral upper region. In between the tiip and lower regions."
	
	    #Socket Lower Rotations
	    lower_rotations_socket_2 = spiral_curl_bunz.interface.new_socket(name = "Lower Rotations", in_out='INPUT', socket_type = 'NodeSocketInt', parent = rotations_settings_panel)
	    lower_rotations_socket_2.default_value = 1
	    lower_rotations_socket_2.min_value = 1
	    lower_rotations_socket_2.max_value = 2147483647
	    lower_rotations_socket_2.subtype = 'NONE'
	    lower_rotations_socket_2.attribute_domain = 'POINT'
	    lower_rotations_socket_2.description = "Rotations of the spiral lower region. In between the upper and root regions."
	
	    #Socket Root Rotations
	    root_rotations_socket_2 = spiral_curl_bunz.interface.new_socket(name = "Root Rotations", in_out='INPUT', socket_type = 'NodeSocketInt', parent = rotations_settings_panel)
	    root_rotations_socket_2.default_value = 1
	    root_rotations_socket_2.min_value = 1
	    root_rotations_socket_2.max_value = 2147483647
	    root_rotations_socket_2.subtype = 'NONE'
	    root_rotations_socket_2.attribute_domain = 'POINT'
	    root_rotations_socket_2.description = "Rotations of the spiral root region."
	
	
	    #Panel Children Settings
	    children_settings_panel = spiral_curl_bunz.interface.new_panel("Children Settings", default_closed=True)
	    children_settings_panel.description = "Settings for duplicate curves."
	    #Socket Duplicate Amount
	    duplicate_amount_socket = spiral_curl_bunz.interface.new_socket(name = "Duplicate Amount", in_out='INPUT', socket_type = 'NodeSocketInt', parent = children_settings_panel)
	    duplicate_amount_socket.default_value = 10
	    duplicate_amount_socket.min_value = 0
	    duplicate_amount_socket.max_value = 2147483647
	    duplicate_amount_socket.subtype = 'NONE'
	    duplicate_amount_socket.attribute_domain = 'POINT'
	    duplicate_amount_socket.description = "Amount of duplicates per curve."
	
	    #Socket Duplicate Viewport Amount
	    duplicate_viewport_amount_socket = spiral_curl_bunz.interface.new_socket(name = "Duplicate Viewport Amount", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = children_settings_panel)
	    duplicate_viewport_amount_socket.default_value = 1.0
	    duplicate_viewport_amount_socket.min_value = 0.0
	    duplicate_viewport_amount_socket.max_value = 1.0
	    duplicate_viewport_amount_socket.subtype = 'FACTOR'
	    duplicate_viewport_amount_socket.attribute_domain = 'POINT'
	    duplicate_viewport_amount_socket.description = "Percentage of amount used for the viewport."
	
	    #Socket Duplicate Radius
	    duplicate_radius_socket = spiral_curl_bunz.interface.new_socket(name = "Duplicate Radius", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = children_settings_panel)
	    duplicate_radius_socket.default_value = 0.10000000149011612
	    duplicate_radius_socket.min_value = 0.0
	    duplicate_radius_socket.max_value = 3.4028234663852886e+38
	    duplicate_radius_socket.subtype = 'DISTANCE'
	    duplicate_radius_socket.attribute_domain = 'POINT'
	    duplicate_radius_socket.description = "Radius in which the duplicate curves are offset from the guides."
	
	    #Socket Duplicate Distribution Shape
	    duplicate_distribution_shape_socket = spiral_curl_bunz.interface.new_socket(name = "Duplicate Distribution Shape", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = children_settings_panel)
	    duplicate_distribution_shape_socket.default_value = 0.0
	    duplicate_distribution_shape_socket.min_value = -10.0
	    duplicate_distribution_shape_socket.max_value = 10.0
	    duplicate_distribution_shape_socket.subtype = 'NONE'
	    duplicate_distribution_shape_socket.attribute_domain = 'POINT'
	    duplicate_distribution_shape_socket.description = "Shape of distribution from center to the edge around the guide."
	
	    #Socket Duplicate Tip Roundness
	    duplicate_tip_roundness_socket = spiral_curl_bunz.interface.new_socket(name = "Duplicate Tip Roundness", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = children_settings_panel)
	    duplicate_tip_roundness_socket.default_value = 0.0
	    duplicate_tip_roundness_socket.min_value = 0.0
	    duplicate_tip_roundness_socket.max_value = 1.0
	    duplicate_tip_roundness_socket.subtype = 'FACTOR'
	    duplicate_tip_roundness_socket.attribute_domain = 'POINT'
	    duplicate_tip_roundness_socket.description = "Offset of the curves to round the tip."
	
	    #Socket Duplicate Even Thickness
	    duplicate_even_thickness_socket = spiral_curl_bunz.interface.new_socket(name = "Duplicate Even Thickness", in_out='INPUT', socket_type = 'NodeSocketBool', parent = children_settings_panel)
	    duplicate_even_thickness_socket.default_value = False
	    duplicate_even_thickness_socket.attribute_domain = 'POINT'
	    duplicate_even_thickness_socket.description = "Keep an even thickness of the distribution of duplicates."
	
	    #Socket Duplicate Seed
	    duplicate_seed_socket = spiral_curl_bunz.interface.new_socket(name = "Duplicate Seed", in_out='INPUT', socket_type = 'NodeSocketInt', parent = children_settings_panel)
	    duplicate_seed_socket.default_value = 0
	    duplicate_seed_socket.min_value = -10000
	    duplicate_seed_socket.max_value = 10000
	    duplicate_seed_socket.subtype = 'NONE'
	    duplicate_seed_socket.attribute_domain = 'POINT'
	    duplicate_seed_socket.description = "Random Seed for curve duplicates."
	
	
	    #Panel Mesh Settings
	    mesh_settings_panel = spiral_curl_bunz.interface.new_panel("Mesh Settings", default_closed=True)
	    mesh_settings_panel.description = "Settings for mesh parameters."
	    #Socket Use Mesh
	    use_mesh_socket = spiral_curl_bunz.interface.new_socket(name = "Use Mesh", in_out='INPUT', socket_type = 'NodeSocketBool', parent = mesh_settings_panel)
	    use_mesh_socket.default_value = False
	    use_mesh_socket.attribute_domain = 'POINT'
	    use_mesh_socket.description = "Convert spiral bun to mesh."
	
	    #Socket Shade Smooth
	    shade_smooth_socket_1 = spiral_curl_bunz.interface.new_socket(name = "Shade Smooth", in_out='INPUT', socket_type = 'NodeSocketBool', parent = mesh_settings_panel)
	    shade_smooth_socket_1.default_value = False
	    shade_smooth_socket_1.attribute_domain = 'POINT'
	    shade_smooth_socket_1.description = "Use Smooth Shade for mesh."
	
	    #Socket Style Select
	    style_select_socket_1 = spiral_curl_bunz.interface.new_socket(name = "Style Select", in_out='INPUT', socket_type = 'NodeSocketMenu', parent = mesh_settings_panel)
	    style_select_socket_1.attribute_domain = 'POINT'
	    style_select_socket_1.description = "Mesh style to convert curve."
	
	    #Socket Mesh Material
	    mesh_material_socket = spiral_curl_bunz.interface.new_socket(name = "Mesh Material", in_out='INPUT', socket_type = 'NodeSocketMaterial', parent = mesh_settings_panel)
	    mesh_material_socket.attribute_domain = 'POINT'
	    mesh_material_socket.description = "Material used for mesh."
	
	    #Socket Resolution
	    resolution_socket_7 = spiral_curl_bunz.interface.new_socket(name = "Resolution", in_out='INPUT', socket_type = 'NodeSocketInt', parent = mesh_settings_panel)
	    resolution_socket_7.default_value = 0
	    resolution_socket_7.min_value = 2
	    resolution_socket_7.max_value = 512
	    resolution_socket_7.subtype = 'NONE'
	    resolution_socket_7.attribute_domain = 'POINT'
	    resolution_socket_7.description = "Control mesh smoothness by add and removing points along curve."
	
	    #Socket Width
	    width_socket_4 = spiral_curl_bunz.interface.new_socket(name = "Width", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = mesh_settings_panel)
	    width_socket_4.default_value = 0.009999999776482582
	    width_socket_4.min_value = 0.0
	    width_socket_4.max_value = 3.4028234663852886e+38
	    width_socket_4.subtype = 'DISTANCE'
	    width_socket_4.attribute_domain = 'POINT'
	    width_socket_4.description = "Width of mesh object."
	
	    #Socket Fill Caps
	    fill_caps_socket_3 = spiral_curl_bunz.interface.new_socket(name = "Fill Caps", in_out='INPUT', socket_type = 'NodeSocketBool', parent = mesh_settings_panel)
	    fill_caps_socket_3.default_value = False
	    fill_caps_socket_3.attribute_domain = 'POINT'
	    fill_caps_socket_3.description = "Fill openings with mesh surface. (Used only for [Tube Mesh | Stylized] mesh styles)"
	
	    #Socket Hair Card Angle
	    hair_card_angle_socket_1 = spiral_curl_bunz.interface.new_socket(name = "Hair Card Angle", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = mesh_settings_panel)
	    hair_card_angle_socket_1.default_value = 0.0
	    hair_card_angle_socket_1.min_value = -90.0
	    hair_card_angle_socket_1.max_value = 90.0
	    hair_card_angle_socket_1.subtype = 'ANGLE'
	    hair_card_angle_socket_1.attribute_domain = 'POINT'
	    hair_card_angle_socket_1.description = "Angle used to bend hair card. (Mesh Style=Hair Card)"
	
	    #Socket Tube Ribbon Count
	    tube_ribbon_count_socket_1 = spiral_curl_bunz.interface.new_socket(name = "Tube Ribbon Count", in_out='INPUT', socket_type = 'NodeSocketInt', parent = mesh_settings_panel)
	    tube_ribbon_count_socket_1.default_value = 8
	    tube_ribbon_count_socket_1.min_value = 1
	    tube_ribbon_count_socket_1.max_value = 180
	    tube_ribbon_count_socket_1.subtype = 'NONE'
	    tube_ribbon_count_socket_1.attribute_domain = 'POINT'
	    tube_ribbon_count_socket_1.description = "Amount of billboard like hair cards used to shape hair. (Mesh Style=Tube Ribbon)"
	
	    #Socket Profile Curve
	    profile_curve_socket_1 = spiral_curl_bunz.interface.new_socket(name = "Profile Curve", in_out='INPUT', socket_type = 'NodeSocketObject', parent = mesh_settings_panel)
	    profile_curve_socket_1.attribute_domain = 'POINT'
	    profile_curve_socket_1.description = "Curve object used as the profile for stylized hair. (Mesh Style=Stylized)"
	
	    #Socket Profile Translation
	    profile_translation_socket_1 = spiral_curl_bunz.interface.new_socket(name = "Profile Translation", in_out='INPUT', socket_type = 'NodeSocketVector', parent = mesh_settings_panel)
	    profile_translation_socket_1.default_value = (0.0, 0.0, 0.0)
	    profile_translation_socket_1.min_value = -3.4028234663852886e+38
	    profile_translation_socket_1.max_value = 3.4028234663852886e+38
	    profile_translation_socket_1.subtype = 'TRANSLATION'
	    profile_translation_socket_1.attribute_domain = 'POINT'
	    profile_translation_socket_1.description = "Move position of stylized profile from origin. (Mesh Style=Stylized)"
	
	    #Socket Profile Rotation
	    profile_rotation_socket_1 = spiral_curl_bunz.interface.new_socket(name = "Profile Rotation", in_out='INPUT', socket_type = 'NodeSocketRotation', parent = mesh_settings_panel)
	    profile_rotation_socket_1.default_value = (0.0, 0.0, 0.0)
	    profile_rotation_socket_1.attribute_domain = 'POINT'
	    profile_rotation_socket_1.description = "Rotate the stylized profile from origin. (Mesh Style=Stylized)"
	
	    #Socket Profile Scale
	    profile_scale_socket_1 = spiral_curl_bunz.interface.new_socket(name = "Profile Scale", in_out='INPUT', socket_type = 'NodeSocketVector', parent = mesh_settings_panel)
	    profile_scale_socket_1.default_value = (1.0, 1.0, 1.0)
	    profile_scale_socket_1.min_value = -3.4028234663852886e+38
	    profile_scale_socket_1.max_value = 3.4028234663852886e+38
	    profile_scale_socket_1.subtype = 'XYZ'
	    profile_scale_socket_1.attribute_domain = 'POINT'
	    profile_scale_socket_1.description = "Scale the stylized profile from origin. (Mesh Style=Stylized)"
	
	
	
	    #initialize spiral_curl_bunz nodes
	    #node Group Input
	    group_input_12 = spiral_curl_bunz.nodes.new("NodeGroupInput")
	    group_input_12.name = "Group Input"
	    group_input_12.outputs[1].hide = True
	    group_input_12.outputs[4].hide = True
	    group_input_12.outputs[5].hide = True
	    group_input_12.outputs[6].hide = True
	    group_input_12.outputs[7].hide = True
	    group_input_12.outputs[8].hide = True
	    group_input_12.outputs[9].hide = True
	    group_input_12.outputs[10].hide = True
	    group_input_12.outputs[11].hide = True
	    group_input_12.outputs[12].hide = True
	    group_input_12.outputs[13].hide = True
	    group_input_12.outputs[26].hide = True
	    group_input_12.outputs[27].hide = True
	    group_input_12.outputs[28].hide = True
	    group_input_12.outputs[29].hide = True
	    group_input_12.outputs[30].hide = True
	    group_input_12.outputs[31].hide = True
	    group_input_12.outputs[32].hide = True
	    group_input_12.outputs[33].hide = True
	    group_input_12.outputs[34].hide = True
	    group_input_12.outputs[35].hide = True
	    group_input_12.outputs[36].hide = True
	    group_input_12.outputs[37].hide = True
	    group_input_12.outputs[38].hide = True
	    group_input_12.outputs[39].hide = True
	    group_input_12.outputs[40].hide = True
	    group_input_12.outputs[41].hide = True
	    group_input_12.outputs[42].hide = True
	    group_input_12.outputs[43].hide = True
	    group_input_12.outputs[44].hide = True
	    group_input_12.outputs[45].hide = True
	    group_input_12.outputs[46].hide = True
	
	    #node Group Output
	    group_output_17 = spiral_curl_bunz.nodes.new("NodeGroupOutput")
	    group_output_17.name = "Group Output"
	    group_output_17.is_active_output = True
	    group_output_17.inputs[1].hide = True
	
	    #node Group.004
	    group_004 = spiral_curl_bunz.nodes.new("GeometryNodeGroup")
	    group_004.name = "Group.004"
	    group_004.node_tree = duplicate_hair_curves
	
	    #node Group.003
	    group_003_2 = spiral_curl_bunz.nodes.new("GeometryNodeGroup")
	    group_003_2.name = "Group.003"
	    group_003_2.node_tree = spiral_twist_1
	
	    #node Reroute
	    reroute_8 = spiral_curl_bunz.nodes.new("NodeReroute")
	    reroute_8.name = "Reroute"
	    reroute_8.socket_idname = "NodeSocketGeometry"
	    #node Group Input.002
	    group_input_002_8 = spiral_curl_bunz.nodes.new("NodeGroupInput")
	    group_input_002_8.name = "Group Input.002"
	    group_input_002_8.outputs[0].hide = True
	    group_input_002_8.outputs[1].hide = True
	    group_input_002_8.outputs[2].hide = True
	    group_input_002_8.outputs[3].hide = True
	    group_input_002_8.outputs[4].hide = True
	    group_input_002_8.outputs[5].hide = True
	    group_input_002_8.outputs[6].hide = True
	    group_input_002_8.outputs[7].hide = True
	    group_input_002_8.outputs[8].hide = True
	    group_input_002_8.outputs[9].hide = True
	    group_input_002_8.outputs[10].hide = True
	    group_input_002_8.outputs[11].hide = True
	    group_input_002_8.outputs[12].hide = True
	    group_input_002_8.outputs[13].hide = True
	    group_input_002_8.outputs[14].hide = True
	    group_input_002_8.outputs[15].hide = True
	    group_input_002_8.outputs[16].hide = True
	    group_input_002_8.outputs[17].hide = True
	    group_input_002_8.outputs[18].hide = True
	    group_input_002_8.outputs[19].hide = True
	    group_input_002_8.outputs[20].hide = True
	    group_input_002_8.outputs[21].hide = True
	    group_input_002_8.outputs[22].hide = True
	    group_input_002_8.outputs[23].hide = True
	    group_input_002_8.outputs[24].hide = True
	    group_input_002_8.outputs[25].hide = True
	    group_input_002_8.outputs[33].hide = True
	    group_input_002_8.outputs[34].hide = True
	    group_input_002_8.outputs[35].hide = True
	    group_input_002_8.outputs[36].hide = True
	    group_input_002_8.outputs[37].hide = True
	    group_input_002_8.outputs[38].hide = True
	    group_input_002_8.outputs[39].hide = True
	    group_input_002_8.outputs[40].hide = True
	    group_input_002_8.outputs[41].hide = True
	    group_input_002_8.outputs[42].hide = True
	    group_input_002_8.outputs[43].hide = True
	    group_input_002_8.outputs[44].hide = True
	    group_input_002_8.outputs[45].hide = True
	    group_input_002_8.outputs[46].hide = True
	
	    #node Group Input.003
	    group_input_003_8 = spiral_curl_bunz.nodes.new("NodeGroupInput")
	    group_input_003_8.name = "Group Input.003"
	    group_input_003_8.outputs[0].hide = True
	    group_input_003_8.outputs[1].hide = True
	    group_input_003_8.outputs[2].hide = True
	    group_input_003_8.outputs[3].hide = True
	    group_input_003_8.outputs[4].hide = True
	    group_input_003_8.outputs[5].hide = True
	    group_input_003_8.outputs[6].hide = True
	    group_input_003_8.outputs[7].hide = True
	    group_input_003_8.outputs[8].hide = True
	    group_input_003_8.outputs[9].hide = True
	    group_input_003_8.outputs[10].hide = True
	    group_input_003_8.outputs[11].hide = True
	    group_input_003_8.outputs[12].hide = True
	    group_input_003_8.outputs[13].hide = True
	    group_input_003_8.outputs[14].hide = True
	    group_input_003_8.outputs[15].hide = True
	    group_input_003_8.outputs[16].hide = True
	    group_input_003_8.outputs[17].hide = True
	    group_input_003_8.outputs[18].hide = True
	    group_input_003_8.outputs[19].hide = True
	    group_input_003_8.outputs[20].hide = True
	    group_input_003_8.outputs[21].hide = True
	    group_input_003_8.outputs[22].hide = True
	    group_input_003_8.outputs[23].hide = True
	    group_input_003_8.outputs[24].hide = True
	    group_input_003_8.outputs[25].hide = True
	    group_input_003_8.outputs[26].hide = True
	    group_input_003_8.outputs[27].hide = True
	    group_input_003_8.outputs[28].hide = True
	    group_input_003_8.outputs[29].hide = True
	    group_input_003_8.outputs[30].hide = True
	    group_input_003_8.outputs[31].hide = True
	    group_input_003_8.outputs[32].hide = True
	    group_input_003_8.outputs[33].hide = True
	    group_input_003_8.outputs[46].hide = True
	
	    #node Switch
	    switch_7 = spiral_curl_bunz.nodes.new("GeometryNodeSwitch")
	    switch_7.name = "Switch"
	    switch_7.hide = True
	    switch_7.input_type = 'GEOMETRY'
	
	    #node Switch.001
	    switch_001_3 = spiral_curl_bunz.nodes.new("GeometryNodeSwitch")
	    switch_001_3.name = "Switch.001"
	    switch_001_3.hide = True
	    switch_001_3.input_type = 'GEOMETRY'
	
	    #node Group Input.004
	    group_input_004_7 = spiral_curl_bunz.nodes.new("NodeGroupInput")
	    group_input_004_7.name = "Group Input.004"
	    group_input_004_7.outputs[0].hide = True
	    group_input_004_7.outputs[1].hide = True
	    group_input_004_7.outputs[2].hide = True
	    group_input_004_7.outputs[3].hide = True
	    group_input_004_7.outputs[4].hide = True
	    group_input_004_7.outputs[5].hide = True
	    group_input_004_7.outputs[6].hide = True
	    group_input_004_7.outputs[7].hide = True
	    group_input_004_7.outputs[8].hide = True
	    group_input_004_7.outputs[9].hide = True
	    group_input_004_7.outputs[10].hide = True
	    group_input_004_7.outputs[11].hide = True
	    group_input_004_7.outputs[12].hide = True
	    group_input_004_7.outputs[13].hide = True
	    group_input_004_7.outputs[14].hide = True
	    group_input_004_7.outputs[15].hide = True
	    group_input_004_7.outputs[16].hide = True
	    group_input_004_7.outputs[17].hide = True
	    group_input_004_7.outputs[18].hide = True
	    group_input_004_7.outputs[19].hide = True
	    group_input_004_7.outputs[20].hide = True
	    group_input_004_7.outputs[21].hide = True
	    group_input_004_7.outputs[22].hide = True
	    group_input_004_7.outputs[23].hide = True
	    group_input_004_7.outputs[24].hide = True
	    group_input_004_7.outputs[25].hide = True
	    group_input_004_7.outputs[27].hide = True
	    group_input_004_7.outputs[28].hide = True
	    group_input_004_7.outputs[29].hide = True
	    group_input_004_7.outputs[30].hide = True
	    group_input_004_7.outputs[31].hide = True
	    group_input_004_7.outputs[32].hide = True
	    group_input_004_7.outputs[33].hide = True
	    group_input_004_7.outputs[34].hide = True
	    group_input_004_7.outputs[35].hide = True
	    group_input_004_7.outputs[36].hide = True
	    group_input_004_7.outputs[37].hide = True
	    group_input_004_7.outputs[38].hide = True
	    group_input_004_7.outputs[39].hide = True
	    group_input_004_7.outputs[40].hide = True
	    group_input_004_7.outputs[41].hide = True
	    group_input_004_7.outputs[42].hide = True
	    group_input_004_7.outputs[43].hide = True
	    group_input_004_7.outputs[44].hide = True
	    group_input_004_7.outputs[45].hide = True
	    group_input_004_7.outputs[46].hide = True
	
	    #node Compare
	    compare_6 = spiral_curl_bunz.nodes.new("FunctionNodeCompare")
	    compare_6.name = "Compare"
	    compare_6.hide = True
	    compare_6.data_type = 'INT'
	    compare_6.mode = 'ELEMENT'
	    compare_6.operation = 'GREATER_THAN'
	    compare_6.inputs[0].hide = True
	    compare_6.inputs[1].hide = True
	    compare_6.inputs[3].hide = True
	    compare_6.inputs[4].hide = True
	    compare_6.inputs[5].hide = True
	    compare_6.inputs[6].hide = True
	    compare_6.inputs[7].hide = True
	    compare_6.inputs[8].hide = True
	    compare_6.inputs[9].hide = True
	    compare_6.inputs[10].hide = True
	    compare_6.inputs[11].hide = True
	    compare_6.inputs[12].hide = True
	    #B_INT
	    compare_6.inputs[3].default_value = 0
	
	    #node Group Input.005
	    group_input_005_6 = spiral_curl_bunz.nodes.new("NodeGroupInput")
	    group_input_005_6.name = "Group Input.005"
	    group_input_005_6.outputs[0].hide = True
	    group_input_005_6.outputs[1].hide = True
	    group_input_005_6.outputs[2].hide = True
	    group_input_005_6.outputs[3].hide = True
	    group_input_005_6.outputs[4].hide = True
	    group_input_005_6.outputs[5].hide = True
	    group_input_005_6.outputs[6].hide = True
	    group_input_005_6.outputs[7].hide = True
	    group_input_005_6.outputs[8].hide = True
	    group_input_005_6.outputs[9].hide = True
	    group_input_005_6.outputs[10].hide = True
	    group_input_005_6.outputs[11].hide = True
	    group_input_005_6.outputs[12].hide = True
	    group_input_005_6.outputs[13].hide = True
	    group_input_005_6.outputs[14].hide = True
	    group_input_005_6.outputs[15].hide = True
	    group_input_005_6.outputs[16].hide = True
	    group_input_005_6.outputs[17].hide = True
	    group_input_005_6.outputs[18].hide = True
	    group_input_005_6.outputs[19].hide = True
	    group_input_005_6.outputs[20].hide = True
	    group_input_005_6.outputs[21].hide = True
	    group_input_005_6.outputs[22].hide = True
	    group_input_005_6.outputs[23].hide = True
	    group_input_005_6.outputs[24].hide = True
	    group_input_005_6.outputs[25].hide = True
	    group_input_005_6.outputs[26].hide = True
	    group_input_005_6.outputs[27].hide = True
	    group_input_005_6.outputs[28].hide = True
	    group_input_005_6.outputs[29].hide = True
	    group_input_005_6.outputs[30].hide = True
	    group_input_005_6.outputs[31].hide = True
	    group_input_005_6.outputs[32].hide = True
	    group_input_005_6.outputs[34].hide = True
	    group_input_005_6.outputs[35].hide = True
	    group_input_005_6.outputs[36].hide = True
	    group_input_005_6.outputs[37].hide = True
	    group_input_005_6.outputs[38].hide = True
	    group_input_005_6.outputs[39].hide = True
	    group_input_005_6.outputs[40].hide = True
	    group_input_005_6.outputs[41].hide = True
	    group_input_005_6.outputs[42].hide = True
	    group_input_005_6.outputs[43].hide = True
	    group_input_005_6.outputs[44].hide = True
	    group_input_005_6.outputs[45].hide = True
	    group_input_005_6.outputs[46].hide = True
	
	    #node Set Material
	    set_material_4 = spiral_curl_bunz.nodes.new("GeometryNodeSetMaterial")
	    set_material_4.name = "Set Material"
	    set_material_4.inputs[1].hide = True
	    #Selection
	    set_material_4.inputs[1].default_value = True
	
	    #node Reroute.001
	    reroute_001_7 = spiral_curl_bunz.nodes.new("NodeReroute")
	    reroute_001_7.name = "Reroute.001"
	    reroute_001_7.socket_idname = "NodeSocketGeometry"
	    #node Group Input.006
	    group_input_006_4 = spiral_curl_bunz.nodes.new("NodeGroupInput")
	    group_input_006_4.name = "Group Input.006"
	    group_input_006_4.outputs[0].hide = True
	    group_input_006_4.outputs[1].hide = True
	    group_input_006_4.outputs[2].hide = True
	    group_input_006_4.outputs[3].hide = True
	    group_input_006_4.outputs[4].hide = True
	    group_input_006_4.outputs[6].hide = True
	    group_input_006_4.outputs[7].hide = True
	    group_input_006_4.outputs[8].hide = True
	    group_input_006_4.outputs[9].hide = True
	    group_input_006_4.outputs[10].hide = True
	    group_input_006_4.outputs[11].hide = True
	    group_input_006_4.outputs[12].hide = True
	    group_input_006_4.outputs[13].hide = True
	    group_input_006_4.outputs[14].hide = True
	    group_input_006_4.outputs[15].hide = True
	    group_input_006_4.outputs[16].hide = True
	    group_input_006_4.outputs[17].hide = True
	    group_input_006_4.outputs[18].hide = True
	    group_input_006_4.outputs[19].hide = True
	    group_input_006_4.outputs[20].hide = True
	    group_input_006_4.outputs[21].hide = True
	    group_input_006_4.outputs[22].hide = True
	    group_input_006_4.outputs[23].hide = True
	    group_input_006_4.outputs[24].hide = True
	    group_input_006_4.outputs[25].hide = True
	    group_input_006_4.outputs[26].hide = True
	    group_input_006_4.outputs[27].hide = True
	    group_input_006_4.outputs[28].hide = True
	    group_input_006_4.outputs[29].hide = True
	    group_input_006_4.outputs[30].hide = True
	    group_input_006_4.outputs[31].hide = True
	    group_input_006_4.outputs[32].hide = True
	    group_input_006_4.outputs[33].hide = True
	    group_input_006_4.outputs[34].hide = True
	    group_input_006_4.outputs[35].hide = True
	    group_input_006_4.outputs[36].hide = True
	    group_input_006_4.outputs[37].hide = True
	    group_input_006_4.outputs[38].hide = True
	    group_input_006_4.outputs[39].hide = True
	    group_input_006_4.outputs[40].hide = True
	    group_input_006_4.outputs[41].hide = True
	    group_input_006_4.outputs[42].hide = True
	    group_input_006_4.outputs[43].hide = True
	    group_input_006_4.outputs[44].hide = True
	    group_input_006_4.outputs[45].hide = True
	    group_input_006_4.outputs[46].hide = True
	
	    #node Set Curve Radius
	    set_curve_radius_4 = spiral_curl_bunz.nodes.new("GeometryNodeSetCurveRadius")
	    set_curve_radius_4.name = "Set Curve Radius"
	    set_curve_radius_4.inputs[1].hide = True
	    #Selection
	    set_curve_radius_4.inputs[1].default_value = True
	
	    #node Strand Shape
	    strand_shape = spiral_curl_bunz.nodes.new("ShaderNodeFloatCurve")
	    strand_shape.label = "Strand Shape"
	    strand_shape.name = "Strand Shape"
	    #mapping settings
	    strand_shape.mapping.extend = 'EXTRAPOLATED'
	    strand_shape.mapping.tone = 'STANDARD'
	    strand_shape.mapping.black_level = (0.0, 0.0, 0.0)
	    strand_shape.mapping.white_level = (1.0, 1.0, 1.0)
	    strand_shape.mapping.clip_min_x = 0.0
	    strand_shape.mapping.clip_min_y = 0.0
	    strand_shape.mapping.clip_max_x = 1.0
	    strand_shape.mapping.clip_max_y = 1.0
	    strand_shape.mapping.use_clip = True
	    #curve 0
	    strand_shape_curve_0 = strand_shape.mapping.curves[0]
	    strand_shape_curve_0_point_0 = strand_shape_curve_0.points[0]
	    strand_shape_curve_0_point_0.location = (0.0, 0.5)
	    strand_shape_curve_0_point_0.handle_type = 'AUTO'
	    strand_shape_curve_0_point_1 = strand_shape_curve_0.points[1]
	    strand_shape_curve_0_point_1.location = (0.03393665328621864, 1.0)
	    strand_shape_curve_0_point_1.handle_type = 'AUTO'
	    strand_shape_curve_0_point_2 = strand_shape_curve_0.points.new(0.9638009071350098, 1.0)
	    strand_shape_curve_0_point_2.handle_type = 'AUTO'
	    strand_shape_curve_0_point_3 = strand_shape_curve_0.points.new(1.0, 0.0)
	    strand_shape_curve_0_point_3.handle_type = 'AUTO'
	    #update curve after changes
	    strand_shape.mapping.update()
	    strand_shape.inputs[0].hide = True
	    #Factor
	    strand_shape.inputs[0].default_value = 1.0
	
	    #node Spline Parameter.001
	    spline_parameter_001_1 = spiral_curl_bunz.nodes.new("GeometryNodeSplineParameter")
	    spline_parameter_001_1.name = "Spline Parameter.001"
	    spline_parameter_001_1.outputs[1].hide = True
	    spline_parameter_001_1.outputs[2].hide = True
	
	    #node Map Range
	    map_range_1 = spiral_curl_bunz.nodes.new("ShaderNodeMapRange")
	    map_range_1.name = "Map Range"
	    map_range_1.hide = True
	    map_range_1.clamp = True
	    map_range_1.data_type = 'FLOAT'
	    map_range_1.interpolation_type = 'LINEAR'
	    map_range_1.inputs[1].hide = True
	    map_range_1.inputs[2].hide = True
	    map_range_1.inputs[3].hide = True
	    map_range_1.inputs[5].hide = True
	    map_range_1.inputs[6].hide = True
	    map_range_1.inputs[7].hide = True
	    map_range_1.inputs[8].hide = True
	    map_range_1.inputs[9].hide = True
	    map_range_1.inputs[10].hide = True
	    map_range_1.inputs[11].hide = True
	    map_range_1.outputs[1].hide = True
	    #From Min
	    map_range_1.inputs[1].default_value = 0.0
	    #From Max
	    map_range_1.inputs[2].default_value = 1.0
	    #To Min
	    map_range_1.inputs[3].default_value = 0.0
	
	    #node Group Input.001
	    group_input_001_9 = spiral_curl_bunz.nodes.new("NodeGroupInput")
	    group_input_001_9.name = "Group Input.001"
	    group_input_001_9.outputs[0].hide = True
	    group_input_001_9.outputs[1].hide = True
	    group_input_001_9.outputs[2].hide = True
	    group_input_001_9.outputs[3].hide = True
	    group_input_001_9.outputs[5].hide = True
	    group_input_001_9.outputs[6].hide = True
	    group_input_001_9.outputs[7].hide = True
	    group_input_001_9.outputs[8].hide = True
	    group_input_001_9.outputs[9].hide = True
	    group_input_001_9.outputs[10].hide = True
	    group_input_001_9.outputs[11].hide = True
	    group_input_001_9.outputs[12].hide = True
	    group_input_001_9.outputs[13].hide = True
	    group_input_001_9.outputs[14].hide = True
	    group_input_001_9.outputs[15].hide = True
	    group_input_001_9.outputs[16].hide = True
	    group_input_001_9.outputs[17].hide = True
	    group_input_001_9.outputs[18].hide = True
	    group_input_001_9.outputs[19].hide = True
	    group_input_001_9.outputs[20].hide = True
	    group_input_001_9.outputs[21].hide = True
	    group_input_001_9.outputs[22].hide = True
	    group_input_001_9.outputs[23].hide = True
	    group_input_001_9.outputs[24].hide = True
	    group_input_001_9.outputs[25].hide = True
	    group_input_001_9.outputs[26].hide = True
	    group_input_001_9.outputs[27].hide = True
	    group_input_001_9.outputs[28].hide = True
	    group_input_001_9.outputs[29].hide = True
	    group_input_001_9.outputs[30].hide = True
	    group_input_001_9.outputs[31].hide = True
	    group_input_001_9.outputs[32].hide = True
	    group_input_001_9.outputs[33].hide = True
	    group_input_001_9.outputs[34].hide = True
	    group_input_001_9.outputs[35].hide = True
	    group_input_001_9.outputs[36].hide = True
	    group_input_001_9.outputs[37].hide = True
	    group_input_001_9.outputs[38].hide = True
	    group_input_001_9.outputs[39].hide = True
	    group_input_001_9.outputs[40].hide = True
	    group_input_001_9.outputs[41].hide = True
	    group_input_001_9.outputs[42].hide = True
	    group_input_001_9.outputs[43].hide = True
	    group_input_001_9.outputs[44].hide = True
	    group_input_001_9.outputs[45].hide = True
	    group_input_001_9.outputs[46].hide = True
	
	    #node Group
	    group_6 = spiral_curl_bunz.nodes.new("GeometryNodeGroup")
	    group_6.name = "Group"
	    group_6.node_tree = attach_hair
	
	    #node Group Input.007
	    group_input_007_4 = spiral_curl_bunz.nodes.new("NodeGroupInput")
	    group_input_007_4.name = "Group Input.007"
	    group_input_007_4.outputs[0].hide = True
	    group_input_007_4.outputs[2].hide = True
	    group_input_007_4.outputs[3].hide = True
	    group_input_007_4.outputs[4].hide = True
	    group_input_007_4.outputs[5].hide = True
	    group_input_007_4.outputs[8].hide = True
	    group_input_007_4.outputs[9].hide = True
	    group_input_007_4.outputs[10].hide = True
	    group_input_007_4.outputs[11].hide = True
	    group_input_007_4.outputs[12].hide = True
	    group_input_007_4.outputs[13].hide = True
	    group_input_007_4.outputs[14].hide = True
	    group_input_007_4.outputs[15].hide = True
	    group_input_007_4.outputs[16].hide = True
	    group_input_007_4.outputs[17].hide = True
	    group_input_007_4.outputs[18].hide = True
	    group_input_007_4.outputs[19].hide = True
	    group_input_007_4.outputs[20].hide = True
	    group_input_007_4.outputs[21].hide = True
	    group_input_007_4.outputs[22].hide = True
	    group_input_007_4.outputs[23].hide = True
	    group_input_007_4.outputs[24].hide = True
	    group_input_007_4.outputs[25].hide = True
	    group_input_007_4.outputs[26].hide = True
	    group_input_007_4.outputs[27].hide = True
	    group_input_007_4.outputs[28].hide = True
	    group_input_007_4.outputs[29].hide = True
	    group_input_007_4.outputs[30].hide = True
	    group_input_007_4.outputs[31].hide = True
	    group_input_007_4.outputs[32].hide = True
	    group_input_007_4.outputs[33].hide = True
	    group_input_007_4.outputs[34].hide = True
	    group_input_007_4.outputs[35].hide = True
	    group_input_007_4.outputs[36].hide = True
	    group_input_007_4.outputs[37].hide = True
	    group_input_007_4.outputs[38].hide = True
	    group_input_007_4.outputs[39].hide = True
	    group_input_007_4.outputs[40].hide = True
	    group_input_007_4.outputs[41].hide = True
	    group_input_007_4.outputs[42].hide = True
	    group_input_007_4.outputs[43].hide = True
	    group_input_007_4.outputs[44].hide = True
	    group_input_007_4.outputs[45].hide = True
	    group_input_007_4.outputs[46].hide = True
	
	    #node Reroute.003
	    reroute_003_7 = spiral_curl_bunz.nodes.new("NodeReroute")
	    reroute_003_7.name = "Reroute.003"
	    reroute_003_7.socket_idname = "NodeSocketGeometry"
	    #node Final Bake
	    final_bake = spiral_curl_bunz.nodes.new("GeometryNodeBake")
	    final_bake.label = "Final Bake"
	    final_bake.name = "Final Bake"
	    final_bake.active_index = 0
	    final_bake.bake_items.clear()
	    final_bake.bake_items.new('GEOMETRY', "Geometry")
	    final_bake.bake_items[0].attribute_domain = 'POINT'
	    final_bake.inputs[1].hide = True
	    final_bake.outputs[1].hide = True
	
	    #node Group Input.008
	    group_input_008_2 = spiral_curl_bunz.nodes.new("NodeGroupInput")
	    group_input_008_2.name = "Group Input.008"
	    group_input_008_2.outputs[0].hide = True
	    group_input_008_2.outputs[1].hide = True
	    group_input_008_2.outputs[2].hide = True
	    group_input_008_2.outputs[3].hide = True
	    group_input_008_2.outputs[4].hide = True
	    group_input_008_2.outputs[5].hide = True
	    group_input_008_2.outputs[6].hide = True
	    group_input_008_2.outputs[7].hide = True
	    group_input_008_2.outputs[8].hide = True
	    group_input_008_2.outputs[9].hide = True
	    group_input_008_2.outputs[14].hide = True
	    group_input_008_2.outputs[15].hide = True
	    group_input_008_2.outputs[16].hide = True
	    group_input_008_2.outputs[17].hide = True
	    group_input_008_2.outputs[18].hide = True
	    group_input_008_2.outputs[19].hide = True
	    group_input_008_2.outputs[20].hide = True
	    group_input_008_2.outputs[21].hide = True
	    group_input_008_2.outputs[22].hide = True
	    group_input_008_2.outputs[23].hide = True
	    group_input_008_2.outputs[24].hide = True
	    group_input_008_2.outputs[25].hide = True
	    group_input_008_2.outputs[26].hide = True
	    group_input_008_2.outputs[27].hide = True
	    group_input_008_2.outputs[28].hide = True
	    group_input_008_2.outputs[29].hide = True
	    group_input_008_2.outputs[30].hide = True
	    group_input_008_2.outputs[31].hide = True
	    group_input_008_2.outputs[32].hide = True
	    group_input_008_2.outputs[33].hide = True
	    group_input_008_2.outputs[34].hide = True
	    group_input_008_2.outputs[35].hide = True
	    group_input_008_2.outputs[36].hide = True
	    group_input_008_2.outputs[37].hide = True
	    group_input_008_2.outputs[38].hide = True
	    group_input_008_2.outputs[39].hide = True
	    group_input_008_2.outputs[40].hide = True
	    group_input_008_2.outputs[41].hide = True
	    group_input_008_2.outputs[42].hide = True
	    group_input_008_2.outputs[43].hide = True
	    group_input_008_2.outputs[44].hide = True
	    group_input_008_2.outputs[45].hide = True
	    group_input_008_2.outputs[46].hide = True
	
	    #node Trim Curve
	    trim_curve = spiral_curl_bunz.nodes.new("GeometryNodeTrimCurve")
	    trim_curve.name = "Trim Curve"
	    trim_curve.mode = 'FACTOR'
	    trim_curve.inputs[1].hide = True
	    trim_curve.inputs[2].hide = True
	    trim_curve.inputs[4].hide = True
	    trim_curve.inputs[5].hide = True
	    #Selection
	    trim_curve.inputs[1].default_value = True
	    #Start
	    trim_curve.inputs[2].default_value = 0.0
	
	    #node Group Input.009
	    group_input_009_2 = spiral_curl_bunz.nodes.new("NodeGroupInput")
	    group_input_009_2.name = "Group Input.009"
	    group_input_009_2.outputs[0].hide = True
	    group_input_009_2.outputs[1].hide = True
	    group_input_009_2.outputs[2].hide = True
	    group_input_009_2.outputs[3].hide = True
	    group_input_009_2.outputs[4].hide = True
	    group_input_009_2.outputs[5].hide = True
	    group_input_009_2.outputs[6].hide = True
	    group_input_009_2.outputs[7].hide = True
	    group_input_009_2.outputs[9].hide = True
	    group_input_009_2.outputs[10].hide = True
	    group_input_009_2.outputs[11].hide = True
	    group_input_009_2.outputs[12].hide = True
	    group_input_009_2.outputs[13].hide = True
	    group_input_009_2.outputs[14].hide = True
	    group_input_009_2.outputs[15].hide = True
	    group_input_009_2.outputs[16].hide = True
	    group_input_009_2.outputs[17].hide = True
	    group_input_009_2.outputs[18].hide = True
	    group_input_009_2.outputs[19].hide = True
	    group_input_009_2.outputs[20].hide = True
	    group_input_009_2.outputs[21].hide = True
	    group_input_009_2.outputs[22].hide = True
	    group_input_009_2.outputs[23].hide = True
	    group_input_009_2.outputs[24].hide = True
	    group_input_009_2.outputs[25].hide = True
	    group_input_009_2.outputs[26].hide = True
	    group_input_009_2.outputs[27].hide = True
	    group_input_009_2.outputs[28].hide = True
	    group_input_009_2.outputs[29].hide = True
	    group_input_009_2.outputs[30].hide = True
	    group_input_009_2.outputs[31].hide = True
	    group_input_009_2.outputs[32].hide = True
	    group_input_009_2.outputs[33].hide = True
	    group_input_009_2.outputs[34].hide = True
	    group_input_009_2.outputs[35].hide = True
	    group_input_009_2.outputs[36].hide = True
	    group_input_009_2.outputs[37].hide = True
	    group_input_009_2.outputs[38].hide = True
	    group_input_009_2.outputs[39].hide = True
	    group_input_009_2.outputs[40].hide = True
	    group_input_009_2.outputs[41].hide = True
	    group_input_009_2.outputs[42].hide = True
	    group_input_009_2.outputs[43].hide = True
	    group_input_009_2.outputs[44].hide = True
	    group_input_009_2.outputs[45].hide = True
	    group_input_009_2.outputs[46].hide = True
	
	    #node Spiral Bake
	    spiral_bake = spiral_curl_bunz.nodes.new("GeometryNodeBake")
	    spiral_bake.label = "Spiral Bake"
	    spiral_bake.name = "Spiral Bake"
	    spiral_bake.active_index = 0
	    spiral_bake.bake_items.clear()
	    spiral_bake.bake_items.new('GEOMETRY', "Geometry")
	    spiral_bake.bake_items[0].attribute_domain = 'POINT'
	    spiral_bake.inputs[1].hide = True
	    spiral_bake.outputs[1].hide = True
	
	    #node Reroute.004
	    reroute_004_6 = spiral_curl_bunz.nodes.new("NodeReroute")
	    reroute_004_6.name = "Reroute.004"
	    reroute_004_6.socket_idname = "NodeSocketGeometry"
	    #node Reroute.005
	    reroute_005_5 = spiral_curl_bunz.nodes.new("NodeReroute")
	    reroute_005_5.name = "Reroute.005"
	    reroute_005_5.socket_idname = "NodeSocketGeometry"
	    #node Reroute.006
	    reroute_006_4 = spiral_curl_bunz.nodes.new("NodeReroute")
	    reroute_006_4.name = "Reroute.006"
	    reroute_006_4.socket_idname = "NodeSocketGeometry"
	    #node Duplicate Bake
	    duplicate_bake = spiral_curl_bunz.nodes.new("GeometryNodeBake")
	    duplicate_bake.label = "Duplicate Bake"
	    duplicate_bake.name = "Duplicate Bake"
	    duplicate_bake.active_index = 0
	    duplicate_bake.bake_items.clear()
	    duplicate_bake.bake_items.new('GEOMETRY', "Geometry")
	    duplicate_bake.bake_items[0].attribute_domain = 'POINT'
	    duplicate_bake.inputs[1].hide = True
	    duplicate_bake.outputs[1].hide = True
	
	    #node Reroute.007
	    reroute_007_4 = spiral_curl_bunz.nodes.new("NodeReroute")
	    reroute_007_4.name = "Reroute.007"
	    reroute_007_4.socket_idname = "NodeSocketGeometry"
	    #node Reroute.008
	    reroute_008_4 = spiral_curl_bunz.nodes.new("NodeReroute")
	    reroute_008_4.name = "Reroute.008"
	    reroute_008_4.socket_idname = "NodeSocketGeometry"
	    #node Reroute.009
	    reroute_009_4 = spiral_curl_bunz.nodes.new("NodeReroute")
	    reroute_009_4.name = "Reroute.009"
	    reroute_009_4.socket_idname = "NodeSocketGeometry"
	    #node Reroute.002
	    reroute_002_7 = spiral_curl_bunz.nodes.new("NodeReroute")
	    reroute_002_7.name = "Reroute.002"
	    reroute_002_7.socket_idname = "NodeSocketGeometry"
	    #node Reroute.010
	    reroute_010_2 = spiral_curl_bunz.nodes.new("NodeReroute")
	    reroute_010_2.name = "Reroute.010"
	    reroute_010_2.socket_idname = "NodeSocketGeometry"
	    #node Group.002
	    group_002_3 = spiral_curl_bunz.nodes.new("GeometryNodeGroup")
	    group_002_3.name = "Group.002"
	    group_002_3.hide = True
	    group_002_3.node_tree = trim_by_surface_norm
	
	    #node Switch.002
	    switch_002_2 = spiral_curl_bunz.nodes.new("GeometryNodeSwitch")
	    switch_002_2.name = "Switch.002"
	    switch_002_2.hide = True
	    switch_002_2.input_type = 'GEOMETRY'
	
	    #node Group Input.010
	    group_input_010_1 = spiral_curl_bunz.nodes.new("NodeGroupInput")
	    group_input_010_1.name = "Group Input.010"
	    group_input_010_1.hide = True
	    group_input_010_1.outputs[0].hide = True
	    group_input_010_1.outputs[2].hide = True
	    group_input_010_1.outputs[3].hide = True
	    group_input_010_1.outputs[4].hide = True
	    group_input_010_1.outputs[5].hide = True
	    group_input_010_1.outputs[8].hide = True
	    group_input_010_1.outputs[10].hide = True
	    group_input_010_1.outputs[11].hide = True
	    group_input_010_1.outputs[12].hide = True
	    group_input_010_1.outputs[13].hide = True
	    group_input_010_1.outputs[14].hide = True
	    group_input_010_1.outputs[15].hide = True
	    group_input_010_1.outputs[16].hide = True
	    group_input_010_1.outputs[17].hide = True
	    group_input_010_1.outputs[18].hide = True
	    group_input_010_1.outputs[19].hide = True
	    group_input_010_1.outputs[20].hide = True
	    group_input_010_1.outputs[21].hide = True
	    group_input_010_1.outputs[22].hide = True
	    group_input_010_1.outputs[23].hide = True
	    group_input_010_1.outputs[24].hide = True
	    group_input_010_1.outputs[25].hide = True
	    group_input_010_1.outputs[26].hide = True
	    group_input_010_1.outputs[27].hide = True
	    group_input_010_1.outputs[28].hide = True
	    group_input_010_1.outputs[29].hide = True
	    group_input_010_1.outputs[30].hide = True
	    group_input_010_1.outputs[31].hide = True
	    group_input_010_1.outputs[32].hide = True
	    group_input_010_1.outputs[33].hide = True
	    group_input_010_1.outputs[34].hide = True
	    group_input_010_1.outputs[35].hide = True
	    group_input_010_1.outputs[36].hide = True
	    group_input_010_1.outputs[37].hide = True
	    group_input_010_1.outputs[38].hide = True
	    group_input_010_1.outputs[39].hide = True
	    group_input_010_1.outputs[40].hide = True
	    group_input_010_1.outputs[41].hide = True
	    group_input_010_1.outputs[42].hide = True
	    group_input_010_1.outputs[43].hide = True
	    group_input_010_1.outputs[44].hide = True
	    group_input_010_1.outputs[45].hide = True
	    group_input_010_1.outputs[46].hide = True
	
	    #node Reroute.011
	    reroute_011_2 = spiral_curl_bunz.nodes.new("NodeReroute")
	    reroute_011_2.name = "Reroute.011"
	    reroute_011_2.socket_idname = "NodeSocketGeometry"
	    #node Reroute.012
	    reroute_012_3 = spiral_curl_bunz.nodes.new("NodeReroute")
	    reroute_012_3.name = "Reroute.012"
	    reroute_012_3.socket_idname = "NodeSocketGeometry"
	    #node Group.005
	    group_005 = spiral_curl_bunz.nodes.new("GeometryNodeGroup")
	    group_005.name = "Group.005"
	    group_005.node_tree = mesh_hair_selector
	    group_005.inputs[13].hide = True
	    #Socket_14
	    group_005.inputs[13].default_value = 0
	
	    #node Join Geometry
	    join_geometry_5 = spiral_curl_bunz.nodes.new("GeometryNodeJoinGeometry")
	    join_geometry_5.name = "Join Geometry"
	
	    #node Separate Components
	    separate_components_2 = spiral_curl_bunz.nodes.new("GeometryNodeSeparateComponents")
	    separate_components_2.name = "Separate Components"
	    separate_components_2.hide = True
	
	    #node Reroute.013
	    reroute_013_3 = spiral_curl_bunz.nodes.new("NodeReroute")
	    reroute_013_3.name = "Reroute.013"
	    reroute_013_3.socket_idname = "NodeSocketGeometry"
	    #node Reroute.014
	    reroute_014_3 = spiral_curl_bunz.nodes.new("NodeReroute")
	    reroute_014_3.name = "Reroute.014"
	    reroute_014_3.socket_idname = "NodeSocketGeometry"
	    #node Reroute.015
	    reroute_015_3 = spiral_curl_bunz.nodes.new("NodeReroute")
	    reroute_015_3.name = "Reroute.015"
	    reroute_015_3.socket_idname = "NodeSocketGeometry"
	    #node Reroute.016
	    reroute_016_3 = spiral_curl_bunz.nodes.new("NodeReroute")
	    reroute_016_3.name = "Reroute.016"
	    reroute_016_3.socket_idname = "NodeSocketGeometry"
	    #node Reroute.017
	    reroute_017_2 = spiral_curl_bunz.nodes.new("NodeReroute")
	    reroute_017_2.name = "Reroute.017"
	    reroute_017_2.socket_idname = "NodeSocketGeometry"
	    #node Reroute.018
	    reroute_018_2 = spiral_curl_bunz.nodes.new("NodeReroute")
	    reroute_018_2.name = "Reroute.018"
	    reroute_018_2.socket_idname = "NodeSocketGeometry"
	    #node Reroute.019
	    reroute_019_2 = spiral_curl_bunz.nodes.new("NodeReroute")
	    reroute_019_2.name = "Reroute.019"
	    reroute_019_2.socket_idname = "NodeSocketGeometry"
	    #node Reroute.020
	    reroute_020_2 = spiral_curl_bunz.nodes.new("NodeReroute")
	    reroute_020_2.name = "Reroute.020"
	    reroute_020_2.socket_idname = "NodeSocketGeometry"
	    #node Reroute.021
	    reroute_021 = spiral_curl_bunz.nodes.new("NodeReroute")
	    reroute_021.name = "Reroute.021"
	    reroute_021.socket_idname = "NodeSocketGeometry"
	    #node Reroute.022
	    reroute_022 = spiral_curl_bunz.nodes.new("NodeReroute")
	    reroute_022.name = "Reroute.022"
	    reroute_022.socket_idname = "NodeSocketGeometry"
	
	
	
	
	    #Set locations
	    group_input_12.location = (-340.0, 0.0)
	    group_output_17.location = (1898.942626953125, 207.73947143554688)
	    group_004.location = (648.41552734375, 63.97454833984375)
	    group_003_2.location = (-151.48873901367188, 44.29536437988281)
	    reroute_8.location = (602.7703247070312, 83.56657409667969)
	    group_input_002_8.location = (450.5013427734375, -26.557828903198242)
	    group_input_003_8.location = (1079.4049072265625, 22.302274703979492)
	    switch_7.location = (1314.3389892578125, 160.9814453125)
	    switch_001_3.location = (648.3236083984375, 134.26458740234375)
	    group_input_004_7.location = (646.674560546875, 233.21151733398438)
	    compare_6.location = (649.7059326171875, 170.44577026367188)
	    group_input_005_6.location = (1310.2843017578125, 225.466796875)
	    set_material_4.location = (828.1436767578125, 185.08978271484375)
	    reroute_001_7.location = (1283.0987548828125, 149.8670654296875)
	    group_input_006_4.location = (827.84375, 81.52503204345703)
	    set_curve_radius_4.location = (43.25322341918945, 69.58769989013672)
	    strand_shape.location = (29.95001220703125, -128.37545776367188)
	    spline_parameter_001_1.location = (29.11688232421875, -427.8659973144531)
	    map_range_1.location = (43.25323486328125, -36.2623291015625)
	    group_input_001_9.location = (40.30213928222656, -68.10702514648438)
	    group_6.location = (1031.005859375, 370.04156494140625)
	    group_input_007_4.location = (826.5632934570312, 300.7814025878906)
	    reroute_003_7.location = (1288.8724365234375, 12.63180160522461)
	    final_bake.location = (1724.81103515625, 254.24649047851562)
	    group_input_008_2.location = (-340.0, -366.9595642089844)
	    trim_curve.location = (403.359619140625, 118.62076568603516)
	    group_input_009_2.location = (405.8150939941406, 198.63134765625)
	    spiral_bake.location = (223.00003051757812, 116.54996490478516)
	    reroute_004_6.location = (1000.6701049804688, 150.40194702148438)
	    reroute_005_5.location = (997.7105712890625, 287.7841796875)
	    reroute_006_4.location = (1200.44189453125, 182.50827026367188)
	    duplicate_bake.location = (1075.17919921875, 156.52630615234375)
	    reroute_007_4.location = (1194.52294921875, 336.36383056640625)
	    reroute_008_4.location = (1031.984619140625, 180.6866455078125)
	    reroute_009_4.location = (1034.969482421875, 74.46708679199219)
	    reroute_002_7.location = (1245.482421875, 148.4194793701172)
	    reroute_010_2.location = (1245.458740234375, 76.54037475585938)
	    group_002_3.location = (1244.5262451171875, 384.0679626464844)
	    switch_002_2.location = (1238.868896484375, 347.53936767578125)
	    group_input_010_1.location = (1031.55126953125, 441.2655029296875)
	    reroute_011_2.location = (1380.1925048828125, 291.934814453125)
	    reroute_012_3.location = (1200.38623046875, 288.5459289550781)
	    group_005.location = (1319.2366943359375, 94.157470703125)
	    join_geometry_5.location = (1547.8612060546875, 207.58343505859375)
	    separate_components_2.location = (-338.90081787109375, 39.60975646972656)
	    reroute_013_3.location = (12.229523658752441, 481.1900634765625)
	    reroute_014_3.location = (14.06615161895752, 471.59222412109375)
	    reroute_015_3.location = (11.814697265625, 491.7799072265625)
	    reroute_016_3.location = (11.814697265625, 486.243408203125)
	    reroute_017_2.location = (13.29449462890625, 476.443115234375)
	    reroute_018_2.location = (1324.4090576171875, 492.62255859375)
	    reroute_019_2.location = (1325.0738525390625, 472.62158203125)
	    reroute_020_2.location = (1324.4090576171875, 487.618408203125)
	    reroute_021.location = (1324.4090576171875, 477.61993408203125)
	    reroute_022.location = (1324.4090576171875, 482.617919921875)
	
	    #Set dimensions
	    group_input_12.width, group_input_12.height = 140.0, 100.0
	    group_output_17.width, group_output_17.height = 140.0, 100.0
	    group_004.width, group_004.height = 140.0, 100.0
	    group_003_2.width, group_003_2.height = 140.0, 100.0
	    reroute_8.width, reroute_8.height = 10.0, 100.0
	    group_input_002_8.width, group_input_002_8.height = 140.0, 100.0
	    group_input_003_8.width, group_input_003_8.height = 140.0, 100.0
	    switch_7.width, switch_7.height = 140.0, 100.0
	    switch_001_3.width, switch_001_3.height = 140.0, 100.0
	    group_input_004_7.width, group_input_004_7.height = 140.0, 100.0
	    compare_6.width, compare_6.height = 140.0, 100.0
	    group_input_005_6.width, group_input_005_6.height = 140.0, 100.0
	    set_material_4.width, set_material_4.height = 140.0, 100.0
	    reroute_001_7.width, reroute_001_7.height = 10.0, 100.0
	    group_input_006_4.width, group_input_006_4.height = 140.0, 100.0
	    set_curve_radius_4.width, set_curve_radius_4.height = 140.0, 100.0
	    strand_shape.width, strand_shape.height = 240.0, 100.0
	    spline_parameter_001_1.width, spline_parameter_001_1.height = 140.0, 100.0
	    map_range_1.width, map_range_1.height = 140.0, 100.0
	    group_input_001_9.width, group_input_001_9.height = 140.0, 100.0
	    group_6.width, group_6.height = 140.0, 100.0
	    group_input_007_4.width, group_input_007_4.height = 140.0, 100.0
	    reroute_003_7.width, reroute_003_7.height = 10.0, 100.0
	    final_bake.width, final_bake.height = 140.0, 100.0
	    group_input_008_2.width, group_input_008_2.height = 140.0, 100.0
	    trim_curve.width, trim_curve.height = 140.0, 100.0
	    group_input_009_2.width, group_input_009_2.height = 140.0, 100.0
	    spiral_bake.width, spiral_bake.height = 140.0, 100.0
	    reroute_004_6.width, reroute_004_6.height = 10.0, 100.0
	    reroute_005_5.width, reroute_005_5.height = 10.0, 100.0
	    reroute_006_4.width, reroute_006_4.height = 10.0, 100.0
	    duplicate_bake.width, duplicate_bake.height = 140.0, 100.0
	    reroute_007_4.width, reroute_007_4.height = 10.0, 100.0
	    reroute_008_4.width, reroute_008_4.height = 10.0, 100.0
	    reroute_009_4.width, reroute_009_4.height = 10.0, 100.0
	    reroute_002_7.width, reroute_002_7.height = 10.0, 100.0
	    reroute_010_2.width, reroute_010_2.height = 10.0, 100.0
	    group_002_3.width, group_002_3.height = 140.0, 100.0
	    switch_002_2.width, switch_002_2.height = 140.0, 100.0
	    group_input_010_1.width, group_input_010_1.height = 140.0, 100.0
	    reroute_011_2.width, reroute_011_2.height = 10.0, 100.0
	    reroute_012_3.width, reroute_012_3.height = 10.0, 100.0
	    group_005.width, group_005.height = 140.0, 100.0
	    join_geometry_5.width, join_geometry_5.height = 140.0, 100.0
	    separate_components_2.width, separate_components_2.height = 140.0, 100.0
	    reroute_013_3.width, reroute_013_3.height = 10.0, 100.0
	    reroute_014_3.width, reroute_014_3.height = 10.0, 100.0
	    reroute_015_3.width, reroute_015_3.height = 10.0, 100.0
	    reroute_016_3.width, reroute_016_3.height = 10.0, 100.0
	    reroute_017_2.width, reroute_017_2.height = 10.0, 100.0
	    reroute_018_2.width, reroute_018_2.height = 10.0, 100.0
	    reroute_019_2.width, reroute_019_2.height = 10.0, 100.0
	    reroute_020_2.width, reroute_020_2.height = 10.0, 100.0
	    reroute_021.width, reroute_021.height = 10.0, 100.0
	    reroute_022.width, reroute_022.height = 10.0, 100.0
	
	    #initialize spiral_curl_bunz links
	    #reroute_8.Output -> group_004.Geometry
	    spiral_curl_bunz.links.new(reroute_8.outputs[0], group_004.inputs[0])
	    #group_input_12.Control Points -> group_003_2.Resolution
	    spiral_curl_bunz.links.new(group_input_12.outputs[3], group_003_2.inputs[2])
	    #group_input_12.Root Height -> group_003_2.Root Height
	    spiral_curl_bunz.links.new(group_input_12.outputs[17], group_003_2.inputs[6])
	    #group_input_12.Lower Height -> group_003_2.Lower Height
	    spiral_curl_bunz.links.new(group_input_12.outputs[16], group_003_2.inputs[5])
	    #group_input_12.Upper Height -> group_003_2.Upper Height
	    spiral_curl_bunz.links.new(group_input_12.outputs[15], group_003_2.inputs[4])
	    #group_input_12.Tip Height -> group_003_2.Tip Height
	    spiral_curl_bunz.links.new(group_input_12.outputs[14], group_003_2.inputs[3])
	    #group_input_12.Root Radius -> group_003_2.Root Radius
	    spiral_curl_bunz.links.new(group_input_12.outputs[21], group_003_2.inputs[10])
	    #group_input_12.Lower Radius -> group_003_2.Lower Radius
	    spiral_curl_bunz.links.new(group_input_12.outputs[20], group_003_2.inputs[9])
	    #group_input_12.Upper Radius -> group_003_2.Upper Radius
	    spiral_curl_bunz.links.new(group_input_12.outputs[19], group_003_2.inputs[8])
	    #group_input_12.Tip Radius -> group_003_2.Tip Radius
	    spiral_curl_bunz.links.new(group_input_12.outputs[18], group_003_2.inputs[7])
	    #group_input_12.Root Rotations -> group_003_2.Root Rotations
	    spiral_curl_bunz.links.new(group_input_12.outputs[25], group_003_2.inputs[14])
	    #group_input_12.Lower Rotations -> group_003_2.Lower Rotations
	    spiral_curl_bunz.links.new(group_input_12.outputs[24], group_003_2.inputs[13])
	    #group_input_12.Upper Rotations -> group_003_2.Upper Rotations
	    spiral_curl_bunz.links.new(group_input_12.outputs[23], group_003_2.inputs[12])
	    #group_input_12.Tip Rotations -> group_003_2.Tip Rotations
	    spiral_curl_bunz.links.new(group_input_12.outputs[22], group_003_2.inputs[11])
	    #group_input_002_8.Duplicate Amount -> group_004.Amount
	    spiral_curl_bunz.links.new(group_input_002_8.outputs[26], group_004.inputs[1])
	    #group_input_002_8.Duplicate Viewport Amount -> group_004.Viewport Amount
	    spiral_curl_bunz.links.new(group_input_002_8.outputs[27], group_004.inputs[2])
	    #group_input_002_8.Duplicate Radius -> group_004.Radius
	    spiral_curl_bunz.links.new(group_input_002_8.outputs[28], group_004.inputs[3])
	    #group_input_002_8.Duplicate Distribution Shape -> group_004.Distribution Shape
	    spiral_curl_bunz.links.new(group_input_002_8.outputs[29], group_004.inputs[4])
	    #group_input_002_8.Duplicate Tip Roundness -> group_004.Tip Roundness
	    spiral_curl_bunz.links.new(group_input_002_8.outputs[30], group_004.inputs[5])
	    #group_input_002_8.Duplicate Even Thickness -> group_004.Even Thickness
	    spiral_curl_bunz.links.new(group_input_002_8.outputs[31], group_004.inputs[6])
	    #group_input_002_8.Duplicate Seed -> group_004.Seed
	    spiral_curl_bunz.links.new(group_input_002_8.outputs[32], group_004.inputs[7])
	    #group_input_004_7.Duplicate Amount -> compare_6.A
	    spiral_curl_bunz.links.new(group_input_004_7.outputs[26], compare_6.inputs[2])
	    #compare_6.Result -> switch_001_3.Switch
	    spiral_curl_bunz.links.new(compare_6.outputs[0], switch_001_3.inputs[0])
	    #group_004.Geometry -> switch_001_3.True
	    spiral_curl_bunz.links.new(group_004.outputs[0], switch_001_3.inputs[2])
	    #reroute_8.Output -> switch_001_3.False
	    spiral_curl_bunz.links.new(reroute_8.outputs[0], switch_001_3.inputs[1])
	    #reroute_001_7.Output -> switch_7.False
	    spiral_curl_bunz.links.new(reroute_001_7.outputs[0], switch_7.inputs[1])
	    #group_input_005_6.Use Mesh -> switch_7.Switch
	    spiral_curl_bunz.links.new(group_input_005_6.outputs[33], switch_7.inputs[0])
	    #switch_001_3.Output -> set_material_4.Geometry
	    spiral_curl_bunz.links.new(switch_001_3.outputs[0], set_material_4.inputs[0])
	    #group_input_006_4.Curve Material -> set_material_4.Material
	    spiral_curl_bunz.links.new(group_input_006_4.outputs[5], set_material_4.inputs[2])
	    #group_003_2.Geometry -> set_curve_radius_4.Curve
	    spiral_curl_bunz.links.new(group_003_2.outputs[0], set_curve_radius_4.inputs[0])
	    #spline_parameter_001_1.Factor -> strand_shape.Value
	    spiral_curl_bunz.links.new(spline_parameter_001_1.outputs[0], strand_shape.inputs[1])
	    #strand_shape.Value -> map_range_1.Value
	    spiral_curl_bunz.links.new(strand_shape.outputs[0], map_range_1.inputs[0])
	    #group_input_001_9.Strand Radius -> map_range_1.To Max
	    spiral_curl_bunz.links.new(group_input_001_9.outputs[4], map_range_1.inputs[4])
	    #map_range_1.Result -> set_curve_radius_4.Radius
	    spiral_curl_bunz.links.new(map_range_1.outputs[0], set_curve_radius_4.inputs[2])
	    #reroute_005_5.Output -> group_6.Geometry
	    spiral_curl_bunz.links.new(reroute_005_5.outputs[0], group_6.inputs[0])
	    #group_input_007_4.Surface -> group_6.Surface
	    spiral_curl_bunz.links.new(group_input_007_4.outputs[1], group_6.inputs[1])
	    #group_input_007_4.UV Map -> group_6.UV Map
	    spiral_curl_bunz.links.new(group_input_007_4.outputs[6], group_6.inputs[2])
	    #group_input_007_4.Blend along Curve -> group_6.Blend along Curve
	    spiral_curl_bunz.links.new(group_input_007_4.outputs[7], group_6.inputs[3])
	    #reroute_001_7.Output -> reroute_003_7.Input
	    spiral_curl_bunz.links.new(reroute_001_7.outputs[0], reroute_003_7.inputs[0])
	    #final_bake.Geometry -> group_output_17.Geometry
	    spiral_curl_bunz.links.new(final_bake.outputs[0], group_output_17.inputs[0])
	    #group_input_008_2.Curl XY Angle -> group_003_2.Curl XY Angle
	    spiral_curl_bunz.links.new(group_input_008_2.outputs[10], group_003_2.inputs[15])
	    #group_input_008_2.Curl XZ Angle -> group_003_2.Curl XZ Angle
	    spiral_curl_bunz.links.new(group_input_008_2.outputs[11], group_003_2.inputs[16])
	    #group_input_008_2.Curl Rotation -> group_003_2.Curl Rotation
	    spiral_curl_bunz.links.new(group_input_008_2.outputs[12], group_003_2.inputs[17])
	    #group_input_008_2.Curl Scale -> group_003_2.Curl Scale
	    spiral_curl_bunz.links.new(group_input_008_2.outputs[13], group_003_2.inputs[18])
	    #group_input_12.Spiral Style -> group_003_2.Spiral Style
	    spiral_curl_bunz.links.new(group_input_12.outputs[2], group_003_2.inputs[1])
	    #spiral_bake.Geometry -> trim_curve.Curve
	    spiral_curl_bunz.links.new(spiral_bake.outputs[0], trim_curve.inputs[0])
	    #trim_curve.Curve -> reroute_8.Input
	    spiral_curl_bunz.links.new(trim_curve.outputs[0], reroute_8.inputs[0])
	    #group_input_009_2.Trim Factor -> trim_curve.End
	    spiral_curl_bunz.links.new(group_input_009_2.outputs[8], trim_curve.inputs[3])
	    #set_curve_radius_4.Curve -> spiral_bake.Geometry
	    spiral_curl_bunz.links.new(set_curve_radius_4.outputs[0], spiral_bake.inputs[0])
	    #set_material_4.Geometry -> reroute_004_6.Input
	    spiral_curl_bunz.links.new(set_material_4.outputs[0], reroute_004_6.inputs[0])
	    #reroute_004_6.Output -> reroute_005_5.Input
	    spiral_curl_bunz.links.new(reroute_004_6.outputs[0], reroute_005_5.inputs[0])
	    #group_6.Geometry -> reroute_007_4.Input
	    spiral_curl_bunz.links.new(group_6.outputs[0], reroute_007_4.inputs[0])
	    #reroute_009_4.Output -> duplicate_bake.Geometry
	    spiral_curl_bunz.links.new(reroute_009_4.outputs[0], duplicate_bake.inputs[0])
	    #reroute_006_4.Output -> reroute_008_4.Input
	    spiral_curl_bunz.links.new(reroute_006_4.outputs[0], reroute_008_4.inputs[0])
	    #reroute_008_4.Output -> reroute_009_4.Input
	    spiral_curl_bunz.links.new(reroute_008_4.outputs[0], reroute_009_4.inputs[0])
	    #reroute_002_7.Output -> reroute_001_7.Input
	    spiral_curl_bunz.links.new(reroute_002_7.outputs[0], reroute_001_7.inputs[0])
	    #reroute_010_2.Output -> reroute_002_7.Input
	    spiral_curl_bunz.links.new(reroute_010_2.outputs[0], reroute_002_7.inputs[0])
	    #duplicate_bake.Geometry -> reroute_010_2.Input
	    spiral_curl_bunz.links.new(duplicate_bake.outputs[0], reroute_010_2.inputs[0])
	    #reroute_007_4.Output -> group_002_3.Geometry
	    spiral_curl_bunz.links.new(reroute_007_4.outputs[0], group_002_3.inputs[0])
	    #group_002_3.Geometry -> switch_002_2.True
	    spiral_curl_bunz.links.new(group_002_3.outputs[0], switch_002_2.inputs[2])
	    #reroute_007_4.Output -> switch_002_2.False
	    spiral_curl_bunz.links.new(reroute_007_4.outputs[0], switch_002_2.inputs[1])
	    #group_input_010_1.Surface -> group_002_3.Surface
	    spiral_curl_bunz.links.new(group_input_010_1.outputs[1], group_002_3.inputs[1])
	    #group_input_010_1.UV Map -> group_002_3.UV Map
	    spiral_curl_bunz.links.new(group_input_010_1.outputs[6], group_002_3.inputs[2])
	    #group_input_010_1.Blend along Curve -> group_002_3.Blend along Curve
	    spiral_curl_bunz.links.new(group_input_010_1.outputs[7], group_002_3.inputs[3])
	    #reroute_012_3.Output -> reroute_006_4.Input
	    spiral_curl_bunz.links.new(reroute_012_3.outputs[0], reroute_006_4.inputs[0])
	    #switch_002_2.Output -> reroute_011_2.Input
	    spiral_curl_bunz.links.new(switch_002_2.outputs[0], reroute_011_2.inputs[0])
	    #reroute_011_2.Output -> reroute_012_3.Input
	    spiral_curl_bunz.links.new(reroute_011_2.outputs[0], reroute_012_3.inputs[0])
	    #group_input_010_1.Trim by Surface Normal -> switch_002_2.Switch
	    spiral_curl_bunz.links.new(group_input_010_1.outputs[9], switch_002_2.inputs[0])
	    #reroute_003_7.Output -> group_005.Geometry
	    spiral_curl_bunz.links.new(reroute_003_7.outputs[0], group_005.inputs[0])
	    #group_005.Geometry -> switch_7.True
	    spiral_curl_bunz.links.new(group_005.outputs[0], switch_7.inputs[2])
	    #group_input_003_8.Style Select -> group_005.Style Select
	    spiral_curl_bunz.links.new(group_input_003_8.outputs[35], group_005.inputs[1])
	    #group_input_003_8.Mesh Material -> group_005.Material
	    spiral_curl_bunz.links.new(group_input_003_8.outputs[36], group_005.inputs[2])
	    #group_input_003_8.Resolution -> group_005.Resolution
	    spiral_curl_bunz.links.new(group_input_003_8.outputs[37], group_005.inputs[3])
	    #group_input_003_8.Width -> group_005.Width
	    spiral_curl_bunz.links.new(group_input_003_8.outputs[38], group_005.inputs[4])
	    #group_input_003_8.Fill Caps -> group_005.Fill Caps
	    spiral_curl_bunz.links.new(group_input_003_8.outputs[39], group_005.inputs[5])
	    #group_input_003_8.Hair Card Angle -> group_005.Hair Card Angle
	    spiral_curl_bunz.links.new(group_input_003_8.outputs[40], group_005.inputs[7])
	    #group_input_003_8.Tube Ribbon Count -> group_005.Tube Ribbon Count
	    spiral_curl_bunz.links.new(group_input_003_8.outputs[41], group_005.inputs[8])
	    #group_input_003_8.Profile Curve -> group_005.Profile Curve
	    spiral_curl_bunz.links.new(group_input_003_8.outputs[42], group_005.inputs[9])
	    #group_input_003_8.Profile Translation -> group_005.Profile Translation
	    spiral_curl_bunz.links.new(group_input_003_8.outputs[43], group_005.inputs[10])
	    #group_input_003_8.Profile Rotation -> group_005.Profile Rotation
	    spiral_curl_bunz.links.new(group_input_003_8.outputs[44], group_005.inputs[11])
	    #group_input_003_8.Profile Scale -> group_005.Profile Scale
	    spiral_curl_bunz.links.new(group_input_003_8.outputs[45], group_005.inputs[12])
	    #group_input_003_8.Shade Smooth -> group_005.Shade Smooth
	    spiral_curl_bunz.links.new(group_input_003_8.outputs[34], group_005.inputs[6])
	    #group_input_12.Geometry -> separate_components_2.Geometry
	    spiral_curl_bunz.links.new(group_input_12.outputs[0], separate_components_2.inputs[0])
	    #separate_components_2.Curve -> group_003_2.Geometry
	    spiral_curl_bunz.links.new(separate_components_2.outputs[1], group_003_2.inputs[0])
	    #reroute_019_2.Output -> join_geometry_5.Geometry
	    spiral_curl_bunz.links.new(reroute_019_2.outputs[0], join_geometry_5.inputs[0])
	    #separate_components_2.Point Cloud -> reroute_013_3.Input
	    spiral_curl_bunz.links.new(separate_components_2.outputs[3], reroute_013_3.inputs[0])
	    #separate_components_2.Instances -> reroute_014_3.Input
	    spiral_curl_bunz.links.new(separate_components_2.outputs[5], reroute_014_3.inputs[0])
	    #separate_components_2.Mesh -> reroute_015_3.Input
	    spiral_curl_bunz.links.new(separate_components_2.outputs[0], reroute_015_3.inputs[0])
	    #separate_components_2.Grease Pencil -> reroute_016_3.Input
	    spiral_curl_bunz.links.new(separate_components_2.outputs[2], reroute_016_3.inputs[0])
	    #separate_components_2.Volume -> reroute_017_2.Input
	    spiral_curl_bunz.links.new(separate_components_2.outputs[4], reroute_017_2.inputs[0])
	    #reroute_015_3.Output -> reroute_018_2.Input
	    spiral_curl_bunz.links.new(reroute_015_3.outputs[0], reroute_018_2.inputs[0])
	    #reroute_014_3.Output -> reroute_019_2.Input
	    spiral_curl_bunz.links.new(reroute_014_3.outputs[0], reroute_019_2.inputs[0])
	    #reroute_016_3.Output -> reroute_020_2.Input
	    spiral_curl_bunz.links.new(reroute_016_3.outputs[0], reroute_020_2.inputs[0])
	    #reroute_017_2.Output -> reroute_021.Input
	    spiral_curl_bunz.links.new(reroute_017_2.outputs[0], reroute_021.inputs[0])
	    #reroute_013_3.Output -> reroute_022.Input
	    spiral_curl_bunz.links.new(reroute_013_3.outputs[0], reroute_022.inputs[0])
	    #join_geometry_5.Geometry -> final_bake.Geometry
	    spiral_curl_bunz.links.new(join_geometry_5.outputs[0], final_bake.inputs[0])
	    #reroute_021.Output -> join_geometry_5.Geometry
	    spiral_curl_bunz.links.new(reroute_021.outputs[0], join_geometry_5.inputs[0])
	    #reroute_022.Output -> join_geometry_5.Geometry
	    spiral_curl_bunz.links.new(reroute_022.outputs[0], join_geometry_5.inputs[0])
	    #reroute_020_2.Output -> join_geometry_5.Geometry
	    spiral_curl_bunz.links.new(reroute_020_2.outputs[0], join_geometry_5.inputs[0])
	    #reroute_018_2.Output -> join_geometry_5.Geometry
	    spiral_curl_bunz.links.new(reroute_018_2.outputs[0], join_geometry_5.inputs[0])
	    #switch_7.Output -> join_geometry_5.Geometry
	    spiral_curl_bunz.links.new(switch_7.outputs[0], join_geometry_5.inputs[0])
	    spiral_style_socket_1.default_value = 'Spiral Bun'
	    style_select_socket_1.default_value = 'Hair Card'
	    return spiral_curl_bunz
	return spiral_curl_bunz_node_group()

	

	
