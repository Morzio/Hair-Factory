import bpy, mathutils

def node():
	#initialize subdivision_shrinkwrap node group
	def subdivision_shrinkwrap_node_group():
	    subdivision_shrinkwrap = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "SUBDIVISION_SHRINKWRAP")
	
	    subdivision_shrinkwrap.color_tag = 'NONE'
	    subdivision_shrinkwrap.description = "Use subdivision and shrinkwrap on object."
	    subdivision_shrinkwrap.default_group_node_width = 140
	    
	
	    subdivision_shrinkwrap.is_modifier = True
	
	    #subdivision_shrinkwrap interface
	    #Socket Geometry
	    geometry_socket = subdivision_shrinkwrap.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket.attribute_domain = 'POINT'
	    geometry_socket.description = "Modified geometry."
	
	    #Socket Geometry
	    geometry_socket_1 = subdivision_shrinkwrap.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_1.attribute_domain = 'POINT'
	    geometry_socket_1.description = "Input Geometry."
	
	    #Socket Surface
	    surface_socket = subdivision_shrinkwrap.interface.new_socket(name = "Surface", in_out='INPUT', socket_type = 'NodeSocketObject')
	    surface_socket.attribute_domain = 'POINT'
	    surface_socket.description = "Surface used for shrinkwrap."
	
	    #Socket Subdivision Level
	    subdivision_level_socket = subdivision_shrinkwrap.interface.new_socket(name = "Subdivision Level", in_out='INPUT', socket_type = 'NodeSocketInt')
	    subdivision_level_socket.default_value = 1
	    subdivision_level_socket.min_value = 0
	    subdivision_level_socket.max_value = 6
	    subdivision_level_socket.subtype = 'NONE'
	    subdivision_level_socket.attribute_domain = 'POINT'
	    subdivision_level_socket.description = "Level of subdivision to use."
	
	    #Socket Edge Crease
	    edge_crease_socket = subdivision_shrinkwrap.interface.new_socket(name = "Edge Crease", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    edge_crease_socket.default_value = 0.0
	    edge_crease_socket.min_value = 0.0
	    edge_crease_socket.max_value = 1.0
	    edge_crease_socket.subtype = 'FACTOR'
	    edge_crease_socket.attribute_domain = 'POINT'
	    edge_crease_socket.description = "Edge crease factor."
	
	    #Socket Vertex Crease
	    vertex_crease_socket = subdivision_shrinkwrap.interface.new_socket(name = "Vertex Crease", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    vertex_crease_socket.default_value = 0.0
	    vertex_crease_socket.min_value = 0.0
	    vertex_crease_socket.max_value = 1.0
	    vertex_crease_socket.subtype = 'FACTOR'
	    vertex_crease_socket.attribute_domain = 'POINT'
	    vertex_crease_socket.description = "Vertex crease factor."
	
	    #Socket Limit Surface
	    limit_surface_socket = subdivision_shrinkwrap.interface.new_socket(name = "Limit Surface", in_out='INPUT', socket_type = 'NodeSocketBool')
	    limit_surface_socket.default_value = True
	    limit_surface_socket.attribute_domain = 'POINT'
	    limit_surface_socket.description = "Use smoothest possible shape."
	
	
	    #initialize subdivision_shrinkwrap nodes
	    #node Group Input
	    group_input = subdivision_shrinkwrap.nodes.new("NodeGroupInput")
	    group_input.name = "Group Input"
	    group_input.outputs[2].hide = True
	    group_input.outputs[3].hide = True
	    group_input.outputs[4].hide = True
	    group_input.outputs[5].hide = True
	    group_input.outputs[6].hide = True
	
	    #node Group Output
	    group_output = subdivision_shrinkwrap.nodes.new("NodeGroupOutput")
	    group_output.name = "Group Output"
	    group_output.is_active_output = True
	    group_output.inputs[1].hide = True
	
	    #node Object Info
	    object_info = subdivision_shrinkwrap.nodes.new("GeometryNodeObjectInfo")
	    object_info.name = "Object Info"
	    object_info.hide = True
	    object_info.transform_space = 'RELATIVE'
	    object_info.inputs[1].hide = True
	    object_info.outputs[0].hide = True
	    object_info.outputs[1].hide = True
	    object_info.outputs[2].hide = True
	    object_info.outputs[3].hide = True
	    #As Instance
	    object_info.inputs[1].default_value = False
	
	    #node Geometry Proximity
	    geometry_proximity = subdivision_shrinkwrap.nodes.new("GeometryNodeProximity")
	    geometry_proximity.name = "Geometry Proximity"
	    geometry_proximity.hide = True
	    geometry_proximity.target_element = 'FACES'
	    geometry_proximity.inputs[1].hide = True
	    geometry_proximity.inputs[2].hide = True
	    geometry_proximity.inputs[3].hide = True
	    geometry_proximity.outputs[2].hide = True
	    #Group ID
	    geometry_proximity.inputs[1].default_value = 0
	    #Source Position
	    geometry_proximity.inputs[2].default_value = (0.0, 0.0, 0.0)
	    #Sample Group ID
	    geometry_proximity.inputs[3].default_value = 0
	
	    #node Raycast
	    raycast = subdivision_shrinkwrap.nodes.new("GeometryNodeRaycast")
	    raycast.name = "Raycast"
	    raycast.hide = True
	    raycast.data_type = 'FLOAT'
	    raycast.mapping = 'INTERPOLATED'
	    raycast.inputs[1].hide = True
	    raycast.inputs[2].hide = True
	    raycast.inputs[4].hide = True
	    raycast.outputs[2].hide = True
	    raycast.outputs[4].hide = True
	    #Attribute
	    raycast.inputs[1].default_value = 0.0
	    #Source Position
	    raycast.inputs[2].default_value = (0.0, 0.0, 0.0)
	    #Ray Length
	    raycast.inputs[4].default_value = 100.0
	
	    #node Switch
	    switch = subdivision_shrinkwrap.nodes.new("GeometryNodeSwitch")
	    switch.name = "Switch"
	    switch.hide = True
	    switch.input_type = 'VECTOR'
	
	    #node Set Position
	    set_position = subdivision_shrinkwrap.nodes.new("GeometryNodeSetPosition")
	    set_position.name = "Set Position"
	    set_position.inputs[1].hide = True
	    set_position.inputs[3].hide = True
	    #Selection
	    set_position.inputs[1].default_value = True
	    #Offset
	    set_position.inputs[3].default_value = (0.0, 0.0, 0.0)
	
	    #node Normal
	    normal = subdivision_shrinkwrap.nodes.new("GeometryNodeInputNormal")
	    normal.name = "Normal"
	    normal.legacy_corner_normals = False
	
	    #node normal_invert
	    normal_invert = subdivision_shrinkwrap.nodes.new("ShaderNodeVectorMath")
	    normal_invert.label = "normal_invert"
	    normal_invert.name = "normal_invert"
	    normal_invert.hide = True
	    normal_invert.operation = 'SCALE'
	    #Scale
	    normal_invert.inputs[3].default_value = -1.0
	
	    #node Compare
	    compare = subdivision_shrinkwrap.nodes.new("FunctionNodeCompare")
	    compare.name = "Compare"
	    compare.hide = True
	    compare.data_type = 'FLOAT'
	    compare.mode = 'ELEMENT'
	    compare.operation = 'LESS_THAN'
	
	    #node Boolean Math
	    boolean_math = subdivision_shrinkwrap.nodes.new("FunctionNodeBooleanMath")
	    boolean_math.name = "Boolean Math"
	    boolean_math.hide = True
	    boolean_math.operation = 'AND'
	
	    #node Subdivision Surface
	    subdivision_surface = subdivision_shrinkwrap.nodes.new("GeometryNodeSubdivisionSurface")
	    subdivision_surface.name = "Subdivision Surface"
	    subdivision_surface.boundary_smooth = 'ALL'
	    subdivision_surface.uv_smooth = 'PRESERVE_BOUNDARIES'
	
	    #node Group Input.001
	    group_input_001 = subdivision_shrinkwrap.nodes.new("NodeGroupInput")
	    group_input_001.name = "Group Input.001"
	    group_input_001.outputs[0].hide = True
	    group_input_001.outputs[1].hide = True
	    group_input_001.outputs[6].hide = True
	
	    #node Domain Size
	    domain_size = subdivision_shrinkwrap.nodes.new("GeometryNodeAttributeDomainSize")
	    domain_size.name = "Domain Size"
	    domain_size.hide = True
	    domain_size.component = 'MESH'
	    domain_size.outputs[1].hide = True
	    domain_size.outputs[2].hide = True
	    domain_size.outputs[3].hide = True
	    domain_size.outputs[4].hide = True
	    domain_size.outputs[5].hide = True
	    domain_size.outputs[6].hide = True
	
	    #node shrinkwrap_bypass
	    shrinkwrap_bypass = subdivision_shrinkwrap.nodes.new("GeometryNodeSwitch")
	    shrinkwrap_bypass.label = "shrinkwrap_bypass"
	    shrinkwrap_bypass.name = "shrinkwrap_bypass"
	    shrinkwrap_bypass.hide = True
	    shrinkwrap_bypass.input_type = 'GEOMETRY'
	
	    #node has_points
	    has_points = subdivision_shrinkwrap.nodes.new("FunctionNodeCompare")
	    has_points.label = "has_points"
	    has_points.name = "has_points"
	    has_points.hide = True
	    has_points.data_type = 'INT'
	    has_points.mode = 'ELEMENT'
	    has_points.operation = 'NOT_EQUAL'
	    has_points.inputs[0].hide = True
	    has_points.inputs[1].hide = True
	    has_points.inputs[3].hide = True
	    has_points.inputs[4].hide = True
	    has_points.inputs[5].hide = True
	    has_points.inputs[6].hide = True
	    has_points.inputs[7].hide = True
	    has_points.inputs[8].hide = True
	    has_points.inputs[9].hide = True
	    has_points.inputs[10].hide = True
	    has_points.inputs[11].hide = True
	    has_points.inputs[12].hide = True
	    #B_INT
	    has_points.inputs[3].default_value = 0
	
	
	
	
	
	    #Set locations
	    group_input.location = (-340.0, 0.0)
	    group_output.location = (514.6207885742188, 7.660621643066406)
	    object_info.location = (-335.33624267578125, -87.3990478515625)
	    geometry_proximity.location = (-101.05105590820312, -93.83245849609375)
	    raycast.location = (-103.23592376708984, -150.73916625976562)
	    switch.location = (135.37612915039062, -167.15541076660156)
	    set_position.location = (326.0909423828125, -47.868614196777344)
	    normal.location = (-337.0169677734375, -124.29570007324219)
	    normal_invert.location = (-334.8321228027344, -186.67495727539062)
	    compare.location = (132.731201171875, -91.82608032226562)
	    boolean_math.location = (135.02377319335938, -129.03485107421875)
	    subdivision_surface.location = (-97.95836639404297, 224.32875061035156)
	    group_input_001.location = (-340.0, 128.0421905517578)
	    domain_size.location = (-93.5887451171875, -44.727699279785156)
	    shrinkwrap_bypass.location = (323.7242431640625, -17.368263244628906)
	    has_points.location = (-94.68109130859375, -9.240226745605469)
	
	    #Set dimensions
	    group_input.width, group_input.height = 140.0, 100.0
	    group_output.width, group_output.height = 140.0, 100.0
	    object_info.width, object_info.height = 140.0, 100.0
	    geometry_proximity.width, geometry_proximity.height = 140.0, 100.0
	    raycast.width, raycast.height = 150.0, 100.0
	    switch.width, switch.height = 140.0, 100.0
	    set_position.width, set_position.height = 140.0, 100.0
	    normal.width, normal.height = 140.0, 100.0
	    normal_invert.width, normal_invert.height = 140.0, 100.0
	    compare.width, compare.height = 140.0, 100.0
	    boolean_math.width, boolean_math.height = 140.0, 100.0
	    subdivision_surface.width, subdivision_surface.height = 150.0, 100.0
	    group_input_001.width, group_input_001.height = 140.0, 100.0
	    domain_size.width, domain_size.height = 140.0, 100.0
	    shrinkwrap_bypass.width, shrinkwrap_bypass.height = 140.0, 100.0
	    has_points.width, has_points.height = 140.0, 100.0
	
	    #initialize subdivision_shrinkwrap links
	    #group_input.Surface -> object_info.Object
	    subdivision_shrinkwrap.links.new(group_input.outputs[1], object_info.inputs[0])
	    #object_info.Geometry -> geometry_proximity.Geometry
	    subdivision_shrinkwrap.links.new(object_info.outputs[4], geometry_proximity.inputs[0])
	    #object_info.Geometry -> raycast.Target Geometry
	    subdivision_shrinkwrap.links.new(object_info.outputs[4], raycast.inputs[0])
	    #normal.Normal -> normal_invert.Vector
	    subdivision_shrinkwrap.links.new(normal.outputs[0], normal_invert.inputs[0])
	    #normal_invert.Vector -> raycast.Ray Direction
	    subdivision_shrinkwrap.links.new(normal_invert.outputs[0], raycast.inputs[3])
	    #geometry_proximity.Distance -> compare.B
	    subdivision_shrinkwrap.links.new(geometry_proximity.outputs[1], compare.inputs[1])
	    #raycast.Hit Distance -> compare.A
	    subdivision_shrinkwrap.links.new(raycast.outputs[3], compare.inputs[0])
	    #boolean_math.Boolean -> switch.Switch
	    subdivision_shrinkwrap.links.new(boolean_math.outputs[0], switch.inputs[0])
	    #compare.Result -> boolean_math.Boolean
	    subdivision_shrinkwrap.links.new(compare.outputs[0], boolean_math.inputs[0])
	    #raycast.Is Hit -> boolean_math.Boolean
	    subdivision_shrinkwrap.links.new(raycast.outputs[0], boolean_math.inputs[1])
	    #raycast.Hit Position -> switch.True
	    subdivision_shrinkwrap.links.new(raycast.outputs[1], switch.inputs[2])
	    #geometry_proximity.Position -> switch.False
	    subdivision_shrinkwrap.links.new(geometry_proximity.outputs[0], switch.inputs[1])
	    #switch.Output -> set_position.Position
	    subdivision_shrinkwrap.links.new(switch.outputs[0], set_position.inputs[2])
	    #group_input.Geometry -> subdivision_surface.Mesh
	    subdivision_shrinkwrap.links.new(group_input.outputs[0], subdivision_surface.inputs[0])
	    #subdivision_surface.Mesh -> set_position.Geometry
	    subdivision_shrinkwrap.links.new(subdivision_surface.outputs[0], set_position.inputs[0])
	    #group_input_001.Subdivision Level -> subdivision_surface.Level
	    subdivision_shrinkwrap.links.new(group_input_001.outputs[2], subdivision_surface.inputs[1])
	    #group_input_001.Edge Crease -> subdivision_surface.Edge Crease
	    subdivision_shrinkwrap.links.new(group_input_001.outputs[3], subdivision_surface.inputs[2])
	    #group_input_001.Vertex Crease -> subdivision_surface.Vertex Crease
	    subdivision_shrinkwrap.links.new(group_input_001.outputs[4], subdivision_surface.inputs[3])
	    #group_input_001.Limit Surface -> subdivision_surface.Limit Surface
	    subdivision_shrinkwrap.links.new(group_input_001.outputs[5], subdivision_surface.inputs[4])
	    #object_info.Geometry -> domain_size.Geometry
	    subdivision_shrinkwrap.links.new(object_info.outputs[4], domain_size.inputs[0])
	    #domain_size.Point Count -> has_points.A
	    subdivision_shrinkwrap.links.new(domain_size.outputs[0], has_points.inputs[2])
	    #has_points.Result -> shrinkwrap_bypass.Switch
	    subdivision_shrinkwrap.links.new(has_points.outputs[0], shrinkwrap_bypass.inputs[0])
	    #set_position.Geometry -> shrinkwrap_bypass.True
	    subdivision_shrinkwrap.links.new(set_position.outputs[0], shrinkwrap_bypass.inputs[2])
	    #subdivision_surface.Mesh -> shrinkwrap_bypass.False
	    subdivision_shrinkwrap.links.new(subdivision_surface.outputs[0], shrinkwrap_bypass.inputs[1])
	    #shrinkwrap_bypass.Output -> group_output.Geometry
	    subdivision_shrinkwrap.links.new(shrinkwrap_bypass.outputs[0], group_output.inputs[0])
	    return subdivision_shrinkwrap
	return subdivision_shrinkwrap_node_group()

	

	
