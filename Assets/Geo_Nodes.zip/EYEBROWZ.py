import bpy, mathutils

def node():
	#initialize curve_root node group
	def curve_root_node_group():
	    curve_root = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Curve Root")
	
	    curve_root.color_tag = 'INPUT'
	    curve_root.description = "Reads information about each curve's root point"
	    curve_root.default_group_node_width = 140
	    
	
	
	    #curve_root interface
	    #Socket Root Selection
	    root_selection_socket = curve_root.interface.new_socket(name = "Root Selection", in_out='OUTPUT', socket_type = 'NodeSocketBool')
	    root_selection_socket.default_value = False
	    root_selection_socket.attribute_domain = 'POINT'
	    root_selection_socket.description = "Boolean selection of curve root points"
	
	    #Socket Root Position
	    root_position_socket = curve_root.interface.new_socket(name = "Root Position", in_out='OUTPUT', socket_type = 'NodeSocketVector')
	    root_position_socket.default_value = (0.0, 0.0, 0.0)
	    root_position_socket.min_value = -3.4028234663852886e+38
	    root_position_socket.max_value = 3.4028234663852886e+38
	    root_position_socket.subtype = 'NONE'
	    root_position_socket.attribute_domain = 'CURVE'
	    root_position_socket.description = "Position of the root point of a curve"
	
	    #Socket Root Direction
	    root_direction_socket = curve_root.interface.new_socket(name = "Root Direction", in_out='OUTPUT', socket_type = 'NodeSocketVector')
	    root_direction_socket.default_value = (0.0, 0.0, 0.0)
	    root_direction_socket.min_value = -3.4028234663852886e+38
	    root_direction_socket.max_value = 3.4028234663852886e+38
	    root_direction_socket.subtype = 'NONE'
	    root_direction_socket.attribute_domain = 'CURVE'
	    root_direction_socket.description = "Direction of the root segment of a curve"
	
	    #Socket Root Index
	    root_index_socket = curve_root.interface.new_socket(name = "Root Index", in_out='OUTPUT', socket_type = 'NodeSocketInt')
	    root_index_socket.default_value = 0
	    root_index_socket.min_value = -2147483648
	    root_index_socket.max_value = 2147483647
	    root_index_socket.subtype = 'NONE'
	    root_index_socket.attribute_domain = 'CURVE'
	    root_index_socket.description = "Index of the root point of a curve"
	
	
	    #initialize curve_root nodes
	    #node Position.002
	    position_002 = curve_root.nodes.new("GeometryNodeInputPosition")
	    position_002.name = "Position.002"
	
	    #node Interpolate Domain
	    interpolate_domain = curve_root.nodes.new("GeometryNodeFieldOnDomain")
	    interpolate_domain.name = "Interpolate Domain"
	    interpolate_domain.data_type = 'INT'
	    interpolate_domain.domain = 'CURVE'
	
	    #node Field at Index.003
	    field_at_index_003 = curve_root.nodes.new("GeometryNodeFieldAtIndex")
	    field_at_index_003.name = "Field at Index.003"
	    field_at_index_003.data_type = 'FLOAT_VECTOR'
	    field_at_index_003.domain = 'POINT'
	
	    #node Interpolate Domain.001
	    interpolate_domain_001 = curve_root.nodes.new("GeometryNodeFieldOnDomain")
	    interpolate_domain_001.name = "Interpolate Domain.001"
	    interpolate_domain_001.data_type = 'FLOAT_VECTOR'
	    interpolate_domain_001.domain = 'CURVE'
	
	    #node Curve Tangent
	    curve_tangent = curve_root.nodes.new("GeometryNodeInputTangent")
	    curve_tangent.name = "Curve Tangent"
	
	    #node Endpoint Selection
	    endpoint_selection = curve_root.nodes.new("GeometryNodeCurveEndpointSelection")
	    endpoint_selection.name = "Endpoint Selection"
	    #Start Size
	    endpoint_selection.inputs[0].default_value = 1
	    #End Size
	    endpoint_selection.inputs[1].default_value = 0
	
	    #node Field at Index.004
	    field_at_index_004 = curve_root.nodes.new("GeometryNodeFieldAtIndex")
	    field_at_index_004.name = "Field at Index.004"
	    field_at_index_004.data_type = 'FLOAT_VECTOR'
	    field_at_index_004.domain = 'POINT'
	
	    #node Interpolate Domain.002
	    interpolate_domain_002 = curve_root.nodes.new("GeometryNodeFieldOnDomain")
	    interpolate_domain_002.name = "Interpolate Domain.002"
	    interpolate_domain_002.data_type = 'FLOAT_VECTOR'
	    interpolate_domain_002.domain = 'CURVE'
	
	    #node Group Output
	    group_output = curve_root.nodes.new("NodeGroupOutput")
	    group_output.name = "Group Output"
	    group_output.is_active_output = True
	
	    #node Points of Curve
	    points_of_curve = curve_root.nodes.new("GeometryNodePointsOfCurve")
	    points_of_curve.name = "Points of Curve"
	    points_of_curve.inputs[0].hide = True
	    points_of_curve.inputs[1].hide = True
	    points_of_curve.outputs[1].hide = True
	    #Curve Index
	    points_of_curve.inputs[0].default_value = 0
	    #Weights
	    points_of_curve.inputs[1].default_value = 0.0
	    #Sort Index
	    points_of_curve.inputs[2].default_value = 0
	
	
	
	
	
	    #Set locations
	    position_002.location = (-608.1627807617188, -70.55814361572266)
	    interpolate_domain.location = (-608.1627807617188, 90.18604278564453)
	    field_at_index_003.location = (-407.2325439453125, 70.09302520751953)
	    interpolate_domain_001.location = (-206.30230712890625, 70.09302520751953)
	    curve_tangent.location = (-608.1627807617188, -271.4883728027344)
	    endpoint_selection.location = (-206.30230712890625, 190.65118408203125)
	    field_at_index_004.location = (-407.2325439453125, -130.83721923828125)
	    interpolate_domain_002.location = (-206.30230712890625, -130.83721923828125)
	    group_output.location = (75.0, 50.0)
	    points_of_curve.location = (-789.0, 50.0)
	
	    #Set dimensions
	    position_002.width, position_002.height = 140.0, 100.0
	    interpolate_domain.width, interpolate_domain.height = 140.0, 100.0
	    field_at_index_003.width, field_at_index_003.height = 140.0, 100.0
	    interpolate_domain_001.width, interpolate_domain_001.height = 140.0, 100.0
	    curve_tangent.width, curve_tangent.height = 140.0, 100.0
	    endpoint_selection.width, endpoint_selection.height = 140.0, 100.0
	    field_at_index_004.width, field_at_index_004.height = 140.0, 100.0
	    interpolate_domain_002.width, interpolate_domain_002.height = 140.0, 100.0
	    group_output.width, group_output.height = 140.0, 100.0
	    points_of_curve.width, points_of_curve.height = 140.0, 100.0
	
	    #initialize curve_root links
	    #position_002.Position -> field_at_index_003.Value
	    curve_root.links.new(position_002.outputs[0], field_at_index_003.inputs[1])
	    #interpolate_domain_001.Value -> group_output.Root Position
	    curve_root.links.new(interpolate_domain_001.outputs[0], group_output.inputs[1])
	    #interpolate_domain.Value -> field_at_index_003.Index
	    curve_root.links.new(interpolate_domain.outputs[0], field_at_index_003.inputs[0])
	    #points_of_curve.Point Index -> interpolate_domain.Value
	    curve_root.links.new(points_of_curve.outputs[0], interpolate_domain.inputs[0])
	    #interpolate_domain.Value -> group_output.Root Index
	    curve_root.links.new(interpolate_domain.outputs[0], group_output.inputs[3])
	    #endpoint_selection.Selection -> group_output.Root Selection
	    curve_root.links.new(endpoint_selection.outputs[0], group_output.inputs[0])
	    #field_at_index_003.Value -> interpolate_domain_001.Value
	    curve_root.links.new(field_at_index_003.outputs[0], interpolate_domain_001.inputs[0])
	    #interpolate_domain_002.Value -> group_output.Root Direction
	    curve_root.links.new(interpolate_domain_002.outputs[0], group_output.inputs[2])
	    #interpolate_domain.Value -> field_at_index_004.Index
	    curve_root.links.new(interpolate_domain.outputs[0], field_at_index_004.inputs[0])
	    #curve_tangent.Tangent -> field_at_index_004.Value
	    curve_root.links.new(curve_tangent.outputs[0], field_at_index_004.inputs[1])
	    #field_at_index_004.Value -> interpolate_domain_002.Value
	    curve_root.links.new(field_at_index_004.outputs[0], interpolate_domain_002.inputs[0])
	    return curve_root
	
	curve_root = curve_root_node_group()
	
	#initialize curve_tip node group
	def curve_tip_node_group():
	    curve_tip = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Curve Tip")
	
	    curve_tip.color_tag = 'INPUT'
	    curve_tip.description = "Reads information about each curve's tip point"
	    curve_tip.default_group_node_width = 140
	    
	
	
	    #curve_tip interface
	    #Socket Tip Selection
	    tip_selection_socket = curve_tip.interface.new_socket(name = "Tip Selection", in_out='OUTPUT', socket_type = 'NodeSocketBool')
	    tip_selection_socket.default_value = False
	    tip_selection_socket.attribute_domain = 'POINT'
	    tip_selection_socket.description = "Boolean selection of curve tip points"
	
	    #Socket Tip Position
	    tip_position_socket = curve_tip.interface.new_socket(name = "Tip Position", in_out='OUTPUT', socket_type = 'NodeSocketVector')
	    tip_position_socket.default_value = (0.0, 0.0, 0.0)
	    tip_position_socket.min_value = -3.4028234663852886e+38
	    tip_position_socket.max_value = 3.4028234663852886e+38
	    tip_position_socket.subtype = 'NONE'
	    tip_position_socket.attribute_domain = 'CURVE'
	    tip_position_socket.description = "Position of the tip point of a curve"
	
	    #Socket Tip Direction
	    tip_direction_socket = curve_tip.interface.new_socket(name = "Tip Direction", in_out='OUTPUT', socket_type = 'NodeSocketVector')
	    tip_direction_socket.default_value = (0.0, 0.0, 0.0)
	    tip_direction_socket.min_value = -3.4028234663852886e+38
	    tip_direction_socket.max_value = 3.4028234663852886e+38
	    tip_direction_socket.subtype = 'NONE'
	    tip_direction_socket.attribute_domain = 'CURVE'
	    tip_direction_socket.description = "Direction of the tip segment of a curve"
	
	    #Socket Tip Index
	    tip_index_socket = curve_tip.interface.new_socket(name = "Tip Index", in_out='OUTPUT', socket_type = 'NodeSocketInt')
	    tip_index_socket.default_value = 0
	    tip_index_socket.min_value = -2147483648
	    tip_index_socket.max_value = 2147483647
	    tip_index_socket.subtype = 'NONE'
	    tip_index_socket.attribute_domain = 'CURVE'
	    tip_index_socket.description = "Index of the tip point of a curve"
	
	
	    #initialize curve_tip nodes
	    #node Position.002
	    position_002_1 = curve_tip.nodes.new("GeometryNodeInputPosition")
	    position_002_1.name = "Position.002"
	
	    #node Interpolate Domain
	    interpolate_domain_1 = curve_tip.nodes.new("GeometryNodeFieldOnDomain")
	    interpolate_domain_1.name = "Interpolate Domain"
	    interpolate_domain_1.data_type = 'INT'
	    interpolate_domain_1.domain = 'CURVE'
	
	    #node Interpolate Domain.001
	    interpolate_domain_001_1 = curve_tip.nodes.new("GeometryNodeFieldOnDomain")
	    interpolate_domain_001_1.name = "Interpolate Domain.001"
	    interpolate_domain_001_1.data_type = 'FLOAT_VECTOR'
	    interpolate_domain_001_1.domain = 'CURVE'
	
	    #node Field at Index.003
	    field_at_index_003_1 = curve_tip.nodes.new("GeometryNodeFieldAtIndex")
	    field_at_index_003_1.name = "Field at Index.003"
	    field_at_index_003_1.data_type = 'FLOAT_VECTOR'
	    field_at_index_003_1.domain = 'POINT'
	
	    #node Curve Tangent
	    curve_tangent_1 = curve_tip.nodes.new("GeometryNodeInputTangent")
	    curve_tangent_1.name = "Curve Tangent"
	
	    #node Endpoint Selection
	    endpoint_selection_1 = curve_tip.nodes.new("GeometryNodeCurveEndpointSelection")
	    endpoint_selection_1.name = "Endpoint Selection"
	    #Start Size
	    endpoint_selection_1.inputs[0].default_value = 0
	    #End Size
	    endpoint_selection_1.inputs[1].default_value = 1
	
	    #node Field at Index.004
	    field_at_index_004_1 = curve_tip.nodes.new("GeometryNodeFieldAtIndex")
	    field_at_index_004_1.name = "Field at Index.004"
	    field_at_index_004_1.data_type = 'FLOAT_VECTOR'
	    field_at_index_004_1.domain = 'POINT'
	
	    #node Interpolate Domain.002
	    interpolate_domain_002_1 = curve_tip.nodes.new("GeometryNodeFieldOnDomain")
	    interpolate_domain_002_1.name = "Interpolate Domain.002"
	    interpolate_domain_002_1.data_type = 'FLOAT_VECTOR'
	    interpolate_domain_002_1.domain = 'CURVE'
	
	    #node Group Output
	    group_output_1 = curve_tip.nodes.new("NodeGroupOutput")
	    group_output_1.name = "Group Output"
	    group_output_1.is_active_output = True
	
	    #node Points of Curve
	    points_of_curve_1 = curve_tip.nodes.new("GeometryNodePointsOfCurve")
	    points_of_curve_1.name = "Points of Curve"
	    points_of_curve_1.inputs[0].hide = True
	    points_of_curve_1.inputs[1].hide = True
	    points_of_curve_1.outputs[1].hide = True
	    #Curve Index
	    points_of_curve_1.inputs[0].default_value = 0
	    #Weights
	    points_of_curve_1.inputs[1].default_value = 0.0
	    #Sort Index
	    points_of_curve_1.inputs[2].default_value = -1
	
	
	
	
	
	    #Set locations
	    position_002_1.location = (-628.2557983398438, -70.55813598632812)
	    interpolate_domain_1.location = (-628.2557983398438, 90.18605041503906)
	    interpolate_domain_001_1.location = (-246.4883575439453, 90.18605041503906)
	    field_at_index_003_1.location = (-427.3255615234375, 90.18605041503906)
	    curve_tangent_1.location = (-628.2557983398438, -231.3023223876953)
	    endpoint_selection_1.location = (-246.4883575439453, 210.7441864013672)
	    field_at_index_004_1.location = (-427.3255615234375, -90.65116882324219)
	    interpolate_domain_002_1.location = (-246.4883575439453, -90.65116882324219)
	    group_output_1.location = (75.0, 50.0)
	    points_of_curve_1.location = (-829.18603515625, 50.0)
	
	    #Set dimensions
	    position_002_1.width, position_002_1.height = 140.0, 100.0
	    interpolate_domain_1.width, interpolate_domain_1.height = 140.0, 100.0
	    interpolate_domain_001_1.width, interpolate_domain_001_1.height = 140.0, 100.0
	    field_at_index_003_1.width, field_at_index_003_1.height = 140.0, 100.0
	    curve_tangent_1.width, curve_tangent_1.height = 140.0, 100.0
	    endpoint_selection_1.width, endpoint_selection_1.height = 140.0, 100.0
	    field_at_index_004_1.width, field_at_index_004_1.height = 140.0, 100.0
	    interpolate_domain_002_1.width, interpolate_domain_002_1.height = 140.0, 100.0
	    group_output_1.width, group_output_1.height = 140.0, 100.0
	    points_of_curve_1.width, points_of_curve_1.height = 140.0, 100.0
	
	    #initialize curve_tip links
	    #position_002_1.Position -> field_at_index_003_1.Value
	    curve_tip.links.new(position_002_1.outputs[0], field_at_index_003_1.inputs[1])
	    #interpolate_domain_1.Value -> field_at_index_003_1.Index
	    curve_tip.links.new(interpolate_domain_1.outputs[0], field_at_index_003_1.inputs[0])
	    #points_of_curve_1.Point Index -> interpolate_domain_1.Value
	    curve_tip.links.new(points_of_curve_1.outputs[0], interpolate_domain_1.inputs[0])
	    #interpolate_domain_001_1.Value -> group_output_1.Tip Position
	    curve_tip.links.new(interpolate_domain_001_1.outputs[0], group_output_1.inputs[1])
	    #interpolate_domain_1.Value -> group_output_1.Tip Index
	    curve_tip.links.new(interpolate_domain_1.outputs[0], group_output_1.inputs[3])
	    #endpoint_selection_1.Selection -> group_output_1.Tip Selection
	    curve_tip.links.new(endpoint_selection_1.outputs[0], group_output_1.inputs[0])
	    #field_at_index_003_1.Value -> interpolate_domain_001_1.Value
	    curve_tip.links.new(field_at_index_003_1.outputs[0], interpolate_domain_001_1.inputs[0])
	    #interpolate_domain_002_1.Value -> group_output_1.Tip Direction
	    curve_tip.links.new(interpolate_domain_002_1.outputs[0], group_output_1.inputs[2])
	    #curve_tangent_1.Tangent -> field_at_index_004_1.Value
	    curve_tip.links.new(curve_tangent_1.outputs[0], field_at_index_004_1.inputs[1])
	    #interpolate_domain_1.Value -> field_at_index_004_1.Index
	    curve_tip.links.new(interpolate_domain_1.outputs[0], field_at_index_004_1.inputs[0])
	    #field_at_index_004_1.Value -> interpolate_domain_002_1.Value
	    curve_tip.links.new(field_at_index_004_1.outputs[0], interpolate_domain_002_1.inputs[0])
	    return curve_tip
	
	curve_tip = curve_tip_node_group()
	
	#initialize curve_info node group
	def curve_info_node_group():
	    curve_info = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Curve Info")
	
	    curve_info.color_tag = 'INPUT'
	    curve_info.description = "Reads information about each curve"
	    curve_info.default_group_node_width = 140
	    
	
	
	    #curve_info interface
	    #Socket Curve Index
	    curve_index_socket = curve_info.interface.new_socket(name = "Curve Index", in_out='OUTPUT', socket_type = 'NodeSocketInt')
	    curve_index_socket.default_value = 0
	    curve_index_socket.min_value = -2147483648
	    curve_index_socket.max_value = 2147483647
	    curve_index_socket.subtype = 'NONE'
	    curve_index_socket.attribute_domain = 'CURVE'
	    curve_index_socket.description = "Index of each Curve"
	
	    #Socket Curve ID
	    curve_id_socket = curve_info.interface.new_socket(name = "Curve ID", in_out='OUTPUT', socket_type = 'NodeSocketInt')
	    curve_id_socket.default_value = 0
	    curve_id_socket.min_value = -2147483648
	    curve_id_socket.max_value = 2147483647
	    curve_id_socket.subtype = 'NONE'
	    curve_id_socket.attribute_domain = 'CURVE'
	    curve_id_socket.description = "ID of each curve"
	
	    #Socket Length
	    length_socket = curve_info.interface.new_socket(name = "Length", in_out='OUTPUT', socket_type = 'NodeSocketFloat')
	    length_socket.default_value = 0.0
	    length_socket.min_value = -3.4028234663852886e+38
	    length_socket.max_value = 3.4028234663852886e+38
	    length_socket.subtype = 'NONE'
	    length_socket.attribute_domain = 'CURVE'
	    length_socket.description = "Length of each curve"
	
	    #Socket Direction
	    direction_socket = curve_info.interface.new_socket(name = "Direction", in_out='OUTPUT', socket_type = 'NodeSocketVector')
	    direction_socket.default_value = (0.0, 0.0, 0.0)
	    direction_socket.min_value = -3.4028234663852886e+38
	    direction_socket.max_value = 3.4028234663852886e+38
	    direction_socket.subtype = 'NONE'
	    direction_socket.attribute_domain = 'CURVE'
	    direction_socket.description = "Direction from root to tip of each curve"
	
	    #Socket Random
	    random_socket = curve_info.interface.new_socket(name = "Random", in_out='OUTPUT', socket_type = 'NodeSocketFloat')
	    random_socket.default_value = 0.0
	    random_socket.min_value = -3.4028234663852886e+38
	    random_socket.max_value = 3.4028234663852886e+38
	    random_socket.subtype = 'NONE'
	    random_socket.attribute_domain = 'CURVE'
	    random_socket.description = "Random vector for each curve"
	
	    #Socket Surface UV
	    surface_uv_socket = curve_info.interface.new_socket(name = "Surface UV", in_out='OUTPUT', socket_type = 'NodeSocketVector')
	    surface_uv_socket.default_value = (0.0, 0.0, 0.0)
	    surface_uv_socket.min_value = -3.4028234663852886e+38
	    surface_uv_socket.max_value = 3.4028234663852886e+38
	    surface_uv_socket.subtype = 'NONE'
	    surface_uv_socket.attribute_domain = 'CURVE'
	    surface_uv_socket.description = "Attachment surface UV coordinates of each curve"
	
	
	    #initialize curve_info nodes
	    #node Frame
	    frame = curve_info.nodes.new("NodeFrame")
	    frame.label = "ID per Curve"
	    frame.name = "Frame"
	    frame.label_size = 20
	    frame.shrink = True
	
	    #node Group Output
	    group_output_2 = curve_info.nodes.new("NodeGroupOutput")
	    group_output_2.name = "Group Output"
	    group_output_2.is_active_output = True
	
	    #node Named Attribute
	    named_attribute = curve_info.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute.name = "Named Attribute"
	    named_attribute.data_type = 'FLOAT_VECTOR'
	    #Name
	    named_attribute.inputs[0].default_value = "surface_uv_coordinate"
	
	    #node Group.002
	    group_002 = curve_info.nodes.new("GeometryNodeGroup")
	    group_002.name = "Group.002"
	    group_002.node_tree = curve_tip
	    group_002.outputs[0].hide = True
	    group_002.outputs[2].hide = True
	    group_002.outputs[3].hide = True
	
	    #node Group.001
	    group_001 = curve_info.nodes.new("GeometryNodeGroup")
	    group_001.name = "Group.001"
	    group_001.node_tree = curve_root
	    group_001.outputs[0].hide = True
	    group_001.outputs[2].hide = True
	    group_001.outputs[3].hide = True
	
	    #node Evaluate at Index
	    evaluate_at_index = curve_info.nodes.new("GeometryNodeFieldAtIndex")
	    evaluate_at_index.name = "Evaluate at Index"
	    evaluate_at_index.data_type = 'FLOAT'
	    evaluate_at_index.domain = 'POINT'
	
	    #node Evaluate on Domain.001
	    evaluate_on_domain_001 = curve_info.nodes.new("GeometryNodeFieldOnDomain")
	    evaluate_on_domain_001.name = "Evaluate on Domain.001"
	    evaluate_on_domain_001.data_type = 'FLOAT'
	    evaluate_on_domain_001.domain = 'CURVE'
	
	    #node Group.003
	    group_003 = curve_info.nodes.new("GeometryNodeGroup")
	    group_003.name = "Group.003"
	    group_003.node_tree = curve_root
	    group_003.outputs[0].hide = True
	    group_003.outputs[1].hide = True
	    group_003.outputs[2].hide = True
	
	    #node Random Value.002
	    random_value_002 = curve_info.nodes.new("FunctionNodeRandomValue")
	    random_value_002.name = "Random Value.002"
	    random_value_002.data_type = 'FLOAT'
	    #Min_001
	    random_value_002.inputs[2].default_value = 0.0
	    #Max_001
	    random_value_002.inputs[3].default_value = 1.0
	    #Seed
	    random_value_002.inputs[8].default_value = 0
	
	    #node Reroute
	    reroute = curve_info.nodes.new("NodeReroute")
	    reroute.name = "Reroute"
	    reroute.socket_idname = "NodeSocketInt"
	    #node Vector Math
	    vector_math = curve_info.nodes.new("ShaderNodeVectorMath")
	    vector_math.name = "Vector Math"
	    vector_math.operation = 'SUBTRACT'
	
	    #node Vector Math.001
	    vector_math_001 = curve_info.nodes.new("ShaderNodeVectorMath")
	    vector_math_001.name = "Vector Math.001"
	    vector_math_001.operation = 'NORMALIZE'
	
	    #node Evaluate on Domain
	    evaluate_on_domain = curve_info.nodes.new("GeometryNodeFieldOnDomain")
	    evaluate_on_domain.name = "Evaluate on Domain"
	    evaluate_on_domain.hide = True
	    evaluate_on_domain.data_type = 'INT'
	    evaluate_on_domain.domain = 'CURVE'
	
	    #node Index.001
	    index_001 = curve_info.nodes.new("GeometryNodeInputIndex")
	    index_001.name = "Index.001"
	
	    #node Spline Length
	    spline_length = curve_info.nodes.new("GeometryNodeSplineLength")
	    spline_length.name = "Spline Length"
	    spline_length.outputs[1].hide = True
	
	    #node Evaluate at Index.001
	    evaluate_at_index_001 = curve_info.nodes.new("GeometryNodeFieldAtIndex")
	    evaluate_at_index_001.name = "Evaluate at Index.001"
	    evaluate_at_index_001.data_type = 'INT'
	    evaluate_at_index_001.domain = 'POINT'
	
	    #node Evaluate on Domain.002
	    evaluate_on_domain_002 = curve_info.nodes.new("GeometryNodeFieldOnDomain")
	    evaluate_on_domain_002.name = "Evaluate on Domain.002"
	    evaluate_on_domain_002.data_type = 'INT'
	    evaluate_on_domain_002.domain = 'CURVE'
	
	    #node Group
	    group = curve_info.nodes.new("GeometryNodeGroup")
	    group.name = "Group"
	    group.node_tree = curve_root
	    group.outputs[0].hide = True
	    group.outputs[1].hide = True
	    group.outputs[2].hide = True
	
	    #node ID
	    id = curve_info.nodes.new("GeometryNodeInputID")
	    id.name = "ID"
	
	
	
	
	    #Set parents
	    evaluate_at_index_001.parent = frame
	    evaluate_on_domain_002.parent = frame
	    group.parent = frame
	    id.parent = frame
	
	    #Set locations
	    frame.location = (-1201.4400634765625, 150.51998901367188)
	    group_output_2.location = (75.0, 50.0)
	    named_attribute.location = (-166.11627197265625, -371.9534912109375)
	    group_002.location = (-527.7907104492188, -90.65116882324219)
	    group_001.location = (-527.7907104492188, -171.02325439453125)
	    evaluate_at_index.location = (-346.9534912109375, -211.2093048095703)
	    evaluate_on_domain_001.location = (-166.11627197265625, -211.2093048095703)
	    group_003.location = (-527.7907104492188, -251.39535522460938)
	    random_value_002.location = (-527.7907104492188, -331.7674560546875)
	    reroute.location = (-608.162841796875, 29.906982421875)
	    vector_math.location = (-346.9534912109375, -70.55814361572266)
	    vector_math_001.location = (-166.11627197265625, -70.55814361572266)
	    evaluate_on_domain.location = (-166.11627197265625, 70.093017578125)
	    index_001.location = (-346.9534912109375, 110.27906799316406)
	    spline_length.location = (-166.11627197265625, -10.279067993164062)
	    evaluate_at_index_001.location = (211.50982666015625, -40.24092102050781)
	    evaluate_on_domain_002.location = (392.3470458984375, -40.24092102050781)
	    group.location = (30.672607421875, -60.333953857421875)
	    id.location = (30.672607421875, -140.70603942871094)
	
	    #Set dimensions
	    frame.width, frame.height = 562.4000244140625, 221.07998657226562
	    group_output_2.width, group_output_2.height = 140.0, 100.0
	    named_attribute.width, named_attribute.height = 140.0, 100.0
	    group_002.width, group_002.height = 140.0, 100.0
	    group_001.width, group_001.height = 140.0, 100.0
	    evaluate_at_index.width, evaluate_at_index.height = 140.0, 100.0
	    evaluate_on_domain_001.width, evaluate_on_domain_001.height = 140.0, 100.0
	    group_003.width, group_003.height = 140.0, 100.0
	    random_value_002.width, random_value_002.height = 140.0, 100.0
	    reroute.width, reroute.height = 100.0, 100.0
	    vector_math.width, vector_math.height = 140.0, 100.0
	    vector_math_001.width, vector_math_001.height = 140.0, 100.0
	    evaluate_on_domain.width, evaluate_on_domain.height = 140.0, 100.0
	    index_001.width, index_001.height = 140.0, 100.0
	    spline_length.width, spline_length.height = 140.0, 100.0
	    evaluate_at_index_001.width, evaluate_at_index_001.height = 140.0, 100.0
	    evaluate_on_domain_002.width, evaluate_on_domain_002.height = 140.0, 100.0
	    group.width, group.height = 140.0, 100.0
	    id.width, id.height = 140.0, 100.0
	
	    #initialize curve_info links
	    #index_001.Index -> evaluate_on_domain.Value
	    curve_info.links.new(index_001.outputs[0], evaluate_on_domain.inputs[0])
	    #evaluate_on_domain.Value -> group_output_2.Curve Index
	    curve_info.links.new(evaluate_on_domain.outputs[0], group_output_2.inputs[0])
	    #named_attribute.Attribute -> group_output_2.Surface UV
	    curve_info.links.new(named_attribute.outputs[0], group_output_2.inputs[5])
	    #evaluate_at_index_001.Value -> evaluate_on_domain_002.Value
	    curve_info.links.new(evaluate_at_index_001.outputs[0], evaluate_on_domain_002.inputs[0])
	    #group.Root Index -> evaluate_at_index_001.Index
	    curve_info.links.new(group.outputs[3], evaluate_at_index_001.inputs[0])
	    #reroute.Output -> group_output_2.Curve ID
	    curve_info.links.new(reroute.outputs[0], group_output_2.inputs[1])
	    #id.ID -> evaluate_at_index_001.Value
	    curve_info.links.new(id.outputs[0], evaluate_at_index_001.inputs[1])
	    #spline_length.Length -> group_output_2.Length
	    curve_info.links.new(spline_length.outputs[0], group_output_2.inputs[2])
	    #group_002.Tip Position -> vector_math.Vector
	    curve_info.links.new(group_002.outputs[1], vector_math.inputs[0])
	    #group_001.Root Position -> vector_math.Vector
	    curve_info.links.new(group_001.outputs[1], vector_math.inputs[1])
	    #vector_math_001.Vector -> group_output_2.Direction
	    curve_info.links.new(vector_math_001.outputs[0], group_output_2.inputs[3])
	    #vector_math.Vector -> vector_math_001.Vector
	    curve_info.links.new(vector_math.outputs[0], vector_math_001.inputs[0])
	    #reroute.Output -> random_value_002.ID
	    curve_info.links.new(reroute.outputs[0], random_value_002.inputs[7])
	    #evaluate_at_index.Value -> evaluate_on_domain_001.Value
	    curve_info.links.new(evaluate_at_index.outputs[0], evaluate_on_domain_001.inputs[0])
	    #evaluate_on_domain_001.Value -> group_output_2.Random
	    curve_info.links.new(evaluate_on_domain_001.outputs[0], group_output_2.inputs[4])
	    #random_value_002.Value -> evaluate_at_index.Value
	    curve_info.links.new(random_value_002.outputs[1], evaluate_at_index.inputs[1])
	    #group_003.Root Index -> evaluate_at_index.Index
	    curve_info.links.new(group_003.outputs[3], evaluate_at_index.inputs[0])
	    #evaluate_on_domain_002.Value -> reroute.Input
	    curve_info.links.new(evaluate_on_domain_002.outputs[0], reroute.inputs[0])
	    return curve_info
	
	curve_info = curve_info_node_group()
	
	#initialize duplicate_hair_curves node group
	def duplicate_hair_curves_node_group():
	    duplicate_hair_curves = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Duplicate Hair Curves")
	
	    duplicate_hair_curves.color_tag = 'GEOMETRY'
	    duplicate_hair_curves.description = "Duplicates hair curves a certain number of times within a radius"
	    duplicate_hair_curves.default_group_node_width = 140
	    
	
	    duplicate_hair_curves.is_modifier = True
	
	    #duplicate_hair_curves interface
	    #Socket Geometry
	    geometry_socket = duplicate_hair_curves.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket.attribute_domain = 'POINT'
	
	    #Socket Guide Index
	    guide_index_socket = duplicate_hair_curves.interface.new_socket(name = "Guide Index", in_out='OUTPUT', socket_type = 'NodeSocketInt')
	    guide_index_socket.default_value = 0
	    guide_index_socket.min_value = -2147483648
	    guide_index_socket.max_value = 2147483647
	    guide_index_socket.subtype = 'NONE'
	    guide_index_socket.attribute_domain = 'CURVE'
	    guide_index_socket.description = "Guide index map that was used for the operation"
	
	    #Socket Geometry
	    geometry_socket_1 = duplicate_hair_curves.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_1.attribute_domain = 'POINT'
	    geometry_socket_1.description = "Input Geometry (May include other than curves)"
	
	    #Socket Amount
	    amount_socket = duplicate_hair_curves.interface.new_socket(name = "Amount", in_out='INPUT', socket_type = 'NodeSocketInt')
	    amount_socket.default_value = 10
	    amount_socket.min_value = 0
	    amount_socket.max_value = 2147483647
	    amount_socket.subtype = 'NONE'
	    amount_socket.attribute_domain = 'POINT'
	    amount_socket.description = "Amount of duplicates per curve"
	
	    #Socket Viewport Amount
	    viewport_amount_socket = duplicate_hair_curves.interface.new_socket(name = "Viewport Amount", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    viewport_amount_socket.default_value = 1.0
	    viewport_amount_socket.min_value = 0.0
	    viewport_amount_socket.max_value = 1.0
	    viewport_amount_socket.subtype = 'FACTOR'
	    viewport_amount_socket.attribute_domain = 'POINT'
	    viewport_amount_socket.description = "Percentage of amount used for the viewport"
	
	    #Socket Radius
	    radius_socket = duplicate_hair_curves.interface.new_socket(name = "Radius", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    radius_socket.default_value = 0.10000000149011612
	    radius_socket.min_value = 0.0
	    radius_socket.max_value = 3.4028234663852886e+38
	    radius_socket.subtype = 'DISTANCE'
	    radius_socket.attribute_domain = 'POINT'
	    radius_socket.description = "Radius in which the duplicate curves are offset from the guides"
	
	    #Socket Distribution Shape
	    distribution_shape_socket = duplicate_hair_curves.interface.new_socket(name = "Distribution Shape", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    distribution_shape_socket.default_value = 0.0
	    distribution_shape_socket.min_value = -10.0
	    distribution_shape_socket.max_value = 10.0
	    distribution_shape_socket.subtype = 'NONE'
	    distribution_shape_socket.attribute_domain = 'POINT'
	    distribution_shape_socket.description = "Shape of distribution from center to the edge around the guide"
	
	    #Socket Tip Roundness
	    tip_roundness_socket = duplicate_hair_curves.interface.new_socket(name = "Tip Roundness", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    tip_roundness_socket.default_value = 0.0
	    tip_roundness_socket.min_value = 0.0
	    tip_roundness_socket.max_value = 1.0
	    tip_roundness_socket.subtype = 'FACTOR'
	    tip_roundness_socket.attribute_domain = 'POINT'
	    tip_roundness_socket.description = "Offset of the curves to round the tip"
	
	    #Socket Even Thickness
	    even_thickness_socket = duplicate_hair_curves.interface.new_socket(name = "Even Thickness", in_out='INPUT', socket_type = 'NodeSocketBool')
	    even_thickness_socket.default_value = False
	    even_thickness_socket.attribute_domain = 'POINT'
	    even_thickness_socket.description = "Keep an even thickness of the distribution of duplicates"
	
	    #Socket Seed
	    seed_socket = duplicate_hair_curves.interface.new_socket(name = "Seed", in_out='INPUT', socket_type = 'NodeSocketInt')
	    seed_socket.default_value = 0
	    seed_socket.min_value = -10000
	    seed_socket.max_value = 10000
	    seed_socket.subtype = 'NONE'
	    seed_socket.attribute_domain = 'POINT'
	    seed_socket.description = "Random Seed for the operation"
	
	
	    #initialize duplicate_hair_curves nodes
	    #node Frame.002
	    frame_002 = duplicate_hair_curves.nodes.new("NodeFrame")
	    frame_002.label = "Random Disc Position"
	    frame_002.name = "Frame.002"
	    frame_002.label_size = 20
	    frame_002.shrink = True
	
	    #node Frame.001
	    frame_001 = duplicate_hair_curves.nodes.new("NodeFrame")
	    frame_001.label = "Tangent Space per Point"
	    frame_001.name = "Frame.001"
	    frame_001.label_size = 20
	    frame_001.shrink = True
	
	    #node Frame
	    frame_1 = duplicate_hair_curves.nodes.new("NodeFrame")
	    frame_1.label = "Tangent Space of Root Point"
	    frame_1.name = "Frame"
	    frame_1.label_size = 20
	    frame_1.shrink = True
	
	    #node Frame.004
	    frame_004 = duplicate_hair_curves.nodes.new("NodeFrame")
	    frame_004.label = "Duplicate Curves"
	    frame_004.name = "Frame.004"
	    frame_004.label_size = 20
	    frame_004.shrink = True
	
	    #node Frame.003
	    frame_003 = duplicate_hair_curves.nodes.new("NodeFrame")
	    frame_003.label = "Random Vector per Curve"
	    frame_003.name = "Frame.003"
	    frame_003.label_size = 20
	    frame_003.shrink = True
	
	    #node Reroute.016
	    reroute_016 = duplicate_hair_curves.nodes.new("NodeReroute")
	    reroute_016.name = "Reroute.016"
	    reroute_016.socket_idname = "NodeSocketGeometry"
	    #node Reroute.017
	    reroute_017 = duplicate_hair_curves.nodes.new("NodeReroute")
	    reroute_017.name = "Reroute.017"
	    reroute_017.socket_idname = "NodeSocketGeometry"
	    #node Reroute.019
	    reroute_019 = duplicate_hair_curves.nodes.new("NodeReroute")
	    reroute_019.name = "Reroute.019"
	    reroute_019.socket_idname = "NodeSocketGeometry"
	    #node Reroute.018
	    reroute_018 = duplicate_hair_curves.nodes.new("NodeReroute")
	    reroute_018.name = "Reroute.018"
	    reroute_018.socket_idname = "NodeSocketGeometry"
	    #node Group Input
	    group_input = duplicate_hair_curves.nodes.new("NodeGroupInput")
	    group_input.name = "Group Input"
	    group_input.outputs[1].hide = True
	    group_input.outputs[2].hide = True
	    group_input.outputs[3].hide = True
	    group_input.outputs[4].hide = True
	    group_input.outputs[5].hide = True
	    group_input.outputs[6].hide = True
	    group_input.outputs[7].hide = True
	    group_input.outputs[8].hide = True
	
	    #node Group Output
	    group_output_3 = duplicate_hair_curves.nodes.new("NodeGroupOutput")
	    group_output_3.name = "Group Output"
	    group_output_3.is_active_output = True
	
	    #node Separate Components
	    separate_components = duplicate_hair_curves.nodes.new("GeometryNodeSeparateComponents")
	    separate_components.name = "Separate Components"
	    separate_components.hide = True
	
	    #node Math.053
	    math_053 = duplicate_hair_curves.nodes.new("ShaderNodeMath")
	    math_053.name = "Math.053"
	    math_053.hide = True
	    math_053.operation = 'ARCCOSINE'
	    math_053.use_clamp = False
	
	    #node Math.055
	    math_055 = duplicate_hair_curves.nodes.new("ShaderNodeMath")
	    math_055.name = "Math.055"
	    math_055.hide = True
	    math_055.operation = 'DIVIDE'
	    math_055.use_clamp = False
	    #Value_001
	    math_055.inputs[1].default_value = 1.5707963705062866
	
	    #node Math.056
	    math_056 = duplicate_hair_curves.nodes.new("ShaderNodeMath")
	    math_056.name = "Math.056"
	    math_056.hide = True
	    math_056.operation = 'POWER'
	    math_056.use_clamp = False
	    #Value
	    math_056.inputs[0].default_value = 2.0
	
	    #node Group Input.006
	    group_input_006 = duplicate_hair_curves.nodes.new("NodeGroupInput")
	    group_input_006.name = "Group Input.006"
	    group_input_006.outputs[0].hide = True
	    group_input_006.outputs[1].hide = True
	    group_input_006.outputs[2].hide = True
	    group_input_006.outputs[3].hide = True
	    group_input_006.outputs[5].hide = True
	    group_input_006.outputs[6].hide = True
	    group_input_006.outputs[7].hide = True
	    group_input_006.outputs[8].hide = True
	
	    #node Separate XYZ.002
	    separate_xyz_002 = duplicate_hair_curves.nodes.new("ShaderNodeSeparateXYZ")
	    separate_xyz_002.name = "Separate XYZ.002"
	
	    #node Math.054
	    math_054 = duplicate_hair_curves.nodes.new("ShaderNodeMath")
	    math_054.name = "Math.054"
	    math_054.operation = 'POWER'
	    math_054.use_clamp = False
	
	    #node Math.052
	    math_052 = duplicate_hair_curves.nodes.new("ShaderNodeMath")
	    math_052.name = "Math.052"
	    math_052.hide = True
	    math_052.operation = 'MULTIPLY'
	    math_052.use_clamp = False
	    #Value_001
	    math_052.inputs[1].default_value = 6.2831854820251465
	
	    #node Combine XYZ.002
	    combine_xyz_002 = duplicate_hair_curves.nodes.new("ShaderNodeCombineXYZ")
	    combine_xyz_002.name = "Combine XYZ.002"
	    combine_xyz_002.inputs[1].hide = True
	    combine_xyz_002.inputs[2].hide = True
	    #Y
	    combine_xyz_002.inputs[1].default_value = 0.0
	    #Z
	    combine_xyz_002.inputs[2].default_value = 0.0
	
	    #node Math.059
	    math_059 = duplicate_hair_curves.nodes.new("ShaderNodeMath")
	    math_059.name = "Math.059"
	    math_059.hide = True
	    math_059.operation = 'SUBTRACT'
	    math_059.use_clamp = False
	    #Value_001
	    math_059.inputs[1].default_value = 0.5
	
	    #node Math.058
	    math_058 = duplicate_hair_curves.nodes.new("ShaderNodeMath")
	    math_058.name = "Math.058"
	    math_058.hide = True
	    math_058.operation = 'POWER'
	    math_058.use_clamp = False
	    #Value_001
	    math_058.inputs[1].default_value = 2.0
	
	    #node Vector Rotate
	    vector_rotate = duplicate_hair_curves.nodes.new("ShaderNodeVectorRotate")
	    vector_rotate.name = "Vector Rotate"
	    vector_rotate.invert = False
	    vector_rotate.rotation_type = 'Z_AXIS'
	    vector_rotate.inputs[1].hide = True
	    vector_rotate.inputs[2].hide = True
	    vector_rotate.inputs[4].hide = True
	    #Center
	    vector_rotate.inputs[1].default_value = (0.0, 0.0, 0.0)
	
	    #node Math.057
	    math_057 = duplicate_hair_curves.nodes.new("ShaderNodeMath")
	    math_057.name = "Math.057"
	    math_057.operation = 'ADD'
	    math_057.use_clamp = False
	
	    #node Group Input.007
	    group_input_007 = duplicate_hair_curves.nodes.new("NodeGroupInput")
	    group_input_007.name = "Group Input.007"
	    group_input_007.outputs[0].hide = True
	    group_input_007.outputs[1].hide = True
	    group_input_007.outputs[2].hide = True
	    group_input_007.outputs[3].hide = True
	    group_input_007.outputs[4].hide = True
	    group_input_007.outputs[6].hide = True
	    group_input_007.outputs[7].hide = True
	    group_input_007.outputs[8].hide = True
	
	    #node Combine XYZ
	    combine_xyz = duplicate_hair_curves.nodes.new("ShaderNodeCombineXYZ")
	    combine_xyz.name = "Combine XYZ"
	    combine_xyz.inputs[0].hide = True
	    combine_xyz.inputs[1].hide = True
	    #X
	    combine_xyz.inputs[0].default_value = 0.0
	    #Y
	    combine_xyz.inputs[1].default_value = 0.0
	
	    #node Vector Math.014
	    vector_math_014 = duplicate_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_014.name = "Vector Math.014"
	    vector_math_014.operation = 'SCALE'
	
	    #node Vector Math.013
	    vector_math_013 = duplicate_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_013.name = "Vector Math.013"
	    vector_math_013.operation = 'SUBTRACT'
	
	    #node Reroute.001
	    reroute_001 = duplicate_hair_curves.nodes.new("NodeReroute")
	    reroute_001.name = "Reroute.001"
	    reroute_001.socket_idname = "NodeSocketGeometry"
	    #node Reroute.003
	    reroute_003 = duplicate_hair_curves.nodes.new("NodeReroute")
	    reroute_003.name = "Reroute.003"
	    reroute_003.socket_idname = "NodeSocketBool"
	    #node Set Position
	    set_position = duplicate_hair_curves.nodes.new("GeometryNodeSetPosition")
	    set_position.name = "Set Position"
	    #Position
	    set_position.inputs[2].default_value = (0.0, 0.0, 0.0)
	
	    #node Set Position.001
	    set_position_001 = duplicate_hair_curves.nodes.new("GeometryNodeSetPosition")
	    set_position_001.name = "Set Position.001"
	    #Position
	    set_position_001.inputs[2].default_value = (0.0, 0.0, 0.0)
	
	    #node Normal
	    normal = duplicate_hair_curves.nodes.new("GeometryNodeInputNormal")
	    normal.name = "Normal"
	    normal.legacy_corner_normals = True
	
	    #node Curve Tangent
	    curve_tangent_2 = duplicate_hair_curves.nodes.new("GeometryNodeInputTangent")
	    curve_tangent_2.name = "Curve Tangent"
	
	    #node Separate XYZ
	    separate_xyz = duplicate_hair_curves.nodes.new("ShaderNodeSeparateXYZ")
	    separate_xyz.name = "Separate XYZ"
	
	    #node Vector Math.001
	    vector_math_001_1 = duplicate_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_001_1.name = "Vector Math.001"
	    vector_math_001_1.operation = 'SCALE'
	
	    #node Vector Math.003
	    vector_math_003 = duplicate_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_003.name = "Vector Math.003"
	    vector_math_003.operation = 'ADD'
	
	    #node Vector Math.002
	    vector_math_002 = duplicate_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_002.name = "Vector Math.002"
	    vector_math_002.operation = 'SCALE'
	
	    #node Vector Math.009
	    vector_math_009 = duplicate_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_009.name = "Vector Math.009"
	    vector_math_009.operation = 'ADD'
	
	    #node Vector Math.010
	    vector_math_010 = duplicate_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_010.name = "Vector Math.010"
	    vector_math_010.operation = 'SCALE'
	
	    #node Vector Math
	    vector_math_1 = duplicate_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_1.name = "Vector Math"
	    vector_math_1.operation = 'CROSS_PRODUCT'
	
	    #node Group.001
	    group_001_1 = duplicate_hair_curves.nodes.new("GeometryNodeGroup")
	    group_001_1.name = "Group.001"
	    group_001_1.node_tree = curve_root
	    group_001_1.outputs[0].hide = True
	    group_001_1.outputs[1].hide = True
	    group_001_1.outputs[2].hide = True
	
	    #node Evaluate on Domain.002
	    evaluate_on_domain_002_1 = duplicate_hair_curves.nodes.new("GeometryNodeFieldOnDomain")
	    evaluate_on_domain_002_1.name = "Evaluate on Domain.002"
	    evaluate_on_domain_002_1.data_type = 'FLOAT_VECTOR'
	    evaluate_on_domain_002_1.domain = 'CURVE'
	
	    #node Separate XYZ.001
	    separate_xyz_001 = duplicate_hair_curves.nodes.new("ShaderNodeSeparateXYZ")
	    separate_xyz_001.name = "Separate XYZ.001"
	
	    #node Vector Math.011
	    vector_math_011 = duplicate_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_011.name = "Vector Math.011"
	    vector_math_011.operation = 'ADD'
	
	    #node Vector Math.005
	    vector_math_005 = duplicate_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_005.name = "Vector Math.005"
	    vector_math_005.operation = 'ADD'
	
	    #node Vector Math.007
	    vector_math_007 = duplicate_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_007.name = "Vector Math.007"
	    vector_math_007.operation = 'SCALE'
	
	    #node Vector Math.008
	    vector_math_008 = duplicate_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_008.name = "Vector Math.008"
	    vector_math_008.operation = 'CROSS_PRODUCT'
	
	    #node Evaluate at Index
	    evaluate_at_index_1 = duplicate_hair_curves.nodes.new("GeometryNodeFieldAtIndex")
	    evaluate_at_index_1.name = "Evaluate at Index"
	    evaluate_at_index_1.data_type = 'FLOAT_VECTOR'
	    evaluate_at_index_1.domain = 'POINT'
	
	    #node Vector Math.012
	    vector_math_012 = duplicate_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_012.name = "Vector Math.012"
	    vector_math_012.operation = 'SCALE'
	
	    #node Vector Math.006
	    vector_math_006 = duplicate_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_006.name = "Vector Math.006"
	    vector_math_006.operation = 'SCALE'
	
	    #node Evaluate on Domain.001
	    evaluate_on_domain_001_1 = duplicate_hair_curves.nodes.new("GeometryNodeFieldOnDomain")
	    evaluate_on_domain_001_1.name = "Evaluate on Domain.001"
	    evaluate_on_domain_001_1.hide = True
	    evaluate_on_domain_001_1.data_type = 'FLOAT_VECTOR'
	    evaluate_on_domain_001_1.domain = 'POINT'
	
	    #node Curve Tangent.001
	    curve_tangent_001 = duplicate_hair_curves.nodes.new("GeometryNodeInputTangent")
	    curve_tangent_001.name = "Curve Tangent.001"
	
	    #node Normal.001
	    normal_001 = duplicate_hair_curves.nodes.new("GeometryNodeInputNormal")
	    normal_001.name = "Normal.001"
	    normal_001.legacy_corner_normals = True
	
	    #node Reroute.014
	    reroute_014 = duplicate_hair_curves.nodes.new("NodeReroute")
	    reroute_014.name = "Reroute.014"
	    reroute_014.socket_idname = "NodeSocketGeometry"
	    #node Reroute.015
	    reroute_015 = duplicate_hair_curves.nodes.new("NodeReroute")
	    reroute_015.name = "Reroute.015"
	    reroute_015.socket_idname = "NodeSocketGeometry"
	    #node Reroute.013
	    reroute_013 = duplicate_hair_curves.nodes.new("NodeReroute")
	    reroute_013.name = "Reroute.013"
	    reroute_013.socket_idname = "NodeSocketGeometry"
	    #node Reroute.012
	    reroute_012 = duplicate_hair_curves.nodes.new("NodeReroute")
	    reroute_012.name = "Reroute.012"
	    reroute_012.socket_idname = "NodeSocketGeometry"
	    #node Is Viewport
	    is_viewport = duplicate_hair_curves.nodes.new("GeometryNodeIsViewport")
	    is_viewport.name = "Is Viewport"
	
	    #node Switch
	    switch = duplicate_hair_curves.nodes.new("GeometryNodeSwitch")
	    switch.name = "Switch"
	    switch.input_type = 'INT'
	
	    #node ID
	    id_1 = duplicate_hair_curves.nodes.new("GeometryNodeInputID")
	    id_1.name = "ID"
	
	    #node Reroute.004
	    reroute_004 = duplicate_hair_curves.nodes.new("NodeReroute")
	    reroute_004.name = "Reroute.004"
	    reroute_004.socket_idname = "NodeSocketInt"
	    #node Reroute.002
	    reroute_002 = duplicate_hair_curves.nodes.new("NodeReroute")
	    reroute_002.name = "Reroute.002"
	    reroute_002.socket_idname = "NodeSocketGeometry"
	    #node Join Geometry
	    join_geometry = duplicate_hair_curves.nodes.new("GeometryNodeJoinGeometry")
	    join_geometry.name = "Join Geometry"
	
	    #node Set ID
	    set_id = duplicate_hair_curves.nodes.new("GeometryNodeSetID")
	    set_id.name = "Set ID"
	    #Selection
	    set_id.inputs[1].default_value = True
	
	    #node Store Named Attribute
	    store_named_attribute = duplicate_hair_curves.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute.name = "Store Named Attribute"
	    store_named_attribute.data_type = 'INT'
	    store_named_attribute.domain = 'CURVE'
	    #Selection
	    store_named_attribute.inputs[1].default_value = True
	    #Name
	    store_named_attribute.inputs[2].default_value = "guide_curve_index"
	
	    #node Math
	    math = duplicate_hair_curves.nodes.new("ShaderNodeMath")
	    math.name = "Math"
	    math.hide = True
	    math.operation = 'MULTIPLY'
	    math.use_clamp = False
	
	    #node Group Input.002
	    group_input_002 = duplicate_hair_curves.nodes.new("NodeGroupInput")
	    group_input_002.name = "Group Input.002"
	    group_input_002.outputs[0].hide = True
	    group_input_002.outputs[1].hide = True
	    group_input_002.outputs[3].hide = True
	    group_input_002.outputs[4].hide = True
	    group_input_002.outputs[5].hide = True
	    group_input_002.outputs[6].hide = True
	    group_input_002.outputs[7].hide = True
	    group_input_002.outputs[8].hide = True
	
	    #node Group Input.004
	    group_input_004 = duplicate_hair_curves.nodes.new("NodeGroupInput")
	    group_input_004.name = "Group Input.004"
	    group_input_004.outputs[0].hide = True
	    group_input_004.outputs[2].hide = True
	    group_input_004.outputs[3].hide = True
	    group_input_004.outputs[4].hide = True
	    group_input_004.outputs[5].hide = True
	    group_input_004.outputs[6].hide = True
	    group_input_004.outputs[7].hide = True
	    group_input_004.outputs[8].hide = True
	
	    #node Capture Attribute.002
	    capture_attribute_002 = duplicate_hair_curves.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_002.name = "Capture Attribute.002"
	    capture_attribute_002.active_index = 0
	    capture_attribute_002.capture_items.clear()
	    capture_attribute_002.capture_items.new('FLOAT', "Value")
	    capture_attribute_002.capture_items["Value"].data_type = 'BOOLEAN'
	    capture_attribute_002.domain = 'POINT'
	    #Value
	    capture_attribute_002.inputs[1].default_value = True
	
	    #node Vector Math.004
	    vector_math_004 = duplicate_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_004.name = "Vector Math.004"
	    vector_math_004.operation = 'SCALE'
	
	    #node Group Input.003
	    group_input_003 = duplicate_hair_curves.nodes.new("NodeGroupInput")
	    group_input_003.name = "Group Input.003"
	    group_input_003.outputs[0].hide = True
	    group_input_003.outputs[1].hide = True
	    group_input_003.outputs[2].hide = True
	    group_input_003.outputs[4].hide = True
	    group_input_003.outputs[5].hide = True
	    group_input_003.outputs[6].hide = True
	    group_input_003.outputs[7].hide = True
	    group_input_003.outputs[8].hide = True
	
	    #node Random Value.001
	    random_value_001 = duplicate_hair_curves.nodes.new("FunctionNodeRandomValue")
	    random_value_001.name = "Random Value.001"
	    random_value_001.data_type = 'FLOAT_VECTOR'
	    #Min
	    random_value_001.inputs[0].default_value = (0.0, 0.0, 0.0)
	    #Max
	    random_value_001.inputs[1].default_value = (1.0, 1.0, 1.0)
	
	    #node Capture Attribute
	    capture_attribute = duplicate_hair_curves.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute.name = "Capture Attribute"
	    capture_attribute.active_index = 0
	    capture_attribute.capture_items.clear()
	    capture_attribute.capture_items.new('FLOAT', "Value")
	    capture_attribute.capture_items["Value"].data_type = 'INT'
	    capture_attribute.domain = 'POINT'
	
	    #node Duplicate Elements
	    duplicate_elements = duplicate_hair_curves.nodes.new("GeometryNodeDuplicateElements")
	    duplicate_elements.name = "Duplicate Elements"
	    duplicate_elements.domain = 'SPLINE'
	    #Selection
	    duplicate_elements.inputs[1].default_value = True
	
	    #node Join Geometry.001
	    join_geometry_001 = duplicate_hair_curves.nodes.new("GeometryNodeJoinGeometry")
	    join_geometry_001.name = "Join Geometry.001"
	
	    #node Random Value
	    random_value = duplicate_hair_curves.nodes.new("FunctionNodeRandomValue")
	    random_value.name = "Random Value"
	    random_value.data_type = 'INT'
	    #Min_002
	    random_value.inputs[4].default_value = -1073741823
	    #Max_002
	    random_value.inputs[5].default_value = 1073741823
	
	    #node Reroute.020
	    reroute_020 = duplicate_hair_curves.nodes.new("NodeReroute")
	    reroute_020.name = "Reroute.020"
	    reroute_020.socket_idname = "NodeSocketGeometry"
	    #node Index
	    index = duplicate_hair_curves.nodes.new("GeometryNodeInputIndex")
	    index.name = "Index"
	
	    #node Capture Attribute.001
	    capture_attribute_001 = duplicate_hair_curves.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_001.name = "Capture Attribute.001"
	    capture_attribute_001.active_index = 0
	    capture_attribute_001.capture_items.clear()
	    capture_attribute_001.capture_items.new('FLOAT', "Value")
	    capture_attribute_001.capture_items["Value"].data_type = 'INT'
	    capture_attribute_001.domain = 'CURVE'
	
	    #node Switch.001
	    switch_001 = duplicate_hair_curves.nodes.new("GeometryNodeSwitch")
	    switch_001.name = "Switch.001"
	    switch_001.input_type = 'GEOMETRY'
	
	    #node Group
	    group_1 = duplicate_hair_curves.nodes.new("GeometryNodeGroup")
	    group_1.name = "Group"
	    group_1.node_tree = curve_info
	    group_1.outputs[0].hide = True
	    group_1.outputs[2].hide = True
	    group_1.outputs[3].hide = True
	    group_1.outputs[4].hide = True
	    group_1.outputs[5].hide = True
	
	    #node Group Input.001
	    group_input_001 = duplicate_hair_curves.nodes.new("NodeGroupInput")
	    group_input_001.name = "Group Input.001"
	    group_input_001.outputs[0].hide = True
	    group_input_001.outputs[1].hide = True
	    group_input_001.outputs[2].hide = True
	    group_input_001.outputs[3].hide = True
	    group_input_001.outputs[4].hide = True
	    group_input_001.outputs[5].hide = True
	    group_input_001.outputs[6].hide = True
	    group_input_001.outputs[8].hide = True
	
	    #node Group Input.005
	    group_input_005 = duplicate_hair_curves.nodes.new("NodeGroupInput")
	    group_input_005.name = "Group Input.005"
	    group_input_005.outputs[0].hide = True
	    group_input_005.outputs[1].hide = True
	    group_input_005.outputs[2].hide = True
	    group_input_005.outputs[3].hide = True
	    group_input_005.outputs[4].hide = True
	    group_input_005.outputs[5].hide = True
	    group_input_005.outputs[7].hide = True
	    group_input_005.outputs[8].hide = True
	
	    #node Random Value.004
	    random_value_004 = duplicate_hair_curves.nodes.new("FunctionNodeRandomValue")
	    random_value_004.name = "Random Value.004"
	    random_value_004.data_type = 'INT'
	    #Min_002
	    random_value_004.inputs[4].default_value = -1073741823
	    #Max_002
	    random_value_004.inputs[5].default_value = 1073741823
	    #Seed
	    random_value_004.inputs[8].default_value = 296
	
	
	
	
	    #Set parents
	    math_053.parent = frame_002
	    math_055.parent = frame_002
	    math_056.parent = frame_002
	    group_input_006.parent = frame_002
	    separate_xyz_002.parent = frame_002
	    math_054.parent = frame_002
	    math_052.parent = frame_002
	    combine_xyz_002.parent = frame_002
	    math_059.parent = frame_002
	    math_058.parent = frame_002
	    vector_rotate.parent = frame_002
	    math_057.parent = frame_002
	    group_input_007.parent = frame_002
	    combine_xyz.parent = frame_002
	    vector_math_014.parent = frame_002
	    vector_math_013.parent = frame_002
	    normal.parent = frame_001
	    curve_tangent_2.parent = frame_001
	    separate_xyz.parent = frame_001
	    vector_math_001_1.parent = frame_001
	    vector_math_003.parent = frame_001
	    vector_math_002.parent = frame_001
	    vector_math_009.parent = frame_001
	    vector_math_010.parent = frame_001
	    vector_math_1.parent = frame_001
	    group_001_1.parent = frame_1
	    evaluate_on_domain_002_1.parent = frame_1
	    separate_xyz_001.parent = frame_1
	    vector_math_011.parent = frame_1
	    vector_math_005.parent = frame_1
	    vector_math_007.parent = frame_1
	    vector_math_008.parent = frame_1
	    evaluate_at_index_1.parent = frame_1
	    vector_math_012.parent = frame_1
	    vector_math_006.parent = frame_1
	    evaluate_on_domain_001_1.parent = frame_1
	    curve_tangent_001.parent = frame_1
	    normal_001.parent = frame_1
	    is_viewport.parent = frame_004
	    switch.parent = frame_004
	    id_1.parent = frame_004
	    reroute_004.parent = frame_004
	    reroute_002.parent = frame_004
	    join_geometry.parent = frame_004
	    set_id.parent = frame_004
	    store_named_attribute.parent = frame_004
	    math.parent = frame_004
	    group_input_002.parent = frame_004
	    group_input_004.parent = frame_004
	    capture_attribute_002.parent = frame_004
	    random_value_001.parent = frame_003
	    capture_attribute.parent = frame_004
	    duplicate_elements.parent = frame_004
	    random_value.parent = frame_004
	    group_1.parent = frame_003
	    group_input_001.parent = frame_003
	    random_value_004.parent = frame_003
	
	    #Set locations
	    frame_002.location = (-4255.2001953125, -612.6799926757812)
	    frame_001.location = (-1964.6400146484375, -733.6400146484375)
	    frame_1.location = (-2265.1201171875, -271.8800048828125)
	    frame_004.location = (-2910.239990234375, 227.31997680664062)
	    frame_003.location = (-4867.68017578125, -612.6799926757812)
	    reroute_016.location = (-431.521728515625, 395.1722106933594)
	    reroute_017.location = (-431.521728515625, 354.9861755371094)
	    reroute_019.location = (-431.521728515625, 314.8001403808594)
	    reroute_018.location = (-431.521728515625, 274.6141052246094)
	    group_input.location = (-3843.1396484375, 29.906982421875)
	    group_output_3.location = (75.0, 50.0)
	    separate_components.location = (-3652.255859375, 19.86041259765625)
	    math_053.location = (230.822998046875, -60.69171142578125)
	    math_055.location = (230.822998046875, -100.87774658203125)
	    math_056.location = (190.636962890625, -221.4359130859375)
	    group_input_006.location = (29.892578125, -221.4359130859375)
	    separate_xyz_002.location = (29.892578125, -60.69171142578125)
	    math_054.location = (411.66015625, -80.78472900390625)
	    math_052.location = (411.66015625, -201.3428955078125)
	    combine_xyz_002.location = (592.49755859375, -40.59869384765625)
	    math_059.location = (592.49755859375, -281.7149658203125)
	    math_058.location = (592.49755859375, -241.5289306640625)
	    vector_rotate.location = (773.33447265625, -60.69171142578125)
	    math_057.location = (773.33447265625, -201.3428955078125)
	    group_input_007.location = (954.171875, -301.8079833984375)
	    combine_xyz.location = (954.171875, -201.3428955078125)
	    vector_math_014.location = (1135.009033203125, -221.4359130859375)
	    vector_math_013.location = (1335.939208984375, -141.06378173828125)
	    reroute_001.location = (-839.232666015625, -160.97679138183594)
	    reroute_003.location = (-839.232666015625, -281.5349426269531)
	    set_position.location = (-738.7674560546875, -241.348876953125)
	    set_position_001.location = (-738.7674560546875, -80.60469055175781)
	    normal.location = (29.926513671875, -161.1331787109375)
	    curve_tangent_2.location = (29.926513671875, -100.8541259765625)
	    separate_xyz.location = (230.8568115234375, -221.41229248046875)
	    vector_math_001_1.location = (411.6939697265625, -40.5750732421875)
	    vector_math_003.location = (592.53125, -40.5750732421875)
	    vector_math_002.location = (411.6939697265625, -181.22625732421875)
	    vector_math_009.location = (793.46142578125, -40.5750732421875)
	    vector_math_010.location = (592.53125, -201.31927490234375)
	    vector_math_1.location = (230.8568115234375, -40.5750732421875)
	    group_001_1.location = (744.0943603515625, -60.23541259765625)
	    evaluate_on_domain_002_1.location = (1105.768798828125, -40.14239501953125)
	    separate_xyz_001.location = (201.58251953125, -261.1656494140625)
	    vector_math_011.location = (744.0943603515625, -140.6075439453125)
	    vector_math_005.location = (563.257080078125, -140.6075439453125)
	    vector_math_007.location = (382.419921875, -120.5145263671875)
	    vector_math_008.location = (201.58251953125, -120.5145263671875)
	    evaluate_at_index_1.location = (924.9315185546875, -40.14239501953125)
	    vector_math_012.location = (563.257080078125, -301.3516845703125)
	    vector_math_006.location = (382.419921875, -261.1656494140625)
	    evaluate_on_domain_001_1.location = (29.82666015625, -339.91510009765625)
	    curve_tangent_001.location = (29.82666015625, -118.89178466796875)
	    normal_001.location = (29.82666015625, -179.1708984375)
	    reroute_014.location = (-3230.302490234375, 341.3487854003906)
	    reroute_015.location = (-3230.302490234375, 301.1627502441406)
	    reroute_013.location = (-3230.302490234375, 260.9767150878906)
	    reroute_012.location = (-3230.302490234375, 381.5348815917969)
	    is_viewport.location = (280.9560546875, -275.0502624511719)
	    switch.location = (461.793212890625, -234.86422729492188)
	    id_1.location = (29.793212890625, -204.72470092773438)
	    reroute_004.location = (1375.686767578125, -240.71444702148438)
	    reroute_002.location = (571.9658203125, -100.06326293945312)
	    join_geometry.location = (1074.2913818359375, -59.877227783203125)
	    set_id.location = (1275.2216796875, -59.877227783203125)
	    store_named_attribute.location = (1476.15185546875, -39.7841796875)
	    math.location = (290.66357421875, -381.3656005859375)
	    group_input_002.location = (89.733154296875, -381.3656005859375)
	    group_input_004.location = (89.733154296875, -321.0865478515625)
	    capture_attribute_002.location = (843.528564453125, -130.4752197265625)
	    vector_math_004.location = (-2506.95361328125, -703.4884033203125)
	    group_input_003.location = (-2687.790771484375, -824.0465698242188)
	    random_value_001.location = (381.1650390625, -40.59869384765625)
	    capture_attribute.location = (225.0947265625, -50.538970947265625)
	    duplicate_elements.location = (652.337890625, -120.15631103515625)
	    join_geometry_001.location = (-130.127197265625, 53.59075927734375)
	    random_value.location = (1074.2913818359375, -160.34234619140625)
	    reroute_020.location = (-223.732666015625, -87.405517578125)
	    index.location = (-3431.232666015625, -100.69772338867188)
	    capture_attribute_001.location = (-3210.20947265625, 60.046478271484375)
	    switch_001.location = (-507.69775390625, -50.46514892578125)
	    group_1.location = (210.77294921875, -211.3665771484375)
	    group_input_001.location = (29.93603515625, -331.92474365234375)
	    group_input_005.location = (-738.7674560546875, -0.23260498046875)
	    random_value_004.location = (210.77294921875, -291.73870849609375)
	
	    #Set dimensions
	    frame_002.width, frame_002.height = 1506.080078125, 384.280029296875
	    frame_001.width, frame_001.height = 963.6799926757812, 370.840087890625
	    frame_1.width, frame_1.height = 1275.68017578125, 430.36004638671875
	    frame_004.width, frame_004.height = 1646.239990234375, 463.0
	    frame_003.width, frame_003.height = 551.84033203125, 464.92010498046875
	    reroute_016.width, reroute_016.height = 100.0, 100.0
	    reroute_017.width, reroute_017.height = 100.0, 100.0
	    reroute_019.width, reroute_019.height = 100.0, 100.0
	    reroute_018.width, reroute_018.height = 100.0, 100.0
	    group_input.width, group_input.height = 140.0, 100.0
	    group_output_3.width, group_output_3.height = 140.0, 100.0
	    separate_components.width, separate_components.height = 140.0, 100.0
	    math_053.width, math_053.height = 140.0, 100.0
	    math_055.width, math_055.height = 140.0, 100.0
	    math_056.width, math_056.height = 140.0, 100.0
	    group_input_006.width, group_input_006.height = 140.0, 100.0
	    separate_xyz_002.width, separate_xyz_002.height = 140.0, 100.0
	    math_054.width, math_054.height = 140.0, 100.0
	    math_052.width, math_052.height = 140.0, 100.0
	    combine_xyz_002.width, combine_xyz_002.height = 140.0, 100.0
	    math_059.width, math_059.height = 140.0, 100.0
	    math_058.width, math_058.height = 140.0, 100.0
	    vector_rotate.width, vector_rotate.height = 140.0, 100.0
	    math_057.width, math_057.height = 140.0, 100.0
	    group_input_007.width, group_input_007.height = 140.0, 100.0
	    combine_xyz.width, combine_xyz.height = 140.0, 100.0
	    vector_math_014.width, vector_math_014.height = 140.0, 100.0
	    vector_math_013.width, vector_math_013.height = 140.0, 100.0
	    reroute_001.width, reroute_001.height = 100.0, 100.0
	    reroute_003.width, reroute_003.height = 100.0, 100.0
	    set_position.width, set_position.height = 140.0, 100.0
	    set_position_001.width, set_position_001.height = 140.0, 100.0
	    normal.width, normal.height = 140.0, 100.0
	    curve_tangent_2.width, curve_tangent_2.height = 140.0, 100.0
	    separate_xyz.width, separate_xyz.height = 140.0, 100.0
	    vector_math_001_1.width, vector_math_001_1.height = 140.0, 100.0
	    vector_math_003.width, vector_math_003.height = 140.0, 100.0
	    vector_math_002.width, vector_math_002.height = 140.0, 100.0
	    vector_math_009.width, vector_math_009.height = 140.0, 100.0
	    vector_math_010.width, vector_math_010.height = 140.0, 100.0
	    vector_math_1.width, vector_math_1.height = 140.0, 100.0
	    group_001_1.width, group_001_1.height = 140.0, 100.0
	    evaluate_on_domain_002_1.width, evaluate_on_domain_002_1.height = 140.0, 100.0
	    separate_xyz_001.width, separate_xyz_001.height = 140.0, 100.0
	    vector_math_011.width, vector_math_011.height = 140.0, 100.0
	    vector_math_005.width, vector_math_005.height = 140.0, 100.0
	    vector_math_007.width, vector_math_007.height = 140.0, 100.0
	    vector_math_008.width, vector_math_008.height = 140.0, 100.0
	    evaluate_at_index_1.width, evaluate_at_index_1.height = 140.0, 100.0
	    vector_math_012.width, vector_math_012.height = 140.0, 100.0
	    vector_math_006.width, vector_math_006.height = 140.0, 100.0
	    evaluate_on_domain_001_1.width, evaluate_on_domain_001_1.height = 140.0, 100.0
	    curve_tangent_001.width, curve_tangent_001.height = 140.0, 100.0
	    normal_001.width, normal_001.height = 140.0, 100.0
	    reroute_014.width, reroute_014.height = 100.0, 100.0
	    reroute_015.width, reroute_015.height = 100.0, 100.0
	    reroute_013.width, reroute_013.height = 100.0, 100.0
	    reroute_012.width, reroute_012.height = 100.0, 100.0
	    is_viewport.width, is_viewport.height = 140.0, 100.0
	    switch.width, switch.height = 140.0, 100.0
	    id_1.width, id_1.height = 140.0, 100.0
	    reroute_004.width, reroute_004.height = 100.0, 100.0
	    reroute_002.width, reroute_002.height = 100.0, 100.0
	    join_geometry.width, join_geometry.height = 140.0, 100.0
	    set_id.width, set_id.height = 140.0, 100.0
	    store_named_attribute.width, store_named_attribute.height = 140.0, 100.0
	    math.width, math.height = 140.0, 100.0
	    group_input_002.width, group_input_002.height = 140.0, 100.0
	    group_input_004.width, group_input_004.height = 140.0, 100.0
	    capture_attribute_002.width, capture_attribute_002.height = 140.0, 100.0
	    vector_math_004.width, vector_math_004.height = 140.0, 100.0
	    group_input_003.width, group_input_003.height = 140.0, 100.0
	    random_value_001.width, random_value_001.height = 140.0, 100.0
	    capture_attribute.width, capture_attribute.height = 140.0, 100.0
	    duplicate_elements.width, duplicate_elements.height = 140.0, 100.0
	    join_geometry_001.width, join_geometry_001.height = 140.0, 100.0
	    random_value.width, random_value.height = 140.0, 100.0
	    reroute_020.width, reroute_020.height = 100.0, 100.0
	    index.width, index.height = 140.0, 100.0
	    capture_attribute_001.width, capture_attribute_001.height = 140.0, 100.0
	    switch_001.width, switch_001.height = 140.0, 100.0
	    group_1.width, group_1.height = 140.0, 100.0
	    group_input_001.width, group_input_001.height = 140.0, 100.0
	    group_input_005.width, group_input_005.height = 140.0, 100.0
	    random_value_004.width, random_value_004.height = 140.0, 100.0
	
	    #initialize duplicate_hair_curves links
	    #join_geometry_001.Geometry -> group_output_3.Geometry
	    duplicate_hair_curves.links.new(join_geometry_001.outputs[0], group_output_3.inputs[0])
	    #reroute_002.Output -> duplicate_elements.Geometry
	    duplicate_hair_curves.links.new(reroute_002.outputs[0], duplicate_elements.inputs[0])
	    #capture_attribute_001.Geometry -> capture_attribute.Geometry
	    duplicate_hair_curves.links.new(capture_attribute_001.outputs[0], capture_attribute.inputs[0])
	    #random_value.Value -> set_id.ID
	    duplicate_hair_curves.links.new(random_value.outputs[2], set_id.inputs[2])
	    #capture_attribute.Value -> random_value.ID
	    duplicate_hair_curves.links.new(capture_attribute.outputs[1], random_value.inputs[7])
	    #duplicate_elements.Duplicate Index -> random_value.Seed
	    duplicate_hair_curves.links.new(duplicate_elements.outputs[1], random_value.inputs[8])
	    #random_value_001.Value -> separate_xyz_002.Vector
	    duplicate_hair_curves.links.new(random_value_001.outputs[0], separate_xyz_002.inputs[0])
	    #math_052.Value -> vector_rotate.Angle
	    duplicate_hair_curves.links.new(math_052.outputs[0], vector_rotate.inputs[3])
	    #combine_xyz_002.Vector -> vector_rotate.Vector
	    duplicate_hair_curves.links.new(combine_xyz_002.outputs[0], vector_rotate.inputs[0])
	    #separate_xyz_002.Y -> math_052.Value
	    duplicate_hair_curves.links.new(separate_xyz_002.outputs[1], math_052.inputs[0])
	    #separate_xyz_002.X -> math_053.Value
	    duplicate_hair_curves.links.new(separate_xyz_002.outputs[0], math_053.inputs[0])
	    #math_054.Value -> combine_xyz_002.X
	    duplicate_hair_curves.links.new(math_054.outputs[0], combine_xyz_002.inputs[0])
	    #group_1.Curve ID -> random_value_001.ID
	    duplicate_hair_curves.links.new(group_1.outputs[1], random_value_001.inputs[7])
	    #vector_math_004.Vector -> separate_xyz.Vector
	    duplicate_hair_curves.links.new(vector_math_004.outputs[0], separate_xyz.inputs[0])
	    #reroute_001.Output -> set_position.Geometry
	    duplicate_hair_curves.links.new(reroute_001.outputs[0], set_position.inputs[0])
	    #curve_tangent_2.Tangent -> vector_math_1.Vector
	    duplicate_hair_curves.links.new(curve_tangent_2.outputs[0], vector_math_1.inputs[0])
	    #normal.Normal -> vector_math_1.Vector
	    duplicate_hair_curves.links.new(normal.outputs[0], vector_math_1.inputs[1])
	    #vector_math_1.Vector -> vector_math_001_1.Vector
	    duplicate_hair_curves.links.new(vector_math_1.outputs[0], vector_math_001_1.inputs[0])
	    #vector_math_001_1.Vector -> vector_math_003.Vector
	    duplicate_hair_curves.links.new(vector_math_001_1.outputs[0], vector_math_003.inputs[0])
	    #vector_math_002.Vector -> vector_math_003.Vector
	    duplicate_hair_curves.links.new(vector_math_002.outputs[0], vector_math_003.inputs[1])
	    #separate_xyz.X -> vector_math_001_1.Scale
	    duplicate_hair_curves.links.new(separate_xyz.outputs[0], vector_math_001_1.inputs[3])
	    #separate_xyz.Y -> vector_math_002.Scale
	    duplicate_hair_curves.links.new(separate_xyz.outputs[1], vector_math_002.inputs[3])
	    #normal.Normal -> vector_math_002.Vector
	    duplicate_hair_curves.links.new(normal.outputs[0], vector_math_002.inputs[0])
	    #index.Index -> capture_attribute_001.Value
	    duplicate_hair_curves.links.new(index.outputs[0], capture_attribute_001.inputs[1])
	    #set_id.Geometry -> store_named_attribute.Geometry
	    duplicate_hair_curves.links.new(set_id.outputs[0], store_named_attribute.inputs[0])
	    #capture_attribute_002.Geometry -> join_geometry.Geometry
	    duplicate_hair_curves.links.new(capture_attribute_002.outputs[0], join_geometry.inputs[0])
	    #reroute_004.Output -> store_named_attribute.Value
	    duplicate_hair_curves.links.new(reroute_004.outputs[0], store_named_attribute.inputs[3])
	    #group_input_004.Amount -> switch.False
	    duplicate_hair_curves.links.new(group_input_004.outputs[1], switch.inputs[1])
	    #switch.Output -> duplicate_elements.Amount
	    duplicate_hair_curves.links.new(switch.outputs[0], duplicate_elements.inputs[2])
	    #is_viewport.Is Viewport -> switch.Switch
	    duplicate_hair_curves.links.new(is_viewport.outputs[0], switch.inputs[0])
	    #group_input_004.Amount -> math.Value
	    duplicate_hair_curves.links.new(group_input_004.outputs[1], math.inputs[0])
	    #math.Value -> switch.True
	    duplicate_hair_curves.links.new(math.outputs[0], switch.inputs[2])
	    #group_input_002.Viewport Amount -> math.Value
	    duplicate_hair_curves.links.new(group_input_002.outputs[2], math.inputs[1])
	    #id_1.ID -> capture_attribute.Value
	    duplicate_hair_curves.links.new(id_1.outputs[0], capture_attribute.inputs[1])
	    #vector_math_009.Vector -> set_position.Offset
	    duplicate_hair_curves.links.new(vector_math_009.outputs[0], set_position.inputs[3])
	    #group_input_005.Even Thickness -> switch_001.Switch
	    duplicate_hair_curves.links.new(group_input_005.outputs[6], switch_001.inputs[0])
	    #vector_math_007.Vector -> vector_math_005.Vector
	    duplicate_hair_curves.links.new(vector_math_007.outputs[0], vector_math_005.inputs[0])
	    #vector_math_006.Vector -> vector_math_005.Vector
	    duplicate_hair_curves.links.new(vector_math_006.outputs[0], vector_math_005.inputs[1])
	    #separate_xyz_001.X -> vector_math_007.Scale
	    duplicate_hair_curves.links.new(separate_xyz_001.outputs[0], vector_math_007.inputs[3])
	    #separate_xyz_001.Y -> vector_math_006.Scale
	    duplicate_hair_curves.links.new(separate_xyz_001.outputs[1], vector_math_006.inputs[3])
	    #evaluate_on_domain_002_1.Value -> set_position_001.Offset
	    duplicate_hair_curves.links.new(evaluate_on_domain_002_1.outputs[0], set_position_001.inputs[3])
	    #curve_tangent_001.Tangent -> vector_math_008.Vector
	    duplicate_hair_curves.links.new(curve_tangent_001.outputs[0], vector_math_008.inputs[0])
	    #normal_001.Normal -> vector_math_008.Vector
	    duplicate_hair_curves.links.new(normal_001.outputs[0], vector_math_008.inputs[1])
	    #evaluate_at_index_1.Value -> evaluate_on_domain_002_1.Value
	    duplicate_hair_curves.links.new(evaluate_at_index_1.outputs[0], evaluate_on_domain_002_1.inputs[0])
	    #vector_math_008.Vector -> vector_math_007.Vector
	    duplicate_hair_curves.links.new(vector_math_008.outputs[0], vector_math_007.inputs[0])
	    #normal_001.Normal -> vector_math_006.Vector
	    duplicate_hair_curves.links.new(normal_001.outputs[0], vector_math_006.inputs[0])
	    #evaluate_on_domain_001_1.Value -> separate_xyz_001.Vector
	    duplicate_hair_curves.links.new(evaluate_on_domain_001_1.outputs[0], separate_xyz_001.inputs[0])
	    #store_named_attribute.Geometry -> reroute_001.Input
	    duplicate_hair_curves.links.new(store_named_attribute.outputs[0], reroute_001.inputs[0])
	    #reroute_001.Output -> set_position_001.Geometry
	    duplicate_hair_curves.links.new(reroute_001.outputs[0], set_position_001.inputs[0])
	    #vector_math_011.Vector -> evaluate_at_index_1.Value
	    duplicate_hair_curves.links.new(vector_math_011.outputs[0], evaluate_at_index_1.inputs[1])
	    #group_001_1.Root Index -> evaluate_at_index_1.Index
	    duplicate_hair_curves.links.new(group_001_1.outputs[3], evaluate_at_index_1.inputs[0])
	    #capture_attribute.Geometry -> reroute_002.Input
	    duplicate_hair_curves.links.new(capture_attribute.outputs[0], reroute_002.inputs[0])
	    #math_055.Value -> math_054.Value
	    duplicate_hair_curves.links.new(math_055.outputs[0], math_054.inputs[0])
	    #math_053.Value -> math_055.Value
	    duplicate_hair_curves.links.new(math_053.outputs[0], math_055.inputs[0])
	    #math_056.Value -> math_054.Value
	    duplicate_hair_curves.links.new(math_056.outputs[0], math_054.inputs[1])
	    #group_input_006.Distribution Shape -> math_056.Value
	    duplicate_hair_curves.links.new(group_input_006.outputs[4], math_056.inputs[1])
	    #vector_math_003.Vector -> vector_math_009.Vector
	    duplicate_hair_curves.links.new(vector_math_003.outputs[0], vector_math_009.inputs[0])
	    #separate_xyz.Z -> vector_math_010.Scale
	    duplicate_hair_curves.links.new(separate_xyz.outputs[2], vector_math_010.inputs[3])
	    #curve_tangent_2.Tangent -> vector_math_010.Vector
	    duplicate_hair_curves.links.new(curve_tangent_2.outputs[0], vector_math_010.inputs[0])
	    #vector_math_010.Vector -> vector_math_009.Vector
	    duplicate_hair_curves.links.new(vector_math_010.outputs[0], vector_math_009.inputs[1])
	    #vector_math_005.Vector -> vector_math_011.Vector
	    duplicate_hair_curves.links.new(vector_math_005.outputs[0], vector_math_011.inputs[0])
	    #vector_math_012.Vector -> vector_math_011.Vector
	    duplicate_hair_curves.links.new(vector_math_012.outputs[0], vector_math_011.inputs[1])
	    #separate_xyz_001.Z -> vector_math_012.Scale
	    duplicate_hair_curves.links.new(separate_xyz_001.outputs[2], vector_math_012.inputs[3])
	    #curve_tangent_001.Tangent -> vector_math_012.Vector
	    duplicate_hair_curves.links.new(curve_tangent_001.outputs[0], vector_math_012.inputs[0])
	    #vector_rotate.Vector -> vector_math_013.Vector
	    duplicate_hair_curves.links.new(vector_rotate.outputs[0], vector_math_013.inputs[0])
	    #vector_math_014.Vector -> vector_math_013.Vector
	    duplicate_hair_curves.links.new(vector_math_014.outputs[0], vector_math_013.inputs[1])
	    #math_057.Value -> combine_xyz.Z
	    duplicate_hair_curves.links.new(math_057.outputs[0], combine_xyz.inputs[2])
	    #vector_math_013.Vector -> vector_math_004.Vector
	    duplicate_hair_curves.links.new(vector_math_013.outputs[0], vector_math_004.inputs[0])
	    #group_input_003.Radius -> vector_math_004.Scale
	    duplicate_hair_curves.links.new(group_input_003.outputs[3], vector_math_004.inputs[3])
	    #math_058.Value -> math_057.Value
	    duplicate_hair_curves.links.new(math_058.outputs[0], math_057.inputs[0])
	    #math_059.Value -> math_057.Value
	    duplicate_hair_curves.links.new(math_059.outputs[0], math_057.inputs[1])
	    #math_054.Value -> math_058.Value
	    duplicate_hair_curves.links.new(math_054.outputs[0], math_058.inputs[0])
	    #combine_xyz.Vector -> vector_math_014.Vector
	    duplicate_hair_curves.links.new(combine_xyz.outputs[0], vector_math_014.inputs[0])
	    #group_input_007.Tip Roundness -> vector_math_014.Scale
	    duplicate_hair_curves.links.new(group_input_007.outputs[5], vector_math_014.inputs[3])
	    #separate_xyz_002.Z -> math_059.Value
	    duplicate_hair_curves.links.new(separate_xyz_002.outputs[2], math_059.inputs[0])
	    #set_position_001.Geometry -> switch_001.False
	    duplicate_hair_curves.links.new(set_position_001.outputs[0], switch_001.inputs[1])
	    #set_position.Geometry -> switch_001.True
	    duplicate_hair_curves.links.new(set_position.outputs[0], switch_001.inputs[2])
	    #reroute_003.Output -> set_position.Selection
	    duplicate_hair_curves.links.new(reroute_003.outputs[0], set_position.inputs[1])
	    #reroute_003.Output -> set_position_001.Selection
	    duplicate_hair_curves.links.new(reroute_003.outputs[0], set_position_001.inputs[1])
	    #capture_attribute_002.Value -> reroute_003.Input
	    duplicate_hair_curves.links.new(capture_attribute_002.outputs[1], reroute_003.inputs[0])
	    #capture_attribute_001.Value -> reroute_004.Input
	    duplicate_hair_curves.links.new(capture_attribute_001.outputs[1], reroute_004.inputs[0])
	    #join_geometry.Geometry -> set_id.Geometry
	    duplicate_hair_curves.links.new(join_geometry.outputs[0], set_id.inputs[0])
	    #duplicate_elements.Geometry -> capture_attribute_002.Geometry
	    duplicate_hair_curves.links.new(duplicate_elements.outputs[0], capture_attribute_002.inputs[0])
	    #group_input_001.Seed -> random_value_004.ID
	    duplicate_hair_curves.links.new(group_input_001.outputs[7], random_value_004.inputs[7])
	    #random_value_004.Value -> random_value_001.Seed
	    duplicate_hair_curves.links.new(random_value_004.outputs[2], random_value_001.inputs[8])
	    #vector_math_004.Vector -> evaluate_on_domain_001_1.Value
	    duplicate_hair_curves.links.new(vector_math_004.outputs[0], evaluate_on_domain_001_1.inputs[0])
	    #reroute_018.Output -> join_geometry_001.Geometry
	    duplicate_hair_curves.links.new(reroute_018.outputs[0], join_geometry_001.inputs[0])
	    #separate_components.Mesh -> reroute_012.Input
	    duplicate_hair_curves.links.new(separate_components.outputs[0], reroute_012.inputs[0])
	    #separate_components.Instances -> reroute_013.Input
	    duplicate_hair_curves.links.new(separate_components.outputs[5], reroute_013.inputs[0])
	    #separate_components.Point Cloud -> reroute_014.Input
	    duplicate_hair_curves.links.new(separate_components.outputs[3], reroute_014.inputs[0])
	    #separate_components.Volume -> reroute_015.Input
	    duplicate_hair_curves.links.new(separate_components.outputs[4], reroute_015.inputs[0])
	    #reroute_012.Output -> reroute_016.Input
	    duplicate_hair_curves.links.new(reroute_012.outputs[0], reroute_016.inputs[0])
	    #reroute_014.Output -> reroute_017.Input
	    duplicate_hair_curves.links.new(reroute_014.outputs[0], reroute_017.inputs[0])
	    #reroute_013.Output -> reroute_018.Input
	    duplicate_hair_curves.links.new(reroute_013.outputs[0], reroute_018.inputs[0])
	    #reroute_015.Output -> reroute_019.Input
	    duplicate_hair_curves.links.new(reroute_015.outputs[0], reroute_019.inputs[0])
	    #switch_001.Output -> reroute_020.Input
	    duplicate_hair_curves.links.new(switch_001.outputs[0], reroute_020.inputs[0])
	    #group_input.Geometry -> separate_components.Geometry
	    duplicate_hair_curves.links.new(group_input.outputs[0], separate_components.inputs[0])
	    #separate_components.Curve -> capture_attribute_001.Geometry
	    duplicate_hair_curves.links.new(separate_components.outputs[1], capture_attribute_001.inputs[0])
	    #reroute_004.Output -> group_output_3.Guide Index
	    duplicate_hair_curves.links.new(reroute_004.outputs[0], group_output_3.inputs[1])
	    #reroute_002.Output -> join_geometry.Geometry
	    duplicate_hair_curves.links.new(reroute_002.outputs[0], join_geometry.inputs[0])
	    #reroute_019.Output -> join_geometry_001.Geometry
	    duplicate_hair_curves.links.new(reroute_019.outputs[0], join_geometry_001.inputs[0])
	    #reroute_020.Output -> join_geometry_001.Geometry
	    duplicate_hair_curves.links.new(reroute_020.outputs[0], join_geometry_001.inputs[0])
	    #reroute_017.Output -> join_geometry_001.Geometry
	    duplicate_hair_curves.links.new(reroute_017.outputs[0], join_geometry_001.inputs[0])
	    #reroute_016.Output -> join_geometry_001.Geometry
	    duplicate_hair_curves.links.new(reroute_016.outputs[0], join_geometry_001.inputs[0])
	    return duplicate_hair_curves
	
	duplicate_hair_curves = duplicate_hair_curves_node_group()
	
	#initialize curve_segment node group
	def curve_segment_node_group():
	    curve_segment = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Curve Segment")
	
	    curve_segment.color_tag = 'INPUT'
	    curve_segment.description = "Reads information each point's previous curve segment"
	    curve_segment.default_group_node_width = 140
	    
	
	
	    #curve_segment interface
	    #Socket Segment Length
	    segment_length_socket = curve_segment.interface.new_socket(name = "Segment Length", in_out='OUTPUT', socket_type = 'NodeSocketFloat')
	    segment_length_socket.default_value = 0.0
	    segment_length_socket.min_value = -3.4028234663852886e+38
	    segment_length_socket.max_value = 3.4028234663852886e+38
	    segment_length_socket.subtype = 'NONE'
	    segment_length_socket.attribute_domain = 'POINT'
	    segment_length_socket.description = "Distance to previous point on curve"
	
	    #Socket Segment Direction
	    segment_direction_socket = curve_segment.interface.new_socket(name = "Segment Direction", in_out='OUTPUT', socket_type = 'NodeSocketVector')
	    segment_direction_socket.default_value = (0.0, 0.0, 0.0)
	    segment_direction_socket.min_value = -3.4028234663852886e+38
	    segment_direction_socket.max_value = 3.4028234663852886e+38
	    segment_direction_socket.subtype = 'NONE'
	    segment_direction_socket.attribute_domain = 'POINT'
	    segment_direction_socket.description = "Direction from previous neighboring point on segment"
	
	    #Socket Neighbor Index
	    neighbor_index_socket = curve_segment.interface.new_socket(name = "Neighbor Index", in_out='OUTPUT', socket_type = 'NodeSocketInt')
	    neighbor_index_socket.default_value = 0
	    neighbor_index_socket.min_value = -2147483648
	    neighbor_index_socket.max_value = 2147483647
	    neighbor_index_socket.subtype = 'NONE'
	    neighbor_index_socket.attribute_domain = 'POINT'
	    neighbor_index_socket.description = "Index of previous neighboring point on segment"
	
	
	    #initialize curve_segment nodes
	    #node Vector Math.009
	    vector_math_009_1 = curve_segment.nodes.new("ShaderNodeVectorMath")
	    vector_math_009_1.name = "Vector Math.009"
	    vector_math_009_1.operation = 'NORMALIZE'
	
	    #node Reroute.015
	    reroute_015_1 = curve_segment.nodes.new("NodeReroute")
	    reroute_015_1.name = "Reroute.015"
	    reroute_015_1.socket_idname = "NodeSocketVector"
	    #node Reroute.017
	    reroute_017_1 = curve_segment.nodes.new("NodeReroute")
	    reroute_017_1.name = "Reroute.017"
	    reroute_017_1.socket_idname = "NodeSocketVector"
	    #node Field at Index.001
	    field_at_index_001 = curve_segment.nodes.new("GeometryNodeFieldAtIndex")
	    field_at_index_001.name = "Field at Index.001"
	    field_at_index_001.data_type = 'FLOAT_VECTOR'
	    field_at_index_001.domain = 'POINT'
	
	    #node Vector Math.008
	    vector_math_008_1 = curve_segment.nodes.new("ShaderNodeVectorMath")
	    vector_math_008_1.name = "Vector Math.008"
	    vector_math_008_1.operation = 'SUBTRACT'
	
	    #node Reroute.018
	    reroute_018_1 = curve_segment.nodes.new("NodeReroute")
	    reroute_018_1.name = "Reroute.018"
	    reroute_018_1.socket_idname = "NodeSocketInt"
	    #node Interpolate Domain.002
	    interpolate_domain_002_2 = curve_segment.nodes.new("GeometryNodeFieldOnDomain")
	    interpolate_domain_002_2.name = "Interpolate Domain.002"
	    interpolate_domain_002_2.data_type = 'FLOAT_VECTOR'
	    interpolate_domain_002_2.domain = 'POINT'
	
	    #node Group Output
	    group_output_4 = curve_segment.nodes.new("NodeGroupOutput")
	    group_output_4.name = "Group Output"
	    group_output_4.is_active_output = True
	
	    #node Vector Math.007
	    vector_math_007_1 = curve_segment.nodes.new("ShaderNodeVectorMath")
	    vector_math_007_1.name = "Vector Math.007"
	    vector_math_007_1.operation = 'LENGTH'
	
	    #node Interpolate Domain.003
	    interpolate_domain_003 = curve_segment.nodes.new("GeometryNodeFieldOnDomain")
	    interpolate_domain_003.name = "Interpolate Domain.003"
	    interpolate_domain_003.data_type = 'INT'
	    interpolate_domain_003.domain = 'POINT'
	
	    #node Reroute
	    reroute_1 = curve_segment.nodes.new("NodeReroute")
	    reroute_1.name = "Reroute"
	    reroute_1.socket_idname = "NodeSocketBool"
	    #node Switch.004
	    switch_004 = curve_segment.nodes.new("GeometryNodeSwitch")
	    switch_004.name = "Switch.004"
	    switch_004.hide = True
	    switch_004.input_type = 'VECTOR'
	    #False
	    switch_004.inputs[1].default_value = (0.0, 0.0, 0.0)
	
	    #node Switch.003
	    switch_003 = curve_segment.nodes.new("GeometryNodeSwitch")
	    switch_003.name = "Switch.003"
	    switch_003.hide = True
	    switch_003.input_type = 'FLOAT'
	    #False
	    switch_003.inputs[1].default_value = 0.0
	
	    #node Boolean
	    boolean = curve_segment.nodes.new("FunctionNodeInputBool")
	    boolean.name = "Boolean"
	    boolean.boolean = True
	
	    #node Interpolate Domain
	    interpolate_domain_2 = curve_segment.nodes.new("GeometryNodeFieldOnDomain")
	    interpolate_domain_2.name = "Interpolate Domain"
	    interpolate_domain_2.data_type = 'BOOLEAN'
	    interpolate_domain_2.domain = 'CURVE'
	
	    #node Switch.005
	    switch_005 = curve_segment.nodes.new("GeometryNodeSwitch")
	    switch_005.name = "Switch.005"
	    switch_005.hide = True
	    switch_005.input_type = 'INT'
	    #False
	    switch_005.inputs[1].default_value = 0
	
	    #node Index.002
	    index_002 = curve_segment.nodes.new("GeometryNodeInputIndex")
	    index_002.name = "Index.002"
	
	    #node Switch.001
	    switch_001_1 = curve_segment.nodes.new("GeometryNodeSwitch")
	    switch_001_1.name = "Switch.001"
	    switch_001_1.input_type = 'INT'
	
	    #node Offset Point in Curve
	    offset_point_in_curve = curve_segment.nodes.new("GeometryNodeOffsetPointInCurve")
	    offset_point_in_curve.name = "Offset Point in Curve"
	    #Point Index
	    offset_point_in_curve.inputs[0].default_value = 0
	    #Offset
	    offset_point_in_curve.inputs[1].default_value = -1
	
	    #node Position.002
	    position_002_2 = curve_segment.nodes.new("GeometryNodeInputPosition")
	    position_002_2.name = "Position.002"
	
	
	
	
	
	    #Set locations
	    vector_math_009_1.location = (-389.8524169921875, 30.443286895751953)
	    reroute_015_1.location = (-456.8948974609375, 4.604297637939453)
	    reroute_017_1.location = (-1012.7362060546875, -9.742748260498047)
	    field_at_index_001.location = (-992.6431884765625, 70.62931823730469)
	    vector_math_008_1.location = (-811.805908203125, 70.62931823730469)
	    reroute_018_1.location = (-1032.8292236328125, 110.81541442871094)
	    interpolate_domain_002_2.location = (-630.9686279296875, 70.62931823730469)
	    group_output_4.location = (75.0, 50.0)
	    vector_math_007_1.location = (-389.8524169921875, 151.00144958496094)
	    interpolate_domain_003.location = (-390.85833740234375, -97.25408935546875)
	    reroute_1.location = (-342.979248046875, 193.345458984375)
	    switch_004.location = (-178.8756103515625, 10.35025405883789)
	    switch_003.location = (-178.8756103515625, 90.72234344482422)
	    boolean.location = (-781.6663208007812, 291.652587890625)
	    interpolate_domain_2.location = (-600.8291015625, 311.74560546875)
	    switch_005.location = (-178.8756103515625, -70.0218505859375)
	    index_002.location = (-1404.550048828125, 211.28048706054688)
	    switch_001_1.location = (-1223.712890625, 231.37350463867188)
	    offset_point_in_curve.location = (-1404.550048828125, 151.0014190673828)
	    position_002_2.location = (-1223.712890625, 30.44327163696289)
	
	    #Set dimensions
	    vector_math_009_1.width, vector_math_009_1.height = 140.0, 100.0
	    reroute_015_1.width, reroute_015_1.height = 100.0, 100.0
	    reroute_017_1.width, reroute_017_1.height = 100.0, 100.0
	    field_at_index_001.width, field_at_index_001.height = 140.0, 100.0
	    vector_math_008_1.width, vector_math_008_1.height = 140.0, 100.0
	    reroute_018_1.width, reroute_018_1.height = 100.0, 100.0
	    interpolate_domain_002_2.width, interpolate_domain_002_2.height = 140.0, 100.0
	    group_output_4.width, group_output_4.height = 140.0, 100.0
	    vector_math_007_1.width, vector_math_007_1.height = 140.0, 100.0
	    interpolate_domain_003.width, interpolate_domain_003.height = 140.0, 100.0
	    reroute_1.width, reroute_1.height = 100.0, 100.0
	    switch_004.width, switch_004.height = 140.0, 100.0
	    switch_003.width, switch_003.height = 140.0, 100.0
	    boolean.width, boolean.height = 140.0, 100.0
	    interpolate_domain_2.width, interpolate_domain_2.height = 140.0, 100.0
	    switch_005.width, switch_005.height = 140.0, 100.0
	    index_002.width, index_002.height = 140.0, 100.0
	    switch_001_1.width, switch_001_1.height = 140.0, 100.0
	    offset_point_in_curve.width, offset_point_in_curve.height = 140.0, 100.0
	    position_002_2.width, position_002_2.height = 140.0, 100.0
	
	    #initialize curve_segment links
	    #reroute_015_1.Output -> vector_math_007_1.Vector
	    curve_segment.links.new(reroute_015_1.outputs[0], vector_math_007_1.inputs[0])
	    #reroute_018_1.Output -> field_at_index_001.Index
	    curve_segment.links.new(reroute_018_1.outputs[0], field_at_index_001.inputs[0])
	    #vector_math_008_1.Vector -> interpolate_domain_002_2.Value
	    curve_segment.links.new(vector_math_008_1.outputs[0], interpolate_domain_002_2.inputs[0])
	    #reroute_017_1.Output -> vector_math_008_1.Vector
	    curve_segment.links.new(reroute_017_1.outputs[0], vector_math_008_1.inputs[0])
	    #reroute_015_1.Output -> vector_math_009_1.Vector
	    curve_segment.links.new(reroute_015_1.outputs[0], vector_math_009_1.inputs[0])
	    #reroute_017_1.Output -> field_at_index_001.Value
	    curve_segment.links.new(reroute_017_1.outputs[0], field_at_index_001.inputs[1])
	    #field_at_index_001.Value -> vector_math_008_1.Vector
	    curve_segment.links.new(field_at_index_001.outputs[0], vector_math_008_1.inputs[1])
	    #position_002_2.Position -> reroute_017_1.Input
	    curve_segment.links.new(position_002_2.outputs[0], reroute_017_1.inputs[0])
	    #interpolate_domain_002_2.Value -> reroute_015_1.Input
	    curve_segment.links.new(interpolate_domain_002_2.outputs[0], reroute_015_1.inputs[0])
	    #switch_004.Output -> group_output_4.Segment Direction
	    curve_segment.links.new(switch_004.outputs[0], group_output_4.inputs[1])
	    #switch_005.Output -> group_output_4.Neighbor Index
	    curve_segment.links.new(switch_005.outputs[0], group_output_4.inputs[2])
	    #boolean.Boolean -> interpolate_domain_2.Value
	    curve_segment.links.new(boolean.outputs[0], interpolate_domain_2.inputs[0])
	    #reroute_018_1.Output -> interpolate_domain_003.Value
	    curve_segment.links.new(reroute_018_1.outputs[0], interpolate_domain_003.inputs[0])
	    #vector_math_007_1.Value -> switch_003.True
	    curve_segment.links.new(vector_math_007_1.outputs[1], switch_003.inputs[2])
	    #reroute_1.Output -> switch_003.Switch
	    curve_segment.links.new(reroute_1.outputs[0], switch_003.inputs[0])
	    #switch_003.Output -> group_output_4.Segment Length
	    curve_segment.links.new(switch_003.outputs[0], group_output_4.inputs[0])
	    #vector_math_009_1.Vector -> switch_004.True
	    curve_segment.links.new(vector_math_009_1.outputs[0], switch_004.inputs[2])
	    #interpolate_domain_2.Value -> reroute_1.Input
	    curve_segment.links.new(interpolate_domain_2.outputs[0], reroute_1.inputs[0])
	    #reroute_1.Output -> switch_004.Switch
	    curve_segment.links.new(reroute_1.outputs[0], switch_004.inputs[0])
	    #interpolate_domain_003.Value -> switch_005.True
	    curve_segment.links.new(interpolate_domain_003.outputs[0], switch_005.inputs[2])
	    #reroute_1.Output -> switch_005.Switch
	    curve_segment.links.new(reroute_1.outputs[0], switch_005.inputs[0])
	    #offset_point_in_curve.Is Valid Offset -> switch_001_1.Switch
	    curve_segment.links.new(offset_point_in_curve.outputs[0], switch_001_1.inputs[0])
	    #offset_point_in_curve.Point Index -> switch_001_1.True
	    curve_segment.links.new(offset_point_in_curve.outputs[1], switch_001_1.inputs[2])
	    #index_002.Index -> switch_001_1.False
	    curve_segment.links.new(index_002.outputs[0], switch_001_1.inputs[1])
	    #switch_001_1.Output -> reroute_018_1.Input
	    curve_segment.links.new(switch_001_1.outputs[0], reroute_018_1.inputs[0])
	    return curve_segment
	
	curve_segment = curve_segment_node_group()
	
	#initialize restore_curve_segment_length node group
	def restore_curve_segment_length_node_group():
	    restore_curve_segment_length = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Restore Curve Segment Length")
	
	    restore_curve_segment_length.color_tag = 'GEOMETRY'
	    restore_curve_segment_length.description = "Restores the length of each curve segment using a previous state after deformation"
	    restore_curve_segment_length.default_group_node_width = 140
	    
	
	    restore_curve_segment_length.is_modifier = True
	
	    #restore_curve_segment_length interface
	    #Socket Curves
	    curves_socket = restore_curve_segment_length.interface.new_socket(name = "Curves", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    curves_socket.attribute_domain = 'POINT'
	
	    #Socket Curves
	    curves_socket_1 = restore_curve_segment_length.interface.new_socket(name = "Curves", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    curves_socket_1.attribute_domain = 'POINT'
	
	    #Socket Selection
	    selection_socket = restore_curve_segment_length.interface.new_socket(name = "Selection", in_out='INPUT', socket_type = 'NodeSocketBool')
	    selection_socket.default_value = True
	    selection_socket.attribute_domain = 'POINT'
	    selection_socket.hide_value = True
	    selection_socket.description = "Only affect selected elements"
	
	    #Socket Factor
	    factor_socket = restore_curve_segment_length.interface.new_socket(name = "Factor", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    factor_socket.default_value = 1.0
	    factor_socket.min_value = 0.0
	    factor_socket.max_value = 1.0
	    factor_socket.subtype = 'FACTOR'
	    factor_socket.attribute_domain = 'POINT'
	    factor_socket.description = "Factor to blend overall effect"
	
	    #Socket Reference Position
	    reference_position_socket = restore_curve_segment_length.interface.new_socket(name = "Reference Position", in_out='INPUT', socket_type = 'NodeSocketVector')
	    reference_position_socket.default_value = (8.146539688110352, 4.969870090484619, 9.874540328979492)
	    reference_position_socket.min_value = -3.4028234663852886e+38
	    reference_position_socket.max_value = 3.4028234663852886e+38
	    reference_position_socket.subtype = 'NONE'
	    reference_position_socket.default_attribute_name = "rest_position"
	    reference_position_socket.attribute_domain = 'POINT'
	    reference_position_socket.hide_value = True
	    reference_position_socket.description = "Reference position before deformation"
	
	    #Socket Pin at Parameter
	    pin_at_parameter_socket = restore_curve_segment_length.interface.new_socket(name = "Pin at Parameter", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    pin_at_parameter_socket.default_value = 0.0
	    pin_at_parameter_socket.min_value = 0.0
	    pin_at_parameter_socket.max_value = 1.0
	    pin_at_parameter_socket.subtype = 'FACTOR'
	    pin_at_parameter_socket.attribute_domain = 'POINT'
	    pin_at_parameter_socket.description = "Pin each curve at a certain point for the operation"
	
	
	    #initialize restore_curve_segment_length nodes
	    #node Frame.001
	    frame_001_1 = restore_curve_segment_length.nodes.new("NodeFrame")
	    frame_001_1.label = "Pin at Parameter"
	    frame_001_1.name = "Frame.001"
	    frame_001_1.label_size = 20
	    frame_001_1.shrink = True
	
	    #node Frame
	    frame_2 = restore_curve_segment_length.nodes.new("NodeFrame")
	    frame_2.label = "Restore Segment Lengths"
	    frame_2.name = "Frame"
	    frame_2.label_size = 20
	    frame_2.shrink = True
	
	    #node Frame.002
	    frame_002_1 = restore_curve_segment_length.nodes.new("NodeFrame")
	    frame_002_1.label = "Default Fallback"
	    frame_002_1.name = "Frame.002"
	    frame_002_1.label_size = 20
	    frame_002_1.shrink = True
	
	    #node Reroute.009
	    reroute_009 = restore_curve_segment_length.nodes.new("NodeReroute")
	    reroute_009.name = "Reroute.009"
	    reroute_009.socket_idname = "NodeSocketVector"
	    #node Group Input.006
	    group_input_006_1 = restore_curve_segment_length.nodes.new("NodeGroupInput")
	    group_input_006_1.name = "Group Input.006"
	    group_input_006_1.outputs[0].hide = True
	    group_input_006_1.outputs[1].hide = True
	    group_input_006_1.outputs[2].hide = True
	    group_input_006_1.outputs[3].hide = True
	    group_input_006_1.outputs[5].hide = True
	
	    #node Reroute.013
	    reroute_013_1 = restore_curve_segment_length.nodes.new("NodeReroute")
	    reroute_013_1.name = "Reroute.013"
	    reroute_013_1.socket_idname = "NodeSocketGeometry"
	    #node Index
	    index_1 = restore_curve_segment_length.nodes.new("GeometryNodeInputIndex")
	    index_1.name = "Index"
	
	    #node Sample Curve.001
	    sample_curve_001 = restore_curve_segment_length.nodes.new("GeometryNodeSampleCurve")
	    sample_curve_001.name = "Sample Curve.001"
	    sample_curve_001.data_type = 'FLOAT_VECTOR'
	    sample_curve_001.mode = 'FACTOR'
	    sample_curve_001.use_all_curves = False
	
	    #node Group Input.003
	    group_input_003_1 = restore_curve_segment_length.nodes.new("NodeGroupInput")
	    group_input_003_1.name = "Group Input.003"
	    group_input_003_1.outputs[0].hide = True
	    group_input_003_1.outputs[1].hide = True
	    group_input_003_1.outputs[2].hide = True
	    group_input_003_1.outputs[3].hide = True
	    group_input_003_1.outputs[5].hide = True
	
	    #node Vector Math.006
	    vector_math_006_1 = restore_curve_segment_length.nodes.new("ShaderNodeVectorMath")
	    vector_math_006_1.name = "Vector Math.006"
	    vector_math_006_1.hide = True
	    vector_math_006_1.operation = 'SUBTRACT'
	
	    #node Interpolate Domain
	    interpolate_domain_3 = restore_curve_segment_length.nodes.new("GeometryNodeFieldOnDomain")
	    interpolate_domain_3.name = "Interpolate Domain"
	    interpolate_domain_3.hide = True
	    interpolate_domain_3.data_type = 'FLOAT_VECTOR'
	    interpolate_domain_3.domain = 'CURVE'
	
	    #node Group Input.005
	    group_input_005_1 = restore_curve_segment_length.nodes.new("NodeGroupInput")
	    group_input_005_1.name = "Group Input.005"
	    group_input_005_1.outputs[0].hide = True
	    group_input_005_1.outputs[2].hide = True
	    group_input_005_1.outputs[3].hide = True
	    group_input_005_1.outputs[4].hide = True
	    group_input_005_1.outputs[5].hide = True
	
	    #node Boolean Math.002
	    boolean_math_002 = restore_curve_segment_length.nodes.new("FunctionNodeBooleanMath")
	    boolean_math_002.name = "Boolean Math.002"
	    boolean_math_002.hide = True
	    boolean_math_002.operation = 'AND'
	
	    #node Field at Index.002
	    field_at_index_002 = restore_curve_segment_length.nodes.new("GeometryNodeFieldAtIndex")
	    field_at_index_002.name = "Field at Index.002"
	    field_at_index_002.data_type = 'FLOAT_VECTOR'
	    field_at_index_002.domain = 'POINT'
	
	    #node Vector Math.004
	    vector_math_004_1 = restore_curve_segment_length.nodes.new("ShaderNodeVectorMath")
	    vector_math_004_1.name = "Vector Math.004"
	    vector_math_004_1.operation = 'DISTANCE'
	
	    #node Accumulate Field
	    accumulate_field = restore_curve_segment_length.nodes.new("GeometryNodeAccumulateField")
	    accumulate_field.name = "Accumulate Field"
	    accumulate_field.data_type = 'FLOAT_VECTOR'
	    accumulate_field.domain = 'POINT'
	    accumulate_field.outputs[1].hide = True
	    accumulate_field.outputs[2].hide = True
	
	    #node Curve of Point
	    curve_of_point = restore_curve_segment_length.nodes.new("GeometryNodeCurveOfPoint")
	    curve_of_point.name = "Curve of Point"
	    curve_of_point.inputs[0].hide = True
	    curve_of_point.outputs[1].hide = True
	    #Point Index
	    curve_of_point.inputs[0].default_value = 0
	
	    #node Vector Math
	    vector_math_2 = restore_curve_segment_length.nodes.new("ShaderNodeVectorMath")
	    vector_math_2.name = "Vector Math"
	    vector_math_2.operation = 'SCALE'
	
	    #node Index.001
	    index_001_1 = restore_curve_segment_length.nodes.new("GeometryNodeInputIndex")
	    index_001_1.name = "Index.001"
	
	    #node Curve of Point.001
	    curve_of_point_001 = restore_curve_segment_length.nodes.new("GeometryNodeCurveOfPoint")
	    curve_of_point_001.name = "Curve of Point.001"
	    curve_of_point_001.inputs[0].hide = True
	    curve_of_point_001.outputs[0].hide = True
	    #Point Index
	    curve_of_point_001.inputs[0].default_value = 0
	
	    #node Switch
	    switch_1 = restore_curve_segment_length.nodes.new("GeometryNodeSwitch")
	    switch_1.name = "Switch"
	    switch_1.input_type = 'INT'
	
	    #node Math
	    math_1 = restore_curve_segment_length.nodes.new("ShaderNodeMath")
	    math_1.name = "Math"
	    math_1.hide = True
	    math_1.operation = 'SUBTRACT'
	    math_1.use_clamp = False
	    #Value_001
	    math_1.inputs[1].default_value = 1.0
	
	    #node Compare
	    compare = restore_curve_segment_length.nodes.new("FunctionNodeCompare")
	    compare.name = "Compare"
	    compare.hide = True
	    compare.data_type = 'INT'
	    compare.mode = 'ELEMENT'
	    compare.operation = 'EQUAL'
	    #B_INT
	    compare.inputs[3].default_value = 0
	
	    #node Reroute.001
	    reroute_001_1 = restore_curve_segment_length.nodes.new("NodeReroute")
	    reroute_001_1.name = "Reroute.001"
	    reroute_001_1.socket_idname = "NodeSocketVector"
	    #node Set Position.001
	    set_position_001_1 = restore_curve_segment_length.nodes.new("GeometryNodeSetPosition")
	    set_position_001_1.name = "Set Position.001"
	
	    #node Boolean Math
	    boolean_math = restore_curve_segment_length.nodes.new("FunctionNodeBooleanMath")
	    boolean_math.name = "Boolean Math"
	    boolean_math.operation = 'AND'
	
	    #node Compare.002
	    compare_002 = restore_curve_segment_length.nodes.new("FunctionNodeCompare")
	    compare_002.name = "Compare.002"
	    compare_002.data_type = 'FLOAT'
	    compare_002.mode = 'ELEMENT'
	    compare_002.operation = 'GREATER_THAN'
	    #B
	    compare_002.inputs[1].default_value = 0.0
	
	    #node Group Input.002
	    group_input_002_1 = restore_curve_segment_length.nodes.new("NodeGroupInput")
	    group_input_002_1.name = "Group Input.002"
	    group_input_002_1.outputs[0].hide = True
	    group_input_002_1.outputs[3].hide = True
	    group_input_002_1.outputs[4].hide = True
	    group_input_002_1.outputs[5].hide = True
	
	    #node Reroute.016
	    reroute_016_1 = restore_curve_segment_length.nodes.new("NodeReroute")
	    reroute_016_1.name = "Reroute.016"
	    reroute_016_1.socket_idname = "NodeSocketBool"
	    #node Reroute.014
	    reroute_014_1 = restore_curve_segment_length.nodes.new("NodeReroute")
	    reroute_014_1.name = "Reroute.014"
	    reroute_014_1.socket_idname = "NodeSocketGeometry"
	    #node Switch.001
	    switch_001_2 = restore_curve_segment_length.nodes.new("GeometryNodeSwitch")
	    switch_001_2.name = "Switch.001"
	    switch_001_2.input_type = 'GEOMETRY'
	
	    #node Group Output
	    group_output_5 = restore_curve_segment_length.nodes.new("NodeGroupOutput")
	    group_output_5.name = "Group Output"
	    group_output_5.is_active_output = True
	
	    #node Attribute Statistic
	    attribute_statistic = restore_curve_segment_length.nodes.new("GeometryNodeAttributeStatistic")
	    attribute_statistic.name = "Attribute Statistic"
	    attribute_statistic.hide = True
	    attribute_statistic.data_type = 'FLOAT'
	    attribute_statistic.domain = 'CURVE'
	    attribute_statistic.inputs[1].hide = True
	    attribute_statistic.outputs[0].hide = True
	    attribute_statistic.outputs[1].hide = True
	    attribute_statistic.outputs[2].hide = True
	    attribute_statistic.outputs[3].hide = True
	    attribute_statistic.outputs[5].hide = True
	    attribute_statistic.outputs[6].hide = True
	    attribute_statistic.outputs[7].hide = True
	    #Selection
	    attribute_statistic.inputs[1].default_value = True
	
	    #node Group
	    group_2 = restore_curve_segment_length.nodes.new("GeometryNodeGroup")
	    group_2.name = "Group"
	    group_2.node_tree = curve_root
	    group_2.outputs[0].hide = True
	    group_2.outputs[2].hide = True
	    group_2.outputs[3].hide = True
	
	    #node Reroute.007
	    reroute_007 = restore_curve_segment_length.nodes.new("NodeReroute")
	    reroute_007.name = "Reroute.007"
	    reroute_007.socket_idname = "NodeSocketVector"
	    #node Reroute.004
	    reroute_004_1 = restore_curve_segment_length.nodes.new("NodeReroute")
	    reroute_004_1.name = "Reroute.004"
	    reroute_004_1.socket_idname = "NodeSocketGeometry"
	    #node Position.001
	    position_001 = restore_curve_segment_length.nodes.new("GeometryNodeInputPosition")
	    position_001.name = "Position.001"
	
	    #node Named Attribute
	    named_attribute_1 = restore_curve_segment_length.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute_1.name = "Named Attribute"
	    named_attribute_1.data_type = 'FLOAT_VECTOR'
	    #Name
	    named_attribute_1.inputs[0].default_value = "rest_position"
	
	    #node Switch.003
	    switch_003_1 = restore_curve_segment_length.nodes.new("GeometryNodeSwitch")
	    switch_003_1.name = "Switch.003"
	    switch_003_1.input_type = 'VECTOR'
	
	    #node Reroute.006
	    reroute_006 = restore_curve_segment_length.nodes.new("NodeReroute")
	    reroute_006.name = "Reroute.006"
	    reroute_006.socket_idname = "NodeSocketVector"
	    #node Switch.002
	    switch_002 = restore_curve_segment_length.nodes.new("GeometryNodeSwitch")
	    switch_002.name = "Switch.002"
	    switch_002.input_type = 'VECTOR'
	
	    #node Compare.004
	    compare_004 = restore_curve_segment_length.nodes.new("FunctionNodeCompare")
	    compare_004.name = "Compare.004"
	    compare_004.data_type = 'VECTOR'
	    compare_004.mode = 'ELEMENT'
	    compare_004.operation = 'EQUAL'
	    #B_VEC3
	    compare_004.inputs[5].default_value = (8.146539688110352, 4.969870090484619, 9.874540328979492)
	    #Epsilon
	    compare_004.inputs[12].default_value = 0.0
	
	    #node Group Input
	    group_input_1 = restore_curve_segment_length.nodes.new("NodeGroupInput")
	    group_input_1.name = "Group Input"
	    group_input_1.outputs[1].hide = True
	    group_input_1.outputs[2].hide = True
	    group_input_1.outputs[4].hide = True
	    group_input_1.outputs[5].hide = True
	
	    #node Reroute.011
	    reroute_011 = restore_curve_segment_length.nodes.new("NodeReroute")
	    reroute_011.name = "Reroute.011"
	    reroute_011.socket_idname = "NodeSocketGeometry"
	    #node Reroute.005
	    reroute_005 = restore_curve_segment_length.nodes.new("NodeReroute")
	    reroute_005.name = "Reroute.005"
	    reroute_005.socket_idname = "NodeSocketGeometry"
	    #node Reroute.008
	    reroute_008 = restore_curve_segment_length.nodes.new("NodeReroute")
	    reroute_008.name = "Reroute.008"
	    reroute_008.socket_idname = "NodeSocketVector"
	    #node Set Position.002
	    set_position_002 = restore_curve_segment_length.nodes.new("GeometryNodeSetPosition")
	    set_position_002.name = "Set Position.002"
	    set_position_002.inputs[2].hide = True
	    #Position
	    set_position_002.inputs[2].default_value = (0.0, 0.0, 0.0)
	
	    #node Reroute.012
	    reroute_012_1 = restore_curve_segment_length.nodes.new("NodeReroute")
	    reroute_012_1.name = "Reroute.012"
	    reroute_012_1.socket_idname = "NodeSocketGeometry"
	    #node Group Input.001
	    group_input_001_1 = restore_curve_segment_length.nodes.new("NodeGroupInput")
	    group_input_001_1.name = "Group Input.001"
	    group_input_001_1.outputs[0].hide = True
	    group_input_001_1.outputs[1].hide = True
	    group_input_001_1.outputs[3].hide = True
	    group_input_001_1.outputs[4].hide = True
	    group_input_001_1.outputs[5].hide = True
	
	    #node Mix
	    mix = restore_curve_segment_length.nodes.new("ShaderNodeMix")
	    mix.name = "Mix"
	    mix.blend_type = 'MIX'
	    mix.clamp_factor = True
	    mix.clamp_result = False
	    mix.data_type = 'FLOAT'
	    mix.factor_mode = 'UNIFORM'
	
	    #node Group.001
	    group_001_2 = restore_curve_segment_length.nodes.new("GeometryNodeGroup")
	    group_001_2.name = "Group.001"
	    group_001_2.node_tree = curve_segment
	    group_001_2.outputs[2].hide = True
	
	    #node Compare.003
	    compare_003 = restore_curve_segment_length.nodes.new("FunctionNodeCompare")
	    compare_003.name = "Compare.003"
	    compare_003.hide = True
	    compare_003.data_type = 'FLOAT'
	    compare_003.mode = 'ELEMENT'
	    compare_003.operation = 'NOT_EQUAL'
	    #B
	    compare_003.inputs[1].default_value = 0.0
	    #Epsilon
	    compare_003.inputs[12].default_value = 0.0
	
	    #node Compare.005
	    compare_005 = restore_curve_segment_length.nodes.new("FunctionNodeCompare")
	    compare_005.name = "Compare.005"
	    compare_005.hide = True
	    compare_005.data_type = 'FLOAT'
	    compare_005.mode = 'ELEMENT'
	    compare_005.operation = 'GREATER_THAN'
	    #B
	    compare_005.inputs[1].default_value = 0.0
	
	
	
	
	    #Set parents
	    group_input_006_1.parent = frame_001_1
	    reroute_013_1.parent = frame_001_1
	    index_1.parent = frame_001_1
	    sample_curve_001.parent = frame_001_1
	    group_input_003_1.parent = frame_001_1
	    vector_math_006_1.parent = frame_001_1
	    interpolate_domain_3.parent = frame_001_1
	    group_input_005_1.parent = frame_001_1
	    boolean_math_002.parent = frame_001_1
	    field_at_index_002.parent = frame_2
	    vector_math_004_1.parent = frame_2
	    accumulate_field.parent = frame_2
	    curve_of_point.parent = frame_2
	    vector_math_2.parent = frame_2
	    index_001_1.parent = frame_2
	    curve_of_point_001.parent = frame_2
	    switch_1.parent = frame_2
	    math_1.parent = frame_2
	    compare.parent = frame_2
	    reroute_001_1.parent = frame_2
	    set_position_001_1.parent = frame_2
	    boolean_math.parent = frame_2
	    compare_002.parent = frame_2
	    group_input_002_1.parent = frame_2
	    reroute_016_1.parent = frame_001_1
	    reroute_014_1.parent = frame_001_1
	    switch_001_2.parent = frame_001_1
	    attribute_statistic.parent = frame_001_1
	    group_2.parent = frame_2
	    reroute_004_1.parent = frame_2
	    position_001.parent = frame_002_1
	    named_attribute_1.parent = frame_002_1
	    switch_003_1.parent = frame_002_1
	    reroute_006.parent = frame_002_1
	    switch_002.parent = frame_002_1
	    compare_004.parent = frame_002_1
	    reroute_005.parent = frame_2
	    set_position_002.parent = frame_001_1
	    reroute_012_1.parent = frame_001_1
	    group_input_001_1.parent = frame_2
	    mix.parent = frame_2
	    group_001_2.parent = frame_2
	    compare_003.parent = frame_001_1
	    compare_005.parent = frame_001_1
	
	    #Set locations
	    frame_001_1.location = (-1289.059814453125, 110.20000457763672)
	    frame_2.location = (-3492.00048828125, 57.61393737792969)
	    frame_002_1.location = (-4467.1064453125, -100.04000854492188)
	    reroute_009.location = (-1431.9771728515625, -673.348876953125)
	    group_input_006_1.location = (218.757080078125, -140.57211303710938)
	    reroute_013_1.location = (178.571044921875, -120.47908020019531)
	    index_1.location = (37.919921875, -482.15350341796875)
	    sample_curve_001.location = (218.757080078125, -220.94418334960938)
	    group_input_003_1.location = (37.919921875, -421.87445068359375)
	    vector_math_006_1.location = (399.5943603515625, -261.1302490234375)
	    interpolate_domain_3.location = (580.4315795898438, -261.1302490234375)
	    group_input_005_1.location = (399.5943603515625, -180.75814819335938)
	    boolean_math_002.location = (580.4315795898438, -180.75814819335938)
	    field_at_index_002.location = (653.51171875, -248.73023986816406)
	    vector_math_004_1.location = (834.348876953125, -228.63722229003906)
	    accumulate_field.location = (1557.69775390625, -409.47442626953125)
	    curve_of_point.location = (1356.767578125, -550.1256103515625)
	    vector_math_2.location = (1356.767578125, -389.38140869140625)
	    index_001_1.location = (30.6279296875, -469.75347900390625)
	    curve_of_point_001.location = (30.6279296875, -389.38140869140625)
	    switch_1.location = (412.3955078125, -369.28839111328125)
	    math_1.location = (211.46533203125, -469.75347900390625)
	    compare.location = (211.46533203125, -429.56744384765625)
	    reroute_001_1.location = (613.32568359375, -309.0093078613281)
	    set_position_001_1.location = (1798.8140869140625, -148.26512145996094)
	    boolean_math.location = (1494.958251953125, -96.33775329589844)
	    compare_002.location = (1294.0283203125, -116.43077850341797)
	    group_input_002_1.location = (1113.19140625, -136.5238037109375)
	    reroute_016_1.location = (801.454833984375, -160.66513061523438)
	    reroute_014_1.location = (801.454833984375, -120.47908020019531)
	    switch_001_2.location = (1082.757080078125, -40.10698699951172)
	    group_output_5.location = (75.0, 50.0)
	    attribute_statistic.location = (861.73388671875, -60.20000457763672)
	    group_2.location = (1557.69775390625, -268.8232421875)
	    reroute_007.location = (-3762.76806640625, -251.3953857421875)
	    reroute_004_1.location = (1638.06982421875, -47.80000305175781)
	    position_001.location = (60.265625, -241.41067504882812)
	    named_attribute_1.location = (60.265625, -301.6897277832031)
	    switch_003_1.location = (241.1025390625, -221.31765747070312)
	    reroute_006.location = (37.919921875, -72.88264465332031)
	    switch_002.location = (442.03271484375, -100.75950622558594)
	    compare_004.location = (60.26611328125, -40.480438232421875)
	    group_input_1.location = (-4707.1396484375, -30.37213134765625)
	    reroute_011.location = (-3581.9306640625, -70.55816650390625)
	    reroute_005.location = (50.72119140625, -47.80000305175781)
	    reroute_008.location = (-3561.83740234375, -673.348876953125)
	    set_position_002.location = (861.73388671875, -140.57211303710938)
	    reroute_012_1.location = (37.919921875, -241.0372314453125)
	    group_input_001_1.location = (834.348876953125, -168.358154296875)
	    mix.location = (1115.6513671875, -329.10235595703125)
	    group_001_2.location = (834.348876953125, -409.47442626953125)
	    compare_003.location = (399.5943603515625, -140.57211303710938)
	    compare_005.location = (861.73388671875, -100.38605499267578)
	
	    #Set dimensions
	    frame_001_1.width, frame_001_1.height = 1252.8997802734375, 561.8800659179688
	    frame_2.width, frame_2.height = 1968.80029296875, 632.1739501953125
	    frame_002_1.width, frame_002_1.height = 612.06640625, 452.4400329589844
	    reroute_009.width, reroute_009.height = 100.0, 100.0
	    group_input_006_1.width, group_input_006_1.height = 140.0, 100.0
	    reroute_013_1.width, reroute_013_1.height = 100.0, 100.0
	    index_1.width, index_1.height = 140.0, 100.0
	    sample_curve_001.width, sample_curve_001.height = 140.0, 100.0
	    group_input_003_1.width, group_input_003_1.height = 140.0, 100.0
	    vector_math_006_1.width, vector_math_006_1.height = 140.0, 100.0
	    interpolate_domain_3.width, interpolate_domain_3.height = 140.0, 100.0
	    group_input_005_1.width, group_input_005_1.height = 140.0, 100.0
	    boolean_math_002.width, boolean_math_002.height = 140.0, 100.0
	    field_at_index_002.width, field_at_index_002.height = 140.0, 100.0
	    vector_math_004_1.width, vector_math_004_1.height = 140.0, 100.0
	    accumulate_field.width, accumulate_field.height = 140.0, 100.0
	    curve_of_point.width, curve_of_point.height = 140.0, 100.0
	    vector_math_2.width, vector_math_2.height = 140.0, 100.0
	    index_001_1.width, index_001_1.height = 140.0, 100.0
	    curve_of_point_001.width, curve_of_point_001.height = 140.0, 100.0
	    switch_1.width, switch_1.height = 140.0, 100.0
	    math_1.width, math_1.height = 140.0, 100.0
	    compare.width, compare.height = 140.0, 100.0
	    reroute_001_1.width, reroute_001_1.height = 100.0, 100.0
	    set_position_001_1.width, set_position_001_1.height = 140.0, 100.0
	    boolean_math.width, boolean_math.height = 140.0, 100.0
	    compare_002.width, compare_002.height = 140.0, 100.0
	    group_input_002_1.width, group_input_002_1.height = 140.0, 100.0
	    reroute_016_1.width, reroute_016_1.height = 100.0, 100.0
	    reroute_014_1.width, reroute_014_1.height = 100.0, 100.0
	    switch_001_2.width, switch_001_2.height = 140.0, 100.0
	    group_output_5.width, group_output_5.height = 140.0, 100.0
	    attribute_statistic.width, attribute_statistic.height = 140.0, 100.0
	    group_2.width, group_2.height = 140.0, 100.0
	    reroute_007.width, reroute_007.height = 100.0, 100.0
	    reroute_004_1.width, reroute_004_1.height = 100.0, 100.0
	    position_001.width, position_001.height = 140.0, 100.0
	    named_attribute_1.width, named_attribute_1.height = 140.0, 100.0
	    switch_003_1.width, switch_003_1.height = 140.0, 100.0
	    reroute_006.width, reroute_006.height = 100.0, 100.0
	    switch_002.width, switch_002.height = 140.0, 100.0
	    compare_004.width, compare_004.height = 140.0, 100.0
	    group_input_1.width, group_input_1.height = 140.0, 100.0
	    reroute_011.width, reroute_011.height = 100.0, 100.0
	    reroute_005.width, reroute_005.height = 100.0, 100.0
	    reroute_008.width, reroute_008.height = 100.0, 100.0
	    set_position_002.width, set_position_002.height = 140.0, 100.0
	    reroute_012_1.width, reroute_012_1.height = 100.0, 100.0
	    group_input_001_1.width, group_input_001_1.height = 140.0, 100.0
	    mix.width, mix.height = 140.0, 100.0
	    group_001_2.width, group_001_2.height = 140.0, 100.0
	    compare_003.width, compare_003.height = 140.0, 100.0
	    compare_005.width, compare_005.height = 140.0, 100.0
	
	    #initialize restore_curve_segment_length links
	    #reroute_004_1.Output -> set_position_001_1.Geometry
	    restore_curve_segment_length.links.new(reroute_004_1.outputs[0], set_position_001_1.inputs[0])
	    #curve_of_point.Curve Index -> accumulate_field.Group ID
	    restore_curve_segment_length.links.new(curve_of_point.outputs[0], accumulate_field.inputs[1])
	    #field_at_index_002.Value -> vector_math_004_1.Vector
	    restore_curve_segment_length.links.new(field_at_index_002.outputs[0], vector_math_004_1.inputs[0])
	    #reroute_001_1.Output -> vector_math_004_1.Vector
	    restore_curve_segment_length.links.new(reroute_001_1.outputs[0], vector_math_004_1.inputs[1])
	    #reroute_001_1.Output -> field_at_index_002.Value
	    restore_curve_segment_length.links.new(reroute_001_1.outputs[0], field_at_index_002.inputs[1])
	    #index_001_1.Index -> math_1.Value
	    restore_curve_segment_length.links.new(index_001_1.outputs[0], math_1.inputs[0])
	    #switch_1.Output -> field_at_index_002.Index
	    restore_curve_segment_length.links.new(switch_1.outputs[0], field_at_index_002.inputs[0])
	    #vector_math_2.Vector -> accumulate_field.Value
	    restore_curve_segment_length.links.new(vector_math_2.outputs[0], accumulate_field.inputs[0])
	    #curve_of_point_001.Index in Curve -> compare.A
	    restore_curve_segment_length.links.new(curve_of_point_001.outputs[1], compare.inputs[2])
	    #math_1.Value -> switch_1.False
	    restore_curve_segment_length.links.new(math_1.outputs[0], switch_1.inputs[1])
	    #compare.Result -> switch_1.Switch
	    restore_curve_segment_length.links.new(compare.outputs[0], switch_1.inputs[0])
	    #index_001_1.Index -> switch_1.True
	    restore_curve_segment_length.links.new(index_001_1.outputs[0], switch_1.inputs[2])
	    #reroute_006.Output -> switch_002.False
	    restore_curve_segment_length.links.new(reroute_006.outputs[0], switch_002.inputs[1])
	    #group_2.Root Position -> set_position_001_1.Position
	    restore_curve_segment_length.links.new(group_2.outputs[1], set_position_001_1.inputs[2])
	    #vector_math_004_1.Value -> mix.B
	    restore_curve_segment_length.links.new(vector_math_004_1.outputs[1], mix.inputs[3])
	    #mix.Result -> vector_math_2.Scale
	    restore_curve_segment_length.links.new(mix.outputs[0], vector_math_2.inputs[3])
	    #group_input_001_1.Factor -> mix.Factor
	    restore_curve_segment_length.links.new(group_input_001_1.outputs[2], mix.inputs[0])
	    #group_input_002_1.Factor -> compare_002.A
	    restore_curve_segment_length.links.new(group_input_002_1.outputs[2], compare_002.inputs[0])
	    #accumulate_field.Leading -> set_position_001_1.Offset
	    restore_curve_segment_length.links.new(accumulate_field.outputs[0], set_position_001_1.inputs[3])
	    #compare_002.Result -> boolean_math.Boolean
	    restore_curve_segment_length.links.new(compare_002.outputs[0], boolean_math.inputs[0])
	    #group_input_002_1.Selection -> boolean_math.Boolean
	    restore_curve_segment_length.links.new(group_input_002_1.outputs[1], boolean_math.inputs[1])
	    #reroute_005.Output -> reroute_004_1.Input
	    restore_curve_segment_length.links.new(reroute_005.outputs[0], reroute_004_1.inputs[0])
	    #reroute_012_1.Output -> sample_curve_001.Curves
	    restore_curve_segment_length.links.new(reroute_012_1.outputs[0], sample_curve_001.inputs[0])
	    #sample_curve_001.Position -> vector_math_006_1.Vector
	    restore_curve_segment_length.links.new(sample_curve_001.outputs[1], vector_math_006_1.inputs[1])
	    #sample_curve_001.Value -> vector_math_006_1.Vector
	    restore_curve_segment_length.links.new(sample_curve_001.outputs[0], vector_math_006_1.inputs[0])
	    #reroute_014_1.Output -> set_position_002.Geometry
	    restore_curve_segment_length.links.new(reroute_014_1.outputs[0], set_position_002.inputs[0])
	    #interpolate_domain_3.Value -> set_position_002.Offset
	    restore_curve_segment_length.links.new(interpolate_domain_3.outputs[0], set_position_002.inputs[3])
	    #index_1.Index -> sample_curve_001.Curve Index
	    restore_curve_segment_length.links.new(index_1.outputs[0], sample_curve_001.inputs[4])
	    #reroute_012_1.Output -> reroute_013_1.Input
	    restore_curve_segment_length.links.new(reroute_012_1.outputs[0], reroute_013_1.inputs[0])
	    #group_input_005_1.Selection -> boolean_math_002.Boolean
	    restore_curve_segment_length.links.new(group_input_005_1.outputs[1], boolean_math_002.inputs[1])
	    #compare_003.Result -> boolean_math_002.Boolean
	    restore_curve_segment_length.links.new(compare_003.outputs[0], boolean_math_002.inputs[0])
	    #reroute_011.Output -> reroute_005.Input
	    restore_curve_segment_length.links.new(reroute_011.outputs[0], reroute_005.inputs[0])
	    #group_input_003_1.Pin at Parameter -> sample_curve_001.Factor
	    restore_curve_segment_length.links.new(group_input_003_1.outputs[4], sample_curve_001.inputs[2])
	    #group_input_006_1.Pin at Parameter -> compare_003.A
	    restore_curve_segment_length.links.new(group_input_006_1.outputs[4], compare_003.inputs[0])
	    #reroute_006.Output -> compare_004.A
	    restore_curve_segment_length.links.new(reroute_006.outputs[0], compare_004.inputs[4])
	    #compare_004.Result -> switch_002.Switch
	    restore_curve_segment_length.links.new(compare_004.outputs[0], switch_002.inputs[0])
	    #named_attribute_1.Attribute -> switch_003_1.True
	    restore_curve_segment_length.links.new(named_attribute_1.outputs[0], switch_003_1.inputs[2])
	    #named_attribute_1.Exists -> switch_003_1.Switch
	    restore_curve_segment_length.links.new(named_attribute_1.outputs[1], switch_003_1.inputs[0])
	    #position_001.Position -> switch_003_1.False
	    restore_curve_segment_length.links.new(position_001.outputs[0], switch_003_1.inputs[1])
	    #switch_003_1.Output -> switch_002.True
	    restore_curve_segment_length.links.new(switch_003_1.outputs[0], switch_002.inputs[2])
	    #reroute_009.Output -> sample_curve_001.Value
	    restore_curve_segment_length.links.new(reroute_009.outputs[0], sample_curve_001.inputs[1])
	    #switch_002.Output -> reroute_007.Input
	    restore_curve_segment_length.links.new(switch_002.outputs[0], reroute_007.inputs[0])
	    #reroute_007.Output -> reroute_001_1.Input
	    restore_curve_segment_length.links.new(reroute_007.outputs[0], reroute_001_1.inputs[0])
	    #group_input_1.Reference Position -> reroute_006.Input
	    restore_curve_segment_length.links.new(group_input_1.outputs[3], reroute_006.inputs[0])
	    #reroute_007.Output -> reroute_008.Input
	    restore_curve_segment_length.links.new(reroute_007.outputs[0], reroute_008.inputs[0])
	    #reroute_008.Output -> reroute_009.Input
	    restore_curve_segment_length.links.new(reroute_008.outputs[0], reroute_009.inputs[0])
	    #group_input_1.Curves -> reroute_011.Input
	    restore_curve_segment_length.links.new(group_input_1.outputs[0], reroute_011.inputs[0])
	    #group_001_2.Segment Length -> mix.A
	    restore_curve_segment_length.links.new(group_001_2.outputs[0], mix.inputs[2])
	    #group_001_2.Segment Direction -> vector_math_2.Vector
	    restore_curve_segment_length.links.new(group_001_2.outputs[1], vector_math_2.inputs[0])
	    #vector_math_006_1.Vector -> interpolate_domain_3.Value
	    restore_curve_segment_length.links.new(vector_math_006_1.outputs[0], interpolate_domain_3.inputs[0])
	    #reroute_016_1.Output -> attribute_statistic.Attribute
	    restore_curve_segment_length.links.new(reroute_016_1.outputs[0], attribute_statistic.inputs[2])
	    #attribute_statistic.Max -> compare_005.A
	    restore_curve_segment_length.links.new(attribute_statistic.outputs[4], compare_005.inputs[0])
	    #set_position_002.Geometry -> switch_001_2.True
	    restore_curve_segment_length.links.new(set_position_002.outputs[0], switch_001_2.inputs[2])
	    #reroute_014_1.Output -> switch_001_2.False
	    restore_curve_segment_length.links.new(reroute_014_1.outputs[0], switch_001_2.inputs[1])
	    #reroute_016_1.Output -> set_position_002.Selection
	    restore_curve_segment_length.links.new(reroute_016_1.outputs[0], set_position_002.inputs[1])
	    #compare_005.Result -> switch_001_2.Switch
	    restore_curve_segment_length.links.new(compare_005.outputs[0], switch_001_2.inputs[0])
	    #reroute_014_1.Output -> attribute_statistic.Geometry
	    restore_curve_segment_length.links.new(reroute_014_1.outputs[0], attribute_statistic.inputs[0])
	    #boolean_math.Boolean -> set_position_001_1.Selection
	    restore_curve_segment_length.links.new(boolean_math.outputs[0], set_position_001_1.inputs[1])
	    #boolean_math_002.Boolean -> reroute_016_1.Input
	    restore_curve_segment_length.links.new(boolean_math_002.outputs[0], reroute_016_1.inputs[0])
	    #reroute_013_1.Output -> reroute_014_1.Input
	    restore_curve_segment_length.links.new(reroute_013_1.outputs[0], reroute_014_1.inputs[0])
	    #set_position_001_1.Geometry -> reroute_012_1.Input
	    restore_curve_segment_length.links.new(set_position_001_1.outputs[0], reroute_012_1.inputs[0])
	    #switch_001_2.Output -> group_output_5.Curves
	    restore_curve_segment_length.links.new(switch_001_2.outputs[0], group_output_5.inputs[0])
	    return restore_curve_segment_length
	
	restore_curve_segment_length = restore_curve_segment_length_node_group()
	
	#initialize create_guide_index_map node group
	def create_guide_index_map_node_group():
	    create_guide_index_map = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Create Guide Index Map")
	
	    create_guide_index_map.color_tag = 'ATTRIBUTE'
	    create_guide_index_map.description = "Creates an attribute that maps each curve to its nearest guide via index"
	    create_guide_index_map.default_group_node_width = 140
	    
	
	    create_guide_index_map.is_modifier = True
	
	    #create_guide_index_map interface
	    #Socket Geometry
	    geometry_socket_2 = create_guide_index_map.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_2.attribute_domain = 'POINT'
	
	    #Socket Guide Curves
	    guide_curves_socket = create_guide_index_map.interface.new_socket(name = "Guide Curves", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    guide_curves_socket.attribute_domain = 'POINT'
	
	    #Socket Guide Index
	    guide_index_socket_1 = create_guide_index_map.interface.new_socket(name = "Guide Index", in_out='OUTPUT', socket_type = 'NodeSocketInt')
	    guide_index_socket_1.default_value = 0
	    guide_index_socket_1.min_value = 0
	    guide_index_socket_1.max_value = 1
	    guide_index_socket_1.subtype = 'NONE'
	    guide_index_socket_1.attribute_domain = 'CURVE'
	
	    #Socket Guide Selection
	    guide_selection_socket = create_guide_index_map.interface.new_socket(name = "Guide Selection", in_out='OUTPUT', socket_type = 'NodeSocketBool')
	    guide_selection_socket.default_value = False
	    guide_selection_socket.attribute_domain = 'CURVE'
	
	    #Socket Geometry
	    geometry_socket_3 = create_guide_index_map.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_3.attribute_domain = 'POINT'
	
	    #Socket Guides
	    guides_socket = create_guide_index_map.interface.new_socket(name = "Guides", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    guides_socket.attribute_domain = 'POINT'
	    guides_socket.description = "Guide curves or points used for the selection of guide curves"
	
	    #Socket Guide Distance
	    guide_distance_socket = create_guide_index_map.interface.new_socket(name = "Guide Distance", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    guide_distance_socket.default_value = 0.0
	    guide_distance_socket.min_value = 0.0
	    guide_distance_socket.max_value = 3.4028234663852886e+38
	    guide_distance_socket.subtype = 'DISTANCE'
	    guide_distance_socket.attribute_domain = 'POINT'
	    guide_distance_socket.description = "Minimum distance between two guides"
	
	    #Socket Guide Mask
	    guide_mask_socket = create_guide_index_map.interface.new_socket(name = "Guide Mask", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    guide_mask_socket.default_value = 1.0
	    guide_mask_socket.min_value = 0.0
	    guide_mask_socket.max_value = 1.0
	    guide_mask_socket.subtype = 'NONE'
	    guide_mask_socket.attribute_domain = 'POINT'
	    guide_mask_socket.description = "Mask for which curves are eligible to be selected as guides"
	
	    #Socket Group ID
	    group_id_socket = create_guide_index_map.interface.new_socket(name = "Group ID", in_out='INPUT', socket_type = 'NodeSocketInt')
	    group_id_socket.default_value = 0
	    group_id_socket.min_value = -2147483648
	    group_id_socket.max_value = 2147483647
	    group_id_socket.subtype = 'NONE'
	    group_id_socket.attribute_domain = 'POINT'
	    group_id_socket.description = "ID to group curves together for guide map creation"
	
	
	    #initialize create_guide_index_map nodes
	    #node Frame.003
	    frame_003_1 = create_guide_index_map.nodes.new("NodeFrame")
	    frame_003_1.label = "Sample Guide Index"
	    frame_003_1.name = "Frame.003"
	    frame_003_1.label_size = 20
	    frame_003_1.shrink = True
	
	    #node Frame.004
	    frame_004_1 = create_guide_index_map.nodes.new("NodeFrame")
	    frame_004_1.label = "Isolate Guide Points"
	    frame_004_1.name = "Frame.004"
	    frame_004_1.label_size = 20
	    frame_004_1.shrink = True
	
	    #node Frame.006
	    frame_006 = create_guide_index_map.nodes.new("NodeFrame")
	    frame_006.label = "Input Guide Geometry Points"
	    frame_006.name = "Frame.006"
	    frame_006.label_size = 20
	    frame_006.shrink = True
	
	    #node Frame
	    frame_3 = create_guide_index_map.nodes.new("NodeFrame")
	    frame_3.label = "Ensure Data on Input Points"
	    frame_3.name = "Frame"
	    frame_3.label_size = 20
	    frame_3.shrink = True
	
	    #node Frame.007
	    frame_007 = create_guide_index_map.nodes.new("NodeFrame")
	    frame_007.label = "Switch Guide Input"
	    frame_007.name = "Frame.007"
	    frame_007.label_size = 20
	    frame_007.shrink = True
	
	    #node Frame.002
	    frame_002_2 = create_guide_index_map.nodes.new("NodeFrame")
	    frame_002_2.label = "Sample per Group ID"
	    frame_002_2.name = "Frame.002"
	    frame_002_2.label_size = 20
	    frame_002_2.shrink = True
	
	    #node Frame.005
	    frame_005 = create_guide_index_map.nodes.new("NodeFrame")
	    frame_005.label = "Optimization"
	    frame_005.name = "Frame.005"
	    frame_005.label_size = 20
	    frame_005.shrink = True
	
	    #node Reroute.019
	    reroute_019_1 = create_guide_index_map.nodes.new("NodeReroute")
	    reroute_019_1.name = "Reroute.019"
	    reroute_019_1.socket_idname = "NodeSocketGeometry"
	    #node Reroute.021
	    reroute_021 = create_guide_index_map.nodes.new("NodeReroute")
	    reroute_021.name = "Reroute.021"
	    reroute_021.socket_idname = "NodeSocketGeometry"
	    #node Reroute.022
	    reroute_022 = create_guide_index_map.nodes.new("NodeReroute")
	    reroute_022.name = "Reroute.022"
	    reroute_022.socket_idname = "NodeSocketGeometry"
	    #node Reroute.023
	    reroute_023 = create_guide_index_map.nodes.new("NodeReroute")
	    reroute_023.name = "Reroute.023"
	    reroute_023.socket_idname = "NodeSocketGeometry"
	    #node Reroute.001
	    reroute_001_2 = create_guide_index_map.nodes.new("NodeReroute")
	    reroute_001_2.name = "Reroute.001"
	    reroute_001_2.socket_idname = "NodeSocketGeometry"
	    #node Reroute
	    reroute_2 = create_guide_index_map.nodes.new("NodeReroute")
	    reroute_2.name = "Reroute"
	    reroute_2.socket_idname = "NodeSocketGeometry"
	    #node Set Position.002
	    set_position_002_1 = create_guide_index_map.nodes.new("GeometryNodeSetPosition")
	    set_position_002_1.name = "Set Position.002"
	    set_position_002_1.inputs[1].hide = True
	    set_position_002_1.inputs[2].hide = True
	    #Selection
	    set_position_002_1.inputs[1].default_value = True
	    #Position
	    set_position_002_1.inputs[2].default_value = (0.0, 0.0, 0.0)
	
	    #node Switch.002
	    switch_002_1 = create_guide_index_map.nodes.new("GeometryNodeSwitch")
	    switch_002_1.name = "Switch.002"
	    switch_002_1.input_type = 'GEOMETRY'
	
	    #node Set Position
	    set_position_1 = create_guide_index_map.nodes.new("GeometryNodeSetPosition")
	    set_position_1.name = "Set Position"
	    set_position_1.inputs[1].hide = True
	    set_position_1.inputs[2].hide = True
	    #Selection
	    set_position_1.inputs[1].default_value = True
	    #Position
	    set_position_1.inputs[2].default_value = (0.0, 0.0, 0.0)
	
	    #node Vector Math.003
	    vector_math_003_1 = create_guide_index_map.nodes.new("ShaderNodeVectorMath")
	    vector_math_003_1.name = "Vector Math.003"
	    vector_math_003_1.hide = True
	    vector_math_003_1.operation = 'SCALE'
	    #Vector
	    vector_math_003_1.inputs[0].default_value = (100.0, 100.0, 100.0)
	
	    #node Vector Math.004
	    vector_math_004_2 = create_guide_index_map.nodes.new("ShaderNodeVectorMath")
	    vector_math_004_2.name = "Vector Math.004"
	    vector_math_004_2.hide = True
	    vector_math_004_2.operation = 'SCALE'
	    #Scale
	    vector_math_004_2.inputs[3].default_value = -1.0
	
	    #node Merge by Distance
	    merge_by_distance = create_guide_index_map.nodes.new("GeometryNodeMergeByDistance")
	    merge_by_distance.name = "Merge by Distance"
	    merge_by_distance.hide = True
	    merge_by_distance.mode = 'ALL'
	
	    #node Merge by Distance.001
	    merge_by_distance_001 = create_guide_index_map.nodes.new("GeometryNodeMergeByDistance")
	    merge_by_distance_001.name = "Merge by Distance.001"
	    merge_by_distance_001.hide = True
	    merge_by_distance_001.mode = 'ALL'
	
	    #node Group Input.001
	    group_input_001_2 = create_guide_index_map.nodes.new("NodeGroupInput")
	    group_input_001_2.name = "Group Input.001"
	    group_input_001_2.outputs[0].hide = True
	    group_input_001_2.outputs[1].hide = True
	    group_input_001_2.outputs[3].hide = True
	    group_input_001_2.outputs[4].hide = True
	    group_input_001_2.outputs[5].hide = True
	
	    #node Reroute.026
	    reroute_026 = create_guide_index_map.nodes.new("NodeReroute")
	    reroute_026.name = "Reroute.026"
	    reroute_026.socket_idname = "NodeSocketFloatDistance"
	    #node Compare.004
	    compare_004_1 = create_guide_index_map.nodes.new("FunctionNodeCompare")
	    compare_004_1.name = "Compare.004"
	    compare_004_1.hide = True
	    compare_004_1.data_type = 'FLOAT'
	    compare_004_1.mode = 'ELEMENT'
	    compare_004_1.operation = 'GREATER_THAN'
	    #B
	    compare_004_1.inputs[1].default_value = 0.0
	
	    #node Reroute.015
	    reroute_015_2 = create_guide_index_map.nodes.new("NodeReroute")
	    reroute_015_2.name = "Reroute.015"
	    reroute_015_2.socket_idname = "NodeSocketGeometry"
	    #node Reroute.016
	    reroute_016_2 = create_guide_index_map.nodes.new("NodeReroute")
	    reroute_016_2.name = "Reroute.016"
	    reroute_016_2.socket_idname = "NodeSocketGeometry"
	    #node Reroute.013
	    reroute_013_2 = create_guide_index_map.nodes.new("NodeReroute")
	    reroute_013_2.name = "Reroute.013"
	    reroute_013_2.socket_idname = "NodeSocketGeometry"
	    #node Reroute.017
	    reroute_017_2 = create_guide_index_map.nodes.new("NodeReroute")
	    reroute_017_2.name = "Reroute.017"
	    reroute_017_2.socket_idname = "NodeSocketGeometry"
	    #node Group Input
	    group_input_2 = create_guide_index_map.nodes.new("NodeGroupInput")
	    group_input_2.name = "Group Input"
	    group_input_2.outputs[1].hide = True
	    group_input_2.outputs[2].hide = True
	    group_input_2.outputs[3].hide = True
	    group_input_2.outputs[4].hide = True
	    group_input_2.outputs[5].hide = True
	
	    #node Separate Components.001
	    separate_components_001 = create_guide_index_map.nodes.new("GeometryNodeSeparateComponents")
	    separate_components_001.name = "Separate Components.001"
	
	    #node Group Input.003
	    group_input_003_2 = create_guide_index_map.nodes.new("NodeGroupInput")
	    group_input_003_2.name = "Group Input.003"
	    group_input_003_2.outputs[0].hide = True
	    group_input_003_2.outputs[1].hide = True
	    group_input_003_2.outputs[2].hide = True
	    group_input_003_2.outputs[4].hide = True
	    group_input_003_2.outputs[5].hide = True
	
	    #node Capture Attribute.003
	    capture_attribute_003 = create_guide_index_map.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_003.name = "Capture Attribute.003"
	    capture_attribute_003.active_index = 0
	    capture_attribute_003.capture_items.clear()
	    capture_attribute_003.capture_items.new('FLOAT', "Value")
	    capture_attribute_003.capture_items["Value"].data_type = 'FLOAT'
	    capture_attribute_003.domain = 'CURVE'
	
	    #node Group Input.010
	    group_input_010 = create_guide_index_map.nodes.new("NodeGroupInput")
	    group_input_010.name = "Group Input.010"
	    group_input_010.outputs[0].hide = True
	    group_input_010.outputs[1].hide = True
	    group_input_010.outputs[2].hide = True
	    group_input_010.outputs[3].hide = True
	    group_input_010.outputs[5].hide = True
	
	    #node Capture Attribute.006
	    capture_attribute_006 = create_guide_index_map.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_006.name = "Capture Attribute.006"
	    capture_attribute_006.active_index = 0
	    capture_attribute_006.capture_items.clear()
	    capture_attribute_006.capture_items.new('FLOAT', "Value")
	    capture_attribute_006.capture_items["Value"].data_type = 'INT'
	    capture_attribute_006.domain = 'CURVE'
	
	    #node Reroute.005
	    reroute_005_1 = create_guide_index_map.nodes.new("NodeReroute")
	    reroute_005_1.name = "Reroute.005"
	    reroute_005_1.socket_idname = "NodeSocketGeometry"
	    #node Capture Attribute.001
	    capture_attribute_001_1 = create_guide_index_map.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_001_1.name = "Capture Attribute.001"
	    capture_attribute_001_1.active_index = 0
	    capture_attribute_001_1.capture_items.clear()
	    capture_attribute_001_1.capture_items.new('FLOAT', "Value")
	    capture_attribute_001_1.capture_items["Value"].data_type = 'INT'
	    capture_attribute_001_1.domain = 'CURVE'
	
	    #node Curve to Points
	    curve_to_points = create_guide_index_map.nodes.new("GeometryNodeCurveToPoints")
	    curve_to_points.name = "Curve to Points"
	    curve_to_points.mode = 'COUNT'
	    curve_to_points.inputs[2].hide = True
	    curve_to_points.outputs[1].hide = True
	    curve_to_points.outputs[2].hide = True
	    curve_to_points.outputs[3].hide = True
	    #Count
	    curve_to_points.inputs[1].default_value = 1
	
	    #node Index.001
	    index_001_2 = create_guide_index_map.nodes.new("GeometryNodeInputIndex")
	    index_001_2.name = "Index.001"
	
	    #node Reroute.014
	    reroute_014_2 = create_guide_index_map.nodes.new("NodeReroute")
	    reroute_014_2.name = "Reroute.014"
	    reroute_014_2.socket_idname = "NodeSocketGeometry"
	    #node Reroute.027
	    reroute_027 = create_guide_index_map.nodes.new("NodeReroute")
	    reroute_027.name = "Reroute.027"
	    reroute_027.socket_idname = "NodeSocketGeometry"
	    #node Reroute.007
	    reroute_007_1 = create_guide_index_map.nodes.new("NodeReroute")
	    reroute_007_1.name = "Reroute.007"
	    reroute_007_1.socket_idname = "NodeSocketGeometry"
	    #node Reroute.004
	    reroute_004_2 = create_guide_index_map.nodes.new("NodeReroute")
	    reroute_004_2.name = "Reroute.004"
	    reroute_004_2.socket_idname = "NodeSocketGeometry"
	    #node Curve to Points.001
	    curve_to_points_001 = create_guide_index_map.nodes.new("GeometryNodeCurveToPoints")
	    curve_to_points_001.name = "Curve to Points.001"
	    curve_to_points_001.mode = 'COUNT'
	    curve_to_points_001.inputs[2].hide = True
	    curve_to_points_001.outputs[1].hide = True
	    curve_to_points_001.outputs[2].hide = True
	    curve_to_points_001.outputs[3].hide = True
	    #Count
	    curve_to_points_001.inputs[1].default_value = 1
	
	    #node Group Input.004
	    group_input_004_1 = create_guide_index_map.nodes.new("NodeGroupInput")
	    group_input_004_1.name = "Group Input.004"
	    group_input_004_1.outputs[0].hide = True
	    group_input_004_1.outputs[2].hide = True
	    group_input_004_1.outputs[3].hide = True
	    group_input_004_1.outputs[4].hide = True
	    group_input_004_1.outputs[5].hide = True
	
	    #node Mesh to Points
	    mesh_to_points = create_guide_index_map.nodes.new("GeometryNodeMeshToPoints")
	    mesh_to_points.name = "Mesh to Points"
	    mesh_to_points.mode = 'VERTICES'
	    mesh_to_points.inputs[1].hide = True
	    mesh_to_points.inputs[2].hide = True
	    mesh_to_points.inputs[3].hide = True
	    #Selection
	    mesh_to_points.inputs[1].default_value = True
	    #Position
	    mesh_to_points.inputs[2].default_value = (0.0, 0.0, 0.0)
	    #Radius
	    mesh_to_points.inputs[3].default_value = 0.05000000074505806
	
	    #node Separate Components
	    separate_components_1 = create_guide_index_map.nodes.new("GeometryNodeSeparateComponents")
	    separate_components_1.name = "Separate Components"
	    separate_components_1.outputs[4].hide = True
	    separate_components_1.outputs[5].hide = True
	
	    #node Join Geometry
	    join_geometry_1 = create_guide_index_map.nodes.new("GeometryNodeJoinGeometry")
	    join_geometry_1.name = "Join Geometry"
	
	    #node Domain Size
	    domain_size = create_guide_index_map.nodes.new("GeometryNodeAttributeDomainSize")
	    domain_size.name = "Domain Size"
	    domain_size.hide = True
	    domain_size.component = 'POINTCLOUD'
	    domain_size.outputs[1].hide = True
	    domain_size.outputs[2].hide = True
	    domain_size.outputs[3].hide = True
	    domain_size.outputs[4].hide = True
	    domain_size.outputs[5].hide = True
	
	    #node Compare.003
	    compare_003_1 = create_guide_index_map.nodes.new("FunctionNodeCompare")
	    compare_003_1.name = "Compare.003"
	    compare_003_1.data_type = 'INT'
	    compare_003_1.mode = 'ELEMENT'
	    compare_003_1.operation = 'GREATER_THAN'
	    #B_INT
	    compare_003_1.inputs[3].default_value = 0
	
	    #node Group Input.008
	    group_input_008 = create_guide_index_map.nodes.new("NodeGroupInput")
	    group_input_008.name = "Group Input.008"
	    group_input_008.outputs[0].hide = True
	    group_input_008.outputs[1].hide = True
	    group_input_008.outputs[2].hide = True
	    group_input_008.outputs[4].hide = True
	    group_input_008.outputs[5].hide = True
	
	    #node Reroute.020
	    reroute_020_1 = create_guide_index_map.nodes.new("NodeReroute")
	    reroute_020_1.name = "Reroute.020"
	    reroute_020_1.socket_idname = "NodeSocketGeometry"
	    #node Sample Nearest.002
	    sample_nearest_002 = create_guide_index_map.nodes.new("GeometryNodeSampleNearest")
	    sample_nearest_002.name = "Sample Nearest.002"
	    sample_nearest_002.domain = 'POINT'
	    #Sample Position
	    sample_nearest_002.inputs[1].default_value = (0.0, 0.0, 0.0)
	
	    #node Sample Index.004
	    sample_index_004 = create_guide_index_map.nodes.new("GeometryNodeSampleIndex")
	    sample_index_004.name = "Sample Index.004"
	    sample_index_004.clamp = False
	    sample_index_004.data_type = 'INT'
	    sample_index_004.domain = 'POINT'
	
	    #node Group Input.009
	    group_input_009 = create_guide_index_map.nodes.new("NodeGroupInput")
	    group_input_009.name = "Group Input.009"
	    group_input_009.outputs[0].hide = True
	    group_input_009.outputs[1].hide = True
	    group_input_009.outputs[2].hide = True
	    group_input_009.outputs[3].hide = True
	    group_input_009.outputs[5].hide = True
	
	    #node Math.003
	    math_003 = create_guide_index_map.nodes.new("ShaderNodeMath")
	    math_003.name = "Math.003"
	    math_003.operation = 'ADD'
	    math_003.use_clamp = False
	
	    #node Capture Attribute.005
	    capture_attribute_005 = create_guide_index_map.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_005.name = "Capture Attribute.005"
	    capture_attribute_005.active_index = 0
	    capture_attribute_005.capture_items.clear()
	    capture_attribute_005.capture_items.new('FLOAT', "Value")
	    capture_attribute_005.capture_items["Value"].data_type = 'INT'
	    capture_attribute_005.domain = 'POINT'
	
	    #node Capture Attribute.004
	    capture_attribute_004 = create_guide_index_map.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_004.name = "Capture Attribute.004"
	    capture_attribute_004.active_index = 0
	    capture_attribute_004.capture_items.clear()
	    capture_attribute_004.capture_items.new('FLOAT', "Value")
	    capture_attribute_004.capture_items["Value"].data_type = 'FLOAT'
	    capture_attribute_004.domain = 'POINT'
	
	    #node Switch.003
	    switch_003_2 = create_guide_index_map.nodes.new("GeometryNodeSwitch")
	    switch_003_2.name = "Switch.003"
	    switch_003_2.input_type = 'FLOAT'
	
	    #node Reroute.024
	    reroute_024 = create_guide_index_map.nodes.new("NodeReroute")
	    reroute_024.name = "Reroute.024"
	    reroute_024.socket_idname = "NodeSocketBool"
	    #node Reroute.028
	    reroute_028 = create_guide_index_map.nodes.new("NodeReroute")
	    reroute_028.name = "Reroute.028"
	    reroute_028.socket_idname = "NodeSocketGeometry"
	    #node Compare.002
	    compare_002_1 = create_guide_index_map.nodes.new("FunctionNodeCompare")
	    compare_002_1.name = "Compare.002"
	    compare_002_1.data_type = 'FLOAT'
	    compare_002_1.mode = 'ELEMENT'
	    compare_002_1.operation = 'LESS_THAN'
	
	    #node Boolean Math
	    boolean_math_1 = create_guide_index_map.nodes.new("FunctionNodeBooleanMath")
	    boolean_math_1.name = "Boolean Math"
	    boolean_math_1.operation = 'NOT'
	
	    #node Random Value.001
	    random_value_001_1 = create_guide_index_map.nodes.new("FunctionNodeRandomValue")
	    random_value_001_1.name = "Random Value.001"
	    random_value_001_1.data_type = 'FLOAT'
	    #Min_001
	    random_value_001_1.inputs[2].default_value = 0.0
	    #Max_001
	    random_value_001_1.inputs[3].default_value = 1.0
	    #ID
	    random_value_001_1.inputs[7].default_value = 0
	    #Seed
	    random_value_001_1.inputs[8].default_value = 568746
	
	    #node Switch
	    switch_2 = create_guide_index_map.nodes.new("GeometryNodeSwitch")
	    switch_2.name = "Switch"
	    switch_2.input_type = 'GEOMETRY'
	
	    #node Delete Geometry.002
	    delete_geometry_002 = create_guide_index_map.nodes.new("GeometryNodeDeleteGeometry")
	    delete_geometry_002.name = "Delete Geometry.002"
	    delete_geometry_002.domain = 'POINT'
	    delete_geometry_002.mode = 'ALL'
	
	    #node Reroute.008
	    reroute_008_1 = create_guide_index_map.nodes.new("NodeReroute")
	    reroute_008_1.name = "Reroute.008"
	    reroute_008_1.socket_idname = "NodeSocketGeometry"
	    #node Position
	    position = create_guide_index_map.nodes.new("GeometryNodeInputPosition")
	    position.name = "Position"
	
	    #node Vector Math.002
	    vector_math_002_1 = create_guide_index_map.nodes.new("ShaderNodeVectorMath")
	    vector_math_002_1.name = "Vector Math.002"
	    vector_math_002_1.operation = 'ADD'
	
	    #node Vector Math.001
	    vector_math_001_2 = create_guide_index_map.nodes.new("ShaderNodeVectorMath")
	    vector_math_001_2.name = "Vector Math.001"
	    vector_math_001_2.operation = 'SCALE'
	    #Vector
	    vector_math_001_2.inputs[0].default_value = (100.0, 100.0, 100.0)
	
	    #node Set Position.001
	    set_position_001_2 = create_guide_index_map.nodes.new("GeometryNodeSetPosition")
	    set_position_001_2.name = "Set Position.001"
	    set_position_001_2.inputs[1].hide = True
	    set_position_001_2.inputs[2].hide = True
	    #Selection
	    set_position_001_2.inputs[1].default_value = True
	    #Position
	    set_position_001_2.inputs[2].default_value = (0.0, 0.0, 0.0)
	
	    #node Reroute.010
	    reroute_010 = create_guide_index_map.nodes.new("NodeReroute")
	    reroute_010.name = "Reroute.010"
	    reroute_010.hide = True
	    reroute_010.socket_idname = "NodeSocketGeometry"
	    #node Sample Nearest.007
	    sample_nearest_007 = create_guide_index_map.nodes.new("GeometryNodeSampleNearest")
	    sample_nearest_007.name = "Sample Nearest.007"
	    sample_nearest_007.domain = 'POINT'
	    sample_nearest_007.inputs[1].hide = True
	    #Sample Position
	    sample_nearest_007.inputs[1].default_value = (0.0, 0.0, 0.0)
	
	    #node Switch.001
	    switch_001_3 = create_guide_index_map.nodes.new("GeometryNodeSwitch")
	    switch_001_3.name = "Switch.001"
	    switch_001_3.input_type = 'INT'
	
	    #node Group Input.007
	    group_input_007_1 = create_guide_index_map.nodes.new("NodeGroupInput")
	    group_input_007_1.name = "Group Input.007"
	    group_input_007_1.outputs[0].hide = True
	    group_input_007_1.outputs[1].hide = True
	    group_input_007_1.outputs[2].hide = True
	    group_input_007_1.outputs[3].hide = True
	    group_input_007_1.outputs[5].hide = True
	
	    #node Math
	    math_2 = create_guide_index_map.nodes.new("ShaderNodeMath")
	    math_2.name = "Math"
	    math_2.hide = True
	    math_2.operation = 'SUBTRACT'
	    math_2.use_clamp = False
	
	    #node Math.001
	    math_001 = create_guide_index_map.nodes.new("ShaderNodeMath")
	    math_001.name = "Math.001"
	    math_001.hide = True
	    math_001.operation = 'ABSOLUTE'
	    math_001.use_clamp = False
	
	    #node Evaluate at Index
	    evaluate_at_index_2 = create_guide_index_map.nodes.new("GeometryNodeFieldAtIndex")
	    evaluate_at_index_2.name = "Evaluate at Index"
	    evaluate_at_index_2.hide = True
	    evaluate_at_index_2.data_type = 'INT'
	    evaluate_at_index_2.domain = 'POINT'
	    #Index
	    evaluate_at_index_2.inputs[0].default_value = 0
	
	    #node Accumulate Field.001
	    accumulate_field_001 = create_guide_index_map.nodes.new("GeometryNodeAccumulateField")
	    accumulate_field_001.name = "Accumulate Field.001"
	    accumulate_field_001.hide = True
	    accumulate_field_001.data_type = 'INT'
	    accumulate_field_001.domain = 'POINT'
	    accumulate_field_001.inputs[1].hide = True
	    accumulate_field_001.outputs[0].hide = True
	    accumulate_field_001.outputs[1].hide = True
	    #Value
	    accumulate_field_001.inputs[0].default_value = 1
	    #Group Index
	    accumulate_field_001.inputs[1].default_value = 0
	
	    #node Sample Index.003
	    sample_index_003 = create_guide_index_map.nodes.new("GeometryNodeSampleIndex")
	    sample_index_003.name = "Sample Index.003"
	    sample_index_003.hide = True
	    sample_index_003.clamp = False
	    sample_index_003.data_type = 'INT'
	    sample_index_003.domain = 'POINT'
	    #Index
	    sample_index_003.inputs[2].default_value = 0
	
	    #node Sample Nearest.001
	    sample_nearest_001 = create_guide_index_map.nodes.new("GeometryNodeSampleNearest")
	    sample_nearest_001.name = "Sample Nearest.001"
	    sample_nearest_001.domain = 'POINT'
	    #Sample Position
	    sample_nearest_001.inputs[1].default_value = (0.0, 0.0, 0.0)
	
	    #node Index
	    index_2 = create_guide_index_map.nodes.new("GeometryNodeInputIndex")
	    index_2.name = "Index"
	
	    #node Sample Index
	    sample_index = create_guide_index_map.nodes.new("GeometryNodeSampleIndex")
	    sample_index.name = "Sample Index"
	    sample_index.clamp = False
	    sample_index.data_type = 'INT'
	    sample_index.domain = 'POINT'
	
	    #node Sample Index.002
	    sample_index_002 = create_guide_index_map.nodes.new("GeometryNodeSampleIndex")
	    sample_index_002.name = "Sample Index.002"
	    sample_index_002.clamp = False
	    sample_index_002.data_type = 'INT'
	    sample_index_002.domain = 'POINT'
	
	    #node Reroute.018
	    reroute_018_2 = create_guide_index_map.nodes.new("NodeReroute")
	    reroute_018_2.name = "Reroute.018"
	    reroute_018_2.socket_idname = "NodeSocketGeometry"
	    #node Sample Nearest.005
	    sample_nearest_005 = create_guide_index_map.nodes.new("GeometryNodeSampleNearest")
	    sample_nearest_005.name = "Sample Nearest.005"
	    sample_nearest_005.domain = 'POINT'
	
	    #node Compare
	    compare_1 = create_guide_index_map.nodes.new("FunctionNodeCompare")
	    compare_1.name = "Compare"
	    compare_1.hide = True
	    compare_1.data_type = 'INT'
	    compare_1.mode = 'ELEMENT'
	    compare_1.operation = 'NOT_EQUAL'
	    #B_INT
	    compare_1.inputs[3].default_value = 0
	
	    #node Capture Attribute.002
	    capture_attribute_002_1 = create_guide_index_map.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_002_1.name = "Capture Attribute.002"
	    capture_attribute_002_1.active_index = 0
	    capture_attribute_002_1.capture_items.clear()
	    capture_attribute_002_1.capture_items.new('FLOAT', "Value")
	    capture_attribute_002_1.capture_items["Value"].data_type = 'BOOLEAN'
	    capture_attribute_002_1.domain = 'CURVE'
	
	    #node Compare.001
	    compare_001 = create_guide_index_map.nodes.new("FunctionNodeCompare")
	    compare_001.name = "Compare.001"
	    compare_001.hide = True
	    compare_001.data_type = 'INT'
	    compare_001.mode = 'ELEMENT'
	    compare_001.operation = 'EQUAL'
	
	    #node Index.002
	    index_002_1 = create_guide_index_map.nodes.new("GeometryNodeInputIndex")
	    index_002_1.name = "Index.002"
	
	    #node Reroute.011
	    reroute_011_1 = create_guide_index_map.nodes.new("NodeReroute")
	    reroute_011_1.name = "Reroute.011"
	    reroute_011_1.socket_idname = "NodeSocketInt"
	    #node Reroute.012
	    reroute_012_2 = create_guide_index_map.nodes.new("NodeReroute")
	    reroute_012_2.name = "Reroute.012"
	    reroute_012_2.socket_idname = "NodeSocketGeometry"
	    #node Join Geometry.001
	    join_geometry_001_1 = create_guide_index_map.nodes.new("GeometryNodeJoinGeometry")
	    join_geometry_001_1.name = "Join Geometry.001"
	
	    #node Reroute.003
	    reroute_003_1 = create_guide_index_map.nodes.new("NodeReroute")
	    reroute_003_1.name = "Reroute.003"
	    reroute_003_1.socket_idname = "NodeSocketBool"
	    #node Reroute.002
	    reroute_002_1 = create_guide_index_map.nodes.new("NodeReroute")
	    reroute_002_1.name = "Reroute.002"
	    reroute_002_1.socket_idname = "NodeSocketInt"
	    #node Reroute.009
	    reroute_009_1 = create_guide_index_map.nodes.new("NodeReroute")
	    reroute_009_1.name = "Reroute.009"
	    reroute_009_1.socket_idname = "NodeSocketGeometry"
	    #node Group Output
	    group_output_6 = create_guide_index_map.nodes.new("NodeGroupOutput")
	    group_output_6.name = "Group Output"
	    group_output_6.is_active_output = True
	
	    #node Reroute.006
	    reroute_006_1 = create_guide_index_map.nodes.new("NodeReroute")
	    reroute_006_1.name = "Reroute.006"
	    reroute_006_1.socket_idname = "NodeSocketBool"
	    #node Capture Attribute
	    capture_attribute_1 = create_guide_index_map.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_1.name = "Capture Attribute"
	    capture_attribute_1.active_index = 0
	    capture_attribute_1.capture_items.clear()
	    capture_attribute_1.capture_items.new('FLOAT', "Value")
	    capture_attribute_1.capture_items["Value"].data_type = 'INT'
	    capture_attribute_1.domain = 'CURVE'
	
	    #node Separate Geometry
	    separate_geometry = create_guide_index_map.nodes.new("GeometryNodeSeparateGeometry")
	    separate_geometry.name = "Separate Geometry"
	    separate_geometry.hide = True
	    separate_geometry.domain = 'CURVE'
	
	    #node Sample Index.001
	    sample_index_001 = create_guide_index_map.nodes.new("GeometryNodeSampleIndex")
	    sample_index_001.name = "Sample Index.001"
	    sample_index_001.clamp = False
	    sample_index_001.data_type = 'INT'
	    sample_index_001.domain = 'POINT'
	
	    #node Store Named Attribute
	    store_named_attribute_1 = create_guide_index_map.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_1.name = "Store Named Attribute"
	    store_named_attribute_1.data_type = 'INT'
	    store_named_attribute_1.domain = 'CURVE'
	    store_named_attribute_1.inputs[1].hide = True
	    #Selection
	    store_named_attribute_1.inputs[1].default_value = True
	    #Name
	    store_named_attribute_1.inputs[2].default_value = "guide_curve_index"
	
	
	
	
	    #Set parents
	    reroute_001_2.parent = frame_003_1
	    reroute_2.parent = frame_004_1
	    set_position_002_1.parent = frame_004_1
	    switch_002_1.parent = frame_004_1
	    set_position_1.parent = frame_004_1
	    vector_math_003_1.parent = frame_004_1
	    vector_math_004_2.parent = frame_004_1
	    merge_by_distance.parent = frame_004_1
	    merge_by_distance_001.parent = frame_004_1
	    group_input_001_2.parent = frame_004_1
	    reroute_026.parent = frame_004_1
	    compare_004_1.parent = frame_004_1
	    reroute_014_2.parent = frame_003_1
	    reroute_004_2.parent = frame_003_1
	    curve_to_points_001.parent = frame_006
	    group_input_004_1.parent = frame_006
	    mesh_to_points.parent = frame_006
	    separate_components_1.parent = frame_006
	    join_geometry_1.parent = frame_006
	    domain_size.parent = frame_3
	    compare_003_1.parent = frame_3
	    group_input_008.parent = frame_3
	    reroute_020_1.parent = frame_3
	    sample_nearest_002.parent = frame_3
	    sample_index_004.parent = frame_3
	    group_input_009.parent = frame_3
	    math_003.parent = frame_3
	    capture_attribute_005.parent = frame_3
	    capture_attribute_004.parent = frame_3
	    switch_003_2.parent = frame_3
	    reroute_024.parent = frame_3
	    compare_002_1.parent = frame_004_1
	    boolean_math_1.parent = frame_004_1
	    random_value_001_1.parent = frame_004_1
	    switch_2.parent = frame_007
	    delete_geometry_002.parent = frame_004_1
	    position.parent = frame_002_2
	    vector_math_002_1.parent = frame_002_2
	    vector_math_001_2.parent = frame_002_2
	    set_position_001_2.parent = frame_002_2
	    reroute_010.parent = frame_002_2
	    sample_nearest_007.parent = frame_002_2
	    switch_001_3.parent = frame_002_2
	    group_input_007_1.parent = frame_005
	    math_2.parent = frame_005
	    math_001.parent = frame_005
	    evaluate_at_index_2.parent = frame_005
	    accumulate_field_001.parent = frame_005
	    sample_index_003.parent = frame_005
	    sample_nearest_001.parent = frame_003_1
	    index_2.parent = frame_003_1
	    sample_index.parent = frame_003_1
	    sample_index_002.parent = frame_003_1
	    reroute_018_2.parent = frame_003_1
	    sample_nearest_005.parent = frame_002_2
	    compare_1.parent = frame_005
	    capture_attribute_1.parent = frame_003_1
	    sample_index_001.parent = frame_003_1
	
	    #Set locations
	    frame_003_1.location = (-2293.710693359375, 42.040008544921875)
	    frame_004_1.location = (-3951.840087890625, -432.68157958984375)
	    frame_006.location = (-6505.4404296875, -653.0)
	    frame_3.location = (-5614.56005859375, -572.3599853515625)
	    frame_007.location = (-4275.3603515625, -292.0400085449219)
	    frame_002_2.location = (-2708.64013671875, -711.5599975585938)
	    frame_005.location = (-3762.72021484375, -141.32003784179688)
	    reroute_019_1.location = (-467.51171875, 351.3953552246094)
	    reroute_021.location = (-467.51171875, 311.2093200683594)
	    reroute_022.location = (-467.51171875, 271.0232849121094)
	    reroute_023.location = (-467.51171875, 230.83718872070312)
	    reroute_001_2.location = (138.385009765625, -273.1235046386719)
	    reroute_2.location = (180.02880859375, -47.79998779296875)
	    set_position_002_1.location = (612.585693359375, -167.88531494140625)
	    switch_002_1.location = (793.4228515625, -67.420166015625)
	    set_position_1.location = (210.725341796875, -107.60626220703125)
	    vector_math_003_1.location = (29.887939453125, -167.88531494140625)
	    vector_math_004_2.location = (29.887939453125, -208.07135009765625)
	    merge_by_distance.location = (431.74853515625, -187.97833251953125)
	    merge_by_distance_001.location = (431.74853515625, -147.79229736328125)
	    group_input_001_2.location = (29.887939453125, -268.35040283203125)
	    reroute_026.location = (391.5625, -208.07135009765625)
	    compare_004_1.location = (230.818115234375, -288.44342041015625)
	    reroute_015_2.location = (-6535.60498046875, 311.2093200683594)
	    reroute_016_2.location = (-6535.60498046875, 271.0232849121094)
	    reroute_013_2.location = (-6535.60498046875, 230.83718872070312)
	    reroute_017_2.location = (-6535.60498046875, 351.3953552246094)
	    group_input_2.location = (-7299.1396484375, 29.906982421875)
	    separate_components_001.location = (-7078.1162109375, 130.37210083007812)
	    group_input_003_2.location = (-7017.837890625, -130.83721923828125)
	    capture_attribute_003.location = (-6837.0, 29.906982421875)
	    group_input_010.location = (-6837.0, -191.11627197265625)
	    capture_attribute_006.location = (-6615.97705078125, 29.906982421875)
	    reroute_005_1.location = (-6314.58154296875, -10.279083251953125)
	    capture_attribute_001_1.location = (-6194.0234375, -130.83721923828125)
	    curve_to_points.location = (-5993.09326171875, -30.372100830078125)
	    index_001_2.location = (-6354.767578125, -251.39535522460938)
	    reroute_014_2.location = (841.640869140625, -52.319091796875)
	    reroute_027.location = (-3569.653076171875, -70.55813598632812)
	    reroute_007_1.location = (-5731.8837890625, -70.55813598632812)
	    reroute_004_2.location = (37.919921875, -112.59814453125)
	    curve_to_points_001.location = (472.1611328125, -161.0)
	    group_input_004_1.location = (30.11474609375, -181.093017578125)
	    mesh_to_points.location = (472.1611328125, -40.44189453125)
	    separate_components_1.location = (231.044921875, -100.720947265625)
	    join_geometry_1.location = (673.09130859375, -80.6279296875)
	    domain_size.location = (30.3525390625, -100.2230224609375)
	    compare_003_1.location = (211.18994140625, -39.9439697265625)
	    group_input_008.location = (190.15966796875, -296.549560546875)
	    reroute_020_1.location = (485.28173828125, -359.29962158203125)
	    sample_nearest_002.location = (538.49072265625, -412.3084716796875)
	    sample_index_004.location = (734.728515625, -343.537841796875)
	    group_input_009.location = (314.84228515625, -402.6466064453125)
	    math_003.location = (1081.72216796875, -230.5653076171875)
	    capture_attribute_005.location = (912.61328125, -174.99285888671875)
	    capture_attribute_004.location = (385.00146484375, -201.4539794921875)
	    switch_003_2.location = (626.11767578125, -100.9888916015625)
	    reroute_024.location = (533.47265625, -80.0181884765625)
	    reroute_028.location = (-4506.20947265625, -70.55813598632812)
	    compare_002_1.location = (611.02587890625, -300.94635009765625)
	    boolean_math_1.location = (791.86328125, -300.94635009765625)
	    random_value_001_1.location = (430.188720703125, -321.03936767578125)
	    switch_2.location = (30.3603515625, -39.727447509765625)
	    delete_geometry_002.location = (1012.886474609375, -120.10919189453125)
	    reroute_008_1.location = (-1994.58154296875, -613.0697631835938)
	    position.location = (205.6083984375, -297.57098388671875)
	    vector_math_002_1.location = (381.41162109375, -260.79779052734375)
	    vector_math_001_2.location = (30.59375, -248.84320068359375)
	    set_position_001_2.location = (381.371826171875, -150.45135498046875)
	    reroute_010.location = (321.60107421875, -160.74139404296875)
	    sample_nearest_007.location = (381.880126953125, -60.27630615234375)
	    switch_001_3.location = (723.46142578125, -40.18328857421875)
	    group_input_007_1.location = (29.9111328125, -40.15869140625)
	    math_2.location = (391.58544921875, -60.251708984375)
	    math_001.location = (391.58544921875, -100.43780517578125)
	    evaluate_at_index_2.location = (210.748291015625, -60.251708984375)
	    accumulate_field_001.location = (391.58544921875, -140.62384033203125)
	    sample_index_003.location = (391.58544921875, -180.80987548828125)
	    sample_nearest_001.location = (198.6640625, -313.3095397949219)
	    index_2.location = (651.4078369140625, -448.8673400878906)
	    sample_index.location = (650.666748046875, -310.1585693359375)
	    sample_index_002.location = (379.501220703125, -212.84442138671875)
	    reroute_018_2.location = (620.6175537109375, -112.59814453125)
	    sample_nearest_005.location = (551.1494140625, -177.01324462890625)
	    compare_1.location = (391.58544921875, -220.99591064453125)
	    capture_attribute_002_1.location = (-723.348876953125, 20.0930233001709)
	    compare_001.location = (-723.348876953125, -180.83721923828125)
	    index_002_1.location = (-904.1860961914062, -180.83721923828125)
	    reroute_011_1.location = (-884.093017578125, -120.55814361572266)
	    reroute_012_2.location = (-884.093017578125, -80.3720932006836)
	    join_geometry_001_1.location = (-20.0930233001709, 100.46511840820312)
	    reroute_003_1.location = (-180.83721923828125, -180.83721923828125)
	    reroute_002_1.location = (-180.83721923828125, -140.6511688232422)
	    reroute_009_1.location = (-281.3023376464844, -20.0930233001709)
	    group_output_6.location = (200.93023681640625, 40.1860466003418)
	    reroute_006_1.location = (-522.4186401367188, -60.27907180786133)
	    capture_attribute_1.location = (1023.0167236328125, -39.658905029296875)
	    separate_geometry.location = (-241.1162872314453, -40.1860466003418)
	    sample_index_001.location = (850.5413818359375, -217.240478515625)
	    store_named_attribute_1.location = (-1063.311279296875, 23.636491775512695)
	
	    #Set dimensions
	    frame_003_1.width, frame_003_1.height = 1192.91064453125, 529.239990234375
	    frame_004_1.width, frame_004_1.height = 1183.52001953125, 518.198486328125
	    frame_006.width, frame_006.height = 843.68017578125, 316.1200256347656
	    frame_3.width, frame_3.height = 1251.68017578125, 539.800048828125
	    frame_007.width, frame_007.height = 200.48046875, 189.4000244140625
	    frame_002_2.width, frame_002_2.height = 893.60009765625, 462.0400695800781
	    frame_005.width, frame_005.height = 561.43994140625, 276.03997802734375
	    reroute_019_1.width, reroute_019_1.height = 100.0, 100.0
	    reroute_021.width, reroute_021.height = 100.0, 100.0
	    reroute_022.width, reroute_022.height = 100.0, 100.0
	    reroute_023.width, reroute_023.height = 100.0, 100.0
	    reroute_001_2.width, reroute_001_2.height = 100.0, 100.0
	    reroute_2.width, reroute_2.height = 100.0, 100.0
	    set_position_002_1.width, set_position_002_1.height = 140.0, 100.0
	    switch_002_1.width, switch_002_1.height = 140.0, 100.0
	    set_position_1.width, set_position_1.height = 140.0, 100.0
	    vector_math_003_1.width, vector_math_003_1.height = 140.0, 100.0
	    vector_math_004_2.width, vector_math_004_2.height = 140.0, 100.0
	    merge_by_distance.width, merge_by_distance.height = 140.0, 100.0
	    merge_by_distance_001.width, merge_by_distance_001.height = 140.0, 100.0
	    group_input_001_2.width, group_input_001_2.height = 140.0, 100.0
	    reroute_026.width, reroute_026.height = 100.0, 100.0
	    compare_004_1.width, compare_004_1.height = 140.0, 100.0
	    reroute_015_2.width, reroute_015_2.height = 100.0, 100.0
	    reroute_016_2.width, reroute_016_2.height = 100.0, 100.0
	    reroute_013_2.width, reroute_013_2.height = 100.0, 100.0
	    reroute_017_2.width, reroute_017_2.height = 100.0, 100.0
	    group_input_2.width, group_input_2.height = 140.0, 100.0
	    separate_components_001.width, separate_components_001.height = 140.0, 100.0
	    group_input_003_2.width, group_input_003_2.height = 140.0, 100.0
	    capture_attribute_003.width, capture_attribute_003.height = 140.0, 100.0
	    group_input_010.width, group_input_010.height = 140.0, 100.0
	    capture_attribute_006.width, capture_attribute_006.height = 140.0, 100.0
	    reroute_005_1.width, reroute_005_1.height = 100.0, 100.0
	    capture_attribute_001_1.width, capture_attribute_001_1.height = 140.0, 100.0
	    curve_to_points.width, curve_to_points.height = 140.0, 100.0
	    index_001_2.width, index_001_2.height = 140.0, 100.0
	    reroute_014_2.width, reroute_014_2.height = 100.0, 100.0
	    reroute_027.width, reroute_027.height = 100.0, 100.0
	    reroute_007_1.width, reroute_007_1.height = 100.0, 100.0
	    reroute_004_2.width, reroute_004_2.height = 100.0, 100.0
	    curve_to_points_001.width, curve_to_points_001.height = 140.0, 100.0
	    group_input_004_1.width, group_input_004_1.height = 140.0, 100.0
	    mesh_to_points.width, mesh_to_points.height = 140.0, 100.0
	    separate_components_1.width, separate_components_1.height = 140.0, 100.0
	    join_geometry_1.width, join_geometry_1.height = 140.0, 100.0
	    domain_size.width, domain_size.height = 140.0, 100.0
	    compare_003_1.width, compare_003_1.height = 140.0, 100.0
	    group_input_008.width, group_input_008.height = 140.0, 100.0
	    reroute_020_1.width, reroute_020_1.height = 100.0, 100.0
	    sample_nearest_002.width, sample_nearest_002.height = 140.0, 100.0
	    sample_index_004.width, sample_index_004.height = 140.0, 100.0
	    group_input_009.width, group_input_009.height = 140.0, 100.0
	    math_003.width, math_003.height = 140.0, 100.0
	    capture_attribute_005.width, capture_attribute_005.height = 140.0, 100.0
	    capture_attribute_004.width, capture_attribute_004.height = 140.0, 100.0
	    switch_003_2.width, switch_003_2.height = 140.0, 100.0
	    reroute_024.width, reroute_024.height = 100.0, 100.0
	    reroute_028.width, reroute_028.height = 100.0, 100.0
	    compare_002_1.width, compare_002_1.height = 140.0, 100.0
	    boolean_math_1.width, boolean_math_1.height = 140.0, 100.0
	    random_value_001_1.width, random_value_001_1.height = 140.0, 100.0
	    switch_2.width, switch_2.height = 140.0, 100.0
	    delete_geometry_002.width, delete_geometry_002.height = 140.0, 100.0
	    reroute_008_1.width, reroute_008_1.height = 100.0, 100.0
	    position.width, position.height = 140.0, 100.0
	    vector_math_002_1.width, vector_math_002_1.height = 140.0, 100.0
	    vector_math_001_2.width, vector_math_001_2.height = 140.0, 100.0
	    set_position_001_2.width, set_position_001_2.height = 140.0, 100.0
	    reroute_010.width, reroute_010.height = 100.0, 100.0
	    sample_nearest_007.width, sample_nearest_007.height = 140.0, 100.0
	    switch_001_3.width, switch_001_3.height = 140.0, 100.0
	    group_input_007_1.width, group_input_007_1.height = 140.0, 100.0
	    math_2.width, math_2.height = 140.0, 100.0
	    math_001.width, math_001.height = 140.0, 100.0
	    evaluate_at_index_2.width, evaluate_at_index_2.height = 140.0, 100.0
	    accumulate_field_001.width, accumulate_field_001.height = 140.0, 100.0
	    sample_index_003.width, sample_index_003.height = 140.0, 100.0
	    sample_nearest_001.width, sample_nearest_001.height = 140.0, 100.0
	    index_2.width, index_2.height = 140.0, 100.0
	    sample_index.width, sample_index.height = 140.0, 100.0
	    sample_index_002.width, sample_index_002.height = 140.0, 100.0
	    reroute_018_2.width, reroute_018_2.height = 100.0, 100.0
	    sample_nearest_005.width, sample_nearest_005.height = 140.0, 100.0
	    compare_1.width, compare_1.height = 140.0, 100.0
	    capture_attribute_002_1.width, capture_attribute_002_1.height = 140.0, 100.0
	    compare_001.width, compare_001.height = 140.0, 100.0
	    index_002_1.width, index_002_1.height = 140.0, 100.0
	    reroute_011_1.width, reroute_011_1.height = 100.0, 100.0
	    reroute_012_2.width, reroute_012_2.height = 100.0, 100.0
	    join_geometry_001_1.width, join_geometry_001_1.height = 140.0, 100.0
	    reroute_003_1.width, reroute_003_1.height = 100.0, 100.0
	    reroute_002_1.width, reroute_002_1.height = 100.0, 100.0
	    reroute_009_1.width, reroute_009_1.height = 100.0, 100.0
	    group_output_6.width, group_output_6.height = 140.0, 100.0
	    reroute_006_1.width, reroute_006_1.height = 100.0, 100.0
	    capture_attribute_1.width, capture_attribute_1.height = 140.0, 100.0
	    separate_geometry.width, separate_geometry.height = 140.0, 100.0
	    sample_index_001.width, sample_index_001.height = 140.0, 100.0
	    store_named_attribute_1.width, store_named_attribute_1.height = 140.0, 100.0
	
	    #initialize create_guide_index_map links
	    #reroute_002_1.Output -> group_output_6.Guide Index
	    create_guide_index_map.links.new(reroute_002_1.outputs[0], group_output_6.inputs[2])
	    #reroute_005_1.Output -> capture_attribute_001_1.Geometry
	    create_guide_index_map.links.new(reroute_005_1.outputs[0], capture_attribute_001_1.inputs[0])
	    #reroute_026.Output -> merge_by_distance.Distance
	    create_guide_index_map.links.new(reroute_026.outputs[0], merge_by_distance.inputs[2])
	    #reroute_018_2.Output -> sample_index_001.Geometry
	    create_guide_index_map.links.new(reroute_018_2.outputs[0], sample_index_001.inputs[0])
	    #sample_index_001.Value -> capture_attribute_1.Value
	    create_guide_index_map.links.new(sample_index_001.outputs[0], capture_attribute_1.inputs[1])
	    #reroute_008_1.Output -> sample_index.Geometry
	    create_guide_index_map.links.new(reroute_008_1.outputs[0], sample_index.inputs[0])
	    #index_001_2.Index -> capture_attribute_001_1.Value
	    create_guide_index_map.links.new(index_001_2.outputs[0], capture_attribute_001_1.inputs[1])
	    #index_2.Index -> sample_index_001.Index
	    create_guide_index_map.links.new(index_2.outputs[0], sample_index_001.inputs[2])
	    #reroute_014_2.Output -> capture_attribute_1.Geometry
	    create_guide_index_map.links.new(reroute_014_2.outputs[0], capture_attribute_1.inputs[0])
	    #reroute_001_2.Output -> sample_nearest_001.Geometry
	    create_guide_index_map.links.new(reroute_001_2.outputs[0], sample_nearest_001.inputs[0])
	    #reroute_001_2.Output -> sample_index_002.Geometry
	    create_guide_index_map.links.new(reroute_001_2.outputs[0], sample_index_002.inputs[0])
	    #sample_nearest_001.Index -> sample_index_002.Index
	    create_guide_index_map.links.new(sample_nearest_001.outputs[0], sample_index_002.inputs[2])
	    #reroute_011_1.Output -> compare_001.A
	    create_guide_index_map.links.new(reroute_011_1.outputs[0], compare_001.inputs[2])
	    #reroute_003_1.Output -> group_output_6.Guide Selection
	    create_guide_index_map.links.new(reroute_003_1.outputs[0], group_output_6.inputs[3])
	    #index_002_1.Index -> compare_001.B
	    create_guide_index_map.links.new(index_002_1.outputs[0], compare_001.inputs[3])
	    #reroute_011_1.Output -> reroute_002_1.Input
	    create_guide_index_map.links.new(reroute_011_1.outputs[0], reroute_002_1.inputs[0])
	    #reroute_006_1.Output -> reroute_003_1.Input
	    create_guide_index_map.links.new(reroute_006_1.outputs[0], reroute_003_1.inputs[0])
	    #reroute_027.Output -> reroute_004_2.Input
	    create_guide_index_map.links.new(reroute_027.outputs[0], reroute_004_2.inputs[0])
	    #curve_to_points.Points -> reroute_007_1.Input
	    create_guide_index_map.links.new(curve_to_points.outputs[0], reroute_007_1.inputs[0])
	    #delete_geometry_002.Geometry -> reroute_008_1.Input
	    create_guide_index_map.links.new(delete_geometry_002.outputs[0], reroute_008_1.inputs[0])
	    #capture_attribute_006.Geometry -> reroute_005_1.Input
	    create_guide_index_map.links.new(capture_attribute_006.outputs[0], reroute_005_1.inputs[0])
	    #reroute_009_1.Output -> separate_geometry.Geometry
	    create_guide_index_map.links.new(reroute_009_1.outputs[0], separate_geometry.inputs[0])
	    #reroute_006_1.Output -> separate_geometry.Selection
	    create_guide_index_map.links.new(reroute_006_1.outputs[0], separate_geometry.inputs[1])
	    #separate_geometry.Selection -> group_output_6.Guide Curves
	    create_guide_index_map.links.new(separate_geometry.outputs[0], group_output_6.inputs[1])
	    #capture_attribute_002_1.Geometry -> reroute_009_1.Input
	    create_guide_index_map.links.new(capture_attribute_002_1.outputs[0], reroute_009_1.inputs[0])
	    #reroute_012_2.Output -> capture_attribute_002_1.Geometry
	    create_guide_index_map.links.new(reroute_012_2.outputs[0], capture_attribute_002_1.inputs[0])
	    #compare_001.Result -> capture_attribute_002_1.Value
	    create_guide_index_map.links.new(compare_001.outputs[0], capture_attribute_002_1.inputs[1])
	    #capture_attribute_002_1.Value -> reroute_006_1.Input
	    create_guide_index_map.links.new(capture_attribute_002_1.outputs[1], reroute_006_1.inputs[0])
	    #random_value_001_1.Value -> compare_002_1.A
	    create_guide_index_map.links.new(random_value_001_1.outputs[1], compare_002_1.inputs[0])
	    #compare_002_1.Result -> boolean_math_1.Boolean
	    create_guide_index_map.links.new(compare_002_1.outputs[0], boolean_math_1.inputs[0])
	    #switch_002_1.Output -> delete_geometry_002.Geometry
	    create_guide_index_map.links.new(switch_002_1.outputs[0], delete_geometry_002.inputs[0])
	    #boolean_math_1.Boolean -> delete_geometry_002.Selection
	    create_guide_index_map.links.new(boolean_math_1.outputs[0], delete_geometry_002.inputs[1])
	    #group_input_003_2.Guide Mask -> capture_attribute_003.Value
	    create_guide_index_map.links.new(group_input_003_2.outputs[3], capture_attribute_003.inputs[1])
	    #reroute_010.Output -> set_position_001_2.Geometry
	    create_guide_index_map.links.new(reroute_010.outputs[0], set_position_001_2.inputs[0])
	    #vector_math_001_2.Vector -> set_position_001_2.Offset
	    create_guide_index_map.links.new(vector_math_001_2.outputs[0], set_position_001_2.inputs[3])
	    #set_position_001_2.Geometry -> sample_nearest_005.Geometry
	    create_guide_index_map.links.new(set_position_001_2.outputs[0], sample_nearest_005.inputs[0])
	    #reroute_010.Output -> sample_nearest_007.Geometry
	    create_guide_index_map.links.new(reroute_010.outputs[0], sample_nearest_007.inputs[0])
	    #vector_math_002_1.Vector -> sample_nearest_005.Sample Position
	    create_guide_index_map.links.new(vector_math_002_1.outputs[0], sample_nearest_005.inputs[1])
	    #position.Position -> vector_math_002_1.Vector
	    create_guide_index_map.links.new(position.outputs[0], vector_math_002_1.inputs[0])
	    #vector_math_001_2.Vector -> vector_math_002_1.Vector
	    create_guide_index_map.links.new(vector_math_001_2.outputs[0], vector_math_002_1.inputs[1])
	    #group_input_004_1.Guides -> separate_components_1.Geometry
	    create_guide_index_map.links.new(group_input_004_1.outputs[1], separate_components_1.inputs[0])
	    #separate_components_1.Mesh -> mesh_to_points.Mesh
	    create_guide_index_map.links.new(separate_components_1.outputs[0], mesh_to_points.inputs[0])
	    #curve_to_points_001.Points -> join_geometry_1.Geometry
	    create_guide_index_map.links.new(curve_to_points_001.outputs[0], join_geometry_1.inputs[0])
	    #capture_attribute_1.Value -> reroute_011_1.Input
	    create_guide_index_map.links.new(capture_attribute_1.outputs[1], reroute_011_1.inputs[0])
	    #domain_size.Point Count -> compare_003_1.A
	    create_guide_index_map.links.new(domain_size.outputs[0], compare_003_1.inputs[2])
	    #store_named_attribute_1.Geometry -> reroute_012_2.Input
	    create_guide_index_map.links.new(store_named_attribute_1.outputs[0], reroute_012_2.inputs[0])
	    #sample_nearest_005.Index -> switch_001_3.True
	    create_guide_index_map.links.new(sample_nearest_005.outputs[0], switch_001_3.inputs[2])
	    #sample_nearest_007.Index -> switch_001_3.False
	    create_guide_index_map.links.new(sample_nearest_007.outputs[0], switch_001_3.inputs[1])
	    #switch_001_3.Output -> sample_index.Index
	    create_guide_index_map.links.new(switch_001_3.outputs[0], sample_index.inputs[2])
	    #reroute_023.Output -> join_geometry_001_1.Geometry
	    create_guide_index_map.links.new(reroute_023.outputs[0], join_geometry_001_1.inputs[0])
	    #separate_components_001.Mesh -> reroute_017_2.Input
	    create_guide_index_map.links.new(separate_components_001.outputs[0], reroute_017_2.inputs[0])
	    #separate_components_001.Instances -> reroute_013_2.Input
	    create_guide_index_map.links.new(separate_components_001.outputs[5], reroute_013_2.inputs[0])
	    #separate_components_001.Point Cloud -> reroute_015_2.Input
	    create_guide_index_map.links.new(separate_components_001.outputs[3], reroute_015_2.inputs[0])
	    #separate_components_001.Volume -> reroute_016_2.Input
	    create_guide_index_map.links.new(separate_components_001.outputs[4], reroute_016_2.inputs[0])
	    #reroute_017_2.Output -> reroute_019_1.Input
	    create_guide_index_map.links.new(reroute_017_2.outputs[0], reroute_019_1.inputs[0])
	    #reroute_015_2.Output -> reroute_021.Input
	    create_guide_index_map.links.new(reroute_015_2.outputs[0], reroute_021.inputs[0])
	    #reroute_013_2.Output -> reroute_023.Input
	    create_guide_index_map.links.new(reroute_013_2.outputs[0], reroute_023.inputs[0])
	    #reroute_016_2.Output -> reroute_022.Input
	    create_guide_index_map.links.new(reroute_016_2.outputs[0], reroute_022.inputs[0])
	    #join_geometry_001_1.Geometry -> group_output_6.Geometry
	    create_guide_index_map.links.new(join_geometry_001_1.outputs[0], group_output_6.inputs[0])
	    #separate_components_001.Curve -> capture_attribute_003.Geometry
	    create_guide_index_map.links.new(separate_components_001.outputs[1], capture_attribute_003.inputs[0])
	    #group_input_2.Geometry -> separate_components_001.Geometry
	    create_guide_index_map.links.new(group_input_2.outputs[0], separate_components_001.inputs[0])
	    #reroute_004_2.Output -> reroute_001_2.Input
	    create_guide_index_map.links.new(reroute_004_2.outputs[0], reroute_001_2.inputs[0])
	    #reroute_005_1.Output -> reroute_014_2.Input
	    create_guide_index_map.links.new(reroute_005_1.outputs[0], reroute_014_2.inputs[0])
	    #reroute_004_2.Output -> reroute_018_2.Input
	    create_guide_index_map.links.new(reroute_004_2.outputs[0], reroute_018_2.inputs[0])
	    #separate_components_1.Curve -> curve_to_points_001.Curve
	    create_guide_index_map.links.new(separate_components_1.outputs[1], curve_to_points_001.inputs[0])
	    #capture_attribute_001_1.Geometry -> curve_to_points.Curve
	    create_guide_index_map.links.new(capture_attribute_001_1.outputs[0], curve_to_points.inputs[0])
	    #set_position_1.Geometry -> merge_by_distance.Geometry
	    create_guide_index_map.links.new(set_position_1.outputs[0], merge_by_distance.inputs[0])
	    #reroute_2.Output -> set_position_1.Geometry
	    create_guide_index_map.links.new(reroute_2.outputs[0], set_position_1.inputs[0])
	    #vector_math_003_1.Vector -> set_position_1.Offset
	    create_guide_index_map.links.new(vector_math_003_1.outputs[0], set_position_1.inputs[3])
	    #merge_by_distance.Geometry -> set_position_002_1.Geometry
	    create_guide_index_map.links.new(merge_by_distance.outputs[0], set_position_002_1.inputs[0])
	    #vector_math_003_1.Vector -> vector_math_004_2.Vector
	    create_guide_index_map.links.new(vector_math_003_1.outputs[0], vector_math_004_2.inputs[0])
	    #vector_math_004_2.Vector -> set_position_002_1.Offset
	    create_guide_index_map.links.new(vector_math_004_2.outputs[0], set_position_002_1.inputs[3])
	    #group_input_007_1.Group ID -> math_2.Value
	    create_guide_index_map.links.new(group_input_007_1.outputs[4], math_2.inputs[0])
	    #group_input_007_1.Group ID -> evaluate_at_index_2.Value
	    create_guide_index_map.links.new(group_input_007_1.outputs[4], evaluate_at_index_2.inputs[1])
	    #reroute_027.Output -> sample_index_003.Geometry
	    create_guide_index_map.links.new(reroute_027.outputs[0], sample_index_003.inputs[0])
	    #evaluate_at_index_2.Value -> math_2.Value
	    create_guide_index_map.links.new(evaluate_at_index_2.outputs[0], math_2.inputs[1])
	    #accumulate_field_001.Total -> sample_index_003.Value
	    create_guide_index_map.links.new(accumulate_field_001.outputs[2], sample_index_003.inputs[1])
	    #math_2.Value -> math_001.Value
	    create_guide_index_map.links.new(math_2.outputs[0], math_001.inputs[0])
	    #sample_index_003.Value -> compare_1.A
	    create_guide_index_map.links.new(sample_index_003.outputs[0], compare_1.inputs[2])
	    #compare_1.Result -> switch_001_3.Switch
	    create_guide_index_map.links.new(compare_1.outputs[0], switch_001_3.inputs[0])
	    #set_position_002_1.Geometry -> switch_002_1.True
	    create_guide_index_map.links.new(set_position_002_1.outputs[0], switch_002_1.inputs[2])
	    #compare_1.Result -> switch_002_1.Switch
	    create_guide_index_map.links.new(compare_1.outputs[0], switch_002_1.inputs[0])
	    #reroute_2.Output -> merge_by_distance_001.Geometry
	    create_guide_index_map.links.new(reroute_2.outputs[0], merge_by_distance_001.inputs[0])
	    #switch_2.Output -> reroute_2.Input
	    create_guide_index_map.links.new(switch_2.outputs[0], reroute_2.inputs[0])
	    #merge_by_distance_001.Geometry -> switch_002_1.False
	    create_guide_index_map.links.new(merge_by_distance_001.outputs[0], switch_002_1.inputs[1])
	    #reroute_026.Output -> merge_by_distance_001.Distance
	    create_guide_index_map.links.new(reroute_026.outputs[0], merge_by_distance_001.inputs[2])
	    #sample_index.Value -> sample_index_001.Value
	    create_guide_index_map.links.new(sample_index.outputs[0], sample_index_001.inputs[1])
	    #capture_attribute_001_1.Value -> sample_index_002.Value
	    create_guide_index_map.links.new(capture_attribute_001_1.outputs[1], sample_index_002.inputs[1])
	    #sample_index_002.Value -> sample_index.Value
	    create_guide_index_map.links.new(sample_index_002.outputs[0], sample_index.inputs[1])
	    #delete_geometry_002.Geometry -> reroute_010.Input
	    create_guide_index_map.links.new(delete_geometry_002.outputs[0], reroute_010.inputs[0])
	    #join_geometry_1.Geometry -> domain_size.Geometry
	    create_guide_index_map.links.new(join_geometry_1.outputs[0], domain_size.inputs[0])
	    #join_geometry_1.Geometry -> capture_attribute_004.Geometry
	    create_guide_index_map.links.new(join_geometry_1.outputs[0], capture_attribute_004.inputs[0])
	    #capture_attribute_003.Value -> switch_003_2.False
	    create_guide_index_map.links.new(capture_attribute_003.outputs[1], switch_003_2.inputs[1])
	    #capture_attribute_004.Value -> switch_003_2.True
	    create_guide_index_map.links.new(capture_attribute_004.outputs[1], switch_003_2.inputs[2])
	    #switch_003_2.Output -> compare_002_1.B
	    create_guide_index_map.links.new(switch_003_2.outputs[0], compare_002_1.inputs[1])
	    #reroute_024.Output -> switch_003_2.Switch
	    create_guide_index_map.links.new(reroute_024.outputs[0], switch_003_2.inputs[0])
	    #compare_003_1.Result -> reroute_024.Input
	    create_guide_index_map.links.new(compare_003_1.outputs[0], reroute_024.inputs[0])
	    #group_input_008.Guide Mask -> capture_attribute_004.Value
	    create_guide_index_map.links.new(group_input_008.outputs[3], capture_attribute_004.inputs[1])
	    #group_input_001_2.Guide Distance -> compare_004_1.A
	    create_guide_index_map.links.new(group_input_001_2.outputs[2], compare_004_1.inputs[0])
	    #compare_004_1.Result -> merge_by_distance.Selection
	    create_guide_index_map.links.new(compare_004_1.outputs[0], merge_by_distance.inputs[1])
	    #compare_004_1.Result -> merge_by_distance_001.Selection
	    create_guide_index_map.links.new(compare_004_1.outputs[0], merge_by_distance_001.inputs[1])
	    #group_input_001_2.Guide Distance -> reroute_026.Input
	    create_guide_index_map.links.new(group_input_001_2.outputs[2], reroute_026.inputs[0])
	    #reroute_020_1.Output -> sample_nearest_002.Geometry
	    create_guide_index_map.links.new(reroute_020_1.outputs[0], sample_nearest_002.inputs[0])
	    #reroute_007_1.Output -> reroute_020_1.Input
	    create_guide_index_map.links.new(reroute_007_1.outputs[0], reroute_020_1.inputs[0])
	    #reroute_020_1.Output -> sample_index_004.Geometry
	    create_guide_index_map.links.new(reroute_020_1.outputs[0], sample_index_004.inputs[0])
	    #sample_nearest_002.Index -> sample_index_004.Index
	    create_guide_index_map.links.new(sample_nearest_002.outputs[0], sample_index_004.inputs[2])
	    #group_input_009.Group ID -> sample_index_004.Value
	    create_guide_index_map.links.new(group_input_009.outputs[4], sample_index_004.inputs[1])
	    #capture_attribute_004.Geometry -> capture_attribute_005.Geometry
	    create_guide_index_map.links.new(capture_attribute_004.outputs[0], capture_attribute_005.inputs[0])
	    #sample_index_004.Value -> capture_attribute_005.Value
	    create_guide_index_map.links.new(sample_index_004.outputs[0], capture_attribute_005.inputs[1])
	    #capture_attribute_003.Geometry -> capture_attribute_006.Geometry
	    create_guide_index_map.links.new(capture_attribute_003.outputs[0], capture_attribute_006.inputs[0])
	    #group_input_010.Group ID -> capture_attribute_006.Value
	    create_guide_index_map.links.new(group_input_010.outputs[4], capture_attribute_006.inputs[1])
	    #capture_attribute_005.Value -> math_003.Value
	    create_guide_index_map.links.new(capture_attribute_005.outputs[1], math_003.inputs[0])
	    #capture_attribute_006.Value -> math_003.Value
	    create_guide_index_map.links.new(capture_attribute_006.outputs[1], math_003.inputs[1])
	    #math_003.Value -> vector_math_003_1.Scale
	    create_guide_index_map.links.new(math_003.outputs[0], vector_math_003_1.inputs[3])
	    #math_003.Value -> vector_math_001_2.Scale
	    create_guide_index_map.links.new(math_003.outputs[0], vector_math_001_2.inputs[3])
	    #reroute_028.Output -> switch_2.False
	    create_guide_index_map.links.new(reroute_028.outputs[0], switch_2.inputs[1])
	    #reroute_024.Output -> switch_2.Switch
	    create_guide_index_map.links.new(reroute_024.outputs[0], switch_2.inputs[0])
	    #capture_attribute_005.Geometry -> switch_2.True
	    create_guide_index_map.links.new(capture_attribute_005.outputs[0], switch_2.inputs[2])
	    #reroute_028.Output -> reroute_027.Input
	    create_guide_index_map.links.new(reroute_028.outputs[0], reroute_027.inputs[0])
	    #reroute_007_1.Output -> reroute_028.Input
	    create_guide_index_map.links.new(reroute_007_1.outputs[0], reroute_028.inputs[0])
	    #capture_attribute_1.Geometry -> store_named_attribute_1.Geometry
	    create_guide_index_map.links.new(capture_attribute_1.outputs[0], store_named_attribute_1.inputs[0])
	    #capture_attribute_1.Value -> store_named_attribute_1.Value
	    create_guide_index_map.links.new(capture_attribute_1.outputs[1], store_named_attribute_1.inputs[3])
	    #separate_components_1.Point Cloud -> join_geometry_1.Geometry
	    create_guide_index_map.links.new(separate_components_1.outputs[3], join_geometry_1.inputs[0])
	    #reroute_022.Output -> join_geometry_001_1.Geometry
	    create_guide_index_map.links.new(reroute_022.outputs[0], join_geometry_001_1.inputs[0])
	    #mesh_to_points.Points -> join_geometry_1.Geometry
	    create_guide_index_map.links.new(mesh_to_points.outputs[0], join_geometry_1.inputs[0])
	    #reroute_009_1.Output -> join_geometry_001_1.Geometry
	    create_guide_index_map.links.new(reroute_009_1.outputs[0], join_geometry_001_1.inputs[0])
	    #reroute_021.Output -> join_geometry_001_1.Geometry
	    create_guide_index_map.links.new(reroute_021.outputs[0], join_geometry_001_1.inputs[0])
	    #reroute_019_1.Output -> join_geometry_001_1.Geometry
	    create_guide_index_map.links.new(reroute_019_1.outputs[0], join_geometry_001_1.inputs[0])
	    return create_guide_index_map
	
	create_guide_index_map = create_guide_index_map_node_group()
	
	#initialize shape_range node group
	def shape_range_node_group():
	    shape_range = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "shape_range")
	
	    shape_range.color_tag = 'CONVERTER'
	    shape_range.description = ""
	    shape_range.default_group_node_width = 140
	    
	
	
	    #shape_range interface
	    #Socket Value
	    value_socket = shape_range.interface.new_socket(name = "Value", in_out='OUTPUT', socket_type = 'NodeSocketFloat')
	    value_socket.default_value = 0.0
	    value_socket.min_value = -3.4028234663852886e+38
	    value_socket.max_value = 3.4028234663852886e+38
	    value_socket.subtype = 'NONE'
	    value_socket.attribute_domain = 'POINT'
	
	    #Socket Value
	    value_socket_1 = shape_range.interface.new_socket(name = "Value", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    value_socket_1.default_value = 0.0
	    value_socket_1.min_value = 0.0
	    value_socket_1.max_value = 1.0
	    value_socket_1.subtype = 'NONE'
	    value_socket_1.attribute_domain = 'POINT'
	    value_socket_1.hide_value = True
	
	    #Socket Min
	    min_socket = shape_range.interface.new_socket(name = "Min", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    min_socket.default_value = 0.0
	    min_socket.min_value = -10000.0
	    min_socket.max_value = 10000.0
	    min_socket.subtype = 'NONE'
	    min_socket.attribute_domain = 'POINT'
	    min_socket.description = "rdghrhd"
	
	    #Socket Max
	    max_socket = shape_range.interface.new_socket(name = "Max", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    max_socket.default_value = 1.0
	    max_socket.min_value = -10000.0
	    max_socket.max_value = 10000.0
	    max_socket.subtype = 'NONE'
	    max_socket.attribute_domain = 'POINT'
	
	    #Socket Shape
	    shape_socket = shape_range.interface.new_socket(name = "Shape", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    shape_socket.default_value = 0.0
	    shape_socket.min_value = -1.0
	    shape_socket.max_value = 1.0
	    shape_socket.subtype = 'NONE'
	    shape_socket.attribute_domain = 'POINT'
	
	    #Socket Base
	    base_socket = shape_range.interface.new_socket(name = "Base", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    base_socket.default_value = 2.0
	    base_socket.min_value = 1.0
	    base_socket.max_value = 10000.0
	    base_socket.subtype = 'NONE'
	    base_socket.attribute_domain = 'POINT'
	
	
	    #initialize shape_range nodes
	    #node Switch.001
	    switch_001_4 = shape_range.nodes.new("GeometryNodeSwitch")
	    switch_001_4.name = "Switch.001"
	    switch_001_4.hide = True
	    switch_001_4.input_type = 'FLOAT'
	
	    #node Math.016
	    math_016 = shape_range.nodes.new("ShaderNodeMath")
	    math_016.name = "Math.016"
	    math_016.hide = True
	    math_016.operation = 'SUBTRACT'
	    math_016.use_clamp = False
	    #Value
	    math_016.inputs[0].default_value = 1.0
	
	    #node Math.004
	    math_004 = shape_range.nodes.new("ShaderNodeMath")
	    math_004.name = "Math.004"
	    math_004.hide = True
	    math_004.operation = 'SUBTRACT'
	    math_004.use_clamp = False
	    #Value
	    math_004.inputs[0].default_value = 1.0
	
	    #node Reroute
	    reroute_3 = shape_range.nodes.new("NodeReroute")
	    reroute_3.name = "Reroute"
	    reroute_3.socket_idname = "NodeSocketFloat"
	    #node Map Range
	    map_range = shape_range.nodes.new("ShaderNodeMapRange")
	    map_range.name = "Map Range"
	    map_range.hide = True
	    map_range.clamp = False
	    map_range.data_type = 'FLOAT'
	    map_range.interpolation_type = 'LINEAR'
	    map_range.inputs[3].hide = True
	    map_range.inputs[4].hide = True
	    map_range.inputs[5].hide = True
	    map_range.inputs[6].hide = True
	    map_range.inputs[7].hide = True
	    map_range.inputs[8].hide = True
	    map_range.inputs[9].hide = True
	    map_range.inputs[10].hide = True
	    map_range.inputs[11].hide = True
	    map_range.outputs[1].hide = True
	    #To Min
	    map_range.inputs[3].default_value = 0.0
	    #To Max
	    map_range.inputs[4].default_value = 1.0
	
	    #node Math.001
	    math_001_1 = shape_range.nodes.new("ShaderNodeMath")
	    math_001_1.name = "Math.001"
	    math_001_1.hide = True
	    math_001_1.operation = 'DIVIDE'
	    math_001_1.use_clamp = False
	    #Value
	    math_001_1.inputs[0].default_value = 1.0
	
	    #node Math.012
	    math_012 = shape_range.nodes.new("ShaderNodeMath")
	    math_012.name = "Math.012"
	    math_012.hide = True
	    math_012.operation = 'SUBTRACT'
	    math_012.use_clamp = False
	    #Value
	    math_012.inputs[0].default_value = 1.0
	
	    #node Math.013
	    math_013 = shape_range.nodes.new("ShaderNodeMath")
	    math_013.name = "Math.013"
	    math_013.hide = True
	    math_013.operation = 'MULTIPLY'
	    math_013.use_clamp = False
	    #Value_001
	    math_013.inputs[1].default_value = 2.0
	
	    #node Math
	    math_3 = shape_range.nodes.new("ShaderNodeMath")
	    math_3.name = "Math"
	    math_3.hide = True
	    math_3.operation = 'MULTIPLY'
	    math_3.use_clamp = False
	
	    #node Reroute.001
	    reroute_001_3 = shape_range.nodes.new("NodeReroute")
	    reroute_001_3.name = "Reroute.001"
	    reroute_001_3.socket_idname = "NodeSocketFloat"
	    #node Compare.004
	    compare_004_2 = shape_range.nodes.new("FunctionNodeCompare")
	    compare_004_2.name = "Compare.004"
	    compare_004_2.hide = True
	    compare_004_2.data_type = 'FLOAT'
	    compare_004_2.mode = 'ELEMENT'
	    compare_004_2.operation = 'LESS_THAN'
	    #B
	    compare_004_2.inputs[1].default_value = 0.0
	
	    #node Compare
	    compare_2 = shape_range.nodes.new("FunctionNodeCompare")
	    compare_2.name = "Compare"
	    compare_2.hide = True
	    compare_2.data_type = 'FLOAT'
	    compare_2.mode = 'ELEMENT'
	    compare_2.operation = 'GREATER_THAN'
	    #B
	    compare_2.inputs[1].default_value = 0.5
	
	    #node Boolean Math.002
	    boolean_math_002_1 = shape_range.nodes.new("FunctionNodeBooleanMath")
	    boolean_math_002_1.name = "Boolean Math.002"
	    boolean_math_002_1.hide = True
	    boolean_math_002_1.operation = 'NOT'
	
	    #node Switch
	    switch_3 = shape_range.nodes.new("GeometryNodeSwitch")
	    switch_3.name = "Switch"
	    switch_3.hide = True
	    switch_3.input_type = 'BOOLEAN'
	
	    #node Math.014
	    math_014 = shape_range.nodes.new("ShaderNodeMath")
	    math_014.name = "Math.014"
	    math_014.hide = True
	    math_014.operation = 'MAXIMUM'
	    math_014.use_clamp = False
	    #Value_001
	    math_014.inputs[1].default_value = 1.0000100135803223
	
	    #node Math.006
	    math_006 = shape_range.nodes.new("ShaderNodeMath")
	    math_006.name = "Math.006"
	    math_006.hide = True
	    math_006.operation = 'MULTIPLY'
	    math_006.use_clamp = False
	    #Value_001
	    math_006.inputs[1].default_value = -1.0
	
	    #node Math.007
	    math_007 = shape_range.nodes.new("ShaderNodeMath")
	    math_007.name = "Math.007"
	    math_007.hide = True
	    math_007.operation = 'SUBTRACT'
	    math_007.use_clamp = False
	    #Value
	    math_007.inputs[0].default_value = 1.0
	
	    #node Math.010
	    math_010 = shape_range.nodes.new("ShaderNodeMath")
	    math_010.name = "Math.010"
	    math_010.hide = True
	    math_010.operation = 'MAXIMUM'
	    math_010.use_clamp = False
	    #Value_001
	    math_010.inputs[1].default_value = 1.0000009536743164
	
	    #node Math.009
	    math_009 = shape_range.nodes.new("ShaderNodeMath")
	    math_009.name = "Math.009"
	    math_009.hide = True
	    math_009.operation = 'MAXIMUM'
	    math_009.use_clamp = False
	    #Value_001
	    math_009.inputs[1].default_value = 9.999999747378752e-06
	
	    #node Math.002
	    math_002 = shape_range.nodes.new("ShaderNodeMath")
	    math_002.name = "Math.002"
	    math_002.operation = 'POWER'
	    math_002.use_clamp = False
	
	    #node Math.005
	    math_005 = shape_range.nodes.new("ShaderNodeMath")
	    math_005.name = "Math.005"
	    math_005.hide = True
	    math_005.operation = 'LOGARITHM'
	    math_005.use_clamp = False
	
	    #node Math.015
	    math_015 = shape_range.nodes.new("ShaderNodeMath")
	    math_015.name = "Math.015"
	    math_015.hide = True
	    math_015.operation = 'PINGPONG'
	    math_015.use_clamp = False
	    #Value_001
	    math_015.inputs[1].default_value = 0.5
	
	    #node Math.017
	    math_017 = shape_range.nodes.new("ShaderNodeMath")
	    math_017.name = "Math.017"
	    math_017.operation = 'MINIMUM'
	    math_017.use_clamp = False
	    #Value_001
	    math_017.inputs[1].default_value = 0.9999989867210388
	
	    #node Math.003
	    math_003_1 = shape_range.nodes.new("ShaderNodeMath")
	    math_003_1.name = "Math.003"
	    math_003_1.operation = 'ABSOLUTE'
	    math_003_1.use_clamp = False
	
	    #node Map Range.001
	    map_range_001 = shape_range.nodes.new("ShaderNodeMapRange")
	    map_range_001.name = "Map Range.001"
	    map_range_001.clamp = True
	    map_range_001.data_type = 'FLOAT'
	    map_range_001.interpolation_type = 'LINEAR'
	    map_range_001.inputs[1].hide = True
	    map_range_001.inputs[2].hide = True
	    map_range_001.inputs[5].hide = True
	    map_range_001.inputs[6].hide = True
	    map_range_001.inputs[7].hide = True
	    map_range_001.inputs[8].hide = True
	    map_range_001.inputs[9].hide = True
	    map_range_001.inputs[10].hide = True
	    map_range_001.inputs[11].hide = True
	    map_range_001.outputs[1].hide = True
	    #From Min
	    map_range_001.inputs[1].default_value = 0.0
	    #From Max
	    map_range_001.inputs[2].default_value = 1.0
	
	    #node Group Input
	    group_input_3 = shape_range.nodes.new("NodeGroupInput")
	    group_input_3.name = "Group Input"
	
	    #node Group Output
	    group_output_7 = shape_range.nodes.new("NodeGroupOutput")
	    group_output_7.name = "Group Output"
	    group_output_7.is_active_output = True
	
	    #node Switch.002
	    switch_002_2 = shape_range.nodes.new("GeometryNodeSwitch")
	    switch_002_2.name = "Switch.002"
	    switch_002_2.hide = True
	    switch_002_2.input_type = 'FLOAT'
	
	    #node Switch.003
	    switch_003_3 = shape_range.nodes.new("GeometryNodeSwitch")
	    switch_003_3.name = "Switch.003"
	    switch_003_3.input_type = 'FLOAT'
	    #True
	    switch_003_3.inputs[2].default_value = 1.0
	
	    #node Compare.001
	    compare_001_1 = shape_range.nodes.new("FunctionNodeCompare")
	    compare_001_1.name = "Compare.001"
	    compare_001_1.data_type = 'FLOAT'
	    compare_001_1.mode = 'ELEMENT'
	    compare_001_1.operation = 'EQUAL'
	    #B
	    compare_001_1.inputs[1].default_value = 0.0
	    #Epsilon
	    compare_001_1.inputs[12].default_value = 9.999999747378752e-06
	
	
	
	
	
	    #Set locations
	    switch_001_4.location = (-1034.40283203125, 93.75666046142578)
	    math_016.location = (-632.5424194335938, 53.57061004638672)
	    math_004.location = (-1295.6121826171875, 133.94271850585938)
	    reroute_3.location = (-1315.7052001953125, 93.75666046142578)
	    map_range.location = (-1516.635498046875, 73.66363525390625)
	    math_001_1.location = (-1858.2169189453125, -147.359619140625)
	    math_012.location = (-1858.2169189453125, -107.17357635498047)
	    math_013.location = (-1858.2169189453125, -66.9875259399414)
	    math_3.location = (-1858.2169189453125, -26.801475524902344)
	    reroute_001_3.location = (-2119.42626953125, -147.359619140625)
	    compare_004_2.location = (-1637.193603515625, -66.9875259399414)
	    compare_2.location = (-1637.193603515625, -107.17357635498047)
	    boolean_math_002_1.location = (-1456.3564453125, -107.17357635498047)
	    switch_3.location = (-1456.3564453125, -66.9875259399414)
	    math_014.location = (-2059.14697265625, -107.17357635498047)
	    math_006.location = (-1034.40283203125, -87.0805435180664)
	    math_007.location = (-1034.40283203125, 33.47759246826172)
	    math_010.location = (-1195.1470947265625, -107.17357635498047)
	    math_009.location = (-1034.40283203125, -6.708457946777344)
	    math_002.location = (-833.47265625, 113.84968566894531)
	    math_005.location = (-1034.40283203125, -46.894508361816406)
	    math_015.location = (-2059.14697265625, -147.359619140625)
	    math_017.location = (-2280.17041015625, -127.26660919189453)
	    math_003_1.location = (-2461.007568359375, -127.26660919189453)
	    map_range_001.location = (-411.5191650390625, 53.57061004638672)
	    group_input_3.location = (-2682.03076171875, 13.384567260742188)
	    group_output_7.location = (75.0, 50.0)
	    switch_002_2.location = (-632.5424194335938, 93.75666046142578)
	    switch_003_3.location = (-164.938232421875, 110.71707153320312)
	    compare_001_1.location = (-828.0901489257812, 397.66241455078125)
	
	    #Set dimensions
	    switch_001_4.width, switch_001_4.height = 140.0, 100.0
	    math_016.width, math_016.height = 140.0, 100.0
	    math_004.width, math_004.height = 140.0, 100.0
	    reroute_3.width, reroute_3.height = 100.0, 100.0
	    map_range.width, map_range.height = 140.0, 100.0
	    math_001_1.width, math_001_1.height = 140.0, 100.0
	    math_012.width, math_012.height = 140.0, 100.0
	    math_013.width, math_013.height = 140.0, 100.0
	    math_3.width, math_3.height = 140.0, 100.0
	    reroute_001_3.width, reroute_001_3.height = 100.0, 100.0
	    compare_004_2.width, compare_004_2.height = 140.0, 100.0
	    compare_2.width, compare_2.height = 140.0, 100.0
	    boolean_math_002_1.width, boolean_math_002_1.height = 140.0, 100.0
	    switch_3.width, switch_3.height = 140.0, 100.0
	    math_014.width, math_014.height = 140.0, 100.0
	    math_006.width, math_006.height = 140.0, 100.0
	    math_007.width, math_007.height = 140.0, 100.0
	    math_010.width, math_010.height = 140.0, 100.0
	    math_009.width, math_009.height = 140.0, 100.0
	    math_002.width, math_002.height = 140.0, 100.0
	    math_005.width, math_005.height = 140.0, 100.0
	    math_015.width, math_015.height = 140.0, 100.0
	    math_017.width, math_017.height = 140.0, 100.0
	    math_003_1.width, math_003_1.height = 140.0, 100.0
	    map_range_001.width, map_range_001.height = 140.0, 100.0
	    group_input_3.width, group_input_3.height = 140.0, 100.0
	    group_output_7.width, group_output_7.height = 140.0, 100.0
	    switch_002_2.width, switch_002_2.height = 140.0, 100.0
	    switch_003_3.width, switch_003_3.height = 140.0, 100.0
	    compare_001_1.width, compare_001_1.height = 140.0, 100.0
	
	    #initialize shape_range links
	    #math_009.Value -> math_005.Value
	    shape_range.links.new(math_009.outputs[0], math_005.inputs[0])
	    #math_005.Value -> math_006.Value
	    shape_range.links.new(math_005.outputs[0], math_006.inputs[0])
	    #math_004.Value -> switch_001_4.True
	    shape_range.links.new(math_004.outputs[0], switch_001_4.inputs[2])
	    #math_3.Value -> math_007.Value
	    shape_range.links.new(math_3.outputs[0], math_007.inputs[1])
	    #switch_001_4.Output -> math_002.Value
	    shape_range.links.new(switch_001_4.outputs[0], math_002.inputs[0])
	    #reroute_3.Output -> math_004.Value
	    shape_range.links.new(reroute_3.outputs[0], math_004.inputs[1])
	    #math_006.Value -> math_002.Value
	    shape_range.links.new(math_006.outputs[0], math_002.inputs[1])
	    #reroute_3.Output -> switch_001_4.False
	    shape_range.links.new(reroute_3.outputs[0], switch_001_4.inputs[1])
	    #math_010.Value -> math_005.Value
	    shape_range.links.new(math_010.outputs[0], math_005.inputs[1])
	    #map_range.Result -> reroute_3.Input
	    shape_range.links.new(map_range.outputs[0], reroute_3.inputs[0])
	    #group_input_3.Value -> map_range.Value
	    shape_range.links.new(group_input_3.outputs[0], map_range.inputs[0])
	    #group_input_3.Min -> map_range.From Min
	    shape_range.links.new(group_input_3.outputs[1], map_range.inputs[1])
	    #group_input_3.Max -> map_range.From Max
	    shape_range.links.new(group_input_3.outputs[2], map_range.inputs[2])
	    #switch_002_2.Output -> map_range_001.Value
	    shape_range.links.new(switch_002_2.outputs[0], map_range_001.inputs[0])
	    #group_input_3.Min -> map_range_001.To Min
	    shape_range.links.new(group_input_3.outputs[1], map_range_001.inputs[3])
	    #group_input_3.Max -> map_range_001.To Max
	    shape_range.links.new(group_input_3.outputs[2], map_range_001.inputs[4])
	    #math_007.Value -> math_009.Value
	    shape_range.links.new(math_007.outputs[0], math_009.inputs[0])
	    #math_014.Value -> math_010.Value
	    shape_range.links.new(math_014.outputs[0], math_010.inputs[0])
	    #switch_003_3.Output -> group_output_7.Value
	    shape_range.links.new(switch_003_3.outputs[0], group_output_7.inputs[0])
	    #math_013.Value -> math_3.Value
	    shape_range.links.new(math_013.outputs[0], math_3.inputs[1])
	    #math_001_1.Value -> math_012.Value
	    shape_range.links.new(math_001_1.outputs[0], math_012.inputs[1])
	    #math_014.Value -> math_001_1.Value
	    shape_range.links.new(math_014.outputs[0], math_001_1.inputs[1])
	    #math_012.Value -> math_013.Value
	    shape_range.links.new(math_012.outputs[0], math_013.inputs[0])
	    #group_input_3.Base -> math_014.Value
	    shape_range.links.new(group_input_3.outputs[4], math_014.inputs[0])
	    #math_015.Value -> math_3.Value
	    shape_range.links.new(math_015.outputs[0], math_3.inputs[0])
	    #reroute_001_3.Output -> math_015.Value
	    shape_range.links.new(reroute_001_3.outputs[0], math_015.inputs[0])
	    #switch_3.Output -> switch_001_4.Switch
	    shape_range.links.new(switch_3.outputs[0], switch_001_4.inputs[0])
	    #reroute_001_3.Output -> compare_2.A
	    shape_range.links.new(reroute_001_3.outputs[0], compare_2.inputs[0])
	    #math_002.Value -> switch_002_2.False
	    shape_range.links.new(math_002.outputs[0], switch_002_2.inputs[1])
	    #math_016.Value -> switch_002_2.True
	    shape_range.links.new(math_016.outputs[0], switch_002_2.inputs[2])
	    #compare_2.Result -> switch_002_2.Switch
	    shape_range.links.new(compare_2.outputs[0], switch_002_2.inputs[0])
	    #math_002.Value -> math_016.Value
	    shape_range.links.new(math_002.outputs[0], math_016.inputs[1])
	    #group_input_3.Shape -> compare_004_2.A
	    shape_range.links.new(group_input_3.outputs[3], compare_004_2.inputs[0])
	    #math_017.Value -> reroute_001_3.Input
	    shape_range.links.new(math_017.outputs[0], reroute_001_3.inputs[0])
	    #group_input_3.Shape -> math_003_1.Value
	    shape_range.links.new(group_input_3.outputs[3], math_003_1.inputs[0])
	    #compare_004_2.Result -> boolean_math_002_1.Boolean
	    shape_range.links.new(compare_004_2.outputs[0], boolean_math_002_1.inputs[0])
	    #compare_2.Result -> switch_3.Switch
	    shape_range.links.new(compare_2.outputs[0], switch_3.inputs[0])
	    #compare_004_2.Result -> switch_3.False
	    shape_range.links.new(compare_004_2.outputs[0], switch_3.inputs[1])
	    #boolean_math_002_1.Boolean -> switch_3.True
	    shape_range.links.new(boolean_math_002_1.outputs[0], switch_3.inputs[2])
	    #math_003_1.Value -> math_017.Value
	    shape_range.links.new(math_003_1.outputs[0], math_017.inputs[0])
	    #group_input_3.Shape -> compare_001_1.A
	    shape_range.links.new(group_input_3.outputs[3], compare_001_1.inputs[0])
	    #map_range_001.Result -> switch_003_3.False
	    shape_range.links.new(map_range_001.outputs[0], switch_003_3.inputs[1])
	    #compare_001_1.Result -> switch_003_3.Switch
	    shape_range.links.new(compare_001_1.outputs[0], switch_003_3.inputs[0])
	    return shape_range
	
	shape_range = shape_range_node_group()
	
	#initialize clump_hair_curves node group
	def clump_hair_curves_node_group():
	    clump_hair_curves = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Clump Hair Curves")
	
	    clump_hair_curves.color_tag = 'GEOMETRY'
	    clump_hair_curves.description = "Clumps together existing hair curves using guide curves"
	    clump_hair_curves.default_group_node_width = 140
	    
	
	    clump_hair_curves.is_modifier = True
	
	    #clump_hair_curves interface
	    #Socket Geometry
	    geometry_socket_4 = clump_hair_curves.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_4.attribute_domain = 'POINT'
	
	    #Socket Guide Index
	    guide_index_socket_2 = clump_hair_curves.interface.new_socket(name = "Guide Index", in_out='OUTPUT', socket_type = 'NodeSocketInt')
	    guide_index_socket_2.default_value = 0
	    guide_index_socket_2.min_value = -2147483648
	    guide_index_socket_2.max_value = 2147483647
	    guide_index_socket_2.subtype = 'NONE'
	    guide_index_socket_2.attribute_domain = 'CURVE'
	    guide_index_socket_2.description = "Guide index map that was used for the operation"
	
	    #Socket Geometry
	    geometry_socket_5 = clump_hair_curves.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_5.attribute_domain = 'POINT'
	    geometry_socket_5.description = "Input Geometry (May include other than curves)"
	
	    #Socket Guide Index
	    guide_index_socket_3 = clump_hair_curves.interface.new_socket(name = "Guide Index", in_out='INPUT', socket_type = 'NodeSocketInt')
	    guide_index_socket_3.default_value = -987654
	    guide_index_socket_3.min_value = -2147483648
	    guide_index_socket_3.max_value = 2147483647
	    guide_index_socket_3.subtype = 'NONE'
	    guide_index_socket_3.attribute_domain = 'POINT'
	    guide_index_socket_3.hide_value = True
	    guide_index_socket_3.hide_in_modifier = True
	    guide_index_socket_3.description = "Guide index map to be used. This input has priority"
	
	    #Socket Guide Distance
	    guide_distance_socket_1 = clump_hair_curves.interface.new_socket(name = "Guide Distance", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    guide_distance_socket_1.default_value = 0.10000000149011612
	    guide_distance_socket_1.min_value = 0.0
	    guide_distance_socket_1.max_value = 3.4028234663852886e+38
	    guide_distance_socket_1.subtype = 'DISTANCE'
	    guide_distance_socket_1.attribute_domain = 'POINT'
	    guide_distance_socket_1.description = "Minimum distance between two guides for new guide map"
	
	    #Socket Guide Mask
	    guide_mask_socket_1 = clump_hair_curves.interface.new_socket(name = "Guide Mask", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    guide_mask_socket_1.default_value = 1.0
	    guide_mask_socket_1.min_value = 0.0
	    guide_mask_socket_1.max_value = 1.0
	    guide_mask_socket_1.subtype = 'NONE'
	    guide_mask_socket_1.attribute_domain = 'POINT'
	    guide_mask_socket_1.description = "Mask for which curves are eligible to be selected as guides"
	
	    #Socket Existing Guide Map
	    existing_guide_map_socket = clump_hair_curves.interface.new_socket(name = "Existing Guide Map", in_out='INPUT', socket_type = 'NodeSocketBool')
	    existing_guide_map_socket.default_value = True
	    existing_guide_map_socket.attribute_domain = 'POINT'
	    existing_guide_map_socket.description = "Use the existing guide map attribute if available"
	
	    #Socket Factor
	    factor_socket_1 = clump_hair_curves.interface.new_socket(name = "Factor", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    factor_socket_1.default_value = 1.0
	    factor_socket_1.min_value = 0.0
	    factor_socket_1.max_value = 1.0
	    factor_socket_1.subtype = 'FACTOR'
	    factor_socket_1.attribute_domain = 'POINT'
	    factor_socket_1.description = "Factor to blend overall effect"
	
	    #Socket Shape
	    shape_socket_1 = clump_hair_curves.interface.new_socket(name = "Shape", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    shape_socket_1.default_value = 0.5
	    shape_socket_1.min_value = -1.0
	    shape_socket_1.max_value = 1.0
	    shape_socket_1.subtype = 'NONE'
	    shape_socket_1.attribute_domain = 'POINT'
	    shape_socket_1.description = "Shape of the influence along curves (0=constant, 0.5=linear)"
	
	    #Socket Tip Spread
	    tip_spread_socket = clump_hair_curves.interface.new_socket(name = "Tip Spread", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    tip_spread_socket.default_value = 0.0
	    tip_spread_socket.min_value = 0.0
	    tip_spread_socket.max_value = 10.0
	    tip_spread_socket.subtype = 'NONE'
	    tip_spread_socket.attribute_domain = 'POINT'
	    tip_spread_socket.description = "Distance of random spread at the curve tips"
	
	    #Socket Clump Offset
	    clump_offset_socket = clump_hair_curves.interface.new_socket(name = "Clump Offset", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    clump_offset_socket.default_value = 0.0
	    clump_offset_socket.min_value = -3.4028234663852886e+38
	    clump_offset_socket.max_value = 3.4028234663852886e+38
	    clump_offset_socket.subtype = 'DISTANCE'
	    clump_offset_socket.attribute_domain = 'POINT'
	    clump_offset_socket.description = "Offset of each clump in a random direction"
	
	    #Socket Distance Falloff
	    distance_falloff_socket = clump_hair_curves.interface.new_socket(name = "Distance Falloff", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    distance_falloff_socket.default_value = 0.0
	    distance_falloff_socket.min_value = 0.0
	    distance_falloff_socket.max_value = 3.4028234663852886e+38
	    distance_falloff_socket.subtype = 'DISTANCE'
	    distance_falloff_socket.attribute_domain = 'POINT'
	    distance_falloff_socket.description = "Falloff distance for the clumping effect (0 means no falloff)"
	
	    #Socket Distance Threshold
	    distance_threshold_socket = clump_hair_curves.interface.new_socket(name = "Distance Threshold", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    distance_threshold_socket.default_value = 0.0
	    distance_threshold_socket.min_value = 0.0
	    distance_threshold_socket.max_value = 3.4028234663852886e+38
	    distance_threshold_socket.subtype = 'DISTANCE'
	    distance_threshold_socket.attribute_domain = 'POINT'
	    distance_threshold_socket.description = "Distance threshold for the falloff around the guide"
	
	    #Socket Seed
	    seed_socket_1 = clump_hair_curves.interface.new_socket(name = "Seed", in_out='INPUT', socket_type = 'NodeSocketInt')
	    seed_socket_1.default_value = 0
	    seed_socket_1.min_value = -10000
	    seed_socket_1.max_value = 10000
	    seed_socket_1.subtype = 'NONE'
	    seed_socket_1.attribute_domain = 'POINT'
	    seed_socket_1.description = "Random seed for the operation"
	
	    #Socket Preserve Length
	    preserve_length_socket = clump_hair_curves.interface.new_socket(name = "Preserve Length", in_out='INPUT', socket_type = 'NodeSocketBool')
	    preserve_length_socket.default_value = False
	    preserve_length_socket.attribute_domain = 'POINT'
	    preserve_length_socket.description = "Preserve each curve's length during deformation"
	
	
	    #initialize clump_hair_curves nodes
	    #node Frame.001
	    frame_001_2 = clump_hair_curves.nodes.new("NodeFrame")
	    frame_001_2.label = "Optimization"
	    frame_001_2.name = "Frame.001"
	    frame_001_2.label_size = 20
	    frame_001_2.shrink = True
	
	    #node Frame
	    frame_4 = clump_hair_curves.nodes.new("NodeFrame")
	    frame_4.label = "Optimization"
	    frame_4.name = "Frame"
	    frame_4.label_size = 20
	    frame_4.shrink = True
	
	    #node Frame.003
	    frame_003_2 = clump_hair_curves.nodes.new("NodeFrame")
	    frame_003_2.label = "Length Preservation"
	    frame_003_2.name = "Frame.003"
	    frame_003_2.label_size = 20
	    frame_003_2.shrink = True
	
	    #node Frame.005
	    frame_005_1 = clump_hair_curves.nodes.new("NodeFrame")
	    frame_005_1.name = "Frame.005"
	    frame_005_1.label_size = 20
	    frame_005_1.shrink = True
	
	    #node Frame.006
	    frame_006_1 = clump_hair_curves.nodes.new("NodeFrame")
	    frame_006_1.label = "Displacement"
	    frame_006_1.name = "Frame.006"
	    frame_006_1.label_size = 20
	    frame_006_1.shrink = True
	
	    #node Frame.007
	    frame_007_1 = clump_hair_curves.nodes.new("NodeFrame")
	    frame_007_1.label = "Guide Map Fallback"
	    frame_007_1.name = "Frame.007"
	    frame_007_1.label_size = 20
	    frame_007_1.shrink = True
	
	    #node Frame.002
	    frame_002_3 = clump_hair_curves.nodes.new("NodeFrame")
	    frame_002_3.label = "Random Displacement"
	    frame_002_3.name = "Frame.002"
	    frame_002_3.label_size = 20
	    frame_002_3.shrink = True
	
	    #node Frame.004
	    frame_004_2 = clump_hair_curves.nodes.new("NodeFrame")
	    frame_004_2.label = "Root Distance Falloff"
	    frame_004_2.name = "Frame.004"
	    frame_004_2.label_size = 20
	    frame_004_2.shrink = True
	
	    #node Group Input.003
	    group_input_003_3 = clump_hair_curves.nodes.new("NodeGroupInput")
	    group_input_003_3.name = "Group Input.003"
	    group_input_003_3.outputs[1].hide = True
	    group_input_003_3.outputs[2].hide = True
	    group_input_003_3.outputs[3].hide = True
	    group_input_003_3.outputs[4].hide = True
	    group_input_003_3.outputs[5].hide = True
	    group_input_003_3.outputs[6].hide = True
	    group_input_003_3.outputs[7].hide = True
	    group_input_003_3.outputs[8].hide = True
	    group_input_003_3.outputs[9].hide = True
	    group_input_003_3.outputs[10].hide = True
	    group_input_003_3.outputs[11].hide = True
	    group_input_003_3.outputs[12].hide = True
	
	    #node Reroute.014
	    reroute_014_3 = clump_hair_curves.nodes.new("NodeReroute")
	    reroute_014_3.name = "Reroute.014"
	    reroute_014_3.socket_idname = "NodeSocketGeometry"
	    #node Reroute.015
	    reroute_015_3 = clump_hair_curves.nodes.new("NodeReroute")
	    reroute_015_3.name = "Reroute.015"
	    reroute_015_3.socket_idname = "NodeSocketGeometry"
	    #node Reroute.013
	    reroute_013_3 = clump_hair_curves.nodes.new("NodeReroute")
	    reroute_013_3.name = "Reroute.013"
	    reroute_013_3.socket_idname = "NodeSocketGeometry"
	    #node Reroute.012
	    reroute_012_3 = clump_hair_curves.nodes.new("NodeReroute")
	    reroute_012_3.name = "Reroute.012"
	    reroute_012_3.socket_idname = "NodeSocketGeometry"
	    #node Separate Components
	    separate_components_2 = clump_hair_curves.nodes.new("GeometryNodeSeparateComponents")
	    separate_components_2.name = "Separate Components"
	
	    #node Group Output.001
	    group_output_001 = clump_hair_curves.nodes.new("NodeGroupOutput")
	    group_output_001.name = "Group Output.001"
	    group_output_001.is_active_output = True
	
	    #node Join Geometry.001
	    join_geometry_001_2 = clump_hair_curves.nodes.new("GeometryNodeJoinGeometry")
	    join_geometry_001_2.name = "Join Geometry.001"
	
	    #node Reroute.016
	    reroute_016_3 = clump_hair_curves.nodes.new("NodeReroute")
	    reroute_016_3.name = "Reroute.016"
	    reroute_016_3.socket_idname = "NodeSocketGeometry"
	    #node Reroute.017
	    reroute_017_3 = clump_hair_curves.nodes.new("NodeReroute")
	    reroute_017_3.name = "Reroute.017"
	    reroute_017_3.socket_idname = "NodeSocketGeometry"
	    #node Reroute.019
	    reroute_019_2 = clump_hair_curves.nodes.new("NodeReroute")
	    reroute_019_2.name = "Reroute.019"
	    reroute_019_2.socket_idname = "NodeSocketGeometry"
	    #node Reroute.018
	    reroute_018_3 = clump_hair_curves.nodes.new("NodeReroute")
	    reroute_018_3.name = "Reroute.018"
	    reroute_018_3.socket_idname = "NodeSocketGeometry"
	    #node Capture Attribute
	    capture_attribute_2 = clump_hair_curves.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_2.name = "Capture Attribute"
	    capture_attribute_2.active_index = 0
	    capture_attribute_2.capture_items.clear()
	    capture_attribute_2.capture_items.new('FLOAT', "Value")
	    capture_attribute_2.capture_items["Value"].data_type = 'FLOAT_VECTOR'
	    capture_attribute_2.domain = 'POINT'
	
	    #node Position.001
	    position_001_1 = clump_hair_curves.nodes.new("GeometryNodeInputPosition")
	    position_001_1.name = "Position.001"
	
	    #node Capture Attribute.002
	    capture_attribute_002_2 = clump_hair_curves.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_002_2.name = "Capture Attribute.002"
	    capture_attribute_002_2.active_index = 0
	    capture_attribute_002_2.capture_items.clear()
	    capture_attribute_002_2.capture_items.new('FLOAT', "Value")
	    capture_attribute_002_2.capture_items["Value"].data_type = 'INT'
	    capture_attribute_002_2.domain = 'CURVE'
	
	    #node Spline Resolution
	    spline_resolution = clump_hair_curves.nodes.new("GeometryNodeInputSplineResolution")
	    spline_resolution.name = "Spline Resolution"
	
	    #node Set Spline Type.002
	    set_spline_type_002 = clump_hair_curves.nodes.new("GeometryNodeCurveSplineType")
	    set_spline_type_002.name = "Set Spline Type.002"
	    set_spline_type_002.spline_type = 'POLY'
	    #Selection
	    set_spline_type_002.inputs[1].default_value = True
	
	    #node Reroute.021
	    reroute_021_1 = clump_hair_curves.nodes.new("NodeReroute")
	    reroute_021_1.name = "Reroute.021"
	    reroute_021_1.socket_idname = "NodeSocketInt"
	    #node Switch.006
	    switch_006 = clump_hair_curves.nodes.new("GeometryNodeSwitch")
	    switch_006.name = "Switch.006"
	    switch_006.input_type = 'INT'
	    #True
	    switch_006.inputs[2].default_value = 12
	
	    #node Compare.004
	    compare_004_3 = clump_hair_curves.nodes.new("FunctionNodeCompare")
	    compare_004_3.name = "Compare.004"
	    compare_004_3.data_type = 'INT'
	    compare_004_3.mode = 'ELEMENT'
	    compare_004_3.operation = 'EQUAL'
	    #B_INT
	    compare_004_3.inputs[3].default_value = 0
	
	    #node Set Spline Resolution.001
	    set_spline_resolution_001 = clump_hair_curves.nodes.new("GeometryNodeSetSplineResolution")
	    set_spline_resolution_001.name = "Set Spline Resolution.001"
	    set_spline_resolution_001.inputs[1].hide = True
	    #Selection
	    set_spline_resolution_001.inputs[1].default_value = True
	
	    #node Set Spline Type.001
	    set_spline_type_001 = clump_hair_curves.nodes.new("GeometryNodeCurveSplineType")
	    set_spline_type_001.name = "Set Spline Type.001"
	    set_spline_type_001.spline_type = 'CATMULL_ROM'
	    set_spline_type_001.inputs[1].hide = True
	    #Selection
	    set_spline_type_001.inputs[1].default_value = True
	
	    #node Reroute.025
	    reroute_025 = clump_hair_curves.nodes.new("NodeReroute")
	    reroute_025.name = "Reroute.025"
	    reroute_025.socket_idname = "NodeSocketGeometry"
	    #node Group.005
	    group_005 = clump_hair_curves.nodes.new("GeometryNodeGroup")
	    group_005.name = "Group.005"
	    group_005.node_tree = restore_curve_segment_length
	    #Socket_3
	    group_005.inputs[2].default_value = 1.0
	    #Socket_5
	    group_005.inputs[4].default_value = 0.0
	
	    #node Group Input.010
	    group_input_010_1 = clump_hair_curves.nodes.new("NodeGroupInput")
	    group_input_010_1.name = "Group Input.010"
	    group_input_010_1.outputs[0].hide = True
	    group_input_010_1.outputs[1].hide = True
	    group_input_010_1.outputs[2].hide = True
	    group_input_010_1.outputs[3].hide = True
	    group_input_010_1.outputs[4].hide = True
	    group_input_010_1.outputs[5].hide = True
	    group_input_010_1.outputs[6].hide = True
	    group_input_010_1.outputs[7].hide = True
	    group_input_010_1.outputs[8].hide = True
	    group_input_010_1.outputs[9].hide = True
	    group_input_010_1.outputs[10].hide = True
	    group_input_010_1.outputs[11].hide = True
	    group_input_010_1.outputs[13].hide = True
	
	    #node Reroute.003
	    reroute_003_2 = clump_hair_curves.nodes.new("NodeReroute")
	    reroute_003_2.name = "Reroute.003"
	    reroute_003_2.socket_idname = "NodeSocketGeometry"
	    #node Reroute.005
	    reroute_005_2 = clump_hair_curves.nodes.new("NodeReroute")
	    reroute_005_2.name = "Reroute.005"
	    reroute_005_2.socket_idname = "NodeSocketGeometry"
	    #node Reroute.002
	    reroute_002_2 = clump_hair_curves.nodes.new("NodeReroute")
	    reroute_002_2.name = "Reroute.002"
	    reroute_002_2.socket_idname = "NodeSocketInt"
	    #node Reroute.010
	    reroute_010_1 = clump_hair_curves.nodes.new("NodeReroute")
	    reroute_010_1.name = "Reroute.010"
	    reroute_010_1.socket_idname = "NodeSocketVector"
	    #node Reroute.022
	    reroute_022_1 = clump_hair_curves.nodes.new("NodeReroute")
	    reroute_022_1.name = "Reroute.022"
	    reroute_022_1.socket_idname = "NodeSocketVector"
	    #node Reroute.023
	    reroute_023_1 = clump_hair_curves.nodes.new("NodeReroute")
	    reroute_023_1.name = "Reroute.023"
	    reroute_023_1.socket_idname = "NodeSocketInt"
	    #node Reroute.024
	    reroute_024_1 = clump_hair_curves.nodes.new("NodeReroute")
	    reroute_024_1.name = "Reroute.024"
	    reroute_024_1.socket_idname = "NodeSocketInt"
	    #node Vector Math
	    vector_math_3 = clump_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_3.name = "Vector Math"
	    vector_math_3.hide = True
	    vector_math_3.operation = 'CROSS_PRODUCT'
	
	    #node Sample Curve
	    sample_curve = clump_hair_curves.nodes.new("GeometryNodeSampleCurve")
	    sample_curve.name = "Sample Curve"
	    sample_curve.data_type = 'FLOAT'
	    sample_curve.mode = 'FACTOR'
	    sample_curve.use_all_curves = False
	    sample_curve.inputs[1].hide = True
	    sample_curve.outputs[0].hide = True
	    #Value
	    sample_curve.inputs[1].default_value = 0.0
	
	    #node Spline Parameter
	    spline_parameter = clump_hair_curves.nodes.new("GeometryNodeSplineParameter")
	    spline_parameter.name = "Spline Parameter"
	    spline_parameter.outputs[1].hide = True
	    spline_parameter.outputs[2].hide = True
	
	    #node Vector Math.001
	    vector_math_001_3 = clump_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_001_3.name = "Vector Math.001"
	    vector_math_001_3.hide = True
	    vector_math_001_3.operation = 'SCALE'
	
	    #node Vector Math.002
	    vector_math_002_2 = clump_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_002_2.name = "Vector Math.002"
	    vector_math_002_2.hide = True
	    vector_math_002_2.operation = 'SCALE'
	
	    #node Separate XYZ
	    separate_xyz_1 = clump_hair_curves.nodes.new("ShaderNodeSeparateXYZ")
	    separate_xyz_1.name = "Separate XYZ"
	    separate_xyz_1.outputs[2].hide = True
	
	    #node Vector Math.006
	    vector_math_006_2 = clump_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_006_2.name = "Vector Math.006"
	    vector_math_006_2.hide = True
	    vector_math_006_2.operation = 'ADD'
	
	    #node Evaluate on Domain
	    evaluate_on_domain_1 = clump_hair_curves.nodes.new("GeometryNodeFieldOnDomain")
	    evaluate_on_domain_1.name = "Evaluate on Domain"
	    evaluate_on_domain_1.data_type = 'FLOAT_VECTOR'
	    evaluate_on_domain_1.domain = 'CURVE'
	
	    #node Combine XYZ
	    combine_xyz_1 = clump_hair_curves.nodes.new("ShaderNodeCombineXYZ")
	    combine_xyz_1.name = "Combine XYZ"
	    #Z
	    combine_xyz_1.inputs[2].default_value = 0.0
	
	    #node Vector Math.004
	    vector_math_004_3 = clump_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_004_3.name = "Vector Math.004"
	    vector_math_004_3.hide = True
	    vector_math_004_3.operation = 'DOT_PRODUCT'
	
	    #node Vector Math.005
	    vector_math_005_1 = clump_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_005_1.name = "Vector Math.005"
	    vector_math_005_1.hide = True
	    vector_math_005_1.operation = 'DOT_PRODUCT'
	
	    #node Reroute
	    reroute_4 = clump_hair_curves.nodes.new("NodeReroute")
	    reroute_4.name = "Reroute"
	    reroute_4.socket_idname = "NodeSocketVector"
	    #node Vector Math.008
	    vector_math_008_2 = clump_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_008_2.name = "Vector Math.008"
	    vector_math_008_2.operation = 'SUBTRACT'
	
	    #node Vector Math.003
	    vector_math_003_2 = clump_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_003_2.name = "Vector Math.003"
	    vector_math_003_2.hide = True
	    vector_math_003_2.operation = 'CROSS_PRODUCT'
	
	    #node Sample Curve.001
	    sample_curve_001_1 = clump_hair_curves.nodes.new("GeometryNodeSampleCurve")
	    sample_curve_001_1.name = "Sample Curve.001"
	    sample_curve_001_1.data_type = 'FLOAT'
	    sample_curve_001_1.mode = 'FACTOR'
	    sample_curve_001_1.use_all_curves = False
	    sample_curve_001_1.inputs[1].hide = True
	    sample_curve_001_1.inputs[2].hide = True
	    sample_curve_001_1.outputs[0].hide = True
	    sample_curve_001_1.outputs[1].hide = True
	    #Value
	    sample_curve_001_1.inputs[1].default_value = 0.0
	    #Factor
	    sample_curve_001_1.inputs[2].default_value = 0.0
	
	    #node Evaluate at Index
	    evaluate_at_index_3 = clump_hair_curves.nodes.new("GeometryNodeFieldAtIndex")
	    evaluate_at_index_3.name = "Evaluate at Index"
	    evaluate_at_index_3.data_type = 'FLOAT_VECTOR'
	    evaluate_at_index_3.domain = 'CURVE'
	
	    #node Group
	    group_3 = clump_hair_curves.nodes.new("GeometryNodeGroup")
	    group_3.name = "Group"
	    group_3.node_tree = curve_root
	    group_3.outputs[0].hide = True
	    group_3.outputs[2].hide = True
	    group_3.outputs[3].hide = True
	
	    #node Reroute.001
	    reroute_001_4 = clump_hair_curves.nodes.new("NodeReroute")
	    reroute_001_4.name = "Reroute.001"
	    reroute_001_4.socket_idname = "NodeSocketInt"
	    #node Reroute.008
	    reroute_008_2 = clump_hair_curves.nodes.new("NodeReroute")
	    reroute_008_2.name = "Reroute.008"
	    reroute_008_2.socket_idname = "NodeSocketInt"
	    #node Reroute.007
	    reroute_007_2 = clump_hair_curves.nodes.new("NodeReroute")
	    reroute_007_2.name = "Reroute.007"
	    reroute_007_2.socket_idname = "NodeSocketInt"
	    #node Reroute.026
	    reroute_026_1 = clump_hair_curves.nodes.new("NodeReroute")
	    reroute_026_1.name = "Reroute.026"
	    reroute_026_1.socket_idname = "NodeSocketInt"
	    #node Reroute.027
	    reroute_027_1 = clump_hair_curves.nodes.new("NodeReroute")
	    reroute_027_1.name = "Reroute.027"
	    reroute_027_1.socket_idname = "NodeSocketInt"
	    #node Evaluate on Domain.001
	    evaluate_on_domain_001_2 = clump_hair_curves.nodes.new("GeometryNodeFieldOnDomain")
	    evaluate_on_domain_001_2.name = "Evaluate on Domain.001"
	    evaluate_on_domain_001_2.data_type = 'FLOAT_VECTOR'
	    evaluate_on_domain_001_2.domain = 'CURVE'
	
	    #node Sample Index
	    sample_index_1 = clump_hair_curves.nodes.new("GeometryNodeSampleIndex")
	    sample_index_1.name = "Sample Index"
	    sample_index_1.hide = True
	    sample_index_1.clamp = False
	    sample_index_1.data_type = 'INT'
	    sample_index_1.domain = 'POINT'
	    #Index
	    sample_index_1.inputs[2].default_value = 0
	
	    #node Accumulate Field.002
	    accumulate_field_002 = clump_hair_curves.nodes.new("GeometryNodeAccumulateField")
	    accumulate_field_002.name = "Accumulate Field.002"
	    accumulate_field_002.hide = True
	    accumulate_field_002.data_type = 'INT'
	    accumulate_field_002.domain = 'POINT'
	    #Group Index
	    accumulate_field_002.inputs[1].default_value = 0
	
	    #node Group Input.002
	    group_input_002_2 = clump_hair_curves.nodes.new("NodeGroupInput")
	    group_input_002_2.name = "Group Input.002"
	    group_input_002_2.outputs[0].hide = True
	    group_input_002_2.outputs[1].hide = True
	    group_input_002_2.outputs[2].hide = True
	    group_input_002_2.outputs[3].hide = True
	    group_input_002_2.outputs[5].hide = True
	    group_input_002_2.outputs[6].hide = True
	    group_input_002_2.outputs[7].hide = True
	    group_input_002_2.outputs[8].hide = True
	    group_input_002_2.outputs[9].hide = True
	    group_input_002_2.outputs[10].hide = True
	    group_input_002_2.outputs[11].hide = True
	    group_input_002_2.outputs[12].hide = True
	    group_input_002_2.outputs[13].hide = True
	
	    #node Reroute.032
	    reroute_032 = clump_hair_curves.nodes.new("NodeReroute")
	    reroute_032.name = "Reroute.032"
	    reroute_032.socket_idname = "NodeSocketGeometry"
	    #node Boolean Math.001
	    boolean_math_001 = clump_hair_curves.nodes.new("FunctionNodeBooleanMath")
	    boolean_math_001.name = "Boolean Math.001"
	    boolean_math_001.operation = 'AND'
	
	    #node Switch.001
	    switch_001_5 = clump_hair_curves.nodes.new("GeometryNodeSwitch")
	    switch_001_5.name = "Switch.001"
	    switch_001_5.input_type = 'GEOMETRY'
	
	    #node Named Attribute.003
	    named_attribute_003 = clump_hair_curves.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute_003.name = "Named Attribute.003"
	    named_attribute_003.data_type = 'INT'
	    #Name
	    named_attribute_003.inputs[0].default_value = "guide_curve_index"
	
	    #node Group Input.013
	    group_input_013 = clump_hair_curves.nodes.new("NodeGroupInput")
	    group_input_013.name = "Group Input.013"
	    group_input_013.outputs[0].hide = True
	    group_input_013.outputs[1].hide = True
	    group_input_013.outputs[2].hide = True
	    group_input_013.outputs[4].hide = True
	    group_input_013.outputs[5].hide = True
	    group_input_013.outputs[6].hide = True
	    group_input_013.outputs[7].hide = True
	    group_input_013.outputs[8].hide = True
	    group_input_013.outputs[9].hide = True
	    group_input_013.outputs[10].hide = True
	    group_input_013.outputs[11].hide = True
	    group_input_013.outputs[12].hide = True
	    group_input_013.outputs[13].hide = True
	
	    #node Group Input.004
	    group_input_004_2 = clump_hair_curves.nodes.new("NodeGroupInput")
	    group_input_004_2.name = "Group Input.004"
	    group_input_004_2.outputs[0].hide = True
	    group_input_004_2.outputs[1].hide = True
	    group_input_004_2.outputs[3].hide = True
	    group_input_004_2.outputs[4].hide = True
	    group_input_004_2.outputs[5].hide = True
	    group_input_004_2.outputs[6].hide = True
	    group_input_004_2.outputs[7].hide = True
	    group_input_004_2.outputs[8].hide = True
	    group_input_004_2.outputs[9].hide = True
	    group_input_004_2.outputs[10].hide = True
	    group_input_004_2.outputs[11].hide = True
	    group_input_004_2.outputs[12].hide = True
	    group_input_004_2.outputs[13].hide = True
	
	    #node Reroute.006
	    reroute_006_2 = clump_hair_curves.nodes.new("NodeReroute")
	    reroute_006_2.name = "Reroute.006"
	    reroute_006_2.socket_idname = "NodeSocketInt"
	    #node Compare.003
	    compare_003_2 = clump_hair_curves.nodes.new("FunctionNodeCompare")
	    compare_003_2.name = "Compare.003"
	    compare_003_2.data_type = 'INT'
	    compare_003_2.mode = 'ELEMENT'
	    compare_003_2.operation = 'NOT_EQUAL'
	    #B_INT
	    compare_003_2.inputs[3].default_value = -987654
	
	    #node Group Input.011
	    group_input_011 = clump_hair_curves.nodes.new("NodeGroupInput")
	    group_input_011.name = "Group Input.011"
	    group_input_011.outputs[0].hide = True
	    group_input_011.outputs[2].hide = True
	    group_input_011.outputs[3].hide = True
	    group_input_011.outputs[4].hide = True
	    group_input_011.outputs[5].hide = True
	    group_input_011.outputs[6].hide = True
	    group_input_011.outputs[7].hide = True
	    group_input_011.outputs[8].hide = True
	    group_input_011.outputs[9].hide = True
	    group_input_011.outputs[10].hide = True
	    group_input_011.outputs[11].hide = True
	    group_input_011.outputs[12].hide = True
	    group_input_011.outputs[13].hide = True
	
	    #node Accumulate Field
	    accumulate_field_1 = clump_hair_curves.nodes.new("GeometryNodeAccumulateField")
	    accumulate_field_1.name = "Accumulate Field"
	    accumulate_field_1.data_type = 'INT'
	    accumulate_field_1.domain = 'CURVE'
	    accumulate_field_1.inputs[1].hide = True
	    accumulate_field_1.outputs[0].hide = True
	    accumulate_field_1.outputs[1].hide = True
	    #Group Index
	    accumulate_field_1.inputs[1].default_value = 0
	
	    #node Switch.003
	    switch_003_4 = clump_hair_curves.nodes.new("GeometryNodeSwitch")
	    switch_003_4.name = "Switch.003"
	    switch_003_4.input_type = 'INT'
	
	    #node Compare.001
	    compare_001_2 = clump_hair_curves.nodes.new("FunctionNodeCompare")
	    compare_001_2.name = "Compare.001"
	    compare_001_2.hide = True
	    compare_001_2.data_type = 'INT'
	    compare_001_2.mode = 'ELEMENT'
	    compare_001_2.operation = 'GREATER_THAN'
	    #B_INT
	    compare_001_2.inputs[3].default_value = 0
	
	    #node Group.003
	    group_003_1 = clump_hair_curves.nodes.new("GeometryNodeGroup")
	    group_003_1.name = "Group.003"
	    group_003_1.node_tree = create_guide_index_map
	    group_003_1.inputs[1].hide = True
	    group_003_1.inputs[4].hide = True
	    group_003_1.outputs[1].hide = True
	    group_003_1.outputs[3].hide = True
	    #Socket_8
	    group_003_1.inputs[4].default_value = 0
	
	    #node Boolean Math.002
	    boolean_math_002_2 = clump_hair_curves.nodes.new("FunctionNodeBooleanMath")
	    boolean_math_002_2.name = "Boolean Math.002"
	    boolean_math_002_2.operation = 'NIMPLY'
	
	    #node Sample Index.001
	    sample_index_001_1 = clump_hair_curves.nodes.new("GeometryNodeSampleIndex")
	    sample_index_001_1.name = "Sample Index.001"
	    sample_index_001_1.hide = True
	    sample_index_001_1.clamp = False
	    sample_index_001_1.data_type = 'BOOLEAN'
	    sample_index_001_1.domain = 'CURVE'
	    #Index
	    sample_index_001_1.inputs[2].default_value = 0
	
	    #node Reroute.029
	    reroute_029 = clump_hair_curves.nodes.new("NodeReroute")
	    reroute_029.name = "Reroute.029"
	    reroute_029.socket_idname = "NodeSocketInt"
	    #node Capture Attribute.001
	    capture_attribute_001_2 = clump_hair_curves.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_001_2.name = "Capture Attribute.001"
	    capture_attribute_001_2.active_index = 0
	    capture_attribute_001_2.capture_items.clear()
	    capture_attribute_001_2.capture_items.new('FLOAT', "Value")
	    capture_attribute_001_2.capture_items["Value"].data_type = 'INT'
	    capture_attribute_001_2.domain = 'CURVE'
	
	    #node Position
	    position_1 = clump_hair_curves.nodes.new("GeometryNodeInputPosition")
	    position_1.name = "Position"
	
	    #node Mix
	    mix_1 = clump_hair_curves.nodes.new("ShaderNodeMix")
	    mix_1.name = "Mix"
	    mix_1.blend_type = 'MIX'
	    mix_1.clamp_factor = True
	    mix_1.clamp_result = False
	    mix_1.data_type = 'VECTOR'
	    mix_1.factor_mode = 'UNIFORM'
	
	    #node Vector Math.009
	    vector_math_009_2 = clump_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_009_2.name = "Vector Math.009"
	    vector_math_009_2.operation = 'ADD'
	
	    #node Math.002
	    math_002_1 = clump_hair_curves.nodes.new("ShaderNodeMath")
	    math_002_1.name = "Math.002"
	    math_002_1.operation = 'MULTIPLY'
	    math_002_1.use_clamp = False
	
	    #node Set Position
	    set_position_2 = clump_hair_curves.nodes.new("GeometryNodeSetPosition")
	    set_position_2.name = "Set Position"
	    set_position_2.inputs[1].hide = True
	    set_position_2.inputs[3].hide = True
	    #Selection
	    set_position_2.inputs[1].default_value = True
	    #Offset
	    set_position_2.inputs[3].default_value = (0.0, 0.0, 0.0)
	
	    #node Group Input.001
	    group_input_001_3 = clump_hair_curves.nodes.new("NodeGroupInput")
	    group_input_001_3.name = "Group Input.001"
	    group_input_001_3.outputs[0].hide = True
	    group_input_001_3.outputs[1].hide = True
	    group_input_001_3.outputs[2].hide = True
	    group_input_001_3.outputs[3].hide = True
	    group_input_001_3.outputs[4].hide = True
	    group_input_001_3.outputs[6].hide = True
	    group_input_001_3.outputs[7].hide = True
	    group_input_001_3.outputs[8].hide = True
	    group_input_001_3.outputs[9].hide = True
	    group_input_001_3.outputs[10].hide = True
	    group_input_001_3.outputs[11].hide = True
	    group_input_001_3.outputs[12].hide = True
	    group_input_001_3.outputs[13].hide = True
	
	    #node Math
	    math_4 = clump_hair_curves.nodes.new("ShaderNodeMath")
	    math_4.name = "Math"
	    math_4.operation = 'SUBTRACT'
	    math_4.use_clamp = False
	    #Value
	    math_4.inputs[0].default_value = 1.0
	
	    #node Vector Math.013
	    vector_math_013_1 = clump_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_013_1.name = "Vector Math.013"
	    vector_math_013_1.hide = True
	    vector_math_013_1.operation = 'SCALE'
	
	    #node Vector Math.007
	    vector_math_007_2 = clump_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_007_2.name = "Vector Math.007"
	    vector_math_007_2.hide = True
	    vector_math_007_2.operation = 'SCALE'
	
	    #node Vector Math.011
	    vector_math_011_1 = clump_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_011_1.name = "Vector Math.011"
	    vector_math_011_1.hide = True
	    vector_math_011_1.operation = 'ADD'
	
	    #node Reroute.020
	    reroute_020_2 = clump_hair_curves.nodes.new("NodeReroute")
	    reroute_020_2.name = "Reroute.020"
	    reroute_020_2.socket_idname = "NodeSocketFloat"
	    #node Math.001
	    math_001_2 = clump_hair_curves.nodes.new("ShaderNodeMath")
	    math_001_2.name = "Math.001"
	    math_001_2.operation = 'MULTIPLY'
	    math_001_2.use_clamp = False
	
	    #node Reroute.004
	    reroute_004_3 = clump_hair_curves.nodes.new("NodeReroute")
	    reroute_004_3.name = "Reroute.004"
	    reroute_004_3.socket_idname = "NodeSocketFloat"
	    #node Vector Math.025
	    vector_math_025 = clump_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_025.name = "Vector Math.025"
	    vector_math_025.hide = True
	    vector_math_025.operation = 'ADD'
	
	    #node Switch.002
	    switch_002_3 = clump_hair_curves.nodes.new("GeometryNodeSwitch")
	    switch_002_3.name = "Switch.002"
	    switch_002_3.hide = True
	    switch_002_3.input_type = 'VECTOR'
	    #True
	    switch_002_3.inputs[2].default_value = (0.0, 0.0, 0.0)
	
	    #node Vector Math.020
	    vector_math_020 = clump_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_020.name = "Vector Math.020"
	    vector_math_020.hide = True
	    vector_math_020.operation = 'SCALE'
	
	    #node Vector Math.021
	    vector_math_021 = clump_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_021.name = "Vector Math.021"
	    vector_math_021.hide = True
	    vector_math_021.operation = 'SCALE'
	
	    #node Vector Math.022
	    vector_math_022 = clump_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_022.name = "Vector Math.022"
	    vector_math_022.hide = True
	    vector_math_022.operation = 'ADD'
	
	    #node Vector Math.015
	    vector_math_015 = clump_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_015.name = "Vector Math.015"
	    vector_math_015.hide = True
	    vector_math_015.operation = 'SCALE'
	
	    #node Vector Math.016
	    vector_math_016 = clump_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_016.name = "Vector Math.016"
	    vector_math_016.hide = True
	    vector_math_016.operation = 'SCALE'
	
	    #node Vector Math.018
	    vector_math_018 = clump_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_018.name = "Vector Math.018"
	    vector_math_018.hide = True
	    vector_math_018.operation = 'ADD'
	
	    #node Vector Math.019
	    vector_math_019 = clump_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_019.name = "Vector Math.019"
	    vector_math_019.hide = True
	    vector_math_019.operation = 'ADD'
	
	    #node Vector Math.014
	    vector_math_014_1 = clump_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_014_1.name = "Vector Math.014"
	    vector_math_014_1.hide = True
	    vector_math_014_1.operation = 'SCALE'
	
	    #node Switch
	    switch_4 = clump_hair_curves.nodes.new("GeometryNodeSwitch")
	    switch_4.name = "Switch"
	    switch_4.hide = True
	    switch_4.input_type = 'VECTOR'
	    #True
	    switch_4.inputs[2].default_value = (0.0, 0.0, 0.0)
	
	    #node Sample Curve.002
	    sample_curve_002 = clump_hair_curves.nodes.new("GeometryNodeSampleCurve")
	    sample_curve_002.name = "Sample Curve.002"
	    sample_curve_002.data_type = 'FLOAT'
	    sample_curve_002.mode = 'FACTOR'
	    sample_curve_002.use_all_curves = False
	    sample_curve_002.inputs[1].hide = True
	    sample_curve_002.inputs[2].hide = True
	    sample_curve_002.outputs[0].hide = True
	    sample_curve_002.outputs[1].hide = True
	    #Value
	    sample_curve_002.inputs[1].default_value = 0.0
	    #Factor
	    sample_curve_002.inputs[2].default_value = 1.0
	
	    #node Reroute.011
	    reroute_011_2 = clump_hair_curves.nodes.new("NodeReroute")
	    reroute_011_2.name = "Reroute.011"
	    reroute_011_2.socket_idname = "NodeSocketInt"
	    #node Vector Math.017
	    vector_math_017 = clump_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_017.name = "Vector Math.017"
	    vector_math_017.hide = True
	    vector_math_017.operation = 'CROSS_PRODUCT'
	
	    #node Random Value
	    random_value_1 = clump_hair_curves.nodes.new("FunctionNodeRandomValue")
	    random_value_1.name = "Random Value"
	    random_value_1.hide = True
	    random_value_1.data_type = 'FLOAT_VECTOR'
	    #Min
	    random_value_1.inputs[0].default_value = (-1.0, -1.0, -1.0)
	    #Max
	    random_value_1.inputs[1].default_value = (1.0, 1.0, 1.0)
	
	    #node Vector Math.026
	    vector_math_026 = clump_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_026.name = "Vector Math.026"
	    vector_math_026.operation = 'SCALE'
	
	    #node Separate XYZ.002
	    separate_xyz_002_1 = clump_hair_curves.nodes.new("ShaderNodeSeparateXYZ")
	    separate_xyz_002_1.name = "Separate XYZ.002"
	    separate_xyz_002_1.outputs[2].hide = True
	
	    #node Separate XYZ.001
	    separate_xyz_001_1 = clump_hair_curves.nodes.new("ShaderNodeSeparateXYZ")
	    separate_xyz_001_1.name = "Separate XYZ.001"
	
	    #node Reroute.009
	    reroute_009_2 = clump_hair_curves.nodes.new("NodeReroute")
	    reroute_009_2.name = "Reroute.009"
	    reroute_009_2.socket_idname = "NodeSocketFloatDistance"
	    #node Vector Math.012
	    vector_math_012_1 = clump_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_012_1.name = "Vector Math.012"
	    vector_math_012_1.operation = 'SCALE'
	
	    #node Group Input.009
	    group_input_009_1 = clump_hair_curves.nodes.new("NodeGroupInput")
	    group_input_009_1.name = "Group Input.009"
	    group_input_009_1.outputs[0].hide = True
	    group_input_009_1.outputs[1].hide = True
	    group_input_009_1.outputs[2].hide = True
	    group_input_009_1.outputs[3].hide = True
	    group_input_009_1.outputs[4].hide = True
	    group_input_009_1.outputs[5].hide = True
	    group_input_009_1.outputs[6].hide = True
	    group_input_009_1.outputs[7].hide = True
	    group_input_009_1.outputs[9].hide = True
	    group_input_009_1.outputs[10].hide = True
	    group_input_009_1.outputs[11].hide = True
	    group_input_009_1.outputs[12].hide = True
	    group_input_009_1.outputs[13].hide = True
	
	    #node Group Input.012
	    group_input_012 = clump_hair_curves.nodes.new("NodeGroupInput")
	    group_input_012.name = "Group Input.012"
	    group_input_012.outputs[0].hide = True
	    group_input_012.outputs[1].hide = True
	    group_input_012.outputs[2].hide = True
	    group_input_012.outputs[3].hide = True
	    group_input_012.outputs[4].hide = True
	    group_input_012.outputs[5].hide = True
	    group_input_012.outputs[6].hide = True
	    group_input_012.outputs[8].hide = True
	    group_input_012.outputs[9].hide = True
	    group_input_012.outputs[10].hide = True
	    group_input_012.outputs[11].hide = True
	    group_input_012.outputs[12].hide = True
	    group_input_012.outputs[13].hide = True
	
	    #node Group Input.008
	    group_input_008_1 = clump_hair_curves.nodes.new("NodeGroupInput")
	    group_input_008_1.name = "Group Input.008"
	    group_input_008_1.outputs[0].hide = True
	    group_input_008_1.outputs[1].hide = True
	    group_input_008_1.outputs[2].hide = True
	    group_input_008_1.outputs[3].hide = True
	    group_input_008_1.outputs[4].hide = True
	    group_input_008_1.outputs[5].hide = True
	    group_input_008_1.outputs[6].hide = True
	    group_input_008_1.outputs[8].hide = True
	    group_input_008_1.outputs[9].hide = True
	    group_input_008_1.outputs[10].hide = True
	    group_input_008_1.outputs[11].hide = True
	    group_input_008_1.outputs[12].hide = True
	    group_input_008_1.outputs[13].hide = True
	
	    #node Random Value.001
	    random_value_001_2 = clump_hair_curves.nodes.new("FunctionNodeRandomValue")
	    random_value_001_2.name = "Random Value.001"
	    random_value_001_2.hide = True
	    random_value_001_2.data_type = 'FLOAT_VECTOR'
	    #Min
	    random_value_001_2.inputs[0].default_value = (-1.0, -1.0, -1.0)
	    #Max
	    random_value_001_2.inputs[1].default_value = (1.0, 1.0, 1.0)
	
	    #node Reroute.028
	    reroute_028_1 = clump_hair_curves.nodes.new("NodeReroute")
	    reroute_028_1.name = "Reroute.028"
	    reroute_028_1.socket_idname = "NodeSocketInt"
	    #node Evaluate at Index.001
	    evaluate_at_index_001_1 = clump_hair_curves.nodes.new("GeometryNodeFieldAtIndex")
	    evaluate_at_index_001_1.name = "Evaluate at Index.001"
	    evaluate_at_index_001_1.data_type = 'INT'
	    evaluate_at_index_001_1.domain = 'CURVE'
	
	    #node Group.006
	    group_006 = clump_hair_curves.nodes.new("GeometryNodeGroup")
	    group_006.name = "Group.006"
	    group_006.node_tree = curve_info
	    group_006.outputs[0].hide = True
	    group_006.outputs[2].hide = True
	    group_006.outputs[3].hide = True
	    group_006.outputs[4].hide = True
	    group_006.outputs[5].hide = True
	
	    #node Group.007
	    group_007 = clump_hair_curves.nodes.new("GeometryNodeGroup")
	    group_007.name = "Group.007"
	    group_007.node_tree = curve_info
	    group_007.outputs[0].hide = True
	    group_007.outputs[2].hide = True
	    group_007.outputs[3].hide = True
	    group_007.outputs[4].hide = True
	    group_007.outputs[5].hide = True
	
	    #node Random Value.004
	    random_value_004_1 = clump_hair_curves.nodes.new("FunctionNodeRandomValue")
	    random_value_004_1.label = "Hash Seed"
	    random_value_004_1.name = "Random Value.004"
	    random_value_004_1.data_type = 'INT'
	    #Min_002
	    random_value_004_1.inputs[4].default_value = -1073741823
	    #Max_002
	    random_value_004_1.inputs[5].default_value = 1073741823
	    #Seed
	    random_value_004_1.inputs[8].default_value = 148762
	
	    #node Group Input.005
	    group_input_005_2 = clump_hair_curves.nodes.new("NodeGroupInput")
	    group_input_005_2.name = "Group Input.005"
	    group_input_005_2.outputs[0].hide = True
	    group_input_005_2.outputs[1].hide = True
	    group_input_005_2.outputs[2].hide = True
	    group_input_005_2.outputs[3].hide = True
	    group_input_005_2.outputs[4].hide = True
	    group_input_005_2.outputs[5].hide = True
	    group_input_005_2.outputs[6].hide = True
	    group_input_005_2.outputs[7].hide = True
	    group_input_005_2.outputs[8].hide = True
	    group_input_005_2.outputs[9].hide = True
	    group_input_005_2.outputs[10].hide = True
	    group_input_005_2.outputs[12].hide = True
	    group_input_005_2.outputs[13].hide = True
	
	    #node Compare
	    compare_3 = clump_hair_curves.nodes.new("FunctionNodeCompare")
	    compare_3.name = "Compare"
	    compare_3.hide = True
	    compare_3.data_type = 'FLOAT'
	    compare_3.mode = 'ELEMENT'
	    compare_3.operation = 'EQUAL'
	    #B
	    compare_3.inputs[1].default_value = 0.0
	    #Epsilon
	    compare_3.inputs[12].default_value = 0.0
	
	    #node Compare.002
	    compare_002_2 = clump_hair_curves.nodes.new("FunctionNodeCompare")
	    compare_002_2.name = "Compare.002"
	    compare_002_2.hide = True
	    compare_002_2.data_type = 'FLOAT'
	    compare_002_2.mode = 'ELEMENT'
	    compare_002_2.operation = 'EQUAL'
	    #A
	    compare_002_2.inputs[0].default_value = 0.0
	    #Epsilon
	    compare_002_2.inputs[12].default_value = 0.0
	
	    #node Spline Parameter.001
	    spline_parameter_001 = clump_hair_curves.nodes.new("GeometryNodeSplineParameter")
	    spline_parameter_001.name = "Spline Parameter.001"
	    spline_parameter_001.outputs[1].hide = True
	    spline_parameter_001.outputs[2].hide = True
	
	    #node Group Input
	    group_input_4 = clump_hair_curves.nodes.new("NodeGroupInput")
	    group_input_4.name = "Group Input"
	    group_input_4.outputs[0].hide = True
	    group_input_4.outputs[1].hide = True
	    group_input_4.outputs[2].hide = True
	    group_input_4.outputs[3].hide = True
	    group_input_4.outputs[4].hide = True
	    group_input_4.outputs[5].hide = True
	    group_input_4.outputs[7].hide = True
	    group_input_4.outputs[8].hide = True
	    group_input_4.outputs[9].hide = True
	    group_input_4.outputs[10].hide = True
	    group_input_4.outputs[11].hide = True
	    group_input_4.outputs[12].hide = True
	    group_input_4.outputs[13].hide = True
	
	    #node Group.001
	    group_001_3 = clump_hair_curves.nodes.new("GeometryNodeGroup")
	    group_001_3.name = "Group.001"
	    group_001_3.node_tree = shape_range
	    group_001_3.inputs[1].hide = True
	    group_001_3.inputs[2].hide = True
	    group_001_3.inputs[4].hide = True
	    #Socket_2
	    group_001_3.inputs[1].default_value = 0.0
	    #Socket_3
	    group_001_3.inputs[2].default_value = 1.0
	    #Socket_5
	    group_001_3.inputs[4].default_value = 2.0
	
	    #node Math.003
	    math_003_2 = clump_hair_curves.nodes.new("ShaderNodeMath")
	    math_003_2.name = "Math.003"
	    math_003_2.operation = 'ADD'
	    math_003_2.use_clamp = False
	    math_003_2.inputs[2].hide = True
	
	    #node Vector Math.010
	    vector_math_010_1 = clump_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_010_1.name = "Vector Math.010"
	    vector_math_010_1.hide = True
	    vector_math_010_1.operation = 'LENGTH'
	
	    #node Compare.006
	    compare_006 = clump_hair_curves.nodes.new("FunctionNodeCompare")
	    compare_006.name = "Compare.006"
	    compare_006.hide = True
	    compare_006.data_type = 'FLOAT'
	    compare_006.mode = 'ELEMENT'
	    compare_006.operation = 'NOT_EQUAL'
	    #B
	    compare_006.inputs[1].default_value = 0.0
	    #Epsilon
	    compare_006.inputs[12].default_value = 0.0
	
	    #node Compare.007
	    compare_007 = clump_hair_curves.nodes.new("FunctionNodeCompare")
	    compare_007.name = "Compare.007"
	    compare_007.hide = True
	    compare_007.data_type = 'FLOAT'
	    compare_007.mode = 'ELEMENT'
	    compare_007.operation = 'EQUAL'
	    #B
	    compare_007.inputs[1].default_value = 0.0
	    #Epsilon
	    compare_007.inputs[12].default_value = 0.0
	
	    #node Reroute.030
	    reroute_030 = clump_hair_curves.nodes.new("NodeReroute")
	    reroute_030.name = "Reroute.030"
	    reroute_030.socket_idname = "NodeSocketFloatDistance"
	    #node Group Input.007
	    group_input_007_2 = clump_hair_curves.nodes.new("NodeGroupInput")
	    group_input_007_2.name = "Group Input.007"
	    group_input_007_2.outputs[0].hide = True
	    group_input_007_2.outputs[1].hide = True
	    group_input_007_2.outputs[2].hide = True
	    group_input_007_2.outputs[3].hide = True
	    group_input_007_2.outputs[4].hide = True
	    group_input_007_2.outputs[5].hide = True
	    group_input_007_2.outputs[6].hide = True
	    group_input_007_2.outputs[7].hide = True
	    group_input_007_2.outputs[8].hide = True
	    group_input_007_2.outputs[10].hide = True
	    group_input_007_2.outputs[11].hide = True
	    group_input_007_2.outputs[12].hide = True
	    group_input_007_2.outputs[13].hide = True
	
	    #node Group Input.006
	    group_input_006_2 = clump_hair_curves.nodes.new("NodeGroupInput")
	    group_input_006_2.name = "Group Input.006"
	    group_input_006_2.outputs[0].hide = True
	    group_input_006_2.outputs[1].hide = True
	    group_input_006_2.outputs[2].hide = True
	    group_input_006_2.outputs[3].hide = True
	    group_input_006_2.outputs[4].hide = True
	    group_input_006_2.outputs[5].hide = True
	    group_input_006_2.outputs[6].hide = True
	    group_input_006_2.outputs[7].hide = True
	    group_input_006_2.outputs[8].hide = True
	    group_input_006_2.outputs[9].hide = True
	    group_input_006_2.outputs[11].hide = True
	    group_input_006_2.outputs[12].hide = True
	    group_input_006_2.outputs[13].hide = True
	
	    #node Compare.005
	    compare_005_1 = clump_hair_curves.nodes.new("FunctionNodeCompare")
	    compare_005_1.name = "Compare.005"
	    compare_005_1.hide = True
	    compare_005_1.data_type = 'FLOAT'
	    compare_005_1.mode = 'ELEMENT'
	    compare_005_1.operation = 'LESS_EQUAL'
	
	    #node Map Range.001
	    map_range_001_1 = clump_hair_curves.nodes.new("ShaderNodeMapRange")
	    map_range_001_1.name = "Map Range.001"
	    map_range_001_1.hide = True
	    map_range_001_1.clamp = True
	    map_range_001_1.data_type = 'FLOAT'
	    map_range_001_1.interpolation_type = 'SMOOTHSTEP'
	    map_range_001_1.inputs[3].hide = True
	    map_range_001_1.inputs[4].hide = True
	    map_range_001_1.inputs[5].hide = True
	    map_range_001_1.inputs[6].hide = True
	    map_range_001_1.inputs[7].hide = True
	    map_range_001_1.inputs[8].hide = True
	    map_range_001_1.inputs[9].hide = True
	    map_range_001_1.inputs[10].hide = True
	    map_range_001_1.inputs[11].hide = True
	    map_range_001_1.outputs[1].hide = True
	    #To Min
	    map_range_001_1.inputs[3].default_value = 1.0
	    #To Max
	    map_range_001_1.inputs[4].default_value = 0.0
	
	    #node Boolean Math
	    boolean_math_2 = clump_hair_curves.nodes.new("FunctionNodeBooleanMath")
	    boolean_math_2.name = "Boolean Math"
	    boolean_math_2.hide = True
	    boolean_math_2.operation = 'AND'
	
	    #node Switch.004
	    switch_004_1 = clump_hair_curves.nodes.new("GeometryNodeSwitch")
	    switch_004_1.name = "Switch.004"
	    switch_004_1.input_type = 'FLOAT'
	
	
	
	
	    #Set parents
	    frame_004_2.parent = frame_006_1
	    capture_attribute_002_2.parent = frame_001_2
	    spline_resolution.parent = frame_001_2
	    set_spline_type_002.parent = frame_001_2
	    reroute_021_1.parent = frame_4
	    switch_006.parent = frame_4
	    compare_004_3.parent = frame_4
	    set_spline_resolution_001.parent = frame_4
	    set_spline_type_001.parent = frame_4
	    group_005.parent = frame_003_2
	    group_input_010_1.parent = frame_003_2
	    vector_math_3.parent = frame_005_1
	    sample_curve.parent = frame_005_1
	    spline_parameter.parent = frame_005_1
	    vector_math_001_3.parent = frame_005_1
	    vector_math_002_2.parent = frame_005_1
	    separate_xyz_1.parent = frame_005_1
	    vector_math_006_2.parent = frame_005_1
	    evaluate_on_domain_1.parent = frame_005_1
	    combine_xyz_1.parent = frame_005_1
	    vector_math_004_3.parent = frame_005_1
	    vector_math_005_1.parent = frame_005_1
	    reroute_4.parent = frame_005_1
	    vector_math_008_2.parent = frame_005_1
	    vector_math_003_2.parent = frame_005_1
	    sample_curve_001_1.parent = frame_005_1
	    evaluate_at_index_3.parent = frame_005_1
	    group_3.parent = frame_005_1
	    reroute_001_4.parent = frame_005_1
	    evaluate_on_domain_001_2.parent = frame_006_1
	    sample_index_1.parent = frame_007_1
	    accumulate_field_002.parent = frame_007_1
	    group_input_002_2.parent = frame_007_1
	    reroute_032.parent = frame_007_1
	    boolean_math_001.parent = frame_007_1
	    switch_001_5.parent = frame_007_1
	    named_attribute_003.parent = frame_007_1
	    group_input_013.parent = frame_007_1
	    group_input_004_2.parent = frame_007_1
	    reroute_006_2.parent = frame_007_1
	    compare_003_2.parent = frame_007_1
	    group_input_011.parent = frame_007_1
	    accumulate_field_1.parent = frame_007_1
	    switch_003_4.parent = frame_007_1
	    compare_001_2.parent = frame_007_1
	    group_003_1.parent = frame_007_1
	    boolean_math_002_2.parent = frame_007_1
	    sample_index_001_1.parent = frame_007_1
	    capture_attribute_001_2.parent = frame_007_1
	    position_1.parent = frame_006_1
	    mix_1.parent = frame_006_1
	    vector_math_009_2.parent = frame_006_1
	    math_002_1.parent = frame_006_1
	    set_position_2.parent = frame_006_1
	    group_input_001_3.parent = frame_006_1
	    math_4.parent = frame_006_1
	    vector_math_013_1.parent = frame_006_1
	    vector_math_007_2.parent = frame_006_1
	    vector_math_011_1.parent = frame_006_1
	    reroute_020_2.parent = frame_006_1
	    math_001_2.parent = frame_006_1
	    reroute_004_3.parent = frame_006_1
	    vector_math_025.parent = frame_002_3
	    switch_002_3.parent = frame_002_3
	    vector_math_020.parent = frame_002_3
	    vector_math_021.parent = frame_002_3
	    vector_math_022.parent = frame_002_3
	    vector_math_015.parent = frame_002_3
	    vector_math_016.parent = frame_002_3
	    vector_math_018.parent = frame_002_3
	    vector_math_019.parent = frame_002_3
	    vector_math_014_1.parent = frame_002_3
	    switch_4.parent = frame_002_3
	    sample_curve_002.parent = frame_002_3
	    reroute_011_2.parent = frame_002_3
	    vector_math_017.parent = frame_002_3
	    random_value_1.parent = frame_002_3
	    vector_math_026.parent = frame_002_3
	    separate_xyz_002_1.parent = frame_002_3
	    separate_xyz_001_1.parent = frame_002_3
	    reroute_009_2.parent = frame_002_3
	    vector_math_012_1.parent = frame_002_3
	    group_input_009_1.parent = frame_002_3
	    group_input_012.parent = frame_002_3
	    group_input_008_1.parent = frame_002_3
	    random_value_001_2.parent = frame_002_3
	    reroute_028_1.parent = frame_002_3
	    evaluate_at_index_001_1.parent = frame_002_3
	    group_006.parent = frame_002_3
	    group_007.parent = frame_002_3
	    random_value_004_1.parent = frame_002_3
	    group_input_005_2.parent = frame_002_3
	    compare_3.parent = frame_002_3
	    compare_002_2.parent = frame_002_3
	    math_003_2.parent = frame_004_2
	    vector_math_010_1.parent = frame_004_2
	    compare_006.parent = frame_004_2
	    compare_007.parent = frame_004_2
	    reroute_030.parent = frame_004_2
	    group_input_007_2.parent = frame_004_2
	    group_input_006_2.parent = frame_004_2
	    compare_005_1.parent = frame_004_2
	    map_range_001_1.parent = frame_004_2
	    boolean_math_2.parent = frame_004_2
	    switch_004_1.parent = frame_004_2
	
	    #Set locations
	    frame_001_2.location = (-7469.2802734375, -29.96002197265625)
	    frame_4.location = (-730.2764282226562, -105.79998779296875)
	    frame_003_2.location = (-1181.280029296875, -156.6800537109375)
	    frame_005_1.location = (-4988.64013671875, -297.1200256347656)
	    frame_006_1.location = (-2652.47998046875, -120.20001220703125)
	    frame_007_1.location = (-6576.48046875, -63.3199462890625)
	    frame_002_3.location = (-4987.23046875, -794.1199951171875)
	    frame_004_2.location = (30.239990234375, -220.80001831054688)
	    group_input_003_3.location = (-8175.67333984375, 29.46435546875)
	    reroute_014_3.location = (-7339.32568359375, 411.67431640625)
	    reroute_015_3.location = (-7339.32568359375, 371.48828125)
	    reroute_013_3.location = (-7339.32568359375, 331.30224609375)
	    reroute_012_3.location = (-7339.32568359375, 451.860595703125)
	    separate_components_2.location = (-7958.42626953125, 110.1392822265625)
	    group_output_001.location = (75.0, 50.0)
	    join_geometry_001_2.location = (-125.9296875, 50.0)
	    reroute_016_3.location = (-427.3251953125, 391.581298828125)
	    reroute_017_3.location = (-427.3251953125, 351.395263671875)
	    reroute_019_2.location = (-427.3251953125, 311.209228515625)
	    reroute_018_3.location = (-427.3251953125, 271.023193359375)
	    capture_attribute_2.location = (-6837.00048828125, -211.2093505859375)
	    position_001_1.location = (-7037.93017578125, -432.2325439453125)
	    capture_attribute_002_2.location = (210.68701171875, -40.468505859375)
	    spline_resolution.location = (29.85009765625, -221.3057861328125)
	    set_spline_type_002.location = (391.05126953125, -46.22802734375)
	    reroute_021_1.location = (37.91998291015625, -301.72882080078125)
	    switch_006.location = (299.1292724609375, -161.07763671875)
	    compare_004_3.location = (118.29205322265625, -161.07763671875)
	    set_spline_resolution_001.location = (299.1292724609375, -40.51953125)
	    set_spline_type_001.location = (118.29205322265625, -40.51953125)
	    reroute_025.location = (-3984.263427734375, -200.02154541015625)
	    group_005.location = (231.0631103515625, -40.19573974609375)
	    group_input_010_1.location = (30.1328125, -120.56784057617188)
	    reroute_003_2.location = (-5089.3798828125, -196.87579345703125)
	    reroute_005_2.location = (-4325.8447265625, -196.87579345703125)
	    reroute_002_2.location = (-5089.3798828125, -237.06182861328125)
	    reroute_010_1.location = (-5350.5888671875, -1583.29443359375)
	    reroute_022_1.location = (-2075.42626953125, -1583.29443359375)
	    reroute_023_1.location = (-5390.77490234375, -1643.573486328125)
	    reroute_024_1.location = (-2035.240234375, -1643.573486328125)
	    vector_math_3.location = (1356.88671875, -130.41342163085938)
	    sample_curve.location = (1155.95654296875, -29.9482421875)
	    spline_parameter.location = (974.646240234375, -116.07986450195312)
	    vector_math_001_3.location = (1537.250732421875, -112.93405151367188)
	    vector_math_002_2.location = (1537.250732421875, -153.1201171875)
	    separate_xyz_1.location = (1155.4833984375, -213.399169921875)
	    vector_math_006_2.location = (1718.088134765625, -133.02706909179688)
	    evaluate_on_domain_1.location = (974.646240234375, -213.399169921875)
	    combine_xyz_1.location = (793.80908203125, -213.399169921875)
	    vector_math_004_3.location = (612.9716796875, -293.7712707519531)
	    vector_math_005_1.location = (612.9716796875, -253.58523559570312)
	    reroute_4.location = (572.78564453125, -293.7712707519531)
	    vector_math_008_2.location = (391.94873046875, -253.58523559570312)
	    vector_math_003_2.location = (391.94873046875, -173.213134765625)
	    sample_curve_001_1.location = (211.111328125, -133.02706909179688)
	    evaluate_at_index_3.location = (211.111328125, -273.6782531738281)
	    group_3.location = (30.27392578125, -313.8642883300781)
	    reroute_001_4.location = (170.92529296875, -253.58523559570312)
	    reroute_008_2.location = (-4004.3564453125, -237.06182861328125)
	    reroute_007_2.location = (-2919.333251953125, -237.06182861328125)
	    reroute_026_1.location = (-2738.49609375, -96.41070556640625)
	    reroute_027_1.location = (-5.84478759765625, -96.41070556640625)
	    evaluate_on_domain_001_2.location = (195.2861328125, -699.5595092773438)
	    sample_index_1.location = (323.0927734375, -85.3118896484375)
	    accumulate_field_002.location = (323.0927734375, -125.4979248046875)
	    group_input_002_2.location = (323.0927734375, -165.6839599609375)
	    reroute_032.location = (242.720703125, -185.777099609375)
	    boolean_math_001.location = (557.85546875, -91.071533203125)
	    switch_001_5.location = (959.7158203125, -211.629638671875)
	    named_attribute_003.location = (55.52978515625, -211.629638671875)
	    group_input_013.location = (75.623046875, -392.4669189453125)
	    group_input_004_2.location = (75.623046875, -332.1878662109375)
	    reroute_006_2.location = (231.21435546875, -604.0736083984375)
	    compare_003_2.location = (291.49365234375, -443.3294677734375)
	    group_input_011.location = (30.28466796875, -583.9808349609375)
	    accumulate_field_1.location = (472.3310546875, -443.3294677734375)
	    switch_003_4.location = (961.23046875, -359.1385498046875)
	    compare_001_2.location = (323.0927734375, -45.1258544921875)
	    group_003_1.location = (303.0, -246.05615234375)
	    boolean_math_002_2.location = (765.68115234375, -125.6689453125)
	    sample_index_001_1.location = (633.2236328125, -425.7286376953125)
	    reroute_029.location = (-5204.09326171875, -301.3953552246094)
	    capture_attribute_001_2.location = (1171.45703125, -157.7032470703125)
	    position_1.location = (864.200927734375, -241.47442626953125)
	    mix_1.location = (1065.131103515625, -161.10232543945312)
	    vector_math_009_2.location = (864.200927734375, -301.75347900390625)
	    math_002_1.location = (864.200927734375, -120.916259765625)
	    set_position_2.location = (1245.96826171875, -40.544189453125)
	    group_input_001_3.location = (393.985107421875, -116.75531005859375)
	    math_4.location = (201.131103515625, -583.0558471679688)
	    vector_math_013_1.location = (402.061279296875, -643.3348999023438)
	    vector_math_007_2.location = (402.061279296875, -603.1488647460938)
	    vector_math_011_1.location = (582.8984375, -623.2418823242188)
	    reroute_020_2.location = (160.945068359375, -683.5209350585938)
	    math_001_2.location = (631.866455078125, -114.27447509765625)
	    reroute_004_3.location = (40.386962890625, -603.1488647460938)
	    vector_math_025.location = (1808.00927734375, -300.99072265625)
	    switch_002_3.location = (1586.98583984375, -381.363037109375)
	    vector_math_020.location = (1225.3115234375, -381.363037109375)
	    vector_math_021.location = (1225.3115234375, -421.549072265625)
	    vector_math_022.location = (1386.0556640625, -401.4560546875)
	    vector_math_015.location = (1224.838134765625, -186.19219970703125)
	    vector_math_016.location = (1224.838134765625, -226.37823486328125)
	    vector_math_018.location = (1385.58251953125, -206.28521728515625)
	    vector_math_019.location = (1385.58251953125, -246.4713134765625)
	    vector_math_014_1.location = (1224.838134765625, -266.5643310546875)
	    switch_4.location = (1586.5126953125, -226.37823486328125)
	    sample_curve_002.location = (963.62890625, -105.820068359375)
	    reroute_011_2.location = (37.919921875, -271.0601806640625)
	    vector_math_017.location = (1223.915283203125, -132.5950927734375)
	    random_value_1.location = (606.84326171875, -281.6739501953125)
	    vector_math_026.location = (787.6806640625, -402.2320556640625)
	    separate_xyz_002_1.location = (968.517578125, -402.2320556640625)
	    separate_xyz_001_1.location = (968.517578125, -261.5809326171875)
	    reroute_009_2.location = (727.4013671875, -542.8831787109375)
	    vector_math_012_1.location = (787.6806640625, -261.5809326171875)
	    group_input_009_1.location = (506.3779296875, -542.8831787109375)
	    group_input_012.location = (1209.6337890625, -40.5576171875)
	    group_input_008_1.location = (606.84326171875, -321.8599853515625)
	    random_value_001_2.location = (606.84326171875, -442.4180908203125)
	    reroute_028_1.location = (533.3916015625, -362.7786865234375)
	    evaluate_at_index_001_1.location = (332.46142578125, -463.243896484375)
	    group_006.location = (131.53125, -543.615966796875)
	    group_007.location = (412.83349609375, -222.1275634765625)
	    random_value_004_1.location = (332.46142578125, -302.4996337890625)
	    group_input_005_2.location = (151.6240234375, -362.7786865234375)
	    compare_3.location = (1390.47119140625, -60.650634765625)
	    compare_002_2.location = (963.62890625, -567.9595947265625)
	    spline_parameter_001.location = (-3013.938720703125, -662.9942016601562)
	    group_input_4.location = (-3013.938720703125, -723.2733154296875)
	    group_001_3.location = (-2833.10205078125, -622.8081665039062)
	    math_003_2.location = (210.9765625, -180.57009887695312)
	    vector_math_010_1.location = (210.9765625, -140.384033203125)
	    compare_006.location = (210.9765625, -60.011932373046875)
	    compare_007.location = (210.9765625, -100.19796752929688)
	    reroute_030.location = (391.813720703125, -180.57009887695312)
	    group_input_007_2.location = (30.139404296875, -180.57009887695312)
	    group_input_006_2.location = (30.139404296875, -120.291015625)
	    compare_005_1.location = (431.999755859375, -180.57009887695312)
	    map_range_001_1.location = (431.999755859375, -140.384033203125)
	    boolean_math_2.location = (431.999755859375, -80.10494995117188)
	    switch_004_1.location = (612.8369140625, -39.918914794921875)
	
	    #Set dimensions
	    frame_001_2.width, frame_001_2.height = 561.43994140625, 301.7200012207031
	    frame_4.width, frame_4.height = 469.4764099121094, 339.6488037109375
	    frame_003_2.width, frame_003_2.height = 401.1199951171875, 231.63995361328125
	    frame_005_1.width, frame_005_1.height = 1888.159912109375, 450.2400207519531
	    frame_006_1.width, frame_006_1.height = 1416.3199462890625, 853.7200317382812
	    frame_007_1.width, frame_007_1.height = 1341.92041015625, 665.8001708984375
	    frame_002_3.width, frame_002_3.height = 1977.9501953125, 639.6400146484375
	    frame_004_2.width, frame_004_2.height = 783.199951171875, 309.3999938964844
	    group_input_003_3.width, group_input_003_3.height = 140.0, 100.0
	    reroute_014_3.width, reroute_014_3.height = 100.0, 100.0
	    reroute_015_3.width, reroute_015_3.height = 100.0, 100.0
	    reroute_013_3.width, reroute_013_3.height = 100.0, 100.0
	    reroute_012_3.width, reroute_012_3.height = 100.0, 100.0
	    separate_components_2.width, separate_components_2.height = 140.0, 100.0
	    group_output_001.width, group_output_001.height = 140.0, 100.0
	    join_geometry_001_2.width, join_geometry_001_2.height = 140.0, 100.0
	    reroute_016_3.width, reroute_016_3.height = 100.0, 100.0
	    reroute_017_3.width, reroute_017_3.height = 100.0, 100.0
	    reroute_019_2.width, reroute_019_2.height = 100.0, 100.0
	    reroute_018_3.width, reroute_018_3.height = 100.0, 100.0
	    capture_attribute_2.width, capture_attribute_2.height = 140.0, 100.0
	    position_001_1.width, position_001_1.height = 140.0, 100.0
	    capture_attribute_002_2.width, capture_attribute_002_2.height = 140.0, 100.0
	    spline_resolution.width, spline_resolution.height = 140.0, 100.0
	    set_spline_type_002.width, set_spline_type_002.height = 140.0, 100.0
	    reroute_021_1.width, reroute_021_1.height = 100.0, 100.0
	    switch_006.width, switch_006.height = 140.0, 100.0
	    compare_004_3.width, compare_004_3.height = 140.0, 100.0
	    set_spline_resolution_001.width, set_spline_resolution_001.height = 140.0, 100.0
	    set_spline_type_001.width, set_spline_type_001.height = 140.0, 100.0
	    reroute_025.width, reroute_025.height = 100.0, 100.0
	    group_005.width, group_005.height = 140.0, 100.0
	    group_input_010_1.width, group_input_010_1.height = 140.0, 100.0
	    reroute_003_2.width, reroute_003_2.height = 100.0, 100.0
	    reroute_005_2.width, reroute_005_2.height = 100.0, 100.0
	    reroute_002_2.width, reroute_002_2.height = 100.0, 100.0
	    reroute_010_1.width, reroute_010_1.height = 100.0, 100.0
	    reroute_022_1.width, reroute_022_1.height = 100.0, 100.0
	    reroute_023_1.width, reroute_023_1.height = 100.0, 100.0
	    reroute_024_1.width, reroute_024_1.height = 100.0, 100.0
	    vector_math_3.width, vector_math_3.height = 140.0, 100.0
	    sample_curve.width, sample_curve.height = 140.0, 100.0
	    spline_parameter.width, spline_parameter.height = 140.0, 100.0
	    vector_math_001_3.width, vector_math_001_3.height = 140.0, 100.0
	    vector_math_002_2.width, vector_math_002_2.height = 140.0, 100.0
	    separate_xyz_1.width, separate_xyz_1.height = 140.0, 100.0
	    vector_math_006_2.width, vector_math_006_2.height = 140.0, 100.0
	    evaluate_on_domain_1.width, evaluate_on_domain_1.height = 140.0, 100.0
	    combine_xyz_1.width, combine_xyz_1.height = 140.0, 100.0
	    vector_math_004_3.width, vector_math_004_3.height = 140.0, 100.0
	    vector_math_005_1.width, vector_math_005_1.height = 140.0, 100.0
	    reroute_4.width, reroute_4.height = 100.0, 100.0
	    vector_math_008_2.width, vector_math_008_2.height = 140.0, 100.0
	    vector_math_003_2.width, vector_math_003_2.height = 140.0, 100.0
	    sample_curve_001_1.width, sample_curve_001_1.height = 140.0, 100.0
	    evaluate_at_index_3.width, evaluate_at_index_3.height = 140.0, 100.0
	    group_3.width, group_3.height = 140.0, 100.0
	    reroute_001_4.width, reroute_001_4.height = 100.0, 100.0
	    reroute_008_2.width, reroute_008_2.height = 100.0, 100.0
	    reroute_007_2.width, reroute_007_2.height = 100.0, 100.0
	    reroute_026_1.width, reroute_026_1.height = 100.0, 100.0
	    reroute_027_1.width, reroute_027_1.height = 100.0, 100.0
	    evaluate_on_domain_001_2.width, evaluate_on_domain_001_2.height = 140.0, 100.0
	    sample_index_1.width, sample_index_1.height = 140.0, 100.0
	    accumulate_field_002.width, accumulate_field_002.height = 140.0, 100.0
	    group_input_002_2.width, group_input_002_2.height = 140.0, 100.0
	    reroute_032.width, reroute_032.height = 100.0, 100.0
	    boolean_math_001.width, boolean_math_001.height = 140.0, 100.0
	    switch_001_5.width, switch_001_5.height = 140.0, 100.0
	    named_attribute_003.width, named_attribute_003.height = 167.335205078125, 100.0
	    group_input_013.width, group_input_013.height = 140.0, 100.0
	    group_input_004_2.width, group_input_004_2.height = 140.0, 100.0
	    reroute_006_2.width, reroute_006_2.height = 100.0, 100.0
	    compare_003_2.width, compare_003_2.height = 140.0, 100.0
	    group_input_011.width, group_input_011.height = 140.0, 100.0
	    accumulate_field_1.width, accumulate_field_1.height = 140.0, 100.0
	    switch_003_4.width, switch_003_4.height = 140.0, 100.0
	    compare_001_2.width, compare_001_2.height = 140.0, 100.0
	    group_003_1.width, group_003_1.height = 201.331298828125, 100.0
	    boolean_math_002_2.width, boolean_math_002_2.height = 140.0, 100.0
	    sample_index_001_1.width, sample_index_001_1.height = 140.0, 100.0
	    reroute_029.width, reroute_029.height = 100.0, 100.0
	    capture_attribute_001_2.width, capture_attribute_001_2.height = 140.0, 100.0
	    position_1.width, position_1.height = 140.0, 100.0
	    mix_1.width, mix_1.height = 140.0, 100.0
	    vector_math_009_2.width, vector_math_009_2.height = 140.0, 100.0
	    math_002_1.width, math_002_1.height = 140.0, 100.0
	    set_position_2.width, set_position_2.height = 140.0, 100.0
	    group_input_001_3.width, group_input_001_3.height = 140.0, 100.0
	    math_4.width, math_4.height = 140.0, 100.0
	    vector_math_013_1.width, vector_math_013_1.height = 140.0, 100.0
	    vector_math_007_2.width, vector_math_007_2.height = 140.0, 100.0
	    vector_math_011_1.width, vector_math_011_1.height = 140.0, 100.0
	    reroute_020_2.width, reroute_020_2.height = 100.0, 100.0
	    math_001_2.width, math_001_2.height = 140.0, 100.0
	    reroute_004_3.width, reroute_004_3.height = 100.0, 100.0
	    vector_math_025.width, vector_math_025.height = 140.0, 100.0
	    switch_002_3.width, switch_002_3.height = 140.0, 100.0
	    vector_math_020.width, vector_math_020.height = 140.0, 100.0
	    vector_math_021.width, vector_math_021.height = 140.0, 100.0
	    vector_math_022.width, vector_math_022.height = 140.0, 100.0
	    vector_math_015.width, vector_math_015.height = 140.0, 100.0
	    vector_math_016.width, vector_math_016.height = 140.0, 100.0
	    vector_math_018.width, vector_math_018.height = 140.0, 100.0
	    vector_math_019.width, vector_math_019.height = 140.0, 100.0
	    vector_math_014_1.width, vector_math_014_1.height = 140.0, 100.0
	    switch_4.width, switch_4.height = 140.0, 100.0
	    sample_curve_002.width, sample_curve_002.height = 140.0, 100.0
	    reroute_011_2.width, reroute_011_2.height = 100.0, 100.0
	    vector_math_017.width, vector_math_017.height = 140.0, 100.0
	    random_value_1.width, random_value_1.height = 140.0, 100.0
	    vector_math_026.width, vector_math_026.height = 140.0, 100.0
	    separate_xyz_002_1.width, separate_xyz_002_1.height = 140.0, 100.0
	    separate_xyz_001_1.width, separate_xyz_001_1.height = 140.0, 100.0
	    reroute_009_2.width, reroute_009_2.height = 100.0, 100.0
	    vector_math_012_1.width, vector_math_012_1.height = 140.0, 100.0
	    group_input_009_1.width, group_input_009_1.height = 140.0, 100.0
	    group_input_012.width, group_input_012.height = 140.0, 100.0
	    group_input_008_1.width, group_input_008_1.height = 140.0, 100.0
	    random_value_001_2.width, random_value_001_2.height = 140.0, 100.0
	    reroute_028_1.width, reroute_028_1.height = 100.0, 100.0
	    evaluate_at_index_001_1.width, evaluate_at_index_001_1.height = 140.0, 100.0
	    group_006.width, group_006.height = 140.0, 100.0
	    group_007.width, group_007.height = 140.0, 100.0
	    random_value_004_1.width, random_value_004_1.height = 140.0, 100.0
	    group_input_005_2.width, group_input_005_2.height = 140.0, 100.0
	    compare_3.width, compare_3.height = 140.0, 100.0
	    compare_002_2.width, compare_002_2.height = 140.0, 100.0
	    spline_parameter_001.width, spline_parameter_001.height = 140.0, 100.0
	    group_input_4.width, group_input_4.height = 140.0, 100.0
	    group_001_3.width, group_001_3.height = 140.0, 100.0
	    math_003_2.width, math_003_2.height = 140.0, 100.0
	    vector_math_010_1.width, vector_math_010_1.height = 140.0, 100.0
	    compare_006.width, compare_006.height = 140.0, 100.0
	    compare_007.width, compare_007.height = 140.0, 100.0
	    reroute_030.width, reroute_030.height = 100.0, 100.0
	    group_input_007_2.width, group_input_007_2.height = 140.0, 100.0
	    group_input_006_2.width, group_input_006_2.height = 140.0, 100.0
	    compare_005_1.width, compare_005_1.height = 140.0, 100.0
	    map_range_001_1.width, map_range_001_1.height = 140.0, 100.0
	    boolean_math_2.width, boolean_math_2.height = 140.0, 100.0
	    switch_004_1.width, switch_004_1.height = 140.0, 100.0
	
	    #initialize clump_hair_curves links
	    #group_input_003_3.Geometry -> separate_components_2.Geometry
	    clump_hair_curves.links.new(group_input_003_3.outputs[0], separate_components_2.inputs[0])
	    #reroute_032.Output -> group_003_1.Geometry
	    clump_hair_curves.links.new(reroute_032.outputs[0], group_003_1.inputs[0])
	    #accumulate_field_002.Total -> sample_index_1.Value
	    clump_hair_curves.links.new(accumulate_field_002.outputs[2], sample_index_1.inputs[1])
	    #reroute_032.Output -> sample_index_1.Geometry
	    clump_hair_curves.links.new(reroute_032.outputs[0], sample_index_1.inputs[0])
	    #named_attribute_003.Exists -> accumulate_field_002.Value
	    clump_hair_curves.links.new(named_attribute_003.outputs[1], accumulate_field_002.inputs[0])
	    #sample_index_1.Value -> compare_001_2.A
	    clump_hair_curves.links.new(sample_index_1.outputs[0], compare_001_2.inputs[2])
	    #group_003_1.Geometry -> switch_001_5.False
	    clump_hair_curves.links.new(group_003_1.outputs[0], switch_001_5.inputs[1])
	    #reroute_032.Output -> switch_001_5.True
	    clump_hair_curves.links.new(reroute_032.outputs[0], switch_001_5.inputs[2])
	    #compare_001_2.Result -> boolean_math_001.Boolean
	    clump_hair_curves.links.new(compare_001_2.outputs[0], boolean_math_001.inputs[0])
	    #boolean_math_002_2.Boolean -> switch_001_5.Switch
	    clump_hair_curves.links.new(boolean_math_002_2.outputs[0], switch_001_5.inputs[0])
	    #reroute_008_2.Output -> sample_curve.Curve Index
	    clump_hair_curves.links.new(reroute_008_2.outputs[0], sample_curve.inputs[4])
	    #reroute_025.Output -> sample_curve.Curves
	    clump_hair_curves.links.new(reroute_025.outputs[0], sample_curve.inputs[0])
	    #sample_curve.Tangent -> vector_math_3.Vector
	    clump_hair_curves.links.new(sample_curve.outputs[2], vector_math_3.inputs[0])
	    #sample_curve.Normal -> vector_math_3.Vector
	    clump_hair_curves.links.new(sample_curve.outputs[3], vector_math_3.inputs[1])
	    #sample_curve_001_1.Tangent -> vector_math_003_2.Vector
	    clump_hair_curves.links.new(sample_curve_001_1.outputs[2], vector_math_003_2.inputs[0])
	    #sample_curve_001_1.Normal -> vector_math_003_2.Vector
	    clump_hair_curves.links.new(sample_curve_001_1.outputs[3], vector_math_003_2.inputs[1])
	    #vector_math_003_2.Vector -> vector_math_004_3.Vector
	    clump_hair_curves.links.new(vector_math_003_2.outputs[0], vector_math_004_3.inputs[0])
	    #sample_curve_001_1.Normal -> vector_math_005_1.Vector
	    clump_hair_curves.links.new(sample_curve_001_1.outputs[3], vector_math_005_1.inputs[0])
	    #reroute_003_2.Output -> sample_curve_001_1.Curves
	    clump_hair_curves.links.new(reroute_003_2.outputs[0], sample_curve_001_1.inputs[0])
	    #reroute_001_4.Output -> sample_curve_001_1.Curve Index
	    clump_hair_curves.links.new(reroute_001_4.outputs[0], sample_curve_001_1.inputs[4])
	    #evaluate_on_domain_1.Value -> separate_xyz_1.Vector
	    clump_hair_curves.links.new(evaluate_on_domain_1.outputs[0], separate_xyz_1.inputs[0])
	    #sample_curve.Normal -> vector_math_001_3.Vector
	    clump_hair_curves.links.new(sample_curve.outputs[3], vector_math_001_3.inputs[0])
	    #separate_xyz_1.X -> vector_math_001_3.Scale
	    clump_hair_curves.links.new(separate_xyz_1.outputs[0], vector_math_001_3.inputs[3])
	    #vector_math_3.Vector -> vector_math_002_2.Vector
	    clump_hair_curves.links.new(vector_math_3.outputs[0], vector_math_002_2.inputs[0])
	    #separate_xyz_1.Y -> vector_math_002_2.Scale
	    clump_hair_curves.links.new(separate_xyz_1.outputs[1], vector_math_002_2.inputs[3])
	    #vector_math_001_3.Vector -> vector_math_006_2.Vector
	    clump_hair_curves.links.new(vector_math_001_3.outputs[0], vector_math_006_2.inputs[0])
	    #vector_math_002_2.Vector -> vector_math_006_2.Vector
	    clump_hair_curves.links.new(vector_math_002_2.outputs[0], vector_math_006_2.inputs[1])
	    #vector_math_005_1.Value -> combine_xyz_1.X
	    clump_hair_curves.links.new(vector_math_005_1.outputs[1], combine_xyz_1.inputs[0])
	    #vector_math_004_3.Value -> combine_xyz_1.Y
	    clump_hair_curves.links.new(vector_math_004_3.outputs[1], combine_xyz_1.inputs[1])
	    #combine_xyz_1.Vector -> evaluate_on_domain_1.Value
	    clump_hair_curves.links.new(combine_xyz_1.outputs[0], evaluate_on_domain_1.inputs[0])
	    #reroute_4.Output -> vector_math_005_1.Vector
	    clump_hair_curves.links.new(reroute_4.outputs[0], vector_math_005_1.inputs[1])
	    #reroute_4.Output -> vector_math_004_3.Vector
	    clump_hair_curves.links.new(reroute_4.outputs[0], vector_math_004_3.inputs[1])
	    #group_3.Root Position -> vector_math_008_2.Vector
	    clump_hair_curves.links.new(group_3.outputs[1], vector_math_008_2.inputs[0])
	    #group_3.Root Position -> evaluate_at_index_3.Value
	    clump_hair_curves.links.new(group_3.outputs[1], evaluate_at_index_3.inputs[1])
	    #evaluate_at_index_3.Value -> vector_math_008_2.Vector
	    clump_hair_curves.links.new(evaluate_at_index_3.outputs[0], vector_math_008_2.inputs[1])
	    #reroute_001_4.Output -> evaluate_at_index_3.Index
	    clump_hair_curves.links.new(reroute_001_4.outputs[0], evaluate_at_index_3.inputs[0])
	    #reroute_002_2.Output -> reroute_001_4.Input
	    clump_hair_curves.links.new(reroute_002_2.outputs[0], reroute_001_4.inputs[0])
	    #mix_1.Result -> set_position_2.Position
	    clump_hair_curves.links.new(mix_1.outputs[1], set_position_2.inputs[2])
	    #vector_math_011_1.Vector -> vector_math_009_2.Vector
	    clump_hair_curves.links.new(vector_math_011_1.outputs[0], vector_math_009_2.inputs[1])
	    #sample_curve.Position -> vector_math_009_2.Vector
	    clump_hair_curves.links.new(sample_curve.outputs[1], vector_math_009_2.inputs[0])
	    #vector_math_006_2.Vector -> vector_math_007_2.Vector
	    clump_hair_curves.links.new(vector_math_006_2.outputs[0], vector_math_007_2.inputs[0])
	    #reroute_020_2.Output -> math_4.Value
	    clump_hair_curves.links.new(reroute_020_2.outputs[0], math_4.inputs[1])
	    #math_4.Value -> vector_math_007_2.Scale
	    clump_hair_curves.links.new(math_4.outputs[0], vector_math_007_2.inputs[3])
	    #vector_math_009_2.Vector -> mix_1.B
	    clump_hair_curves.links.new(vector_math_009_2.outputs[0], mix_1.inputs[5])
	    #position_1.Position -> mix_1.A
	    clump_hair_curves.links.new(position_1.outputs[0], mix_1.inputs[4])
	    #reroute_029.Output -> reroute_002_2.Input
	    clump_hair_curves.links.new(reroute_029.outputs[0], reroute_002_2.inputs[0])
	    #spline_parameter_001.Factor -> group_001_3.Value
	    clump_hair_curves.links.new(spline_parameter_001.outputs[0], group_001_3.inputs[0])
	    #group_input_4.Shape -> group_001_3.Shape
	    clump_hair_curves.links.new(group_input_4.outputs[6], group_001_3.inputs[3])
	    #group_001_3.Value -> reroute_004_3.Input
	    clump_hair_curves.links.new(group_001_3.outputs[0], reroute_004_3.inputs[0])
	    #reroute_004_3.Output -> math_001_2.Value
	    clump_hair_curves.links.new(reroute_004_3.outputs[0], math_001_2.inputs[0])
	    #group_input_001_3.Factor -> math_001_2.Value
	    clump_hair_curves.links.new(group_input_001_3.outputs[5], math_001_2.inputs[1])
	    #math_002_1.Value -> mix_1.Factor
	    clump_hair_curves.links.new(math_002_1.outputs[0], mix_1.inputs[0])
	    #group_input_002_2.Existing Guide Map -> boolean_math_001.Boolean
	    clump_hair_curves.links.new(group_input_002_2.outputs[4], boolean_math_001.inputs[1])
	    #group_input_004_2.Guide Distance -> group_003_1.Guide Distance
	    clump_hair_curves.links.new(group_input_004_2.outputs[2], group_003_1.inputs[2])
	    #reroute_003_2.Output -> reroute_005_2.Input
	    clump_hair_curves.links.new(reroute_003_2.outputs[0], reroute_005_2.inputs[0])
	    #vector_math_008_2.Vector -> reroute_4.Input
	    clump_hair_curves.links.new(vector_math_008_2.outputs[0], reroute_4.inputs[0])
	    #math_001_2.Value -> math_002_1.Value
	    clump_hair_curves.links.new(math_001_2.outputs[0], math_002_1.inputs[0])
	    #vector_math_008_2.Vector -> vector_math_010_1.Vector
	    clump_hair_curves.links.new(vector_math_008_2.outputs[0], vector_math_010_1.inputs[0])
	    #vector_math_010_1.Value -> map_range_001_1.Value
	    clump_hair_curves.links.new(vector_math_010_1.outputs[1], map_range_001_1.inputs[0])
	    #switch_004_1.Output -> math_002_1.Value
	    clump_hair_curves.links.new(switch_004_1.outputs[0], math_002_1.inputs[1])
	    #reroute_030.Output -> map_range_001_1.From Min
	    clump_hair_curves.links.new(reroute_030.outputs[0], map_range_001_1.inputs[1])
	    #group_input_006_2.Distance Threshold -> math_003_2.Value
	    clump_hair_curves.links.new(group_input_006_2.outputs[10], math_003_2.inputs[0])
	    #group_input_007_2.Distance Falloff -> math_003_2.Value
	    clump_hair_curves.links.new(group_input_007_2.outputs[9], math_003_2.inputs[1])
	    #math_003_2.Value -> map_range_001_1.From Max
	    clump_hair_curves.links.new(math_003_2.outputs[0], map_range_001_1.inputs[2])
	    #group_input_008_1.Tip Spread -> vector_math_012_1.Scale
	    clump_hair_curves.links.new(group_input_008_1.outputs[7], vector_math_012_1.inputs[3])
	    #random_value_1.Value -> vector_math_012_1.Vector
	    clump_hair_curves.links.new(random_value_1.outputs[0], vector_math_012_1.inputs[0])
	    #evaluate_on_domain_001_2.Value -> vector_math_013_1.Vector
	    clump_hair_curves.links.new(evaluate_on_domain_001_2.outputs[0], vector_math_013_1.inputs[0])
	    #reroute_020_2.Output -> vector_math_013_1.Scale
	    clump_hair_curves.links.new(reroute_020_2.outputs[0], vector_math_013_1.inputs[3])
	    #vector_math_007_2.Vector -> vector_math_011_1.Vector
	    clump_hair_curves.links.new(vector_math_007_2.outputs[0], vector_math_011_1.inputs[0])
	    #reroute_005_2.Output -> sample_curve_002.Curves
	    clump_hair_curves.links.new(reroute_005_2.outputs[0], sample_curve_002.inputs[0])
	    #vector_math_012_1.Vector -> separate_xyz_001_1.Vector
	    clump_hair_curves.links.new(vector_math_012_1.outputs[0], separate_xyz_001_1.inputs[0])
	    #sample_curve_002.Tangent -> vector_math_014_1.Vector
	    clump_hair_curves.links.new(sample_curve_002.outputs[2], vector_math_014_1.inputs[0])
	    #sample_curve_002.Normal -> vector_math_015.Vector
	    clump_hair_curves.links.new(sample_curve_002.outputs[3], vector_math_015.inputs[0])
	    #separate_xyz_001_1.Z -> vector_math_014_1.Scale
	    clump_hair_curves.links.new(separate_xyz_001_1.outputs[2], vector_math_014_1.inputs[3])
	    #separate_xyz_001_1.X -> vector_math_015.Scale
	    clump_hair_curves.links.new(separate_xyz_001_1.outputs[0], vector_math_015.inputs[3])
	    #sample_curve_002.Tangent -> vector_math_017.Vector
	    clump_hair_curves.links.new(sample_curve_002.outputs[2], vector_math_017.inputs[0])
	    #sample_curve_002.Normal -> vector_math_017.Vector
	    clump_hair_curves.links.new(sample_curve_002.outputs[3], vector_math_017.inputs[1])
	    #separate_xyz_001_1.Y -> vector_math_016.Scale
	    clump_hair_curves.links.new(separate_xyz_001_1.outputs[1], vector_math_016.inputs[3])
	    #vector_math_017.Vector -> vector_math_016.Vector
	    clump_hair_curves.links.new(vector_math_017.outputs[0], vector_math_016.inputs[0])
	    #vector_math_015.Vector -> vector_math_018.Vector
	    clump_hair_curves.links.new(vector_math_015.outputs[0], vector_math_018.inputs[0])
	    #vector_math_016.Vector -> vector_math_018.Vector
	    clump_hair_curves.links.new(vector_math_016.outputs[0], vector_math_018.inputs[1])
	    #vector_math_018.Vector -> vector_math_019.Vector
	    clump_hair_curves.links.new(vector_math_018.outputs[0], vector_math_019.inputs[0])
	    #vector_math_014_1.Vector -> vector_math_019.Vector
	    clump_hair_curves.links.new(vector_math_014_1.outputs[0], vector_math_019.inputs[1])
	    #reroute_011_2.Output -> sample_curve_002.Curve Index
	    clump_hair_curves.links.new(reroute_011_2.outputs[0], sample_curve_002.inputs[4])
	    #vector_math_026.Vector -> separate_xyz_002_1.Vector
	    clump_hair_curves.links.new(vector_math_026.outputs[0], separate_xyz_002_1.inputs[0])
	    #sample_curve_002.Normal -> vector_math_020.Vector
	    clump_hair_curves.links.new(sample_curve_002.outputs[3], vector_math_020.inputs[0])
	    #separate_xyz_002_1.X -> vector_math_020.Scale
	    clump_hair_curves.links.new(separate_xyz_002_1.outputs[0], vector_math_020.inputs[3])
	    #separate_xyz_002_1.Y -> vector_math_021.Scale
	    clump_hair_curves.links.new(separate_xyz_002_1.outputs[1], vector_math_021.inputs[3])
	    #vector_math_020.Vector -> vector_math_022.Vector
	    clump_hair_curves.links.new(vector_math_020.outputs[0], vector_math_022.inputs[0])
	    #vector_math_021.Vector -> vector_math_022.Vector
	    clump_hair_curves.links.new(vector_math_021.outputs[0], vector_math_022.inputs[1])
	    #vector_math_017.Vector -> vector_math_021.Vector
	    clump_hair_curves.links.new(vector_math_017.outputs[0], vector_math_021.inputs[0])
	    #random_value_001_2.Value -> vector_math_026.Vector
	    clump_hair_curves.links.new(random_value_001_2.outputs[0], vector_math_026.inputs[0])
	    #reroute_009_2.Output -> vector_math_026.Scale
	    clump_hair_curves.links.new(reroute_009_2.outputs[0], vector_math_026.inputs[3])
	    #vector_math_013_1.Vector -> vector_math_011_1.Vector
	    clump_hair_curves.links.new(vector_math_013_1.outputs[0], vector_math_011_1.inputs[1])
	    #switch_4.Output -> vector_math_025.Vector
	    clump_hair_curves.links.new(switch_4.outputs[0], vector_math_025.inputs[0])
	    #switch_002_3.Output -> vector_math_025.Vector
	    clump_hair_curves.links.new(switch_002_3.outputs[0], vector_math_025.inputs[1])
	    #vector_math_025.Vector -> evaluate_on_domain_001_2.Value
	    clump_hair_curves.links.new(vector_math_025.outputs[0], evaluate_on_domain_001_2.inputs[0])
	    #vector_math_022.Vector -> switch_002_3.False
	    clump_hair_curves.links.new(vector_math_022.outputs[0], switch_002_3.inputs[1])
	    #vector_math_019.Vector -> switch_4.False
	    clump_hair_curves.links.new(vector_math_019.outputs[0], switch_4.inputs[1])
	    #reroute_009_2.Output -> compare_002_2.B
	    clump_hair_curves.links.new(reroute_009_2.outputs[0], compare_002_2.inputs[1])
	    #compare_002_2.Result -> switch_002_3.Switch
	    clump_hair_curves.links.new(compare_002_2.outputs[0], switch_002_3.inputs[0])
	    #group_input_009_1.Clump Offset -> reroute_009_2.Input
	    clump_hair_curves.links.new(group_input_009_1.outputs[8], reroute_009_2.inputs[0])
	    #reroute_028_1.Output -> random_value_1.Seed
	    clump_hair_curves.links.new(reroute_028_1.outputs[0], random_value_1.inputs[8])
	    #reroute_028_1.Output -> random_value_001_2.Seed
	    clump_hair_curves.links.new(reroute_028_1.outputs[0], random_value_001_2.inputs[8])
	    #reroute_011_2.Output -> evaluate_at_index_001_1.Index
	    clump_hair_curves.links.new(reroute_011_2.outputs[0], evaluate_at_index_001_1.inputs[0])
	    #capture_attribute_2.Geometry -> reroute_032.Input
	    clump_hair_curves.links.new(capture_attribute_2.outputs[0], reroute_032.inputs[0])
	    #capture_attribute_001_2.Geometry -> reroute_003_2.Input
	    clump_hair_curves.links.new(capture_attribute_001_2.outputs[0], reroute_003_2.inputs[0])
	    #reroute_018_3.Output -> join_geometry_001_2.Geometry
	    clump_hair_curves.links.new(reroute_018_3.outputs[0], join_geometry_001_2.inputs[0])
	    #separate_components_2.Mesh -> reroute_012_3.Input
	    clump_hair_curves.links.new(separate_components_2.outputs[0], reroute_012_3.inputs[0])
	    #separate_components_2.Instances -> reroute_013_3.Input
	    clump_hair_curves.links.new(separate_components_2.outputs[5], reroute_013_3.inputs[0])
	    #separate_components_2.Point Cloud -> reroute_014_3.Input
	    clump_hair_curves.links.new(separate_components_2.outputs[3], reroute_014_3.inputs[0])
	    #separate_components_2.Volume -> reroute_015_3.Input
	    clump_hair_curves.links.new(separate_components_2.outputs[4], reroute_015_3.inputs[0])
	    #join_geometry_001_2.Geometry -> group_output_001.Geometry
	    clump_hair_curves.links.new(join_geometry_001_2.outputs[0], group_output_001.inputs[0])
	    #reroute_012_3.Output -> reroute_016_3.Input
	    clump_hair_curves.links.new(reroute_012_3.outputs[0], reroute_016_3.inputs[0])
	    #reroute_014_3.Output -> reroute_017_3.Input
	    clump_hair_curves.links.new(reroute_014_3.outputs[0], reroute_017_3.inputs[0])
	    #reroute_013_3.Output -> reroute_018_3.Input
	    clump_hair_curves.links.new(reroute_013_3.outputs[0], reroute_018_3.inputs[0])
	    #reroute_015_3.Output -> reroute_019_2.Input
	    clump_hair_curves.links.new(reroute_015_3.outputs[0], reroute_019_2.inputs[0])
	    #set_position_2.Geometry -> group_005.Curves
	    clump_hair_curves.links.new(set_position_2.outputs[0], group_005.inputs[0])
	    #position_001_1.Position -> capture_attribute_2.Value
	    clump_hair_curves.links.new(position_001_1.outputs[0], capture_attribute_2.inputs[1])
	    #reroute_022_1.Output -> group_005.Reference Position
	    clump_hair_curves.links.new(reroute_022_1.outputs[0], group_005.inputs[3])
	    #group_input_010_1.Preserve Length -> group_005.Selection
	    clump_hair_curves.links.new(group_input_010_1.outputs[12], group_005.inputs[1])
	    #spline_parameter.Factor -> sample_curve.Factor
	    clump_hair_curves.links.new(spline_parameter.outputs[0], sample_curve.inputs[2])
	    #reroute_006_2.Output -> compare_003_2.A
	    clump_hair_curves.links.new(reroute_006_2.outputs[0], compare_003_2.inputs[2])
	    #named_attribute_003.Attribute -> switch_003_4.False
	    clump_hair_curves.links.new(named_attribute_003.outputs[0], switch_003_4.inputs[1])
	    #compare_003_2.Result -> switch_003_4.Switch
	    clump_hair_curves.links.new(compare_003_2.outputs[0], switch_003_4.inputs[0])
	    #reroute_006_2.Output -> switch_003_4.True
	    clump_hair_curves.links.new(reroute_006_2.outputs[0], switch_003_4.inputs[2])
	    #boolean_math_001.Boolean -> boolean_math_002_2.Boolean
	    clump_hair_curves.links.new(boolean_math_001.outputs[0], boolean_math_002_2.inputs[0])
	    #reroute_027_1.Output -> group_output_001.Guide Index
	    clump_hair_curves.links.new(reroute_027_1.outputs[0], group_output_001.inputs[1])
	    #separate_components_2.Curve -> capture_attribute_002_2.Geometry
	    clump_hair_curves.links.new(separate_components_2.outputs[1], capture_attribute_002_2.inputs[0])
	    #spline_resolution.Resolution -> capture_attribute_002_2.Value
	    clump_hair_curves.links.new(spline_resolution.outputs[0], capture_attribute_002_2.inputs[1])
	    #set_spline_type_001.Curve -> set_spline_resolution_001.Geometry
	    clump_hair_curves.links.new(set_spline_type_001.outputs[0], set_spline_resolution_001.inputs[0])
	    #set_spline_type_002.Curve -> capture_attribute_2.Geometry
	    clump_hair_curves.links.new(set_spline_type_002.outputs[0], capture_attribute_2.inputs[0])
	    #group_006.Curve ID -> evaluate_at_index_001_1.Value
	    clump_hair_curves.links.new(group_006.outputs[1], evaluate_at_index_001_1.inputs[1])
	    #evaluate_at_index_001_1.Value -> random_value_001_2.ID
	    clump_hair_curves.links.new(evaluate_at_index_001_1.outputs[0], random_value_001_2.inputs[7])
	    #group_007.Curve ID -> random_value_1.ID
	    clump_hair_curves.links.new(group_007.outputs[1], random_value_1.inputs[7])
	    #group_input_013.Guide Mask -> group_003_1.Guide Mask
	    clump_hair_curves.links.new(group_input_013.outputs[3], group_003_1.inputs[3])
	    #reroute_021_1.Output -> compare_004_3.A
	    clump_hair_curves.links.new(reroute_021_1.outputs[0], compare_004_3.inputs[2])
	    #compare_004_3.Result -> switch_006.Switch
	    clump_hair_curves.links.new(compare_004_3.outputs[0], switch_006.inputs[0])
	    #reroute_021_1.Output -> switch_006.False
	    clump_hair_curves.links.new(reroute_021_1.outputs[0], switch_006.inputs[1])
	    #group_005.Curves -> set_spline_type_001.Curve
	    clump_hair_curves.links.new(group_005.outputs[0], set_spline_type_001.inputs[0])
	    #reroute_024_1.Output -> reroute_021_1.Input
	    clump_hair_curves.links.new(reroute_024_1.outputs[0], reroute_021_1.inputs[0])
	    #switch_006.Output -> set_spline_resolution_001.Resolution
	    clump_hair_curves.links.new(switch_006.outputs[0], set_spline_resolution_001.inputs[2])
	    #capture_attribute_002_2.Geometry -> set_spline_type_002.Curve
	    clump_hair_curves.links.new(capture_attribute_002_2.outputs[0], set_spline_type_002.inputs[0])
	    #compare_003_2.Result -> accumulate_field_1.Value
	    clump_hair_curves.links.new(compare_003_2.outputs[0], accumulate_field_1.inputs[0])
	    #accumulate_field_1.Total -> sample_index_001_1.Value
	    clump_hair_curves.links.new(accumulate_field_1.outputs[2], sample_index_001_1.inputs[1])
	    #reroute_032.Output -> sample_index_001_1.Geometry
	    clump_hair_curves.links.new(reroute_032.outputs[0], sample_index_001_1.inputs[0])
	    #sample_index_001_1.Value -> boolean_math_002_2.Boolean
	    clump_hair_curves.links.new(sample_index_001_1.outputs[0], boolean_math_002_2.inputs[1])
	    #group_input_011.Guide Index -> reroute_006_2.Input
	    clump_hair_curves.links.new(group_input_011.outputs[1], reroute_006_2.inputs[0])
	    #reroute_002_2.Output -> reroute_008_2.Input
	    clump_hair_curves.links.new(reroute_002_2.outputs[0], reroute_008_2.inputs[0])
	    #reroute_004_3.Output -> reroute_020_2.Input
	    clump_hair_curves.links.new(reroute_004_3.outputs[0], reroute_020_2.inputs[0])
	    #reroute_025.Output -> set_position_2.Geometry
	    clump_hair_curves.links.new(reroute_025.outputs[0], set_position_2.inputs[0])
	    #reroute_029.Output -> reroute_011_2.Input
	    clump_hair_curves.links.new(reroute_029.outputs[0], reroute_011_2.inputs[0])
	    #capture_attribute_2.Value -> reroute_010_1.Input
	    clump_hair_curves.links.new(capture_attribute_2.outputs[1], reroute_010_1.inputs[0])
	    #reroute_010_1.Output -> reroute_022_1.Input
	    clump_hair_curves.links.new(reroute_010_1.outputs[0], reroute_022_1.inputs[0])
	    #capture_attribute_002_2.Value -> reroute_023_1.Input
	    clump_hair_curves.links.new(capture_attribute_002_2.outputs[1], reroute_023_1.inputs[0])
	    #reroute_023_1.Output -> reroute_024_1.Input
	    clump_hair_curves.links.new(reroute_023_1.outputs[0], reroute_024_1.inputs[0])
	    #reroute_005_2.Output -> reroute_025.Input
	    clump_hair_curves.links.new(reroute_005_2.outputs[0], reroute_025.inputs[0])
	    #group_input_012.Tip Spread -> compare_3.A
	    clump_hair_curves.links.new(group_input_012.outputs[7], compare_3.inputs[0])
	    #compare_3.Result -> switch_4.Switch
	    clump_hair_curves.links.new(compare_3.outputs[0], switch_4.inputs[0])
	    #reroute_008_2.Output -> reroute_007_2.Input
	    clump_hair_curves.links.new(reroute_008_2.outputs[0], reroute_007_2.inputs[0])
	    #reroute_007_2.Output -> reroute_026_1.Input
	    clump_hair_curves.links.new(reroute_007_2.outputs[0], reroute_026_1.inputs[0])
	    #reroute_026_1.Output -> reroute_027_1.Input
	    clump_hair_curves.links.new(reroute_026_1.outputs[0], reroute_027_1.inputs[0])
	    #random_value_004_1.Value -> reroute_028_1.Input
	    clump_hair_curves.links.new(random_value_004_1.outputs[2], reroute_028_1.inputs[0])
	    #group_input_005_2.Seed -> random_value_004_1.ID
	    clump_hair_curves.links.new(group_input_005_2.outputs[11], random_value_004_1.inputs[7])
	    #switch_001_5.Output -> capture_attribute_001_2.Geometry
	    clump_hair_curves.links.new(switch_001_5.outputs[0], capture_attribute_001_2.inputs[0])
	    #switch_003_4.Output -> capture_attribute_001_2.Value
	    clump_hair_curves.links.new(switch_003_4.outputs[0], capture_attribute_001_2.inputs[1])
	    #capture_attribute_001_2.Value -> reroute_029.Input
	    clump_hair_curves.links.new(capture_attribute_001_2.outputs[1], reroute_029.inputs[0])
	    #map_range_001_1.Result -> switch_004_1.False
	    clump_hair_curves.links.new(map_range_001_1.outputs[0], switch_004_1.inputs[1])
	    #vector_math_010_1.Value -> compare_005_1.A
	    clump_hair_curves.links.new(vector_math_010_1.outputs[1], compare_005_1.inputs[0])
	    #compare_005_1.Result -> switch_004_1.True
	    clump_hair_curves.links.new(compare_005_1.outputs[0], switch_004_1.inputs[2])
	    #reroute_030.Output -> compare_005_1.B
	    clump_hair_curves.links.new(reroute_030.outputs[0], compare_005_1.inputs[1])
	    #group_input_006_2.Distance Threshold -> compare_006.A
	    clump_hair_curves.links.new(group_input_006_2.outputs[10], compare_006.inputs[0])
	    #group_input_007_2.Distance Falloff -> compare_007.A
	    clump_hair_curves.links.new(group_input_007_2.outputs[9], compare_007.inputs[0])
	    #compare_006.Result -> boolean_math_2.Boolean
	    clump_hair_curves.links.new(compare_006.outputs[0], boolean_math_2.inputs[0])
	    #compare_007.Result -> boolean_math_2.Boolean
	    clump_hair_curves.links.new(compare_007.outputs[0], boolean_math_2.inputs[1])
	    #boolean_math_2.Boolean -> switch_004_1.Switch
	    clump_hair_curves.links.new(boolean_math_2.outputs[0], switch_004_1.inputs[0])
	    #group_input_006_2.Distance Threshold -> reroute_030.Input
	    clump_hair_curves.links.new(group_input_006_2.outputs[10], reroute_030.inputs[0])
	    #reroute_019_2.Output -> join_geometry_001_2.Geometry
	    clump_hair_curves.links.new(reroute_019_2.outputs[0], join_geometry_001_2.inputs[0])
	    #set_spline_resolution_001.Geometry -> join_geometry_001_2.Geometry
	    clump_hair_curves.links.new(set_spline_resolution_001.outputs[0], join_geometry_001_2.inputs[0])
	    #reroute_017_3.Output -> join_geometry_001_2.Geometry
	    clump_hair_curves.links.new(reroute_017_3.outputs[0], join_geometry_001_2.inputs[0])
	    #reroute_016_3.Output -> join_geometry_001_2.Geometry
	    clump_hair_curves.links.new(reroute_016_3.outputs[0], join_geometry_001_2.inputs[0])
	    return clump_hair_curves
	
	clump_hair_curves = clump_hair_curves_node_group()
	
	#initialize attach_hair_curves_to_surface node group
	def attach_hair_curves_to_surface_node_group():
	    attach_hair_curves_to_surface = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Attach Hair Curves to Surface")
	
	    attach_hair_curves_to_surface.color_tag = 'GEOMETRY'
	    attach_hair_curves_to_surface.description = "Attaches hair curves to a surface mesh"
	    attach_hair_curves_to_surface.default_group_node_width = 140
	    
	
	    attach_hair_curves_to_surface.is_modifier = True
	
	    #attach_hair_curves_to_surface interface
	    #Socket Geometry
	    geometry_socket_6 = attach_hair_curves_to_surface.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_6.attribute_domain = 'POINT'
	
	    #Socket Surface UV Coordinate
	    surface_uv_coordinate_socket = attach_hair_curves_to_surface.interface.new_socket(name = "Surface UV Coordinate", in_out='OUTPUT', socket_type = 'NodeSocketVector')
	    surface_uv_coordinate_socket.default_value = (0.0, 0.0, 0.0)
	    surface_uv_coordinate_socket.min_value = -3.4028234663852886e+38
	    surface_uv_coordinate_socket.max_value = 3.4028234663852886e+38
	    surface_uv_coordinate_socket.subtype = 'NONE'
	    surface_uv_coordinate_socket.attribute_domain = 'CURVE'
	    surface_uv_coordinate_socket.description = "Surface UV coordinates at the attachment point"
	
	    #Socket Surface Normal
	    surface_normal_socket = attach_hair_curves_to_surface.interface.new_socket(name = "Surface Normal", in_out='OUTPUT', socket_type = 'NodeSocketVector')
	    surface_normal_socket.default_value = (0.0, 0.0, 0.0)
	    surface_normal_socket.min_value = -3.4028234663852886e+38
	    surface_normal_socket.max_value = 3.4028234663852886e+38
	    surface_normal_socket.subtype = 'NONE'
	    surface_normal_socket.attribute_domain = 'CURVE'
	    surface_normal_socket.description = "Surface normal at the attachment point"
	
	    #Socket Geometry
	    geometry_socket_7 = attach_hair_curves_to_surface.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_7.attribute_domain = 'POINT'
	    geometry_socket_7.description = "Input Geometry (may include other than curves)"
	
	    #Socket Surface
	    surface_socket = attach_hair_curves_to_surface.interface.new_socket(name = "Surface", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    surface_socket.attribute_domain = 'POINT'
	    surface_socket.description = "Surface geometry to attach hair curves to"
	
	    #Socket Surface
	    surface_socket_1 = attach_hair_curves_to_surface.interface.new_socket(name = "Surface", in_out='INPUT', socket_type = 'NodeSocketObject')
	    surface_socket_1.attribute_domain = 'POINT'
	    surface_socket_1.description = "Surface Object to attach to (needs to have matching transforms)"
	
	    #Socket Surface UV Map
	    surface_uv_map_socket = attach_hair_curves_to_surface.interface.new_socket(name = "Surface UV Map", in_out='INPUT', socket_type = 'NodeSocketVector')
	    surface_uv_map_socket.default_value = (0.0, 0.0, 0.0)
	    surface_uv_map_socket.min_value = -3.4028234663852886e+38
	    surface_uv_map_socket.max_value = 3.4028234663852886e+38
	    surface_uv_map_socket.subtype = 'NONE'
	    surface_uv_map_socket.default_attribute_name = "UVMap"
	    surface_uv_map_socket.attribute_domain = 'POINT'
	    surface_uv_map_socket.hide_value = True
	    surface_uv_map_socket.description = "Surface UV map used for attachment"
	
	    #Socket Surface Rest Position
	    surface_rest_position_socket = attach_hair_curves_to_surface.interface.new_socket(name = "Surface Rest Position", in_out='INPUT', socket_type = 'NodeSocketBool')
	    surface_rest_position_socket.default_value = False
	    surface_rest_position_socket.attribute_domain = 'POINT'
	    surface_rest_position_socket.description = "Set the surface mesh into its rest position before attachment"
	
	    #Socket Sample Attachment UV
	    sample_attachment_uv_socket = attach_hair_curves_to_surface.interface.new_socket(name = "Sample Attachment UV", in_out='INPUT', socket_type = 'NodeSocketBool')
	    sample_attachment_uv_socket.default_value = True
	    sample_attachment_uv_socket.attribute_domain = 'POINT'
	    sample_attachment_uv_socket.description = "Sample the surface UV map at the attachment point"
	
	    #Socket Snap to Surface
	    snap_to_surface_socket = attach_hair_curves_to_surface.interface.new_socket(name = "Snap to Surface", in_out='INPUT', socket_type = 'NodeSocketBool')
	    snap_to_surface_socket.default_value = True
	    snap_to_surface_socket.attribute_domain = 'POINT'
	    snap_to_surface_socket.description = "Snap the root of each curve to the closest surface point"
	
	    #Socket Align to Surface Normal
	    align_to_surface_normal_socket = attach_hair_curves_to_surface.interface.new_socket(name = "Align to Surface Normal", in_out='INPUT', socket_type = 'NodeSocketBool')
	    align_to_surface_normal_socket.default_value = True
	    align_to_surface_normal_socket.attribute_domain = 'POINT'
	    align_to_surface_normal_socket.description = "Align the curve to the surface normal (needs a guide as reference)"
	
	    #Socket Blend along Curve
	    blend_along_curve_socket = attach_hair_curves_to_surface.interface.new_socket(name = "Blend along Curve", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    blend_along_curve_socket.default_value = 0.0
	    blend_along_curve_socket.min_value = 0.0
	    blend_along_curve_socket.max_value = 1.0
	    blend_along_curve_socket.subtype = 'FACTOR'
	    blend_along_curve_socket.attribute_domain = 'POINT'
	    blend_along_curve_socket.description = "Blend deformation along each curve from the root"
	
	
	    #initialize attach_hair_curves_to_surface nodes
	    #node Frame.004
	    frame_004_3 = attach_hair_curves_to_surface.nodes.new("NodeFrame")
	    frame_004_3.label = "Write Data"
	    frame_004_3.name = "Frame.004"
	    frame_004_3.label_size = 20
	    frame_004_3.shrink = True
	
	    #node Frame.005
	    frame_005_2 = attach_hair_curves_to_surface.nodes.new("NodeFrame")
	    frame_005_2.label = "Sample Surface"
	    frame_005_2.name = "Frame.005"
	    frame_005_2.label_size = 20
	    frame_005_2.shrink = True
	
	    #node Frame
	    frame_5 = attach_hair_curves_to_surface.nodes.new("NodeFrame")
	    frame_5.label = "Surface Geometry Input"
	    frame_5.name = "Frame"
	    frame_5.label_size = 20
	    frame_5.shrink = True
	
	    #node Frame.006
	    frame_006_2 = attach_hair_curves_to_surface.nodes.new("NodeFrame")
	    frame_006_2.label = "Geometry Socket with Priority"
	    frame_006_2.name = "Frame.006"
	    frame_006_2.label_size = 20
	    frame_006_2.shrink = True
	
	    #node Frame.007
	    frame_007_2 = attach_hair_curves_to_surface.nodes.new("NodeFrame")
	    frame_007_2.label = "Object in Local Space"
	    frame_007_2.name = "Frame.007"
	    frame_007_2.label_size = 20
	    frame_007_2.shrink = True
	
	    #node Frame.011
	    frame_011 = attach_hair_curves_to_surface.nodes.new("NodeFrame")
	    frame_011.label = "Sample Attachment UV"
	    frame_011.name = "Frame.011"
	    frame_011.label_size = 20
	    frame_011.shrink = True
	
	    #node Frame.001
	    frame_001_3 = attach_hair_curves_to_surface.nodes.new("NodeFrame")
	    frame_001_3.label = "Smooth Normals"
	    frame_001_3.name = "Frame.001"
	    frame_001_3.label_size = 20
	    frame_001_3.shrink = True
	
	    #node Frame.010
	    frame_010 = attach_hair_curves_to_surface.nodes.new("NodeFrame")
	    frame_010.label = "Calculate New Position"
	    frame_010.name = "Frame.010"
	    frame_010.use_custom_color = True
	    frame_010.color = (0.13328450918197632, 0.13328450918197632, 0.13328450918197632)
	    frame_010.label_size = 20
	    frame_010.shrink = True
	
	    #node Frame.003
	    frame_003_3 = attach_hair_curves_to_surface.nodes.new("NodeFrame")
	    frame_003_3.label = "Blend Deformation"
	    frame_003_3.name = "Frame.003"
	    frame_003_3.label_size = 20
	    frame_003_3.shrink = True
	
	    #node Frame.002
	    frame_002_4 = attach_hair_curves_to_surface.nodes.new("NodeFrame")
	    frame_002_4.label = "Align to Normal"
	    frame_002_4.name = "Frame.002"
	    frame_002_4.use_custom_color = True
	    frame_002_4.color = (0.08883915841579437, 0.08883915841579437, 0.08883915841579437)
	    frame_002_4.label_size = 20
	    frame_002_4.shrink = True
	
	    #node Frame.008
	    frame_008 = attach_hair_curves_to_surface.nodes.new("NodeFrame")
	    frame_008.label = "Optimize"
	    frame_008.name = "Frame.008"
	    frame_008.label_size = 20
	    frame_008.shrink = True
	
	    #node Frame.009
	    frame_009 = attach_hair_curves_to_surface.nodes.new("NodeFrame")
	    frame_009.label = "Sample from Guide"
	    frame_009.name = "Frame.009"
	    frame_009.label_size = 20
	    frame_009.shrink = True
	
	    #node Reroute.010
	    reroute_010_2 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_010_2.name = "Reroute.010"
	    reroute_010_2.socket_idname = "NodeSocketGeometry"
	    #node Reroute.013
	    reroute_013_4 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_013_4.name = "Reroute.013"
	    reroute_013_4.socket_idname = "NodeSocketBool"
	    #node Group Output
	    group_output_8 = attach_hair_curves_to_surface.nodes.new("NodeGroupOutput")
	    group_output_8.name = "Group Output"
	    group_output_8.is_active_output = True
	
	    #node Reroute.003
	    reroute_003_3 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_003_3.name = "Reroute.003"
	    reroute_003_3.socket_idname = "NodeSocketVector"
	    #node Switch
	    switch_5 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSwitch")
	    switch_5.name = "Switch"
	    switch_5.input_type = 'GEOMETRY'
	
	    #node Store Named Attribute
	    store_named_attribute_2 = attach_hair_curves_to_surface.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_2.name = "Store Named Attribute"
	    store_named_attribute_2.data_type = 'FLOAT2'
	    store_named_attribute_2.domain = 'CURVE'
	    #Selection
	    store_named_attribute_2.inputs[1].default_value = True
	    #Name
	    store_named_attribute_2.inputs[2].default_value = "surface_uv_coordinate"
	
	    #node Group Input.007
	    group_input_007_3 = attach_hair_curves_to_surface.nodes.new("NodeGroupInput")
	    group_input_007_3.name = "Group Input.007"
	    group_input_007_3.outputs[0].hide = True
	    group_input_007_3.outputs[1].hide = True
	    group_input_007_3.outputs[2].hide = True
	    group_input_007_3.outputs[3].hide = True
	    group_input_007_3.outputs[4].hide = True
	    group_input_007_3.outputs[6].hide = True
	    group_input_007_3.outputs[7].hide = True
	    group_input_007_3.outputs[8].hide = True
	    group_input_007_3.outputs[9].hide = True
	
	    #node Reroute.016
	    reroute_016_4 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_016_4.name = "Reroute.016"
	    reroute_016_4.socket_idname = "NodeSocketGeometry"
	    #node Reroute.005
	    reroute_005_3 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_005_3.name = "Reroute.005"
	    reroute_005_3.socket_idname = "NodeSocketVector"
	    #node Store Named Attribute.001
	    store_named_attribute_001 = attach_hair_curves_to_surface.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_001.name = "Store Named Attribute.001"
	    store_named_attribute_001.data_type = 'FLOAT_VECTOR'
	    store_named_attribute_001.domain = 'CURVE'
	    #Selection
	    store_named_attribute_001.inputs[1].default_value = True
	    #Name
	    store_named_attribute_001.inputs[2].default_value = "surface_normal"
	
	    #node Named Attribute.004
	    named_attribute_004 = attach_hair_curves_to_surface.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute_004.name = "Named Attribute.004"
	    named_attribute_004.data_type = 'FLOAT_VECTOR'
	    #Name
	    named_attribute_004.inputs[0].default_value = "surface_normal"
	
	    #node Reroute.012
	    reroute_012_4 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_012_4.name = "Reroute.012"
	    reroute_012_4.socket_idname = "NodeSocketBool"
	    #node Reroute.014
	    reroute_014_4 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_014_4.name = "Reroute.014"
	    reroute_014_4.socket_idname = "NodeSocketBool"
	    #node Reroute.006
	    reroute_006_3 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_006_3.name = "Reroute.006"
	    reroute_006_3.socket_idname = "NodeSocketGeometry"
	    #node Named Attribute.003
	    named_attribute_003_1 = attach_hair_curves_to_surface.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute_003_1.name = "Named Attribute.003"
	    named_attribute_003_1.data_type = 'FLOAT_VECTOR'
	    #Name
	    named_attribute_003_1.inputs[0].default_value = "surface_uv_coordinate"
	
	    #node Switch.008
	    switch_008 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSwitch")
	    switch_008.name = "Switch.008"
	    switch_008.input_type = 'GEOMETRY'
	
	    #node Switch.009
	    switch_009 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSwitch")
	    switch_009.name = "Switch.009"
	    switch_009.input_type = 'VECTOR'
	
	    #node Switch.010
	    switch_010 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSwitch")
	    switch_010.name = "Switch.010"
	    switch_010.input_type = 'VECTOR'
	
	    #node Set Position.001
	    set_position_001_3 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSetPosition")
	    set_position_001_3.name = "Set Position.001"
	    set_position_001_3.inputs[2].hide = True
	    #Position
	    set_position_001_3.inputs[2].default_value = (0.0, 0.0, 0.0)
	
	    #node Reroute.002
	    reroute_002_3 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_002_3.name = "Reroute.002"
	    reroute_002_3.socket_idname = "NodeSocketVector"
	    #node Reroute.018
	    reroute_018_4 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_018_4.name = "Reroute.018"
	    reroute_018_4.socket_idname = "NodeSocketVector"
	    #node Reroute.017
	    reroute_017_4 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_017_4.name = "Reroute.017"
	    reroute_017_4.socket_idname = "NodeSocketGeometry"
	    #node Group Input.009
	    group_input_009_2 = attach_hair_curves_to_surface.nodes.new("NodeGroupInput")
	    group_input_009_2.name = "Group Input.009"
	    group_input_009_2.outputs[0].hide = True
	    group_input_009_2.outputs[1].hide = True
	    group_input_009_2.outputs[2].hide = True
	    group_input_009_2.outputs[4].hide = True
	    group_input_009_2.outputs[5].hide = True
	    group_input_009_2.outputs[6].hide = True
	    group_input_009_2.outputs[7].hide = True
	    group_input_009_2.outputs[8].hide = True
	    group_input_009_2.outputs[9].hide = True
	
	    #node Position
	    position_2 = attach_hair_curves_to_surface.nodes.new("GeometryNodeInputPosition")
	    position_2.name = "Position"
	
	    #node Named Attribute.001
	    named_attribute_001 = attach_hair_curves_to_surface.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute_001.name = "Named Attribute.001"
	    named_attribute_001.data_type = 'FLOAT_VECTOR'
	    #Name
	    named_attribute_001.inputs[0].default_value = "surface_uv_coordinate"
	
	    #node Capture Attribute.001
	    capture_attribute_001_3 = attach_hair_curves_to_surface.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_001_3.name = "Capture Attribute.001"
	    capture_attribute_001_3.active_index = 0
	    capture_attribute_001_3.capture_items.clear()
	    capture_attribute_001_3.capture_items.new('FLOAT', "Value")
	    capture_attribute_001_3.capture_items["Value"].data_type = 'FLOAT_VECTOR'
	    capture_attribute_001_3.domain = 'CURVE'
	
	    #node Group Input.004
	    group_input_004_3 = attach_hair_curves_to_surface.nodes.new("NodeGroupInput")
	    group_input_004_3.name = "Group Input.004"
	    group_input_004_3.outputs[0].hide = True
	    group_input_004_3.outputs[2].hide = True
	    group_input_004_3.outputs[3].hide = True
	    group_input_004_3.outputs[4].hide = True
	    group_input_004_3.outputs[5].hide = True
	    group_input_004_3.outputs[6].hide = True
	    group_input_004_3.outputs[7].hide = True
	    group_input_004_3.outputs[8].hide = True
	    group_input_004_3.outputs[9].hide = True
	
	    #node Domain Size.002
	    domain_size_002 = attach_hair_curves_to_surface.nodes.new("GeometryNodeAttributeDomainSize")
	    domain_size_002.name = "Domain Size.002"
	    domain_size_002.component = 'MESH'
	    domain_size_002.outputs[0].hide = True
	    domain_size_002.outputs[1].hide = True
	    domain_size_002.outputs[3].hide = True
	    domain_size_002.outputs[4].hide = True
	    domain_size_002.outputs[5].hide = True
	
	    #node Compare.001
	    compare_001_3 = attach_hair_curves_to_surface.nodes.new("FunctionNodeCompare")
	    compare_001_3.name = "Compare.001"
	    compare_001_3.data_type = 'INT'
	    compare_001_3.mode = 'ELEMENT'
	    compare_001_3.operation = 'NOT_EQUAL'
	    #B_INT
	    compare_001_3.inputs[3].default_value = 0
	
	    #node Object Info.001
	    object_info_001 = attach_hair_curves_to_surface.nodes.new("GeometryNodeObjectInfo")
	    object_info_001.name = "Object Info.001"
	    object_info_001.transform_space = 'ORIGINAL'
	    object_info_001.inputs[1].hide = True
	    object_info_001.outputs[1].hide = True
	    object_info_001.outputs[3].hide = True
	    #As Instance
	    object_info_001.inputs[1].default_value = False
	
	    #node Group Input.002
	    group_input_002_3 = attach_hair_curves_to_surface.nodes.new("NodeGroupInput")
	    group_input_002_3.name = "Group Input.002"
	    group_input_002_3.outputs[0].hide = True
	    group_input_002_3.outputs[1].hide = True
	    group_input_002_3.outputs[3].hide = True
	    group_input_002_3.outputs[4].hide = True
	    group_input_002_3.outputs[5].hide = True
	    group_input_002_3.outputs[6].hide = True
	    group_input_002_3.outputs[7].hide = True
	    group_input_002_3.outputs[8].hide = True
	    group_input_002_3.outputs[9].hide = True
	
	    #node Switch.005
	    switch_005_1 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSwitch")
	    switch_005_1.name = "Switch.005"
	    switch_005_1.input_type = 'GEOMETRY'
	
	    #node Domain Size.003
	    domain_size_003 = attach_hair_curves_to_surface.nodes.new("GeometryNodeAttributeDomainSize")
	    domain_size_003.name = "Domain Size.003"
	    domain_size_003.component = 'MESH'
	    domain_size_003.outputs[0].hide = True
	    domain_size_003.outputs[1].hide = True
	    domain_size_003.outputs[3].hide = True
	    domain_size_003.outputs[4].hide = True
	    domain_size_003.outputs[5].hide = True
	
	    #node Compare.002
	    compare_002_3 = attach_hair_curves_to_surface.nodes.new("FunctionNodeCompare")
	    compare_002_3.name = "Compare.002"
	    compare_002_3.data_type = 'INT'
	    compare_002_3.mode = 'ELEMENT'
	    compare_002_3.operation = 'EQUAL'
	    #B_INT
	    compare_002_3.inputs[3].default_value = 0
	
	    #node Named Attribute
	    named_attribute_2 = attach_hair_curves_to_surface.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute_2.name = "Named Attribute"
	    named_attribute_2.data_type = 'FLOAT_VECTOR'
	    #Name
	    named_attribute_2.inputs[0].default_value = "rest_position"
	
	    #node Reroute
	    reroute_5 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_5.name = "Reroute"
	    reroute_5.socket_idname = "NodeSocketGeometry"
	    #node Group Input.005
	    group_input_005_3 = attach_hair_curves_to_surface.nodes.new("NodeGroupInput")
	    group_input_005_3.name = "Group Input.005"
	    group_input_005_3.outputs[0].hide = True
	    group_input_005_3.outputs[1].hide = True
	    group_input_005_3.outputs[2].hide = True
	    group_input_005_3.outputs[3].hide = True
	    group_input_005_3.outputs[5].hide = True
	    group_input_005_3.outputs[6].hide = True
	    group_input_005_3.outputs[7].hide = True
	    group_input_005_3.outputs[8].hide = True
	    group_input_005_3.outputs[9].hide = True
	
	    #node Set Position
	    set_position_3 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSetPosition")
	    set_position_3.name = "Set Position"
	    set_position_3.inputs[3].hide = True
	    #Offset
	    set_position_3.inputs[3].default_value = (0.0, 0.0, 0.0)
	
	    #node Switch.007
	    switch_007 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSwitch")
	    switch_007.name = "Switch.007"
	    switch_007.input_type = 'GEOMETRY'
	
	    #node Reroute.015
	    reroute_015_4 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_015_4.name = "Reroute.015"
	    reroute_015_4.socket_idname = "NodeSocketBool"
	    #node Reroute.011
	    reroute_011_3 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_011_3.name = "Reroute.011"
	    reroute_011_3.socket_idname = "NodeSocketGeometry"
	    #node Group Input
	    group_input_5 = attach_hair_curves_to_surface.nodes.new("NodeGroupInput")
	    group_input_5.name = "Group Input"
	    group_input_5.outputs[1].hide = True
	    group_input_5.outputs[2].hide = True
	    group_input_5.outputs[3].hide = True
	    group_input_5.outputs[4].hide = True
	    group_input_5.outputs[5].hide = True
	    group_input_5.outputs[6].hide = True
	    group_input_5.outputs[7].hide = True
	    group_input_5.outputs[8].hide = True
	    group_input_5.outputs[9].hide = True
	
	    #node Capture Attribute.002
	    capture_attribute_002_3 = attach_hair_curves_to_surface.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_002_3.name = "Capture Attribute.002"
	    capture_attribute_002_3.active_index = 0
	    capture_attribute_002_3.capture_items.clear()
	    capture_attribute_002_3.capture_items.new('FLOAT', "Value")
	    capture_attribute_002_3.capture_items["Value"].data_type = 'FLOAT_VECTOR'
	    capture_attribute_002_3.domain = 'CURVE'
	
	    #node Reroute.001
	    reroute_001_5 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_001_5.name = "Reroute.001"
	    reroute_001_5.socket_idname = "NodeSocketGeometry"
	    #node Sample Nearest Surface
	    sample_nearest_surface = attach_hair_curves_to_surface.nodes.new("GeometryNodeSampleNearestSurface")
	    sample_nearest_surface.name = "Sample Nearest Surface"
	    sample_nearest_surface.data_type = 'FLOAT_VECTOR'
	    #Group ID
	    sample_nearest_surface.inputs[2].default_value = 0
	    #Sample Group ID
	    sample_nearest_surface.inputs[4].default_value = 0
	
	    #node Group
	    group_4 = attach_hair_curves_to_surface.nodes.new("GeometryNodeGroup")
	    group_4.name = "Group"
	    group_4.node_tree = curve_root
	    group_4.outputs[0].hide = True
	    group_4.outputs[2].hide = True
	    group_4.outputs[3].hide = True
	
	    #node Group Input.001
	    group_input_001_4 = attach_hair_curves_to_surface.nodes.new("NodeGroupInput")
	    group_input_001_4.name = "Group Input.001"
	    group_input_001_4.outputs[0].hide = True
	    group_input_001_4.outputs[1].hide = True
	    group_input_001_4.outputs[2].hide = True
	    group_input_001_4.outputs[4].hide = True
	    group_input_001_4.outputs[5].hide = True
	    group_input_001_4.outputs[6].hide = True
	    group_input_001_4.outputs[7].hide = True
	    group_input_001_4.outputs[8].hide = True
	    group_input_001_4.outputs[9].hide = True
	
	    #node Reroute.020
	    reroute_020_3 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_020_3.name = "Reroute.020"
	    reroute_020_3.socket_idname = "NodeSocketGeometry"
	    #node Normal
	    normal_1 = attach_hair_curves_to_surface.nodes.new("GeometryNodeInputNormal")
	    normal_1.name = "Normal"
	    normal_1.legacy_corner_normals = True
	
	    #node Capture Attribute
	    capture_attribute_3 = attach_hair_curves_to_surface.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_3.name = "Capture Attribute"
	    capture_attribute_3.hide = True
	    capture_attribute_3.active_index = 0
	    capture_attribute_3.capture_items.clear()
	    capture_attribute_3.capture_items.new('FLOAT', "Value")
	    capture_attribute_3.capture_items["Value"].data_type = 'FLOAT_VECTOR'
	    capture_attribute_3.domain = 'POINT'
	
	    #node Sample UV Surface
	    sample_uv_surface = attach_hair_curves_to_surface.nodes.new("GeometryNodeSampleUVSurface")
	    sample_uv_surface.name = "Sample UV Surface"
	    sample_uv_surface.hide = True
	    sample_uv_surface.data_type = 'FLOAT_VECTOR'
	    sample_uv_surface.outputs[1].hide = True
	
	    #node Sample UV Surface.003
	    sample_uv_surface_003 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSampleUVSurface")
	    sample_uv_surface_003.name = "Sample UV Surface.003"
	    sample_uv_surface_003.hide = True
	    sample_uv_surface_003.data_type = 'FLOAT_VECTOR'
	    sample_uv_surface_003.outputs[1].hide = True
	
	    #node Reroute.004
	    reroute_004_4 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_004_4.name = "Reroute.004"
	    reroute_004_4.socket_idname = "NodeSocketVector"
	    #node Sample UV Surface.001
	    sample_uv_surface_001 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSampleUVSurface")
	    sample_uv_surface_001.name = "Sample UV Surface.001"
	    sample_uv_surface_001.hide = True
	    sample_uv_surface_001.data_type = 'FLOAT_VECTOR'
	    sample_uv_surface_001.outputs[1].hide = True
	
	    #node Group.001
	    group_001_4 = attach_hair_curves_to_surface.nodes.new("GeometryNodeGroup")
	    group_001_4.name = "Group.001"
	    group_001_4.node_tree = curve_root
	    group_001_4.outputs[0].hide = True
	    group_001_4.outputs[2].hide = True
	    group_001_4.outputs[3].hide = True
	
	    #node Position.001
	    position_001_2 = attach_hair_curves_to_surface.nodes.new("GeometryNodeInputPosition")
	    position_001_2.name = "Position.001"
	
	    #node Vector Math
	    vector_math_4 = attach_hair_curves_to_surface.nodes.new("ShaderNodeVectorMath")
	    vector_math_4.name = "Vector Math"
	    vector_math_4.operation = 'SUBTRACT'
	
	    #node Vector Math.001
	    vector_math_001_4 = attach_hair_curves_to_surface.nodes.new("ShaderNodeVectorMath")
	    vector_math_001_4.name = "Vector Math.001"
	    vector_math_001_4.operation = 'SUBTRACT'
	
	    #node Vector Math.004
	    vector_math_004_4 = attach_hair_curves_to_surface.nodes.new("ShaderNodeVectorMath")
	    vector_math_004_4.name = "Vector Math.004"
	    vector_math_004_4.operation = 'SUBTRACT'
	
	    #node Vector Math.003
	    vector_math_003_3 = attach_hair_curves_to_surface.nodes.new("ShaderNodeVectorMath")
	    vector_math_003_3.name = "Vector Math.003"
	    vector_math_003_3.operation = 'SUBTRACT'
	
	    #node Group Input.003
	    group_input_003_4 = attach_hair_curves_to_surface.nodes.new("NodeGroupInput")
	    group_input_003_4.name = "Group Input.003"
	    group_input_003_4.outputs[0].hide = True
	    group_input_003_4.outputs[1].hide = True
	    group_input_003_4.outputs[2].hide = True
	    group_input_003_4.outputs[3].hide = True
	    group_input_003_4.outputs[4].hide = True
	    group_input_003_4.outputs[5].hide = True
	    group_input_003_4.outputs[6].hide = True
	    group_input_003_4.outputs[8].hide = True
	    group_input_003_4.outputs[9].hide = True
	
	    #node Group Input.006
	    group_input_006_3 = attach_hair_curves_to_surface.nodes.new("NodeGroupInput")
	    group_input_006_3.name = "Group Input.006"
	    group_input_006_3.outputs[0].hide = True
	    group_input_006_3.outputs[1].hide = True
	    group_input_006_3.outputs[2].hide = True
	    group_input_006_3.outputs[3].hide = True
	    group_input_006_3.outputs[4].hide = True
	    group_input_006_3.outputs[5].hide = True
	    group_input_006_3.outputs[7].hide = True
	    group_input_006_3.outputs[8].hide = True
	    group_input_006_3.outputs[9].hide = True
	
	    #node Switch.003
	    switch_003_5 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSwitch")
	    switch_003_5.name = "Switch.003"
	    switch_003_5.hide = True
	    switch_003_5.input_type = 'VECTOR'
	    #False
	    switch_003_5.inputs[1].default_value = (0.0, 0.0, 0.0)
	
	    #node Switch.002
	    switch_002_4 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSwitch")
	    switch_002_4.name = "Switch.002"
	    switch_002_4.input_type = 'VECTOR'
	
	    #node Vector Math.002
	    vector_math_002_3 = attach_hair_curves_to_surface.nodes.new("ShaderNodeVectorMath")
	    vector_math_002_3.name = "Vector Math.002"
	    vector_math_002_3.operation = 'ADD'
	
	    #node Vector Math.005
	    vector_math_005_2 = attach_hair_curves_to_surface.nodes.new("ShaderNodeVectorMath")
	    vector_math_005_2.name = "Vector Math.005"
	    vector_math_005_2.operation = 'SCALE'
	
	    #node Boolean Math
	    boolean_math_3 = attach_hair_curves_to_surface.nodes.new("FunctionNodeBooleanMath")
	    boolean_math_3.name = "Boolean Math"
	    boolean_math_3.operation = 'OR'
	
	    #node Spline Parameter
	    spline_parameter_1 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSplineParameter")
	    spline_parameter_1.name = "Spline Parameter"
	    spline_parameter_1.outputs[1].hide = True
	    spline_parameter_1.outputs[2].hide = True
	
	    #node Group Input.008
	    group_input_008_2 = attach_hair_curves_to_surface.nodes.new("NodeGroupInput")
	    group_input_008_2.name = "Group Input.008"
	    group_input_008_2.outputs[0].hide = True
	    group_input_008_2.outputs[1].hide = True
	    group_input_008_2.outputs[2].hide = True
	    group_input_008_2.outputs[3].hide = True
	    group_input_008_2.outputs[4].hide = True
	    group_input_008_2.outputs[5].hide = True
	    group_input_008_2.outputs[6].hide = True
	    group_input_008_2.outputs[7].hide = True
	    group_input_008_2.outputs[9].hide = True
	
	    #node Map Range
	    map_range_1 = attach_hair_curves_to_surface.nodes.new("ShaderNodeMapRange")
	    map_range_1.name = "Map Range"
	    map_range_1.hide = True
	    map_range_1.clamp = True
	    map_range_1.data_type = 'FLOAT'
	    map_range_1.interpolation_type = 'SMOOTHSTEP'
	    #From Min
	    map_range_1.inputs[1].default_value = 0.0
	    #To Min
	    map_range_1.inputs[3].default_value = 1.0
	    #To Max
	    map_range_1.inputs[4].default_value = 0.0
	
	    #node Compare
	    compare_4 = attach_hair_curves_to_surface.nodes.new("FunctionNodeCompare")
	    compare_4.name = "Compare"
	    compare_4.data_type = 'FLOAT'
	    compare_4.mode = 'ELEMENT'
	    compare_4.operation = 'EQUAL'
	    #B
	    compare_4.inputs[1].default_value = 0.0
	    #Epsilon
	    compare_4.inputs[12].default_value = 0.0
	
	    #node Switch.004
	    switch_004_2 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSwitch")
	    switch_004_2.name = "Switch.004"
	    switch_004_2.input_type = 'FLOAT'
	    #True
	    switch_004_2.inputs[2].default_value = 1.0
	
	    #node Position.002
	    position_002_3 = attach_hair_curves_to_surface.nodes.new("GeometryNodeInputPosition")
	    position_002_3.name = "Position.002"
	
	    #node Evaluate on Domain
	    evaluate_on_domain_2 = attach_hair_curves_to_surface.nodes.new("GeometryNodeFieldOnDomain")
	    evaluate_on_domain_2.name = "Evaluate on Domain"
	    evaluate_on_domain_2.data_type = 'FLOAT_VECTOR'
	    evaluate_on_domain_2.domain = 'CURVE'
	
	    #node Reroute.009
	    reroute_009_3 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_009_3.name = "Reroute.009"
	    reroute_009_3.socket_idname = "NodeSocketVector"
	    #node Evaluate on Domain.002
	    evaluate_on_domain_002_2 = attach_hair_curves_to_surface.nodes.new("GeometryNodeFieldOnDomain")
	    evaluate_on_domain_002_2.name = "Evaluate on Domain.002"
	    evaluate_on_domain_002_2.hide = True
	    evaluate_on_domain_002_2.data_type = 'FLOAT_VECTOR'
	    evaluate_on_domain_002_2.domain = 'CURVE'
	
	    #node Switch.006
	    switch_006_1 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSwitch")
	    switch_006_1.name = "Switch.006"
	    switch_006_1.input_type = 'VECTOR'
	
	    #node Vector Rotate
	    vector_rotate_1 = attach_hair_curves_to_surface.nodes.new("ShaderNodeVectorRotate")
	    vector_rotate_1.name = "Vector Rotate"
	    vector_rotate_1.invert = False
	    vector_rotate_1.rotation_type = 'EULER_XYZ'
	    vector_rotate_1.inputs[1].hide = True
	    vector_rotate_1.inputs[2].hide = True
	    vector_rotate_1.inputs[3].hide = True
	    #Center
	    vector_rotate_1.inputs[1].default_value = (0.0, 0.0, 0.0)
	
	    #node Vector Rotate.003
	    vector_rotate_003 = attach_hair_curves_to_surface.nodes.new("ShaderNodeVectorRotate")
	    vector_rotate_003.name = "Vector Rotate.003"
	    vector_rotate_003.invert = True
	    vector_rotate_003.rotation_type = 'EULER_XYZ'
	    vector_rotate_003.inputs[1].hide = True
	    vector_rotate_003.inputs[2].hide = True
	    vector_rotate_003.inputs[3].hide = True
	    #Center
	    vector_rotate_003.inputs[1].default_value = (0.0, 0.0, 0.0)
	
	    #node Align Euler to Vector.003
	    align_euler_to_vector_003 = attach_hair_curves_to_surface.nodes.new("FunctionNodeAlignEulerToVector")
	    align_euler_to_vector_003.name = "Align Euler to Vector.003"
	    align_euler_to_vector_003.axis = 'Z'
	    align_euler_to_vector_003.pivot_axis = 'AUTO'
	    align_euler_to_vector_003.inputs[0].hide = True
	    align_euler_to_vector_003.inputs[1].hide = True
	    #Rotation
	    align_euler_to_vector_003.inputs[0].default_value = (0.0, 0.0, 0.0)
	    #Factor
	    align_euler_to_vector_003.inputs[1].default_value = 1.0
	
	    #node Align Euler to Vector.002
	    align_euler_to_vector_002 = attach_hair_curves_to_surface.nodes.new("FunctionNodeAlignEulerToVector")
	    align_euler_to_vector_002.name = "Align Euler to Vector.002"
	    align_euler_to_vector_002.axis = 'Z'
	    align_euler_to_vector_002.pivot_axis = 'AUTO'
	    align_euler_to_vector_002.inputs[0].hide = True
	    align_euler_to_vector_002.inputs[1].hide = True
	    #Rotation
	    align_euler_to_vector_002.inputs[0].default_value = (0.0, 0.0, 0.0)
	    #Factor
	    align_euler_to_vector_002.inputs[1].default_value = 1.0
	
	    #node Evaluate on Domain.003
	    evaluate_on_domain_003 = attach_hair_curves_to_surface.nodes.new("GeometryNodeFieldOnDomain")
	    evaluate_on_domain_003.name = "Evaluate on Domain.003"
	    evaluate_on_domain_003.hide = True
	    evaluate_on_domain_003.data_type = 'FLOAT_VECTOR'
	    evaluate_on_domain_003.domain = 'CURVE'
	
	    #node Switch.001
	    switch_001_6 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSwitch")
	    switch_001_6.name = "Switch.001"
	    switch_001_6.hide = True
	    switch_001_6.input_type = 'VECTOR'
	
	    #node Accumulate Field
	    accumulate_field_2 = attach_hair_curves_to_surface.nodes.new("GeometryNodeAccumulateField")
	    accumulate_field_2.name = "Accumulate Field"
	    accumulate_field_2.hide = True
	    accumulate_field_2.data_type = 'FLOAT'
	    accumulate_field_2.domain = 'POINT'
	    #Group Index
	    accumulate_field_2.inputs[1].default_value = 0
	
	    #node Sample Index.001
	    sample_index_001_2 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSampleIndex")
	    sample_index_001_2.name = "Sample Index.001"
	    sample_index_001_2.hide = True
	    sample_index_001_2.clamp = False
	    sample_index_001_2.data_type = 'BOOLEAN'
	    sample_index_001_2.domain = 'CURVE'
	    #Index
	    sample_index_001_2.inputs[2].default_value = 0
	
	    #node Reroute.019
	    reroute_019_3 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_019_3.name = "Reroute.019"
	    reroute_019_3.socket_idname = "NodeSocketVector"
	    #node Named Attribute.002
	    named_attribute_002 = attach_hair_curves_to_surface.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute_002.name = "Named Attribute.002"
	    named_attribute_002.data_type = 'INT'
	    #Name
	    named_attribute_002.inputs[0].default_value = "guide_curve_index"
	
	    #node Reroute.007
	    reroute_007_3 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_007_3.name = "Reroute.007"
	    reroute_007_3.socket_idname = "NodeSocketGeometry"
	    #node Reroute.008
	    reroute_008_3 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_008_3.name = "Reroute.008"
	    reroute_008_3.socket_idname = "NodeSocketVector"
	    #node Sample Index
	    sample_index_2 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSampleIndex")
	    sample_index_2.name = "Sample Index"
	    sample_index_2.hide = True
	    sample_index_2.clamp = False
	    sample_index_2.data_type = 'FLOAT_VECTOR'
	    sample_index_2.domain = 'CURVE'
	
	
	
	
	    #Set parents
	    frame_006_2.parent = frame_5
	    frame_007_2.parent = frame_5
	    frame_003_3.parent = frame_010
	    frame_002_4.parent = frame_010
	    frame_008.parent = frame_002_4
	    frame_009.parent = frame_002_4
	    reroute_003_3.parent = frame_004_3
	    switch_5.parent = frame_004_3
	    store_named_attribute_2.parent = frame_004_3
	    group_input_007_3.parent = frame_004_3
	    reroute_016_4.parent = frame_004_3
	    reroute_005_3.parent = frame_004_3
	    store_named_attribute_001.parent = frame_004_3
	    named_attribute_004.parent = frame_004_3
	    reroute_012_4.parent = frame_004_3
	    named_attribute_003_1.parent = frame_004_3
	    switch_008.parent = frame_004_3
	    switch_009.parent = frame_004_3
	    switch_010.parent = frame_004_3
	    reroute_002_3.parent = frame_005_2
	    reroute_018_4.parent = frame_005_2
	    reroute_017_4.parent = frame_005_2
	    group_input_009_2.parent = frame_005_2
	    position_2.parent = frame_005_2
	    named_attribute_001.parent = frame_005_2
	    group_input_004_3.parent = frame_006_2
	    domain_size_002.parent = frame_006_2
	    compare_001_3.parent = frame_006_2
	    object_info_001.parent = frame_007_2
	    group_input_002_3.parent = frame_007_2
	    switch_005_1.parent = frame_5
	    domain_size_003.parent = frame_5
	    compare_002_3.parent = frame_5
	    named_attribute_2.parent = frame_5
	    reroute_5.parent = frame_5
	    group_input_005_3.parent = frame_5
	    set_position_3.parent = frame_5
	    switch_007.parent = frame_5
	    sample_nearest_surface.parent = frame_011
	    group_4.parent = frame_011
	    group_input_001_4.parent = frame_011
	    normal_1.parent = frame_001_3
	    capture_attribute_3.parent = frame_001_3
	    sample_uv_surface.parent = frame_005_2
	    sample_uv_surface_003.parent = frame_005_2
	    reroute_004_4.parent = frame_005_2
	    sample_uv_surface_001.parent = frame_005_2
	    group_001_4.parent = frame_010
	    position_001_2.parent = frame_010
	    vector_math_4.parent = frame_010
	    vector_math_001_4.parent = frame_010
	    vector_math_004_4.parent = frame_010
	    vector_math_003_3.parent = frame_010
	    group_input_003_4.parent = frame_010
	    group_input_006_3.parent = frame_010
	    switch_003_5.parent = frame_010
	    switch_002_4.parent = frame_010
	    vector_math_002_3.parent = frame_010
	    vector_math_005_2.parent = frame_010
	    boolean_math_3.parent = frame_010
	    spline_parameter_1.parent = frame_003_3
	    group_input_008_2.parent = frame_003_3
	    map_range_1.parent = frame_003_3
	    compare_4.parent = frame_003_3
	    switch_004_2.parent = frame_003_3
	    position_002_3.parent = frame_010
	    evaluate_on_domain_2.parent = frame_010
	    reroute_009_3.parent = frame_002_4
	    evaluate_on_domain_002_2.parent = frame_002_4
	    switch_006_1.parent = frame_002_4
	    vector_rotate_1.parent = frame_002_4
	    vector_rotate_003.parent = frame_002_4
	    align_euler_to_vector_003.parent = frame_002_4
	    align_euler_to_vector_002.parent = frame_002_4
	    evaluate_on_domain_003.parent = frame_002_4
	    switch_001_6.parent = frame_008
	    accumulate_field_2.parent = frame_008
	    sample_index_001_2.parent = frame_008
	    reroute_019_3.parent = frame_002_4
	    named_attribute_002.parent = frame_009
	    reroute_007_3.parent = frame_009
	    reroute_008_3.parent = frame_009
	    sample_index_2.parent = frame_009
	
	    #Set locations
	    frame_004_3.location = (-1215.903076171875, 262.0)
	    frame_005_2.location = (-4968.0, -121.0)
	    frame_5.location = (-7319.0, 140.0)
	    frame_006_2.location = (30.0, -355.0)
	    frame_007_2.location = (207.0, -181.0)
	    frame_011.location = (-5752.0, 120.0)
	    frame_001_3.location = (-5510.0, -382.0)
	    frame_010.location = (-4110.3515625, 32.0)
	    frame_003_3.location = (1565.3515625, -503.0)
	    frame_002_4.location = (29.999755859375, -437.0)
	    frame_008.location = (219.351806640625, -40.0)
	    frame_009.location = (30.0, -217.5032958984375)
	    reroute_010_2.location = (-798.60986328125, 472.99615478515625)
	    reroute_013_4.location = (-789.0, 512.1389770507812)
	    group_output_8.location = (75.0, 50.0)
	    reroute_003_3.location = (35.0, -292.3721618652344)
	    switch_5.location = (320.95263671875, -40.143096923828125)
	    store_named_attribute_2.location = (115.3720703125, -151.72100830078125)
	    group_input_007_3.location = (122.9049072265625, -39.53450012207031)
	    reroute_016_4.location = (45.1358642578125, -151.72100830078125)
	    reroute_005_3.location = (406.810302734375, -272.2791442871094)
	    store_named_attribute_001.location = (527.368408203125, -51.255889892578125)
	    named_attribute_004.location = (607.740478515625, -513.3954467773438)
	    reroute_012_4.location = (768.484619140625, -252.18612670898438)
	    reroute_014_4.location = (-507.69775390625, 311.209228515625)
	    reroute_006_3.location = (-547.8837890625, 291.1162109375)
	    named_attribute_003_1.location = (607.740478515625, -352.6512451171875)
	    switch_008.location = (808.670654296875, -71.34890747070312)
	    switch_009.location = (808.670654296875, -212.00006103515625)
	    switch_010.location = (808.670654296875, -392.8372802734375)
	    set_position_001_3.location = (-1472.16259765625, 230.837158203125)
	    reroute_002_3.location = (220.65625, -190.25262451171875)
	    reroute_018_4.location = (220.65625, -150.06658935546875)
	    reroute_017_4.location = (220.65625, -109.88055419921875)
	    group_input_009_2.location = (29.99072265625, -180.322021484375)
	    position_2.location = (29.99072265625, -39.67083740234375)
	    named_attribute_001.location = (29.99072265625, -260.694091796875)
	    capture_attribute_001_3.location = (-4365.55810546875, 210.744140625)
	    group_input_004_3.location = (29.669921875, -178.9044189453125)
	    domain_size_002.location = (207.6806640625, -80.07354736328125)
	    compare_001_3.location = (388.517578125, -39.88751220703125)
	    object_info_001.location = (210.88330078125, -39.64691162109375)
	    group_input_002_3.location = (30.0458984375, -79.83294677734375)
	    switch_005_1.location = (640.525390625, -283.5823974609375)
	    domain_size_003.location = (938.8193359375, -79.91128540039062)
	    compare_002_3.location = (1119.65625, -39.725250244140625)
	    named_attribute_2.location = (820.7041015625, -432.90301513671875)
	    reroute_5.location = (961.35546875, -332.43792724609375)
	    group_input_005_3.location = (1021.63427734375, -252.0657958984375)
	    set_position_3.location = (1021.63427734375, -352.53094482421875)
	    switch_007.location = (1222.564453125, -231.9727783203125)
	    reroute_015_4.location = (-5129.0927734375, 532.2319946289062)
	    reroute_011_3.location = (-5109.0, 492.04595947265625)
	    group_input_5.location = (-5510.8603515625, 351.395263671875)
	    capture_attribute_002_3.location = (-5209.46484375, 230.837158203125)
	    reroute_001_5.location = (-4887.9765625, -653.2559814453125)
	    sample_nearest_surface.location = (210.7509765625, -40.199798583984375)
	    group_4.location = (29.9140625, -180.85098266601562)
	    group_input_001_4.location = (29.9140625, -100.4788818359375)
	    reroute_020_3.location = (-4526.30224609375, -10.2791748046875)
	    normal_1.location = (29.5712890625, -45.01953125)
	    capture_attribute_3.location = (230.50146484375, -45.01953125)
	    sample_uv_surface.location = (321.1396484375, -50.02386474609375)
	    sample_uv_surface_003.location = (321.1396484375, -130.39593505859375)
	    reroute_004_4.location = (220.6748046875, -230.86102294921875)
	    sample_uv_surface_001.location = (321.1396484375, -210.76800537109375)
	    group_001_4.location = (158.627685546875, -240.71258544921875)
	    position_001_2.location = (339.46484375, -321.08465576171875)
	    vector_math_4.location = (339.46484375, -140.2474365234375)
	    vector_math_001_4.location = (540.39501953125, -321.08465576171875)
	    vector_math_004_4.location = (1826.3486328125, -341.17767333984375)
	    vector_math_003_3.location = (2027.27880859375, -200.52651977539062)
	    group_input_003_4.location = (1424.48828125, -220.79666137695312)
	    group_input_006_3.location = (1424.48828125, -100.238525390625)
	    switch_003_5.location = (1625.41845703125, -180.61062622070312)
	    switch_002_4.location = (1625.41845703125, -220.79666137695312)
	    vector_math_002_3.location = (1826.3486328125, -140.424560546875)
	    vector_math_005_2.location = (2248.30224609375, -200.70364379882812)
	    boolean_math_3.location = (1625.41845703125, -39.959442138671875)
	    spline_parameter_1.location = (32.72265625, -81.9400634765625)
	    group_input_008_2.location = (30.322265625, -161.4296875)
	    map_range_1.location = (205.259765625, -190.3057861328125)
	    compare_4.location = (205.20068359375, -39.6795654296875)
	    switch_004_2.location = (386.037841796875, -59.772705078125)
	    position_002_3.location = (1625.41845703125, -371.6761474609375)
	    evaluate_on_domain_2.location = (531.248291015625, -115.30325317382812)
	    reroute_009_3.location = (731.747802734375, -64.921875)
	    evaluate_on_domain_002_2.location = (630.95361328125, -265.85211181640625)
	    switch_006_1.location = (992.6279296875, -64.921875)
	    vector_rotate_1.location = (1173.465087890625, -64.921875)
	    vector_rotate_003.location = (811.790771484375, -165.386962890625)
	    align_euler_to_vector_003.location = (630.95361328125, -165.386962890625)
	    align_euler_to_vector_002.location = (630.95361328125, -306.0382080078125)
	    evaluate_on_domain_003.location = (630.95361328125, -406.5032958984375)
	    switch_001_6.location = (210.67138671875, -105.2939453125)
	    accumulate_field_2.location = (29.834228515625, -45.014892578125)
	    sample_index_001_2.location = (29.834228515625, -85.200927734375)
	    reroute_019_3.location = (48.255859375, -185.48004150390625)
	    named_attribute_002.location = (35.0, -105.279052734375)
	    reroute_007_3.location = (35.0, -45.0)
	    reroute_008_3.location = (35.0, -85.18603515625)
	    sample_index_2.location = (215.837158203125, -65.093017578125)
	
	    #Set dimensions
	    frame_004_3.width, frame_004_3.height = 978.903076171875, 664.0
	    frame_005_2.width, frame_005_2.height = 491.0, 412.0
	    frame_5.width, frame_5.height = 1393.0, 646.0
	    frame_006_2.width, frame_006_2.height = 559.0, 261.0
	    frame_007_2.width, frame_007_2.height = 381.0, 215.0
	    frame_011.width, frame_011.height = 390.33642578125, 279.0
	    frame_001_3.width, frame_001_3.height = 401.0, 125.0
	    frame_010.width, frame_010.height = 2418.3515625, 971.0
	    frame_003_3.width, frame_003_3.height = 556.0, 250.0
	    frame_002_4.width, frame_002_4.height = 1343.351806640625, 504.0
	    frame_008.width, frame_008.height = 381.0, 160.0
	    frame_009.width, frame_009.height = 385.351806640625, 256.4967041015625
	    reroute_010_2.width, reroute_010_2.height = 100.0, 100.0
	    reroute_013_4.width, reroute_013_4.height = 100.0, 100.0
	    group_output_8.width, group_output_8.height = 140.0, 100.0
	    reroute_003_3.width, reroute_003_3.height = 100.0, 100.0
	    switch_5.width, switch_5.height = 140.0, 100.0
	    store_named_attribute_2.width, store_named_attribute_2.height = 140.0, 100.0
	    group_input_007_3.width, group_input_007_3.height = 140.0, 100.0
	    reroute_016_4.width, reroute_016_4.height = 100.0, 100.0
	    reroute_005_3.width, reroute_005_3.height = 100.0, 100.0
	    store_named_attribute_001.width, store_named_attribute_001.height = 140.0, 100.0
	    named_attribute_004.width, named_attribute_004.height = 140.0, 100.0
	    reroute_012_4.width, reroute_012_4.height = 100.0, 100.0
	    reroute_014_4.width, reroute_014_4.height = 100.0, 100.0
	    reroute_006_3.width, reroute_006_3.height = 100.0, 100.0
	    named_attribute_003_1.width, named_attribute_003_1.height = 140.0, 100.0
	    switch_008.width, switch_008.height = 140.0, 100.0
	    switch_009.width, switch_009.height = 140.0, 100.0
	    switch_010.width, switch_010.height = 140.0, 100.0
	    set_position_001_3.width, set_position_001_3.height = 140.0, 100.0
	    reroute_002_3.width, reroute_002_3.height = 100.0, 100.0
	    reroute_018_4.width, reroute_018_4.height = 100.0, 100.0
	    reroute_017_4.width, reroute_017_4.height = 100.0, 100.0
	    group_input_009_2.width, group_input_009_2.height = 140.0, 100.0
	    position_2.width, position_2.height = 140.0, 100.0
	    named_attribute_001.width, named_attribute_001.height = 140.0, 100.0
	    capture_attribute_001_3.width, capture_attribute_001_3.height = 140.0, 100.0
	    group_input_004_3.width, group_input_004_3.height = 140.0, 100.0
	    domain_size_002.width, domain_size_002.height = 140.0, 100.0
	    compare_001_3.width, compare_001_3.height = 140.0, 100.0
	    object_info_001.width, object_info_001.height = 140.0, 100.0
	    group_input_002_3.width, group_input_002_3.height = 140.0, 100.0
	    switch_005_1.width, switch_005_1.height = 140.0, 100.0
	    domain_size_003.width, domain_size_003.height = 140.0, 100.0
	    compare_002_3.width, compare_002_3.height = 140.0, 100.0
	    named_attribute_2.width, named_attribute_2.height = 140.0, 100.0
	    reroute_5.width, reroute_5.height = 100.0, 100.0
	    group_input_005_3.width, group_input_005_3.height = 140.0, 100.0
	    set_position_3.width, set_position_3.height = 140.0, 100.0
	    switch_007.width, switch_007.height = 140.0, 100.0
	    reroute_015_4.width, reroute_015_4.height = 100.0, 100.0
	    reroute_011_3.width, reroute_011_3.height = 100.0, 100.0
	    group_input_5.width, group_input_5.height = 140.0, 100.0
	    capture_attribute_002_3.width, capture_attribute_002_3.height = 140.0, 100.0
	    reroute_001_5.width, reroute_001_5.height = 100.0, 100.0
	    sample_nearest_surface.width, sample_nearest_surface.height = 149.33627319335938, 100.0
	    group_4.width, group_4.height = 140.0, 100.0
	    group_input_001_4.width, group_input_001_4.height = 140.0, 100.0
	    reroute_020_3.width, reroute_020_3.height = 100.0, 100.0
	    normal_1.width, normal_1.height = 140.0, 100.0
	    capture_attribute_3.width, capture_attribute_3.height = 140.0, 100.0
	    sample_uv_surface.width, sample_uv_surface.height = 140.0, 100.0
	    sample_uv_surface_003.width, sample_uv_surface_003.height = 140.0, 100.0
	    reroute_004_4.width, reroute_004_4.height = 100.0, 100.0
	    sample_uv_surface_001.width, sample_uv_surface_001.height = 140.0, 100.0
	    group_001_4.width, group_001_4.height = 140.0, 100.0
	    position_001_2.width, position_001_2.height = 140.0, 100.0
	    vector_math_4.width, vector_math_4.height = 140.0, 100.0
	    vector_math_001_4.width, vector_math_001_4.height = 140.0, 100.0
	    vector_math_004_4.width, vector_math_004_4.height = 140.0, 100.0
	    vector_math_003_3.width, vector_math_003_3.height = 140.0, 100.0
	    group_input_003_4.width, group_input_003_4.height = 140.0, 100.0
	    group_input_006_3.width, group_input_006_3.height = 140.0, 100.0
	    switch_003_5.width, switch_003_5.height = 140.0, 100.0
	    switch_002_4.width, switch_002_4.height = 140.0, 100.0
	    vector_math_002_3.width, vector_math_002_3.height = 140.0, 100.0
	    vector_math_005_2.width, vector_math_005_2.height = 140.0, 100.0
	    boolean_math_3.width, boolean_math_3.height = 140.0, 100.0
	    spline_parameter_1.width, spline_parameter_1.height = 140.0, 100.0
	    group_input_008_2.width, group_input_008_2.height = 140.0, 100.0
	    map_range_1.width, map_range_1.height = 140.0, 100.0
	    compare_4.width, compare_4.height = 140.0, 100.0
	    switch_004_2.width, switch_004_2.height = 140.0, 100.0
	    position_002_3.width, position_002_3.height = 140.0, 100.0
	    evaluate_on_domain_2.width, evaluate_on_domain_2.height = 140.0, 100.0
	    reroute_009_3.width, reroute_009_3.height = 100.0, 100.0
	    evaluate_on_domain_002_2.width, evaluate_on_domain_002_2.height = 140.0, 100.0
	    switch_006_1.width, switch_006_1.height = 140.0, 100.0
	    vector_rotate_1.width, vector_rotate_1.height = 140.0, 100.0
	    vector_rotate_003.width, vector_rotate_003.height = 140.0, 100.0
	    align_euler_to_vector_003.width, align_euler_to_vector_003.height = 140.0, 100.0
	    align_euler_to_vector_002.width, align_euler_to_vector_002.height = 140.0, 100.0
	    evaluate_on_domain_003.width, evaluate_on_domain_003.height = 140.0, 100.0
	    switch_001_6.width, switch_001_6.height = 140.0, 100.0
	    accumulate_field_2.width, accumulate_field_2.height = 140.0, 100.0
	    sample_index_001_2.width, sample_index_001_2.height = 140.0, 100.0
	    reroute_019_3.width, reroute_019_3.height = 100.0, 100.0
	    named_attribute_002.width, named_attribute_002.height = 140.0, 100.0
	    reroute_007_3.width, reroute_007_3.height = 100.0, 100.0
	    reroute_008_3.width, reroute_008_3.height = 100.0, 100.0
	    sample_index_2.width, sample_index_2.height = 140.0, 100.0
	
	    #initialize attach_hair_curves_to_surface links
	    #domain_size_002.Face Count -> compare_001_3.A
	    attach_hair_curves_to_surface.links.new(domain_size_002.outputs[2], compare_001_3.inputs[2])
	    #compare_001_3.Result -> switch_005_1.Switch
	    attach_hair_curves_to_surface.links.new(compare_001_3.outputs[0], switch_005_1.inputs[0])
	    #group_input_002_3.Surface -> object_info_001.Object
	    attach_hair_curves_to_surface.links.new(group_input_002_3.outputs[2], object_info_001.inputs[0])
	    #group_input_004_3.Surface -> domain_size_002.Geometry
	    attach_hair_curves_to_surface.links.new(group_input_004_3.outputs[1], domain_size_002.inputs[0])
	    #group_input_004_3.Surface -> switch_005_1.True
	    attach_hair_curves_to_surface.links.new(group_input_004_3.outputs[1], switch_005_1.inputs[2])
	    #group_input_001_4.Surface UV Map -> sample_nearest_surface.Value
	    attach_hair_curves_to_surface.links.new(group_input_001_4.outputs[3], sample_nearest_surface.inputs[1])
	    #reroute_5.Output -> set_position_3.Geometry
	    attach_hair_curves_to_surface.links.new(reroute_5.outputs[0], set_position_3.inputs[0])
	    #reroute_5.Output -> switch_007.False
	    attach_hair_curves_to_surface.links.new(reroute_5.outputs[0], switch_007.inputs[1])
	    #set_position_3.Geometry -> switch_007.True
	    attach_hair_curves_to_surface.links.new(set_position_3.outputs[0], switch_007.inputs[2])
	    #switch_005_1.Output -> reroute_5.Input
	    attach_hair_curves_to_surface.links.new(switch_005_1.outputs[0], reroute_5.inputs[0])
	    #group_input_005_3.Surface Rest Position -> switch_007.Switch
	    attach_hair_curves_to_surface.links.new(group_input_005_3.outputs[4], switch_007.inputs[0])
	    #named_attribute_2.Attribute -> set_position_3.Position
	    attach_hair_curves_to_surface.links.new(named_attribute_2.outputs[0], set_position_3.inputs[2])
	    #named_attribute_2.Exists -> set_position_3.Selection
	    attach_hair_curves_to_surface.links.new(named_attribute_2.outputs[1], set_position_3.inputs[1])
	    #switch_007.Output -> sample_nearest_surface.Mesh
	    attach_hair_curves_to_surface.links.new(switch_007.outputs[0], sample_nearest_surface.inputs[0])
	    #object_info_001.Geometry -> switch_005_1.False
	    attach_hair_curves_to_surface.links.new(object_info_001.outputs[4], switch_005_1.inputs[1])
	    #group_4.Root Position -> sample_nearest_surface.Sample Position
	    attach_hair_curves_to_surface.links.new(group_4.outputs[1], sample_nearest_surface.inputs[3])
	    #reroute_002_3.Output -> sample_uv_surface.UV Map
	    attach_hair_curves_to_surface.links.new(reroute_002_3.outputs[0], sample_uv_surface.inputs[2])
	    #position_2.Position -> sample_uv_surface.Value
	    attach_hair_curves_to_surface.links.new(position_2.outputs[0], sample_uv_surface.inputs[1])
	    #reroute_004_4.Output -> sample_uv_surface.Sample UV
	    attach_hair_curves_to_surface.links.new(reroute_004_4.outputs[0], sample_uv_surface.inputs[3])
	    #capture_attribute_001_3.Geometry -> set_position_001_3.Geometry
	    attach_hair_curves_to_surface.links.new(capture_attribute_001_3.outputs[0], set_position_001_3.inputs[0])
	    #reroute_017_4.Output -> sample_uv_surface_001.Mesh
	    attach_hair_curves_to_surface.links.new(reroute_017_4.outputs[0], sample_uv_surface_001.inputs[0])
	    #reroute_004_4.Output -> sample_uv_surface_001.Sample UV
	    attach_hair_curves_to_surface.links.new(reroute_004_4.outputs[0], sample_uv_surface_001.inputs[3])
	    #reroute_002_3.Output -> sample_uv_surface_001.UV Map
	    attach_hair_curves_to_surface.links.new(reroute_002_3.outputs[0], sample_uv_surface_001.inputs[2])
	    #normal_1.Normal -> capture_attribute_3.Value
	    attach_hair_curves_to_surface.links.new(normal_1.outputs[0], capture_attribute_3.inputs[1])
	    #reroute_018_4.Output -> sample_uv_surface_001.Value
	    attach_hair_curves_to_surface.links.new(reroute_018_4.outputs[0], sample_uv_surface_001.inputs[1])
	    #sample_uv_surface.Value -> vector_math_4.Vector
	    attach_hair_curves_to_surface.links.new(sample_uv_surface.outputs[0], vector_math_4.inputs[0])
	    #group_001_4.Root Position -> vector_math_4.Vector
	    attach_hair_curves_to_surface.links.new(group_001_4.outputs[1], vector_math_4.inputs[1])
	    #vector_math_4.Vector -> evaluate_on_domain_2.Value
	    attach_hair_curves_to_surface.links.new(vector_math_4.outputs[0], evaluate_on_domain_2.inputs[0])
	    #position_001_2.Position -> vector_math_001_4.Vector
	    attach_hair_curves_to_surface.links.new(position_001_2.outputs[0], vector_math_001_4.inputs[0])
	    #group_001_4.Root Position -> vector_math_001_4.Vector
	    attach_hair_curves_to_surface.links.new(group_001_4.outputs[1], vector_math_001_4.inputs[1])
	    #switch_006_1.Output -> vector_rotate_1.Vector
	    attach_hair_curves_to_surface.links.new(switch_006_1.outputs[0], vector_rotate_1.inputs[0])
	    #reroute_007_3.Output -> sample_index_2.Geometry
	    attach_hair_curves_to_surface.links.new(reroute_007_3.outputs[0], sample_index_2.inputs[0])
	    #named_attribute_002.Attribute -> sample_index_2.Index
	    attach_hair_curves_to_surface.links.new(named_attribute_002.outputs[0], sample_index_2.inputs[2])
	    #position_002_3.Position -> vector_math_004_4.Vector
	    attach_hair_curves_to_surface.links.new(position_002_3.outputs[0], vector_math_004_4.inputs[0])
	    #vector_math_002_3.Vector -> vector_math_003_3.Vector
	    attach_hair_curves_to_surface.links.new(vector_math_002_3.outputs[0], vector_math_003_3.inputs[0])
	    #switch_003_5.Output -> vector_math_002_3.Vector
	    attach_hair_curves_to_surface.links.new(switch_003_5.outputs[0], vector_math_002_3.inputs[0])
	    #switch_002_4.Output -> vector_math_002_3.Vector
	    attach_hair_curves_to_surface.links.new(switch_002_4.outputs[0], vector_math_002_3.inputs[1])
	    #reroute_009_3.Output -> vector_rotate_003.Vector
	    attach_hair_curves_to_surface.links.new(reroute_009_3.outputs[0], vector_rotate_003.inputs[0])
	    #evaluate_on_domain_002_2.Value -> vector_rotate_003.Rotation
	    attach_hair_curves_to_surface.links.new(evaluate_on_domain_002_2.outputs[0], vector_rotate_003.inputs[4])
	    #evaluate_on_domain_003.Value -> vector_rotate_1.Rotation
	    attach_hair_curves_to_surface.links.new(evaluate_on_domain_003.outputs[0], vector_rotate_1.inputs[4])
	    #group_001_4.Root Position -> vector_math_004_4.Vector
	    attach_hair_curves_to_surface.links.new(group_001_4.outputs[1], vector_math_004_4.inputs[1])
	    #vector_math_004_4.Vector -> vector_math_003_3.Vector
	    attach_hair_curves_to_surface.links.new(vector_math_004_4.outputs[0], vector_math_003_3.inputs[1])
	    #reroute_016_4.Output -> store_named_attribute_2.Geometry
	    attach_hair_curves_to_surface.links.new(reroute_016_4.outputs[0], store_named_attribute_2.inputs[0])
	    #group_input_5.Geometry -> capture_attribute_002_3.Geometry
	    attach_hair_curves_to_surface.links.new(group_input_5.outputs[0], capture_attribute_002_3.inputs[0])
	    #reroute_003_3.Output -> store_named_attribute_2.Value
	    attach_hair_curves_to_surface.links.new(reroute_003_3.outputs[0], store_named_attribute_2.inputs[3])
	    #sample_nearest_surface.Value -> capture_attribute_002_3.Value
	    attach_hair_curves_to_surface.links.new(sample_nearest_surface.outputs[0], capture_attribute_002_3.inputs[1])
	    #capture_attribute_002_3.Value -> reroute_004_4.Input
	    attach_hair_curves_to_surface.links.new(capture_attribute_002_3.outputs[1], reroute_004_4.inputs[0])
	    #switch_007.Output -> capture_attribute_3.Geometry
	    attach_hair_curves_to_surface.links.new(switch_007.outputs[0], capture_attribute_3.inputs[0])
	    #align_euler_to_vector_003.Rotation -> evaluate_on_domain_002_2.Value
	    attach_hair_curves_to_surface.links.new(align_euler_to_vector_003.outputs[0], evaluate_on_domain_002_2.inputs[0])
	    #align_euler_to_vector_002.Rotation -> evaluate_on_domain_003.Value
	    attach_hair_curves_to_surface.links.new(align_euler_to_vector_002.outputs[0], evaluate_on_domain_003.inputs[0])
	    #capture_attribute_3.Geometry -> reroute_001_5.Input
	    attach_hair_curves_to_surface.links.new(capture_attribute_3.outputs[0], reroute_001_5.inputs[0])
	    #reroute_018_4.Output -> sample_uv_surface_003.Value
	    attach_hair_curves_to_surface.links.new(reroute_018_4.outputs[0], sample_uv_surface_003.inputs[1])
	    #reroute_002_3.Output -> sample_uv_surface_003.UV Map
	    attach_hair_curves_to_surface.links.new(reroute_002_3.outputs[0], sample_uv_surface_003.inputs[2])
	    #reroute_017_4.Output -> sample_uv_surface_003.Mesh
	    attach_hair_curves_to_surface.links.new(reroute_017_4.outputs[0], sample_uv_surface_003.inputs[0])
	    #named_attribute_001.Attribute -> sample_uv_surface_003.Sample UV
	    attach_hair_curves_to_surface.links.new(named_attribute_001.outputs[0], sample_uv_surface_003.inputs[3])
	    #reroute_019_3.Output -> switch_001_6.True
	    attach_hair_curves_to_surface.links.new(reroute_019_3.outputs[0], switch_001_6.inputs[2])
	    #reroute_020_3.Output -> sample_index_001_2.Geometry
	    attach_hair_curves_to_surface.links.new(reroute_020_3.outputs[0], sample_index_001_2.inputs[0])
	    #named_attribute_001.Exists -> accumulate_field_2.Value
	    attach_hair_curves_to_surface.links.new(named_attribute_001.outputs[1], accumulate_field_2.inputs[0])
	    #accumulate_field_2.Total -> sample_index_001_2.Value
	    attach_hair_curves_to_surface.links.new(accumulate_field_2.outputs[2], sample_index_001_2.inputs[1])
	    #sample_index_001_2.Value -> switch_001_6.Switch
	    attach_hair_curves_to_surface.links.new(sample_index_001_2.outputs[0], switch_001_6.inputs[0])
	    #reroute_008_3.Output -> sample_index_2.Value
	    attach_hair_curves_to_surface.links.new(reroute_008_3.outputs[0], sample_index_2.inputs[1])
	    #vector_rotate_1.Vector -> switch_002_4.True
	    attach_hair_curves_to_surface.links.new(vector_rotate_1.outputs[0], switch_002_4.inputs[2])
	    #vector_math_001_4.Vector -> switch_002_4.False
	    attach_hair_curves_to_surface.links.new(vector_math_001_4.outputs[0], switch_002_4.inputs[1])
	    #group_input_003_4.Align to Surface Normal -> switch_002_4.Switch
	    attach_hair_curves_to_surface.links.new(group_input_003_4.outputs[7], switch_002_4.inputs[0])
	    #vector_math_005_2.Vector -> set_position_001_3.Offset
	    attach_hair_curves_to_surface.links.new(vector_math_005_2.outputs[0], set_position_001_3.inputs[3])
	    #evaluate_on_domain_2.Value -> switch_003_5.True
	    attach_hair_curves_to_surface.links.new(evaluate_on_domain_2.outputs[0], switch_003_5.inputs[2])
	    #group_input_006_3.Snap to Surface -> switch_003_5.Switch
	    attach_hair_curves_to_surface.links.new(group_input_006_3.outputs[6], switch_003_5.inputs[0])
	    #group_input_006_3.Snap to Surface -> boolean_math_3.Boolean
	    attach_hair_curves_to_surface.links.new(group_input_006_3.outputs[6], boolean_math_3.inputs[0])
	    #group_input_003_4.Align to Surface Normal -> boolean_math_3.Boolean
	    attach_hair_curves_to_surface.links.new(group_input_003_4.outputs[7], boolean_math_3.inputs[1])
	    #boolean_math_3.Boolean -> set_position_001_3.Selection
	    attach_hair_curves_to_surface.links.new(boolean_math_3.outputs[0], set_position_001_3.inputs[1])
	    #capture_attribute_002_3.Value -> reroute_003_3.Input
	    attach_hair_curves_to_surface.links.new(capture_attribute_002_3.outputs[1], reroute_003_3.inputs[0])
	    #switch_009.Output -> group_output_8.Surface UV Coordinate
	    attach_hair_curves_to_surface.links.new(switch_009.outputs[0], group_output_8.inputs[1])
	    #store_named_attribute_2.Geometry -> switch_5.True
	    attach_hair_curves_to_surface.links.new(store_named_attribute_2.outputs[0], switch_5.inputs[2])
	    #group_input_007_3.Sample Attachment UV -> switch_5.Switch
	    attach_hair_curves_to_surface.links.new(group_input_007_3.outputs[5], switch_5.inputs[0])
	    #reroute_016_4.Output -> switch_5.False
	    attach_hair_curves_to_surface.links.new(reroute_016_4.outputs[0], switch_5.inputs[1])
	    #switch_5.Output -> store_named_attribute_001.Geometry
	    attach_hair_curves_to_surface.links.new(switch_5.outputs[0], store_named_attribute_001.inputs[0])
	    #reroute_020_3.Output -> capture_attribute_001_3.Geometry
	    attach_hair_curves_to_surface.links.new(reroute_020_3.outputs[0], capture_attribute_001_3.inputs[0])
	    #reroute_005_3.Output -> store_named_attribute_001.Value
	    attach_hair_curves_to_surface.links.new(reroute_005_3.outputs[0], store_named_attribute_001.inputs[3])
	    #capture_attribute_001_3.Value -> reroute_005_3.Input
	    attach_hair_curves_to_surface.links.new(capture_attribute_001_3.outputs[1], reroute_005_3.inputs[0])
	    #switch_010.Output -> group_output_8.Surface Normal
	    attach_hair_curves_to_surface.links.new(switch_010.outputs[0], group_output_8.inputs[2])
	    #sample_uv_surface_001.Value -> capture_attribute_001_3.Value
	    attach_hair_curves_to_surface.links.new(sample_uv_surface_001.outputs[0], capture_attribute_001_3.inputs[1])
	    #vector_math_003_3.Vector -> vector_math_005_2.Vector
	    attach_hair_curves_to_surface.links.new(vector_math_003_3.outputs[0], vector_math_005_2.inputs[0])
	    #spline_parameter_1.Factor -> map_range_1.Value
	    attach_hair_curves_to_surface.links.new(spline_parameter_1.outputs[0], map_range_1.inputs[0])
	    #group_input_008_2.Blend along Curve -> map_range_1.From Max
	    attach_hair_curves_to_surface.links.new(group_input_008_2.outputs[8], map_range_1.inputs[2])
	    #group_input_008_2.Blend along Curve -> compare_4.A
	    attach_hair_curves_to_surface.links.new(group_input_008_2.outputs[8], compare_4.inputs[0])
	    #compare_4.Result -> switch_004_2.Switch
	    attach_hair_curves_to_surface.links.new(compare_4.outputs[0], switch_004_2.inputs[0])
	    #map_range_1.Result -> switch_004_2.False
	    attach_hair_curves_to_surface.links.new(map_range_1.outputs[0], switch_004_2.inputs[1])
	    #switch_004_2.Output -> vector_math_005_2.Scale
	    attach_hair_curves_to_surface.links.new(switch_004_2.outputs[0], vector_math_005_2.inputs[3])
	    #switch_001_6.Output -> align_euler_to_vector_003.Vector
	    attach_hair_curves_to_surface.links.new(switch_001_6.outputs[0], align_euler_to_vector_003.inputs[2])
	    #sample_index_2.Value -> switch_001_6.False
	    attach_hair_curves_to_surface.links.new(sample_index_2.outputs[0], switch_001_6.inputs[1])
	    #named_attribute_002.Exists -> switch_006_1.Switch
	    attach_hair_curves_to_surface.links.new(named_attribute_002.outputs[1], switch_006_1.inputs[0])
	    #reroute_009_3.Output -> switch_006_1.False
	    attach_hair_curves_to_surface.links.new(reroute_009_3.outputs[0], switch_006_1.inputs[1])
	    #vector_rotate_003.Vector -> switch_006_1.True
	    attach_hair_curves_to_surface.links.new(vector_rotate_003.outputs[0], switch_006_1.inputs[2])
	    #vector_math_001_4.Vector -> reroute_009_3.Input
	    attach_hair_curves_to_surface.links.new(vector_math_001_4.outputs[0], reroute_009_3.inputs[0])
	    #reroute_011_3.Output -> reroute_010_2.Input
	    attach_hair_curves_to_surface.links.new(reroute_011_3.outputs[0], reroute_010_2.inputs[0])
	    #group_input_5.Geometry -> reroute_011_3.Input
	    attach_hair_curves_to_surface.links.new(group_input_5.outputs[0], reroute_011_3.inputs[0])
	    #store_named_attribute_001.Geometry -> switch_008.False
	    attach_hair_curves_to_surface.links.new(store_named_attribute_001.outputs[0], switch_008.inputs[1])
	    #reroute_006_3.Output -> switch_008.True
	    attach_hair_curves_to_surface.links.new(reroute_006_3.outputs[0], switch_008.inputs[2])
	    #switch_008.Output -> group_output_8.Geometry
	    attach_hair_curves_to_surface.links.new(switch_008.outputs[0], group_output_8.inputs[0])
	    #reroute_003_3.Output -> switch_009.False
	    attach_hair_curves_to_surface.links.new(reroute_003_3.outputs[0], switch_009.inputs[1])
	    #reroute_005_3.Output -> switch_010.False
	    attach_hair_curves_to_surface.links.new(reroute_005_3.outputs[0], switch_010.inputs[1])
	    #domain_size_003.Face Count -> compare_002_3.A
	    attach_hair_curves_to_surface.links.new(domain_size_003.outputs[2], compare_002_3.inputs[2])
	    #switch_005_1.Output -> domain_size_003.Geometry
	    attach_hair_curves_to_surface.links.new(switch_005_1.outputs[0], domain_size_003.inputs[0])
	    #reroute_012_4.Output -> switch_008.Switch
	    attach_hair_curves_to_surface.links.new(reroute_012_4.outputs[0], switch_008.inputs[0])
	    #reroute_014_4.Output -> reroute_012_4.Input
	    attach_hair_curves_to_surface.links.new(reroute_014_4.outputs[0], reroute_012_4.inputs[0])
	    #reroute_012_4.Output -> switch_009.Switch
	    attach_hair_curves_to_surface.links.new(reroute_012_4.outputs[0], switch_009.inputs[0])
	    #reroute_012_4.Output -> switch_010.Switch
	    attach_hair_curves_to_surface.links.new(reroute_012_4.outputs[0], switch_010.inputs[0])
	    #named_attribute_003_1.Attribute -> switch_009.True
	    attach_hair_curves_to_surface.links.new(named_attribute_003_1.outputs[0], switch_009.inputs[2])
	    #named_attribute_004.Attribute -> switch_010.True
	    attach_hair_curves_to_surface.links.new(named_attribute_004.outputs[0], switch_010.inputs[2])
	    #reroute_015_4.Output -> reroute_013_4.Input
	    attach_hair_curves_to_surface.links.new(reroute_015_4.outputs[0], reroute_013_4.inputs[0])
	    #reroute_013_4.Output -> reroute_014_4.Input
	    attach_hair_curves_to_surface.links.new(reroute_013_4.outputs[0], reroute_014_4.inputs[0])
	    #compare_002_3.Result -> reroute_015_4.Input
	    attach_hair_curves_to_surface.links.new(compare_002_3.outputs[0], reroute_015_4.inputs[0])
	    #set_position_001_3.Geometry -> reroute_016_4.Input
	    attach_hair_curves_to_surface.links.new(set_position_001_3.outputs[0], reroute_016_4.inputs[0])
	    #capture_attribute_3.Geometry -> reroute_017_4.Input
	    attach_hair_curves_to_surface.links.new(capture_attribute_3.outputs[0], reroute_017_4.inputs[0])
	    #capture_attribute_3.Value -> reroute_018_4.Input
	    attach_hair_curves_to_surface.links.new(capture_attribute_3.outputs[1], reroute_018_4.inputs[0])
	    #reroute_010_2.Output -> reroute_006_3.Input
	    attach_hair_curves_to_surface.links.new(reroute_010_2.outputs[0], reroute_006_3.inputs[0])
	    #reroute_001_5.Output -> reroute_007_3.Input
	    attach_hair_curves_to_surface.links.new(reroute_001_5.outputs[0], reroute_007_3.inputs[0])
	    #sample_uv_surface_001.Value -> reroute_008_3.Input
	    attach_hair_curves_to_surface.links.new(sample_uv_surface_001.outputs[0], reroute_008_3.inputs[0])
	    #reroute_008_3.Output -> align_euler_to_vector_002.Vector
	    attach_hair_curves_to_surface.links.new(reroute_008_3.outputs[0], align_euler_to_vector_002.inputs[2])
	    #sample_uv_surface_003.Value -> reroute_019_3.Input
	    attach_hair_curves_to_surface.links.new(sample_uv_surface_003.outputs[0], reroute_019_3.inputs[0])
	    #reroute_017_4.Output -> sample_uv_surface.Mesh
	    attach_hair_curves_to_surface.links.new(reroute_017_4.outputs[0], sample_uv_surface.inputs[0])
	    #group_input_009_2.Surface UV Map -> reroute_002_3.Input
	    attach_hair_curves_to_surface.links.new(group_input_009_2.outputs[3], reroute_002_3.inputs[0])
	    #capture_attribute_002_3.Geometry -> reroute_020_3.Input
	    attach_hair_curves_to_surface.links.new(capture_attribute_002_3.outputs[0], reroute_020_3.inputs[0])
	    return attach_hair_curves_to_surface
	
	attach_hair_curves_to_surface = attach_hair_curves_to_surface_node_group()
	
	#initialize hair_card node group
	def hair_card_node_group():
	    hair_card = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Hair_Card")
	
	    hair_card.color_tag = 'NONE'
	    hair_card.description = ""
	    hair_card.default_group_node_width = 140
	    
	
	    hair_card.is_modifier = True
	
	    #hair_card interface
	    #Socket Geometry
	    geometry_socket_8 = hair_card.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_8.attribute_domain = 'POINT'
	
	    #Socket Geometry
	    geometry_socket_9 = hair_card.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_9.attribute_domain = 'POINT'
	
	    #Socket Material
	    material_socket = hair_card.interface.new_socket(name = "Material", in_out='INPUT', socket_type = 'NodeSocketMaterial')
	    material_socket.attribute_domain = 'POINT'
	
	    #Socket Curve Radius
	    curve_radius_socket = hair_card.interface.new_socket(name = "Curve Radius", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    curve_radius_socket.default_value = 1.0
	    curve_radius_socket.min_value = 0.0
	    curve_radius_socket.max_value = 3.4028234663852886e+38
	    curve_radius_socket.subtype = 'DISTANCE'
	    curve_radius_socket.attribute_domain = 'POINT'
	    curve_radius_socket.hide_value = True
	    curve_radius_socket.hide_in_modifier = True
	
	    #Socket Resolution
	    resolution_socket = hair_card.interface.new_socket(name = "Resolution", in_out='INPUT', socket_type = 'NodeSocketInt')
	    resolution_socket.default_value = 0
	    resolution_socket.min_value = 2
	    resolution_socket.max_value = 512
	    resolution_socket.subtype = 'NONE'
	    resolution_socket.attribute_domain = 'POINT'
	
	    #Socket Width
	    width_socket = hair_card.interface.new_socket(name = "Width", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    width_socket.default_value = 0.10000000149011612
	    width_socket.min_value = 0.0
	    width_socket.max_value = 3.4028234663852886e+38
	    width_socket.subtype = 'DISTANCE'
	    width_socket.attribute_domain = 'POINT'
	
	    #Socket Angle
	    angle_socket = hair_card.interface.new_socket(name = "Angle", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    angle_socket.default_value = 45.0
	    angle_socket.min_value = -90.0
	    angle_socket.max_value = 90.0
	    angle_socket.subtype = 'ANGLE'
	    angle_socket.attribute_domain = 'POINT'
	
	
	    #initialize hair_card nodes
	    #node Group Input
	    group_input_6 = hair_card.nodes.new("NodeGroupInput")
	    group_input_6.name = "Group Input"
	    group_input_6.outputs[1].hide = True
	    group_input_6.outputs[2].hide = True
	    group_input_6.outputs[5].hide = True
	    group_input_6.outputs[6].hide = True
	
	    #node Group Output
	    group_output_9 = hair_card.nodes.new("NodeGroupOutput")
	    group_output_9.name = "Group Output"
	    group_output_9.is_active_output = True
	
	    #node Curve to Mesh
	    curve_to_mesh = hair_card.nodes.new("GeometryNodeCurveToMesh")
	    curve_to_mesh.name = "Curve to Mesh"
	    curve_to_mesh.hide = True
	    #Fill Caps
	    curve_to_mesh.inputs[2].default_value = False
	
	    #node Capture Attribute
	    capture_attribute_4 = hair_card.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_4.name = "Capture Attribute"
	    capture_attribute_4.hide = True
	    capture_attribute_4.active_index = 0
	    capture_attribute_4.capture_items.clear()
	    capture_attribute_4.capture_items.new('FLOAT', "Factor")
	    capture_attribute_4.capture_items["Factor"].data_type = 'FLOAT'
	    capture_attribute_4.domain = 'POINT'
	
	    #node Spline Parameter
	    spline_parameter_2 = hair_card.nodes.new("GeometryNodeSplineParameter")
	    spline_parameter_2.name = "Spline Parameter"
	    spline_parameter_2.hide = True
	
	    #node Combine XYZ
	    combine_xyz_2 = hair_card.nodes.new("ShaderNodeCombineXYZ")
	    combine_xyz_2.name = "Combine XYZ"
	    combine_xyz_2.hide = True
	    #Z
	    combine_xyz_2.inputs[2].default_value = 0.0
	
	    #node Store Named Attribute
	    store_named_attribute_3 = hair_card.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_3.name = "Store Named Attribute"
	    store_named_attribute_3.data_type = 'FLOAT2'
	    store_named_attribute_3.domain = 'CORNER'
	    #Selection
	    store_named_attribute_3.inputs[1].default_value = True
	    #Name
	    store_named_attribute_3.inputs[2].default_value = "hair_card_UV"
	
	    #node Set Material
	    set_material = hair_card.nodes.new("GeometryNodeSetMaterial")
	    set_material.name = "Set Material"
	    set_material.hide = True
	    #Selection
	    set_material.inputs[1].default_value = True
	
	    #node Capture Attribute.002
	    capture_attribute_002_4 = hair_card.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_002_4.name = "Capture Attribute.002"
	    capture_attribute_002_4.hide = True
	    capture_attribute_002_4.active_index = 0
	    capture_attribute_002_4.capture_items.clear()
	    capture_attribute_002_4.capture_items.new('FLOAT', "Factor")
	    capture_attribute_002_4.capture_items["Factor"].data_type = 'FLOAT'
	    capture_attribute_002_4.domain = 'POINT'
	
	    #node Reroute
	    reroute_6 = hair_card.nodes.new("NodeReroute")
	    reroute_6.name = "Reroute"
	    reroute_6.socket_idname = "NodeSocketFloat"
	    #node Group Input.001
	    group_input_001_5 = hair_card.nodes.new("NodeGroupInput")
	    group_input_001_5.name = "Group Input.001"
	    group_input_001_5.outputs[0].hide = True
	    group_input_001_5.outputs[2].hide = True
	    group_input_001_5.outputs[3].hide = True
	    group_input_001_5.outputs[4].hide = True
	    group_input_001_5.outputs[5].hide = True
	    group_input_001_5.outputs[6].hide = True
	
	    #node Reroute.001
	    reroute_001_6 = hair_card.nodes.new("NodeReroute")
	    reroute_001_6.name = "Reroute.001"
	    reroute_001_6.socket_idname = "NodeSocketFloatDistance"
	    #node Resample Curve
	    resample_curve = hair_card.nodes.new("GeometryNodeResampleCurve")
	    resample_curve.name = "Resample Curve"
	    resample_curve.hide = True
	    resample_curve.keep_last_segment = False
	    resample_curve.mode = 'COUNT'
	    #Selection
	    resample_curve.inputs[1].default_value = True
	
	    #node Switch
	    switch_6 = hair_card.nodes.new("GeometryNodeSwitch")
	    switch_6.name = "Switch"
	    switch_6.hide = True
	    switch_6.input_type = 'GEOMETRY'
	
	    #node Group Input.002
	    group_input_002_4 = hair_card.nodes.new("NodeGroupInput")
	    group_input_002_4.name = "Group Input.002"
	    group_input_002_4.outputs[0].hide = True
	    group_input_002_4.outputs[1].hide = True
	    group_input_002_4.outputs[2].hide = True
	    group_input_002_4.outputs[4].hide = True
	    group_input_002_4.outputs[5].hide = True
	    group_input_002_4.outputs[6].hide = True
	
	    #node Compare
	    compare_5 = hair_card.nodes.new("FunctionNodeCompare")
	    compare_5.name = "Compare"
	    compare_5.hide = True
	    compare_5.data_type = 'INT'
	    compare_5.mode = 'ELEMENT'
	    compare_5.operation = 'LESS_THAN'
	    #B_INT
	    compare_5.inputs[3].default_value = 2
	
	    #node Reroute.002
	    reroute_002_4 = hair_card.nodes.new("NodeReroute")
	    reroute_002_4.name = "Reroute.002"
	    reroute_002_4.socket_idname = "NodeSocketGeometry"
	    #node Group Input.003
	    group_input_003_5 = hair_card.nodes.new("NodeGroupInput")
	    group_input_003_5.name = "Group Input.003"
	    group_input_003_5.outputs[0].hide = True
	    group_input_003_5.outputs[1].hide = True
	    group_input_003_5.outputs[2].hide = True
	    group_input_003_5.outputs[3].hide = True
	    group_input_003_5.outputs[4].hide = True
	    group_input_003_5.outputs[6].hide = True
	
	    #node Points
	    points = hair_card.nodes.new("GeometryNodePoints")
	    points.name = "Points"
	    points.hide = True
	    #Count
	    points.inputs[0].default_value = 1
	    #Position
	    points.inputs[1].default_value = (0.0, 0.0, 0.0)
	    #Radius
	    points.inputs[2].default_value = 0.10000000149011612
	
	    #node Points.001
	    points_001 = hair_card.nodes.new("GeometryNodePoints")
	    points_001.name = "Points.001"
	    points_001.hide = True
	    #Count
	    points_001.inputs[0].default_value = 1
	    #Radius
	    points_001.inputs[2].default_value = 0.10000000149011612
	
	    #node Points.002
	    points_002 = hair_card.nodes.new("GeometryNodePoints")
	    points_002.name = "Points.002"
	    points_002.hide = True
	    #Count
	    points_002.inputs[0].default_value = 1
	    #Radius
	    points_002.inputs[2].default_value = 0.10000000149011612
	
	    #node Points to Curves
	    points_to_curves = hair_card.nodes.new("GeometryNodePointsToCurves")
	    points_to_curves.name = "Points to Curves"
	    points_to_curves.hide = True
	    #Curve Group ID
	    points_to_curves.inputs[1].default_value = 0
	    #Weight
	    points_to_curves.inputs[2].default_value = 0.0
	
	    #node Join Geometry
	    join_geometry_2 = hair_card.nodes.new("GeometryNodeJoinGeometry")
	    join_geometry_2.name = "Join Geometry"
	    join_geometry_2.hide = True
	
	    #node Vector Rotate
	    vector_rotate_2 = hair_card.nodes.new("ShaderNodeVectorRotate")
	    vector_rotate_2.name = "Vector Rotate"
	    vector_rotate_2.hide = True
	    vector_rotate_2.invert = False
	    vector_rotate_2.rotation_type = 'AXIS_ANGLE'
	    #Center
	    vector_rotate_2.inputs[1].default_value = (0.0, 0.0, 0.0)
	    #Axis
	    vector_rotate_2.inputs[2].default_value = (0.0, 0.0, 1.0)
	
	    #node Combine XYZ.003
	    combine_xyz_003 = hair_card.nodes.new("ShaderNodeCombineXYZ")
	    combine_xyz_003.name = "Combine XYZ.003"
	    combine_xyz_003.hide = True
	    #Y
	    combine_xyz_003.inputs[1].default_value = 0.0
	    #Z
	    combine_xyz_003.inputs[2].default_value = 0.0
	
	    #node Vector Math
	    vector_math_5 = hair_card.nodes.new("ShaderNodeVectorMath")
	    vector_math_5.name = "Vector Math"
	    vector_math_5.hide = True
	    vector_math_5.operation = 'MULTIPLY'
	    #Vector_001
	    vector_math_5.inputs[1].default_value = (-1.0, 1.0, 1.0)
	
	    #node Set Curve Radius
	    set_curve_radius = hair_card.nodes.new("GeometryNodeSetCurveRadius")
	    set_curve_radius.name = "Set Curve Radius"
	    set_curve_radius.hide = True
	    #Selection
	    set_curve_radius.inputs[1].default_value = True
	
	    #node Group Input.004
	    group_input_004_4 = hair_card.nodes.new("NodeGroupInput")
	    group_input_004_4.name = "Group Input.004"
	    group_input_004_4.outputs[0].hide = True
	    group_input_004_4.outputs[1].hide = True
	    group_input_004_4.outputs[3].hide = True
	    group_input_004_4.outputs[4].hide = True
	    group_input_004_4.outputs[5].hide = True
	    group_input_004_4.outputs[6].hide = True
	
	    #node Reroute.003
	    reroute_003_4 = hair_card.nodes.new("NodeReroute")
	    reroute_003_4.name = "Reroute.003"
	    reroute_003_4.socket_idname = "NodeSocketFloatDistance"
	    #node Reroute.004
	    reroute_004_5 = hair_card.nodes.new("NodeReroute")
	    reroute_004_5.name = "Reroute.004"
	    reroute_004_5.socket_idname = "NodeSocketFloatDistance"
	
	
	
	
	    #Set locations
	    group_input_6.location = (-340.0, 0.0)
	    group_output_9.location = (1204.581787109375, 58.388336181640625)
	    curve_to_mesh.location = (717.3101196289062, -30.657630920410156)
	    capture_attribute_4.location = (532.3717651367188, -13.901289939880371)
	    spline_parameter_2.location = (329.8749084472656, -144.0863800048828)
	    combine_xyz_2.location = (717.11865234375, -93.34249114990234)
	    store_named_attribute_3.location = (883.1387329101562, 66.61811828613281)
	    set_material.location = (1044.3658447265625, 32.40200424194336)
	    capture_attribute_002_4.location = (534.5352783203125, -74.45401000976562)
	    reroute_6.location = (496.6486511230469, -141.76992797851562)
	    group_input_001_5.location = (1041.4315185546875, 1.5365350246429443)
	    reroute_001_6.location = (-187.22337341308594, -77.96863555908203)
	    resample_curve.location = (-5.360104560852051, -28.505603790283203)
	    switch_6.location = (-5.43592643737793, 6.486942291259766)
	    group_input_002_4.location = (-336.779052734375, 70.9764633178711)
	    compare_5.location = (-8.656487464904785, 41.045326232910156)
	    reroute_002_4.location = (-99.20211791992188, -32.54893493652344)
	    group_input_003_5.location = (-339.9999694824219, -103.2856674194336)
	    points.location = (156.70631408691406, -123.0439224243164)
	    points_001.location = (156.70632934570312, -81.72965240478516)
	    points_002.location = (158.99679565429688, -168.9486846923828)
	    points_to_curves.location = (321.6205749511719, -74.84392547607422)
	    join_geometry_2.location = (328.4919128417969, -106.97728729248047)
	    vector_rotate_2.location = (-8.371872901916504, -97.79617309570312)
	    combine_xyz_003.location = (-168.62094116210938, -79.79706573486328)
	    vector_math_5.location = (-6.081514358520508, -135.33193969726562)
	    set_curve_radius.location = (320.7674560546875, -1.0603179931640625)
	    group_input_004_4.location = (-334.8185729980469, 133.8203125)
	    reroute_003_4.location = (237.70924377441406, 97.4658203125)
	    reroute_004_5.location = (241.74778747558594, -21.909408569335938)
	
	    #Set dimensions
	    group_input_6.width, group_input_6.height = 140.0, 100.0
	    group_output_9.width, group_output_9.height = 140.0, 100.0
	    curve_to_mesh.width, curve_to_mesh.height = 140.0, 100.0
	    capture_attribute_4.width, capture_attribute_4.height = 140.0, 100.0
	    spline_parameter_2.width, spline_parameter_2.height = 140.0, 100.0
	    combine_xyz_2.width, combine_xyz_2.height = 140.0, 100.0
	    store_named_attribute_3.width, store_named_attribute_3.height = 140.0, 100.0
	    set_material.width, set_material.height = 140.0, 100.0
	    capture_attribute_002_4.width, capture_attribute_002_4.height = 140.0, 100.0
	    reroute_6.width, reroute_6.height = 100.0, 100.0
	    group_input_001_5.width, group_input_001_5.height = 140.0, 100.0
	    reroute_001_6.width, reroute_001_6.height = 100.0, 100.0
	    resample_curve.width, resample_curve.height = 140.0, 100.0
	    switch_6.width, switch_6.height = 140.0, 100.0
	    group_input_002_4.width, group_input_002_4.height = 140.0, 100.0
	    compare_5.width, compare_5.height = 140.0, 100.0
	    reroute_002_4.width, reroute_002_4.height = 100.0, 100.0
	    group_input_003_5.width, group_input_003_5.height = 140.0, 100.0
	    points.width, points.height = 140.0, 100.0
	    points_001.width, points_001.height = 140.0, 100.0
	    points_002.width, points_002.height = 140.0, 100.0
	    points_to_curves.width, points_to_curves.height = 140.0, 100.0
	    join_geometry_2.width, join_geometry_2.height = 140.0, 100.0
	    vector_rotate_2.width, vector_rotate_2.height = 140.0, 100.0
	    combine_xyz_003.width, combine_xyz_003.height = 140.0, 100.0
	    vector_math_5.width, vector_math_5.height = 140.0, 100.0
	    set_curve_radius.width, set_curve_radius.height = 140.0, 100.0
	    group_input_004_4.width, group_input_004_4.height = 140.0, 100.0
	    reroute_003_4.width, reroute_003_4.height = 100.0, 100.0
	    reroute_004_5.width, reroute_004_5.height = 100.0, 100.0
	
	    #initialize hair_card links
	    #set_material.Geometry -> group_output_9.Geometry
	    hair_card.links.new(set_material.outputs[0], group_output_9.inputs[0])
	    #capture_attribute_4.Geometry -> curve_to_mesh.Curve
	    hair_card.links.new(capture_attribute_4.outputs[0], curve_to_mesh.inputs[0])
	    #reroute_6.Output -> capture_attribute_4.Factor
	    hair_card.links.new(reroute_6.outputs[0], capture_attribute_4.inputs[1])
	    #capture_attribute_4.Factor -> combine_xyz_2.X
	    hair_card.links.new(capture_attribute_4.outputs[1], combine_xyz_2.inputs[0])
	    #curve_to_mesh.Mesh -> store_named_attribute_3.Geometry
	    hair_card.links.new(curve_to_mesh.outputs[0], store_named_attribute_3.inputs[0])
	    #combine_xyz_2.Vector -> store_named_attribute_3.Value
	    hair_card.links.new(combine_xyz_2.outputs[0], store_named_attribute_3.inputs[3])
	    #store_named_attribute_3.Geometry -> set_material.Geometry
	    hair_card.links.new(store_named_attribute_3.outputs[0], set_material.inputs[0])
	    #reroute_6.Output -> capture_attribute_002_4.Factor
	    hair_card.links.new(reroute_6.outputs[0], capture_attribute_002_4.inputs[1])
	    #capture_attribute_002_4.Factor -> combine_xyz_2.Y
	    hair_card.links.new(capture_attribute_002_4.outputs[1], combine_xyz_2.inputs[1])
	    #spline_parameter_2.Factor -> reroute_6.Input
	    hair_card.links.new(spline_parameter_2.outputs[0], reroute_6.inputs[0])
	    #group_input_001_5.Material -> set_material.Material
	    hair_card.links.new(group_input_001_5.outputs[1], set_material.inputs[2])
	    #group_input_6.Width -> reroute_001_6.Input
	    hair_card.links.new(group_input_6.outputs[4], reroute_001_6.inputs[0])
	    #reroute_002_4.Output -> resample_curve.Curve
	    hair_card.links.new(reroute_002_4.outputs[0], resample_curve.inputs[0])
	    #group_input_6.Resolution -> resample_curve.Count
	    hair_card.links.new(group_input_6.outputs[3], resample_curve.inputs[2])
	    #group_input_002_4.Resolution -> compare_5.A
	    hair_card.links.new(group_input_002_4.outputs[3], compare_5.inputs[2])
	    #compare_5.Result -> switch_6.Switch
	    hair_card.links.new(compare_5.outputs[0], switch_6.inputs[0])
	    #set_curve_radius.Curve -> capture_attribute_4.Geometry
	    hair_card.links.new(set_curve_radius.outputs[0], capture_attribute_4.inputs[0])
	    #group_input_6.Geometry -> reroute_002_4.Input
	    hair_card.links.new(group_input_6.outputs[0], reroute_002_4.inputs[0])
	    #reroute_002_4.Output -> switch_6.True
	    hair_card.links.new(reroute_002_4.outputs[0], switch_6.inputs[2])
	    #resample_curve.Curve -> switch_6.False
	    hair_card.links.new(resample_curve.outputs[0], switch_6.inputs[1])
	    #join_geometry_2.Geometry -> points_to_curves.Points
	    hair_card.links.new(join_geometry_2.outputs[0], points_to_curves.inputs[0])
	    #points_002.Points -> join_geometry_2.Geometry
	    hair_card.links.new(points_002.outputs[0], join_geometry_2.inputs[0])
	    #group_input_003_5.Angle -> vector_rotate_2.Angle
	    hair_card.links.new(group_input_003_5.outputs[5], vector_rotate_2.inputs[3])
	    #vector_rotate_2.Vector -> vector_math_5.Vector
	    hair_card.links.new(vector_rotate_2.outputs[0], vector_math_5.inputs[0])
	    #vector_rotate_2.Vector -> points_001.Position
	    hair_card.links.new(vector_rotate_2.outputs[0], points_001.inputs[1])
	    #vector_math_5.Vector -> points_002.Position
	    hair_card.links.new(vector_math_5.outputs[0], points_002.inputs[1])
	    #combine_xyz_003.Vector -> vector_rotate_2.Vector
	    hair_card.links.new(combine_xyz_003.outputs[0], vector_rotate_2.inputs[0])
	    #reroute_001_6.Output -> combine_xyz_003.X
	    hair_card.links.new(reroute_001_6.outputs[0], combine_xyz_003.inputs[0])
	    #points_to_curves.Curves -> capture_attribute_002_4.Geometry
	    hair_card.links.new(points_to_curves.outputs[0], capture_attribute_002_4.inputs[0])
	    #capture_attribute_002_4.Geometry -> curve_to_mesh.Profile Curve
	    hair_card.links.new(capture_attribute_002_4.outputs[0], curve_to_mesh.inputs[1])
	    #switch_6.Output -> set_curve_radius.Curve
	    hair_card.links.new(switch_6.outputs[0], set_curve_radius.inputs[0])
	    #reroute_004_5.Output -> set_curve_radius.Radius
	    hair_card.links.new(reroute_004_5.outputs[0], set_curve_radius.inputs[2])
	    #group_input_004_4.Curve Radius -> reroute_003_4.Input
	    hair_card.links.new(group_input_004_4.outputs[2], reroute_003_4.inputs[0])
	    #reroute_003_4.Output -> reroute_004_5.Input
	    hair_card.links.new(reroute_003_4.outputs[0], reroute_004_5.inputs[0])
	    #points.Points -> join_geometry_2.Geometry
	    hair_card.links.new(points.outputs[0], join_geometry_2.inputs[0])
	    #points_001.Points -> join_geometry_2.Geometry
	    hair_card.links.new(points_001.outputs[0], join_geometry_2.inputs[0])
	    return hair_card
	
	hair_card = hair_card_node_group()
	
	#initialize stylized_hair node group
	def stylized_hair_node_group():
	    stylized_hair = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Stylized_Hair")
	
	    stylized_hair.color_tag = 'NONE'
	    stylized_hair.description = ""
	    stylized_hair.default_group_node_width = 140
	    
	
	    stylized_hair.is_modifier = True
	
	    #stylized_hair interface
	    #Socket Geometry
	    geometry_socket_10 = stylized_hair.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_10.attribute_domain = 'POINT'
	
	    #Socket Geometry
	    geometry_socket_11 = stylized_hair.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_11.attribute_domain = 'POINT'
	
	    #Socket Profile
	    profile_socket = stylized_hair.interface.new_socket(name = "Profile", in_out='INPUT', socket_type = 'NodeSocketObject')
	    profile_socket.attribute_domain = 'POINT'
	
	    #Socket Material
	    material_socket_1 = stylized_hair.interface.new_socket(name = "Material", in_out='INPUT', socket_type = 'NodeSocketMaterial')
	    material_socket_1.attribute_domain = 'POINT'
	
	    #Socket Curve Radius
	    curve_radius_socket_1 = stylized_hair.interface.new_socket(name = "Curve Radius", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    curve_radius_socket_1.default_value = 1.0
	    curve_radius_socket_1.min_value = 0.0
	    curve_radius_socket_1.max_value = 3.4028234663852886e+38
	    curve_radius_socket_1.subtype = 'DISTANCE'
	    curve_radius_socket_1.attribute_domain = 'POINT'
	    curve_radius_socket_1.hide_value = True
	    curve_radius_socket_1.hide_in_modifier = True
	
	    #Socket Resolution
	    resolution_socket_1 = stylized_hair.interface.new_socket(name = "Resolution", in_out='INPUT', socket_type = 'NodeSocketInt')
	    resolution_socket_1.default_value = 10
	    resolution_socket_1.min_value = 1
	    resolution_socket_1.max_value = 100000
	    resolution_socket_1.subtype = 'NONE'
	    resolution_socket_1.attribute_domain = 'POINT'
	
	    #Socket Fill Caps
	    fill_caps_socket = stylized_hair.interface.new_socket(name = "Fill Caps", in_out='INPUT', socket_type = 'NodeSocketBool')
	    fill_caps_socket.default_value = True
	    fill_caps_socket.attribute_domain = 'POINT'
	
	    #Socket Translation
	    translation_socket = stylized_hair.interface.new_socket(name = "Translation", in_out='INPUT', socket_type = 'NodeSocketVector')
	    translation_socket.default_value = (0.0, 0.0, 0.0)
	    translation_socket.min_value = -3.4028234663852886e+38
	    translation_socket.max_value = 3.4028234663852886e+38
	    translation_socket.subtype = 'TRANSLATION'
	    translation_socket.attribute_domain = 'POINT'
	
	    #Socket Rotation
	    rotation_socket = stylized_hair.interface.new_socket(name = "Rotation", in_out='INPUT', socket_type = 'NodeSocketRotation')
	    rotation_socket.default_value = (0.0, 0.0, 0.0)
	    rotation_socket.attribute_domain = 'POINT'
	
	    #Socket Scale
	    scale_socket = stylized_hair.interface.new_socket(name = "Scale", in_out='INPUT', socket_type = 'NodeSocketVector')
	    scale_socket.default_value = (1.0, 1.0, 1.0)
	    scale_socket.min_value = -3.4028234663852886e+38
	    scale_socket.max_value = 3.4028234663852886e+38
	    scale_socket.subtype = 'XYZ'
	    scale_socket.attribute_domain = 'POINT'
	
	
	    #initialize stylized_hair nodes
	    #node Group Input
	    group_input_7 = stylized_hair.nodes.new("NodeGroupInput")
	    group_input_7.name = "Group Input"
	    group_input_7.outputs[2].hide = True
	    group_input_7.outputs[3].hide = True
	    group_input_7.outputs[4].hide = True
	    group_input_7.outputs[5].hide = True
	    group_input_7.outputs[6].hide = True
	    group_input_7.outputs[7].hide = True
	    group_input_7.outputs[8].hide = True
	    group_input_7.outputs[9].hide = True
	
	    #node Group Output
	    group_output_10 = stylized_hair.nodes.new("NodeGroupOutput")
	    group_output_10.name = "Group Output"
	    group_output_10.is_active_output = True
	
	    #node Curve to Mesh
	    curve_to_mesh_1 = stylized_hair.nodes.new("GeometryNodeCurveToMesh")
	    curve_to_mesh_1.name = "Curve to Mesh"
	    curve_to_mesh_1.hide = True
	
	    #node Capture Attribute
	    capture_attribute_5 = stylized_hair.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_5.name = "Capture Attribute"
	    capture_attribute_5.hide = True
	    capture_attribute_5.active_index = 0
	    capture_attribute_5.capture_items.clear()
	    capture_attribute_5.capture_items.new('FLOAT', "Factor")
	    capture_attribute_5.capture_items["Factor"].data_type = 'FLOAT'
	    capture_attribute_5.domain = 'POINT'
	
	    #node Spline Parameter
	    spline_parameter_3 = stylized_hair.nodes.new("GeometryNodeSplineParameter")
	    spline_parameter_3.name = "Spline Parameter"
	    spline_parameter_3.hide = True
	
	    #node Combine XYZ
	    combine_xyz_3 = stylized_hair.nodes.new("ShaderNodeCombineXYZ")
	    combine_xyz_3.name = "Combine XYZ"
	    combine_xyz_3.hide = True
	    #Z
	    combine_xyz_3.inputs[2].default_value = 0.0
	
	    #node Store Named Attribute
	    store_named_attribute_4 = stylized_hair.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_4.name = "Store Named Attribute"
	    store_named_attribute_4.data_type = 'FLOAT2'
	    store_named_attribute_4.domain = 'CORNER'
	    #Selection
	    store_named_attribute_4.inputs[1].default_value = True
	    #Name
	    store_named_attribute_4.inputs[2].default_value = "stylized_hair_UV"
	
	    #node Set Material
	    set_material_1 = stylized_hair.nodes.new("GeometryNodeSetMaterial")
	    set_material_1.name = "Set Material"
	    set_material_1.hide = True
	    #Selection
	    set_material_1.inputs[1].default_value = True
	
	    #node Capture Attribute.002
	    capture_attribute_002_5 = stylized_hair.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_002_5.name = "Capture Attribute.002"
	    capture_attribute_002_5.hide = True
	    capture_attribute_002_5.active_index = 0
	    capture_attribute_002_5.capture_items.clear()
	    capture_attribute_002_5.capture_items.new('FLOAT', "Factor")
	    capture_attribute_002_5.capture_items["Factor"].data_type = 'FLOAT'
	    capture_attribute_002_5.domain = 'POINT'
	
	    #node Reroute
	    reroute_7 = stylized_hair.nodes.new("NodeReroute")
	    reroute_7.name = "Reroute"
	    reroute_7.socket_idname = "NodeSocketFloat"
	    #node Group Input.001
	    group_input_001_6 = stylized_hair.nodes.new("NodeGroupInput")
	    group_input_001_6.name = "Group Input.001"
	    group_input_001_6.outputs[0].hide = True
	    group_input_001_6.outputs[1].hide = True
	    group_input_001_6.outputs[3].hide = True
	    group_input_001_6.outputs[4].hide = True
	    group_input_001_6.outputs[5].hide = True
	    group_input_001_6.outputs[6].hide = True
	    group_input_001_6.outputs[7].hide = True
	    group_input_001_6.outputs[8].hide = True
	    group_input_001_6.outputs[9].hide = True
	
	    #node Group Input.002
	    group_input_002_5 = stylized_hair.nodes.new("NodeGroupInput")
	    group_input_002_5.name = "Group Input.002"
	    group_input_002_5.outputs[0].hide = True
	    group_input_002_5.outputs[1].hide = True
	    group_input_002_5.outputs[2].hide = True
	    group_input_002_5.outputs[3].hide = True
	    group_input_002_5.outputs[4].hide = True
	    group_input_002_5.outputs[6].hide = True
	    group_input_002_5.outputs[7].hide = True
	    group_input_002_5.outputs[8].hide = True
	    group_input_002_5.outputs[9].hide = True
	
	    #node Object Info
	    object_info = stylized_hair.nodes.new("GeometryNodeObjectInfo")
	    object_info.name = "Object Info"
	    object_info.hide = True
	    object_info.transform_space = 'RELATIVE'
	    #As Instance
	    object_info.inputs[1].default_value = False
	
	    #node Transform Geometry
	    transform_geometry = stylized_hair.nodes.new("GeometryNodeTransform")
	    transform_geometry.name = "Transform Geometry"
	    transform_geometry.hide = True
	    transform_geometry.mode = 'COMPONENTS'
	
	    #node Group Input.003
	    group_input_003_6 = stylized_hair.nodes.new("NodeGroupInput")
	    group_input_003_6.name = "Group Input.003"
	    group_input_003_6.outputs[0].hide = True
	    group_input_003_6.outputs[1].hide = True
	    group_input_003_6.outputs[2].hide = True
	    group_input_003_6.outputs[4].hide = True
	    group_input_003_6.outputs[5].hide = True
	    group_input_003_6.outputs[6].hide = True
	    group_input_003_6.outputs[7].hide = True
	    group_input_003_6.outputs[8].hide = True
	    group_input_003_6.outputs[9].hide = True
	
	    #node Group Input.004
	    group_input_004_5 = stylized_hair.nodes.new("NodeGroupInput")
	    group_input_004_5.name = "Group Input.004"
	    group_input_004_5.outputs[0].hide = True
	    group_input_004_5.outputs[1].hide = True
	    group_input_004_5.outputs[2].hide = True
	    group_input_004_5.outputs[3].hide = True
	    group_input_004_5.outputs[4].hide = True
	    group_input_004_5.outputs[5].hide = True
	    group_input_004_5.outputs[9].hide = True
	
	    #node Set Curve Radius
	    set_curve_radius_1 = stylized_hair.nodes.new("GeometryNodeSetCurveRadius")
	    set_curve_radius_1.name = "Set Curve Radius"
	    set_curve_radius_1.hide = True
	    #Selection
	    set_curve_radius_1.inputs[1].default_value = True
	
	    #node Reroute.001
	    reroute_001_7 = stylized_hair.nodes.new("NodeReroute")
	    reroute_001_7.name = "Reroute.001"
	    reroute_001_7.socket_idname = "NodeSocketGeometry"
	    #node Reroute.002
	    reroute_002_5 = stylized_hair.nodes.new("NodeReroute")
	    reroute_002_5.name = "Reroute.002"
	    reroute_002_5.socket_idname = "NodeSocketGeometry"
	    #node Resample Curve
	    resample_curve_1 = stylized_hair.nodes.new("GeometryNodeResampleCurve")
	    resample_curve_1.name = "Resample Curve"
	    resample_curve_1.hide = True
	    resample_curve_1.keep_last_segment = False
	    resample_curve_1.mode = 'COUNT'
	    #Selection
	    resample_curve_1.inputs[1].default_value = True
	
	    #node Switch
	    switch_7 = stylized_hair.nodes.new("GeometryNodeSwitch")
	    switch_7.name = "Switch"
	    switch_7.hide = True
	    switch_7.input_type = 'GEOMETRY'
	
	    #node Compare
	    compare_6 = stylized_hair.nodes.new("FunctionNodeCompare")
	    compare_6.name = "Compare"
	    compare_6.hide = True
	    compare_6.data_type = 'INT'
	    compare_6.mode = 'ELEMENT'
	    compare_6.operation = 'LESS_THAN'
	    #B_INT
	    compare_6.inputs[3].default_value = 2
	
	    #node Reroute.005
	    reroute_005_4 = stylized_hair.nodes.new("NodeReroute")
	    reroute_005_4.name = "Reroute.005"
	    reroute_005_4.socket_idname = "NodeSocketGeometry"
	    #node Group Input.005
	    group_input_005_4 = stylized_hair.nodes.new("NodeGroupInput")
	    group_input_005_4.name = "Group Input.005"
	    group_input_005_4.outputs[0].hide = True
	    group_input_005_4.outputs[1].hide = True
	    group_input_005_4.outputs[2].hide = True
	    group_input_005_4.outputs[3].hide = True
	    group_input_005_4.outputs[5].hide = True
	    group_input_005_4.outputs[6].hide = True
	    group_input_005_4.outputs[7].hide = True
	    group_input_005_4.outputs[8].hide = True
	    group_input_005_4.outputs[9].hide = True
	
	
	
	
	
	    #Set locations
	    group_input_7.location = (-340.0, -125.68765258789062)
	    group_output_10.location = (1046.0562744140625, -35.87745666503906)
	    curve_to_mesh_1.location = (546.74853515625, -108.79241180419922)
	    capture_attribute_5.location = (361.8101501464844, -82.63687133789062)
	    spline_parameter_3.location = (156.93017578125, -142.56178283691406)
	    combine_xyz_3.location = (546.5570068359375, -195.67379760742188)
	    store_named_attribute_4.location = (712.5771484375, -27.647676467895508)
	    set_material_1.location = (873.80419921875, -61.86378860473633)
	    capture_attribute_002_5.location = (363.9737243652344, -168.7198028564453)
	    reroute_7.location = (319.04217529296875, -141.52703857421875)
	    group_input_001_6.location = (870.8699951171875, -92.72925567626953)
	    group_input_002_5.location = (542.2694702148438, -137.2887725830078)
	    object_info.location = (-173.28436279296875, -181.30752563476562)
	    transform_geometry.location = (156.43304443359375, -206.8249053955078)
	    group_input_003_6.location = (-339.0907897949219, -62.643611907958984)
	    group_input_004_5.location = (-338.4869689941406, -211.2111053466797)
	    set_curve_radius_1.location = (158.24813842773438, -76.21592712402344)
	    reroute_001_7.location = (-164.16294860839844, -159.83448791503906)
	    reroute_002_5.location = (-164.90399169921875, -71.62743377685547)
	    resample_curve_1.location = (-36.965057373046875, -67.16246032714844)
	    switch_7.location = (-37.0408821105957, -32.16990661621094)
	    compare_6.location = (-40.26144027709961, 2.388460159301758)
	    reroute_005_4.location = (-130.80706787109375, -71.2057876586914)
	    group_input_005_4.location = (-338.4869689941406, -2.108567237854004)
	
	    #Set dimensions
	    group_input_7.width, group_input_7.height = 140.0, 100.0
	    group_output_10.width, group_output_10.height = 140.0, 100.0
	    curve_to_mesh_1.width, curve_to_mesh_1.height = 140.0, 100.0
	    capture_attribute_5.width, capture_attribute_5.height = 140.0, 100.0
	    spline_parameter_3.width, spline_parameter_3.height = 140.0, 100.0
	    combine_xyz_3.width, combine_xyz_3.height = 140.0, 100.0
	    store_named_attribute_4.width, store_named_attribute_4.height = 140.0, 100.0
	    set_material_1.width, set_material_1.height = 140.0, 100.0
	    capture_attribute_002_5.width, capture_attribute_002_5.height = 140.0, 100.0
	    reroute_7.width, reroute_7.height = 100.0, 100.0
	    group_input_001_6.width, group_input_001_6.height = 140.0, 100.0
	    group_input_002_5.width, group_input_002_5.height = 140.0, 100.0
	    object_info.width, object_info.height = 140.0, 100.0
	    transform_geometry.width, transform_geometry.height = 140.0, 100.0
	    group_input_003_6.width, group_input_003_6.height = 140.0, 100.0
	    group_input_004_5.width, group_input_004_5.height = 140.0, 100.0
	    set_curve_radius_1.width, set_curve_radius_1.height = 140.0, 100.0
	    reroute_001_7.width, reroute_001_7.height = 100.0, 100.0
	    reroute_002_5.width, reroute_002_5.height = 100.0, 100.0
	    resample_curve_1.width, resample_curve_1.height = 140.0, 100.0
	    switch_7.width, switch_7.height = 140.0, 100.0
	    compare_6.width, compare_6.height = 140.0, 100.0
	    reroute_005_4.width, reroute_005_4.height = 100.0, 100.0
	    group_input_005_4.width, group_input_005_4.height = 140.0, 100.0
	
	    #initialize stylized_hair links
	    #set_material_1.Geometry -> group_output_10.Geometry
	    stylized_hair.links.new(set_material_1.outputs[0], group_output_10.inputs[0])
	    #capture_attribute_5.Geometry -> curve_to_mesh_1.Curve
	    stylized_hair.links.new(capture_attribute_5.outputs[0], curve_to_mesh_1.inputs[0])
	    #set_curve_radius_1.Curve -> capture_attribute_5.Geometry
	    stylized_hair.links.new(set_curve_radius_1.outputs[0], capture_attribute_5.inputs[0])
	    #reroute_7.Output -> capture_attribute_5.Factor
	    stylized_hair.links.new(reroute_7.outputs[0], capture_attribute_5.inputs[1])
	    #capture_attribute_5.Factor -> combine_xyz_3.X
	    stylized_hair.links.new(capture_attribute_5.outputs[1], combine_xyz_3.inputs[0])
	    #curve_to_mesh_1.Mesh -> store_named_attribute_4.Geometry
	    stylized_hair.links.new(curve_to_mesh_1.outputs[0], store_named_attribute_4.inputs[0])
	    #combine_xyz_3.Vector -> store_named_attribute_4.Value
	    stylized_hair.links.new(combine_xyz_3.outputs[0], store_named_attribute_4.inputs[3])
	    #store_named_attribute_4.Geometry -> set_material_1.Geometry
	    stylized_hair.links.new(store_named_attribute_4.outputs[0], set_material_1.inputs[0])
	    #reroute_7.Output -> capture_attribute_002_5.Factor
	    stylized_hair.links.new(reroute_7.outputs[0], capture_attribute_002_5.inputs[1])
	    #capture_attribute_002_5.Factor -> combine_xyz_3.Y
	    stylized_hair.links.new(capture_attribute_002_5.outputs[1], combine_xyz_3.inputs[1])
	    #capture_attribute_002_5.Geometry -> curve_to_mesh_1.Profile Curve
	    stylized_hair.links.new(capture_attribute_002_5.outputs[0], curve_to_mesh_1.inputs[1])
	    #spline_parameter_3.Factor -> reroute_7.Input
	    stylized_hair.links.new(spline_parameter_3.outputs[0], reroute_7.inputs[0])
	    #group_input_001_6.Material -> set_material_1.Material
	    stylized_hair.links.new(group_input_001_6.outputs[2], set_material_1.inputs[2])
	    #group_input_002_5.Fill Caps -> curve_to_mesh_1.Fill Caps
	    stylized_hair.links.new(group_input_002_5.outputs[5], curve_to_mesh_1.inputs[2])
	    #group_input_7.Profile -> object_info.Object
	    stylized_hair.links.new(group_input_7.outputs[1], object_info.inputs[0])
	    #object_info.Geometry -> transform_geometry.Geometry
	    stylized_hair.links.new(object_info.outputs[4], transform_geometry.inputs[0])
	    #transform_geometry.Geometry -> capture_attribute_002_5.Geometry
	    stylized_hair.links.new(transform_geometry.outputs[0], capture_attribute_002_5.inputs[0])
	    #group_input_003_6.Curve Radius -> set_curve_radius_1.Radius
	    stylized_hair.links.new(group_input_003_6.outputs[3], set_curve_radius_1.inputs[2])
	    #group_input_004_5.Translation -> transform_geometry.Translation
	    stylized_hair.links.new(group_input_004_5.outputs[6], transform_geometry.inputs[1])
	    #group_input_004_5.Rotation -> transform_geometry.Rotation
	    stylized_hair.links.new(group_input_004_5.outputs[7], transform_geometry.inputs[2])
	    #group_input_004_5.Scale -> transform_geometry.Scale
	    stylized_hair.links.new(group_input_004_5.outputs[8], transform_geometry.inputs[3])
	    #group_input_7.Geometry -> reroute_001_7.Input
	    stylized_hair.links.new(group_input_7.outputs[0], reroute_001_7.inputs[0])
	    #reroute_001_7.Output -> reroute_002_5.Input
	    stylized_hair.links.new(reroute_001_7.outputs[0], reroute_002_5.inputs[0])
	    #reroute_005_4.Output -> resample_curve_1.Curve
	    stylized_hair.links.new(reroute_005_4.outputs[0], resample_curve_1.inputs[0])
	    #compare_6.Result -> switch_7.Switch
	    stylized_hair.links.new(compare_6.outputs[0], switch_7.inputs[0])
	    #reroute_005_4.Output -> switch_7.True
	    stylized_hair.links.new(reroute_005_4.outputs[0], switch_7.inputs[2])
	    #resample_curve_1.Curve -> switch_7.False
	    stylized_hair.links.new(resample_curve_1.outputs[0], switch_7.inputs[1])
	    #group_input_005_4.Resolution -> resample_curve_1.Count
	    stylized_hair.links.new(group_input_005_4.outputs[4], resample_curve_1.inputs[2])
	    #group_input_005_4.Resolution -> compare_6.A
	    stylized_hair.links.new(group_input_005_4.outputs[4], compare_6.inputs[2])
	    #switch_7.Output -> set_curve_radius_1.Curve
	    stylized_hair.links.new(switch_7.outputs[0], set_curve_radius_1.inputs[0])
	    #reroute_002_5.Output -> reroute_005_4.Input
	    stylized_hair.links.new(reroute_002_5.outputs[0], reroute_005_4.inputs[0])
	    return stylized_hair
	
	stylized_hair = stylized_hair_node_group()
	
	#initialize tube_mesh node group
	def tube_mesh_node_group():
	    tube_mesh = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Tube_Mesh")
	
	    tube_mesh.color_tag = 'NONE'
	    tube_mesh.description = ""
	    tube_mesh.default_group_node_width = 140
	    
	
	    tube_mesh.is_modifier = True
	
	    #tube_mesh interface
	    #Socket Geometry
	    geometry_socket_12 = tube_mesh.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_12.attribute_domain = 'POINT'
	
	    #Socket Geometry
	    geometry_socket_13 = tube_mesh.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_13.attribute_domain = 'POINT'
	
	    #Socket Material
	    material_socket_2 = tube_mesh.interface.new_socket(name = "Material", in_out='INPUT', socket_type = 'NodeSocketMaterial')
	    material_socket_2.attribute_domain = 'POINT'
	
	    #Socket Curve Radius
	    curve_radius_socket_2 = tube_mesh.interface.new_socket(name = "Curve Radius", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    curve_radius_socket_2.default_value = 1.0
	    curve_radius_socket_2.min_value = 0.0
	    curve_radius_socket_2.max_value = 3.4028234663852886e+38
	    curve_radius_socket_2.subtype = 'DISTANCE'
	    curve_radius_socket_2.attribute_domain = 'POINT'
	    curve_radius_socket_2.hide_value = True
	    curve_radius_socket_2.hide_in_modifier = True
	
	    #Socket Resolution
	    resolution_socket_2 = tube_mesh.interface.new_socket(name = "Resolution", in_out='INPUT', socket_type = 'NodeSocketInt')
	    resolution_socket_2.default_value = 32
	    resolution_socket_2.min_value = 3
	    resolution_socket_2.max_value = 512
	    resolution_socket_2.subtype = 'NONE'
	    resolution_socket_2.attribute_domain = 'POINT'
	
	    #Socket Width
	    width_socket_1 = tube_mesh.interface.new_socket(name = "Width", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    width_socket_1.default_value = 0.10000000149011612
	    width_socket_1.min_value = 0.0
	    width_socket_1.max_value = 3.4028234663852886e+38
	    width_socket_1.subtype = 'DISTANCE'
	    width_socket_1.attribute_domain = 'POINT'
	
	    #Socket Fill Caps
	    fill_caps_socket_1 = tube_mesh.interface.new_socket(name = "Fill Caps", in_out='INPUT', socket_type = 'NodeSocketBool')
	    fill_caps_socket_1.default_value = True
	    fill_caps_socket_1.attribute_domain = 'POINT'
	
	
	    #initialize tube_mesh nodes
	    #node Group Input
	    group_input_8 = tube_mesh.nodes.new("NodeGroupInput")
	    group_input_8.name = "Group Input"
	    group_input_8.outputs[1].hide = True
	    group_input_8.outputs[2].hide = True
	    group_input_8.outputs[5].hide = True
	    group_input_8.outputs[6].hide = True
	
	    #node Group Output
	    group_output_11 = tube_mesh.nodes.new("NodeGroupOutput")
	    group_output_11.name = "Group Output"
	    group_output_11.is_active_output = True
	
	    #node Curve to Mesh
	    curve_to_mesh_2 = tube_mesh.nodes.new("GeometryNodeCurveToMesh")
	    curve_to_mesh_2.name = "Curve to Mesh"
	    curve_to_mesh_2.hide = True
	
	    #node Capture Attribute
	    capture_attribute_6 = tube_mesh.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_6.name = "Capture Attribute"
	    capture_attribute_6.hide = True
	    capture_attribute_6.active_index = 0
	    capture_attribute_6.capture_items.clear()
	    capture_attribute_6.capture_items.new('FLOAT', "Factor")
	    capture_attribute_6.capture_items["Factor"].data_type = 'FLOAT'
	    capture_attribute_6.domain = 'POINT'
	
	    #node Spline Parameter
	    spline_parameter_4 = tube_mesh.nodes.new("GeometryNodeSplineParameter")
	    spline_parameter_4.name = "Spline Parameter"
	    spline_parameter_4.hide = True
	
	    #node Combine XYZ
	    combine_xyz_4 = tube_mesh.nodes.new("ShaderNodeCombineXYZ")
	    combine_xyz_4.name = "Combine XYZ"
	    combine_xyz_4.hide = True
	    #Z
	    combine_xyz_4.inputs[2].default_value = 0.0
	
	    #node Store Named Attribute
	    store_named_attribute_5 = tube_mesh.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_5.name = "Store Named Attribute"
	    store_named_attribute_5.data_type = 'FLOAT2'
	    store_named_attribute_5.domain = 'CORNER'
	    #Selection
	    store_named_attribute_5.inputs[1].default_value = True
	    #Name
	    store_named_attribute_5.inputs[2].default_value = "tube_mesh_UV"
	
	    #node Set Material
	    set_material_2 = tube_mesh.nodes.new("GeometryNodeSetMaterial")
	    set_material_2.name = "Set Material"
	    set_material_2.hide = True
	    #Selection
	    set_material_2.inputs[1].default_value = True
	
	    #node Curve Circle
	    curve_circle = tube_mesh.nodes.new("GeometryNodeCurvePrimitiveCircle")
	    curve_circle.name = "Curve Circle"
	    curve_circle.hide = True
	    curve_circle.mode = 'RADIUS'
	    #Resolution
	    curve_circle.inputs[0].default_value = 16
	
	    #node Capture Attribute.002
	    capture_attribute_002_6 = tube_mesh.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_002_6.name = "Capture Attribute.002"
	    capture_attribute_002_6.hide = True
	    capture_attribute_002_6.active_index = 0
	    capture_attribute_002_6.capture_items.clear()
	    capture_attribute_002_6.capture_items.new('FLOAT', "Factor")
	    capture_attribute_002_6.capture_items["Factor"].data_type = 'FLOAT'
	    capture_attribute_002_6.domain = 'POINT'
	
	    #node Reroute
	    reroute_8 = tube_mesh.nodes.new("NodeReroute")
	    reroute_8.name = "Reroute"
	    reroute_8.socket_idname = "NodeSocketFloat"
	    #node Group Input.001
	    group_input_001_7 = tube_mesh.nodes.new("NodeGroupInput")
	    group_input_001_7.name = "Group Input.001"
	    group_input_001_7.outputs[0].hide = True
	    group_input_001_7.outputs[2].hide = True
	    group_input_001_7.outputs[3].hide = True
	    group_input_001_7.outputs[4].hide = True
	    group_input_001_7.outputs[5].hide = True
	    group_input_001_7.outputs[6].hide = True
	
	    #node Group Input.002
	    group_input_002_6 = tube_mesh.nodes.new("NodeGroupInput")
	    group_input_002_6.name = "Group Input.002"
	    group_input_002_6.outputs[0].hide = True
	    group_input_002_6.outputs[1].hide = True
	    group_input_002_6.outputs[2].hide = True
	    group_input_002_6.outputs[3].hide = True
	    group_input_002_6.outputs[4].hide = True
	    group_input_002_6.outputs[6].hide = True
	
	    #node Set Curve Radius
	    set_curve_radius_2 = tube_mesh.nodes.new("GeometryNodeSetCurveRadius")
	    set_curve_radius_2.name = "Set Curve Radius"
	    set_curve_radius_2.hide = True
	    #Selection
	    set_curve_radius_2.inputs[1].default_value = True
	
	    #node Group Input.003
	    group_input_003_7 = tube_mesh.nodes.new("NodeGroupInput")
	    group_input_003_7.name = "Group Input.003"
	    group_input_003_7.outputs[0].hide = True
	    group_input_003_7.outputs[1].hide = True
	    group_input_003_7.outputs[3].hide = True
	    group_input_003_7.outputs[4].hide = True
	    group_input_003_7.outputs[5].hide = True
	    group_input_003_7.outputs[6].hide = True
	
	    #node Resample Curve
	    resample_curve_2 = tube_mesh.nodes.new("GeometryNodeResampleCurve")
	    resample_curve_2.name = "Resample Curve"
	    resample_curve_2.hide = True
	    resample_curve_2.keep_last_segment = False
	    resample_curve_2.mode = 'COUNT'
	    #Selection
	    resample_curve_2.inputs[1].default_value = True
	
	    #node Switch
	    switch_8 = tube_mesh.nodes.new("GeometryNodeSwitch")
	    switch_8.name = "Switch"
	    switch_8.hide = True
	    switch_8.input_type = 'GEOMETRY'
	
	    #node Compare
	    compare_7 = tube_mesh.nodes.new("FunctionNodeCompare")
	    compare_7.name = "Compare"
	    compare_7.hide = True
	    compare_7.data_type = 'INT'
	    compare_7.mode = 'ELEMENT'
	    compare_7.operation = 'LESS_THAN'
	    #B_INT
	    compare_7.inputs[3].default_value = 2
	
	    #node Reroute.003
	    reroute_003_5 = tube_mesh.nodes.new("NodeReroute")
	    reroute_003_5.name = "Reroute.003"
	    reroute_003_5.socket_idname = "NodeSocketGeometry"
	    #node Group Input.004
	    group_input_004_6 = tube_mesh.nodes.new("NodeGroupInput")
	    group_input_004_6.name = "Group Input.004"
	    group_input_004_6.outputs[0].hide = True
	    group_input_004_6.outputs[1].hide = True
	    group_input_004_6.outputs[2].hide = True
	    group_input_004_6.outputs[4].hide = True
	    group_input_004_6.outputs[5].hide = True
	    group_input_004_6.outputs[6].hide = True
	
	    #node Reroute.006
	    reroute_006_4 = tube_mesh.nodes.new("NodeReroute")
	    reroute_006_4.name = "Reroute.006"
	    reroute_006_4.socket_idname = "NodeSocketFloatDistance"
	    #node Reroute.007
	    reroute_007_4 = tube_mesh.nodes.new("NodeReroute")
	    reroute_007_4.name = "Reroute.007"
	    reroute_007_4.socket_idname = "NodeSocketFloatDistance"
	    #node Reroute.008
	    reroute_008_4 = tube_mesh.nodes.new("NodeReroute")
	    reroute_008_4.name = "Reroute.008"
	    reroute_008_4.socket_idname = "NodeSocketInt"
	    #node Reroute.009
	    reroute_009_4 = tube_mesh.nodes.new("NodeReroute")
	    reroute_009_4.name = "Reroute.009"
	    reroute_009_4.socket_idname = "NodeSocketInt"
	
	
	
	
	    #Set locations
	    group_input_8.location = (-340.0, 0.0)
	    group_output_11.location = (953.9598388671875, 58.388336181640625)
	    curve_to_mesh_2.location = (466.6881408691406, -14.526612281799316)
	    capture_attribute_6.location = (281.749755859375, -33.53998565673828)
	    spline_parameter_4.location = (84.9455795288086, -92.41136169433594)
	    combine_xyz_4.location = (466.4966735839844, -101.40799713134766)
	    store_named_attribute_5.location = (632.5167846679688, 66.61811828613281)
	    set_material_2.location = (793.743896484375, 32.40200424194336)
	    curve_circle.location = (87.1727523803711, -56.81591033935547)
	    capture_attribute_002_6.location = (283.9133605957031, -74.45401000976562)
	    reroute_8.location = (247.05758666992188, -91.37664031982422)
	    group_input_001_7.location = (790.8096313476562, 1.5365350246429443)
	    group_input_002_6.location = (462.2091369628906, -43.022979736328125)
	    set_curve_radius_2.location = (93.72252655029297, -22.188615798950195)
	    group_input_003_7.location = (-339.80987548828125, 120.61366271972656)
	    resample_curve_2.location = (-105.32349395751953, -15.050445556640625)
	    switch_8.location = (-105.3993148803711, 19.942108154296875)
	    compare_7.location = (-108.61988830566406, 54.5004768371582)
	    reroute_003_5.location = (-169.31845092773438, -19.093738555908203)
	    group_input_004_6.location = (-340.0, 59.733726501464844)
	    reroute_006_4.location = (58.51203918457031, -44.47895431518555)
	    reroute_007_4.location = (51.51875686645508, 91.57743072509766)
	    reroute_008_4.location = (-135.7594451904297, -35.677268981933594)
	    reroute_009_4.location = (-140.79913330078125, 26.496713638305664)
	
	    #Set dimensions
	    group_input_8.width, group_input_8.height = 140.0, 100.0
	    group_output_11.width, group_output_11.height = 140.0, 100.0
	    curve_to_mesh_2.width, curve_to_mesh_2.height = 140.0, 100.0
	    capture_attribute_6.width, capture_attribute_6.height = 140.0, 100.0
	    spline_parameter_4.width, spline_parameter_4.height = 140.0, 100.0
	    combine_xyz_4.width, combine_xyz_4.height = 140.0, 100.0
	    store_named_attribute_5.width, store_named_attribute_5.height = 140.0, 100.0
	    set_material_2.width, set_material_2.height = 140.0, 100.0
	    curve_circle.width, curve_circle.height = 140.0, 100.0
	    capture_attribute_002_6.width, capture_attribute_002_6.height = 140.0, 100.0
	    reroute_8.width, reroute_8.height = 100.0, 100.0
	    group_input_001_7.width, group_input_001_7.height = 140.0, 100.0
	    group_input_002_6.width, group_input_002_6.height = 140.0, 100.0
	    set_curve_radius_2.width, set_curve_radius_2.height = 140.0, 100.0
	    group_input_003_7.width, group_input_003_7.height = 140.0, 100.0
	    resample_curve_2.width, resample_curve_2.height = 140.0, 100.0
	    switch_8.width, switch_8.height = 140.0, 100.0
	    compare_7.width, compare_7.height = 140.0, 100.0
	    reroute_003_5.width, reroute_003_5.height = 100.0, 100.0
	    group_input_004_6.width, group_input_004_6.height = 140.0, 100.0
	    reroute_006_4.width, reroute_006_4.height = 100.0, 100.0
	    reroute_007_4.width, reroute_007_4.height = 100.0, 100.0
	    reroute_008_4.width, reroute_008_4.height = 100.0, 100.0
	    reroute_009_4.width, reroute_009_4.height = 100.0, 100.0
	
	    #initialize tube_mesh links
	    #set_material_2.Geometry -> group_output_11.Geometry
	    tube_mesh.links.new(set_material_2.outputs[0], group_output_11.inputs[0])
	    #capture_attribute_6.Geometry -> curve_to_mesh_2.Curve
	    tube_mesh.links.new(capture_attribute_6.outputs[0], curve_to_mesh_2.inputs[0])
	    #set_curve_radius_2.Curve -> capture_attribute_6.Geometry
	    tube_mesh.links.new(set_curve_radius_2.outputs[0], capture_attribute_6.inputs[0])
	    #reroute_8.Output -> capture_attribute_6.Factor
	    tube_mesh.links.new(reroute_8.outputs[0], capture_attribute_6.inputs[1])
	    #capture_attribute_6.Factor -> combine_xyz_4.X
	    tube_mesh.links.new(capture_attribute_6.outputs[1], combine_xyz_4.inputs[0])
	    #curve_to_mesh_2.Mesh -> store_named_attribute_5.Geometry
	    tube_mesh.links.new(curve_to_mesh_2.outputs[0], store_named_attribute_5.inputs[0])
	    #combine_xyz_4.Vector -> store_named_attribute_5.Value
	    tube_mesh.links.new(combine_xyz_4.outputs[0], store_named_attribute_5.inputs[3])
	    #store_named_attribute_5.Geometry -> set_material_2.Geometry
	    tube_mesh.links.new(store_named_attribute_5.outputs[0], set_material_2.inputs[0])
	    #curve_circle.Curve -> capture_attribute_002_6.Geometry
	    tube_mesh.links.new(curve_circle.outputs[0], capture_attribute_002_6.inputs[0])
	    #reroute_8.Output -> capture_attribute_002_6.Factor
	    tube_mesh.links.new(reroute_8.outputs[0], capture_attribute_002_6.inputs[1])
	    #capture_attribute_002_6.Factor -> combine_xyz_4.Y
	    tube_mesh.links.new(capture_attribute_002_6.outputs[1], combine_xyz_4.inputs[1])
	    #capture_attribute_002_6.Geometry -> curve_to_mesh_2.Profile Curve
	    tube_mesh.links.new(capture_attribute_002_6.outputs[0], curve_to_mesh_2.inputs[1])
	    #group_input_8.Width -> curve_circle.Radius
	    tube_mesh.links.new(group_input_8.outputs[4], curve_circle.inputs[4])
	    #spline_parameter_4.Factor -> reroute_8.Input
	    tube_mesh.links.new(spline_parameter_4.outputs[0], reroute_8.inputs[0])
	    #group_input_001_7.Material -> set_material_2.Material
	    tube_mesh.links.new(group_input_001_7.outputs[1], set_material_2.inputs[2])
	    #group_input_002_6.Fill Caps -> curve_to_mesh_2.Fill Caps
	    tube_mesh.links.new(group_input_002_6.outputs[5], curve_to_mesh_2.inputs[2])
	    #reroute_006_4.Output -> set_curve_radius_2.Radius
	    tube_mesh.links.new(reroute_006_4.outputs[0], set_curve_radius_2.inputs[2])
	    #reroute_003_5.Output -> resample_curve_2.Curve
	    tube_mesh.links.new(reroute_003_5.outputs[0], resample_curve_2.inputs[0])
	    #compare_7.Result -> switch_8.Switch
	    tube_mesh.links.new(compare_7.outputs[0], switch_8.inputs[0])
	    #reroute_003_5.Output -> switch_8.True
	    tube_mesh.links.new(reroute_003_5.outputs[0], switch_8.inputs[2])
	    #resample_curve_2.Curve -> switch_8.False
	    tube_mesh.links.new(resample_curve_2.outputs[0], switch_8.inputs[1])
	    #reroute_008_4.Output -> resample_curve_2.Count
	    tube_mesh.links.new(reroute_008_4.outputs[0], resample_curve_2.inputs[2])
	    #group_input_8.Geometry -> reroute_003_5.Input
	    tube_mesh.links.new(group_input_8.outputs[0], reroute_003_5.inputs[0])
	    #reroute_007_4.Output -> reroute_006_4.Input
	    tube_mesh.links.new(reroute_007_4.outputs[0], reroute_006_4.inputs[0])
	    #group_input_003_7.Curve Radius -> reroute_007_4.Input
	    tube_mesh.links.new(group_input_003_7.outputs[2], reroute_007_4.inputs[0])
	    #reroute_009_4.Output -> reroute_008_4.Input
	    tube_mesh.links.new(reroute_009_4.outputs[0], reroute_008_4.inputs[0])
	    #group_input_004_6.Resolution -> reroute_009_4.Input
	    tube_mesh.links.new(group_input_004_6.outputs[3], reroute_009_4.inputs[0])
	    #reroute_009_4.Output -> compare_7.A
	    tube_mesh.links.new(reroute_009_4.outputs[0], compare_7.inputs[2])
	    #switch_8.Output -> set_curve_radius_2.Curve
	    tube_mesh.links.new(switch_8.outputs[0], set_curve_radius_2.inputs[0])
	    return tube_mesh
	
	tube_mesh = tube_mesh_node_group()
	
	#initialize tube_ribbon node group
	def tube_ribbon_node_group():
	    tube_ribbon = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Tube_Ribbon")
	
	    tube_ribbon.color_tag = 'NONE'
	    tube_ribbon.description = ""
	    tube_ribbon.default_group_node_width = 140
	    
	
	    tube_ribbon.is_modifier = True
	
	    #tube_ribbon interface
	    #Socket Geometry
	    geometry_socket_14 = tube_ribbon.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_14.attribute_domain = 'POINT'
	
	    #Socket Geometry
	    geometry_socket_15 = tube_ribbon.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_15.attribute_domain = 'POINT'
	
	    #Socket Material
	    material_socket_3 = tube_ribbon.interface.new_socket(name = "Material", in_out='INPUT', socket_type = 'NodeSocketMaterial')
	    material_socket_3.attribute_domain = 'POINT'
	
	    #Socket Curve Radius
	    curve_radius_socket_3 = tube_ribbon.interface.new_socket(name = "Curve Radius", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    curve_radius_socket_3.default_value = 1.0
	    curve_radius_socket_3.min_value = 0.0
	    curve_radius_socket_3.max_value = 3.4028234663852886e+38
	    curve_radius_socket_3.subtype = 'DISTANCE'
	    curve_radius_socket_3.attribute_domain = 'POINT'
	    curve_radius_socket_3.hide_value = True
	    curve_radius_socket_3.hide_in_modifier = True
	
	    #Socket Ribbon Count
	    ribbon_count_socket = tube_ribbon.interface.new_socket(name = "Ribbon Count", in_out='INPUT', socket_type = 'NodeSocketInt')
	    ribbon_count_socket.default_value = 8
	    ribbon_count_socket.min_value = 1
	    ribbon_count_socket.max_value = 180
	    ribbon_count_socket.subtype = 'NONE'
	    ribbon_count_socket.attribute_domain = 'POINT'
	
	    #Socket Resolution
	    resolution_socket_3 = tube_ribbon.interface.new_socket(name = "Resolution", in_out='INPUT', socket_type = 'NodeSocketInt')
	    resolution_socket_3.default_value = 0
	    resolution_socket_3.min_value = 2
	    resolution_socket_3.max_value = 512
	    resolution_socket_3.subtype = 'NONE'
	    resolution_socket_3.attribute_domain = 'POINT'
	
	    #Socket Width
	    width_socket_2 = tube_ribbon.interface.new_socket(name = "Width", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    width_socket_2.default_value = 0.10000000149011612
	    width_socket_2.min_value = 0.0
	    width_socket_2.max_value = 3.4028234663852886e+38
	    width_socket_2.subtype = 'DISTANCE'
	    width_socket_2.attribute_domain = 'POINT'
	
	
	    #initialize tube_ribbon nodes
	    #node Group Input
	    group_input_9 = tube_ribbon.nodes.new("NodeGroupInput")
	    group_input_9.name = "Group Input"
	    group_input_9.outputs[1].hide = True
	    group_input_9.outputs[2].hide = True
	    group_input_9.outputs[3].hide = True
	    group_input_9.outputs[6].hide = True
	
	    #node Group Output
	    group_output_12 = tube_ribbon.nodes.new("NodeGroupOutput")
	    group_output_12.name = "Group Output"
	    group_output_12.is_active_output = True
	
	    #node Curve to Mesh
	    curve_to_mesh_3 = tube_ribbon.nodes.new("GeometryNodeCurveToMesh")
	    curve_to_mesh_3.name = "Curve to Mesh"
	    curve_to_mesh_3.hide = True
	    #Fill Caps
	    curve_to_mesh_3.inputs[2].default_value = True
	
	    #node Capture Attribute
	    capture_attribute_7 = tube_ribbon.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_7.name = "Capture Attribute"
	    capture_attribute_7.hide = True
	    capture_attribute_7.active_index = 0
	    capture_attribute_7.capture_items.clear()
	    capture_attribute_7.capture_items.new('FLOAT', "Factor")
	    capture_attribute_7.capture_items["Factor"].data_type = 'FLOAT'
	    capture_attribute_7.domain = 'POINT'
	
	    #node Spline Parameter
	    spline_parameter_5 = tube_ribbon.nodes.new("GeometryNodeSplineParameter")
	    spline_parameter_5.name = "Spline Parameter"
	    spline_parameter_5.hide = True
	
	    #node Combine XYZ
	    combine_xyz_5 = tube_ribbon.nodes.new("ShaderNodeCombineXYZ")
	    combine_xyz_5.name = "Combine XYZ"
	    combine_xyz_5.hide = True
	    #Z
	    combine_xyz_5.inputs[2].default_value = 0.0
	
	    #node Store Named Attribute
	    store_named_attribute_6 = tube_ribbon.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_6.name = "Store Named Attribute"
	    store_named_attribute_6.data_type = 'FLOAT2'
	    store_named_attribute_6.domain = 'CORNER'
	    #Selection
	    store_named_attribute_6.inputs[1].default_value = True
	    #Name
	    store_named_attribute_6.inputs[2].default_value = "ribbon_mesh_UV"
	
	    #node Set Material
	    set_material_3 = tube_ribbon.nodes.new("GeometryNodeSetMaterial")
	    set_material_3.name = "Set Material"
	    set_material_3.hide = True
	    #Selection
	    set_material_3.inputs[1].default_value = True
	
	    #node Capture Attribute.002
	    capture_attribute_002_7 = tube_ribbon.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_002_7.name = "Capture Attribute.002"
	    capture_attribute_002_7.hide = True
	    capture_attribute_002_7.active_index = 0
	    capture_attribute_002_7.capture_items.clear()
	    capture_attribute_002_7.capture_items.new('FLOAT', "Factor")
	    capture_attribute_002_7.capture_items["Factor"].data_type = 'FLOAT'
	    capture_attribute_002_7.domain = 'POINT'
	
	    #node Reroute
	    reroute_9 = tube_ribbon.nodes.new("NodeReroute")
	    reroute_9.name = "Reroute"
	    reroute_9.socket_idname = "NodeSocketFloat"
	    #node Group Input.001
	    group_input_001_8 = tube_ribbon.nodes.new("NodeGroupInput")
	    group_input_001_8.name = "Group Input.001"
	    group_input_001_8.outputs[0].hide = True
	    group_input_001_8.outputs[2].hide = True
	    group_input_001_8.outputs[3].hide = True
	    group_input_001_8.outputs[4].hide = True
	    group_input_001_8.outputs[5].hide = True
	    group_input_001_8.outputs[6].hide = True
	
	    #node Curve Line
	    curve_line = tube_ribbon.nodes.new("GeometryNodeCurvePrimitiveLine")
	    curve_line.name = "Curve Line"
	    curve_line.hide = True
	    curve_line.mode = 'POINTS'
	
	    #node Combine XYZ.001
	    combine_xyz_001 = tube_ribbon.nodes.new("ShaderNodeCombineXYZ")
	    combine_xyz_001.name = "Combine XYZ.001"
	    combine_xyz_001.hide = True
	    #Y
	    combine_xyz_001.inputs[1].default_value = 0.0
	    #Z
	    combine_xyz_001.inputs[2].default_value = 0.0
	
	    #node Math.001
	    math_001_3 = tube_ribbon.nodes.new("ShaderNodeMath")
	    math_001_3.name = "Math.001"
	    math_001_3.hide = True
	    math_001_3.operation = 'MULTIPLY'
	    math_001_3.use_clamp = False
	    #Value_001
	    math_001_3.inputs[1].default_value = -1.0
	
	    #node Combine XYZ.002
	    combine_xyz_002_1 = tube_ribbon.nodes.new("ShaderNodeCombineXYZ")
	    combine_xyz_002_1.name = "Combine XYZ.002"
	    combine_xyz_002_1.hide = True
	    #Y
	    combine_xyz_002_1.inputs[1].default_value = 0.0
	    #Z
	    combine_xyz_002_1.inputs[2].default_value = 0.0
	
	    #node Reroute.001
	    reroute_001_8 = tube_ribbon.nodes.new("NodeReroute")
	    reroute_001_8.name = "Reroute.001"
	    reroute_001_8.socket_idname = "NodeSocketFloatDistance"
	    #node Resample Curve
	    resample_curve_3 = tube_ribbon.nodes.new("GeometryNodeResampleCurve")
	    resample_curve_3.name = "Resample Curve"
	    resample_curve_3.hide = True
	    resample_curve_3.keep_last_segment = False
	    resample_curve_3.mode = 'COUNT'
	    #Selection
	    resample_curve_3.inputs[1].default_value = True
	
	    #node Switch
	    switch_9 = tube_ribbon.nodes.new("GeometryNodeSwitch")
	    switch_9.name = "Switch"
	    switch_9.hide = True
	    switch_9.input_type = 'GEOMETRY'
	
	    #node Group Input.002
	    group_input_002_7 = tube_ribbon.nodes.new("NodeGroupInput")
	    group_input_002_7.name = "Group Input.002"
	    group_input_002_7.outputs[0].hide = True
	    group_input_002_7.outputs[1].hide = True
	    group_input_002_7.outputs[2].hide = True
	    group_input_002_7.outputs[3].hide = True
	    group_input_002_7.outputs[5].hide = True
	    group_input_002_7.outputs[6].hide = True
	
	    #node Compare
	    compare_8 = tube_ribbon.nodes.new("FunctionNodeCompare")
	    compare_8.name = "Compare"
	    compare_8.hide = True
	    compare_8.data_type = 'INT'
	    compare_8.mode = 'ELEMENT'
	    compare_8.operation = 'LESS_THAN'
	    #B_INT
	    compare_8.inputs[3].default_value = 2
	
	    #node Reroute.002
	    reroute_002_6 = tube_ribbon.nodes.new("NodeReroute")
	    reroute_002_6.name = "Reroute.002"
	    reroute_002_6.socket_idname = "NodeSocketGeometry"
	    #node Frame
	    frame_6 = tube_ribbon.nodes.new("NodeFrame")
	    frame_6.name = "Frame"
	    frame_6.label_size = 20
	    frame_6.shrink = True
	
	    #node Join Geometry
	    join_geometry_3 = tube_ribbon.nodes.new("GeometryNodeJoinGeometry")
	    join_geometry_3.name = "Join Geometry"
	
	    #node Set Curve Tilt
	    set_curve_tilt = tube_ribbon.nodes.new("GeometryNodeSetCurveTilt")
	    set_curve_tilt.name = "Set Curve Tilt"
	    #Selection
	    set_curve_tilt.inputs[1].default_value = True
	
	    #node Repeat Input
	    repeat_input = tube_ribbon.nodes.new("GeometryNodeRepeatInput")
	    repeat_input.name = "Repeat Input"
	    #node Repeat Output
	    repeat_output = tube_ribbon.nodes.new("GeometryNodeRepeatOutput")
	    repeat_output.name = "Repeat Output"
	    repeat_output.active_index = 1
	    repeat_output.inspection_index = 0
	    repeat_output.repeat_items.clear()
	    # Create item "Geometry"
	    repeat_output.repeat_items.new('GEOMETRY', "Geometry")
	    # Create item "Index"
	    repeat_output.repeat_items.new('INT', "Index")
	
	    #node Math.002
	    math_002_2 = tube_ribbon.nodes.new("ShaderNodeMath")
	    math_002_2.name = "Math.002"
	    math_002_2.hide = True
	    math_002_2.operation = 'DIVIDE'
	    math_002_2.use_clamp = False
	    #Value
	    math_002_2.inputs[0].default_value = 180.0
	
	    #node Group Input.003
	    group_input_003_8 = tube_ribbon.nodes.new("NodeGroupInput")
	    group_input_003_8.name = "Group Input.003"
	    group_input_003_8.outputs[0].hide = True
	    group_input_003_8.outputs[1].hide = True
	    group_input_003_8.outputs[2].hide = True
	    group_input_003_8.outputs[4].hide = True
	    group_input_003_8.outputs[5].hide = True
	    group_input_003_8.outputs[6].hide = True
	
	    #node Group Input.004
	    group_input_004_7 = tube_ribbon.nodes.new("NodeGroupInput")
	    group_input_004_7.name = "Group Input.004"
	    group_input_004_7.outputs[0].hide = True
	    group_input_004_7.outputs[1].hide = True
	    group_input_004_7.outputs[2].hide = True
	    group_input_004_7.outputs[4].hide = True
	    group_input_004_7.outputs[5].hide = True
	    group_input_004_7.outputs[6].hide = True
	
	    #node Math.003
	    math_003_3 = tube_ribbon.nodes.new("ShaderNodeMath")
	    math_003_3.name = "Math.003"
	    math_003_3.hide = True
	    math_003_3.operation = 'ADD'
	    math_003_3.use_clamp = False
	    #Value_001
	    math_003_3.inputs[1].default_value = 1.0
	
	    #node Math.004
	    math_004_1 = tube_ribbon.nodes.new("ShaderNodeMath")
	    math_004_1.name = "Math.004"
	    math_004_1.hide = True
	    math_004_1.operation = 'MULTIPLY'
	    math_004_1.use_clamp = False
	
	    #node Reroute.003
	    reroute_003_6 = tube_ribbon.nodes.new("NodeReroute")
	    reroute_003_6.name = "Reroute.003"
	    reroute_003_6.socket_idname = "NodeSocketInt"
	    #node Curve Tilt
	    curve_tilt = tube_ribbon.nodes.new("GeometryNodeInputCurveTilt")
	    curve_tilt.name = "Curve Tilt"
	    curve_tilt.hide = True
	
	    #node Math.005
	    math_005_1 = tube_ribbon.nodes.new("ShaderNodeMath")
	    math_005_1.name = "Math.005"
	    math_005_1.hide = True
	    math_005_1.operation = 'ADD'
	    math_005_1.use_clamp = False
	
	    #node Set Curve Radius
	    set_curve_radius_3 = tube_ribbon.nodes.new("GeometryNodeSetCurveRadius")
	    set_curve_radius_3.name = "Set Curve Radius"
	    set_curve_radius_3.hide = True
	    #Selection
	    set_curve_radius_3.inputs[1].default_value = True
	
	    #node Group Input.005
	    group_input_005_5 = tube_ribbon.nodes.new("NodeGroupInput")
	    group_input_005_5.name = "Group Input.005"
	    group_input_005_5.outputs[0].hide = True
	    group_input_005_5.outputs[1].hide = True
	    group_input_005_5.outputs[3].hide = True
	    group_input_005_5.outputs[4].hide = True
	    group_input_005_5.outputs[5].hide = True
	    group_input_005_5.outputs[6].hide = True
	
	    #node Reroute.004
	    reroute_004_6 = tube_ribbon.nodes.new("NodeReroute")
	    reroute_004_6.name = "Reroute.004"
	    reroute_004_6.socket_idname = "NodeSocketFloatDistance"
	    #node Reroute.005
	    reroute_005_5 = tube_ribbon.nodes.new("NodeReroute")
	    reroute_005_5.name = "Reroute.005"
	    reroute_005_5.socket_idname = "NodeSocketFloatDistance"
	
	    #Process zone input Repeat Input
	    repeat_input.pair_with_output(repeat_output)
	    #Item_2
	    repeat_input.inputs[2].default_value = 0
	
	
	
	
	    #Set parents
	    group_input_9.parent = frame_6
	    curve_to_mesh_3.parent = frame_6
	    capture_attribute_7.parent = frame_6
	    spline_parameter_5.parent = frame_6
	    combine_xyz_5.parent = frame_6
	    store_named_attribute_6.parent = frame_6
	    set_material_3.parent = frame_6
	    capture_attribute_002_7.parent = frame_6
	    reroute_9.parent = frame_6
	    group_input_001_8.parent = frame_6
	    curve_line.parent = frame_6
	    combine_xyz_001.parent = frame_6
	    math_001_3.parent = frame_6
	    combine_xyz_002_1.parent = frame_6
	    reroute_001_8.parent = frame_6
	    resample_curve_3.parent = frame_6
	    switch_9.parent = frame_6
	    group_input_002_7.parent = frame_6
	    compare_8.parent = frame_6
	    reroute_002_6.parent = frame_6
	    set_curve_tilt.parent = frame_6
	    math_004_1.parent = frame_6
	    math_005_1.parent = frame_6
	    set_curve_radius_3.parent = frame_6
	    group_input_005_5.parent = frame_6
	    reroute_004_6.parent = frame_6
	    reroute_005_5.parent = frame_6
	
	    #Set locations
	    group_input_9.location = (46.5567626953125, -187.68907165527344)
	    group_output_12.location = (1687.6083984375, 27.941242218017578)
	    curve_to_mesh_3.location = (937.7008666992188, -218.34669494628906)
	    capture_attribute_7.location = (764.834716796875, -223.1929168701172)
	    spline_parameter_5.location = (408.7358093261719, -288.16595458984375)
	    combine_xyz_5.location = (937.5093383789062, -281.03155517578125)
	    store_named_attribute_6.location = (1093.46923828125, -121.07095336914062)
	    set_material_3.location = (1254.6962890625, -155.2870635986328)
	    capture_attribute_002_7.location = (766.9982299804688, -262.14312744140625)
	    reroute_9.location = (566.0176391601562, -285.51812744140625)
	    group_input_001_8.location = (1251.76220703125, -186.1525421142578)
	    curve_line.location = (409.7470397949219, -252.2234649658203)
	    combine_xyz_001.location = (242.35899353027344, -260.64910888671875)
	    math_001_3.location = (247.1505889892578, -332.52447509765625)
	    combine_xyz_002_1.location = (245.62991333007812, -296.69708251953125)
	    reroute_001_8.location = (199.33338928222656, -265.65771484375)
	    resample_curve_3.location = (380.4243469238281, -216.19468688964844)
	    switch_9.location = (380.3485412597656, -181.20213317871094)
	    group_input_002_7.location = (375.72821044921875, -86.50663757324219)
	    compare_8.location = (377.1279602050781, -146.6437530517578)
	    reroute_002_6.location = (333.6315612792969, -213.35231018066406)
	    frame_6.location = (-58.76470947265625, -48.17646789550781)
	    join_geometry_3.location = (1331.0086669921875, 47.14059066772461)
	    set_curve_tilt.location = (192.23997497558594, -54.01100158691406)
	    repeat_input.location = (-184.79876708984375, 46.944000244140625)
	    repeat_output.location = (1511.4083251953125, 27.655336380004883)
	    math_002_2.location = (-195.4779510498047, -161.6897735595703)
	    group_input_003_8.location = (-346.3707580566406, 47.1754035949707)
	    group_input_004_7.location = (-353.25665283203125, -145.0489044189453)
	    math_003_3.location = (1134.1580810546875, -24.601409912109375)
	    math_004_1.location = (30.277496337890625, -106.62132263183594)
	    reroute_003_6.location = (-25.963211059570312, -31.35608673095703)
	    curve_tilt.location = (-197.5312957763672, -198.6190185546875)
	    math_005_1.location = (31.753875732421875, -145.03323364257812)
	    set_curve_radius_3.location = (591.83837890625, -194.33396911621094)
	    group_input_005_5.location = (377.0597229003906, -29.650436401367188)
	    reroute_004_6.location = (563.5545654296875, -215.4977264404297)
	    reroute_005_5.location = (561.7288208007812, -64.61457824707031)
	
	    #Set dimensions
	    group_input_9.width, group_input_9.height = 140.0, 100.0
	    group_output_12.width, group_output_12.height = 140.0, 100.0
	    curve_to_mesh_3.width, curve_to_mesh_3.height = 140.0, 100.0
	    capture_attribute_7.width, capture_attribute_7.height = 140.0, 100.0
	    spline_parameter_5.width, spline_parameter_5.height = 140.0, 100.0
	    combine_xyz_5.width, combine_xyz_5.height = 140.0, 100.0
	    store_named_attribute_6.width, store_named_attribute_6.height = 140.0, 100.0
	    set_material_3.width, set_material_3.height = 140.0, 100.0
	    capture_attribute_002_7.width, capture_attribute_002_7.height = 140.0, 100.0
	    reroute_9.width, reroute_9.height = 100.0, 100.0
	    group_input_001_8.width, group_input_001_8.height = 140.0, 100.0
	    curve_line.width, curve_line.height = 140.0, 100.0
	    combine_xyz_001.width, combine_xyz_001.height = 140.0, 100.0
	    math_001_3.width, math_001_3.height = 140.0, 100.0
	    combine_xyz_002_1.width, combine_xyz_002_1.height = 140.0, 100.0
	    reroute_001_8.width, reroute_001_8.height = 100.0, 100.0
	    resample_curve_3.width, resample_curve_3.height = 140.0, 100.0
	    switch_9.width, switch_9.height = 140.0, 100.0
	    group_input_002_7.width, group_input_002_7.height = 140.0, 100.0
	    compare_8.width, compare_8.height = 140.0, 100.0
	    reroute_002_6.width, reroute_002_6.height = 100.0, 100.0
	    frame_6.width, frame_6.height = 1424.3529052734375, 388.32354736328125
	    join_geometry_3.width, join_geometry_3.height = 140.0, 100.0
	    set_curve_tilt.width, set_curve_tilt.height = 140.0, 100.0
	    repeat_input.width, repeat_input.height = 140.0, 100.0
	    repeat_output.width, repeat_output.height = 140.0, 100.0
	    math_002_2.width, math_002_2.height = 140.0, 100.0
	    group_input_003_8.width, group_input_003_8.height = 140.0, 100.0
	    group_input_004_7.width, group_input_004_7.height = 140.0, 100.0
	    math_003_3.width, math_003_3.height = 140.0, 100.0
	    math_004_1.width, math_004_1.height = 140.0, 100.0
	    reroute_003_6.width, reroute_003_6.height = 100.0, 100.0
	    curve_tilt.width, curve_tilt.height = 140.0, 100.0
	    math_005_1.width, math_005_1.height = 140.0, 100.0
	    set_curve_radius_3.width, set_curve_radius_3.height = 140.0, 100.0
	    group_input_005_5.width, group_input_005_5.height = 140.0, 100.0
	    reroute_004_6.width, reroute_004_6.height = 100.0, 100.0
	    reroute_005_5.width, reroute_005_5.height = 100.0, 100.0
	
	    #initialize tube_ribbon links
	    #capture_attribute_7.Geometry -> curve_to_mesh_3.Curve
	    tube_ribbon.links.new(capture_attribute_7.outputs[0], curve_to_mesh_3.inputs[0])
	    #reroute_9.Output -> capture_attribute_7.Factor
	    tube_ribbon.links.new(reroute_9.outputs[0], capture_attribute_7.inputs[1])
	    #capture_attribute_7.Factor -> combine_xyz_5.X
	    tube_ribbon.links.new(capture_attribute_7.outputs[1], combine_xyz_5.inputs[0])
	    #curve_to_mesh_3.Mesh -> store_named_attribute_6.Geometry
	    tube_ribbon.links.new(curve_to_mesh_3.outputs[0], store_named_attribute_6.inputs[0])
	    #combine_xyz_5.Vector -> store_named_attribute_6.Value
	    tube_ribbon.links.new(combine_xyz_5.outputs[0], store_named_attribute_6.inputs[3])
	    #store_named_attribute_6.Geometry -> set_material_3.Geometry
	    tube_ribbon.links.new(store_named_attribute_6.outputs[0], set_material_3.inputs[0])
	    #reroute_9.Output -> capture_attribute_002_7.Factor
	    tube_ribbon.links.new(reroute_9.outputs[0], capture_attribute_002_7.inputs[1])
	    #capture_attribute_002_7.Factor -> combine_xyz_5.Y
	    tube_ribbon.links.new(capture_attribute_002_7.outputs[1], combine_xyz_5.inputs[1])
	    #capture_attribute_002_7.Geometry -> curve_to_mesh_3.Profile Curve
	    tube_ribbon.links.new(capture_attribute_002_7.outputs[0], curve_to_mesh_3.inputs[1])
	    #spline_parameter_5.Factor -> reroute_9.Input
	    tube_ribbon.links.new(spline_parameter_5.outputs[0], reroute_9.inputs[0])
	    #group_input_001_8.Material -> set_material_3.Material
	    tube_ribbon.links.new(group_input_001_8.outputs[1], set_material_3.inputs[2])
	    #combine_xyz_001.Vector -> curve_line.Start
	    tube_ribbon.links.new(combine_xyz_001.outputs[0], curve_line.inputs[0])
	    #math_001_3.Value -> combine_xyz_002_1.X
	    tube_ribbon.links.new(math_001_3.outputs[0], combine_xyz_002_1.inputs[0])
	    #combine_xyz_002_1.Vector -> curve_line.End
	    tube_ribbon.links.new(combine_xyz_002_1.outputs[0], curve_line.inputs[1])
	    #reroute_001_8.Output -> math_001_3.Value
	    tube_ribbon.links.new(reroute_001_8.outputs[0], math_001_3.inputs[0])
	    #curve_line.Curve -> capture_attribute_002_7.Geometry
	    tube_ribbon.links.new(curve_line.outputs[0], capture_attribute_002_7.inputs[0])
	    #group_input_9.Width -> reroute_001_8.Input
	    tube_ribbon.links.new(group_input_9.outputs[5], reroute_001_8.inputs[0])
	    #reroute_002_6.Output -> resample_curve_3.Curve
	    tube_ribbon.links.new(reroute_002_6.outputs[0], resample_curve_3.inputs[0])
	    #group_input_9.Resolution -> resample_curve_3.Count
	    tube_ribbon.links.new(group_input_9.outputs[4], resample_curve_3.inputs[2])
	    #group_input_002_7.Resolution -> compare_8.A
	    tube_ribbon.links.new(group_input_002_7.outputs[4], compare_8.inputs[2])
	    #compare_8.Result -> switch_9.Switch
	    tube_ribbon.links.new(compare_8.outputs[0], switch_9.inputs[0])
	    #set_curve_radius_3.Curve -> capture_attribute_7.Geometry
	    tube_ribbon.links.new(set_curve_radius_3.outputs[0], capture_attribute_7.inputs[0])
	    #reroute_002_6.Output -> switch_9.True
	    tube_ribbon.links.new(reroute_002_6.outputs[0], switch_9.inputs[2])
	    #resample_curve_3.Curve -> switch_9.False
	    tube_ribbon.links.new(resample_curve_3.outputs[0], switch_9.inputs[1])
	    #group_input_9.Geometry -> set_curve_tilt.Curve
	    tube_ribbon.links.new(group_input_9.outputs[0], set_curve_tilt.inputs[0])
	    #set_curve_tilt.Curve -> reroute_002_6.Input
	    tube_ribbon.links.new(set_curve_tilt.outputs[0], reroute_002_6.inputs[0])
	    #join_geometry_3.Geometry -> repeat_output.Geometry
	    tube_ribbon.links.new(join_geometry_3.outputs[0], repeat_output.inputs[0])
	    #group_input_003_8.Ribbon Count -> repeat_input.Iterations
	    tube_ribbon.links.new(group_input_003_8.outputs[3], repeat_input.inputs[0])
	    #math_003_3.Value -> repeat_output.Index
	    tube_ribbon.links.new(math_003_3.outputs[0], repeat_output.inputs[1])
	    #repeat_output.Geometry -> group_output_12.Geometry
	    tube_ribbon.links.new(repeat_output.outputs[0], group_output_12.inputs[0])
	    #reroute_003_6.Output -> math_003_3.Value
	    tube_ribbon.links.new(reroute_003_6.outputs[0], math_003_3.inputs[0])
	    #group_input_004_7.Ribbon Count -> math_002_2.Value
	    tube_ribbon.links.new(group_input_004_7.outputs[3], math_002_2.inputs[1])
	    #math_002_2.Value -> math_004_1.Value
	    tube_ribbon.links.new(math_002_2.outputs[0], math_004_1.inputs[1])
	    #reroute_003_6.Output -> math_004_1.Value
	    tube_ribbon.links.new(reroute_003_6.outputs[0], math_004_1.inputs[0])
	    #repeat_input.Index -> reroute_003_6.Input
	    tube_ribbon.links.new(repeat_input.outputs[2], reroute_003_6.inputs[0])
	    #set_material_3.Geometry -> join_geometry_3.Geometry
	    tube_ribbon.links.new(set_material_3.outputs[0], join_geometry_3.inputs[0])
	    #curve_tilt.Tilt -> math_005_1.Value
	    tube_ribbon.links.new(curve_tilt.outputs[0], math_005_1.inputs[1])
	    #math_004_1.Value -> math_005_1.Value
	    tube_ribbon.links.new(math_004_1.outputs[0], math_005_1.inputs[0])
	    #math_005_1.Value -> set_curve_tilt.Tilt
	    tube_ribbon.links.new(math_005_1.outputs[0], set_curve_tilt.inputs[2])
	    #switch_9.Output -> set_curve_radius_3.Curve
	    tube_ribbon.links.new(switch_9.outputs[0], set_curve_radius_3.inputs[0])
	    #reroute_004_6.Output -> set_curve_radius_3.Radius
	    tube_ribbon.links.new(reroute_004_6.outputs[0], set_curve_radius_3.inputs[2])
	    #reroute_005_5.Output -> reroute_004_6.Input
	    tube_ribbon.links.new(reroute_005_5.outputs[0], reroute_004_6.inputs[0])
	    #group_input_005_5.Curve Radius -> reroute_005_5.Input
	    tube_ribbon.links.new(group_input_005_5.outputs[2], reroute_005_5.inputs[0])
	    #reroute_001_8.Output -> combine_xyz_001.X
	    tube_ribbon.links.new(reroute_001_8.outputs[0], combine_xyz_001.inputs[0])
	    #repeat_input.Geometry -> join_geometry_3.Geometry
	    tube_ribbon.links.new(repeat_input.outputs[1], join_geometry_3.inputs[0])
	    return tube_ribbon
	
	tube_ribbon = tube_ribbon_node_group()
	
	#initialize mesh_hair_selector node group
	def mesh_hair_selector_node_group():
	    mesh_hair_selector = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "MESH_HAIR_SELECTOR")
	
	    mesh_hair_selector.color_tag = 'NONE'
	    mesh_hair_selector.description = "Convert hair to mesh object."
	    mesh_hair_selector.default_group_node_width = 140
	    
	
	    mesh_hair_selector.is_modifier = True
	
	    #mesh_hair_selector interface
	    #Socket Geometry
	    geometry_socket_16 = mesh_hair_selector.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_16.attribute_domain = 'POINT'
	    geometry_socket_16.description = "Mesh object."
	
	    #Socket Geometry
	    geometry_socket_17 = mesh_hair_selector.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_17.attribute_domain = 'POINT'
	    geometry_socket_17.description = "Curve object"
	
	    #Socket Style Select
	    style_select_socket = mesh_hair_selector.interface.new_socket(name = "Style Select", in_out='INPUT', socket_type = 'NodeSocketMenu')
	    style_select_socket.attribute_domain = 'POINT'
	    style_select_socket.description = "Mesh style to convert curve."
	
	    #Socket Material
	    material_socket_4 = mesh_hair_selector.interface.new_socket(name = "Material", in_out='INPUT', socket_type = 'NodeSocketMaterial')
	    material_socket_4.attribute_domain = 'POINT'
	    material_socket_4.description = "Material used for mesh."
	
	    #Socket Resolution
	    resolution_socket_4 = mesh_hair_selector.interface.new_socket(name = "Resolution", in_out='INPUT', socket_type = 'NodeSocketInt')
	    resolution_socket_4.default_value = 0
	    resolution_socket_4.min_value = 2
	    resolution_socket_4.max_value = 512
	    resolution_socket_4.subtype = 'NONE'
	    resolution_socket_4.attribute_domain = 'POINT'
	    resolution_socket_4.description = "Control mesh smoothness by add and removing points along curve."
	
	    #Socket Width
	    width_socket_3 = mesh_hair_selector.interface.new_socket(name = "Width", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    width_socket_3.default_value = 0.10000000149011612
	    width_socket_3.min_value = 0.0
	    width_socket_3.max_value = 3.4028234663852886e+38
	    width_socket_3.subtype = 'DISTANCE'
	    width_socket_3.attribute_domain = 'POINT'
	    width_socket_3.description = "Width of mesh object."
	
	    #Socket Curve Radius
	    curve_radius_socket_4 = mesh_hair_selector.interface.new_socket(name = "Curve Radius", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    curve_radius_socket_4.default_value = 0.0
	    curve_radius_socket_4.min_value = 0.0
	    curve_radius_socket_4.max_value = 0.0
	    curve_radius_socket_4.subtype = 'DISTANCE'
	    curve_radius_socket_4.attribute_domain = 'POINT'
	    curve_radius_socket_4.hide_value = True
	    curve_radius_socket_4.hide_in_modifier = True
	    curve_radius_socket_4.description = "Overall mesh shape float curve."
	
	    #Socket Fill Caps
	    fill_caps_socket_2 = mesh_hair_selector.interface.new_socket(name = "Fill Caps", in_out='INPUT', socket_type = 'NodeSocketBool')
	    fill_caps_socket_2.default_value = False
	    fill_caps_socket_2.attribute_domain = 'POINT'
	    fill_caps_socket_2.description = "Fill openings with mesh surface. (Used only for [Tube Mesh | Stylized] mesh styles)"
	
	    #Socket Shade Smooth
	    shade_smooth_socket = mesh_hair_selector.interface.new_socket(name = "Shade Smooth", in_out='INPUT', socket_type = 'NodeSocketBool')
	    shade_smooth_socket.default_value = False
	    shade_smooth_socket.attribute_domain = 'POINT'
	    shade_smooth_socket.description = "Use Smooth Shade for mesh."
	
	    #Socket Hair Card Angle
	    hair_card_angle_socket = mesh_hair_selector.interface.new_socket(name = "Hair Card Angle", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    hair_card_angle_socket.default_value = 0.0
	    hair_card_angle_socket.min_value = -90.0
	    hair_card_angle_socket.max_value = 90.0
	    hair_card_angle_socket.subtype = 'ANGLE'
	    hair_card_angle_socket.attribute_domain = 'POINT'
	    hair_card_angle_socket.description = "Angle used to bend hair card. (Mesh Style=Hair Card)"
	
	    #Socket Tube Ribbon Count
	    tube_ribbon_count_socket = mesh_hair_selector.interface.new_socket(name = "Tube Ribbon Count", in_out='INPUT', socket_type = 'NodeSocketInt')
	    tube_ribbon_count_socket.default_value = 8
	    tube_ribbon_count_socket.min_value = 1
	    tube_ribbon_count_socket.max_value = 180
	    tube_ribbon_count_socket.subtype = 'NONE'
	    tube_ribbon_count_socket.attribute_domain = 'POINT'
	    tube_ribbon_count_socket.description = "Amount of billboard like hair cards used to shape hair. (Mesh Style=Tube Ribbon)"
	
	    #Socket Profile Curve
	    profile_curve_socket = mesh_hair_selector.interface.new_socket(name = "Profile Curve", in_out='INPUT', socket_type = 'NodeSocketObject')
	    profile_curve_socket.attribute_domain = 'POINT'
	    profile_curve_socket.description = "Curve object used as the profile for stylized hair. (Mesh Style=Stylized)"
	
	    #Socket Profile Translation
	    profile_translation_socket = mesh_hair_selector.interface.new_socket(name = "Profile Translation", in_out='INPUT', socket_type = 'NodeSocketVector')
	    profile_translation_socket.default_value = (0.0, 0.0, 0.0)
	    profile_translation_socket.min_value = -3.4028234663852886e+38
	    profile_translation_socket.max_value = 3.4028234663852886e+38
	    profile_translation_socket.subtype = 'TRANSLATION'
	    profile_translation_socket.attribute_domain = 'POINT'
	    profile_translation_socket.description = "Move position of stylized profile from origin. (Mesh Style=Stylized)"
	
	    #Socket Profile Rotation
	    profile_rotation_socket = mesh_hair_selector.interface.new_socket(name = "Profile Rotation", in_out='INPUT', socket_type = 'NodeSocketRotation')
	    profile_rotation_socket.default_value = (0.0, 0.0, 0.0)
	    profile_rotation_socket.attribute_domain = 'POINT'
	    profile_rotation_socket.description = "Rotate the stylized profile from origin. (Mesh Style=Stylized)"
	
	    #Socket Profile Scale
	    profile_scale_socket = mesh_hair_selector.interface.new_socket(name = "Profile Scale", in_out='INPUT', socket_type = 'NodeSocketVector')
	    profile_scale_socket.default_value = (1.0, 1.0, 1.0)
	    profile_scale_socket.min_value = -3.4028234663852886e+38
	    profile_scale_socket.max_value = 3.4028234663852886e+38
	    profile_scale_socket.subtype = 'XYZ'
	    profile_scale_socket.attribute_domain = 'POINT'
	    profile_scale_socket.description = "Scale the stylized profile from origin. (Mesh Style=Stylized)"
	
	    #Socket Mesh Index
	    mesh_index_socket = mesh_hair_selector.interface.new_socket(name = "Mesh Index", in_out='INPUT', socket_type = 'NodeSocketInt')
	    mesh_index_socket.default_value = 0
	    mesh_index_socket.min_value = 0
	    mesh_index_socket.max_value = 2147483647
	    mesh_index_socket.subtype = 'NONE'
	    mesh_index_socket.attribute_domain = 'POINT'
	    mesh_index_socket.description = "Index used to offset uv coords."
	
	
	    #initialize mesh_hair_selector nodes
	    #node Group Output
	    group_output_13 = mesh_hair_selector.nodes.new("NodeGroupOutput")
	    group_output_13.name = "Group Output"
	    group_output_13.is_active_output = True
	    group_output_13.inputs[1].hide = True
	
	    #node Group
	    group_5 = mesh_hair_selector.nodes.new("GeometryNodeGroup")
	    group_5.name = "Group"
	    group_5.node_tree = hair_card
	
	    #node Group.001
	    group_001_5 = mesh_hair_selector.nodes.new("GeometryNodeGroup")
	    group_001_5.name = "Group.001"
	    group_001_5.node_tree = stylized_hair
	
	    #node Group.002
	    group_002_1 = mesh_hair_selector.nodes.new("GeometryNodeGroup")
	    group_002_1.name = "Group.002"
	    group_002_1.node_tree = tube_mesh
	
	    #node Group.003
	    group_003_2 = mesh_hair_selector.nodes.new("GeometryNodeGroup")
	    group_003_2.name = "Group.003"
	    group_003_2.node_tree = tube_ribbon
	
	    #node Group Input.001
	    group_input_001_9 = mesh_hair_selector.nodes.new("NodeGroupInput")
	    group_input_001_9.name = "Group Input.001"
	    group_input_001_9.outputs[1].hide = True
	    group_input_001_9.outputs[5].hide = True
	    group_input_001_9.outputs[6].hide = True
	    group_input_001_9.outputs[7].hide = True
	    group_input_001_9.outputs[9].hide = True
	    group_input_001_9.outputs[10].hide = True
	    group_input_001_9.outputs[11].hide = True
	    group_input_001_9.outputs[12].hide = True
	    group_input_001_9.outputs[13].hide = True
	    group_input_001_9.outputs[14].hide = True
	    group_input_001_9.outputs[15].hide = True
	
	    #node Group Input.002
	    group_input_002_8 = mesh_hair_selector.nodes.new("NodeGroupInput")
	    group_input_002_8.name = "Group Input.002"
	    group_input_002_8.outputs[1].hide = True
	    group_input_002_8.outputs[5].hide = True
	    group_input_002_8.outputs[7].hide = True
	    group_input_002_8.outputs[8].hide = True
	    group_input_002_8.outputs[9].hide = True
	    group_input_002_8.outputs[10].hide = True
	    group_input_002_8.outputs[11].hide = True
	    group_input_002_8.outputs[12].hide = True
	    group_input_002_8.outputs[13].hide = True
	    group_input_002_8.outputs[14].hide = True
	    group_input_002_8.outputs[15].hide = True
	
	    #node Group Input.003
	    group_input_003_9 = mesh_hair_selector.nodes.new("NodeGroupInput")
	    group_input_003_9.name = "Group Input.003"
	    group_input_003_9.outputs[1].hide = True
	    group_input_003_9.outputs[5].hide = True
	    group_input_003_9.outputs[6].hide = True
	    group_input_003_9.outputs[7].hide = True
	    group_input_003_9.outputs[8].hide = True
	    group_input_003_9.outputs[10].hide = True
	    group_input_003_9.outputs[11].hide = True
	    group_input_003_9.outputs[12].hide = True
	    group_input_003_9.outputs[13].hide = True
	    group_input_003_9.outputs[14].hide = True
	    group_input_003_9.outputs[15].hide = True
	
	    #node Group Input.004
	    group_input_004_8 = mesh_hair_selector.nodes.new("NodeGroupInput")
	    group_input_004_8.name = "Group Input.004"
	    group_input_004_8.outputs[1].hide = True
	    group_input_004_8.outputs[4].hide = True
	    group_input_004_8.outputs[5].hide = True
	    group_input_004_8.outputs[7].hide = True
	    group_input_004_8.outputs[8].hide = True
	    group_input_004_8.outputs[9].hide = True
	    group_input_004_8.outputs[10].hide = True
	    group_input_004_8.outputs[14].hide = True
	    group_input_004_8.outputs[15].hide = True
	
	    #node Menu Switch.001
	    menu_switch_001 = mesh_hair_selector.nodes.new("GeometryNodeMenuSwitch")
	    menu_switch_001.name = "Menu Switch.001"
	    menu_switch_001.active_index = 3
	    menu_switch_001.data_type = 'STRING'
	    menu_switch_001.enum_items.clear()
	    menu_switch_001.enum_items.new("Hair Card")
	    menu_switch_001.enum_items[0].description = ""
	    menu_switch_001.enum_items.new("Tube Mesh")
	    menu_switch_001.enum_items[1].description = ""
	    menu_switch_001.enum_items.new("Tube Ribbon")
	    menu_switch_001.enum_items[2].description = ""
	    menu_switch_001.enum_items.new("Stylized")
	    menu_switch_001.enum_items[3].description = ""
	    menu_switch_001.inputs[5].hide = True
	
	    #node Store Named Attribute
	    store_named_attribute_7 = mesh_hair_selector.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_7.name = "Store Named Attribute"
	    store_named_attribute_7.data_type = 'FLOAT2'
	    store_named_attribute_7.domain = 'CORNER'
	    #Selection
	    store_named_attribute_7.inputs[1].default_value = True
	    #Name
	    store_named_attribute_7.inputs[2].default_value = "UVMap"
	
	    #node Named Attribute
	    named_attribute_3 = mesh_hair_selector.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute_3.name = "Named Attribute"
	    named_attribute_3.data_type = 'FLOAT_VECTOR'
	
	    #node Group Input.005
	    group_input_005_6 = mesh_hair_selector.nodes.new("NodeGroupInput")
	    group_input_005_6.name = "Group Input.005"
	    group_input_005_6.outputs[0].hide = True
	    group_input_005_6.outputs[2].hide = True
	    group_input_005_6.outputs[3].hide = True
	    group_input_005_6.outputs[4].hide = True
	    group_input_005_6.outputs[5].hide = True
	    group_input_005_6.outputs[6].hide = True
	    group_input_005_6.outputs[7].hide = True
	    group_input_005_6.outputs[8].hide = True
	    group_input_005_6.outputs[9].hide = True
	    group_input_005_6.outputs[10].hide = True
	    group_input_005_6.outputs[11].hide = True
	    group_input_005_6.outputs[12].hide = True
	    group_input_005_6.outputs[13].hide = True
	    group_input_005_6.outputs[14].hide = True
	    group_input_005_6.outputs[15].hide = True
	
	    #node Group Input.006
	    group_input_006_4 = mesh_hair_selector.nodes.new("NodeGroupInput")
	    group_input_006_4.name = "Group Input.006"
	    group_input_006_4.outputs[0].hide = True
	    group_input_006_4.outputs[1].hide = True
	    group_input_006_4.outputs[2].hide = True
	    group_input_006_4.outputs[3].hide = True
	    group_input_006_4.outputs[4].hide = True
	    group_input_006_4.outputs[5].hide = True
	    group_input_006_4.outputs[6].hide = True
	    group_input_006_4.outputs[7].hide = True
	    group_input_006_4.outputs[8].hide = True
	    group_input_006_4.outputs[9].hide = True
	    group_input_006_4.outputs[11].hide = True
	    group_input_006_4.outputs[12].hide = True
	    group_input_006_4.outputs[13].hide = True
	    group_input_006_4.outputs[14].hide = True
	    group_input_006_4.outputs[15].hide = True
	
	    #node Compare
	    compare_9 = mesh_hair_selector.nodes.new("FunctionNodeCompare")
	    compare_9.name = "Compare"
	    compare_9.hide = True
	    compare_9.data_type = 'STRING'
	    compare_9.mode = 'ELEMENT'
	    compare_9.operation = 'EQUAL'
	
	    #node Switch
	    switch_10 = mesh_hair_selector.nodes.new("GeometryNodeSwitch")
	    switch_10.name = "Switch"
	    switch_10.hide = True
	    switch_10.input_type = 'GEOMETRY'
	
	    #node Compare.001
	    compare_001_4 = mesh_hair_selector.nodes.new("FunctionNodeCompare")
	    compare_001_4.name = "Compare.001"
	    compare_001_4.hide = True
	    compare_001_4.data_type = 'STRING'
	    compare_001_4.mode = 'ELEMENT'
	    compare_001_4.operation = 'EQUAL'
	
	    #node Switch.001
	    switch_001_7 = mesh_hair_selector.nodes.new("GeometryNodeSwitch")
	    switch_001_7.name = "Switch.001"
	    switch_001_7.hide = True
	    switch_001_7.input_type = 'GEOMETRY'
	
	    #node Compare.002
	    compare_002_4 = mesh_hair_selector.nodes.new("FunctionNodeCompare")
	    compare_002_4.name = "Compare.002"
	    compare_002_4.hide = True
	    compare_002_4.data_type = 'STRING'
	    compare_002_4.mode = 'ELEMENT'
	    compare_002_4.operation = 'EQUAL'
	
	    #node Switch.002
	    switch_002_5 = mesh_hair_selector.nodes.new("GeometryNodeSwitch")
	    switch_002_5.name = "Switch.002"
	    switch_002_5.hide = True
	    switch_002_5.input_type = 'GEOMETRY'
	
	    #node Compare.003
	    compare_003_3 = mesh_hair_selector.nodes.new("FunctionNodeCompare")
	    compare_003_3.name = "Compare.003"
	    compare_003_3.hide = True
	    compare_003_3.data_type = 'STRING'
	    compare_003_3.mode = 'ELEMENT'
	    compare_003_3.operation = 'EQUAL'
	
	    #node Switch.003
	    switch_003_6 = mesh_hair_selector.nodes.new("GeometryNodeSwitch")
	    switch_003_6.name = "Switch.003"
	    switch_003_6.hide = True
	    switch_003_6.input_type = 'GEOMETRY'
	
	    #node String
	    string = mesh_hair_selector.nodes.new("FunctionNodeInputString")
	    string.name = "String"
	    string.string = "hair_card_UV"
	
	    #node String.001
	    string_001 = mesh_hair_selector.nodes.new("FunctionNodeInputString")
	    string_001.name = "String.001"
	    string_001.string = "tube_mesh_UV"
	
	    #node String.002
	    string_002 = mesh_hair_selector.nodes.new("FunctionNodeInputString")
	    string_002.name = "String.002"
	    string_002.string = "ribbon_mesh_UV"
	
	    #node String.003
	    string_003 = mesh_hair_selector.nodes.new("FunctionNodeInputString")
	    string_003.name = "String.003"
	    string_003.string = "stylized_hair_UV"
	
	    #node Reroute
	    reroute_10 = mesh_hair_selector.nodes.new("NodeReroute")
	    reroute_10.name = "Reroute"
	    reroute_10.socket_idname = "NodeSocketString"
	    #node Reroute.001
	    reroute_001_9 = mesh_hair_selector.nodes.new("NodeReroute")
	    reroute_001_9.name = "Reroute.001"
	    reroute_001_9.socket_idname = "NodeSocketString"
	    #node Reroute.002
	    reroute_002_7 = mesh_hair_selector.nodes.new("NodeReroute")
	    reroute_002_7.name = "Reroute.002"
	    reroute_002_7.socket_idname = "NodeSocketString"
	    #node Reroute.003
	    reroute_003_7 = mesh_hair_selector.nodes.new("NodeReroute")
	    reroute_003_7.name = "Reroute.003"
	    reroute_003_7.socket_idname = "NodeSocketString"
	    #node Reroute.004
	    reroute_004_7 = mesh_hair_selector.nodes.new("NodeReroute")
	    reroute_004_7.name = "Reroute.004"
	    reroute_004_7.socket_idname = "NodeSocketString"
	    #node Reroute.005
	    reroute_005_6 = mesh_hair_selector.nodes.new("NodeReroute")
	    reroute_005_6.name = "Reroute.005"
	    reroute_005_6.socket_idname = "NodeSocketString"
	    #node Reroute.006
	    reroute_006_5 = mesh_hair_selector.nodes.new("NodeReroute")
	    reroute_006_5.name = "Reroute.006"
	    reroute_006_5.socket_idname = "NodeSocketString"
	    #node Reroute.007
	    reroute_007_5 = mesh_hair_selector.nodes.new("NodeReroute")
	    reroute_007_5.name = "Reroute.007"
	    reroute_007_5.socket_idname = "NodeSocketString"
	    #node Reroute.008
	    reroute_008_5 = mesh_hair_selector.nodes.new("NodeReroute")
	    reroute_008_5.name = "Reroute.008"
	    reroute_008_5.socket_idname = "NodeSocketString"
	    #node Reroute.009
	    reroute_009_5 = mesh_hair_selector.nodes.new("NodeReroute")
	    reroute_009_5.name = "Reroute.009"
	    reroute_009_5.socket_idname = "NodeSocketString"
	    #node Reroute.010
	    reroute_010_3 = mesh_hair_selector.nodes.new("NodeReroute")
	    reroute_010_3.name = "Reroute.010"
	    reroute_010_3.socket_idname = "NodeSocketString"
	    #node Reroute.011
	    reroute_011_4 = mesh_hair_selector.nodes.new("NodeReroute")
	    reroute_011_4.name = "Reroute.011"
	    reroute_011_4.socket_idname = "NodeSocketString"
	    #node Reroute.012
	    reroute_012_5 = mesh_hair_selector.nodes.new("NodeReroute")
	    reroute_012_5.name = "Reroute.012"
	    reroute_012_5.socket_idname = "NodeSocketString"
	    #node Reroute.013
	    reroute_013_5 = mesh_hair_selector.nodes.new("NodeReroute")
	    reroute_013_5.name = "Reroute.013"
	    reroute_013_5.socket_idname = "NodeSocketString"
	    #node Reroute.014
	    reroute_014_5 = mesh_hair_selector.nodes.new("NodeReroute")
	    reroute_014_5.name = "Reroute.014"
	    reroute_014_5.socket_idname = "NodeSocketString"
	    #node Group Input.007
	    group_input_007_4 = mesh_hair_selector.nodes.new("NodeGroupInput")
	    group_input_007_4.name = "Group Input.007"
	    group_input_007_4.outputs[0].hide = True
	    group_input_007_4.outputs[1].hide = True
	    group_input_007_4.outputs[2].hide = True
	    group_input_007_4.outputs[3].hide = True
	    group_input_007_4.outputs[4].hide = True
	    group_input_007_4.outputs[5].hide = True
	    group_input_007_4.outputs[6].hide = True
	    group_input_007_4.outputs[7].hide = True
	    group_input_007_4.outputs[8].hide = True
	    group_input_007_4.outputs[9].hide = True
	    group_input_007_4.outputs[10].hide = True
	    group_input_007_4.outputs[11].hide = True
	    group_input_007_4.outputs[12].hide = True
	    group_input_007_4.outputs[13].hide = True
	    group_input_007_4.outputs[15].hide = True
	
	    #node Store Named Attribute.001
	    store_named_attribute_001_1 = mesh_hair_selector.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_001_1.name = "Store Named Attribute.001"
	    store_named_attribute_001_1.data_type = 'INT'
	    store_named_attribute_001_1.domain = 'CORNER'
	    #Selection
	    store_named_attribute_001_1.inputs[1].default_value = True
	    #Name
	    store_named_attribute_001_1.inputs[2].default_value = "mesh_idx"
	
	    #node Remove Named Attribute
	    remove_named_attribute = mesh_hair_selector.nodes.new("GeometryNodeRemoveAttribute")
	    remove_named_attribute.name = "Remove Named Attribute"
	    remove_named_attribute.pattern_mode = 'EXACT'
	
	    #node Reroute.015
	    reroute_015_5 = mesh_hair_selector.nodes.new("NodeReroute")
	    reroute_015_5.name = "Reroute.015"
	    reroute_015_5.socket_idname = "NodeSocketString"
	    #node Reroute.016
	    reroute_016_5 = mesh_hair_selector.nodes.new("NodeReroute")
	    reroute_016_5.name = "Reroute.016"
	    reroute_016_5.socket_idname = "NodeSocketString"
	    #node Set Shade Smooth
	    set_shade_smooth = mesh_hair_selector.nodes.new("GeometryNodeSetShadeSmooth")
	    set_shade_smooth.name = "Set Shade Smooth"
	    set_shade_smooth.domain = 'FACE'
	    set_shade_smooth.inputs[1].hide = True
	    #Selection
	    set_shade_smooth.inputs[1].default_value = True
	
	    #node Use Mesh Bake
	    use_mesh_bake = mesh_hair_selector.nodes.new("GeometryNodeBake")
	    use_mesh_bake.label = "Use Mesh Bake"
	    use_mesh_bake.name = "Use Mesh Bake"
	    use_mesh_bake.active_index = 0
	    use_mesh_bake.bake_items.clear()
	    use_mesh_bake.bake_items.new('GEOMETRY', "Geometry")
	    use_mesh_bake.bake_items[0].attribute_domain = 'POINT'
	    use_mesh_bake.inputs[1].hide = True
	    use_mesh_bake.outputs[1].hide = True
	
	    #node Group Input.008
	    group_input_008_3 = mesh_hair_selector.nodes.new("NodeGroupInput")
	    group_input_008_3.name = "Group Input.008"
	    group_input_008_3.outputs[0].hide = True
	    group_input_008_3.outputs[1].hide = True
	    group_input_008_3.outputs[2].hide = True
	    group_input_008_3.outputs[3].hide = True
	    group_input_008_3.outputs[4].hide = True
	    group_input_008_3.outputs[5].hide = True
	    group_input_008_3.outputs[6].hide = True
	    group_input_008_3.outputs[8].hide = True
	    group_input_008_3.outputs[9].hide = True
	    group_input_008_3.outputs[10].hide = True
	    group_input_008_3.outputs[11].hide = True
	    group_input_008_3.outputs[12].hide = True
	    group_input_008_3.outputs[13].hide = True
	    group_input_008_3.outputs[14].hide = True
	    group_input_008_3.outputs[15].hide = True
	
	    #node Mesh Overall Shape
	    mesh_overall_shape = mesh_hair_selector.nodes.new("ShaderNodeFloatCurve")
	    mesh_overall_shape.label = "Mesh Overall Shape"
	    mesh_overall_shape.name = "Mesh Overall Shape"
	    #mapping settings
	    mesh_overall_shape.mapping.extend = 'EXTRAPOLATED'
	    mesh_overall_shape.mapping.tone = 'STANDARD'
	    mesh_overall_shape.mapping.black_level = (0.0, 0.0, 0.0)
	    mesh_overall_shape.mapping.white_level = (1.0, 1.0, 1.0)
	    mesh_overall_shape.mapping.clip_min_x = 0.0
	    mesh_overall_shape.mapping.clip_min_y = 0.0
	    mesh_overall_shape.mapping.clip_max_x = 1.0
	    mesh_overall_shape.mapping.clip_max_y = 1.0
	    mesh_overall_shape.mapping.use_clip = True
	    #curve 0
	    mesh_overall_shape_curve_0 = mesh_overall_shape.mapping.curves[0]
	    mesh_overall_shape_curve_0_point_0 = mesh_overall_shape_curve_0.points[0]
	    mesh_overall_shape_curve_0_point_0.location = (0.0, 1.0)
	    mesh_overall_shape_curve_0_point_0.handle_type = 'AUTO'
	    mesh_overall_shape_curve_0_point_1 = mesh_overall_shape_curve_0.points[1]
	    mesh_overall_shape_curve_0_point_1.location = (1.0, 0.550000011920929)
	    mesh_overall_shape_curve_0_point_1.handle_type = 'AUTO'
	    #update curve after changes
	    mesh_overall_shape.mapping.update()
	    #Factor
	    mesh_overall_shape.inputs[0].default_value = 1.0
	
	    #node Spline Parameter
	    spline_parameter_6 = mesh_hair_selector.nodes.new("GeometryNodeSplineParameter")
	    spline_parameter_6.name = "Spline Parameter"
	    spline_parameter_6.outputs[1].hide = True
	    spline_parameter_6.outputs[2].hide = True
	
	    #node Switch.004
	    switch_004_3 = mesh_hair_selector.nodes.new("GeometryNodeSwitch")
	    switch_004_3.name = "Switch.004"
	    switch_004_3.hide = True
	    switch_004_3.input_type = 'FLOAT'
	
	    #node Group Input.009
	    group_input_009_3 = mesh_hair_selector.nodes.new("NodeGroupInput")
	    group_input_009_3.name = "Group Input.009"
	    group_input_009_3.outputs[0].hide = True
	    group_input_009_3.outputs[1].hide = True
	    group_input_009_3.outputs[2].hide = True
	    group_input_009_3.outputs[3].hide = True
	    group_input_009_3.outputs[4].hide = True
	    group_input_009_3.outputs[6].hide = True
	    group_input_009_3.outputs[7].hide = True
	    group_input_009_3.outputs[8].hide = True
	    group_input_009_3.outputs[9].hide = True
	    group_input_009_3.outputs[10].hide = True
	    group_input_009_3.outputs[11].hide = True
	    group_input_009_3.outputs[12].hide = True
	    group_input_009_3.outputs[13].hide = True
	    group_input_009_3.outputs[14].hide = True
	    group_input_009_3.outputs[15].hide = True
	
	    #node Attribute Statistic
	    attribute_statistic_1 = mesh_hair_selector.nodes.new("GeometryNodeAttributeStatistic")
	    attribute_statistic_1.name = "Attribute Statistic"
	    attribute_statistic_1.hide = True
	    attribute_statistic_1.data_type = 'FLOAT'
	    attribute_statistic_1.domain = 'POINT'
	    attribute_statistic_1.inputs[1].hide = True
	    attribute_statistic_1.outputs[0].hide = True
	    attribute_statistic_1.outputs[1].hide = True
	    attribute_statistic_1.outputs[3].hide = True
	    attribute_statistic_1.outputs[4].hide = True
	    attribute_statistic_1.outputs[5].hide = True
	    attribute_statistic_1.outputs[6].hide = True
	    attribute_statistic_1.outputs[7].hide = True
	    #Selection
	    attribute_statistic_1.inputs[1].default_value = True
	
	    #node Store Named Attribute.002
	    store_named_attribute_002 = mesh_hair_selector.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_002.name = "Store Named Attribute.002"
	    store_named_attribute_002.hide = True
	    store_named_attribute_002.data_type = 'FLOAT'
	    store_named_attribute_002.domain = 'POINT'
	    store_named_attribute_002.inputs[1].hide = True
	    store_named_attribute_002.inputs[2].hide = True
	    #Selection
	    store_named_attribute_002.inputs[1].default_value = True
	    #Name
	    store_named_attribute_002.inputs[2].default_value = "mcr"
	
	    #node Compare.005
	    compare_005_2 = mesh_hair_selector.nodes.new("FunctionNodeCompare")
	    compare_005_2.name = "Compare.005"
	    compare_005_2.hide = True
	    compare_005_2.data_type = 'FLOAT'
	    compare_005_2.mode = 'ELEMENT'
	    compare_005_2.operation = 'EQUAL'
	    compare_005_2.inputs[1].hide = True
	    compare_005_2.inputs[2].hide = True
	    compare_005_2.inputs[3].hide = True
	    compare_005_2.inputs[4].hide = True
	    compare_005_2.inputs[5].hide = True
	    compare_005_2.inputs[6].hide = True
	    compare_005_2.inputs[7].hide = True
	    compare_005_2.inputs[8].hide = True
	    compare_005_2.inputs[9].hide = True
	    compare_005_2.inputs[10].hide = True
	    compare_005_2.inputs[11].hide = True
	    compare_005_2.inputs[12].hide = True
	    #B
	    compare_005_2.inputs[1].default_value = 0.0
	    #Epsilon
	    compare_005_2.inputs[12].default_value = 0.0
	
	    #node Named Attribute.001
	    named_attribute_001_1 = mesh_hair_selector.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute_001_1.name = "Named Attribute.001"
	    named_attribute_001_1.hide = True
	    named_attribute_001_1.data_type = 'FLOAT'
	    #Name
	    named_attribute_001_1.inputs[0].default_value = "mcr"
	
	    #node Group Input.010
	    group_input_010_2 = mesh_hair_selector.nodes.new("NodeGroupInput")
	    group_input_010_2.name = "Group Input.010"
	    group_input_010_2.outputs[1].hide = True
	    group_input_010_2.outputs[2].hide = True
	    group_input_010_2.outputs[3].hide = True
	    group_input_010_2.outputs[4].hide = True
	    group_input_010_2.outputs[5].hide = True
	    group_input_010_2.outputs[6].hide = True
	    group_input_010_2.outputs[7].hide = True
	    group_input_010_2.outputs[8].hide = True
	    group_input_010_2.outputs[9].hide = True
	    group_input_010_2.outputs[10].hide = True
	    group_input_010_2.outputs[11].hide = True
	    group_input_010_2.outputs[12].hide = True
	    group_input_010_2.outputs[13].hide = True
	    group_input_010_2.outputs[14].hide = True
	    group_input_010_2.outputs[15].hide = True
	
	
	
	
	
	    #Set locations
	    group_output_13.location = (2610.42724609375, -19.416736602783203)
	    group_5.location = (-79.76215362548828, -110.40367889404297)
	    group_001_5.location = (-81.79773712158203, -748.9313354492188)
	    group_002_1.location = (-78.79950714111328, -318.1512451171875)
	    group_003_2.location = (-78.67485809326172, -526.0662231445312)
	    group_input_001_9.location = (-338.60595703125, -155.34437561035156)
	    group_input_002_8.location = (-338.60595703125, -362.43890380859375)
	    group_input_003_9.location = (-338.60595703125, -569.8320922851562)
	    group_input_004_8.location = (-338.60595703125, -815.11083984375)
	    menu_switch_001.location = (469.07684326171875, 163.7274627685547)
	    store_named_attribute_7.location = (1647.7332763671875, -19.652393341064453)
	    named_attribute_3.location = (1475.844482421875, -157.7658233642578)
	    group_input_005_6.location = (265.0098571777344, 135.95323181152344)
	    group_input_006_4.location = (-338.60595703125, -756.4561767578125)
	    compare_9.location = (1238.7310791015625, -84.21184539794922)
	    switch_10.location = (1238.74365234375, -117.19403076171875)
	    compare_001_4.location = (1099.1707763671875, -299.4894104003906)
	    switch_001_7.location = (1106.2532958984375, -334.8301696777344)
	    compare_002_4.location = (970.40234375, -499.8262634277344)
	    switch_002_5.location = (975.1282958984375, -535.1670532226562)
	    compare_003_3.location = (837.8390502929688, -724.1065063476562)
	    switch_003_6.location = (840.2083740234375, -760.2830810546875)
	    string.location = (84.04959869384766, -54.475547790527344)
	    string_001.location = (82.85930633544922, -258.00762939453125)
	    string_002.location = (79.31243896484375, -471.3780517578125)
	    string_003.location = (76.95584106445312, -696.93603515625)
	    reroute_10.location = (266.1946716308594, -90.37294006347656)
	    reroute_001_9.location = (330.2995910644531, -295.4872741699219)
	    reroute_002_7.location = (386.08740234375, -507.37738037109375)
	    reroute_003_7.location = (432.0370178222656, -735.281005859375)
	    reroute_004_7.location = (267.64080810546875, 58.478363037109375)
	    reroute_005_6.location = (328.94110107421875, 33.61994552612305)
	    reroute_006_5.location = (388.06353759765625, 12.934127807617188)
	    reroute_007_5.location = (434.48321533203125, -6.701620101928711)
	    reroute_008_5.location = (790.6254272460938, 129.04226684570312)
	    reroute_009_5.location = (800.4947509765625, -727.48974609375)
	    reroute_010_3.location = (796.8050537109375, -498.8685607910156)
	    reroute_011_4.location = (792.9110107421875, -293.6495361328125)
	    reroute_012_5.location = (790.7710571289062, -80.90033721923828)
	    reroute_013_5.location = (1415.17578125, -264.01324462890625)
	    reroute_014_5.location = (1401.7613525390625, 129.6073760986328)
	    group_input_007_4.location = (1837.3367919921875, -221.13070678710938)
	    store_named_attribute_001_1.location = (1841.328125, -19.652393341064453)
	    remove_named_attribute.location = (2020.999755859375, -18.566680908203125)
	    reroute_015_5.location = (1997.9866943359375, 132.55369567871094)
	    reroute_016_5.location = (2003.16845703125, -126.52413940429688)
	    set_shade_smooth.location = (2246.024658203125, -17.58367919921875)
	    use_mesh_bake.location = (2430.91064453125, 27.558258056640625)
	    group_input_008_3.location = (2049.84326171875, -148.66607666015625)
	    mesh_overall_shape.location = (-873.3704223632812, -650.7651977539062)
	    spline_parameter_6.location = (-876.84423828125, -968.0524291992188)
	    switch_004_3.location = (-631.904296875, -473.04425048828125)
	    group_input_009_3.location = (-872.6063232421875, -591.0381469726562)
	    attribute_statistic_1.location = (-870.9525146484375, -511.33477783203125)
	    store_named_attribute_002.location = (-879.0206909179688, -565.9711303710938)
	    compare_005_2.location = (-632.6890869140625, -511.18927001953125)
	    named_attribute_001_1.location = (-874.1126708984375, -454.52947998046875)
	    group_input_010_2.location = (-1047.1160888671875, -533.9951782226562)
	
	    #Set dimensions
	    group_output_13.width, group_output_13.height = 140.0, 100.0
	    group_5.width, group_5.height = 140.0, 100.0
	    group_001_5.width, group_001_5.height = 140.0, 100.0
	    group_002_1.width, group_002_1.height = 140.0, 100.0
	    group_003_2.width, group_003_2.height = 140.0, 100.0
	    group_input_001_9.width, group_input_001_9.height = 140.0, 100.0
	    group_input_002_8.width, group_input_002_8.height = 140.0, 100.0
	    group_input_003_9.width, group_input_003_9.height = 140.0, 100.0
	    group_input_004_8.width, group_input_004_8.height = 140.0, 100.0
	    menu_switch_001.width, menu_switch_001.height = 245.18148803710938, 100.0
	    store_named_attribute_7.width, store_named_attribute_7.height = 140.0, 100.0
	    named_attribute_3.width, named_attribute_3.height = 140.0, 100.0
	    group_input_005_6.width, group_input_005_6.height = 140.0, 100.0
	    group_input_006_4.width, group_input_006_4.height = 140.0, 100.0
	    compare_9.width, compare_9.height = 140.0, 100.0
	    switch_10.width, switch_10.height = 140.0, 100.0
	    compare_001_4.width, compare_001_4.height = 140.0, 100.0
	    switch_001_7.width, switch_001_7.height = 140.0, 100.0
	    compare_002_4.width, compare_002_4.height = 140.0, 100.0
	    switch_002_5.width, switch_002_5.height = 140.0, 100.0
	    compare_003_3.width, compare_003_3.height = 140.0, 100.0
	    switch_003_6.width, switch_003_6.height = 140.0, 100.0
	    string.width, string.height = 140.0, 100.0
	    string_001.width, string_001.height = 140.0, 100.0
	    string_002.width, string_002.height = 140.0, 100.0
	    string_003.width, string_003.height = 140.0, 100.0
	    reroute_10.width, reroute_10.height = 100.0, 100.0
	    reroute_001_9.width, reroute_001_9.height = 100.0, 100.0
	    reroute_002_7.width, reroute_002_7.height = 100.0, 100.0
	    reroute_003_7.width, reroute_003_7.height = 100.0, 100.0
	    reroute_004_7.width, reroute_004_7.height = 100.0, 100.0
	    reroute_005_6.width, reroute_005_6.height = 100.0, 100.0
	    reroute_006_5.width, reroute_006_5.height = 100.0, 100.0
	    reroute_007_5.width, reroute_007_5.height = 100.0, 100.0
	    reroute_008_5.width, reroute_008_5.height = 100.0, 100.0
	    reroute_009_5.width, reroute_009_5.height = 100.0, 100.0
	    reroute_010_3.width, reroute_010_3.height = 100.0, 100.0
	    reroute_011_4.width, reroute_011_4.height = 100.0, 100.0
	    reroute_012_5.width, reroute_012_5.height = 100.0, 100.0
	    reroute_013_5.width, reroute_013_5.height = 100.0, 100.0
	    reroute_014_5.width, reroute_014_5.height = 100.0, 100.0
	    group_input_007_4.width, group_input_007_4.height = 140.0, 100.0
	    store_named_attribute_001_1.width, store_named_attribute_001_1.height = 140.0, 100.0
	    remove_named_attribute.width, remove_named_attribute.height = 170.0, 100.0
	    reroute_015_5.width, reroute_015_5.height = 100.0, 100.0
	    reroute_016_5.width, reroute_016_5.height = 100.0, 100.0
	    set_shade_smooth.width, set_shade_smooth.height = 140.0, 100.0
	    use_mesh_bake.width, use_mesh_bake.height = 140.0, 100.0
	    group_input_008_3.width, group_input_008_3.height = 140.0, 100.0
	    mesh_overall_shape.width, mesh_overall_shape.height = 240.0, 100.0
	    spline_parameter_6.width, spline_parameter_6.height = 140.0, 100.0
	    switch_004_3.width, switch_004_3.height = 140.0, 100.0
	    group_input_009_3.width, group_input_009_3.height = 140.0, 100.0
	    attribute_statistic_1.width, attribute_statistic_1.height = 140.0, 100.0
	    store_named_attribute_002.width, store_named_attribute_002.height = 140.0, 100.0
	    compare_005_2.width, compare_005_2.height = 140.0, 100.0
	    named_attribute_001_1.width, named_attribute_001_1.height = 140.0, 100.0
	    group_input_010_2.width, group_input_010_2.height = 140.0, 100.0
	
	    #initialize mesh_hair_selector links
	    #use_mesh_bake.Geometry -> group_output_13.Geometry
	    mesh_hair_selector.links.new(use_mesh_bake.outputs[0], group_output_13.inputs[0])
	    #group_input_001_9.Geometry -> group_5.Geometry
	    mesh_hair_selector.links.new(group_input_001_9.outputs[0], group_5.inputs[0])
	    #group_input_002_8.Geometry -> group_002_1.Geometry
	    mesh_hair_selector.links.new(group_input_002_8.outputs[0], group_002_1.inputs[0])
	    #group_input_003_9.Geometry -> group_003_2.Geometry
	    mesh_hair_selector.links.new(group_input_003_9.outputs[0], group_003_2.inputs[0])
	    #group_input_001_9.Material -> group_5.Material
	    mesh_hair_selector.links.new(group_input_001_9.outputs[2], group_5.inputs[1])
	    #named_attribute_3.Attribute -> store_named_attribute_7.Value
	    mesh_hair_selector.links.new(named_attribute_3.outputs[0], store_named_attribute_7.inputs[3])
	    #reroute_013_5.Output -> named_attribute_3.Name
	    mesh_hair_selector.links.new(reroute_013_5.outputs[0], named_attribute_3.inputs[0])
	    #group_input_005_6.Style Select -> menu_switch_001.Menu
	    mesh_hair_selector.links.new(group_input_005_6.outputs[1], menu_switch_001.inputs[0])
	    #group_input_001_9.Resolution -> group_5.Resolution
	    mesh_hair_selector.links.new(group_input_001_9.outputs[3], group_5.inputs[3])
	    #group_input_001_9.Width -> group_5.Width
	    mesh_hair_selector.links.new(group_input_001_9.outputs[4], group_5.inputs[4])
	    #group_input_001_9.Hair Card Angle -> group_5.Angle
	    mesh_hair_selector.links.new(group_input_001_9.outputs[8], group_5.inputs[5])
	    #group_input_002_8.Material -> group_002_1.Material
	    mesh_hair_selector.links.new(group_input_002_8.outputs[2], group_002_1.inputs[1])
	    #group_input_002_8.Resolution -> group_002_1.Resolution
	    mesh_hair_selector.links.new(group_input_002_8.outputs[3], group_002_1.inputs[3])
	    #group_input_002_8.Width -> group_002_1.Width
	    mesh_hair_selector.links.new(group_input_002_8.outputs[4], group_002_1.inputs[4])
	    #group_input_002_8.Fill Caps -> group_002_1.Fill Caps
	    mesh_hair_selector.links.new(group_input_002_8.outputs[6], group_002_1.inputs[5])
	    #group_input_003_9.Material -> group_003_2.Material
	    mesh_hair_selector.links.new(group_input_003_9.outputs[2], group_003_2.inputs[1])
	    #group_input_003_9.Resolution -> group_003_2.Resolution
	    mesh_hair_selector.links.new(group_input_003_9.outputs[3], group_003_2.inputs[4])
	    #group_input_003_9.Width -> group_003_2.Width
	    mesh_hair_selector.links.new(group_input_003_9.outputs[4], group_003_2.inputs[5])
	    #group_input_003_9.Tube Ribbon Count -> group_003_2.Ribbon Count
	    mesh_hair_selector.links.new(group_input_003_9.outputs[9], group_003_2.inputs[3])
	    #group_input_004_8.Material -> group_001_5.Material
	    mesh_hair_selector.links.new(group_input_004_8.outputs[2], group_001_5.inputs[2])
	    #group_input_004_8.Fill Caps -> group_001_5.Fill Caps
	    mesh_hair_selector.links.new(group_input_004_8.outputs[6], group_001_5.inputs[5])
	    #group_input_004_8.Profile Translation -> group_001_5.Translation
	    mesh_hair_selector.links.new(group_input_004_8.outputs[11], group_001_5.inputs[6])
	    #group_input_004_8.Profile Rotation -> group_001_5.Rotation
	    mesh_hair_selector.links.new(group_input_004_8.outputs[12], group_001_5.inputs[7])
	    #group_input_004_8.Profile Scale -> group_001_5.Scale
	    mesh_hair_selector.links.new(group_input_004_8.outputs[13], group_001_5.inputs[8])
	    #group_input_006_4.Profile Curve -> group_001_5.Profile
	    mesh_hair_selector.links.new(group_input_006_4.outputs[10], group_001_5.inputs[1])
	    #group_input_004_8.Resolution -> group_001_5.Resolution
	    mesh_hair_selector.links.new(group_input_004_8.outputs[3], group_001_5.inputs[4])
	    #compare_9.Result -> switch_10.Switch
	    mesh_hair_selector.links.new(compare_9.outputs[0], switch_10.inputs[0])
	    #compare_001_4.Result -> switch_001_7.Switch
	    mesh_hair_selector.links.new(compare_001_4.outputs[0], switch_001_7.inputs[0])
	    #compare_002_4.Result -> switch_002_5.Switch
	    mesh_hair_selector.links.new(compare_002_4.outputs[0], switch_002_5.inputs[0])
	    #reroute_009_5.Output -> compare_003_3.A
	    mesh_hair_selector.links.new(reroute_009_5.outputs[0], compare_003_3.inputs[8])
	    #compare_003_3.Result -> switch_003_6.Switch
	    mesh_hair_selector.links.new(compare_003_3.outputs[0], switch_003_6.inputs[0])
	    #switch_001_7.Output -> switch_10.False
	    mesh_hair_selector.links.new(switch_001_7.outputs[0], switch_10.inputs[1])
	    #switch_002_5.Output -> switch_001_7.False
	    mesh_hair_selector.links.new(switch_002_5.outputs[0], switch_001_7.inputs[1])
	    #switch_003_6.Output -> switch_002_5.False
	    mesh_hair_selector.links.new(switch_003_6.outputs[0], switch_002_5.inputs[1])
	    #reroute_004_7.Output -> menu_switch_001.Hair Card
	    mesh_hair_selector.links.new(reroute_004_7.outputs[0], menu_switch_001.inputs[1])
	    #reroute_10.Output -> compare_9.B
	    mesh_hair_selector.links.new(reroute_10.outputs[0], compare_9.inputs[9])
	    #group_5.Geometry -> switch_10.True
	    mesh_hair_selector.links.new(group_5.outputs[0], switch_10.inputs[2])
	    #reroute_005_6.Output -> menu_switch_001.Tube Mesh
	    mesh_hair_selector.links.new(reroute_005_6.outputs[0], menu_switch_001.inputs[2])
	    #reroute_001_9.Output -> compare_001_4.B
	    mesh_hair_selector.links.new(reroute_001_9.outputs[0], compare_001_4.inputs[9])
	    #group_002_1.Geometry -> switch_001_7.True
	    mesh_hair_selector.links.new(group_002_1.outputs[0], switch_001_7.inputs[2])
	    #reroute_006_5.Output -> menu_switch_001.Tube Ribbon
	    mesh_hair_selector.links.new(reroute_006_5.outputs[0], menu_switch_001.inputs[3])
	    #reroute_002_7.Output -> compare_002_4.B
	    mesh_hair_selector.links.new(reroute_002_7.outputs[0], compare_002_4.inputs[9])
	    #group_003_2.Geometry -> switch_002_5.True
	    mesh_hair_selector.links.new(group_003_2.outputs[0], switch_002_5.inputs[2])
	    #reroute_007_5.Output -> menu_switch_001.Stylized
	    mesh_hair_selector.links.new(reroute_007_5.outputs[0], menu_switch_001.inputs[4])
	    #reroute_003_7.Output -> compare_003_3.B
	    mesh_hair_selector.links.new(reroute_003_7.outputs[0], compare_003_3.inputs[9])
	    #group_001_5.Geometry -> switch_003_6.True
	    mesh_hair_selector.links.new(group_001_5.outputs[0], switch_003_6.inputs[2])
	    #switch_10.Output -> store_named_attribute_7.Geometry
	    mesh_hair_selector.links.new(switch_10.outputs[0], store_named_attribute_7.inputs[0])
	    #string.String -> reroute_10.Input
	    mesh_hair_selector.links.new(string.outputs[0], reroute_10.inputs[0])
	    #string_001.String -> reroute_001_9.Input
	    mesh_hair_selector.links.new(string_001.outputs[0], reroute_001_9.inputs[0])
	    #string_002.String -> reroute_002_7.Input
	    mesh_hair_selector.links.new(string_002.outputs[0], reroute_002_7.inputs[0])
	    #string_003.String -> reroute_003_7.Input
	    mesh_hair_selector.links.new(string_003.outputs[0], reroute_003_7.inputs[0])
	    #reroute_10.Output -> reroute_004_7.Input
	    mesh_hair_selector.links.new(reroute_10.outputs[0], reroute_004_7.inputs[0])
	    #reroute_001_9.Output -> reroute_005_6.Input
	    mesh_hair_selector.links.new(reroute_001_9.outputs[0], reroute_005_6.inputs[0])
	    #reroute_002_7.Output -> reroute_006_5.Input
	    mesh_hair_selector.links.new(reroute_002_7.outputs[0], reroute_006_5.inputs[0])
	    #reroute_003_7.Output -> reroute_007_5.Input
	    mesh_hair_selector.links.new(reroute_003_7.outputs[0], reroute_007_5.inputs[0])
	    #menu_switch_001.Output -> reroute_008_5.Input
	    mesh_hair_selector.links.new(menu_switch_001.outputs[0], reroute_008_5.inputs[0])
	    #reroute_010_3.Output -> reroute_009_5.Input
	    mesh_hair_selector.links.new(reroute_010_3.outputs[0], reroute_009_5.inputs[0])
	    #reroute_011_4.Output -> reroute_010_3.Input
	    mesh_hair_selector.links.new(reroute_011_4.outputs[0], reroute_010_3.inputs[0])
	    #reroute_010_3.Output -> compare_002_4.A
	    mesh_hair_selector.links.new(reroute_010_3.outputs[0], compare_002_4.inputs[8])
	    #reroute_012_5.Output -> reroute_011_4.Input
	    mesh_hair_selector.links.new(reroute_012_5.outputs[0], reroute_011_4.inputs[0])
	    #reroute_008_5.Output -> reroute_012_5.Input
	    mesh_hair_selector.links.new(reroute_008_5.outputs[0], reroute_012_5.inputs[0])
	    #reroute_011_4.Output -> compare_001_4.A
	    mesh_hair_selector.links.new(reroute_011_4.outputs[0], compare_001_4.inputs[8])
	    #reroute_012_5.Output -> compare_9.A
	    mesh_hair_selector.links.new(reroute_012_5.outputs[0], compare_9.inputs[8])
	    #reroute_014_5.Output -> reroute_013_5.Input
	    mesh_hair_selector.links.new(reroute_014_5.outputs[0], reroute_013_5.inputs[0])
	    #reroute_008_5.Output -> reroute_014_5.Input
	    mesh_hair_selector.links.new(reroute_008_5.outputs[0], reroute_014_5.inputs[0])
	    #store_named_attribute_7.Geometry -> store_named_attribute_001_1.Geometry
	    mesh_hair_selector.links.new(store_named_attribute_7.outputs[0], store_named_attribute_001_1.inputs[0])
	    #group_input_007_4.Mesh Index -> store_named_attribute_001_1.Value
	    mesh_hair_selector.links.new(group_input_007_4.outputs[14], store_named_attribute_001_1.inputs[3])
	    #store_named_attribute_001_1.Geometry -> remove_named_attribute.Geometry
	    mesh_hair_selector.links.new(store_named_attribute_001_1.outputs[0], remove_named_attribute.inputs[0])
	    #reroute_016_5.Output -> remove_named_attribute.Name
	    mesh_hair_selector.links.new(reroute_016_5.outputs[0], remove_named_attribute.inputs[1])
	    #reroute_014_5.Output -> reroute_015_5.Input
	    mesh_hair_selector.links.new(reroute_014_5.outputs[0], reroute_015_5.inputs[0])
	    #reroute_015_5.Output -> reroute_016_5.Input
	    mesh_hair_selector.links.new(reroute_015_5.outputs[0], reroute_016_5.inputs[0])
	    #set_shade_smooth.Geometry -> use_mesh_bake.Geometry
	    mesh_hair_selector.links.new(set_shade_smooth.outputs[0], use_mesh_bake.inputs[0])
	    #remove_named_attribute.Geometry -> set_shade_smooth.Geometry
	    mesh_hair_selector.links.new(remove_named_attribute.outputs[0], set_shade_smooth.inputs[0])
	    #group_input_008_3.Shade Smooth -> set_shade_smooth.Shade Smooth
	    mesh_hair_selector.links.new(group_input_008_3.outputs[7], set_shade_smooth.inputs[2])
	    #switch_004_3.Output -> group_001_5.Curve Radius
	    mesh_hair_selector.links.new(switch_004_3.outputs[0], group_001_5.inputs[3])
	    #switch_004_3.Output -> group_003_2.Curve Radius
	    mesh_hair_selector.links.new(switch_004_3.outputs[0], group_003_2.inputs[2])
	    #switch_004_3.Output -> group_002_1.Curve Radius
	    mesh_hair_selector.links.new(switch_004_3.outputs[0], group_002_1.inputs[2])
	    #switch_004_3.Output -> group_5.Curve Radius
	    mesh_hair_selector.links.new(switch_004_3.outputs[0], group_5.inputs[2])
	    #spline_parameter_6.Factor -> mesh_overall_shape.Value
	    mesh_hair_selector.links.new(spline_parameter_6.outputs[0], mesh_overall_shape.inputs[1])
	    #group_input_009_3.Curve Radius -> store_named_attribute_002.Value
	    mesh_hair_selector.links.new(group_input_009_3.outputs[5], store_named_attribute_002.inputs[3])
	    #store_named_attribute_002.Geometry -> attribute_statistic_1.Geometry
	    mesh_hair_selector.links.new(store_named_attribute_002.outputs[0], attribute_statistic_1.inputs[0])
	    #attribute_statistic_1.Sum -> compare_005_2.A
	    mesh_hair_selector.links.new(attribute_statistic_1.outputs[2], compare_005_2.inputs[0])
	    #compare_005_2.Result -> switch_004_3.Switch
	    mesh_hair_selector.links.new(compare_005_2.outputs[0], switch_004_3.inputs[0])
	    #named_attribute_001_1.Attribute -> attribute_statistic_1.Attribute
	    mesh_hair_selector.links.new(named_attribute_001_1.outputs[0], attribute_statistic_1.inputs[2])
	    #mesh_overall_shape.Value -> switch_004_3.True
	    mesh_hair_selector.links.new(mesh_overall_shape.outputs[0], switch_004_3.inputs[2])
	    #group_input_009_3.Curve Radius -> switch_004_3.False
	    mesh_hair_selector.links.new(group_input_009_3.outputs[5], switch_004_3.inputs[1])
	    #group_input_010_2.Geometry -> store_named_attribute_002.Geometry
	    mesh_hair_selector.links.new(group_input_010_2.outputs[0], store_named_attribute_002.inputs[0])
	    #group_input_004_8.Geometry -> group_001_5.Geometry
	    mesh_hair_selector.links.new(group_input_004_8.outputs[0], group_001_5.inputs[0])
	    style_select_socket.default_value = 'Hair Card'
	    return mesh_hair_selector
	
	mesh_hair_selector = mesh_hair_selector_node_group()
	
	#initialize stylized_eyebrow node group
	def stylized_eyebrow_node_group():
	    stylized_eyebrow = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Stylized_eyebrow")
	
	    stylized_eyebrow.color_tag = 'NONE'
	    stylized_eyebrow.description = ""
	    stylized_eyebrow.default_group_node_width = 140
	    
	
	
	    #stylized_eyebrow interface
	    #Socket Geometry
	    geometry_socket_18 = stylized_eyebrow.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_18.attribute_domain = 'POINT'
	
	    #Socket Geometry
	    geometry_socket_19 = stylized_eyebrow.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_19.attribute_domain = 'POINT'
	
	    #Socket Hair Curves
	    hair_curves_socket = stylized_eyebrow.interface.new_socket(name = "Hair Curves", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    hair_curves_socket.attribute_domain = 'POINT'
	
	    #Socket Control Points
	    control_points_socket = stylized_eyebrow.interface.new_socket(name = "Control Points", in_out='INPUT', socket_type = 'NodeSocketInt')
	    control_points_socket.default_value = 10
	    control_points_socket.min_value = 2
	    control_points_socket.max_value = 100000
	    control_points_socket.subtype = 'NONE'
	    control_points_socket.attribute_domain = 'POINT'
	
	    #Socket Resolution
	    resolution_socket_5 = stylized_eyebrow.interface.new_socket(name = "Resolution", in_out='INPUT', socket_type = 'NodeSocketInt')
	    resolution_socket_5.default_value = 8
	    resolution_socket_5.min_value = 3
	    resolution_socket_5.max_value = 512
	    resolution_socket_5.subtype = 'NONE'
	    resolution_socket_5.attribute_domain = 'POINT'
	
	    #Socket Radius
	    radius_socket_1 = stylized_eyebrow.interface.new_socket(name = "Radius", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    radius_socket_1.default_value = 1.0
	    radius_socket_1.min_value = 0.0
	    radius_socket_1.max_value = 3.4028234663852886e+38
	    radius_socket_1.subtype = 'DISTANCE'
	    radius_socket_1.attribute_domain = 'POINT'
	
	    #Socket Offset Factor
	    offset_factor_socket = stylized_eyebrow.interface.new_socket(name = "Offset Factor", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    offset_factor_socket.default_value = 0.09999990463256836
	    offset_factor_socket.min_value = 0.0
	    offset_factor_socket.max_value = 1.0
	    offset_factor_socket.subtype = 'FACTOR'
	    offset_factor_socket.attribute_domain = 'POINT'
	
	    #Socket Resample Count
	    resample_count_socket = stylized_eyebrow.interface.new_socket(name = "Resample Count", in_out='INPUT', socket_type = 'NodeSocketInt')
	    resample_count_socket.default_value = 10
	    resample_count_socket.min_value = 1
	    resample_count_socket.max_value = 100000
	    resample_count_socket.subtype = 'NONE'
	    resample_count_socket.attribute_domain = 'POINT'
	
	    #Socket Level
	    level_socket = stylized_eyebrow.interface.new_socket(name = "Level", in_out='INPUT', socket_type = 'NodeSocketInt')
	    level_socket.default_value = 1
	    level_socket.min_value = 0
	    level_socket.max_value = 6
	    level_socket.subtype = 'NONE'
	    level_socket.attribute_domain = 'POINT'
	
	    #Socket Edge Crease
	    edge_crease_socket = stylized_eyebrow.interface.new_socket(name = "Edge Crease", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    edge_crease_socket.default_value = 0.0
	    edge_crease_socket.min_value = 0.0
	    edge_crease_socket.max_value = 1.0
	    edge_crease_socket.subtype = 'FACTOR'
	    edge_crease_socket.attribute_domain = 'POINT'
	
	    #Socket Vertex Crease
	    vertex_crease_socket = stylized_eyebrow.interface.new_socket(name = "Vertex Crease", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    vertex_crease_socket.default_value = 0.0
	    vertex_crease_socket.min_value = 0.0
	    vertex_crease_socket.max_value = 1.0
	    vertex_crease_socket.subtype = 'FACTOR'
	    vertex_crease_socket.attribute_domain = 'POINT'
	
	    #Socket Limit Surface
	    limit_surface_socket = stylized_eyebrow.interface.new_socket(name = "Limit Surface", in_out='INPUT', socket_type = 'NodeSocketBool')
	    limit_surface_socket.default_value = True
	    limit_surface_socket.attribute_domain = 'POINT'
	
	    #Socket Distance
	    distance_socket = stylized_eyebrow.interface.new_socket(name = "Distance", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    distance_socket.default_value = 0.0010000000474974513
	    distance_socket.min_value = 0.0
	    distance_socket.max_value = 3.4028234663852886e+38
	    distance_socket.subtype = 'DISTANCE'
	    distance_socket.attribute_domain = 'POINT'
	
	
	    #initialize stylized_eyebrow nodes
	    #node Group Output
	    group_output_14 = stylized_eyebrow.nodes.new("NodeGroupOutput")
	    group_output_14.name = "Group Output"
	    group_output_14.is_active_output = True
	
	    #node Group Input
	    group_input_10 = stylized_eyebrow.nodes.new("NodeGroupInput")
	    group_input_10.name = "Group Input"
	    group_input_10.outputs[1].hide = True
	    group_input_10.outputs[3].hide = True
	    group_input_10.outputs[4].hide = True
	    group_input_10.outputs[5].hide = True
	    group_input_10.outputs[6].hide = True
	    group_input_10.outputs[7].hide = True
	    group_input_10.outputs[8].hide = True
	    group_input_10.outputs[9].hide = True
	    group_input_10.outputs[10].hide = True
	    group_input_10.outputs[11].hide = True
	    group_input_10.outputs[12].hide = True
	
	    #node Curve to Mesh
	    curve_to_mesh_4 = stylized_eyebrow.nodes.new("GeometryNodeCurveToMesh")
	    curve_to_mesh_4.name = "Curve to Mesh"
	    curve_to_mesh_4.hide = True
	    curve_to_mesh_4.inputs[2].hide = True
	    #Fill Caps
	    curve_to_mesh_4.inputs[2].default_value = True
	
	    #node Curve Circle
	    curve_circle_1 = stylized_eyebrow.nodes.new("GeometryNodeCurvePrimitiveCircle")
	    curve_circle_1.name = "Curve Circle"
	    curve_circle_1.hide = True
	    curve_circle_1.mode = 'RADIUS'
	
	    #node Set Position
	    set_position_4 = stylized_eyebrow.nodes.new("GeometryNodeSetPosition")
	    set_position_4.name = "Set Position"
	    set_position_4.hide = True
	    set_position_4.inputs[1].hide = True
	    set_position_4.inputs[3].hide = True
	    #Selection
	    set_position_4.inputs[1].default_value = True
	    #Offset
	    set_position_4.inputs[3].default_value = (0.0, 0.0, 0.0)
	
	    #node Geometry Proximity.001
	    geometry_proximity_001 = stylized_eyebrow.nodes.new("GeometryNodeProximity")
	    geometry_proximity_001.name = "Geometry Proximity.001"
	    geometry_proximity_001.hide = True
	    geometry_proximity_001.target_element = 'POINTS'
	    geometry_proximity_001.inputs[1].hide = True
	    geometry_proximity_001.inputs[2].hide = True
	    geometry_proximity_001.inputs[3].hide = True
	    geometry_proximity_001.outputs[1].hide = True
	    geometry_proximity_001.outputs[2].hide = True
	    #Group ID
	    geometry_proximity_001.inputs[1].default_value = 0
	    #Source Position
	    geometry_proximity_001.inputs[2].default_value = (0.0, 0.0, 0.0)
	    #Sample Group ID
	    geometry_proximity_001.inputs[3].default_value = 0
	
	    #node Curve to Mesh.001
	    curve_to_mesh_001 = stylized_eyebrow.nodes.new("GeometryNodeCurveToMesh")
	    curve_to_mesh_001.name = "Curve to Mesh.001"
	    curve_to_mesh_001.hide = True
	    curve_to_mesh_001.inputs[1].hide = True
	    curve_to_mesh_001.inputs[2].hide = True
	    #Fill Caps
	    curve_to_mesh_001.inputs[2].default_value = False
	
	    #node Resample Curve.001
	    resample_curve_001 = stylized_eyebrow.nodes.new("GeometryNodeResampleCurve")
	    resample_curve_001.name = "Resample Curve.001"
	    resample_curve_001.hide = True
	    resample_curve_001.keep_last_segment = True
	    resample_curve_001.mode = 'COUNT'
	    resample_curve_001.inputs[1].hide = True
	    resample_curve_001.inputs[3].hide = True
	    #Selection
	    resample_curve_001.inputs[1].default_value = True
	
	    #node Subdivision Surface
	    subdivision_surface = stylized_eyebrow.nodes.new("GeometryNodeSubdivisionSurface")
	    subdivision_surface.name = "Subdivision Surface"
	    subdivision_surface.hide = True
	    subdivision_surface.boundary_smooth = 'ALL'
	    subdivision_surface.uv_smooth = 'PRESERVE_BOUNDARIES'
	
	    #node Merge by Distance
	    merge_by_distance_1 = stylized_eyebrow.nodes.new("GeometryNodeMergeByDistance")
	    merge_by_distance_1.name = "Merge by Distance"
	    merge_by_distance_1.hide = True
	    merge_by_distance_1.mode = 'ALL'
	    merge_by_distance_1.inputs[1].hide = True
	    #Selection
	    merge_by_distance_1.inputs[1].default_value = True
	
	    #node Curve to Points.001
	    curve_to_points_001_1 = stylized_eyebrow.nodes.new("GeometryNodeCurveToPoints")
	    curve_to_points_001_1.name = "Curve to Points.001"
	    curve_to_points_001_1.hide = True
	    curve_to_points_001_1.mode = 'COUNT'
	    curve_to_points_001_1.inputs[2].hide = True
	    curve_to_points_001_1.outputs[1].hide = True
	    curve_to_points_001_1.outputs[2].hide = True
	    curve_to_points_001_1.outputs[3].hide = True
	
	    #node Sample Curve
	    sample_curve_1 = stylized_eyebrow.nodes.new("GeometryNodeSampleCurve")
	    sample_curve_1.name = "Sample Curve"
	    sample_curve_1.hide = True
	    sample_curve_1.data_type = 'FLOAT'
	    sample_curve_1.mode = 'FACTOR'
	    sample_curve_1.use_all_curves = False
	    sample_curve_1.inputs[1].hide = True
	    sample_curve_1.inputs[2].hide = True
	    sample_curve_1.inputs[3].hide = True
	    sample_curve_1.inputs[4].hide = True
	    sample_curve_1.outputs[0].hide = True
	    sample_curve_1.outputs[3].hide = True
	    #Value
	    sample_curve_1.inputs[1].default_value = 0.0
	    #Factor
	    sample_curve_1.inputs[2].default_value = 1.0
	    #Curve Index
	    sample_curve_1.inputs[4].default_value = 0
	
	    #node Points
	    points_1 = stylized_eyebrow.nodes.new("GeometryNodePoints")
	    points_1.name = "Points"
	    points_1.hide = True
	    points_1.inputs[0].hide = True
	    points_1.inputs[2].hide = True
	    #Count
	    points_1.inputs[0].default_value = 1
	    #Radius
	    points_1.inputs[2].default_value = 0.10000000149011612
	
	    #node Vector Math
	    vector_math_6 = stylized_eyebrow.nodes.new("ShaderNodeVectorMath")
	    vector_math_6.name = "Vector Math"
	    vector_math_6.hide = True
	    vector_math_6.operation = 'ADD'
	
	    #node Vector Math.003
	    vector_math_003_4 = stylized_eyebrow.nodes.new("ShaderNodeVectorMath")
	    vector_math_003_4.name = "Vector Math.003"
	    vector_math_003_4.hide = True
	    vector_math_003_4.operation = 'SCALE'
	
	    #node Points to Curves
	    points_to_curves_1 = stylized_eyebrow.nodes.new("GeometryNodePointsToCurves")
	    points_to_curves_1.name = "Points to Curves"
	    points_to_curves_1.hide = True
	    points_to_curves_1.inputs[1].hide = True
	    points_to_curves_1.inputs[2].hide = True
	    #Curve Group ID
	    points_to_curves_1.inputs[1].default_value = 0
	    #Weight
	    points_to_curves_1.inputs[2].default_value = 0.0
	
	    #node Join Geometry.003
	    join_geometry_003 = stylized_eyebrow.nodes.new("GeometryNodeJoinGeometry")
	    join_geometry_003.name = "Join Geometry.003"
	    join_geometry_003.hide = True
	
	    #node Group Input.001
	    group_input_001_10 = stylized_eyebrow.nodes.new("NodeGroupInput")
	    group_input_001_10.name = "Group Input.001"
	    group_input_001_10.outputs[0].hide = True
	    group_input_001_10.outputs[2].hide = True
	    group_input_001_10.outputs[3].hide = True
	    group_input_001_10.outputs[4].hide = True
	    group_input_001_10.outputs[5].hide = True
	    group_input_001_10.outputs[6].hide = True
	    group_input_001_10.outputs[7].hide = True
	    group_input_001_10.outputs[8].hide = True
	    group_input_001_10.outputs[9].hide = True
	    group_input_001_10.outputs[10].hide = True
	    group_input_001_10.outputs[11].hide = True
	    group_input_001_10.outputs[12].hide = True
	
	    #node Group Input.002
	    group_input_002_9 = stylized_eyebrow.nodes.new("NodeGroupInput")
	    group_input_002_9.name = "Group Input.002"
	    group_input_002_9.outputs[1].hide = True
	    group_input_002_9.outputs[2].hide = True
	    group_input_002_9.outputs[3].hide = True
	    group_input_002_9.outputs[4].hide = True
	    group_input_002_9.outputs[6].hide = True
	    group_input_002_9.outputs[7].hide = True
	    group_input_002_9.outputs[8].hide = True
	    group_input_002_9.outputs[9].hide = True
	    group_input_002_9.outputs[10].hide = True
	    group_input_002_9.outputs[11].hide = True
	    group_input_002_9.outputs[12].hide = True
	
	    #node Group Input.004
	    group_input_004_9 = stylized_eyebrow.nodes.new("NodeGroupInput")
	    group_input_004_9.name = "Group Input.004"
	    group_input_004_9.outputs[0].hide = True
	    group_input_004_9.outputs[1].hide = True
	    group_input_004_9.outputs[2].hide = True
	    group_input_004_9.outputs[3].hide = True
	    group_input_004_9.outputs[4].hide = True
	    group_input_004_9.outputs[5].hide = True
	    group_input_004_9.outputs[7].hide = True
	    group_input_004_9.outputs[8].hide = True
	    group_input_004_9.outputs[9].hide = True
	    group_input_004_9.outputs[10].hide = True
	    group_input_004_9.outputs[11].hide = True
	    group_input_004_9.outputs[12].hide = True
	
	    #node Group Input.003
	    group_input_003_10 = stylized_eyebrow.nodes.new("NodeGroupInput")
	    group_input_003_10.name = "Group Input.003"
	    group_input_003_10.outputs[0].hide = True
	    group_input_003_10.outputs[1].hide = True
	    group_input_003_10.outputs[2].hide = True
	    group_input_003_10.outputs[5].hide = True
	    group_input_003_10.outputs[6].hide = True
	    group_input_003_10.outputs[7].hide = True
	    group_input_003_10.outputs[8].hide = True
	    group_input_003_10.outputs[9].hide = True
	    group_input_003_10.outputs[10].hide = True
	    group_input_003_10.outputs[11].hide = True
	    group_input_003_10.outputs[12].hide = True
	
	    #node Capture Attribute
	    capture_attribute_8 = stylized_eyebrow.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_8.name = "Capture Attribute"
	    capture_attribute_8.hide = True
	    capture_attribute_8.active_index = 0
	    capture_attribute_8.capture_items.clear()
	    capture_attribute_8.capture_items.new('FLOAT', "Factor")
	    capture_attribute_8.capture_items["Factor"].data_type = 'FLOAT'
	    capture_attribute_8.domain = 'POINT'
	    capture_attribute_8.inputs[2].hide = True
	    capture_attribute_8.outputs[2].hide = True
	
	    #node Spline Parameter
	    spline_parameter_7 = stylized_eyebrow.nodes.new("GeometryNodeSplineParameter")
	    spline_parameter_7.name = "Spline Parameter"
	    spline_parameter_7.outputs[1].hide = True
	    spline_parameter_7.outputs[2].hide = True
	
	    #node Capture Attribute.001
	    capture_attribute_001_4 = stylized_eyebrow.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_001_4.name = "Capture Attribute.001"
	    capture_attribute_001_4.hide = True
	    capture_attribute_001_4.active_index = 0
	    capture_attribute_001_4.capture_items.clear()
	    capture_attribute_001_4.capture_items.new('FLOAT', "Factor")
	    capture_attribute_001_4.capture_items["Factor"].data_type = 'FLOAT'
	    capture_attribute_001_4.domain = 'POINT'
	    capture_attribute_001_4.inputs[2].hide = True
	    capture_attribute_001_4.outputs[2].hide = True
	
	    #node Store Named Attribute
	    store_named_attribute_8 = stylized_eyebrow.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_8.name = "Store Named Attribute"
	    store_named_attribute_8.data_type = 'FLOAT2'
	    store_named_attribute_8.domain = 'CORNER'
	    #Selection
	    store_named_attribute_8.inputs[1].default_value = True
	    #Name
	    store_named_attribute_8.inputs[2].default_value = "UVMap"
	
	    #node Combine XYZ
	    combine_xyz_6 = stylized_eyebrow.nodes.new("ShaderNodeCombineXYZ")
	    combine_xyz_6.name = "Combine XYZ"
	    combine_xyz_6.hide = True
	    combine_xyz_6.inputs[2].hide = True
	    #Z
	    combine_xyz_6.inputs[2].default_value = 0.0
	
	    #node Group Input.005
	    group_input_005_7 = stylized_eyebrow.nodes.new("NodeGroupInput")
	    group_input_005_7.name = "Group Input.005"
	    group_input_005_7.outputs[0].hide = True
	    group_input_005_7.outputs[1].hide = True
	    group_input_005_7.outputs[2].hide = True
	    group_input_005_7.outputs[3].hide = True
	    group_input_005_7.outputs[4].hide = True
	    group_input_005_7.outputs[5].hide = True
	    group_input_005_7.outputs[6].hide = True
	    group_input_005_7.outputs[11].hide = True
	    group_input_005_7.outputs[12].hide = True
	
	    #node Group Input.006
	    group_input_006_5 = stylized_eyebrow.nodes.new("NodeGroupInput")
	    group_input_006_5.name = "Group Input.006"
	    group_input_006_5.outputs[0].hide = True
	    group_input_006_5.outputs[1].hide = True
	    group_input_006_5.outputs[2].hide = True
	    group_input_006_5.outputs[3].hide = True
	    group_input_006_5.outputs[4].hide = True
	    group_input_006_5.outputs[5].hide = True
	    group_input_006_5.outputs[6].hide = True
	    group_input_006_5.outputs[7].hide = True
	    group_input_006_5.outputs[8].hide = True
	    group_input_006_5.outputs[9].hide = True
	    group_input_006_5.outputs[10].hide = True
	    group_input_006_5.outputs[12].hide = True
	
	
	
	
	
	    #Set locations
	    group_output_14.location = (719.9576416015625, -117.9132080078125)
	    group_input_10.location = (-913.463134765625, 0.0)
	    curve_to_mesh_4.location = (-17.064910888671875, -146.429443359375)
	    curve_circle_1.location = (-383.4480285644531, -219.8371124267578)
	    set_position_4.location = (526.772216796875, -94.09420776367188)
	    geometry_proximity_001.location = (357.42791748046875, -268.0325927734375)
	    curve_to_mesh_001.location = (357.397216796875, -319.9130859375)
	    resample_curve_001.location = (-382.3069152832031, -77.90435791015625)
	    subdivision_surface.location = (343.462646484375, -88.07131958007812)
	    merge_by_distance_1.location = (531.6414184570312, -145.85255432128906)
	    curve_to_points_001_1.location = (-741.1807250976562, -31.14517593383789)
	    sample_curve_1.location = (-738.7161254882812, -133.2061309814453)
	    points_1.location = (-568.5728759765625, -83.1309585571289)
	    vector_math_6.location = (-566.93310546875, -121.93599700927734)
	    vector_math_003_4.location = (-567.9382934570312, -159.82394409179688)
	    points_to_curves_1.location = (-386.7469482421875, -28.581192016601562)
	    join_geometry_003.location = (-569.779296875, -31.08361053466797)
	    group_input_001_10.location = (359.28875732421875, -352.05511474609375)
	    group_input_002_9.location = (-910.0960083007812, -121.28217315673828)
	    group_input_004_9.location = (-384.83343505859375, -111.17535400390625)
	    group_input_003_10.location = (-566.6551513671875, -190.3456268310547)
	    capture_attribute_8.location = (-201.99998474121094, -84.22369384765625)
	    spline_parameter_7.location = (-383.00384521484375, -266.1469421386719)
	    capture_attribute_001_4.location = (-201.99998474121094, -227.40402221679688)
	    store_named_attribute_8.location = (163.0, -47.16527557373047)
	    combine_xyz_6.location = (-12.893035888671875, -188.87484741210938)
	    group_input_005_7.location = (350.8710632324219, -122.96659851074219)
	    group_input_006_5.location = (534.3763427734375, -178.55426025390625)
	
	    #Set dimensions
	    group_output_14.width, group_output_14.height = 140.0, 100.0
	    group_input_10.width, group_input_10.height = 140.0, 100.0
	    curve_to_mesh_4.width, curve_to_mesh_4.height = 140.0, 100.0
	    curve_circle_1.width, curve_circle_1.height = 140.0, 100.0
	    set_position_4.width, set_position_4.height = 140.0, 100.0
	    geometry_proximity_001.width, geometry_proximity_001.height = 140.0, 100.0
	    curve_to_mesh_001.width, curve_to_mesh_001.height = 140.0, 100.0
	    resample_curve_001.width, resample_curve_001.height = 140.0, 100.0
	    subdivision_surface.width, subdivision_surface.height = 150.0, 100.0
	    merge_by_distance_1.width, merge_by_distance_1.height = 140.0, 100.0
	    curve_to_points_001_1.width, curve_to_points_001_1.height = 140.0, 100.0
	    sample_curve_1.width, sample_curve_1.height = 140.0, 100.0
	    points_1.width, points_1.height = 140.0, 100.0
	    vector_math_6.width, vector_math_6.height = 140.0, 100.0
	    vector_math_003_4.width, vector_math_003_4.height = 140.0, 100.0
	    points_to_curves_1.width, points_to_curves_1.height = 140.0, 100.0
	    join_geometry_003.width, join_geometry_003.height = 140.0, 100.0
	    group_input_001_10.width, group_input_001_10.height = 140.0, 100.0
	    group_input_002_9.width, group_input_002_9.height = 140.0, 100.0
	    group_input_004_9.width, group_input_004_9.height = 140.0, 100.0
	    group_input_003_10.width, group_input_003_10.height = 140.0, 100.0
	    capture_attribute_8.width, capture_attribute_8.height = 140.0, 100.0
	    spline_parameter_7.width, spline_parameter_7.height = 140.0, 100.0
	    capture_attribute_001_4.width, capture_attribute_001_4.height = 140.0, 100.0
	    store_named_attribute_8.width, store_named_attribute_8.height = 140.0, 100.0
	    combine_xyz_6.width, combine_xyz_6.height = 140.0, 100.0
	    group_input_005_7.width, group_input_005_7.height = 140.0, 100.0
	    group_input_006_5.width, group_input_006_5.height = 140.0, 100.0
	
	    #initialize stylized_eyebrow links
	    #curve_to_mesh_001.Mesh -> geometry_proximity_001.Geometry
	    stylized_eyebrow.links.new(curve_to_mesh_001.outputs[0], geometry_proximity_001.inputs[0])
	    #geometry_proximity_001.Position -> set_position_4.Position
	    stylized_eyebrow.links.new(geometry_proximity_001.outputs[0], set_position_4.inputs[2])
	    #points_1.Points -> join_geometry_003.Geometry
	    stylized_eyebrow.links.new(points_1.outputs[0], join_geometry_003.inputs[0])
	    #store_named_attribute_8.Geometry -> subdivision_surface.Mesh
	    stylized_eyebrow.links.new(store_named_attribute_8.outputs[0], subdivision_surface.inputs[0])
	    #capture_attribute_001_4.Geometry -> curve_to_mesh_4.Profile Curve
	    stylized_eyebrow.links.new(capture_attribute_001_4.outputs[0], curve_to_mesh_4.inputs[1])
	    #capture_attribute_8.Geometry -> curve_to_mesh_4.Curve
	    stylized_eyebrow.links.new(capture_attribute_8.outputs[0], curve_to_mesh_4.inputs[0])
	    #vector_math_6.Vector -> points_1.Position
	    stylized_eyebrow.links.new(vector_math_6.outputs[0], points_1.inputs[1])
	    #sample_curve_1.Position -> vector_math_6.Vector
	    stylized_eyebrow.links.new(sample_curve_1.outputs[1], vector_math_6.inputs[0])
	    #vector_math_003_4.Vector -> vector_math_6.Vector
	    stylized_eyebrow.links.new(vector_math_003_4.outputs[0], vector_math_6.inputs[1])
	    #points_to_curves_1.Curves -> resample_curve_001.Curve
	    stylized_eyebrow.links.new(points_to_curves_1.outputs[0], resample_curve_001.inputs[0])
	    #subdivision_surface.Mesh -> set_position_4.Geometry
	    stylized_eyebrow.links.new(subdivision_surface.outputs[0], set_position_4.inputs[0])
	    #join_geometry_003.Geometry -> points_to_curves_1.Points
	    stylized_eyebrow.links.new(join_geometry_003.outputs[0], points_to_curves_1.inputs[0])
	    #set_position_4.Geometry -> merge_by_distance_1.Geometry
	    stylized_eyebrow.links.new(set_position_4.outputs[0], merge_by_distance_1.inputs[0])
	    #sample_curve_1.Tangent -> vector_math_003_4.Vector
	    stylized_eyebrow.links.new(sample_curve_1.outputs[2], vector_math_003_4.inputs[0])
	    #group_input_10.Control Points -> curve_to_points_001_1.Count
	    stylized_eyebrow.links.new(group_input_10.outputs[2], curve_to_points_001_1.inputs[1])
	    #group_input_10.Geometry -> curve_to_points_001_1.Curve
	    stylized_eyebrow.links.new(group_input_10.outputs[0], curve_to_points_001_1.inputs[0])
	    #merge_by_distance_1.Geometry -> group_output_14.Geometry
	    stylized_eyebrow.links.new(merge_by_distance_1.outputs[0], group_output_14.inputs[0])
	    #group_input_001_10.Hair Curves -> curve_to_mesh_001.Curve
	    stylized_eyebrow.links.new(group_input_001_10.outputs[1], curve_to_mesh_001.inputs[0])
	    #group_input_002_9.Geometry -> sample_curve_1.Curves
	    stylized_eyebrow.links.new(group_input_002_9.outputs[0], sample_curve_1.inputs[0])
	    #group_input_002_9.Offset Factor -> vector_math_003_4.Scale
	    stylized_eyebrow.links.new(group_input_002_9.outputs[5], vector_math_003_4.inputs[3])
	    #group_input_003_10.Radius -> curve_circle_1.Radius
	    stylized_eyebrow.links.new(group_input_003_10.outputs[4], curve_circle_1.inputs[4])
	    #group_input_004_9.Resample Count -> resample_curve_001.Count
	    stylized_eyebrow.links.new(group_input_004_9.outputs[6], resample_curve_001.inputs[2])
	    #resample_curve_001.Curve -> capture_attribute_8.Geometry
	    stylized_eyebrow.links.new(resample_curve_001.outputs[0], capture_attribute_8.inputs[0])
	    #spline_parameter_7.Factor -> capture_attribute_8.Factor
	    stylized_eyebrow.links.new(spline_parameter_7.outputs[0], capture_attribute_8.inputs[1])
	    #curve_circle_1.Curve -> capture_attribute_001_4.Geometry
	    stylized_eyebrow.links.new(curve_circle_1.outputs[0], capture_attribute_001_4.inputs[0])
	    #spline_parameter_7.Factor -> capture_attribute_001_4.Factor
	    stylized_eyebrow.links.new(spline_parameter_7.outputs[0], capture_attribute_001_4.inputs[1])
	    #curve_to_mesh_4.Mesh -> store_named_attribute_8.Geometry
	    stylized_eyebrow.links.new(curve_to_mesh_4.outputs[0], store_named_attribute_8.inputs[0])
	    #combine_xyz_6.Vector -> store_named_attribute_8.Value
	    stylized_eyebrow.links.new(combine_xyz_6.outputs[0], store_named_attribute_8.inputs[3])
	    #capture_attribute_8.Factor -> combine_xyz_6.X
	    stylized_eyebrow.links.new(capture_attribute_8.outputs[1], combine_xyz_6.inputs[0])
	    #capture_attribute_001_4.Factor -> combine_xyz_6.Y
	    stylized_eyebrow.links.new(capture_attribute_001_4.outputs[1], combine_xyz_6.inputs[1])
	    #group_input_005_7.Level -> subdivision_surface.Level
	    stylized_eyebrow.links.new(group_input_005_7.outputs[7], subdivision_surface.inputs[1])
	    #group_input_005_7.Edge Crease -> subdivision_surface.Edge Crease
	    stylized_eyebrow.links.new(group_input_005_7.outputs[8], subdivision_surface.inputs[2])
	    #group_input_005_7.Vertex Crease -> subdivision_surface.Vertex Crease
	    stylized_eyebrow.links.new(group_input_005_7.outputs[9], subdivision_surface.inputs[3])
	    #group_input_005_7.Limit Surface -> subdivision_surface.Limit Surface
	    stylized_eyebrow.links.new(group_input_005_7.outputs[10], subdivision_surface.inputs[4])
	    #group_input_006_5.Distance -> merge_by_distance_1.Distance
	    stylized_eyebrow.links.new(group_input_006_5.outputs[11], merge_by_distance_1.inputs[2])
	    #group_input_003_10.Resolution -> curve_circle_1.Resolution
	    stylized_eyebrow.links.new(group_input_003_10.outputs[3], curve_circle_1.inputs[0])
	    #curve_to_points_001_1.Points -> join_geometry_003.Geometry
	    stylized_eyebrow.links.new(curve_to_points_001_1.outputs[0], join_geometry_003.inputs[0])
	    return stylized_eyebrow
	
	stylized_eyebrow = stylized_eyebrow_node_group()
	
	#initialize eyebrowz node group
	def eyebrowz_node_group():
	    eyebrowz = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "EYEBROWZ")
	
	    eyebrowz.color_tag = 'NONE'
	    eyebrowz.description = "Create eyebrow from curve drawn on Surface mesh."
	    eyebrowz.default_group_node_width = 140
	    
	
	    eyebrowz.is_modifier = True
	
	    #eyebrowz interface
	    #Socket Geometry
	    geometry_socket_20 = eyebrowz.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_20.attribute_domain = 'POINT'
	    geometry_socket_20.description = "Eyebrow."
	
	    #Socket Geometry
	    geometry_socket_21 = eyebrowz.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_21.attribute_domain = 'POINT'
	    geometry_socket_21.description = "Curve drawn on Surface mesh."
	
	    #Socket Surface
	    surface_socket_2 = eyebrowz.interface.new_socket(name = "Surface", in_out='INPUT', socket_type = 'NodeSocketObject')
	    surface_socket_2.attribute_domain = 'POINT'
	    surface_socket_2.description = "Surface Object to attach to (needs to have matching transforms)"
	
	    #Socket Hair Style
	    hair_style_socket = eyebrowz.interface.new_socket(name = "Hair Style", in_out='INPUT', socket_type = 'NodeSocketMenu')
	    hair_style_socket.attribute_domain = 'POINT'
	    hair_style_socket.description = "Style of hair to use."
	
	    #Socket Count
	    count_socket = eyebrowz.interface.new_socket(name = "Count", in_out='INPUT', socket_type = 'NodeSocketInt')
	    count_socket.default_value = 10
	    count_socket.min_value = 0
	    count_socket.max_value = 100000
	    count_socket.subtype = 'NONE'
	    count_socket.attribute_domain = 'POINT'
	    count_socket.description = "Number of splines in curve."
	
	    #Socket ControlPoints
	    controlpoints_socket = eyebrowz.interface.new_socket(name = "ControlPoints", in_out='INPUT', socket_type = 'NodeSocketInt')
	    controlpoints_socket.default_value = 10
	    controlpoints_socket.min_value = 2
	    controlpoints_socket.max_value = 100000
	    controlpoints_socket.subtype = 'NONE'
	    controlpoints_socket.attribute_domain = 'POINT'
	    controlpoints_socket.description = "Amount of points for each spline."
	
	    #Socket Length
	    length_socket_1 = eyebrowz.interface.new_socket(name = "Length", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    length_socket_1.default_value = 0.20000004768371582
	    length_socket_1.min_value = -3.4028234663852886e+38
	    length_socket_1.max_value = 3.4028234663852886e+38
	    length_socket_1.subtype = 'DISTANCE'
	    length_socket_1.attribute_domain = 'POINT'
	    length_socket_1.description = "Length of each spline."
	
	    #Socket Strand Radius
	    strand_radius_socket = eyebrowz.interface.new_socket(name = "Strand Radius", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    strand_radius_socket.default_value = 0.0010000000474974513
	    strand_radius_socket.min_value = 0.0
	    strand_radius_socket.max_value = 3.4028234663852886e+38
	    strand_radius_socket.subtype = 'DISTANCE'
	    strand_radius_socket.attribute_domain = 'POINT'
	    strand_radius_socket.description = "Hair strand radius."
	
	    #Socket Tangent Offset Angle
	    tangent_offset_angle_socket = eyebrowz.interface.new_socket(name = "Tangent Offset Angle", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    tangent_offset_angle_socket.default_value = 0.0
	    tangent_offset_angle_socket.min_value = -3.4028234663852886e+38
	    tangent_offset_angle_socket.max_value = 3.4028234663852886e+38
	    tangent_offset_angle_socket.subtype = 'ANGLE'
	    tangent_offset_angle_socket.attribute_domain = 'POINT'
	    tangent_offset_angle_socket.description = "Angle to offset curve direction along tangent."
	
	    #Socket Surface Snap Threshold
	    surface_snap_threshold_socket = eyebrowz.interface.new_socket(name = "Surface Snap Threshold", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    surface_snap_threshold_socket.default_value = 0.20000000298023224
	    surface_snap_threshold_socket.min_value = 0.0
	    surface_snap_threshold_socket.max_value = 10000.0
	    surface_snap_threshold_socket.subtype = 'NONE'
	    surface_snap_threshold_socket.attribute_domain = 'POINT'
	    surface_snap_threshold_socket.description = "Maximum distance to consider snapping point to face of Surface mesh."
	
	    #Socket Surface Offset
	    surface_offset_socket = eyebrowz.interface.new_socket(name = "Surface Offset", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    surface_offset_socket.default_value = 0.10000000149011612
	    surface_offset_socket.min_value = 0.0
	    surface_offset_socket.max_value = 10000.0
	    surface_offset_socket.subtype = 'NONE'
	    surface_offset_socket.attribute_domain = 'POINT'
	    surface_offset_socket.description = "Max distance to offset curve from Surface mesh."
	
	    #Socket Strand Roulette
	    strand_roulette_socket = eyebrowz.interface.new_socket(name = "Strand Roulette", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    strand_roulette_socket.default_value = 0.0
	    strand_roulette_socket.min_value = -3.4028234663852886e+38
	    strand_roulette_socket.max_value = 3.4028234663852886e+38
	    strand_roulette_socket.subtype = 'ANGLE'
	    strand_roulette_socket.attribute_domain = 'POINT'
	    strand_roulette_socket.description = "Angle to shift strands around guide curve."
	
	    #Socket UV Map
	    uv_map_socket = eyebrowz.interface.new_socket(name = "UV Map", in_out='INPUT', socket_type = 'NodeSocketString')
	    uv_map_socket.default_value = "UVMap"
	    uv_map_socket.subtype = 'NONE'
	    uv_map_socket.attribute_domain = 'POINT'
	    uv_map_socket.description = "Surface UV Map."
	
	    #Socket Mirror X
	    mirror_x_socket = eyebrowz.interface.new_socket(name = "Mirror X", in_out='INPUT', socket_type = 'NodeSocketBool')
	    mirror_x_socket.default_value = False
	    mirror_x_socket.attribute_domain = 'POINT'
	    mirror_x_socket.description = "Mirror Eyebrow across X axis."
	
	    #Socket Material
	    material_socket_5 = eyebrowz.interface.new_socket(name = "Material", in_out='INPUT', socket_type = 'NodeSocketMaterial')
	    material_socket_5.attribute_domain = 'POINT'
	    material_socket_5.description = "Curve Material."
	
	    #Panel Children Settings
	    children_settings_panel = eyebrowz.interface.new_panel("Children Settings", default_closed=True)
	    children_settings_panel.description = "Settings for duplicate hairs."
	    #Socket Amount
	    amount_socket_1 = eyebrowz.interface.new_socket(name = "Amount", in_out='INPUT', socket_type = 'NodeSocketInt', parent = children_settings_panel)
	    amount_socket_1.default_value = 10
	    amount_socket_1.min_value = 0
	    amount_socket_1.max_value = 2147483647
	    amount_socket_1.subtype = 'NONE'
	    amount_socket_1.attribute_domain = 'POINT'
	    amount_socket_1.description = "Amount of duplicates per curve"
	
	    #Socket Radius
	    radius_socket_2 = eyebrowz.interface.new_socket(name = "Radius", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = children_settings_panel)
	    radius_socket_2.default_value = 0.05000000074505806
	    radius_socket_2.min_value = 0.0
	    radius_socket_2.max_value = 3.4028234663852886e+38
	    radius_socket_2.subtype = 'DISTANCE'
	    radius_socket_2.attribute_domain = 'POINT'
	    radius_socket_2.description = "Radius in which the duplicate curves are offset from the guides"
	
	    #Socket Viewport Amount
	    viewport_amount_socket_1 = eyebrowz.interface.new_socket(name = "Viewport Amount", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = children_settings_panel)
	    viewport_amount_socket_1.default_value = 1.0
	    viewport_amount_socket_1.min_value = 0.0
	    viewport_amount_socket_1.max_value = 1.0
	    viewport_amount_socket_1.subtype = 'FACTOR'
	    viewport_amount_socket_1.attribute_domain = 'POINT'
	    viewport_amount_socket_1.description = "Percentage of amount used for the viewport"
	
	    #Socket Distribution Shape
	    distribution_shape_socket_1 = eyebrowz.interface.new_socket(name = "Distribution Shape", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = children_settings_panel)
	    distribution_shape_socket_1.default_value = -0.19999998807907104
	    distribution_shape_socket_1.min_value = -10.0
	    distribution_shape_socket_1.max_value = 10.0
	    distribution_shape_socket_1.subtype = 'NONE'
	    distribution_shape_socket_1.attribute_domain = 'POINT'
	    distribution_shape_socket_1.description = "Shape of distribution from center to the edge around the guide"
	
	    #Socket Tip Roundness
	    tip_roundness_socket_1 = eyebrowz.interface.new_socket(name = "Tip Roundness", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = children_settings_panel)
	    tip_roundness_socket_1.default_value = 0.0
	    tip_roundness_socket_1.min_value = 0.0
	    tip_roundness_socket_1.max_value = 1.0
	    tip_roundness_socket_1.subtype = 'FACTOR'
	    tip_roundness_socket_1.attribute_domain = 'POINT'
	    tip_roundness_socket_1.description = "Offset of the curves to round the tip"
	
	    #Socket Seed
	    seed_socket_2 = eyebrowz.interface.new_socket(name = "Seed", in_out='INPUT', socket_type = 'NodeSocketInt', parent = children_settings_panel)
	    seed_socket_2.default_value = 0
	    seed_socket_2.min_value = -10000
	    seed_socket_2.max_value = 10000
	    seed_socket_2.subtype = 'NONE'
	    seed_socket_2.attribute_domain = 'POINT'
	    seed_socket_2.description = "Random Seed for the operation"
	
	
	    #Panel Clump Settings
	    clump_settings_panel = eyebrowz.interface.new_panel("Clump Settings", default_closed=True)
	    clump_settings_panel.description = "Settings for hair clumping."
	    #Socket Use Clump
	    use_clump_socket = eyebrowz.interface.new_socket(name = "Use Clump", in_out='INPUT', socket_type = 'NodeSocketBool', parent = clump_settings_panel)
	    use_clump_socket.default_value = True
	    use_clump_socket.attribute_domain = 'POINT'
	    use_clump_socket.description = "Use hair clumping."
	
	    #Socket Tip Spread
	    tip_spread_socket_1 = eyebrowz.interface.new_socket(name = "Tip Spread", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = clump_settings_panel)
	    tip_spread_socket_1.default_value = 0.0
	    tip_spread_socket_1.min_value = -10000.0
	    tip_spread_socket_1.max_value = 10000.0
	    tip_spread_socket_1.subtype = 'NONE'
	    tip_spread_socket_1.attribute_domain = 'POINT'
	    tip_spread_socket_1.description = "Distance between hair tips."
	
	    #Socket Clump Offset
	    clump_offset_socket_1 = eyebrowz.interface.new_socket(name = "Clump Offset", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = clump_settings_panel)
	    clump_offset_socket_1.default_value = 0.0
	    clump_offset_socket_1.min_value = -3.4028234663852886e+38
	    clump_offset_socket_1.max_value = 3.4028234663852886e+38
	    clump_offset_socket_1.subtype = 'DISTANCE'
	    clump_offset_socket_1.attribute_domain = 'POINT'
	    clump_offset_socket_1.description = "Offset of each clump in a random direction"
	
	    #Socket Seed
	    seed_socket_3 = eyebrowz.interface.new_socket(name = "Seed", in_out='INPUT', socket_type = 'NodeSocketInt', parent = clump_settings_panel)
	    seed_socket_3.default_value = 0
	    seed_socket_3.min_value = -10000
	    seed_socket_3.max_value = 10000
	    seed_socket_3.subtype = 'NONE'
	    seed_socket_3.attribute_domain = 'POINT'
	    seed_socket_3.description = "Random seed for the operation"
	
	
	    #Panel Mesh Settings
	    mesh_settings_panel = eyebrowz.interface.new_panel("Mesh Settings", default_closed=True)
	    mesh_settings_panel.description = "Settings for mesh eyebrow."
	    #Socket Mesh Material
	    mesh_material_socket = eyebrowz.interface.new_socket(name = "Mesh Material", in_out='INPUT', socket_type = 'NodeSocketMaterial', parent = mesh_settings_panel)
	    mesh_material_socket.attribute_domain = 'POINT'
	    mesh_material_socket.description = "Material used for mesh."
	
	    #Socket Mesh Tilt
	    mesh_tilt_socket = eyebrowz.interface.new_socket(name = "Mesh Tilt", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = mesh_settings_panel)
	    mesh_tilt_socket.default_value = 0.0
	    mesh_tilt_socket.min_value = -3.4028234663852886e+38
	    mesh_tilt_socket.max_value = 3.4028234663852886e+38
	    mesh_tilt_socket.subtype = 'ANGLE'
	    mesh_tilt_socket.attribute_domain = 'POINT'
	    mesh_tilt_socket.description = "Rotate mesh at centers."
	
	    #Panel Mesh Hair | Mesh Strip Settings
	    mesh_hair___mesh_strip_settings_panel = eyebrowz.interface.new_panel("Mesh Hair | Mesh Strip Settings", default_closed=True)
	    mesh_hair___mesh_strip_settings_panel.description = "Settings for mesh eyebrow."
	    #Socket Resolution
	    resolution_socket_6 = eyebrowz.interface.new_socket(name = "Resolution", in_out='INPUT', socket_type = 'NodeSocketInt', parent = mesh_hair___mesh_strip_settings_panel)
	    resolution_socket_6.default_value = 0
	    resolution_socket_6.min_value = 2
	    resolution_socket_6.max_value = 512
	    resolution_socket_6.subtype = 'NONE'
	    resolution_socket_6.attribute_domain = 'POINT'
	    resolution_socket_6.description = "Control mesh smoothness by add and removing points along curve."
	
	    #Socket Width
	    width_socket_4 = eyebrowz.interface.new_socket(name = "Width", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = mesh_hair___mesh_strip_settings_panel)
	    width_socket_4.default_value = 0.10000000149011612
	    width_socket_4.min_value = 0.0
	    width_socket_4.max_value = 3.4028234663852886e+38
	    width_socket_4.subtype = 'DISTANCE'
	    width_socket_4.attribute_domain = 'POINT'
	    width_socket_4.description = "Width of mesh object."
	
	    #Socket Shade Smooth
	    shade_smooth_socket_1 = eyebrowz.interface.new_socket(name = "Shade Smooth", in_out='INPUT', socket_type = 'NodeSocketBool', parent = mesh_hair___mesh_strip_settings_panel)
	    shade_smooth_socket_1.default_value = False
	    shade_smooth_socket_1.attribute_domain = 'POINT'
	    shade_smooth_socket_1.description = "Use Smooth Shade for mesh."
	
	    #Socket Hair Card Angle
	    hair_card_angle_socket_1 = eyebrowz.interface.new_socket(name = "Hair Card Angle", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = mesh_hair___mesh_strip_settings_panel)
	    hair_card_angle_socket_1.default_value = 0.0
	    hair_card_angle_socket_1.min_value = -90.0
	    hair_card_angle_socket_1.max_value = 90.0
	    hair_card_angle_socket_1.subtype = 'ANGLE'
	    hair_card_angle_socket_1.attribute_domain = 'POINT'
	    hair_card_angle_socket_1.description = "Angle used to bend hair card. (Mesh Style=Hair Card)"
	
	    #Socket Fill Caps
	    fill_caps_socket_3 = eyebrowz.interface.new_socket(name = "Fill Caps", in_out='INPUT', socket_type = 'NodeSocketBool', parent = mesh_hair___mesh_strip_settings_panel)
	    fill_caps_socket_3.default_value = False
	    fill_caps_socket_3.attribute_domain = 'POINT'
	    fill_caps_socket_3.description = "Fill openings with mesh surface. (Used only for [Tube Mesh | Stylized] mesh styles)"
	
	    #Panel Mesh Hair Settings
	    mesh_hair_settings_panel = eyebrowz.interface.new_panel("Mesh Hair Settings")
	    mesh_hair_settings_panel.description = "Full Settings for mesh hair. (Hair Style=Mesh Hair)"
	    #Socket Tube Ribbon Count
	    tube_ribbon_count_socket_1 = eyebrowz.interface.new_socket(name = "Tube Ribbon Count", in_out='INPUT', socket_type = 'NodeSocketInt', parent = mesh_hair_settings_panel)
	    tube_ribbon_count_socket_1.default_value = 8
	    tube_ribbon_count_socket_1.min_value = 1
	    tube_ribbon_count_socket_1.max_value = 180
	    tube_ribbon_count_socket_1.subtype = 'NONE'
	    tube_ribbon_count_socket_1.attribute_domain = 'POINT'
	    tube_ribbon_count_socket_1.description = "Amount of billboard like hair cards used to shape hair. (Mesh Style=Tube Ribbon)"
	
	    #Socket Profile Curve
	    profile_curve_socket_1 = eyebrowz.interface.new_socket(name = "Profile Curve", in_out='INPUT', socket_type = 'NodeSocketObject', parent = mesh_hair_settings_panel)
	    profile_curve_socket_1.attribute_domain = 'POINT'
	    profile_curve_socket_1.description = "Curve object used as the profile for stylized hair. (Mesh Style=Stylized)"
	
	    #Socket Profile Translation
	    profile_translation_socket_1 = eyebrowz.interface.new_socket(name = "Profile Translation", in_out='INPUT', socket_type = 'NodeSocketVector', parent = mesh_hair_settings_panel)
	    profile_translation_socket_1.default_value = (0.0, 0.0, 0.0)
	    profile_translation_socket_1.min_value = -3.4028234663852886e+38
	    profile_translation_socket_1.max_value = 3.4028234663852886e+38
	    profile_translation_socket_1.subtype = 'TRANSLATION'
	    profile_translation_socket_1.attribute_domain = 'POINT'
	    profile_translation_socket_1.description = "Move position of stylized profile from origin. (Mesh Style=Stylized)"
	
	    #Socket Profile Rotation
	    profile_rotation_socket_1 = eyebrowz.interface.new_socket(name = "Profile Rotation", in_out='INPUT', socket_type = 'NodeSocketRotation', parent = mesh_hair_settings_panel)
	    profile_rotation_socket_1.default_value = (0.0, 0.0, 0.0)
	    profile_rotation_socket_1.attribute_domain = 'POINT'
	    profile_rotation_socket_1.description = "Rotate the stylized profile from origin. (Mesh Style=Stylized)"
	
	    #Socket Profile Scale
	    profile_scale_socket_1 = eyebrowz.interface.new_socket(name = "Profile Scale", in_out='INPUT', socket_type = 'NodeSocketVector', parent = mesh_hair_settings_panel)
	    profile_scale_socket_1.default_value = (1.0, 1.0, 1.0)
	    profile_scale_socket_1.min_value = -3.4028234663852886e+38
	    profile_scale_socket_1.max_value = 3.4028234663852886e+38
	    profile_scale_socket_1.subtype = 'XYZ'
	    profile_scale_socket_1.attribute_domain = 'POINT'
	    profile_scale_socket_1.description = "Scale the stylized profile from origin. (Mesh Style=Stylized)"
	
	
	    eyebrowz.interface.move_to_parent(mesh_hair_settings_panel, mesh_hair___mesh_strip_settings_panel, 36)
	
	    eyebrowz.interface.move_to_parent(mesh_hair___mesh_strip_settings_panel, mesh_settings_panel, 30)
	    #Panel Stylized
	    stylized_panel = eyebrowz.interface.new_panel("Stylized", default_closed=True)
	    stylized_panel.description = "Stylized eyebrow mesh."
	    #Socket Resolution
	    resolution_socket_7 = eyebrowz.interface.new_socket(name = "Resolution", in_out='INPUT', socket_type = 'NodeSocketInt', parent = stylized_panel)
	    resolution_socket_7.default_value = 8
	    resolution_socket_7.min_value = 3
	    resolution_socket_7.max_value = 512
	    resolution_socket_7.subtype = 'NONE'
	    resolution_socket_7.attribute_domain = 'POINT'
	    resolution_socket_7.description = "Control mesh smoothness by add and removing points along curve."
	
	    #Socket Offset Factor
	    offset_factor_socket_1 = eyebrowz.interface.new_socket(name = "Offset Factor", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = stylized_panel)
	    offset_factor_socket_1.default_value = 0.09999990463256836
	    offset_factor_socket_1.min_value = 0.0
	    offset_factor_socket_1.max_value = 1.0
	    offset_factor_socket_1.subtype = 'FACTOR'
	    offset_factor_socket_1.attribute_domain = 'POINT'
	    offset_factor_socket_1.description = "Tip extension offset factor."
	
	    #Socket Resample Count
	    resample_count_socket_1 = eyebrowz.interface.new_socket(name = "Resample Count", in_out='INPUT', socket_type = 'NodeSocketInt', parent = stylized_panel)
	    resample_count_socket_1.default_value = 10
	    resample_count_socket_1.min_value = 1
	    resample_count_socket_1.max_value = 100000
	    resample_count_socket_1.subtype = 'NONE'
	    resample_count_socket_1.attribute_domain = 'POINT'
	    resample_count_socket_1.description = "Amount of control points to resample."
	
	    #Socket Level
	    level_socket_1 = eyebrowz.interface.new_socket(name = "Level", in_out='INPUT', socket_type = 'NodeSocketInt', parent = stylized_panel)
	    level_socket_1.default_value = 1
	    level_socket_1.min_value = 0
	    level_socket_1.max_value = 6
	    level_socket_1.subtype = 'NONE'
	    level_socket_1.attribute_domain = 'POINT'
	    level_socket_1.description = "Subdivision level."
	
	    #Socket Edge Crease
	    edge_crease_socket_1 = eyebrowz.interface.new_socket(name = "Edge Crease", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = stylized_panel)
	    edge_crease_socket_1.default_value = 0.0
	    edge_crease_socket_1.min_value = 0.0
	    edge_crease_socket_1.max_value = 1.0
	    edge_crease_socket_1.subtype = 'FACTOR'
	    edge_crease_socket_1.attribute_domain = 'POINT'
	    edge_crease_socket_1.description = "Edge crease for subdivision."
	
	    #Socket Vertex Crease
	    vertex_crease_socket_1 = eyebrowz.interface.new_socket(name = "Vertex Crease", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = stylized_panel)
	    vertex_crease_socket_1.default_value = 0.0
	    vertex_crease_socket_1.min_value = 0.0
	    vertex_crease_socket_1.max_value = 1.0
	    vertex_crease_socket_1.subtype = 'FACTOR'
	    vertex_crease_socket_1.attribute_domain = 'POINT'
	    vertex_crease_socket_1.description = "Vertex crease for subdivision."
	
	    #Socket Limit Surface
	    limit_surface_socket_1 = eyebrowz.interface.new_socket(name = "Limit Surface", in_out='INPUT', socket_type = 'NodeSocketBool', parent = stylized_panel)
	    limit_surface_socket_1.default_value = True
	    limit_surface_socket_1.attribute_domain = 'POINT'
	    limit_surface_socket_1.description = "Limit surface subdivision."
	
	    #Socket Distance
	    distance_socket_1 = eyebrowz.interface.new_socket(name = "Distance", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = stylized_panel)
	    distance_socket_1.default_value = 0.0010000000474974513
	    distance_socket_1.min_value = 0.0
	    distance_socket_1.max_value = 3.4028234663852886e+38
	    distance_socket_1.subtype = 'DISTANCE'
	    distance_socket_1.attribute_domain = 'POINT'
	    distance_socket_1.description = "Distance threshold to merge vertices."
	
	
	    eyebrowz.interface.move_to_parent(stylized_panel, mesh_settings_panel, 42)
	
	
	    #initialize eyebrowz nodes
	    #node Group Output
	    group_output_15 = eyebrowz.nodes.new("NodeGroupOutput")
	    group_output_15.name = "Group Output"
	    group_output_15.is_active_output = True
	
	    #node Group Input
	    group_input_11 = eyebrowz.nodes.new("NodeGroupInput")
	    group_input_11.name = "Group Input"
	    group_input_11.outputs[1].hide = True
	    group_input_11.outputs[2].hide = True
	    group_input_11.outputs[6].hide = True
	    group_input_11.outputs[8].hide = True
	    group_input_11.outputs[9].hide = True
	    group_input_11.outputs[10].hide = True
	    group_input_11.outputs[11].hide = True
	    group_input_11.outputs[12].hide = True
	    group_input_11.outputs[13].hide = True
	    group_input_11.outputs[14].hide = True
	    group_input_11.outputs[15].hide = True
	    group_input_11.outputs[16].hide = True
	    group_input_11.outputs[17].hide = True
	    group_input_11.outputs[18].hide = True
	    group_input_11.outputs[19].hide = True
	    group_input_11.outputs[20].hide = True
	    group_input_11.outputs[21].hide = True
	    group_input_11.outputs[22].hide = True
	    group_input_11.outputs[23].hide = True
	    group_input_11.outputs[24].hide = True
	    group_input_11.outputs[25].hide = True
	    group_input_11.outputs[26].hide = True
	    group_input_11.outputs[27].hide = True
	    group_input_11.outputs[28].hide = True
	    group_input_11.outputs[29].hide = True
	    group_input_11.outputs[30].hide = True
	    group_input_11.outputs[31].hide = True
	    group_input_11.outputs[32].hide = True
	    group_input_11.outputs[33].hide = True
	    group_input_11.outputs[34].hide = True
	    group_input_11.outputs[35].hide = True
	    group_input_11.outputs[36].hide = True
	    group_input_11.outputs[37].hide = True
	    group_input_11.outputs[38].hide = True
	    group_input_11.outputs[39].hide = True
	    group_input_11.outputs[40].hide = True
	    group_input_11.outputs[41].hide = True
	    group_input_11.outputs[42].hide = True
	    group_input_11.outputs[43].hide = True
	    group_input_11.outputs[44].hide = True
	
	    #node Curve to Points
	    curve_to_points_1 = eyebrowz.nodes.new("GeometryNodeCurveToPoints")
	    curve_to_points_1.name = "Curve to Points"
	    curve_to_points_1.hide = True
	    curve_to_points_1.mode = 'COUNT'
	
	    #node Instance on Points
	    instance_on_points = eyebrowz.nodes.new("GeometryNodeInstanceOnPoints")
	    instance_on_points.name = "Instance on Points"
	    instance_on_points.hide = True
	    instance_on_points.inputs[1].hide = True
	    instance_on_points.inputs[3].hide = True
	    instance_on_points.inputs[4].hide = True
	    instance_on_points.inputs[6].hide = True
	    #Selection
	    instance_on_points.inputs[1].default_value = True
	    #Pick Instance
	    instance_on_points.inputs[3].default_value = False
	    #Instance Index
	    instance_on_points.inputs[4].default_value = 0
	    #Scale
	    instance_on_points.inputs[6].default_value = (1.0, 1.0, 1.0)
	
	    #node Curve Line
	    curve_line_1 = eyebrowz.nodes.new("GeometryNodeCurvePrimitiveLine")
	    curve_line_1.name = "Curve Line"
	    curve_line_1.hide = True
	    curve_line_1.mode = 'DIRECTION'
	    curve_line_1.inputs[0].hide = True
	    curve_line_1.inputs[1].hide = True
	    #Start
	    curve_line_1.inputs[0].default_value = (0.0, 0.0, 0.0)
	
	    #node Resample Curve
	    resample_curve_4 = eyebrowz.nodes.new("GeometryNodeResampleCurve")
	    resample_curve_4.name = "Resample Curve"
	    resample_curve_4.hide = True
	    resample_curve_4.keep_last_segment = True
	    resample_curve_4.mode = 'COUNT'
	    resample_curve_4.inputs[1].hide = True
	    resample_curve_4.inputs[3].hide = True
	    #Selection
	    resample_curve_4.inputs[1].default_value = True
	
	    #node Realize Instances
	    realize_instances = eyebrowz.nodes.new("GeometryNodeRealizeInstances")
	    realize_instances.name = "Realize Instances"
	    realize_instances.hide = True
	    realize_instances.inputs[1].hide = True
	    realize_instances.inputs[2].hide = True
	    realize_instances.inputs[3].hide = True
	    #Selection
	    realize_instances.inputs[1].default_value = True
	    #Realize All
	    realize_instances.inputs[2].default_value = True
	    #Depth
	    realize_instances.inputs[3].default_value = 0
	
	    #node Group.004
	    group_004 = eyebrowz.nodes.new("GeometryNodeGroup")
	    group_004.name = "Group.004"
	    group_004.node_tree = duplicate_hair_curves
	    group_004.inputs[6].hide = True
	    group_004.outputs[1].hide = True
	    #Socket_8
	    group_004.inputs[6].default_value = False
	
	    #node Object Info
	    object_info_1 = eyebrowz.nodes.new("GeometryNodeObjectInfo")
	    object_info_1.name = "Object Info"
	    object_info_1.hide = True
	    object_info_1.transform_space = 'RELATIVE'
	    object_info_1.inputs[1].hide = True
	    object_info_1.outputs[0].hide = True
	    object_info_1.outputs[1].hide = True
	    object_info_1.outputs[2].hide = True
	    object_info_1.outputs[3].hide = True
	    #As Instance
	    object_info_1.inputs[1].default_value = False
	
	    #node Geometry Proximity
	    geometry_proximity = eyebrowz.nodes.new("GeometryNodeProximity")
	    geometry_proximity.name = "Geometry Proximity"
	    geometry_proximity.hide = True
	    geometry_proximity.target_element = 'FACES'
	    geometry_proximity.inputs[1].hide = True
	    geometry_proximity.inputs[2].hide = True
	    geometry_proximity.inputs[3].hide = True
	    geometry_proximity.outputs[2].hide = True
	    #Group ID
	    geometry_proximity.inputs[1].default_value = 0
	    #Source Position
	    geometry_proximity.inputs[2].default_value = (0.0, 0.0, 0.0)
	    #Sample Group ID
	    geometry_proximity.inputs[3].default_value = 0
	
	    #node Set Position.001
	    set_position_001_4 = eyebrowz.nodes.new("GeometryNodeSetPosition")
	    set_position_001_4.name = "Set Position.001"
	    set_position_001_4.hide = True
	    set_position_001_4.inputs[3].hide = True
	    #Offset
	    set_position_001_4.inputs[3].default_value = (0.0, 0.0, 0.0)
	
	    #node Endpoint Selection.001
	    endpoint_selection_001 = eyebrowz.nodes.new("GeometryNodeCurveEndpointSelection")
	    endpoint_selection_001.name = "Endpoint Selection.001"
	    endpoint_selection_001.hide = True
	    #Start Size
	    endpoint_selection_001.inputs[0].default_value = 1
	    #End Size
	    endpoint_selection_001.inputs[1].default_value = 0
	
	    #node Boolean Math.001
	    boolean_math_001_1 = eyebrowz.nodes.new("FunctionNodeBooleanMath")
	    boolean_math_001_1.name = "Boolean Math.001"
	    boolean_math_001_1.hide = True
	    boolean_math_001_1.operation = 'NOT'
	
	    #node Compare
	    compare_10 = eyebrowz.nodes.new("FunctionNodeCompare")
	    compare_10.name = "Compare"
	    compare_10.hide = True
	    compare_10.data_type = 'FLOAT'
	    compare_10.mode = 'ELEMENT'
	    compare_10.operation = 'LESS_THAN'
	
	    #node Set Position.002
	    set_position_002_2 = eyebrowz.nodes.new("GeometryNodeSetPosition")
	    set_position_002_2.name = "Set Position.002"
	    set_position_002_2.hide = True
	    set_position_002_2.inputs[2].hide = True
	    #Position
	    set_position_002_2.inputs[2].default_value = (0.0, 0.0, 0.0)
	
	    #node Sample Nearest
	    sample_nearest = eyebrowz.nodes.new("GeometryNodeSampleNearest")
	    sample_nearest.name = "Sample Nearest"
	    sample_nearest.hide = True
	    sample_nearest.domain = 'FACE'
	    #Sample Position
	    sample_nearest.inputs[1].default_value = (0.0, 0.0, 0.0)
	
	    #node Sample Index.003
	    sample_index_003_1 = eyebrowz.nodes.new("GeometryNodeSampleIndex")
	    sample_index_003_1.name = "Sample Index.003"
	    sample_index_003_1.hide = True
	    sample_index_003_1.clamp = False
	    sample_index_003_1.data_type = 'FLOAT_VECTOR'
	    sample_index_003_1.domain = 'FACE'
	
	    #node Normal
	    normal_2 = eyebrowz.nodes.new("GeometryNodeInputNormal")
	    normal_2.name = "Normal"
	    normal_2.legacy_corner_normals = False
	
	    #node Vector Math.005
	    vector_math_005_3 = eyebrowz.nodes.new("ShaderNodeVectorMath")
	    vector_math_005_3.name = "Vector Math.005"
	    vector_math_005_3.hide = True
	    vector_math_005_3.operation = 'SCALE'
	
	    #node Surface Offset Curve
	    surface_offset_curve = eyebrowz.nodes.new("ShaderNodeFloatCurve")
	    surface_offset_curve.label = "Surface Offset Curve"
	    surface_offset_curve.name = "Surface Offset Curve"
	    #mapping settings
	    surface_offset_curve.mapping.extend = 'EXTRAPOLATED'
	    surface_offset_curve.mapping.tone = 'STANDARD'
	    surface_offset_curve.mapping.black_level = (0.0, 0.0, 0.0)
	    surface_offset_curve.mapping.white_level = (1.0, 1.0, 1.0)
	    surface_offset_curve.mapping.clip_min_x = 0.0
	    surface_offset_curve.mapping.clip_min_y = 0.0
	    surface_offset_curve.mapping.clip_max_x = 1.0
	    surface_offset_curve.mapping.clip_max_y = 1.0
	    surface_offset_curve.mapping.use_clip = True
	    #curve 0
	    surface_offset_curve_curve_0 = surface_offset_curve.mapping.curves[0]
	    surface_offset_curve_curve_0_point_0 = surface_offset_curve_curve_0.points[0]
	    surface_offset_curve_curve_0_point_0.location = (0.0, 0.0)
	    surface_offset_curve_curve_0_point_0.handle_type = 'AUTO'
	    surface_offset_curve_curve_0_point_1 = surface_offset_curve_curve_0.points[1]
	    surface_offset_curve_curve_0_point_1.location = (0.2545454204082489, 0.12500005960464478)
	    surface_offset_curve_curve_0_point_1.handle_type = 'AUTO'
	    surface_offset_curve_curve_0_point_2 = surface_offset_curve_curve_0.points.new(1.0, 0.03124999813735485)
	    surface_offset_curve_curve_0_point_2.handle_type = 'AUTO'
	    #update curve after changes
	    surface_offset_curve.mapping.update()
	    #Factor
	    surface_offset_curve.inputs[0].default_value = 1.0
	
	    #node Spline Parameter
	    spline_parameter_8 = eyebrowz.nodes.new("GeometryNodeSplineParameter")
	    spline_parameter_8.name = "Spline Parameter"
	    spline_parameter_8.outputs[1].hide = True
	    spline_parameter_8.outputs[2].hide = True
	
	    #node Map Range
	    map_range_2 = eyebrowz.nodes.new("ShaderNodeMapRange")
	    map_range_2.name = "Map Range"
	    map_range_2.hide = True
	    map_range_2.clamp = True
	    map_range_2.data_type = 'FLOAT'
	    map_range_2.interpolation_type = 'LINEAR'
	    map_range_2.inputs[1].hide = True
	    map_range_2.inputs[2].hide = True
	    map_range_2.inputs[3].hide = True
	    map_range_2.inputs[5].hide = True
	    map_range_2.inputs[6].hide = True
	    map_range_2.inputs[7].hide = True
	    map_range_2.inputs[8].hide = True
	    map_range_2.inputs[9].hide = True
	    map_range_2.inputs[10].hide = True
	    map_range_2.inputs[11].hide = True
	    map_range_2.outputs[1].hide = True
	    #From Min
	    map_range_2.inputs[1].default_value = 0.0
	    #From Max
	    map_range_2.inputs[2].default_value = 1.0
	    #To Min
	    map_range_2.inputs[3].default_value = 0.0
	
	    #node Vector Rotate.001
	    vector_rotate_001 = eyebrowz.nodes.new("ShaderNodeVectorRotate")
	    vector_rotate_001.name = "Vector Rotate.001"
	    vector_rotate_001.hide = True
	    vector_rotate_001.invert = False
	    vector_rotate_001.rotation_type = 'AXIS_ANGLE'
	    vector_rotate_001.inputs[1].hide = True
	    vector_rotate_001.inputs[2].hide = True
	    vector_rotate_001.inputs[4].hide = True
	    #Center
	    vector_rotate_001.inputs[1].default_value = (0.0, 0.0, 0.0)
	    #Axis
	    vector_rotate_001.inputs[2].default_value = (1.0, 0.0, 0.0)
	
	    #node Vector
	    vector = eyebrowz.nodes.new("FunctionNodeInputVector")
	    vector.name = "Vector"
	    vector.hide = True
	    vector.vector = (0.0, 0.0, 1.0)
	
	    #node Group Input.001
	    group_input_001_11 = eyebrowz.nodes.new("NodeGroupInput")
	    group_input_001_11.name = "Group Input.001"
	    group_input_001_11.outputs[0].hide = True
	    group_input_001_11.outputs[2].hide = True
	    group_input_001_11.outputs[3].hide = True
	    group_input_001_11.outputs[4].hide = True
	    group_input_001_11.outputs[5].hide = True
	    group_input_001_11.outputs[6].hide = True
	    group_input_001_11.outputs[7].hide = True
	    group_input_001_11.outputs[8].hide = True
	    group_input_001_11.outputs[9].hide = True
	    group_input_001_11.outputs[10].hide = True
	    group_input_001_11.outputs[11].hide = True
	    group_input_001_11.outputs[12].hide = True
	    group_input_001_11.outputs[13].hide = True
	    group_input_001_11.outputs[14].hide = True
	    group_input_001_11.outputs[15].hide = True
	    group_input_001_11.outputs[16].hide = True
	    group_input_001_11.outputs[17].hide = True
	    group_input_001_11.outputs[18].hide = True
	    group_input_001_11.outputs[19].hide = True
	    group_input_001_11.outputs[20].hide = True
	    group_input_001_11.outputs[21].hide = True
	    group_input_001_11.outputs[22].hide = True
	    group_input_001_11.outputs[23].hide = True
	    group_input_001_11.outputs[24].hide = True
	    group_input_001_11.outputs[25].hide = True
	    group_input_001_11.outputs[26].hide = True
	    group_input_001_11.outputs[27].hide = True
	    group_input_001_11.outputs[28].hide = True
	    group_input_001_11.outputs[29].hide = True
	    group_input_001_11.outputs[30].hide = True
	    group_input_001_11.outputs[31].hide = True
	    group_input_001_11.outputs[32].hide = True
	    group_input_001_11.outputs[33].hide = True
	    group_input_001_11.outputs[34].hide = True
	    group_input_001_11.outputs[35].hide = True
	    group_input_001_11.outputs[36].hide = True
	    group_input_001_11.outputs[37].hide = True
	    group_input_001_11.outputs[38].hide = True
	    group_input_001_11.outputs[39].hide = True
	    group_input_001_11.outputs[40].hide = True
	    group_input_001_11.outputs[41].hide = True
	    group_input_001_11.outputs[42].hide = True
	    group_input_001_11.outputs[43].hide = True
	    group_input_001_11.outputs[44].hide = True
	
	    #node Group Input.002
	    group_input_002_10 = eyebrowz.nodes.new("NodeGroupInput")
	    group_input_002_10.name = "Group Input.002"
	    group_input_002_10.outputs[0].hide = True
	    group_input_002_10.outputs[1].hide = True
	    group_input_002_10.outputs[2].hide = True
	    group_input_002_10.outputs[3].hide = True
	    group_input_002_10.outputs[4].hide = True
	    group_input_002_10.outputs[5].hide = True
	    group_input_002_10.outputs[6].hide = True
	    group_input_002_10.outputs[7].hide = True
	    group_input_002_10.outputs[9].hide = True
	    group_input_002_10.outputs[10].hide = True
	    group_input_002_10.outputs[11].hide = True
	    group_input_002_10.outputs[12].hide = True
	    group_input_002_10.outputs[13].hide = True
	    group_input_002_10.outputs[14].hide = True
	    group_input_002_10.outputs[15].hide = True
	    group_input_002_10.outputs[16].hide = True
	    group_input_002_10.outputs[17].hide = True
	    group_input_002_10.outputs[18].hide = True
	    group_input_002_10.outputs[19].hide = True
	    group_input_002_10.outputs[20].hide = True
	    group_input_002_10.outputs[21].hide = True
	    group_input_002_10.outputs[22].hide = True
	    group_input_002_10.outputs[23].hide = True
	    group_input_002_10.outputs[24].hide = True
	    group_input_002_10.outputs[25].hide = True
	    group_input_002_10.outputs[26].hide = True
	    group_input_002_10.outputs[27].hide = True
	    group_input_002_10.outputs[28].hide = True
	    group_input_002_10.outputs[29].hide = True
	    group_input_002_10.outputs[30].hide = True
	    group_input_002_10.outputs[31].hide = True
	    group_input_002_10.outputs[32].hide = True
	    group_input_002_10.outputs[33].hide = True
	    group_input_002_10.outputs[34].hide = True
	    group_input_002_10.outputs[35].hide = True
	    group_input_002_10.outputs[36].hide = True
	    group_input_002_10.outputs[37].hide = True
	    group_input_002_10.outputs[38].hide = True
	    group_input_002_10.outputs[39].hide = True
	    group_input_002_10.outputs[40].hide = True
	    group_input_002_10.outputs[41].hide = True
	    group_input_002_10.outputs[42].hide = True
	    group_input_002_10.outputs[43].hide = True
	    group_input_002_10.outputs[44].hide = True
	
	    #node Group Input.003
	    group_input_003_11 = eyebrowz.nodes.new("NodeGroupInput")
	    group_input_003_11.name = "Group Input.003"
	    group_input_003_11.outputs[0].hide = True
	    group_input_003_11.outputs[1].hide = True
	    group_input_003_11.outputs[2].hide = True
	    group_input_003_11.outputs[3].hide = True
	    group_input_003_11.outputs[4].hide = True
	    group_input_003_11.outputs[5].hide = True
	    group_input_003_11.outputs[6].hide = True
	    group_input_003_11.outputs[7].hide = True
	    group_input_003_11.outputs[8].hide = True
	    group_input_003_11.outputs[10].hide = True
	    group_input_003_11.outputs[11].hide = True
	    group_input_003_11.outputs[12].hide = True
	    group_input_003_11.outputs[13].hide = True
	    group_input_003_11.outputs[14].hide = True
	    group_input_003_11.outputs[15].hide = True
	    group_input_003_11.outputs[16].hide = True
	    group_input_003_11.outputs[17].hide = True
	    group_input_003_11.outputs[18].hide = True
	    group_input_003_11.outputs[19].hide = True
	    group_input_003_11.outputs[20].hide = True
	    group_input_003_11.outputs[21].hide = True
	    group_input_003_11.outputs[22].hide = True
	    group_input_003_11.outputs[23].hide = True
	    group_input_003_11.outputs[24].hide = True
	    group_input_003_11.outputs[25].hide = True
	    group_input_003_11.outputs[26].hide = True
	    group_input_003_11.outputs[27].hide = True
	    group_input_003_11.outputs[28].hide = True
	    group_input_003_11.outputs[29].hide = True
	    group_input_003_11.outputs[30].hide = True
	    group_input_003_11.outputs[31].hide = True
	    group_input_003_11.outputs[32].hide = True
	    group_input_003_11.outputs[33].hide = True
	    group_input_003_11.outputs[34].hide = True
	    group_input_003_11.outputs[35].hide = True
	    group_input_003_11.outputs[36].hide = True
	    group_input_003_11.outputs[37].hide = True
	    group_input_003_11.outputs[38].hide = True
	    group_input_003_11.outputs[39].hide = True
	    group_input_003_11.outputs[40].hide = True
	    group_input_003_11.outputs[41].hide = True
	    group_input_003_11.outputs[42].hide = True
	    group_input_003_11.outputs[43].hide = True
	    group_input_003_11.outputs[44].hide = True
	
	    #node Group Input.004
	    group_input_004_10 = eyebrowz.nodes.new("NodeGroupInput")
	    group_input_004_10.name = "Group Input.004"
	    group_input_004_10.outputs[0].hide = True
	    group_input_004_10.outputs[1].hide = True
	    group_input_004_10.outputs[2].hide = True
	    group_input_004_10.outputs[3].hide = True
	    group_input_004_10.outputs[4].hide = True
	    group_input_004_10.outputs[5].hide = True
	    group_input_004_10.outputs[6].hide = True
	    group_input_004_10.outputs[7].hide = True
	    group_input_004_10.outputs[8].hide = True
	    group_input_004_10.outputs[9].hide = True
	    group_input_004_10.outputs[10].hide = True
	    group_input_004_10.outputs[11].hide = True
	    group_input_004_10.outputs[12].hide = True
	    group_input_004_10.outputs[13].hide = True
	    group_input_004_10.outputs[20].hide = True
	    group_input_004_10.outputs[21].hide = True
	    group_input_004_10.outputs[22].hide = True
	    group_input_004_10.outputs[23].hide = True
	    group_input_004_10.outputs[24].hide = True
	    group_input_004_10.outputs[25].hide = True
	    group_input_004_10.outputs[26].hide = True
	    group_input_004_10.outputs[27].hide = True
	    group_input_004_10.outputs[28].hide = True
	    group_input_004_10.outputs[29].hide = True
	    group_input_004_10.outputs[30].hide = True
	    group_input_004_10.outputs[31].hide = True
	    group_input_004_10.outputs[32].hide = True
	    group_input_004_10.outputs[33].hide = True
	    group_input_004_10.outputs[34].hide = True
	    group_input_004_10.outputs[35].hide = True
	    group_input_004_10.outputs[36].hide = True
	    group_input_004_10.outputs[37].hide = True
	    group_input_004_10.outputs[38].hide = True
	    group_input_004_10.outputs[39].hide = True
	    group_input_004_10.outputs[40].hide = True
	    group_input_004_10.outputs[41].hide = True
	    group_input_004_10.outputs[42].hide = True
	    group_input_004_10.outputs[43].hide = True
	    group_input_004_10.outputs[44].hide = True
	
	    #node Reroute
	    reroute_11 = eyebrowz.nodes.new("NodeReroute")
	    reroute_11.name = "Reroute"
	    reroute_11.socket_idname = "NodeSocketGeometry"
	    #node Reroute.001
	    reroute_001_10 = eyebrowz.nodes.new("NodeReroute")
	    reroute_001_10.name = "Reroute.001"
	    reroute_001_10.socket_idname = "NodeSocketGeometry"
	    #node Reroute.002
	    reroute_002_8 = eyebrowz.nodes.new("NodeReroute")
	    reroute_002_8.name = "Reroute.002"
	    reroute_002_8.socket_idname = "NodeSocketGeometry"
	    #node Separate Components
	    separate_components_3 = eyebrowz.nodes.new("GeometryNodeSeparateComponents")
	    separate_components_3.name = "Separate Components"
	    separate_components_3.hide = True
	
	    #node Trim Curve
	    trim_curve = eyebrowz.nodes.new("GeometryNodeTrimCurve")
	    trim_curve.name = "Trim Curve"
	    trim_curve.mode = 'FACTOR'
	    trim_curve.inputs[1].hide = True
	    trim_curve.inputs[2].hide = True
	    trim_curve.inputs[4].hide = True
	    trim_curve.inputs[5].hide = True
	    #Selection
	    trim_curve.inputs[1].default_value = True
	    #Start
	    trim_curve.inputs[2].default_value = 0.0
	
	    #node Reroute.004
	    reroute_004_8 = eyebrowz.nodes.new("NodeReroute")
	    reroute_004_8.name = "Reroute.004"
	    reroute_004_8.socket_idname = "NodeSocketGeometry"
	    #node Trim Factor
	    trim_factor = eyebrowz.nodes.new("ShaderNodeFloatCurve")
	    trim_factor.label = "Trim Factor"
	    trim_factor.name = "Trim Factor"
	    #mapping settings
	    trim_factor.mapping.extend = 'EXTRAPOLATED'
	    trim_factor.mapping.tone = 'STANDARD'
	    trim_factor.mapping.black_level = (0.0, 0.0, 0.0)
	    trim_factor.mapping.white_level = (1.0, 1.0, 1.0)
	    trim_factor.mapping.clip_min_x = 0.0
	    trim_factor.mapping.clip_min_y = 0.0
	    trim_factor.mapping.clip_max_x = 1.0
	    trim_factor.mapping.clip_max_y = 1.0
	    trim_factor.mapping.use_clip = True
	    #curve 0
	    trim_factor_curve_0 = trim_factor.mapping.curves[0]
	    trim_factor_curve_0_point_0 = trim_factor_curve_0.points[0]
	    trim_factor_curve_0_point_0.location = (0.0, 1.0)
	    trim_factor_curve_0_point_0.handle_type = 'AUTO'
	    trim_factor_curve_0_point_1 = trim_factor_curve_0.points[1]
	    trim_factor_curve_0_point_1.location = (0.5272727012634277, 0.8937500715255737)
	    trim_factor_curve_0_point_1.handle_type = 'AUTO'
	    trim_factor_curve_0_point_2 = trim_factor_curve_0.points.new(1.0, 0.600000262260437)
	    trim_factor_curve_0_point_2.handle_type = 'AUTO'
	    #update curve after changes
	    trim_factor.mapping.update()
	    trim_factor.inputs[0].hide = True
	    #Factor
	    trim_factor.inputs[0].default_value = 1.0
	
	    #node Spline Parameter.001
	    spline_parameter_001_1 = eyebrowz.nodes.new("GeometryNodeSplineParameter")
	    spline_parameter_001_1.name = "Spline Parameter.001"
	    spline_parameter_001_1.outputs[1].hide = True
	    spline_parameter_001_1.outputs[2].hide = True
	
	    #node Group
	    group_6 = eyebrowz.nodes.new("GeometryNodeGroup")
	    group_6.name = "Group"
	    group_6.node_tree = clump_hair_curves
	    group_6.inputs[1].hide = True
	    group_6.inputs[2].hide = True
	    group_6.inputs[3].hide = True
	    group_6.inputs[4].hide = True
	    group_6.inputs[6].hide = True
	    group_6.inputs[9].hide = True
	    group_6.inputs[10].hide = True
	    group_6.inputs[12].hide = True
	    group_6.outputs[1].hide = True
	    #Socket_3
	    group_6.inputs[1].default_value = -987654
	    #Socket_4
	    group_6.inputs[2].default_value = 0.0
	    #Socket_5
	    group_6.inputs[3].default_value = 0.10000002384185791
	    #Socket_6
	    group_6.inputs[4].default_value = True
	    #Socket_8
	    group_6.inputs[6].default_value = 0.5
	    #Socket_11
	    group_6.inputs[9].default_value = 0.0
	    #Socket_12
	    group_6.inputs[10].default_value = 0.0
	    #Socket_14
	    group_6.inputs[12].default_value = True
	
	    #node Clump Factor
	    clump_factor = eyebrowz.nodes.new("ShaderNodeFloatCurve")
	    clump_factor.label = "Clump Factor"
	    clump_factor.name = "Clump Factor"
	    #mapping settings
	    clump_factor.mapping.extend = 'EXTRAPOLATED'
	    clump_factor.mapping.tone = 'STANDARD'
	    clump_factor.mapping.black_level = (0.0, 0.0, 0.0)
	    clump_factor.mapping.white_level = (1.0, 1.0, 1.0)
	    clump_factor.mapping.clip_min_x = 0.0
	    clump_factor.mapping.clip_min_y = 0.0
	    clump_factor.mapping.clip_max_x = 1.0
	    clump_factor.mapping.clip_max_y = 1.0
	    clump_factor.mapping.use_clip = True
	    #curve 0
	    clump_factor_curve_0 = clump_factor.mapping.curves[0]
	    clump_factor_curve_0_point_0 = clump_factor_curve_0.points[0]
	    clump_factor_curve_0_point_0.location = (0.013636363670229912, 0.2937498092651367)
	    clump_factor_curve_0_point_0.handle_type = 'AUTO'
	    clump_factor_curve_0_point_1 = clump_factor_curve_0.points[1]
	    clump_factor_curve_0_point_1.location = (0.5772726535797119, 0.24999971687793732)
	    clump_factor_curve_0_point_1.handle_type = 'AUTO'
	    clump_factor_curve_0_point_2 = clump_factor_curve_0.points.new(1.0, 0.5312500596046448)
	    clump_factor_curve_0_point_2.handle_type = 'AUTO'
	    #update curve after changes
	    clump_factor.mapping.update()
	    #Factor
	    clump_factor.inputs[0].default_value = 1.0
	
	    #node Spline Parameter.002
	    spline_parameter_002 = eyebrowz.nodes.new("GeometryNodeSplineParameter")
	    spline_parameter_002.name = "Spline Parameter.002"
	    spline_parameter_002.outputs[1].hide = True
	    spline_parameter_002.outputs[2].hide = True
	
	    #node Group.001
	    group_001_6 = eyebrowz.nodes.new("GeometryNodeGroup")
	    group_001_6.name = "Group.001"
	    group_001_6.node_tree = attach_hair_curves_to_surface
	    group_001_6.inputs[1].hide = True
	    group_001_6.inputs[4].hide = True
	    group_001_6.inputs[5].hide = True
	    group_001_6.inputs[6].hide = True
	    group_001_6.inputs[7].hide = True
	    group_001_6.inputs[8].hide = True
	    group_001_6.outputs[1].hide = True
	    group_001_6.outputs[2].hide = True
	    #Socket_7
	    group_001_6.inputs[4].default_value = False
	    #Socket_8
	    group_001_6.inputs[5].default_value = True
	    #Socket_9
	    group_001_6.inputs[6].default_value = True
	    #Socket_10
	    group_001_6.inputs[7].default_value = False
	    #Socket_11
	    group_001_6.inputs[8].default_value = 0.0
	
	    #node Group Input.005
	    group_input_005_8 = eyebrowz.nodes.new("NodeGroupInput")
	    group_input_005_8.name = "Group Input.005"
	    group_input_005_8.outputs[0].hide = True
	    group_input_005_8.outputs[2].hide = True
	    group_input_005_8.outputs[3].hide = True
	    group_input_005_8.outputs[4].hide = True
	    group_input_005_8.outputs[5].hide = True
	    group_input_005_8.outputs[6].hide = True
	    group_input_005_8.outputs[7].hide = True
	    group_input_005_8.outputs[8].hide = True
	    group_input_005_8.outputs[9].hide = True
	    group_input_005_8.outputs[10].hide = True
	    group_input_005_8.outputs[11].hide = True
	    group_input_005_8.outputs[12].hide = True
	    group_input_005_8.outputs[13].hide = True
	    group_input_005_8.outputs[14].hide = True
	    group_input_005_8.outputs[15].hide = True
	    group_input_005_8.outputs[16].hide = True
	    group_input_005_8.outputs[17].hide = True
	    group_input_005_8.outputs[18].hide = True
	    group_input_005_8.outputs[19].hide = True
	    group_input_005_8.outputs[20].hide = True
	    group_input_005_8.outputs[21].hide = True
	    group_input_005_8.outputs[22].hide = True
	    group_input_005_8.outputs[23].hide = True
	    group_input_005_8.outputs[24].hide = True
	    group_input_005_8.outputs[25].hide = True
	    group_input_005_8.outputs[26].hide = True
	    group_input_005_8.outputs[27].hide = True
	    group_input_005_8.outputs[28].hide = True
	    group_input_005_8.outputs[29].hide = True
	    group_input_005_8.outputs[30].hide = True
	    group_input_005_8.outputs[31].hide = True
	    group_input_005_8.outputs[32].hide = True
	    group_input_005_8.outputs[33].hide = True
	    group_input_005_8.outputs[34].hide = True
	    group_input_005_8.outputs[35].hide = True
	    group_input_005_8.outputs[36].hide = True
	    group_input_005_8.outputs[37].hide = True
	    group_input_005_8.outputs[38].hide = True
	    group_input_005_8.outputs[39].hide = True
	    group_input_005_8.outputs[40].hide = True
	    group_input_005_8.outputs[41].hide = True
	    group_input_005_8.outputs[42].hide = True
	    group_input_005_8.outputs[43].hide = True
	    group_input_005_8.outputs[44].hide = True
	
	    #node Named Attribute
	    named_attribute_4 = eyebrowz.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute_4.name = "Named Attribute"
	    named_attribute_4.hide = True
	    named_attribute_4.data_type = 'FLOAT_VECTOR'
	
	    #node Tip Spread Factor
	    tip_spread_factor = eyebrowz.nodes.new("ShaderNodeFloatCurve")
	    tip_spread_factor.label = "Tip Spread Factor"
	    tip_spread_factor.name = "Tip Spread Factor"
	    #mapping settings
	    tip_spread_factor.mapping.extend = 'EXTRAPOLATED'
	    tip_spread_factor.mapping.tone = 'STANDARD'
	    tip_spread_factor.mapping.black_level = (0.0, 0.0, 0.0)
	    tip_spread_factor.mapping.white_level = (1.0, 1.0, 1.0)
	    tip_spread_factor.mapping.clip_min_x = 0.0
	    tip_spread_factor.mapping.clip_min_y = 0.0
	    tip_spread_factor.mapping.clip_max_x = 1.0
	    tip_spread_factor.mapping.clip_max_y = 1.0
	    tip_spread_factor.mapping.use_clip = True
	    #curve 0
	    tip_spread_factor_curve_0 = tip_spread_factor.mapping.curves[0]
	    tip_spread_factor_curve_0_point_0 = tip_spread_factor_curve_0.points[0]
	    tip_spread_factor_curve_0_point_0.location = (0.06818182021379471, 0.0)
	    tip_spread_factor_curve_0_point_0.handle_type = 'AUTO'
	    tip_spread_factor_curve_0_point_1 = tip_spread_factor_curve_0.points[1]
	    tip_spread_factor_curve_0_point_1.location = (0.5772726535797119, 0.24999971687793732)
	    tip_spread_factor_curve_0_point_1.handle_type = 'AUTO'
	    tip_spread_factor_curve_0_point_2 = tip_spread_factor_curve_0.points.new(1.0, 0.0)
	    tip_spread_factor_curve_0_point_2.handle_type = 'AUTO'
	    #update curve after changes
	    tip_spread_factor.mapping.update()
	    tip_spread_factor.inputs[0].hide = True
	    #Factor
	    tip_spread_factor.inputs[0].default_value = 1.0
	
	    #node Spline Parameter.003
	    spline_parameter_003 = eyebrowz.nodes.new("GeometryNodeSplineParameter")
	    spline_parameter_003.name = "Spline Parameter.003"
	    spline_parameter_003.outputs[1].hide = True
	    spline_parameter_003.outputs[2].hide = True
	
	    #node Map Range.001
	    map_range_001_2 = eyebrowz.nodes.new("ShaderNodeMapRange")
	    map_range_001_2.name = "Map Range.001"
	    map_range_001_2.hide = True
	    map_range_001_2.clamp = True
	    map_range_001_2.data_type = 'FLOAT'
	    map_range_001_2.interpolation_type = 'LINEAR'
	    map_range_001_2.inputs[1].hide = True
	    map_range_001_2.inputs[2].hide = True
	    map_range_001_2.inputs[3].hide = True
	    map_range_001_2.inputs[5].hide = True
	    map_range_001_2.inputs[6].hide = True
	    map_range_001_2.inputs[7].hide = True
	    map_range_001_2.inputs[8].hide = True
	    map_range_001_2.inputs[9].hide = True
	    map_range_001_2.inputs[10].hide = True
	    map_range_001_2.inputs[11].hide = True
	    map_range_001_2.outputs[1].hide = True
	    #From Min
	    map_range_001_2.inputs[1].default_value = 0.0
	    #From Max
	    map_range_001_2.inputs[2].default_value = 1.0
	    #To Min
	    map_range_001_2.inputs[3].default_value = 0.0
	
	    #node Group Input.006
	    group_input_006_6 = eyebrowz.nodes.new("NodeGroupInput")
	    group_input_006_6.name = "Group Input.006"
	    group_input_006_6.outputs[0].hide = True
	    group_input_006_6.outputs[1].hide = True
	    group_input_006_6.outputs[2].hide = True
	    group_input_006_6.outputs[3].hide = True
	    group_input_006_6.outputs[4].hide = True
	    group_input_006_6.outputs[5].hide = True
	    group_input_006_6.outputs[6].hide = True
	    group_input_006_6.outputs[7].hide = True
	    group_input_006_6.outputs[8].hide = True
	    group_input_006_6.outputs[9].hide = True
	    group_input_006_6.outputs[10].hide = True
	    group_input_006_6.outputs[11].hide = True
	    group_input_006_6.outputs[12].hide = True
	    group_input_006_6.outputs[13].hide = True
	    group_input_006_6.outputs[14].hide = True
	    group_input_006_6.outputs[15].hide = True
	    group_input_006_6.outputs[16].hide = True
	    group_input_006_6.outputs[17].hide = True
	    group_input_006_6.outputs[18].hide = True
	    group_input_006_6.outputs[19].hide = True
	    group_input_006_6.outputs[20].hide = True
	    group_input_006_6.outputs[24].hide = True
	    group_input_006_6.outputs[25].hide = True
	    group_input_006_6.outputs[26].hide = True
	    group_input_006_6.outputs[27].hide = True
	    group_input_006_6.outputs[28].hide = True
	    group_input_006_6.outputs[29].hide = True
	    group_input_006_6.outputs[30].hide = True
	    group_input_006_6.outputs[31].hide = True
	    group_input_006_6.outputs[32].hide = True
	    group_input_006_6.outputs[33].hide = True
	    group_input_006_6.outputs[34].hide = True
	    group_input_006_6.outputs[35].hide = True
	    group_input_006_6.outputs[36].hide = True
	    group_input_006_6.outputs[37].hide = True
	    group_input_006_6.outputs[38].hide = True
	    group_input_006_6.outputs[39].hide = True
	    group_input_006_6.outputs[40].hide = True
	    group_input_006_6.outputs[41].hide = True
	    group_input_006_6.outputs[42].hide = True
	    group_input_006_6.outputs[43].hide = True
	    group_input_006_6.outputs[44].hide = True
	
	    #node Group Input.007
	    group_input_007_5 = eyebrowz.nodes.new("NodeGroupInput")
	    group_input_007_5.name = "Group Input.007"
	    group_input_007_5.outputs[0].hide = True
	    group_input_007_5.outputs[1].hide = True
	    group_input_007_5.outputs[2].hide = True
	    group_input_007_5.outputs[3].hide = True
	    group_input_007_5.outputs[4].hide = True
	    group_input_007_5.outputs[5].hide = True
	    group_input_007_5.outputs[6].hide = True
	    group_input_007_5.outputs[7].hide = True
	    group_input_007_5.outputs[8].hide = True
	    group_input_007_5.outputs[9].hide = True
	    group_input_007_5.outputs[10].hide = True
	    group_input_007_5.outputs[12].hide = True
	    group_input_007_5.outputs[13].hide = True
	    group_input_007_5.outputs[14].hide = True
	    group_input_007_5.outputs[15].hide = True
	    group_input_007_5.outputs[16].hide = True
	    group_input_007_5.outputs[17].hide = True
	    group_input_007_5.outputs[18].hide = True
	    group_input_007_5.outputs[19].hide = True
	    group_input_007_5.outputs[20].hide = True
	    group_input_007_5.outputs[21].hide = True
	    group_input_007_5.outputs[22].hide = True
	    group_input_007_5.outputs[23].hide = True
	    group_input_007_5.outputs[24].hide = True
	    group_input_007_5.outputs[25].hide = True
	    group_input_007_5.outputs[26].hide = True
	    group_input_007_5.outputs[27].hide = True
	    group_input_007_5.outputs[28].hide = True
	    group_input_007_5.outputs[29].hide = True
	    group_input_007_5.outputs[30].hide = True
	    group_input_007_5.outputs[31].hide = True
	    group_input_007_5.outputs[32].hide = True
	    group_input_007_5.outputs[33].hide = True
	    group_input_007_5.outputs[34].hide = True
	    group_input_007_5.outputs[35].hide = True
	    group_input_007_5.outputs[36].hide = True
	    group_input_007_5.outputs[37].hide = True
	    group_input_007_5.outputs[38].hide = True
	    group_input_007_5.outputs[39].hide = True
	    group_input_007_5.outputs[40].hide = True
	    group_input_007_5.outputs[41].hide = True
	    group_input_007_5.outputs[42].hide = True
	    group_input_007_5.outputs[43].hide = True
	    group_input_007_5.outputs[44].hide = True
	
	    #node Set Material
	    set_material_4 = eyebrowz.nodes.new("GeometryNodeSetMaterial")
	    set_material_4.name = "Set Material"
	    set_material_4.inputs[1].hide = True
	    #Selection
	    set_material_4.inputs[1].default_value = True
	
	    #node Set Position.003
	    set_position_003 = eyebrowz.nodes.new("GeometryNodeSetPosition")
	    set_position_003.name = "Set Position.003"
	    set_position_003.hide = True
	    #Selection
	    set_position_003.inputs[1].default_value = True
	    #Offset
	    set_position_003.inputs[3].default_value = (0.0, 0.0, 0.0)
	
	    #node Vector Math.001
	    vector_math_001_5 = eyebrowz.nodes.new("ShaderNodeVectorMath")
	    vector_math_001_5.name = "Vector Math.001"
	    vector_math_001_5.hide = True
	    vector_math_001_5.operation = 'MULTIPLY'
	    #Vector_001
	    vector_math_001_5.inputs[1].default_value = (-1.0, 1.0, 1.0)
	
	    #node Capture Attribute
	    capture_attribute_9 = eyebrowz.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_9.name = "Capture Attribute"
	    capture_attribute_9.hide = True
	    capture_attribute_9.active_index = 0
	    capture_attribute_9.capture_items.clear()
	    capture_attribute_9.capture_items.new('FLOAT', "Position")
	    capture_attribute_9.capture_items["Position"].data_type = 'FLOAT_VECTOR'
	    capture_attribute_9.domain = 'POINT'
	
	    #node Position.001
	    position_001_3 = eyebrowz.nodes.new("GeometryNodeInputPosition")
	    position_001_3.name = "Position.001"
	    position_001_3.hide = True
	
	    #node Switch.002
	    switch_002_6 = eyebrowz.nodes.new("GeometryNodeSwitch")
	    switch_002_6.name = "Switch.002"
	    switch_002_6.hide = True
	    switch_002_6.input_type = 'GEOMETRY'
	
	    #node Join Geometry.001
	    join_geometry_001_3 = eyebrowz.nodes.new("GeometryNodeJoinGeometry")
	    join_geometry_001_3.name = "Join Geometry.001"
	    join_geometry_001_3.hide = True
	
	    #node Frame.001
	    frame_001_4 = eyebrowz.nodes.new("NodeFrame")
	    frame_001_4.label = "Mirror"
	    frame_001_4.name = "Frame.001"
	    frame_001_4.label_size = 20
	    frame_001_4.shrink = True
	
	    #node Group Input.011
	    group_input_011_1 = eyebrowz.nodes.new("NodeGroupInput")
	    group_input_011_1.name = "Group Input.011"
	    group_input_011_1.outputs[0].hide = True
	    group_input_011_1.outputs[1].hide = True
	    group_input_011_1.outputs[2].hide = True
	    group_input_011_1.outputs[3].hide = True
	    group_input_011_1.outputs[4].hide = True
	    group_input_011_1.outputs[5].hide = True
	    group_input_011_1.outputs[6].hide = True
	    group_input_011_1.outputs[7].hide = True
	    group_input_011_1.outputs[8].hide = True
	    group_input_011_1.outputs[9].hide = True
	    group_input_011_1.outputs[10].hide = True
	    group_input_011_1.outputs[11].hide = True
	    group_input_011_1.outputs[14].hide = True
	    group_input_011_1.outputs[15].hide = True
	    group_input_011_1.outputs[16].hide = True
	    group_input_011_1.outputs[17].hide = True
	    group_input_011_1.outputs[18].hide = True
	    group_input_011_1.outputs[19].hide = True
	    group_input_011_1.outputs[20].hide = True
	    group_input_011_1.outputs[21].hide = True
	    group_input_011_1.outputs[22].hide = True
	    group_input_011_1.outputs[23].hide = True
	    group_input_011_1.outputs[24].hide = True
	    group_input_011_1.outputs[25].hide = True
	    group_input_011_1.outputs[26].hide = True
	    group_input_011_1.outputs[27].hide = True
	    group_input_011_1.outputs[28].hide = True
	    group_input_011_1.outputs[29].hide = True
	    group_input_011_1.outputs[30].hide = True
	    group_input_011_1.outputs[31].hide = True
	    group_input_011_1.outputs[32].hide = True
	    group_input_011_1.outputs[33].hide = True
	    group_input_011_1.outputs[34].hide = True
	    group_input_011_1.outputs[35].hide = True
	    group_input_011_1.outputs[36].hide = True
	    group_input_011_1.outputs[37].hide = True
	    group_input_011_1.outputs[38].hide = True
	    group_input_011_1.outputs[39].hide = True
	    group_input_011_1.outputs[40].hide = True
	    group_input_011_1.outputs[41].hide = True
	    group_input_011_1.outputs[42].hide = True
	    group_input_011_1.outputs[43].hide = True
	    group_input_011_1.outputs[44].hide = True
	
	    #node Reroute.012
	    reroute_012_6 = eyebrowz.nodes.new("NodeReroute")
	    reroute_012_6.name = "Reroute.012"
	    reroute_012_6.socket_idname = "NodeSocketGeometry"
	    #node Reroute.013
	    reroute_013_6 = eyebrowz.nodes.new("NodeReroute")
	    reroute_013_6.name = "Reroute.013"
	    reroute_013_6.socket_idname = "NodeSocketGeometry"
	    #node Reroute.014
	    reroute_014_6 = eyebrowz.nodes.new("NodeReroute")
	    reroute_014_6.name = "Reroute.014"
	    reroute_014_6.socket_idname = "NodeSocketGeometry"
	    #node Reroute.015
	    reroute_015_6 = eyebrowz.nodes.new("NodeReroute")
	    reroute_015_6.name = "Reroute.015"
	    reroute_015_6.socket_idname = "NodeSocketGeometry"
	    #node Reroute.016
	    reroute_016_6 = eyebrowz.nodes.new("NodeReroute")
	    reroute_016_6.name = "Reroute.016"
	    reroute_016_6.socket_idname = "NodeSocketGeometry"
	    #node Reroute.017
	    reroute_017_5 = eyebrowz.nodes.new("NodeReroute")
	    reroute_017_5.name = "Reroute.017"
	    reroute_017_5.socket_idname = "NodeSocketGeometry"
	    #node Hair Shape
	    hair_shape = eyebrowz.nodes.new("ShaderNodeFloatCurve")
	    hair_shape.label = "Hair Shape"
	    hair_shape.name = "Hair Shape"
	    #mapping settings
	    hair_shape.mapping.extend = 'EXTRAPOLATED'
	    hair_shape.mapping.tone = 'STANDARD'
	    hair_shape.mapping.black_level = (0.0, 0.0, 0.0)
	    hair_shape.mapping.white_level = (1.0, 1.0, 1.0)
	    hair_shape.mapping.clip_min_x = 0.0
	    hair_shape.mapping.clip_min_y = 0.0
	    hair_shape.mapping.clip_max_x = 1.0
	    hair_shape.mapping.clip_max_y = 1.0
	    hair_shape.mapping.use_clip = True
	    #curve 0
	    hair_shape_curve_0 = hair_shape.mapping.curves[0]
	    hair_shape_curve_0_point_0 = hair_shape_curve_0.points[0]
	    hair_shape_curve_0_point_0.location = (0.00909090880304575, 0.0)
	    hair_shape_curve_0_point_0.handle_type = 'AUTO'
	    hair_shape_curve_0_point_1 = hair_shape_curve_0.points[1]
	    hair_shape_curve_0_point_1.location = (0.044510386884212494, 1.0)
	    hair_shape_curve_0_point_1.handle_type = 'VECTOR'
	    hair_shape_curve_0_point_2 = hair_shape_curve_0.points.new(0.925815999507904, 0.96875)
	    hair_shape_curve_0_point_2.handle_type = 'VECTOR'
	    hair_shape_curve_0_point_3 = hair_shape_curve_0.points.new(1.0, 0.0)
	    hair_shape_curve_0_point_3.handle_type = 'AUTO'
	    #update curve after changes
	    hair_shape.mapping.update()
	    hair_shape.inputs[0].hide = True
	    #Factor
	    hair_shape.inputs[0].default_value = 1.0
	
	    #node Spline Parameter.004
	    spline_parameter_004 = eyebrowz.nodes.new("GeometryNodeSplineParameter")
	    spline_parameter_004.name = "Spline Parameter.004"
	    spline_parameter_004.outputs[1].hide = True
	    spline_parameter_004.outputs[2].hide = True
	
	    #node Map Range.002
	    map_range_002 = eyebrowz.nodes.new("ShaderNodeMapRange")
	    map_range_002.name = "Map Range.002"
	    map_range_002.hide = True
	    map_range_002.clamp = True
	    map_range_002.data_type = 'FLOAT'
	    map_range_002.interpolation_type = 'LINEAR'
	    map_range_002.inputs[1].hide = True
	    map_range_002.inputs[2].hide = True
	    map_range_002.inputs[3].hide = True
	    map_range_002.inputs[5].hide = True
	    map_range_002.inputs[6].hide = True
	    map_range_002.inputs[7].hide = True
	    map_range_002.inputs[8].hide = True
	    map_range_002.inputs[9].hide = True
	    map_range_002.inputs[10].hide = True
	    map_range_002.inputs[11].hide = True
	    map_range_002.outputs[1].hide = True
	    #From Min
	    map_range_002.inputs[1].default_value = 0.0
	    #From Max
	    map_range_002.inputs[2].default_value = 1.0
	    #To Min
	    map_range_002.inputs[3].default_value = 0.0
	
	    #node Group Input.014
	    group_input_014 = eyebrowz.nodes.new("NodeGroupInput")
	    group_input_014.name = "Group Input.014"
	    group_input_014.outputs[0].hide = True
	    group_input_014.outputs[1].hide = True
	    group_input_014.outputs[2].hide = True
	    group_input_014.outputs[3].hide = True
	    group_input_014.outputs[4].hide = True
	    group_input_014.outputs[5].hide = True
	    group_input_014.outputs[7].hide = True
	    group_input_014.outputs[8].hide = True
	    group_input_014.outputs[9].hide = True
	    group_input_014.outputs[10].hide = True
	    group_input_014.outputs[11].hide = True
	    group_input_014.outputs[12].hide = True
	    group_input_014.outputs[13].hide = True
	    group_input_014.outputs[14].hide = True
	    group_input_014.outputs[15].hide = True
	    group_input_014.outputs[16].hide = True
	    group_input_014.outputs[17].hide = True
	    group_input_014.outputs[18].hide = True
	    group_input_014.outputs[19].hide = True
	    group_input_014.outputs[20].hide = True
	    group_input_014.outputs[21].hide = True
	    group_input_014.outputs[22].hide = True
	    group_input_014.outputs[23].hide = True
	    group_input_014.outputs[24].hide = True
	    group_input_014.outputs[25].hide = True
	    group_input_014.outputs[26].hide = True
	    group_input_014.outputs[27].hide = True
	    group_input_014.outputs[28].hide = True
	    group_input_014.outputs[29].hide = True
	    group_input_014.outputs[30].hide = True
	    group_input_014.outputs[31].hide = True
	    group_input_014.outputs[32].hide = True
	    group_input_014.outputs[33].hide = True
	    group_input_014.outputs[34].hide = True
	    group_input_014.outputs[35].hide = True
	    group_input_014.outputs[36].hide = True
	    group_input_014.outputs[37].hide = True
	    group_input_014.outputs[38].hide = True
	    group_input_014.outputs[39].hide = True
	    group_input_014.outputs[40].hide = True
	    group_input_014.outputs[41].hide = True
	    group_input_014.outputs[42].hide = True
	    group_input_014.outputs[43].hide = True
	    group_input_014.outputs[44].hide = True
	
	    #node Eyebrow Bake
	    eyebrow_bake = eyebrowz.nodes.new("GeometryNodeBake")
	    eyebrow_bake.label = "Eyebrow Bake"
	    eyebrow_bake.name = "Eyebrow Bake"
	    eyebrow_bake.active_index = 0
	    eyebrow_bake.bake_items.clear()
	    eyebrow_bake.bake_items.new('GEOMETRY', "Geometry")
	    eyebrow_bake.bake_items[0].attribute_domain = 'POINT'
	    eyebrow_bake.inputs[1].hide = True
	    eyebrow_bake.outputs[1].hide = True
	
	    #node Join Geometry
	    join_geometry_4 = eyebrowz.nodes.new("GeometryNodeJoinGeometry")
	    join_geometry_4.name = "Join Geometry"
	
	    #node Reroute.003
	    reroute_003_8 = eyebrowz.nodes.new("NodeReroute")
	    reroute_003_8.name = "Reroute.003"
	    reroute_003_8.socket_idname = "NodeSocketGeometry"
	    #node Reroute.005
	    reroute_005_7 = eyebrowz.nodes.new("NodeReroute")
	    reroute_005_7.name = "Reroute.005"
	    reroute_005_7.socket_idname = "NodeSocketGeometry"
	    #node Reroute.006
	    reroute_006_6 = eyebrowz.nodes.new("NodeReroute")
	    reroute_006_6.name = "Reroute.006"
	    reroute_006_6.socket_idname = "NodeSocketGeometry"
	    #node Reroute.007
	    reroute_007_6 = eyebrowz.nodes.new("NodeReroute")
	    reroute_007_6.name = "Reroute.007"
	    reroute_007_6.socket_idname = "NodeSocketGeometry"
	    #node Reroute.008
	    reroute_008_6 = eyebrowz.nodes.new("NodeReroute")
	    reroute_008_6.name = "Reroute.008"
	    reroute_008_6.socket_idname = "NodeSocketGeometry"
	    #node Reroute.009
	    reroute_009_6 = eyebrowz.nodes.new("NodeReroute")
	    reroute_009_6.name = "Reroute.009"
	    reroute_009_6.socket_idname = "NodeSocketGeometry"
	    #node Reroute.010
	    reroute_010_4 = eyebrowz.nodes.new("NodeReroute")
	    reroute_010_4.name = "Reroute.010"
	    reroute_010_4.socket_idname = "NodeSocketGeometry"
	    #node Reroute.011
	    reroute_011_5 = eyebrowz.nodes.new("NodeReroute")
	    reroute_011_5.name = "Reroute.011"
	    reroute_011_5.socket_idname = "NodeSocketGeometry"
	    #node Reroute.018
	    reroute_018_5 = eyebrowz.nodes.new("NodeReroute")
	    reroute_018_5.name = "Reroute.018"
	    reroute_018_5.socket_idname = "NodeSocketGeometry"
	    #node Reroute.019
	    reroute_019_4 = eyebrowz.nodes.new("NodeReroute")
	    reroute_019_4.name = "Reroute.019"
	    reroute_019_4.socket_idname = "NodeSocketGeometry"
	    #node Set Curve Tilt
	    set_curve_tilt_1 = eyebrowz.nodes.new("GeometryNodeSetCurveTilt")
	    set_curve_tilt_1.name = "Set Curve Tilt"
	    #Selection
	    set_curve_tilt_1.inputs[1].default_value = True
	
	    #node Reroute.020
	    reroute_020_4 = eyebrowz.nodes.new("NodeReroute")
	    reroute_020_4.name = "Reroute.020"
	    reroute_020_4.socket_idname = "NodeSocketGeometry"
	    #node Group Input.015
	    group_input_015 = eyebrowz.nodes.new("NodeGroupInput")
	    group_input_015.name = "Group Input.015"
	    group_input_015.outputs[0].hide = True
	    group_input_015.outputs[1].hide = True
	    group_input_015.outputs[2].hide = True
	    group_input_015.outputs[3].hide = True
	    group_input_015.outputs[4].hide = True
	    group_input_015.outputs[5].hide = True
	    group_input_015.outputs[6].hide = True
	    group_input_015.outputs[7].hide = True
	    group_input_015.outputs[8].hide = True
	    group_input_015.outputs[9].hide = True
	    group_input_015.outputs[11].hide = True
	    group_input_015.outputs[12].hide = True
	    group_input_015.outputs[13].hide = True
	    group_input_015.outputs[14].hide = True
	    group_input_015.outputs[15].hide = True
	    group_input_015.outputs[16].hide = True
	    group_input_015.outputs[17].hide = True
	    group_input_015.outputs[18].hide = True
	    group_input_015.outputs[19].hide = True
	    group_input_015.outputs[20].hide = True
	    group_input_015.outputs[21].hide = True
	    group_input_015.outputs[22].hide = True
	    group_input_015.outputs[23].hide = True
	    group_input_015.outputs[24].hide = True
	    group_input_015.outputs[25].hide = True
	    group_input_015.outputs[26].hide = True
	    group_input_015.outputs[27].hide = True
	    group_input_015.outputs[28].hide = True
	    group_input_015.outputs[29].hide = True
	    group_input_015.outputs[30].hide = True
	    group_input_015.outputs[31].hide = True
	    group_input_015.outputs[32].hide = True
	    group_input_015.outputs[33].hide = True
	    group_input_015.outputs[34].hide = True
	    group_input_015.outputs[35].hide = True
	    group_input_015.outputs[36].hide = True
	    group_input_015.outputs[37].hide = True
	    group_input_015.outputs[38].hide = True
	    group_input_015.outputs[39].hide = True
	    group_input_015.outputs[40].hide = True
	    group_input_015.outputs[41].hide = True
	    group_input_015.outputs[42].hide = True
	    group_input_015.outputs[43].hide = True
	    group_input_015.outputs[44].hide = True
	
	    #node Group.002
	    group_002_2 = eyebrowz.nodes.new("GeometryNodeGroup")
	    group_002_2.name = "Group.002"
	    group_002_2.node_tree = mesh_hair_selector
	    group_002_2.inputs[1].hide = True
	    group_002_2.inputs[5].hide = True
	    group_002_2.inputs[6].hide = True
	    group_002_2.inputs[9].hide = True
	    group_002_2.inputs[10].hide = True
	    group_002_2.inputs[11].hide = True
	    group_002_2.inputs[12].hide = True
	    group_002_2.inputs[13].hide = True
	    group_002_2.inputs[14].hide = True
	    #Socket_2
	    group_002_2.inputs[1].default_value = 'Hair Card'
	    #Socket_6
	    group_002_2.inputs[5].default_value = 0.0
	    #Socket_7
	    group_002_2.inputs[6].default_value = False
	    #Socket_10
	    group_002_2.inputs[9].default_value = 8
	    #Socket_12
	    group_002_2.inputs[11].default_value = (0.0, 0.0, 0.0)
	    #Socket_13
	    group_002_2.inputs[12].default_value = (0.0, 0.0, 0.0)
	    #Socket_14
	    group_002_2.inputs[13].default_value = (1.0, 1.0, 1.0)
	    #Socket_15
	    group_002_2.inputs[14].default_value = 0
	
	    #node Set Curve Tilt.001
	    set_curve_tilt_001 = eyebrowz.nodes.new("GeometryNodeSetCurveTilt")
	    set_curve_tilt_001.name = "Set Curve Tilt.001"
	    set_curve_tilt_001.hide = True
	    set_curve_tilt_001.inputs[1].hide = True
	    set_curve_tilt_001.inputs[2].hide = True
	    #Selection
	    set_curve_tilt_001.inputs[1].default_value = True
	    #Tilt
	    set_curve_tilt_001.inputs[2].default_value = 1.5707963705062866
	
	    #node Set Position.004
	    set_position_004 = eyebrowz.nodes.new("GeometryNodeSetPosition")
	    set_position_004.name = "Set Position.004"
	    set_position_004.hide = True
	    #Selection
	    set_position_004.inputs[1].default_value = True
	    #Offset
	    set_position_004.inputs[3].default_value = (0.0, 0.0, 0.0)
	
	    #node Vector Math.002
	    vector_math_002_4 = eyebrowz.nodes.new("ShaderNodeVectorMath")
	    vector_math_002_4.name = "Vector Math.002"
	    vector_math_002_4.hide = True
	    vector_math_002_4.operation = 'MULTIPLY'
	    #Vector_001
	    vector_math_002_4.inputs[1].default_value = (-1.0, 1.0, 1.0)
	
	    #node Capture Attribute.001
	    capture_attribute_001_5 = eyebrowz.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_001_5.name = "Capture Attribute.001"
	    capture_attribute_001_5.hide = True
	    capture_attribute_001_5.active_index = 0
	    capture_attribute_001_5.capture_items.clear()
	    capture_attribute_001_5.capture_items.new('FLOAT', "Position")
	    capture_attribute_001_5.capture_items["Position"].data_type = 'FLOAT_VECTOR'
	    capture_attribute_001_5.domain = 'POINT'
	
	    #node Position.002
	    position_002_4 = eyebrowz.nodes.new("GeometryNodeInputPosition")
	    position_002_4.name = "Position.002"
	    position_002_4.hide = True
	
	    #node Switch.003
	    switch_003_7 = eyebrowz.nodes.new("GeometryNodeSwitch")
	    switch_003_7.name = "Switch.003"
	    switch_003_7.hide = True
	    switch_003_7.input_type = 'GEOMETRY'
	
	    #node Join Geometry.002
	    join_geometry_002 = eyebrowz.nodes.new("GeometryNodeJoinGeometry")
	    join_geometry_002.name = "Join Geometry.002"
	    join_geometry_002.hide = True
	
	    #node Frame.002
	    frame_002_5 = eyebrowz.nodes.new("NodeFrame")
	    frame_002_5.label = "Mirror"
	    frame_002_5.name = "Frame.002"
	    frame_002_5.label_size = 20
	    frame_002_5.shrink = True
	
	    #node Group Input.012
	    group_input_012_1 = eyebrowz.nodes.new("NodeGroupInput")
	    group_input_012_1.name = "Group Input.012"
	    group_input_012_1.outputs[0].hide = True
	    group_input_012_1.outputs[1].hide = True
	    group_input_012_1.outputs[2].hide = True
	    group_input_012_1.outputs[3].hide = True
	    group_input_012_1.outputs[4].hide = True
	    group_input_012_1.outputs[5].hide = True
	    group_input_012_1.outputs[6].hide = True
	    group_input_012_1.outputs[7].hide = True
	    group_input_012_1.outputs[8].hide = True
	    group_input_012_1.outputs[9].hide = True
	    group_input_012_1.outputs[10].hide = True
	    group_input_012_1.outputs[11].hide = True
	    group_input_012_1.outputs[13].hide = True
	    group_input_012_1.outputs[14].hide = True
	    group_input_012_1.outputs[15].hide = True
	    group_input_012_1.outputs[16].hide = True
	    group_input_012_1.outputs[17].hide = True
	    group_input_012_1.outputs[18].hide = True
	    group_input_012_1.outputs[19].hide = True
	    group_input_012_1.outputs[20].hide = True
	    group_input_012_1.outputs[21].hide = True
	    group_input_012_1.outputs[22].hide = True
	    group_input_012_1.outputs[23].hide = True
	    group_input_012_1.outputs[24].hide = True
	    group_input_012_1.outputs[25].hide = True
	    group_input_012_1.outputs[26].hide = True
	    group_input_012_1.outputs[27].hide = True
	    group_input_012_1.outputs[28].hide = True
	    group_input_012_1.outputs[29].hide = True
	    group_input_012_1.outputs[30].hide = True
	    group_input_012_1.outputs[31].hide = True
	    group_input_012_1.outputs[32].hide = True
	    group_input_012_1.outputs[33].hide = True
	    group_input_012_1.outputs[34].hide = True
	    group_input_012_1.outputs[35].hide = True
	    group_input_012_1.outputs[36].hide = True
	    group_input_012_1.outputs[37].hide = True
	    group_input_012_1.outputs[38].hide = True
	    group_input_012_1.outputs[39].hide = True
	    group_input_012_1.outputs[40].hide = True
	    group_input_012_1.outputs[41].hide = True
	    group_input_012_1.outputs[42].hide = True
	    group_input_012_1.outputs[43].hide = True
	    group_input_012_1.outputs[44].hide = True
	
	    #node Reroute.021
	    reroute_021_2 = eyebrowz.nodes.new("NodeReroute")
	    reroute_021_2.name = "Reroute.021"
	    reroute_021_2.socket_idname = "NodeSocketGeometry"
	    #node Reroute.022
	    reroute_022_2 = eyebrowz.nodes.new("NodeReroute")
	    reroute_022_2.name = "Reroute.022"
	    reroute_022_2.socket_idname = "NodeSocketGeometry"
	    #node Reroute.023
	    reroute_023_2 = eyebrowz.nodes.new("NodeReroute")
	    reroute_023_2.name = "Reroute.023"
	    reroute_023_2.socket_idname = "NodeSocketGeometry"
	    #node Reroute.024
	    reroute_024_2 = eyebrowz.nodes.new("NodeReroute")
	    reroute_024_2.name = "Reroute.024"
	    reroute_024_2.socket_idname = "NodeSocketGeometry"
	    #node Reroute.025
	    reroute_025_1 = eyebrowz.nodes.new("NodeReroute")
	    reroute_025_1.name = "Reroute.025"
	    reroute_025_1.socket_idname = "NodeSocketGeometry"
	    #node Reroute.026
	    reroute_026_2 = eyebrowz.nodes.new("NodeReroute")
	    reroute_026_2.name = "Reroute.026"
	    reroute_026_2.socket_idname = "NodeSocketGeometry"
	    #node Reroute.027
	    reroute_027_2 = eyebrowz.nodes.new("NodeReroute")
	    reroute_027_2.name = "Reroute.027"
	    reroute_027_2.socket_idname = "NodeSocketGeometry"
	    #node Reroute.028
	    reroute_028_2 = eyebrowz.nodes.new("NodeReroute")
	    reroute_028_2.name = "Reroute.028"
	    reroute_028_2.socket_idname = "NodeSocketGeometry"
	    #node Reroute.029
	    reroute_029_1 = eyebrowz.nodes.new("NodeReroute")
	    reroute_029_1.name = "Reroute.029"
	    reroute_029_1.socket_idname = "NodeSocketGeometry"
	    #node Group Input.013
	    group_input_013_1 = eyebrowz.nodes.new("NodeGroupInput")
	    group_input_013_1.name = "Group Input.013"
	    group_input_013_1.outputs[0].hide = True
	    group_input_013_1.outputs[1].hide = True
	    group_input_013_1.outputs[2].hide = True
	    group_input_013_1.outputs[3].hide = True
	    group_input_013_1.outputs[4].hide = True
	    group_input_013_1.outputs[5].hide = True
	    group_input_013_1.outputs[6].hide = True
	    group_input_013_1.outputs[7].hide = True
	    group_input_013_1.outputs[8].hide = True
	    group_input_013_1.outputs[9].hide = True
	    group_input_013_1.outputs[10].hide = True
	    group_input_013_1.outputs[11].hide = True
	    group_input_013_1.outputs[12].hide = True
	    group_input_013_1.outputs[13].hide = True
	    group_input_013_1.outputs[14].hide = True
	    group_input_013_1.outputs[15].hide = True
	    group_input_013_1.outputs[16].hide = True
	    group_input_013_1.outputs[17].hide = True
	    group_input_013_1.outputs[18].hide = True
	    group_input_013_1.outputs[19].hide = True
	    group_input_013_1.outputs[20].hide = True
	    group_input_013_1.outputs[21].hide = True
	    group_input_013_1.outputs[22].hide = True
	    group_input_013_1.outputs[23].hide = True
	    group_input_013_1.outputs[25].hide = True
	    group_input_013_1.outputs[30].hide = True
	    group_input_013_1.outputs[31].hide = True
	    group_input_013_1.outputs[32].hide = True
	    group_input_013_1.outputs[33].hide = True
	    group_input_013_1.outputs[34].hide = True
	    group_input_013_1.outputs[35].hide = True
	    group_input_013_1.outputs[36].hide = True
	    group_input_013_1.outputs[37].hide = True
	    group_input_013_1.outputs[38].hide = True
	    group_input_013_1.outputs[39].hide = True
	    group_input_013_1.outputs[40].hide = True
	    group_input_013_1.outputs[41].hide = True
	    group_input_013_1.outputs[42].hide = True
	    group_input_013_1.outputs[43].hide = True
	    group_input_013_1.outputs[44].hide = True
	
	    #node Group Input.016
	    group_input_016 = eyebrowz.nodes.new("NodeGroupInput")
	    group_input_016.name = "Group Input.016"
	    group_input_016.outputs[0].hide = True
	    group_input_016.outputs[1].hide = True
	    group_input_016.outputs[3].hide = True
	    group_input_016.outputs[4].hide = True
	    group_input_016.outputs[5].hide = True
	    group_input_016.outputs[6].hide = True
	    group_input_016.outputs[7].hide = True
	    group_input_016.outputs[8].hide = True
	    group_input_016.outputs[9].hide = True
	    group_input_016.outputs[10].hide = True
	    group_input_016.outputs[11].hide = True
	    group_input_016.outputs[12].hide = True
	    group_input_016.outputs[13].hide = True
	    group_input_016.outputs[14].hide = True
	    group_input_016.outputs[15].hide = True
	    group_input_016.outputs[16].hide = True
	    group_input_016.outputs[17].hide = True
	    group_input_016.outputs[18].hide = True
	    group_input_016.outputs[19].hide = True
	    group_input_016.outputs[20].hide = True
	    group_input_016.outputs[21].hide = True
	    group_input_016.outputs[22].hide = True
	    group_input_016.outputs[23].hide = True
	    group_input_016.outputs[24].hide = True
	    group_input_016.outputs[25].hide = True
	    group_input_016.outputs[26].hide = True
	    group_input_016.outputs[27].hide = True
	    group_input_016.outputs[28].hide = True
	    group_input_016.outputs[29].hide = True
	    group_input_016.outputs[30].hide = True
	    group_input_016.outputs[31].hide = True
	    group_input_016.outputs[32].hide = True
	    group_input_016.outputs[33].hide = True
	    group_input_016.outputs[34].hide = True
	    group_input_016.outputs[35].hide = True
	    group_input_016.outputs[36].hide = True
	    group_input_016.outputs[37].hide = True
	    group_input_016.outputs[38].hide = True
	    group_input_016.outputs[39].hide = True
	    group_input_016.outputs[40].hide = True
	    group_input_016.outputs[41].hide = True
	    group_input_016.outputs[42].hide = True
	    group_input_016.outputs[43].hide = True
	    group_input_016.outputs[44].hide = True
	
	    #node Reroute.030
	    reroute_030_1 = eyebrowz.nodes.new("NodeReroute")
	    reroute_030_1.name = "Reroute.030"
	    reroute_030_1.socket_idname = "NodeSocketGeometry"
	    #node Reroute.032
	    reroute_032_1 = eyebrowz.nodes.new("NodeReroute")
	    reroute_032_1.name = "Reroute.032"
	    reroute_032_1.socket_idname = "NodeSocketGeometry"
	    #node Group.003
	    group_003_3 = eyebrowz.nodes.new("GeometryNodeGroup")
	    group_003_3.name = "Group.003"
	    group_003_3.node_tree = stylized_eyebrow
	
	    #node Reroute.033
	    reroute_033 = eyebrowz.nodes.new("NodeReroute")
	    reroute_033.name = "Reroute.033"
	    reroute_033.socket_idname = "NodeSocketGeometry"
	    #node Reroute.034
	    reroute_034 = eyebrowz.nodes.new("NodeReroute")
	    reroute_034.name = "Reroute.034"
	    reroute_034.socket_idname = "NodeSocketGeometry"
	    #node Reroute.035
	    reroute_035 = eyebrowz.nodes.new("NodeReroute")
	    reroute_035.name = "Reroute.035"
	    reroute_035.socket_idname = "NodeSocketGeometry"
	    #node Hair Style
	    hair_style = eyebrowz.nodes.new("GeometryNodeMenuSwitch")
	    hair_style.label = "Hair Style"
	    hair_style.name = "Hair Style"
	    hair_style.active_index = 3
	    hair_style.data_type = 'GEOMETRY'
	    hair_style.enum_items.clear()
	    hair_style.enum_items.new("Curve Hair")
	    hair_style.enum_items[0].description = "Curve style hair."
	    hair_style.enum_items.new("Mesh Hair")
	    hair_style.enum_items[1].description = "Convert hair to mesh."
	    hair_style.enum_items.new("Mesh Strip")
	    hair_style.enum_items[2].description = "onvert hair to mesh strip."
	    hair_style.enum_items.new("Stylized")
	    hair_style.enum_items[3].description = "Convert hair to stylized mesh."
	    hair_style.inputs[5].hide = True
	
	    #node Group.005
	    group_005_1 = eyebrowz.nodes.new("GeometryNodeGroup")
	    group_005_1.name = "Group.005"
	    group_005_1.node_tree = mesh_hair_selector
	    group_005_1.inputs[1].hide = True
	    group_005_1.inputs[5].hide = True
	    group_005_1.inputs[14].hide = True
	    #Socket_2
	    group_005_1.inputs[1].default_value = 'Hair Card'
	    #Socket_6
	    group_005_1.inputs[5].default_value = 0.0
	    #Socket_15
	    group_005_1.inputs[14].default_value = 0
	
	    #node Group Input.017
	    group_input_017 = eyebrowz.nodes.new("NodeGroupInput")
	    group_input_017.name = "Group Input.017"
	    group_input_017.outputs[0].hide = True
	    group_input_017.outputs[1].hide = True
	    group_input_017.outputs[2].hide = True
	    group_input_017.outputs[3].hide = True
	    group_input_017.outputs[4].hide = True
	    group_input_017.outputs[5].hide = True
	    group_input_017.outputs[6].hide = True
	    group_input_017.outputs[7].hide = True
	    group_input_017.outputs[8].hide = True
	    group_input_017.outputs[9].hide = True
	    group_input_017.outputs[10].hide = True
	    group_input_017.outputs[11].hide = True
	    group_input_017.outputs[12].hide = True
	    group_input_017.outputs[13].hide = True
	    group_input_017.outputs[14].hide = True
	    group_input_017.outputs[15].hide = True
	    group_input_017.outputs[16].hide = True
	    group_input_017.outputs[17].hide = True
	    group_input_017.outputs[18].hide = True
	    group_input_017.outputs[19].hide = True
	    group_input_017.outputs[20].hide = True
	    group_input_017.outputs[21].hide = True
	    group_input_017.outputs[22].hide = True
	    group_input_017.outputs[23].hide = True
	    group_input_017.outputs[25].hide = True
	    group_input_017.outputs[36].hide = True
	    group_input_017.outputs[37].hide = True
	    group_input_017.outputs[38].hide = True
	    group_input_017.outputs[39].hide = True
	    group_input_017.outputs[40].hide = True
	    group_input_017.outputs[41].hide = True
	    group_input_017.outputs[42].hide = True
	    group_input_017.outputs[43].hide = True
	    group_input_017.outputs[44].hide = True
	
	    #node Reroute.036
	    reroute_036 = eyebrowz.nodes.new("NodeReroute")
	    reroute_036.name = "Reroute.036"
	    reroute_036.socket_idname = "NodeSocketGeometry"
	    #node Reroute.037
	    reroute_037 = eyebrowz.nodes.new("NodeReroute")
	    reroute_037.name = "Reroute.037"
	    reroute_037.socket_idname = "NodeSocketGeometry"
	    #node Reroute.039
	    reroute_039 = eyebrowz.nodes.new("NodeReroute")
	    reroute_039.name = "Reroute.039"
	    reroute_039.socket_idname = "NodeSocketGeometry"
	    #node Reroute.040
	    reroute_040 = eyebrowz.nodes.new("NodeReroute")
	    reroute_040.name = "Reroute.040"
	    reroute_040.socket_idname = "NodeSocketGeometry"
	    #node Curve Bake
	    curve_bake = eyebrowz.nodes.new("GeometryNodeBake")
	    curve_bake.label = "Curve Bake"
	    curve_bake.name = "Curve Bake"
	    curve_bake.active_index = 0
	    curve_bake.bake_items.clear()
	    curve_bake.bake_items.new('GEOMETRY', "Geometry")
	    curve_bake.bake_items[0].attribute_domain = 'POINT'
	    curve_bake.inputs[1].hide = True
	    curve_bake.outputs[1].hide = True
	
	    #node Group Input.018
	    group_input_018 = eyebrowz.nodes.new("NodeGroupInput")
	    group_input_018.name = "Group Input.018"
	    group_input_018.outputs[0].hide = True
	    group_input_018.outputs[1].hide = True
	    group_input_018.outputs[2].hide = True
	    group_input_018.outputs[3].hide = True
	    group_input_018.outputs[5].hide = True
	    group_input_018.outputs[6].hide = True
	    group_input_018.outputs[7].hide = True
	    group_input_018.outputs[8].hide = True
	    group_input_018.outputs[9].hide = True
	    group_input_018.outputs[10].hide = True
	    group_input_018.outputs[11].hide = True
	    group_input_018.outputs[12].hide = True
	    group_input_018.outputs[13].hide = True
	    group_input_018.outputs[14].hide = True
	    group_input_018.outputs[16].hide = True
	    group_input_018.outputs[17].hide = True
	    group_input_018.outputs[18].hide = True
	    group_input_018.outputs[19].hide = True
	    group_input_018.outputs[20].hide = True
	    group_input_018.outputs[21].hide = True
	    group_input_018.outputs[22].hide = True
	    group_input_018.outputs[23].hide = True
	    group_input_018.outputs[24].hide = True
	    group_input_018.outputs[25].hide = True
	    group_input_018.outputs[26].hide = True
	    group_input_018.outputs[27].hide = True
	    group_input_018.outputs[28].hide = True
	    group_input_018.outputs[29].hide = True
	    group_input_018.outputs[30].hide = True
	    group_input_018.outputs[31].hide = True
	    group_input_018.outputs[32].hide = True
	    group_input_018.outputs[33].hide = True
	    group_input_018.outputs[34].hide = True
	    group_input_018.outputs[35].hide = True
	    group_input_018.outputs[44].hide = True
	
	    #node Reroute.031
	    reroute_031 = eyebrowz.nodes.new("NodeReroute")
	    reroute_031.name = "Reroute.031"
	    reroute_031.socket_idname = "NodeSocketGeometry"
	    #node Reroute.038
	    reroute_038 = eyebrowz.nodes.new("NodeReroute")
	    reroute_038.name = "Reroute.038"
	    reroute_038.socket_idname = "NodeSocketGeometry"
	    #node Stylized Bake
	    stylized_bake = eyebrowz.nodes.new("GeometryNodeBake")
	    stylized_bake.label = "Stylized Bake"
	    stylized_bake.name = "Stylized Bake"
	    stylized_bake.active_index = 0
	    stylized_bake.bake_items.clear()
	    stylized_bake.bake_items.new('GEOMETRY', "Geometry")
	    stylized_bake.bake_items[0].attribute_domain = 'POINT'
	    stylized_bake.inputs[1].hide = True
	    stylized_bake.outputs[1].hide = True
	
	    #node Set Position.005
	    set_position_005 = eyebrowz.nodes.new("GeometryNodeSetPosition")
	    set_position_005.name = "Set Position.005"
	    set_position_005.hide = True
	    #Selection
	    set_position_005.inputs[1].default_value = True
	    #Offset
	    set_position_005.inputs[3].default_value = (0.0, 0.0, 0.0)
	
	    #node Vector Math.003
	    vector_math_003_5 = eyebrowz.nodes.new("ShaderNodeVectorMath")
	    vector_math_003_5.name = "Vector Math.003"
	    vector_math_003_5.hide = True
	    vector_math_003_5.operation = 'MULTIPLY'
	    #Vector_001
	    vector_math_003_5.inputs[1].default_value = (-1.0, 1.0, 1.0)
	
	    #node Capture Attribute.002
	    capture_attribute_002_8 = eyebrowz.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_002_8.name = "Capture Attribute.002"
	    capture_attribute_002_8.hide = True
	    capture_attribute_002_8.active_index = 0
	    capture_attribute_002_8.capture_items.clear()
	    capture_attribute_002_8.capture_items.new('FLOAT', "Position")
	    capture_attribute_002_8.capture_items["Position"].data_type = 'FLOAT_VECTOR'
	    capture_attribute_002_8.domain = 'POINT'
	
	    #node Position.003
	    position_003 = eyebrowz.nodes.new("GeometryNodeInputPosition")
	    position_003.name = "Position.003"
	    position_003.hide = True
	
	    #node Switch.004
	    switch_004_4 = eyebrowz.nodes.new("GeometryNodeSwitch")
	    switch_004_4.name = "Switch.004"
	    switch_004_4.hide = True
	    switch_004_4.input_type = 'GEOMETRY'
	
	    #node Join Geometry.003
	    join_geometry_003_1 = eyebrowz.nodes.new("GeometryNodeJoinGeometry")
	    join_geometry_003_1.name = "Join Geometry.003"
	    join_geometry_003_1.hide = True
	
	    #node Frame.003
	    frame_003_4 = eyebrowz.nodes.new("NodeFrame")
	    frame_003_4.label = "Mirror"
	    frame_003_4.name = "Frame.003"
	    frame_003_4.label_size = 20
	    frame_003_4.shrink = True
	
	    #node Group Input.019
	    group_input_019 = eyebrowz.nodes.new("NodeGroupInput")
	    group_input_019.name = "Group Input.019"
	    group_input_019.outputs[0].hide = True
	    group_input_019.outputs[1].hide = True
	    group_input_019.outputs[2].hide = True
	    group_input_019.outputs[3].hide = True
	    group_input_019.outputs[4].hide = True
	    group_input_019.outputs[5].hide = True
	    group_input_019.outputs[6].hide = True
	    group_input_019.outputs[7].hide = True
	    group_input_019.outputs[8].hide = True
	    group_input_019.outputs[9].hide = True
	    group_input_019.outputs[10].hide = True
	    group_input_019.outputs[11].hide = True
	    group_input_019.outputs[13].hide = True
	    group_input_019.outputs[14].hide = True
	    group_input_019.outputs[15].hide = True
	    group_input_019.outputs[16].hide = True
	    group_input_019.outputs[17].hide = True
	    group_input_019.outputs[18].hide = True
	    group_input_019.outputs[19].hide = True
	    group_input_019.outputs[20].hide = True
	    group_input_019.outputs[21].hide = True
	    group_input_019.outputs[22].hide = True
	    group_input_019.outputs[23].hide = True
	    group_input_019.outputs[24].hide = True
	    group_input_019.outputs[25].hide = True
	    group_input_019.outputs[26].hide = True
	    group_input_019.outputs[27].hide = True
	    group_input_019.outputs[28].hide = True
	    group_input_019.outputs[29].hide = True
	    group_input_019.outputs[30].hide = True
	    group_input_019.outputs[31].hide = True
	    group_input_019.outputs[32].hide = True
	    group_input_019.outputs[33].hide = True
	    group_input_019.outputs[34].hide = True
	    group_input_019.outputs[35].hide = True
	    group_input_019.outputs[36].hide = True
	    group_input_019.outputs[37].hide = True
	    group_input_019.outputs[38].hide = True
	    group_input_019.outputs[39].hide = True
	    group_input_019.outputs[40].hide = True
	    group_input_019.outputs[41].hide = True
	    group_input_019.outputs[42].hide = True
	    group_input_019.outputs[43].hide = True
	    group_input_019.outputs[44].hide = True
	
	    #node Reroute.041
	    reroute_041 = eyebrowz.nodes.new("NodeReroute")
	    reroute_041.name = "Reroute.041"
	    reroute_041.socket_idname = "NodeSocketGeometry"
	    #node Reroute.042
	    reroute_042 = eyebrowz.nodes.new("NodeReroute")
	    reroute_042.name = "Reroute.042"
	    reroute_042.socket_idname = "NodeSocketGeometry"
	    #node Reroute.043
	    reroute_043 = eyebrowz.nodes.new("NodeReroute")
	    reroute_043.name = "Reroute.043"
	    reroute_043.socket_idname = "NodeSocketGeometry"
	    #node Reroute.044
	    reroute_044 = eyebrowz.nodes.new("NodeReroute")
	    reroute_044.name = "Reroute.044"
	    reroute_044.socket_idname = "NodeSocketGeometry"
	    #node Reroute.045
	    reroute_045 = eyebrowz.nodes.new("NodeReroute")
	    reroute_045.name = "Reroute.045"
	    reroute_045.socket_idname = "NodeSocketGeometry"
	    #node Reroute.046
	    reroute_046 = eyebrowz.nodes.new("NodeReroute")
	    reroute_046.name = "Reroute.046"
	    reroute_046.socket_idname = "NodeSocketGeometry"
	    #node Reroute.047
	    reroute_047 = eyebrowz.nodes.new("NodeReroute")
	    reroute_047.name = "Reroute.047"
	    reroute_047.socket_idname = "NodeSocketGeometry"
	    #node Reroute.048
	    reroute_048 = eyebrowz.nodes.new("NodeReroute")
	    reroute_048.name = "Reroute.048"
	    reroute_048.socket_idname = "NodeSocketGeometry"
	    #node Reroute.049
	    reroute_049 = eyebrowz.nodes.new("NodeReroute")
	    reroute_049.name = "Reroute.049"
	    reroute_049.socket_idname = "NodeSocketGeometry"
	    #node Set Material.001
	    set_material_001 = eyebrowz.nodes.new("GeometryNodeSetMaterial")
	    set_material_001.name = "Set Material.001"
	    set_material_001.hide = True
	    set_material_001.inputs[1].hide = True
	    #Selection
	    set_material_001.inputs[1].default_value = True
	
	    #node Group Input.020
	    group_input_020 = eyebrowz.nodes.new("NodeGroupInput")
	    group_input_020.name = "Group Input.020"
	    group_input_020.outputs[0].hide = True
	    group_input_020.outputs[1].hide = True
	    group_input_020.outputs[2].hide = True
	    group_input_020.outputs[3].hide = True
	    group_input_020.outputs[4].hide = True
	    group_input_020.outputs[5].hide = True
	    group_input_020.outputs[6].hide = True
	    group_input_020.outputs[7].hide = True
	    group_input_020.outputs[8].hide = True
	    group_input_020.outputs[9].hide = True
	    group_input_020.outputs[10].hide = True
	    group_input_020.outputs[11].hide = True
	    group_input_020.outputs[12].hide = True
	    group_input_020.outputs[13].hide = True
	    group_input_020.outputs[14].hide = True
	    group_input_020.outputs[15].hide = True
	    group_input_020.outputs[16].hide = True
	    group_input_020.outputs[17].hide = True
	    group_input_020.outputs[18].hide = True
	    group_input_020.outputs[19].hide = True
	    group_input_020.outputs[20].hide = True
	    group_input_020.outputs[21].hide = True
	    group_input_020.outputs[22].hide = True
	    group_input_020.outputs[23].hide = True
	    group_input_020.outputs[25].hide = True
	    group_input_020.outputs[26].hide = True
	    group_input_020.outputs[27].hide = True
	    group_input_020.outputs[28].hide = True
	    group_input_020.outputs[29].hide = True
	    group_input_020.outputs[30].hide = True
	    group_input_020.outputs[31].hide = True
	    group_input_020.outputs[32].hide = True
	    group_input_020.outputs[33].hide = True
	    group_input_020.outputs[34].hide = True
	    group_input_020.outputs[35].hide = True
	    group_input_020.outputs[36].hide = True
	    group_input_020.outputs[37].hide = True
	    group_input_020.outputs[38].hide = True
	    group_input_020.outputs[39].hide = True
	    group_input_020.outputs[40].hide = True
	    group_input_020.outputs[41].hide = True
	    group_input_020.outputs[42].hide = True
	    group_input_020.outputs[43].hide = True
	    group_input_020.outputs[44].hide = True
	
	    #node Set Curve Radius.001
	    set_curve_radius_001 = eyebrowz.nodes.new("GeometryNodeSetCurveRadius")
	    set_curve_radius_001.name = "Set Curve Radius.001"
	    set_curve_radius_001.hide = True
	    #Selection
	    set_curve_radius_001.inputs[1].default_value = True
	
	    #node Switch
	    switch_11 = eyebrowz.nodes.new("GeometryNodeSwitch")
	    switch_11.name = "Switch"
	    switch_11.hide = True
	    switch_11.input_type = 'GEOMETRY'
	
	    #node Compare.001
	    compare_001_5 = eyebrowz.nodes.new("FunctionNodeCompare")
	    compare_001_5.name = "Compare.001"
	    compare_001_5.hide = True
	    compare_001_5.data_type = 'INT'
	    compare_001_5.mode = 'ELEMENT'
	    compare_001_5.operation = 'NOT_EQUAL'
	    compare_001_5.inputs[0].hide = True
	    compare_001_5.inputs[1].hide = True
	    compare_001_5.inputs[3].hide = True
	    compare_001_5.inputs[4].hide = True
	    compare_001_5.inputs[5].hide = True
	    compare_001_5.inputs[6].hide = True
	    compare_001_5.inputs[7].hide = True
	    compare_001_5.inputs[8].hide = True
	    compare_001_5.inputs[9].hide = True
	    compare_001_5.inputs[10].hide = True
	    compare_001_5.inputs[11].hide = True
	    compare_001_5.inputs[12].hide = True
	    #B_INT
	    compare_001_5.inputs[3].default_value = 0
	
	    #node Switch.001
	    switch_001_8 = eyebrowz.nodes.new("GeometryNodeSwitch")
	    switch_001_8.name = "Switch.001"
	    switch_001_8.hide = True
	    switch_001_8.input_type = 'GEOMETRY'
	
	    #node Group Input.021
	    group_input_021 = eyebrowz.nodes.new("NodeGroupInput")
	    group_input_021.name = "Group Input.021"
	    group_input_021.outputs[0].hide = True
	    group_input_021.outputs[1].hide = True
	    group_input_021.outputs[2].hide = True
	    group_input_021.outputs[3].hide = True
	    group_input_021.outputs[4].hide = True
	    group_input_021.outputs[5].hide = True
	    group_input_021.outputs[6].hide = True
	    group_input_021.outputs[7].hide = True
	    group_input_021.outputs[8].hide = True
	    group_input_021.outputs[9].hide = True
	    group_input_021.outputs[10].hide = True
	    group_input_021.outputs[11].hide = True
	    group_input_021.outputs[12].hide = True
	    group_input_021.outputs[13].hide = True
	    group_input_021.outputs[14].hide = True
	    group_input_021.outputs[15].hide = True
	    group_input_021.outputs[16].hide = True
	    group_input_021.outputs[17].hide = True
	    group_input_021.outputs[18].hide = True
	    group_input_021.outputs[19].hide = True
	    group_input_021.outputs[21].hide = True
	    group_input_021.outputs[22].hide = True
	    group_input_021.outputs[23].hide = True
	    group_input_021.outputs[24].hide = True
	    group_input_021.outputs[25].hide = True
	    group_input_021.outputs[26].hide = True
	    group_input_021.outputs[27].hide = True
	    group_input_021.outputs[28].hide = True
	    group_input_021.outputs[29].hide = True
	    group_input_021.outputs[30].hide = True
	    group_input_021.outputs[31].hide = True
	    group_input_021.outputs[32].hide = True
	    group_input_021.outputs[33].hide = True
	    group_input_021.outputs[34].hide = True
	    group_input_021.outputs[35].hide = True
	    group_input_021.outputs[36].hide = True
	    group_input_021.outputs[37].hide = True
	    group_input_021.outputs[38].hide = True
	    group_input_021.outputs[39].hide = True
	    group_input_021.outputs[40].hide = True
	    group_input_021.outputs[41].hide = True
	    group_input_021.outputs[42].hide = True
	    group_input_021.outputs[43].hide = True
	    group_input_021.outputs[44].hide = True
	
	    #node Reroute.050
	    reroute_050 = eyebrowz.nodes.new("NodeReroute")
	    reroute_050.name = "Reroute.050"
	    reroute_050.socket_idname = "NodeSocketGeometry"
	    #node Set Curve Tilt.002
	    set_curve_tilt_002 = eyebrowz.nodes.new("GeometryNodeSetCurveTilt")
	    set_curve_tilt_002.name = "Set Curve Tilt.002"
	    set_curve_tilt_002.hide = True
	    set_curve_tilt_002.inputs[1].hide = True
	    #Selection
	    set_curve_tilt_002.inputs[1].default_value = True
	
	    #node Group Input.008
	    group_input_008_4 = eyebrowz.nodes.new("NodeGroupInput")
	    group_input_008_4.name = "Group Input.008"
	    group_input_008_4.outputs[0].hide = True
	    group_input_008_4.outputs[1].hide = True
	    group_input_008_4.outputs[2].hide = True
	    group_input_008_4.outputs[3].hide = True
	    group_input_008_4.outputs[4].hide = True
	    group_input_008_4.outputs[5].hide = True
	    group_input_008_4.outputs[6].hide = True
	    group_input_008_4.outputs[7].hide = True
	    group_input_008_4.outputs[8].hide = True
	    group_input_008_4.outputs[9].hide = True
	    group_input_008_4.outputs[10].hide = True
	    group_input_008_4.outputs[11].hide = True
	    group_input_008_4.outputs[12].hide = True
	    group_input_008_4.outputs[13].hide = True
	    group_input_008_4.outputs[14].hide = True
	    group_input_008_4.outputs[15].hide = True
	    group_input_008_4.outputs[16].hide = True
	    group_input_008_4.outputs[17].hide = True
	    group_input_008_4.outputs[18].hide = True
	    group_input_008_4.outputs[19].hide = True
	    group_input_008_4.outputs[20].hide = True
	    group_input_008_4.outputs[21].hide = True
	    group_input_008_4.outputs[22].hide = True
	    group_input_008_4.outputs[23].hide = True
	    group_input_008_4.outputs[24].hide = True
	    group_input_008_4.outputs[26].hide = True
	    group_input_008_4.outputs[27].hide = True
	    group_input_008_4.outputs[28].hide = True
	    group_input_008_4.outputs[29].hide = True
	    group_input_008_4.outputs[30].hide = True
	    group_input_008_4.outputs[31].hide = True
	    group_input_008_4.outputs[32].hide = True
	    group_input_008_4.outputs[33].hide = True
	    group_input_008_4.outputs[34].hide = True
	    group_input_008_4.outputs[35].hide = True
	    group_input_008_4.outputs[36].hide = True
	    group_input_008_4.outputs[37].hide = True
	    group_input_008_4.outputs[38].hide = True
	    group_input_008_4.outputs[39].hide = True
	    group_input_008_4.outputs[40].hide = True
	    group_input_008_4.outputs[41].hide = True
	    group_input_008_4.outputs[42].hide = True
	    group_input_008_4.outputs[43].hide = True
	    group_input_008_4.outputs[44].hide = True
	
	
	
	
	    #Set parents
	    set_position_003.parent = frame_001_4
	    vector_math_001_5.parent = frame_001_4
	    capture_attribute_9.parent = frame_001_4
	    position_001_3.parent = frame_001_4
	    set_position_004.parent = frame_002_5
	    vector_math_002_4.parent = frame_002_5
	    capture_attribute_001_5.parent = frame_002_5
	    position_002_4.parent = frame_002_5
	    set_position_005.parent = frame_003_4
	    vector_math_003_5.parent = frame_003_4
	    capture_attribute_002_8.parent = frame_003_4
	    position_003.parent = frame_003_4
	
	    #Set locations
	    group_output_15.location = (3367.49365234375, 439.5181884765625)
	    group_input_11.location = (-401.00128173828125, 0.0)
	    curve_to_points_1.location = (-150.20706176757812, -32.377967834472656)
	    instance_on_points.location = (45.18135070800781, -30.38379669189453)
	    curve_line_1.location = (-150.07435607910156, -136.7882843017578)
	    resample_curve_4.location = (-149.50802612304688, -83.79814910888672)
	    realize_instances.location = (46.41802978515625, 8.918266296386719)
	    group_004.location = (222.91265869140625, -144.84835815429688)
	    object_info_1.location = (-87.6217041015625, 619.7703247070312)
	    geometry_proximity.location = (404.23297119140625, 171.2868194580078)
	    set_position_001_4.location = (412.236083984375, 20.879295349121094)
	    endpoint_selection_001.location = (408.2547607421875, -105.69692993164062)
	    boolean_math_001_1.location = (411.8514404296875, -66.89053344726562)
	    compare_10.location = (405.0015869140625, 133.026123046875)
	    set_position_002_2.location = (411.43450927734375, -29.49276351928711)
	    sample_nearest.location = (152.5193634033203, 569.088134765625)
	    sample_index_003_1.location = (152.35791015625, 622.06494140625)
	    normal_2.location = (152.17245483398438, 683.146484375)
	    vector_math_005_3.location = (152.79736328125, 529.513671875)
	    surface_offset_curve.location = (55.732177734375, 403.81671142578125)
	    spline_parameter_8.location = (49.612060546875, 77.83245849609375)
	    map_range_2.location = (153.997314453125, 434.94158935546875)
	    vector_rotate_001.location = (-150.1345977783203, -171.3663787841797)
	    vector.location = (-149.5225372314453, -208.39234924316406)
	    group_input_001_11.location = (-89.361328125, 584.8660888671875)
	    group_input_002_10.location = (407.14984130859375, 101.38282012939453)
	    group_input_003_11.location = (155.372802734375, 498.54559326171875)
	    group_input_004_10.location = (37.407470703125, -213.49014282226562)
	    reroute_11.location = (89.8967056274414, 609.0923461914062)
	    reroute_001_10.location = (90.9754867553711, 692.4959716796875)
	    reroute_002_8.location = (394.78851318359375, 690.1414184570312)
	    separate_components_3.location = (-398.9849853515625, -178.14234924316406)
	    trim_curve.location = (672.8721313476562, 223.92095947265625)
	    reroute_004_8.location = (597.5589599609375, -28.276142120361328)
	    trim_factor.location = (426.84283447265625, 546.32373046875)
	    spline_parameter_001_1.location = (420.72271728515625, 252.930419921875)
	    group_6.location = (989.2015380859375, 270.7536315917969)
	    clump_factor.location = (685.9295654296875, 631.9238891601562)
	    spline_parameter_002.location = (679.8094482421875, 305.9395751953125)
	    group_001_6.location = (673.9713134765625, 53.213165283203125)
	    group_input_005_8.location = (673.7459716796875, -93.05206298828125)
	    named_attribute_4.location = (676.3417358398438, -177.8634490966797)
	    tip_spread_factor.location = (892.1810302734375, 51.058921813964844)
	    spline_parameter_003.location = (886.0609130859375, -243.96392822265625)
	    map_range_001_2.location = (991.950927734375, 79.3479232788086)
	    group_input_006_6.location = (825.677734375, 177.87503051757812)
	    group_input_007_5.location = (675.8412475585938, -211.97259521484375)
	    set_material_4.location = (1763.8497314453125, 679.5970458984375)
	    set_position_003.location = (355.629638671875, -49.46734619140625)
	    vector_math_001_5.location = (197.36328125, -55.79888916015625)
	    capture_attribute_9.location = (33.89892578125, -44.80670166015625)
	    position_001_3.location = (29.630126953125, -81.87371826171875)
	    switch_002_6.location = (1570.5758056640625, 630.820556640625)
	    join_geometry_001_3.location = (1576.6544189453125, 590.8935546875)
	    frame_001_4.location = (1223.0, 498.0)
	    group_input_011_1.location = (1572.2423095703125, 715.3984375)
	    reroute_012_6.location = (1388.6539306640625, 621.7445068359375)
	    reroute_013_6.location = (1260.718017578125, 516.5965576171875)
	    reroute_014_6.location = (1718.2969970703125, 515.3675537109375)
	    reroute_015_6.location = (1390.8585205078125, 516.0096435546875)
	    reroute_016_6.location = (1579.6280517578125, 516.0029296875)
	    reroute_017_5.location = (1389.3394775390625, 583.2017822265625)
	    hair_shape.location = (-395.97772216796875, 419.3523864746094)
	    spline_parameter_004.location = (-396.62713623046875, 124.24644470214844)
	    map_range_002.location = (-291.46478271484375, 449.1122741699219)
	    group_input_014.location = (-289.5763244628906, 509.6662292480469)
	    eyebrow_bake.location = (3187.16064453125, 485.11322021484375)
	    join_geometry_4.location = (3013.1640625, 437.57696533203125)
	    reroute_003_8.location = (-116.9547119140625, -422.2505798339844)
	    reroute_005_7.location = (-116.9547119140625, -416.8775939941406)
	    reroute_006_6.location = (-116.9547119140625, -437.7381286621094)
	    reroute_007_6.location = (-116.9547119140625, -427.41302490234375)
	    reroute_008_6.location = (-116.9547119140625, -432.5754699707031)
	    reroute_009_6.location = (2721.846435546875, -423.9959716796875)
	    reroute_010_4.location = (2722.455078125, -428.99688720703125)
	    reroute_011_5.location = (2724.083740234375, -438.9986572265625)
	    reroute_018_5.location = (2722.978759765625, -433.9975891113281)
	    reroute_019_4.location = (2720.826416015625, -418.9939880371094)
	    set_curve_tilt_1.location = (-144.78726196289062, 116.5240249633789)
	    reroute_020_4.location = (-186.42030334472656, 57.141822814941406)
	    group_input_015.location = (-396.56549072265625, 62.12841033935547)
	    group_002_2.location = (1378.447998046875, -28.643516540527344)
	    set_curve_tilt_001.location = (1184.250732421875, -100.95759582519531)
	    set_position_004.location = (356.1005859375, -49.660247802734375)
	    vector_math_002_4.location = (197.8338623046875, -55.991180419921875)
	    capture_attribute_001_5.location = (34.368896484375, -44.997894287109375)
	    position_002_4.location = (30.100341796875, -82.06527709960938)
	    switch_003_7.location = (1737.25341796875, -141.29742431640625)
	    join_geometry_002.location = (1743.33203125, -181.22442626953125)
	    frame_002_5.location = (1388.0, -272.0)
	    group_input_012_1.location = (1738.919921875, -77.30934143066406)
	    reroute_021_2.location = (1555.33154296875, -150.37347412109375)
	    reroute_022_2.location = (1427.395751953125, -255.52142333984375)
	    reroute_023_2.location = (1884.974853515625, -256.75042724609375)
	    reroute_024_2.location = (1557.5361328125, -256.10833740234375)
	    reroute_025_1.location = (1746.3056640625, -256.11505126953125)
	    reroute_026_2.location = (1556.01708984375, -188.91619873046875)
	    reroute_027_2.location = (-186.91749572753906, -472.45562744140625)
	    reroute_028_2.location = (1154.6026611328125, -475.62457275390625)
	    reroute_029_1.location = (1153.774658203125, -110.63272857666016)
	    group_input_013_1.location = (1183.4775390625, -130.84156799316406)
	    group_input_016.location = (2770.929931640625, 481.2214050292969)
	    reroute_030_1.location = (1557.284423828125, -63.87158203125)
	    reroute_032_1.location = (1878.28955078125, 263.0559387207031)
	    group_003_3.location = (2181.1787109375, 213.67979431152344)
	    reroute_033.location = (1164.043212890625, 329.57440185546875)
	    reroute_034.location = (1162.3597412109375, 619.765380859375)
	    reroute_035.location = (1365.714111328125, 341.8072509765625)
	    hair_style.location = (2770.148681640625, 416.0685119628906)
	    group_005_1.location = (1715.1204833984375, 323.41522216796875)
	    group_input_017.location = (1523.5172119140625, 233.0085906982422)
	    reroute_036.location = (1907.7874755859375, 345.6775207519531)
	    reroute_037.location = (1365.65234375, 248.43447875976562)
	    reroute_039.location = (1970.0830078125, -476.92535400390625)
	    reroute_040.location = (1959.98193359375, 129.4922332763672)
	    curve_bake.location = (1204.22412109375, 704.1180419921875)
	    group_input_018.location = (1982.9913330078125, 108.35685729980469)
	    reroute_031.location = (2138.15478515625, 646.4840698242188)
	    reroute_038.location = (2154.4091796875, 109.47624969482422)
	    stylized_bake.location = (2551.19140625, 261.07537841796875)
	    set_position_005.location = (356.119140625, -49.289276123046875)
	    vector_math_003_5.location = (197.85107421875, -55.620208740234375)
	    capture_attribute_002_8.location = (34.380615234375, -44.626922607421875)
	    position_003.location = (30.112548828125, -81.69430541992188)
	    switch_004_4.location = (2535.259033203125, -141.29742431640625)
	    join_geometry_003_1.location = (2541.337646484375, -181.22442626953125)
	    frame_003_4.location = (2186.0, -272.0)
	    group_input_019.location = (2533.558349609375, -77.30934143066406)
	    reroute_041.location = (2353.337158203125, -150.37347412109375)
	    reroute_042.location = (2225.4013671875, -255.52142333984375)
	    reroute_043.location = (2682.980712890625, -256.75042724609375)
	    reroute_044.location = (2355.541748046875, -256.10833740234375)
	    reroute_045.location = (2544.311279296875, -256.11505126953125)
	    reroute_046.location = (2354.022705078125, -188.91619873046875)
	    reroute_047.location = (2347.748046875, 180.044189453125)
	    reroute_048.location = (2674.392578125, -49.40781784057617)
	    reroute_049.location = (2392.123291015625, -49.762001037597656)
	    set_material_001.location = (2385.86083984375, 188.8249969482422)
	    group_input_020.location = (2390.412841796875, 157.2073516845703)
	    set_curve_radius_001.location = (44.32234191894531, -79.06037139892578)
	    switch_11.location = (226.32394409179688, -77.48499298095703)
	    compare_001_5.location = (224.64048767089844, -42.32482147216797)
	    switch_001_8.location = (990.6397705078125, 338.5754699707031)
	    group_input_021.location = (988.96728515625, 402.38836669921875)
	    reroute_050.location = (-186.62442016601562, -192.94268798828125)
	    set_curve_tilt_002.location = (1380.3489990234375, 251.17852783203125)
	    group_input_008_4.location = (1377.871826171875, 218.30213928222656)
	
	    #Set dimensions
	    group_output_15.width, group_output_15.height = 140.0, 100.0
	    group_input_11.width, group_input_11.height = 140.0, 100.0
	    curve_to_points_1.width, curve_to_points_1.height = 140.0, 100.0
	    instance_on_points.width, instance_on_points.height = 140.0, 100.0
	    curve_line_1.width, curve_line_1.height = 140.0, 100.0
	    resample_curve_4.width, resample_curve_4.height = 140.0, 100.0
	    realize_instances.width, realize_instances.height = 140.0, 100.0
	    group_004.width, group_004.height = 140.0, 100.0
	    object_info_1.width, object_info_1.height = 140.0, 100.0
	    geometry_proximity.width, geometry_proximity.height = 140.0, 100.0
	    set_position_001_4.width, set_position_001_4.height = 140.0, 100.0
	    endpoint_selection_001.width, endpoint_selection_001.height = 140.0, 100.0
	    boolean_math_001_1.width, boolean_math_001_1.height = 140.0, 100.0
	    compare_10.width, compare_10.height = 140.0, 100.0
	    set_position_002_2.width, set_position_002_2.height = 140.0, 100.0
	    sample_nearest.width, sample_nearest.height = 140.0, 100.0
	    sample_index_003_1.width, sample_index_003_1.height = 140.0, 100.0
	    normal_2.width, normal_2.height = 140.0, 100.0
	    vector_math_005_3.width, vector_math_005_3.height = 140.0, 100.0
	    surface_offset_curve.width, surface_offset_curve.height = 240.0, 100.0
	    spline_parameter_8.width, spline_parameter_8.height = 140.0, 100.0
	    map_range_2.width, map_range_2.height = 140.0, 100.0
	    vector_rotate_001.width, vector_rotate_001.height = 140.0, 100.0
	    vector.width, vector.height = 140.0, 100.0
	    group_input_001_11.width, group_input_001_11.height = 140.0, 100.0
	    group_input_002_10.width, group_input_002_10.height = 140.0, 100.0
	    group_input_003_11.width, group_input_003_11.height = 140.0, 100.0
	    group_input_004_10.width, group_input_004_10.height = 140.0, 100.0
	    reroute_11.width, reroute_11.height = 10.0, 100.0
	    reroute_001_10.width, reroute_001_10.height = 10.0, 100.0
	    reroute_002_8.width, reroute_002_8.height = 10.0, 100.0
	    separate_components_3.width, separate_components_3.height = 140.0, 100.0
	    trim_curve.width, trim_curve.height = 140.0, 100.0
	    reroute_004_8.width, reroute_004_8.height = 10.0, 100.0
	    trim_factor.width, trim_factor.height = 240.0, 100.0
	    spline_parameter_001_1.width, spline_parameter_001_1.height = 140.0, 100.0
	    group_6.width, group_6.height = 140.0, 100.0
	    clump_factor.width, clump_factor.height = 240.0, 100.0
	    spline_parameter_002.width, spline_parameter_002.height = 140.0, 100.0
	    group_001_6.width, group_001_6.height = 140.0, 100.0
	    group_input_005_8.width, group_input_005_8.height = 140.0, 100.0
	    named_attribute_4.width, named_attribute_4.height = 140.0, 100.0
	    tip_spread_factor.width, tip_spread_factor.height = 240.0, 100.0
	    spline_parameter_003.width, spline_parameter_003.height = 140.0, 100.0
	    map_range_001_2.width, map_range_001_2.height = 140.0, 100.0
	    group_input_006_6.width, group_input_006_6.height = 140.0, 100.0
	    group_input_007_5.width, group_input_007_5.height = 140.0, 100.0
	    set_material_4.width, set_material_4.height = 140.0, 100.0
	    set_position_003.width, set_position_003.height = 140.0, 100.0
	    vector_math_001_5.width, vector_math_001_5.height = 140.0, 100.0
	    capture_attribute_9.width, capture_attribute_9.height = 140.0, 100.0
	    position_001_3.width, position_001_3.height = 140.0, 100.0
	    switch_002_6.width, switch_002_6.height = 140.0, 100.0
	    join_geometry_001_3.width, join_geometry_001_3.height = 140.0, 100.0
	    frame_001_4.width, frame_001_4.height = 526.0, 137.0
	    group_input_011_1.width, group_input_011_1.height = 140.0, 100.0
	    reroute_012_6.width, reroute_012_6.height = 10.0, 100.0
	    reroute_013_6.width, reroute_013_6.height = 10.0, 100.0
	    reroute_014_6.width, reroute_014_6.height = 10.0, 100.0
	    reroute_015_6.width, reroute_015_6.height = 10.0, 100.0
	    reroute_016_6.width, reroute_016_6.height = 10.0, 100.0
	    reroute_017_5.width, reroute_017_5.height = 10.0, 100.0
	    hair_shape.width, hair_shape.height = 240.0, 100.0
	    spline_parameter_004.width, spline_parameter_004.height = 140.0, 100.0
	    map_range_002.width, map_range_002.height = 140.0, 100.0
	    group_input_014.width, group_input_014.height = 140.0, 100.0
	    eyebrow_bake.width, eyebrow_bake.height = 140.0, 100.0
	    join_geometry_4.width, join_geometry_4.height = 140.0, 100.0
	    reroute_003_8.width, reroute_003_8.height = 10.0, 100.0
	    reroute_005_7.width, reroute_005_7.height = 10.0, 100.0
	    reroute_006_6.width, reroute_006_6.height = 10.0, 100.0
	    reroute_007_6.width, reroute_007_6.height = 10.0, 100.0
	    reroute_008_6.width, reroute_008_6.height = 10.0, 100.0
	    reroute_009_6.width, reroute_009_6.height = 10.0, 100.0
	    reroute_010_4.width, reroute_010_4.height = 10.0, 100.0
	    reroute_011_5.width, reroute_011_5.height = 10.0, 100.0
	    reroute_018_5.width, reroute_018_5.height = 10.0, 100.0
	    reroute_019_4.width, reroute_019_4.height = 10.0, 100.0
	    set_curve_tilt_1.width, set_curve_tilt_1.height = 140.0, 100.0
	    reroute_020_4.width, reroute_020_4.height = 10.0, 100.0
	    group_input_015.width, group_input_015.height = 140.0, 100.0
	    group_002_2.width, group_002_2.height = 140.0, 100.0
	    set_curve_tilt_001.width, set_curve_tilt_001.height = 140.0, 100.0
	    set_position_004.width, set_position_004.height = 140.0, 100.0
	    vector_math_002_4.width, vector_math_002_4.height = 140.0, 100.0
	    capture_attribute_001_5.width, capture_attribute_001_5.height = 140.0, 100.0
	    position_002_4.width, position_002_4.height = 140.0, 100.0
	    switch_003_7.width, switch_003_7.height = 140.0, 100.0
	    join_geometry_002.width, join_geometry_002.height = 140.0, 100.0
	    frame_002_5.width, frame_002_5.height = 526.0, 137.0
	    group_input_012_1.width, group_input_012_1.height = 140.0, 100.0
	    reroute_021_2.width, reroute_021_2.height = 10.0, 100.0
	    reroute_022_2.width, reroute_022_2.height = 10.0, 100.0
	    reroute_023_2.width, reroute_023_2.height = 10.0, 100.0
	    reroute_024_2.width, reroute_024_2.height = 10.0, 100.0
	    reroute_025_1.width, reroute_025_1.height = 10.0, 100.0
	    reroute_026_2.width, reroute_026_2.height = 10.0, 100.0
	    reroute_027_2.width, reroute_027_2.height = 10.0, 100.0
	    reroute_028_2.width, reroute_028_2.height = 10.0, 100.0
	    reroute_029_1.width, reroute_029_1.height = 10.0, 100.0
	    group_input_013_1.width, group_input_013_1.height = 140.0, 100.0
	    group_input_016.width, group_input_016.height = 140.0, 100.0
	    reroute_030_1.width, reroute_030_1.height = 10.0, 100.0
	    reroute_032_1.width, reroute_032_1.height = 10.0, 100.0
	    group_003_3.width, group_003_3.height = 140.0, 100.0
	    reroute_033.width, reroute_033.height = 10.0, 100.0
	    reroute_034.width, reroute_034.height = 10.0, 100.0
	    reroute_035.width, reroute_035.height = 10.0, 100.0
	    hair_style.width, hair_style.height = 140.0, 100.0
	    group_005_1.width, group_005_1.height = 140.0, 100.0
	    group_input_017.width, group_input_017.height = 140.0, 100.0
	    reroute_036.width, reroute_036.height = 10.0, 100.0
	    reroute_037.width, reroute_037.height = 10.0, 100.0
	    reroute_039.width, reroute_039.height = 10.0, 100.0
	    reroute_040.width, reroute_040.height = 10.0, 100.0
	    curve_bake.width, curve_bake.height = 140.0, 100.0
	    group_input_018.width, group_input_018.height = 140.0, 100.0
	    reroute_031.width, reroute_031.height = 10.0, 100.0
	    reroute_038.width, reroute_038.height = 10.0, 100.0
	    stylized_bake.width, stylized_bake.height = 140.0, 100.0
	    set_position_005.width, set_position_005.height = 140.0, 100.0
	    vector_math_003_5.width, vector_math_003_5.height = 140.0, 100.0
	    capture_attribute_002_8.width, capture_attribute_002_8.height = 140.0, 100.0
	    position_003.width, position_003.height = 140.0, 100.0
	    switch_004_4.width, switch_004_4.height = 140.0, 100.0
	    join_geometry_003_1.width, join_geometry_003_1.height = 140.0, 100.0
	    frame_003_4.width, frame_003_4.height = 526.0, 137.0
	    group_input_019.width, group_input_019.height = 140.0, 100.0
	    reroute_041.width, reroute_041.height = 10.0, 100.0
	    reroute_042.width, reroute_042.height = 10.0, 100.0
	    reroute_043.width, reroute_043.height = 10.0, 100.0
	    reroute_044.width, reroute_044.height = 10.0, 100.0
	    reroute_045.width, reroute_045.height = 10.0, 100.0
	    reroute_046.width, reroute_046.height = 10.0, 100.0
	    reroute_047.width, reroute_047.height = 10.0, 100.0
	    reroute_048.width, reroute_048.height = 10.0, 100.0
	    reroute_049.width, reroute_049.height = 10.0, 100.0
	    set_material_001.width, set_material_001.height = 140.0, 100.0
	    group_input_020.width, group_input_020.height = 140.0, 100.0
	    set_curve_radius_001.width, set_curve_radius_001.height = 140.0, 100.0
	    switch_11.width, switch_11.height = 140.0, 100.0
	    compare_001_5.width, compare_001_5.height = 140.0, 100.0
	    switch_001_8.width, switch_001_8.height = 140.0, 100.0
	    group_input_021.width, group_input_021.height = 140.0, 100.0
	    reroute_050.width, reroute_050.height = 10.0, 100.0
	    set_curve_tilt_002.width, set_curve_tilt_002.height = 140.0, 100.0
	    group_input_008_4.width, group_input_008_4.height = 140.0, 100.0
	
	    #initialize eyebrowz links
	    #curve_to_points_1.Rotation -> instance_on_points.Rotation
	    eyebrowz.links.new(curve_to_points_1.outputs[3], instance_on_points.inputs[5])
	    #curve_to_points_1.Points -> instance_on_points.Points
	    eyebrowz.links.new(curve_to_points_1.outputs[0], instance_on_points.inputs[0])
	    #instance_on_points.Instances -> realize_instances.Geometry
	    eyebrowz.links.new(instance_on_points.outputs[0], realize_instances.inputs[0])
	    #resample_curve_4.Curve -> instance_on_points.Instance
	    eyebrowz.links.new(resample_curve_4.outputs[0], instance_on_points.inputs[2])
	    #group_input_11.Count -> curve_to_points_1.Count
	    eyebrowz.links.new(group_input_11.outputs[3], curve_to_points_1.inputs[1])
	    #group_input_11.ControlPoints -> resample_curve_4.Count
	    eyebrowz.links.new(group_input_11.outputs[4], resample_curve_4.inputs[2])
	    #group_input_11.Length -> curve_line_1.Length
	    eyebrowz.links.new(group_input_11.outputs[5], curve_line_1.inputs[3])
	    #spline_parameter_8.Factor -> surface_offset_curve.Value
	    eyebrowz.links.new(spline_parameter_8.outputs[0], surface_offset_curve.inputs[1])
	    #vector_math_005_3.Vector -> set_position_002_2.Offset
	    eyebrowz.links.new(vector_math_005_3.outputs[0], set_position_002_2.inputs[3])
	    #sample_index_003_1.Value -> vector_math_005_3.Vector
	    eyebrowz.links.new(sample_index_003_1.outputs[0], vector_math_005_3.inputs[0])
	    #geometry_proximity.Position -> set_position_001_4.Position
	    eyebrowz.links.new(geometry_proximity.outputs[0], set_position_001_4.inputs[2])
	    #normal_2.Normal -> sample_index_003_1.Value
	    eyebrowz.links.new(normal_2.outputs[0], sample_index_003_1.inputs[1])
	    #sample_nearest.Index -> sample_index_003_1.Index
	    eyebrowz.links.new(sample_nearest.outputs[0], sample_index_003_1.inputs[2])
	    #geometry_proximity.Distance -> compare_10.A
	    eyebrowz.links.new(geometry_proximity.outputs[1], compare_10.inputs[0])
	    #reroute_11.Output -> sample_index_003_1.Geometry
	    eyebrowz.links.new(reroute_11.outputs[0], sample_index_003_1.inputs[0])
	    #reroute_11.Output -> sample_nearest.Geometry
	    eyebrowz.links.new(reroute_11.outputs[0], sample_nearest.inputs[0])
	    #endpoint_selection_001.Selection -> boolean_math_001_1.Boolean
	    eyebrowz.links.new(endpoint_selection_001.outputs[0], boolean_math_001_1.inputs[0])
	    #boolean_math_001_1.Boolean -> set_position_002_2.Selection
	    eyebrowz.links.new(boolean_math_001_1.outputs[0], set_position_002_2.inputs[1])
	    #vector.Vector -> vector_rotate_001.Vector
	    eyebrowz.links.new(vector.outputs[0], vector_rotate_001.inputs[0])
	    #set_position_001_4.Geometry -> set_position_002_2.Geometry
	    eyebrowz.links.new(set_position_001_4.outputs[0], set_position_002_2.inputs[0])
	    #map_range_2.Result -> vector_math_005_3.Scale
	    eyebrowz.links.new(map_range_2.outputs[0], vector_math_005_3.inputs[3])
	    #compare_10.Result -> set_position_001_4.Selection
	    eyebrowz.links.new(compare_10.outputs[0], set_position_001_4.inputs[1])
	    #reroute_002_8.Output -> geometry_proximity.Geometry
	    eyebrowz.links.new(reroute_002_8.outputs[0], geometry_proximity.inputs[0])
	    #surface_offset_curve.Value -> map_range_2.Value
	    eyebrowz.links.new(surface_offset_curve.outputs[0], map_range_2.inputs[0])
	    #group_input_11.Tangent Offset Angle -> vector_rotate_001.Angle
	    eyebrowz.links.new(group_input_11.outputs[7], vector_rotate_001.inputs[3])
	    #vector_rotate_001.Vector -> curve_line_1.Direction
	    eyebrowz.links.new(vector_rotate_001.outputs[0], curve_line_1.inputs[2])
	    #eyebrow_bake.Geometry -> group_output_15.Geometry
	    eyebrowz.links.new(eyebrow_bake.outputs[0], group_output_15.inputs[0])
	    #group_input_001_11.Surface -> object_info_1.Object
	    eyebrowz.links.new(group_input_001_11.outputs[1], object_info_1.inputs[0])
	    #group_input_002_10.Surface Snap Threshold -> compare_10.B
	    eyebrowz.links.new(group_input_002_10.outputs[8], compare_10.inputs[1])
	    #group_input_003_11.Surface Offset -> map_range_2.To Max
	    eyebrowz.links.new(group_input_003_11.outputs[9], map_range_2.inputs[4])
	    #object_info_1.Geometry -> reroute_11.Input
	    eyebrowz.links.new(object_info_1.outputs[4], reroute_11.inputs[0])
	    #reroute_11.Output -> reroute_001_10.Input
	    eyebrowz.links.new(reroute_11.outputs[0], reroute_001_10.inputs[0])
	    #reroute_001_10.Output -> reroute_002_8.Input
	    eyebrowz.links.new(reroute_001_10.outputs[0], reroute_002_8.inputs[0])
	    #group_input_004_10.Amount -> group_004.Amount
	    eyebrowz.links.new(group_input_004_10.outputs[14], group_004.inputs[1])
	    #group_input_004_10.Radius -> group_004.Radius
	    eyebrowz.links.new(group_input_004_10.outputs[15], group_004.inputs[3])
	    #group_input_004_10.Viewport Amount -> group_004.Viewport Amount
	    eyebrowz.links.new(group_input_004_10.outputs[16], group_004.inputs[2])
	    #group_input_004_10.Distribution Shape -> group_004.Distribution Shape
	    eyebrowz.links.new(group_input_004_10.outputs[17], group_004.inputs[4])
	    #group_input_004_10.Tip Roundness -> group_004.Tip Roundness
	    eyebrowz.links.new(group_input_004_10.outputs[18], group_004.inputs[5])
	    #group_input_004_10.Seed -> group_004.Seed
	    eyebrowz.links.new(group_input_004_10.outputs[19], group_004.inputs[7])
	    #group_input_11.Geometry -> separate_components_3.Geometry
	    eyebrowz.links.new(group_input_11.outputs[0], separate_components_3.inputs[0])
	    #set_position_002_2.Geometry -> reroute_004_8.Input
	    eyebrowz.links.new(set_position_002_2.outputs[0], reroute_004_8.inputs[0])
	    #spline_parameter_001_1.Factor -> trim_factor.Value
	    eyebrowz.links.new(spline_parameter_001_1.outputs[0], trim_factor.inputs[1])
	    #trim_factor.Value -> trim_curve.End
	    eyebrowz.links.new(trim_factor.outputs[0], trim_curve.inputs[3])
	    #trim_curve.Curve -> group_6.Geometry
	    eyebrowz.links.new(trim_curve.outputs[0], group_6.inputs[0])
	    #spline_parameter_002.Factor -> clump_factor.Value
	    eyebrowz.links.new(spline_parameter_002.outputs[0], clump_factor.inputs[1])
	    #clump_factor.Value -> group_6.Factor
	    eyebrowz.links.new(clump_factor.outputs[0], group_6.inputs[5])
	    #reroute_004_8.Output -> group_001_6.Geometry
	    eyebrowz.links.new(reroute_004_8.outputs[0], group_001_6.inputs[0])
	    #group_001_6.Geometry -> trim_curve.Curve
	    eyebrowz.links.new(group_001_6.outputs[0], trim_curve.inputs[0])
	    #group_input_005_8.Surface -> group_001_6.Surface
	    eyebrowz.links.new(group_input_005_8.outputs[1], group_001_6.inputs[2])
	    #named_attribute_4.Attribute -> group_001_6.Surface UV Map
	    eyebrowz.links.new(named_attribute_4.outputs[0], group_001_6.inputs[3])
	    #spline_parameter_003.Factor -> tip_spread_factor.Value
	    eyebrowz.links.new(spline_parameter_003.outputs[0], tip_spread_factor.inputs[1])
	    #tip_spread_factor.Value -> map_range_001_2.Value
	    eyebrowz.links.new(tip_spread_factor.outputs[0], map_range_001_2.inputs[0])
	    #map_range_001_2.Result -> group_6.Tip Spread
	    eyebrowz.links.new(map_range_001_2.outputs[0], group_6.inputs[7])
	    #group_input_006_6.Tip Spread -> map_range_001_2.To Max
	    eyebrowz.links.new(group_input_006_6.outputs[21], map_range_001_2.inputs[4])
	    #group_input_006_6.Clump Offset -> group_6.Clump Offset
	    eyebrowz.links.new(group_input_006_6.outputs[22], group_6.inputs[8])
	    #group_input_006_6.Seed -> group_6.Seed
	    eyebrowz.links.new(group_input_006_6.outputs[23], group_6.inputs[11])
	    #group_input_007_5.UV Map -> named_attribute_4.Name
	    eyebrowz.links.new(group_input_007_5.outputs[11], named_attribute_4.inputs[0])
	    #reroute_012_6.Output -> switch_002_6.False
	    eyebrowz.links.new(reroute_012_6.outputs[0], switch_002_6.inputs[1])
	    #reroute_013_6.Output -> capture_attribute_9.Geometry
	    eyebrowz.links.new(reroute_013_6.outputs[0], capture_attribute_9.inputs[0])
	    #position_001_3.Position -> capture_attribute_9.Position
	    eyebrowz.links.new(position_001_3.outputs[0], capture_attribute_9.inputs[1])
	    #capture_attribute_9.Position -> vector_math_001_5.Vector
	    eyebrowz.links.new(capture_attribute_9.outputs[1], vector_math_001_5.inputs[0])
	    #capture_attribute_9.Geometry -> set_position_003.Geometry
	    eyebrowz.links.new(capture_attribute_9.outputs[0], set_position_003.inputs[0])
	    #vector_math_001_5.Vector -> set_position_003.Position
	    eyebrowz.links.new(vector_math_001_5.outputs[0], set_position_003.inputs[2])
	    #reroute_016_6.Output -> join_geometry_001_3.Geometry
	    eyebrowz.links.new(reroute_016_6.outputs[0], join_geometry_001_3.inputs[0])
	    #join_geometry_001_3.Geometry -> switch_002_6.True
	    eyebrowz.links.new(join_geometry_001_3.outputs[0], switch_002_6.inputs[2])
	    #reroute_015_6.Output -> reroute_013_6.Input
	    eyebrowz.links.new(reroute_015_6.outputs[0], reroute_013_6.inputs[0])
	    #set_position_003.Geometry -> reroute_014_6.Input
	    eyebrowz.links.new(set_position_003.outputs[0], reroute_014_6.inputs[0])
	    #reroute_017_5.Output -> reroute_015_6.Input
	    eyebrowz.links.new(reroute_017_5.outputs[0], reroute_015_6.inputs[0])
	    #reroute_014_6.Output -> reroute_016_6.Input
	    eyebrowz.links.new(reroute_014_6.outputs[0], reroute_016_6.inputs[0])
	    #reroute_012_6.Output -> reroute_017_5.Input
	    eyebrowz.links.new(reroute_012_6.outputs[0], reroute_017_5.inputs[0])
	    #switch_002_6.Output -> set_material_4.Geometry
	    eyebrowz.links.new(switch_002_6.outputs[0], set_material_4.inputs[0])
	    #spline_parameter_004.Factor -> hair_shape.Value
	    eyebrowz.links.new(spline_parameter_004.outputs[0], hair_shape.inputs[1])
	    #hair_shape.Value -> map_range_002.Value
	    eyebrowz.links.new(hair_shape.outputs[0], map_range_002.inputs[0])
	    #group_input_014.Strand Radius -> map_range_002.To Max
	    eyebrowz.links.new(group_input_014.outputs[6], map_range_002.inputs[4])
	    #curve_line_1.Curve -> resample_curve_4.Curve
	    eyebrowz.links.new(curve_line_1.outputs[0], resample_curve_4.inputs[0])
	    #curve_bake.Geometry -> reroute_012_6.Input
	    eyebrowz.links.new(curve_bake.outputs[0], reroute_012_6.inputs[0])
	    #group_input_011_1.Mirror X -> switch_002_6.Switch
	    eyebrowz.links.new(group_input_011_1.outputs[12], switch_002_6.inputs[0])
	    #group_input_011_1.Material -> set_material_4.Material
	    eyebrowz.links.new(group_input_011_1.outputs[13], set_material_4.inputs[2])
	    #reroute_011_5.Output -> join_geometry_4.Geometry
	    eyebrowz.links.new(reroute_011_5.outputs[0], join_geometry_4.inputs[0])
	    #separate_components_3.Grease Pencil -> reroute_003_8.Input
	    eyebrowz.links.new(separate_components_3.outputs[2], reroute_003_8.inputs[0])
	    #separate_components_3.Mesh -> reroute_005_7.Input
	    eyebrowz.links.new(separate_components_3.outputs[0], reroute_005_7.inputs[0])
	    #separate_components_3.Instances -> reroute_006_6.Input
	    eyebrowz.links.new(separate_components_3.outputs[5], reroute_006_6.inputs[0])
	    #separate_components_3.Point Cloud -> reroute_007_6.Input
	    eyebrowz.links.new(separate_components_3.outputs[3], reroute_007_6.inputs[0])
	    #separate_components_3.Volume -> reroute_008_6.Input
	    eyebrowz.links.new(separate_components_3.outputs[4], reroute_008_6.inputs[0])
	    #reroute_003_8.Output -> reroute_009_6.Input
	    eyebrowz.links.new(reroute_003_8.outputs[0], reroute_009_6.inputs[0])
	    #reroute_007_6.Output -> reroute_010_4.Input
	    eyebrowz.links.new(reroute_007_6.outputs[0], reroute_010_4.inputs[0])
	    #reroute_006_6.Output -> reroute_011_5.Input
	    eyebrowz.links.new(reroute_006_6.outputs[0], reroute_011_5.inputs[0])
	    #reroute_008_6.Output -> reroute_018_5.Input
	    eyebrowz.links.new(reroute_008_6.outputs[0], reroute_018_5.inputs[0])
	    #reroute_005_7.Output -> reroute_019_4.Input
	    eyebrowz.links.new(reroute_005_7.outputs[0], reroute_019_4.inputs[0])
	    #join_geometry_4.Geometry -> eyebrow_bake.Geometry
	    eyebrowz.links.new(join_geometry_4.outputs[0], eyebrow_bake.inputs[0])
	    #reroute_020_4.Output -> set_curve_tilt_1.Curve
	    eyebrowz.links.new(reroute_020_4.outputs[0], set_curve_tilt_1.inputs[0])
	    #set_curve_tilt_1.Curve -> curve_to_points_1.Curve
	    eyebrowz.links.new(set_curve_tilt_1.outputs[0], curve_to_points_1.inputs[0])
	    #group_input_015.Strand Roulette -> set_curve_tilt_1.Tilt
	    eyebrowz.links.new(group_input_015.outputs[10], set_curve_tilt_1.inputs[2])
	    #reroute_029_1.Output -> set_curve_tilt_001.Curve
	    eyebrowz.links.new(reroute_029_1.outputs[0], set_curve_tilt_001.inputs[0])
	    #set_curve_tilt_001.Curve -> group_002_2.Geometry
	    eyebrowz.links.new(set_curve_tilt_001.outputs[0], group_002_2.inputs[0])
	    #reroute_021_2.Output -> switch_003_7.False
	    eyebrowz.links.new(reroute_021_2.outputs[0], switch_003_7.inputs[1])
	    #reroute_022_2.Output -> capture_attribute_001_5.Geometry
	    eyebrowz.links.new(reroute_022_2.outputs[0], capture_attribute_001_5.inputs[0])
	    #position_002_4.Position -> capture_attribute_001_5.Position
	    eyebrowz.links.new(position_002_4.outputs[0], capture_attribute_001_5.inputs[1])
	    #capture_attribute_001_5.Position -> vector_math_002_4.Vector
	    eyebrowz.links.new(capture_attribute_001_5.outputs[1], vector_math_002_4.inputs[0])
	    #capture_attribute_001_5.Geometry -> set_position_004.Geometry
	    eyebrowz.links.new(capture_attribute_001_5.outputs[0], set_position_004.inputs[0])
	    #vector_math_002_4.Vector -> set_position_004.Position
	    eyebrowz.links.new(vector_math_002_4.outputs[0], set_position_004.inputs[2])
	    #reroute_025_1.Output -> join_geometry_002.Geometry
	    eyebrowz.links.new(reroute_025_1.outputs[0], join_geometry_002.inputs[0])
	    #join_geometry_002.Geometry -> switch_003_7.True
	    eyebrowz.links.new(join_geometry_002.outputs[0], switch_003_7.inputs[2])
	    #reroute_024_2.Output -> reroute_022_2.Input
	    eyebrowz.links.new(reroute_024_2.outputs[0], reroute_022_2.inputs[0])
	    #set_position_004.Geometry -> reroute_023_2.Input
	    eyebrowz.links.new(set_position_004.outputs[0], reroute_023_2.inputs[0])
	    #reroute_026_2.Output -> reroute_024_2.Input
	    eyebrowz.links.new(reroute_026_2.outputs[0], reroute_024_2.inputs[0])
	    #reroute_023_2.Output -> reroute_025_1.Input
	    eyebrowz.links.new(reroute_023_2.outputs[0], reroute_025_1.inputs[0])
	    #reroute_021_2.Output -> reroute_026_2.Input
	    eyebrowz.links.new(reroute_021_2.outputs[0], reroute_026_2.inputs[0])
	    #group_input_012_1.Mirror X -> switch_003_7.Switch
	    eyebrowz.links.new(group_input_012_1.outputs[12], switch_003_7.inputs[0])
	    #reroute_030_1.Output -> reroute_021_2.Input
	    eyebrowz.links.new(reroute_030_1.outputs[0], reroute_021_2.inputs[0])
	    #reroute_050.Output -> reroute_027_2.Input
	    eyebrowz.links.new(reroute_050.outputs[0], reroute_027_2.inputs[0])
	    #reroute_027_2.Output -> reroute_028_2.Input
	    eyebrowz.links.new(reroute_027_2.outputs[0], reroute_028_2.inputs[0])
	    #reroute_028_2.Output -> reroute_029_1.Input
	    eyebrowz.links.new(reroute_028_2.outputs[0], reroute_029_1.inputs[0])
	    #group_input_013_1.Mesh Material -> group_002_2.Material
	    eyebrowz.links.new(group_input_013_1.outputs[24], group_002_2.inputs[2])
	    #group_input_013_1.Resolution -> group_002_2.Resolution
	    eyebrowz.links.new(group_input_013_1.outputs[26], group_002_2.inputs[3])
	    #group_input_013_1.Width -> group_002_2.Width
	    eyebrowz.links.new(group_input_013_1.outputs[27], group_002_2.inputs[4])
	    #group_input_013_1.Shade Smooth -> group_002_2.Shade Smooth
	    eyebrowz.links.new(group_input_013_1.outputs[28], group_002_2.inputs[7])
	    #group_input_013_1.Hair Card Angle -> group_002_2.Hair Card Angle
	    eyebrowz.links.new(group_input_013_1.outputs[29], group_002_2.inputs[8])
	    #group_002_2.Geometry -> reroute_030_1.Input
	    eyebrowz.links.new(group_002_2.outputs[0], reroute_030_1.inputs[0])
	    #switch_003_7.Output -> reroute_032_1.Input
	    eyebrowz.links.new(switch_003_7.outputs[0], reroute_032_1.inputs[0])
	    #reroute_033.Output -> reroute_034.Input
	    eyebrowz.links.new(reroute_033.outputs[0], reroute_034.inputs[0])
	    #reroute_036.Output -> reroute_035.Input
	    eyebrowz.links.new(reroute_036.outputs[0], reroute_035.inputs[0])
	    #reroute_031.Output -> hair_style.Curve Hair
	    eyebrowz.links.new(reroute_031.outputs[0], hair_style.inputs[1])
	    #group_input_016.Hair Style -> hair_style.Menu
	    eyebrowz.links.new(group_input_016.outputs[2], hair_style.inputs[0])
	    #group_input_017.Mesh Material -> group_005_1.Material
	    eyebrowz.links.new(group_input_017.outputs[24], group_005_1.inputs[2])
	    #group_input_017.Resolution -> group_005_1.Resolution
	    eyebrowz.links.new(group_input_017.outputs[26], group_005_1.inputs[3])
	    #group_input_017.Width -> group_005_1.Width
	    eyebrowz.links.new(group_input_017.outputs[27], group_005_1.inputs[4])
	    #group_input_017.Shade Smooth -> group_005_1.Shade Smooth
	    eyebrowz.links.new(group_input_017.outputs[28], group_005_1.inputs[7])
	    #group_input_017.Hair Card Angle -> group_005_1.Hair Card Angle
	    eyebrowz.links.new(group_input_017.outputs[29], group_005_1.inputs[8])
	    #set_material_4.Geometry -> reroute_036.Input
	    eyebrowz.links.new(set_material_4.outputs[0], reroute_036.inputs[0])
	    #set_curve_tilt_002.Curve -> group_005_1.Geometry
	    eyebrowz.links.new(set_curve_tilt_002.outputs[0], group_005_1.inputs[0])
	    #reroute_035.Output -> reroute_037.Input
	    eyebrowz.links.new(reroute_035.outputs[0], reroute_037.inputs[0])
	    #group_005_1.Geometry -> hair_style.Mesh Hair
	    eyebrowz.links.new(group_005_1.outputs[0], hair_style.inputs[2])
	    #reroute_032_1.Output -> hair_style.Mesh Strip
	    eyebrowz.links.new(reroute_032_1.outputs[0], hair_style.inputs[3])
	    #reroute_028_2.Output -> reroute_039.Input
	    eyebrowz.links.new(reroute_028_2.outputs[0], reroute_039.inputs[0])
	    #reroute_039.Output -> reroute_040.Input
	    eyebrowz.links.new(reroute_039.outputs[0], reroute_040.inputs[0])
	    #stylized_bake.Geometry -> hair_style.Stylized
	    eyebrowz.links.new(stylized_bake.outputs[0], hair_style.inputs[4])
	    #reroute_034.Output -> curve_bake.Geometry
	    eyebrowz.links.new(reroute_034.outputs[0], curve_bake.inputs[0])
	    #group_input_017.Fill Caps -> group_005_1.Fill Caps
	    eyebrowz.links.new(group_input_017.outputs[30], group_005_1.inputs[6])
	    #group_input_017.Tube Ribbon Count -> group_005_1.Tube Ribbon Count
	    eyebrowz.links.new(group_input_017.outputs[31], group_005_1.inputs[9])
	    #group_input_017.Profile Curve -> group_005_1.Profile Curve
	    eyebrowz.links.new(group_input_017.outputs[32], group_005_1.inputs[10])
	    #group_input_017.Profile Translation -> group_005_1.Profile Translation
	    eyebrowz.links.new(group_input_017.outputs[33], group_005_1.inputs[11])
	    #group_input_017.Profile Rotation -> group_005_1.Profile Rotation
	    eyebrowz.links.new(group_input_017.outputs[34], group_005_1.inputs[12])
	    #group_input_017.Profile Scale -> group_005_1.Profile Scale
	    eyebrowz.links.new(group_input_017.outputs[35], group_005_1.inputs[13])
	    #group_input_018.ControlPoints -> group_003_3.Control Points
	    eyebrowz.links.new(group_input_018.outputs[4], group_003_3.inputs[2])
	    #group_input_018.Radius -> group_003_3.Radius
	    eyebrowz.links.new(group_input_018.outputs[15], group_003_3.inputs[4])
	    #group_input_018.Resolution -> group_003_3.Resolution
	    eyebrowz.links.new(group_input_018.outputs[36], group_003_3.inputs[3])
	    #group_input_018.Offset Factor -> group_003_3.Offset Factor
	    eyebrowz.links.new(group_input_018.outputs[37], group_003_3.inputs[5])
	    #group_input_018.Resample Count -> group_003_3.Resample Count
	    eyebrowz.links.new(group_input_018.outputs[38], group_003_3.inputs[6])
	    #group_input_018.Level -> group_003_3.Level
	    eyebrowz.links.new(group_input_018.outputs[39], group_003_3.inputs[7])
	    #group_input_018.Edge Crease -> group_003_3.Edge Crease
	    eyebrowz.links.new(group_input_018.outputs[40], group_003_3.inputs[8])
	    #group_input_018.Vertex Crease -> group_003_3.Vertex Crease
	    eyebrowz.links.new(group_input_018.outputs[41], group_003_3.inputs[9])
	    #group_input_018.Limit Surface -> group_003_3.Limit Surface
	    eyebrowz.links.new(group_input_018.outputs[42], group_003_3.inputs[10])
	    #group_input_018.Distance -> group_003_3.Distance
	    eyebrowz.links.new(group_input_018.outputs[43], group_003_3.inputs[11])
	    #set_material_4.Geometry -> reroute_031.Input
	    eyebrowz.links.new(set_material_4.outputs[0], reroute_031.inputs[0])
	    #reroute_038.Output -> group_003_3.Hair Curves
	    eyebrowz.links.new(reroute_038.outputs[0], group_003_3.inputs[1])
	    #reroute_031.Output -> reroute_038.Input
	    eyebrowz.links.new(reroute_031.outputs[0], reroute_038.inputs[0])
	    #reroute_040.Output -> group_003_3.Geometry
	    eyebrowz.links.new(reroute_040.outputs[0], group_003_3.inputs[0])
	    #reroute_041.Output -> switch_004_4.False
	    eyebrowz.links.new(reroute_041.outputs[0], switch_004_4.inputs[1])
	    #reroute_042.Output -> capture_attribute_002_8.Geometry
	    eyebrowz.links.new(reroute_042.outputs[0], capture_attribute_002_8.inputs[0])
	    #position_003.Position -> capture_attribute_002_8.Position
	    eyebrowz.links.new(position_003.outputs[0], capture_attribute_002_8.inputs[1])
	    #capture_attribute_002_8.Position -> vector_math_003_5.Vector
	    eyebrowz.links.new(capture_attribute_002_8.outputs[1], vector_math_003_5.inputs[0])
	    #capture_attribute_002_8.Geometry -> set_position_005.Geometry
	    eyebrowz.links.new(capture_attribute_002_8.outputs[0], set_position_005.inputs[0])
	    #vector_math_003_5.Vector -> set_position_005.Position
	    eyebrowz.links.new(vector_math_003_5.outputs[0], set_position_005.inputs[2])
	    #reroute_045.Output -> join_geometry_003_1.Geometry
	    eyebrowz.links.new(reroute_045.outputs[0], join_geometry_003_1.inputs[0])
	    #join_geometry_003_1.Geometry -> switch_004_4.True
	    eyebrowz.links.new(join_geometry_003_1.outputs[0], switch_004_4.inputs[2])
	    #reroute_044.Output -> reroute_042.Input
	    eyebrowz.links.new(reroute_044.outputs[0], reroute_042.inputs[0])
	    #set_position_005.Geometry -> reroute_043.Input
	    eyebrowz.links.new(set_position_005.outputs[0], reroute_043.inputs[0])
	    #reroute_046.Output -> reroute_044.Input
	    eyebrowz.links.new(reroute_046.outputs[0], reroute_044.inputs[0])
	    #reroute_043.Output -> reroute_045.Input
	    eyebrowz.links.new(reroute_043.outputs[0], reroute_045.inputs[0])
	    #reroute_041.Output -> reroute_046.Input
	    eyebrowz.links.new(reroute_041.outputs[0], reroute_046.inputs[0])
	    #group_input_019.Mirror X -> switch_004_4.Switch
	    eyebrowz.links.new(group_input_019.outputs[12], switch_004_4.inputs[0])
	    #reroute_047.Output -> reroute_041.Input
	    eyebrowz.links.new(reroute_047.outputs[0], reroute_041.inputs[0])
	    #set_material_001.Geometry -> stylized_bake.Geometry
	    eyebrowz.links.new(set_material_001.outputs[0], stylized_bake.inputs[0])
	    #group_003_3.Geometry -> reroute_047.Input
	    eyebrowz.links.new(group_003_3.outputs[0], reroute_047.inputs[0])
	    #switch_004_4.Output -> reroute_048.Input
	    eyebrowz.links.new(switch_004_4.outputs[0], reroute_048.inputs[0])
	    #reroute_048.Output -> reroute_049.Input
	    eyebrowz.links.new(reroute_048.outputs[0], reroute_049.inputs[0])
	    #reroute_049.Output -> set_material_001.Geometry
	    eyebrowz.links.new(reroute_049.outputs[0], set_material_001.inputs[0])
	    #group_input_020.Mesh Material -> set_material_001.Material
	    eyebrowz.links.new(group_input_020.outputs[24], set_material_001.inputs[2])
	    #realize_instances.Geometry -> set_curve_radius_001.Curve
	    eyebrowz.links.new(realize_instances.outputs[0], set_curve_radius_001.inputs[0])
	    #map_range_002.Result -> set_curve_radius_001.Radius
	    eyebrowz.links.new(map_range_002.outputs[0], set_curve_radius_001.inputs[2])
	    #set_curve_radius_001.Curve -> group_004.Geometry
	    eyebrowz.links.new(set_curve_radius_001.outputs[0], group_004.inputs[0])
	    #group_input_004_10.Amount -> compare_001_5.A
	    eyebrowz.links.new(group_input_004_10.outputs[14], compare_001_5.inputs[2])
	    #set_curve_radius_001.Curve -> switch_11.False
	    eyebrowz.links.new(set_curve_radius_001.outputs[0], switch_11.inputs[1])
	    #compare_001_5.Result -> switch_11.Switch
	    eyebrowz.links.new(compare_001_5.outputs[0], switch_11.inputs[0])
	    #switch_11.Output -> set_position_001_4.Geometry
	    eyebrowz.links.new(switch_11.outputs[0], set_position_001_4.inputs[0])
	    #group_004.Geometry -> switch_11.True
	    eyebrowz.links.new(group_004.outputs[0], switch_11.inputs[2])
	    #trim_curve.Curve -> switch_001_8.False
	    eyebrowz.links.new(trim_curve.outputs[0], switch_001_8.inputs[1])
	    #group_6.Geometry -> switch_001_8.True
	    eyebrowz.links.new(group_6.outputs[0], switch_001_8.inputs[2])
	    #switch_001_8.Output -> reroute_033.Input
	    eyebrowz.links.new(switch_001_8.outputs[0], reroute_033.inputs[0])
	    #group_input_021.Use Clump -> switch_001_8.Switch
	    eyebrowz.links.new(group_input_021.outputs[20], switch_001_8.inputs[0])
	    #separate_components_3.Curve -> reroute_050.Input
	    eyebrowz.links.new(separate_components_3.outputs[1], reroute_050.inputs[0])
	    #reroute_050.Output -> reroute_020_4.Input
	    eyebrowz.links.new(reroute_050.outputs[0], reroute_020_4.inputs[0])
	    #reroute_037.Output -> set_curve_tilt_002.Curve
	    eyebrowz.links.new(reroute_037.outputs[0], set_curve_tilt_002.inputs[0])
	    #group_input_008_4.Mesh Tilt -> set_curve_tilt_002.Tilt
	    eyebrowz.links.new(group_input_008_4.outputs[25], set_curve_tilt_002.inputs[2])
	    #reroute_017_5.Output -> join_geometry_001_3.Geometry
	    eyebrowz.links.new(reroute_017_5.outputs[0], join_geometry_001_3.inputs[0])
	    #reroute_018_5.Output -> join_geometry_4.Geometry
	    eyebrowz.links.new(reroute_018_5.outputs[0], join_geometry_4.inputs[0])
	    #reroute_026_2.Output -> join_geometry_002.Geometry
	    eyebrowz.links.new(reroute_026_2.outputs[0], join_geometry_002.inputs[0])
	    #reroute_046.Output -> join_geometry_003_1.Geometry
	    eyebrowz.links.new(reroute_046.outputs[0], join_geometry_003_1.inputs[0])
	    #reroute_010_4.Output -> join_geometry_4.Geometry
	    eyebrowz.links.new(reroute_010_4.outputs[0], join_geometry_4.inputs[0])
	    #reroute_009_6.Output -> join_geometry_4.Geometry
	    eyebrowz.links.new(reroute_009_6.outputs[0], join_geometry_4.inputs[0])
	    #reroute_019_4.Output -> join_geometry_4.Geometry
	    eyebrowz.links.new(reroute_019_4.outputs[0], join_geometry_4.inputs[0])
	    #hair_style.Output -> join_geometry_4.Geometry
	    eyebrowz.links.new(hair_style.outputs[0], join_geometry_4.inputs[0])
	    hair_style_socket.default_value = 'Curve Hair'
	    return eyebrowz
	return eyebrowz_node_group()

	

	
