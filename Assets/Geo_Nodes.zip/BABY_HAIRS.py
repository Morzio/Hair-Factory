import bpy, mathutils

def node():
	#initialize curve_root_006 node group
	def curve_root_006_node_group():
	    curve_root_006 = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Curve Root.006")
	
	    curve_root_006.color_tag = 'NONE'
	    curve_root_006.description = "Reads information about each curve's root point"
	    curve_root_006.default_group_node_width = 140
	    
	
	
	    #curve_root_006 interface
	    #Socket Root Selection
	    root_selection_socket = curve_root_006.interface.new_socket(name = "Root Selection", in_out='OUTPUT', socket_type = 'NodeSocketBool')
	    root_selection_socket.default_value = False
	    root_selection_socket.attribute_domain = 'POINT'
	    root_selection_socket.description = "Boolean selection of curve root points"
	
	    #Socket Root Position
	    root_position_socket = curve_root_006.interface.new_socket(name = "Root Position", in_out='OUTPUT', socket_type = 'NodeSocketVector')
	    root_position_socket.default_value = (0.0, 0.0, 0.0)
	    root_position_socket.min_value = -3.4028234663852886e+38
	    root_position_socket.max_value = 3.4028234663852886e+38
	    root_position_socket.subtype = 'NONE'
	    root_position_socket.attribute_domain = 'CURVE'
	    root_position_socket.description = "Position of the root point of a curve"
	
	    #Socket Root Direction
	    root_direction_socket = curve_root_006.interface.new_socket(name = "Root Direction", in_out='OUTPUT', socket_type = 'NodeSocketVector')
	    root_direction_socket.default_value = (0.0, 0.0, 0.0)
	    root_direction_socket.min_value = -3.4028234663852886e+38
	    root_direction_socket.max_value = 3.4028234663852886e+38
	    root_direction_socket.subtype = 'NONE'
	    root_direction_socket.attribute_domain = 'CURVE'
	    root_direction_socket.description = "Direction of the root segment of a curve"
	
	    #Socket Root Index
	    root_index_socket = curve_root_006.interface.new_socket(name = "Root Index", in_out='OUTPUT', socket_type = 'NodeSocketInt')
	    root_index_socket.default_value = 0
	    root_index_socket.min_value = -2147483648
	    root_index_socket.max_value = 2147483647
	    root_index_socket.subtype = 'NONE'
	    root_index_socket.attribute_domain = 'CURVE'
	    root_index_socket.description = "Index of the root point of a curve"
	
	
	    #initialize curve_root_006 nodes
	    #node Position.002
	    position_002 = curve_root_006.nodes.new("GeometryNodeInputPosition")
	    position_002.name = "Position.002"
	
	    #node Interpolate Domain
	    interpolate_domain = curve_root_006.nodes.new("GeometryNodeFieldOnDomain")
	    interpolate_domain.name = "Interpolate Domain"
	    interpolate_domain.data_type = 'INT'
	    interpolate_domain.domain = 'CURVE'
	
	    #node Field at Index.003
	    field_at_index_003 = curve_root_006.nodes.new("GeometryNodeFieldAtIndex")
	    field_at_index_003.name = "Field at Index.003"
	    field_at_index_003.data_type = 'FLOAT_VECTOR'
	    field_at_index_003.domain = 'POINT'
	
	    #node Interpolate Domain.001
	    interpolate_domain_001 = curve_root_006.nodes.new("GeometryNodeFieldOnDomain")
	    interpolate_domain_001.name = "Interpolate Domain.001"
	    interpolate_domain_001.data_type = 'FLOAT_VECTOR'
	    interpolate_domain_001.domain = 'CURVE'
	
	    #node Curve Tangent
	    curve_tangent = curve_root_006.nodes.new("GeometryNodeInputTangent")
	    curve_tangent.name = "Curve Tangent"
	
	    #node Endpoint Selection
	    endpoint_selection = curve_root_006.nodes.new("GeometryNodeCurveEndpointSelection")
	    endpoint_selection.name = "Endpoint Selection"
	    #Start Size
	    endpoint_selection.inputs[0].default_value = 1
	    #End Size
	    endpoint_selection.inputs[1].default_value = 0
	
	    #node Field at Index.004
	    field_at_index_004 = curve_root_006.nodes.new("GeometryNodeFieldAtIndex")
	    field_at_index_004.name = "Field at Index.004"
	    field_at_index_004.data_type = 'FLOAT_VECTOR'
	    field_at_index_004.domain = 'POINT'
	
	    #node Interpolate Domain.002
	    interpolate_domain_002 = curve_root_006.nodes.new("GeometryNodeFieldOnDomain")
	    interpolate_domain_002.name = "Interpolate Domain.002"
	    interpolate_domain_002.data_type = 'FLOAT_VECTOR'
	    interpolate_domain_002.domain = 'CURVE'
	
	    #node Group Output
	    group_output = curve_root_006.nodes.new("NodeGroupOutput")
	    group_output.name = "Group Output"
	    group_output.is_active_output = True
	
	    #node Points of Curve
	    points_of_curve = curve_root_006.nodes.new("GeometryNodePointsOfCurve")
	    points_of_curve.name = "Points of Curve"
	    points_of_curve.inputs[0].hide = True
	    points_of_curve.inputs[1].hide = True
	    points_of_curve.outputs[1].hide = True
	    #Curve Index
	    points_of_curve.inputs[0].default_value = 0
	    #Weights
	    points_of_curve.inputs[1].default_value = 0.0
	    #Sort Index
	    points_of_curve.inputs[2].default_value = 0
	
	
	
	
	
	    #Set locations
	    position_002.location = (-608.1627807617188, -70.55814361572266)
	    interpolate_domain.location = (-608.1627807617188, 90.18604278564453)
	    field_at_index_003.location = (-407.2325439453125, 70.09302520751953)
	    interpolate_domain_001.location = (-206.30230712890625, 70.09302520751953)
	    curve_tangent.location = (-608.1627807617188, -271.4883728027344)
	    endpoint_selection.location = (-206.30230712890625, 190.65118408203125)
	    field_at_index_004.location = (-407.2325439453125, -130.83721923828125)
	    interpolate_domain_002.location = (-206.30230712890625, -130.83721923828125)
	    group_output.location = (75.0, 50.0)
	    points_of_curve.location = (-789.0, 50.0)
	
	    #Set dimensions
	    position_002.width, position_002.height = 140.0, 100.0
	    interpolate_domain.width, interpolate_domain.height = 140.0, 100.0
	    field_at_index_003.width, field_at_index_003.height = 140.0, 100.0
	    interpolate_domain_001.width, interpolate_domain_001.height = 140.0, 100.0
	    curve_tangent.width, curve_tangent.height = 140.0, 100.0
	    endpoint_selection.width, endpoint_selection.height = 140.0, 100.0
	    field_at_index_004.width, field_at_index_004.height = 140.0, 100.0
	    interpolate_domain_002.width, interpolate_domain_002.height = 140.0, 100.0
	    group_output.width, group_output.height = 140.0, 100.0
	    points_of_curve.width, points_of_curve.height = 140.0, 100.0
	
	    #initialize curve_root_006 links
	    #position_002.Position -> field_at_index_003.Value
	    curve_root_006.links.new(position_002.outputs[0], field_at_index_003.inputs[1])
	    #interpolate_domain_001.Value -> group_output.Root Position
	    curve_root_006.links.new(interpolate_domain_001.outputs[0], group_output.inputs[1])
	    #interpolate_domain.Value -> field_at_index_003.Index
	    curve_root_006.links.new(interpolate_domain.outputs[0], field_at_index_003.inputs[0])
	    #points_of_curve.Point Index -> interpolate_domain.Value
	    curve_root_006.links.new(points_of_curve.outputs[0], interpolate_domain.inputs[0])
	    #interpolate_domain.Value -> group_output.Root Index
	    curve_root_006.links.new(interpolate_domain.outputs[0], group_output.inputs[3])
	    #endpoint_selection.Selection -> group_output.Root Selection
	    curve_root_006.links.new(endpoint_selection.outputs[0], group_output.inputs[0])
	    #field_at_index_003.Value -> interpolate_domain_001.Value
	    curve_root_006.links.new(field_at_index_003.outputs[0], interpolate_domain_001.inputs[0])
	    #interpolate_domain_002.Value -> group_output.Root Direction
	    curve_root_006.links.new(interpolate_domain_002.outputs[0], group_output.inputs[2])
	    #interpolate_domain.Value -> field_at_index_004.Index
	    curve_root_006.links.new(interpolate_domain.outputs[0], field_at_index_004.inputs[0])
	    #curve_tangent.Tangent -> field_at_index_004.Value
	    curve_root_006.links.new(curve_tangent.outputs[0], field_at_index_004.inputs[1])
	    #field_at_index_004.Value -> interpolate_domain_002.Value
	    curve_root_006.links.new(field_at_index_004.outputs[0], interpolate_domain_002.inputs[0])
	    return curve_root_006
	
	curve_root_006 = curve_root_006_node_group()
	
	#initialize curve_tip_003 node group
	def curve_tip_003_node_group():
	    curve_tip_003 = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Curve Tip.003")
	
	    curve_tip_003.color_tag = 'NONE'
	    curve_tip_003.description = "Reads information about each curve's tip point"
	    curve_tip_003.default_group_node_width = 140
	    
	
	
	    #curve_tip_003 interface
	    #Socket Tip Selection
	    tip_selection_socket = curve_tip_003.interface.new_socket(name = "Tip Selection", in_out='OUTPUT', socket_type = 'NodeSocketBool')
	    tip_selection_socket.default_value = False
	    tip_selection_socket.attribute_domain = 'POINT'
	    tip_selection_socket.description = "Boolean selection of curve tip points"
	
	    #Socket Tip Position
	    tip_position_socket = curve_tip_003.interface.new_socket(name = "Tip Position", in_out='OUTPUT', socket_type = 'NodeSocketVector')
	    tip_position_socket.default_value = (0.0, 0.0, 0.0)
	    tip_position_socket.min_value = -3.4028234663852886e+38
	    tip_position_socket.max_value = 3.4028234663852886e+38
	    tip_position_socket.subtype = 'NONE'
	    tip_position_socket.attribute_domain = 'CURVE'
	    tip_position_socket.description = "Position of the tip point of a curve"
	
	    #Socket Tip Direction
	    tip_direction_socket = curve_tip_003.interface.new_socket(name = "Tip Direction", in_out='OUTPUT', socket_type = 'NodeSocketVector')
	    tip_direction_socket.default_value = (0.0, 0.0, 0.0)
	    tip_direction_socket.min_value = -3.4028234663852886e+38
	    tip_direction_socket.max_value = 3.4028234663852886e+38
	    tip_direction_socket.subtype = 'NONE'
	    tip_direction_socket.attribute_domain = 'CURVE'
	    tip_direction_socket.description = "Direction of the tip segment of a curve"
	
	    #Socket Tip Index
	    tip_index_socket = curve_tip_003.interface.new_socket(name = "Tip Index", in_out='OUTPUT', socket_type = 'NodeSocketInt')
	    tip_index_socket.default_value = 0
	    tip_index_socket.min_value = -2147483648
	    tip_index_socket.max_value = 2147483647
	    tip_index_socket.subtype = 'NONE'
	    tip_index_socket.attribute_domain = 'CURVE'
	    tip_index_socket.description = "Index of the tip point of a curve"
	
	
	    #initialize curve_tip_003 nodes
	    #node Position.002
	    position_002_1 = curve_tip_003.nodes.new("GeometryNodeInputPosition")
	    position_002_1.name = "Position.002"
	
	    #node Interpolate Domain
	    interpolate_domain_1 = curve_tip_003.nodes.new("GeometryNodeFieldOnDomain")
	    interpolate_domain_1.name = "Interpolate Domain"
	    interpolate_domain_1.data_type = 'INT'
	    interpolate_domain_1.domain = 'CURVE'
	
	    #node Interpolate Domain.001
	    interpolate_domain_001_1 = curve_tip_003.nodes.new("GeometryNodeFieldOnDomain")
	    interpolate_domain_001_1.name = "Interpolate Domain.001"
	    interpolate_domain_001_1.data_type = 'FLOAT_VECTOR'
	    interpolate_domain_001_1.domain = 'CURVE'
	
	    #node Field at Index.003
	    field_at_index_003_1 = curve_tip_003.nodes.new("GeometryNodeFieldAtIndex")
	    field_at_index_003_1.name = "Field at Index.003"
	    field_at_index_003_1.data_type = 'FLOAT_VECTOR'
	    field_at_index_003_1.domain = 'POINT'
	
	    #node Curve Tangent
	    curve_tangent_1 = curve_tip_003.nodes.new("GeometryNodeInputTangent")
	    curve_tangent_1.name = "Curve Tangent"
	
	    #node Endpoint Selection
	    endpoint_selection_1 = curve_tip_003.nodes.new("GeometryNodeCurveEndpointSelection")
	    endpoint_selection_1.name = "Endpoint Selection"
	    #Start Size
	    endpoint_selection_1.inputs[0].default_value = 0
	    #End Size
	    endpoint_selection_1.inputs[1].default_value = 1
	
	    #node Field at Index.004
	    field_at_index_004_1 = curve_tip_003.nodes.new("GeometryNodeFieldAtIndex")
	    field_at_index_004_1.name = "Field at Index.004"
	    field_at_index_004_1.data_type = 'FLOAT_VECTOR'
	    field_at_index_004_1.domain = 'POINT'
	
	    #node Interpolate Domain.002
	    interpolate_domain_002_1 = curve_tip_003.nodes.new("GeometryNodeFieldOnDomain")
	    interpolate_domain_002_1.name = "Interpolate Domain.002"
	    interpolate_domain_002_1.data_type = 'FLOAT_VECTOR'
	    interpolate_domain_002_1.domain = 'CURVE'
	
	    #node Group Output
	    group_output_1 = curve_tip_003.nodes.new("NodeGroupOutput")
	    group_output_1.name = "Group Output"
	    group_output_1.is_active_output = True
	
	    #node Points of Curve
	    points_of_curve_1 = curve_tip_003.nodes.new("GeometryNodePointsOfCurve")
	    points_of_curve_1.name = "Points of Curve"
	    points_of_curve_1.inputs[0].hide = True
	    points_of_curve_1.inputs[1].hide = True
	    points_of_curve_1.outputs[1].hide = True
	    #Curve Index
	    points_of_curve_1.inputs[0].default_value = 0
	    #Weights
	    points_of_curve_1.inputs[1].default_value = 0.0
	    #Sort Index
	    points_of_curve_1.inputs[2].default_value = -1
	
	
	
	
	
	    #Set locations
	    position_002_1.location = (-628.2557983398438, -70.55813598632812)
	    interpolate_domain_1.location = (-628.2557983398438, 90.18605041503906)
	    interpolate_domain_001_1.location = (-246.4883575439453, 90.18605041503906)
	    field_at_index_003_1.location = (-427.3255615234375, 90.18605041503906)
	    curve_tangent_1.location = (-628.2557983398438, -231.3023223876953)
	    endpoint_selection_1.location = (-246.4883575439453, 210.7441864013672)
	    field_at_index_004_1.location = (-427.3255615234375, -90.65116882324219)
	    interpolate_domain_002_1.location = (-246.4883575439453, -90.65116882324219)
	    group_output_1.location = (75.0, 50.0)
	    points_of_curve_1.location = (-829.18603515625, 50.0)
	
	    #Set dimensions
	    position_002_1.width, position_002_1.height = 140.0, 100.0
	    interpolate_domain_1.width, interpolate_domain_1.height = 140.0, 100.0
	    interpolate_domain_001_1.width, interpolate_domain_001_1.height = 140.0, 100.0
	    field_at_index_003_1.width, field_at_index_003_1.height = 140.0, 100.0
	    curve_tangent_1.width, curve_tangent_1.height = 140.0, 100.0
	    endpoint_selection_1.width, endpoint_selection_1.height = 140.0, 100.0
	    field_at_index_004_1.width, field_at_index_004_1.height = 140.0, 100.0
	    interpolate_domain_002_1.width, interpolate_domain_002_1.height = 140.0, 100.0
	    group_output_1.width, group_output_1.height = 140.0, 100.0
	    points_of_curve_1.width, points_of_curve_1.height = 140.0, 100.0
	
	    #initialize curve_tip_003 links
	    #position_002_1.Position -> field_at_index_003_1.Value
	    curve_tip_003.links.new(position_002_1.outputs[0], field_at_index_003_1.inputs[1])
	    #interpolate_domain_1.Value -> field_at_index_003_1.Index
	    curve_tip_003.links.new(interpolate_domain_1.outputs[0], field_at_index_003_1.inputs[0])
	    #points_of_curve_1.Point Index -> interpolate_domain_1.Value
	    curve_tip_003.links.new(points_of_curve_1.outputs[0], interpolate_domain_1.inputs[0])
	    #interpolate_domain_001_1.Value -> group_output_1.Tip Position
	    curve_tip_003.links.new(interpolate_domain_001_1.outputs[0], group_output_1.inputs[1])
	    #interpolate_domain_1.Value -> group_output_1.Tip Index
	    curve_tip_003.links.new(interpolate_domain_1.outputs[0], group_output_1.inputs[3])
	    #endpoint_selection_1.Selection -> group_output_1.Tip Selection
	    curve_tip_003.links.new(endpoint_selection_1.outputs[0], group_output_1.inputs[0])
	    #field_at_index_003_1.Value -> interpolate_domain_001_1.Value
	    curve_tip_003.links.new(field_at_index_003_1.outputs[0], interpolate_domain_001_1.inputs[0])
	    #interpolate_domain_002_1.Value -> group_output_1.Tip Direction
	    curve_tip_003.links.new(interpolate_domain_002_1.outputs[0], group_output_1.inputs[2])
	    #curve_tangent_1.Tangent -> field_at_index_004_1.Value
	    curve_tip_003.links.new(curve_tangent_1.outputs[0], field_at_index_004_1.inputs[1])
	    #interpolate_domain_1.Value -> field_at_index_004_1.Index
	    curve_tip_003.links.new(interpolate_domain_1.outputs[0], field_at_index_004_1.inputs[0])
	    #field_at_index_004_1.Value -> interpolate_domain_002_1.Value
	    curve_tip_003.links.new(field_at_index_004_1.outputs[0], interpolate_domain_002_1.inputs[0])
	    return curve_tip_003
	
	curve_tip_003 = curve_tip_003_node_group()
	
	#initialize curve_info_003 node group
	def curve_info_003_node_group():
	    curve_info_003 = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Curve Info.003")
	
	    curve_info_003.color_tag = 'NONE'
	    curve_info_003.description = "Reads information about each curve"
	    curve_info_003.default_group_node_width = 140
	    
	
	
	    #curve_info_003 interface
	    #Socket Curve Index
	    curve_index_socket = curve_info_003.interface.new_socket(name = "Curve Index", in_out='OUTPUT', socket_type = 'NodeSocketInt')
	    curve_index_socket.default_value = 0
	    curve_index_socket.min_value = -2147483648
	    curve_index_socket.max_value = 2147483647
	    curve_index_socket.subtype = 'NONE'
	    curve_index_socket.attribute_domain = 'CURVE'
	    curve_index_socket.description = "Index of each Curve"
	
	    #Socket Curve ID
	    curve_id_socket = curve_info_003.interface.new_socket(name = "Curve ID", in_out='OUTPUT', socket_type = 'NodeSocketInt')
	    curve_id_socket.default_value = 0
	    curve_id_socket.min_value = -2147483648
	    curve_id_socket.max_value = 2147483647
	    curve_id_socket.subtype = 'NONE'
	    curve_id_socket.attribute_domain = 'CURVE'
	    curve_id_socket.description = "ID of each curve"
	
	    #Socket Length
	    length_socket = curve_info_003.interface.new_socket(name = "Length", in_out='OUTPUT', socket_type = 'NodeSocketFloat')
	    length_socket.default_value = 0.0
	    length_socket.min_value = -3.4028234663852886e+38
	    length_socket.max_value = 3.4028234663852886e+38
	    length_socket.subtype = 'NONE'
	    length_socket.attribute_domain = 'CURVE'
	    length_socket.description = "Length of each curve"
	
	    #Socket Direction
	    direction_socket = curve_info_003.interface.new_socket(name = "Direction", in_out='OUTPUT', socket_type = 'NodeSocketVector')
	    direction_socket.default_value = (0.0, 0.0, 0.0)
	    direction_socket.min_value = -3.4028234663852886e+38
	    direction_socket.max_value = 3.4028234663852886e+38
	    direction_socket.subtype = 'NONE'
	    direction_socket.attribute_domain = 'CURVE'
	    direction_socket.description = "Direction from root to tip of each curve"
	
	    #Socket Random
	    random_socket = curve_info_003.interface.new_socket(name = "Random", in_out='OUTPUT', socket_type = 'NodeSocketFloat')
	    random_socket.default_value = 0.0
	    random_socket.min_value = -3.4028234663852886e+38
	    random_socket.max_value = 3.4028234663852886e+38
	    random_socket.subtype = 'NONE'
	    random_socket.attribute_domain = 'CURVE'
	    random_socket.description = "Random vector for each curve"
	
	    #Socket Surface UV
	    surface_uv_socket = curve_info_003.interface.new_socket(name = "Surface UV", in_out='OUTPUT', socket_type = 'NodeSocketVector')
	    surface_uv_socket.default_value = (0.0, 0.0, 0.0)
	    surface_uv_socket.min_value = -3.4028234663852886e+38
	    surface_uv_socket.max_value = 3.4028234663852886e+38
	    surface_uv_socket.subtype = 'NONE'
	    surface_uv_socket.attribute_domain = 'CURVE'
	    surface_uv_socket.description = "Attachment surface UV coordinates of each curve"
	
	
	    #initialize curve_info_003 nodes
	    #node Frame
	    frame = curve_info_003.nodes.new("NodeFrame")
	    frame.label = "ID per Curve"
	    frame.name = "Frame"
	    frame.label_size = 20
	    frame.shrink = True
	
	    #node Group Output
	    group_output_2 = curve_info_003.nodes.new("NodeGroupOutput")
	    group_output_2.name = "Group Output"
	    group_output_2.is_active_output = True
	
	    #node Named Attribute
	    named_attribute = curve_info_003.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute.name = "Named Attribute"
	    named_attribute.data_type = 'FLOAT_VECTOR'
	    #Name
	    named_attribute.inputs[0].default_value = "surface_uv_coordinate"
	
	    #node Group.002
	    group_002 = curve_info_003.nodes.new("GeometryNodeGroup")
	    group_002.name = "Group.002"
	    group_002.node_tree = curve_tip_003
	    group_002.outputs[0].hide = True
	    group_002.outputs[2].hide = True
	    group_002.outputs[3].hide = True
	
	    #node Group.001
	    group_001 = curve_info_003.nodes.new("GeometryNodeGroup")
	    group_001.name = "Group.001"
	    group_001.node_tree = curve_root_006
	    group_001.outputs[0].hide = True
	    group_001.outputs[2].hide = True
	    group_001.outputs[3].hide = True
	
	    #node Evaluate at Index
	    evaluate_at_index = curve_info_003.nodes.new("GeometryNodeFieldAtIndex")
	    evaluate_at_index.name = "Evaluate at Index"
	    evaluate_at_index.data_type = 'FLOAT'
	    evaluate_at_index.domain = 'POINT'
	
	    #node Evaluate on Domain.001
	    evaluate_on_domain_001 = curve_info_003.nodes.new("GeometryNodeFieldOnDomain")
	    evaluate_on_domain_001.name = "Evaluate on Domain.001"
	    evaluate_on_domain_001.data_type = 'FLOAT'
	    evaluate_on_domain_001.domain = 'CURVE'
	
	    #node Group.003
	    group_003 = curve_info_003.nodes.new("GeometryNodeGroup")
	    group_003.name = "Group.003"
	    group_003.node_tree = curve_root_006
	    group_003.outputs[0].hide = True
	    group_003.outputs[1].hide = True
	    group_003.outputs[2].hide = True
	
	    #node Random Value.002
	    random_value_002 = curve_info_003.nodes.new("FunctionNodeRandomValue")
	    random_value_002.name = "Random Value.002"
	    random_value_002.data_type = 'FLOAT'
	    #Min_001
	    random_value_002.inputs[2].default_value = 0.0
	    #Max_001
	    random_value_002.inputs[3].default_value = 1.0
	    #Seed
	    random_value_002.inputs[8].default_value = 0
	
	    #node Reroute
	    reroute = curve_info_003.nodes.new("NodeReroute")
	    reroute.name = "Reroute"
	    reroute.socket_idname = "NodeSocketInt"
	    #node Vector Math
	    vector_math = curve_info_003.nodes.new("ShaderNodeVectorMath")
	    vector_math.name = "Vector Math"
	    vector_math.operation = 'SUBTRACT'
	
	    #node Vector Math.001
	    vector_math_001 = curve_info_003.nodes.new("ShaderNodeVectorMath")
	    vector_math_001.name = "Vector Math.001"
	    vector_math_001.operation = 'NORMALIZE'
	
	    #node Evaluate on Domain
	    evaluate_on_domain = curve_info_003.nodes.new("GeometryNodeFieldOnDomain")
	    evaluate_on_domain.name = "Evaluate on Domain"
	    evaluate_on_domain.hide = True
	    evaluate_on_domain.data_type = 'INT'
	    evaluate_on_domain.domain = 'CURVE'
	
	    #node Index.001
	    index_001 = curve_info_003.nodes.new("GeometryNodeInputIndex")
	    index_001.name = "Index.001"
	
	    #node Spline Length
	    spline_length = curve_info_003.nodes.new("GeometryNodeSplineLength")
	    spline_length.name = "Spline Length"
	    spline_length.outputs[1].hide = True
	
	    #node Evaluate at Index.001
	    evaluate_at_index_001 = curve_info_003.nodes.new("GeometryNodeFieldAtIndex")
	    evaluate_at_index_001.name = "Evaluate at Index.001"
	    evaluate_at_index_001.data_type = 'INT'
	    evaluate_at_index_001.domain = 'POINT'
	
	    #node Evaluate on Domain.002
	    evaluate_on_domain_002 = curve_info_003.nodes.new("GeometryNodeFieldOnDomain")
	    evaluate_on_domain_002.name = "Evaluate on Domain.002"
	    evaluate_on_domain_002.data_type = 'INT'
	    evaluate_on_domain_002.domain = 'CURVE'
	
	    #node Group
	    group = curve_info_003.nodes.new("GeometryNodeGroup")
	    group.name = "Group"
	    group.node_tree = curve_root_006
	    group.outputs[0].hide = True
	    group.outputs[1].hide = True
	    group.outputs[2].hide = True
	
	    #node ID
	    id = curve_info_003.nodes.new("GeometryNodeInputID")
	    id.name = "ID"
	
	
	
	
	    #Set parents
	    evaluate_at_index_001.parent = frame
	    evaluate_on_domain_002.parent = frame
	    group.parent = frame
	    id.parent = frame
	
	    #Set locations
	    frame.location = (-1200.55810546875, 150.5814208984375)
	    group_output_2.location = (75.0, 50.0)
	    named_attribute.location = (-166.11627197265625, -371.9534912109375)
	    group_002.location = (-527.7907104492188, -90.65116882324219)
	    group_001.location = (-527.7907104492188, -171.02325439453125)
	    evaluate_at_index.location = (-346.9534912109375, -211.2093048095703)
	    evaluate_on_domain_001.location = (-166.11627197265625, -211.2093048095703)
	    group_003.location = (-527.7907104492188, -251.39535522460938)
	    random_value_002.location = (-527.7907104492188, -331.7674560546875)
	    reroute.location = (-608.162841796875, 29.906982421875)
	    vector_math.location = (-346.9534912109375, -70.55814361572266)
	    vector_math_001.location = (-166.11627197265625, -70.55814361572266)
	    evaluate_on_domain.location = (-166.11627197265625, 70.093017578125)
	    index_001.location = (-346.9534912109375, 110.27906799316406)
	    spline_length.location = (-166.11627197265625, -10.279067993164062)
	    evaluate_at_index_001.location = (210.62786865234375, -40.30235290527344)
	    evaluate_on_domain_002.location = (391.465087890625, -40.30235290527344)
	    group.location = (29.7906494140625, -60.3953857421875)
	    id.location = (29.7906494140625, -140.76747131347656)
	
	    #Set dimensions
	    frame.width, frame.height = 561.9534301757812, 225.93026733398438
	    group_output_2.width, group_output_2.height = 140.0, 100.0
	    named_attribute.width, named_attribute.height = 140.0, 100.0
	    group_002.width, group_002.height = 140.0, 100.0
	    group_001.width, group_001.height = 140.0, 100.0
	    evaluate_at_index.width, evaluate_at_index.height = 140.0, 100.0
	    evaluate_on_domain_001.width, evaluate_on_domain_001.height = 140.0, 100.0
	    group_003.width, group_003.height = 140.0, 100.0
	    random_value_002.width, random_value_002.height = 140.0, 100.0
	    reroute.width, reroute.height = 100.0, 100.0
	    vector_math.width, vector_math.height = 140.0, 100.0
	    vector_math_001.width, vector_math_001.height = 140.0, 100.0
	    evaluate_on_domain.width, evaluate_on_domain.height = 140.0, 100.0
	    index_001.width, index_001.height = 140.0, 100.0
	    spline_length.width, spline_length.height = 140.0, 100.0
	    evaluate_at_index_001.width, evaluate_at_index_001.height = 140.0, 100.0
	    evaluate_on_domain_002.width, evaluate_on_domain_002.height = 140.0, 100.0
	    group.width, group.height = 140.0, 100.0
	    id.width, id.height = 140.0, 100.0
	
	    #initialize curve_info_003 links
	    #index_001.Index -> evaluate_on_domain.Value
	    curve_info_003.links.new(index_001.outputs[0], evaluate_on_domain.inputs[0])
	    #evaluate_on_domain.Value -> group_output_2.Curve Index
	    curve_info_003.links.new(evaluate_on_domain.outputs[0], group_output_2.inputs[0])
	    #named_attribute.Attribute -> group_output_2.Surface UV
	    curve_info_003.links.new(named_attribute.outputs[0], group_output_2.inputs[5])
	    #evaluate_at_index_001.Value -> evaluate_on_domain_002.Value
	    curve_info_003.links.new(evaluate_at_index_001.outputs[0], evaluate_on_domain_002.inputs[0])
	    #group.Root Index -> evaluate_at_index_001.Index
	    curve_info_003.links.new(group.outputs[3], evaluate_at_index_001.inputs[0])
	    #reroute.Output -> group_output_2.Curve ID
	    curve_info_003.links.new(reroute.outputs[0], group_output_2.inputs[1])
	    #id.ID -> evaluate_at_index_001.Value
	    curve_info_003.links.new(id.outputs[0], evaluate_at_index_001.inputs[1])
	    #spline_length.Length -> group_output_2.Length
	    curve_info_003.links.new(spline_length.outputs[0], group_output_2.inputs[2])
	    #group_002.Tip Position -> vector_math.Vector
	    curve_info_003.links.new(group_002.outputs[1], vector_math.inputs[0])
	    #group_001.Root Position -> vector_math.Vector
	    curve_info_003.links.new(group_001.outputs[1], vector_math.inputs[1])
	    #vector_math_001.Vector -> group_output_2.Direction
	    curve_info_003.links.new(vector_math_001.outputs[0], group_output_2.inputs[3])
	    #vector_math.Vector -> vector_math_001.Vector
	    curve_info_003.links.new(vector_math.outputs[0], vector_math_001.inputs[0])
	    #reroute.Output -> random_value_002.ID
	    curve_info_003.links.new(reroute.outputs[0], random_value_002.inputs[7])
	    #evaluate_at_index.Value -> evaluate_on_domain_001.Value
	    curve_info_003.links.new(evaluate_at_index.outputs[0], evaluate_on_domain_001.inputs[0])
	    #evaluate_on_domain_001.Value -> group_output_2.Random
	    curve_info_003.links.new(evaluate_on_domain_001.outputs[0], group_output_2.inputs[4])
	    #random_value_002.Value -> evaluate_at_index.Value
	    curve_info_003.links.new(random_value_002.outputs[1], evaluate_at_index.inputs[1])
	    #group_003.Root Index -> evaluate_at_index.Index
	    curve_info_003.links.new(group_003.outputs[3], evaluate_at_index.inputs[0])
	    #evaluate_on_domain_002.Value -> reroute.Input
	    curve_info_003.links.new(evaluate_on_domain_002.outputs[0], reroute.inputs[0])
	    return curve_info_003
	
	curve_info_003 = curve_info_003_node_group()
	
	#initialize duplicate_hair_curves_002 node group
	def duplicate_hair_curves_002_node_group():
	    duplicate_hair_curves_002 = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Duplicate Hair Curves.002")
	
	    duplicate_hair_curves_002.color_tag = 'NONE'
	    duplicate_hair_curves_002.description = "Duplicates hair curves a certain number of times within a radius"
	    duplicate_hair_curves_002.default_group_node_width = 140
	    
	
	    duplicate_hair_curves_002.is_modifier = True
	
	    #duplicate_hair_curves_002 interface
	    #Socket Geometry
	    geometry_socket = duplicate_hair_curves_002.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket.attribute_domain = 'POINT'
	
	    #Socket Guide Index
	    guide_index_socket = duplicate_hair_curves_002.interface.new_socket(name = "Guide Index", in_out='OUTPUT', socket_type = 'NodeSocketInt')
	    guide_index_socket.default_value = 0
	    guide_index_socket.min_value = -2147483648
	    guide_index_socket.max_value = 2147483647
	    guide_index_socket.subtype = 'NONE'
	    guide_index_socket.attribute_domain = 'CURVE'
	    guide_index_socket.description = "Guide index map that was used for the operation"
	
	    #Socket Geometry
	    geometry_socket_1 = duplicate_hair_curves_002.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_1.attribute_domain = 'POINT'
	    geometry_socket_1.description = "Input Geometry (May include other than curves)"
	
	    #Socket Amount
	    amount_socket = duplicate_hair_curves_002.interface.new_socket(name = "Amount", in_out='INPUT', socket_type = 'NodeSocketInt')
	    amount_socket.default_value = 10
	    amount_socket.min_value = 0
	    amount_socket.max_value = 2147483647
	    amount_socket.subtype = 'NONE'
	    amount_socket.attribute_domain = 'POINT'
	    amount_socket.description = "Amount of duplicates per curve"
	
	    #Socket Viewport Amount
	    viewport_amount_socket = duplicate_hair_curves_002.interface.new_socket(name = "Viewport Amount", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    viewport_amount_socket.default_value = 1.0
	    viewport_amount_socket.min_value = 0.0
	    viewport_amount_socket.max_value = 1.0
	    viewport_amount_socket.subtype = 'FACTOR'
	    viewport_amount_socket.attribute_domain = 'POINT'
	    viewport_amount_socket.description = "Percentage of amount used for the viewport"
	
	    #Socket Radius
	    radius_socket = duplicate_hair_curves_002.interface.new_socket(name = "Radius", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    radius_socket.default_value = 0.10000000149011612
	    radius_socket.min_value = 0.0
	    radius_socket.max_value = 3.4028234663852886e+38
	    radius_socket.subtype = 'DISTANCE'
	    radius_socket.attribute_domain = 'POINT'
	    radius_socket.description = "Radius in which the duplicate curves are offset from the guides"
	
	    #Socket Distribution Shape
	    distribution_shape_socket = duplicate_hair_curves_002.interface.new_socket(name = "Distribution Shape", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    distribution_shape_socket.default_value = 0.0
	    distribution_shape_socket.min_value = -10.0
	    distribution_shape_socket.max_value = 10.0
	    distribution_shape_socket.subtype = 'NONE'
	    distribution_shape_socket.attribute_domain = 'POINT'
	    distribution_shape_socket.description = "Shape of distribution from center to the edge around the guide"
	
	    #Socket Tip Roundness
	    tip_roundness_socket = duplicate_hair_curves_002.interface.new_socket(name = "Tip Roundness", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    tip_roundness_socket.default_value = 0.0
	    tip_roundness_socket.min_value = 0.0
	    tip_roundness_socket.max_value = 1.0
	    tip_roundness_socket.subtype = 'FACTOR'
	    tip_roundness_socket.attribute_domain = 'POINT'
	    tip_roundness_socket.description = "Offset of the curves to round the tip"
	
	    #Socket Even Thickness
	    even_thickness_socket = duplicate_hair_curves_002.interface.new_socket(name = "Even Thickness", in_out='INPUT', socket_type = 'NodeSocketBool')
	    even_thickness_socket.default_value = False
	    even_thickness_socket.attribute_domain = 'POINT'
	    even_thickness_socket.description = "Keep an even thickness of the distribution of duplicates"
	
	    #Socket Seed
	    seed_socket = duplicate_hair_curves_002.interface.new_socket(name = "Seed", in_out='INPUT', socket_type = 'NodeSocketInt')
	    seed_socket.default_value = 0
	    seed_socket.min_value = -10000
	    seed_socket.max_value = 10000
	    seed_socket.subtype = 'NONE'
	    seed_socket.attribute_domain = 'POINT'
	    seed_socket.description = "Random Seed for the operation"
	
	
	    #initialize duplicate_hair_curves_002 nodes
	    #node Frame.002
	    frame_002 = duplicate_hair_curves_002.nodes.new("NodeFrame")
	    frame_002.label = "Random Disc Position"
	    frame_002.name = "Frame.002"
	    frame_002.label_size = 20
	    frame_002.shrink = True
	
	    #node Frame.001
	    frame_001 = duplicate_hair_curves_002.nodes.new("NodeFrame")
	    frame_001.label = "Tangent Space per Point"
	    frame_001.name = "Frame.001"
	    frame_001.label_size = 20
	    frame_001.shrink = True
	
	    #node Frame
	    frame_1 = duplicate_hair_curves_002.nodes.new("NodeFrame")
	    frame_1.label = "Tangent Space of Root Point"
	    frame_1.name = "Frame"
	    frame_1.label_size = 20
	    frame_1.shrink = True
	
	    #node Frame.004
	    frame_004 = duplicate_hair_curves_002.nodes.new("NodeFrame")
	    frame_004.label = "Duplicate Curves"
	    frame_004.name = "Frame.004"
	    frame_004.label_size = 20
	    frame_004.shrink = True
	
	    #node Frame.003
	    frame_003 = duplicate_hair_curves_002.nodes.new("NodeFrame")
	    frame_003.label = "Random Vector per Curve"
	    frame_003.name = "Frame.003"
	    frame_003.label_size = 20
	    frame_003.shrink = True
	
	    #node Reroute.016
	    reroute_016 = duplicate_hair_curves_002.nodes.new("NodeReroute")
	    reroute_016.name = "Reroute.016"
	    reroute_016.socket_idname = "NodeSocketGeometry"
	    #node Reroute.017
	    reroute_017 = duplicate_hair_curves_002.nodes.new("NodeReroute")
	    reroute_017.name = "Reroute.017"
	    reroute_017.socket_idname = "NodeSocketGeometry"
	    #node Reroute.019
	    reroute_019 = duplicate_hair_curves_002.nodes.new("NodeReroute")
	    reroute_019.name = "Reroute.019"
	    reroute_019.socket_idname = "NodeSocketGeometry"
	    #node Reroute.018
	    reroute_018 = duplicate_hair_curves_002.nodes.new("NodeReroute")
	    reroute_018.name = "Reroute.018"
	    reroute_018.socket_idname = "NodeSocketGeometry"
	    #node Group Input
	    group_input = duplicate_hair_curves_002.nodes.new("NodeGroupInput")
	    group_input.name = "Group Input"
	    group_input.outputs[1].hide = True
	    group_input.outputs[2].hide = True
	    group_input.outputs[3].hide = True
	    group_input.outputs[4].hide = True
	    group_input.outputs[5].hide = True
	    group_input.outputs[6].hide = True
	    group_input.outputs[7].hide = True
	    group_input.outputs[8].hide = True
	
	    #node Group Output
	    group_output_3 = duplicate_hair_curves_002.nodes.new("NodeGroupOutput")
	    group_output_3.name = "Group Output"
	    group_output_3.is_active_output = True
	
	    #node Separate Components
	    separate_components = duplicate_hair_curves_002.nodes.new("GeometryNodeSeparateComponents")
	    separate_components.name = "Separate Components"
	    separate_components.hide = True
	
	    #node Math.053
	    math_053 = duplicate_hair_curves_002.nodes.new("ShaderNodeMath")
	    math_053.name = "Math.053"
	    math_053.hide = True
	    math_053.operation = 'ARCCOSINE'
	    math_053.use_clamp = False
	
	    #node Math.055
	    math_055 = duplicate_hair_curves_002.nodes.new("ShaderNodeMath")
	    math_055.name = "Math.055"
	    math_055.hide = True
	    math_055.operation = 'DIVIDE'
	    math_055.use_clamp = False
	    #Value_001
	    math_055.inputs[1].default_value = 1.5707963705062866
	
	    #node Math.056
	    math_056 = duplicate_hair_curves_002.nodes.new("ShaderNodeMath")
	    math_056.name = "Math.056"
	    math_056.hide = True
	    math_056.operation = 'POWER'
	    math_056.use_clamp = False
	    #Value
	    math_056.inputs[0].default_value = 2.0
	
	    #node Group Input.006
	    group_input_006 = duplicate_hair_curves_002.nodes.new("NodeGroupInput")
	    group_input_006.name = "Group Input.006"
	    group_input_006.outputs[0].hide = True
	    group_input_006.outputs[1].hide = True
	    group_input_006.outputs[2].hide = True
	    group_input_006.outputs[3].hide = True
	    group_input_006.outputs[5].hide = True
	    group_input_006.outputs[6].hide = True
	    group_input_006.outputs[7].hide = True
	    group_input_006.outputs[8].hide = True
	
	    #node Separate XYZ.002
	    separate_xyz_002 = duplicate_hair_curves_002.nodes.new("ShaderNodeSeparateXYZ")
	    separate_xyz_002.name = "Separate XYZ.002"
	
	    #node Math.054
	    math_054 = duplicate_hair_curves_002.nodes.new("ShaderNodeMath")
	    math_054.name = "Math.054"
	    math_054.operation = 'POWER'
	    math_054.use_clamp = False
	
	    #node Math.052
	    math_052 = duplicate_hair_curves_002.nodes.new("ShaderNodeMath")
	    math_052.name = "Math.052"
	    math_052.hide = True
	    math_052.operation = 'MULTIPLY'
	    math_052.use_clamp = False
	    #Value_001
	    math_052.inputs[1].default_value = 6.2831854820251465
	
	    #node Combine XYZ.002
	    combine_xyz_002 = duplicate_hair_curves_002.nodes.new("ShaderNodeCombineXYZ")
	    combine_xyz_002.name = "Combine XYZ.002"
	    combine_xyz_002.inputs[1].hide = True
	    combine_xyz_002.inputs[2].hide = True
	    #Y
	    combine_xyz_002.inputs[1].default_value = 0.0
	    #Z
	    combine_xyz_002.inputs[2].default_value = 0.0
	
	    #node Math.059
	    math_059 = duplicate_hair_curves_002.nodes.new("ShaderNodeMath")
	    math_059.name = "Math.059"
	    math_059.hide = True
	    math_059.operation = 'SUBTRACT'
	    math_059.use_clamp = False
	    #Value_001
	    math_059.inputs[1].default_value = 0.5
	
	    #node Math.058
	    math_058 = duplicate_hair_curves_002.nodes.new("ShaderNodeMath")
	    math_058.name = "Math.058"
	    math_058.hide = True
	    math_058.operation = 'POWER'
	    math_058.use_clamp = False
	    #Value_001
	    math_058.inputs[1].default_value = 2.0
	
	    #node Vector Rotate
	    vector_rotate = duplicate_hair_curves_002.nodes.new("ShaderNodeVectorRotate")
	    vector_rotate.name = "Vector Rotate"
	    vector_rotate.invert = False
	    vector_rotate.rotation_type = 'Z_AXIS'
	    vector_rotate.inputs[1].hide = True
	    vector_rotate.inputs[2].hide = True
	    vector_rotate.inputs[4].hide = True
	    #Center
	    vector_rotate.inputs[1].default_value = (0.0, 0.0, 0.0)
	
	    #node Math.057
	    math_057 = duplicate_hair_curves_002.nodes.new("ShaderNodeMath")
	    math_057.name = "Math.057"
	    math_057.operation = 'ADD'
	    math_057.use_clamp = False
	
	    #node Group Input.007
	    group_input_007 = duplicate_hair_curves_002.nodes.new("NodeGroupInput")
	    group_input_007.name = "Group Input.007"
	    group_input_007.outputs[0].hide = True
	    group_input_007.outputs[1].hide = True
	    group_input_007.outputs[2].hide = True
	    group_input_007.outputs[3].hide = True
	    group_input_007.outputs[4].hide = True
	    group_input_007.outputs[6].hide = True
	    group_input_007.outputs[7].hide = True
	    group_input_007.outputs[8].hide = True
	
	    #node Combine XYZ
	    combine_xyz = duplicate_hair_curves_002.nodes.new("ShaderNodeCombineXYZ")
	    combine_xyz.name = "Combine XYZ"
	    combine_xyz.inputs[0].hide = True
	    combine_xyz.inputs[1].hide = True
	    #X
	    combine_xyz.inputs[0].default_value = 0.0
	    #Y
	    combine_xyz.inputs[1].default_value = 0.0
	
	    #node Vector Math.014
	    vector_math_014 = duplicate_hair_curves_002.nodes.new("ShaderNodeVectorMath")
	    vector_math_014.name = "Vector Math.014"
	    vector_math_014.operation = 'SCALE'
	
	    #node Vector Math.013
	    vector_math_013 = duplicate_hair_curves_002.nodes.new("ShaderNodeVectorMath")
	    vector_math_013.name = "Vector Math.013"
	    vector_math_013.operation = 'SUBTRACT'
	
	    #node Reroute.001
	    reroute_001 = duplicate_hair_curves_002.nodes.new("NodeReroute")
	    reroute_001.name = "Reroute.001"
	    reroute_001.socket_idname = "NodeSocketGeometry"
	    #node Reroute.003
	    reroute_003 = duplicate_hair_curves_002.nodes.new("NodeReroute")
	    reroute_003.name = "Reroute.003"
	    reroute_003.socket_idname = "NodeSocketBool"
	    #node Set Position
	    set_position = duplicate_hair_curves_002.nodes.new("GeometryNodeSetPosition")
	    set_position.name = "Set Position"
	    #Position
	    set_position.inputs[2].default_value = (0.0, 0.0, 0.0)
	
	    #node Set Position.001
	    set_position_001 = duplicate_hair_curves_002.nodes.new("GeometryNodeSetPosition")
	    set_position_001.name = "Set Position.001"
	    #Position
	    set_position_001.inputs[2].default_value = (0.0, 0.0, 0.0)
	
	    #node Normal
	    normal = duplicate_hair_curves_002.nodes.new("GeometryNodeInputNormal")
	    normal.name = "Normal"
	    normal.legacy_corner_normals = True
	
	    #node Curve Tangent
	    curve_tangent_2 = duplicate_hair_curves_002.nodes.new("GeometryNodeInputTangent")
	    curve_tangent_2.name = "Curve Tangent"
	
	    #node Separate XYZ
	    separate_xyz = duplicate_hair_curves_002.nodes.new("ShaderNodeSeparateXYZ")
	    separate_xyz.name = "Separate XYZ"
	
	    #node Vector Math.001
	    vector_math_001_1 = duplicate_hair_curves_002.nodes.new("ShaderNodeVectorMath")
	    vector_math_001_1.name = "Vector Math.001"
	    vector_math_001_1.operation = 'SCALE'
	
	    #node Vector Math.003
	    vector_math_003 = duplicate_hair_curves_002.nodes.new("ShaderNodeVectorMath")
	    vector_math_003.name = "Vector Math.003"
	    vector_math_003.operation = 'ADD'
	
	    #node Vector Math.002
	    vector_math_002 = duplicate_hair_curves_002.nodes.new("ShaderNodeVectorMath")
	    vector_math_002.name = "Vector Math.002"
	    vector_math_002.operation = 'SCALE'
	
	    #node Vector Math.009
	    vector_math_009 = duplicate_hair_curves_002.nodes.new("ShaderNodeVectorMath")
	    vector_math_009.name = "Vector Math.009"
	    vector_math_009.operation = 'ADD'
	
	    #node Vector Math.010
	    vector_math_010 = duplicate_hair_curves_002.nodes.new("ShaderNodeVectorMath")
	    vector_math_010.name = "Vector Math.010"
	    vector_math_010.operation = 'SCALE'
	
	    #node Vector Math
	    vector_math_1 = duplicate_hair_curves_002.nodes.new("ShaderNodeVectorMath")
	    vector_math_1.name = "Vector Math"
	    vector_math_1.operation = 'CROSS_PRODUCT'
	
	    #node Group.001
	    group_001_1 = duplicate_hair_curves_002.nodes.new("GeometryNodeGroup")
	    group_001_1.name = "Group.001"
	    group_001_1.node_tree = curve_root_006
	    group_001_1.outputs[0].hide = True
	    group_001_1.outputs[1].hide = True
	    group_001_1.outputs[2].hide = True
	
	    #node Evaluate on Domain.002
	    evaluate_on_domain_002_1 = duplicate_hair_curves_002.nodes.new("GeometryNodeFieldOnDomain")
	    evaluate_on_domain_002_1.name = "Evaluate on Domain.002"
	    evaluate_on_domain_002_1.data_type = 'FLOAT_VECTOR'
	    evaluate_on_domain_002_1.domain = 'CURVE'
	
	    #node Separate XYZ.001
	    separate_xyz_001 = duplicate_hair_curves_002.nodes.new("ShaderNodeSeparateXYZ")
	    separate_xyz_001.name = "Separate XYZ.001"
	
	    #node Vector Math.011
	    vector_math_011 = duplicate_hair_curves_002.nodes.new("ShaderNodeVectorMath")
	    vector_math_011.name = "Vector Math.011"
	    vector_math_011.operation = 'ADD'
	
	    #node Vector Math.005
	    vector_math_005 = duplicate_hair_curves_002.nodes.new("ShaderNodeVectorMath")
	    vector_math_005.name = "Vector Math.005"
	    vector_math_005.operation = 'ADD'
	
	    #node Vector Math.007
	    vector_math_007 = duplicate_hair_curves_002.nodes.new("ShaderNodeVectorMath")
	    vector_math_007.name = "Vector Math.007"
	    vector_math_007.operation = 'SCALE'
	
	    #node Vector Math.008
	    vector_math_008 = duplicate_hair_curves_002.nodes.new("ShaderNodeVectorMath")
	    vector_math_008.name = "Vector Math.008"
	    vector_math_008.operation = 'CROSS_PRODUCT'
	
	    #node Evaluate at Index
	    evaluate_at_index_1 = duplicate_hair_curves_002.nodes.new("GeometryNodeFieldAtIndex")
	    evaluate_at_index_1.name = "Evaluate at Index"
	    evaluate_at_index_1.data_type = 'FLOAT_VECTOR'
	    evaluate_at_index_1.domain = 'POINT'
	
	    #node Vector Math.012
	    vector_math_012 = duplicate_hair_curves_002.nodes.new("ShaderNodeVectorMath")
	    vector_math_012.name = "Vector Math.012"
	    vector_math_012.operation = 'SCALE'
	
	    #node Vector Math.006
	    vector_math_006 = duplicate_hair_curves_002.nodes.new("ShaderNodeVectorMath")
	    vector_math_006.name = "Vector Math.006"
	    vector_math_006.operation = 'SCALE'
	
	    #node Evaluate on Domain.001
	    evaluate_on_domain_001_1 = duplicate_hair_curves_002.nodes.new("GeometryNodeFieldOnDomain")
	    evaluate_on_domain_001_1.name = "Evaluate on Domain.001"
	    evaluate_on_domain_001_1.hide = True
	    evaluate_on_domain_001_1.data_type = 'FLOAT_VECTOR'
	    evaluate_on_domain_001_1.domain = 'POINT'
	
	    #node Curve Tangent.001
	    curve_tangent_001 = duplicate_hair_curves_002.nodes.new("GeometryNodeInputTangent")
	    curve_tangent_001.name = "Curve Tangent.001"
	
	    #node Normal.001
	    normal_001 = duplicate_hair_curves_002.nodes.new("GeometryNodeInputNormal")
	    normal_001.name = "Normal.001"
	    normal_001.legacy_corner_normals = True
	
	    #node Reroute.014
	    reroute_014 = duplicate_hair_curves_002.nodes.new("NodeReroute")
	    reroute_014.name = "Reroute.014"
	    reroute_014.socket_idname = "NodeSocketGeometry"
	    #node Reroute.015
	    reroute_015 = duplicate_hair_curves_002.nodes.new("NodeReroute")
	    reroute_015.name = "Reroute.015"
	    reroute_015.socket_idname = "NodeSocketGeometry"
	    #node Reroute.013
	    reroute_013 = duplicate_hair_curves_002.nodes.new("NodeReroute")
	    reroute_013.name = "Reroute.013"
	    reroute_013.socket_idname = "NodeSocketGeometry"
	    #node Reroute.012
	    reroute_012 = duplicate_hair_curves_002.nodes.new("NodeReroute")
	    reroute_012.name = "Reroute.012"
	    reroute_012.socket_idname = "NodeSocketGeometry"
	    #node Is Viewport
	    is_viewport = duplicate_hair_curves_002.nodes.new("GeometryNodeIsViewport")
	    is_viewport.name = "Is Viewport"
	
	    #node Switch
	    switch = duplicate_hair_curves_002.nodes.new("GeometryNodeSwitch")
	    switch.name = "Switch"
	    switch.input_type = 'INT'
	
	    #node ID
	    id_1 = duplicate_hair_curves_002.nodes.new("GeometryNodeInputID")
	    id_1.name = "ID"
	
	    #node Reroute.004
	    reroute_004 = duplicate_hair_curves_002.nodes.new("NodeReroute")
	    reroute_004.name = "Reroute.004"
	    reroute_004.socket_idname = "NodeSocketInt"
	    #node Reroute.002
	    reroute_002 = duplicate_hair_curves_002.nodes.new("NodeReroute")
	    reroute_002.name = "Reroute.002"
	    reroute_002.socket_idname = "NodeSocketGeometry"
	    #node Join Geometry
	    join_geometry = duplicate_hair_curves_002.nodes.new("GeometryNodeJoinGeometry")
	    join_geometry.name = "Join Geometry"
	
	    #node Set ID
	    set_id = duplicate_hair_curves_002.nodes.new("GeometryNodeSetID")
	    set_id.name = "Set ID"
	    #Selection
	    set_id.inputs[1].default_value = True
	
	    #node Store Named Attribute
	    store_named_attribute = duplicate_hair_curves_002.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute.name = "Store Named Attribute"
	    store_named_attribute.data_type = 'INT'
	    store_named_attribute.domain = 'CURVE'
	    #Selection
	    store_named_attribute.inputs[1].default_value = True
	    #Name
	    store_named_attribute.inputs[2].default_value = "guide_curve_index"
	
	    #node Math
	    math = duplicate_hair_curves_002.nodes.new("ShaderNodeMath")
	    math.name = "Math"
	    math.hide = True
	    math.operation = 'MULTIPLY'
	    math.use_clamp = False
	
	    #node Group Input.002
	    group_input_002 = duplicate_hair_curves_002.nodes.new("NodeGroupInput")
	    group_input_002.name = "Group Input.002"
	    group_input_002.outputs[0].hide = True
	    group_input_002.outputs[1].hide = True
	    group_input_002.outputs[3].hide = True
	    group_input_002.outputs[4].hide = True
	    group_input_002.outputs[5].hide = True
	    group_input_002.outputs[6].hide = True
	    group_input_002.outputs[7].hide = True
	    group_input_002.outputs[8].hide = True
	
	    #node Group Input.004
	    group_input_004 = duplicate_hair_curves_002.nodes.new("NodeGroupInput")
	    group_input_004.name = "Group Input.004"
	    group_input_004.outputs[0].hide = True
	    group_input_004.outputs[2].hide = True
	    group_input_004.outputs[3].hide = True
	    group_input_004.outputs[4].hide = True
	    group_input_004.outputs[5].hide = True
	    group_input_004.outputs[6].hide = True
	    group_input_004.outputs[7].hide = True
	    group_input_004.outputs[8].hide = True
	
	    #node Capture Attribute.002
	    capture_attribute_002 = duplicate_hair_curves_002.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_002.name = "Capture Attribute.002"
	    capture_attribute_002.active_index = 0
	    capture_attribute_002.capture_items.clear()
	    capture_attribute_002.capture_items.new('FLOAT', "Value")
	    capture_attribute_002.capture_items["Value"].data_type = 'BOOLEAN'
	    capture_attribute_002.domain = 'POINT'
	    #Value
	    capture_attribute_002.inputs[1].default_value = True
	
	    #node Vector Math.004
	    vector_math_004 = duplicate_hair_curves_002.nodes.new("ShaderNodeVectorMath")
	    vector_math_004.name = "Vector Math.004"
	    vector_math_004.operation = 'SCALE'
	
	    #node Group Input.003
	    group_input_003 = duplicate_hair_curves_002.nodes.new("NodeGroupInput")
	    group_input_003.name = "Group Input.003"
	    group_input_003.outputs[0].hide = True
	    group_input_003.outputs[1].hide = True
	    group_input_003.outputs[2].hide = True
	    group_input_003.outputs[4].hide = True
	    group_input_003.outputs[5].hide = True
	    group_input_003.outputs[6].hide = True
	    group_input_003.outputs[7].hide = True
	    group_input_003.outputs[8].hide = True
	
	    #node Random Value.001
	    random_value_001 = duplicate_hair_curves_002.nodes.new("FunctionNodeRandomValue")
	    random_value_001.name = "Random Value.001"
	    random_value_001.data_type = 'FLOAT_VECTOR'
	    #Min
	    random_value_001.inputs[0].default_value = (0.0, 0.0, 0.0)
	    #Max
	    random_value_001.inputs[1].default_value = (1.0, 1.0, 1.0)
	
	    #node Capture Attribute
	    capture_attribute = duplicate_hair_curves_002.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute.name = "Capture Attribute"
	    capture_attribute.active_index = 0
	    capture_attribute.capture_items.clear()
	    capture_attribute.capture_items.new('FLOAT', "Value")
	    capture_attribute.capture_items["Value"].data_type = 'INT'
	    capture_attribute.domain = 'POINT'
	
	    #node Duplicate Elements
	    duplicate_elements = duplicate_hair_curves_002.nodes.new("GeometryNodeDuplicateElements")
	    duplicate_elements.name = "Duplicate Elements"
	    duplicate_elements.domain = 'SPLINE'
	    #Selection
	    duplicate_elements.inputs[1].default_value = True
	
	    #node Join Geometry.001
	    join_geometry_001 = duplicate_hair_curves_002.nodes.new("GeometryNodeJoinGeometry")
	    join_geometry_001.name = "Join Geometry.001"
	
	    #node Random Value
	    random_value = duplicate_hair_curves_002.nodes.new("FunctionNodeRandomValue")
	    random_value.name = "Random Value"
	    random_value.data_type = 'INT'
	    #Min_002
	    random_value.inputs[4].default_value = -1073741823
	    #Max_002
	    random_value.inputs[5].default_value = 1073741823
	
	    #node Reroute.020
	    reroute_020 = duplicate_hair_curves_002.nodes.new("NodeReroute")
	    reroute_020.name = "Reroute.020"
	    reroute_020.socket_idname = "NodeSocketGeometry"
	    #node Index
	    index = duplicate_hair_curves_002.nodes.new("GeometryNodeInputIndex")
	    index.name = "Index"
	
	    #node Capture Attribute.001
	    capture_attribute_001 = duplicate_hair_curves_002.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_001.name = "Capture Attribute.001"
	    capture_attribute_001.active_index = 0
	    capture_attribute_001.capture_items.clear()
	    capture_attribute_001.capture_items.new('FLOAT', "Value")
	    capture_attribute_001.capture_items["Value"].data_type = 'INT'
	    capture_attribute_001.domain = 'CURVE'
	
	    #node Switch.001
	    switch_001 = duplicate_hair_curves_002.nodes.new("GeometryNodeSwitch")
	    switch_001.name = "Switch.001"
	    switch_001.input_type = 'GEOMETRY'
	
	    #node Group
	    group_1 = duplicate_hair_curves_002.nodes.new("GeometryNodeGroup")
	    group_1.name = "Group"
	    group_1.node_tree = curve_info_003
	    group_1.outputs[0].hide = True
	    group_1.outputs[2].hide = True
	    group_1.outputs[3].hide = True
	    group_1.outputs[4].hide = True
	    group_1.outputs[5].hide = True
	
	    #node Group Input.001
	    group_input_001 = duplicate_hair_curves_002.nodes.new("NodeGroupInput")
	    group_input_001.name = "Group Input.001"
	    group_input_001.outputs[0].hide = True
	    group_input_001.outputs[1].hide = True
	    group_input_001.outputs[2].hide = True
	    group_input_001.outputs[3].hide = True
	    group_input_001.outputs[4].hide = True
	    group_input_001.outputs[5].hide = True
	    group_input_001.outputs[6].hide = True
	    group_input_001.outputs[8].hide = True
	
	    #node Group Input.005
	    group_input_005 = duplicate_hair_curves_002.nodes.new("NodeGroupInput")
	    group_input_005.name = "Group Input.005"
	    group_input_005.outputs[0].hide = True
	    group_input_005.outputs[1].hide = True
	    group_input_005.outputs[2].hide = True
	    group_input_005.outputs[3].hide = True
	    group_input_005.outputs[4].hide = True
	    group_input_005.outputs[5].hide = True
	    group_input_005.outputs[7].hide = True
	    group_input_005.outputs[8].hide = True
	
	    #node Random Value.004
	    random_value_004 = duplicate_hair_curves_002.nodes.new("FunctionNodeRandomValue")
	    random_value_004.name = "Random Value.004"
	    random_value_004.data_type = 'INT'
	    #Min_002
	    random_value_004.inputs[4].default_value = -1073741823
	    #Max_002
	    random_value_004.inputs[5].default_value = 1073741823
	    #Seed
	    random_value_004.inputs[8].default_value = 296
	
	
	
	
	    #Set parents
	    math_053.parent = frame_002
	    math_055.parent = frame_002
	    math_056.parent = frame_002
	    group_input_006.parent = frame_002
	    separate_xyz_002.parent = frame_002
	    math_054.parent = frame_002
	    math_052.parent = frame_002
	    combine_xyz_002.parent = frame_002
	    math_059.parent = frame_002
	    math_058.parent = frame_002
	    vector_rotate.parent = frame_002
	    math_057.parent = frame_002
	    group_input_007.parent = frame_002
	    combine_xyz.parent = frame_002
	    vector_math_014.parent = frame_002
	    vector_math_013.parent = frame_002
	    normal.parent = frame_001
	    curve_tangent_2.parent = frame_001
	    separate_xyz.parent = frame_001
	    vector_math_001_1.parent = frame_001
	    vector_math_003.parent = frame_001
	    vector_math_002.parent = frame_001
	    vector_math_009.parent = frame_001
	    vector_math_010.parent = frame_001
	    vector_math_1.parent = frame_001
	    group_001_1.parent = frame_1
	    evaluate_on_domain_002_1.parent = frame_1
	    separate_xyz_001.parent = frame_1
	    vector_math_011.parent = frame_1
	    vector_math_005.parent = frame_1
	    vector_math_007.parent = frame_1
	    vector_math_008.parent = frame_1
	    evaluate_at_index_1.parent = frame_1
	    vector_math_012.parent = frame_1
	    vector_math_006.parent = frame_1
	    evaluate_on_domain_001_1.parent = frame_1
	    curve_tangent_001.parent = frame_1
	    normal_001.parent = frame_1
	    is_viewport.parent = frame_004
	    switch.parent = frame_004
	    id_1.parent = frame_004
	    reroute_004.parent = frame_004
	    reroute_002.parent = frame_004
	    join_geometry.parent = frame_004
	    set_id.parent = frame_004
	    store_named_attribute.parent = frame_004
	    math.parent = frame_004
	    group_input_002.parent = frame_004
	    group_input_004.parent = frame_004
	    capture_attribute_002.parent = frame_004
	    random_value_001.parent = frame_003
	    capture_attribute.parent = frame_004
	    duplicate_elements.parent = frame_004
	    random_value.parent = frame_004
	    group_1.parent = frame_003
	    group_input_001.parent = frame_003
	    random_value_004.parent = frame_003
	
	    #Set locations
	    frame_002.location = (-4255.0, -613.0)
	    frame_001.location = (-1965.0, -734.0)
	    frame_1.location = (-2265.0, -272.0)
	    frame_004.location = (-2910.0, 228.0)
	    frame_003.location = (-4868.0, -613.0)
	    reroute_016.location = (-431.521728515625, 395.1722106933594)
	    reroute_017.location = (-431.521728515625, 354.9861755371094)
	    reroute_019.location = (-431.521728515625, 314.8001403808594)
	    reroute_018.location = (-431.521728515625, 274.6141052246094)
	    group_input.location = (-3843.1396484375, 29.906982421875)
	    group_output_3.location = (75.0, 50.0)
	    separate_components.location = (-3652.255859375, 19.86041259765625)
	    math_053.location = (230.622802734375, -60.3717041015625)
	    math_055.location = (230.622802734375, -100.5577392578125)
	    math_056.location = (190.436767578125, -221.11590576171875)
	    group_input_006.location = (29.6923828125, -221.11590576171875)
	    separate_xyz_002.location = (29.6923828125, -60.3717041015625)
	    math_054.location = (411.4599609375, -80.4647216796875)
	    math_052.location = (411.4599609375, -201.02288818359375)
	    combine_xyz_002.location = (592.29736328125, -40.2786865234375)
	    math_059.location = (592.29736328125, -281.39495849609375)
	    math_058.location = (592.29736328125, -241.20892333984375)
	    vector_rotate.location = (773.13427734375, -60.3717041015625)
	    math_057.location = (773.13427734375, -201.02288818359375)
	    group_input_007.location = (953.9716796875, -301.48797607421875)
	    combine_xyz.location = (953.9716796875, -201.02288818359375)
	    vector_math_014.location = (1134.808837890625, -221.11590576171875)
	    vector_math_013.location = (1335.739013671875, -140.7437744140625)
	    reroute_001.location = (-839.232666015625, -160.97679138183594)
	    reroute_003.location = (-839.232666015625, -281.5349426269531)
	    set_position.location = (-738.7674560546875, -241.348876953125)
	    set_position_001.location = (-738.7674560546875, -80.60469055175781)
	    normal.location = (30.2864990234375, -160.773193359375)
	    curve_tangent_2.location = (30.2864990234375, -100.494140625)
	    separate_xyz.location = (231.216796875, -221.05230712890625)
	    vector_math_001_1.location = (412.053955078125, -40.215087890625)
	    vector_math_003.location = (592.8912353515625, -40.215087890625)
	    vector_math_002.location = (412.053955078125, -180.86627197265625)
	    vector_math_009.location = (793.8214111328125, -40.215087890625)
	    vector_math_010.location = (592.8912353515625, -200.95928955078125)
	    vector_math_1.location = (231.216796875, -40.215087890625)
	    group_001_1.location = (743.9742431640625, -60.11541748046875)
	    evaluate_on_domain_002_1.location = (1105.648681640625, -40.02239990234375)
	    separate_xyz_001.location = (201.46240234375, -261.045654296875)
	    vector_math_011.location = (743.9742431640625, -140.487548828125)
	    vector_math_005.location = (563.136962890625, -140.487548828125)
	    vector_math_007.location = (382.2998046875, -120.39453125)
	    vector_math_008.location = (201.46240234375, -120.39453125)
	    evaluate_at_index_1.location = (924.8114013671875, -40.02239990234375)
	    vector_math_012.location = (563.136962890625, -301.231689453125)
	    vector_math_006.location = (382.2998046875, -261.045654296875)
	    evaluate_on_domain_001_1.location = (29.70654296875, -339.79510498046875)
	    curve_tangent_001.location = (29.70654296875, -118.77178955078125)
	    normal_001.location = (29.70654296875, -179.0509033203125)
	    reroute_014.location = (-3230.302490234375, 341.3487854003906)
	    reroute_015.location = (-3230.302490234375, 301.1627502441406)
	    reroute_013.location = (-3230.302490234375, 260.9767150878906)
	    reroute_012.location = (-3230.302490234375, 381.5348815917969)
	    is_viewport.location = (280.716064453125, -275.73028564453125)
	    switch.location = (461.55322265625, -235.54425048828125)
	    id_1.location = (29.55322265625, -205.40472412109375)
	    reroute_004.location = (1375.44677734375, -241.39447021484375)
	    reroute_002.location = (571.725830078125, -100.7432861328125)
	    join_geometry.location = (1074.0513916015625, -60.5572509765625)
	    set_id.location = (1274.981689453125, -60.5572509765625)
	    store_named_attribute.location = (1475.911865234375, -40.464202880859375)
	    math.location = (290.423583984375, -382.0456237792969)
	    group_input_002.location = (89.4931640625, -382.0456237792969)
	    group_input_004.location = (89.4931640625, -321.7665710449219)
	    capture_attribute_002.location = (843.28857421875, -131.15524291992188)
	    vector_math_004.location = (-2506.95361328125, -703.4884033203125)
	    group_input_003.location = (-2687.790771484375, -824.0465698242188)
	    random_value_001.location = (381.48486328125, -40.2786865234375)
	    capture_attribute.location = (224.854736328125, -51.218994140625)
	    duplicate_elements.location = (652.097900390625, -120.83633422851562)
	    join_geometry_001.location = (-130.127197265625, 53.59075927734375)
	    random_value.location = (1074.0513916015625, -161.02236938476562)
	    reroute_020.location = (-223.732666015625, -87.405517578125)
	    index.location = (-3431.232666015625, -100.69772338867188)
	    capture_attribute_001.location = (-3210.20947265625, 60.046478271484375)
	    switch_001.location = (-507.69775390625, -50.46514892578125)
	    group_1.location = (211.0927734375, -211.04656982421875)
	    group_input_001.location = (30.255859375, -331.604736328125)
	    group_input_005.location = (-738.7674560546875, -0.23260498046875)
	    random_value_004.location = (211.0927734375, -291.418701171875)
	
	    #Set dimensions
	    frame_002.width, frame_002.height = 1506.0, 383.0
	    frame_001.width, frame_001.height = 964.0, 370.0
	    frame_1.width, frame_1.height = 1276.0, 454.0
	    frame_004.width, frame_004.height = 1646.0, 464.0
	    frame_003.width, frame_003.height = 551.0, 488.0
	    reroute_016.width, reroute_016.height = 100.0, 100.0
	    reroute_017.width, reroute_017.height = 100.0, 100.0
	    reroute_019.width, reroute_019.height = 100.0, 100.0
	    reroute_018.width, reroute_018.height = 100.0, 100.0
	    group_input.width, group_input.height = 140.0, 100.0
	    group_output_3.width, group_output_3.height = 140.0, 100.0
	    separate_components.width, separate_components.height = 140.0, 100.0
	    math_053.width, math_053.height = 140.0, 100.0
	    math_055.width, math_055.height = 140.0, 100.0
	    math_056.width, math_056.height = 140.0, 100.0
	    group_input_006.width, group_input_006.height = 140.0, 100.0
	    separate_xyz_002.width, separate_xyz_002.height = 140.0, 100.0
	    math_054.width, math_054.height = 140.0, 100.0
	    math_052.width, math_052.height = 140.0, 100.0
	    combine_xyz_002.width, combine_xyz_002.height = 140.0, 100.0
	    math_059.width, math_059.height = 140.0, 100.0
	    math_058.width, math_058.height = 140.0, 100.0
	    vector_rotate.width, vector_rotate.height = 140.0, 100.0
	    math_057.width, math_057.height = 140.0, 100.0
	    group_input_007.width, group_input_007.height = 140.0, 100.0
	    combine_xyz.width, combine_xyz.height = 140.0, 100.0
	    vector_math_014.width, vector_math_014.height = 140.0, 100.0
	    vector_math_013.width, vector_math_013.height = 140.0, 100.0
	    reroute_001.width, reroute_001.height = 100.0, 100.0
	    reroute_003.width, reroute_003.height = 100.0, 100.0
	    set_position.width, set_position.height = 140.0, 100.0
	    set_position_001.width, set_position_001.height = 140.0, 100.0
	    normal.width, normal.height = 140.0, 100.0
	    curve_tangent_2.width, curve_tangent_2.height = 140.0, 100.0
	    separate_xyz.width, separate_xyz.height = 140.0, 100.0
	    vector_math_001_1.width, vector_math_001_1.height = 140.0, 100.0
	    vector_math_003.width, vector_math_003.height = 140.0, 100.0
	    vector_math_002.width, vector_math_002.height = 140.0, 100.0
	    vector_math_009.width, vector_math_009.height = 140.0, 100.0
	    vector_math_010.width, vector_math_010.height = 140.0, 100.0
	    vector_math_1.width, vector_math_1.height = 140.0, 100.0
	    group_001_1.width, group_001_1.height = 140.0, 100.0
	    evaluate_on_domain_002_1.width, evaluate_on_domain_002_1.height = 140.0, 100.0
	    separate_xyz_001.width, separate_xyz_001.height = 140.0, 100.0
	    vector_math_011.width, vector_math_011.height = 140.0, 100.0
	    vector_math_005.width, vector_math_005.height = 140.0, 100.0
	    vector_math_007.width, vector_math_007.height = 140.0, 100.0
	    vector_math_008.width, vector_math_008.height = 140.0, 100.0
	    evaluate_at_index_1.width, evaluate_at_index_1.height = 140.0, 100.0
	    vector_math_012.width, vector_math_012.height = 140.0, 100.0
	    vector_math_006.width, vector_math_006.height = 140.0, 100.0
	    evaluate_on_domain_001_1.width, evaluate_on_domain_001_1.height = 140.0, 100.0
	    curve_tangent_001.width, curve_tangent_001.height = 140.0, 100.0
	    normal_001.width, normal_001.height = 140.0, 100.0
	    reroute_014.width, reroute_014.height = 100.0, 100.0
	    reroute_015.width, reroute_015.height = 100.0, 100.0
	    reroute_013.width, reroute_013.height = 100.0, 100.0
	    reroute_012.width, reroute_012.height = 100.0, 100.0
	    is_viewport.width, is_viewport.height = 140.0, 100.0
	    switch.width, switch.height = 140.0, 100.0
	    id_1.width, id_1.height = 140.0, 100.0
	    reroute_004.width, reroute_004.height = 100.0, 100.0
	    reroute_002.width, reroute_002.height = 100.0, 100.0
	    join_geometry.width, join_geometry.height = 140.0, 100.0
	    set_id.width, set_id.height = 140.0, 100.0
	    store_named_attribute.width, store_named_attribute.height = 140.0, 100.0
	    math.width, math.height = 140.0, 100.0
	    group_input_002.width, group_input_002.height = 140.0, 100.0
	    group_input_004.width, group_input_004.height = 140.0, 100.0
	    capture_attribute_002.width, capture_attribute_002.height = 140.0, 100.0
	    vector_math_004.width, vector_math_004.height = 140.0, 100.0
	    group_input_003.width, group_input_003.height = 140.0, 100.0
	    random_value_001.width, random_value_001.height = 140.0, 100.0
	    capture_attribute.width, capture_attribute.height = 140.0, 100.0
	    duplicate_elements.width, duplicate_elements.height = 140.0, 100.0
	    join_geometry_001.width, join_geometry_001.height = 140.0, 100.0
	    random_value.width, random_value.height = 140.0, 100.0
	    reroute_020.width, reroute_020.height = 100.0, 100.0
	    index.width, index.height = 140.0, 100.0
	    capture_attribute_001.width, capture_attribute_001.height = 140.0, 100.0
	    switch_001.width, switch_001.height = 140.0, 100.0
	    group_1.width, group_1.height = 140.0, 100.0
	    group_input_001.width, group_input_001.height = 140.0, 100.0
	    group_input_005.width, group_input_005.height = 140.0, 100.0
	    random_value_004.width, random_value_004.height = 140.0, 100.0
	
	    #initialize duplicate_hair_curves_002 links
	    #join_geometry_001.Geometry -> group_output_3.Geometry
	    duplicate_hair_curves_002.links.new(join_geometry_001.outputs[0], group_output_3.inputs[0])
	    #reroute_002.Output -> duplicate_elements.Geometry
	    duplicate_hair_curves_002.links.new(reroute_002.outputs[0], duplicate_elements.inputs[0])
	    #capture_attribute_001.Geometry -> capture_attribute.Geometry
	    duplicate_hair_curves_002.links.new(capture_attribute_001.outputs[0], capture_attribute.inputs[0])
	    #random_value.Value -> set_id.ID
	    duplicate_hair_curves_002.links.new(random_value.outputs[2], set_id.inputs[2])
	    #capture_attribute.Value -> random_value.ID
	    duplicate_hair_curves_002.links.new(capture_attribute.outputs[1], random_value.inputs[7])
	    #duplicate_elements.Duplicate Index -> random_value.Seed
	    duplicate_hair_curves_002.links.new(duplicate_elements.outputs[1], random_value.inputs[8])
	    #random_value_001.Value -> separate_xyz_002.Vector
	    duplicate_hair_curves_002.links.new(random_value_001.outputs[0], separate_xyz_002.inputs[0])
	    #math_052.Value -> vector_rotate.Angle
	    duplicate_hair_curves_002.links.new(math_052.outputs[0], vector_rotate.inputs[3])
	    #combine_xyz_002.Vector -> vector_rotate.Vector
	    duplicate_hair_curves_002.links.new(combine_xyz_002.outputs[0], vector_rotate.inputs[0])
	    #separate_xyz_002.Y -> math_052.Value
	    duplicate_hair_curves_002.links.new(separate_xyz_002.outputs[1], math_052.inputs[0])
	    #separate_xyz_002.X -> math_053.Value
	    duplicate_hair_curves_002.links.new(separate_xyz_002.outputs[0], math_053.inputs[0])
	    #math_054.Value -> combine_xyz_002.X
	    duplicate_hair_curves_002.links.new(math_054.outputs[0], combine_xyz_002.inputs[0])
	    #group_1.Curve ID -> random_value_001.ID
	    duplicate_hair_curves_002.links.new(group_1.outputs[1], random_value_001.inputs[7])
	    #vector_math_004.Vector -> separate_xyz.Vector
	    duplicate_hair_curves_002.links.new(vector_math_004.outputs[0], separate_xyz.inputs[0])
	    #reroute_001.Output -> set_position.Geometry
	    duplicate_hair_curves_002.links.new(reroute_001.outputs[0], set_position.inputs[0])
	    #curve_tangent_2.Tangent -> vector_math_1.Vector
	    duplicate_hair_curves_002.links.new(curve_tangent_2.outputs[0], vector_math_1.inputs[0])
	    #normal.Normal -> vector_math_1.Vector
	    duplicate_hair_curves_002.links.new(normal.outputs[0], vector_math_1.inputs[1])
	    #vector_math_1.Vector -> vector_math_001_1.Vector
	    duplicate_hair_curves_002.links.new(vector_math_1.outputs[0], vector_math_001_1.inputs[0])
	    #vector_math_001_1.Vector -> vector_math_003.Vector
	    duplicate_hair_curves_002.links.new(vector_math_001_1.outputs[0], vector_math_003.inputs[0])
	    #vector_math_002.Vector -> vector_math_003.Vector
	    duplicate_hair_curves_002.links.new(vector_math_002.outputs[0], vector_math_003.inputs[1])
	    #separate_xyz.X -> vector_math_001_1.Scale
	    duplicate_hair_curves_002.links.new(separate_xyz.outputs[0], vector_math_001_1.inputs[3])
	    #separate_xyz.Y -> vector_math_002.Scale
	    duplicate_hair_curves_002.links.new(separate_xyz.outputs[1], vector_math_002.inputs[3])
	    #normal.Normal -> vector_math_002.Vector
	    duplicate_hair_curves_002.links.new(normal.outputs[0], vector_math_002.inputs[0])
	    #index.Index -> capture_attribute_001.Value
	    duplicate_hair_curves_002.links.new(index.outputs[0], capture_attribute_001.inputs[1])
	    #set_id.Geometry -> store_named_attribute.Geometry
	    duplicate_hair_curves_002.links.new(set_id.outputs[0], store_named_attribute.inputs[0])
	    #capture_attribute_002.Geometry -> join_geometry.Geometry
	    duplicate_hair_curves_002.links.new(capture_attribute_002.outputs[0], join_geometry.inputs[0])
	    #reroute_004.Output -> store_named_attribute.Value
	    duplicate_hair_curves_002.links.new(reroute_004.outputs[0], store_named_attribute.inputs[3])
	    #group_input_004.Amount -> switch.False
	    duplicate_hair_curves_002.links.new(group_input_004.outputs[1], switch.inputs[1])
	    #switch.Output -> duplicate_elements.Amount
	    duplicate_hair_curves_002.links.new(switch.outputs[0], duplicate_elements.inputs[2])
	    #is_viewport.Is Viewport -> switch.Switch
	    duplicate_hair_curves_002.links.new(is_viewport.outputs[0], switch.inputs[0])
	    #group_input_004.Amount -> math.Value
	    duplicate_hair_curves_002.links.new(group_input_004.outputs[1], math.inputs[0])
	    #math.Value -> switch.True
	    duplicate_hair_curves_002.links.new(math.outputs[0], switch.inputs[2])
	    #group_input_002.Viewport Amount -> math.Value
	    duplicate_hair_curves_002.links.new(group_input_002.outputs[2], math.inputs[1])
	    #id_1.ID -> capture_attribute.Value
	    duplicate_hair_curves_002.links.new(id_1.outputs[0], capture_attribute.inputs[1])
	    #vector_math_009.Vector -> set_position.Offset
	    duplicate_hair_curves_002.links.new(vector_math_009.outputs[0], set_position.inputs[3])
	    #group_input_005.Even Thickness -> switch_001.Switch
	    duplicate_hair_curves_002.links.new(group_input_005.outputs[6], switch_001.inputs[0])
	    #vector_math_007.Vector -> vector_math_005.Vector
	    duplicate_hair_curves_002.links.new(vector_math_007.outputs[0], vector_math_005.inputs[0])
	    #vector_math_006.Vector -> vector_math_005.Vector
	    duplicate_hair_curves_002.links.new(vector_math_006.outputs[0], vector_math_005.inputs[1])
	    #separate_xyz_001.X -> vector_math_007.Scale
	    duplicate_hair_curves_002.links.new(separate_xyz_001.outputs[0], vector_math_007.inputs[3])
	    #separate_xyz_001.Y -> vector_math_006.Scale
	    duplicate_hair_curves_002.links.new(separate_xyz_001.outputs[1], vector_math_006.inputs[3])
	    #evaluate_on_domain_002_1.Value -> set_position_001.Offset
	    duplicate_hair_curves_002.links.new(evaluate_on_domain_002_1.outputs[0], set_position_001.inputs[3])
	    #curve_tangent_001.Tangent -> vector_math_008.Vector
	    duplicate_hair_curves_002.links.new(curve_tangent_001.outputs[0], vector_math_008.inputs[0])
	    #normal_001.Normal -> vector_math_008.Vector
	    duplicate_hair_curves_002.links.new(normal_001.outputs[0], vector_math_008.inputs[1])
	    #evaluate_at_index_1.Value -> evaluate_on_domain_002_1.Value
	    duplicate_hair_curves_002.links.new(evaluate_at_index_1.outputs[0], evaluate_on_domain_002_1.inputs[0])
	    #vector_math_008.Vector -> vector_math_007.Vector
	    duplicate_hair_curves_002.links.new(vector_math_008.outputs[0], vector_math_007.inputs[0])
	    #normal_001.Normal -> vector_math_006.Vector
	    duplicate_hair_curves_002.links.new(normal_001.outputs[0], vector_math_006.inputs[0])
	    #evaluate_on_domain_001_1.Value -> separate_xyz_001.Vector
	    duplicate_hair_curves_002.links.new(evaluate_on_domain_001_1.outputs[0], separate_xyz_001.inputs[0])
	    #store_named_attribute.Geometry -> reroute_001.Input
	    duplicate_hair_curves_002.links.new(store_named_attribute.outputs[0], reroute_001.inputs[0])
	    #reroute_001.Output -> set_position_001.Geometry
	    duplicate_hair_curves_002.links.new(reroute_001.outputs[0], set_position_001.inputs[0])
	    #vector_math_011.Vector -> evaluate_at_index_1.Value
	    duplicate_hair_curves_002.links.new(vector_math_011.outputs[0], evaluate_at_index_1.inputs[1])
	    #group_001_1.Root Index -> evaluate_at_index_1.Index
	    duplicate_hair_curves_002.links.new(group_001_1.outputs[3], evaluate_at_index_1.inputs[0])
	    #capture_attribute.Geometry -> reroute_002.Input
	    duplicate_hair_curves_002.links.new(capture_attribute.outputs[0], reroute_002.inputs[0])
	    #math_055.Value -> math_054.Value
	    duplicate_hair_curves_002.links.new(math_055.outputs[0], math_054.inputs[0])
	    #math_053.Value -> math_055.Value
	    duplicate_hair_curves_002.links.new(math_053.outputs[0], math_055.inputs[0])
	    #math_056.Value -> math_054.Value
	    duplicate_hair_curves_002.links.new(math_056.outputs[0], math_054.inputs[1])
	    #group_input_006.Distribution Shape -> math_056.Value
	    duplicate_hair_curves_002.links.new(group_input_006.outputs[4], math_056.inputs[1])
	    #vector_math_003.Vector -> vector_math_009.Vector
	    duplicate_hair_curves_002.links.new(vector_math_003.outputs[0], vector_math_009.inputs[0])
	    #separate_xyz.Z -> vector_math_010.Scale
	    duplicate_hair_curves_002.links.new(separate_xyz.outputs[2], vector_math_010.inputs[3])
	    #curve_tangent_2.Tangent -> vector_math_010.Vector
	    duplicate_hair_curves_002.links.new(curve_tangent_2.outputs[0], vector_math_010.inputs[0])
	    #vector_math_010.Vector -> vector_math_009.Vector
	    duplicate_hair_curves_002.links.new(vector_math_010.outputs[0], vector_math_009.inputs[1])
	    #vector_math_005.Vector -> vector_math_011.Vector
	    duplicate_hair_curves_002.links.new(vector_math_005.outputs[0], vector_math_011.inputs[0])
	    #vector_math_012.Vector -> vector_math_011.Vector
	    duplicate_hair_curves_002.links.new(vector_math_012.outputs[0], vector_math_011.inputs[1])
	    #separate_xyz_001.Z -> vector_math_012.Scale
	    duplicate_hair_curves_002.links.new(separate_xyz_001.outputs[2], vector_math_012.inputs[3])
	    #curve_tangent_001.Tangent -> vector_math_012.Vector
	    duplicate_hair_curves_002.links.new(curve_tangent_001.outputs[0], vector_math_012.inputs[0])
	    #vector_rotate.Vector -> vector_math_013.Vector
	    duplicate_hair_curves_002.links.new(vector_rotate.outputs[0], vector_math_013.inputs[0])
	    #vector_math_014.Vector -> vector_math_013.Vector
	    duplicate_hair_curves_002.links.new(vector_math_014.outputs[0], vector_math_013.inputs[1])
	    #math_057.Value -> combine_xyz.Z
	    duplicate_hair_curves_002.links.new(math_057.outputs[0], combine_xyz.inputs[2])
	    #vector_math_013.Vector -> vector_math_004.Vector
	    duplicate_hair_curves_002.links.new(vector_math_013.outputs[0], vector_math_004.inputs[0])
	    #group_input_003.Radius -> vector_math_004.Scale
	    duplicate_hair_curves_002.links.new(group_input_003.outputs[3], vector_math_004.inputs[3])
	    #math_058.Value -> math_057.Value
	    duplicate_hair_curves_002.links.new(math_058.outputs[0], math_057.inputs[0])
	    #math_059.Value -> math_057.Value
	    duplicate_hair_curves_002.links.new(math_059.outputs[0], math_057.inputs[1])
	    #math_054.Value -> math_058.Value
	    duplicate_hair_curves_002.links.new(math_054.outputs[0], math_058.inputs[0])
	    #combine_xyz.Vector -> vector_math_014.Vector
	    duplicate_hair_curves_002.links.new(combine_xyz.outputs[0], vector_math_014.inputs[0])
	    #group_input_007.Tip Roundness -> vector_math_014.Scale
	    duplicate_hair_curves_002.links.new(group_input_007.outputs[5], vector_math_014.inputs[3])
	    #separate_xyz_002.Z -> math_059.Value
	    duplicate_hair_curves_002.links.new(separate_xyz_002.outputs[2], math_059.inputs[0])
	    #set_position_001.Geometry -> switch_001.False
	    duplicate_hair_curves_002.links.new(set_position_001.outputs[0], switch_001.inputs[1])
	    #set_position.Geometry -> switch_001.True
	    duplicate_hair_curves_002.links.new(set_position.outputs[0], switch_001.inputs[2])
	    #reroute_003.Output -> set_position.Selection
	    duplicate_hair_curves_002.links.new(reroute_003.outputs[0], set_position.inputs[1])
	    #reroute_003.Output -> set_position_001.Selection
	    duplicate_hair_curves_002.links.new(reroute_003.outputs[0], set_position_001.inputs[1])
	    #capture_attribute_002.Value -> reroute_003.Input
	    duplicate_hair_curves_002.links.new(capture_attribute_002.outputs[1], reroute_003.inputs[0])
	    #capture_attribute_001.Value -> reroute_004.Input
	    duplicate_hair_curves_002.links.new(capture_attribute_001.outputs[1], reroute_004.inputs[0])
	    #join_geometry.Geometry -> set_id.Geometry
	    duplicate_hair_curves_002.links.new(join_geometry.outputs[0], set_id.inputs[0])
	    #duplicate_elements.Geometry -> capture_attribute_002.Geometry
	    duplicate_hair_curves_002.links.new(duplicate_elements.outputs[0], capture_attribute_002.inputs[0])
	    #group_input_001.Seed -> random_value_004.ID
	    duplicate_hair_curves_002.links.new(group_input_001.outputs[7], random_value_004.inputs[7])
	    #random_value_004.Value -> random_value_001.Seed
	    duplicate_hair_curves_002.links.new(random_value_004.outputs[2], random_value_001.inputs[8])
	    #vector_math_004.Vector -> evaluate_on_domain_001_1.Value
	    duplicate_hair_curves_002.links.new(vector_math_004.outputs[0], evaluate_on_domain_001_1.inputs[0])
	    #reroute_018.Output -> join_geometry_001.Geometry
	    duplicate_hair_curves_002.links.new(reroute_018.outputs[0], join_geometry_001.inputs[0])
	    #separate_components.Mesh -> reroute_012.Input
	    duplicate_hair_curves_002.links.new(separate_components.outputs[0], reroute_012.inputs[0])
	    #separate_components.Instances -> reroute_013.Input
	    duplicate_hair_curves_002.links.new(separate_components.outputs[5], reroute_013.inputs[0])
	    #separate_components.Point Cloud -> reroute_014.Input
	    duplicate_hair_curves_002.links.new(separate_components.outputs[3], reroute_014.inputs[0])
	    #separate_components.Volume -> reroute_015.Input
	    duplicate_hair_curves_002.links.new(separate_components.outputs[4], reroute_015.inputs[0])
	    #reroute_012.Output -> reroute_016.Input
	    duplicate_hair_curves_002.links.new(reroute_012.outputs[0], reroute_016.inputs[0])
	    #reroute_014.Output -> reroute_017.Input
	    duplicate_hair_curves_002.links.new(reroute_014.outputs[0], reroute_017.inputs[0])
	    #reroute_013.Output -> reroute_018.Input
	    duplicate_hair_curves_002.links.new(reroute_013.outputs[0], reroute_018.inputs[0])
	    #reroute_015.Output -> reroute_019.Input
	    duplicate_hair_curves_002.links.new(reroute_015.outputs[0], reroute_019.inputs[0])
	    #switch_001.Output -> reroute_020.Input
	    duplicate_hair_curves_002.links.new(switch_001.outputs[0], reroute_020.inputs[0])
	    #group_input.Geometry -> separate_components.Geometry
	    duplicate_hair_curves_002.links.new(group_input.outputs[0], separate_components.inputs[0])
	    #separate_components.Curve -> capture_attribute_001.Geometry
	    duplicate_hair_curves_002.links.new(separate_components.outputs[1], capture_attribute_001.inputs[0])
	    #reroute_004.Output -> group_output_3.Guide Index
	    duplicate_hair_curves_002.links.new(reroute_004.outputs[0], group_output_3.inputs[1])
	    #reroute_002.Output -> join_geometry.Geometry
	    duplicate_hair_curves_002.links.new(reroute_002.outputs[0], join_geometry.inputs[0])
	    #reroute_019.Output -> join_geometry_001.Geometry
	    duplicate_hair_curves_002.links.new(reroute_019.outputs[0], join_geometry_001.inputs[0])
	    #reroute_020.Output -> join_geometry_001.Geometry
	    duplicate_hair_curves_002.links.new(reroute_020.outputs[0], join_geometry_001.inputs[0])
	    #reroute_017.Output -> join_geometry_001.Geometry
	    duplicate_hair_curves_002.links.new(reroute_017.outputs[0], join_geometry_001.inputs[0])
	    #reroute_016.Output -> join_geometry_001.Geometry
	    duplicate_hair_curves_002.links.new(reroute_016.outputs[0], join_geometry_001.inputs[0])
	    return duplicate_hair_curves_002
	
	duplicate_hair_curves_002 = duplicate_hair_curves_002_node_group()
	
	#initialize curve_segment_003 node group
	def curve_segment_003_node_group():
	    curve_segment_003 = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Curve Segment.003")
	
	    curve_segment_003.color_tag = 'NONE'
	    curve_segment_003.description = "Reads information each point's previous curve segment"
	    curve_segment_003.default_group_node_width = 140
	    
	
	
	    #curve_segment_003 interface
	    #Socket Segment Length
	    segment_length_socket = curve_segment_003.interface.new_socket(name = "Segment Length", in_out='OUTPUT', socket_type = 'NodeSocketFloat')
	    segment_length_socket.default_value = 0.0
	    segment_length_socket.min_value = -3.4028234663852886e+38
	    segment_length_socket.max_value = 3.4028234663852886e+38
	    segment_length_socket.subtype = 'NONE'
	    segment_length_socket.attribute_domain = 'POINT'
	    segment_length_socket.description = "Distance to previous point on curve"
	
	    #Socket Segment Direction
	    segment_direction_socket = curve_segment_003.interface.new_socket(name = "Segment Direction", in_out='OUTPUT', socket_type = 'NodeSocketVector')
	    segment_direction_socket.default_value = (0.0, 0.0, 0.0)
	    segment_direction_socket.min_value = -3.4028234663852886e+38
	    segment_direction_socket.max_value = 3.4028234663852886e+38
	    segment_direction_socket.subtype = 'NONE'
	    segment_direction_socket.attribute_domain = 'POINT'
	    segment_direction_socket.description = "Direction from previous neighboring point on segment"
	
	    #Socket Neighbor Index
	    neighbor_index_socket = curve_segment_003.interface.new_socket(name = "Neighbor Index", in_out='OUTPUT', socket_type = 'NodeSocketInt')
	    neighbor_index_socket.default_value = 0
	    neighbor_index_socket.min_value = -2147483648
	    neighbor_index_socket.max_value = 2147483647
	    neighbor_index_socket.subtype = 'NONE'
	    neighbor_index_socket.attribute_domain = 'POINT'
	    neighbor_index_socket.description = "Index of previous neighboring point on segment"
	
	
	    #initialize curve_segment_003 nodes
	    #node Vector Math.009
	    vector_math_009_1 = curve_segment_003.nodes.new("ShaderNodeVectorMath")
	    vector_math_009_1.name = "Vector Math.009"
	    vector_math_009_1.operation = 'NORMALIZE'
	
	    #node Reroute.015
	    reroute_015_1 = curve_segment_003.nodes.new("NodeReroute")
	    reroute_015_1.name = "Reroute.015"
	    reroute_015_1.socket_idname = "NodeSocketVector"
	    #node Reroute.017
	    reroute_017_1 = curve_segment_003.nodes.new("NodeReroute")
	    reroute_017_1.name = "Reroute.017"
	    reroute_017_1.socket_idname = "NodeSocketVector"
	    #node Field at Index.001
	    field_at_index_001 = curve_segment_003.nodes.new("GeometryNodeFieldAtIndex")
	    field_at_index_001.name = "Field at Index.001"
	    field_at_index_001.data_type = 'FLOAT_VECTOR'
	    field_at_index_001.domain = 'POINT'
	
	    #node Vector Math.008
	    vector_math_008_1 = curve_segment_003.nodes.new("ShaderNodeVectorMath")
	    vector_math_008_1.name = "Vector Math.008"
	    vector_math_008_1.operation = 'SUBTRACT'
	
	    #node Reroute.018
	    reroute_018_1 = curve_segment_003.nodes.new("NodeReroute")
	    reroute_018_1.name = "Reroute.018"
	    reroute_018_1.socket_idname = "NodeSocketInt"
	    #node Interpolate Domain.002
	    interpolate_domain_002_2 = curve_segment_003.nodes.new("GeometryNodeFieldOnDomain")
	    interpolate_domain_002_2.name = "Interpolate Domain.002"
	    interpolate_domain_002_2.data_type = 'FLOAT_VECTOR'
	    interpolate_domain_002_2.domain = 'POINT'
	
	    #node Group Output
	    group_output_4 = curve_segment_003.nodes.new("NodeGroupOutput")
	    group_output_4.name = "Group Output"
	    group_output_4.is_active_output = True
	
	    #node Vector Math.007
	    vector_math_007_1 = curve_segment_003.nodes.new("ShaderNodeVectorMath")
	    vector_math_007_1.name = "Vector Math.007"
	    vector_math_007_1.operation = 'LENGTH'
	
	    #node Interpolate Domain.003
	    interpolate_domain_003 = curve_segment_003.nodes.new("GeometryNodeFieldOnDomain")
	    interpolate_domain_003.name = "Interpolate Domain.003"
	    interpolate_domain_003.data_type = 'INT'
	    interpolate_domain_003.domain = 'POINT'
	
	    #node Reroute
	    reroute_1 = curve_segment_003.nodes.new("NodeReroute")
	    reroute_1.name = "Reroute"
	    reroute_1.socket_idname = "NodeSocketBool"
	    #node Switch.004
	    switch_004 = curve_segment_003.nodes.new("GeometryNodeSwitch")
	    switch_004.name = "Switch.004"
	    switch_004.hide = True
	    switch_004.input_type = 'VECTOR'
	    #False
	    switch_004.inputs[1].default_value = (0.0, 0.0, 0.0)
	
	    #node Switch.003
	    switch_003 = curve_segment_003.nodes.new("GeometryNodeSwitch")
	    switch_003.name = "Switch.003"
	    switch_003.hide = True
	    switch_003.input_type = 'FLOAT'
	    #False
	    switch_003.inputs[1].default_value = 0.0
	
	    #node Boolean
	    boolean = curve_segment_003.nodes.new("FunctionNodeInputBool")
	    boolean.name = "Boolean"
	    boolean.boolean = True
	
	    #node Interpolate Domain
	    interpolate_domain_2 = curve_segment_003.nodes.new("GeometryNodeFieldOnDomain")
	    interpolate_domain_2.name = "Interpolate Domain"
	    interpolate_domain_2.data_type = 'BOOLEAN'
	    interpolate_domain_2.domain = 'CURVE'
	
	    #node Switch.005
	    switch_005 = curve_segment_003.nodes.new("GeometryNodeSwitch")
	    switch_005.name = "Switch.005"
	    switch_005.hide = True
	    switch_005.input_type = 'INT'
	    #False
	    switch_005.inputs[1].default_value = 0
	
	    #node Index.002
	    index_002 = curve_segment_003.nodes.new("GeometryNodeInputIndex")
	    index_002.name = "Index.002"
	
	    #node Switch.001
	    switch_001_1 = curve_segment_003.nodes.new("GeometryNodeSwitch")
	    switch_001_1.name = "Switch.001"
	    switch_001_1.input_type = 'INT'
	
	    #node Offset Point in Curve
	    offset_point_in_curve = curve_segment_003.nodes.new("GeometryNodeOffsetPointInCurve")
	    offset_point_in_curve.name = "Offset Point in Curve"
	    #Point Index
	    offset_point_in_curve.inputs[0].default_value = 0
	    #Offset
	    offset_point_in_curve.inputs[1].default_value = -1
	
	    #node Position.002
	    position_002_2 = curve_segment_003.nodes.new("GeometryNodeInputPosition")
	    position_002_2.name = "Position.002"
	
	
	
	
	
	    #Set locations
	    vector_math_009_1.location = (-389.8524169921875, 30.443286895751953)
	    reroute_015_1.location = (-456.8948974609375, 4.604297637939453)
	    reroute_017_1.location = (-1012.7362060546875, -9.742748260498047)
	    field_at_index_001.location = (-992.6431884765625, 70.62931823730469)
	    vector_math_008_1.location = (-811.805908203125, 70.62931823730469)
	    reroute_018_1.location = (-1032.8292236328125, 110.81541442871094)
	    interpolate_domain_002_2.location = (-630.9686279296875, 70.62931823730469)
	    group_output_4.location = (75.0, 50.0)
	    vector_math_007_1.location = (-389.8524169921875, 151.00144958496094)
	    interpolate_domain_003.location = (-390.85833740234375, -97.25408935546875)
	    reroute_1.location = (-342.979248046875, 193.345458984375)
	    switch_004.location = (-178.8756103515625, 10.35025405883789)
	    switch_003.location = (-178.8756103515625, 90.72234344482422)
	    boolean.location = (-781.6663208007812, 291.652587890625)
	    interpolate_domain_2.location = (-600.8291015625, 311.74560546875)
	    switch_005.location = (-178.8756103515625, -70.0218505859375)
	    index_002.location = (-1404.550048828125, 211.28048706054688)
	    switch_001_1.location = (-1223.712890625, 231.37350463867188)
	    offset_point_in_curve.location = (-1404.550048828125, 151.0014190673828)
	    position_002_2.location = (-1223.712890625, 30.44327163696289)
	
	    #Set dimensions
	    vector_math_009_1.width, vector_math_009_1.height = 140.0, 100.0
	    reroute_015_1.width, reroute_015_1.height = 100.0, 100.0
	    reroute_017_1.width, reroute_017_1.height = 100.0, 100.0
	    field_at_index_001.width, field_at_index_001.height = 140.0, 100.0
	    vector_math_008_1.width, vector_math_008_1.height = 140.0, 100.0
	    reroute_018_1.width, reroute_018_1.height = 100.0, 100.0
	    interpolate_domain_002_2.width, interpolate_domain_002_2.height = 140.0, 100.0
	    group_output_4.width, group_output_4.height = 140.0, 100.0
	    vector_math_007_1.width, vector_math_007_1.height = 140.0, 100.0
	    interpolate_domain_003.width, interpolate_domain_003.height = 140.0, 100.0
	    reroute_1.width, reroute_1.height = 100.0, 100.0
	    switch_004.width, switch_004.height = 140.0, 100.0
	    switch_003.width, switch_003.height = 140.0, 100.0
	    boolean.width, boolean.height = 140.0, 100.0
	    interpolate_domain_2.width, interpolate_domain_2.height = 140.0, 100.0
	    switch_005.width, switch_005.height = 140.0, 100.0
	    index_002.width, index_002.height = 140.0, 100.0
	    switch_001_1.width, switch_001_1.height = 140.0, 100.0
	    offset_point_in_curve.width, offset_point_in_curve.height = 140.0, 100.0
	    position_002_2.width, position_002_2.height = 140.0, 100.0
	
	    #initialize curve_segment_003 links
	    #reroute_015_1.Output -> vector_math_007_1.Vector
	    curve_segment_003.links.new(reroute_015_1.outputs[0], vector_math_007_1.inputs[0])
	    #reroute_018_1.Output -> field_at_index_001.Index
	    curve_segment_003.links.new(reroute_018_1.outputs[0], field_at_index_001.inputs[0])
	    #vector_math_008_1.Vector -> interpolate_domain_002_2.Value
	    curve_segment_003.links.new(vector_math_008_1.outputs[0], interpolate_domain_002_2.inputs[0])
	    #reroute_017_1.Output -> vector_math_008_1.Vector
	    curve_segment_003.links.new(reroute_017_1.outputs[0], vector_math_008_1.inputs[0])
	    #reroute_015_1.Output -> vector_math_009_1.Vector
	    curve_segment_003.links.new(reroute_015_1.outputs[0], vector_math_009_1.inputs[0])
	    #reroute_017_1.Output -> field_at_index_001.Value
	    curve_segment_003.links.new(reroute_017_1.outputs[0], field_at_index_001.inputs[1])
	    #field_at_index_001.Value -> vector_math_008_1.Vector
	    curve_segment_003.links.new(field_at_index_001.outputs[0], vector_math_008_1.inputs[1])
	    #position_002_2.Position -> reroute_017_1.Input
	    curve_segment_003.links.new(position_002_2.outputs[0], reroute_017_1.inputs[0])
	    #interpolate_domain_002_2.Value -> reroute_015_1.Input
	    curve_segment_003.links.new(interpolate_domain_002_2.outputs[0], reroute_015_1.inputs[0])
	    #switch_004.Output -> group_output_4.Segment Direction
	    curve_segment_003.links.new(switch_004.outputs[0], group_output_4.inputs[1])
	    #switch_005.Output -> group_output_4.Neighbor Index
	    curve_segment_003.links.new(switch_005.outputs[0], group_output_4.inputs[2])
	    #boolean.Boolean -> interpolate_domain_2.Value
	    curve_segment_003.links.new(boolean.outputs[0], interpolate_domain_2.inputs[0])
	    #reroute_018_1.Output -> interpolate_domain_003.Value
	    curve_segment_003.links.new(reroute_018_1.outputs[0], interpolate_domain_003.inputs[0])
	    #vector_math_007_1.Value -> switch_003.True
	    curve_segment_003.links.new(vector_math_007_1.outputs[1], switch_003.inputs[2])
	    #reroute_1.Output -> switch_003.Switch
	    curve_segment_003.links.new(reroute_1.outputs[0], switch_003.inputs[0])
	    #switch_003.Output -> group_output_4.Segment Length
	    curve_segment_003.links.new(switch_003.outputs[0], group_output_4.inputs[0])
	    #vector_math_009_1.Vector -> switch_004.True
	    curve_segment_003.links.new(vector_math_009_1.outputs[0], switch_004.inputs[2])
	    #interpolate_domain_2.Value -> reroute_1.Input
	    curve_segment_003.links.new(interpolate_domain_2.outputs[0], reroute_1.inputs[0])
	    #reroute_1.Output -> switch_004.Switch
	    curve_segment_003.links.new(reroute_1.outputs[0], switch_004.inputs[0])
	    #interpolate_domain_003.Value -> switch_005.True
	    curve_segment_003.links.new(interpolate_domain_003.outputs[0], switch_005.inputs[2])
	    #reroute_1.Output -> switch_005.Switch
	    curve_segment_003.links.new(reroute_1.outputs[0], switch_005.inputs[0])
	    #offset_point_in_curve.Is Valid Offset -> switch_001_1.Switch
	    curve_segment_003.links.new(offset_point_in_curve.outputs[0], switch_001_1.inputs[0])
	    #offset_point_in_curve.Point Index -> switch_001_1.True
	    curve_segment_003.links.new(offset_point_in_curve.outputs[1], switch_001_1.inputs[2])
	    #index_002.Index -> switch_001_1.False
	    curve_segment_003.links.new(index_002.outputs[0], switch_001_1.inputs[1])
	    #switch_001_1.Output -> reroute_018_1.Input
	    curve_segment_003.links.new(switch_001_1.outputs[0], reroute_018_1.inputs[0])
	    return curve_segment_003
	
	curve_segment_003 = curve_segment_003_node_group()
	
	#initialize restore_curve_segment_length_003 node group
	def restore_curve_segment_length_003_node_group():
	    restore_curve_segment_length_003 = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Restore Curve Segment Length.003")
	
	    restore_curve_segment_length_003.color_tag = 'NONE'
	    restore_curve_segment_length_003.description = "Restores the length of each curve segment using a previous state after deformation"
	    restore_curve_segment_length_003.default_group_node_width = 140
	    
	
	    restore_curve_segment_length_003.is_modifier = True
	
	    #restore_curve_segment_length_003 interface
	    #Socket Curves
	    curves_socket = restore_curve_segment_length_003.interface.new_socket(name = "Curves", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    curves_socket.attribute_domain = 'POINT'
	
	    #Socket Curves
	    curves_socket_1 = restore_curve_segment_length_003.interface.new_socket(name = "Curves", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    curves_socket_1.attribute_domain = 'POINT'
	
	    #Socket Selection
	    selection_socket = restore_curve_segment_length_003.interface.new_socket(name = "Selection", in_out='INPUT', socket_type = 'NodeSocketBool')
	    selection_socket.default_value = True
	    selection_socket.attribute_domain = 'POINT'
	    selection_socket.hide_value = True
	    selection_socket.description = "Only affect selected elements"
	
	    #Socket Factor
	    factor_socket = restore_curve_segment_length_003.interface.new_socket(name = "Factor", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    factor_socket.default_value = 1.0
	    factor_socket.min_value = 0.0
	    factor_socket.max_value = 1.0
	    factor_socket.subtype = 'FACTOR'
	    factor_socket.attribute_domain = 'POINT'
	    factor_socket.description = "Factor to blend overall effect"
	
	    #Socket Reference Position
	    reference_position_socket = restore_curve_segment_length_003.interface.new_socket(name = "Reference Position", in_out='INPUT', socket_type = 'NodeSocketVector')
	    reference_position_socket.default_value = (8.146539688110352, 4.969870090484619, 9.874540328979492)
	    reference_position_socket.min_value = -3.4028234663852886e+38
	    reference_position_socket.max_value = 3.4028234663852886e+38
	    reference_position_socket.subtype = 'NONE'
	    reference_position_socket.default_attribute_name = "rest_position"
	    reference_position_socket.attribute_domain = 'POINT'
	    reference_position_socket.hide_value = True
	    reference_position_socket.description = "Reference position before deformation"
	
	    #Socket Pin at Parameter
	    pin_at_parameter_socket = restore_curve_segment_length_003.interface.new_socket(name = "Pin at Parameter", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    pin_at_parameter_socket.default_value = 0.0
	    pin_at_parameter_socket.min_value = 0.0
	    pin_at_parameter_socket.max_value = 1.0
	    pin_at_parameter_socket.subtype = 'FACTOR'
	    pin_at_parameter_socket.attribute_domain = 'POINT'
	    pin_at_parameter_socket.description = "Pin each curve at a certain point for the operation"
	
	
	    #initialize restore_curve_segment_length_003 nodes
	    #node Frame.001
	    frame_001_1 = restore_curve_segment_length_003.nodes.new("NodeFrame")
	    frame_001_1.label = "Pin at Parameter"
	    frame_001_1.name = "Frame.001"
	    frame_001_1.label_size = 20
	    frame_001_1.shrink = True
	
	    #node Frame
	    frame_2 = restore_curve_segment_length_003.nodes.new("NodeFrame")
	    frame_2.label = "Restore Segment Lengths"
	    frame_2.name = "Frame"
	    frame_2.label_size = 20
	    frame_2.shrink = True
	
	    #node Frame.002
	    frame_002_1 = restore_curve_segment_length_003.nodes.new("NodeFrame")
	    frame_002_1.label = "Default Fallback"
	    frame_002_1.name = "Frame.002"
	    frame_002_1.label_size = 20
	    frame_002_1.shrink = True
	
	    #node Reroute.009
	    reroute_009 = restore_curve_segment_length_003.nodes.new("NodeReroute")
	    reroute_009.name = "Reroute.009"
	    reroute_009.socket_idname = "NodeSocketVector"
	    #node Group Input.006
	    group_input_006_1 = restore_curve_segment_length_003.nodes.new("NodeGroupInput")
	    group_input_006_1.name = "Group Input.006"
	    group_input_006_1.outputs[0].hide = True
	    group_input_006_1.outputs[1].hide = True
	    group_input_006_1.outputs[2].hide = True
	    group_input_006_1.outputs[3].hide = True
	    group_input_006_1.outputs[5].hide = True
	
	    #node Reroute.013
	    reroute_013_1 = restore_curve_segment_length_003.nodes.new("NodeReroute")
	    reroute_013_1.name = "Reroute.013"
	    reroute_013_1.socket_idname = "NodeSocketGeometry"
	    #node Index
	    index_1 = restore_curve_segment_length_003.nodes.new("GeometryNodeInputIndex")
	    index_1.name = "Index"
	
	    #node Sample Curve.001
	    sample_curve_001 = restore_curve_segment_length_003.nodes.new("GeometryNodeSampleCurve")
	    sample_curve_001.name = "Sample Curve.001"
	    sample_curve_001.data_type = 'FLOAT_VECTOR'
	    sample_curve_001.mode = 'FACTOR'
	    sample_curve_001.use_all_curves = False
	
	    #node Group Input.003
	    group_input_003_1 = restore_curve_segment_length_003.nodes.new("NodeGroupInput")
	    group_input_003_1.name = "Group Input.003"
	    group_input_003_1.outputs[0].hide = True
	    group_input_003_1.outputs[1].hide = True
	    group_input_003_1.outputs[2].hide = True
	    group_input_003_1.outputs[3].hide = True
	    group_input_003_1.outputs[5].hide = True
	
	    #node Vector Math.006
	    vector_math_006_1 = restore_curve_segment_length_003.nodes.new("ShaderNodeVectorMath")
	    vector_math_006_1.name = "Vector Math.006"
	    vector_math_006_1.hide = True
	    vector_math_006_1.operation = 'SUBTRACT'
	
	    #node Interpolate Domain
	    interpolate_domain_3 = restore_curve_segment_length_003.nodes.new("GeometryNodeFieldOnDomain")
	    interpolate_domain_3.name = "Interpolate Domain"
	    interpolate_domain_3.hide = True
	    interpolate_domain_3.data_type = 'FLOAT_VECTOR'
	    interpolate_domain_3.domain = 'CURVE'
	
	    #node Group Input.005
	    group_input_005_1 = restore_curve_segment_length_003.nodes.new("NodeGroupInput")
	    group_input_005_1.name = "Group Input.005"
	    group_input_005_1.outputs[0].hide = True
	    group_input_005_1.outputs[2].hide = True
	    group_input_005_1.outputs[3].hide = True
	    group_input_005_1.outputs[4].hide = True
	    group_input_005_1.outputs[5].hide = True
	
	    #node Boolean Math.002
	    boolean_math_002 = restore_curve_segment_length_003.nodes.new("FunctionNodeBooleanMath")
	    boolean_math_002.name = "Boolean Math.002"
	    boolean_math_002.hide = True
	    boolean_math_002.operation = 'AND'
	
	    #node Field at Index.002
	    field_at_index_002 = restore_curve_segment_length_003.nodes.new("GeometryNodeFieldAtIndex")
	    field_at_index_002.name = "Field at Index.002"
	    field_at_index_002.data_type = 'FLOAT_VECTOR'
	    field_at_index_002.domain = 'POINT'
	
	    #node Vector Math.004
	    vector_math_004_1 = restore_curve_segment_length_003.nodes.new("ShaderNodeVectorMath")
	    vector_math_004_1.name = "Vector Math.004"
	    vector_math_004_1.operation = 'DISTANCE'
	
	    #node Accumulate Field
	    accumulate_field = restore_curve_segment_length_003.nodes.new("GeometryNodeAccumulateField")
	    accumulate_field.name = "Accumulate Field"
	    accumulate_field.data_type = 'FLOAT_VECTOR'
	    accumulate_field.domain = 'POINT'
	    accumulate_field.outputs[1].hide = True
	    accumulate_field.outputs[2].hide = True
	
	    #node Curve of Point
	    curve_of_point = restore_curve_segment_length_003.nodes.new("GeometryNodeCurveOfPoint")
	    curve_of_point.name = "Curve of Point"
	    curve_of_point.inputs[0].hide = True
	    curve_of_point.outputs[1].hide = True
	    #Point Index
	    curve_of_point.inputs[0].default_value = 0
	
	    #node Vector Math
	    vector_math_2 = restore_curve_segment_length_003.nodes.new("ShaderNodeVectorMath")
	    vector_math_2.name = "Vector Math"
	    vector_math_2.operation = 'SCALE'
	
	    #node Index.001
	    index_001_1 = restore_curve_segment_length_003.nodes.new("GeometryNodeInputIndex")
	    index_001_1.name = "Index.001"
	
	    #node Curve of Point.001
	    curve_of_point_001 = restore_curve_segment_length_003.nodes.new("GeometryNodeCurveOfPoint")
	    curve_of_point_001.name = "Curve of Point.001"
	    curve_of_point_001.inputs[0].hide = True
	    curve_of_point_001.outputs[0].hide = True
	    #Point Index
	    curve_of_point_001.inputs[0].default_value = 0
	
	    #node Switch
	    switch_1 = restore_curve_segment_length_003.nodes.new("GeometryNodeSwitch")
	    switch_1.name = "Switch"
	    switch_1.input_type = 'INT'
	
	    #node Math
	    math_1 = restore_curve_segment_length_003.nodes.new("ShaderNodeMath")
	    math_1.name = "Math"
	    math_1.hide = True
	    math_1.operation = 'SUBTRACT'
	    math_1.use_clamp = False
	    #Value_001
	    math_1.inputs[1].default_value = 1.0
	
	    #node Compare
	    compare = restore_curve_segment_length_003.nodes.new("FunctionNodeCompare")
	    compare.name = "Compare"
	    compare.hide = True
	    compare.data_type = 'INT'
	    compare.mode = 'ELEMENT'
	    compare.operation = 'EQUAL'
	    #B_INT
	    compare.inputs[3].default_value = 0
	
	    #node Reroute.001
	    reroute_001_1 = restore_curve_segment_length_003.nodes.new("NodeReroute")
	    reroute_001_1.name = "Reroute.001"
	    reroute_001_1.socket_idname = "NodeSocketVector"
	    #node Set Position.001
	    set_position_001_1 = restore_curve_segment_length_003.nodes.new("GeometryNodeSetPosition")
	    set_position_001_1.name = "Set Position.001"
	
	    #node Boolean Math
	    boolean_math = restore_curve_segment_length_003.nodes.new("FunctionNodeBooleanMath")
	    boolean_math.name = "Boolean Math"
	    boolean_math.operation = 'AND'
	
	    #node Compare.002
	    compare_002 = restore_curve_segment_length_003.nodes.new("FunctionNodeCompare")
	    compare_002.name = "Compare.002"
	    compare_002.data_type = 'FLOAT'
	    compare_002.mode = 'ELEMENT'
	    compare_002.operation = 'GREATER_THAN'
	    #B
	    compare_002.inputs[1].default_value = 0.0
	
	    #node Group Input.002
	    group_input_002_1 = restore_curve_segment_length_003.nodes.new("NodeGroupInput")
	    group_input_002_1.name = "Group Input.002"
	    group_input_002_1.outputs[0].hide = True
	    group_input_002_1.outputs[3].hide = True
	    group_input_002_1.outputs[4].hide = True
	    group_input_002_1.outputs[5].hide = True
	
	    #node Reroute.016
	    reroute_016_1 = restore_curve_segment_length_003.nodes.new("NodeReroute")
	    reroute_016_1.name = "Reroute.016"
	    reroute_016_1.socket_idname = "NodeSocketBool"
	    #node Reroute.014
	    reroute_014_1 = restore_curve_segment_length_003.nodes.new("NodeReroute")
	    reroute_014_1.name = "Reroute.014"
	    reroute_014_1.socket_idname = "NodeSocketGeometry"
	    #node Switch.001
	    switch_001_2 = restore_curve_segment_length_003.nodes.new("GeometryNodeSwitch")
	    switch_001_2.name = "Switch.001"
	    switch_001_2.input_type = 'GEOMETRY'
	
	    #node Group Output
	    group_output_5 = restore_curve_segment_length_003.nodes.new("NodeGroupOutput")
	    group_output_5.name = "Group Output"
	    group_output_5.is_active_output = True
	
	    #node Attribute Statistic
	    attribute_statistic = restore_curve_segment_length_003.nodes.new("GeometryNodeAttributeStatistic")
	    attribute_statistic.name = "Attribute Statistic"
	    attribute_statistic.hide = True
	    attribute_statistic.data_type = 'FLOAT'
	    attribute_statistic.domain = 'CURVE'
	    attribute_statistic.inputs[1].hide = True
	    attribute_statistic.outputs[0].hide = True
	    attribute_statistic.outputs[1].hide = True
	    attribute_statistic.outputs[2].hide = True
	    attribute_statistic.outputs[3].hide = True
	    attribute_statistic.outputs[5].hide = True
	    attribute_statistic.outputs[6].hide = True
	    attribute_statistic.outputs[7].hide = True
	    #Selection
	    attribute_statistic.inputs[1].default_value = True
	
	    #node Group
	    group_2 = restore_curve_segment_length_003.nodes.new("GeometryNodeGroup")
	    group_2.name = "Group"
	    group_2.node_tree = curve_root_006
	    group_2.outputs[0].hide = True
	    group_2.outputs[2].hide = True
	    group_2.outputs[3].hide = True
	
	    #node Reroute.007
	    reroute_007 = restore_curve_segment_length_003.nodes.new("NodeReroute")
	    reroute_007.name = "Reroute.007"
	    reroute_007.socket_idname = "NodeSocketVector"
	    #node Reroute.004
	    reroute_004_1 = restore_curve_segment_length_003.nodes.new("NodeReroute")
	    reroute_004_1.name = "Reroute.004"
	    reroute_004_1.socket_idname = "NodeSocketGeometry"
	    #node Position.001
	    position_001 = restore_curve_segment_length_003.nodes.new("GeometryNodeInputPosition")
	    position_001.name = "Position.001"
	
	    #node Named Attribute
	    named_attribute_1 = restore_curve_segment_length_003.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute_1.name = "Named Attribute"
	    named_attribute_1.data_type = 'FLOAT_VECTOR'
	    #Name
	    named_attribute_1.inputs[0].default_value = "rest_position"
	
	    #node Switch.003
	    switch_003_1 = restore_curve_segment_length_003.nodes.new("GeometryNodeSwitch")
	    switch_003_1.name = "Switch.003"
	    switch_003_1.input_type = 'VECTOR'
	
	    #node Reroute.006
	    reroute_006 = restore_curve_segment_length_003.nodes.new("NodeReroute")
	    reroute_006.name = "Reroute.006"
	    reroute_006.socket_idname = "NodeSocketVector"
	    #node Switch.002
	    switch_002 = restore_curve_segment_length_003.nodes.new("GeometryNodeSwitch")
	    switch_002.name = "Switch.002"
	    switch_002.input_type = 'VECTOR'
	
	    #node Compare.004
	    compare_004 = restore_curve_segment_length_003.nodes.new("FunctionNodeCompare")
	    compare_004.name = "Compare.004"
	    compare_004.data_type = 'VECTOR'
	    compare_004.mode = 'ELEMENT'
	    compare_004.operation = 'EQUAL'
	    #B_VEC3
	    compare_004.inputs[5].default_value = (8.146539688110352, 4.969870090484619, 9.874540328979492)
	    #Epsilon
	    compare_004.inputs[12].default_value = 0.0
	
	    #node Group Input
	    group_input_1 = restore_curve_segment_length_003.nodes.new("NodeGroupInput")
	    group_input_1.name = "Group Input"
	    group_input_1.outputs[1].hide = True
	    group_input_1.outputs[2].hide = True
	    group_input_1.outputs[4].hide = True
	    group_input_1.outputs[5].hide = True
	
	    #node Reroute.011
	    reroute_011 = restore_curve_segment_length_003.nodes.new("NodeReroute")
	    reroute_011.name = "Reroute.011"
	    reroute_011.socket_idname = "NodeSocketGeometry"
	    #node Reroute.005
	    reroute_005 = restore_curve_segment_length_003.nodes.new("NodeReroute")
	    reroute_005.name = "Reroute.005"
	    reroute_005.socket_idname = "NodeSocketGeometry"
	    #node Reroute.008
	    reroute_008 = restore_curve_segment_length_003.nodes.new("NodeReroute")
	    reroute_008.name = "Reroute.008"
	    reroute_008.socket_idname = "NodeSocketVector"
	    #node Set Position.002
	    set_position_002 = restore_curve_segment_length_003.nodes.new("GeometryNodeSetPosition")
	    set_position_002.name = "Set Position.002"
	    set_position_002.inputs[2].hide = True
	    #Position
	    set_position_002.inputs[2].default_value = (0.0, 0.0, 0.0)
	
	    #node Reroute.012
	    reroute_012_1 = restore_curve_segment_length_003.nodes.new("NodeReroute")
	    reroute_012_1.name = "Reroute.012"
	    reroute_012_1.socket_idname = "NodeSocketGeometry"
	    #node Group Input.001
	    group_input_001_1 = restore_curve_segment_length_003.nodes.new("NodeGroupInput")
	    group_input_001_1.name = "Group Input.001"
	    group_input_001_1.outputs[0].hide = True
	    group_input_001_1.outputs[1].hide = True
	    group_input_001_1.outputs[3].hide = True
	    group_input_001_1.outputs[4].hide = True
	    group_input_001_1.outputs[5].hide = True
	
	    #node Mix
	    mix = restore_curve_segment_length_003.nodes.new("ShaderNodeMix")
	    mix.name = "Mix"
	    mix.blend_type = 'MIX'
	    mix.clamp_factor = True
	    mix.clamp_result = False
	    mix.data_type = 'FLOAT'
	    mix.factor_mode = 'UNIFORM'
	
	    #node Group.001
	    group_001_2 = restore_curve_segment_length_003.nodes.new("GeometryNodeGroup")
	    group_001_2.name = "Group.001"
	    group_001_2.node_tree = curve_segment_003
	    group_001_2.outputs[2].hide = True
	
	    #node Compare.003
	    compare_003 = restore_curve_segment_length_003.nodes.new("FunctionNodeCompare")
	    compare_003.name = "Compare.003"
	    compare_003.hide = True
	    compare_003.data_type = 'FLOAT'
	    compare_003.mode = 'ELEMENT'
	    compare_003.operation = 'NOT_EQUAL'
	    #B
	    compare_003.inputs[1].default_value = 0.0
	    #Epsilon
	    compare_003.inputs[12].default_value = 0.0
	
	    #node Compare.005
	    compare_005 = restore_curve_segment_length_003.nodes.new("FunctionNodeCompare")
	    compare_005.name = "Compare.005"
	    compare_005.hide = True
	    compare_005.data_type = 'FLOAT'
	    compare_005.mode = 'ELEMENT'
	    compare_005.operation = 'GREATER_THAN'
	    #B
	    compare_005.inputs[1].default_value = 0.0
	
	
	
	
	    #Set parents
	    group_input_006_1.parent = frame_001_1
	    reroute_013_1.parent = frame_001_1
	    index_1.parent = frame_001_1
	    sample_curve_001.parent = frame_001_1
	    group_input_003_1.parent = frame_001_1
	    vector_math_006_1.parent = frame_001_1
	    interpolate_domain_3.parent = frame_001_1
	    group_input_005_1.parent = frame_001_1
	    boolean_math_002.parent = frame_001_1
	    field_at_index_002.parent = frame_2
	    vector_math_004_1.parent = frame_2
	    accumulate_field.parent = frame_2
	    curve_of_point.parent = frame_2
	    vector_math_2.parent = frame_2
	    index_001_1.parent = frame_2
	    curve_of_point_001.parent = frame_2
	    switch_1.parent = frame_2
	    math_1.parent = frame_2
	    compare.parent = frame_2
	    reroute_001_1.parent = frame_2
	    set_position_001_1.parent = frame_2
	    boolean_math.parent = frame_2
	    compare_002.parent = frame_2
	    group_input_002_1.parent = frame_2
	    reroute_016_1.parent = frame_001_1
	    reroute_014_1.parent = frame_001_1
	    switch_001_2.parent = frame_001_1
	    attribute_statistic.parent = frame_001_1
	    group_2.parent = frame_2
	    reroute_004_1.parent = frame_2
	    position_001.parent = frame_002_1
	    named_attribute_1.parent = frame_002_1
	    switch_003_1.parent = frame_002_1
	    reroute_006.parent = frame_002_1
	    switch_002.parent = frame_002_1
	    compare_004.parent = frame_002_1
	    reroute_005.parent = frame_2
	    set_position_002.parent = frame_001_1
	    reroute_012_1.parent = frame_001_1
	    group_input_001_1.parent = frame_2
	    mix.parent = frame_2
	    group_001_2.parent = frame_2
	    compare_003.parent = frame_001_1
	    compare_005.parent = frame_001_1
	
	    #Set locations
	    frame_001_1.location = (-1289.139892578125, 110.0)
	    frame_2.location = (-3491.0, 57.813934326171875)
	    frame_002_1.location = (-4467.1865234375, -101.0)
	    reroute_009.location = (-1431.9771728515625, -673.348876953125)
	    group_input_006_1.location = (218.837158203125, -140.37210083007812)
	    reroute_013_1.location = (178.651123046875, -120.2790756225586)
	    index_1.location = (38.0, -481.9534912109375)
	    sample_curve_001.location = (218.837158203125, -220.7441864013672)
	    group_input_003_1.location = (38.0, -421.6744384765625)
	    vector_math_006_1.location = (399.6744384765625, -260.93023681640625)
	    interpolate_domain_3.location = (580.5116577148438, -260.93023681640625)
	    group_input_005_1.location = (399.6744384765625, -180.5581512451172)
	    boolean_math_002.location = (580.5116577148438, -180.5581512451172)
	    field_at_index_002.location = (652.51123046875, -248.93023681640625)
	    vector_math_004_1.location = (833.348388671875, -228.83721923828125)
	    accumulate_field.location = (1556.697265625, -409.6744384765625)
	    curve_of_point.location = (1355.76708984375, -550.3255615234375)
	    vector_math_2.location = (1355.76708984375, -389.5813903808594)
	    index_001_1.location = (29.62744140625, -469.9534912109375)
	    curve_of_point_001.location = (29.62744140625, -389.5813903808594)
	    switch_1.location = (411.39501953125, -369.4883728027344)
	    math_1.location = (210.46484375, -469.9534912109375)
	    compare.location = (210.46484375, -429.7674560546875)
	    reroute_001_1.location = (612.3251953125, -309.20928955078125)
	    set_position_001_1.location = (1797.8135986328125, -148.46511840820312)
	    boolean_math.location = (1493.957763671875, -96.53775024414062)
	    compare_002.location = (1293.02783203125, -116.63077545166016)
	    group_input_002_1.location = (1112.19091796875, -136.7238006591797)
	    reroute_016_1.location = (801.534912109375, -160.46511840820312)
	    reroute_014_1.location = (801.534912109375, -120.2790756225586)
	    switch_001_2.location = (1082.837158203125, -39.906982421875)
	    group_output_5.location = (75.0, 50.0)
	    attribute_statistic.location = (861.81396484375, -60.0)
	    group_2.location = (1556.697265625, -269.02325439453125)
	    reroute_007.location = (-3762.76806640625, -251.3953857421875)
	    reroute_004_1.location = (1637.0693359375, -48.0)
	    position_001.location = (60.345703125, -240.45068359375)
	    named_attribute_1.location = (60.345703125, -300.729736328125)
	    switch_003_1.location = (241.1826171875, -220.357666015625)
	    reroute_006.location = (38.0, -71.92265319824219)
	    switch_002.location = (442.11279296875, -99.79951477050781)
	    compare_004.location = (60.34619140625, -39.52044677734375)
	    group_input_1.location = (-4707.1396484375, -30.37213134765625)
	    reroute_011.location = (-3581.9306640625, -70.55816650390625)
	    reroute_005.location = (49.720703125, -48.0)
	    reroute_008.location = (-3561.83740234375, -673.348876953125)
	    set_position_002.location = (861.81396484375, -140.37210083007812)
	    reroute_012_1.location = (38.0, -240.83721923828125)
	    group_input_001_1.location = (833.348388671875, -168.55813598632812)
	    mix.location = (1114.65087890625, -329.3023376464844)
	    group_001_2.location = (833.348388671875, -409.6744384765625)
	    compare_003.location = (399.6744384765625, -140.37210083007812)
	    compare_005.location = (861.81396484375, -100.18605041503906)
	
	    #Set dimensions
	    frame_001_1.width, frame_001_1.height = 1253.139892578125, 562.0
	    frame_2.width, frame_2.height = 1967.9998779296875, 637.81396484375
	    frame_002_1.width, frame_002_1.height = 612.1865234375, 458.0
	    reroute_009.width, reroute_009.height = 100.0, 100.0
	    group_input_006_1.width, group_input_006_1.height = 140.0, 100.0
	    reroute_013_1.width, reroute_013_1.height = 100.0, 100.0
	    index_1.width, index_1.height = 140.0, 100.0
	    sample_curve_001.width, sample_curve_001.height = 140.0, 100.0
	    group_input_003_1.width, group_input_003_1.height = 140.0, 100.0
	    vector_math_006_1.width, vector_math_006_1.height = 140.0, 100.0
	    interpolate_domain_3.width, interpolate_domain_3.height = 140.0, 100.0
	    group_input_005_1.width, group_input_005_1.height = 140.0, 100.0
	    boolean_math_002.width, boolean_math_002.height = 140.0, 100.0
	    field_at_index_002.width, field_at_index_002.height = 140.0, 100.0
	    vector_math_004_1.width, vector_math_004_1.height = 140.0, 100.0
	    accumulate_field.width, accumulate_field.height = 140.0, 100.0
	    curve_of_point.width, curve_of_point.height = 140.0, 100.0
	    vector_math_2.width, vector_math_2.height = 140.0, 100.0
	    index_001_1.width, index_001_1.height = 140.0, 100.0
	    curve_of_point_001.width, curve_of_point_001.height = 140.0, 100.0
	    switch_1.width, switch_1.height = 140.0, 100.0
	    math_1.width, math_1.height = 140.0, 100.0
	    compare.width, compare.height = 140.0, 100.0
	    reroute_001_1.width, reroute_001_1.height = 100.0, 100.0
	    set_position_001_1.width, set_position_001_1.height = 140.0, 100.0
	    boolean_math.width, boolean_math.height = 140.0, 100.0
	    compare_002.width, compare_002.height = 140.0, 100.0
	    group_input_002_1.width, group_input_002_1.height = 140.0, 100.0
	    reroute_016_1.width, reroute_016_1.height = 100.0, 100.0
	    reroute_014_1.width, reroute_014_1.height = 100.0, 100.0
	    switch_001_2.width, switch_001_2.height = 140.0, 100.0
	    group_output_5.width, group_output_5.height = 140.0, 100.0
	    attribute_statistic.width, attribute_statistic.height = 140.0, 100.0
	    group_2.width, group_2.height = 140.0, 100.0
	    reroute_007.width, reroute_007.height = 100.0, 100.0
	    reroute_004_1.width, reroute_004_1.height = 100.0, 100.0
	    position_001.width, position_001.height = 140.0, 100.0
	    named_attribute_1.width, named_attribute_1.height = 140.0, 100.0
	    switch_003_1.width, switch_003_1.height = 140.0, 100.0
	    reroute_006.width, reroute_006.height = 100.0, 100.0
	    switch_002.width, switch_002.height = 140.0, 100.0
	    compare_004.width, compare_004.height = 140.0, 100.0
	    group_input_1.width, group_input_1.height = 140.0, 100.0
	    reroute_011.width, reroute_011.height = 100.0, 100.0
	    reroute_005.width, reroute_005.height = 100.0, 100.0
	    reroute_008.width, reroute_008.height = 100.0, 100.0
	    set_position_002.width, set_position_002.height = 140.0, 100.0
	    reroute_012_1.width, reroute_012_1.height = 100.0, 100.0
	    group_input_001_1.width, group_input_001_1.height = 140.0, 100.0
	    mix.width, mix.height = 140.0, 100.0
	    group_001_2.width, group_001_2.height = 140.0, 100.0
	    compare_003.width, compare_003.height = 140.0, 100.0
	    compare_005.width, compare_005.height = 140.0, 100.0
	
	    #initialize restore_curve_segment_length_003 links
	    #reroute_004_1.Output -> set_position_001_1.Geometry
	    restore_curve_segment_length_003.links.new(reroute_004_1.outputs[0], set_position_001_1.inputs[0])
	    #curve_of_point.Curve Index -> accumulate_field.Group ID
	    restore_curve_segment_length_003.links.new(curve_of_point.outputs[0], accumulate_field.inputs[1])
	    #field_at_index_002.Value -> vector_math_004_1.Vector
	    restore_curve_segment_length_003.links.new(field_at_index_002.outputs[0], vector_math_004_1.inputs[0])
	    #reroute_001_1.Output -> vector_math_004_1.Vector
	    restore_curve_segment_length_003.links.new(reroute_001_1.outputs[0], vector_math_004_1.inputs[1])
	    #reroute_001_1.Output -> field_at_index_002.Value
	    restore_curve_segment_length_003.links.new(reroute_001_1.outputs[0], field_at_index_002.inputs[1])
	    #index_001_1.Index -> math_1.Value
	    restore_curve_segment_length_003.links.new(index_001_1.outputs[0], math_1.inputs[0])
	    #switch_1.Output -> field_at_index_002.Index
	    restore_curve_segment_length_003.links.new(switch_1.outputs[0], field_at_index_002.inputs[0])
	    #vector_math_2.Vector -> accumulate_field.Value
	    restore_curve_segment_length_003.links.new(vector_math_2.outputs[0], accumulate_field.inputs[0])
	    #curve_of_point_001.Index in Curve -> compare.A
	    restore_curve_segment_length_003.links.new(curve_of_point_001.outputs[1], compare.inputs[2])
	    #math_1.Value -> switch_1.False
	    restore_curve_segment_length_003.links.new(math_1.outputs[0], switch_1.inputs[1])
	    #compare.Result -> switch_1.Switch
	    restore_curve_segment_length_003.links.new(compare.outputs[0], switch_1.inputs[0])
	    #index_001_1.Index -> switch_1.True
	    restore_curve_segment_length_003.links.new(index_001_1.outputs[0], switch_1.inputs[2])
	    #reroute_006.Output -> switch_002.False
	    restore_curve_segment_length_003.links.new(reroute_006.outputs[0], switch_002.inputs[1])
	    #group_2.Root Position -> set_position_001_1.Position
	    restore_curve_segment_length_003.links.new(group_2.outputs[1], set_position_001_1.inputs[2])
	    #vector_math_004_1.Value -> mix.B
	    restore_curve_segment_length_003.links.new(vector_math_004_1.outputs[1], mix.inputs[3])
	    #mix.Result -> vector_math_2.Scale
	    restore_curve_segment_length_003.links.new(mix.outputs[0], vector_math_2.inputs[3])
	    #group_input_001_1.Factor -> mix.Factor
	    restore_curve_segment_length_003.links.new(group_input_001_1.outputs[2], mix.inputs[0])
	    #group_input_002_1.Factor -> compare_002.A
	    restore_curve_segment_length_003.links.new(group_input_002_1.outputs[2], compare_002.inputs[0])
	    #accumulate_field.Leading -> set_position_001_1.Offset
	    restore_curve_segment_length_003.links.new(accumulate_field.outputs[0], set_position_001_1.inputs[3])
	    #compare_002.Result -> boolean_math.Boolean
	    restore_curve_segment_length_003.links.new(compare_002.outputs[0], boolean_math.inputs[0])
	    #group_input_002_1.Selection -> boolean_math.Boolean
	    restore_curve_segment_length_003.links.new(group_input_002_1.outputs[1], boolean_math.inputs[1])
	    #reroute_005.Output -> reroute_004_1.Input
	    restore_curve_segment_length_003.links.new(reroute_005.outputs[0], reroute_004_1.inputs[0])
	    #reroute_012_1.Output -> sample_curve_001.Curves
	    restore_curve_segment_length_003.links.new(reroute_012_1.outputs[0], sample_curve_001.inputs[0])
	    #sample_curve_001.Position -> vector_math_006_1.Vector
	    restore_curve_segment_length_003.links.new(sample_curve_001.outputs[1], vector_math_006_1.inputs[1])
	    #sample_curve_001.Value -> vector_math_006_1.Vector
	    restore_curve_segment_length_003.links.new(sample_curve_001.outputs[0], vector_math_006_1.inputs[0])
	    #reroute_014_1.Output -> set_position_002.Geometry
	    restore_curve_segment_length_003.links.new(reroute_014_1.outputs[0], set_position_002.inputs[0])
	    #interpolate_domain_3.Value -> set_position_002.Offset
	    restore_curve_segment_length_003.links.new(interpolate_domain_3.outputs[0], set_position_002.inputs[3])
	    #index_1.Index -> sample_curve_001.Curve Index
	    restore_curve_segment_length_003.links.new(index_1.outputs[0], sample_curve_001.inputs[4])
	    #reroute_012_1.Output -> reroute_013_1.Input
	    restore_curve_segment_length_003.links.new(reroute_012_1.outputs[0], reroute_013_1.inputs[0])
	    #group_input_005_1.Selection -> boolean_math_002.Boolean
	    restore_curve_segment_length_003.links.new(group_input_005_1.outputs[1], boolean_math_002.inputs[1])
	    #compare_003.Result -> boolean_math_002.Boolean
	    restore_curve_segment_length_003.links.new(compare_003.outputs[0], boolean_math_002.inputs[0])
	    #reroute_011.Output -> reroute_005.Input
	    restore_curve_segment_length_003.links.new(reroute_011.outputs[0], reroute_005.inputs[0])
	    #group_input_003_1.Pin at Parameter -> sample_curve_001.Factor
	    restore_curve_segment_length_003.links.new(group_input_003_1.outputs[4], sample_curve_001.inputs[2])
	    #group_input_006_1.Pin at Parameter -> compare_003.A
	    restore_curve_segment_length_003.links.new(group_input_006_1.outputs[4], compare_003.inputs[0])
	    #reroute_006.Output -> compare_004.A
	    restore_curve_segment_length_003.links.new(reroute_006.outputs[0], compare_004.inputs[4])
	    #compare_004.Result -> switch_002.Switch
	    restore_curve_segment_length_003.links.new(compare_004.outputs[0], switch_002.inputs[0])
	    #named_attribute_1.Attribute -> switch_003_1.True
	    restore_curve_segment_length_003.links.new(named_attribute_1.outputs[0], switch_003_1.inputs[2])
	    #named_attribute_1.Exists -> switch_003_1.Switch
	    restore_curve_segment_length_003.links.new(named_attribute_1.outputs[1], switch_003_1.inputs[0])
	    #position_001.Position -> switch_003_1.False
	    restore_curve_segment_length_003.links.new(position_001.outputs[0], switch_003_1.inputs[1])
	    #switch_003_1.Output -> switch_002.True
	    restore_curve_segment_length_003.links.new(switch_003_1.outputs[0], switch_002.inputs[2])
	    #reroute_009.Output -> sample_curve_001.Value
	    restore_curve_segment_length_003.links.new(reroute_009.outputs[0], sample_curve_001.inputs[1])
	    #switch_002.Output -> reroute_007.Input
	    restore_curve_segment_length_003.links.new(switch_002.outputs[0], reroute_007.inputs[0])
	    #reroute_007.Output -> reroute_001_1.Input
	    restore_curve_segment_length_003.links.new(reroute_007.outputs[0], reroute_001_1.inputs[0])
	    #group_input_1.Reference Position -> reroute_006.Input
	    restore_curve_segment_length_003.links.new(group_input_1.outputs[3], reroute_006.inputs[0])
	    #reroute_007.Output -> reroute_008.Input
	    restore_curve_segment_length_003.links.new(reroute_007.outputs[0], reroute_008.inputs[0])
	    #reroute_008.Output -> reroute_009.Input
	    restore_curve_segment_length_003.links.new(reroute_008.outputs[0], reroute_009.inputs[0])
	    #group_input_1.Curves -> reroute_011.Input
	    restore_curve_segment_length_003.links.new(group_input_1.outputs[0], reroute_011.inputs[0])
	    #group_001_2.Segment Length -> mix.A
	    restore_curve_segment_length_003.links.new(group_001_2.outputs[0], mix.inputs[2])
	    #group_001_2.Segment Direction -> vector_math_2.Vector
	    restore_curve_segment_length_003.links.new(group_001_2.outputs[1], vector_math_2.inputs[0])
	    #vector_math_006_1.Vector -> interpolate_domain_3.Value
	    restore_curve_segment_length_003.links.new(vector_math_006_1.outputs[0], interpolate_domain_3.inputs[0])
	    #reroute_016_1.Output -> attribute_statistic.Attribute
	    restore_curve_segment_length_003.links.new(reroute_016_1.outputs[0], attribute_statistic.inputs[2])
	    #attribute_statistic.Max -> compare_005.A
	    restore_curve_segment_length_003.links.new(attribute_statistic.outputs[4], compare_005.inputs[0])
	    #set_position_002.Geometry -> switch_001_2.True
	    restore_curve_segment_length_003.links.new(set_position_002.outputs[0], switch_001_2.inputs[2])
	    #reroute_014_1.Output -> switch_001_2.False
	    restore_curve_segment_length_003.links.new(reroute_014_1.outputs[0], switch_001_2.inputs[1])
	    #reroute_016_1.Output -> set_position_002.Selection
	    restore_curve_segment_length_003.links.new(reroute_016_1.outputs[0], set_position_002.inputs[1])
	    #compare_005.Result -> switch_001_2.Switch
	    restore_curve_segment_length_003.links.new(compare_005.outputs[0], switch_001_2.inputs[0])
	    #reroute_014_1.Output -> attribute_statistic.Geometry
	    restore_curve_segment_length_003.links.new(reroute_014_1.outputs[0], attribute_statistic.inputs[0])
	    #boolean_math.Boolean -> set_position_001_1.Selection
	    restore_curve_segment_length_003.links.new(boolean_math.outputs[0], set_position_001_1.inputs[1])
	    #boolean_math_002.Boolean -> reroute_016_1.Input
	    restore_curve_segment_length_003.links.new(boolean_math_002.outputs[0], reroute_016_1.inputs[0])
	    #reroute_013_1.Output -> reroute_014_1.Input
	    restore_curve_segment_length_003.links.new(reroute_013_1.outputs[0], reroute_014_1.inputs[0])
	    #set_position_001_1.Geometry -> reroute_012_1.Input
	    restore_curve_segment_length_003.links.new(set_position_001_1.outputs[0], reroute_012_1.inputs[0])
	    #switch_001_2.Output -> group_output_5.Curves
	    restore_curve_segment_length_003.links.new(switch_001_2.outputs[0], group_output_5.inputs[0])
	    return restore_curve_segment_length_003
	
	restore_curve_segment_length_003 = restore_curve_segment_length_003_node_group()
	
	#initialize create_guide_index_map_001 node group
	def create_guide_index_map_001_node_group():
	    create_guide_index_map_001 = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Create Guide Index Map.001")
	
	    create_guide_index_map_001.color_tag = 'NONE'
	    create_guide_index_map_001.description = "Creates an attribute that maps each curve to its nearest guide via index"
	    create_guide_index_map_001.default_group_node_width = 140
	    
	
	    create_guide_index_map_001.is_modifier = True
	
	    #create_guide_index_map_001 interface
	    #Socket Geometry
	    geometry_socket_2 = create_guide_index_map_001.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_2.attribute_domain = 'POINT'
	
	    #Socket Guide Curves
	    guide_curves_socket = create_guide_index_map_001.interface.new_socket(name = "Guide Curves", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    guide_curves_socket.attribute_domain = 'POINT'
	
	    #Socket Guide Index
	    guide_index_socket_1 = create_guide_index_map_001.interface.new_socket(name = "Guide Index", in_out='OUTPUT', socket_type = 'NodeSocketInt')
	    guide_index_socket_1.default_value = 0
	    guide_index_socket_1.min_value = 0
	    guide_index_socket_1.max_value = 1
	    guide_index_socket_1.subtype = 'NONE'
	    guide_index_socket_1.attribute_domain = 'CURVE'
	
	    #Socket Guide Selection
	    guide_selection_socket = create_guide_index_map_001.interface.new_socket(name = "Guide Selection", in_out='OUTPUT', socket_type = 'NodeSocketBool')
	    guide_selection_socket.default_value = False
	    guide_selection_socket.attribute_domain = 'CURVE'
	
	    #Socket Geometry
	    geometry_socket_3 = create_guide_index_map_001.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_3.attribute_domain = 'POINT'
	
	    #Socket Guides
	    guides_socket = create_guide_index_map_001.interface.new_socket(name = "Guides", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    guides_socket.attribute_domain = 'POINT'
	    guides_socket.description = "Guide curves or points used for the selection of guide curves"
	
	    #Socket Guide Distance
	    guide_distance_socket = create_guide_index_map_001.interface.new_socket(name = "Guide Distance", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    guide_distance_socket.default_value = 0.0
	    guide_distance_socket.min_value = 0.0
	    guide_distance_socket.max_value = 3.4028234663852886e+38
	    guide_distance_socket.subtype = 'DISTANCE'
	    guide_distance_socket.attribute_domain = 'POINT'
	    guide_distance_socket.description = "Minimum distance between two guides"
	
	    #Socket Guide Mask
	    guide_mask_socket = create_guide_index_map_001.interface.new_socket(name = "Guide Mask", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    guide_mask_socket.default_value = 1.0
	    guide_mask_socket.min_value = 0.0
	    guide_mask_socket.max_value = 1.0
	    guide_mask_socket.subtype = 'NONE'
	    guide_mask_socket.attribute_domain = 'POINT'
	    guide_mask_socket.description = "Mask for which curves are eligible to be selected as guides"
	
	    #Socket Group ID
	    group_id_socket = create_guide_index_map_001.interface.new_socket(name = "Group ID", in_out='INPUT', socket_type = 'NodeSocketInt')
	    group_id_socket.default_value = 0
	    group_id_socket.min_value = -2147483648
	    group_id_socket.max_value = 2147483647
	    group_id_socket.subtype = 'NONE'
	    group_id_socket.attribute_domain = 'POINT'
	    group_id_socket.description = "ID to group curves together for guide map creation"
	
	
	    #initialize create_guide_index_map_001 nodes
	    #node Frame.003
	    frame_003_1 = create_guide_index_map_001.nodes.new("NodeFrame")
	    frame_003_1.label = "Sample Guide Index"
	    frame_003_1.name = "Frame.003"
	    frame_003_1.label_size = 20
	    frame_003_1.shrink = True
	
	    #node Frame.004
	    frame_004_1 = create_guide_index_map_001.nodes.new("NodeFrame")
	    frame_004_1.label = "Isolate Guide Points"
	    frame_004_1.name = "Frame.004"
	    frame_004_1.label_size = 20
	    frame_004_1.shrink = True
	
	    #node Frame.006
	    frame_006 = create_guide_index_map_001.nodes.new("NodeFrame")
	    frame_006.label = "Input Guide Geometry Points"
	    frame_006.name = "Frame.006"
	    frame_006.label_size = 20
	    frame_006.shrink = True
	
	    #node Frame
	    frame_3 = create_guide_index_map_001.nodes.new("NodeFrame")
	    frame_3.label = "Ensure Data on Input Points"
	    frame_3.name = "Frame"
	    frame_3.label_size = 20
	    frame_3.shrink = True
	
	    #node Frame.007
	    frame_007 = create_guide_index_map_001.nodes.new("NodeFrame")
	    frame_007.label = "Switch Guide Input"
	    frame_007.name = "Frame.007"
	    frame_007.label_size = 20
	    frame_007.shrink = True
	
	    #node Frame.002
	    frame_002_2 = create_guide_index_map_001.nodes.new("NodeFrame")
	    frame_002_2.label = "Sample per Group ID"
	    frame_002_2.name = "Frame.002"
	    frame_002_2.label_size = 20
	    frame_002_2.shrink = True
	
	    #node Frame.005
	    frame_005 = create_guide_index_map_001.nodes.new("NodeFrame")
	    frame_005.label = "Optimization"
	    frame_005.name = "Frame.005"
	    frame_005.label_size = 20
	    frame_005.shrink = True
	
	    #node Reroute.019
	    reroute_019_1 = create_guide_index_map_001.nodes.new("NodeReroute")
	    reroute_019_1.name = "Reroute.019"
	    reroute_019_1.socket_idname = "NodeSocketGeometry"
	    #node Reroute.021
	    reroute_021 = create_guide_index_map_001.nodes.new("NodeReroute")
	    reroute_021.name = "Reroute.021"
	    reroute_021.socket_idname = "NodeSocketGeometry"
	    #node Reroute.022
	    reroute_022 = create_guide_index_map_001.nodes.new("NodeReroute")
	    reroute_022.name = "Reroute.022"
	    reroute_022.socket_idname = "NodeSocketGeometry"
	    #node Reroute.023
	    reroute_023 = create_guide_index_map_001.nodes.new("NodeReroute")
	    reroute_023.name = "Reroute.023"
	    reroute_023.socket_idname = "NodeSocketGeometry"
	    #node Reroute.001
	    reroute_001_2 = create_guide_index_map_001.nodes.new("NodeReroute")
	    reroute_001_2.name = "Reroute.001"
	    reroute_001_2.socket_idname = "NodeSocketGeometry"
	    #node Reroute
	    reroute_2 = create_guide_index_map_001.nodes.new("NodeReroute")
	    reroute_2.name = "Reroute"
	    reroute_2.socket_idname = "NodeSocketGeometry"
	    #node Set Position.002
	    set_position_002_1 = create_guide_index_map_001.nodes.new("GeometryNodeSetPosition")
	    set_position_002_1.name = "Set Position.002"
	    set_position_002_1.inputs[1].hide = True
	    set_position_002_1.inputs[2].hide = True
	    #Selection
	    set_position_002_1.inputs[1].default_value = True
	    #Position
	    set_position_002_1.inputs[2].default_value = (0.0, 0.0, 0.0)
	
	    #node Switch.002
	    switch_002_1 = create_guide_index_map_001.nodes.new("GeometryNodeSwitch")
	    switch_002_1.name = "Switch.002"
	    switch_002_1.input_type = 'GEOMETRY'
	
	    #node Set Position
	    set_position_1 = create_guide_index_map_001.nodes.new("GeometryNodeSetPosition")
	    set_position_1.name = "Set Position"
	    set_position_1.inputs[1].hide = True
	    set_position_1.inputs[2].hide = True
	    #Selection
	    set_position_1.inputs[1].default_value = True
	    #Position
	    set_position_1.inputs[2].default_value = (0.0, 0.0, 0.0)
	
	    #node Vector Math.003
	    vector_math_003_1 = create_guide_index_map_001.nodes.new("ShaderNodeVectorMath")
	    vector_math_003_1.name = "Vector Math.003"
	    vector_math_003_1.hide = True
	    vector_math_003_1.operation = 'SCALE'
	    #Vector
	    vector_math_003_1.inputs[0].default_value = (100.0, 100.0, 100.0)
	
	    #node Vector Math.004
	    vector_math_004_2 = create_guide_index_map_001.nodes.new("ShaderNodeVectorMath")
	    vector_math_004_2.name = "Vector Math.004"
	    vector_math_004_2.hide = True
	    vector_math_004_2.operation = 'SCALE'
	    #Scale
	    vector_math_004_2.inputs[3].default_value = -1.0
	
	    #node Merge by Distance
	    merge_by_distance = create_guide_index_map_001.nodes.new("GeometryNodeMergeByDistance")
	    merge_by_distance.name = "Merge by Distance"
	    merge_by_distance.hide = True
	    merge_by_distance.mode = 'ALL'
	
	    #node Merge by Distance.001
	    merge_by_distance_001 = create_guide_index_map_001.nodes.new("GeometryNodeMergeByDistance")
	    merge_by_distance_001.name = "Merge by Distance.001"
	    merge_by_distance_001.hide = True
	    merge_by_distance_001.mode = 'ALL'
	
	    #node Group Input.001
	    group_input_001_2 = create_guide_index_map_001.nodes.new("NodeGroupInput")
	    group_input_001_2.name = "Group Input.001"
	    group_input_001_2.outputs[0].hide = True
	    group_input_001_2.outputs[1].hide = True
	    group_input_001_2.outputs[3].hide = True
	    group_input_001_2.outputs[4].hide = True
	    group_input_001_2.outputs[5].hide = True
	
	    #node Reroute.026
	    reroute_026 = create_guide_index_map_001.nodes.new("NodeReroute")
	    reroute_026.name = "Reroute.026"
	    reroute_026.socket_idname = "NodeSocketFloatDistance"
	    #node Compare.004
	    compare_004_1 = create_guide_index_map_001.nodes.new("FunctionNodeCompare")
	    compare_004_1.name = "Compare.004"
	    compare_004_1.hide = True
	    compare_004_1.data_type = 'FLOAT'
	    compare_004_1.mode = 'ELEMENT'
	    compare_004_1.operation = 'GREATER_THAN'
	    #B
	    compare_004_1.inputs[1].default_value = 0.0
	
	    #node Reroute.015
	    reroute_015_2 = create_guide_index_map_001.nodes.new("NodeReroute")
	    reroute_015_2.name = "Reroute.015"
	    reroute_015_2.socket_idname = "NodeSocketGeometry"
	    #node Reroute.016
	    reroute_016_2 = create_guide_index_map_001.nodes.new("NodeReroute")
	    reroute_016_2.name = "Reroute.016"
	    reroute_016_2.socket_idname = "NodeSocketGeometry"
	    #node Reroute.013
	    reroute_013_2 = create_guide_index_map_001.nodes.new("NodeReroute")
	    reroute_013_2.name = "Reroute.013"
	    reroute_013_2.socket_idname = "NodeSocketGeometry"
	    #node Reroute.017
	    reroute_017_2 = create_guide_index_map_001.nodes.new("NodeReroute")
	    reroute_017_2.name = "Reroute.017"
	    reroute_017_2.socket_idname = "NodeSocketGeometry"
	    #node Group Input
	    group_input_2 = create_guide_index_map_001.nodes.new("NodeGroupInput")
	    group_input_2.name = "Group Input"
	    group_input_2.outputs[1].hide = True
	    group_input_2.outputs[2].hide = True
	    group_input_2.outputs[3].hide = True
	    group_input_2.outputs[4].hide = True
	    group_input_2.outputs[5].hide = True
	
	    #node Separate Components.001
	    separate_components_001 = create_guide_index_map_001.nodes.new("GeometryNodeSeparateComponents")
	    separate_components_001.name = "Separate Components.001"
	
	    #node Group Input.003
	    group_input_003_2 = create_guide_index_map_001.nodes.new("NodeGroupInput")
	    group_input_003_2.name = "Group Input.003"
	    group_input_003_2.outputs[0].hide = True
	    group_input_003_2.outputs[1].hide = True
	    group_input_003_2.outputs[2].hide = True
	    group_input_003_2.outputs[4].hide = True
	    group_input_003_2.outputs[5].hide = True
	
	    #node Capture Attribute.003
	    capture_attribute_003 = create_guide_index_map_001.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_003.name = "Capture Attribute.003"
	    capture_attribute_003.active_index = 0
	    capture_attribute_003.capture_items.clear()
	    capture_attribute_003.capture_items.new('FLOAT', "Value")
	    capture_attribute_003.capture_items["Value"].data_type = 'FLOAT'
	    capture_attribute_003.domain = 'CURVE'
	
	    #node Group Input.010
	    group_input_010 = create_guide_index_map_001.nodes.new("NodeGroupInput")
	    group_input_010.name = "Group Input.010"
	    group_input_010.outputs[0].hide = True
	    group_input_010.outputs[1].hide = True
	    group_input_010.outputs[2].hide = True
	    group_input_010.outputs[3].hide = True
	    group_input_010.outputs[5].hide = True
	
	    #node Capture Attribute.006
	    capture_attribute_006 = create_guide_index_map_001.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_006.name = "Capture Attribute.006"
	    capture_attribute_006.active_index = 0
	    capture_attribute_006.capture_items.clear()
	    capture_attribute_006.capture_items.new('FLOAT', "Value")
	    capture_attribute_006.capture_items["Value"].data_type = 'INT'
	    capture_attribute_006.domain = 'CURVE'
	
	    #node Reroute.005
	    reroute_005_1 = create_guide_index_map_001.nodes.new("NodeReroute")
	    reroute_005_1.name = "Reroute.005"
	    reroute_005_1.socket_idname = "NodeSocketGeometry"
	    #node Capture Attribute.001
	    capture_attribute_001_1 = create_guide_index_map_001.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_001_1.name = "Capture Attribute.001"
	    capture_attribute_001_1.active_index = 0
	    capture_attribute_001_1.capture_items.clear()
	    capture_attribute_001_1.capture_items.new('FLOAT', "Value")
	    capture_attribute_001_1.capture_items["Value"].data_type = 'INT'
	    capture_attribute_001_1.domain = 'CURVE'
	
	    #node Curve to Points
	    curve_to_points = create_guide_index_map_001.nodes.new("GeometryNodeCurveToPoints")
	    curve_to_points.name = "Curve to Points"
	    curve_to_points.mode = 'COUNT'
	    curve_to_points.inputs[2].hide = True
	    curve_to_points.outputs[1].hide = True
	    curve_to_points.outputs[2].hide = True
	    curve_to_points.outputs[3].hide = True
	    #Count
	    curve_to_points.inputs[1].default_value = 1
	
	    #node Index.001
	    index_001_2 = create_guide_index_map_001.nodes.new("GeometryNodeInputIndex")
	    index_001_2.name = "Index.001"
	
	    #node Reroute.014
	    reroute_014_2 = create_guide_index_map_001.nodes.new("NodeReroute")
	    reroute_014_2.name = "Reroute.014"
	    reroute_014_2.socket_idname = "NodeSocketGeometry"
	    #node Reroute.027
	    reroute_027 = create_guide_index_map_001.nodes.new("NodeReroute")
	    reroute_027.name = "Reroute.027"
	    reroute_027.socket_idname = "NodeSocketGeometry"
	    #node Reroute.007
	    reroute_007_1 = create_guide_index_map_001.nodes.new("NodeReroute")
	    reroute_007_1.name = "Reroute.007"
	    reroute_007_1.socket_idname = "NodeSocketGeometry"
	    #node Reroute.004
	    reroute_004_2 = create_guide_index_map_001.nodes.new("NodeReroute")
	    reroute_004_2.name = "Reroute.004"
	    reroute_004_2.socket_idname = "NodeSocketGeometry"
	    #node Curve to Points.001
	    curve_to_points_001 = create_guide_index_map_001.nodes.new("GeometryNodeCurveToPoints")
	    curve_to_points_001.name = "Curve to Points.001"
	    curve_to_points_001.mode = 'COUNT'
	    curve_to_points_001.inputs[2].hide = True
	    curve_to_points_001.outputs[1].hide = True
	    curve_to_points_001.outputs[2].hide = True
	    curve_to_points_001.outputs[3].hide = True
	    #Count
	    curve_to_points_001.inputs[1].default_value = 1
	
	    #node Group Input.004
	    group_input_004_1 = create_guide_index_map_001.nodes.new("NodeGroupInput")
	    group_input_004_1.name = "Group Input.004"
	    group_input_004_1.outputs[0].hide = True
	    group_input_004_1.outputs[2].hide = True
	    group_input_004_1.outputs[3].hide = True
	    group_input_004_1.outputs[4].hide = True
	    group_input_004_1.outputs[5].hide = True
	
	    #node Mesh to Points
	    mesh_to_points = create_guide_index_map_001.nodes.new("GeometryNodeMeshToPoints")
	    mesh_to_points.name = "Mesh to Points"
	    mesh_to_points.mode = 'VERTICES'
	    mesh_to_points.inputs[1].hide = True
	    mesh_to_points.inputs[2].hide = True
	    mesh_to_points.inputs[3].hide = True
	    #Selection
	    mesh_to_points.inputs[1].default_value = True
	    #Position
	    mesh_to_points.inputs[2].default_value = (0.0, 0.0, 0.0)
	    #Radius
	    mesh_to_points.inputs[3].default_value = 0.05000000074505806
	
	    #node Separate Components
	    separate_components_1 = create_guide_index_map_001.nodes.new("GeometryNodeSeparateComponents")
	    separate_components_1.name = "Separate Components"
	    separate_components_1.outputs[4].hide = True
	    separate_components_1.outputs[5].hide = True
	
	    #node Join Geometry
	    join_geometry_1 = create_guide_index_map_001.nodes.new("GeometryNodeJoinGeometry")
	    join_geometry_1.name = "Join Geometry"
	
	    #node Domain Size
	    domain_size = create_guide_index_map_001.nodes.new("GeometryNodeAttributeDomainSize")
	    domain_size.name = "Domain Size"
	    domain_size.hide = True
	    domain_size.component = 'POINTCLOUD'
	    domain_size.outputs[1].hide = True
	    domain_size.outputs[2].hide = True
	    domain_size.outputs[3].hide = True
	    domain_size.outputs[4].hide = True
	    domain_size.outputs[5].hide = True
	
	    #node Compare.003
	    compare_003_1 = create_guide_index_map_001.nodes.new("FunctionNodeCompare")
	    compare_003_1.name = "Compare.003"
	    compare_003_1.data_type = 'INT'
	    compare_003_1.mode = 'ELEMENT'
	    compare_003_1.operation = 'GREATER_THAN'
	    #B_INT
	    compare_003_1.inputs[3].default_value = 0
	
	    #node Group Input.008
	    group_input_008 = create_guide_index_map_001.nodes.new("NodeGroupInput")
	    group_input_008.name = "Group Input.008"
	    group_input_008.outputs[0].hide = True
	    group_input_008.outputs[1].hide = True
	    group_input_008.outputs[2].hide = True
	    group_input_008.outputs[4].hide = True
	    group_input_008.outputs[5].hide = True
	
	    #node Reroute.020
	    reroute_020_1 = create_guide_index_map_001.nodes.new("NodeReroute")
	    reroute_020_1.name = "Reroute.020"
	    reroute_020_1.socket_idname = "NodeSocketGeometry"
	    #node Sample Nearest.002
	    sample_nearest_002 = create_guide_index_map_001.nodes.new("GeometryNodeSampleNearest")
	    sample_nearest_002.name = "Sample Nearest.002"
	    sample_nearest_002.domain = 'POINT'
	    #Sample Position
	    sample_nearest_002.inputs[1].default_value = (0.0, 0.0, 0.0)
	
	    #node Sample Index.004
	    sample_index_004 = create_guide_index_map_001.nodes.new("GeometryNodeSampleIndex")
	    sample_index_004.name = "Sample Index.004"
	    sample_index_004.clamp = False
	    sample_index_004.data_type = 'INT'
	    sample_index_004.domain = 'POINT'
	
	    #node Group Input.009
	    group_input_009 = create_guide_index_map_001.nodes.new("NodeGroupInput")
	    group_input_009.name = "Group Input.009"
	    group_input_009.outputs[0].hide = True
	    group_input_009.outputs[1].hide = True
	    group_input_009.outputs[2].hide = True
	    group_input_009.outputs[3].hide = True
	    group_input_009.outputs[5].hide = True
	
	    #node Math.003
	    math_003 = create_guide_index_map_001.nodes.new("ShaderNodeMath")
	    math_003.name = "Math.003"
	    math_003.operation = 'ADD'
	    math_003.use_clamp = False
	
	    #node Capture Attribute.005
	    capture_attribute_005 = create_guide_index_map_001.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_005.name = "Capture Attribute.005"
	    capture_attribute_005.active_index = 0
	    capture_attribute_005.capture_items.clear()
	    capture_attribute_005.capture_items.new('FLOAT', "Value")
	    capture_attribute_005.capture_items["Value"].data_type = 'INT'
	    capture_attribute_005.domain = 'POINT'
	
	    #node Capture Attribute.004
	    capture_attribute_004 = create_guide_index_map_001.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_004.name = "Capture Attribute.004"
	    capture_attribute_004.active_index = 0
	    capture_attribute_004.capture_items.clear()
	    capture_attribute_004.capture_items.new('FLOAT', "Value")
	    capture_attribute_004.capture_items["Value"].data_type = 'FLOAT'
	    capture_attribute_004.domain = 'POINT'
	
	    #node Switch.003
	    switch_003_2 = create_guide_index_map_001.nodes.new("GeometryNodeSwitch")
	    switch_003_2.name = "Switch.003"
	    switch_003_2.input_type = 'FLOAT'
	
	    #node Reroute.024
	    reroute_024 = create_guide_index_map_001.nodes.new("NodeReroute")
	    reroute_024.name = "Reroute.024"
	    reroute_024.socket_idname = "NodeSocketBool"
	    #node Reroute.028
	    reroute_028 = create_guide_index_map_001.nodes.new("NodeReroute")
	    reroute_028.name = "Reroute.028"
	    reroute_028.socket_idname = "NodeSocketGeometry"
	    #node Compare.002
	    compare_002_1 = create_guide_index_map_001.nodes.new("FunctionNodeCompare")
	    compare_002_1.name = "Compare.002"
	    compare_002_1.data_type = 'FLOAT'
	    compare_002_1.mode = 'ELEMENT'
	    compare_002_1.operation = 'LESS_THAN'
	
	    #node Boolean Math
	    boolean_math_1 = create_guide_index_map_001.nodes.new("FunctionNodeBooleanMath")
	    boolean_math_1.name = "Boolean Math"
	    boolean_math_1.operation = 'NOT'
	
	    #node Random Value.001
	    random_value_001_1 = create_guide_index_map_001.nodes.new("FunctionNodeRandomValue")
	    random_value_001_1.name = "Random Value.001"
	    random_value_001_1.data_type = 'FLOAT'
	    #Min_001
	    random_value_001_1.inputs[2].default_value = 0.0
	    #Max_001
	    random_value_001_1.inputs[3].default_value = 1.0
	    #ID
	    random_value_001_1.inputs[7].default_value = 0
	    #Seed
	    random_value_001_1.inputs[8].default_value = 568746
	
	    #node Switch
	    switch_2 = create_guide_index_map_001.nodes.new("GeometryNodeSwitch")
	    switch_2.name = "Switch"
	    switch_2.input_type = 'GEOMETRY'
	
	    #node Delete Geometry.002
	    delete_geometry_002 = create_guide_index_map_001.nodes.new("GeometryNodeDeleteGeometry")
	    delete_geometry_002.name = "Delete Geometry.002"
	    delete_geometry_002.domain = 'POINT'
	    delete_geometry_002.mode = 'ALL'
	
	    #node Reroute.008
	    reroute_008_1 = create_guide_index_map_001.nodes.new("NodeReroute")
	    reroute_008_1.name = "Reroute.008"
	    reroute_008_1.socket_idname = "NodeSocketGeometry"
	    #node Position
	    position = create_guide_index_map_001.nodes.new("GeometryNodeInputPosition")
	    position.name = "Position"
	
	    #node Vector Math.002
	    vector_math_002_1 = create_guide_index_map_001.nodes.new("ShaderNodeVectorMath")
	    vector_math_002_1.name = "Vector Math.002"
	    vector_math_002_1.operation = 'ADD'
	
	    #node Vector Math.001
	    vector_math_001_2 = create_guide_index_map_001.nodes.new("ShaderNodeVectorMath")
	    vector_math_001_2.name = "Vector Math.001"
	    vector_math_001_2.operation = 'SCALE'
	    #Vector
	    vector_math_001_2.inputs[0].default_value = (100.0, 100.0, 100.0)
	
	    #node Set Position.001
	    set_position_001_2 = create_guide_index_map_001.nodes.new("GeometryNodeSetPosition")
	    set_position_001_2.name = "Set Position.001"
	    set_position_001_2.inputs[1].hide = True
	    set_position_001_2.inputs[2].hide = True
	    #Selection
	    set_position_001_2.inputs[1].default_value = True
	    #Position
	    set_position_001_2.inputs[2].default_value = (0.0, 0.0, 0.0)
	
	    #node Reroute.010
	    reroute_010 = create_guide_index_map_001.nodes.new("NodeReroute")
	    reroute_010.name = "Reroute.010"
	    reroute_010.hide = True
	    reroute_010.socket_idname = "NodeSocketGeometry"
	    #node Sample Nearest.007
	    sample_nearest_007 = create_guide_index_map_001.nodes.new("GeometryNodeSampleNearest")
	    sample_nearest_007.name = "Sample Nearest.007"
	    sample_nearest_007.domain = 'POINT'
	    sample_nearest_007.inputs[1].hide = True
	    #Sample Position
	    sample_nearest_007.inputs[1].default_value = (0.0, 0.0, 0.0)
	
	    #node Switch.001
	    switch_001_3 = create_guide_index_map_001.nodes.new("GeometryNodeSwitch")
	    switch_001_3.name = "Switch.001"
	    switch_001_3.input_type = 'INT'
	
	    #node Group Input.007
	    group_input_007_1 = create_guide_index_map_001.nodes.new("NodeGroupInput")
	    group_input_007_1.name = "Group Input.007"
	    group_input_007_1.outputs[0].hide = True
	    group_input_007_1.outputs[1].hide = True
	    group_input_007_1.outputs[2].hide = True
	    group_input_007_1.outputs[3].hide = True
	    group_input_007_1.outputs[5].hide = True
	
	    #node Math
	    math_2 = create_guide_index_map_001.nodes.new("ShaderNodeMath")
	    math_2.name = "Math"
	    math_2.hide = True
	    math_2.operation = 'SUBTRACT'
	    math_2.use_clamp = False
	
	    #node Math.001
	    math_001 = create_guide_index_map_001.nodes.new("ShaderNodeMath")
	    math_001.name = "Math.001"
	    math_001.hide = True
	    math_001.operation = 'ABSOLUTE'
	    math_001.use_clamp = False
	
	    #node Evaluate at Index
	    evaluate_at_index_2 = create_guide_index_map_001.nodes.new("GeometryNodeFieldAtIndex")
	    evaluate_at_index_2.name = "Evaluate at Index"
	    evaluate_at_index_2.hide = True
	    evaluate_at_index_2.data_type = 'INT'
	    evaluate_at_index_2.domain = 'POINT'
	    #Index
	    evaluate_at_index_2.inputs[0].default_value = 0
	
	    #node Accumulate Field.001
	    accumulate_field_001 = create_guide_index_map_001.nodes.new("GeometryNodeAccumulateField")
	    accumulate_field_001.name = "Accumulate Field.001"
	    accumulate_field_001.hide = True
	    accumulate_field_001.data_type = 'INT'
	    accumulate_field_001.domain = 'POINT'
	    accumulate_field_001.inputs[1].hide = True
	    accumulate_field_001.outputs[0].hide = True
	    accumulate_field_001.outputs[1].hide = True
	    #Value
	    accumulate_field_001.inputs[0].default_value = 1
	    #Group Index
	    accumulate_field_001.inputs[1].default_value = 0
	
	    #node Sample Index.003
	    sample_index_003 = create_guide_index_map_001.nodes.new("GeometryNodeSampleIndex")
	    sample_index_003.name = "Sample Index.003"
	    sample_index_003.hide = True
	    sample_index_003.clamp = False
	    sample_index_003.data_type = 'INT'
	    sample_index_003.domain = 'POINT'
	    #Index
	    sample_index_003.inputs[2].default_value = 0
	
	    #node Sample Nearest.001
	    sample_nearest_001 = create_guide_index_map_001.nodes.new("GeometryNodeSampleNearest")
	    sample_nearest_001.name = "Sample Nearest.001"
	    sample_nearest_001.domain = 'POINT'
	    #Sample Position
	    sample_nearest_001.inputs[1].default_value = (0.0, 0.0, 0.0)
	
	    #node Index
	    index_2 = create_guide_index_map_001.nodes.new("GeometryNodeInputIndex")
	    index_2.name = "Index"
	
	    #node Sample Index
	    sample_index = create_guide_index_map_001.nodes.new("GeometryNodeSampleIndex")
	    sample_index.name = "Sample Index"
	    sample_index.clamp = False
	    sample_index.data_type = 'INT'
	    sample_index.domain = 'POINT'
	
	    #node Sample Index.002
	    sample_index_002 = create_guide_index_map_001.nodes.new("GeometryNodeSampleIndex")
	    sample_index_002.name = "Sample Index.002"
	    sample_index_002.clamp = False
	    sample_index_002.data_type = 'INT'
	    sample_index_002.domain = 'POINT'
	
	    #node Reroute.018
	    reroute_018_2 = create_guide_index_map_001.nodes.new("NodeReroute")
	    reroute_018_2.name = "Reroute.018"
	    reroute_018_2.socket_idname = "NodeSocketGeometry"
	    #node Sample Nearest.005
	    sample_nearest_005 = create_guide_index_map_001.nodes.new("GeometryNodeSampleNearest")
	    sample_nearest_005.name = "Sample Nearest.005"
	    sample_nearest_005.domain = 'POINT'
	
	    #node Compare
	    compare_1 = create_guide_index_map_001.nodes.new("FunctionNodeCompare")
	    compare_1.name = "Compare"
	    compare_1.hide = True
	    compare_1.data_type = 'INT'
	    compare_1.mode = 'ELEMENT'
	    compare_1.operation = 'NOT_EQUAL'
	    #B_INT
	    compare_1.inputs[3].default_value = 0
	
	    #node Capture Attribute.002
	    capture_attribute_002_1 = create_guide_index_map_001.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_002_1.name = "Capture Attribute.002"
	    capture_attribute_002_1.active_index = 0
	    capture_attribute_002_1.capture_items.clear()
	    capture_attribute_002_1.capture_items.new('FLOAT', "Value")
	    capture_attribute_002_1.capture_items["Value"].data_type = 'BOOLEAN'
	    capture_attribute_002_1.domain = 'CURVE'
	
	    #node Compare.001
	    compare_001 = create_guide_index_map_001.nodes.new("FunctionNodeCompare")
	    compare_001.name = "Compare.001"
	    compare_001.hide = True
	    compare_001.data_type = 'INT'
	    compare_001.mode = 'ELEMENT'
	    compare_001.operation = 'EQUAL'
	
	    #node Index.002
	    index_002_1 = create_guide_index_map_001.nodes.new("GeometryNodeInputIndex")
	    index_002_1.name = "Index.002"
	
	    #node Reroute.011
	    reroute_011_1 = create_guide_index_map_001.nodes.new("NodeReroute")
	    reroute_011_1.name = "Reroute.011"
	    reroute_011_1.socket_idname = "NodeSocketInt"
	    #node Reroute.012
	    reroute_012_2 = create_guide_index_map_001.nodes.new("NodeReroute")
	    reroute_012_2.name = "Reroute.012"
	    reroute_012_2.socket_idname = "NodeSocketGeometry"
	    #node Join Geometry.001
	    join_geometry_001_1 = create_guide_index_map_001.nodes.new("GeometryNodeJoinGeometry")
	    join_geometry_001_1.name = "Join Geometry.001"
	
	    #node Reroute.003
	    reroute_003_1 = create_guide_index_map_001.nodes.new("NodeReroute")
	    reroute_003_1.name = "Reroute.003"
	    reroute_003_1.socket_idname = "NodeSocketBool"
	    #node Reroute.002
	    reroute_002_1 = create_guide_index_map_001.nodes.new("NodeReroute")
	    reroute_002_1.name = "Reroute.002"
	    reroute_002_1.socket_idname = "NodeSocketInt"
	    #node Reroute.009
	    reroute_009_1 = create_guide_index_map_001.nodes.new("NodeReroute")
	    reroute_009_1.name = "Reroute.009"
	    reroute_009_1.socket_idname = "NodeSocketGeometry"
	    #node Group Output
	    group_output_6 = create_guide_index_map_001.nodes.new("NodeGroupOutput")
	    group_output_6.name = "Group Output"
	    group_output_6.is_active_output = True
	
	    #node Reroute.006
	    reroute_006_1 = create_guide_index_map_001.nodes.new("NodeReroute")
	    reroute_006_1.name = "Reroute.006"
	    reroute_006_1.socket_idname = "NodeSocketBool"
	    #node Capture Attribute
	    capture_attribute_1 = create_guide_index_map_001.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_1.name = "Capture Attribute"
	    capture_attribute_1.active_index = 0
	    capture_attribute_1.capture_items.clear()
	    capture_attribute_1.capture_items.new('FLOAT', "Value")
	    capture_attribute_1.capture_items["Value"].data_type = 'INT'
	    capture_attribute_1.domain = 'CURVE'
	
	    #node Separate Geometry
	    separate_geometry = create_guide_index_map_001.nodes.new("GeometryNodeSeparateGeometry")
	    separate_geometry.name = "Separate Geometry"
	    separate_geometry.hide = True
	    separate_geometry.domain = 'CURVE'
	
	    #node Sample Index.001
	    sample_index_001 = create_guide_index_map_001.nodes.new("GeometryNodeSampleIndex")
	    sample_index_001.name = "Sample Index.001"
	    sample_index_001.clamp = False
	    sample_index_001.data_type = 'INT'
	    sample_index_001.domain = 'POINT'
	
	    #node Store Named Attribute
	    store_named_attribute_1 = create_guide_index_map_001.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_1.name = "Store Named Attribute"
	    store_named_attribute_1.data_type = 'INT'
	    store_named_attribute_1.domain = 'CURVE'
	    store_named_attribute_1.inputs[1].hide = True
	    #Selection
	    store_named_attribute_1.inputs[1].default_value = True
	    #Name
	    store_named_attribute_1.inputs[2].default_value = "guide_curve_index"
	
	
	
	
	    #Set parents
	    reroute_001_2.parent = frame_003_1
	    reroute_2.parent = frame_004_1
	    set_position_002_1.parent = frame_004_1
	    switch_002_1.parent = frame_004_1
	    set_position_1.parent = frame_004_1
	    vector_math_003_1.parent = frame_004_1
	    vector_math_004_2.parent = frame_004_1
	    merge_by_distance.parent = frame_004_1
	    merge_by_distance_001.parent = frame_004_1
	    group_input_001_2.parent = frame_004_1
	    reroute_026.parent = frame_004_1
	    compare_004_1.parent = frame_004_1
	    reroute_014_2.parent = frame_003_1
	    reroute_004_2.parent = frame_003_1
	    curve_to_points_001.parent = frame_006
	    group_input_004_1.parent = frame_006
	    mesh_to_points.parent = frame_006
	    separate_components_1.parent = frame_006
	    join_geometry_1.parent = frame_006
	    domain_size.parent = frame_3
	    compare_003_1.parent = frame_3
	    group_input_008.parent = frame_3
	    reroute_020_1.parent = frame_3
	    sample_nearest_002.parent = frame_3
	    sample_index_004.parent = frame_3
	    group_input_009.parent = frame_3
	    math_003.parent = frame_3
	    capture_attribute_005.parent = frame_3
	    capture_attribute_004.parent = frame_3
	    switch_003_2.parent = frame_3
	    reroute_024.parent = frame_3
	    compare_002_1.parent = frame_004_1
	    boolean_math_1.parent = frame_004_1
	    random_value_001_1.parent = frame_004_1
	    switch_2.parent = frame_007
	    delete_geometry_002.parent = frame_004_1
	    position.parent = frame_002_2
	    vector_math_002_1.parent = frame_002_2
	    vector_math_001_2.parent = frame_002_2
	    set_position_001_2.parent = frame_002_2
	    reroute_010.parent = frame_002_2
	    sample_nearest_007.parent = frame_002_2
	    switch_001_3.parent = frame_002_2
	    group_input_007_1.parent = frame_005
	    math_2.parent = frame_005
	    math_001.parent = frame_005
	    evaluate_at_index_2.parent = frame_005
	    accumulate_field_001.parent = frame_005
	    sample_index_003.parent = frame_005
	    sample_nearest_001.parent = frame_003_1
	    index_2.parent = frame_003_1
	    sample_index.parent = frame_003_1
	    sample_index_002.parent = frame_003_1
	    reroute_018_2.parent = frame_003_1
	    sample_nearest_005.parent = frame_002_2
	    compare_1.parent = frame_005
	    capture_attribute_1.parent = frame_003_1
	    sample_index_001.parent = frame_003_1
	
	    #Set locations
	    frame_003_1.location = (-2292.6279296875, 32.651153564453125)
	    frame_004_1.location = (-3952.465087890625, -443.64434814453125)
	    frame_006.location = (-6505.1162109375, -663.0697631835938)
	    frame_3.location = (-5614.32568359375, -581.8604736328125)
	    frame_007.location = (-4274.791015625, -301.3953552246094)
	    frame_002_2.location = (-2708.3720703125, -721.6744384765625)
	    frame_005.location = (-3763.255859375, -151.53488159179688)
	    reroute_019_1.location = (-467.51171875, 351.3953552246094)
	    reroute_021.location = (-467.51171875, 311.2093200683594)
	    reroute_022.location = (-467.51171875, 271.0232849121094)
	    reroute_023.location = (-467.51171875, 230.83718872070312)
	    reroute_001_2.location = (137.30224609375, -263.7346496582031)
	    reroute_2.location = (180.65380859375, -36.83721923828125)
	    set_position_002_1.location = (613.210693359375, -156.92254638671875)
	    switch_002_1.location = (794.0478515625, -56.4573974609375)
	    set_position_1.location = (211.350341796875, -96.64349365234375)
	    vector_math_003_1.location = (30.512939453125, -156.92254638671875)
	    vector_math_004_2.location = (30.512939453125, -197.10858154296875)
	    merge_by_distance.location = (432.37353515625, -177.01556396484375)
	    merge_by_distance_001.location = (432.37353515625, -136.82952880859375)
	    group_input_001_2.location = (30.512939453125, -257.38763427734375)
	    reroute_026.location = (392.1875, -197.10858154296875)
	    compare_004_1.location = (231.443115234375, -277.48065185546875)
	    reroute_015_2.location = (-6535.60498046875, 311.2093200683594)
	    reroute_016_2.location = (-6535.60498046875, 271.0232849121094)
	    reroute_013_2.location = (-6535.60498046875, 230.83718872070312)
	    reroute_017_2.location = (-6535.60498046875, 351.3953552246094)
	    group_input_2.location = (-7299.1396484375, 29.906982421875)
	    separate_components_001.location = (-7078.1162109375, 130.37210083007812)
	    group_input_003_2.location = (-7017.837890625, -130.83721923828125)
	    capture_attribute_003.location = (-6837.0, 29.906982421875)
	    group_input_010.location = (-6837.0, -191.11627197265625)
	    capture_attribute_006.location = (-6615.97705078125, 29.906982421875)
	    reroute_005_1.location = (-6314.58154296875, -10.279083251953125)
	    capture_attribute_001_1.location = (-6194.0234375, -130.83721923828125)
	    curve_to_points.location = (-5993.09326171875, -30.372100830078125)
	    index_001_2.location = (-6354.767578125, -251.39535522460938)
	    reroute_014_2.location = (840.55810546875, -42.93023681640625)
	    reroute_027.location = (-3569.653076171875, -70.55813598632812)
	    reroute_007_1.location = (-5731.8837890625, -70.55813598632812)
	    reroute_004_2.location = (36.837158203125, -103.20928955078125)
	    curve_to_points_001.location = (471.8369140625, -150.93023681640625)
	    group_input_004_1.location = (29.79052734375, -171.02325439453125)
	    mesh_to_points.location = (471.8369140625, -30.37213134765625)
	    separate_components_1.location = (230.720703125, -90.65118408203125)
	    join_geometry_1.location = (672.76708984375, -70.55816650390625)
	    domain_size.location = (30.1181640625, -90.7225341796875)
	    compare_003_1.location = (210.95556640625, -30.4434814453125)
	    group_input_008.location = (189.92529296875, -287.049072265625)
	    reroute_020_1.location = (485.04736328125, -349.79913330078125)
	    sample_nearest_002.location = (538.25634765625, -402.8079833984375)
	    sample_index_004.location = (734.494140625, -334.037353515625)
	    group_input_009.location = (314.60791015625, -393.1461181640625)
	    math_003.location = (1081.48779296875, -221.0648193359375)
	    capture_attribute_005.location = (912.37890625, -165.49237060546875)
	    capture_attribute_004.location = (384.76708984375, -191.9534912109375)
	    switch_003_2.location = (625.88330078125, -91.4884033203125)
	    reroute_024.location = (533.23828125, -70.5177001953125)
	    reroute_028.location = (-4506.20947265625, -70.55813598632812)
	    compare_002_1.location = (611.65087890625, -289.98358154296875)
	    boolean_math_1.location = (792.48828125, -289.98358154296875)
	    random_value_001_1.location = (430.813720703125, -310.07659912109375)
	    switch_2.location = (29.791015625, -30.372100830078125)
	    delete_geometry_002.location = (1013.511474609375, -109.14642333984375)
	    reroute_008_1.location = (-1994.58154296875, -613.0697631835938)
	    position.location = (205.34033203125, -287.45654296875)
	    vector_math_002_1.location = (381.1435546875, -250.683349609375)
	    vector_math_001_2.location = (30.32568359375, -238.728759765625)
	    set_position_001_2.location = (381.103759765625, -140.3369140625)
	    reroute_010.location = (321.3330078125, -150.626953125)
	    sample_nearest_007.location = (381.612060546875, -50.161865234375)
	    switch_001_3.location = (723.193359375, -30.06884765625)
	    group_input_007_1.location = (30.44677734375, -29.94384765625)
	    math_2.location = (392.12109375, -50.036865234375)
	    math_001.location = (392.12109375, -90.22296142578125)
	    evaluate_at_index_2.location = (211.283935546875, -50.036865234375)
	    accumulate_field_001.location = (392.12109375, -130.40899658203125)
	    sample_index_003.location = (392.12109375, -170.59503173828125)
	    sample_nearest_001.location = (197.581298828125, -303.9206848144531)
	    index_2.location = (650.3250732421875, -439.4784851074219)
	    sample_index.location = (649.583984375, -300.76971435546875)
	    sample_index_002.location = (378.41845703125, -203.45556640625)
	    reroute_018_2.location = (619.5347900390625, -103.20928955078125)
	    sample_nearest_005.location = (550.88134765625, -166.8988037109375)
	    compare_1.location = (392.12109375, -210.78106689453125)
	    capture_attribute_002_1.location = (-723.348876953125, 20.0930233001709)
	    compare_001.location = (-723.348876953125, -180.83721923828125)
	    index_002_1.location = (-904.1860961914062, -180.83721923828125)
	    reroute_011_1.location = (-884.093017578125, -120.55814361572266)
	    reroute_012_2.location = (-884.093017578125, -80.3720932006836)
	    join_geometry_001_1.location = (-20.0930233001709, 100.46511840820312)
	    reroute_003_1.location = (-180.83721923828125, -180.83721923828125)
	    reroute_002_1.location = (-180.83721923828125, -140.6511688232422)
	    reroute_009_1.location = (-281.3023376464844, -20.0930233001709)
	    group_output_6.location = (200.93023681640625, 40.1860466003418)
	    reroute_006_1.location = (-522.4186401367188, -60.27907180786133)
	    capture_attribute_1.location = (1021.9339599609375, -30.270050048828125)
	    separate_geometry.location = (-241.1162872314453, -40.1860466003418)
	    sample_index_001.location = (849.4586181640625, -207.85162353515625)
	    store_named_attribute_1.location = (-1063.311279296875, 23.636491775512695)
	
	    #Set dimensions
	    frame_003_1.width, frame_003_1.height = 1191.8836669921875, 519.906982421875
	    frame_004_1.width, frame_004_1.height = 1183.999755859375, 512.4486694335938
	    frame_006.width, frame_006.height = 843.25537109375, 311.4418640136719
	    frame_3.width, frame_3.height = 1251.81396484375, 529.9534912109375
	    frame_007.width, frame_007.height = 200.279296875, 182.51162719726562
	    frame_002_2.width, frame_002_2.height = 893.48828125, 457.9534606933594
	    frame_005.width, frame_005.height = 561.953369140625, 266.23260498046875
	    reroute_019_1.width, reroute_019_1.height = 100.0, 100.0
	    reroute_021.width, reroute_021.height = 100.0, 100.0
	    reroute_022.width, reroute_022.height = 100.0, 100.0
	    reroute_023.width, reroute_023.height = 100.0, 100.0
	    reroute_001_2.width, reroute_001_2.height = 100.0, 100.0
	    reroute_2.width, reroute_2.height = 100.0, 100.0
	    set_position_002_1.width, set_position_002_1.height = 140.0, 100.0
	    switch_002_1.width, switch_002_1.height = 140.0, 100.0
	    set_position_1.width, set_position_1.height = 140.0, 100.0
	    vector_math_003_1.width, vector_math_003_1.height = 140.0, 100.0
	    vector_math_004_2.width, vector_math_004_2.height = 140.0, 100.0
	    merge_by_distance.width, merge_by_distance.height = 140.0, 100.0
	    merge_by_distance_001.width, merge_by_distance_001.height = 140.0, 100.0
	    group_input_001_2.width, group_input_001_2.height = 140.0, 100.0
	    reroute_026.width, reroute_026.height = 100.0, 100.0
	    compare_004_1.width, compare_004_1.height = 140.0, 100.0
	    reroute_015_2.width, reroute_015_2.height = 100.0, 100.0
	    reroute_016_2.width, reroute_016_2.height = 100.0, 100.0
	    reroute_013_2.width, reroute_013_2.height = 100.0, 100.0
	    reroute_017_2.width, reroute_017_2.height = 100.0, 100.0
	    group_input_2.width, group_input_2.height = 140.0, 100.0
	    separate_components_001.width, separate_components_001.height = 140.0, 100.0
	    group_input_003_2.width, group_input_003_2.height = 140.0, 100.0
	    capture_attribute_003.width, capture_attribute_003.height = 140.0, 100.0
	    group_input_010.width, group_input_010.height = 140.0, 100.0
	    capture_attribute_006.width, capture_attribute_006.height = 140.0, 100.0
	    reroute_005_1.width, reroute_005_1.height = 100.0, 100.0
	    capture_attribute_001_1.width, capture_attribute_001_1.height = 140.0, 100.0
	    curve_to_points.width, curve_to_points.height = 140.0, 100.0
	    index_001_2.width, index_001_2.height = 140.0, 100.0
	    reroute_014_2.width, reroute_014_2.height = 100.0, 100.0
	    reroute_027.width, reroute_027.height = 100.0, 100.0
	    reroute_007_1.width, reroute_007_1.height = 100.0, 100.0
	    reroute_004_2.width, reroute_004_2.height = 100.0, 100.0
	    curve_to_points_001.width, curve_to_points_001.height = 140.0, 100.0
	    group_input_004_1.width, group_input_004_1.height = 140.0, 100.0
	    mesh_to_points.width, mesh_to_points.height = 140.0, 100.0
	    separate_components_1.width, separate_components_1.height = 140.0, 100.0
	    join_geometry_1.width, join_geometry_1.height = 140.0, 100.0
	    domain_size.width, domain_size.height = 140.0, 100.0
	    compare_003_1.width, compare_003_1.height = 140.0, 100.0
	    group_input_008.width, group_input_008.height = 140.0, 100.0
	    reroute_020_1.width, reroute_020_1.height = 100.0, 100.0
	    sample_nearest_002.width, sample_nearest_002.height = 140.0, 100.0
	    sample_index_004.width, sample_index_004.height = 140.0, 100.0
	    group_input_009.width, group_input_009.height = 140.0, 100.0
	    math_003.width, math_003.height = 140.0, 100.0
	    capture_attribute_005.width, capture_attribute_005.height = 140.0, 100.0
	    capture_attribute_004.width, capture_attribute_004.height = 140.0, 100.0
	    switch_003_2.width, switch_003_2.height = 140.0, 100.0
	    reroute_024.width, reroute_024.height = 100.0, 100.0
	    reroute_028.width, reroute_028.height = 100.0, 100.0
	    compare_002_1.width, compare_002_1.height = 140.0, 100.0
	    boolean_math_1.width, boolean_math_1.height = 140.0, 100.0
	    random_value_001_1.width, random_value_001_1.height = 140.0, 100.0
	    switch_2.width, switch_2.height = 140.0, 100.0
	    delete_geometry_002.width, delete_geometry_002.height = 140.0, 100.0
	    reroute_008_1.width, reroute_008_1.height = 100.0, 100.0
	    position.width, position.height = 140.0, 100.0
	    vector_math_002_1.width, vector_math_002_1.height = 140.0, 100.0
	    vector_math_001_2.width, vector_math_001_2.height = 140.0, 100.0
	    set_position_001_2.width, set_position_001_2.height = 140.0, 100.0
	    reroute_010.width, reroute_010.height = 100.0, 100.0
	    sample_nearest_007.width, sample_nearest_007.height = 140.0, 100.0
	    switch_001_3.width, switch_001_3.height = 140.0, 100.0
	    group_input_007_1.width, group_input_007_1.height = 140.0, 100.0
	    math_2.width, math_2.height = 140.0, 100.0
	    math_001.width, math_001.height = 140.0, 100.0
	    evaluate_at_index_2.width, evaluate_at_index_2.height = 140.0, 100.0
	    accumulate_field_001.width, accumulate_field_001.height = 140.0, 100.0
	    sample_index_003.width, sample_index_003.height = 140.0, 100.0
	    sample_nearest_001.width, sample_nearest_001.height = 140.0, 100.0
	    index_2.width, index_2.height = 140.0, 100.0
	    sample_index.width, sample_index.height = 140.0, 100.0
	    sample_index_002.width, sample_index_002.height = 140.0, 100.0
	    reroute_018_2.width, reroute_018_2.height = 100.0, 100.0
	    sample_nearest_005.width, sample_nearest_005.height = 140.0, 100.0
	    compare_1.width, compare_1.height = 140.0, 100.0
	    capture_attribute_002_1.width, capture_attribute_002_1.height = 140.0, 100.0
	    compare_001.width, compare_001.height = 140.0, 100.0
	    index_002_1.width, index_002_1.height = 140.0, 100.0
	    reroute_011_1.width, reroute_011_1.height = 100.0, 100.0
	    reroute_012_2.width, reroute_012_2.height = 100.0, 100.0
	    join_geometry_001_1.width, join_geometry_001_1.height = 140.0, 100.0
	    reroute_003_1.width, reroute_003_1.height = 100.0, 100.0
	    reroute_002_1.width, reroute_002_1.height = 100.0, 100.0
	    reroute_009_1.width, reroute_009_1.height = 100.0, 100.0
	    group_output_6.width, group_output_6.height = 140.0, 100.0
	    reroute_006_1.width, reroute_006_1.height = 100.0, 100.0
	    capture_attribute_1.width, capture_attribute_1.height = 140.0, 100.0
	    separate_geometry.width, separate_geometry.height = 140.0, 100.0
	    sample_index_001.width, sample_index_001.height = 140.0, 100.0
	    store_named_attribute_1.width, store_named_attribute_1.height = 140.0, 100.0
	
	    #initialize create_guide_index_map_001 links
	    #reroute_002_1.Output -> group_output_6.Guide Index
	    create_guide_index_map_001.links.new(reroute_002_1.outputs[0], group_output_6.inputs[2])
	    #reroute_005_1.Output -> capture_attribute_001_1.Geometry
	    create_guide_index_map_001.links.new(reroute_005_1.outputs[0], capture_attribute_001_1.inputs[0])
	    #reroute_026.Output -> merge_by_distance.Distance
	    create_guide_index_map_001.links.new(reroute_026.outputs[0], merge_by_distance.inputs[2])
	    #reroute_018_2.Output -> sample_index_001.Geometry
	    create_guide_index_map_001.links.new(reroute_018_2.outputs[0], sample_index_001.inputs[0])
	    #sample_index_001.Value -> capture_attribute_1.Value
	    create_guide_index_map_001.links.new(sample_index_001.outputs[0], capture_attribute_1.inputs[1])
	    #reroute_008_1.Output -> sample_index.Geometry
	    create_guide_index_map_001.links.new(reroute_008_1.outputs[0], sample_index.inputs[0])
	    #index_001_2.Index -> capture_attribute_001_1.Value
	    create_guide_index_map_001.links.new(index_001_2.outputs[0], capture_attribute_001_1.inputs[1])
	    #index_2.Index -> sample_index_001.Index
	    create_guide_index_map_001.links.new(index_2.outputs[0], sample_index_001.inputs[2])
	    #reroute_014_2.Output -> capture_attribute_1.Geometry
	    create_guide_index_map_001.links.new(reroute_014_2.outputs[0], capture_attribute_1.inputs[0])
	    #reroute_001_2.Output -> sample_nearest_001.Geometry
	    create_guide_index_map_001.links.new(reroute_001_2.outputs[0], sample_nearest_001.inputs[0])
	    #reroute_001_2.Output -> sample_index_002.Geometry
	    create_guide_index_map_001.links.new(reroute_001_2.outputs[0], sample_index_002.inputs[0])
	    #sample_nearest_001.Index -> sample_index_002.Index
	    create_guide_index_map_001.links.new(sample_nearest_001.outputs[0], sample_index_002.inputs[2])
	    #reroute_011_1.Output -> compare_001.A
	    create_guide_index_map_001.links.new(reroute_011_1.outputs[0], compare_001.inputs[2])
	    #reroute_003_1.Output -> group_output_6.Guide Selection
	    create_guide_index_map_001.links.new(reroute_003_1.outputs[0], group_output_6.inputs[3])
	    #index_002_1.Index -> compare_001.B
	    create_guide_index_map_001.links.new(index_002_1.outputs[0], compare_001.inputs[3])
	    #reroute_011_1.Output -> reroute_002_1.Input
	    create_guide_index_map_001.links.new(reroute_011_1.outputs[0], reroute_002_1.inputs[0])
	    #reroute_006_1.Output -> reroute_003_1.Input
	    create_guide_index_map_001.links.new(reroute_006_1.outputs[0], reroute_003_1.inputs[0])
	    #reroute_027.Output -> reroute_004_2.Input
	    create_guide_index_map_001.links.new(reroute_027.outputs[0], reroute_004_2.inputs[0])
	    #curve_to_points.Points -> reroute_007_1.Input
	    create_guide_index_map_001.links.new(curve_to_points.outputs[0], reroute_007_1.inputs[0])
	    #delete_geometry_002.Geometry -> reroute_008_1.Input
	    create_guide_index_map_001.links.new(delete_geometry_002.outputs[0], reroute_008_1.inputs[0])
	    #capture_attribute_006.Geometry -> reroute_005_1.Input
	    create_guide_index_map_001.links.new(capture_attribute_006.outputs[0], reroute_005_1.inputs[0])
	    #reroute_009_1.Output -> separate_geometry.Geometry
	    create_guide_index_map_001.links.new(reroute_009_1.outputs[0], separate_geometry.inputs[0])
	    #reroute_006_1.Output -> separate_geometry.Selection
	    create_guide_index_map_001.links.new(reroute_006_1.outputs[0], separate_geometry.inputs[1])
	    #separate_geometry.Selection -> group_output_6.Guide Curves
	    create_guide_index_map_001.links.new(separate_geometry.outputs[0], group_output_6.inputs[1])
	    #capture_attribute_002_1.Geometry -> reroute_009_1.Input
	    create_guide_index_map_001.links.new(capture_attribute_002_1.outputs[0], reroute_009_1.inputs[0])
	    #reroute_012_2.Output -> capture_attribute_002_1.Geometry
	    create_guide_index_map_001.links.new(reroute_012_2.outputs[0], capture_attribute_002_1.inputs[0])
	    #compare_001.Result -> capture_attribute_002_1.Value
	    create_guide_index_map_001.links.new(compare_001.outputs[0], capture_attribute_002_1.inputs[1])
	    #capture_attribute_002_1.Value -> reroute_006_1.Input
	    create_guide_index_map_001.links.new(capture_attribute_002_1.outputs[1], reroute_006_1.inputs[0])
	    #random_value_001_1.Value -> compare_002_1.A
	    create_guide_index_map_001.links.new(random_value_001_1.outputs[1], compare_002_1.inputs[0])
	    #compare_002_1.Result -> boolean_math_1.Boolean
	    create_guide_index_map_001.links.new(compare_002_1.outputs[0], boolean_math_1.inputs[0])
	    #switch_002_1.Output -> delete_geometry_002.Geometry
	    create_guide_index_map_001.links.new(switch_002_1.outputs[0], delete_geometry_002.inputs[0])
	    #boolean_math_1.Boolean -> delete_geometry_002.Selection
	    create_guide_index_map_001.links.new(boolean_math_1.outputs[0], delete_geometry_002.inputs[1])
	    #group_input_003_2.Guide Mask -> capture_attribute_003.Value
	    create_guide_index_map_001.links.new(group_input_003_2.outputs[3], capture_attribute_003.inputs[1])
	    #reroute_010.Output -> set_position_001_2.Geometry
	    create_guide_index_map_001.links.new(reroute_010.outputs[0], set_position_001_2.inputs[0])
	    #vector_math_001_2.Vector -> set_position_001_2.Offset
	    create_guide_index_map_001.links.new(vector_math_001_2.outputs[0], set_position_001_2.inputs[3])
	    #set_position_001_2.Geometry -> sample_nearest_005.Geometry
	    create_guide_index_map_001.links.new(set_position_001_2.outputs[0], sample_nearest_005.inputs[0])
	    #reroute_010.Output -> sample_nearest_007.Geometry
	    create_guide_index_map_001.links.new(reroute_010.outputs[0], sample_nearest_007.inputs[0])
	    #vector_math_002_1.Vector -> sample_nearest_005.Sample Position
	    create_guide_index_map_001.links.new(vector_math_002_1.outputs[0], sample_nearest_005.inputs[1])
	    #position.Position -> vector_math_002_1.Vector
	    create_guide_index_map_001.links.new(position.outputs[0], vector_math_002_1.inputs[0])
	    #vector_math_001_2.Vector -> vector_math_002_1.Vector
	    create_guide_index_map_001.links.new(vector_math_001_2.outputs[0], vector_math_002_1.inputs[1])
	    #group_input_004_1.Guides -> separate_components_1.Geometry
	    create_guide_index_map_001.links.new(group_input_004_1.outputs[1], separate_components_1.inputs[0])
	    #separate_components_1.Mesh -> mesh_to_points.Mesh
	    create_guide_index_map_001.links.new(separate_components_1.outputs[0], mesh_to_points.inputs[0])
	    #curve_to_points_001.Points -> join_geometry_1.Geometry
	    create_guide_index_map_001.links.new(curve_to_points_001.outputs[0], join_geometry_1.inputs[0])
	    #capture_attribute_1.Value -> reroute_011_1.Input
	    create_guide_index_map_001.links.new(capture_attribute_1.outputs[1], reroute_011_1.inputs[0])
	    #domain_size.Point Count -> compare_003_1.A
	    create_guide_index_map_001.links.new(domain_size.outputs[0], compare_003_1.inputs[2])
	    #store_named_attribute_1.Geometry -> reroute_012_2.Input
	    create_guide_index_map_001.links.new(store_named_attribute_1.outputs[0], reroute_012_2.inputs[0])
	    #sample_nearest_005.Index -> switch_001_3.True
	    create_guide_index_map_001.links.new(sample_nearest_005.outputs[0], switch_001_3.inputs[2])
	    #sample_nearest_007.Index -> switch_001_3.False
	    create_guide_index_map_001.links.new(sample_nearest_007.outputs[0], switch_001_3.inputs[1])
	    #switch_001_3.Output -> sample_index.Index
	    create_guide_index_map_001.links.new(switch_001_3.outputs[0], sample_index.inputs[2])
	    #reroute_023.Output -> join_geometry_001_1.Geometry
	    create_guide_index_map_001.links.new(reroute_023.outputs[0], join_geometry_001_1.inputs[0])
	    #separate_components_001.Mesh -> reroute_017_2.Input
	    create_guide_index_map_001.links.new(separate_components_001.outputs[0], reroute_017_2.inputs[0])
	    #separate_components_001.Instances -> reroute_013_2.Input
	    create_guide_index_map_001.links.new(separate_components_001.outputs[5], reroute_013_2.inputs[0])
	    #separate_components_001.Point Cloud -> reroute_015_2.Input
	    create_guide_index_map_001.links.new(separate_components_001.outputs[3], reroute_015_2.inputs[0])
	    #separate_components_001.Volume -> reroute_016_2.Input
	    create_guide_index_map_001.links.new(separate_components_001.outputs[4], reroute_016_2.inputs[0])
	    #reroute_017_2.Output -> reroute_019_1.Input
	    create_guide_index_map_001.links.new(reroute_017_2.outputs[0], reroute_019_1.inputs[0])
	    #reroute_015_2.Output -> reroute_021.Input
	    create_guide_index_map_001.links.new(reroute_015_2.outputs[0], reroute_021.inputs[0])
	    #reroute_013_2.Output -> reroute_023.Input
	    create_guide_index_map_001.links.new(reroute_013_2.outputs[0], reroute_023.inputs[0])
	    #reroute_016_2.Output -> reroute_022.Input
	    create_guide_index_map_001.links.new(reroute_016_2.outputs[0], reroute_022.inputs[0])
	    #join_geometry_001_1.Geometry -> group_output_6.Geometry
	    create_guide_index_map_001.links.new(join_geometry_001_1.outputs[0], group_output_6.inputs[0])
	    #separate_components_001.Curve -> capture_attribute_003.Geometry
	    create_guide_index_map_001.links.new(separate_components_001.outputs[1], capture_attribute_003.inputs[0])
	    #group_input_2.Geometry -> separate_components_001.Geometry
	    create_guide_index_map_001.links.new(group_input_2.outputs[0], separate_components_001.inputs[0])
	    #reroute_004_2.Output -> reroute_001_2.Input
	    create_guide_index_map_001.links.new(reroute_004_2.outputs[0], reroute_001_2.inputs[0])
	    #reroute_005_1.Output -> reroute_014_2.Input
	    create_guide_index_map_001.links.new(reroute_005_1.outputs[0], reroute_014_2.inputs[0])
	    #reroute_004_2.Output -> reroute_018_2.Input
	    create_guide_index_map_001.links.new(reroute_004_2.outputs[0], reroute_018_2.inputs[0])
	    #separate_components_1.Curve -> curve_to_points_001.Curve
	    create_guide_index_map_001.links.new(separate_components_1.outputs[1], curve_to_points_001.inputs[0])
	    #capture_attribute_001_1.Geometry -> curve_to_points.Curve
	    create_guide_index_map_001.links.new(capture_attribute_001_1.outputs[0], curve_to_points.inputs[0])
	    #set_position_1.Geometry -> merge_by_distance.Geometry
	    create_guide_index_map_001.links.new(set_position_1.outputs[0], merge_by_distance.inputs[0])
	    #reroute_2.Output -> set_position_1.Geometry
	    create_guide_index_map_001.links.new(reroute_2.outputs[0], set_position_1.inputs[0])
	    #vector_math_003_1.Vector -> set_position_1.Offset
	    create_guide_index_map_001.links.new(vector_math_003_1.outputs[0], set_position_1.inputs[3])
	    #merge_by_distance.Geometry -> set_position_002_1.Geometry
	    create_guide_index_map_001.links.new(merge_by_distance.outputs[0], set_position_002_1.inputs[0])
	    #vector_math_003_1.Vector -> vector_math_004_2.Vector
	    create_guide_index_map_001.links.new(vector_math_003_1.outputs[0], vector_math_004_2.inputs[0])
	    #vector_math_004_2.Vector -> set_position_002_1.Offset
	    create_guide_index_map_001.links.new(vector_math_004_2.outputs[0], set_position_002_1.inputs[3])
	    #group_input_007_1.Group ID -> math_2.Value
	    create_guide_index_map_001.links.new(group_input_007_1.outputs[4], math_2.inputs[0])
	    #group_input_007_1.Group ID -> evaluate_at_index_2.Value
	    create_guide_index_map_001.links.new(group_input_007_1.outputs[4], evaluate_at_index_2.inputs[1])
	    #reroute_027.Output -> sample_index_003.Geometry
	    create_guide_index_map_001.links.new(reroute_027.outputs[0], sample_index_003.inputs[0])
	    #evaluate_at_index_2.Value -> math_2.Value
	    create_guide_index_map_001.links.new(evaluate_at_index_2.outputs[0], math_2.inputs[1])
	    #accumulate_field_001.Total -> sample_index_003.Value
	    create_guide_index_map_001.links.new(accumulate_field_001.outputs[2], sample_index_003.inputs[1])
	    #math_2.Value -> math_001.Value
	    create_guide_index_map_001.links.new(math_2.outputs[0], math_001.inputs[0])
	    #sample_index_003.Value -> compare_1.A
	    create_guide_index_map_001.links.new(sample_index_003.outputs[0], compare_1.inputs[2])
	    #compare_1.Result -> switch_001_3.Switch
	    create_guide_index_map_001.links.new(compare_1.outputs[0], switch_001_3.inputs[0])
	    #set_position_002_1.Geometry -> switch_002_1.True
	    create_guide_index_map_001.links.new(set_position_002_1.outputs[0], switch_002_1.inputs[2])
	    #compare_1.Result -> switch_002_1.Switch
	    create_guide_index_map_001.links.new(compare_1.outputs[0], switch_002_1.inputs[0])
	    #reroute_2.Output -> merge_by_distance_001.Geometry
	    create_guide_index_map_001.links.new(reroute_2.outputs[0], merge_by_distance_001.inputs[0])
	    #switch_2.Output -> reroute_2.Input
	    create_guide_index_map_001.links.new(switch_2.outputs[0], reroute_2.inputs[0])
	    #merge_by_distance_001.Geometry -> switch_002_1.False
	    create_guide_index_map_001.links.new(merge_by_distance_001.outputs[0], switch_002_1.inputs[1])
	    #reroute_026.Output -> merge_by_distance_001.Distance
	    create_guide_index_map_001.links.new(reroute_026.outputs[0], merge_by_distance_001.inputs[2])
	    #sample_index.Value -> sample_index_001.Value
	    create_guide_index_map_001.links.new(sample_index.outputs[0], sample_index_001.inputs[1])
	    #capture_attribute_001_1.Value -> sample_index_002.Value
	    create_guide_index_map_001.links.new(capture_attribute_001_1.outputs[1], sample_index_002.inputs[1])
	    #sample_index_002.Value -> sample_index.Value
	    create_guide_index_map_001.links.new(sample_index_002.outputs[0], sample_index.inputs[1])
	    #delete_geometry_002.Geometry -> reroute_010.Input
	    create_guide_index_map_001.links.new(delete_geometry_002.outputs[0], reroute_010.inputs[0])
	    #join_geometry_1.Geometry -> domain_size.Geometry
	    create_guide_index_map_001.links.new(join_geometry_1.outputs[0], domain_size.inputs[0])
	    #join_geometry_1.Geometry -> capture_attribute_004.Geometry
	    create_guide_index_map_001.links.new(join_geometry_1.outputs[0], capture_attribute_004.inputs[0])
	    #capture_attribute_003.Value -> switch_003_2.False
	    create_guide_index_map_001.links.new(capture_attribute_003.outputs[1], switch_003_2.inputs[1])
	    #capture_attribute_004.Value -> switch_003_2.True
	    create_guide_index_map_001.links.new(capture_attribute_004.outputs[1], switch_003_2.inputs[2])
	    #switch_003_2.Output -> compare_002_1.B
	    create_guide_index_map_001.links.new(switch_003_2.outputs[0], compare_002_1.inputs[1])
	    #reroute_024.Output -> switch_003_2.Switch
	    create_guide_index_map_001.links.new(reroute_024.outputs[0], switch_003_2.inputs[0])
	    #compare_003_1.Result -> reroute_024.Input
	    create_guide_index_map_001.links.new(compare_003_1.outputs[0], reroute_024.inputs[0])
	    #group_input_008.Guide Mask -> capture_attribute_004.Value
	    create_guide_index_map_001.links.new(group_input_008.outputs[3], capture_attribute_004.inputs[1])
	    #group_input_001_2.Guide Distance -> compare_004_1.A
	    create_guide_index_map_001.links.new(group_input_001_2.outputs[2], compare_004_1.inputs[0])
	    #compare_004_1.Result -> merge_by_distance.Selection
	    create_guide_index_map_001.links.new(compare_004_1.outputs[0], merge_by_distance.inputs[1])
	    #compare_004_1.Result -> merge_by_distance_001.Selection
	    create_guide_index_map_001.links.new(compare_004_1.outputs[0], merge_by_distance_001.inputs[1])
	    #group_input_001_2.Guide Distance -> reroute_026.Input
	    create_guide_index_map_001.links.new(group_input_001_2.outputs[2], reroute_026.inputs[0])
	    #reroute_020_1.Output -> sample_nearest_002.Geometry
	    create_guide_index_map_001.links.new(reroute_020_1.outputs[0], sample_nearest_002.inputs[0])
	    #reroute_007_1.Output -> reroute_020_1.Input
	    create_guide_index_map_001.links.new(reroute_007_1.outputs[0], reroute_020_1.inputs[0])
	    #reroute_020_1.Output -> sample_index_004.Geometry
	    create_guide_index_map_001.links.new(reroute_020_1.outputs[0], sample_index_004.inputs[0])
	    #sample_nearest_002.Index -> sample_index_004.Index
	    create_guide_index_map_001.links.new(sample_nearest_002.outputs[0], sample_index_004.inputs[2])
	    #group_input_009.Group ID -> sample_index_004.Value
	    create_guide_index_map_001.links.new(group_input_009.outputs[4], sample_index_004.inputs[1])
	    #capture_attribute_004.Geometry -> capture_attribute_005.Geometry
	    create_guide_index_map_001.links.new(capture_attribute_004.outputs[0], capture_attribute_005.inputs[0])
	    #sample_index_004.Value -> capture_attribute_005.Value
	    create_guide_index_map_001.links.new(sample_index_004.outputs[0], capture_attribute_005.inputs[1])
	    #capture_attribute_003.Geometry -> capture_attribute_006.Geometry
	    create_guide_index_map_001.links.new(capture_attribute_003.outputs[0], capture_attribute_006.inputs[0])
	    #group_input_010.Group ID -> capture_attribute_006.Value
	    create_guide_index_map_001.links.new(group_input_010.outputs[4], capture_attribute_006.inputs[1])
	    #capture_attribute_005.Value -> math_003.Value
	    create_guide_index_map_001.links.new(capture_attribute_005.outputs[1], math_003.inputs[0])
	    #capture_attribute_006.Value -> math_003.Value
	    create_guide_index_map_001.links.new(capture_attribute_006.outputs[1], math_003.inputs[1])
	    #math_003.Value -> vector_math_003_1.Scale
	    create_guide_index_map_001.links.new(math_003.outputs[0], vector_math_003_1.inputs[3])
	    #math_003.Value -> vector_math_001_2.Scale
	    create_guide_index_map_001.links.new(math_003.outputs[0], vector_math_001_2.inputs[3])
	    #reroute_028.Output -> switch_2.False
	    create_guide_index_map_001.links.new(reroute_028.outputs[0], switch_2.inputs[1])
	    #reroute_024.Output -> switch_2.Switch
	    create_guide_index_map_001.links.new(reroute_024.outputs[0], switch_2.inputs[0])
	    #capture_attribute_005.Geometry -> switch_2.True
	    create_guide_index_map_001.links.new(capture_attribute_005.outputs[0], switch_2.inputs[2])
	    #reroute_028.Output -> reroute_027.Input
	    create_guide_index_map_001.links.new(reroute_028.outputs[0], reroute_027.inputs[0])
	    #reroute_007_1.Output -> reroute_028.Input
	    create_guide_index_map_001.links.new(reroute_007_1.outputs[0], reroute_028.inputs[0])
	    #capture_attribute_1.Geometry -> store_named_attribute_1.Geometry
	    create_guide_index_map_001.links.new(capture_attribute_1.outputs[0], store_named_attribute_1.inputs[0])
	    #capture_attribute_1.Value -> store_named_attribute_1.Value
	    create_guide_index_map_001.links.new(capture_attribute_1.outputs[1], store_named_attribute_1.inputs[3])
	    #separate_components_1.Point Cloud -> join_geometry_1.Geometry
	    create_guide_index_map_001.links.new(separate_components_1.outputs[3], join_geometry_1.inputs[0])
	    #reroute_022.Output -> join_geometry_001_1.Geometry
	    create_guide_index_map_001.links.new(reroute_022.outputs[0], join_geometry_001_1.inputs[0])
	    #mesh_to_points.Points -> join_geometry_1.Geometry
	    create_guide_index_map_001.links.new(mesh_to_points.outputs[0], join_geometry_1.inputs[0])
	    #reroute_009_1.Output -> join_geometry_001_1.Geometry
	    create_guide_index_map_001.links.new(reroute_009_1.outputs[0], join_geometry_001_1.inputs[0])
	    #reroute_021.Output -> join_geometry_001_1.Geometry
	    create_guide_index_map_001.links.new(reroute_021.outputs[0], join_geometry_001_1.inputs[0])
	    #reroute_019_1.Output -> join_geometry_001_1.Geometry
	    create_guide_index_map_001.links.new(reroute_019_1.outputs[0], join_geometry_001_1.inputs[0])
	    return create_guide_index_map_001
	
	create_guide_index_map_001 = create_guide_index_map_001_node_group()
	
	#initialize shape_range_004 node group
	def shape_range_004_node_group():
	    shape_range_004 = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "shape_range.004")
	
	    shape_range_004.color_tag = 'NONE'
	    shape_range_004.description = ""
	    shape_range_004.default_group_node_width = 140
	    
	
	
	    #shape_range_004 interface
	    #Socket Value
	    value_socket = shape_range_004.interface.new_socket(name = "Value", in_out='OUTPUT', socket_type = 'NodeSocketFloat')
	    value_socket.default_value = 0.0
	    value_socket.min_value = -3.4028234663852886e+38
	    value_socket.max_value = 3.4028234663852886e+38
	    value_socket.subtype = 'NONE'
	    value_socket.attribute_domain = 'POINT'
	
	    #Socket Value
	    value_socket_1 = shape_range_004.interface.new_socket(name = "Value", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    value_socket_1.default_value = 0.0
	    value_socket_1.min_value = 0.0
	    value_socket_1.max_value = 1.0
	    value_socket_1.subtype = 'NONE'
	    value_socket_1.attribute_domain = 'POINT'
	    value_socket_1.hide_value = True
	
	    #Socket Min
	    min_socket = shape_range_004.interface.new_socket(name = "Min", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    min_socket.default_value = 0.0
	    min_socket.min_value = -10000.0
	    min_socket.max_value = 10000.0
	    min_socket.subtype = 'NONE'
	    min_socket.attribute_domain = 'POINT'
	    min_socket.description = "rdghrhd"
	
	    #Socket Max
	    max_socket = shape_range_004.interface.new_socket(name = "Max", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    max_socket.default_value = 1.0
	    max_socket.min_value = -10000.0
	    max_socket.max_value = 10000.0
	    max_socket.subtype = 'NONE'
	    max_socket.attribute_domain = 'POINT'
	
	    #Socket Shape
	    shape_socket = shape_range_004.interface.new_socket(name = "Shape", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    shape_socket.default_value = 0.0
	    shape_socket.min_value = -1.0
	    shape_socket.max_value = 1.0
	    shape_socket.subtype = 'NONE'
	    shape_socket.attribute_domain = 'POINT'
	
	    #Socket Base
	    base_socket = shape_range_004.interface.new_socket(name = "Base", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    base_socket.default_value = 2.0
	    base_socket.min_value = 1.0
	    base_socket.max_value = 10000.0
	    base_socket.subtype = 'NONE'
	    base_socket.attribute_domain = 'POINT'
	
	
	    #initialize shape_range_004 nodes
	    #node Switch.001
	    switch_001_4 = shape_range_004.nodes.new("GeometryNodeSwitch")
	    switch_001_4.name = "Switch.001"
	    switch_001_4.hide = True
	    switch_001_4.input_type = 'FLOAT'
	
	    #node Math.016
	    math_016 = shape_range_004.nodes.new("ShaderNodeMath")
	    math_016.name = "Math.016"
	    math_016.hide = True
	    math_016.operation = 'SUBTRACT'
	    math_016.use_clamp = False
	    #Value
	    math_016.inputs[0].default_value = 1.0
	
	    #node Math.004
	    math_004 = shape_range_004.nodes.new("ShaderNodeMath")
	    math_004.name = "Math.004"
	    math_004.hide = True
	    math_004.operation = 'SUBTRACT'
	    math_004.use_clamp = False
	    #Value
	    math_004.inputs[0].default_value = 1.0
	
	    #node Reroute
	    reroute_3 = shape_range_004.nodes.new("NodeReroute")
	    reroute_3.name = "Reroute"
	    reroute_3.socket_idname = "NodeSocketFloat"
	    #node Map Range
	    map_range = shape_range_004.nodes.new("ShaderNodeMapRange")
	    map_range.name = "Map Range"
	    map_range.hide = True
	    map_range.clamp = False
	    map_range.data_type = 'FLOAT'
	    map_range.interpolation_type = 'LINEAR'
	    map_range.inputs[3].hide = True
	    map_range.inputs[4].hide = True
	    map_range.inputs[5].hide = True
	    map_range.inputs[6].hide = True
	    map_range.inputs[7].hide = True
	    map_range.inputs[8].hide = True
	    map_range.inputs[9].hide = True
	    map_range.inputs[10].hide = True
	    map_range.inputs[11].hide = True
	    map_range.outputs[1].hide = True
	    #To Min
	    map_range.inputs[3].default_value = 0.0
	    #To Max
	    map_range.inputs[4].default_value = 1.0
	
	    #node Math.001
	    math_001_1 = shape_range_004.nodes.new("ShaderNodeMath")
	    math_001_1.name = "Math.001"
	    math_001_1.hide = True
	    math_001_1.operation = 'DIVIDE'
	    math_001_1.use_clamp = False
	    #Value
	    math_001_1.inputs[0].default_value = 1.0
	
	    #node Math.012
	    math_012 = shape_range_004.nodes.new("ShaderNodeMath")
	    math_012.name = "Math.012"
	    math_012.hide = True
	    math_012.operation = 'SUBTRACT'
	    math_012.use_clamp = False
	    #Value
	    math_012.inputs[0].default_value = 1.0
	
	    #node Math.013
	    math_013 = shape_range_004.nodes.new("ShaderNodeMath")
	    math_013.name = "Math.013"
	    math_013.hide = True
	    math_013.operation = 'MULTIPLY'
	    math_013.use_clamp = False
	    #Value_001
	    math_013.inputs[1].default_value = 2.0
	
	    #node Math
	    math_3 = shape_range_004.nodes.new("ShaderNodeMath")
	    math_3.name = "Math"
	    math_3.hide = True
	    math_3.operation = 'MULTIPLY'
	    math_3.use_clamp = False
	
	    #node Reroute.001
	    reroute_001_3 = shape_range_004.nodes.new("NodeReroute")
	    reroute_001_3.name = "Reroute.001"
	    reroute_001_3.socket_idname = "NodeSocketFloat"
	    #node Compare.004
	    compare_004_2 = shape_range_004.nodes.new("FunctionNodeCompare")
	    compare_004_2.name = "Compare.004"
	    compare_004_2.hide = True
	    compare_004_2.data_type = 'FLOAT'
	    compare_004_2.mode = 'ELEMENT'
	    compare_004_2.operation = 'LESS_THAN'
	    #B
	    compare_004_2.inputs[1].default_value = 0.0
	
	    #node Compare
	    compare_2 = shape_range_004.nodes.new("FunctionNodeCompare")
	    compare_2.name = "Compare"
	    compare_2.hide = True
	    compare_2.data_type = 'FLOAT'
	    compare_2.mode = 'ELEMENT'
	    compare_2.operation = 'GREATER_THAN'
	    #B
	    compare_2.inputs[1].default_value = 0.5
	
	    #node Boolean Math.002
	    boolean_math_002_1 = shape_range_004.nodes.new("FunctionNodeBooleanMath")
	    boolean_math_002_1.name = "Boolean Math.002"
	    boolean_math_002_1.hide = True
	    boolean_math_002_1.operation = 'NOT'
	
	    #node Switch
	    switch_3 = shape_range_004.nodes.new("GeometryNodeSwitch")
	    switch_3.name = "Switch"
	    switch_3.hide = True
	    switch_3.input_type = 'BOOLEAN'
	
	    #node Math.014
	    math_014 = shape_range_004.nodes.new("ShaderNodeMath")
	    math_014.name = "Math.014"
	    math_014.hide = True
	    math_014.operation = 'MAXIMUM'
	    math_014.use_clamp = False
	    #Value_001
	    math_014.inputs[1].default_value = 1.0000100135803223
	
	    #node Math.006
	    math_006 = shape_range_004.nodes.new("ShaderNodeMath")
	    math_006.name = "Math.006"
	    math_006.hide = True
	    math_006.operation = 'MULTIPLY'
	    math_006.use_clamp = False
	    #Value_001
	    math_006.inputs[1].default_value = -1.0
	
	    #node Math.007
	    math_007 = shape_range_004.nodes.new("ShaderNodeMath")
	    math_007.name = "Math.007"
	    math_007.hide = True
	    math_007.operation = 'SUBTRACT'
	    math_007.use_clamp = False
	    #Value
	    math_007.inputs[0].default_value = 1.0
	
	    #node Math.010
	    math_010 = shape_range_004.nodes.new("ShaderNodeMath")
	    math_010.name = "Math.010"
	    math_010.hide = True
	    math_010.operation = 'MAXIMUM'
	    math_010.use_clamp = False
	    #Value_001
	    math_010.inputs[1].default_value = 1.0000009536743164
	
	    #node Math.009
	    math_009 = shape_range_004.nodes.new("ShaderNodeMath")
	    math_009.name = "Math.009"
	    math_009.hide = True
	    math_009.operation = 'MAXIMUM'
	    math_009.use_clamp = False
	    #Value_001
	    math_009.inputs[1].default_value = 9.999999747378752e-06
	
	    #node Math.002
	    math_002 = shape_range_004.nodes.new("ShaderNodeMath")
	    math_002.name = "Math.002"
	    math_002.operation = 'POWER'
	    math_002.use_clamp = False
	
	    #node Math.005
	    math_005 = shape_range_004.nodes.new("ShaderNodeMath")
	    math_005.name = "Math.005"
	    math_005.hide = True
	    math_005.operation = 'LOGARITHM'
	    math_005.use_clamp = False
	
	    #node Math.015
	    math_015 = shape_range_004.nodes.new("ShaderNodeMath")
	    math_015.name = "Math.015"
	    math_015.hide = True
	    math_015.operation = 'PINGPONG'
	    math_015.use_clamp = False
	    #Value_001
	    math_015.inputs[1].default_value = 0.5
	
	    #node Math.017
	    math_017 = shape_range_004.nodes.new("ShaderNodeMath")
	    math_017.name = "Math.017"
	    math_017.operation = 'MINIMUM'
	    math_017.use_clamp = False
	    #Value_001
	    math_017.inputs[1].default_value = 0.9999989867210388
	
	    #node Math.003
	    math_003_1 = shape_range_004.nodes.new("ShaderNodeMath")
	    math_003_1.name = "Math.003"
	    math_003_1.operation = 'ABSOLUTE'
	    math_003_1.use_clamp = False
	
	    #node Map Range.001
	    map_range_001 = shape_range_004.nodes.new("ShaderNodeMapRange")
	    map_range_001.name = "Map Range.001"
	    map_range_001.clamp = True
	    map_range_001.data_type = 'FLOAT'
	    map_range_001.interpolation_type = 'LINEAR'
	    map_range_001.inputs[1].hide = True
	    map_range_001.inputs[2].hide = True
	    map_range_001.inputs[5].hide = True
	    map_range_001.inputs[6].hide = True
	    map_range_001.inputs[7].hide = True
	    map_range_001.inputs[8].hide = True
	    map_range_001.inputs[9].hide = True
	    map_range_001.inputs[10].hide = True
	    map_range_001.inputs[11].hide = True
	    map_range_001.outputs[1].hide = True
	    #From Min
	    map_range_001.inputs[1].default_value = 0.0
	    #From Max
	    map_range_001.inputs[2].default_value = 1.0
	
	    #node Group Input
	    group_input_3 = shape_range_004.nodes.new("NodeGroupInput")
	    group_input_3.name = "Group Input"
	
	    #node Group Output
	    group_output_7 = shape_range_004.nodes.new("NodeGroupOutput")
	    group_output_7.name = "Group Output"
	    group_output_7.is_active_output = True
	
	    #node Switch.002
	    switch_002_2 = shape_range_004.nodes.new("GeometryNodeSwitch")
	    switch_002_2.name = "Switch.002"
	    switch_002_2.hide = True
	    switch_002_2.input_type = 'FLOAT'
	
	    #node Switch.003
	    switch_003_3 = shape_range_004.nodes.new("GeometryNodeSwitch")
	    switch_003_3.name = "Switch.003"
	    switch_003_3.input_type = 'FLOAT'
	    #True
	    switch_003_3.inputs[2].default_value = 1.0
	
	    #node Compare.001
	    compare_001_1 = shape_range_004.nodes.new("FunctionNodeCompare")
	    compare_001_1.name = "Compare.001"
	    compare_001_1.data_type = 'FLOAT'
	    compare_001_1.mode = 'ELEMENT'
	    compare_001_1.operation = 'EQUAL'
	    #B
	    compare_001_1.inputs[1].default_value = 0.0
	    #Epsilon
	    compare_001_1.inputs[12].default_value = 9.999999747378752e-06
	
	
	
	
	
	    #Set locations
	    switch_001_4.location = (-1034.40283203125, 93.75666046142578)
	    math_016.location = (-632.5424194335938, 53.57061004638672)
	    math_004.location = (-1295.6121826171875, 133.94271850585938)
	    reroute_3.location = (-1315.7052001953125, 93.75666046142578)
	    map_range.location = (-1516.635498046875, 73.66363525390625)
	    math_001_1.location = (-1858.2169189453125, -147.359619140625)
	    math_012.location = (-1858.2169189453125, -107.17357635498047)
	    math_013.location = (-1858.2169189453125, -66.9875259399414)
	    math_3.location = (-1858.2169189453125, -26.801475524902344)
	    reroute_001_3.location = (-2119.42626953125, -147.359619140625)
	    compare_004_2.location = (-1637.193603515625, -66.9875259399414)
	    compare_2.location = (-1637.193603515625, -107.17357635498047)
	    boolean_math_002_1.location = (-1456.3564453125, -107.17357635498047)
	    switch_3.location = (-1456.3564453125, -66.9875259399414)
	    math_014.location = (-2059.14697265625, -107.17357635498047)
	    math_006.location = (-1034.40283203125, -87.0805435180664)
	    math_007.location = (-1034.40283203125, 33.47759246826172)
	    math_010.location = (-1195.1470947265625, -107.17357635498047)
	    math_009.location = (-1034.40283203125, -6.708457946777344)
	    math_002.location = (-833.47265625, 113.84968566894531)
	    math_005.location = (-1034.40283203125, -46.894508361816406)
	    math_015.location = (-2059.14697265625, -147.359619140625)
	    math_017.location = (-2280.17041015625, -127.26660919189453)
	    math_003_1.location = (-2461.007568359375, -127.26660919189453)
	    map_range_001.location = (-411.5191650390625, 53.57061004638672)
	    group_input_3.location = (-2682.03076171875, 13.384567260742188)
	    group_output_7.location = (75.0, 50.0)
	    switch_002_2.location = (-632.5424194335938, 93.75666046142578)
	    switch_003_3.location = (-164.938232421875, 110.71707153320312)
	    compare_001_1.location = (-828.0901489257812, 397.66241455078125)
	
	    #Set dimensions
	    switch_001_4.width, switch_001_4.height = 140.0, 100.0
	    math_016.width, math_016.height = 140.0, 100.0
	    math_004.width, math_004.height = 140.0, 100.0
	    reroute_3.width, reroute_3.height = 100.0, 100.0
	    map_range.width, map_range.height = 140.0, 100.0
	    math_001_1.width, math_001_1.height = 140.0, 100.0
	    math_012.width, math_012.height = 140.0, 100.0
	    math_013.width, math_013.height = 140.0, 100.0
	    math_3.width, math_3.height = 140.0, 100.0
	    reroute_001_3.width, reroute_001_3.height = 100.0, 100.0
	    compare_004_2.width, compare_004_2.height = 140.0, 100.0
	    compare_2.width, compare_2.height = 140.0, 100.0
	    boolean_math_002_1.width, boolean_math_002_1.height = 140.0, 100.0
	    switch_3.width, switch_3.height = 140.0, 100.0
	    math_014.width, math_014.height = 140.0, 100.0
	    math_006.width, math_006.height = 140.0, 100.0
	    math_007.width, math_007.height = 140.0, 100.0
	    math_010.width, math_010.height = 140.0, 100.0
	    math_009.width, math_009.height = 140.0, 100.0
	    math_002.width, math_002.height = 140.0, 100.0
	    math_005.width, math_005.height = 140.0, 100.0
	    math_015.width, math_015.height = 140.0, 100.0
	    math_017.width, math_017.height = 140.0, 100.0
	    math_003_1.width, math_003_1.height = 140.0, 100.0
	    map_range_001.width, map_range_001.height = 140.0, 100.0
	    group_input_3.width, group_input_3.height = 140.0, 100.0
	    group_output_7.width, group_output_7.height = 140.0, 100.0
	    switch_002_2.width, switch_002_2.height = 140.0, 100.0
	    switch_003_3.width, switch_003_3.height = 140.0, 100.0
	    compare_001_1.width, compare_001_1.height = 140.0, 100.0
	
	    #initialize shape_range_004 links
	    #math_009.Value -> math_005.Value
	    shape_range_004.links.new(math_009.outputs[0], math_005.inputs[0])
	    #math_005.Value -> math_006.Value
	    shape_range_004.links.new(math_005.outputs[0], math_006.inputs[0])
	    #math_004.Value -> switch_001_4.True
	    shape_range_004.links.new(math_004.outputs[0], switch_001_4.inputs[2])
	    #math_3.Value -> math_007.Value
	    shape_range_004.links.new(math_3.outputs[0], math_007.inputs[1])
	    #switch_001_4.Output -> math_002.Value
	    shape_range_004.links.new(switch_001_4.outputs[0], math_002.inputs[0])
	    #reroute_3.Output -> math_004.Value
	    shape_range_004.links.new(reroute_3.outputs[0], math_004.inputs[1])
	    #math_006.Value -> math_002.Value
	    shape_range_004.links.new(math_006.outputs[0], math_002.inputs[1])
	    #reroute_3.Output -> switch_001_4.False
	    shape_range_004.links.new(reroute_3.outputs[0], switch_001_4.inputs[1])
	    #math_010.Value -> math_005.Value
	    shape_range_004.links.new(math_010.outputs[0], math_005.inputs[1])
	    #map_range.Result -> reroute_3.Input
	    shape_range_004.links.new(map_range.outputs[0], reroute_3.inputs[0])
	    #group_input_3.Value -> map_range.Value
	    shape_range_004.links.new(group_input_3.outputs[0], map_range.inputs[0])
	    #group_input_3.Min -> map_range.From Min
	    shape_range_004.links.new(group_input_3.outputs[1], map_range.inputs[1])
	    #group_input_3.Max -> map_range.From Max
	    shape_range_004.links.new(group_input_3.outputs[2], map_range.inputs[2])
	    #switch_002_2.Output -> map_range_001.Value
	    shape_range_004.links.new(switch_002_2.outputs[0], map_range_001.inputs[0])
	    #group_input_3.Min -> map_range_001.To Min
	    shape_range_004.links.new(group_input_3.outputs[1], map_range_001.inputs[3])
	    #group_input_3.Max -> map_range_001.To Max
	    shape_range_004.links.new(group_input_3.outputs[2], map_range_001.inputs[4])
	    #math_007.Value -> math_009.Value
	    shape_range_004.links.new(math_007.outputs[0], math_009.inputs[0])
	    #math_014.Value -> math_010.Value
	    shape_range_004.links.new(math_014.outputs[0], math_010.inputs[0])
	    #switch_003_3.Output -> group_output_7.Value
	    shape_range_004.links.new(switch_003_3.outputs[0], group_output_7.inputs[0])
	    #math_013.Value -> math_3.Value
	    shape_range_004.links.new(math_013.outputs[0], math_3.inputs[1])
	    #math_001_1.Value -> math_012.Value
	    shape_range_004.links.new(math_001_1.outputs[0], math_012.inputs[1])
	    #math_014.Value -> math_001_1.Value
	    shape_range_004.links.new(math_014.outputs[0], math_001_1.inputs[1])
	    #math_012.Value -> math_013.Value
	    shape_range_004.links.new(math_012.outputs[0], math_013.inputs[0])
	    #group_input_3.Base -> math_014.Value
	    shape_range_004.links.new(group_input_3.outputs[4], math_014.inputs[0])
	    #math_015.Value -> math_3.Value
	    shape_range_004.links.new(math_015.outputs[0], math_3.inputs[0])
	    #reroute_001_3.Output -> math_015.Value
	    shape_range_004.links.new(reroute_001_3.outputs[0], math_015.inputs[0])
	    #switch_3.Output -> switch_001_4.Switch
	    shape_range_004.links.new(switch_3.outputs[0], switch_001_4.inputs[0])
	    #reroute_001_3.Output -> compare_2.A
	    shape_range_004.links.new(reroute_001_3.outputs[0], compare_2.inputs[0])
	    #math_002.Value -> switch_002_2.False
	    shape_range_004.links.new(math_002.outputs[0], switch_002_2.inputs[1])
	    #math_016.Value -> switch_002_2.True
	    shape_range_004.links.new(math_016.outputs[0], switch_002_2.inputs[2])
	    #compare_2.Result -> switch_002_2.Switch
	    shape_range_004.links.new(compare_2.outputs[0], switch_002_2.inputs[0])
	    #math_002.Value -> math_016.Value
	    shape_range_004.links.new(math_002.outputs[0], math_016.inputs[1])
	    #group_input_3.Shape -> compare_004_2.A
	    shape_range_004.links.new(group_input_3.outputs[3], compare_004_2.inputs[0])
	    #math_017.Value -> reroute_001_3.Input
	    shape_range_004.links.new(math_017.outputs[0], reroute_001_3.inputs[0])
	    #group_input_3.Shape -> math_003_1.Value
	    shape_range_004.links.new(group_input_3.outputs[3], math_003_1.inputs[0])
	    #compare_004_2.Result -> boolean_math_002_1.Boolean
	    shape_range_004.links.new(compare_004_2.outputs[0], boolean_math_002_1.inputs[0])
	    #compare_2.Result -> switch_3.Switch
	    shape_range_004.links.new(compare_2.outputs[0], switch_3.inputs[0])
	    #compare_004_2.Result -> switch_3.False
	    shape_range_004.links.new(compare_004_2.outputs[0], switch_3.inputs[1])
	    #boolean_math_002_1.Boolean -> switch_3.True
	    shape_range_004.links.new(boolean_math_002_1.outputs[0], switch_3.inputs[2])
	    #math_003_1.Value -> math_017.Value
	    shape_range_004.links.new(math_003_1.outputs[0], math_017.inputs[0])
	    #group_input_3.Shape -> compare_001_1.A
	    shape_range_004.links.new(group_input_3.outputs[3], compare_001_1.inputs[0])
	    #map_range_001.Result -> switch_003_3.False
	    shape_range_004.links.new(map_range_001.outputs[0], switch_003_3.inputs[1])
	    #compare_001_1.Result -> switch_003_3.Switch
	    shape_range_004.links.new(compare_001_1.outputs[0], switch_003_3.inputs[0])
	    return shape_range_004
	
	shape_range_004 = shape_range_004_node_group()
	
	#initialize clump_hair_curves_001 node group
	def clump_hair_curves_001_node_group():
	    clump_hair_curves_001 = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Clump Hair Curves.001")
	
	    clump_hair_curves_001.color_tag = 'NONE'
	    clump_hair_curves_001.description = "Clumps together existing hair curves using guide curves"
	    clump_hair_curves_001.default_group_node_width = 140
	    
	
	    clump_hair_curves_001.is_modifier = True
	
	    #clump_hair_curves_001 interface
	    #Socket Geometry
	    geometry_socket_4 = clump_hair_curves_001.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_4.attribute_domain = 'POINT'
	
	    #Socket Guide Index
	    guide_index_socket_2 = clump_hair_curves_001.interface.new_socket(name = "Guide Index", in_out='OUTPUT', socket_type = 'NodeSocketInt')
	    guide_index_socket_2.default_value = 0
	    guide_index_socket_2.min_value = -2147483648
	    guide_index_socket_2.max_value = 2147483647
	    guide_index_socket_2.subtype = 'NONE'
	    guide_index_socket_2.attribute_domain = 'CURVE'
	    guide_index_socket_2.description = "Guide index map that was used for the operation"
	
	    #Socket Geometry
	    geometry_socket_5 = clump_hair_curves_001.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_5.attribute_domain = 'POINT'
	    geometry_socket_5.description = "Input Geometry (May include other than curves)"
	
	    #Socket Guide Index
	    guide_index_socket_3 = clump_hair_curves_001.interface.new_socket(name = "Guide Index", in_out='INPUT', socket_type = 'NodeSocketInt')
	    guide_index_socket_3.default_value = -987654
	    guide_index_socket_3.min_value = -2147483648
	    guide_index_socket_3.max_value = 2147483647
	    guide_index_socket_3.subtype = 'NONE'
	    guide_index_socket_3.attribute_domain = 'POINT'
	    guide_index_socket_3.hide_value = True
	    guide_index_socket_3.hide_in_modifier = True
	    guide_index_socket_3.description = "Guide index map to be used. This input has priority"
	
	    #Socket Guide Distance
	    guide_distance_socket_1 = clump_hair_curves_001.interface.new_socket(name = "Guide Distance", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    guide_distance_socket_1.default_value = 0.10000000149011612
	    guide_distance_socket_1.min_value = 0.0
	    guide_distance_socket_1.max_value = 3.4028234663852886e+38
	    guide_distance_socket_1.subtype = 'DISTANCE'
	    guide_distance_socket_1.attribute_domain = 'POINT'
	    guide_distance_socket_1.description = "Minimum distance between two guides for new guide map"
	
	    #Socket Guide Mask
	    guide_mask_socket_1 = clump_hair_curves_001.interface.new_socket(name = "Guide Mask", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    guide_mask_socket_1.default_value = 1.0
	    guide_mask_socket_1.min_value = 0.0
	    guide_mask_socket_1.max_value = 1.0
	    guide_mask_socket_1.subtype = 'NONE'
	    guide_mask_socket_1.attribute_domain = 'POINT'
	    guide_mask_socket_1.description = "Mask for which curves are eligible to be selected as guides"
	
	    #Socket Existing Guide Map
	    existing_guide_map_socket = clump_hair_curves_001.interface.new_socket(name = "Existing Guide Map", in_out='INPUT', socket_type = 'NodeSocketBool')
	    existing_guide_map_socket.default_value = True
	    existing_guide_map_socket.attribute_domain = 'POINT'
	    existing_guide_map_socket.description = "Use the existing guide map attribute if available"
	
	    #Socket Factor
	    factor_socket_1 = clump_hair_curves_001.interface.new_socket(name = "Factor", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    factor_socket_1.default_value = 1.0
	    factor_socket_1.min_value = 0.0
	    factor_socket_1.max_value = 1.0
	    factor_socket_1.subtype = 'FACTOR'
	    factor_socket_1.attribute_domain = 'POINT'
	    factor_socket_1.description = "Factor to blend overall effect"
	
	    #Socket Shape
	    shape_socket_1 = clump_hair_curves_001.interface.new_socket(name = "Shape", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    shape_socket_1.default_value = 0.5
	    shape_socket_1.min_value = -1.0
	    shape_socket_1.max_value = 1.0
	    shape_socket_1.subtype = 'NONE'
	    shape_socket_1.attribute_domain = 'POINT'
	    shape_socket_1.description = "Shape of the influence along curves (0=constant, 0.5=linear)"
	
	    #Socket Tip Spread
	    tip_spread_socket = clump_hair_curves_001.interface.new_socket(name = "Tip Spread", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    tip_spread_socket.default_value = 0.0
	    tip_spread_socket.min_value = 0.0
	    tip_spread_socket.max_value = 10.0
	    tip_spread_socket.subtype = 'NONE'
	    tip_spread_socket.attribute_domain = 'POINT'
	    tip_spread_socket.description = "Distance of random spread at the curve tips"
	
	    #Socket Clump Offset
	    clump_offset_socket = clump_hair_curves_001.interface.new_socket(name = "Clump Offset", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    clump_offset_socket.default_value = 0.0
	    clump_offset_socket.min_value = -3.4028234663852886e+38
	    clump_offset_socket.max_value = 3.4028234663852886e+38
	    clump_offset_socket.subtype = 'DISTANCE'
	    clump_offset_socket.attribute_domain = 'POINT'
	    clump_offset_socket.description = "Offset of each clump in a random direction"
	
	    #Socket Distance Falloff
	    distance_falloff_socket = clump_hair_curves_001.interface.new_socket(name = "Distance Falloff", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    distance_falloff_socket.default_value = 0.0
	    distance_falloff_socket.min_value = 0.0
	    distance_falloff_socket.max_value = 3.4028234663852886e+38
	    distance_falloff_socket.subtype = 'DISTANCE'
	    distance_falloff_socket.attribute_domain = 'POINT'
	    distance_falloff_socket.description = "Falloff distance for the clumping effect (0 means no falloff)"
	
	    #Socket Distance Threshold
	    distance_threshold_socket = clump_hair_curves_001.interface.new_socket(name = "Distance Threshold", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    distance_threshold_socket.default_value = 0.0
	    distance_threshold_socket.min_value = 0.0
	    distance_threshold_socket.max_value = 3.4028234663852886e+38
	    distance_threshold_socket.subtype = 'DISTANCE'
	    distance_threshold_socket.attribute_domain = 'POINT'
	    distance_threshold_socket.description = "Distance threshold for the falloff around the guide"
	
	    #Socket Seed
	    seed_socket_1 = clump_hair_curves_001.interface.new_socket(name = "Seed", in_out='INPUT', socket_type = 'NodeSocketInt')
	    seed_socket_1.default_value = 0
	    seed_socket_1.min_value = -10000
	    seed_socket_1.max_value = 10000
	    seed_socket_1.subtype = 'NONE'
	    seed_socket_1.attribute_domain = 'POINT'
	    seed_socket_1.description = "Random seed for the operation"
	
	    #Socket Preserve Length
	    preserve_length_socket = clump_hair_curves_001.interface.new_socket(name = "Preserve Length", in_out='INPUT', socket_type = 'NodeSocketBool')
	    preserve_length_socket.default_value = False
	    preserve_length_socket.attribute_domain = 'POINT'
	    preserve_length_socket.description = "Preserve each curve's length during deformation"
	
	
	    #initialize clump_hair_curves_001 nodes
	    #node Frame.001
	    frame_001_2 = clump_hair_curves_001.nodes.new("NodeFrame")
	    frame_001_2.label = "Optimization"
	    frame_001_2.name = "Frame.001"
	    frame_001_2.label_size = 20
	    frame_001_2.shrink = True
	
	    #node Frame
	    frame_4 = clump_hair_curves_001.nodes.new("NodeFrame")
	    frame_4.label = "Optimization"
	    frame_4.name = "Frame"
	    frame_4.label_size = 20
	    frame_4.shrink = True
	
	    #node Frame.003
	    frame_003_2 = clump_hair_curves_001.nodes.new("NodeFrame")
	    frame_003_2.label = "Length Preservation"
	    frame_003_2.name = "Frame.003"
	    frame_003_2.label_size = 20
	    frame_003_2.shrink = True
	
	    #node Frame.005
	    frame_005_1 = clump_hair_curves_001.nodes.new("NodeFrame")
	    frame_005_1.name = "Frame.005"
	    frame_005_1.label_size = 20
	    frame_005_1.shrink = True
	
	    #node Frame.006
	    frame_006_1 = clump_hair_curves_001.nodes.new("NodeFrame")
	    frame_006_1.label = "Displacement"
	    frame_006_1.name = "Frame.006"
	    frame_006_1.label_size = 20
	    frame_006_1.shrink = True
	
	    #node Frame.007
	    frame_007_1 = clump_hair_curves_001.nodes.new("NodeFrame")
	    frame_007_1.label = "Guide Map Fallback"
	    frame_007_1.name = "Frame.007"
	    frame_007_1.label_size = 20
	    frame_007_1.shrink = True
	
	    #node Frame.002
	    frame_002_3 = clump_hair_curves_001.nodes.new("NodeFrame")
	    frame_002_3.label = "Random Displacement"
	    frame_002_3.name = "Frame.002"
	    frame_002_3.label_size = 20
	    frame_002_3.shrink = True
	
	    #node Frame.004
	    frame_004_2 = clump_hair_curves_001.nodes.new("NodeFrame")
	    frame_004_2.label = "Root Distance Falloff"
	    frame_004_2.name = "Frame.004"
	    frame_004_2.label_size = 20
	    frame_004_2.shrink = True
	
	    #node Group Input.003
	    group_input_003_3 = clump_hair_curves_001.nodes.new("NodeGroupInput")
	    group_input_003_3.name = "Group Input.003"
	    group_input_003_3.outputs[1].hide = True
	    group_input_003_3.outputs[2].hide = True
	    group_input_003_3.outputs[3].hide = True
	    group_input_003_3.outputs[4].hide = True
	    group_input_003_3.outputs[5].hide = True
	    group_input_003_3.outputs[6].hide = True
	    group_input_003_3.outputs[7].hide = True
	    group_input_003_3.outputs[8].hide = True
	    group_input_003_3.outputs[9].hide = True
	    group_input_003_3.outputs[10].hide = True
	    group_input_003_3.outputs[11].hide = True
	    group_input_003_3.outputs[12].hide = True
	
	    #node Reroute.014
	    reroute_014_3 = clump_hair_curves_001.nodes.new("NodeReroute")
	    reroute_014_3.name = "Reroute.014"
	    reroute_014_3.socket_idname = "NodeSocketGeometry"
	    #node Reroute.015
	    reroute_015_3 = clump_hair_curves_001.nodes.new("NodeReroute")
	    reroute_015_3.name = "Reroute.015"
	    reroute_015_3.socket_idname = "NodeSocketGeometry"
	    #node Reroute.013
	    reroute_013_3 = clump_hair_curves_001.nodes.new("NodeReroute")
	    reroute_013_3.name = "Reroute.013"
	    reroute_013_3.socket_idname = "NodeSocketGeometry"
	    #node Reroute.012
	    reroute_012_3 = clump_hair_curves_001.nodes.new("NodeReroute")
	    reroute_012_3.name = "Reroute.012"
	    reroute_012_3.socket_idname = "NodeSocketGeometry"
	    #node Separate Components
	    separate_components_2 = clump_hair_curves_001.nodes.new("GeometryNodeSeparateComponents")
	    separate_components_2.name = "Separate Components"
	
	    #node Group Output.001
	    group_output_001 = clump_hair_curves_001.nodes.new("NodeGroupOutput")
	    group_output_001.name = "Group Output.001"
	    group_output_001.is_active_output = True
	
	    #node Join Geometry.001
	    join_geometry_001_2 = clump_hair_curves_001.nodes.new("GeometryNodeJoinGeometry")
	    join_geometry_001_2.name = "Join Geometry.001"
	
	    #node Reroute.016
	    reroute_016_3 = clump_hair_curves_001.nodes.new("NodeReroute")
	    reroute_016_3.name = "Reroute.016"
	    reroute_016_3.socket_idname = "NodeSocketGeometry"
	    #node Reroute.017
	    reroute_017_3 = clump_hair_curves_001.nodes.new("NodeReroute")
	    reroute_017_3.name = "Reroute.017"
	    reroute_017_3.socket_idname = "NodeSocketGeometry"
	    #node Reroute.019
	    reroute_019_2 = clump_hair_curves_001.nodes.new("NodeReroute")
	    reroute_019_2.name = "Reroute.019"
	    reroute_019_2.socket_idname = "NodeSocketGeometry"
	    #node Reroute.018
	    reroute_018_3 = clump_hair_curves_001.nodes.new("NodeReroute")
	    reroute_018_3.name = "Reroute.018"
	    reroute_018_3.socket_idname = "NodeSocketGeometry"
	    #node Capture Attribute
	    capture_attribute_2 = clump_hair_curves_001.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_2.name = "Capture Attribute"
	    capture_attribute_2.active_index = 0
	    capture_attribute_2.capture_items.clear()
	    capture_attribute_2.capture_items.new('FLOAT', "Value")
	    capture_attribute_2.capture_items["Value"].data_type = 'FLOAT_VECTOR'
	    capture_attribute_2.domain = 'POINT'
	
	    #node Position.001
	    position_001_1 = clump_hair_curves_001.nodes.new("GeometryNodeInputPosition")
	    position_001_1.name = "Position.001"
	
	    #node Capture Attribute.002
	    capture_attribute_002_2 = clump_hair_curves_001.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_002_2.name = "Capture Attribute.002"
	    capture_attribute_002_2.active_index = 0
	    capture_attribute_002_2.capture_items.clear()
	    capture_attribute_002_2.capture_items.new('FLOAT', "Value")
	    capture_attribute_002_2.capture_items["Value"].data_type = 'INT'
	    capture_attribute_002_2.domain = 'CURVE'
	
	    #node Spline Resolution
	    spline_resolution = clump_hair_curves_001.nodes.new("GeometryNodeInputSplineResolution")
	    spline_resolution.name = "Spline Resolution"
	
	    #node Set Spline Type.002
	    set_spline_type_002 = clump_hair_curves_001.nodes.new("GeometryNodeCurveSplineType")
	    set_spline_type_002.name = "Set Spline Type.002"
	    set_spline_type_002.spline_type = 'POLY'
	    #Selection
	    set_spline_type_002.inputs[1].default_value = True
	
	    #node Reroute.021
	    reroute_021_1 = clump_hair_curves_001.nodes.new("NodeReroute")
	    reroute_021_1.name = "Reroute.021"
	    reroute_021_1.socket_idname = "NodeSocketInt"
	    #node Switch.006
	    switch_006 = clump_hair_curves_001.nodes.new("GeometryNodeSwitch")
	    switch_006.name = "Switch.006"
	    switch_006.input_type = 'INT'
	    #True
	    switch_006.inputs[2].default_value = 12
	
	    #node Compare.004
	    compare_004_3 = clump_hair_curves_001.nodes.new("FunctionNodeCompare")
	    compare_004_3.name = "Compare.004"
	    compare_004_3.data_type = 'INT'
	    compare_004_3.mode = 'ELEMENT'
	    compare_004_3.operation = 'EQUAL'
	    #B_INT
	    compare_004_3.inputs[3].default_value = 0
	
	    #node Set Spline Resolution.001
	    set_spline_resolution_001 = clump_hair_curves_001.nodes.new("GeometryNodeSetSplineResolution")
	    set_spline_resolution_001.name = "Set Spline Resolution.001"
	    set_spline_resolution_001.inputs[1].hide = True
	    #Selection
	    set_spline_resolution_001.inputs[1].default_value = True
	
	    #node Set Spline Type.001
	    set_spline_type_001 = clump_hair_curves_001.nodes.new("GeometryNodeCurveSplineType")
	    set_spline_type_001.name = "Set Spline Type.001"
	    set_spline_type_001.spline_type = 'CATMULL_ROM'
	    set_spline_type_001.inputs[1].hide = True
	    #Selection
	    set_spline_type_001.inputs[1].default_value = True
	
	    #node Reroute.025
	    reroute_025 = clump_hair_curves_001.nodes.new("NodeReroute")
	    reroute_025.name = "Reroute.025"
	    reroute_025.socket_idname = "NodeSocketGeometry"
	    #node Group.005
	    group_005 = clump_hair_curves_001.nodes.new("GeometryNodeGroup")
	    group_005.name = "Group.005"
	    group_005.node_tree = restore_curve_segment_length_003
	    #Socket_3
	    group_005.inputs[2].default_value = 1.0
	    #Socket_5
	    group_005.inputs[4].default_value = 0.0
	
	    #node Group Input.010
	    group_input_010_1 = clump_hair_curves_001.nodes.new("NodeGroupInput")
	    group_input_010_1.name = "Group Input.010"
	    group_input_010_1.outputs[0].hide = True
	    group_input_010_1.outputs[1].hide = True
	    group_input_010_1.outputs[2].hide = True
	    group_input_010_1.outputs[3].hide = True
	    group_input_010_1.outputs[4].hide = True
	    group_input_010_1.outputs[5].hide = True
	    group_input_010_1.outputs[6].hide = True
	    group_input_010_1.outputs[7].hide = True
	    group_input_010_1.outputs[8].hide = True
	    group_input_010_1.outputs[9].hide = True
	    group_input_010_1.outputs[10].hide = True
	    group_input_010_1.outputs[11].hide = True
	    group_input_010_1.outputs[13].hide = True
	
	    #node Reroute.003
	    reroute_003_2 = clump_hair_curves_001.nodes.new("NodeReroute")
	    reroute_003_2.name = "Reroute.003"
	    reroute_003_2.socket_idname = "NodeSocketGeometry"
	    #node Reroute.005
	    reroute_005_2 = clump_hair_curves_001.nodes.new("NodeReroute")
	    reroute_005_2.name = "Reroute.005"
	    reroute_005_2.socket_idname = "NodeSocketGeometry"
	    #node Reroute.002
	    reroute_002_2 = clump_hair_curves_001.nodes.new("NodeReroute")
	    reroute_002_2.name = "Reroute.002"
	    reroute_002_2.socket_idname = "NodeSocketInt"
	    #node Reroute.010
	    reroute_010_1 = clump_hair_curves_001.nodes.new("NodeReroute")
	    reroute_010_1.name = "Reroute.010"
	    reroute_010_1.socket_idname = "NodeSocketVector"
	    #node Reroute.022
	    reroute_022_1 = clump_hair_curves_001.nodes.new("NodeReroute")
	    reroute_022_1.name = "Reroute.022"
	    reroute_022_1.socket_idname = "NodeSocketVector"
	    #node Reroute.023
	    reroute_023_1 = clump_hair_curves_001.nodes.new("NodeReroute")
	    reroute_023_1.name = "Reroute.023"
	    reroute_023_1.socket_idname = "NodeSocketInt"
	    #node Reroute.024
	    reroute_024_1 = clump_hair_curves_001.nodes.new("NodeReroute")
	    reroute_024_1.name = "Reroute.024"
	    reroute_024_1.socket_idname = "NodeSocketInt"
	    #node Vector Math
	    vector_math_3 = clump_hair_curves_001.nodes.new("ShaderNodeVectorMath")
	    vector_math_3.name = "Vector Math"
	    vector_math_3.hide = True
	    vector_math_3.operation = 'CROSS_PRODUCT'
	
	    #node Sample Curve
	    sample_curve = clump_hair_curves_001.nodes.new("GeometryNodeSampleCurve")
	    sample_curve.name = "Sample Curve"
	    sample_curve.data_type = 'FLOAT'
	    sample_curve.mode = 'FACTOR'
	    sample_curve.use_all_curves = False
	    sample_curve.inputs[1].hide = True
	    sample_curve.outputs[0].hide = True
	    #Value
	    sample_curve.inputs[1].default_value = 0.0
	
	    #node Spline Parameter
	    spline_parameter = clump_hair_curves_001.nodes.new("GeometryNodeSplineParameter")
	    spline_parameter.name = "Spline Parameter"
	    spline_parameter.outputs[1].hide = True
	    spline_parameter.outputs[2].hide = True
	
	    #node Vector Math.001
	    vector_math_001_3 = clump_hair_curves_001.nodes.new("ShaderNodeVectorMath")
	    vector_math_001_3.name = "Vector Math.001"
	    vector_math_001_3.hide = True
	    vector_math_001_3.operation = 'SCALE'
	
	    #node Vector Math.002
	    vector_math_002_2 = clump_hair_curves_001.nodes.new("ShaderNodeVectorMath")
	    vector_math_002_2.name = "Vector Math.002"
	    vector_math_002_2.hide = True
	    vector_math_002_2.operation = 'SCALE'
	
	    #node Separate XYZ
	    separate_xyz_1 = clump_hair_curves_001.nodes.new("ShaderNodeSeparateXYZ")
	    separate_xyz_1.name = "Separate XYZ"
	    separate_xyz_1.outputs[2].hide = True
	
	    #node Vector Math.006
	    vector_math_006_2 = clump_hair_curves_001.nodes.new("ShaderNodeVectorMath")
	    vector_math_006_2.name = "Vector Math.006"
	    vector_math_006_2.hide = True
	    vector_math_006_2.operation = 'ADD'
	
	    #node Evaluate on Domain
	    evaluate_on_domain_1 = clump_hair_curves_001.nodes.new("GeometryNodeFieldOnDomain")
	    evaluate_on_domain_1.name = "Evaluate on Domain"
	    evaluate_on_domain_1.data_type = 'FLOAT_VECTOR'
	    evaluate_on_domain_1.domain = 'CURVE'
	
	    #node Combine XYZ
	    combine_xyz_1 = clump_hair_curves_001.nodes.new("ShaderNodeCombineXYZ")
	    combine_xyz_1.name = "Combine XYZ"
	    #Z
	    combine_xyz_1.inputs[2].default_value = 0.0
	
	    #node Vector Math.004
	    vector_math_004_3 = clump_hair_curves_001.nodes.new("ShaderNodeVectorMath")
	    vector_math_004_3.name = "Vector Math.004"
	    vector_math_004_3.hide = True
	    vector_math_004_3.operation = 'DOT_PRODUCT'
	
	    #node Vector Math.005
	    vector_math_005_1 = clump_hair_curves_001.nodes.new("ShaderNodeVectorMath")
	    vector_math_005_1.name = "Vector Math.005"
	    vector_math_005_1.hide = True
	    vector_math_005_1.operation = 'DOT_PRODUCT'
	
	    #node Reroute
	    reroute_4 = clump_hair_curves_001.nodes.new("NodeReroute")
	    reroute_4.name = "Reroute"
	    reroute_4.socket_idname = "NodeSocketVector"
	    #node Vector Math.008
	    vector_math_008_2 = clump_hair_curves_001.nodes.new("ShaderNodeVectorMath")
	    vector_math_008_2.name = "Vector Math.008"
	    vector_math_008_2.operation = 'SUBTRACT'
	
	    #node Vector Math.003
	    vector_math_003_2 = clump_hair_curves_001.nodes.new("ShaderNodeVectorMath")
	    vector_math_003_2.name = "Vector Math.003"
	    vector_math_003_2.hide = True
	    vector_math_003_2.operation = 'CROSS_PRODUCT'
	
	    #node Sample Curve.001
	    sample_curve_001_1 = clump_hair_curves_001.nodes.new("GeometryNodeSampleCurve")
	    sample_curve_001_1.name = "Sample Curve.001"
	    sample_curve_001_1.data_type = 'FLOAT'
	    sample_curve_001_1.mode = 'FACTOR'
	    sample_curve_001_1.use_all_curves = False
	    sample_curve_001_1.inputs[1].hide = True
	    sample_curve_001_1.inputs[2].hide = True
	    sample_curve_001_1.outputs[0].hide = True
	    sample_curve_001_1.outputs[1].hide = True
	    #Value
	    sample_curve_001_1.inputs[1].default_value = 0.0
	    #Factor
	    sample_curve_001_1.inputs[2].default_value = 0.0
	
	    #node Evaluate at Index
	    evaluate_at_index_3 = clump_hair_curves_001.nodes.new("GeometryNodeFieldAtIndex")
	    evaluate_at_index_3.name = "Evaluate at Index"
	    evaluate_at_index_3.data_type = 'FLOAT_VECTOR'
	    evaluate_at_index_3.domain = 'CURVE'
	
	    #node Group
	    group_3 = clump_hair_curves_001.nodes.new("GeometryNodeGroup")
	    group_3.name = "Group"
	    group_3.node_tree = curve_root_006
	    group_3.outputs[0].hide = True
	    group_3.outputs[2].hide = True
	    group_3.outputs[3].hide = True
	
	    #node Reroute.001
	    reroute_001_4 = clump_hair_curves_001.nodes.new("NodeReroute")
	    reroute_001_4.name = "Reroute.001"
	    reroute_001_4.socket_idname = "NodeSocketInt"
	    #node Reroute.008
	    reroute_008_2 = clump_hair_curves_001.nodes.new("NodeReroute")
	    reroute_008_2.name = "Reroute.008"
	    reroute_008_2.socket_idname = "NodeSocketInt"
	    #node Reroute.007
	    reroute_007_2 = clump_hair_curves_001.nodes.new("NodeReroute")
	    reroute_007_2.name = "Reroute.007"
	    reroute_007_2.socket_idname = "NodeSocketInt"
	    #node Reroute.026
	    reroute_026_1 = clump_hair_curves_001.nodes.new("NodeReroute")
	    reroute_026_1.name = "Reroute.026"
	    reroute_026_1.socket_idname = "NodeSocketInt"
	    #node Reroute.027
	    reroute_027_1 = clump_hair_curves_001.nodes.new("NodeReroute")
	    reroute_027_1.name = "Reroute.027"
	    reroute_027_1.socket_idname = "NodeSocketInt"
	    #node Evaluate on Domain.001
	    evaluate_on_domain_001_2 = clump_hair_curves_001.nodes.new("GeometryNodeFieldOnDomain")
	    evaluate_on_domain_001_2.name = "Evaluate on Domain.001"
	    evaluate_on_domain_001_2.data_type = 'FLOAT_VECTOR'
	    evaluate_on_domain_001_2.domain = 'CURVE'
	
	    #node Sample Index
	    sample_index_1 = clump_hair_curves_001.nodes.new("GeometryNodeSampleIndex")
	    sample_index_1.name = "Sample Index"
	    sample_index_1.hide = True
	    sample_index_1.clamp = False
	    sample_index_1.data_type = 'INT'
	    sample_index_1.domain = 'POINT'
	    #Index
	    sample_index_1.inputs[2].default_value = 0
	
	    #node Accumulate Field.002
	    accumulate_field_002 = clump_hair_curves_001.nodes.new("GeometryNodeAccumulateField")
	    accumulate_field_002.name = "Accumulate Field.002"
	    accumulate_field_002.hide = True
	    accumulate_field_002.data_type = 'INT'
	    accumulate_field_002.domain = 'POINT'
	    #Group Index
	    accumulate_field_002.inputs[1].default_value = 0
	
	    #node Group Input.002
	    group_input_002_2 = clump_hair_curves_001.nodes.new("NodeGroupInput")
	    group_input_002_2.name = "Group Input.002"
	    group_input_002_2.outputs[0].hide = True
	    group_input_002_2.outputs[1].hide = True
	    group_input_002_2.outputs[2].hide = True
	    group_input_002_2.outputs[3].hide = True
	    group_input_002_2.outputs[5].hide = True
	    group_input_002_2.outputs[6].hide = True
	    group_input_002_2.outputs[7].hide = True
	    group_input_002_2.outputs[8].hide = True
	    group_input_002_2.outputs[9].hide = True
	    group_input_002_2.outputs[10].hide = True
	    group_input_002_2.outputs[11].hide = True
	    group_input_002_2.outputs[12].hide = True
	    group_input_002_2.outputs[13].hide = True
	
	    #node Reroute.032
	    reroute_032 = clump_hair_curves_001.nodes.new("NodeReroute")
	    reroute_032.name = "Reroute.032"
	    reroute_032.socket_idname = "NodeSocketGeometry"
	    #node Boolean Math.001
	    boolean_math_001 = clump_hair_curves_001.nodes.new("FunctionNodeBooleanMath")
	    boolean_math_001.name = "Boolean Math.001"
	    boolean_math_001.operation = 'AND'
	
	    #node Switch.001
	    switch_001_5 = clump_hair_curves_001.nodes.new("GeometryNodeSwitch")
	    switch_001_5.name = "Switch.001"
	    switch_001_5.input_type = 'GEOMETRY'
	
	    #node Named Attribute.003
	    named_attribute_003 = clump_hair_curves_001.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute_003.name = "Named Attribute.003"
	    named_attribute_003.data_type = 'INT'
	    #Name
	    named_attribute_003.inputs[0].default_value = "guide_curve_index"
	
	    #node Group Input.013
	    group_input_013 = clump_hair_curves_001.nodes.new("NodeGroupInput")
	    group_input_013.name = "Group Input.013"
	    group_input_013.outputs[0].hide = True
	    group_input_013.outputs[1].hide = True
	    group_input_013.outputs[2].hide = True
	    group_input_013.outputs[4].hide = True
	    group_input_013.outputs[5].hide = True
	    group_input_013.outputs[6].hide = True
	    group_input_013.outputs[7].hide = True
	    group_input_013.outputs[8].hide = True
	    group_input_013.outputs[9].hide = True
	    group_input_013.outputs[10].hide = True
	    group_input_013.outputs[11].hide = True
	    group_input_013.outputs[12].hide = True
	    group_input_013.outputs[13].hide = True
	
	    #node Group Input.004
	    group_input_004_2 = clump_hair_curves_001.nodes.new("NodeGroupInput")
	    group_input_004_2.name = "Group Input.004"
	    group_input_004_2.outputs[0].hide = True
	    group_input_004_2.outputs[1].hide = True
	    group_input_004_2.outputs[3].hide = True
	    group_input_004_2.outputs[4].hide = True
	    group_input_004_2.outputs[5].hide = True
	    group_input_004_2.outputs[6].hide = True
	    group_input_004_2.outputs[7].hide = True
	    group_input_004_2.outputs[8].hide = True
	    group_input_004_2.outputs[9].hide = True
	    group_input_004_2.outputs[10].hide = True
	    group_input_004_2.outputs[11].hide = True
	    group_input_004_2.outputs[12].hide = True
	    group_input_004_2.outputs[13].hide = True
	
	    #node Reroute.006
	    reroute_006_2 = clump_hair_curves_001.nodes.new("NodeReroute")
	    reroute_006_2.name = "Reroute.006"
	    reroute_006_2.socket_idname = "NodeSocketInt"
	    #node Compare.003
	    compare_003_2 = clump_hair_curves_001.nodes.new("FunctionNodeCompare")
	    compare_003_2.name = "Compare.003"
	    compare_003_2.data_type = 'INT'
	    compare_003_2.mode = 'ELEMENT'
	    compare_003_2.operation = 'NOT_EQUAL'
	    #B_INT
	    compare_003_2.inputs[3].default_value = -987654
	
	    #node Group Input.011
	    group_input_011 = clump_hair_curves_001.nodes.new("NodeGroupInput")
	    group_input_011.name = "Group Input.011"
	    group_input_011.outputs[0].hide = True
	    group_input_011.outputs[2].hide = True
	    group_input_011.outputs[3].hide = True
	    group_input_011.outputs[4].hide = True
	    group_input_011.outputs[5].hide = True
	    group_input_011.outputs[6].hide = True
	    group_input_011.outputs[7].hide = True
	    group_input_011.outputs[8].hide = True
	    group_input_011.outputs[9].hide = True
	    group_input_011.outputs[10].hide = True
	    group_input_011.outputs[11].hide = True
	    group_input_011.outputs[12].hide = True
	    group_input_011.outputs[13].hide = True
	
	    #node Accumulate Field
	    accumulate_field_1 = clump_hair_curves_001.nodes.new("GeometryNodeAccumulateField")
	    accumulate_field_1.name = "Accumulate Field"
	    accumulate_field_1.data_type = 'INT'
	    accumulate_field_1.domain = 'CURVE'
	    accumulate_field_1.inputs[1].hide = True
	    accumulate_field_1.outputs[0].hide = True
	    accumulate_field_1.outputs[1].hide = True
	    #Group Index
	    accumulate_field_1.inputs[1].default_value = 0
	
	    #node Switch.003
	    switch_003_4 = clump_hair_curves_001.nodes.new("GeometryNodeSwitch")
	    switch_003_4.name = "Switch.003"
	    switch_003_4.input_type = 'INT'
	
	    #node Compare.001
	    compare_001_2 = clump_hair_curves_001.nodes.new("FunctionNodeCompare")
	    compare_001_2.name = "Compare.001"
	    compare_001_2.hide = True
	    compare_001_2.data_type = 'INT'
	    compare_001_2.mode = 'ELEMENT'
	    compare_001_2.operation = 'GREATER_THAN'
	    #B_INT
	    compare_001_2.inputs[3].default_value = 0
	
	    #node Group.003
	    group_003_1 = clump_hair_curves_001.nodes.new("GeometryNodeGroup")
	    group_003_1.name = "Group.003"
	    group_003_1.node_tree = create_guide_index_map_001
	    group_003_1.inputs[1].hide = True
	    group_003_1.inputs[4].hide = True
	    group_003_1.outputs[1].hide = True
	    group_003_1.outputs[3].hide = True
	    #Socket_8
	    group_003_1.inputs[4].default_value = 0
	
	    #node Boolean Math.002
	    boolean_math_002_2 = clump_hair_curves_001.nodes.new("FunctionNodeBooleanMath")
	    boolean_math_002_2.name = "Boolean Math.002"
	    boolean_math_002_2.operation = 'NIMPLY'
	
	    #node Sample Index.001
	    sample_index_001_1 = clump_hair_curves_001.nodes.new("GeometryNodeSampleIndex")
	    sample_index_001_1.name = "Sample Index.001"
	    sample_index_001_1.hide = True
	    sample_index_001_1.clamp = False
	    sample_index_001_1.data_type = 'BOOLEAN'
	    sample_index_001_1.domain = 'CURVE'
	    #Index
	    sample_index_001_1.inputs[2].default_value = 0
	
	    #node Reroute.029
	    reroute_029 = clump_hair_curves_001.nodes.new("NodeReroute")
	    reroute_029.name = "Reroute.029"
	    reroute_029.socket_idname = "NodeSocketInt"
	    #node Capture Attribute.001
	    capture_attribute_001_2 = clump_hair_curves_001.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_001_2.name = "Capture Attribute.001"
	    capture_attribute_001_2.active_index = 0
	    capture_attribute_001_2.capture_items.clear()
	    capture_attribute_001_2.capture_items.new('FLOAT', "Value")
	    capture_attribute_001_2.capture_items["Value"].data_type = 'INT'
	    capture_attribute_001_2.domain = 'CURVE'
	
	    #node Position
	    position_1 = clump_hair_curves_001.nodes.new("GeometryNodeInputPosition")
	    position_1.name = "Position"
	
	    #node Mix
	    mix_1 = clump_hair_curves_001.nodes.new("ShaderNodeMix")
	    mix_1.name = "Mix"
	    mix_1.blend_type = 'MIX'
	    mix_1.clamp_factor = True
	    mix_1.clamp_result = False
	    mix_1.data_type = 'VECTOR'
	    mix_1.factor_mode = 'UNIFORM'
	
	    #node Vector Math.009
	    vector_math_009_2 = clump_hair_curves_001.nodes.new("ShaderNodeVectorMath")
	    vector_math_009_2.name = "Vector Math.009"
	    vector_math_009_2.operation = 'ADD'
	
	    #node Math.002
	    math_002_1 = clump_hair_curves_001.nodes.new("ShaderNodeMath")
	    math_002_1.name = "Math.002"
	    math_002_1.operation = 'MULTIPLY'
	    math_002_1.use_clamp = False
	
	    #node Set Position
	    set_position_2 = clump_hair_curves_001.nodes.new("GeometryNodeSetPosition")
	    set_position_2.name = "Set Position"
	    set_position_2.inputs[1].hide = True
	    set_position_2.inputs[3].hide = True
	    #Selection
	    set_position_2.inputs[1].default_value = True
	    #Offset
	    set_position_2.inputs[3].default_value = (0.0, 0.0, 0.0)
	
	    #node Group Input.001
	    group_input_001_3 = clump_hair_curves_001.nodes.new("NodeGroupInput")
	    group_input_001_3.name = "Group Input.001"
	    group_input_001_3.outputs[0].hide = True
	    group_input_001_3.outputs[1].hide = True
	    group_input_001_3.outputs[2].hide = True
	    group_input_001_3.outputs[3].hide = True
	    group_input_001_3.outputs[4].hide = True
	    group_input_001_3.outputs[6].hide = True
	    group_input_001_3.outputs[7].hide = True
	    group_input_001_3.outputs[8].hide = True
	    group_input_001_3.outputs[9].hide = True
	    group_input_001_3.outputs[10].hide = True
	    group_input_001_3.outputs[11].hide = True
	    group_input_001_3.outputs[12].hide = True
	    group_input_001_3.outputs[13].hide = True
	
	    #node Math
	    math_4 = clump_hair_curves_001.nodes.new("ShaderNodeMath")
	    math_4.name = "Math"
	    math_4.operation = 'SUBTRACT'
	    math_4.use_clamp = False
	    #Value
	    math_4.inputs[0].default_value = 1.0
	
	    #node Vector Math.013
	    vector_math_013_1 = clump_hair_curves_001.nodes.new("ShaderNodeVectorMath")
	    vector_math_013_1.name = "Vector Math.013"
	    vector_math_013_1.hide = True
	    vector_math_013_1.operation = 'SCALE'
	
	    #node Vector Math.007
	    vector_math_007_2 = clump_hair_curves_001.nodes.new("ShaderNodeVectorMath")
	    vector_math_007_2.name = "Vector Math.007"
	    vector_math_007_2.hide = True
	    vector_math_007_2.operation = 'SCALE'
	
	    #node Vector Math.011
	    vector_math_011_1 = clump_hair_curves_001.nodes.new("ShaderNodeVectorMath")
	    vector_math_011_1.name = "Vector Math.011"
	    vector_math_011_1.hide = True
	    vector_math_011_1.operation = 'ADD'
	
	    #node Reroute.020
	    reroute_020_2 = clump_hair_curves_001.nodes.new("NodeReroute")
	    reroute_020_2.name = "Reroute.020"
	    reroute_020_2.socket_idname = "NodeSocketFloat"
	    #node Math.001
	    math_001_2 = clump_hair_curves_001.nodes.new("ShaderNodeMath")
	    math_001_2.name = "Math.001"
	    math_001_2.operation = 'MULTIPLY'
	    math_001_2.use_clamp = False
	
	    #node Reroute.004
	    reroute_004_3 = clump_hair_curves_001.nodes.new("NodeReroute")
	    reroute_004_3.name = "Reroute.004"
	    reroute_004_3.socket_idname = "NodeSocketFloat"
	    #node Vector Math.025
	    vector_math_025 = clump_hair_curves_001.nodes.new("ShaderNodeVectorMath")
	    vector_math_025.name = "Vector Math.025"
	    vector_math_025.hide = True
	    vector_math_025.operation = 'ADD'
	
	    #node Switch.002
	    switch_002_3 = clump_hair_curves_001.nodes.new("GeometryNodeSwitch")
	    switch_002_3.name = "Switch.002"
	    switch_002_3.hide = True
	    switch_002_3.input_type = 'VECTOR'
	    #True
	    switch_002_3.inputs[2].default_value = (0.0, 0.0, 0.0)
	
	    #node Vector Math.020
	    vector_math_020 = clump_hair_curves_001.nodes.new("ShaderNodeVectorMath")
	    vector_math_020.name = "Vector Math.020"
	    vector_math_020.hide = True
	    vector_math_020.operation = 'SCALE'
	
	    #node Vector Math.021
	    vector_math_021 = clump_hair_curves_001.nodes.new("ShaderNodeVectorMath")
	    vector_math_021.name = "Vector Math.021"
	    vector_math_021.hide = True
	    vector_math_021.operation = 'SCALE'
	
	    #node Vector Math.022
	    vector_math_022 = clump_hair_curves_001.nodes.new("ShaderNodeVectorMath")
	    vector_math_022.name = "Vector Math.022"
	    vector_math_022.hide = True
	    vector_math_022.operation = 'ADD'
	
	    #node Vector Math.015
	    vector_math_015 = clump_hair_curves_001.nodes.new("ShaderNodeVectorMath")
	    vector_math_015.name = "Vector Math.015"
	    vector_math_015.hide = True
	    vector_math_015.operation = 'SCALE'
	
	    #node Vector Math.016
	    vector_math_016 = clump_hair_curves_001.nodes.new("ShaderNodeVectorMath")
	    vector_math_016.name = "Vector Math.016"
	    vector_math_016.hide = True
	    vector_math_016.operation = 'SCALE'
	
	    #node Vector Math.018
	    vector_math_018 = clump_hair_curves_001.nodes.new("ShaderNodeVectorMath")
	    vector_math_018.name = "Vector Math.018"
	    vector_math_018.hide = True
	    vector_math_018.operation = 'ADD'
	
	    #node Vector Math.019
	    vector_math_019 = clump_hair_curves_001.nodes.new("ShaderNodeVectorMath")
	    vector_math_019.name = "Vector Math.019"
	    vector_math_019.hide = True
	    vector_math_019.operation = 'ADD'
	
	    #node Vector Math.014
	    vector_math_014_1 = clump_hair_curves_001.nodes.new("ShaderNodeVectorMath")
	    vector_math_014_1.name = "Vector Math.014"
	    vector_math_014_1.hide = True
	    vector_math_014_1.operation = 'SCALE'
	
	    #node Switch
	    switch_4 = clump_hair_curves_001.nodes.new("GeometryNodeSwitch")
	    switch_4.name = "Switch"
	    switch_4.hide = True
	    switch_4.input_type = 'VECTOR'
	    #True
	    switch_4.inputs[2].default_value = (0.0, 0.0, 0.0)
	
	    #node Sample Curve.002
	    sample_curve_002 = clump_hair_curves_001.nodes.new("GeometryNodeSampleCurve")
	    sample_curve_002.name = "Sample Curve.002"
	    sample_curve_002.data_type = 'FLOAT'
	    sample_curve_002.mode = 'FACTOR'
	    sample_curve_002.use_all_curves = False
	    sample_curve_002.inputs[1].hide = True
	    sample_curve_002.inputs[2].hide = True
	    sample_curve_002.outputs[0].hide = True
	    sample_curve_002.outputs[1].hide = True
	    #Value
	    sample_curve_002.inputs[1].default_value = 0.0
	    #Factor
	    sample_curve_002.inputs[2].default_value = 1.0
	
	    #node Reroute.011
	    reroute_011_2 = clump_hair_curves_001.nodes.new("NodeReroute")
	    reroute_011_2.name = "Reroute.011"
	    reroute_011_2.socket_idname = "NodeSocketInt"
	    #node Vector Math.017
	    vector_math_017 = clump_hair_curves_001.nodes.new("ShaderNodeVectorMath")
	    vector_math_017.name = "Vector Math.017"
	    vector_math_017.hide = True
	    vector_math_017.operation = 'CROSS_PRODUCT'
	
	    #node Random Value
	    random_value_1 = clump_hair_curves_001.nodes.new("FunctionNodeRandomValue")
	    random_value_1.name = "Random Value"
	    random_value_1.hide = True
	    random_value_1.data_type = 'FLOAT_VECTOR'
	    #Min
	    random_value_1.inputs[0].default_value = (-1.0, -1.0, -1.0)
	    #Max
	    random_value_1.inputs[1].default_value = (1.0, 1.0, 1.0)
	
	    #node Vector Math.026
	    vector_math_026 = clump_hair_curves_001.nodes.new("ShaderNodeVectorMath")
	    vector_math_026.name = "Vector Math.026"
	    vector_math_026.operation = 'SCALE'
	
	    #node Separate XYZ.002
	    separate_xyz_002_1 = clump_hair_curves_001.nodes.new("ShaderNodeSeparateXYZ")
	    separate_xyz_002_1.name = "Separate XYZ.002"
	    separate_xyz_002_1.outputs[2].hide = True
	
	    #node Separate XYZ.001
	    separate_xyz_001_1 = clump_hair_curves_001.nodes.new("ShaderNodeSeparateXYZ")
	    separate_xyz_001_1.name = "Separate XYZ.001"
	
	    #node Reroute.009
	    reroute_009_2 = clump_hair_curves_001.nodes.new("NodeReroute")
	    reroute_009_2.name = "Reroute.009"
	    reroute_009_2.socket_idname = "NodeSocketFloatDistance"
	    #node Vector Math.012
	    vector_math_012_1 = clump_hair_curves_001.nodes.new("ShaderNodeVectorMath")
	    vector_math_012_1.name = "Vector Math.012"
	    vector_math_012_1.operation = 'SCALE'
	
	    #node Group Input.009
	    group_input_009_1 = clump_hair_curves_001.nodes.new("NodeGroupInput")
	    group_input_009_1.name = "Group Input.009"
	    group_input_009_1.outputs[0].hide = True
	    group_input_009_1.outputs[1].hide = True
	    group_input_009_1.outputs[2].hide = True
	    group_input_009_1.outputs[3].hide = True
	    group_input_009_1.outputs[4].hide = True
	    group_input_009_1.outputs[5].hide = True
	    group_input_009_1.outputs[6].hide = True
	    group_input_009_1.outputs[7].hide = True
	    group_input_009_1.outputs[9].hide = True
	    group_input_009_1.outputs[10].hide = True
	    group_input_009_1.outputs[11].hide = True
	    group_input_009_1.outputs[12].hide = True
	    group_input_009_1.outputs[13].hide = True
	
	    #node Group Input.012
	    group_input_012 = clump_hair_curves_001.nodes.new("NodeGroupInput")
	    group_input_012.name = "Group Input.012"
	    group_input_012.outputs[0].hide = True
	    group_input_012.outputs[1].hide = True
	    group_input_012.outputs[2].hide = True
	    group_input_012.outputs[3].hide = True
	    group_input_012.outputs[4].hide = True
	    group_input_012.outputs[5].hide = True
	    group_input_012.outputs[6].hide = True
	    group_input_012.outputs[8].hide = True
	    group_input_012.outputs[9].hide = True
	    group_input_012.outputs[10].hide = True
	    group_input_012.outputs[11].hide = True
	    group_input_012.outputs[12].hide = True
	    group_input_012.outputs[13].hide = True
	
	    #node Group Input.008
	    group_input_008_1 = clump_hair_curves_001.nodes.new("NodeGroupInput")
	    group_input_008_1.name = "Group Input.008"
	    group_input_008_1.outputs[0].hide = True
	    group_input_008_1.outputs[1].hide = True
	    group_input_008_1.outputs[2].hide = True
	    group_input_008_1.outputs[3].hide = True
	    group_input_008_1.outputs[4].hide = True
	    group_input_008_1.outputs[5].hide = True
	    group_input_008_1.outputs[6].hide = True
	    group_input_008_1.outputs[8].hide = True
	    group_input_008_1.outputs[9].hide = True
	    group_input_008_1.outputs[10].hide = True
	    group_input_008_1.outputs[11].hide = True
	    group_input_008_1.outputs[12].hide = True
	    group_input_008_1.outputs[13].hide = True
	
	    #node Random Value.001
	    random_value_001_2 = clump_hair_curves_001.nodes.new("FunctionNodeRandomValue")
	    random_value_001_2.name = "Random Value.001"
	    random_value_001_2.hide = True
	    random_value_001_2.data_type = 'FLOAT_VECTOR'
	    #Min
	    random_value_001_2.inputs[0].default_value = (-1.0, -1.0, -1.0)
	    #Max
	    random_value_001_2.inputs[1].default_value = (1.0, 1.0, 1.0)
	
	    #node Reroute.028
	    reroute_028_1 = clump_hair_curves_001.nodes.new("NodeReroute")
	    reroute_028_1.name = "Reroute.028"
	    reroute_028_1.socket_idname = "NodeSocketInt"
	    #node Evaluate at Index.001
	    evaluate_at_index_001_1 = clump_hair_curves_001.nodes.new("GeometryNodeFieldAtIndex")
	    evaluate_at_index_001_1.name = "Evaluate at Index.001"
	    evaluate_at_index_001_1.data_type = 'INT'
	    evaluate_at_index_001_1.domain = 'CURVE'
	
	    #node Group.006
	    group_006 = clump_hair_curves_001.nodes.new("GeometryNodeGroup")
	    group_006.name = "Group.006"
	    group_006.node_tree = curve_info_003
	    group_006.outputs[0].hide = True
	    group_006.outputs[2].hide = True
	    group_006.outputs[3].hide = True
	    group_006.outputs[4].hide = True
	    group_006.outputs[5].hide = True
	
	    #node Group.007
	    group_007 = clump_hair_curves_001.nodes.new("GeometryNodeGroup")
	    group_007.name = "Group.007"
	    group_007.node_tree = curve_info_003
	    group_007.outputs[0].hide = True
	    group_007.outputs[2].hide = True
	    group_007.outputs[3].hide = True
	    group_007.outputs[4].hide = True
	    group_007.outputs[5].hide = True
	
	    #node Random Value.004
	    random_value_004_1 = clump_hair_curves_001.nodes.new("FunctionNodeRandomValue")
	    random_value_004_1.label = "Hash Seed"
	    random_value_004_1.name = "Random Value.004"
	    random_value_004_1.data_type = 'INT'
	    #Min_002
	    random_value_004_1.inputs[4].default_value = -1073741823
	    #Max_002
	    random_value_004_1.inputs[5].default_value = 1073741823
	    #Seed
	    random_value_004_1.inputs[8].default_value = 148762
	
	    #node Group Input.005
	    group_input_005_2 = clump_hair_curves_001.nodes.new("NodeGroupInput")
	    group_input_005_2.name = "Group Input.005"
	    group_input_005_2.outputs[0].hide = True
	    group_input_005_2.outputs[1].hide = True
	    group_input_005_2.outputs[2].hide = True
	    group_input_005_2.outputs[3].hide = True
	    group_input_005_2.outputs[4].hide = True
	    group_input_005_2.outputs[5].hide = True
	    group_input_005_2.outputs[6].hide = True
	    group_input_005_2.outputs[7].hide = True
	    group_input_005_2.outputs[8].hide = True
	    group_input_005_2.outputs[9].hide = True
	    group_input_005_2.outputs[10].hide = True
	    group_input_005_2.outputs[12].hide = True
	    group_input_005_2.outputs[13].hide = True
	
	    #node Compare
	    compare_3 = clump_hair_curves_001.nodes.new("FunctionNodeCompare")
	    compare_3.name = "Compare"
	    compare_3.hide = True
	    compare_3.data_type = 'FLOAT'
	    compare_3.mode = 'ELEMENT'
	    compare_3.operation = 'EQUAL'
	    #B
	    compare_3.inputs[1].default_value = 0.0
	    #Epsilon
	    compare_3.inputs[12].default_value = 0.0
	
	    #node Compare.002
	    compare_002_2 = clump_hair_curves_001.nodes.new("FunctionNodeCompare")
	    compare_002_2.name = "Compare.002"
	    compare_002_2.hide = True
	    compare_002_2.data_type = 'FLOAT'
	    compare_002_2.mode = 'ELEMENT'
	    compare_002_2.operation = 'EQUAL'
	    #A
	    compare_002_2.inputs[0].default_value = 0.0
	    #Epsilon
	    compare_002_2.inputs[12].default_value = 0.0
	
	    #node Spline Parameter.001
	    spline_parameter_001 = clump_hair_curves_001.nodes.new("GeometryNodeSplineParameter")
	    spline_parameter_001.name = "Spline Parameter.001"
	    spline_parameter_001.outputs[1].hide = True
	    spline_parameter_001.outputs[2].hide = True
	
	    #node Group Input
	    group_input_4 = clump_hair_curves_001.nodes.new("NodeGroupInput")
	    group_input_4.name = "Group Input"
	    group_input_4.outputs[0].hide = True
	    group_input_4.outputs[1].hide = True
	    group_input_4.outputs[2].hide = True
	    group_input_4.outputs[3].hide = True
	    group_input_4.outputs[4].hide = True
	    group_input_4.outputs[5].hide = True
	    group_input_4.outputs[7].hide = True
	    group_input_4.outputs[8].hide = True
	    group_input_4.outputs[9].hide = True
	    group_input_4.outputs[10].hide = True
	    group_input_4.outputs[11].hide = True
	    group_input_4.outputs[12].hide = True
	    group_input_4.outputs[13].hide = True
	
	    #node Group.001
	    group_001_3 = clump_hair_curves_001.nodes.new("GeometryNodeGroup")
	    group_001_3.name = "Group.001"
	    group_001_3.node_tree = shape_range_004
	    group_001_3.inputs[1].hide = True
	    group_001_3.inputs[2].hide = True
	    group_001_3.inputs[4].hide = True
	    #Socket_2
	    group_001_3.inputs[1].default_value = 0.0
	    #Socket_3
	    group_001_3.inputs[2].default_value = 1.0
	    #Socket_5
	    group_001_3.inputs[4].default_value = 2.0
	
	    #node Math.003
	    math_003_2 = clump_hair_curves_001.nodes.new("ShaderNodeMath")
	    math_003_2.name = "Math.003"
	    math_003_2.operation = 'ADD'
	    math_003_2.use_clamp = False
	    math_003_2.inputs[2].hide = True
	
	    #node Vector Math.010
	    vector_math_010_1 = clump_hair_curves_001.nodes.new("ShaderNodeVectorMath")
	    vector_math_010_1.name = "Vector Math.010"
	    vector_math_010_1.hide = True
	    vector_math_010_1.operation = 'LENGTH'
	
	    #node Compare.006
	    compare_006 = clump_hair_curves_001.nodes.new("FunctionNodeCompare")
	    compare_006.name = "Compare.006"
	    compare_006.hide = True
	    compare_006.data_type = 'FLOAT'
	    compare_006.mode = 'ELEMENT'
	    compare_006.operation = 'NOT_EQUAL'
	    #B
	    compare_006.inputs[1].default_value = 0.0
	    #Epsilon
	    compare_006.inputs[12].default_value = 0.0
	
	    #node Compare.007
	    compare_007 = clump_hair_curves_001.nodes.new("FunctionNodeCompare")
	    compare_007.name = "Compare.007"
	    compare_007.hide = True
	    compare_007.data_type = 'FLOAT'
	    compare_007.mode = 'ELEMENT'
	    compare_007.operation = 'EQUAL'
	    #B
	    compare_007.inputs[1].default_value = 0.0
	    #Epsilon
	    compare_007.inputs[12].default_value = 0.0
	
	    #node Reroute.030
	    reroute_030 = clump_hair_curves_001.nodes.new("NodeReroute")
	    reroute_030.name = "Reroute.030"
	    reroute_030.socket_idname = "NodeSocketFloatDistance"
	    #node Group Input.007
	    group_input_007_2 = clump_hair_curves_001.nodes.new("NodeGroupInput")
	    group_input_007_2.name = "Group Input.007"
	    group_input_007_2.outputs[0].hide = True
	    group_input_007_2.outputs[1].hide = True
	    group_input_007_2.outputs[2].hide = True
	    group_input_007_2.outputs[3].hide = True
	    group_input_007_2.outputs[4].hide = True
	    group_input_007_2.outputs[5].hide = True
	    group_input_007_2.outputs[6].hide = True
	    group_input_007_2.outputs[7].hide = True
	    group_input_007_2.outputs[8].hide = True
	    group_input_007_2.outputs[10].hide = True
	    group_input_007_2.outputs[11].hide = True
	    group_input_007_2.outputs[12].hide = True
	    group_input_007_2.outputs[13].hide = True
	
	    #node Group Input.006
	    group_input_006_2 = clump_hair_curves_001.nodes.new("NodeGroupInput")
	    group_input_006_2.name = "Group Input.006"
	    group_input_006_2.outputs[0].hide = True
	    group_input_006_2.outputs[1].hide = True
	    group_input_006_2.outputs[2].hide = True
	    group_input_006_2.outputs[3].hide = True
	    group_input_006_2.outputs[4].hide = True
	    group_input_006_2.outputs[5].hide = True
	    group_input_006_2.outputs[6].hide = True
	    group_input_006_2.outputs[7].hide = True
	    group_input_006_2.outputs[8].hide = True
	    group_input_006_2.outputs[9].hide = True
	    group_input_006_2.outputs[11].hide = True
	    group_input_006_2.outputs[12].hide = True
	    group_input_006_2.outputs[13].hide = True
	
	    #node Compare.005
	    compare_005_1 = clump_hair_curves_001.nodes.new("FunctionNodeCompare")
	    compare_005_1.name = "Compare.005"
	    compare_005_1.hide = True
	    compare_005_1.data_type = 'FLOAT'
	    compare_005_1.mode = 'ELEMENT'
	    compare_005_1.operation = 'LESS_EQUAL'
	
	    #node Map Range.001
	    map_range_001_1 = clump_hair_curves_001.nodes.new("ShaderNodeMapRange")
	    map_range_001_1.name = "Map Range.001"
	    map_range_001_1.hide = True
	    map_range_001_1.clamp = True
	    map_range_001_1.data_type = 'FLOAT'
	    map_range_001_1.interpolation_type = 'SMOOTHSTEP'
	    map_range_001_1.inputs[3].hide = True
	    map_range_001_1.inputs[4].hide = True
	    map_range_001_1.inputs[5].hide = True
	    map_range_001_1.inputs[6].hide = True
	    map_range_001_1.inputs[7].hide = True
	    map_range_001_1.inputs[8].hide = True
	    map_range_001_1.inputs[9].hide = True
	    map_range_001_1.inputs[10].hide = True
	    map_range_001_1.inputs[11].hide = True
	    map_range_001_1.outputs[1].hide = True
	    #To Min
	    map_range_001_1.inputs[3].default_value = 1.0
	    #To Max
	    map_range_001_1.inputs[4].default_value = 0.0
	
	    #node Boolean Math
	    boolean_math_2 = clump_hair_curves_001.nodes.new("FunctionNodeBooleanMath")
	    boolean_math_2.name = "Boolean Math"
	    boolean_math_2.hide = True
	    boolean_math_2.operation = 'AND'
	
	    #node Switch.004
	    switch_004_1 = clump_hair_curves_001.nodes.new("GeometryNodeSwitch")
	    switch_004_1.name = "Switch.004"
	    switch_004_1.input_type = 'FLOAT'
	
	
	
	
	    #Set parents
	    frame_004_2.parent = frame_006_1
	    capture_attribute_002_2.parent = frame_001_2
	    spline_resolution.parent = frame_001_2
	    set_spline_type_002.parent = frame_001_2
	    reroute_021_1.parent = frame_4
	    switch_006.parent = frame_4
	    compare_004_3.parent = frame_4
	    set_spline_resolution_001.parent = frame_4
	    set_spline_type_001.parent = frame_4
	    group_005.parent = frame_003_2
	    group_input_010_1.parent = frame_003_2
	    vector_math_3.parent = frame_005_1
	    sample_curve.parent = frame_005_1
	    spline_parameter.parent = frame_005_1
	    vector_math_001_3.parent = frame_005_1
	    vector_math_002_2.parent = frame_005_1
	    separate_xyz_1.parent = frame_005_1
	    vector_math_006_2.parent = frame_005_1
	    evaluate_on_domain_1.parent = frame_005_1
	    combine_xyz_1.parent = frame_005_1
	    vector_math_004_3.parent = frame_005_1
	    vector_math_005_1.parent = frame_005_1
	    reroute_4.parent = frame_005_1
	    vector_math_008_2.parent = frame_005_1
	    vector_math_003_2.parent = frame_005_1
	    sample_curve_001_1.parent = frame_005_1
	    evaluate_at_index_3.parent = frame_005_1
	    group_3.parent = frame_005_1
	    reroute_001_4.parent = frame_005_1
	    evaluate_on_domain_001_2.parent = frame_006_1
	    sample_index_1.parent = frame_007_1
	    accumulate_field_002.parent = frame_007_1
	    group_input_002_2.parent = frame_007_1
	    reroute_032.parent = frame_007_1
	    boolean_math_001.parent = frame_007_1
	    switch_001_5.parent = frame_007_1
	    named_attribute_003.parent = frame_007_1
	    group_input_013.parent = frame_007_1
	    group_input_004_2.parent = frame_007_1
	    reroute_006_2.parent = frame_007_1
	    compare_003_2.parent = frame_007_1
	    group_input_011.parent = frame_007_1
	    accumulate_field_1.parent = frame_007_1
	    switch_003_4.parent = frame_007_1
	    compare_001_2.parent = frame_007_1
	    group_003_1.parent = frame_007_1
	    boolean_math_002_2.parent = frame_007_1
	    sample_index_001_1.parent = frame_007_1
	    capture_attribute_001_2.parent = frame_007_1
	    position_1.parent = frame_006_1
	    mix_1.parent = frame_006_1
	    vector_math_009_2.parent = frame_006_1
	    math_002_1.parent = frame_006_1
	    set_position_2.parent = frame_006_1
	    group_input_001_3.parent = frame_006_1
	    math_4.parent = frame_006_1
	    vector_math_013_1.parent = frame_006_1
	    vector_math_007_2.parent = frame_006_1
	    vector_math_011_1.parent = frame_006_1
	    reroute_020_2.parent = frame_006_1
	    math_001_2.parent = frame_006_1
	    reroute_004_3.parent = frame_006_1
	    vector_math_025.parent = frame_002_3
	    switch_002_3.parent = frame_002_3
	    vector_math_020.parent = frame_002_3
	    vector_math_021.parent = frame_002_3
	    vector_math_022.parent = frame_002_3
	    vector_math_015.parent = frame_002_3
	    vector_math_016.parent = frame_002_3
	    vector_math_018.parent = frame_002_3
	    vector_math_019.parent = frame_002_3
	    vector_math_014_1.parent = frame_002_3
	    switch_4.parent = frame_002_3
	    sample_curve_002.parent = frame_002_3
	    reroute_011_2.parent = frame_002_3
	    vector_math_017.parent = frame_002_3
	    random_value_1.parent = frame_002_3
	    vector_math_026.parent = frame_002_3
	    separate_xyz_002_1.parent = frame_002_3
	    separate_xyz_001_1.parent = frame_002_3
	    reroute_009_2.parent = frame_002_3
	    vector_math_012_1.parent = frame_002_3
	    group_input_009_1.parent = frame_002_3
	    group_input_012.parent = frame_002_3
	    group_input_008_1.parent = frame_002_3
	    random_value_001_2.parent = frame_002_3
	    reroute_028_1.parent = frame_002_3
	    evaluate_at_index_001_1.parent = frame_002_3
	    group_006.parent = frame_002_3
	    group_007.parent = frame_002_3
	    random_value_004_1.parent = frame_002_3
	    group_input_005_2.parent = frame_002_3
	    compare_3.parent = frame_002_3
	    compare_002_2.parent = frame_002_3
	    math_003_2.parent = frame_004_2
	    vector_math_010_1.parent = frame_004_2
	    compare_006.parent = frame_004_2
	    compare_007.parent = frame_004_2
	    reroute_030.parent = frame_004_2
	    group_input_007_2.parent = frame_004_2
	    group_input_006_2.parent = frame_004_2
	    compare_005_1.parent = frame_004_2
	    map_range_001_1.parent = frame_004_2
	    boolean_math_2.parent = frame_004_2
	    switch_004_1.parent = frame_004_2
	
	    #Set locations
	    frame_001_2.location = (-7469.0, -30.0)
	    frame_4.location = (-727.3564453125, -106.0)
	    frame_003_2.location = (-1181.0, -157.0)
	    frame_005_1.location = (-4988.0, -297.0)
	    frame_006_1.location = (-2652.0, -121.0)
	    frame_007_1.location = (-6576.0, -63.0)
	    frame_002_3.location = (-4984.310546875, -795.0)
	    frame_004_2.location = (30.0, -220.0)
	    group_input_003_3.location = (-8175.67333984375, 29.46435546875)
	    reroute_014_3.location = (-7339.32568359375, 411.67431640625)
	    reroute_015_3.location = (-7339.32568359375, 371.48828125)
	    reroute_013_3.location = (-7339.32568359375, 331.30224609375)
	    reroute_012_3.location = (-7339.32568359375, 451.860595703125)
	    separate_components_2.location = (-7958.42626953125, 110.1392822265625)
	    group_output_001.location = (75.0, 50.0)
	    join_geometry_001_2.location = (-125.9296875, 50.0)
	    reroute_016_3.location = (-427.3251953125, 391.581298828125)
	    reroute_017_3.location = (-427.3251953125, 351.395263671875)
	    reroute_019_2.location = (-427.3251953125, 311.209228515625)
	    reroute_018_3.location = (-427.3251953125, 271.023193359375)
	    capture_attribute_2.location = (-6837.00048828125, -211.2093505859375)
	    position_001_1.location = (-7037.93017578125, -432.2325439453125)
	    capture_attribute_002_2.location = (210.40673828125, -40.42852783203125)
	    spline_resolution.location = (29.56982421875, -221.26580810546875)
	    set_spline_type_002.location = (390.77099609375, -46.18804931640625)
	    reroute_021_1.location = (35.0, -301.52880859375)
	    switch_006.location = (296.20928955078125, -160.87762451171875)
	    compare_004_3.location = (115.3720703125, -160.87762451171875)
	    set_spline_resolution_001.location = (296.20928955078125, -40.31951904296875)
	    set_spline_type_001.location = (115.3720703125, -40.31951904296875)
	    reroute_025.location = (-3984.263427734375, -200.02154541015625)
	    group_005.location = (230.7830810546875, -39.87579345703125)
	    group_input_010_1.location = (29.852783203125, -120.24789428710938)
	    reroute_003_2.location = (-5089.3798828125, -196.87579345703125)
	    reroute_005_2.location = (-4325.8447265625, -196.87579345703125)
	    reroute_002_2.location = (-5089.3798828125, -237.06182861328125)
	    reroute_010_1.location = (-5350.5888671875, -1583.29443359375)
	    reroute_022_1.location = (-2075.42626953125, -1583.29443359375)
	    reroute_023_1.location = (-5390.77490234375, -1643.573486328125)
	    reroute_024_1.location = (-2035.240234375, -1643.573486328125)
	    vector_math_3.location = (1356.24658203125, -130.533447265625)
	    sample_curve.location = (1155.31640625, -30.068267822265625)
	    spline_parameter.location = (974.006103515625, -116.19989013671875)
	    vector_math_001_3.location = (1536.610595703125, -113.0540771484375)
	    vector_math_002_2.location = (1536.610595703125, -153.24014282226562)
	    separate_xyz_1.location = (1154.84326171875, -213.51919555664062)
	    vector_math_006_2.location = (1717.447998046875, -133.1470947265625)
	    evaluate_on_domain_1.location = (974.006103515625, -213.51919555664062)
	    combine_xyz_1.location = (793.1689453125, -213.51919555664062)
	    vector_math_004_3.location = (612.33154296875, -293.89129638671875)
	    vector_math_005_1.location = (612.33154296875, -253.70526123046875)
	    reroute_4.location = (572.1455078125, -293.89129638671875)
	    vector_math_008_2.location = (391.30859375, -253.70526123046875)
	    vector_math_003_2.location = (391.30859375, -173.33316040039062)
	    sample_curve_001_1.location = (210.47119140625, -133.1470947265625)
	    evaluate_at_index_3.location = (210.47119140625, -273.79827880859375)
	    group_3.location = (29.6337890625, -313.98431396484375)
	    reroute_001_4.location = (170.28515625, -253.70526123046875)
	    reroute_008_2.location = (-4004.3564453125, -237.06182861328125)
	    reroute_007_2.location = (-2919.333251953125, -237.06182861328125)
	    reroute_026_1.location = (-2738.49609375, -96.41070556640625)
	    reroute_027_1.location = (-5.84478759765625, -96.41070556640625)
	    evaluate_on_domain_001_2.location = (194.80615234375, -698.759521484375)
	    sample_index_1.location = (322.6123046875, -85.6318359375)
	    accumulate_field_002.location = (322.6123046875, -125.81787109375)
	    group_input_002_2.location = (322.6123046875, -166.00390625)
	    reroute_032.location = (242.240234375, -186.0970458984375)
	    boolean_math_001.location = (557.375, -91.3914794921875)
	    switch_001_5.location = (959.2353515625, -211.9495849609375)
	    named_attribute_003.location = (55.04931640625, -211.9495849609375)
	    group_input_013.location = (75.142578125, -392.786865234375)
	    group_input_004_2.location = (75.142578125, -332.5078125)
	    reroute_006_2.location = (230.73388671875, -604.3935546875)
	    compare_003_2.location = (291.01318359375, -443.6494140625)
	    group_input_011.location = (29.80419921875, -584.30078125)
	    accumulate_field_1.location = (471.8505859375, -443.6494140625)
	    switch_003_4.location = (960.75, -359.45849609375)
	    compare_001_2.location = (322.6123046875, -45.44580078125)
	    group_003_1.location = (302.51953125, -246.3760986328125)
	    boolean_math_002_2.location = (765.20068359375, -125.9888916015625)
	    sample_index_001_1.location = (632.7431640625, -426.048583984375)
	    reroute_029.location = (-5204.09326171875, -301.3953552246094)
	    capture_attribute_001_2.location = (1170.9765625, -158.023193359375)
	    position_1.location = (863.720947265625, -240.6744384765625)
	    mix_1.location = (1064.651123046875, -160.30233764648438)
	    vector_math_009_2.location = (863.720947265625, -300.9534912109375)
	    math_002_1.location = (863.720947265625, -120.11627197265625)
	    set_position_2.location = (1245.48828125, -39.74420166015625)
	    group_input_001_3.location = (393.505126953125, -115.955322265625)
	    math_4.location = (200.651123046875, -582.255859375)
	    vector_math_013_1.location = (401.581298828125, -642.534912109375)
	    vector_math_007_2.location = (401.581298828125, -602.348876953125)
	    vector_math_011_1.location = (582.41845703125, -622.44189453125)
	    reroute_020_2.location = (160.465087890625, -682.720947265625)
	    math_001_2.location = (631.386474609375, -113.4744873046875)
	    reroute_004_3.location = (39.906982421875, -602.348876953125)
	    vector_math_025.location = (1805.08935546875, -300.1107177734375)
	    switch_002_3.location = (1584.06591796875, -380.4830322265625)
	    vector_math_020.location = (1222.3916015625, -380.4830322265625)
	    vector_math_021.location = (1222.3916015625, -420.6690673828125)
	    vector_math_022.location = (1383.1357421875, -400.5760498046875)
	    vector_math_015.location = (1221.918212890625, -185.31219482421875)
	    vector_math_016.location = (1221.918212890625, -225.49822998046875)
	    vector_math_018.location = (1382.66259765625, -205.40521240234375)
	    vector_math_019.location = (1382.66259765625, -245.59130859375)
	    vector_math_014_1.location = (1221.918212890625, -265.684326171875)
	    switch_4.location = (1583.5927734375, -225.49822998046875)
	    sample_curve_002.location = (960.708984375, -104.9400634765625)
	    reroute_011_2.location = (35.0, -270.18017578125)
	    vector_math_017.location = (1220.995361328125, -131.715087890625)
	    random_value_1.location = (603.92333984375, -280.7939453125)
	    vector_math_026.location = (784.7607421875, -401.35205078125)
	    separate_xyz_002_1.location = (965.59765625, -401.35205078125)
	    separate_xyz_001_1.location = (965.59765625, -260.700927734375)
	    reroute_009_2.location = (724.4814453125, -542.003173828125)
	    vector_math_012_1.location = (784.7607421875, -260.700927734375)
	    group_input_009_1.location = (503.4580078125, -542.003173828125)
	    group_input_012.location = (1206.7138671875, -39.6776123046875)
	    group_input_008_1.location = (603.92333984375, -320.97998046875)
	    random_value_001_2.location = (603.92333984375, -441.5380859375)
	    reroute_028_1.location = (530.4716796875, -361.898681640625)
	    evaluate_at_index_001_1.location = (329.54150390625, -462.3638916015625)
	    group_006.location = (128.611328125, -542.7359619140625)
	    group_007.location = (409.91357421875, -221.24755859375)
	    random_value_004_1.location = (329.54150390625, -301.61962890625)
	    group_input_005_2.location = (148.7041015625, -361.898681640625)
	    compare_3.location = (1387.55126953125, -59.7706298828125)
	    compare_002_2.location = (960.708984375, -567.07958984375)
	    spline_parameter_001.location = (-3013.938720703125, -662.9942016601562)
	    group_input_4.location = (-3013.938720703125, -723.2733154296875)
	    group_001_3.location = (-2833.10205078125, -622.8081665039062)
	    math_003_2.location = (210.736572265625, -180.57012939453125)
	    vector_math_010_1.location = (210.736572265625, -140.38406372070312)
	    compare_006.location = (210.736572265625, -60.011962890625)
	    compare_007.location = (210.736572265625, -100.197998046875)
	    reroute_030.location = (391.57373046875, -180.57012939453125)
	    group_input_007_2.location = (29.8994140625, -180.57012939453125)
	    group_input_006_2.location = (29.8994140625, -120.29104614257812)
	    compare_005_1.location = (431.759765625, -180.57012939453125)
	    map_range_001_1.location = (431.759765625, -140.38406372070312)
	    boolean_math_2.location = (431.759765625, -80.10498046875)
	    switch_004_1.location = (612.596923828125, -39.9189453125)
	
	    #Set dimensions
	    frame_001_2.width, frame_001_2.height = 561.0, 301.0
	    frame_4.width, frame_4.height = 466.3564453125, 339.0
	    frame_003_2.width, frame_003_2.height = 401.0, 254.0
	    frame_005_1.width, frame_005_1.height = 1887.0, 450.0
	    frame_006_1.width, frame_006_1.height = 1415.0, 853.0
	    frame_007_1.width, frame_007_1.height = 1341.0, 666.0
	    frame_002_3.width, frame_002_3.height = 1975.310546875, 651.0
	    frame_004_2.width, frame_004_2.height = 783.0, 359.0
	    group_input_003_3.width, group_input_003_3.height = 140.0, 100.0
	    reroute_014_3.width, reroute_014_3.height = 100.0, 100.0
	    reroute_015_3.width, reroute_015_3.height = 100.0, 100.0
	    reroute_013_3.width, reroute_013_3.height = 100.0, 100.0
	    reroute_012_3.width, reroute_012_3.height = 100.0, 100.0
	    separate_components_2.width, separate_components_2.height = 140.0, 100.0
	    group_output_001.width, group_output_001.height = 140.0, 100.0
	    join_geometry_001_2.width, join_geometry_001_2.height = 140.0, 100.0
	    reroute_016_3.width, reroute_016_3.height = 100.0, 100.0
	    reroute_017_3.width, reroute_017_3.height = 100.0, 100.0
	    reroute_019_2.width, reroute_019_2.height = 100.0, 100.0
	    reroute_018_3.width, reroute_018_3.height = 100.0, 100.0
	    capture_attribute_2.width, capture_attribute_2.height = 140.0, 100.0
	    position_001_1.width, position_001_1.height = 140.0, 100.0
	    capture_attribute_002_2.width, capture_attribute_002_2.height = 140.0, 100.0
	    spline_resolution.width, spline_resolution.height = 140.0, 100.0
	    set_spline_type_002.width, set_spline_type_002.height = 140.0, 100.0
	    reroute_021_1.width, reroute_021_1.height = 100.0, 100.0
	    switch_006.width, switch_006.height = 140.0, 100.0
	    compare_004_3.width, compare_004_3.height = 140.0, 100.0
	    set_spline_resolution_001.width, set_spline_resolution_001.height = 140.0, 100.0
	    set_spline_type_001.width, set_spline_type_001.height = 140.0, 100.0
	    reroute_025.width, reroute_025.height = 100.0, 100.0
	    group_005.width, group_005.height = 140.0, 100.0
	    group_input_010_1.width, group_input_010_1.height = 140.0, 100.0
	    reroute_003_2.width, reroute_003_2.height = 100.0, 100.0
	    reroute_005_2.width, reroute_005_2.height = 100.0, 100.0
	    reroute_002_2.width, reroute_002_2.height = 100.0, 100.0
	    reroute_010_1.width, reroute_010_1.height = 100.0, 100.0
	    reroute_022_1.width, reroute_022_1.height = 100.0, 100.0
	    reroute_023_1.width, reroute_023_1.height = 100.0, 100.0
	    reroute_024_1.width, reroute_024_1.height = 100.0, 100.0
	    vector_math_3.width, vector_math_3.height = 140.0, 100.0
	    sample_curve.width, sample_curve.height = 140.0, 100.0
	    spline_parameter.width, spline_parameter.height = 140.0, 100.0
	    vector_math_001_3.width, vector_math_001_3.height = 140.0, 100.0
	    vector_math_002_2.width, vector_math_002_2.height = 140.0, 100.0
	    separate_xyz_1.width, separate_xyz_1.height = 140.0, 100.0
	    vector_math_006_2.width, vector_math_006_2.height = 140.0, 100.0
	    evaluate_on_domain_1.width, evaluate_on_domain_1.height = 140.0, 100.0
	    combine_xyz_1.width, combine_xyz_1.height = 140.0, 100.0
	    vector_math_004_3.width, vector_math_004_3.height = 140.0, 100.0
	    vector_math_005_1.width, vector_math_005_1.height = 140.0, 100.0
	    reroute_4.width, reroute_4.height = 100.0, 100.0
	    vector_math_008_2.width, vector_math_008_2.height = 140.0, 100.0
	    vector_math_003_2.width, vector_math_003_2.height = 140.0, 100.0
	    sample_curve_001_1.width, sample_curve_001_1.height = 140.0, 100.0
	    evaluate_at_index_3.width, evaluate_at_index_3.height = 140.0, 100.0
	    group_3.width, group_3.height = 140.0, 100.0
	    reroute_001_4.width, reroute_001_4.height = 100.0, 100.0
	    reroute_008_2.width, reroute_008_2.height = 100.0, 100.0
	    reroute_007_2.width, reroute_007_2.height = 100.0, 100.0
	    reroute_026_1.width, reroute_026_1.height = 100.0, 100.0
	    reroute_027_1.width, reroute_027_1.height = 100.0, 100.0
	    evaluate_on_domain_001_2.width, evaluate_on_domain_001_2.height = 140.0, 100.0
	    sample_index_1.width, sample_index_1.height = 140.0, 100.0
	    accumulate_field_002.width, accumulate_field_002.height = 140.0, 100.0
	    group_input_002_2.width, group_input_002_2.height = 140.0, 100.0
	    reroute_032.width, reroute_032.height = 100.0, 100.0
	    boolean_math_001.width, boolean_math_001.height = 140.0, 100.0
	    switch_001_5.width, switch_001_5.height = 140.0, 100.0
	    named_attribute_003.width, named_attribute_003.height = 167.335205078125, 100.0
	    group_input_013.width, group_input_013.height = 140.0, 100.0
	    group_input_004_2.width, group_input_004_2.height = 140.0, 100.0
	    reroute_006_2.width, reroute_006_2.height = 100.0, 100.0
	    compare_003_2.width, compare_003_2.height = 140.0, 100.0
	    group_input_011.width, group_input_011.height = 140.0, 100.0
	    accumulate_field_1.width, accumulate_field_1.height = 140.0, 100.0
	    switch_003_4.width, switch_003_4.height = 140.0, 100.0
	    compare_001_2.width, compare_001_2.height = 140.0, 100.0
	    group_003_1.width, group_003_1.height = 201.331298828125, 100.0
	    boolean_math_002_2.width, boolean_math_002_2.height = 140.0, 100.0
	    sample_index_001_1.width, sample_index_001_1.height = 140.0, 100.0
	    reroute_029.width, reroute_029.height = 100.0, 100.0
	    capture_attribute_001_2.width, capture_attribute_001_2.height = 140.0, 100.0
	    position_1.width, position_1.height = 140.0, 100.0
	    mix_1.width, mix_1.height = 140.0, 100.0
	    vector_math_009_2.width, vector_math_009_2.height = 140.0, 100.0
	    math_002_1.width, math_002_1.height = 140.0, 100.0
	    set_position_2.width, set_position_2.height = 140.0, 100.0
	    group_input_001_3.width, group_input_001_3.height = 140.0, 100.0
	    math_4.width, math_4.height = 140.0, 100.0
	    vector_math_013_1.width, vector_math_013_1.height = 140.0, 100.0
	    vector_math_007_2.width, vector_math_007_2.height = 140.0, 100.0
	    vector_math_011_1.width, vector_math_011_1.height = 140.0, 100.0
	    reroute_020_2.width, reroute_020_2.height = 100.0, 100.0
	    math_001_2.width, math_001_2.height = 140.0, 100.0
	    reroute_004_3.width, reroute_004_3.height = 100.0, 100.0
	    vector_math_025.width, vector_math_025.height = 140.0, 100.0
	    switch_002_3.width, switch_002_3.height = 140.0, 100.0
	    vector_math_020.width, vector_math_020.height = 140.0, 100.0
	    vector_math_021.width, vector_math_021.height = 140.0, 100.0
	    vector_math_022.width, vector_math_022.height = 140.0, 100.0
	    vector_math_015.width, vector_math_015.height = 140.0, 100.0
	    vector_math_016.width, vector_math_016.height = 140.0, 100.0
	    vector_math_018.width, vector_math_018.height = 140.0, 100.0
	    vector_math_019.width, vector_math_019.height = 140.0, 100.0
	    vector_math_014_1.width, vector_math_014_1.height = 140.0, 100.0
	    switch_4.width, switch_4.height = 140.0, 100.0
	    sample_curve_002.width, sample_curve_002.height = 140.0, 100.0
	    reroute_011_2.width, reroute_011_2.height = 100.0, 100.0
	    vector_math_017.width, vector_math_017.height = 140.0, 100.0
	    random_value_1.width, random_value_1.height = 140.0, 100.0
	    vector_math_026.width, vector_math_026.height = 140.0, 100.0
	    separate_xyz_002_1.width, separate_xyz_002_1.height = 140.0, 100.0
	    separate_xyz_001_1.width, separate_xyz_001_1.height = 140.0, 100.0
	    reroute_009_2.width, reroute_009_2.height = 100.0, 100.0
	    vector_math_012_1.width, vector_math_012_1.height = 140.0, 100.0
	    group_input_009_1.width, group_input_009_1.height = 140.0, 100.0
	    group_input_012.width, group_input_012.height = 140.0, 100.0
	    group_input_008_1.width, group_input_008_1.height = 140.0, 100.0
	    random_value_001_2.width, random_value_001_2.height = 140.0, 100.0
	    reroute_028_1.width, reroute_028_1.height = 100.0, 100.0
	    evaluate_at_index_001_1.width, evaluate_at_index_001_1.height = 140.0, 100.0
	    group_006.width, group_006.height = 140.0, 100.0
	    group_007.width, group_007.height = 140.0, 100.0
	    random_value_004_1.width, random_value_004_1.height = 140.0, 100.0
	    group_input_005_2.width, group_input_005_2.height = 140.0, 100.0
	    compare_3.width, compare_3.height = 140.0, 100.0
	    compare_002_2.width, compare_002_2.height = 140.0, 100.0
	    spline_parameter_001.width, spline_parameter_001.height = 140.0, 100.0
	    group_input_4.width, group_input_4.height = 140.0, 100.0
	    group_001_3.width, group_001_3.height = 140.0, 100.0
	    math_003_2.width, math_003_2.height = 140.0, 100.0
	    vector_math_010_1.width, vector_math_010_1.height = 140.0, 100.0
	    compare_006.width, compare_006.height = 140.0, 100.0
	    compare_007.width, compare_007.height = 140.0, 100.0
	    reroute_030.width, reroute_030.height = 100.0, 100.0
	    group_input_007_2.width, group_input_007_2.height = 140.0, 100.0
	    group_input_006_2.width, group_input_006_2.height = 140.0, 100.0
	    compare_005_1.width, compare_005_1.height = 140.0, 100.0
	    map_range_001_1.width, map_range_001_1.height = 140.0, 100.0
	    boolean_math_2.width, boolean_math_2.height = 140.0, 100.0
	    switch_004_1.width, switch_004_1.height = 140.0, 100.0
	
	    #initialize clump_hair_curves_001 links
	    #group_input_003_3.Geometry -> separate_components_2.Geometry
	    clump_hair_curves_001.links.new(group_input_003_3.outputs[0], separate_components_2.inputs[0])
	    #reroute_032.Output -> group_003_1.Geometry
	    clump_hair_curves_001.links.new(reroute_032.outputs[0], group_003_1.inputs[0])
	    #accumulate_field_002.Total -> sample_index_1.Value
	    clump_hair_curves_001.links.new(accumulate_field_002.outputs[2], sample_index_1.inputs[1])
	    #reroute_032.Output -> sample_index_1.Geometry
	    clump_hair_curves_001.links.new(reroute_032.outputs[0], sample_index_1.inputs[0])
	    #named_attribute_003.Exists -> accumulate_field_002.Value
	    clump_hair_curves_001.links.new(named_attribute_003.outputs[1], accumulate_field_002.inputs[0])
	    #sample_index_1.Value -> compare_001_2.A
	    clump_hair_curves_001.links.new(sample_index_1.outputs[0], compare_001_2.inputs[2])
	    #group_003_1.Geometry -> switch_001_5.False
	    clump_hair_curves_001.links.new(group_003_1.outputs[0], switch_001_5.inputs[1])
	    #reroute_032.Output -> switch_001_5.True
	    clump_hair_curves_001.links.new(reroute_032.outputs[0], switch_001_5.inputs[2])
	    #compare_001_2.Result -> boolean_math_001.Boolean
	    clump_hair_curves_001.links.new(compare_001_2.outputs[0], boolean_math_001.inputs[0])
	    #boolean_math_002_2.Boolean -> switch_001_5.Switch
	    clump_hair_curves_001.links.new(boolean_math_002_2.outputs[0], switch_001_5.inputs[0])
	    #reroute_008_2.Output -> sample_curve.Curve Index
	    clump_hair_curves_001.links.new(reroute_008_2.outputs[0], sample_curve.inputs[4])
	    #reroute_025.Output -> sample_curve.Curves
	    clump_hair_curves_001.links.new(reroute_025.outputs[0], sample_curve.inputs[0])
	    #sample_curve.Tangent -> vector_math_3.Vector
	    clump_hair_curves_001.links.new(sample_curve.outputs[2], vector_math_3.inputs[0])
	    #sample_curve.Normal -> vector_math_3.Vector
	    clump_hair_curves_001.links.new(sample_curve.outputs[3], vector_math_3.inputs[1])
	    #sample_curve_001_1.Tangent -> vector_math_003_2.Vector
	    clump_hair_curves_001.links.new(sample_curve_001_1.outputs[2], vector_math_003_2.inputs[0])
	    #sample_curve_001_1.Normal -> vector_math_003_2.Vector
	    clump_hair_curves_001.links.new(sample_curve_001_1.outputs[3], vector_math_003_2.inputs[1])
	    #vector_math_003_2.Vector -> vector_math_004_3.Vector
	    clump_hair_curves_001.links.new(vector_math_003_2.outputs[0], vector_math_004_3.inputs[0])
	    #sample_curve_001_1.Normal -> vector_math_005_1.Vector
	    clump_hair_curves_001.links.new(sample_curve_001_1.outputs[3], vector_math_005_1.inputs[0])
	    #reroute_003_2.Output -> sample_curve_001_1.Curves
	    clump_hair_curves_001.links.new(reroute_003_2.outputs[0], sample_curve_001_1.inputs[0])
	    #reroute_001_4.Output -> sample_curve_001_1.Curve Index
	    clump_hair_curves_001.links.new(reroute_001_4.outputs[0], sample_curve_001_1.inputs[4])
	    #evaluate_on_domain_1.Value -> separate_xyz_1.Vector
	    clump_hair_curves_001.links.new(evaluate_on_domain_1.outputs[0], separate_xyz_1.inputs[0])
	    #sample_curve.Normal -> vector_math_001_3.Vector
	    clump_hair_curves_001.links.new(sample_curve.outputs[3], vector_math_001_3.inputs[0])
	    #separate_xyz_1.X -> vector_math_001_3.Scale
	    clump_hair_curves_001.links.new(separate_xyz_1.outputs[0], vector_math_001_3.inputs[3])
	    #vector_math_3.Vector -> vector_math_002_2.Vector
	    clump_hair_curves_001.links.new(vector_math_3.outputs[0], vector_math_002_2.inputs[0])
	    #separate_xyz_1.Y -> vector_math_002_2.Scale
	    clump_hair_curves_001.links.new(separate_xyz_1.outputs[1], vector_math_002_2.inputs[3])
	    #vector_math_001_3.Vector -> vector_math_006_2.Vector
	    clump_hair_curves_001.links.new(vector_math_001_3.outputs[0], vector_math_006_2.inputs[0])
	    #vector_math_002_2.Vector -> vector_math_006_2.Vector
	    clump_hair_curves_001.links.new(vector_math_002_2.outputs[0], vector_math_006_2.inputs[1])
	    #vector_math_005_1.Value -> combine_xyz_1.X
	    clump_hair_curves_001.links.new(vector_math_005_1.outputs[1], combine_xyz_1.inputs[0])
	    #vector_math_004_3.Value -> combine_xyz_1.Y
	    clump_hair_curves_001.links.new(vector_math_004_3.outputs[1], combine_xyz_1.inputs[1])
	    #combine_xyz_1.Vector -> evaluate_on_domain_1.Value
	    clump_hair_curves_001.links.new(combine_xyz_1.outputs[0], evaluate_on_domain_1.inputs[0])
	    #reroute_4.Output -> vector_math_005_1.Vector
	    clump_hair_curves_001.links.new(reroute_4.outputs[0], vector_math_005_1.inputs[1])
	    #reroute_4.Output -> vector_math_004_3.Vector
	    clump_hair_curves_001.links.new(reroute_4.outputs[0], vector_math_004_3.inputs[1])
	    #group_3.Root Position -> vector_math_008_2.Vector
	    clump_hair_curves_001.links.new(group_3.outputs[1], vector_math_008_2.inputs[0])
	    #group_3.Root Position -> evaluate_at_index_3.Value
	    clump_hair_curves_001.links.new(group_3.outputs[1], evaluate_at_index_3.inputs[1])
	    #evaluate_at_index_3.Value -> vector_math_008_2.Vector
	    clump_hair_curves_001.links.new(evaluate_at_index_3.outputs[0], vector_math_008_2.inputs[1])
	    #reroute_001_4.Output -> evaluate_at_index_3.Index
	    clump_hair_curves_001.links.new(reroute_001_4.outputs[0], evaluate_at_index_3.inputs[0])
	    #reroute_002_2.Output -> reroute_001_4.Input
	    clump_hair_curves_001.links.new(reroute_002_2.outputs[0], reroute_001_4.inputs[0])
	    #mix_1.Result -> set_position_2.Position
	    clump_hair_curves_001.links.new(mix_1.outputs[1], set_position_2.inputs[2])
	    #vector_math_011_1.Vector -> vector_math_009_2.Vector
	    clump_hair_curves_001.links.new(vector_math_011_1.outputs[0], vector_math_009_2.inputs[1])
	    #sample_curve.Position -> vector_math_009_2.Vector
	    clump_hair_curves_001.links.new(sample_curve.outputs[1], vector_math_009_2.inputs[0])
	    #vector_math_006_2.Vector -> vector_math_007_2.Vector
	    clump_hair_curves_001.links.new(vector_math_006_2.outputs[0], vector_math_007_2.inputs[0])
	    #reroute_020_2.Output -> math_4.Value
	    clump_hair_curves_001.links.new(reroute_020_2.outputs[0], math_4.inputs[1])
	    #math_4.Value -> vector_math_007_2.Scale
	    clump_hair_curves_001.links.new(math_4.outputs[0], vector_math_007_2.inputs[3])
	    #vector_math_009_2.Vector -> mix_1.B
	    clump_hair_curves_001.links.new(vector_math_009_2.outputs[0], mix_1.inputs[5])
	    #position_1.Position -> mix_1.A
	    clump_hair_curves_001.links.new(position_1.outputs[0], mix_1.inputs[4])
	    #reroute_029.Output -> reroute_002_2.Input
	    clump_hair_curves_001.links.new(reroute_029.outputs[0], reroute_002_2.inputs[0])
	    #spline_parameter_001.Factor -> group_001_3.Value
	    clump_hair_curves_001.links.new(spline_parameter_001.outputs[0], group_001_3.inputs[0])
	    #group_input_4.Shape -> group_001_3.Shape
	    clump_hair_curves_001.links.new(group_input_4.outputs[6], group_001_3.inputs[3])
	    #group_001_3.Value -> reroute_004_3.Input
	    clump_hair_curves_001.links.new(group_001_3.outputs[0], reroute_004_3.inputs[0])
	    #reroute_004_3.Output -> math_001_2.Value
	    clump_hair_curves_001.links.new(reroute_004_3.outputs[0], math_001_2.inputs[0])
	    #group_input_001_3.Factor -> math_001_2.Value
	    clump_hair_curves_001.links.new(group_input_001_3.outputs[5], math_001_2.inputs[1])
	    #math_002_1.Value -> mix_1.Factor
	    clump_hair_curves_001.links.new(math_002_1.outputs[0], mix_1.inputs[0])
	    #group_input_002_2.Existing Guide Map -> boolean_math_001.Boolean
	    clump_hair_curves_001.links.new(group_input_002_2.outputs[4], boolean_math_001.inputs[1])
	    #group_input_004_2.Guide Distance -> group_003_1.Guide Distance
	    clump_hair_curves_001.links.new(group_input_004_2.outputs[2], group_003_1.inputs[2])
	    #reroute_003_2.Output -> reroute_005_2.Input
	    clump_hair_curves_001.links.new(reroute_003_2.outputs[0], reroute_005_2.inputs[0])
	    #vector_math_008_2.Vector -> reroute_4.Input
	    clump_hair_curves_001.links.new(vector_math_008_2.outputs[0], reroute_4.inputs[0])
	    #math_001_2.Value -> math_002_1.Value
	    clump_hair_curves_001.links.new(math_001_2.outputs[0], math_002_1.inputs[0])
	    #vector_math_008_2.Vector -> vector_math_010_1.Vector
	    clump_hair_curves_001.links.new(vector_math_008_2.outputs[0], vector_math_010_1.inputs[0])
	    #vector_math_010_1.Value -> map_range_001_1.Value
	    clump_hair_curves_001.links.new(vector_math_010_1.outputs[1], map_range_001_1.inputs[0])
	    #switch_004_1.Output -> math_002_1.Value
	    clump_hair_curves_001.links.new(switch_004_1.outputs[0], math_002_1.inputs[1])
	    #reroute_030.Output -> map_range_001_1.From Min
	    clump_hair_curves_001.links.new(reroute_030.outputs[0], map_range_001_1.inputs[1])
	    #group_input_006_2.Distance Threshold -> math_003_2.Value
	    clump_hair_curves_001.links.new(group_input_006_2.outputs[10], math_003_2.inputs[0])
	    #group_input_007_2.Distance Falloff -> math_003_2.Value
	    clump_hair_curves_001.links.new(group_input_007_2.outputs[9], math_003_2.inputs[1])
	    #math_003_2.Value -> map_range_001_1.From Max
	    clump_hair_curves_001.links.new(math_003_2.outputs[0], map_range_001_1.inputs[2])
	    #group_input_008_1.Tip Spread -> vector_math_012_1.Scale
	    clump_hair_curves_001.links.new(group_input_008_1.outputs[7], vector_math_012_1.inputs[3])
	    #random_value_1.Value -> vector_math_012_1.Vector
	    clump_hair_curves_001.links.new(random_value_1.outputs[0], vector_math_012_1.inputs[0])
	    #evaluate_on_domain_001_2.Value -> vector_math_013_1.Vector
	    clump_hair_curves_001.links.new(evaluate_on_domain_001_2.outputs[0], vector_math_013_1.inputs[0])
	    #reroute_020_2.Output -> vector_math_013_1.Scale
	    clump_hair_curves_001.links.new(reroute_020_2.outputs[0], vector_math_013_1.inputs[3])
	    #vector_math_007_2.Vector -> vector_math_011_1.Vector
	    clump_hair_curves_001.links.new(vector_math_007_2.outputs[0], vector_math_011_1.inputs[0])
	    #reroute_005_2.Output -> sample_curve_002.Curves
	    clump_hair_curves_001.links.new(reroute_005_2.outputs[0], sample_curve_002.inputs[0])
	    #vector_math_012_1.Vector -> separate_xyz_001_1.Vector
	    clump_hair_curves_001.links.new(vector_math_012_1.outputs[0], separate_xyz_001_1.inputs[0])
	    #sample_curve_002.Tangent -> vector_math_014_1.Vector
	    clump_hair_curves_001.links.new(sample_curve_002.outputs[2], vector_math_014_1.inputs[0])
	    #sample_curve_002.Normal -> vector_math_015.Vector
	    clump_hair_curves_001.links.new(sample_curve_002.outputs[3], vector_math_015.inputs[0])
	    #separate_xyz_001_1.Z -> vector_math_014_1.Scale
	    clump_hair_curves_001.links.new(separate_xyz_001_1.outputs[2], vector_math_014_1.inputs[3])
	    #separate_xyz_001_1.X -> vector_math_015.Scale
	    clump_hair_curves_001.links.new(separate_xyz_001_1.outputs[0], vector_math_015.inputs[3])
	    #sample_curve_002.Tangent -> vector_math_017.Vector
	    clump_hair_curves_001.links.new(sample_curve_002.outputs[2], vector_math_017.inputs[0])
	    #sample_curve_002.Normal -> vector_math_017.Vector
	    clump_hair_curves_001.links.new(sample_curve_002.outputs[3], vector_math_017.inputs[1])
	    #separate_xyz_001_1.Y -> vector_math_016.Scale
	    clump_hair_curves_001.links.new(separate_xyz_001_1.outputs[1], vector_math_016.inputs[3])
	    #vector_math_017.Vector -> vector_math_016.Vector
	    clump_hair_curves_001.links.new(vector_math_017.outputs[0], vector_math_016.inputs[0])
	    #vector_math_015.Vector -> vector_math_018.Vector
	    clump_hair_curves_001.links.new(vector_math_015.outputs[0], vector_math_018.inputs[0])
	    #vector_math_016.Vector -> vector_math_018.Vector
	    clump_hair_curves_001.links.new(vector_math_016.outputs[0], vector_math_018.inputs[1])
	    #vector_math_018.Vector -> vector_math_019.Vector
	    clump_hair_curves_001.links.new(vector_math_018.outputs[0], vector_math_019.inputs[0])
	    #vector_math_014_1.Vector -> vector_math_019.Vector
	    clump_hair_curves_001.links.new(vector_math_014_1.outputs[0], vector_math_019.inputs[1])
	    #reroute_011_2.Output -> sample_curve_002.Curve Index
	    clump_hair_curves_001.links.new(reroute_011_2.outputs[0], sample_curve_002.inputs[4])
	    #vector_math_026.Vector -> separate_xyz_002_1.Vector
	    clump_hair_curves_001.links.new(vector_math_026.outputs[0], separate_xyz_002_1.inputs[0])
	    #sample_curve_002.Normal -> vector_math_020.Vector
	    clump_hair_curves_001.links.new(sample_curve_002.outputs[3], vector_math_020.inputs[0])
	    #separate_xyz_002_1.X -> vector_math_020.Scale
	    clump_hair_curves_001.links.new(separate_xyz_002_1.outputs[0], vector_math_020.inputs[3])
	    #separate_xyz_002_1.Y -> vector_math_021.Scale
	    clump_hair_curves_001.links.new(separate_xyz_002_1.outputs[1], vector_math_021.inputs[3])
	    #vector_math_020.Vector -> vector_math_022.Vector
	    clump_hair_curves_001.links.new(vector_math_020.outputs[0], vector_math_022.inputs[0])
	    #vector_math_021.Vector -> vector_math_022.Vector
	    clump_hair_curves_001.links.new(vector_math_021.outputs[0], vector_math_022.inputs[1])
	    #vector_math_017.Vector -> vector_math_021.Vector
	    clump_hair_curves_001.links.new(vector_math_017.outputs[0], vector_math_021.inputs[0])
	    #random_value_001_2.Value -> vector_math_026.Vector
	    clump_hair_curves_001.links.new(random_value_001_2.outputs[0], vector_math_026.inputs[0])
	    #reroute_009_2.Output -> vector_math_026.Scale
	    clump_hair_curves_001.links.new(reroute_009_2.outputs[0], vector_math_026.inputs[3])
	    #vector_math_013_1.Vector -> vector_math_011_1.Vector
	    clump_hair_curves_001.links.new(vector_math_013_1.outputs[0], vector_math_011_1.inputs[1])
	    #switch_4.Output -> vector_math_025.Vector
	    clump_hair_curves_001.links.new(switch_4.outputs[0], vector_math_025.inputs[0])
	    #switch_002_3.Output -> vector_math_025.Vector
	    clump_hair_curves_001.links.new(switch_002_3.outputs[0], vector_math_025.inputs[1])
	    #vector_math_025.Vector -> evaluate_on_domain_001_2.Value
	    clump_hair_curves_001.links.new(vector_math_025.outputs[0], evaluate_on_domain_001_2.inputs[0])
	    #vector_math_022.Vector -> switch_002_3.False
	    clump_hair_curves_001.links.new(vector_math_022.outputs[0], switch_002_3.inputs[1])
	    #vector_math_019.Vector -> switch_4.False
	    clump_hair_curves_001.links.new(vector_math_019.outputs[0], switch_4.inputs[1])
	    #reroute_009_2.Output -> compare_002_2.B
	    clump_hair_curves_001.links.new(reroute_009_2.outputs[0], compare_002_2.inputs[1])
	    #compare_002_2.Result -> switch_002_3.Switch
	    clump_hair_curves_001.links.new(compare_002_2.outputs[0], switch_002_3.inputs[0])
	    #group_input_009_1.Clump Offset -> reroute_009_2.Input
	    clump_hair_curves_001.links.new(group_input_009_1.outputs[8], reroute_009_2.inputs[0])
	    #reroute_028_1.Output -> random_value_1.Seed
	    clump_hair_curves_001.links.new(reroute_028_1.outputs[0], random_value_1.inputs[8])
	    #reroute_028_1.Output -> random_value_001_2.Seed
	    clump_hair_curves_001.links.new(reroute_028_1.outputs[0], random_value_001_2.inputs[8])
	    #reroute_011_2.Output -> evaluate_at_index_001_1.Index
	    clump_hair_curves_001.links.new(reroute_011_2.outputs[0], evaluate_at_index_001_1.inputs[0])
	    #capture_attribute_2.Geometry -> reroute_032.Input
	    clump_hair_curves_001.links.new(capture_attribute_2.outputs[0], reroute_032.inputs[0])
	    #capture_attribute_001_2.Geometry -> reroute_003_2.Input
	    clump_hair_curves_001.links.new(capture_attribute_001_2.outputs[0], reroute_003_2.inputs[0])
	    #reroute_018_3.Output -> join_geometry_001_2.Geometry
	    clump_hair_curves_001.links.new(reroute_018_3.outputs[0], join_geometry_001_2.inputs[0])
	    #separate_components_2.Mesh -> reroute_012_3.Input
	    clump_hair_curves_001.links.new(separate_components_2.outputs[0], reroute_012_3.inputs[0])
	    #separate_components_2.Instances -> reroute_013_3.Input
	    clump_hair_curves_001.links.new(separate_components_2.outputs[5], reroute_013_3.inputs[0])
	    #separate_components_2.Point Cloud -> reroute_014_3.Input
	    clump_hair_curves_001.links.new(separate_components_2.outputs[3], reroute_014_3.inputs[0])
	    #separate_components_2.Volume -> reroute_015_3.Input
	    clump_hair_curves_001.links.new(separate_components_2.outputs[4], reroute_015_3.inputs[0])
	    #join_geometry_001_2.Geometry -> group_output_001.Geometry
	    clump_hair_curves_001.links.new(join_geometry_001_2.outputs[0], group_output_001.inputs[0])
	    #reroute_012_3.Output -> reroute_016_3.Input
	    clump_hair_curves_001.links.new(reroute_012_3.outputs[0], reroute_016_3.inputs[0])
	    #reroute_014_3.Output -> reroute_017_3.Input
	    clump_hair_curves_001.links.new(reroute_014_3.outputs[0], reroute_017_3.inputs[0])
	    #reroute_013_3.Output -> reroute_018_3.Input
	    clump_hair_curves_001.links.new(reroute_013_3.outputs[0], reroute_018_3.inputs[0])
	    #reroute_015_3.Output -> reroute_019_2.Input
	    clump_hair_curves_001.links.new(reroute_015_3.outputs[0], reroute_019_2.inputs[0])
	    #set_position_2.Geometry -> group_005.Curves
	    clump_hair_curves_001.links.new(set_position_2.outputs[0], group_005.inputs[0])
	    #position_001_1.Position -> capture_attribute_2.Value
	    clump_hair_curves_001.links.new(position_001_1.outputs[0], capture_attribute_2.inputs[1])
	    #reroute_022_1.Output -> group_005.Reference Position
	    clump_hair_curves_001.links.new(reroute_022_1.outputs[0], group_005.inputs[3])
	    #group_input_010_1.Preserve Length -> group_005.Selection
	    clump_hair_curves_001.links.new(group_input_010_1.outputs[12], group_005.inputs[1])
	    #spline_parameter.Factor -> sample_curve.Factor
	    clump_hair_curves_001.links.new(spline_parameter.outputs[0], sample_curve.inputs[2])
	    #reroute_006_2.Output -> compare_003_2.A
	    clump_hair_curves_001.links.new(reroute_006_2.outputs[0], compare_003_2.inputs[2])
	    #named_attribute_003.Attribute -> switch_003_4.False
	    clump_hair_curves_001.links.new(named_attribute_003.outputs[0], switch_003_4.inputs[1])
	    #compare_003_2.Result -> switch_003_4.Switch
	    clump_hair_curves_001.links.new(compare_003_2.outputs[0], switch_003_4.inputs[0])
	    #reroute_006_2.Output -> switch_003_4.True
	    clump_hair_curves_001.links.new(reroute_006_2.outputs[0], switch_003_4.inputs[2])
	    #boolean_math_001.Boolean -> boolean_math_002_2.Boolean
	    clump_hair_curves_001.links.new(boolean_math_001.outputs[0], boolean_math_002_2.inputs[0])
	    #reroute_027_1.Output -> group_output_001.Guide Index
	    clump_hair_curves_001.links.new(reroute_027_1.outputs[0], group_output_001.inputs[1])
	    #separate_components_2.Curve -> capture_attribute_002_2.Geometry
	    clump_hair_curves_001.links.new(separate_components_2.outputs[1], capture_attribute_002_2.inputs[0])
	    #spline_resolution.Resolution -> capture_attribute_002_2.Value
	    clump_hair_curves_001.links.new(spline_resolution.outputs[0], capture_attribute_002_2.inputs[1])
	    #set_spline_type_001.Curve -> set_spline_resolution_001.Geometry
	    clump_hair_curves_001.links.new(set_spline_type_001.outputs[0], set_spline_resolution_001.inputs[0])
	    #set_spline_type_002.Curve -> capture_attribute_2.Geometry
	    clump_hair_curves_001.links.new(set_spline_type_002.outputs[0], capture_attribute_2.inputs[0])
	    #group_006.Curve ID -> evaluate_at_index_001_1.Value
	    clump_hair_curves_001.links.new(group_006.outputs[1], evaluate_at_index_001_1.inputs[1])
	    #evaluate_at_index_001_1.Value -> random_value_001_2.ID
	    clump_hair_curves_001.links.new(evaluate_at_index_001_1.outputs[0], random_value_001_2.inputs[7])
	    #group_007.Curve ID -> random_value_1.ID
	    clump_hair_curves_001.links.new(group_007.outputs[1], random_value_1.inputs[7])
	    #group_input_013.Guide Mask -> group_003_1.Guide Mask
	    clump_hair_curves_001.links.new(group_input_013.outputs[3], group_003_1.inputs[3])
	    #reroute_021_1.Output -> compare_004_3.A
	    clump_hair_curves_001.links.new(reroute_021_1.outputs[0], compare_004_3.inputs[2])
	    #compare_004_3.Result -> switch_006.Switch
	    clump_hair_curves_001.links.new(compare_004_3.outputs[0], switch_006.inputs[0])
	    #reroute_021_1.Output -> switch_006.False
	    clump_hair_curves_001.links.new(reroute_021_1.outputs[0], switch_006.inputs[1])
	    #group_005.Curves -> set_spline_type_001.Curve
	    clump_hair_curves_001.links.new(group_005.outputs[0], set_spline_type_001.inputs[0])
	    #reroute_024_1.Output -> reroute_021_1.Input
	    clump_hair_curves_001.links.new(reroute_024_1.outputs[0], reroute_021_1.inputs[0])
	    #switch_006.Output -> set_spline_resolution_001.Resolution
	    clump_hair_curves_001.links.new(switch_006.outputs[0], set_spline_resolution_001.inputs[2])
	    #capture_attribute_002_2.Geometry -> set_spline_type_002.Curve
	    clump_hair_curves_001.links.new(capture_attribute_002_2.outputs[0], set_spline_type_002.inputs[0])
	    #compare_003_2.Result -> accumulate_field_1.Value
	    clump_hair_curves_001.links.new(compare_003_2.outputs[0], accumulate_field_1.inputs[0])
	    #accumulate_field_1.Total -> sample_index_001_1.Value
	    clump_hair_curves_001.links.new(accumulate_field_1.outputs[2], sample_index_001_1.inputs[1])
	    #reroute_032.Output -> sample_index_001_1.Geometry
	    clump_hair_curves_001.links.new(reroute_032.outputs[0], sample_index_001_1.inputs[0])
	    #sample_index_001_1.Value -> boolean_math_002_2.Boolean
	    clump_hair_curves_001.links.new(sample_index_001_1.outputs[0], boolean_math_002_2.inputs[1])
	    #group_input_011.Guide Index -> reroute_006_2.Input
	    clump_hair_curves_001.links.new(group_input_011.outputs[1], reroute_006_2.inputs[0])
	    #reroute_002_2.Output -> reroute_008_2.Input
	    clump_hair_curves_001.links.new(reroute_002_2.outputs[0], reroute_008_2.inputs[0])
	    #reroute_004_3.Output -> reroute_020_2.Input
	    clump_hair_curves_001.links.new(reroute_004_3.outputs[0], reroute_020_2.inputs[0])
	    #reroute_025.Output -> set_position_2.Geometry
	    clump_hair_curves_001.links.new(reroute_025.outputs[0], set_position_2.inputs[0])
	    #reroute_029.Output -> reroute_011_2.Input
	    clump_hair_curves_001.links.new(reroute_029.outputs[0], reroute_011_2.inputs[0])
	    #capture_attribute_2.Value -> reroute_010_1.Input
	    clump_hair_curves_001.links.new(capture_attribute_2.outputs[1], reroute_010_1.inputs[0])
	    #reroute_010_1.Output -> reroute_022_1.Input
	    clump_hair_curves_001.links.new(reroute_010_1.outputs[0], reroute_022_1.inputs[0])
	    #capture_attribute_002_2.Value -> reroute_023_1.Input
	    clump_hair_curves_001.links.new(capture_attribute_002_2.outputs[1], reroute_023_1.inputs[0])
	    #reroute_023_1.Output -> reroute_024_1.Input
	    clump_hair_curves_001.links.new(reroute_023_1.outputs[0], reroute_024_1.inputs[0])
	    #reroute_005_2.Output -> reroute_025.Input
	    clump_hair_curves_001.links.new(reroute_005_2.outputs[0], reroute_025.inputs[0])
	    #group_input_012.Tip Spread -> compare_3.A
	    clump_hair_curves_001.links.new(group_input_012.outputs[7], compare_3.inputs[0])
	    #compare_3.Result -> switch_4.Switch
	    clump_hair_curves_001.links.new(compare_3.outputs[0], switch_4.inputs[0])
	    #reroute_008_2.Output -> reroute_007_2.Input
	    clump_hair_curves_001.links.new(reroute_008_2.outputs[0], reroute_007_2.inputs[0])
	    #reroute_007_2.Output -> reroute_026_1.Input
	    clump_hair_curves_001.links.new(reroute_007_2.outputs[0], reroute_026_1.inputs[0])
	    #reroute_026_1.Output -> reroute_027_1.Input
	    clump_hair_curves_001.links.new(reroute_026_1.outputs[0], reroute_027_1.inputs[0])
	    #random_value_004_1.Value -> reroute_028_1.Input
	    clump_hair_curves_001.links.new(random_value_004_1.outputs[2], reroute_028_1.inputs[0])
	    #group_input_005_2.Seed -> random_value_004_1.ID
	    clump_hair_curves_001.links.new(group_input_005_2.outputs[11], random_value_004_1.inputs[7])
	    #switch_001_5.Output -> capture_attribute_001_2.Geometry
	    clump_hair_curves_001.links.new(switch_001_5.outputs[0], capture_attribute_001_2.inputs[0])
	    #switch_003_4.Output -> capture_attribute_001_2.Value
	    clump_hair_curves_001.links.new(switch_003_4.outputs[0], capture_attribute_001_2.inputs[1])
	    #capture_attribute_001_2.Value -> reroute_029.Input
	    clump_hair_curves_001.links.new(capture_attribute_001_2.outputs[1], reroute_029.inputs[0])
	    #map_range_001_1.Result -> switch_004_1.False
	    clump_hair_curves_001.links.new(map_range_001_1.outputs[0], switch_004_1.inputs[1])
	    #vector_math_010_1.Value -> compare_005_1.A
	    clump_hair_curves_001.links.new(vector_math_010_1.outputs[1], compare_005_1.inputs[0])
	    #compare_005_1.Result -> switch_004_1.True
	    clump_hair_curves_001.links.new(compare_005_1.outputs[0], switch_004_1.inputs[2])
	    #reroute_030.Output -> compare_005_1.B
	    clump_hair_curves_001.links.new(reroute_030.outputs[0], compare_005_1.inputs[1])
	    #group_input_006_2.Distance Threshold -> compare_006.A
	    clump_hair_curves_001.links.new(group_input_006_2.outputs[10], compare_006.inputs[0])
	    #group_input_007_2.Distance Falloff -> compare_007.A
	    clump_hair_curves_001.links.new(group_input_007_2.outputs[9], compare_007.inputs[0])
	    #compare_006.Result -> boolean_math_2.Boolean
	    clump_hair_curves_001.links.new(compare_006.outputs[0], boolean_math_2.inputs[0])
	    #compare_007.Result -> boolean_math_2.Boolean
	    clump_hair_curves_001.links.new(compare_007.outputs[0], boolean_math_2.inputs[1])
	    #boolean_math_2.Boolean -> switch_004_1.Switch
	    clump_hair_curves_001.links.new(boolean_math_2.outputs[0], switch_004_1.inputs[0])
	    #group_input_006_2.Distance Threshold -> reroute_030.Input
	    clump_hair_curves_001.links.new(group_input_006_2.outputs[10], reroute_030.inputs[0])
	    #reroute_019_2.Output -> join_geometry_001_2.Geometry
	    clump_hair_curves_001.links.new(reroute_019_2.outputs[0], join_geometry_001_2.inputs[0])
	    #set_spline_resolution_001.Geometry -> join_geometry_001_2.Geometry
	    clump_hair_curves_001.links.new(set_spline_resolution_001.outputs[0], join_geometry_001_2.inputs[0])
	    #reroute_017_3.Output -> join_geometry_001_2.Geometry
	    clump_hair_curves_001.links.new(reroute_017_3.outputs[0], join_geometry_001_2.inputs[0])
	    #reroute_016_3.Output -> join_geometry_001_2.Geometry
	    clump_hair_curves_001.links.new(reroute_016_3.outputs[0], join_geometry_001_2.inputs[0])
	    return clump_hair_curves_001
	
	clump_hair_curves_001 = clump_hair_curves_001_node_group()
	
	#initialize hair_shrinkwrap node group
	def hair_shrinkwrap_node_group():
	    hair_shrinkwrap = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Hair_Shrinkwrap")
	
	    hair_shrinkwrap.color_tag = 'NONE'
	    hair_shrinkwrap.description = ""
	    hair_shrinkwrap.default_group_node_width = 140
	    
	
	    hair_shrinkwrap.is_modifier = True
	
	    #hair_shrinkwrap interface
	    #Socket Geometry
	    geometry_socket_6 = hair_shrinkwrap.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_6.attribute_domain = 'POINT'
	
	    #Socket Geometry
	    geometry_socket_7 = hair_shrinkwrap.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_7.attribute_domain = 'POINT'
	
	    #Socket Surface
	    surface_socket = hair_shrinkwrap.interface.new_socket(name = "Surface", in_out='INPUT', socket_type = 'NodeSocketObject')
	    surface_socket.attribute_domain = 'POINT'
	
	    #Socket Offset
	    offset_socket = hair_shrinkwrap.interface.new_socket(name = "Offset", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    offset_socket.default_value = 0.0010000000474974513
	    offset_socket.min_value = 0.0
	    offset_socket.max_value = 10000.0
	    offset_socket.subtype = 'NONE'
	    offset_socket.attribute_domain = 'POINT'
	
	
	    #initialize hair_shrinkwrap nodes
	    #node Group Input
	    group_input_5 = hair_shrinkwrap.nodes.new("NodeGroupInput")
	    group_input_5.name = "Group Input"
	
	    #node Group Output
	    group_output_8 = hair_shrinkwrap.nodes.new("NodeGroupOutput")
	    group_output_8.name = "Group Output"
	    group_output_8.is_active_output = True
	
	    #node Object Info
	    object_info = hair_shrinkwrap.nodes.new("GeometryNodeObjectInfo")
	    object_info.name = "Object Info"
	    object_info.hide = True
	    object_info.transform_space = 'RELATIVE'
	    #As Instance
	    object_info.inputs[1].default_value = False
	
	    #node Geometry Proximity
	    geometry_proximity = hair_shrinkwrap.nodes.new("GeometryNodeProximity")
	    geometry_proximity.name = "Geometry Proximity"
	    geometry_proximity.hide = True
	    geometry_proximity.target_element = 'FACES'
	    #Group ID
	    geometry_proximity.inputs[1].default_value = 0
	    #Sample Group ID
	    geometry_proximity.inputs[3].default_value = 0
	
	    #node Capture Attribute
	    capture_attribute_3 = hair_shrinkwrap.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_3.name = "Capture Attribute"
	    capture_attribute_3.hide = True
	    capture_attribute_3.active_index = 0
	    capture_attribute_3.capture_items.clear()
	    capture_attribute_3.capture_items.new('FLOAT', "Position")
	    capture_attribute_3.capture_items["Position"].data_type = 'FLOAT_VECTOR'
	    capture_attribute_3.domain = 'POINT'
	
	    #node Position
	    position_2 = hair_shrinkwrap.nodes.new("GeometryNodeInputPosition")
	    position_2.name = "Position"
	    position_2.hide = True
	
	    #node Set Position
	    set_position_3 = hair_shrinkwrap.nodes.new("GeometryNodeSetPosition")
	    set_position_3.name = "Set Position"
	    set_position_3.hide = True
	    #Offset
	    set_position_3.inputs[3].default_value = (0.0, 0.0, 0.0)
	
	    #node Vector Math
	    vector_math_4 = hair_shrinkwrap.nodes.new("ShaderNodeVectorMath")
	    vector_math_4.name = "Vector Math"
	    vector_math_4.hide = True
	    vector_math_4.operation = 'SUBTRACT'
	
	    #node Vector Math.001
	    vector_math_001_4 = hair_shrinkwrap.nodes.new("ShaderNodeVectorMath")
	    vector_math_001_4.name = "Vector Math.001"
	    vector_math_001_4.hide = True
	    vector_math_001_4.operation = 'ADD'
	
	    #node Vector Math.002
	    vector_math_002_3 = hair_shrinkwrap.nodes.new("ShaderNodeVectorMath")
	    vector_math_002_3.name = "Vector Math.002"
	    vector_math_002_3.hide = True
	    vector_math_002_3.operation = 'NORMALIZE'
	
	    #node Vector Math.003
	    vector_math_003_3 = hair_shrinkwrap.nodes.new("ShaderNodeVectorMath")
	    vector_math_003_3.name = "Vector Math.003"
	    vector_math_003_3.hide = True
	    vector_math_003_3.operation = 'SCALE'
	
	    #node Reroute
	    reroute_5 = hair_shrinkwrap.nodes.new("NodeReroute")
	    reroute_5.name = "Reroute"
	    reroute_5.socket_idname = "NodeSocketVector"
	    #node Reroute.001
	    reroute_001_5 = hair_shrinkwrap.nodes.new("NodeReroute")
	    reroute_001_5.name = "Reroute.001"
	    reroute_001_5.socket_idname = "NodeSocketVector"
	    #node Reroute.002
	    reroute_002_3 = hair_shrinkwrap.nodes.new("NodeReroute")
	    reroute_002_3.name = "Reroute.002"
	    reroute_002_3.socket_idname = "NodeSocketVector"
	    #node Reroute.003
	    reroute_003_3 = hair_shrinkwrap.nodes.new("NodeReroute")
	    reroute_003_3.name = "Reroute.003"
	    reroute_003_3.socket_idname = "NodeSocketVector"
	    #node Frame
	    frame_5 = hair_shrinkwrap.nodes.new("NodeFrame")
	    frame_5.name = "Frame"
	    frame_5.label_size = 20
	    frame_5.shrink = True
	
	    #node Reroute.004
	    reroute_004_4 = hair_shrinkwrap.nodes.new("NodeReroute")
	    reroute_004_4.name = "Reroute.004"
	    reroute_004_4.socket_idname = "NodeSocketFloat"
	    #node Reroute.005
	    reroute_005_3 = hair_shrinkwrap.nodes.new("NodeReroute")
	    reroute_005_3.name = "Reroute.005"
	    reroute_005_3.socket_idname = "NodeSocketFloat"
	    #node Reroute.006
	    reroute_006_3 = hair_shrinkwrap.nodes.new("NodeReroute")
	    reroute_006_3.name = "Reroute.006"
	    reroute_006_3.socket_idname = "NodeSocketVector"
	    #node Reroute.007
	    reroute_007_3 = hair_shrinkwrap.nodes.new("NodeReroute")
	    reroute_007_3.name = "Reroute.007"
	    reroute_007_3.socket_idname = "NodeSocketVector"
	    #node Group
	    group_4 = hair_shrinkwrap.nodes.new("GeometryNodeGroup")
	    group_4.name = "Group"
	    group_4.hide = True
	    group_4.node_tree = curve_root_006
	
	    #node Boolean Math
	    boolean_math_3 = hair_shrinkwrap.nodes.new("FunctionNodeBooleanMath")
	    boolean_math_3.name = "Boolean Math"
	    boolean_math_3.hide = True
	    boolean_math_3.operation = 'NOT'
	
	    #node Set Position.001
	    set_position_001_3 = hair_shrinkwrap.nodes.new("GeometryNodeSetPosition")
	    set_position_001_3.name = "Set Position.001"
	    set_position_001_3.hide = True
	    #Offset
	    set_position_001_3.inputs[3].default_value = (0.0, 0.0, 0.0)
	
	    #node Geometry Proximity.001
	    geometry_proximity_001 = hair_shrinkwrap.nodes.new("GeometryNodeProximity")
	    geometry_proximity_001.name = "Geometry Proximity.001"
	    geometry_proximity_001.hide = True
	    geometry_proximity_001.target_element = 'FACES'
	    #Group ID
	    geometry_proximity_001.inputs[1].default_value = 0
	    #Sample Group ID
	    geometry_proximity_001.inputs[3].default_value = 0
	
	    #node Reroute.008
	    reroute_008_3 = hair_shrinkwrap.nodes.new("NodeReroute")
	    reroute_008_3.name = "Reroute.008"
	    reroute_008_3.socket_idname = "NodeSocketGeometry"
	    #node Reroute.009
	    reroute_009_3 = hair_shrinkwrap.nodes.new("NodeReroute")
	    reroute_009_3.name = "Reroute.009"
	    reroute_009_3.socket_idname = "NodeSocketGeometry"
	    #node Reroute.010
	    reroute_010_2 = hair_shrinkwrap.nodes.new("NodeReroute")
	    reroute_010_2.name = "Reroute.010"
	    reroute_010_2.socket_idname = "NodeSocketVector"
	    #node Reroute.011
	    reroute_011_3 = hair_shrinkwrap.nodes.new("NodeReroute")
	    reroute_011_3.name = "Reroute.011"
	    reroute_011_3.socket_idname = "NodeSocketBool"
	    #node Reroute.012
	    reroute_012_4 = hair_shrinkwrap.nodes.new("NodeReroute")
	    reroute_012_4.name = "Reroute.012"
	    reroute_012_4.socket_idname = "NodeSocketVector"
	
	
	
	    #Set parents
	    vector_math_4.parent = frame_5
	    vector_math_002_3.parent = frame_5
	    vector_math_003_3.parent = frame_5
	
	    #Set locations
	    group_input_5.location = (-340.0, 0.0)
	    group_output_8.location = (1026.4234619140625, -23.50284194946289)
	    object_info.location = (-125.76961517333984, -56.2663688659668)
	    geometry_proximity.location = (246.0714874267578, -85.30731201171875)
	    capture_attribute_3.location = (34.87336349487305, -33.59607696533203)
	    position_2.location = (32.304588317871094, 20.49018096923828)
	    set_position_3.location = (598.3317260742188, -37.141319274902344)
	    vector_math_4.location = (30.407257080078125, -35.01246643066406)
	    vector_math_001_4.location = (599.7997436523438, -80.27210998535156)
	    vector_math_002_3.location = (32.039337158203125, -69.37770080566406)
	    vector_math_003_3.location = (33.671234130859375, -103.74295043945312)
	    reroute_5.location = (198.13858032226562, -44.358219146728516)
	    reroute_001_5.location = (199.3470001220703, -194.38702392578125)
	    reroute_002_3.location = (198.45127868652344, -101.33867645263672)
	    reroute_003_3.location = (399.9706115722656, -85.22796630859375)
	    frame_5.location = (381.7059020996094, -153.26470947265625)
	    reroute_004_4.location = (-170.80995178222656, -77.34846496582031)
	    reroute_005_3.location = (-167.71401977539062, -278.49591064453125)
	    reroute_006_3.location = (402.7818908691406, -207.76275634765625)
	    reroute_007_3.location = (603.0008544921875, -266.2869567871094)
	    group_4.location = (593.760986328125, 53.11892318725586)
	    boolean_math_3.location = (598.4335327148438, 16.009042739868164)
	    set_position_001_3.location = (843.1641235351562, -48.994876861572266)
	    geometry_proximity_001.location = (840.4232177734375, -119.17461395263672)
	    reroute_008_3.location = (45.334922790527344, -84.02496337890625)
	    reroute_009_3.location = (45.33495330810547, -119.9047622680664)
	    reroute_010_2.location = (783.8638916015625, 46.56462478637695)
	    reroute_011_3.location = (839.1802978515625, 56.635406494140625)
	    reroute_012_4.location = (789.7108154296875, -135.4138641357422)
	
	    #Set dimensions
	    group_input_5.width, group_input_5.height = 140.0, 100.0
	    group_output_8.width, group_output_8.height = 140.0, 100.0
	    object_info.width, object_info.height = 140.0, 100.0
	    geometry_proximity.width, geometry_proximity.height = 140.0, 100.0
	    capture_attribute_3.width, capture_attribute_3.height = 140.0, 100.0
	    position_2.width, position_2.height = 140.0, 100.0
	    set_position_3.width, set_position_3.height = 140.0, 100.0
	    vector_math_4.width, vector_math_4.height = 140.0, 100.0
	    vector_math_001_4.width, vector_math_001_4.height = 140.0, 100.0
	    vector_math_002_3.width, vector_math_002_3.height = 140.0, 100.0
	    vector_math_003_3.width, vector_math_003_3.height = 140.0, 100.0
	    reroute_5.width, reroute_5.height = 100.0, 100.0
	    reroute_001_5.width, reroute_001_5.height = 100.0, 100.0
	    reroute_002_3.width, reroute_002_3.height = 100.0, 100.0
	    reroute_003_3.width, reroute_003_3.height = 100.0, 100.0
	    frame_5.width, frame_5.height = 203.52935791015625, 159.35293579101562
	    reroute_004_4.width, reroute_004_4.height = 100.0, 100.0
	    reroute_005_3.width, reroute_005_3.height = 100.0, 100.0
	    reroute_006_3.width, reroute_006_3.height = 100.0, 100.0
	    reroute_007_3.width, reroute_007_3.height = 100.0, 100.0
	    group_4.width, group_4.height = 140.0, 100.0
	    boolean_math_3.width, boolean_math_3.height = 140.0, 100.0
	    set_position_001_3.width, set_position_001_3.height = 140.0, 100.0
	    geometry_proximity_001.width, geometry_proximity_001.height = 140.0, 100.0
	    reroute_008_3.width, reroute_008_3.height = 100.0, 100.0
	    reroute_009_3.width, reroute_009_3.height = 100.0, 100.0
	    reroute_010_2.width, reroute_010_2.height = 100.0, 100.0
	    reroute_011_3.width, reroute_011_3.height = 100.0, 100.0
	    reroute_012_4.width, reroute_012_4.height = 100.0, 100.0
	
	    #initialize hair_shrinkwrap links
	    #set_position_001_3.Geometry -> group_output_8.Geometry
	    hair_shrinkwrap.links.new(set_position_001_3.outputs[0], group_output_8.inputs[0])
	    #position_2.Position -> capture_attribute_3.Position
	    hair_shrinkwrap.links.new(position_2.outputs[0], capture_attribute_3.inputs[1])
	    #reroute_008_3.Output -> geometry_proximity.Geometry
	    hair_shrinkwrap.links.new(reroute_008_3.outputs[0], geometry_proximity.inputs[0])
	    #group_input_5.Geometry -> capture_attribute_3.Geometry
	    hair_shrinkwrap.links.new(group_input_5.outputs[0], capture_attribute_3.inputs[0])
	    #capture_attribute_3.Geometry -> set_position_3.Geometry
	    hair_shrinkwrap.links.new(capture_attribute_3.outputs[0], set_position_3.inputs[0])
	    #group_input_5.Surface -> object_info.Object
	    hair_shrinkwrap.links.new(group_input_5.outputs[1], object_info.inputs[0])
	    #reroute_001_5.Output -> vector_math_4.Vector
	    hair_shrinkwrap.links.new(reroute_001_5.outputs[0], vector_math_4.inputs[0])
	    #reroute_006_3.Output -> vector_math_4.Vector
	    hair_shrinkwrap.links.new(reroute_006_3.outputs[0], vector_math_4.inputs[1])
	    #reroute_003_3.Output -> vector_math_001_4.Vector
	    hair_shrinkwrap.links.new(reroute_003_3.outputs[0], vector_math_001_4.inputs[0])
	    #vector_math_4.Vector -> vector_math_002_3.Vector
	    hair_shrinkwrap.links.new(vector_math_4.outputs[0], vector_math_002_3.inputs[0])
	    #vector_math_002_3.Vector -> vector_math_003_3.Vector
	    hair_shrinkwrap.links.new(vector_math_002_3.outputs[0], vector_math_003_3.inputs[0])
	    #reroute_005_3.Output -> vector_math_003_3.Scale
	    hair_shrinkwrap.links.new(reroute_005_3.outputs[0], vector_math_003_3.inputs[3])
	    #reroute_007_3.Output -> vector_math_001_4.Vector
	    hair_shrinkwrap.links.new(reroute_007_3.outputs[0], vector_math_001_4.inputs[1])
	    #vector_math_001_4.Vector -> set_position_3.Position
	    hair_shrinkwrap.links.new(vector_math_001_4.outputs[0], set_position_3.inputs[2])
	    #capture_attribute_3.Position -> reroute_5.Input
	    hair_shrinkwrap.links.new(capture_attribute_3.outputs[1], reroute_5.inputs[0])
	    #reroute_002_3.Output -> reroute_001_5.Input
	    hair_shrinkwrap.links.new(reroute_002_3.outputs[0], reroute_001_5.inputs[0])
	    #reroute_5.Output -> reroute_002_3.Input
	    hair_shrinkwrap.links.new(reroute_5.outputs[0], reroute_002_3.inputs[0])
	    #reroute_002_3.Output -> geometry_proximity.Sample Position
	    hair_shrinkwrap.links.new(reroute_002_3.outputs[0], geometry_proximity.inputs[2])
	    #geometry_proximity.Position -> reroute_003_3.Input
	    hair_shrinkwrap.links.new(geometry_proximity.outputs[0], reroute_003_3.inputs[0])
	    #group_input_5.Offset -> reroute_004_4.Input
	    hair_shrinkwrap.links.new(group_input_5.outputs[2], reroute_004_4.inputs[0])
	    #reroute_004_4.Output -> reroute_005_3.Input
	    hair_shrinkwrap.links.new(reroute_004_4.outputs[0], reroute_005_3.inputs[0])
	    #reroute_003_3.Output -> reroute_006_3.Input
	    hair_shrinkwrap.links.new(reroute_003_3.outputs[0], reroute_006_3.inputs[0])
	    #vector_math_003_3.Vector -> reroute_007_3.Input
	    hair_shrinkwrap.links.new(vector_math_003_3.outputs[0], reroute_007_3.inputs[0])
	    #group_4.Root Selection -> boolean_math_3.Boolean
	    hair_shrinkwrap.links.new(group_4.outputs[0], boolean_math_3.inputs[0])
	    #boolean_math_3.Boolean -> set_position_3.Selection
	    hair_shrinkwrap.links.new(boolean_math_3.outputs[0], set_position_3.inputs[1])
	    #set_position_3.Geometry -> set_position_001_3.Geometry
	    hair_shrinkwrap.links.new(set_position_3.outputs[0], set_position_001_3.inputs[0])
	    #reroute_009_3.Output -> geometry_proximity_001.Geometry
	    hair_shrinkwrap.links.new(reroute_009_3.outputs[0], geometry_proximity_001.inputs[0])
	    #reroute_012_4.Output -> geometry_proximity_001.Sample Position
	    hair_shrinkwrap.links.new(reroute_012_4.outputs[0], geometry_proximity_001.inputs[2])
	    #reroute_011_3.Output -> set_position_001_3.Selection
	    hair_shrinkwrap.links.new(reroute_011_3.outputs[0], set_position_001_3.inputs[1])
	    #geometry_proximity_001.Position -> set_position_001_3.Position
	    hair_shrinkwrap.links.new(geometry_proximity_001.outputs[0], set_position_001_3.inputs[2])
	    #object_info.Geometry -> reroute_008_3.Input
	    hair_shrinkwrap.links.new(object_info.outputs[4], reroute_008_3.inputs[0])
	    #reroute_008_3.Output -> reroute_009_3.Input
	    hair_shrinkwrap.links.new(reroute_008_3.outputs[0], reroute_009_3.inputs[0])
	    #group_4.Root Position -> reroute_010_2.Input
	    hair_shrinkwrap.links.new(group_4.outputs[1], reroute_010_2.inputs[0])
	    #group_4.Root Selection -> reroute_011_3.Input
	    hair_shrinkwrap.links.new(group_4.outputs[0], reroute_011_3.inputs[0])
	    #reroute_010_2.Output -> reroute_012_4.Input
	    hair_shrinkwrap.links.new(reroute_010_2.outputs[0], reroute_012_4.inputs[0])
	    return hair_shrinkwrap
	
	hair_shrinkwrap = hair_shrinkwrap_node_group()
	
	#initialize attach_hair_curves_to_surface node group
	def attach_hair_curves_to_surface_node_group():
	    attach_hair_curves_to_surface = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Attach Hair Curves to Surface")
	
	    attach_hair_curves_to_surface.color_tag = 'NONE'
	    attach_hair_curves_to_surface.description = "Attaches hair curves to a surface mesh"
	    attach_hair_curves_to_surface.default_group_node_width = 140
	    
	
	    attach_hair_curves_to_surface.is_modifier = True
	
	    #attach_hair_curves_to_surface interface
	    #Socket Geometry
	    geometry_socket_8 = attach_hair_curves_to_surface.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_8.attribute_domain = 'POINT'
	
	    #Socket Surface UV Coordinate
	    surface_uv_coordinate_socket = attach_hair_curves_to_surface.interface.new_socket(name = "Surface UV Coordinate", in_out='OUTPUT', socket_type = 'NodeSocketVector')
	    surface_uv_coordinate_socket.default_value = (0.0, 0.0, 0.0)
	    surface_uv_coordinate_socket.min_value = -3.4028234663852886e+38
	    surface_uv_coordinate_socket.max_value = 3.4028234663852886e+38
	    surface_uv_coordinate_socket.subtype = 'NONE'
	    surface_uv_coordinate_socket.attribute_domain = 'CURVE'
	    surface_uv_coordinate_socket.description = "Surface UV coordinates at the attachment point"
	
	    #Socket Surface Normal
	    surface_normal_socket = attach_hair_curves_to_surface.interface.new_socket(name = "Surface Normal", in_out='OUTPUT', socket_type = 'NodeSocketVector')
	    surface_normal_socket.default_value = (0.0, 0.0, 0.0)
	    surface_normal_socket.min_value = -3.4028234663852886e+38
	    surface_normal_socket.max_value = 3.4028234663852886e+38
	    surface_normal_socket.subtype = 'NONE'
	    surface_normal_socket.attribute_domain = 'CURVE'
	    surface_normal_socket.description = "Surface normal at the attachment point"
	
	    #Socket Geometry
	    geometry_socket_9 = attach_hair_curves_to_surface.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_9.attribute_domain = 'POINT'
	    geometry_socket_9.description = "Input Geometry (may include other than curves)"
	
	    #Socket Surface
	    surface_socket_1 = attach_hair_curves_to_surface.interface.new_socket(name = "Surface", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    surface_socket_1.attribute_domain = 'POINT'
	    surface_socket_1.description = "Surface geometry to attach hair curves to"
	
	    #Socket Surface
	    surface_socket_2 = attach_hair_curves_to_surface.interface.new_socket(name = "Surface", in_out='INPUT', socket_type = 'NodeSocketObject')
	    surface_socket_2.attribute_domain = 'POINT'
	    surface_socket_2.description = "Surface Object to attach to (needs to have matching transforms)"
	
	    #Socket Surface UV Map
	    surface_uv_map_socket = attach_hair_curves_to_surface.interface.new_socket(name = "Surface UV Map", in_out='INPUT', socket_type = 'NodeSocketVector')
	    surface_uv_map_socket.default_value = (0.0, 0.0, 0.0)
	    surface_uv_map_socket.min_value = -3.4028234663852886e+38
	    surface_uv_map_socket.max_value = 3.4028234663852886e+38
	    surface_uv_map_socket.subtype = 'NONE'
	    surface_uv_map_socket.default_attribute_name = "UVMap"
	    surface_uv_map_socket.attribute_domain = 'POINT'
	    surface_uv_map_socket.hide_value = True
	    surface_uv_map_socket.description = "Surface UV map used for attachment"
	
	    #Socket Surface Rest Position
	    surface_rest_position_socket = attach_hair_curves_to_surface.interface.new_socket(name = "Surface Rest Position", in_out='INPUT', socket_type = 'NodeSocketBool')
	    surface_rest_position_socket.default_value = False
	    surface_rest_position_socket.attribute_domain = 'POINT'
	    surface_rest_position_socket.description = "Set the surface mesh into its rest position before attachment"
	
	    #Socket Sample Attachment UV
	    sample_attachment_uv_socket = attach_hair_curves_to_surface.interface.new_socket(name = "Sample Attachment UV", in_out='INPUT', socket_type = 'NodeSocketBool')
	    sample_attachment_uv_socket.default_value = True
	    sample_attachment_uv_socket.attribute_domain = 'POINT'
	    sample_attachment_uv_socket.description = "Sample the surface UV map at the attachment point"
	
	    #Socket Snap to Surface
	    snap_to_surface_socket = attach_hair_curves_to_surface.interface.new_socket(name = "Snap to Surface", in_out='INPUT', socket_type = 'NodeSocketBool')
	    snap_to_surface_socket.default_value = True
	    snap_to_surface_socket.attribute_domain = 'POINT'
	    snap_to_surface_socket.description = "Snap the root of each curve to the closest surface point"
	
	    #Socket Align to Surface Normal
	    align_to_surface_normal_socket = attach_hair_curves_to_surface.interface.new_socket(name = "Align to Surface Normal", in_out='INPUT', socket_type = 'NodeSocketBool')
	    align_to_surface_normal_socket.default_value = True
	    align_to_surface_normal_socket.attribute_domain = 'POINT'
	    align_to_surface_normal_socket.description = "Align the curve to the surface normal (needs a guide as reference)"
	
	    #Socket Blend along Curve
	    blend_along_curve_socket = attach_hair_curves_to_surface.interface.new_socket(name = "Blend along Curve", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    blend_along_curve_socket.default_value = 0.0
	    blend_along_curve_socket.min_value = 0.0
	    blend_along_curve_socket.max_value = 1.0
	    blend_along_curve_socket.subtype = 'FACTOR'
	    blend_along_curve_socket.attribute_domain = 'POINT'
	    blend_along_curve_socket.description = "Blend deformation along each curve from the root"
	
	
	    #initialize attach_hair_curves_to_surface nodes
	    #node Frame.004
	    frame_004_3 = attach_hair_curves_to_surface.nodes.new("NodeFrame")
	    frame_004_3.label = "Write Data"
	    frame_004_3.name = "Frame.004"
	    frame_004_3.label_size = 20
	    frame_004_3.shrink = True
	
	    #node Frame.005
	    frame_005_2 = attach_hair_curves_to_surface.nodes.new("NodeFrame")
	    frame_005_2.label = "Sample Surface"
	    frame_005_2.name = "Frame.005"
	    frame_005_2.label_size = 20
	    frame_005_2.shrink = True
	
	    #node Frame
	    frame_6 = attach_hair_curves_to_surface.nodes.new("NodeFrame")
	    frame_6.label = "Surface Geometry Input"
	    frame_6.name = "Frame"
	    frame_6.label_size = 20
	    frame_6.shrink = True
	
	    #node Frame.006
	    frame_006_2 = attach_hair_curves_to_surface.nodes.new("NodeFrame")
	    frame_006_2.label = "Geometry Socket with Priority"
	    frame_006_2.name = "Frame.006"
	    frame_006_2.label_size = 20
	    frame_006_2.shrink = True
	
	    #node Frame.007
	    frame_007_2 = attach_hair_curves_to_surface.nodes.new("NodeFrame")
	    frame_007_2.label = "Object in Local Space"
	    frame_007_2.name = "Frame.007"
	    frame_007_2.label_size = 20
	    frame_007_2.shrink = True
	
	    #node Frame.011
	    frame_011 = attach_hair_curves_to_surface.nodes.new("NodeFrame")
	    frame_011.label = "Sample Attachment UV"
	    frame_011.name = "Frame.011"
	    frame_011.label_size = 20
	    frame_011.shrink = True
	
	    #node Frame.001
	    frame_001_3 = attach_hair_curves_to_surface.nodes.new("NodeFrame")
	    frame_001_3.label = "Smooth Normals"
	    frame_001_3.name = "Frame.001"
	    frame_001_3.label_size = 20
	    frame_001_3.shrink = True
	
	    #node Frame.010
	    frame_010 = attach_hair_curves_to_surface.nodes.new("NodeFrame")
	    frame_010.label = "Calculate New Position"
	    frame_010.name = "Frame.010"
	    frame_010.use_custom_color = True
	    frame_010.color = (0.13328450918197632, 0.13328450918197632, 0.13328450918197632)
	    frame_010.label_size = 20
	    frame_010.shrink = True
	
	    #node Frame.003
	    frame_003_3 = attach_hair_curves_to_surface.nodes.new("NodeFrame")
	    frame_003_3.label = "Blend Deformation"
	    frame_003_3.name = "Frame.003"
	    frame_003_3.label_size = 20
	    frame_003_3.shrink = True
	
	    #node Frame.002
	    frame_002_4 = attach_hair_curves_to_surface.nodes.new("NodeFrame")
	    frame_002_4.label = "Align to Normal"
	    frame_002_4.name = "Frame.002"
	    frame_002_4.use_custom_color = True
	    frame_002_4.color = (0.08883915841579437, 0.08883915841579437, 0.08883915841579437)
	    frame_002_4.label_size = 20
	    frame_002_4.shrink = True
	
	    #node Frame.008
	    frame_008 = attach_hair_curves_to_surface.nodes.new("NodeFrame")
	    frame_008.label = "Optimize"
	    frame_008.name = "Frame.008"
	    frame_008.label_size = 20
	    frame_008.shrink = True
	
	    #node Frame.009
	    frame_009 = attach_hair_curves_to_surface.nodes.new("NodeFrame")
	    frame_009.label = "Sample from Guide"
	    frame_009.name = "Frame.009"
	    frame_009.label_size = 20
	    frame_009.shrink = True
	
	    #node Reroute.010
	    reroute_010_3 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_010_3.name = "Reroute.010"
	    reroute_010_3.socket_idname = "NodeSocketGeometry"
	    #node Reroute.013
	    reroute_013_4 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_013_4.name = "Reroute.013"
	    reroute_013_4.socket_idname = "NodeSocketBool"
	    #node Group Output
	    group_output_9 = attach_hair_curves_to_surface.nodes.new("NodeGroupOutput")
	    group_output_9.name = "Group Output"
	    group_output_9.is_active_output = True
	
	    #node Reroute.003
	    reroute_003_4 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_003_4.name = "Reroute.003"
	    reroute_003_4.socket_idname = "NodeSocketVector"
	    #node Switch
	    switch_5 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSwitch")
	    switch_5.name = "Switch"
	    switch_5.input_type = 'GEOMETRY'
	
	    #node Store Named Attribute
	    store_named_attribute_2 = attach_hair_curves_to_surface.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_2.name = "Store Named Attribute"
	    store_named_attribute_2.data_type = 'FLOAT2'
	    store_named_attribute_2.domain = 'CURVE'
	    #Selection
	    store_named_attribute_2.inputs[1].default_value = True
	    #Name
	    store_named_attribute_2.inputs[2].default_value = "surface_uv_coordinate"
	
	    #node Group Input.007
	    group_input_007_3 = attach_hair_curves_to_surface.nodes.new("NodeGroupInput")
	    group_input_007_3.name = "Group Input.007"
	    group_input_007_3.outputs[0].hide = True
	    group_input_007_3.outputs[1].hide = True
	    group_input_007_3.outputs[2].hide = True
	    group_input_007_3.outputs[3].hide = True
	    group_input_007_3.outputs[4].hide = True
	    group_input_007_3.outputs[6].hide = True
	    group_input_007_3.outputs[7].hide = True
	    group_input_007_3.outputs[8].hide = True
	    group_input_007_3.outputs[9].hide = True
	
	    #node Reroute.016
	    reroute_016_4 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_016_4.name = "Reroute.016"
	    reroute_016_4.socket_idname = "NodeSocketGeometry"
	    #node Reroute.005
	    reroute_005_4 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_005_4.name = "Reroute.005"
	    reroute_005_4.socket_idname = "NodeSocketVector"
	    #node Store Named Attribute.001
	    store_named_attribute_001 = attach_hair_curves_to_surface.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_001.name = "Store Named Attribute.001"
	    store_named_attribute_001.data_type = 'FLOAT_VECTOR'
	    store_named_attribute_001.domain = 'CURVE'
	    #Selection
	    store_named_attribute_001.inputs[1].default_value = True
	    #Name
	    store_named_attribute_001.inputs[2].default_value = "surface_normal"
	
	    #node Named Attribute.004
	    named_attribute_004 = attach_hair_curves_to_surface.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute_004.name = "Named Attribute.004"
	    named_attribute_004.data_type = 'FLOAT_VECTOR'
	    #Name
	    named_attribute_004.inputs[0].default_value = "surface_normal"
	
	    #node Reroute.012
	    reroute_012_5 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_012_5.name = "Reroute.012"
	    reroute_012_5.socket_idname = "NodeSocketBool"
	    #node Reroute.014
	    reroute_014_4 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_014_4.name = "Reroute.014"
	    reroute_014_4.socket_idname = "NodeSocketBool"
	    #node Reroute.006
	    reroute_006_4 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_006_4.name = "Reroute.006"
	    reroute_006_4.socket_idname = "NodeSocketGeometry"
	    #node Named Attribute.003
	    named_attribute_003_1 = attach_hair_curves_to_surface.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute_003_1.name = "Named Attribute.003"
	    named_attribute_003_1.data_type = 'FLOAT_VECTOR'
	    #Name
	    named_attribute_003_1.inputs[0].default_value = "surface_uv_coordinate"
	
	    #node Switch.008
	    switch_008 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSwitch")
	    switch_008.name = "Switch.008"
	    switch_008.input_type = 'GEOMETRY'
	
	    #node Switch.009
	    switch_009 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSwitch")
	    switch_009.name = "Switch.009"
	    switch_009.input_type = 'VECTOR'
	
	    #node Switch.010
	    switch_010 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSwitch")
	    switch_010.name = "Switch.010"
	    switch_010.input_type = 'VECTOR'
	
	    #node Set Position.001
	    set_position_001_4 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSetPosition")
	    set_position_001_4.name = "Set Position.001"
	    set_position_001_4.inputs[2].hide = True
	    #Position
	    set_position_001_4.inputs[2].default_value = (0.0, 0.0, 0.0)
	
	    #node Reroute.002
	    reroute_002_4 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_002_4.name = "Reroute.002"
	    reroute_002_4.socket_idname = "NodeSocketVector"
	    #node Reroute.018
	    reroute_018_4 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_018_4.name = "Reroute.018"
	    reroute_018_4.socket_idname = "NodeSocketVector"
	    #node Reroute.017
	    reroute_017_4 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_017_4.name = "Reroute.017"
	    reroute_017_4.socket_idname = "NodeSocketGeometry"
	    #node Group Input.009
	    group_input_009_2 = attach_hair_curves_to_surface.nodes.new("NodeGroupInput")
	    group_input_009_2.name = "Group Input.009"
	    group_input_009_2.outputs[0].hide = True
	    group_input_009_2.outputs[1].hide = True
	    group_input_009_2.outputs[2].hide = True
	    group_input_009_2.outputs[4].hide = True
	    group_input_009_2.outputs[5].hide = True
	    group_input_009_2.outputs[6].hide = True
	    group_input_009_2.outputs[7].hide = True
	    group_input_009_2.outputs[8].hide = True
	    group_input_009_2.outputs[9].hide = True
	
	    #node Position
	    position_3 = attach_hair_curves_to_surface.nodes.new("GeometryNodeInputPosition")
	    position_3.name = "Position"
	
	    #node Named Attribute.001
	    named_attribute_001 = attach_hair_curves_to_surface.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute_001.name = "Named Attribute.001"
	    named_attribute_001.data_type = 'FLOAT_VECTOR'
	    #Name
	    named_attribute_001.inputs[0].default_value = "surface_uv_coordinate"
	
	    #node Capture Attribute.001
	    capture_attribute_001_3 = attach_hair_curves_to_surface.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_001_3.name = "Capture Attribute.001"
	    capture_attribute_001_3.active_index = 0
	    capture_attribute_001_3.capture_items.clear()
	    capture_attribute_001_3.capture_items.new('FLOAT', "Value")
	    capture_attribute_001_3.capture_items["Value"].data_type = 'FLOAT_VECTOR'
	    capture_attribute_001_3.domain = 'CURVE'
	
	    #node Group Input.004
	    group_input_004_3 = attach_hair_curves_to_surface.nodes.new("NodeGroupInput")
	    group_input_004_3.name = "Group Input.004"
	    group_input_004_3.outputs[0].hide = True
	    group_input_004_3.outputs[2].hide = True
	    group_input_004_3.outputs[3].hide = True
	    group_input_004_3.outputs[4].hide = True
	    group_input_004_3.outputs[5].hide = True
	    group_input_004_3.outputs[6].hide = True
	    group_input_004_3.outputs[7].hide = True
	    group_input_004_3.outputs[8].hide = True
	    group_input_004_3.outputs[9].hide = True
	
	    #node Domain Size.002
	    domain_size_002 = attach_hair_curves_to_surface.nodes.new("GeometryNodeAttributeDomainSize")
	    domain_size_002.name = "Domain Size.002"
	    domain_size_002.component = 'MESH'
	    domain_size_002.outputs[0].hide = True
	    domain_size_002.outputs[1].hide = True
	    domain_size_002.outputs[3].hide = True
	    domain_size_002.outputs[4].hide = True
	    domain_size_002.outputs[5].hide = True
	
	    #node Compare.001
	    compare_001_3 = attach_hair_curves_to_surface.nodes.new("FunctionNodeCompare")
	    compare_001_3.name = "Compare.001"
	    compare_001_3.data_type = 'INT'
	    compare_001_3.mode = 'ELEMENT'
	    compare_001_3.operation = 'NOT_EQUAL'
	    #B_INT
	    compare_001_3.inputs[3].default_value = 0
	
	    #node Object Info.001
	    object_info_001 = attach_hair_curves_to_surface.nodes.new("GeometryNodeObjectInfo")
	    object_info_001.name = "Object Info.001"
	    object_info_001.transform_space = 'ORIGINAL'
	    object_info_001.inputs[1].hide = True
	    object_info_001.outputs[1].hide = True
	    object_info_001.outputs[3].hide = True
	    #As Instance
	    object_info_001.inputs[1].default_value = False
	
	    #node Group Input.002
	    group_input_002_3 = attach_hair_curves_to_surface.nodes.new("NodeGroupInput")
	    group_input_002_3.name = "Group Input.002"
	    group_input_002_3.outputs[0].hide = True
	    group_input_002_3.outputs[1].hide = True
	    group_input_002_3.outputs[3].hide = True
	    group_input_002_3.outputs[4].hide = True
	    group_input_002_3.outputs[5].hide = True
	    group_input_002_3.outputs[6].hide = True
	    group_input_002_3.outputs[7].hide = True
	    group_input_002_3.outputs[8].hide = True
	    group_input_002_3.outputs[9].hide = True
	
	    #node Switch.005
	    switch_005_1 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSwitch")
	    switch_005_1.name = "Switch.005"
	    switch_005_1.input_type = 'GEOMETRY'
	
	    #node Domain Size.003
	    domain_size_003 = attach_hair_curves_to_surface.nodes.new("GeometryNodeAttributeDomainSize")
	    domain_size_003.name = "Domain Size.003"
	    domain_size_003.component = 'MESH'
	    domain_size_003.outputs[0].hide = True
	    domain_size_003.outputs[1].hide = True
	    domain_size_003.outputs[3].hide = True
	    domain_size_003.outputs[4].hide = True
	    domain_size_003.outputs[5].hide = True
	
	    #node Compare.002
	    compare_002_3 = attach_hair_curves_to_surface.nodes.new("FunctionNodeCompare")
	    compare_002_3.name = "Compare.002"
	    compare_002_3.data_type = 'INT'
	    compare_002_3.mode = 'ELEMENT'
	    compare_002_3.operation = 'EQUAL'
	    #B_INT
	    compare_002_3.inputs[3].default_value = 0
	
	    #node Named Attribute
	    named_attribute_2 = attach_hair_curves_to_surface.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute_2.name = "Named Attribute"
	    named_attribute_2.data_type = 'FLOAT_VECTOR'
	    #Name
	    named_attribute_2.inputs[0].default_value = "rest_position"
	
	    #node Reroute
	    reroute_6 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_6.name = "Reroute"
	    reroute_6.socket_idname = "NodeSocketGeometry"
	    #node Group Input.005
	    group_input_005_3 = attach_hair_curves_to_surface.nodes.new("NodeGroupInput")
	    group_input_005_3.name = "Group Input.005"
	    group_input_005_3.outputs[0].hide = True
	    group_input_005_3.outputs[1].hide = True
	    group_input_005_3.outputs[2].hide = True
	    group_input_005_3.outputs[3].hide = True
	    group_input_005_3.outputs[5].hide = True
	    group_input_005_3.outputs[6].hide = True
	    group_input_005_3.outputs[7].hide = True
	    group_input_005_3.outputs[8].hide = True
	    group_input_005_3.outputs[9].hide = True
	
	    #node Set Position
	    set_position_4 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSetPosition")
	    set_position_4.name = "Set Position"
	    set_position_4.inputs[3].hide = True
	    #Offset
	    set_position_4.inputs[3].default_value = (0.0, 0.0, 0.0)
	
	    #node Switch.007
	    switch_007 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSwitch")
	    switch_007.name = "Switch.007"
	    switch_007.input_type = 'GEOMETRY'
	
	    #node Reroute.015
	    reroute_015_4 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_015_4.name = "Reroute.015"
	    reroute_015_4.socket_idname = "NodeSocketBool"
	    #node Reroute.011
	    reroute_011_4 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_011_4.name = "Reroute.011"
	    reroute_011_4.socket_idname = "NodeSocketGeometry"
	    #node Group Input
	    group_input_6 = attach_hair_curves_to_surface.nodes.new("NodeGroupInput")
	    group_input_6.name = "Group Input"
	    group_input_6.outputs[1].hide = True
	    group_input_6.outputs[2].hide = True
	    group_input_6.outputs[3].hide = True
	    group_input_6.outputs[4].hide = True
	    group_input_6.outputs[5].hide = True
	    group_input_6.outputs[6].hide = True
	    group_input_6.outputs[7].hide = True
	    group_input_6.outputs[8].hide = True
	    group_input_6.outputs[9].hide = True
	
	    #node Capture Attribute.002
	    capture_attribute_002_3 = attach_hair_curves_to_surface.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_002_3.name = "Capture Attribute.002"
	    capture_attribute_002_3.active_index = 0
	    capture_attribute_002_3.capture_items.clear()
	    capture_attribute_002_3.capture_items.new('FLOAT', "Value")
	    capture_attribute_002_3.capture_items["Value"].data_type = 'FLOAT_VECTOR'
	    capture_attribute_002_3.domain = 'CURVE'
	
	    #node Reroute.001
	    reroute_001_6 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_001_6.name = "Reroute.001"
	    reroute_001_6.socket_idname = "NodeSocketGeometry"
	    #node Sample Nearest Surface
	    sample_nearest_surface = attach_hair_curves_to_surface.nodes.new("GeometryNodeSampleNearestSurface")
	    sample_nearest_surface.name = "Sample Nearest Surface"
	    sample_nearest_surface.data_type = 'FLOAT_VECTOR'
	    #Group ID
	    sample_nearest_surface.inputs[2].default_value = 0
	    #Sample Group ID
	    sample_nearest_surface.inputs[4].default_value = 0
	
	    #node Group
	    group_5 = attach_hair_curves_to_surface.nodes.new("GeometryNodeGroup")
	    group_5.name = "Group"
	    group_5.node_tree = curve_root_006
	    group_5.outputs[0].hide = True
	    group_5.outputs[2].hide = True
	    group_5.outputs[3].hide = True
	
	    #node Group Input.001
	    group_input_001_4 = attach_hair_curves_to_surface.nodes.new("NodeGroupInput")
	    group_input_001_4.name = "Group Input.001"
	    group_input_001_4.outputs[0].hide = True
	    group_input_001_4.outputs[1].hide = True
	    group_input_001_4.outputs[2].hide = True
	    group_input_001_4.outputs[4].hide = True
	    group_input_001_4.outputs[5].hide = True
	    group_input_001_4.outputs[6].hide = True
	    group_input_001_4.outputs[7].hide = True
	    group_input_001_4.outputs[8].hide = True
	    group_input_001_4.outputs[9].hide = True
	
	    #node Reroute.020
	    reroute_020_3 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_020_3.name = "Reroute.020"
	    reroute_020_3.socket_idname = "NodeSocketGeometry"
	    #node Normal
	    normal_1 = attach_hair_curves_to_surface.nodes.new("GeometryNodeInputNormal")
	    normal_1.name = "Normal"
	    normal_1.legacy_corner_normals = True
	
	    #node Capture Attribute
	    capture_attribute_4 = attach_hair_curves_to_surface.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_4.name = "Capture Attribute"
	    capture_attribute_4.hide = True
	    capture_attribute_4.active_index = 0
	    capture_attribute_4.capture_items.clear()
	    capture_attribute_4.capture_items.new('FLOAT', "Value")
	    capture_attribute_4.capture_items["Value"].data_type = 'FLOAT_VECTOR'
	    capture_attribute_4.domain = 'POINT'
	
	    #node Sample UV Surface
	    sample_uv_surface = attach_hair_curves_to_surface.nodes.new("GeometryNodeSampleUVSurface")
	    sample_uv_surface.name = "Sample UV Surface"
	    sample_uv_surface.hide = True
	    sample_uv_surface.data_type = 'FLOAT_VECTOR'
	    sample_uv_surface.outputs[1].hide = True
	
	    #node Sample UV Surface.003
	    sample_uv_surface_003 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSampleUVSurface")
	    sample_uv_surface_003.name = "Sample UV Surface.003"
	    sample_uv_surface_003.hide = True
	    sample_uv_surface_003.data_type = 'FLOAT_VECTOR'
	    sample_uv_surface_003.outputs[1].hide = True
	
	    #node Reroute.004
	    reroute_004_5 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_004_5.name = "Reroute.004"
	    reroute_004_5.socket_idname = "NodeSocketVector"
	    #node Sample UV Surface.001
	    sample_uv_surface_001 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSampleUVSurface")
	    sample_uv_surface_001.name = "Sample UV Surface.001"
	    sample_uv_surface_001.hide = True
	    sample_uv_surface_001.data_type = 'FLOAT_VECTOR'
	    sample_uv_surface_001.outputs[1].hide = True
	
	    #node Group.001
	    group_001_4 = attach_hair_curves_to_surface.nodes.new("GeometryNodeGroup")
	    group_001_4.name = "Group.001"
	    group_001_4.node_tree = curve_root_006
	    group_001_4.outputs[0].hide = True
	    group_001_4.outputs[2].hide = True
	    group_001_4.outputs[3].hide = True
	
	    #node Position.001
	    position_001_2 = attach_hair_curves_to_surface.nodes.new("GeometryNodeInputPosition")
	    position_001_2.name = "Position.001"
	
	    #node Vector Math
	    vector_math_5 = attach_hair_curves_to_surface.nodes.new("ShaderNodeVectorMath")
	    vector_math_5.name = "Vector Math"
	    vector_math_5.operation = 'SUBTRACT'
	
	    #node Vector Math.001
	    vector_math_001_5 = attach_hair_curves_to_surface.nodes.new("ShaderNodeVectorMath")
	    vector_math_001_5.name = "Vector Math.001"
	    vector_math_001_5.operation = 'SUBTRACT'
	
	    #node Vector Math.004
	    vector_math_004_4 = attach_hair_curves_to_surface.nodes.new("ShaderNodeVectorMath")
	    vector_math_004_4.name = "Vector Math.004"
	    vector_math_004_4.operation = 'SUBTRACT'
	
	    #node Vector Math.003
	    vector_math_003_4 = attach_hair_curves_to_surface.nodes.new("ShaderNodeVectorMath")
	    vector_math_003_4.name = "Vector Math.003"
	    vector_math_003_4.operation = 'SUBTRACT'
	
	    #node Group Input.003
	    group_input_003_4 = attach_hair_curves_to_surface.nodes.new("NodeGroupInput")
	    group_input_003_4.name = "Group Input.003"
	    group_input_003_4.outputs[0].hide = True
	    group_input_003_4.outputs[1].hide = True
	    group_input_003_4.outputs[2].hide = True
	    group_input_003_4.outputs[3].hide = True
	    group_input_003_4.outputs[4].hide = True
	    group_input_003_4.outputs[5].hide = True
	    group_input_003_4.outputs[6].hide = True
	    group_input_003_4.outputs[8].hide = True
	    group_input_003_4.outputs[9].hide = True
	
	    #node Group Input.006
	    group_input_006_3 = attach_hair_curves_to_surface.nodes.new("NodeGroupInput")
	    group_input_006_3.name = "Group Input.006"
	    group_input_006_3.outputs[0].hide = True
	    group_input_006_3.outputs[1].hide = True
	    group_input_006_3.outputs[2].hide = True
	    group_input_006_3.outputs[3].hide = True
	    group_input_006_3.outputs[4].hide = True
	    group_input_006_3.outputs[5].hide = True
	    group_input_006_3.outputs[7].hide = True
	    group_input_006_3.outputs[8].hide = True
	    group_input_006_3.outputs[9].hide = True
	
	    #node Switch.003
	    switch_003_5 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSwitch")
	    switch_003_5.name = "Switch.003"
	    switch_003_5.hide = True
	    switch_003_5.input_type = 'VECTOR'
	    #False
	    switch_003_5.inputs[1].default_value = (0.0, 0.0, 0.0)
	
	    #node Switch.002
	    switch_002_4 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSwitch")
	    switch_002_4.name = "Switch.002"
	    switch_002_4.input_type = 'VECTOR'
	
	    #node Vector Math.002
	    vector_math_002_4 = attach_hair_curves_to_surface.nodes.new("ShaderNodeVectorMath")
	    vector_math_002_4.name = "Vector Math.002"
	    vector_math_002_4.operation = 'ADD'
	
	    #node Vector Math.005
	    vector_math_005_2 = attach_hair_curves_to_surface.nodes.new("ShaderNodeVectorMath")
	    vector_math_005_2.name = "Vector Math.005"
	    vector_math_005_2.operation = 'SCALE'
	
	    #node Boolean Math
	    boolean_math_4 = attach_hair_curves_to_surface.nodes.new("FunctionNodeBooleanMath")
	    boolean_math_4.name = "Boolean Math"
	    boolean_math_4.operation = 'OR'
	
	    #node Spline Parameter
	    spline_parameter_1 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSplineParameter")
	    spline_parameter_1.name = "Spline Parameter"
	    spline_parameter_1.outputs[1].hide = True
	    spline_parameter_1.outputs[2].hide = True
	
	    #node Group Input.008
	    group_input_008_2 = attach_hair_curves_to_surface.nodes.new("NodeGroupInput")
	    group_input_008_2.name = "Group Input.008"
	    group_input_008_2.outputs[0].hide = True
	    group_input_008_2.outputs[1].hide = True
	    group_input_008_2.outputs[2].hide = True
	    group_input_008_2.outputs[3].hide = True
	    group_input_008_2.outputs[4].hide = True
	    group_input_008_2.outputs[5].hide = True
	    group_input_008_2.outputs[6].hide = True
	    group_input_008_2.outputs[7].hide = True
	    group_input_008_2.outputs[9].hide = True
	
	    #node Map Range
	    map_range_1 = attach_hair_curves_to_surface.nodes.new("ShaderNodeMapRange")
	    map_range_1.name = "Map Range"
	    map_range_1.hide = True
	    map_range_1.clamp = True
	    map_range_1.data_type = 'FLOAT'
	    map_range_1.interpolation_type = 'SMOOTHSTEP'
	    #From Min
	    map_range_1.inputs[1].default_value = 0.0
	    #To Min
	    map_range_1.inputs[3].default_value = 1.0
	    #To Max
	    map_range_1.inputs[4].default_value = 0.0
	
	    #node Compare
	    compare_4 = attach_hair_curves_to_surface.nodes.new("FunctionNodeCompare")
	    compare_4.name = "Compare"
	    compare_4.data_type = 'FLOAT'
	    compare_4.mode = 'ELEMENT'
	    compare_4.operation = 'EQUAL'
	    #B
	    compare_4.inputs[1].default_value = 0.0
	    #Epsilon
	    compare_4.inputs[12].default_value = 0.0
	
	    #node Switch.004
	    switch_004_2 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSwitch")
	    switch_004_2.name = "Switch.004"
	    switch_004_2.input_type = 'FLOAT'
	    #True
	    switch_004_2.inputs[2].default_value = 1.0
	
	    #node Position.002
	    position_002_3 = attach_hair_curves_to_surface.nodes.new("GeometryNodeInputPosition")
	    position_002_3.name = "Position.002"
	
	    #node Evaluate on Domain
	    evaluate_on_domain_2 = attach_hair_curves_to_surface.nodes.new("GeometryNodeFieldOnDomain")
	    evaluate_on_domain_2.name = "Evaluate on Domain"
	    evaluate_on_domain_2.data_type = 'FLOAT_VECTOR'
	    evaluate_on_domain_2.domain = 'CURVE'
	
	    #node Reroute.009
	    reroute_009_4 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_009_4.name = "Reroute.009"
	    reroute_009_4.socket_idname = "NodeSocketVector"
	    #node Evaluate on Domain.002
	    evaluate_on_domain_002_2 = attach_hair_curves_to_surface.nodes.new("GeometryNodeFieldOnDomain")
	    evaluate_on_domain_002_2.name = "Evaluate on Domain.002"
	    evaluate_on_domain_002_2.hide = True
	    evaluate_on_domain_002_2.data_type = 'FLOAT_VECTOR'
	    evaluate_on_domain_002_2.domain = 'CURVE'
	
	    #node Switch.006
	    switch_006_1 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSwitch")
	    switch_006_1.name = "Switch.006"
	    switch_006_1.input_type = 'VECTOR'
	
	    #node Vector Rotate
	    vector_rotate_1 = attach_hair_curves_to_surface.nodes.new("ShaderNodeVectorRotate")
	    vector_rotate_1.name = "Vector Rotate"
	    vector_rotate_1.invert = False
	    vector_rotate_1.rotation_type = 'EULER_XYZ'
	    vector_rotate_1.inputs[1].hide = True
	    vector_rotate_1.inputs[2].hide = True
	    vector_rotate_1.inputs[3].hide = True
	    #Center
	    vector_rotate_1.inputs[1].default_value = (0.0, 0.0, 0.0)
	
	    #node Vector Rotate.003
	    vector_rotate_003 = attach_hair_curves_to_surface.nodes.new("ShaderNodeVectorRotate")
	    vector_rotate_003.name = "Vector Rotate.003"
	    vector_rotate_003.invert = True
	    vector_rotate_003.rotation_type = 'EULER_XYZ'
	    vector_rotate_003.inputs[1].hide = True
	    vector_rotate_003.inputs[2].hide = True
	    vector_rotate_003.inputs[3].hide = True
	    #Center
	    vector_rotate_003.inputs[1].default_value = (0.0, 0.0, 0.0)
	
	    #node Align Euler to Vector.003
	    align_euler_to_vector_003 = attach_hair_curves_to_surface.nodes.new("FunctionNodeAlignEulerToVector")
	    align_euler_to_vector_003.name = "Align Euler to Vector.003"
	    align_euler_to_vector_003.axis = 'Z'
	    align_euler_to_vector_003.pivot_axis = 'AUTO'
	    align_euler_to_vector_003.inputs[0].hide = True
	    align_euler_to_vector_003.inputs[1].hide = True
	    #Rotation
	    align_euler_to_vector_003.inputs[0].default_value = (0.0, 0.0, 0.0)
	    #Factor
	    align_euler_to_vector_003.inputs[1].default_value = 1.0
	
	    #node Align Euler to Vector.002
	    align_euler_to_vector_002 = attach_hair_curves_to_surface.nodes.new("FunctionNodeAlignEulerToVector")
	    align_euler_to_vector_002.name = "Align Euler to Vector.002"
	    align_euler_to_vector_002.axis = 'Z'
	    align_euler_to_vector_002.pivot_axis = 'AUTO'
	    align_euler_to_vector_002.inputs[0].hide = True
	    align_euler_to_vector_002.inputs[1].hide = True
	    #Rotation
	    align_euler_to_vector_002.inputs[0].default_value = (0.0, 0.0, 0.0)
	    #Factor
	    align_euler_to_vector_002.inputs[1].default_value = 1.0
	
	    #node Evaluate on Domain.003
	    evaluate_on_domain_003 = attach_hair_curves_to_surface.nodes.new("GeometryNodeFieldOnDomain")
	    evaluate_on_domain_003.name = "Evaluate on Domain.003"
	    evaluate_on_domain_003.hide = True
	    evaluate_on_domain_003.data_type = 'FLOAT_VECTOR'
	    evaluate_on_domain_003.domain = 'CURVE'
	
	    #node Switch.001
	    switch_001_6 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSwitch")
	    switch_001_6.name = "Switch.001"
	    switch_001_6.hide = True
	    switch_001_6.input_type = 'VECTOR'
	
	    #node Accumulate Field
	    accumulate_field_2 = attach_hair_curves_to_surface.nodes.new("GeometryNodeAccumulateField")
	    accumulate_field_2.name = "Accumulate Field"
	    accumulate_field_2.hide = True
	    accumulate_field_2.data_type = 'FLOAT'
	    accumulate_field_2.domain = 'POINT'
	    #Group Index
	    accumulate_field_2.inputs[1].default_value = 0
	
	    #node Sample Index.001
	    sample_index_001_2 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSampleIndex")
	    sample_index_001_2.name = "Sample Index.001"
	    sample_index_001_2.hide = True
	    sample_index_001_2.clamp = False
	    sample_index_001_2.data_type = 'BOOLEAN'
	    sample_index_001_2.domain = 'CURVE'
	    #Index
	    sample_index_001_2.inputs[2].default_value = 0
	
	    #node Reroute.019
	    reroute_019_3 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_019_3.name = "Reroute.019"
	    reroute_019_3.socket_idname = "NodeSocketVector"
	    #node Named Attribute.002
	    named_attribute_002 = attach_hair_curves_to_surface.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute_002.name = "Named Attribute.002"
	    named_attribute_002.data_type = 'INT'
	    #Name
	    named_attribute_002.inputs[0].default_value = "guide_curve_index"
	
	    #node Reroute.007
	    reroute_007_4 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_007_4.name = "Reroute.007"
	    reroute_007_4.socket_idname = "NodeSocketGeometry"
	    #node Reroute.008
	    reroute_008_4 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_008_4.name = "Reroute.008"
	    reroute_008_4.socket_idname = "NodeSocketVector"
	    #node Sample Index
	    sample_index_2 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSampleIndex")
	    sample_index_2.name = "Sample Index"
	    sample_index_2.hide = True
	    sample_index_2.clamp = False
	    sample_index_2.data_type = 'FLOAT_VECTOR'
	    sample_index_2.domain = 'CURVE'
	
	
	
	
	    #Set parents
	    frame_006_2.parent = frame_6
	    frame_007_2.parent = frame_6
	    frame_003_3.parent = frame_010
	    frame_002_4.parent = frame_010
	    frame_008.parent = frame_002_4
	    frame_009.parent = frame_002_4
	    reroute_003_4.parent = frame_004_3
	    switch_5.parent = frame_004_3
	    store_named_attribute_2.parent = frame_004_3
	    group_input_007_3.parent = frame_004_3
	    reroute_016_4.parent = frame_004_3
	    reroute_005_4.parent = frame_004_3
	    store_named_attribute_001.parent = frame_004_3
	    named_attribute_004.parent = frame_004_3
	    reroute_012_5.parent = frame_004_3
	    named_attribute_003_1.parent = frame_004_3
	    switch_008.parent = frame_004_3
	    switch_009.parent = frame_004_3
	    switch_010.parent = frame_004_3
	    reroute_002_4.parent = frame_005_2
	    reroute_018_4.parent = frame_005_2
	    reroute_017_4.parent = frame_005_2
	    group_input_009_2.parent = frame_005_2
	    position_3.parent = frame_005_2
	    named_attribute_001.parent = frame_005_2
	    group_input_004_3.parent = frame_006_2
	    domain_size_002.parent = frame_006_2
	    compare_001_3.parent = frame_006_2
	    object_info_001.parent = frame_007_2
	    group_input_002_3.parent = frame_007_2
	    switch_005_1.parent = frame_6
	    domain_size_003.parent = frame_6
	    compare_002_3.parent = frame_6
	    named_attribute_2.parent = frame_6
	    reroute_6.parent = frame_6
	    group_input_005_3.parent = frame_6
	    set_position_4.parent = frame_6
	    switch_007.parent = frame_6
	    sample_nearest_surface.parent = frame_011
	    group_5.parent = frame_011
	    group_input_001_4.parent = frame_011
	    normal_1.parent = frame_001_3
	    capture_attribute_4.parent = frame_001_3
	    sample_uv_surface.parent = frame_005_2
	    sample_uv_surface_003.parent = frame_005_2
	    reroute_004_5.parent = frame_005_2
	    sample_uv_surface_001.parent = frame_005_2
	    group_001_4.parent = frame_010
	    position_001_2.parent = frame_010
	    vector_math_5.parent = frame_010
	    vector_math_001_5.parent = frame_010
	    vector_math_004_4.parent = frame_010
	    vector_math_003_4.parent = frame_010
	    group_input_003_4.parent = frame_010
	    group_input_006_3.parent = frame_010
	    switch_003_5.parent = frame_010
	    switch_002_4.parent = frame_010
	    vector_math_002_4.parent = frame_010
	    vector_math_005_2.parent = frame_010
	    boolean_math_4.parent = frame_010
	    spline_parameter_1.parent = frame_003_3
	    group_input_008_2.parent = frame_003_3
	    map_range_1.parent = frame_003_3
	    compare_4.parent = frame_003_3
	    switch_004_2.parent = frame_003_3
	    position_002_3.parent = frame_010
	    evaluate_on_domain_2.parent = frame_010
	    reroute_009_4.parent = frame_002_4
	    evaluate_on_domain_002_2.parent = frame_002_4
	    switch_006_1.parent = frame_002_4
	    vector_rotate_1.parent = frame_002_4
	    vector_rotate_003.parent = frame_002_4
	    align_euler_to_vector_003.parent = frame_002_4
	    align_euler_to_vector_002.parent = frame_002_4
	    evaluate_on_domain_003.parent = frame_002_4
	    switch_001_6.parent = frame_008
	    accumulate_field_2.parent = frame_008
	    sample_index_001_2.parent = frame_008
	    reroute_019_3.parent = frame_002_4
	    named_attribute_002.parent = frame_009
	    reroute_007_4.parent = frame_009
	    reroute_008_4.parent = frame_009
	    sample_index_2.parent = frame_009
	
	    #Set locations
	    frame_004_3.location = (-1215.903076171875, 262.0)
	    frame_005_2.location = (-4968.0, -121.0)
	    frame_6.location = (-7319.0, 140.0)
	    frame_006_2.location = (30.0, -355.0)
	    frame_007_2.location = (207.0, -181.0)
	    frame_011.location = (-5752.0, 120.0)
	    frame_001_3.location = (-5510.0, -382.0)
	    frame_010.location = (-4110.3515625, 32.0)
	    frame_003_3.location = (1565.3515625, -503.0)
	    frame_002_4.location = (29.999755859375, -437.0)
	    frame_008.location = (219.351806640625, -40.0)
	    frame_009.location = (30.0, -217.5032958984375)
	    reroute_010_3.location = (-798.60986328125, 472.99615478515625)
	    reroute_013_4.location = (-789.0, 512.1389770507812)
	    group_output_9.location = (75.0, 50.0)
	    reroute_003_4.location = (35.0, -292.3721618652344)
	    switch_5.location = (320.95263671875, -40.143096923828125)
	    store_named_attribute_2.location = (115.3720703125, -151.72100830078125)
	    group_input_007_3.location = (122.9049072265625, -39.53450012207031)
	    reroute_016_4.location = (45.1358642578125, -151.72100830078125)
	    reroute_005_4.location = (406.810302734375, -272.2791442871094)
	    store_named_attribute_001.location = (527.368408203125, -51.255889892578125)
	    named_attribute_004.location = (607.740478515625, -513.3954467773438)
	    reroute_012_5.location = (768.484619140625, -252.18612670898438)
	    reroute_014_4.location = (-507.69775390625, 311.209228515625)
	    reroute_006_4.location = (-547.8837890625, 291.1162109375)
	    named_attribute_003_1.location = (607.740478515625, -352.6512451171875)
	    switch_008.location = (808.670654296875, -71.34890747070312)
	    switch_009.location = (808.670654296875, -212.00006103515625)
	    switch_010.location = (808.670654296875, -392.8372802734375)
	    set_position_001_4.location = (-1472.16259765625, 230.837158203125)
	    reroute_002_4.location = (220.65625, -190.25262451171875)
	    reroute_018_4.location = (220.65625, -150.06658935546875)
	    reroute_017_4.location = (220.65625, -109.88055419921875)
	    group_input_009_2.location = (29.99072265625, -180.322021484375)
	    position_3.location = (29.99072265625, -39.67083740234375)
	    named_attribute_001.location = (29.99072265625, -260.694091796875)
	    capture_attribute_001_3.location = (-4365.55810546875, 210.744140625)
	    group_input_004_3.location = (29.669921875, -178.9044189453125)
	    domain_size_002.location = (207.6806640625, -80.07354736328125)
	    compare_001_3.location = (388.517578125, -39.88751220703125)
	    object_info_001.location = (210.88330078125, -39.64691162109375)
	    group_input_002_3.location = (30.0458984375, -79.83294677734375)
	    switch_005_1.location = (640.525390625, -283.5823974609375)
	    domain_size_003.location = (938.8193359375, -79.91128540039062)
	    compare_002_3.location = (1119.65625, -39.725250244140625)
	    named_attribute_2.location = (820.7041015625, -432.90301513671875)
	    reroute_6.location = (961.35546875, -332.43792724609375)
	    group_input_005_3.location = (1021.63427734375, -252.0657958984375)
	    set_position_4.location = (1021.63427734375, -352.53094482421875)
	    switch_007.location = (1222.564453125, -231.9727783203125)
	    reroute_015_4.location = (-5129.0927734375, 532.2319946289062)
	    reroute_011_4.location = (-5109.0, 492.04595947265625)
	    group_input_6.location = (-5510.8603515625, 351.395263671875)
	    capture_attribute_002_3.location = (-5209.46484375, 230.837158203125)
	    reroute_001_6.location = (-4887.9765625, -653.2559814453125)
	    sample_nearest_surface.location = (210.7509765625, -40.199798583984375)
	    group_5.location = (29.9140625, -180.85098266601562)
	    group_input_001_4.location = (29.9140625, -100.4788818359375)
	    reroute_020_3.location = (-4526.30224609375, -10.2791748046875)
	    normal_1.location = (29.5712890625, -45.01953125)
	    capture_attribute_4.location = (230.50146484375, -45.01953125)
	    sample_uv_surface.location = (321.1396484375, -50.02386474609375)
	    sample_uv_surface_003.location = (321.1396484375, -130.39593505859375)
	    reroute_004_5.location = (220.6748046875, -230.86102294921875)
	    sample_uv_surface_001.location = (321.1396484375, -210.76800537109375)
	    group_001_4.location = (158.627685546875, -240.71258544921875)
	    position_001_2.location = (339.46484375, -321.08465576171875)
	    vector_math_5.location = (339.46484375, -140.2474365234375)
	    vector_math_001_5.location = (540.39501953125, -321.08465576171875)
	    vector_math_004_4.location = (1826.3486328125, -341.17767333984375)
	    vector_math_003_4.location = (2027.27880859375, -200.52651977539062)
	    group_input_003_4.location = (1424.48828125, -220.79666137695312)
	    group_input_006_3.location = (1424.48828125, -100.238525390625)
	    switch_003_5.location = (1625.41845703125, -180.61062622070312)
	    switch_002_4.location = (1625.41845703125, -220.79666137695312)
	    vector_math_002_4.location = (1826.3486328125, -140.424560546875)
	    vector_math_005_2.location = (2248.30224609375, -200.70364379882812)
	    boolean_math_4.location = (1625.41845703125, -39.959442138671875)
	    spline_parameter_1.location = (32.72265625, -81.9400634765625)
	    group_input_008_2.location = (30.322265625, -161.4296875)
	    map_range_1.location = (205.259765625, -190.3057861328125)
	    compare_4.location = (205.20068359375, -39.6795654296875)
	    switch_004_2.location = (386.037841796875, -59.772705078125)
	    position_002_3.location = (1625.41845703125, -371.6761474609375)
	    evaluate_on_domain_2.location = (531.248291015625, -115.30325317382812)
	    reroute_009_4.location = (731.747802734375, -64.921875)
	    evaluate_on_domain_002_2.location = (630.95361328125, -265.85211181640625)
	    switch_006_1.location = (992.6279296875, -64.921875)
	    vector_rotate_1.location = (1173.465087890625, -64.921875)
	    vector_rotate_003.location = (811.790771484375, -165.386962890625)
	    align_euler_to_vector_003.location = (630.95361328125, -165.386962890625)
	    align_euler_to_vector_002.location = (630.95361328125, -306.0382080078125)
	    evaluate_on_domain_003.location = (630.95361328125, -406.5032958984375)
	    switch_001_6.location = (210.67138671875, -105.2939453125)
	    accumulate_field_2.location = (29.834228515625, -45.014892578125)
	    sample_index_001_2.location = (29.834228515625, -85.200927734375)
	    reroute_019_3.location = (48.255859375, -185.48004150390625)
	    named_attribute_002.location = (35.0, -105.279052734375)
	    reroute_007_4.location = (35.0, -45.0)
	    reroute_008_4.location = (35.0, -85.18603515625)
	    sample_index_2.location = (215.837158203125, -65.093017578125)
	
	    #Set dimensions
	    frame_004_3.width, frame_004_3.height = 978.903076171875, 664.0
	    frame_005_2.width, frame_005_2.height = 491.0, 412.0
	    frame_6.width, frame_6.height = 1393.0, 646.0
	    frame_006_2.width, frame_006_2.height = 559.0, 261.0
	    frame_007_2.width, frame_007_2.height = 381.0, 215.0
	    frame_011.width, frame_011.height = 390.33642578125, 289.0
	    frame_001_3.width, frame_001_3.height = 401.0, 125.0
	    frame_010.width, frame_010.height = 2418.3515625, 971.0
	    frame_003_3.width, frame_003_3.height = 556.0, 250.0
	    frame_002_4.width, frame_002_4.height = 1343.351806640625, 504.0
	    frame_008.width, frame_008.height = 381.0, 160.0
	    frame_009.width, frame_009.height = 385.351806640625, 256.4967041015625
	    reroute_010_3.width, reroute_010_3.height = 10.0, 100.0
	    reroute_013_4.width, reroute_013_4.height = 10.0, 100.0
	    group_output_9.width, group_output_9.height = 140.0, 100.0
	    reroute_003_4.width, reroute_003_4.height = 10.0, 100.0
	    switch_5.width, switch_5.height = 140.0, 100.0
	    store_named_attribute_2.width, store_named_attribute_2.height = 140.0, 100.0
	    group_input_007_3.width, group_input_007_3.height = 140.0, 100.0
	    reroute_016_4.width, reroute_016_4.height = 10.0, 100.0
	    reroute_005_4.width, reroute_005_4.height = 10.0, 100.0
	    store_named_attribute_001.width, store_named_attribute_001.height = 140.0, 100.0
	    named_attribute_004.width, named_attribute_004.height = 140.0, 100.0
	    reroute_012_5.width, reroute_012_5.height = 10.0, 100.0
	    reroute_014_4.width, reroute_014_4.height = 10.0, 100.0
	    reroute_006_4.width, reroute_006_4.height = 10.0, 100.0
	    named_attribute_003_1.width, named_attribute_003_1.height = 140.0, 100.0
	    switch_008.width, switch_008.height = 140.0, 100.0
	    switch_009.width, switch_009.height = 140.0, 100.0
	    switch_010.width, switch_010.height = 140.0, 100.0
	    set_position_001_4.width, set_position_001_4.height = 140.0, 100.0
	    reroute_002_4.width, reroute_002_4.height = 10.0, 100.0
	    reroute_018_4.width, reroute_018_4.height = 10.0, 100.0
	    reroute_017_4.width, reroute_017_4.height = 10.0, 100.0
	    group_input_009_2.width, group_input_009_2.height = 140.0, 100.0
	    position_3.width, position_3.height = 140.0, 100.0
	    named_attribute_001.width, named_attribute_001.height = 140.0, 100.0
	    capture_attribute_001_3.width, capture_attribute_001_3.height = 140.0, 100.0
	    group_input_004_3.width, group_input_004_3.height = 140.0, 100.0
	    domain_size_002.width, domain_size_002.height = 140.0, 100.0
	    compare_001_3.width, compare_001_3.height = 140.0, 100.0
	    object_info_001.width, object_info_001.height = 140.0, 100.0
	    group_input_002_3.width, group_input_002_3.height = 140.0, 100.0
	    switch_005_1.width, switch_005_1.height = 140.0, 100.0
	    domain_size_003.width, domain_size_003.height = 140.0, 100.0
	    compare_002_3.width, compare_002_3.height = 140.0, 100.0
	    named_attribute_2.width, named_attribute_2.height = 140.0, 100.0
	    reroute_6.width, reroute_6.height = 10.0, 100.0
	    group_input_005_3.width, group_input_005_3.height = 140.0, 100.0
	    set_position_4.width, set_position_4.height = 140.0, 100.0
	    switch_007.width, switch_007.height = 140.0, 100.0
	    reroute_015_4.width, reroute_015_4.height = 10.0, 100.0
	    reroute_011_4.width, reroute_011_4.height = 10.0, 100.0
	    group_input_6.width, group_input_6.height = 140.0, 100.0
	    capture_attribute_002_3.width, capture_attribute_002_3.height = 140.0, 100.0
	    reroute_001_6.width, reroute_001_6.height = 10.0, 100.0
	    sample_nearest_surface.width, sample_nearest_surface.height = 149.33627319335938, 100.0
	    group_5.width, group_5.height = 140.0, 100.0
	    group_input_001_4.width, group_input_001_4.height = 140.0, 100.0
	    reroute_020_3.width, reroute_020_3.height = 10.0, 100.0
	    normal_1.width, normal_1.height = 140.0, 100.0
	    capture_attribute_4.width, capture_attribute_4.height = 140.0, 100.0
	    sample_uv_surface.width, sample_uv_surface.height = 140.0, 100.0
	    sample_uv_surface_003.width, sample_uv_surface_003.height = 140.0, 100.0
	    reroute_004_5.width, reroute_004_5.height = 10.0, 100.0
	    sample_uv_surface_001.width, sample_uv_surface_001.height = 140.0, 100.0
	    group_001_4.width, group_001_4.height = 140.0, 100.0
	    position_001_2.width, position_001_2.height = 140.0, 100.0
	    vector_math_5.width, vector_math_5.height = 140.0, 100.0
	    vector_math_001_5.width, vector_math_001_5.height = 140.0, 100.0
	    vector_math_004_4.width, vector_math_004_4.height = 140.0, 100.0
	    vector_math_003_4.width, vector_math_003_4.height = 140.0, 100.0
	    group_input_003_4.width, group_input_003_4.height = 140.0, 100.0
	    group_input_006_3.width, group_input_006_3.height = 140.0, 100.0
	    switch_003_5.width, switch_003_5.height = 140.0, 100.0
	    switch_002_4.width, switch_002_4.height = 140.0, 100.0
	    vector_math_002_4.width, vector_math_002_4.height = 140.0, 100.0
	    vector_math_005_2.width, vector_math_005_2.height = 140.0, 100.0
	    boolean_math_4.width, boolean_math_4.height = 140.0, 100.0
	    spline_parameter_1.width, spline_parameter_1.height = 140.0, 100.0
	    group_input_008_2.width, group_input_008_2.height = 140.0, 100.0
	    map_range_1.width, map_range_1.height = 140.0, 100.0
	    compare_4.width, compare_4.height = 140.0, 100.0
	    switch_004_2.width, switch_004_2.height = 140.0, 100.0
	    position_002_3.width, position_002_3.height = 140.0, 100.0
	    evaluate_on_domain_2.width, evaluate_on_domain_2.height = 140.0, 100.0
	    reroute_009_4.width, reroute_009_4.height = 10.0, 100.0
	    evaluate_on_domain_002_2.width, evaluate_on_domain_002_2.height = 140.0, 100.0
	    switch_006_1.width, switch_006_1.height = 140.0, 100.0
	    vector_rotate_1.width, vector_rotate_1.height = 140.0, 100.0
	    vector_rotate_003.width, vector_rotate_003.height = 140.0, 100.0
	    align_euler_to_vector_003.width, align_euler_to_vector_003.height = 140.0, 100.0
	    align_euler_to_vector_002.width, align_euler_to_vector_002.height = 140.0, 100.0
	    evaluate_on_domain_003.width, evaluate_on_domain_003.height = 140.0, 100.0
	    switch_001_6.width, switch_001_6.height = 140.0, 100.0
	    accumulate_field_2.width, accumulate_field_2.height = 140.0, 100.0
	    sample_index_001_2.width, sample_index_001_2.height = 140.0, 100.0
	    reroute_019_3.width, reroute_019_3.height = 10.0, 100.0
	    named_attribute_002.width, named_attribute_002.height = 140.0, 100.0
	    reroute_007_4.width, reroute_007_4.height = 10.0, 100.0
	    reroute_008_4.width, reroute_008_4.height = 10.0, 100.0
	    sample_index_2.width, sample_index_2.height = 140.0, 100.0
	
	    #initialize attach_hair_curves_to_surface links
	    #domain_size_002.Face Count -> compare_001_3.A
	    attach_hair_curves_to_surface.links.new(domain_size_002.outputs[2], compare_001_3.inputs[2])
	    #compare_001_3.Result -> switch_005_1.Switch
	    attach_hair_curves_to_surface.links.new(compare_001_3.outputs[0], switch_005_1.inputs[0])
	    #group_input_002_3.Surface -> object_info_001.Object
	    attach_hair_curves_to_surface.links.new(group_input_002_3.outputs[2], object_info_001.inputs[0])
	    #group_input_004_3.Surface -> domain_size_002.Geometry
	    attach_hair_curves_to_surface.links.new(group_input_004_3.outputs[1], domain_size_002.inputs[0])
	    #group_input_004_3.Surface -> switch_005_1.True
	    attach_hair_curves_to_surface.links.new(group_input_004_3.outputs[1], switch_005_1.inputs[2])
	    #group_input_001_4.Surface UV Map -> sample_nearest_surface.Value
	    attach_hair_curves_to_surface.links.new(group_input_001_4.outputs[3], sample_nearest_surface.inputs[1])
	    #reroute_6.Output -> set_position_4.Geometry
	    attach_hair_curves_to_surface.links.new(reroute_6.outputs[0], set_position_4.inputs[0])
	    #reroute_6.Output -> switch_007.False
	    attach_hair_curves_to_surface.links.new(reroute_6.outputs[0], switch_007.inputs[1])
	    #set_position_4.Geometry -> switch_007.True
	    attach_hair_curves_to_surface.links.new(set_position_4.outputs[0], switch_007.inputs[2])
	    #switch_005_1.Output -> reroute_6.Input
	    attach_hair_curves_to_surface.links.new(switch_005_1.outputs[0], reroute_6.inputs[0])
	    #group_input_005_3.Surface Rest Position -> switch_007.Switch
	    attach_hair_curves_to_surface.links.new(group_input_005_3.outputs[4], switch_007.inputs[0])
	    #named_attribute_2.Attribute -> set_position_4.Position
	    attach_hair_curves_to_surface.links.new(named_attribute_2.outputs[0], set_position_4.inputs[2])
	    #named_attribute_2.Exists -> set_position_4.Selection
	    attach_hair_curves_to_surface.links.new(named_attribute_2.outputs[1], set_position_4.inputs[1])
	    #switch_007.Output -> sample_nearest_surface.Mesh
	    attach_hair_curves_to_surface.links.new(switch_007.outputs[0], sample_nearest_surface.inputs[0])
	    #object_info_001.Geometry -> switch_005_1.False
	    attach_hair_curves_to_surface.links.new(object_info_001.outputs[4], switch_005_1.inputs[1])
	    #group_5.Root Position -> sample_nearest_surface.Sample Position
	    attach_hair_curves_to_surface.links.new(group_5.outputs[1], sample_nearest_surface.inputs[3])
	    #reroute_002_4.Output -> sample_uv_surface.UV Map
	    attach_hair_curves_to_surface.links.new(reroute_002_4.outputs[0], sample_uv_surface.inputs[2])
	    #position_3.Position -> sample_uv_surface.Value
	    attach_hair_curves_to_surface.links.new(position_3.outputs[0], sample_uv_surface.inputs[1])
	    #reroute_004_5.Output -> sample_uv_surface.Sample UV
	    attach_hair_curves_to_surface.links.new(reroute_004_5.outputs[0], sample_uv_surface.inputs[3])
	    #capture_attribute_001_3.Geometry -> set_position_001_4.Geometry
	    attach_hair_curves_to_surface.links.new(capture_attribute_001_3.outputs[0], set_position_001_4.inputs[0])
	    #reroute_017_4.Output -> sample_uv_surface_001.Mesh
	    attach_hair_curves_to_surface.links.new(reroute_017_4.outputs[0], sample_uv_surface_001.inputs[0])
	    #reroute_004_5.Output -> sample_uv_surface_001.Sample UV
	    attach_hair_curves_to_surface.links.new(reroute_004_5.outputs[0], sample_uv_surface_001.inputs[3])
	    #reroute_002_4.Output -> sample_uv_surface_001.UV Map
	    attach_hair_curves_to_surface.links.new(reroute_002_4.outputs[0], sample_uv_surface_001.inputs[2])
	    #normal_1.Normal -> capture_attribute_4.Value
	    attach_hair_curves_to_surface.links.new(normal_1.outputs[0], capture_attribute_4.inputs[1])
	    #reroute_018_4.Output -> sample_uv_surface_001.Value
	    attach_hair_curves_to_surface.links.new(reroute_018_4.outputs[0], sample_uv_surface_001.inputs[1])
	    #sample_uv_surface.Value -> vector_math_5.Vector
	    attach_hair_curves_to_surface.links.new(sample_uv_surface.outputs[0], vector_math_5.inputs[0])
	    #group_001_4.Root Position -> vector_math_5.Vector
	    attach_hair_curves_to_surface.links.new(group_001_4.outputs[1], vector_math_5.inputs[1])
	    #vector_math_5.Vector -> evaluate_on_domain_2.Value
	    attach_hair_curves_to_surface.links.new(vector_math_5.outputs[0], evaluate_on_domain_2.inputs[0])
	    #position_001_2.Position -> vector_math_001_5.Vector
	    attach_hair_curves_to_surface.links.new(position_001_2.outputs[0], vector_math_001_5.inputs[0])
	    #group_001_4.Root Position -> vector_math_001_5.Vector
	    attach_hair_curves_to_surface.links.new(group_001_4.outputs[1], vector_math_001_5.inputs[1])
	    #switch_006_1.Output -> vector_rotate_1.Vector
	    attach_hair_curves_to_surface.links.new(switch_006_1.outputs[0], vector_rotate_1.inputs[0])
	    #reroute_007_4.Output -> sample_index_2.Geometry
	    attach_hair_curves_to_surface.links.new(reroute_007_4.outputs[0], sample_index_2.inputs[0])
	    #named_attribute_002.Attribute -> sample_index_2.Index
	    attach_hair_curves_to_surface.links.new(named_attribute_002.outputs[0], sample_index_2.inputs[2])
	    #position_002_3.Position -> vector_math_004_4.Vector
	    attach_hair_curves_to_surface.links.new(position_002_3.outputs[0], vector_math_004_4.inputs[0])
	    #vector_math_002_4.Vector -> vector_math_003_4.Vector
	    attach_hair_curves_to_surface.links.new(vector_math_002_4.outputs[0], vector_math_003_4.inputs[0])
	    #switch_003_5.Output -> vector_math_002_4.Vector
	    attach_hair_curves_to_surface.links.new(switch_003_5.outputs[0], vector_math_002_4.inputs[0])
	    #switch_002_4.Output -> vector_math_002_4.Vector
	    attach_hair_curves_to_surface.links.new(switch_002_4.outputs[0], vector_math_002_4.inputs[1])
	    #reroute_009_4.Output -> vector_rotate_003.Vector
	    attach_hair_curves_to_surface.links.new(reroute_009_4.outputs[0], vector_rotate_003.inputs[0])
	    #evaluate_on_domain_002_2.Value -> vector_rotate_003.Rotation
	    attach_hair_curves_to_surface.links.new(evaluate_on_domain_002_2.outputs[0], vector_rotate_003.inputs[4])
	    #evaluate_on_domain_003.Value -> vector_rotate_1.Rotation
	    attach_hair_curves_to_surface.links.new(evaluate_on_domain_003.outputs[0], vector_rotate_1.inputs[4])
	    #group_001_4.Root Position -> vector_math_004_4.Vector
	    attach_hair_curves_to_surface.links.new(group_001_4.outputs[1], vector_math_004_4.inputs[1])
	    #vector_math_004_4.Vector -> vector_math_003_4.Vector
	    attach_hair_curves_to_surface.links.new(vector_math_004_4.outputs[0], vector_math_003_4.inputs[1])
	    #reroute_016_4.Output -> store_named_attribute_2.Geometry
	    attach_hair_curves_to_surface.links.new(reroute_016_4.outputs[0], store_named_attribute_2.inputs[0])
	    #group_input_6.Geometry -> capture_attribute_002_3.Geometry
	    attach_hair_curves_to_surface.links.new(group_input_6.outputs[0], capture_attribute_002_3.inputs[0])
	    #reroute_003_4.Output -> store_named_attribute_2.Value
	    attach_hair_curves_to_surface.links.new(reroute_003_4.outputs[0], store_named_attribute_2.inputs[3])
	    #sample_nearest_surface.Value -> capture_attribute_002_3.Value
	    attach_hair_curves_to_surface.links.new(sample_nearest_surface.outputs[0], capture_attribute_002_3.inputs[1])
	    #capture_attribute_002_3.Value -> reroute_004_5.Input
	    attach_hair_curves_to_surface.links.new(capture_attribute_002_3.outputs[1], reroute_004_5.inputs[0])
	    #switch_007.Output -> capture_attribute_4.Geometry
	    attach_hair_curves_to_surface.links.new(switch_007.outputs[0], capture_attribute_4.inputs[0])
	    #align_euler_to_vector_003.Rotation -> evaluate_on_domain_002_2.Value
	    attach_hair_curves_to_surface.links.new(align_euler_to_vector_003.outputs[0], evaluate_on_domain_002_2.inputs[0])
	    #align_euler_to_vector_002.Rotation -> evaluate_on_domain_003.Value
	    attach_hair_curves_to_surface.links.new(align_euler_to_vector_002.outputs[0], evaluate_on_domain_003.inputs[0])
	    #capture_attribute_4.Geometry -> reroute_001_6.Input
	    attach_hair_curves_to_surface.links.new(capture_attribute_4.outputs[0], reroute_001_6.inputs[0])
	    #reroute_018_4.Output -> sample_uv_surface_003.Value
	    attach_hair_curves_to_surface.links.new(reroute_018_4.outputs[0], sample_uv_surface_003.inputs[1])
	    #reroute_002_4.Output -> sample_uv_surface_003.UV Map
	    attach_hair_curves_to_surface.links.new(reroute_002_4.outputs[0], sample_uv_surface_003.inputs[2])
	    #reroute_017_4.Output -> sample_uv_surface_003.Mesh
	    attach_hair_curves_to_surface.links.new(reroute_017_4.outputs[0], sample_uv_surface_003.inputs[0])
	    #named_attribute_001.Attribute -> sample_uv_surface_003.Sample UV
	    attach_hair_curves_to_surface.links.new(named_attribute_001.outputs[0], sample_uv_surface_003.inputs[3])
	    #reroute_019_3.Output -> switch_001_6.True
	    attach_hair_curves_to_surface.links.new(reroute_019_3.outputs[0], switch_001_6.inputs[2])
	    #reroute_020_3.Output -> sample_index_001_2.Geometry
	    attach_hair_curves_to_surface.links.new(reroute_020_3.outputs[0], sample_index_001_2.inputs[0])
	    #named_attribute_001.Exists -> accumulate_field_2.Value
	    attach_hair_curves_to_surface.links.new(named_attribute_001.outputs[1], accumulate_field_2.inputs[0])
	    #accumulate_field_2.Total -> sample_index_001_2.Value
	    attach_hair_curves_to_surface.links.new(accumulate_field_2.outputs[2], sample_index_001_2.inputs[1])
	    #sample_index_001_2.Value -> switch_001_6.Switch
	    attach_hair_curves_to_surface.links.new(sample_index_001_2.outputs[0], switch_001_6.inputs[0])
	    #reroute_008_4.Output -> sample_index_2.Value
	    attach_hair_curves_to_surface.links.new(reroute_008_4.outputs[0], sample_index_2.inputs[1])
	    #vector_rotate_1.Vector -> switch_002_4.True
	    attach_hair_curves_to_surface.links.new(vector_rotate_1.outputs[0], switch_002_4.inputs[2])
	    #vector_math_001_5.Vector -> switch_002_4.False
	    attach_hair_curves_to_surface.links.new(vector_math_001_5.outputs[0], switch_002_4.inputs[1])
	    #group_input_003_4.Align to Surface Normal -> switch_002_4.Switch
	    attach_hair_curves_to_surface.links.new(group_input_003_4.outputs[7], switch_002_4.inputs[0])
	    #vector_math_005_2.Vector -> set_position_001_4.Offset
	    attach_hair_curves_to_surface.links.new(vector_math_005_2.outputs[0], set_position_001_4.inputs[3])
	    #evaluate_on_domain_2.Value -> switch_003_5.True
	    attach_hair_curves_to_surface.links.new(evaluate_on_domain_2.outputs[0], switch_003_5.inputs[2])
	    #group_input_006_3.Snap to Surface -> switch_003_5.Switch
	    attach_hair_curves_to_surface.links.new(group_input_006_3.outputs[6], switch_003_5.inputs[0])
	    #group_input_006_3.Snap to Surface -> boolean_math_4.Boolean
	    attach_hair_curves_to_surface.links.new(group_input_006_3.outputs[6], boolean_math_4.inputs[0])
	    #group_input_003_4.Align to Surface Normal -> boolean_math_4.Boolean
	    attach_hair_curves_to_surface.links.new(group_input_003_4.outputs[7], boolean_math_4.inputs[1])
	    #boolean_math_4.Boolean -> set_position_001_4.Selection
	    attach_hair_curves_to_surface.links.new(boolean_math_4.outputs[0], set_position_001_4.inputs[1])
	    #capture_attribute_002_3.Value -> reroute_003_4.Input
	    attach_hair_curves_to_surface.links.new(capture_attribute_002_3.outputs[1], reroute_003_4.inputs[0])
	    #switch_009.Output -> group_output_9.Surface UV Coordinate
	    attach_hair_curves_to_surface.links.new(switch_009.outputs[0], group_output_9.inputs[1])
	    #store_named_attribute_2.Geometry -> switch_5.True
	    attach_hair_curves_to_surface.links.new(store_named_attribute_2.outputs[0], switch_5.inputs[2])
	    #group_input_007_3.Sample Attachment UV -> switch_5.Switch
	    attach_hair_curves_to_surface.links.new(group_input_007_3.outputs[5], switch_5.inputs[0])
	    #reroute_016_4.Output -> switch_5.False
	    attach_hair_curves_to_surface.links.new(reroute_016_4.outputs[0], switch_5.inputs[1])
	    #switch_5.Output -> store_named_attribute_001.Geometry
	    attach_hair_curves_to_surface.links.new(switch_5.outputs[0], store_named_attribute_001.inputs[0])
	    #reroute_020_3.Output -> capture_attribute_001_3.Geometry
	    attach_hair_curves_to_surface.links.new(reroute_020_3.outputs[0], capture_attribute_001_3.inputs[0])
	    #reroute_005_4.Output -> store_named_attribute_001.Value
	    attach_hair_curves_to_surface.links.new(reroute_005_4.outputs[0], store_named_attribute_001.inputs[3])
	    #capture_attribute_001_3.Value -> reroute_005_4.Input
	    attach_hair_curves_to_surface.links.new(capture_attribute_001_3.outputs[1], reroute_005_4.inputs[0])
	    #switch_010.Output -> group_output_9.Surface Normal
	    attach_hair_curves_to_surface.links.new(switch_010.outputs[0], group_output_9.inputs[2])
	    #sample_uv_surface_001.Value -> capture_attribute_001_3.Value
	    attach_hair_curves_to_surface.links.new(sample_uv_surface_001.outputs[0], capture_attribute_001_3.inputs[1])
	    #vector_math_003_4.Vector -> vector_math_005_2.Vector
	    attach_hair_curves_to_surface.links.new(vector_math_003_4.outputs[0], vector_math_005_2.inputs[0])
	    #spline_parameter_1.Factor -> map_range_1.Value
	    attach_hair_curves_to_surface.links.new(spline_parameter_1.outputs[0], map_range_1.inputs[0])
	    #group_input_008_2.Blend along Curve -> map_range_1.From Max
	    attach_hair_curves_to_surface.links.new(group_input_008_2.outputs[8], map_range_1.inputs[2])
	    #group_input_008_2.Blend along Curve -> compare_4.A
	    attach_hair_curves_to_surface.links.new(group_input_008_2.outputs[8], compare_4.inputs[0])
	    #compare_4.Result -> switch_004_2.Switch
	    attach_hair_curves_to_surface.links.new(compare_4.outputs[0], switch_004_2.inputs[0])
	    #map_range_1.Result -> switch_004_2.False
	    attach_hair_curves_to_surface.links.new(map_range_1.outputs[0], switch_004_2.inputs[1])
	    #switch_004_2.Output -> vector_math_005_2.Scale
	    attach_hair_curves_to_surface.links.new(switch_004_2.outputs[0], vector_math_005_2.inputs[3])
	    #switch_001_6.Output -> align_euler_to_vector_003.Vector
	    attach_hair_curves_to_surface.links.new(switch_001_6.outputs[0], align_euler_to_vector_003.inputs[2])
	    #sample_index_2.Value -> switch_001_6.False
	    attach_hair_curves_to_surface.links.new(sample_index_2.outputs[0], switch_001_6.inputs[1])
	    #named_attribute_002.Exists -> switch_006_1.Switch
	    attach_hair_curves_to_surface.links.new(named_attribute_002.outputs[1], switch_006_1.inputs[0])
	    #reroute_009_4.Output -> switch_006_1.False
	    attach_hair_curves_to_surface.links.new(reroute_009_4.outputs[0], switch_006_1.inputs[1])
	    #vector_rotate_003.Vector -> switch_006_1.True
	    attach_hair_curves_to_surface.links.new(vector_rotate_003.outputs[0], switch_006_1.inputs[2])
	    #vector_math_001_5.Vector -> reroute_009_4.Input
	    attach_hair_curves_to_surface.links.new(vector_math_001_5.outputs[0], reroute_009_4.inputs[0])
	    #reroute_011_4.Output -> reroute_010_3.Input
	    attach_hair_curves_to_surface.links.new(reroute_011_4.outputs[0], reroute_010_3.inputs[0])
	    #group_input_6.Geometry -> reroute_011_4.Input
	    attach_hair_curves_to_surface.links.new(group_input_6.outputs[0], reroute_011_4.inputs[0])
	    #store_named_attribute_001.Geometry -> switch_008.False
	    attach_hair_curves_to_surface.links.new(store_named_attribute_001.outputs[0], switch_008.inputs[1])
	    #reroute_006_4.Output -> switch_008.True
	    attach_hair_curves_to_surface.links.new(reroute_006_4.outputs[0], switch_008.inputs[2])
	    #switch_008.Output -> group_output_9.Geometry
	    attach_hair_curves_to_surface.links.new(switch_008.outputs[0], group_output_9.inputs[0])
	    #reroute_003_4.Output -> switch_009.False
	    attach_hair_curves_to_surface.links.new(reroute_003_4.outputs[0], switch_009.inputs[1])
	    #reroute_005_4.Output -> switch_010.False
	    attach_hair_curves_to_surface.links.new(reroute_005_4.outputs[0], switch_010.inputs[1])
	    #domain_size_003.Face Count -> compare_002_3.A
	    attach_hair_curves_to_surface.links.new(domain_size_003.outputs[2], compare_002_3.inputs[2])
	    #switch_005_1.Output -> domain_size_003.Geometry
	    attach_hair_curves_to_surface.links.new(switch_005_1.outputs[0], domain_size_003.inputs[0])
	    #reroute_012_5.Output -> switch_008.Switch
	    attach_hair_curves_to_surface.links.new(reroute_012_5.outputs[0], switch_008.inputs[0])
	    #reroute_014_4.Output -> reroute_012_5.Input
	    attach_hair_curves_to_surface.links.new(reroute_014_4.outputs[0], reroute_012_5.inputs[0])
	    #reroute_012_5.Output -> switch_009.Switch
	    attach_hair_curves_to_surface.links.new(reroute_012_5.outputs[0], switch_009.inputs[0])
	    #reroute_012_5.Output -> switch_010.Switch
	    attach_hair_curves_to_surface.links.new(reroute_012_5.outputs[0], switch_010.inputs[0])
	    #named_attribute_003_1.Attribute -> switch_009.True
	    attach_hair_curves_to_surface.links.new(named_attribute_003_1.outputs[0], switch_009.inputs[2])
	    #named_attribute_004.Attribute -> switch_010.True
	    attach_hair_curves_to_surface.links.new(named_attribute_004.outputs[0], switch_010.inputs[2])
	    #reroute_015_4.Output -> reroute_013_4.Input
	    attach_hair_curves_to_surface.links.new(reroute_015_4.outputs[0], reroute_013_4.inputs[0])
	    #reroute_013_4.Output -> reroute_014_4.Input
	    attach_hair_curves_to_surface.links.new(reroute_013_4.outputs[0], reroute_014_4.inputs[0])
	    #compare_002_3.Result -> reroute_015_4.Input
	    attach_hair_curves_to_surface.links.new(compare_002_3.outputs[0], reroute_015_4.inputs[0])
	    #set_position_001_4.Geometry -> reroute_016_4.Input
	    attach_hair_curves_to_surface.links.new(set_position_001_4.outputs[0], reroute_016_4.inputs[0])
	    #capture_attribute_4.Geometry -> reroute_017_4.Input
	    attach_hair_curves_to_surface.links.new(capture_attribute_4.outputs[0], reroute_017_4.inputs[0])
	    #capture_attribute_4.Value -> reroute_018_4.Input
	    attach_hair_curves_to_surface.links.new(capture_attribute_4.outputs[1], reroute_018_4.inputs[0])
	    #reroute_010_3.Output -> reroute_006_4.Input
	    attach_hair_curves_to_surface.links.new(reroute_010_3.outputs[0], reroute_006_4.inputs[0])
	    #reroute_001_6.Output -> reroute_007_4.Input
	    attach_hair_curves_to_surface.links.new(reroute_001_6.outputs[0], reroute_007_4.inputs[0])
	    #sample_uv_surface_001.Value -> reroute_008_4.Input
	    attach_hair_curves_to_surface.links.new(sample_uv_surface_001.outputs[0], reroute_008_4.inputs[0])
	    #reroute_008_4.Output -> align_euler_to_vector_002.Vector
	    attach_hair_curves_to_surface.links.new(reroute_008_4.outputs[0], align_euler_to_vector_002.inputs[2])
	    #sample_uv_surface_003.Value -> reroute_019_3.Input
	    attach_hair_curves_to_surface.links.new(sample_uv_surface_003.outputs[0], reroute_019_3.inputs[0])
	    #reroute_017_4.Output -> sample_uv_surface.Mesh
	    attach_hair_curves_to_surface.links.new(reroute_017_4.outputs[0], sample_uv_surface.inputs[0])
	    #group_input_009_2.Surface UV Map -> reroute_002_4.Input
	    attach_hair_curves_to_surface.links.new(group_input_009_2.outputs[3], reroute_002_4.inputs[0])
	    #capture_attribute_002_3.Geometry -> reroute_020_3.Input
	    attach_hair_curves_to_surface.links.new(capture_attribute_002_3.outputs[0], reroute_020_3.inputs[0])
	    return attach_hair_curves_to_surface
	
	attach_hair_curves_to_surface = attach_hair_curves_to_surface_node_group()
	
	#initialize baby_hairs node group
	def baby_hairs_node_group():
	    baby_hairs = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "BABY_HAIRS")
	
	    baby_hairs.color_tag = 'NONE'
	    baby_hairs.description = "Draw baby hairs outside of main scalp hairs."
	    baby_hairs.default_group_node_width = 140
	    
	
	    baby_hairs.is_modifier = True
	
	    #baby_hairs interface
	    #Socket Geometry
	    geometry_socket_10 = baby_hairs.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_10.attribute_domain = 'POINT'
	    geometry_socket_10.description = "Baby hairs."
	
	    #Socket Geometry
	    geometry_socket_11 = baby_hairs.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_11.attribute_domain = 'POINT'
	    geometry_socket_11.description = "Drawn hair curves."
	
	    #Socket Surface
	    surface_socket_3 = baby_hairs.interface.new_socket(name = "Surface", in_out='INPUT', socket_type = 'NodeSocketObject')
	    surface_socket_3.attribute_domain = 'POINT'
	    surface_socket_3.description = "Surface mesh to attach hairs."
	
	    #Socket Surface Offset
	    surface_offset_socket = baby_hairs.interface.new_socket(name = "Surface Offset", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    surface_offset_socket.default_value = 0.0010000000474974513
	    surface_offset_socket.min_value = 0.0
	    surface_offset_socket.max_value = 10000.0
	    surface_offset_socket.subtype = 'NONE'
	    surface_offset_socket.attribute_domain = 'POINT'
	    surface_offset_socket.description = "Offset hair from surface."
	
	    #Socket Mirror X
	    mirror_x_socket = baby_hairs.interface.new_socket(name = "Mirror X", in_out='INPUT', socket_type = 'NodeSocketBool')
	    mirror_x_socket.default_value = True
	    mirror_x_socket.attribute_domain = 'POINT'
	    mirror_x_socket.description = "Mirror hair across x position."
	
	    #Socket Scalp Hairs
	    scalp_hairs_socket = baby_hairs.interface.new_socket(name = "Scalp Hairs", in_out='INPUT', socket_type = 'NodeSocketObject')
	    scalp_hairs_socket.attribute_domain = 'POINT'
	    scalp_hairs_socket.description = "Scalp hairs used to distance overlapping hairs from."
	
	    #Socket Trim distance
	    trim_distance_socket = baby_hairs.interface.new_socket(name = "Trim distance", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    trim_distance_socket.default_value = 0.0
	    trim_distance_socket.min_value = 0.0
	    trim_distance_socket.max_value = 10000.0
	    trim_distance_socket.subtype = 'NONE'
	    trim_distance_socket.attribute_domain = 'POINT'
	    trim_distance_socket.description = "Distance threshold from scalp hairs used to trim hairs."
	
	    #Socket Material
	    material_socket = baby_hairs.interface.new_socket(name = "Material", in_out='INPUT', socket_type = 'NodeSocketMaterial')
	    material_socket.attribute_domain = 'POINT'
	    material_socket.description = "Hair material."
	
	    #Socket Control Points
	    control_points_socket = baby_hairs.interface.new_socket(name = "Control Points", in_out='INPUT', socket_type = 'NodeSocketInt')
	    control_points_socket.default_value = 8
	    control_points_socket.min_value = 2
	    control_points_socket.max_value = 100000
	    control_points_socket.subtype = 'NONE'
	    control_points_socket.attribute_domain = 'POINT'
	    control_points_socket.description = "Amount of points for each hair curve."
	
	    #Socket Hair Radius
	    hair_radius_socket = baby_hairs.interface.new_socket(name = "Hair Radius", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    hair_radius_socket.default_value = 0.003000000026077032
	    hair_radius_socket.min_value = 0.0
	    hair_radius_socket.max_value = 3.4028234663852886e+38
	    hair_radius_socket.subtype = 'DISTANCE'
	    hair_radius_socket.attribute_domain = 'POINT'
	    hair_radius_socket.description = "Radius of hair strands."
	
	    #Panel Children Hairs Settings
	    children_hairs_settings_panel = baby_hairs.interface.new_panel("Children Hairs Settings", default_closed=True)
	    children_hairs_settings_panel.description = "Settings for Duplicate Hairs."
	    #Socket Duplicate Amount
	    duplicate_amount_socket = baby_hairs.interface.new_socket(name = "Duplicate Amount", in_out='INPUT', socket_type = 'NodeSocketInt', parent = children_hairs_settings_panel)
	    duplicate_amount_socket.default_value = 10
	    duplicate_amount_socket.min_value = 0
	    duplicate_amount_socket.max_value = 2147483647
	    duplicate_amount_socket.subtype = 'NONE'
	    duplicate_amount_socket.attribute_domain = 'POINT'
	    duplicate_amount_socket.description = "Amount of duplicates per curve."
	
	    #Socket Duplicate Viewport Amount
	    duplicate_viewport_amount_socket = baby_hairs.interface.new_socket(name = "Duplicate Viewport Amount", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = children_hairs_settings_panel)
	    duplicate_viewport_amount_socket.default_value = 1.0
	    duplicate_viewport_amount_socket.min_value = 0.0
	    duplicate_viewport_amount_socket.max_value = 1.0
	    duplicate_viewport_amount_socket.subtype = 'FACTOR'
	    duplicate_viewport_amount_socket.attribute_domain = 'POINT'
	    duplicate_viewport_amount_socket.description = "Percentage of amount used for the viewport."
	
	    #Socket Duplicate Radius
	    duplicate_radius_socket = baby_hairs.interface.new_socket(name = "Duplicate Radius", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = children_hairs_settings_panel)
	    duplicate_radius_socket.default_value = 0.09999999403953552
	    duplicate_radius_socket.min_value = 0.0
	    duplicate_radius_socket.max_value = 3.4028234663852886e+38
	    duplicate_radius_socket.subtype = 'DISTANCE'
	    duplicate_radius_socket.attribute_domain = 'POINT'
	    duplicate_radius_socket.description = "Radius in which the duplicate curves are offset from the guides."
	
	    #Socket Duplicate Distribution Shape
	    duplicate_distribution_shape_socket = baby_hairs.interface.new_socket(name = "Duplicate Distribution Shape", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = children_hairs_settings_panel)
	    duplicate_distribution_shape_socket.default_value = 0.0
	    duplicate_distribution_shape_socket.min_value = -10.0
	    duplicate_distribution_shape_socket.max_value = 10.0
	    duplicate_distribution_shape_socket.subtype = 'NONE'
	    duplicate_distribution_shape_socket.attribute_domain = 'POINT'
	    duplicate_distribution_shape_socket.description = "Shape of distribution from center to the edge around the guide."
	
	    #Socket Duplicate Tip Roundness
	    duplicate_tip_roundness_socket = baby_hairs.interface.new_socket(name = "Duplicate Tip Roundness", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = children_hairs_settings_panel)
	    duplicate_tip_roundness_socket.default_value = 0.0
	    duplicate_tip_roundness_socket.min_value = 0.0
	    duplicate_tip_roundness_socket.max_value = 1.0
	    duplicate_tip_roundness_socket.subtype = 'FACTOR'
	    duplicate_tip_roundness_socket.attribute_domain = 'POINT'
	    duplicate_tip_roundness_socket.description = "Offset of the curves to round the tip"
	
	    #Socket Duplicate Even Thickness
	    duplicate_even_thickness_socket = baby_hairs.interface.new_socket(name = "Duplicate Even Thickness", in_out='INPUT', socket_type = 'NodeSocketBool', parent = children_hairs_settings_panel)
	    duplicate_even_thickness_socket.default_value = False
	    duplicate_even_thickness_socket.attribute_domain = 'POINT'
	    duplicate_even_thickness_socket.description = "Keep an even thickness of the distribution of duplicates."
	
	    #Socket Duplicate Seed
	    duplicate_seed_socket = baby_hairs.interface.new_socket(name = "Duplicate Seed", in_out='INPUT', socket_type = 'NodeSocketInt', parent = children_hairs_settings_panel)
	    duplicate_seed_socket.default_value = 0
	    duplicate_seed_socket.min_value = -10000
	    duplicate_seed_socket.max_value = 10000
	    duplicate_seed_socket.subtype = 'NONE'
	    duplicate_seed_socket.attribute_domain = 'POINT'
	    duplicate_seed_socket.description = "Random Seed for duplicate hairs."
	
	
	    #Panel Clump Settings
	    clump_settings_panel = baby_hairs.interface.new_panel("Clump Settings", default_closed=True)
	    clump_settings_panel.description = "Settings for hair clumping."
	    #Socket Clump Guide Distance
	    clump_guide_distance_socket = baby_hairs.interface.new_socket(name = "Clump Guide Distance", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = clump_settings_panel)
	    clump_guide_distance_socket.default_value = 0.10000000149011612
	    clump_guide_distance_socket.min_value = 0.0
	    clump_guide_distance_socket.max_value = 3.4028234663852886e+38
	    clump_guide_distance_socket.subtype = 'DISTANCE'
	    clump_guide_distance_socket.attribute_domain = 'POINT'
	    clump_guide_distance_socket.description = "Minimum distance between two guides for new guide map."
	
	    #Socket Clump Factor
	    clump_factor_socket = baby_hairs.interface.new_socket(name = "Clump Factor", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = clump_settings_panel)
	    clump_factor_socket.default_value = 1.0
	    clump_factor_socket.min_value = 0.0
	    clump_factor_socket.max_value = 1.0
	    clump_factor_socket.subtype = 'FACTOR'
	    clump_factor_socket.attribute_domain = 'POINT'
	    clump_factor_socket.description = "Factor to blend overall clumping."
	
	    #Socket Clump Shape
	    clump_shape_socket = baby_hairs.interface.new_socket(name = "Clump Shape", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = clump_settings_panel)
	    clump_shape_socket.default_value = 0.5
	    clump_shape_socket.min_value = -1.0
	    clump_shape_socket.max_value = 1.0
	    clump_shape_socket.subtype = 'NONE'
	    clump_shape_socket.attribute_domain = 'POINT'
	    clump_shape_socket.description = "Shape of the influence along curves. (0=constant, 0.5=linear)"
	
	    #Socket Clump Tip Spread
	    clump_tip_spread_socket = baby_hairs.interface.new_socket(name = "Clump Tip Spread", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = clump_settings_panel)
	    clump_tip_spread_socket.default_value = 0.0
	    clump_tip_spread_socket.min_value = 0.0
	    clump_tip_spread_socket.max_value = 10.0
	    clump_tip_spread_socket.subtype = 'NONE'
	    clump_tip_spread_socket.attribute_domain = 'POINT'
	    clump_tip_spread_socket.description = "Distance of random spread at the curve tips."
	
	    #Socket Clump Offset
	    clump_offset_socket_1 = baby_hairs.interface.new_socket(name = "Clump Offset", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = clump_settings_panel)
	    clump_offset_socket_1.default_value = 0.0
	    clump_offset_socket_1.min_value = -3.4028234663852886e+38
	    clump_offset_socket_1.max_value = 3.4028234663852886e+38
	    clump_offset_socket_1.subtype = 'DISTANCE'
	    clump_offset_socket_1.attribute_domain = 'POINT'
	    clump_offset_socket_1.description = "Offset of each clump in a random direction."
	
	    #Socket Clump Distance Falloff
	    clump_distance_falloff_socket = baby_hairs.interface.new_socket(name = "Clump Distance Falloff", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = clump_settings_panel)
	    clump_distance_falloff_socket.default_value = 0.0
	    clump_distance_falloff_socket.min_value = 0.0
	    clump_distance_falloff_socket.max_value = 3.4028234663852886e+38
	    clump_distance_falloff_socket.subtype = 'DISTANCE'
	    clump_distance_falloff_socket.attribute_domain = 'POINT'
	    clump_distance_falloff_socket.description = "Falloff distance for the clumping effect. (0 means no falloff)"
	
	    #Socket Clump Distance Threshold
	    clump_distance_threshold_socket = baby_hairs.interface.new_socket(name = "Clump Distance Threshold", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = clump_settings_panel)
	    clump_distance_threshold_socket.default_value = 0.0
	    clump_distance_threshold_socket.min_value = 0.0
	    clump_distance_threshold_socket.max_value = 3.4028234663852886e+38
	    clump_distance_threshold_socket.subtype = 'DISTANCE'
	    clump_distance_threshold_socket.attribute_domain = 'POINT'
	    clump_distance_threshold_socket.description = "Distance threshold for the falloff around the guide."
	
	    #Socket Clump Seed
	    clump_seed_socket = baby_hairs.interface.new_socket(name = "Clump Seed", in_out='INPUT', socket_type = 'NodeSocketInt', parent = clump_settings_panel)
	    clump_seed_socket.default_value = 0
	    clump_seed_socket.min_value = -10000
	    clump_seed_socket.max_value = 10000
	    clump_seed_socket.subtype = 'NONE'
	    clump_seed_socket.attribute_domain = 'POINT'
	    clump_seed_socket.description = "Random seed for hair clumping."
	
	    #Socket Preserve Length
	    preserve_length_socket_1 = baby_hairs.interface.new_socket(name = "Preserve Length", in_out='INPUT', socket_type = 'NodeSocketBool', parent = clump_settings_panel)
	    preserve_length_socket_1.default_value = False
	    preserve_length_socket_1.attribute_domain = 'POINT'
	    preserve_length_socket_1.description = "Preserve each curve's length during deformation."
	
	
	    #Panel Extra Hairs Settings
	    extra_hairs_settings_panel = baby_hairs.interface.new_panel("Extra Hairs Settings", default_closed=True)
	    extra_hairs_settings_panel.description = "Settings for extra hairs."
	    #Socket Use Extra Hairs
	    use_extra_hairs_socket = baby_hairs.interface.new_socket(name = "Use Extra Hairs", in_out='INPUT', socket_type = 'NodeSocketBool', parent = extra_hairs_settings_panel)
	    use_extra_hairs_socket.default_value = False
	    use_extra_hairs_socket.attribute_domain = 'POINT'
	    use_extra_hairs_socket.description = "Use extra smaller hairs to add to baby hairs."
	
	    #Socket Extra Hairs Count
	    extra_hairs_count_socket = baby_hairs.interface.new_socket(name = "Extra Hairs Count", in_out='INPUT', socket_type = 'NodeSocketInt', parent = extra_hairs_settings_panel)
	    extra_hairs_count_socket.default_value = 50
	    extra_hairs_count_socket.min_value = 2
	    extra_hairs_count_socket.max_value = 100000
	    extra_hairs_count_socket.subtype = 'NONE'
	    extra_hairs_count_socket.attribute_domain = 'POINT'
	    extra_hairs_count_socket.description = "Amount of extra hairs to use."
	
	    #Socket Extra Hairs Samples
	    extra_hairs_samples_socket = baby_hairs.interface.new_socket(name = "Extra Hairs Samples", in_out='INPUT', socket_type = 'NodeSocketInt', parent = extra_hairs_settings_panel)
	    extra_hairs_samples_socket.default_value = 30
	    extra_hairs_samples_socket.min_value = 0
	    extra_hairs_samples_socket.max_value = 2147483647
	    extra_hairs_samples_socket.subtype = 'NONE'
	    extra_hairs_samples_socket.attribute_domain = 'POINT'
	    extra_hairs_samples_socket.description = "Amount of extra hairs to remove from count."
	
	    #Socket Extra Hairs Trim
	    extra_hairs_trim_socket = baby_hairs.interface.new_socket(name = "Extra Hairs Trim", in_out='INPUT', socket_type = 'NodeSocketInt', parent = extra_hairs_settings_panel)
	    extra_hairs_trim_socket.default_value = 5
	    extra_hairs_trim_socket.min_value = 0
	    extra_hairs_trim_socket.max_value = 2147483647
	    extra_hairs_trim_socket.subtype = 'NONE'
	    extra_hairs_trim_socket.attribute_domain = 'POINT'
	    extra_hairs_trim_socket.description = "Index threshold for each curve to trim hairs."
	
	    #Socket Extra Hairs Duplicate Count
	    extra_hairs_duplicate_count_socket = baby_hairs.interface.new_socket(name = "Extra Hairs Duplicate Count", in_out='INPUT', socket_type = 'NodeSocketInt', parent = extra_hairs_settings_panel)
	    extra_hairs_duplicate_count_socket.default_value = 30
	    extra_hairs_duplicate_count_socket.min_value = 0
	    extra_hairs_duplicate_count_socket.max_value = 2147483647
	    extra_hairs_duplicate_count_socket.subtype = 'NONE'
	    extra_hairs_duplicate_count_socket.attribute_domain = 'POINT'
	    extra_hairs_duplicate_count_socket.description = "Amount of extra hair duplicates to use."
	
	    #Socket Offset
	    offset_socket_1 = baby_hairs.interface.new_socket(name = "Offset", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = extra_hairs_settings_panel)
	    offset_socket_1.default_value = 0.0003000000142492354
	    offset_socket_1.min_value = 0.0
	    offset_socket_1.max_value = 10000.0
	    offset_socket_1.subtype = 'NONE'
	    offset_socket_1.attribute_domain = 'POINT'
	    offset_socket_1.description = "Offset beteween hairs."
	
	    #Socket Extra Hairs Only
	    extra_hairs_only_socket = baby_hairs.interface.new_socket(name = "Extra Hairs Only", in_out='INPUT', socket_type = 'NodeSocketBool', parent = extra_hairs_settings_panel)
	    extra_hairs_only_socket.default_value = False
	    extra_hairs_only_socket.attribute_domain = 'POINT'
	    extra_hairs_only_socket.description = "Use only extra hairs and not the baby hairs."
	
	
	
	    #initialize baby_hairs nodes
	    #node Group Input
	    group_input_7 = baby_hairs.nodes.new("NodeGroupInput")
	    group_input_7.name = "Group Input"
	    group_input_7.outputs[1].hide = True
	    group_input_7.outputs[2].hide = True
	    group_input_7.outputs[3].hide = True
	    group_input_7.outputs[4].hide = True
	    group_input_7.outputs[5].hide = True
	    group_input_7.outputs[6].hide = True
	    group_input_7.outputs[8].hide = True
	    group_input_7.outputs[9].hide = True
	    group_input_7.outputs[10].hide = True
	    group_input_7.outputs[11].hide = True
	    group_input_7.outputs[12].hide = True
	    group_input_7.outputs[13].hide = True
	    group_input_7.outputs[14].hide = True
	    group_input_7.outputs[15].hide = True
	    group_input_7.outputs[16].hide = True
	    group_input_7.outputs[17].hide = True
	    group_input_7.outputs[18].hide = True
	    group_input_7.outputs[19].hide = True
	    group_input_7.outputs[20].hide = True
	    group_input_7.outputs[21].hide = True
	    group_input_7.outputs[22].hide = True
	    group_input_7.outputs[23].hide = True
	    group_input_7.outputs[24].hide = True
	    group_input_7.outputs[25].hide = True
	    group_input_7.outputs[26].hide = True
	    group_input_7.outputs[27].hide = True
	    group_input_7.outputs[28].hide = True
	    group_input_7.outputs[29].hide = True
	    group_input_7.outputs[30].hide = True
	    group_input_7.outputs[31].hide = True
	    group_input_7.outputs[32].hide = True
	
	    #node Group Output
	    group_output_10 = baby_hairs.nodes.new("NodeGroupOutput")
	    group_output_10.name = "Group Output"
	    group_output_10.is_active_output = True
	    group_output_10.inputs[1].hide = True
	
	    #node Resample Curve
	    resample_curve = baby_hairs.nodes.new("GeometryNodeResampleCurve")
	    resample_curve.name = "Resample Curve"
	    resample_curve.keep_last_segment = False
	    resample_curve.mode = 'COUNT'
	    resample_curve.inputs[1].hide = True
	    resample_curve.inputs[3].hide = True
	    #Selection
	    resample_curve.inputs[1].default_value = True
	
	    #node Group
	    group_6 = baby_hairs.nodes.new("GeometryNodeGroup")
	    group_6.name = "Group"
	    group_6.node_tree = duplicate_hair_curves_002
	
	    #node Group.001
	    group_001_5 = baby_hairs.nodes.new("GeometryNodeGroup")
	    group_001_5.name = "Group.001"
	    group_001_5.node_tree = clump_hair_curves_001
	    group_001_5.inputs[3].hide = True
	    group_001_5.inputs[4].hide = True
	    group_001_5.outputs[1].hide = True
	    #Socket_5
	    group_001_5.inputs[3].default_value = 1.0
	    #Socket_6
	    group_001_5.inputs[4].default_value = True
	
	    #node Group.002
	    group_002_1 = baby_hairs.nodes.new("GeometryNodeGroup")
	    group_002_1.name = "Group.002"
	    group_002_1.node_tree = hair_shrinkwrap
	
	    #node Group Input.001
	    group_input_001_5 = baby_hairs.nodes.new("NodeGroupInput")
	    group_input_001_5.name = "Group Input.001"
	    group_input_001_5.outputs[0].hide = True
	    group_input_001_5.outputs[1].hide = True
	    group_input_001_5.outputs[2].hide = True
	    group_input_001_5.outputs[3].hide = True
	    group_input_001_5.outputs[4].hide = True
	    group_input_001_5.outputs[5].hide = True
	    group_input_001_5.outputs[6].hide = True
	    group_input_001_5.outputs[7].hide = True
	    group_input_001_5.outputs[8].hide = True
	    group_input_001_5.outputs[16].hide = True
	    group_input_001_5.outputs[17].hide = True
	    group_input_001_5.outputs[18].hide = True
	    group_input_001_5.outputs[19].hide = True
	    group_input_001_5.outputs[20].hide = True
	    group_input_001_5.outputs[21].hide = True
	    group_input_001_5.outputs[22].hide = True
	    group_input_001_5.outputs[23].hide = True
	    group_input_001_5.outputs[24].hide = True
	    group_input_001_5.outputs[25].hide = True
	    group_input_001_5.outputs[26].hide = True
	    group_input_001_5.outputs[27].hide = True
	    group_input_001_5.outputs[28].hide = True
	    group_input_001_5.outputs[29].hide = True
	    group_input_001_5.outputs[30].hide = True
	    group_input_001_5.outputs[31].hide = True
	    group_input_001_5.outputs[32].hide = True
	
	    #node Group Input.002
	    group_input_002_4 = baby_hairs.nodes.new("NodeGroupInput")
	    group_input_002_4.name = "Group Input.002"
	    group_input_002_4.outputs[0].hide = True
	    group_input_002_4.outputs[1].hide = True
	    group_input_002_4.outputs[2].hide = True
	    group_input_002_4.outputs[3].hide = True
	    group_input_002_4.outputs[4].hide = True
	    group_input_002_4.outputs[5].hide = True
	    group_input_002_4.outputs[6].hide = True
	    group_input_002_4.outputs[7].hide = True
	    group_input_002_4.outputs[8].hide = True
	    group_input_002_4.outputs[9].hide = True
	    group_input_002_4.outputs[10].hide = True
	    group_input_002_4.outputs[11].hide = True
	    group_input_002_4.outputs[12].hide = True
	    group_input_002_4.outputs[13].hide = True
	    group_input_002_4.outputs[14].hide = True
	    group_input_002_4.outputs[15].hide = True
	    group_input_002_4.outputs[25].hide = True
	    group_input_002_4.outputs[26].hide = True
	    group_input_002_4.outputs[27].hide = True
	    group_input_002_4.outputs[28].hide = True
	    group_input_002_4.outputs[29].hide = True
	    group_input_002_4.outputs[30].hide = True
	    group_input_002_4.outputs[31].hide = True
	    group_input_002_4.outputs[32].hide = True
	
	    #node Group Input.003
	    group_input_003_5 = baby_hairs.nodes.new("NodeGroupInput")
	    group_input_003_5.name = "Group Input.003"
	    group_input_003_5.outputs[0].hide = True
	    group_input_003_5.outputs[3].hide = True
	    group_input_003_5.outputs[4].hide = True
	    group_input_003_5.outputs[5].hide = True
	    group_input_003_5.outputs[6].hide = True
	    group_input_003_5.outputs[7].hide = True
	    group_input_003_5.outputs[8].hide = True
	    group_input_003_5.outputs[9].hide = True
	    group_input_003_5.outputs[10].hide = True
	    group_input_003_5.outputs[11].hide = True
	    group_input_003_5.outputs[12].hide = True
	    group_input_003_5.outputs[13].hide = True
	    group_input_003_5.outputs[14].hide = True
	    group_input_003_5.outputs[15].hide = True
	    group_input_003_5.outputs[16].hide = True
	    group_input_003_5.outputs[17].hide = True
	    group_input_003_5.outputs[18].hide = True
	    group_input_003_5.outputs[19].hide = True
	    group_input_003_5.outputs[20].hide = True
	    group_input_003_5.outputs[21].hide = True
	    group_input_003_5.outputs[22].hide = True
	    group_input_003_5.outputs[23].hide = True
	    group_input_003_5.outputs[24].hide = True
	    group_input_003_5.outputs[25].hide = True
	    group_input_003_5.outputs[26].hide = True
	    group_input_003_5.outputs[27].hide = True
	    group_input_003_5.outputs[28].hide = True
	    group_input_003_5.outputs[29].hide = True
	    group_input_003_5.outputs[30].hide = True
	    group_input_003_5.outputs[31].hide = True
	    group_input_003_5.outputs[32].hide = True
	
	    #node Set Material
	    set_material = baby_hairs.nodes.new("GeometryNodeSetMaterial")
	    set_material.name = "Set Material"
	    #Selection
	    set_material.inputs[1].default_value = True
	
	    #node Group Input.005
	    group_input_005_4 = baby_hairs.nodes.new("NodeGroupInput")
	    group_input_005_4.name = "Group Input.005"
	    group_input_005_4.outputs[0].hide = True
	    group_input_005_4.outputs[1].hide = True
	    group_input_005_4.outputs[2].hide = True
	    group_input_005_4.outputs[3].hide = True
	    group_input_005_4.outputs[4].hide = True
	    group_input_005_4.outputs[5].hide = True
	    group_input_005_4.outputs[7].hide = True
	    group_input_005_4.outputs[8].hide = True
	    group_input_005_4.outputs[9].hide = True
	    group_input_005_4.outputs[10].hide = True
	    group_input_005_4.outputs[11].hide = True
	    group_input_005_4.outputs[12].hide = True
	    group_input_005_4.outputs[13].hide = True
	    group_input_005_4.outputs[14].hide = True
	    group_input_005_4.outputs[15].hide = True
	    group_input_005_4.outputs[16].hide = True
	    group_input_005_4.outputs[17].hide = True
	    group_input_005_4.outputs[18].hide = True
	    group_input_005_4.outputs[19].hide = True
	    group_input_005_4.outputs[20].hide = True
	    group_input_005_4.outputs[21].hide = True
	    group_input_005_4.outputs[22].hide = True
	    group_input_005_4.outputs[23].hide = True
	    group_input_005_4.outputs[24].hide = True
	    group_input_005_4.outputs[25].hide = True
	    group_input_005_4.outputs[26].hide = True
	    group_input_005_4.outputs[27].hide = True
	    group_input_005_4.outputs[28].hide = True
	    group_input_005_4.outputs[29].hide = True
	    group_input_005_4.outputs[30].hide = True
	    group_input_005_4.outputs[31].hide = True
	    group_input_005_4.outputs[32].hide = True
	
	    #node Set Position
	    set_position_5 = baby_hairs.nodes.new("GeometryNodeSetPosition")
	    set_position_5.name = "Set Position"
	    set_position_5.hide = True
	    #Selection
	    set_position_5.inputs[1].default_value = True
	    #Offset
	    set_position_5.inputs[3].default_value = (0.0, 0.0, 0.0)
	
	    #node Vector Math
	    vector_math_6 = baby_hairs.nodes.new("ShaderNodeVectorMath")
	    vector_math_6.name = "Vector Math"
	    vector_math_6.hide = True
	    vector_math_6.operation = 'MULTIPLY'
	    #Vector_001
	    vector_math_6.inputs[1].default_value = (-1.0, 1.0, 1.0)
	
	    #node Capture Attribute
	    capture_attribute_5 = baby_hairs.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_5.name = "Capture Attribute"
	    capture_attribute_5.hide = True
	    capture_attribute_5.active_index = 0
	    capture_attribute_5.capture_items.clear()
	    capture_attribute_5.capture_items.new('FLOAT', "Position")
	    capture_attribute_5.capture_items["Position"].data_type = 'FLOAT_VECTOR'
	    capture_attribute_5.domain = 'POINT'
	
	    #node Position
	    position_4 = baby_hairs.nodes.new("GeometryNodeInputPosition")
	    position_4.name = "Position"
	    position_4.hide = True
	
	    #node Switch
	    switch_6 = baby_hairs.nodes.new("GeometryNodeSwitch")
	    switch_6.name = "Switch"
	    switch_6.hide = True
	    switch_6.input_type = 'GEOMETRY'
	
	    #node Join Geometry
	    join_geometry_2 = baby_hairs.nodes.new("GeometryNodeJoinGeometry")
	    join_geometry_2.name = "Join Geometry"
	    join_geometry_2.hide = True
	
	    #node Frame
	    frame_7 = baby_hairs.nodes.new("NodeFrame")
	    frame_7.label = "Mirror"
	    frame_7.name = "Frame"
	    frame_7.label_size = 20
	    frame_7.shrink = True
	
	    #node Group Input.006
	    group_input_006_4 = baby_hairs.nodes.new("NodeGroupInput")
	    group_input_006_4.name = "Group Input.006"
	    group_input_006_4.outputs[0].hide = True
	    group_input_006_4.outputs[1].hide = True
	    group_input_006_4.outputs[2].hide = True
	    group_input_006_4.outputs[4].hide = True
	    group_input_006_4.outputs[5].hide = True
	    group_input_006_4.outputs[6].hide = True
	    group_input_006_4.outputs[7].hide = True
	    group_input_006_4.outputs[8].hide = True
	    group_input_006_4.outputs[9].hide = True
	    group_input_006_4.outputs[10].hide = True
	    group_input_006_4.outputs[11].hide = True
	    group_input_006_4.outputs[12].hide = True
	    group_input_006_4.outputs[13].hide = True
	    group_input_006_4.outputs[14].hide = True
	    group_input_006_4.outputs[15].hide = True
	    group_input_006_4.outputs[16].hide = True
	    group_input_006_4.outputs[17].hide = True
	    group_input_006_4.outputs[18].hide = True
	    group_input_006_4.outputs[19].hide = True
	    group_input_006_4.outputs[20].hide = True
	    group_input_006_4.outputs[21].hide = True
	    group_input_006_4.outputs[22].hide = True
	    group_input_006_4.outputs[23].hide = True
	    group_input_006_4.outputs[24].hide = True
	    group_input_006_4.outputs[25].hide = True
	    group_input_006_4.outputs[26].hide = True
	    group_input_006_4.outputs[27].hide = True
	    group_input_006_4.outputs[28].hide = True
	    group_input_006_4.outputs[29].hide = True
	    group_input_006_4.outputs[30].hide = True
	    group_input_006_4.outputs[31].hide = True
	    group_input_006_4.outputs[32].hide = True
	
	    #node Reroute
	    reroute_7 = baby_hairs.nodes.new("NodeReroute")
	    reroute_7.name = "Reroute"
	    reroute_7.socket_idname = "NodeSocketGeometry"
	    #node Reroute.001
	    reroute_001_7 = baby_hairs.nodes.new("NodeReroute")
	    reroute_001_7.name = "Reroute.001"
	    reroute_001_7.socket_idname = "NodeSocketGeometry"
	    #node Reroute.002
	    reroute_002_5 = baby_hairs.nodes.new("NodeReroute")
	    reroute_002_5.name = "Reroute.002"
	    reroute_002_5.socket_idname = "NodeSocketGeometry"
	    #node Reroute.003
	    reroute_003_5 = baby_hairs.nodes.new("NodeReroute")
	    reroute_003_5.name = "Reroute.003"
	    reroute_003_5.socket_idname = "NodeSocketGeometry"
	    #node Reroute.004
	    reroute_004_6 = baby_hairs.nodes.new("NodeReroute")
	    reroute_004_6.name = "Reroute.004"
	    reroute_004_6.socket_idname = "NodeSocketGeometry"
	    #node Reroute.005
	    reroute_005_5 = baby_hairs.nodes.new("NodeReroute")
	    reroute_005_5.name = "Reroute.005"
	    reroute_005_5.socket_idname = "NodeSocketGeometry"
	    #node Resample Curve.001
	    resample_curve_001 = baby_hairs.nodes.new("GeometryNodeResampleCurve")
	    resample_curve_001.name = "Resample Curve.001"
	    resample_curve_001.hide = True
	    resample_curve_001.keep_last_segment = False
	    resample_curve_001.mode = 'COUNT'
	    #Selection
	    resample_curve_001.inputs[1].default_value = True
	
	    #node Resample Curve.002
	    resample_curve_002 = baby_hairs.nodes.new("GeometryNodeResampleCurve")
	    resample_curve_002.name = "Resample Curve.002"
	    resample_curve_002.hide = True
	    resample_curve_002.keep_last_segment = False
	    resample_curve_002.mode = 'COUNT'
	    #Selection
	    resample_curve_002.inputs[1].default_value = True
	
	    #node Group Input.007
	    group_input_007_4 = baby_hairs.nodes.new("NodeGroupInput")
	    group_input_007_4.name = "Group Input.007"
	    group_input_007_4.outputs[0].hide = True
	    group_input_007_4.outputs[1].hide = True
	    group_input_007_4.outputs[2].hide = True
	    group_input_007_4.outputs[3].hide = True
	    group_input_007_4.outputs[4].hide = True
	    group_input_007_4.outputs[5].hide = True
	    group_input_007_4.outputs[6].hide = True
	    group_input_007_4.outputs[8].hide = True
	    group_input_007_4.outputs[9].hide = True
	    group_input_007_4.outputs[10].hide = True
	    group_input_007_4.outputs[11].hide = True
	    group_input_007_4.outputs[12].hide = True
	    group_input_007_4.outputs[13].hide = True
	    group_input_007_4.outputs[14].hide = True
	    group_input_007_4.outputs[15].hide = True
	    group_input_007_4.outputs[16].hide = True
	    group_input_007_4.outputs[17].hide = True
	    group_input_007_4.outputs[18].hide = True
	    group_input_007_4.outputs[19].hide = True
	    group_input_007_4.outputs[20].hide = True
	    group_input_007_4.outputs[21].hide = True
	    group_input_007_4.outputs[22].hide = True
	    group_input_007_4.outputs[23].hide = True
	    group_input_007_4.outputs[24].hide = True
	    group_input_007_4.outputs[25].hide = True
	    group_input_007_4.outputs[26].hide = True
	    group_input_007_4.outputs[27].hide = True
	    group_input_007_4.outputs[28].hide = True
	    group_input_007_4.outputs[29].hide = True
	    group_input_007_4.outputs[30].hide = True
	    group_input_007_4.outputs[31].hide = True
	    group_input_007_4.outputs[32].hide = True
	
	    #node Math
	    math_5 = baby_hairs.nodes.new("ShaderNodeMath")
	    math_5.name = "Math"
	    math_5.hide = True
	    math_5.operation = 'MULTIPLY'
	    math_5.use_clamp = False
	    #Value_001
	    math_5.inputs[1].default_value = 10.0
	
	    #node Group Input.008
	    group_input_008_3 = baby_hairs.nodes.new("NodeGroupInput")
	    group_input_008_3.name = "Group Input.008"
	    group_input_008_3.outputs[0].hide = True
	    group_input_008_3.outputs[1].hide = True
	    group_input_008_3.outputs[2].hide = True
	    group_input_008_3.outputs[3].hide = True
	    group_input_008_3.outputs[4].hide = True
	    group_input_008_3.outputs[5].hide = True
	    group_input_008_3.outputs[6].hide = True
	    group_input_008_3.outputs[8].hide = True
	    group_input_008_3.outputs[9].hide = True
	    group_input_008_3.outputs[10].hide = True
	    group_input_008_3.outputs[11].hide = True
	    group_input_008_3.outputs[12].hide = True
	    group_input_008_3.outputs[13].hide = True
	    group_input_008_3.outputs[14].hide = True
	    group_input_008_3.outputs[15].hide = True
	    group_input_008_3.outputs[16].hide = True
	    group_input_008_3.outputs[17].hide = True
	    group_input_008_3.outputs[18].hide = True
	    group_input_008_3.outputs[19].hide = True
	    group_input_008_3.outputs[20].hide = True
	    group_input_008_3.outputs[21].hide = True
	    group_input_008_3.outputs[22].hide = True
	    group_input_008_3.outputs[23].hide = True
	    group_input_008_3.outputs[24].hide = True
	    group_input_008_3.outputs[25].hide = True
	    group_input_008_3.outputs[26].hide = True
	    group_input_008_3.outputs[27].hide = True
	    group_input_008_3.outputs[28].hide = True
	    group_input_008_3.outputs[29].hide = True
	    group_input_008_3.outputs[30].hide = True
	    group_input_008_3.outputs[31].hide = True
	    group_input_008_3.outputs[32].hide = True
	
	    #node Curve to Mesh
	    curve_to_mesh = baby_hairs.nodes.new("GeometryNodeCurveToMesh")
	    curve_to_mesh.name = "Curve to Mesh"
	    curve_to_mesh.hide = True
	    #Fill Caps
	    curve_to_mesh.inputs[2].default_value = False
	
	    #node Mesh to Curve
	    mesh_to_curve = baby_hairs.nodes.new("GeometryNodeMeshToCurve")
	    mesh_to_curve.name = "Mesh to Curve"
	    mesh_to_curve.hide = True
	    #Selection
	    mesh_to_curve.inputs[1].default_value = True
	
	    #node Object Info
	    object_info_1 = baby_hairs.nodes.new("GeometryNodeObjectInfo")
	    object_info_1.name = "Object Info"
	    object_info_1.hide = True
	    object_info_1.transform_space = 'RELATIVE'
	    #As Instance
	    object_info_1.inputs[1].default_value = False
	
	    #node Geometry Proximity
	    geometry_proximity_1 = baby_hairs.nodes.new("GeometryNodeProximity")
	    geometry_proximity_1.name = "Geometry Proximity"
	    geometry_proximity_1.hide = True
	    geometry_proximity_1.target_element = 'POINTS'
	    #Group ID
	    geometry_proximity_1.inputs[1].default_value = 0
	    #Sample Group ID
	    geometry_proximity_1.inputs[3].default_value = 0
	
	    #node Capture Attribute.001
	    capture_attribute_001_4 = baby_hairs.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_001_4.name = "Capture Attribute.001"
	    capture_attribute_001_4.hide = True
	    capture_attribute_001_4.active_index = 1
	    capture_attribute_001_4.capture_items.clear()
	    capture_attribute_001_4.capture_items.new('FLOAT', "Index")
	    capture_attribute_001_4.capture_items["Index"].data_type = 'INT'
	    capture_attribute_001_4.capture_items.new('FLOAT', "Position")
	    capture_attribute_001_4.capture_items["Position"].data_type = 'FLOAT_VECTOR'
	    capture_attribute_001_4.domain = 'POINT'
	
	    #node Position.001
	    position_001_3 = baby_hairs.nodes.new("GeometryNodeInputPosition")
	    position_001_3.name = "Position.001"
	    position_001_3.hide = True
	
	    #node Index
	    index_3 = baby_hairs.nodes.new("GeometryNodeInputIndex")
	    index_3.name = "Index"
	    index_3.hide = True
	
	    #node Curve to Points
	    curve_to_points_1 = baby_hairs.nodes.new("GeometryNodeCurveToPoints")
	    curve_to_points_1.name = "Curve to Points"
	    curve_to_points_1.hide = True
	    curve_to_points_1.mode = 'COUNT'
	    #Count
	    curve_to_points_1.inputs[1].default_value = 1
	
	    #node Compare
	    compare_5 = baby_hairs.nodes.new("FunctionNodeCompare")
	    compare_5.name = "Compare"
	    compare_5.hide = True
	    compare_5.data_type = 'FLOAT'
	    compare_5.mode = 'ELEMENT'
	    compare_5.operation = 'LESS_THAN'
	
	    #node Compare.001
	    compare_001_4 = baby_hairs.nodes.new("FunctionNodeCompare")
	    compare_001_4.name = "Compare.001"
	    compare_001_4.hide = True
	    compare_001_4.data_type = 'INT'
	    compare_001_4.mode = 'ELEMENT'
	    compare_001_4.operation = 'LESS_THAN'
	    #B_INT
	    compare_001_4.inputs[3].default_value = 10
	
	    #node Boolean Math
	    boolean_math_5 = baby_hairs.nodes.new("FunctionNodeBooleanMath")
	    boolean_math_5.name = "Boolean Math"
	    boolean_math_5.hide = True
	    boolean_math_5.operation = 'AND'
	
	    #node Delete Geometry
	    delete_geometry = baby_hairs.nodes.new("GeometryNodeDeleteGeometry")
	    delete_geometry.name = "Delete Geometry"
	    delete_geometry.hide = True
	    delete_geometry.domain = 'POINT'
	    delete_geometry.mode = 'ALL'
	
	    #node Math.001
	    math_001_3 = baby_hairs.nodes.new("ShaderNodeMath")
	    math_001_3.name = "Math.001"
	    math_001_3.hide = True
	    math_001_3.operation = 'FLOORED_MODULO'
	    math_001_3.use_clamp = False
	
	    #node Group Input.009
	    group_input_009_3 = baby_hairs.nodes.new("NodeGroupInput")
	    group_input_009_3.name = "Group Input.009"
	    group_input_009_3.outputs[0].hide = True
	    group_input_009_3.outputs[1].hide = True
	    group_input_009_3.outputs[2].hide = True
	    group_input_009_3.outputs[3].hide = True
	    group_input_009_3.outputs[5].hide = True
	    group_input_009_3.outputs[6].hide = True
	    group_input_009_3.outputs[7].hide = True
	    group_input_009_3.outputs[8].hide = True
	    group_input_009_3.outputs[9].hide = True
	    group_input_009_3.outputs[10].hide = True
	    group_input_009_3.outputs[11].hide = True
	    group_input_009_3.outputs[12].hide = True
	    group_input_009_3.outputs[13].hide = True
	    group_input_009_3.outputs[14].hide = True
	    group_input_009_3.outputs[15].hide = True
	    group_input_009_3.outputs[16].hide = True
	    group_input_009_3.outputs[17].hide = True
	    group_input_009_3.outputs[18].hide = True
	    group_input_009_3.outputs[19].hide = True
	    group_input_009_3.outputs[20].hide = True
	    group_input_009_3.outputs[21].hide = True
	    group_input_009_3.outputs[22].hide = True
	    group_input_009_3.outputs[23].hide = True
	    group_input_009_3.outputs[24].hide = True
	    group_input_009_3.outputs[25].hide = True
	    group_input_009_3.outputs[26].hide = True
	    group_input_009_3.outputs[27].hide = True
	    group_input_009_3.outputs[28].hide = True
	    group_input_009_3.outputs[29].hide = True
	    group_input_009_3.outputs[30].hide = True
	    group_input_009_3.outputs[31].hide = True
	    group_input_009_3.outputs[32].hide = True
	
	    #node Group Input.010
	    group_input_010_2 = baby_hairs.nodes.new("NodeGroupInput")
	    group_input_010_2.name = "Group Input.010"
	    group_input_010_2.outputs[0].hide = True
	    group_input_010_2.outputs[1].hide = True
	    group_input_010_2.outputs[2].hide = True
	    group_input_010_2.outputs[3].hide = True
	    group_input_010_2.outputs[4].hide = True
	    group_input_010_2.outputs[6].hide = True
	    group_input_010_2.outputs[7].hide = True
	    group_input_010_2.outputs[8].hide = True
	    group_input_010_2.outputs[9].hide = True
	    group_input_010_2.outputs[10].hide = True
	    group_input_010_2.outputs[11].hide = True
	    group_input_010_2.outputs[12].hide = True
	    group_input_010_2.outputs[13].hide = True
	    group_input_010_2.outputs[14].hide = True
	    group_input_010_2.outputs[15].hide = True
	    group_input_010_2.outputs[16].hide = True
	    group_input_010_2.outputs[17].hide = True
	    group_input_010_2.outputs[18].hide = True
	    group_input_010_2.outputs[19].hide = True
	    group_input_010_2.outputs[20].hide = True
	    group_input_010_2.outputs[21].hide = True
	    group_input_010_2.outputs[22].hide = True
	    group_input_010_2.outputs[23].hide = True
	    group_input_010_2.outputs[24].hide = True
	    group_input_010_2.outputs[25].hide = True
	    group_input_010_2.outputs[26].hide = True
	    group_input_010_2.outputs[27].hide = True
	    group_input_010_2.outputs[28].hide = True
	    group_input_010_2.outputs[29].hide = True
	    group_input_010_2.outputs[30].hide = True
	    group_input_010_2.outputs[31].hide = True
	    group_input_010_2.outputs[32].hide = True
	
	    #node Frame.001
	    frame_001_4 = baby_hairs.nodes.new("NodeFrame")
	    frame_001_4.label = "Trim Roots by Scalp Hair Proximity"
	    frame_001_4.name = "Frame.001"
	    frame_001_4.label_size = 20
	    frame_001_4.shrink = True
	
	    #node Reroute.006
	    reroute_006_5 = baby_hairs.nodes.new("NodeReroute")
	    reroute_006_5.name = "Reroute.006"
	    reroute_006_5.socket_idname = "NodeSocketGeometry"
	    #node Reroute.007
	    reroute_007_5 = baby_hairs.nodes.new("NodeReroute")
	    reroute_007_5.name = "Reroute.007"
	    reroute_007_5.socket_idname = "NodeSocketGeometry"
	    #node Reroute.008
	    reroute_008_5 = baby_hairs.nodes.new("NodeReroute")
	    reroute_008_5.name = "Reroute.008"
	    reroute_008_5.socket_idname = "NodeSocketGeometry"
	    #node Reroute.009
	    reroute_009_5 = baby_hairs.nodes.new("NodeReroute")
	    reroute_009_5.name = "Reroute.009"
	    reroute_009_5.socket_idname = "NodeSocketGeometry"
	    #node Switch.001
	    switch_001_7 = baby_hairs.nodes.new("GeometryNodeSwitch")
	    switch_001_7.name = "Switch.001"
	    switch_001_7.hide = True
	    switch_001_7.input_type = 'GEOMETRY'
	
	    #node Reroute.010
	    reroute_010_4 = baby_hairs.nodes.new("NodeReroute")
	    reroute_010_4.name = "Reroute.010"
	    reroute_010_4.socket_idname = "NodeSocketGeometry"
	    #node Compare.002
	    compare_002_4 = baby_hairs.nodes.new("FunctionNodeCompare")
	    compare_002_4.name = "Compare.002"
	    compare_002_4.hide = True
	    compare_002_4.data_type = 'FLOAT'
	    compare_002_4.mode = 'ELEMENT'
	    compare_002_4.operation = 'EQUAL'
	    #B
	    compare_002_4.inputs[1].default_value = 0.0
	    #Epsilon
	    compare_002_4.inputs[12].default_value = 0.0
	
	    #node Group Input.011
	    group_input_011_1 = baby_hairs.nodes.new("NodeGroupInput")
	    group_input_011_1.name = "Group Input.011"
	    group_input_011_1.outputs[0].hide = True
	    group_input_011_1.outputs[1].hide = True
	    group_input_011_1.outputs[2].hide = True
	    group_input_011_1.outputs[3].hide = True
	    group_input_011_1.outputs[4].hide = True
	    group_input_011_1.outputs[6].hide = True
	    group_input_011_1.outputs[7].hide = True
	    group_input_011_1.outputs[8].hide = True
	    group_input_011_1.outputs[9].hide = True
	    group_input_011_1.outputs[10].hide = True
	    group_input_011_1.outputs[11].hide = True
	    group_input_011_1.outputs[12].hide = True
	    group_input_011_1.outputs[13].hide = True
	    group_input_011_1.outputs[14].hide = True
	    group_input_011_1.outputs[15].hide = True
	    group_input_011_1.outputs[16].hide = True
	    group_input_011_1.outputs[17].hide = True
	    group_input_011_1.outputs[18].hide = True
	    group_input_011_1.outputs[19].hide = True
	    group_input_011_1.outputs[20].hide = True
	    group_input_011_1.outputs[21].hide = True
	    group_input_011_1.outputs[22].hide = True
	    group_input_011_1.outputs[23].hide = True
	    group_input_011_1.outputs[24].hide = True
	    group_input_011_1.outputs[25].hide = True
	    group_input_011_1.outputs[26].hide = True
	    group_input_011_1.outputs[27].hide = True
	    group_input_011_1.outputs[28].hide = True
	    group_input_011_1.outputs[29].hide = True
	    group_input_011_1.outputs[30].hide = True
	    group_input_011_1.outputs[31].hide = True
	    group_input_011_1.outputs[32].hide = True
	
	    #node Reroute.011
	    reroute_011_5 = baby_hairs.nodes.new("NodeReroute")
	    reroute_011_5.name = "Reroute.011"
	    reroute_011_5.socket_idname = "NodeSocketGeometry"
	    #node Sample Curve
	    sample_curve_1 = baby_hairs.nodes.new("GeometryNodeSampleCurve")
	    sample_curve_1.name = "Sample Curve"
	    sample_curve_1.hide = True
	    sample_curve_1.data_type = 'FLOAT'
	    sample_curve_1.mode = 'FACTOR'
	    sample_curve_1.use_all_curves = False
	    #Value
	    sample_curve_1.inputs[1].default_value = 0.0
	
	    #node Spline Parameter.001
	    spline_parameter_001_1 = baby_hairs.nodes.new("GeometryNodeSplineParameter")
	    spline_parameter_001_1.name = "Spline Parameter.001"
	    spline_parameter_001_1.hide = True
	
	    #node Resample Curve.003
	    resample_curve_003 = baby_hairs.nodes.new("GeometryNodeResampleCurve")
	    resample_curve_003.name = "Resample Curve.003"
	    resample_curve_003.hide = True
	    resample_curve_003.keep_last_segment = False
	    resample_curve_003.mode = 'COUNT'
	    #Selection
	    resample_curve_003.inputs[1].default_value = True
	    #Count
	    resample_curve_003.inputs[2].default_value = 2
	
	    #node Curve to Points.001
	    curve_to_points_001_1 = baby_hairs.nodes.new("GeometryNodeCurveToPoints")
	    curve_to_points_001_1.name = "Curve to Points.001"
	    curve_to_points_001_1.hide = True
	    curve_to_points_001_1.mode = 'COUNT'
	
	    #node Instance on Points
	    instance_on_points = baby_hairs.nodes.new("GeometryNodeInstanceOnPoints")
	    instance_on_points.name = "Instance on Points"
	    instance_on_points.hide = True
	    #Selection
	    instance_on_points.inputs[1].default_value = True
	    #Pick Instance
	    instance_on_points.inputs[3].default_value = False
	    #Instance Index
	    instance_on_points.inputs[4].default_value = 0
	    #Rotation
	    instance_on_points.inputs[5].default_value = (0.0, 0.0, 0.0)
	    #Scale
	    instance_on_points.inputs[6].default_value = (1.0, 1.0, 1.0)
	
	    #node Set Position.002
	    set_position_002_2 = baby_hairs.nodes.new("GeometryNodeSetPosition")
	    set_position_002_2.name = "Set Position.002"
	    set_position_002_2.hide = True
	    #Selection
	    set_position_002_2.inputs[1].default_value = True
	    #Offset
	    set_position_002_2.inputs[3].default_value = (0.0, 0.0, 0.0)
	
	    #node Capture Attribute.002
	    capture_attribute_002_4 = baby_hairs.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_002_4.name = "Capture Attribute.002"
	    capture_attribute_002_4.hide = True
	    capture_attribute_002_4.active_index = 1
	    capture_attribute_002_4.capture_items.clear()
	    capture_attribute_002_4.capture_items.new('FLOAT', "Position")
	    capture_attribute_002_4.capture_items["Position"].data_type = 'FLOAT_VECTOR'
	    capture_attribute_002_4.capture_items.new('FLOAT', "Index")
	    capture_attribute_002_4.capture_items["Index"].data_type = 'INT'
	    capture_attribute_002_4.domain = 'POINT'
	
	    #node Position.002
	    position_002_4 = baby_hairs.nodes.new("GeometryNodeInputPosition")
	    position_002_4.name = "Position.002"
	    position_002_4.hide = True
	
	    #node Vector Math.003
	    vector_math_003_5 = baby_hairs.nodes.new("ShaderNodeVectorMath")
	    vector_math_003_5.name = "Vector Math.003"
	    vector_math_003_5.hide = True
	    vector_math_003_5.operation = 'SUBTRACT'
	
	    #node Realize Instances
	    realize_instances = baby_hairs.nodes.new("GeometryNodeRealizeInstances")
	    realize_instances.name = "Realize Instances"
	    realize_instances.hide = True
	    #Selection
	    realize_instances.inputs[1].default_value = True
	    #Realize All
	    realize_instances.inputs[2].default_value = True
	    #Depth
	    realize_instances.inputs[3].default_value = 0
	
	    #node Join Geometry.003
	    join_geometry_003 = baby_hairs.nodes.new("GeometryNodeJoinGeometry")
	    join_geometry_003.name = "Join Geometry.003"
	    join_geometry_003.hide = True
	
	    #node Group.003
	    group_003_2 = baby_hairs.nodes.new("GeometryNodeGroup")
	    group_003_2.name = "Group.003"
	    group_003_2.node_tree = duplicate_hair_curves_002
	    #Socket_4
	    group_003_2.inputs[2].default_value = 1.0
	    #Socket_5
	    group_003_2.inputs[3].default_value = 0.10000000149011612
	    #Socket_6
	    group_003_2.inputs[4].default_value = 0.0
	    #Socket_7
	    group_003_2.inputs[5].default_value = 0.0
	    #Socket_8
	    group_003_2.inputs[6].default_value = False
	    #Socket_9
	    group_003_2.inputs[7].default_value = 0
	
	    #node Delete Geometry.001
	    delete_geometry_001 = baby_hairs.nodes.new("GeometryNodeDeleteGeometry")
	    delete_geometry_001.name = "Delete Geometry.001"
	    delete_geometry_001.hide = True
	    delete_geometry_001.domain = 'POINT'
	    delete_geometry_001.mode = 'ALL'
	
	    #node Index.001
	    index_001_3 = baby_hairs.nodes.new("GeometryNodeInputIndex")
	    index_001_3.name = "Index.001"
	    index_001_3.hide = True
	
	    #node Compare.003
	    compare_003_3 = baby_hairs.nodes.new("FunctionNodeCompare")
	    compare_003_3.name = "Compare.003"
	    compare_003_3.hide = True
	    compare_003_3.data_type = 'INT'
	    compare_003_3.mode = 'ELEMENT'
	    compare_003_3.operation = 'GREATER_THAN'
	
	    #node Compare.004
	    compare_004_4 = baby_hairs.nodes.new("FunctionNodeCompare")
	    compare_004_4.name = "Compare.004"
	    compare_004_4.hide = True
	    compare_004_4.data_type = 'INT'
	    compare_004_4.mode = 'ELEMENT'
	    compare_004_4.operation = 'LESS_THAN'
	
	    #node Index.002
	    index_002_2 = baby_hairs.nodes.new("GeometryNodeInputIndex")
	    index_002_2.name = "Index.002"
	    index_002_2.hide = True
	
	    #node Delete Geometry.002
	    delete_geometry_002_1 = baby_hairs.nodes.new("GeometryNodeDeleteGeometry")
	    delete_geometry_002_1.name = "Delete Geometry.002"
	    delete_geometry_002_1.hide = True
	    delete_geometry_002_1.domain = 'POINT'
	    delete_geometry_002_1.mode = 'ALL'
	
	    #node Reverse Curve
	    reverse_curve = baby_hairs.nodes.new("GeometryNodeReverseCurve")
	    reverse_curve.name = "Reverse Curve"
	    reverse_curve.hide = True
	    #Selection
	    reverse_curve.inputs[1].default_value = True
	
	    #node Baby Hairs Shape
	    baby_hairs_shape = baby_hairs.nodes.new("ShaderNodeFloatCurve")
	    baby_hairs_shape.label = "Baby Hairs Shape"
	    baby_hairs_shape.name = "Baby Hairs Shape"
	    #mapping settings
	    baby_hairs_shape.mapping.extend = 'EXTRAPOLATED'
	    baby_hairs_shape.mapping.tone = 'STANDARD'
	    baby_hairs_shape.mapping.black_level = (0.0, 0.0, 0.0)
	    baby_hairs_shape.mapping.white_level = (1.0, 1.0, 1.0)
	    baby_hairs_shape.mapping.clip_min_x = 0.0
	    baby_hairs_shape.mapping.clip_min_y = 0.0
	    baby_hairs_shape.mapping.clip_max_x = 1.0
	    baby_hairs_shape.mapping.clip_max_y = 1.0
	    baby_hairs_shape.mapping.use_clip = True
	    #curve 0
	    baby_hairs_shape_curve_0 = baby_hairs_shape.mapping.curves[0]
	    baby_hairs_shape_curve_0_point_0 = baby_hairs_shape_curve_0.points[0]
	    baby_hairs_shape_curve_0_point_0.location = (0.0, 0.0)
	    baby_hairs_shape_curve_0_point_0.handle_type = 'AUTO'
	    baby_hairs_shape_curve_0_point_1 = baby_hairs_shape_curve_0.points[1]
	    baby_hairs_shape_curve_0_point_1.location = (0.5, 1.0)
	    baby_hairs_shape_curve_0_point_1.handle_type = 'AUTO'
	    baby_hairs_shape_curve_0_point_2 = baby_hairs_shape_curve_0.points.new(0.75, 0.25)
	    baby_hairs_shape_curve_0_point_2.handle_type = 'AUTO_CLAMPED'
	    baby_hairs_shape_curve_0_point_3 = baby_hairs_shape_curve_0.points.new(1.0, 0.0)
	    baby_hairs_shape_curve_0_point_3.handle_type = 'AUTO'
	    #update curve after changes
	    baby_hairs_shape.mapping.update()
	    #Factor
	    baby_hairs_shape.inputs[0].default_value = 1.0
	
	    #node Spline Parameter.002
	    spline_parameter_002 = baby_hairs.nodes.new("GeometryNodeSplineParameter")
	    spline_parameter_002.name = "Spline Parameter.002"
	    spline_parameter_002.hide = True
	
	    #node Math.003
	    math_003_3 = baby_hairs.nodes.new("ShaderNodeMath")
	    math_003_3.name = "Math.003"
	    math_003_3.hide = True
	    math_003_3.operation = 'MULTIPLY'
	    math_003_3.use_clamp = False
	
	    #node Group Input.014
	    group_input_014 = baby_hairs.nodes.new("NodeGroupInput")
	    group_input_014.name = "Group Input.014"
	    group_input_014.outputs[0].hide = True
	    group_input_014.outputs[1].hide = True
	    group_input_014.outputs[2].hide = True
	    group_input_014.outputs[3].hide = True
	    group_input_014.outputs[4].hide = True
	    group_input_014.outputs[5].hide = True
	    group_input_014.outputs[6].hide = True
	    group_input_014.outputs[7].hide = True
	    group_input_014.outputs[9].hide = True
	    group_input_014.outputs[10].hide = True
	    group_input_014.outputs[11].hide = True
	    group_input_014.outputs[12].hide = True
	    group_input_014.outputs[13].hide = True
	    group_input_014.outputs[14].hide = True
	    group_input_014.outputs[15].hide = True
	    group_input_014.outputs[16].hide = True
	    group_input_014.outputs[17].hide = True
	    group_input_014.outputs[18].hide = True
	    group_input_014.outputs[19].hide = True
	    group_input_014.outputs[20].hide = True
	    group_input_014.outputs[21].hide = True
	    group_input_014.outputs[22].hide = True
	    group_input_014.outputs[23].hide = True
	    group_input_014.outputs[24].hide = True
	    group_input_014.outputs[25].hide = True
	    group_input_014.outputs[26].hide = True
	    group_input_014.outputs[27].hide = True
	    group_input_014.outputs[28].hide = True
	    group_input_014.outputs[29].hide = True
	    group_input_014.outputs[30].hide = True
	    group_input_014.outputs[31].hide = True
	    group_input_014.outputs[32].hide = True
	
	    #node Set Curve Radius.001
	    set_curve_radius_001 = baby_hairs.nodes.new("GeometryNodeSetCurveRadius")
	    set_curve_radius_001.name = "Set Curve Radius.001"
	    #Selection
	    set_curve_radius_001.inputs[1].default_value = True
	
	    #node Frame.003
	    frame_003_4 = baby_hairs.nodes.new("NodeFrame")
	    frame_003_4.label = "Shape"
	    frame_003_4.name = "Frame.003"
	    frame_003_4.label_size = 20
	    frame_003_4.shrink = True
	
	    #node Reroute.012
	    reroute_012_6 = baby_hairs.nodes.new("NodeReroute")
	    reroute_012_6.name = "Reroute.012"
	    reroute_012_6.socket_idname = "NodeSocketGeometry"
	    #node Reroute.013
	    reroute_013_5 = baby_hairs.nodes.new("NodeReroute")
	    reroute_013_5.name = "Reroute.013"
	    reroute_013_5.socket_idname = "NodeSocketGeometry"
	    #node Group Input.004
	    group_input_004_4 = baby_hairs.nodes.new("NodeGroupInput")
	    group_input_004_4.name = "Group Input.004"
	    group_input_004_4.outputs[0].hide = True
	    group_input_004_4.outputs[1].hide = True
	    group_input_004_4.outputs[2].hide = True
	    group_input_004_4.outputs[3].hide = True
	    group_input_004_4.outputs[4].hide = True
	    group_input_004_4.outputs[5].hide = True
	    group_input_004_4.outputs[6].hide = True
	    group_input_004_4.outputs[7].hide = True
	    group_input_004_4.outputs[8].hide = True
	    group_input_004_4.outputs[9].hide = True
	    group_input_004_4.outputs[10].hide = True
	    group_input_004_4.outputs[11].hide = True
	    group_input_004_4.outputs[12].hide = True
	    group_input_004_4.outputs[13].hide = True
	    group_input_004_4.outputs[14].hide = True
	    group_input_004_4.outputs[15].hide = True
	    group_input_004_4.outputs[16].hide = True
	    group_input_004_4.outputs[17].hide = True
	    group_input_004_4.outputs[18].hide = True
	    group_input_004_4.outputs[19].hide = True
	    group_input_004_4.outputs[20].hide = True
	    group_input_004_4.outputs[21].hide = True
	    group_input_004_4.outputs[22].hide = True
	    group_input_004_4.outputs[23].hide = True
	    group_input_004_4.outputs[24].hide = True
	    group_input_004_4.outputs[25].hide = True
	    group_input_004_4.outputs[27].hide = True
	    group_input_004_4.outputs[28].hide = True
	    group_input_004_4.outputs[29].hide = True
	    group_input_004_4.outputs[30].hide = True
	    group_input_004_4.outputs[31].hide = True
	    group_input_004_4.outputs[32].hide = True
	
	    #node Group Input.012
	    group_input_012_1 = baby_hairs.nodes.new("NodeGroupInput")
	    group_input_012_1.name = "Group Input.012"
	    group_input_012_1.outputs[0].hide = True
	    group_input_012_1.outputs[1].hide = True
	    group_input_012_1.outputs[2].hide = True
	    group_input_012_1.outputs[3].hide = True
	    group_input_012_1.outputs[4].hide = True
	    group_input_012_1.outputs[5].hide = True
	    group_input_012_1.outputs[6].hide = True
	    group_input_012_1.outputs[7].hide = True
	    group_input_012_1.outputs[8].hide = True
	    group_input_012_1.outputs[9].hide = True
	    group_input_012_1.outputs[10].hide = True
	    group_input_012_1.outputs[11].hide = True
	    group_input_012_1.outputs[12].hide = True
	    group_input_012_1.outputs[13].hide = True
	    group_input_012_1.outputs[14].hide = True
	    group_input_012_1.outputs[15].hide = True
	    group_input_012_1.outputs[16].hide = True
	    group_input_012_1.outputs[17].hide = True
	    group_input_012_1.outputs[18].hide = True
	    group_input_012_1.outputs[19].hide = True
	    group_input_012_1.outputs[20].hide = True
	    group_input_012_1.outputs[21].hide = True
	    group_input_012_1.outputs[22].hide = True
	    group_input_012_1.outputs[23].hide = True
	    group_input_012_1.outputs[24].hide = True
	    group_input_012_1.outputs[25].hide = True
	    group_input_012_1.outputs[26].hide = True
	    group_input_012_1.outputs[28].hide = True
	    group_input_012_1.outputs[29].hide = True
	    group_input_012_1.outputs[30].hide = True
	    group_input_012_1.outputs[31].hide = True
	    group_input_012_1.outputs[32].hide = True
	
	    #node Group Input.013
	    group_input_013_1 = baby_hairs.nodes.new("NodeGroupInput")
	    group_input_013_1.name = "Group Input.013"
	    group_input_013_1.outputs[0].hide = True
	    group_input_013_1.outputs[1].hide = True
	    group_input_013_1.outputs[2].hide = True
	    group_input_013_1.outputs[3].hide = True
	    group_input_013_1.outputs[4].hide = True
	    group_input_013_1.outputs[5].hide = True
	    group_input_013_1.outputs[6].hide = True
	    group_input_013_1.outputs[7].hide = True
	    group_input_013_1.outputs[8].hide = True
	    group_input_013_1.outputs[9].hide = True
	    group_input_013_1.outputs[10].hide = True
	    group_input_013_1.outputs[11].hide = True
	    group_input_013_1.outputs[12].hide = True
	    group_input_013_1.outputs[13].hide = True
	    group_input_013_1.outputs[14].hide = True
	    group_input_013_1.outputs[15].hide = True
	    group_input_013_1.outputs[16].hide = True
	    group_input_013_1.outputs[17].hide = True
	    group_input_013_1.outputs[18].hide = True
	    group_input_013_1.outputs[19].hide = True
	    group_input_013_1.outputs[20].hide = True
	    group_input_013_1.outputs[21].hide = True
	    group_input_013_1.outputs[22].hide = True
	    group_input_013_1.outputs[23].hide = True
	    group_input_013_1.outputs[24].hide = True
	    group_input_013_1.outputs[25].hide = True
	    group_input_013_1.outputs[26].hide = True
	    group_input_013_1.outputs[27].hide = True
	    group_input_013_1.outputs[29].hide = True
	    group_input_013_1.outputs[30].hide = True
	    group_input_013_1.outputs[31].hide = True
	    group_input_013_1.outputs[32].hide = True
	
	    #node Reroute.014
	    reroute_014_5 = baby_hairs.nodes.new("NodeReroute")
	    reroute_014_5.name = "Reroute.014"
	    reroute_014_5.socket_idname = "NodeSocketGeometry"
	    #node Reroute.015
	    reroute_015_5 = baby_hairs.nodes.new("NodeReroute")
	    reroute_015_5.name = "Reroute.015"
	    reroute_015_5.socket_idname = "NodeSocketGeometry"
	    #node Extra Hairs Shape
	    extra_hairs_shape = baby_hairs.nodes.new("ShaderNodeFloatCurve")
	    extra_hairs_shape.label = "Extra Hairs Shape"
	    extra_hairs_shape.name = "Extra Hairs Shape"
	    #mapping settings
	    extra_hairs_shape.mapping.extend = 'EXTRAPOLATED'
	    extra_hairs_shape.mapping.tone = 'STANDARD'
	    extra_hairs_shape.mapping.black_level = (0.0, 0.0, 0.0)
	    extra_hairs_shape.mapping.white_level = (1.0, 1.0, 1.0)
	    extra_hairs_shape.mapping.clip_min_x = 0.0
	    extra_hairs_shape.mapping.clip_min_y = 0.0
	    extra_hairs_shape.mapping.clip_max_x = 1.0
	    extra_hairs_shape.mapping.clip_max_y = 1.0
	    extra_hairs_shape.mapping.use_clip = True
	    #curve 0
	    extra_hairs_shape_curve_0 = extra_hairs_shape.mapping.curves[0]
	    extra_hairs_shape_curve_0_point_0 = extra_hairs_shape_curve_0.points[0]
	    extra_hairs_shape_curve_0_point_0.location = (0.0, 0.0)
	    extra_hairs_shape_curve_0_point_0.handle_type = 'AUTO'
	    extra_hairs_shape_curve_0_point_1 = extra_hairs_shape_curve_0.points[1]
	    extra_hairs_shape_curve_0_point_1.location = (0.5, 1.0)
	    extra_hairs_shape_curve_0_point_1.handle_type = 'AUTO'
	    extra_hairs_shape_curve_0_point_2 = extra_hairs_shape_curve_0.points.new(0.75, 0.25)
	    extra_hairs_shape_curve_0_point_2.handle_type = 'AUTO_CLAMPED'
	    extra_hairs_shape_curve_0_point_3 = extra_hairs_shape_curve_0.points.new(1.0, 0.0)
	    extra_hairs_shape_curve_0_point_3.handle_type = 'AUTO'
	    #update curve after changes
	    extra_hairs_shape.mapping.update()
	    #Factor
	    extra_hairs_shape.inputs[0].default_value = 1.0
	
	    #node Spline Parameter.003
	    spline_parameter_003 = baby_hairs.nodes.new("GeometryNodeSplineParameter")
	    spline_parameter_003.name = "Spline Parameter.003"
	    spline_parameter_003.hide = True
	
	    #node Math.004
	    math_004_1 = baby_hairs.nodes.new("ShaderNodeMath")
	    math_004_1.name = "Math.004"
	    math_004_1.hide = True
	    math_004_1.operation = 'MULTIPLY'
	    math_004_1.use_clamp = False
	
	    #node Group Input.015
	    group_input_015 = baby_hairs.nodes.new("NodeGroupInput")
	    group_input_015.name = "Group Input.015"
	    group_input_015.outputs[0].hide = True
	    group_input_015.outputs[1].hide = True
	    group_input_015.outputs[2].hide = True
	    group_input_015.outputs[3].hide = True
	    group_input_015.outputs[4].hide = True
	    group_input_015.outputs[5].hide = True
	    group_input_015.outputs[6].hide = True
	    group_input_015.outputs[7].hide = True
	    group_input_015.outputs[9].hide = True
	    group_input_015.outputs[10].hide = True
	    group_input_015.outputs[11].hide = True
	    group_input_015.outputs[12].hide = True
	    group_input_015.outputs[13].hide = True
	    group_input_015.outputs[14].hide = True
	    group_input_015.outputs[15].hide = True
	    group_input_015.outputs[16].hide = True
	    group_input_015.outputs[17].hide = True
	    group_input_015.outputs[18].hide = True
	    group_input_015.outputs[19].hide = True
	    group_input_015.outputs[20].hide = True
	    group_input_015.outputs[21].hide = True
	    group_input_015.outputs[22].hide = True
	    group_input_015.outputs[23].hide = True
	    group_input_015.outputs[24].hide = True
	    group_input_015.outputs[25].hide = True
	    group_input_015.outputs[26].hide = True
	    group_input_015.outputs[27].hide = True
	    group_input_015.outputs[28].hide = True
	    group_input_015.outputs[29].hide = True
	    group_input_015.outputs[30].hide = True
	    group_input_015.outputs[31].hide = True
	    group_input_015.outputs[32].hide = True
	
	    #node Set Curve Radius.002
	    set_curve_radius_002 = baby_hairs.nodes.new("GeometryNodeSetCurveRadius")
	    set_curve_radius_002.name = "Set Curve Radius.002"
	    #Selection
	    set_curve_radius_002.inputs[1].default_value = True
	
	    #node Frame.004
	    frame_004_4 = baby_hairs.nodes.new("NodeFrame")
	    frame_004_4.name = "Frame.004"
	    frame_004_4.label_size = 20
	    frame_004_4.shrink = True
	
	    #node Reroute.016
	    reroute_016_5 = baby_hairs.nodes.new("NodeReroute")
	    reroute_016_5.name = "Reroute.016"
	    reroute_016_5.socket_idname = "NodeSocketGeometry"
	    #node Reroute.017
	    reroute_017_5 = baby_hairs.nodes.new("NodeReroute")
	    reroute_017_5.name = "Reroute.017"
	    reroute_017_5.socket_idname = "NodeSocketGeometry"
	    #node Reroute.018
	    reroute_018_5 = baby_hairs.nodes.new("NodeReroute")
	    reroute_018_5.name = "Reroute.018"
	    reroute_018_5.socket_idname = "NodeSocketInt"
	    #node Reroute.019
	    reroute_019_4 = baby_hairs.nodes.new("NodeReroute")
	    reroute_019_4.name = "Reroute.019"
	    reroute_019_4.socket_idname = "NodeSocketInt"
	    #node Reroute.020
	    reroute_020_4 = baby_hairs.nodes.new("NodeReroute")
	    reroute_020_4.name = "Reroute.020"
	    reroute_020_4.socket_idname = "NodeSocketBool"
	    #node Reroute.021
	    reroute_021_2 = baby_hairs.nodes.new("NodeReroute")
	    reroute_021_2.name = "Reroute.021"
	    reroute_021_2.socket_idname = "NodeSocketBool"
	    #node Reroute.022
	    reroute_022_2 = baby_hairs.nodes.new("NodeReroute")
	    reroute_022_2.name = "Reroute.022"
	    reroute_022_2.socket_idname = "NodeSocketBool"
	    #node Reroute.023
	    reroute_023_2 = baby_hairs.nodes.new("NodeReroute")
	    reroute_023_2.name = "Reroute.023"
	    reroute_023_2.socket_idname = "NodeSocketVector"
	    #node Reroute.024
	    reroute_024_2 = baby_hairs.nodes.new("NodeReroute")
	    reroute_024_2.name = "Reroute.024"
	    reroute_024_2.socket_idname = "NodeSocketVector"
	    #node Frame.002
	    frame_002_5 = baby_hairs.nodes.new("NodeFrame")
	    frame_002_5.label = "Extra Hairs"
	    frame_002_5.name = "Frame.002"
	    frame_002_5.label_size = 20
	    frame_002_5.shrink = True
	
	    #node Math.005
	    math_005_1 = baby_hairs.nodes.new("ShaderNodeMath")
	    math_005_1.name = "Math.005"
	    math_005_1.hide = True
	    math_005_1.operation = 'DIVIDE'
	    math_005_1.use_clamp = False
	    #Value_001
	    math_005_1.inputs[1].default_value = 5.0
	
	    #node Reroute.025
	    reroute_025_1 = baby_hairs.nodes.new("NodeReroute")
	    reroute_025_1.name = "Reroute.025"
	    reroute_025_1.socket_idname = "NodeSocketGeometry"
	    #node Reroute.028
	    reroute_028_2 = baby_hairs.nodes.new("NodeReroute")
	    reroute_028_2.name = "Reroute.028"
	    reroute_028_2.socket_idname = "NodeSocketGeometry"
	    #node Reroute.029
	    reroute_029_1 = baby_hairs.nodes.new("NodeReroute")
	    reroute_029_1.name = "Reroute.029"
	    reroute_029_1.socket_idname = "NodeSocketGeometry"
	    #node Group Input.016
	    group_input_016 = baby_hairs.nodes.new("NodeGroupInput")
	    group_input_016.name = "Group Input.016"
	    group_input_016.outputs[0].hide = True
	    group_input_016.outputs[1].hide = True
	    group_input_016.outputs[2].hide = True
	    group_input_016.outputs[3].hide = True
	    group_input_016.outputs[4].hide = True
	    group_input_016.outputs[5].hide = True
	    group_input_016.outputs[6].hide = True
	    group_input_016.outputs[7].hide = True
	    group_input_016.outputs[8].hide = True
	    group_input_016.outputs[9].hide = True
	    group_input_016.outputs[10].hide = True
	    group_input_016.outputs[11].hide = True
	    group_input_016.outputs[12].hide = True
	    group_input_016.outputs[13].hide = True
	    group_input_016.outputs[14].hide = True
	    group_input_016.outputs[15].hide = True
	    group_input_016.outputs[16].hide = True
	    group_input_016.outputs[17].hide = True
	    group_input_016.outputs[18].hide = True
	    group_input_016.outputs[19].hide = True
	    group_input_016.outputs[20].hide = True
	    group_input_016.outputs[21].hide = True
	    group_input_016.outputs[22].hide = True
	    group_input_016.outputs[23].hide = True
	    group_input_016.outputs[24].hide = True
	    group_input_016.outputs[25].hide = True
	    group_input_016.outputs[26].hide = True
	    group_input_016.outputs[27].hide = True
	    group_input_016.outputs[28].hide = True
	    group_input_016.outputs[30].hide = True
	    group_input_016.outputs[31].hide = True
	    group_input_016.outputs[32].hide = True
	
	    #node Capture Attribute.003
	    capture_attribute_003_1 = baby_hairs.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_003_1.name = "Capture Attribute.003"
	    capture_attribute_003_1.hide = True
	    capture_attribute_003_1.active_index = 0
	    capture_attribute_003_1.capture_items.clear()
	    capture_attribute_003_1.capture_items.new('FLOAT', "Index")
	    capture_attribute_003_1.capture_items["Index"].data_type = 'INT'
	    capture_attribute_003_1.domain = 'CURVE'
	
	    #node Index.003
	    index_003 = baby_hairs.nodes.new("GeometryNodeInputIndex")
	    index_003.name = "Index.003"
	    index_003.hide = True
	
	    #node Capture Attribute.004
	    capture_attribute_004_1 = baby_hairs.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_004_1.name = "Capture Attribute.004"
	    capture_attribute_004_1.hide = True
	    capture_attribute_004_1.active_index = 0
	    capture_attribute_004_1.capture_items.clear()
	    capture_attribute_004_1.capture_items.new('FLOAT', "Position")
	    capture_attribute_004_1.capture_items["Position"].data_type = 'FLOAT_VECTOR'
	    capture_attribute_004_1.domain = 'POINT'
	
	    #node Position.003
	    position_003 = baby_hairs.nodes.new("GeometryNodeInputPosition")
	    position_003.name = "Position.003"
	    position_003.hide = True
	
	    #node Boolean Math.001
	    boolean_math_001_1 = baby_hairs.nodes.new("FunctionNodeBooleanMath")
	    boolean_math_001_1.name = "Boolean Math.001"
	    boolean_math_001_1.hide = True
	    boolean_math_001_1.operation = 'AND'
	
	    #node Group Input.018
	    group_input_018 = baby_hairs.nodes.new("NodeGroupInput")
	    group_input_018.name = "Group Input.018"
	    group_input_018.outputs[0].hide = True
	    group_input_018.outputs[1].hide = True
	    group_input_018.outputs[2].hide = True
	    group_input_018.outputs[3].hide = True
	    group_input_018.outputs[4].hide = True
	    group_input_018.outputs[5].hide = True
	    group_input_018.outputs[6].hide = True
	    group_input_018.outputs[7].hide = True
	    group_input_018.outputs[8].hide = True
	    group_input_018.outputs[10].hide = True
	    group_input_018.outputs[11].hide = True
	    group_input_018.outputs[12].hide = True
	    group_input_018.outputs[13].hide = True
	    group_input_018.outputs[14].hide = True
	    group_input_018.outputs[15].hide = True
	    group_input_018.outputs[16].hide = True
	    group_input_018.outputs[17].hide = True
	    group_input_018.outputs[18].hide = True
	    group_input_018.outputs[19].hide = True
	    group_input_018.outputs[20].hide = True
	    group_input_018.outputs[21].hide = True
	    group_input_018.outputs[22].hide = True
	    group_input_018.outputs[23].hide = True
	    group_input_018.outputs[24].hide = True
	    group_input_018.outputs[25].hide = True
	    group_input_018.outputs[26].hide = True
	    group_input_018.outputs[27].hide = True
	    group_input_018.outputs[28].hide = True
	    group_input_018.outputs[29].hide = True
	    group_input_018.outputs[30].hide = True
	    group_input_018.outputs[31].hide = True
	    group_input_018.outputs[32].hide = True
	
	    #node Compare.005
	    compare_005_2 = baby_hairs.nodes.new("FunctionNodeCompare")
	    compare_005_2.name = "Compare.005"
	    compare_005_2.hide = True
	    compare_005_2.data_type = 'INT'
	    compare_005_2.mode = 'ELEMENT'
	    compare_005_2.operation = 'GREATER_THAN'
	
	    #node Group Input.019
	    group_input_019 = baby_hairs.nodes.new("NodeGroupInput")
	    group_input_019.name = "Group Input.019"
	    group_input_019.outputs[0].hide = True
	    group_input_019.outputs[1].hide = True
	    group_input_019.outputs[2].hide = True
	    group_input_019.outputs[3].hide = True
	    group_input_019.outputs[4].hide = True
	    group_input_019.outputs[5].hide = True
	    group_input_019.outputs[6].hide = True
	    group_input_019.outputs[7].hide = True
	    group_input_019.outputs[8].hide = True
	    group_input_019.outputs[9].hide = True
	    group_input_019.outputs[10].hide = True
	    group_input_019.outputs[11].hide = True
	    group_input_019.outputs[12].hide = True
	    group_input_019.outputs[13].hide = True
	    group_input_019.outputs[14].hide = True
	    group_input_019.outputs[15].hide = True
	    group_input_019.outputs[16].hide = True
	    group_input_019.outputs[17].hide = True
	    group_input_019.outputs[18].hide = True
	    group_input_019.outputs[19].hide = True
	    group_input_019.outputs[20].hide = True
	    group_input_019.outputs[21].hide = True
	    group_input_019.outputs[22].hide = True
	    group_input_019.outputs[23].hide = True
	    group_input_019.outputs[24].hide = True
	    group_input_019.outputs[26].hide = True
	    group_input_019.outputs[27].hide = True
	    group_input_019.outputs[28].hide = True
	    group_input_019.outputs[29].hide = True
	    group_input_019.outputs[30].hide = True
	    group_input_019.outputs[31].hide = True
	    group_input_019.outputs[32].hide = True
	
	    #node Delete Geometry.003
	    delete_geometry_003 = baby_hairs.nodes.new("GeometryNodeDeleteGeometry")
	    delete_geometry_003.name = "Delete Geometry.003"
	    delete_geometry_003.hide = True
	    delete_geometry_003.domain = 'CURVE'
	    delete_geometry_003.mode = 'ALL'
	
	    #node Compare.006
	    compare_006_1 = baby_hairs.nodes.new("FunctionNodeCompare")
	    compare_006_1.name = "Compare.006"
	    compare_006_1.hide = True
	    compare_006_1.data_type = 'INT'
	    compare_006_1.mode = 'ELEMENT'
	    compare_006_1.operation = 'GREATER_THAN'
	    #B_INT
	    compare_006_1.inputs[3].default_value = 0
	
	    #node Curve to Mesh.002
	    curve_to_mesh_002 = baby_hairs.nodes.new("GeometryNodeCurveToMesh")
	    curve_to_mesh_002.name = "Curve to Mesh.002"
	    curve_to_mesh_002.hide = True
	    #Fill Caps
	    curve_to_mesh_002.inputs[2].default_value = False
	
	    #node Geometry Proximity.001
	    geometry_proximity_001_1 = baby_hairs.nodes.new("GeometryNodeProximity")
	    geometry_proximity_001_1.name = "Geometry Proximity.001"
	    geometry_proximity_001_1.hide = True
	    geometry_proximity_001_1.target_element = 'EDGES'
	    #Group ID
	    geometry_proximity_001_1.inputs[1].default_value = 0
	    #Sample Group ID
	    geometry_proximity_001_1.inputs[3].default_value = 0
	
	    #node Group.004
	    group_004 = baby_hairs.nodes.new("GeometryNodeGroup")
	    group_004.name = "Group.004"
	    group_004.hide = True
	    group_004.node_tree = hair_shrinkwrap
	    #Socket_3
	    group_004.inputs[2].default_value = 0.0
	
	    #node Group Input.020
	    group_input_020 = baby_hairs.nodes.new("NodeGroupInput")
	    group_input_020.name = "Group Input.020"
	    group_input_020.outputs[0].hide = True
	    group_input_020.outputs[2].hide = True
	    group_input_020.outputs[3].hide = True
	    group_input_020.outputs[4].hide = True
	    group_input_020.outputs[5].hide = True
	    group_input_020.outputs[6].hide = True
	    group_input_020.outputs[7].hide = True
	    group_input_020.outputs[8].hide = True
	    group_input_020.outputs[9].hide = True
	    group_input_020.outputs[10].hide = True
	    group_input_020.outputs[11].hide = True
	    group_input_020.outputs[12].hide = True
	    group_input_020.outputs[13].hide = True
	    group_input_020.outputs[14].hide = True
	    group_input_020.outputs[15].hide = True
	    group_input_020.outputs[16].hide = True
	    group_input_020.outputs[17].hide = True
	    group_input_020.outputs[18].hide = True
	    group_input_020.outputs[19].hide = True
	    group_input_020.outputs[20].hide = True
	    group_input_020.outputs[21].hide = True
	    group_input_020.outputs[22].hide = True
	    group_input_020.outputs[23].hide = True
	    group_input_020.outputs[24].hide = True
	    group_input_020.outputs[25].hide = True
	    group_input_020.outputs[26].hide = True
	    group_input_020.outputs[27].hide = True
	    group_input_020.outputs[28].hide = True
	    group_input_020.outputs[29].hide = True
	    group_input_020.outputs[30].hide = True
	    group_input_020.outputs[31].hide = True
	    group_input_020.outputs[32].hide = True
	
	    #node Sample Curve.001
	    sample_curve_001_2 = baby_hairs.nodes.new("GeometryNodeSampleCurve")
	    sample_curve_001_2.name = "Sample Curve.001"
	    sample_curve_001_2.hide = True
	    sample_curve_001_2.data_type = 'FLOAT'
	    sample_curve_001_2.mode = 'FACTOR'
	    sample_curve_001_2.use_all_curves = False
	    #Value
	    sample_curve_001_2.inputs[1].default_value = 0.0
	    #Factor
	    sample_curve_001_2.inputs[2].default_value = 0.0
	
	    #node Vector Math.001
	    vector_math_001_6 = baby_hairs.nodes.new("ShaderNodeVectorMath")
	    vector_math_001_6.name = "Vector Math.001"
	    vector_math_001_6.hide = True
	    vector_math_001_6.operation = 'SUBTRACT'
	
	    #node Vector Math.002
	    vector_math_002_5 = baby_hairs.nodes.new("ShaderNodeVectorMath")
	    vector_math_002_5.name = "Vector Math.002"
	    vector_math_002_5.hide = True
	    vector_math_002_5.operation = 'SUBTRACT'
	
	    #node Vector Math.004
	    vector_math_004_5 = baby_hairs.nodes.new("ShaderNodeVectorMath")
	    vector_math_004_5.name = "Vector Math.004"
	    vector_math_004_5.hide = True
	    vector_math_004_5.operation = 'NORMALIZE'
	
	    #node Vector Math.005
	    vector_math_005_3 = baby_hairs.nodes.new("ShaderNodeVectorMath")
	    vector_math_005_3.name = "Vector Math.005"
	    vector_math_005_3.hide = True
	    vector_math_005_3.operation = 'NORMALIZE'
	
	    #node Vector Math.006
	    vector_math_006_3 = baby_hairs.nodes.new("ShaderNodeVectorMath")
	    vector_math_006_3.name = "Vector Math.006"
	    vector_math_006_3.hide = True
	    vector_math_006_3.operation = 'DOT_PRODUCT'
	
	    #node Compare.007
	    compare_007_1 = baby_hairs.nodes.new("FunctionNodeCompare")
	    compare_007_1.name = "Compare.007"
	    compare_007_1.hide = True
	    compare_007_1.data_type = 'FLOAT'
	    compare_007_1.mode = 'ELEMENT'
	    compare_007_1.operation = 'LESS_THAN'
	    #B
	    compare_007_1.inputs[1].default_value = 0.0
	
	    #node Delete Geometry.004
	    delete_geometry_004 = baby_hairs.nodes.new("GeometryNodeDeleteGeometry")
	    delete_geometry_004.name = "Delete Geometry.004"
	    delete_geometry_004.hide = True
	    delete_geometry_004.domain = 'POINT'
	    delete_geometry_004.mode = 'ALL'
	
	    #node Boolean Math.002
	    boolean_math_002_3 = baby_hairs.nodes.new("FunctionNodeBooleanMath")
	    boolean_math_002_3.name = "Boolean Math.002"
	    boolean_math_002_3.hide = True
	    boolean_math_002_3.operation = 'AND'
	
	    #node Reroute.030
	    reroute_030_1 = baby_hairs.nodes.new("NodeReroute")
	    reroute_030_1.name = "Reroute.030"
	    reroute_030_1.socket_idname = "NodeSocketGeometry"
	    #node Reroute.031
	    reroute_031 = baby_hairs.nodes.new("NodeReroute")
	    reroute_031.name = "Reroute.031"
	    reroute_031.socket_idname = "NodeSocketInt"
	    #node Reroute.032
	    reroute_032_1 = baby_hairs.nodes.new("NodeReroute")
	    reroute_032_1.name = "Reroute.032"
	    reroute_032_1.socket_idname = "NodeSocketGeometry"
	    #node Reroute.033
	    reroute_033 = baby_hairs.nodes.new("NodeReroute")
	    reroute_033.name = "Reroute.033"
	    reroute_033.socket_idname = "NodeSocketGeometry"
	    #node Reroute.034
	    reroute_034 = baby_hairs.nodes.new("NodeReroute")
	    reroute_034.name = "Reroute.034"
	    reroute_034.socket_idname = "NodeSocketGeometry"
	    #node Reroute.035
	    reroute_035 = baby_hairs.nodes.new("NodeReroute")
	    reroute_035.name = "Reroute.035"
	    reroute_035.socket_idname = "NodeSocketGeometry"
	    #node Reroute.036
	    reroute_036 = baby_hairs.nodes.new("NodeReroute")
	    reroute_036.name = "Reroute.036"
	    reroute_036.socket_idname = "NodeSocketVector"
	    #node Reroute.037
	    reroute_037 = baby_hairs.nodes.new("NodeReroute")
	    reroute_037.name = "Reroute.037"
	    reroute_037.socket_idname = "NodeSocketGeometry"
	    #node Reroute.038
	    reroute_038 = baby_hairs.nodes.new("NodeReroute")
	    reroute_038.name = "Reroute.038"
	    reroute_038.socket_idname = "NodeSocketInt"
	    #node Reroute.039
	    reroute_039 = baby_hairs.nodes.new("NodeReroute")
	    reroute_039.name = "Reroute.039"
	    reroute_039.socket_idname = "NodeSocketVector"
	    #node Reroute.040
	    reroute_040 = baby_hairs.nodes.new("NodeReroute")
	    reroute_040.name = "Reroute.040"
	    reroute_040.socket_idname = "NodeSocketVector"
	    #node Reroute.041
	    reroute_041 = baby_hairs.nodes.new("NodeReroute")
	    reroute_041.name = "Reroute.041"
	    reroute_041.socket_idname = "NodeSocketVector"
	    #node Reroute.042
	    reroute_042 = baby_hairs.nodes.new("NodeReroute")
	    reroute_042.name = "Reroute.042"
	    reroute_042.socket_idname = "NodeSocketVector"
	    #node Reroute.043
	    reroute_043 = baby_hairs.nodes.new("NodeReroute")
	    reroute_043.name = "Reroute.043"
	    reroute_043.socket_idname = "NodeSocketVector"
	    #node Frame.005
	    frame_005_3 = baby_hairs.nodes.new("NodeFrame")
	    frame_005_3.label = "Extra Hairs"
	    frame_005_3.name = "Frame.005"
	    frame_005_3.label_size = 20
	    frame_005_3.shrink = True
	
	    #node Switch.003
	    switch_003_6 = baby_hairs.nodes.new("GeometryNodeSwitch")
	    switch_003_6.name = "Switch.003"
	    switch_003_6.hide = True
	    switch_003_6.input_type = 'GEOMETRY'
	
	    #node Group Input.021
	    group_input_021 = baby_hairs.nodes.new("NodeGroupInput")
	    group_input_021.name = "Group Input.021"
	    group_input_021.outputs[0].hide = True
	    group_input_021.outputs[1].hide = True
	    group_input_021.outputs[2].hide = True
	    group_input_021.outputs[3].hide = True
	    group_input_021.outputs[4].hide = True
	    group_input_021.outputs[5].hide = True
	    group_input_021.outputs[6].hide = True
	    group_input_021.outputs[7].hide = True
	    group_input_021.outputs[8].hide = True
	    group_input_021.outputs[9].hide = True
	    group_input_021.outputs[10].hide = True
	    group_input_021.outputs[11].hide = True
	    group_input_021.outputs[12].hide = True
	    group_input_021.outputs[13].hide = True
	    group_input_021.outputs[14].hide = True
	    group_input_021.outputs[15].hide = True
	    group_input_021.outputs[16].hide = True
	    group_input_021.outputs[17].hide = True
	    group_input_021.outputs[18].hide = True
	    group_input_021.outputs[19].hide = True
	    group_input_021.outputs[20].hide = True
	    group_input_021.outputs[21].hide = True
	    group_input_021.outputs[22].hide = True
	    group_input_021.outputs[23].hide = True
	    group_input_021.outputs[24].hide = True
	    group_input_021.outputs[26].hide = True
	    group_input_021.outputs[27].hide = True
	    group_input_021.outputs[28].hide = True
	    group_input_021.outputs[29].hide = True
	    group_input_021.outputs[30].hide = True
	    group_input_021.outputs[31].hide = True
	    group_input_021.outputs[32].hide = True
	
	    #node Reroute.044
	    reroute_044 = baby_hairs.nodes.new("NodeReroute")
	    reroute_044.name = "Reroute.044"
	    reroute_044.socket_idname = "NodeSocketGeometry"
	    #node Join Geometry.004
	    join_geometry_004 = baby_hairs.nodes.new("GeometryNodeJoinGeometry")
	    join_geometry_004.name = "Join Geometry.004"
	    join_geometry_004.hide = True
	
	    #node Group.005
	    group_005_1 = baby_hairs.nodes.new("GeometryNodeGroup")
	    group_005_1.name = "Group.005"
	    group_005_1.node_tree = hair_shrinkwrap
	
	    #node Group Input.017
	    group_input_017 = baby_hairs.nodes.new("NodeGroupInput")
	    group_input_017.name = "Group Input.017"
	    group_input_017.outputs[0].hide = True
	    group_input_017.outputs[2].hide = True
	    group_input_017.outputs[3].hide = True
	    group_input_017.outputs[4].hide = True
	    group_input_017.outputs[5].hide = True
	    group_input_017.outputs[6].hide = True
	    group_input_017.outputs[7].hide = True
	    group_input_017.outputs[8].hide = True
	    group_input_017.outputs[9].hide = True
	    group_input_017.outputs[10].hide = True
	    group_input_017.outputs[11].hide = True
	    group_input_017.outputs[12].hide = True
	    group_input_017.outputs[13].hide = True
	    group_input_017.outputs[14].hide = True
	    group_input_017.outputs[15].hide = True
	    group_input_017.outputs[16].hide = True
	    group_input_017.outputs[17].hide = True
	    group_input_017.outputs[18].hide = True
	    group_input_017.outputs[19].hide = True
	    group_input_017.outputs[20].hide = True
	    group_input_017.outputs[21].hide = True
	    group_input_017.outputs[22].hide = True
	    group_input_017.outputs[23].hide = True
	    group_input_017.outputs[24].hide = True
	    group_input_017.outputs[25].hide = True
	    group_input_017.outputs[26].hide = True
	    group_input_017.outputs[27].hide = True
	    group_input_017.outputs[28].hide = True
	    group_input_017.outputs[29].hide = True
	    group_input_017.outputs[31].hide = True
	    group_input_017.outputs[32].hide = True
	
	    #node Delete Geometry.005
	    delete_geometry_005 = baby_hairs.nodes.new("GeometryNodeDeleteGeometry")
	    delete_geometry_005.name = "Delete Geometry.005"
	    delete_geometry_005.hide = True
	    delete_geometry_005.domain = 'CURVE'
	    delete_geometry_005.mode = 'ALL'
	
	    #node Group Input.022
	    group_input_022 = baby_hairs.nodes.new("NodeGroupInput")
	    group_input_022.name = "Group Input.022"
	    group_input_022.outputs[0].hide = True
	    group_input_022.outputs[1].hide = True
	    group_input_022.outputs[2].hide = True
	    group_input_022.outputs[3].hide = True
	    group_input_022.outputs[4].hide = True
	    group_input_022.outputs[5].hide = True
	    group_input_022.outputs[6].hide = True
	    group_input_022.outputs[7].hide = True
	    group_input_022.outputs[8].hide = True
	    group_input_022.outputs[10].hide = True
	    group_input_022.outputs[11].hide = True
	    group_input_022.outputs[12].hide = True
	    group_input_022.outputs[13].hide = True
	    group_input_022.outputs[14].hide = True
	    group_input_022.outputs[15].hide = True
	    group_input_022.outputs[16].hide = True
	    group_input_022.outputs[17].hide = True
	    group_input_022.outputs[18].hide = True
	    group_input_022.outputs[19].hide = True
	    group_input_022.outputs[20].hide = True
	    group_input_022.outputs[21].hide = True
	    group_input_022.outputs[22].hide = True
	    group_input_022.outputs[23].hide = True
	    group_input_022.outputs[24].hide = True
	    group_input_022.outputs[25].hide = True
	    group_input_022.outputs[26].hide = True
	    group_input_022.outputs[27].hide = True
	    group_input_022.outputs[28].hide = True
	    group_input_022.outputs[29].hide = True
	    group_input_022.outputs[30].hide = True
	    group_input_022.outputs[31].hide = True
	    group_input_022.outputs[32].hide = True
	
	    #node Compare.009
	    compare_009 = baby_hairs.nodes.new("FunctionNodeCompare")
	    compare_009.name = "Compare.009"
	    compare_009.hide = True
	    compare_009.data_type = 'INT'
	    compare_009.mode = 'ELEMENT'
	    compare_009.operation = 'LESS_EQUAL'
	
	    #node Reroute.026
	    reroute_026_2 = baby_hairs.nodes.new("NodeReroute")
	    reroute_026_2.name = "Reroute.026"
	    reroute_026_2.socket_idname = "NodeSocketInt"
	    #node Reroute.027
	    reroute_027_2 = baby_hairs.nodes.new("NodeReroute")
	    reroute_027_2.name = "Reroute.027"
	    reroute_027_2.socket_idname = "NodeSocketGeometry"
	    #node Reroute.045
	    reroute_045 = baby_hairs.nodes.new("NodeReroute")
	    reroute_045.name = "Reroute.045"
	    reroute_045.socket_idname = "NodeSocketGeometry"
	    #node Reroute.046
	    reroute_046 = baby_hairs.nodes.new("NodeReroute")
	    reroute_046.name = "Reroute.046"
	    reroute_046.socket_idname = "NodeSocketGeometry"
	    #node Reroute.048
	    reroute_048 = baby_hairs.nodes.new("NodeReroute")
	    reroute_048.name = "Reroute.048"
	    reroute_048.socket_idname = "NodeSocketGeometry"
	    #node Reroute.051
	    reroute_051 = baby_hairs.nodes.new("NodeReroute")
	    reroute_051.name = "Reroute.051"
	    reroute_051.socket_idname = "NodeSocketBool"
	    #node Reroute.052
	    reroute_052 = baby_hairs.nodes.new("NodeReroute")
	    reroute_052.name = "Reroute.052"
	    reroute_052.socket_idname = "NodeSocketBool"
	    #node Reroute.053
	    reroute_053 = baby_hairs.nodes.new("NodeReroute")
	    reroute_053.name = "Reroute.053"
	    reroute_053.socket_idname = "NodeSocketGeometry"
	    #node Frame.006
	    frame_006_3 = baby_hairs.nodes.new("NodeFrame")
	    frame_006_3.label = "Shrinkwrap"
	    frame_006_3.name = "Frame.006"
	    frame_006_3.label_size = 20
	    frame_006_3.shrink = True
	
	    #node Switch.004
	    switch_004_3 = baby_hairs.nodes.new("GeometryNodeSwitch")
	    switch_004_3.name = "Switch.004"
	    switch_004_3.hide = True
	    switch_004_3.input_type = 'GEOMETRY'
	
	    #node Capture Attribute.007
	    capture_attribute_007 = baby_hairs.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_007.name = "Capture Attribute.007"
	    capture_attribute_007.hide = True
	    capture_attribute_007.active_index = 0
	    capture_attribute_007.capture_items.clear()
	    capture_attribute_007.capture_items.new('FLOAT', "Index")
	    capture_attribute_007.capture_items["Index"].data_type = 'INT'
	    capture_attribute_007.domain = 'CURVE'
	
	    #node Index.005
	    index_005 = baby_hairs.nodes.new("GeometryNodeInputIndex")
	    index_005.name = "Index.005"
	    index_005.hide = True
	
	    #node Reroute.047
	    reroute_047 = baby_hairs.nodes.new("NodeReroute")
	    reroute_047.name = "Reroute.047"
	    reroute_047.socket_idname = "NodeSocketGeometry"
	    #node Group Input.023
	    group_input_023 = baby_hairs.nodes.new("NodeGroupInput")
	    group_input_023.name = "Group Input.023"
	    group_input_023.outputs[0].hide = True
	    group_input_023.outputs[1].hide = True
	    group_input_023.outputs[2].hide = True
	    group_input_023.outputs[3].hide = True
	    group_input_023.outputs[4].hide = True
	    group_input_023.outputs[5].hide = True
	    group_input_023.outputs[6].hide = True
	    group_input_023.outputs[7].hide = True
	    group_input_023.outputs[8].hide = True
	    group_input_023.outputs[9].hide = True
	    group_input_023.outputs[10].hide = True
	    group_input_023.outputs[11].hide = True
	    group_input_023.outputs[12].hide = True
	    group_input_023.outputs[13].hide = True
	    group_input_023.outputs[14].hide = True
	    group_input_023.outputs[15].hide = True
	    group_input_023.outputs[16].hide = True
	    group_input_023.outputs[17].hide = True
	    group_input_023.outputs[18].hide = True
	    group_input_023.outputs[19].hide = True
	    group_input_023.outputs[20].hide = True
	    group_input_023.outputs[21].hide = True
	    group_input_023.outputs[22].hide = True
	    group_input_023.outputs[23].hide = True
	    group_input_023.outputs[24].hide = True
	    group_input_023.outputs[25].hide = True
	    group_input_023.outputs[26].hide = True
	    group_input_023.outputs[27].hide = True
	    group_input_023.outputs[28].hide = True
	    group_input_023.outputs[29].hide = True
	    group_input_023.outputs[30].hide = True
	    group_input_023.outputs[32].hide = True
	
	    #node Reroute.049
	    reroute_049 = baby_hairs.nodes.new("NodeReroute")
	    reroute_049.name = "Reroute.049"
	    reroute_049.socket_idname = "NodeSocketGeometry"
	    #node Switch.002
	    switch_002_5 = baby_hairs.nodes.new("GeometryNodeSwitch")
	    switch_002_5.name = "Switch.002"
	    switch_002_5.hide = True
	    switch_002_5.input_type = 'GEOMETRY'
	
	    #node Compare.008
	    compare_008 = baby_hairs.nodes.new("FunctionNodeCompare")
	    compare_008.name = "Compare.008"
	    compare_008.hide = True
	    compare_008.data_type = 'FLOAT'
	    compare_008.mode = 'ELEMENT'
	    compare_008.operation = 'EQUAL'
	    #B
	    compare_008.inputs[1].default_value = 0.0
	    #Epsilon
	    compare_008.inputs[12].default_value = 0.0
	
	    #node Group Input.024
	    group_input_024 = baby_hairs.nodes.new("NodeGroupInput")
	    group_input_024.name = "Group Input.024"
	    group_input_024.outputs[0].hide = True
	    group_input_024.outputs[1].hide = True
	    group_input_024.outputs[2].hide = True
	    group_input_024.outputs[3].hide = True
	    group_input_024.outputs[4].hide = True
	    group_input_024.outputs[5].hide = True
	    group_input_024.outputs[6].hide = True
	    group_input_024.outputs[7].hide = True
	    group_input_024.outputs[8].hide = True
	    group_input_024.outputs[9].hide = True
	    group_input_024.outputs[10].hide = True
	    group_input_024.outputs[11].hide = True
	    group_input_024.outputs[12].hide = True
	    group_input_024.outputs[13].hide = True
	    group_input_024.outputs[14].hide = True
	    group_input_024.outputs[15].hide = True
	    group_input_024.outputs[16].hide = True
	    group_input_024.outputs[18].hide = True
	    group_input_024.outputs[19].hide = True
	    group_input_024.outputs[20].hide = True
	    group_input_024.outputs[21].hide = True
	    group_input_024.outputs[22].hide = True
	    group_input_024.outputs[23].hide = True
	    group_input_024.outputs[24].hide = True
	    group_input_024.outputs[25].hide = True
	    group_input_024.outputs[26].hide = True
	    group_input_024.outputs[27].hide = True
	    group_input_024.outputs[28].hide = True
	    group_input_024.outputs[29].hide = True
	    group_input_024.outputs[30].hide = True
	    group_input_024.outputs[31].hide = True
	    group_input_024.outputs[32].hide = True
	
	    #node Reroute.050
	    reroute_050 = baby_hairs.nodes.new("NodeReroute")
	    reroute_050.name = "Reroute.050"
	    reroute_050.socket_idname = "NodeSocketInt"
	    #node Reroute.054
	    reroute_054 = baby_hairs.nodes.new("NodeReroute")
	    reroute_054.name = "Reroute.054"
	    reroute_054.socket_idname = "NodeSocketGeometry"
	    #node Reroute.055
	    reroute_055 = baby_hairs.nodes.new("NodeReroute")
	    reroute_055.name = "Reroute.055"
	    reroute_055.socket_idname = "NodeSocketGeometry"
	    #node Reroute.056
	    reroute_056 = baby_hairs.nodes.new("NodeReroute")
	    reroute_056.name = "Reroute.056"
	    reroute_056.socket_idname = "NodeSocketInt"
	    #node Reroute.057
	    reroute_057 = baby_hairs.nodes.new("NodeReroute")
	    reroute_057.name = "Reroute.057"
	    reroute_057.socket_idname = "NodeSocketGeometry"
	    #node Group.006
	    group_006_1 = baby_hairs.nodes.new("GeometryNodeGroup")
	    group_006_1.name = "Group.006"
	    group_006_1.node_tree = attach_hair_curves_to_surface
	    group_006_1.inputs[1].hide = True
	    group_006_1.inputs[4].hide = True
	    group_006_1.inputs[5].hide = True
	    group_006_1.inputs[6].hide = True
	    group_006_1.inputs[7].hide = True
	    group_006_1.inputs[8].hide = True
	    group_006_1.outputs[1].hide = True
	    group_006_1.outputs[2].hide = True
	    #Socket_7
	    group_006_1.inputs[4].default_value = True
	    #Socket_8
	    group_006_1.inputs[5].default_value = True
	    #Socket_9
	    group_006_1.inputs[6].default_value = True
	    #Socket_10
	    group_006_1.inputs[7].default_value = True
	    #Socket_11
	    group_006_1.inputs[8].default_value = 0.0
	
	    #node Named Attribute
	    named_attribute_3 = baby_hairs.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute_3.name = "Named Attribute"
	    named_attribute_3.data_type = 'FLOAT_VECTOR'
	    #Name
	    named_attribute_3.inputs[0].default_value = "UVMap"
	
	    #node Group Input.025
	    group_input_025 = baby_hairs.nodes.new("NodeGroupInput")
	    group_input_025.name = "Group Input.025"
	    group_input_025.outputs[0].hide = True
	    group_input_025.outputs[2].hide = True
	    group_input_025.outputs[3].hide = True
	    group_input_025.outputs[4].hide = True
	    group_input_025.outputs[5].hide = True
	    group_input_025.outputs[6].hide = True
	    group_input_025.outputs[7].hide = True
	    group_input_025.outputs[8].hide = True
	    group_input_025.outputs[9].hide = True
	    group_input_025.outputs[10].hide = True
	    group_input_025.outputs[11].hide = True
	    group_input_025.outputs[12].hide = True
	    group_input_025.outputs[13].hide = True
	    group_input_025.outputs[14].hide = True
	    group_input_025.outputs[15].hide = True
	    group_input_025.outputs[16].hide = True
	    group_input_025.outputs[17].hide = True
	    group_input_025.outputs[18].hide = True
	    group_input_025.outputs[19].hide = True
	    group_input_025.outputs[20].hide = True
	    group_input_025.outputs[21].hide = True
	    group_input_025.outputs[22].hide = True
	    group_input_025.outputs[23].hide = True
	    group_input_025.outputs[24].hide = True
	    group_input_025.outputs[25].hide = True
	    group_input_025.outputs[26].hide = True
	    group_input_025.outputs[27].hide = True
	    group_input_025.outputs[28].hide = True
	    group_input_025.outputs[29].hide = True
	    group_input_025.outputs[30].hide = True
	    group_input_025.outputs[31].hide = True
	    group_input_025.outputs[32].hide = True
	
	    #node Frame.007
	    frame_007_3 = baby_hairs.nodes.new("NodeFrame")
	    frame_007_3.label = "UVMap"
	    frame_007_3.name = "Frame.007"
	    frame_007_3.label_size = 20
	    frame_007_3.shrink = True
	
	    #node Final Bake
	    final_bake = baby_hairs.nodes.new("GeometryNodeBake")
	    final_bake.label = "Final Bake"
	    final_bake.name = "Final Bake"
	    final_bake.active_index = 0
	    final_bake.bake_items.clear()
	    final_bake.bake_items.new('GEOMETRY', "Geometry")
	    final_bake.bake_items[0].attribute_domain = 'POINT'
	    final_bake.inputs[1].hide = True
	    final_bake.outputs[1].hide = True
	
	    #node Separate Components
	    separate_components_3 = baby_hairs.nodes.new("GeometryNodeSeparateComponents")
	    separate_components_3.name = "Separate Components"
	    separate_components_3.hide = True
	
	    #node Join Geometry.001
	    join_geometry_001_3 = baby_hairs.nodes.new("GeometryNodeJoinGeometry")
	    join_geometry_001_3.name = "Join Geometry.001"
	
	    #node Reroute.058
	    reroute_058 = baby_hairs.nodes.new("NodeReroute")
	    reroute_058.name = "Reroute.058"
	    reroute_058.socket_idname = "NodeSocketGeometry"
	    #node Reroute.059
	    reroute_059 = baby_hairs.nodes.new("NodeReroute")
	    reroute_059.name = "Reroute.059"
	    reroute_059.socket_idname = "NodeSocketGeometry"
	    #node Reroute.060
	    reroute_060 = baby_hairs.nodes.new("NodeReroute")
	    reroute_060.name = "Reroute.060"
	    reroute_060.socket_idname = "NodeSocketGeometry"
	    #node Reroute.061
	    reroute_061 = baby_hairs.nodes.new("NodeReroute")
	    reroute_061.name = "Reroute.061"
	    reroute_061.socket_idname = "NodeSocketGeometry"
	    #node Reroute.062
	    reroute_062 = baby_hairs.nodes.new("NodeReroute")
	    reroute_062.name = "Reroute.062"
	    reroute_062.socket_idname = "NodeSocketGeometry"
	    #node Reroute.063
	    reroute_063 = baby_hairs.nodes.new("NodeReroute")
	    reroute_063.name = "Reroute.063"
	    reroute_063.socket_idname = "NodeSocketGeometry"
	    #node Reroute.064
	    reroute_064 = baby_hairs.nodes.new("NodeReroute")
	    reroute_064.name = "Reroute.064"
	    reroute_064.socket_idname = "NodeSocketGeometry"
	    #node Reroute.065
	    reroute_065 = baby_hairs.nodes.new("NodeReroute")
	    reroute_065.name = "Reroute.065"
	    reroute_065.socket_idname = "NodeSocketGeometry"
	    #node Reroute.066
	    reroute_066 = baby_hairs.nodes.new("NodeReroute")
	    reroute_066.name = "Reroute.066"
	    reroute_066.socket_idname = "NodeSocketGeometry"
	    #node Reroute.067
	    reroute_067 = baby_hairs.nodes.new("NodeReroute")
	    reroute_067.name = "Reroute.067"
	    reroute_067.socket_idname = "NodeSocketGeometry"
	
	
	
	    #Set parents
	    group_002_1.parent = frame_006_3
	    group_input_003_5.parent = frame_006_3
	    set_position_5.parent = frame_7
	    vector_math_6.parent = frame_7
	    capture_attribute_5.parent = frame_7
	    position_4.parent = frame_7
	    resample_curve_001.parent = frame_001_4
	    resample_curve_002.parent = frame_001_4
	    group_input_007_4.parent = frame_001_4
	    math_5.parent = frame_001_4
	    group_input_008_3.parent = frame_001_4
	    curve_to_mesh.parent = frame_001_4
	    mesh_to_curve.parent = frame_001_4
	    object_info_1.parent = frame_001_4
	    geometry_proximity_1.parent = frame_001_4
	    capture_attribute_001_4.parent = frame_001_4
	    position_001_3.parent = frame_001_4
	    index_3.parent = frame_001_4
	    curve_to_points_1.parent = frame_001_4
	    compare_5.parent = frame_001_4
	    compare_001_4.parent = frame_001_4
	    boolean_math_5.parent = frame_001_4
	    delete_geometry.parent = frame_001_4
	    math_001_3.parent = frame_001_4
	    group_input_009_3.parent = frame_001_4
	    group_input_010_2.parent = frame_001_4
	    sample_curve_1.parent = frame_002_5
	    spline_parameter_001_1.parent = frame_002_5
	    resample_curve_003.parent = frame_002_5
	    curve_to_points_001_1.parent = frame_002_5
	    instance_on_points.parent = frame_002_5
	    set_position_002_2.parent = frame_002_5
	    capture_attribute_002_4.parent = frame_002_5
	    position_002_4.parent = frame_002_5
	    vector_math_003_5.parent = frame_002_5
	    realize_instances.parent = frame_002_5
	    group_003_2.parent = frame_002_5
	    delete_geometry_001.parent = frame_002_5
	    index_001_3.parent = frame_002_5
	    compare_003_3.parent = frame_002_5
	    compare_004_4.parent = frame_002_5
	    index_002_2.parent = frame_002_5
	    delete_geometry_002_1.parent = frame_002_5
	    reverse_curve.parent = frame_002_5
	    baby_hairs_shape.parent = frame_003_4
	    spline_parameter_002.parent = frame_003_4
	    math_003_3.parent = frame_003_4
	    group_input_014.parent = frame_003_4
	    set_curve_radius_001.parent = frame_003_4
	    reroute_012_6.parent = frame_002_5
	    reroute_014_5.parent = frame_002_5
	    reroute_015_5.parent = frame_002_5
	    extra_hairs_shape.parent = frame_004_4
	    spline_parameter_003.parent = frame_004_4
	    math_004_1.parent = frame_004_4
	    group_input_015.parent = frame_004_4
	    set_curve_radius_002.parent = frame_004_4
	    frame_004_4.parent = frame_002_5
	    reroute_016_5.parent = frame_002_5
	    reroute_017_5.parent = frame_002_5
	    reroute_018_5.parent = frame_002_5
	    reroute_019_4.parent = frame_002_5
	    reroute_020_4.parent = frame_002_5
	    reroute_021_2.parent = frame_002_5
	    reroute_022_2.parent = frame_002_5
	    reroute_023_2.parent = frame_002_5
	    reroute_024_2.parent = frame_002_5
	    math_005_1.parent = frame_004_4
	    reroute_028_2.parent = frame_006_3
	    reroute_029_1.parent = frame_002_5
	    group_input_016.parent = frame_002_5
	    capture_attribute_003_1.parent = frame_005_3
	    index_003.parent = frame_005_3
	    capture_attribute_004_1.parent = frame_005_3
	    position_003.parent = frame_005_3
	    boolean_math_001_1.parent = frame_005_3
	    group_input_018.parent = frame_005_3
	    compare_005_2.parent = frame_005_3
	    group_input_019.parent = frame_005_3
	    delete_geometry_003.parent = frame_005_3
	    compare_006_1.parent = frame_005_3
	    curve_to_mesh_002.parent = frame_005_3
	    geometry_proximity_001_1.parent = frame_005_3
	    group_004.parent = frame_005_3
	    group_input_020.parent = frame_005_3
	    sample_curve_001_2.parent = frame_005_3
	    vector_math_001_6.parent = frame_005_3
	    vector_math_002_5.parent = frame_005_3
	    vector_math_004_5.parent = frame_005_3
	    vector_math_005_3.parent = frame_005_3
	    vector_math_006_3.parent = frame_005_3
	    compare_007_1.parent = frame_005_3
	    boolean_math_002_3.parent = frame_005_3
	    reroute_031.parent = frame_005_3
	    reroute_033.parent = frame_005_3
	    reroute_034.parent = frame_005_3
	    reroute_035.parent = frame_005_3
	    reroute_036.parent = frame_005_3
	    reroute_037.parent = frame_005_3
	    reroute_038.parent = frame_005_3
	    reroute_039.parent = frame_005_3
	    reroute_040.parent = frame_005_3
	    reroute_041.parent = frame_005_3
	    reroute_042.parent = frame_005_3
	    reroute_043.parent = frame_005_3
	    switch_003_6.parent = frame_006_3
	    group_input_021.parent = frame_006_3
	    reroute_044.parent = frame_006_3
	    join_geometry_004.parent = frame_006_3
	    group_005_1.parent = frame_006_3
	    group_input_017.parent = frame_006_3
	    delete_geometry_005.parent = frame_006_3
	    group_input_022.parent = frame_006_3
	    compare_009.parent = frame_006_3
	    reroute_026_2.parent = frame_006_3
	    reroute_027_2.parent = frame_006_3
	    reroute_045.parent = frame_006_3
	    reroute_046.parent = frame_006_3
	    reroute_048.parent = frame_006_3
	    reroute_051.parent = frame_006_3
	    reroute_052.parent = frame_006_3
	    reroute_053.parent = frame_006_3
	    capture_attribute_007.parent = frame_006_3
	    index_005.parent = frame_006_3
	    reroute_047.parent = frame_006_3
	    group_006_1.parent = frame_007_3
	    named_attribute_3.parent = frame_007_3
	    group_input_025.parent = frame_007_3
	
	    #Set locations
	    group_input_7.location = (-340.0, 0.0)
	    group_output_10.location = (3710.15478515625, 253.6625213623047)
	    resample_curve.location = (-159.8823699951172, 46.70746994018555)
	    group_6.location = (679.2781982421875, 140.95254516601562)
	    group_001_5.location = (870.1892700195312, -57.147056579589844)
	    group_002_1.location = (246.7872314453125, -94.21527099609375)
	    group_input_001_5.location = (506.3309020996094, 52.6111946105957)
	    group_input_002_4.location = (681.5573120117188, -147.9561309814453)
	    group_input_003_5.location = (82.787841796875, -168.00338745117188)
	    set_material.location = (2382.1376953125, 183.48007202148438)
	    group_input_005_4.location = (2207.62744140625, 97.950439453125)
	    set_position_5.location = (356.463134765625, -49.226646423339844)
	    vector_math_6.location = (198.197265625, -55.55845642089844)
	    capture_attribute_5.location = (34.734375, -44.56610107421875)
	    position_4.location = (30.4658203125, -81.63262939453125)
	    switch_6.location = (2734.478271484375, 156.96517944335938)
	    join_geometry_2.location = (2740.55712890625, 117.03821563720703)
	    frame_7.location = (2385.0, 29.0)
	    group_input_006_4.location = (2593.4521484375, 236.22610473632812)
	    reroute_7.location = (2552.556396484375, 147.8890838623047)
	    reroute_001_7.location = (2424.62060546875, 42.74127197265625)
	    reroute_002_5.location = (2882.199462890625, 41.51223373413086)
	    reroute_003_5.location = (2554.76123046875, 42.154319763183594)
	    reroute_004_6.location = (2743.53076171875, 42.14756774902344)
	    reroute_005_5.location = (2553.241943359375, 109.34635925292969)
	    resample_curve_001.location = (170.83837890625, -283.6490478515625)
	    resample_curve_002.location = (1236.234375, -309.9123840332031)
	    group_input_007_4.location = (1233.798583984375, -247.20751953125)
	    math_5.location = (31.771484375, -201.43603515625)
	    group_input_008_3.location = (30.2103271484375, -139.372314453125)
	    curve_to_mesh.location = (168.4560546875, -328.56927490234375)
	    mesh_to_curve.location = (1053.71337890625, -297.8879699707031)
	    object_info_1.location = (494.0181884765625, -72.36553955078125)
	    geometry_proximity_1.location = (493.9073486328125, -170.147216796875)
	    capture_attribute_001_4.location = (360.905517578125, -345.2586975097656)
	    position_001_3.location = (351.5628662109375, -383.4822692871094)
	    index_3.location = (351.109619140625, -291.236083984375)
	    curve_to_points_1.location = (493.703369140625, -124.3712158203125)
	    compare_5.location = (751.29443359375, -269.5177307128906)
	    compare_001_4.location = (751.08203125, -230.1953125)
	    boolean_math_5.location = (910.48046875, -256.24053955078125)
	    delete_geometry.location = (1052.7333984375, -338.50213623046875)
	    math_001_3.location = (746.761962890625, -192.50640869140625)
	    group_input_009_3.location = (301.28466796875, -39.56439208984375)
	    group_input_010_2.location = (614.55322265625, -359.49578857421875)
	    frame_001_4.location = (1494.0, 702.0)
	    reroute_006_5.location = (2162.39794921875, 245.98516845703125)
	    reroute_007_5.location = (2110.25830078125, 245.413818359375)
	    reroute_008_5.location = (2869.714599609375, 249.59146118164062)
	    reroute_009_5.location = (1667.48876953125, 248.06146240234375)
	    switch_001_7.location = (2207.2294921875, 133.78445434570312)
	    reroute_010_4.location = (2112.972900390625, 112.45211791992188)
	    compare_002_4.location = (2203.73828125, 168.02467346191406)
	    group_input_011_1.location = (2202.864990234375, 230.42759704589844)
	    reroute_011_5.location = (2161.533935546875, 124.73583221435547)
	    sample_curve_1.location = (224.47071838378906, -281.4234924316406)
	    spline_parameter_001_1.location = (223.0216827392578, -317.2159118652344)
	    resample_curve_003.location = (35.29010009765625, -90.24398803710938)
	    curve_to_points_001_1.location = (30.440086364746094, -190.11032104492188)
	    instance_on_points.location = (747.2705078125, -199.75711059570312)
	    set_position_002_2.location = (745.892578125, -266.4634094238281)
	    capture_attribute_002_4.location = (226.8690643310547, -190.77053833007812)
	    position_002_4.location = (225.72816467285156, -137.95846557617188)
	    vector_math_003_5.location = (579.4313354492188, -272.0107727050781)
	    realize_instances.location = (747.2597045898438, -320.9042053222656)
	    join_geometry_003.location = (1191.7529296875, -310.2608337402344)
	    group_003_2.location = (1093.789794921875, -44.474395751953125)
	    delete_geometry_001.location = (576.1066284179688, -232.23855590820312)
	    index_001_3.location = (411.55670166015625, -375.8220520019531)
	    compare_003_3.location = (410.3155822753906, -410.5070495605469)
	    compare_004_4.location = (407.00042724609375, -336.9831848144531)
	    index_002_2.location = (227.97027587890625, -226.62081909179688)
	    delete_geometry_002_1.location = (566.1033325195312, -181.00894165039062)
	    reverse_curve.location = (35.45728302001953, -137.96701049804688)
	    baby_hairs_shape.location = (33.5968017578125, -134.10015869140625)
	    spline_parameter_002.location = (30.144287109375, -449.96612548828125)
	    math_003_3.location = (295.4136962890625, -168.09690856933594)
	    group_input_014.location = (291.0987548828125, -201.9226837158203)
	    set_curve_radius_001.location = (288.1611328125, -40.447052001953125)
	    frame_003_4.location = (26.0, 110.0)
	    reroute_012_6.location = (41.06984329223633, -45.0)
	    reroute_013_5.location = (-6.715243339538574, 12.236936569213867)
	    group_input_004_4.location = (-196.31930541992188, -583.7837524414062)
	    group_input_012_1.location = (-198.9629364013672, -732.3084716796875)
	    group_input_013_1.location = (-197.78305053710938, -808.6336059570312)
	    reroute_014_5.location = (199.62289428710938, -46.75140380859375)
	    reroute_015_5.location = (202.4659881591797, -278.6111145019531)
	    extra_hairs_shape.location = (33.647216796875, -124.10052490234375)
	    spline_parameter_003.location = (30.1947021484375, -439.966552734375)
	    math_004_1.location = (295.464111328125, -158.0972900390625)
	    group_input_015.location = (291.149169921875, -229.05419921875)
	    set_curve_radius_002.location = (288.2115478515625, -30.44744873046875)
	    frame_004_4.location = (641.0, -244.95907592773438)
	    reroute_016_5.location = (522.3901977539062, -47.193206787109375)
	    reroute_017_5.location = (528.16455078125, -235.27938842773438)
	    reroute_018_5.location = (390.99298095703125, -339.6638488769531)
	    reroute_019_4.location = (388.1249694824219, -205.04043579101562)
	    reroute_020_4.location = (546.1140747070312, -199.93777465820312)
	    reroute_021_2.location = (566.0343017578125, -421.4573669433594)
	    reroute_022_2.location = (564.4041748046875, -251.55886840820312)
	    reroute_023_2.location = (445.9541931152344, -196.32467651367188)
	    reroute_024_2.location = (448.57696533203125, -271.8446960449219)
	    frame_002_5.location = (-41.0, -410.0409240722656)
	    math_005_1.location = (295.464111328125, -195.22845458984375)
	    reroute_025_1.location = (1190.67626953125, 121.25188446044922)
	    reroute_028_2.location = (189.604248046875, -511.1033020019531)
	    reroute_029_1.location = (1066.82373046875, -150.04519653320312)
	    group_input_016.location = (909.00048828125, -135.66873168945312)
	    capture_attribute_003_1.location = (303.8739013671875, -189.50509643554688)
	    index_003.location = (31.66259765625, -188.05511474609375)
	    capture_attribute_004_1.location = (492.6572265625, -56.44781494140625)
	    position_003.location = (36.9296875, -56.249755859375)
	    boolean_math_001_1.location = (1429.34423828125, -154.98892211914062)
	    group_input_018.location = (1089.36767578125, -269.466064453125)
	    compare_005_2.location = (1429.762451171875, -190.68301391601562)
	    group_input_019.location = (1091.270263671875, -212.86376953125)
	    delete_geometry_003.location = (709.04931640625, -275.4169921875)
	    compare_006_1.location = (712.8582763671875, -313.29693603515625)
	    curve_to_mesh_002.location = (712.02587890625, -239.31536865234375)
	    geometry_proximity_001_1.location = (898.45361328125, -250.69866943359375)
	    group_004.location = (303.2926025390625, -149.61563110351562)
	    group_input_020.location = (30.2452392578125, -126.4935302734375)
	    sample_curve_001_2.location = (683.5814208984375, -56.985931396484375)
	    vector_math_001_6.location = (1078.99365234375, -45.315032958984375)
	    vector_math_002_5.location = (1082.287841796875, -119.53775024414062)
	    vector_math_004_5.location = (1081.483642578125, -83.72903442382812)
	    vector_math_005_3.location = (1088.126708984375, -155.30496215820312)
	    vector_math_006_3.location = (1250.699462890625, -149.91964721679688)
	    compare_007_1.location = (1252.969482421875, -115.73065185546875)
	    delete_geometry_004.location = (2861.343505859375, -322.3406066894531)
	    boolean_math_002_3.location = (1424.446533203125, -119.13385009765625)
	    reroute_030_1.location = (1607.41650390625, -321.1880187988281)
	    reroute_031.location = (691.930419921875, -199.82363891601562)
	    reroute_032_1.location = (2999.01416015625, -274.6456298828125)
	    reroute_033.location = (467.7867431640625, -187.86270141601562)
	    reroute_034.location = (467.0401611328125, -54.59637451171875)
	    reroute_035.location = (657.5953369140625, -54.88336181640625)
	    reroute_036.location = (636.4368896484375, -143.20703125)
	    reroute_037.location = (663.250244140625, -278.2945556640625)
	    reroute_038.location = (698.450439453125, -315.98309326171875)
	    reroute_039.location = (879.068359375, -139.95767211914062)
	    reroute_040.location = (884.28759765625, -265.29449462890625)
	    reroute_041.location = (1055.35546875, -248.5780029296875)
	    reroute_042.location = (1045.993408203125, -46.832305908203125)
	    reroute_043.location = (1049.03466796875, -121.37237548828125)
	    frame_005_3.location = (1302.0, -310.0)
	    switch_003_6.location = (563.6015625, -119.13124084472656)
	    group_input_021.location = (426.8685302734375, -39.91728210449219)
	    reroute_044.location = (229.5478515625, -116.65159606933594)
	    join_geometry_004.location = (562.649169921875, -168.44363403320312)
	    group_005_1.location = (422.1007080078125, -339.38916015625)
	    group_input_017.location = (204.299560546875, -427.16107177734375)
	    delete_geometry_005.location = (422.6724853515625, -210.69564819335938)
	    group_input_022.location = (30.060302734375, -404.5652160644531)
	    compare_009.location = (205.9063720703125, -326.8301696777344)
	    reroute_026_2.location = (168.9990234375, -346.4656982421875)
	    reroute_027_2.location = (188.5748291015625, -395.82830810546875)
	    reroute_045.location = (425.53857421875, -283.11932373046875)
	    reroute_046.location = (561.0458984375, -283.11932373046875)
	    reroute_048.location = (232.61474609375, -173.65904235839844)
	    reroute_051.location = (406.10986328125, -228.66036987304688)
	    reroute_052.location = (407.7662353515625, -337.3461608886719)
	    reroute_053.location = (413.2789306640625, -128.51199340820312)
	    frame_006_3.location = (1179.0, 241.0)
	    switch_004_3.location = (1924.5025634765625, 121.86875915527344)
	    capture_attribute_007.location = (204.6712646484375, -397.17169189453125)
	    index_005.location = (206.825439453125, -362.6783752441406)
	    reroute_047.location = (415.7747802734375, -176.58172607421875)
	    group_input_023.location = (1923.9801025390625, 188.14581298828125)
	    reroute_049.location = (1929.4114990234375, 22.017175674438477)
	    switch_002_5.location = (1022.4134521484375, 130.98468017578125)
	    compare_008.location = (1025.468505859375, 166.9058380126953)
	    group_input_024.location = (1024.547607421875, 228.7401885986328)
	    reroute_050.location = (837.9011840820312, 83.94673156738281)
	    reroute_054.location = (856.6083984375, 106.16084289550781)
	    reroute_055.location = (857.6417236328125, -138.83226013183594)
	    reroute_056.location = (840.38916015625, -160.16104125976562)
	    reroute_057.location = (1008.8994140625, 121.69691467285156)
	    group_006_1.location = (197.53759765625, -40.48890686035156)
	    named_attribute_3.location = (36.79345703125, -202.56317138671875)
	    group_input_025.location = (29.584716796875, -131.61669921875)
	    frame_007_3.location = (2924.0, 269.0)
	    final_bake.location = (3530.1376953125, 301.8968200683594)
	    separate_components_3.location = (-338.26318359375, 42.8817138671875)
	    join_geometry_001_3.location = (3356.83154296875, 253.14341735839844)
	    reroute_058.location = (194.8363037109375, 792.3807373046875)
	    reroute_059.location = (194.8363037109375, 772.2886352539062)
	    reroute_060.location = (194.8363037109375, 777.23583984375)
	    reroute_061.location = (194.8363037109375, 782.2263793945312)
	    reroute_062.location = (194.8363037109375, 787.2520751953125)
	    reroute_063.location = (3019.713134765625, 794.9907836914062)
	    reroute_064.location = (3019.713134765625, 779.9904174804688)
	    reroute_065.location = (3019.713134765625, 784.990234375)
	    reroute_066.location = (3019.713134765625, 774.9905395507812)
	    reroute_067.location = (3019.713134765625, 789.990478515625)
	
	    #Set dimensions
	    group_input_7.width, group_input_7.height = 140.0, 100.0
	    group_output_10.width, group_output_10.height = 140.0, 100.0
	    resample_curve.width, resample_curve.height = 140.0, 100.0
	    group_6.width, group_6.height = 140.0, 100.0
	    group_001_5.width, group_001_5.height = 140.0, 100.0
	    group_002_1.width, group_002_1.height = 140.0, 100.0
	    group_input_001_5.width, group_input_001_5.height = 140.0, 100.0
	    group_input_002_4.width, group_input_002_4.height = 140.0, 100.0
	    group_input_003_5.width, group_input_003_5.height = 140.0, 100.0
	    set_material.width, set_material.height = 140.0, 100.0
	    group_input_005_4.width, group_input_005_4.height = 140.0, 100.0
	    set_position_5.width, set_position_5.height = 140.0, 100.0
	    vector_math_6.width, vector_math_6.height = 140.0, 100.0
	    capture_attribute_5.width, capture_attribute_5.height = 140.0, 100.0
	    position_4.width, position_4.height = 140.0, 100.0
	    switch_6.width, switch_6.height = 140.0, 100.0
	    join_geometry_2.width, join_geometry_2.height = 140.0, 100.0
	    frame_7.width, frame_7.height = 526.0, 137.0
	    group_input_006_4.width, group_input_006_4.height = 140.0, 100.0
	    reroute_7.width, reroute_7.height = 10.0, 100.0
	    reroute_001_7.width, reroute_001_7.height = 10.0, 100.0
	    reroute_002_5.width, reroute_002_5.height = 10.0, 100.0
	    reroute_003_5.width, reroute_003_5.height = 10.0, 100.0
	    reroute_004_6.width, reroute_004_6.height = 10.0, 100.0
	    reroute_005_5.width, reroute_005_5.height = 10.0, 100.0
	    resample_curve_001.width, resample_curve_001.height = 140.0, 100.0
	    resample_curve_002.width, resample_curve_002.height = 140.0, 100.0
	    group_input_007_4.width, group_input_007_4.height = 140.0, 100.0
	    math_5.width, math_5.height = 140.0, 100.0
	    group_input_008_3.width, group_input_008_3.height = 140.0, 100.0
	    curve_to_mesh.width, curve_to_mesh.height = 140.0, 100.0
	    mesh_to_curve.width, mesh_to_curve.height = 140.0, 100.0
	    object_info_1.width, object_info_1.height = 140.0, 100.0
	    geometry_proximity_1.width, geometry_proximity_1.height = 140.0, 100.0
	    capture_attribute_001_4.width, capture_attribute_001_4.height = 140.0, 100.0
	    position_001_3.width, position_001_3.height = 140.0, 100.0
	    index_3.width, index_3.height = 140.0, 100.0
	    curve_to_points_1.width, curve_to_points_1.height = 140.0, 100.0
	    compare_5.width, compare_5.height = 140.0, 100.0
	    compare_001_4.width, compare_001_4.height = 140.0, 100.0
	    boolean_math_5.width, boolean_math_5.height = 140.0, 100.0
	    delete_geometry.width, delete_geometry.height = 140.0, 100.0
	    math_001_3.width, math_001_3.height = 140.0, 100.0
	    group_input_009_3.width, group_input_009_3.height = 140.0, 100.0
	    group_input_010_2.width, group_input_010_2.height = 140.0, 100.0
	    frame_001_4.width, frame_001_4.height = 1406.0, 441.0
	    reroute_006_5.width, reroute_006_5.height = 10.0, 100.0
	    reroute_007_5.width, reroute_007_5.height = 10.0, 100.0
	    reroute_008_5.width, reroute_008_5.height = 10.0, 100.0
	    reroute_009_5.width, reroute_009_5.height = 10.0, 100.0
	    switch_001_7.width, switch_001_7.height = 140.0, 100.0
	    reroute_010_4.width, reroute_010_4.height = 10.0, 100.0
	    compare_002_4.width, compare_002_4.height = 140.0, 100.0
	    group_input_011_1.width, group_input_011_1.height = 140.0, 100.0
	    reroute_011_5.width, reroute_011_5.height = 10.0, 100.0
	    sample_curve_1.width, sample_curve_1.height = 140.0, 100.0
	    spline_parameter_001_1.width, spline_parameter_001_1.height = 140.0, 100.0
	    resample_curve_003.width, resample_curve_003.height = 140.0, 100.0
	    curve_to_points_001_1.width, curve_to_points_001_1.height = 140.0, 100.0
	    instance_on_points.width, instance_on_points.height = 140.0, 100.0
	    set_position_002_2.width, set_position_002_2.height = 140.0, 100.0
	    capture_attribute_002_4.width, capture_attribute_002_4.height = 140.0, 100.0
	    position_002_4.width, position_002_4.height = 140.0, 100.0
	    vector_math_003_5.width, vector_math_003_5.height = 140.0, 100.0
	    realize_instances.width, realize_instances.height = 140.0, 100.0
	    join_geometry_003.width, join_geometry_003.height = 140.0, 100.0
	    group_003_2.width, group_003_2.height = 140.0, 100.0
	    delete_geometry_001.width, delete_geometry_001.height = 140.0, 100.0
	    index_001_3.width, index_001_3.height = 140.0, 100.0
	    compare_003_3.width, compare_003_3.height = 140.0, 100.0
	    compare_004_4.width, compare_004_4.height = 140.0, 100.0
	    index_002_2.width, index_002_2.height = 140.0, 100.0
	    delete_geometry_002_1.width, delete_geometry_002_1.height = 140.0, 100.0
	    reverse_curve.width, reverse_curve.height = 140.0, 100.0
	    baby_hairs_shape.width, baby_hairs_shape.height = 240.0, 100.0
	    spline_parameter_002.width, spline_parameter_002.height = 140.0, 100.0
	    math_003_3.width, math_003_3.height = 140.0, 100.0
	    group_input_014.width, group_input_014.height = 140.0, 100.0
	    set_curve_radius_001.width, set_curve_radius_001.height = 140.0, 100.0
	    frame_003_4.width, frame_003_4.height = 465.0, 505.0
	    reroute_012_6.width, reroute_012_6.height = 10.0, 100.0
	    reroute_013_5.width, reroute_013_5.height = 10.0, 100.0
	    group_input_004_4.width, group_input_004_4.height = 140.0, 100.0
	    group_input_012_1.width, group_input_012_1.height = 140.0, 100.0
	    group_input_013_1.width, group_input_013_1.height = 140.0, 100.0
	    reroute_014_5.width, reroute_014_5.height = 10.0, 100.0
	    reroute_015_5.width, reroute_015_5.height = 10.0, 100.0
	    extra_hairs_shape.width, extra_hairs_shape.height = 240.0, 100.0
	    spline_parameter_003.width, spline_parameter_003.height = 140.0, 100.0
	    math_004_1.width, math_004_1.height = 140.0, 100.0
	    group_input_015.width, group_input_015.height = 140.0, 100.0
	    set_curve_radius_002.width, set_curve_radius_002.height = 140.0, 100.0
	    frame_004_4.width, frame_004_4.height = 465.0, 495.0
	    reroute_016_5.width, reroute_016_5.height = 10.0, 100.0
	    reroute_017_5.width, reroute_017_5.height = 10.0, 100.0
	    reroute_018_5.width, reroute_018_5.height = 10.0, 100.0
	    reroute_019_4.width, reroute_019_4.height = 10.0, 100.0
	    reroute_020_4.width, reroute_020_4.height = 10.0, 100.0
	    reroute_021_2.width, reroute_021_2.height = 10.0, 100.0
	    reroute_022_2.width, reroute_022_2.height = 10.0, 100.0
	    reroute_023_2.width, reroute_023_2.height = 10.0, 100.0
	    reroute_024_2.width, reroute_024_2.height = 10.0, 100.0
	    frame_002_5.width, frame_002_5.height = 1264.0, 769.9591064453125
	    math_005_1.width, math_005_1.height = 140.0, 100.0
	    reroute_025_1.width, reroute_025_1.height = 10.0, 100.0
	    reroute_028_2.width, reroute_028_2.height = 10.0, 100.0
	    reroute_029_1.width, reroute_029_1.height = 10.0, 100.0
	    group_input_016.width, group_input_016.height = 140.0, 100.0
	    capture_attribute_003_1.width, capture_attribute_003_1.height = 140.0, 100.0
	    index_003.width, index_003.height = 140.0, 100.0
	    capture_attribute_004_1.width, capture_attribute_004_1.height = 140.0, 100.0
	    position_003.width, position_003.height = 140.0, 100.0
	    boolean_math_001_1.width, boolean_math_001_1.height = 140.0, 100.0
	    group_input_018.width, group_input_018.height = 140.0, 100.0
	    compare_005_2.width, compare_005_2.height = 140.0, 100.0
	    group_input_019.width, group_input_019.height = 140.0, 100.0
	    delete_geometry_003.width, delete_geometry_003.height = 140.0, 100.0
	    compare_006_1.width, compare_006_1.height = 140.0, 100.0
	    curve_to_mesh_002.width, curve_to_mesh_002.height = 140.0, 100.0
	    geometry_proximity_001_1.width, geometry_proximity_001_1.height = 140.0, 100.0
	    group_004.width, group_004.height = 140.0, 100.0
	    group_input_020.width, group_input_020.height = 140.0, 100.0
	    sample_curve_001_2.width, sample_curve_001_2.height = 140.0, 100.0
	    vector_math_001_6.width, vector_math_001_6.height = 140.0, 100.0
	    vector_math_002_5.width, vector_math_002_5.height = 140.0, 100.0
	    vector_math_004_5.width, vector_math_004_5.height = 140.0, 100.0
	    vector_math_005_3.width, vector_math_005_3.height = 140.0, 100.0
	    vector_math_006_3.width, vector_math_006_3.height = 140.0, 100.0
	    compare_007_1.width, compare_007_1.height = 140.0, 100.0
	    delete_geometry_004.width, delete_geometry_004.height = 140.0, 100.0
	    boolean_math_002_3.width, boolean_math_002_3.height = 140.0, 100.0
	    reroute_030_1.width, reroute_030_1.height = 10.0, 100.0
	    reroute_031.width, reroute_031.height = 10.0, 100.0
	    reroute_032_1.width, reroute_032_1.height = 10.0, 100.0
	    reroute_033.width, reroute_033.height = 10.0, 100.0
	    reroute_034.width, reroute_034.height = 10.0, 100.0
	    reroute_035.width, reroute_035.height = 10.0, 100.0
	    reroute_036.width, reroute_036.height = 10.0, 100.0
	    reroute_037.width, reroute_037.height = 10.0, 100.0
	    reroute_038.width, reroute_038.height = 10.0, 100.0
	    reroute_039.width, reroute_039.height = 10.0, 100.0
	    reroute_040.width, reroute_040.height = 10.0, 100.0
	    reroute_041.width, reroute_041.height = 10.0, 100.0
	    reroute_042.width, reroute_042.height = 10.0, 100.0
	    reroute_043.width, reroute_043.height = 10.0, 100.0
	    frame_005_3.width, frame_005_3.height = 1600.0, 368.0
	    switch_003_6.width, switch_003_6.height = 140.0, 100.0
	    group_input_021.width, group_input_021.height = 140.0, 100.0
	    reroute_044.width, reroute_044.height = 10.0, 100.0
	    join_geometry_004.width, join_geometry_004.height = 140.0, 100.0
	    group_005_1.width, group_005_1.height = 140.0, 100.0
	    group_input_017.width, group_input_017.height = 140.0, 100.0
	    delete_geometry_005.width, delete_geometry_005.height = 140.0, 100.0
	    group_input_022.width, group_input_022.height = 140.0, 100.0
	    compare_009.width, compare_009.height = 140.0, 100.0
	    reroute_026_2.width, reroute_026_2.height = 10.0, 100.0
	    reroute_027_2.width, reroute_027_2.height = 10.0, 100.0
	    reroute_045.width, reroute_045.height = 10.0, 100.0
	    reroute_046.width, reroute_046.height = 10.0, 100.0
	    reroute_048.width, reroute_048.height = 10.0, 100.0
	    reroute_051.width, reroute_051.height = 10.0, 100.0
	    reroute_052.width, reroute_052.height = 10.0, 100.0
	    reroute_053.width, reroute_053.height = 10.0, 100.0
	    frame_006_3.width, frame_006_3.height = 734.0, 546.103271484375
	    switch_004_3.width, switch_004_3.height = 140.0, 100.0
	    capture_attribute_007.width, capture_attribute_007.height = 140.0, 100.0
	    index_005.width, index_005.height = 140.0, 100.0
	    reroute_047.width, reroute_047.height = 10.0, 100.0
	    group_input_023.width, group_input_023.height = 140.0, 100.0
	    reroute_049.width, reroute_049.height = 10.0, 100.0
	    switch_002_5.width, switch_002_5.height = 140.0, 100.0
	    compare_008.width, compare_008.height = 140.0, 100.0
	    group_input_024.width, group_input_024.height = 140.0, 100.0
	    reroute_050.width, reroute_050.height = 10.0, 100.0
	    reroute_054.width, reroute_054.height = 10.0, 100.0
	    reroute_055.width, reroute_055.height = 10.0, 100.0
	    reroute_056.width, reroute_056.height = 10.0, 100.0
	    reroute_057.width, reroute_057.height = 10.0, 100.0
	    group_006_1.width, group_006_1.height = 140.0, 100.0
	    named_attribute_3.width, named_attribute_3.height = 140.0, 100.0
	    group_input_025.width, group_input_025.height = 140.0, 100.0
	    frame_007_3.width, frame_007_3.height = 368.0, 354.0
	    final_bake.width, final_bake.height = 140.0, 100.0
	    separate_components_3.width, separate_components_3.height = 140.0, 100.0
	    join_geometry_001_3.width, join_geometry_001_3.height = 140.0, 100.0
	    reroute_058.width, reroute_058.height = 10.0, 100.0
	    reroute_059.width, reroute_059.height = 10.0, 100.0
	    reroute_060.width, reroute_060.height = 10.0, 100.0
	    reroute_061.width, reroute_061.height = 10.0, 100.0
	    reroute_062.width, reroute_062.height = 10.0, 100.0
	    reroute_063.width, reroute_063.height = 10.0, 100.0
	    reroute_064.width, reroute_064.height = 10.0, 100.0
	    reroute_065.width, reroute_065.height = 10.0, 100.0
	    reroute_066.width, reroute_066.height = 10.0, 100.0
	    reroute_067.width, reroute_067.height = 10.0, 100.0
	
	    #initialize baby_hairs links
	    #final_bake.Geometry -> group_output_10.Geometry
	    baby_hairs.links.new(final_bake.outputs[0], group_output_10.inputs[0])
	    #reroute_055.Output -> group_001_5.Geometry
	    baby_hairs.links.new(reroute_055.outputs[0], group_001_5.inputs[0])
	    #group_input_7.Control Points -> resample_curve.Count
	    baby_hairs.links.new(group_input_7.outputs[7], resample_curve.inputs[2])
	    #group_input_001_5.Duplicate Amount -> group_6.Amount
	    baby_hairs.links.new(group_input_001_5.outputs[9], group_6.inputs[1])
	    #group_input_001_5.Duplicate Viewport Amount -> group_6.Viewport Amount
	    baby_hairs.links.new(group_input_001_5.outputs[10], group_6.inputs[2])
	    #group_input_001_5.Duplicate Radius -> group_6.Radius
	    baby_hairs.links.new(group_input_001_5.outputs[11], group_6.inputs[3])
	    #group_input_001_5.Duplicate Distribution Shape -> group_6.Distribution Shape
	    baby_hairs.links.new(group_input_001_5.outputs[12], group_6.inputs[4])
	    #group_input_001_5.Duplicate Tip Roundness -> group_6.Tip Roundness
	    baby_hairs.links.new(group_input_001_5.outputs[13], group_6.inputs[5])
	    #group_input_001_5.Duplicate Even Thickness -> group_6.Even Thickness
	    baby_hairs.links.new(group_input_001_5.outputs[14], group_6.inputs[6])
	    #group_input_001_5.Duplicate Seed -> group_6.Seed
	    baby_hairs.links.new(group_input_001_5.outputs[15], group_6.inputs[7])
	    #group_input_002_4.Clump Guide Distance -> group_001_5.Guide Distance
	    baby_hairs.links.new(group_input_002_4.outputs[16], group_001_5.inputs[2])
	    #group_input_002_4.Clump Factor -> group_001_5.Factor
	    baby_hairs.links.new(group_input_002_4.outputs[17], group_001_5.inputs[5])
	    #group_input_002_4.Clump Shape -> group_001_5.Shape
	    baby_hairs.links.new(group_input_002_4.outputs[18], group_001_5.inputs[6])
	    #group_input_002_4.Clump Tip Spread -> group_001_5.Tip Spread
	    baby_hairs.links.new(group_input_002_4.outputs[19], group_001_5.inputs[7])
	    #group_input_002_4.Clump Offset -> group_001_5.Clump Offset
	    baby_hairs.links.new(group_input_002_4.outputs[20], group_001_5.inputs[8])
	    #group_input_002_4.Clump Distance Falloff -> group_001_5.Distance Falloff
	    baby_hairs.links.new(group_input_002_4.outputs[21], group_001_5.inputs[9])
	    #group_input_002_4.Clump Distance Threshold -> group_001_5.Distance Threshold
	    baby_hairs.links.new(group_input_002_4.outputs[22], group_001_5.inputs[10])
	    #group_input_002_4.Clump Seed -> group_001_5.Seed
	    baby_hairs.links.new(group_input_002_4.outputs[23], group_001_5.inputs[11])
	    #group_input_002_4.Preserve Length -> group_001_5.Preserve Length
	    baby_hairs.links.new(group_input_002_4.outputs[24], group_001_5.inputs[12])
	    #group_input_003_5.Surface -> group_002_1.Surface
	    baby_hairs.links.new(group_input_003_5.outputs[1], group_002_1.inputs[1])
	    #group_input_003_5.Surface Offset -> group_002_1.Offset
	    baby_hairs.links.new(group_input_003_5.outputs[2], group_002_1.inputs[2])
	    #reroute_056.Output -> group_001_5.Guide Index
	    baby_hairs.links.new(reroute_056.outputs[0], group_001_5.inputs[1])
	    #switch_001_7.Output -> set_material.Geometry
	    baby_hairs.links.new(switch_001_7.outputs[0], set_material.inputs[0])
	    #group_input_005_4.Material -> set_material.Material
	    baby_hairs.links.new(group_input_005_4.outputs[6], set_material.inputs[2])
	    #reroute_7.Output -> switch_6.False
	    baby_hairs.links.new(reroute_7.outputs[0], switch_6.inputs[1])
	    #reroute_001_7.Output -> capture_attribute_5.Geometry
	    baby_hairs.links.new(reroute_001_7.outputs[0], capture_attribute_5.inputs[0])
	    #position_4.Position -> capture_attribute_5.Position
	    baby_hairs.links.new(position_4.outputs[0], capture_attribute_5.inputs[1])
	    #capture_attribute_5.Position -> vector_math_6.Vector
	    baby_hairs.links.new(capture_attribute_5.outputs[1], vector_math_6.inputs[0])
	    #capture_attribute_5.Geometry -> set_position_5.Geometry
	    baby_hairs.links.new(capture_attribute_5.outputs[0], set_position_5.inputs[0])
	    #vector_math_6.Vector -> set_position_5.Position
	    baby_hairs.links.new(vector_math_6.outputs[0], set_position_5.inputs[2])
	    #reroute_004_6.Output -> join_geometry_2.Geometry
	    baby_hairs.links.new(reroute_004_6.outputs[0], join_geometry_2.inputs[0])
	    #join_geometry_2.Geometry -> switch_6.True
	    baby_hairs.links.new(join_geometry_2.outputs[0], switch_6.inputs[2])
	    #group_input_006_4.Mirror X -> switch_6.Switch
	    baby_hairs.links.new(group_input_006_4.outputs[3], switch_6.inputs[0])
	    #set_material.Geometry -> reroute_7.Input
	    baby_hairs.links.new(set_material.outputs[0], reroute_7.inputs[0])
	    #reroute_003_5.Output -> reroute_001_7.Input
	    baby_hairs.links.new(reroute_003_5.outputs[0], reroute_001_7.inputs[0])
	    #set_position_5.Geometry -> reroute_002_5.Input
	    baby_hairs.links.new(set_position_5.outputs[0], reroute_002_5.inputs[0])
	    #reroute_005_5.Output -> reroute_003_5.Input
	    baby_hairs.links.new(reroute_005_5.outputs[0], reroute_003_5.inputs[0])
	    #reroute_002_5.Output -> reroute_004_6.Input
	    baby_hairs.links.new(reroute_002_5.outputs[0], reroute_004_6.inputs[0])
	    #reroute_7.Output -> reroute_005_5.Input
	    baby_hairs.links.new(reroute_7.outputs[0], reroute_005_5.inputs[0])
	    #reroute_009_5.Output -> resample_curve_001.Curve
	    baby_hairs.links.new(reroute_009_5.outputs[0], resample_curve_001.inputs[0])
	    #group_input_007_4.Control Points -> resample_curve_002.Count
	    baby_hairs.links.new(group_input_007_4.outputs[7], resample_curve_002.inputs[2])
	    #group_input_008_3.Control Points -> math_5.Value
	    baby_hairs.links.new(group_input_008_3.outputs[7], math_5.inputs[0])
	    #math_5.Value -> resample_curve_001.Count
	    baby_hairs.links.new(math_5.outputs[0], resample_curve_001.inputs[2])
	    #resample_curve_001.Curve -> curve_to_mesh.Curve
	    baby_hairs.links.new(resample_curve_001.outputs[0], curve_to_mesh.inputs[0])
	    #delete_geometry.Geometry -> mesh_to_curve.Mesh
	    baby_hairs.links.new(delete_geometry.outputs[0], mesh_to_curve.inputs[0])
	    #mesh_to_curve.Curve -> resample_curve_002.Curve
	    baby_hairs.links.new(mesh_to_curve.outputs[0], resample_curve_002.inputs[0])
	    #curve_to_mesh.Mesh -> capture_attribute_001_4.Geometry
	    baby_hairs.links.new(curve_to_mesh.outputs[0], capture_attribute_001_4.inputs[0])
	    #index_3.Index -> capture_attribute_001_4.Index
	    baby_hairs.links.new(index_3.outputs[0], capture_attribute_001_4.inputs[1])
	    #position_001_3.Position -> capture_attribute_001_4.Position
	    baby_hairs.links.new(position_001_3.outputs[0], capture_attribute_001_4.inputs[2])
	    #object_info_1.Geometry -> curve_to_points_1.Curve
	    baby_hairs.links.new(object_info_1.outputs[4], curve_to_points_1.inputs[0])
	    #curve_to_points_1.Points -> geometry_proximity_1.Geometry
	    baby_hairs.links.new(curve_to_points_1.outputs[0], geometry_proximity_1.inputs[0])
	    #capture_attribute_001_4.Position -> geometry_proximity_1.Sample Position
	    baby_hairs.links.new(capture_attribute_001_4.outputs[2], geometry_proximity_1.inputs[2])
	    #geometry_proximity_1.Distance -> compare_5.A
	    baby_hairs.links.new(geometry_proximity_1.outputs[1], compare_5.inputs[0])
	    #compare_5.Result -> boolean_math_5.Boolean
	    baby_hairs.links.new(compare_5.outputs[0], boolean_math_5.inputs[1])
	    #compare_001_4.Result -> boolean_math_5.Boolean
	    baby_hairs.links.new(compare_001_4.outputs[0], boolean_math_5.inputs[0])
	    #capture_attribute_001_4.Index -> math_001_3.Value
	    baby_hairs.links.new(capture_attribute_001_4.outputs[1], math_001_3.inputs[0])
	    #math_001_3.Value -> compare_001_4.A
	    baby_hairs.links.new(math_001_3.outputs[0], compare_001_4.inputs[2])
	    #math_5.Value -> math_001_3.Value
	    baby_hairs.links.new(math_5.outputs[0], math_001_3.inputs[1])
	    #capture_attribute_001_4.Geometry -> delete_geometry.Geometry
	    baby_hairs.links.new(capture_attribute_001_4.outputs[0], delete_geometry.inputs[0])
	    #boolean_math_5.Boolean -> delete_geometry.Selection
	    baby_hairs.links.new(boolean_math_5.outputs[0], delete_geometry.inputs[1])
	    #group_input_009_3.Scalp Hairs -> object_info_1.Object
	    baby_hairs.links.new(group_input_009_3.outputs[4], object_info_1.inputs[0])
	    #group_input_010_2.Trim distance -> compare_5.B
	    baby_hairs.links.new(group_input_010_2.outputs[5], compare_5.inputs[1])
	    #reroute_008_5.Output -> reroute_006_5.Input
	    baby_hairs.links.new(reroute_008_5.outputs[0], reroute_006_5.inputs[0])
	    #reroute_010_4.Output -> reroute_007_5.Input
	    baby_hairs.links.new(reroute_010_4.outputs[0], reroute_007_5.inputs[0])
	    #resample_curve_002.Curve -> reroute_008_5.Input
	    baby_hairs.links.new(resample_curve_002.outputs[0], reroute_008_5.inputs[0])
	    #reroute_007_5.Output -> reroute_009_5.Input
	    baby_hairs.links.new(reroute_007_5.outputs[0], reroute_009_5.inputs[0])
	    #reroute_010_4.Output -> switch_001_7.True
	    baby_hairs.links.new(reroute_010_4.outputs[0], switch_001_7.inputs[2])
	    #reroute_011_5.Output -> switch_001_7.False
	    baby_hairs.links.new(reroute_011_5.outputs[0], switch_001_7.inputs[1])
	    #group_input_011_1.Trim distance -> compare_002_4.A
	    baby_hairs.links.new(group_input_011_1.outputs[5], compare_002_4.inputs[0])
	    #compare_002_4.Result -> switch_001_7.Switch
	    baby_hairs.links.new(compare_002_4.outputs[0], switch_001_7.inputs[0])
	    #reroute_006_5.Output -> reroute_011_5.Input
	    baby_hairs.links.new(reroute_006_5.outputs[0], reroute_011_5.inputs[0])
	    #spline_parameter_001_1.Index -> sample_curve_1.Curve Index
	    baby_hairs.links.new(spline_parameter_001_1.outputs[2], sample_curve_1.inputs[4])
	    #spline_parameter_001_1.Factor -> sample_curve_1.Factor
	    baby_hairs.links.new(spline_parameter_001_1.outputs[0], sample_curve_1.inputs[2])
	    #reroute_012_6.Output -> resample_curve_003.Curve
	    baby_hairs.links.new(reroute_012_6.outputs[0], resample_curve_003.inputs[0])
	    #reverse_curve.Curve -> curve_to_points_001_1.Curve
	    baby_hairs.links.new(reverse_curve.outputs[0], curve_to_points_001_1.inputs[0])
	    #delete_geometry_002_1.Geometry -> instance_on_points.Points
	    baby_hairs.links.new(delete_geometry_002_1.outputs[0], instance_on_points.inputs[0])
	    #delete_geometry_001.Geometry -> instance_on_points.Instance
	    baby_hairs.links.new(delete_geometry_001.outputs[0], instance_on_points.inputs[2])
	    #instance_on_points.Instances -> set_position_002_2.Geometry
	    baby_hairs.links.new(instance_on_points.outputs[0], set_position_002_2.inputs[0])
	    #curve_to_points_001_1.Points -> capture_attribute_002_4.Geometry
	    baby_hairs.links.new(curve_to_points_001_1.outputs[0], capture_attribute_002_4.inputs[0])
	    #position_002_4.Position -> capture_attribute_002_4.Position
	    baby_hairs.links.new(position_002_4.outputs[0], capture_attribute_002_4.inputs[1])
	    #reroute_024_2.Output -> vector_math_003_5.Vector
	    baby_hairs.links.new(reroute_024_2.outputs[0], vector_math_003_5.inputs[0])
	    #sample_curve_1.Position -> vector_math_003_5.Vector
	    baby_hairs.links.new(sample_curve_1.outputs[1], vector_math_003_5.inputs[1])
	    #vector_math_003_5.Vector -> set_position_002_2.Position
	    baby_hairs.links.new(vector_math_003_5.outputs[0], set_position_002_2.inputs[2])
	    #set_position_002_2.Geometry -> realize_instances.Geometry
	    baby_hairs.links.new(set_position_002_2.outputs[0], realize_instances.inputs[0])
	    #reroute_017_5.Output -> delete_geometry_001.Geometry
	    baby_hairs.links.new(reroute_017_5.outputs[0], delete_geometry_001.inputs[0])
	    #index_001_3.Index -> compare_003_3.A
	    baby_hairs.links.new(index_001_3.outputs[0], compare_003_3.inputs[2])
	    #reroute_022_2.Output -> delete_geometry_001.Selection
	    baby_hairs.links.new(reroute_022_2.outputs[0], delete_geometry_001.inputs[1])
	    #index_002_2.Index -> capture_attribute_002_4.Index
	    baby_hairs.links.new(index_002_2.outputs[0], capture_attribute_002_4.inputs[2])
	    #reroute_018_5.Output -> compare_004_4.A
	    baby_hairs.links.new(reroute_018_5.outputs[0], compare_004_4.inputs[2])
	    #capture_attribute_002_4.Geometry -> delete_geometry_002_1.Geometry
	    baby_hairs.links.new(capture_attribute_002_4.outputs[0], delete_geometry_002_1.inputs[0])
	    #reroute_020_4.Output -> delete_geometry_002_1.Selection
	    baby_hairs.links.new(reroute_020_4.outputs[0], delete_geometry_002_1.inputs[1])
	    #resample_curve_003.Curve -> reverse_curve.Curve
	    baby_hairs.links.new(resample_curve_003.outputs[0], reverse_curve.inputs[0])
	    #group_003_2.Geometry -> join_geometry_003.Geometry
	    baby_hairs.links.new(group_003_2.outputs[0], join_geometry_003.inputs[0])
	    #spline_parameter_002.Factor -> baby_hairs_shape.Value
	    baby_hairs.links.new(spline_parameter_002.outputs[0], baby_hairs_shape.inputs[1])
	    #group_input_014.Hair Radius -> math_003_3.Value
	    baby_hairs.links.new(group_input_014.outputs[8], math_003_3.inputs[1])
	    #baby_hairs_shape.Value -> math_003_3.Value
	    baby_hairs.links.new(baby_hairs_shape.outputs[0], math_003_3.inputs[0])
	    #math_003_3.Value -> set_curve_radius_001.Radius
	    baby_hairs.links.new(math_003_3.outputs[0], set_curve_radius_001.inputs[2])
	    #reroute_013_5.Output -> reroute_012_6.Input
	    baby_hairs.links.new(reroute_013_5.outputs[0], reroute_012_6.inputs[0])
	    #resample_curve.Curve -> reroute_013_5.Input
	    baby_hairs.links.new(resample_curve.outputs[0], reroute_013_5.inputs[0])
	    #reroute_013_5.Output -> set_curve_radius_001.Curve
	    baby_hairs.links.new(reroute_013_5.outputs[0], set_curve_radius_001.inputs[0])
	    #set_curve_radius_001.Curve -> group_6.Geometry
	    baby_hairs.links.new(set_curve_radius_001.outputs[0], group_6.inputs[0])
	    #group_input_004_4.Extra Hairs Count -> curve_to_points_001_1.Count
	    baby_hairs.links.new(group_input_004_4.outputs[26], curve_to_points_001_1.inputs[1])
	    #group_input_012_1.Extra Hairs Samples -> compare_004_4.B
	    baby_hairs.links.new(group_input_012_1.outputs[27], compare_004_4.inputs[3])
	    #group_input_013_1.Extra Hairs Trim -> compare_003_3.B
	    baby_hairs.links.new(group_input_013_1.outputs[28], compare_003_3.inputs[3])
	    #reroute_012_6.Output -> reroute_014_5.Input
	    baby_hairs.links.new(reroute_012_6.outputs[0], reroute_014_5.inputs[0])
	    #reroute_015_5.Output -> sample_curve_1.Curves
	    baby_hairs.links.new(reroute_015_5.outputs[0], sample_curve_1.inputs[0])
	    #reroute_014_5.Output -> reroute_015_5.Input
	    baby_hairs.links.new(reroute_014_5.outputs[0], reroute_015_5.inputs[0])
	    #spline_parameter_003.Factor -> extra_hairs_shape.Value
	    baby_hairs.links.new(spline_parameter_003.outputs[0], extra_hairs_shape.inputs[1])
	    #extra_hairs_shape.Value -> math_004_1.Value
	    baby_hairs.links.new(extra_hairs_shape.outputs[0], math_004_1.inputs[0])
	    #math_004_1.Value -> set_curve_radius_002.Radius
	    baby_hairs.links.new(math_004_1.outputs[0], set_curve_radius_002.inputs[2])
	    #realize_instances.Geometry -> set_curve_radius_002.Curve
	    baby_hairs.links.new(realize_instances.outputs[0], set_curve_radius_002.inputs[0])
	    #reroute_029_1.Output -> group_003_2.Geometry
	    baby_hairs.links.new(reroute_029_1.outputs[0], group_003_2.inputs[0])
	    #reroute_014_5.Output -> reroute_016_5.Input
	    baby_hairs.links.new(reroute_014_5.outputs[0], reroute_016_5.inputs[0])
	    #reroute_016_5.Output -> reroute_017_5.Input
	    baby_hairs.links.new(reroute_016_5.outputs[0], reroute_017_5.inputs[0])
	    #reroute_019_4.Output -> reroute_018_5.Input
	    baby_hairs.links.new(reroute_019_4.outputs[0], reroute_018_5.inputs[0])
	    #capture_attribute_002_4.Index -> reroute_019_4.Input
	    baby_hairs.links.new(capture_attribute_002_4.outputs[2], reroute_019_4.inputs[0])
	    #compare_004_4.Result -> reroute_020_4.Input
	    baby_hairs.links.new(compare_004_4.outputs[0], reroute_020_4.inputs[0])
	    #compare_003_3.Result -> reroute_021_2.Input
	    baby_hairs.links.new(compare_003_3.outputs[0], reroute_021_2.inputs[0])
	    #reroute_021_2.Output -> reroute_022_2.Input
	    baby_hairs.links.new(reroute_021_2.outputs[0], reroute_022_2.inputs[0])
	    #capture_attribute_002_4.Position -> reroute_023_2.Input
	    baby_hairs.links.new(capture_attribute_002_4.outputs[1], reroute_023_2.inputs[0])
	    #reroute_023_2.Output -> reroute_024_2.Input
	    baby_hairs.links.new(reroute_023_2.outputs[0], reroute_024_2.inputs[0])
	    #group_input_015.Hair Radius -> math_005_1.Value
	    baby_hairs.links.new(group_input_015.outputs[8], math_005_1.inputs[0])
	    #math_005_1.Value -> math_004_1.Value
	    baby_hairs.links.new(math_005_1.outputs[0], math_004_1.inputs[1])
	    #reroute_048.Output -> group_002_1.Geometry
	    baby_hairs.links.new(reroute_048.outputs[0], group_002_1.inputs[0])
	    #set_curve_radius_002.Curve -> reroute_029_1.Input
	    baby_hairs.links.new(set_curve_radius_002.outputs[0], reroute_029_1.inputs[0])
	    #group_input_016.Extra Hairs Duplicate Count -> group_003_2.Amount
	    baby_hairs.links.new(group_input_016.outputs[29], group_003_2.inputs[1])
	    #index_003.Index -> capture_attribute_003_1.Index
	    baby_hairs.links.new(index_003.outputs[0], capture_attribute_003_1.inputs[1])
	    #reroute_034.Output -> capture_attribute_004_1.Geometry
	    baby_hairs.links.new(reroute_034.outputs[0], capture_attribute_004_1.inputs[0])
	    #position_003.Position -> capture_attribute_004_1.Position
	    baby_hairs.links.new(position_003.outputs[0], capture_attribute_004_1.inputs[1])
	    #group_input_018.Duplicate Amount -> compare_005_2.B
	    baby_hairs.links.new(group_input_018.outputs[9], compare_005_2.inputs[3])
	    #reroute_031.Output -> compare_005_2.A
	    baby_hairs.links.new(reroute_031.outputs[0], compare_005_2.inputs[2])
	    #reroute_037.Output -> delete_geometry_003.Geometry
	    baby_hairs.links.new(reroute_037.outputs[0], delete_geometry_003.inputs[0])
	    #reroute_038.Output -> compare_006_1.A
	    baby_hairs.links.new(reroute_038.outputs[0], compare_006_1.inputs[2])
	    #compare_006_1.Result -> delete_geometry_003.Selection
	    baby_hairs.links.new(compare_006_1.outputs[0], delete_geometry_003.inputs[1])
	    #delete_geometry_003.Geometry -> curve_to_mesh_002.Curve
	    baby_hairs.links.new(delete_geometry_003.outputs[0], curve_to_mesh_002.inputs[0])
	    #curve_to_mesh_002.Mesh -> geometry_proximity_001_1.Geometry
	    baby_hairs.links.new(curve_to_mesh_002.outputs[0], geometry_proximity_001_1.inputs[0])
	    #group_input_020.Surface -> group_004.Surface
	    baby_hairs.links.new(group_input_020.outputs[1], group_004.inputs[1])
	    #group_004.Geometry -> capture_attribute_003_1.Geometry
	    baby_hairs.links.new(group_004.outputs[0], capture_attribute_003_1.inputs[0])
	    #reroute_030_1.Output -> group_004.Geometry
	    baby_hairs.links.new(reroute_030_1.outputs[0], group_004.inputs[0])
	    #reroute_035.Output -> sample_curve_001_2.Curves
	    baby_hairs.links.new(reroute_035.outputs[0], sample_curve_001_2.inputs[0])
	    #reroute_031.Output -> sample_curve_001_2.Curve Index
	    baby_hairs.links.new(reroute_031.outputs[0], sample_curve_001_2.inputs[4])
	    #reroute_042.Output -> vector_math_001_6.Vector
	    baby_hairs.links.new(reroute_042.outputs[0], vector_math_001_6.inputs[0])
	    #sample_curve_001_2.Position -> vector_math_001_6.Vector
	    baby_hairs.links.new(sample_curve_001_2.outputs[1], vector_math_001_6.inputs[1])
	    #reroute_039.Output -> vector_math_002_5.Vector
	    baby_hairs.links.new(reroute_039.outputs[0], vector_math_002_5.inputs[1])
	    #vector_math_001_6.Vector -> vector_math_004_5.Vector
	    baby_hairs.links.new(vector_math_001_6.outputs[0], vector_math_004_5.inputs[0])
	    #vector_math_002_5.Vector -> vector_math_005_3.Vector
	    baby_hairs.links.new(vector_math_002_5.outputs[0], vector_math_005_3.inputs[0])
	    #vector_math_004_5.Vector -> vector_math_006_3.Vector
	    baby_hairs.links.new(vector_math_004_5.outputs[0], vector_math_006_3.inputs[0])
	    #vector_math_005_3.Vector -> vector_math_006_3.Vector
	    baby_hairs.links.new(vector_math_005_3.outputs[0], vector_math_006_3.inputs[1])
	    #vector_math_006_3.Value -> compare_007_1.A
	    baby_hairs.links.new(vector_math_006_3.outputs[1], compare_007_1.inputs[0])
	    #boolean_math_001_1.Boolean -> boolean_math_002_3.Boolean
	    baby_hairs.links.new(boolean_math_001_1.outputs[0], boolean_math_002_3.inputs[0])
	    #compare_007_1.Result -> boolean_math_002_3.Boolean
	    baby_hairs.links.new(compare_007_1.outputs[0], boolean_math_002_3.inputs[1])
	    #boolean_math_002_3.Boolean -> delete_geometry_004.Selection
	    baby_hairs.links.new(boolean_math_002_3.outputs[0], delete_geometry_004.inputs[1])
	    #reroute_032_1.Output -> reroute_028_2.Input
	    baby_hairs.links.new(reroute_032_1.outputs[0], reroute_028_2.inputs[0])
	    #reroute_030_1.Output -> delete_geometry_004.Geometry
	    baby_hairs.links.new(reroute_030_1.outputs[0], delete_geometry_004.inputs[0])
	    #compare_005_2.Result -> boolean_math_001_1.Boolean
	    baby_hairs.links.new(compare_005_2.outputs[0], boolean_math_001_1.inputs[0])
	    #group_input_019.Use Extra Hairs -> boolean_math_001_1.Boolean
	    baby_hairs.links.new(group_input_019.outputs[25], boolean_math_001_1.inputs[1])
	    #join_geometry_003.Geometry -> reroute_030_1.Input
	    baby_hairs.links.new(join_geometry_003.outputs[0], reroute_030_1.inputs[0])
	    #capture_attribute_003_1.Index -> reroute_031.Input
	    baby_hairs.links.new(capture_attribute_003_1.outputs[1], reroute_031.inputs[0])
	    #delete_geometry_004.Geometry -> reroute_032_1.Input
	    baby_hairs.links.new(delete_geometry_004.outputs[0], reroute_032_1.inputs[0])
	    #capture_attribute_003_1.Geometry -> reroute_033.Input
	    baby_hairs.links.new(capture_attribute_003_1.outputs[0], reroute_033.inputs[0])
	    #reroute_033.Output -> reroute_034.Input
	    baby_hairs.links.new(reroute_033.outputs[0], reroute_034.inputs[0])
	    #capture_attribute_004_1.Geometry -> reroute_035.Input
	    baby_hairs.links.new(capture_attribute_004_1.outputs[0], reroute_035.inputs[0])
	    #capture_attribute_004_1.Position -> reroute_036.Input
	    baby_hairs.links.new(capture_attribute_004_1.outputs[1], reroute_036.inputs[0])
	    #reroute_035.Output -> reroute_037.Input
	    baby_hairs.links.new(reroute_035.outputs[0], reroute_037.inputs[0])
	    #reroute_031.Output -> reroute_038.Input
	    baby_hairs.links.new(reroute_031.outputs[0], reroute_038.inputs[0])
	    #reroute_036.Output -> reroute_039.Input
	    baby_hairs.links.new(reroute_036.outputs[0], reroute_039.inputs[0])
	    #reroute_040.Output -> geometry_proximity_001_1.Sample Position
	    baby_hairs.links.new(reroute_040.outputs[0], geometry_proximity_001_1.inputs[2])
	    #reroute_039.Output -> reroute_040.Input
	    baby_hairs.links.new(reroute_039.outputs[0], reroute_040.inputs[0])
	    #geometry_proximity_001_1.Position -> reroute_041.Input
	    baby_hairs.links.new(geometry_proximity_001_1.outputs[0], reroute_041.inputs[0])
	    #reroute_043.Output -> reroute_042.Input
	    baby_hairs.links.new(reroute_043.outputs[0], reroute_042.inputs[0])
	    #reroute_041.Output -> reroute_043.Input
	    baby_hairs.links.new(reroute_041.outputs[0], reroute_043.inputs[0])
	    #reroute_043.Output -> vector_math_002_5.Vector
	    baby_hairs.links.new(reroute_043.outputs[0], vector_math_002_5.inputs[0])
	    #group_input_021.Use Extra Hairs -> switch_003_6.Switch
	    baby_hairs.links.new(group_input_021.outputs[25], switch_003_6.inputs[0])
	    #reroute_053.Output -> switch_003_6.False
	    baby_hairs.links.new(reroute_053.outputs[0], switch_003_6.inputs[1])
	    #switch_004_3.Output -> reroute_010_4.Input
	    baby_hairs.links.new(switch_004_3.outputs[0], reroute_010_4.inputs[0])
	    #join_geometry_004.Geometry -> switch_003_6.True
	    baby_hairs.links.new(join_geometry_004.outputs[0], switch_003_6.inputs[2])
	    #group_input_017.Surface -> group_005_1.Surface
	    baby_hairs.links.new(group_input_017.outputs[1], group_005_1.inputs[1])
	    #group_input_017.Offset -> group_005_1.Offset
	    baby_hairs.links.new(group_input_017.outputs[30], group_005_1.inputs[2])
	    #reroute_025_1.Output -> reroute_044.Input
	    baby_hairs.links.new(reroute_025_1.outputs[0], reroute_044.inputs[0])
	    #reroute_045.Output -> delete_geometry_005.Geometry
	    baby_hairs.links.new(reroute_045.outputs[0], delete_geometry_005.inputs[0])
	    #group_input_022.Duplicate Amount -> reroute_026_2.Input
	    baby_hairs.links.new(group_input_022.outputs[9], reroute_026_2.inputs[0])
	    #reroute_026_2.Output -> compare_009.B
	    baby_hairs.links.new(reroute_026_2.outputs[0], compare_009.inputs[3])
	    #reroute_028_2.Output -> reroute_027_2.Input
	    baby_hairs.links.new(reroute_028_2.outputs[0], reroute_027_2.inputs[0])
	    #delete_geometry_005.Geometry -> join_geometry_004.Geometry
	    baby_hairs.links.new(delete_geometry_005.outputs[0], join_geometry_004.inputs[0])
	    #reroute_046.Output -> reroute_045.Input
	    baby_hairs.links.new(reroute_046.outputs[0], reroute_045.inputs[0])
	    #group_005_1.Geometry -> reroute_046.Input
	    baby_hairs.links.new(group_005_1.outputs[0], reroute_046.inputs[0])
	    #reroute_051.Output -> delete_geometry_005.Selection
	    baby_hairs.links.new(reroute_051.outputs[0], delete_geometry_005.inputs[1])
	    #reroute_044.Output -> reroute_048.Input
	    baby_hairs.links.new(reroute_044.outputs[0], reroute_048.inputs[0])
	    #reroute_052.Output -> reroute_051.Input
	    baby_hairs.links.new(reroute_052.outputs[0], reroute_051.inputs[0])
	    #compare_009.Result -> reroute_052.Input
	    baby_hairs.links.new(compare_009.outputs[0], reroute_052.inputs[0])
	    #group_002_1.Geometry -> reroute_053.Input
	    baby_hairs.links.new(group_002_1.outputs[0], reroute_053.inputs[0])
	    #switch_003_6.Output -> switch_004_3.False
	    baby_hairs.links.new(switch_003_6.outputs[0], switch_004_3.inputs[1])
	    #reroute_049.Output -> switch_004_3.True
	    baby_hairs.links.new(reroute_049.outputs[0], switch_004_3.inputs[2])
	    #index_005.Index -> capture_attribute_007.Index
	    baby_hairs.links.new(index_005.outputs[0], capture_attribute_007.inputs[1])
	    #reroute_027_2.Output -> capture_attribute_007.Geometry
	    baby_hairs.links.new(reroute_027_2.outputs[0], capture_attribute_007.inputs[0])
	    #capture_attribute_007.Geometry -> group_005_1.Geometry
	    baby_hairs.links.new(capture_attribute_007.outputs[0], group_005_1.inputs[0])
	    #capture_attribute_007.Index -> compare_009.A
	    baby_hairs.links.new(capture_attribute_007.outputs[1], compare_009.inputs[2])
	    #reroute_053.Output -> reroute_047.Input
	    baby_hairs.links.new(reroute_053.outputs[0], reroute_047.inputs[0])
	    #group_input_023.Extra Hairs Only -> switch_004_3.Switch
	    baby_hairs.links.new(group_input_023.outputs[31], switch_004_3.inputs[0])
	    #delete_geometry_005.Geometry -> reroute_049.Input
	    baby_hairs.links.new(delete_geometry_005.outputs[0], reroute_049.inputs[0])
	    #group_input_024.Clump Factor -> compare_008.A
	    baby_hairs.links.new(group_input_024.outputs[17], compare_008.inputs[0])
	    #compare_008.Result -> switch_002_5.Switch
	    baby_hairs.links.new(compare_008.outputs[0], switch_002_5.inputs[0])
	    #reroute_054.Output -> switch_002_5.True
	    baby_hairs.links.new(reroute_054.outputs[0], switch_002_5.inputs[2])
	    #reroute_057.Output -> switch_002_5.False
	    baby_hairs.links.new(reroute_057.outputs[0], switch_002_5.inputs[1])
	    #switch_002_5.Output -> reroute_025_1.Input
	    baby_hairs.links.new(switch_002_5.outputs[0], reroute_025_1.inputs[0])
	    #group_6.Guide Index -> reroute_050.Input
	    baby_hairs.links.new(group_6.outputs[1], reroute_050.inputs[0])
	    #group_6.Geometry -> reroute_054.Input
	    baby_hairs.links.new(group_6.outputs[0], reroute_054.inputs[0])
	    #reroute_054.Output -> reroute_055.Input
	    baby_hairs.links.new(reroute_054.outputs[0], reroute_055.inputs[0])
	    #reroute_050.Output -> reroute_056.Input
	    baby_hairs.links.new(reroute_050.outputs[0], reroute_056.inputs[0])
	    #group_001_5.Geometry -> reroute_057.Input
	    baby_hairs.links.new(group_001_5.outputs[0], reroute_057.inputs[0])
	    #switch_6.Output -> group_006_1.Geometry
	    baby_hairs.links.new(switch_6.outputs[0], group_006_1.inputs[0])
	    #group_input_025.Surface -> group_006_1.Surface
	    baby_hairs.links.new(group_input_025.outputs[1], group_006_1.inputs[2])
	    #named_attribute_3.Attribute -> group_006_1.Surface UV Map
	    baby_hairs.links.new(named_attribute_3.outputs[0], group_006_1.inputs[3])
	    #group_input_7.Geometry -> separate_components_3.Geometry
	    baby_hairs.links.new(group_input_7.outputs[0], separate_components_3.inputs[0])
	    #separate_components_3.Curve -> resample_curve.Curve
	    baby_hairs.links.new(separate_components_3.outputs[1], resample_curve.inputs[0])
	    #reroute_066.Output -> join_geometry_001_3.Geometry
	    baby_hairs.links.new(reroute_066.outputs[0], join_geometry_001_3.inputs[0])
	    #separate_components_3.Mesh -> reroute_058.Input
	    baby_hairs.links.new(separate_components_3.outputs[0], reroute_058.inputs[0])
	    #separate_components_3.Instances -> reroute_059.Input
	    baby_hairs.links.new(separate_components_3.outputs[5], reroute_059.inputs[0])
	    #separate_components_3.Volume -> reroute_060.Input
	    baby_hairs.links.new(separate_components_3.outputs[4], reroute_060.inputs[0])
	    #separate_components_3.Point Cloud -> reroute_061.Input
	    baby_hairs.links.new(separate_components_3.outputs[3], reroute_061.inputs[0])
	    #separate_components_3.Grease Pencil -> reroute_062.Input
	    baby_hairs.links.new(separate_components_3.outputs[2], reroute_062.inputs[0])
	    #reroute_058.Output -> reroute_063.Input
	    baby_hairs.links.new(reroute_058.outputs[0], reroute_063.inputs[0])
	    #reroute_060.Output -> reroute_064.Input
	    baby_hairs.links.new(reroute_060.outputs[0], reroute_064.inputs[0])
	    #reroute_061.Output -> reroute_065.Input
	    baby_hairs.links.new(reroute_061.outputs[0], reroute_065.inputs[0])
	    #reroute_059.Output -> reroute_066.Input
	    baby_hairs.links.new(reroute_059.outputs[0], reroute_066.inputs[0])
	    #reroute_062.Output -> reroute_067.Input
	    baby_hairs.links.new(reroute_062.outputs[0], reroute_067.inputs[0])
	    #join_geometry_001_3.Geometry -> final_bake.Geometry
	    baby_hairs.links.new(join_geometry_001_3.outputs[0], final_bake.inputs[0])
	    #reroute_005_5.Output -> join_geometry_2.Geometry
	    baby_hairs.links.new(reroute_005_5.outputs[0], join_geometry_2.inputs[0])
	    #reroute_025_1.Output -> join_geometry_003.Geometry
	    baby_hairs.links.new(reroute_025_1.outputs[0], join_geometry_003.inputs[0])
	    #reroute_047.Output -> join_geometry_004.Geometry
	    baby_hairs.links.new(reroute_047.outputs[0], join_geometry_004.inputs[0])
	    #reroute_064.Output -> join_geometry_001_3.Geometry
	    baby_hairs.links.new(reroute_064.outputs[0], join_geometry_001_3.inputs[0])
	    #reroute_065.Output -> join_geometry_001_3.Geometry
	    baby_hairs.links.new(reroute_065.outputs[0], join_geometry_001_3.inputs[0])
	    #reroute_067.Output -> join_geometry_001_3.Geometry
	    baby_hairs.links.new(reroute_067.outputs[0], join_geometry_001_3.inputs[0])
	    #reroute_063.Output -> join_geometry_001_3.Geometry
	    baby_hairs.links.new(reroute_063.outputs[0], join_geometry_001_3.inputs[0])
	    #group_006_1.Geometry -> join_geometry_001_3.Geometry
	    baby_hairs.links.new(group_006_1.outputs[0], join_geometry_001_3.inputs[0])
	    return baby_hairs
	return baby_hairs_node_group()

	

	
