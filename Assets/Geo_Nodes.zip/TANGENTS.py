import bpy, mathutils

def node():
	#initialize tangents node group
	def tangents_node_group():
	    tangents = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "TANGENTS")
	
	    tangents.color_tag = 'NONE'
	    tangents.description = "Add tangents atrribute to curve."
	    tangents.default_group_node_width = 140
	    
	
	    tangents.is_modifier = True
	
	    #tangents interface
	    #Socket Geometry
	    geometry_socket = tangents.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket.attribute_domain = 'POINT'
	
	    #Socket Geometry
	    geometry_socket_1 = tangents.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_1.attribute_domain = 'POINT'
	
	
	    #initialize tangents nodes
	    #node Group Input
	    group_input = tangents.nodes.new("NodeGroupInput")
	    group_input.name = "Group Input"
	
	    #node Group Output
	    group_output = tangents.nodes.new("NodeGroupOutput")
	    group_output.name = "Group Output"
	    group_output.is_active_output = True
	
	    #node Store Named Attribute
	    store_named_attribute = tangents.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute.name = "Store Named Attribute"
	    store_named_attribute.data_type = 'FLOAT_VECTOR'
	    store_named_attribute.domain = 'POINT'
	    #Selection
	    store_named_attribute.inputs[1].default_value = True
	    #Name
	    store_named_attribute.inputs[2].default_value = "tangents"
	
	    #node Curve Tangent
	    curve_tangent = tangents.nodes.new("GeometryNodeInputTangent")
	    curve_tangent.name = "Curve Tangent"
	
	
	
	
	
	    #Set locations
	    group_input.location = (-340.0, 0.0)
	    group_output.location = (200.0, 0.0)
	    store_named_attribute.location = (5.626739501953125, 21.030473709106445)
	    curve_tangent.location = (-337.27496337890625, -82.31363677978516)
	
	    #Set dimensions
	    group_input.width, group_input.height = 140.0, 100.0
	    group_output.width, group_output.height = 140.0, 100.0
	    store_named_attribute.width, store_named_attribute.height = 140.0, 100.0
	    curve_tangent.width, curve_tangent.height = 140.0, 100.0
	
	    #initialize tangents links
	    #store_named_attribute.Geometry -> group_output.Geometry
	    tangents.links.new(store_named_attribute.outputs[0], group_output.inputs[0])
	    #group_input.Geometry -> store_named_attribute.Geometry
	    tangents.links.new(group_input.outputs[0], store_named_attribute.inputs[0])
	    #curve_tangent.Tangent -> store_named_attribute.Value
	    tangents.links.new(curve_tangent.outputs[0], store_named_attribute.inputs[3])
	    return tangents
	return tangents_node_group()

	

	
