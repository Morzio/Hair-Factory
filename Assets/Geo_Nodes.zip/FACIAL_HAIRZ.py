import bpy, mathutils

def node():
	#initialize curve_root_006 node group
	def curve_root_006_node_group():
	    curve_root_006 = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Curve Root.006")
	
	    curve_root_006.color_tag = 'NONE'
	    curve_root_006.description = "Reads information about each curve's root point"
	    curve_root_006.default_group_node_width = 140
	    
	
	
	    #curve_root_006 interface
	    #Socket Root Selection
	    root_selection_socket = curve_root_006.interface.new_socket(name = "Root Selection", in_out='OUTPUT', socket_type = 'NodeSocketBool')
	    root_selection_socket.default_value = False
	    root_selection_socket.attribute_domain = 'POINT'
	    root_selection_socket.description = "Boolean selection of curve root points"
	
	    #Socket Root Position
	    root_position_socket = curve_root_006.interface.new_socket(name = "Root Position", in_out='OUTPUT', socket_type = 'NodeSocketVector')
	    root_position_socket.default_value = (0.0, 0.0, 0.0)
	    root_position_socket.min_value = -3.4028234663852886e+38
	    root_position_socket.max_value = 3.4028234663852886e+38
	    root_position_socket.subtype = 'NONE'
	    root_position_socket.attribute_domain = 'CURVE'
	    root_position_socket.description = "Position of the root point of a curve"
	
	    #Socket Root Direction
	    root_direction_socket = curve_root_006.interface.new_socket(name = "Root Direction", in_out='OUTPUT', socket_type = 'NodeSocketVector')
	    root_direction_socket.default_value = (0.0, 0.0, 0.0)
	    root_direction_socket.min_value = -3.4028234663852886e+38
	    root_direction_socket.max_value = 3.4028234663852886e+38
	    root_direction_socket.subtype = 'NONE'
	    root_direction_socket.attribute_domain = 'CURVE'
	    root_direction_socket.description = "Direction of the root segment of a curve"
	
	    #Socket Root Index
	    root_index_socket = curve_root_006.interface.new_socket(name = "Root Index", in_out='OUTPUT', socket_type = 'NodeSocketInt')
	    root_index_socket.default_value = 0
	    root_index_socket.min_value = -2147483648
	    root_index_socket.max_value = 2147483647
	    root_index_socket.subtype = 'NONE'
	    root_index_socket.attribute_domain = 'CURVE'
	    root_index_socket.description = "Index of the root point of a curve"
	
	
	    #initialize curve_root_006 nodes
	    #node Position.002
	    position_002 = curve_root_006.nodes.new("GeometryNodeInputPosition")
	    position_002.name = "Position.002"
	
	    #node Interpolate Domain
	    interpolate_domain = curve_root_006.nodes.new("GeometryNodeFieldOnDomain")
	    interpolate_domain.name = "Interpolate Domain"
	    interpolate_domain.data_type = 'INT'
	    interpolate_domain.domain = 'CURVE'
	
	    #node Field at Index.003
	    field_at_index_003 = curve_root_006.nodes.new("GeometryNodeFieldAtIndex")
	    field_at_index_003.name = "Field at Index.003"
	    field_at_index_003.data_type = 'FLOAT_VECTOR'
	    field_at_index_003.domain = 'POINT'
	
	    #node Interpolate Domain.001
	    interpolate_domain_001 = curve_root_006.nodes.new("GeometryNodeFieldOnDomain")
	    interpolate_domain_001.name = "Interpolate Domain.001"
	    interpolate_domain_001.data_type = 'FLOAT_VECTOR'
	    interpolate_domain_001.domain = 'CURVE'
	
	    #node Curve Tangent
	    curve_tangent = curve_root_006.nodes.new("GeometryNodeInputTangent")
	    curve_tangent.name = "Curve Tangent"
	
	    #node Endpoint Selection
	    endpoint_selection = curve_root_006.nodes.new("GeometryNodeCurveEndpointSelection")
	    endpoint_selection.name = "Endpoint Selection"
	    #Start Size
	    endpoint_selection.inputs[0].default_value = 1
	    #End Size
	    endpoint_selection.inputs[1].default_value = 0
	
	    #node Field at Index.004
	    field_at_index_004 = curve_root_006.nodes.new("GeometryNodeFieldAtIndex")
	    field_at_index_004.name = "Field at Index.004"
	    field_at_index_004.data_type = 'FLOAT_VECTOR'
	    field_at_index_004.domain = 'POINT'
	
	    #node Interpolate Domain.002
	    interpolate_domain_002 = curve_root_006.nodes.new("GeometryNodeFieldOnDomain")
	    interpolate_domain_002.name = "Interpolate Domain.002"
	    interpolate_domain_002.data_type = 'FLOAT_VECTOR'
	    interpolate_domain_002.domain = 'CURVE'
	
	    #node Group Output
	    group_output = curve_root_006.nodes.new("NodeGroupOutput")
	    group_output.name = "Group Output"
	    group_output.is_active_output = True
	
	    #node Points of Curve
	    points_of_curve = curve_root_006.nodes.new("GeometryNodePointsOfCurve")
	    points_of_curve.name = "Points of Curve"
	    points_of_curve.inputs[0].hide = True
	    points_of_curve.inputs[1].hide = True
	    points_of_curve.outputs[1].hide = True
	    #Curve Index
	    points_of_curve.inputs[0].default_value = 0
	    #Weights
	    points_of_curve.inputs[1].default_value = 0.0
	    #Sort Index
	    points_of_curve.inputs[2].default_value = 0
	
	
	
	
	
	    #Set locations
	    position_002.location = (-608.1627807617188, -70.55814361572266)
	    interpolate_domain.location = (-608.1627807617188, 90.18604278564453)
	    field_at_index_003.location = (-407.2325439453125, 70.09302520751953)
	    interpolate_domain_001.location = (-206.30230712890625, 70.09302520751953)
	    curve_tangent.location = (-608.1627807617188, -271.4883728027344)
	    endpoint_selection.location = (-206.30230712890625, 190.65118408203125)
	    field_at_index_004.location = (-407.2325439453125, -130.83721923828125)
	    interpolate_domain_002.location = (-206.30230712890625, -130.83721923828125)
	    group_output.location = (75.0, 50.0)
	    points_of_curve.location = (-789.0, 50.0)
	
	    #Set dimensions
	    position_002.width, position_002.height = 140.0, 100.0
	    interpolate_domain.width, interpolate_domain.height = 140.0, 100.0
	    field_at_index_003.width, field_at_index_003.height = 140.0, 100.0
	    interpolate_domain_001.width, interpolate_domain_001.height = 140.0, 100.0
	    curve_tangent.width, curve_tangent.height = 140.0, 100.0
	    endpoint_selection.width, endpoint_selection.height = 140.0, 100.0
	    field_at_index_004.width, field_at_index_004.height = 140.0, 100.0
	    interpolate_domain_002.width, interpolate_domain_002.height = 140.0, 100.0
	    group_output.width, group_output.height = 140.0, 100.0
	    points_of_curve.width, points_of_curve.height = 140.0, 100.0
	
	    #initialize curve_root_006 links
	    #position_002.Position -> field_at_index_003.Value
	    curve_root_006.links.new(position_002.outputs[0], field_at_index_003.inputs[1])
	    #interpolate_domain_001.Value -> group_output.Root Position
	    curve_root_006.links.new(interpolate_domain_001.outputs[0], group_output.inputs[1])
	    #interpolate_domain.Value -> field_at_index_003.Index
	    curve_root_006.links.new(interpolate_domain.outputs[0], field_at_index_003.inputs[0])
	    #points_of_curve.Point Index -> interpolate_domain.Value
	    curve_root_006.links.new(points_of_curve.outputs[0], interpolate_domain.inputs[0])
	    #interpolate_domain.Value -> group_output.Root Index
	    curve_root_006.links.new(interpolate_domain.outputs[0], group_output.inputs[3])
	    #endpoint_selection.Selection -> group_output.Root Selection
	    curve_root_006.links.new(endpoint_selection.outputs[0], group_output.inputs[0])
	    #field_at_index_003.Value -> interpolate_domain_001.Value
	    curve_root_006.links.new(field_at_index_003.outputs[0], interpolate_domain_001.inputs[0])
	    #interpolate_domain_002.Value -> group_output.Root Direction
	    curve_root_006.links.new(interpolate_domain_002.outputs[0], group_output.inputs[2])
	    #interpolate_domain.Value -> field_at_index_004.Index
	    curve_root_006.links.new(interpolate_domain.outputs[0], field_at_index_004.inputs[0])
	    #curve_tangent.Tangent -> field_at_index_004.Value
	    curve_root_006.links.new(curve_tangent.outputs[0], field_at_index_004.inputs[1])
	    #field_at_index_004.Value -> interpolate_domain_002.Value
	    curve_root_006.links.new(field_at_index_004.outputs[0], interpolate_domain_002.inputs[0])
	    return curve_root_006
	
	curve_root_006 = curve_root_006_node_group()
	
	#initialize curve_tip node group
	def curve_tip_node_group():
	    curve_tip = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Curve Tip")
	
	    curve_tip.color_tag = 'NONE'
	    curve_tip.description = "Reads information about each curve's tip point"
	    curve_tip.default_group_node_width = 140
	    
	
	
	    #curve_tip interface
	    #Socket Tip Selection
	    tip_selection_socket = curve_tip.interface.new_socket(name = "Tip Selection", in_out='OUTPUT', socket_type = 'NodeSocketBool')
	    tip_selection_socket.default_value = False
	    tip_selection_socket.attribute_domain = 'POINT'
	    tip_selection_socket.description = "Boolean selection of curve tip points"
	
	    #Socket Tip Position
	    tip_position_socket = curve_tip.interface.new_socket(name = "Tip Position", in_out='OUTPUT', socket_type = 'NodeSocketVector')
	    tip_position_socket.default_value = (0.0, 0.0, 0.0)
	    tip_position_socket.min_value = -3.4028234663852886e+38
	    tip_position_socket.max_value = 3.4028234663852886e+38
	    tip_position_socket.subtype = 'NONE'
	    tip_position_socket.attribute_domain = 'CURVE'
	    tip_position_socket.description = "Position of the tip point of a curve"
	
	    #Socket Tip Direction
	    tip_direction_socket = curve_tip.interface.new_socket(name = "Tip Direction", in_out='OUTPUT', socket_type = 'NodeSocketVector')
	    tip_direction_socket.default_value = (0.0, 0.0, 0.0)
	    tip_direction_socket.min_value = -3.4028234663852886e+38
	    tip_direction_socket.max_value = 3.4028234663852886e+38
	    tip_direction_socket.subtype = 'NONE'
	    tip_direction_socket.attribute_domain = 'CURVE'
	    tip_direction_socket.description = "Direction of the tip segment of a curve"
	
	    #Socket Tip Index
	    tip_index_socket = curve_tip.interface.new_socket(name = "Tip Index", in_out='OUTPUT', socket_type = 'NodeSocketInt')
	    tip_index_socket.default_value = 0
	    tip_index_socket.min_value = -2147483648
	    tip_index_socket.max_value = 2147483647
	    tip_index_socket.subtype = 'NONE'
	    tip_index_socket.attribute_domain = 'CURVE'
	    tip_index_socket.description = "Index of the tip point of a curve"
	
	
	    #initialize curve_tip nodes
	    #node Position.002
	    position_002_1 = curve_tip.nodes.new("GeometryNodeInputPosition")
	    position_002_1.name = "Position.002"
	
	    #node Interpolate Domain
	    interpolate_domain_1 = curve_tip.nodes.new("GeometryNodeFieldOnDomain")
	    interpolate_domain_1.name = "Interpolate Domain"
	    interpolate_domain_1.data_type = 'INT'
	    interpolate_domain_1.domain = 'CURVE'
	
	    #node Interpolate Domain.001
	    interpolate_domain_001_1 = curve_tip.nodes.new("GeometryNodeFieldOnDomain")
	    interpolate_domain_001_1.name = "Interpolate Domain.001"
	    interpolate_domain_001_1.data_type = 'FLOAT_VECTOR'
	    interpolate_domain_001_1.domain = 'CURVE'
	
	    #node Field at Index.003
	    field_at_index_003_1 = curve_tip.nodes.new("GeometryNodeFieldAtIndex")
	    field_at_index_003_1.name = "Field at Index.003"
	    field_at_index_003_1.data_type = 'FLOAT_VECTOR'
	    field_at_index_003_1.domain = 'POINT'
	
	    #node Curve Tangent
	    curve_tangent_1 = curve_tip.nodes.new("GeometryNodeInputTangent")
	    curve_tangent_1.name = "Curve Tangent"
	
	    #node Endpoint Selection
	    endpoint_selection_1 = curve_tip.nodes.new("GeometryNodeCurveEndpointSelection")
	    endpoint_selection_1.name = "Endpoint Selection"
	    #Start Size
	    endpoint_selection_1.inputs[0].default_value = 0
	    #End Size
	    endpoint_selection_1.inputs[1].default_value = 1
	
	    #node Field at Index.004
	    field_at_index_004_1 = curve_tip.nodes.new("GeometryNodeFieldAtIndex")
	    field_at_index_004_1.name = "Field at Index.004"
	    field_at_index_004_1.data_type = 'FLOAT_VECTOR'
	    field_at_index_004_1.domain = 'POINT'
	
	    #node Interpolate Domain.002
	    interpolate_domain_002_1 = curve_tip.nodes.new("GeometryNodeFieldOnDomain")
	    interpolate_domain_002_1.name = "Interpolate Domain.002"
	    interpolate_domain_002_1.data_type = 'FLOAT_VECTOR'
	    interpolate_domain_002_1.domain = 'CURVE'
	
	    #node Group Output
	    group_output_1 = curve_tip.nodes.new("NodeGroupOutput")
	    group_output_1.name = "Group Output"
	    group_output_1.is_active_output = True
	
	    #node Points of Curve
	    points_of_curve_1 = curve_tip.nodes.new("GeometryNodePointsOfCurve")
	    points_of_curve_1.name = "Points of Curve"
	    points_of_curve_1.inputs[0].hide = True
	    points_of_curve_1.inputs[1].hide = True
	    points_of_curve_1.outputs[1].hide = True
	    #Curve Index
	    points_of_curve_1.inputs[0].default_value = 0
	    #Weights
	    points_of_curve_1.inputs[1].default_value = 0.0
	    #Sort Index
	    points_of_curve_1.inputs[2].default_value = -1
	
	
	
	
	
	    #Set locations
	    position_002_1.location = (-628.2557983398438, -70.55813598632812)
	    interpolate_domain_1.location = (-628.2557983398438, 90.18605041503906)
	    interpolate_domain_001_1.location = (-246.4883575439453, 90.18605041503906)
	    field_at_index_003_1.location = (-427.3255615234375, 90.18605041503906)
	    curve_tangent_1.location = (-628.2557983398438, -231.3023223876953)
	    endpoint_selection_1.location = (-246.4883575439453, 210.7441864013672)
	    field_at_index_004_1.location = (-427.3255615234375, -90.65116882324219)
	    interpolate_domain_002_1.location = (-246.4883575439453, -90.65116882324219)
	    group_output_1.location = (75.0, 50.0)
	    points_of_curve_1.location = (-829.18603515625, 50.0)
	
	    #Set dimensions
	    position_002_1.width, position_002_1.height = 140.0, 100.0
	    interpolate_domain_1.width, interpolate_domain_1.height = 140.0, 100.0
	    interpolate_domain_001_1.width, interpolate_domain_001_1.height = 140.0, 100.0
	    field_at_index_003_1.width, field_at_index_003_1.height = 140.0, 100.0
	    curve_tangent_1.width, curve_tangent_1.height = 140.0, 100.0
	    endpoint_selection_1.width, endpoint_selection_1.height = 140.0, 100.0
	    field_at_index_004_1.width, field_at_index_004_1.height = 140.0, 100.0
	    interpolate_domain_002_1.width, interpolate_domain_002_1.height = 140.0, 100.0
	    group_output_1.width, group_output_1.height = 140.0, 100.0
	    points_of_curve_1.width, points_of_curve_1.height = 140.0, 100.0
	
	    #initialize curve_tip links
	    #position_002_1.Position -> field_at_index_003_1.Value
	    curve_tip.links.new(position_002_1.outputs[0], field_at_index_003_1.inputs[1])
	    #interpolate_domain_1.Value -> field_at_index_003_1.Index
	    curve_tip.links.new(interpolate_domain_1.outputs[0], field_at_index_003_1.inputs[0])
	    #points_of_curve_1.Point Index -> interpolate_domain_1.Value
	    curve_tip.links.new(points_of_curve_1.outputs[0], interpolate_domain_1.inputs[0])
	    #interpolate_domain_001_1.Value -> group_output_1.Tip Position
	    curve_tip.links.new(interpolate_domain_001_1.outputs[0], group_output_1.inputs[1])
	    #interpolate_domain_1.Value -> group_output_1.Tip Index
	    curve_tip.links.new(interpolate_domain_1.outputs[0], group_output_1.inputs[3])
	    #endpoint_selection_1.Selection -> group_output_1.Tip Selection
	    curve_tip.links.new(endpoint_selection_1.outputs[0], group_output_1.inputs[0])
	    #field_at_index_003_1.Value -> interpolate_domain_001_1.Value
	    curve_tip.links.new(field_at_index_003_1.outputs[0], interpolate_domain_001_1.inputs[0])
	    #interpolate_domain_002_1.Value -> group_output_1.Tip Direction
	    curve_tip.links.new(interpolate_domain_002_1.outputs[0], group_output_1.inputs[2])
	    #curve_tangent_1.Tangent -> field_at_index_004_1.Value
	    curve_tip.links.new(curve_tangent_1.outputs[0], field_at_index_004_1.inputs[1])
	    #interpolate_domain_1.Value -> field_at_index_004_1.Index
	    curve_tip.links.new(interpolate_domain_1.outputs[0], field_at_index_004_1.inputs[0])
	    #field_at_index_004_1.Value -> interpolate_domain_002_1.Value
	    curve_tip.links.new(field_at_index_004_1.outputs[0], interpolate_domain_002_1.inputs[0])
	    return curve_tip
	
	curve_tip = curve_tip_node_group()
	
	#initialize curve_info node group
	def curve_info_node_group():
	    curve_info = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Curve Info")
	
	    curve_info.color_tag = 'NONE'
	    curve_info.description = "Reads information about each curve"
	    curve_info.default_group_node_width = 140
	    
	
	
	    #curve_info interface
	    #Socket Curve Index
	    curve_index_socket = curve_info.interface.new_socket(name = "Curve Index", in_out='OUTPUT', socket_type = 'NodeSocketInt')
	    curve_index_socket.default_value = 0
	    curve_index_socket.min_value = -2147483648
	    curve_index_socket.max_value = 2147483647
	    curve_index_socket.subtype = 'NONE'
	    curve_index_socket.attribute_domain = 'CURVE'
	    curve_index_socket.description = "Index of each Curve"
	
	    #Socket Curve ID
	    curve_id_socket = curve_info.interface.new_socket(name = "Curve ID", in_out='OUTPUT', socket_type = 'NodeSocketInt')
	    curve_id_socket.default_value = 0
	    curve_id_socket.min_value = -2147483648
	    curve_id_socket.max_value = 2147483647
	    curve_id_socket.subtype = 'NONE'
	    curve_id_socket.attribute_domain = 'CURVE'
	    curve_id_socket.description = "ID of each curve"
	
	    #Socket Length
	    length_socket = curve_info.interface.new_socket(name = "Length", in_out='OUTPUT', socket_type = 'NodeSocketFloat')
	    length_socket.default_value = 0.0
	    length_socket.min_value = -3.4028234663852886e+38
	    length_socket.max_value = 3.4028234663852886e+38
	    length_socket.subtype = 'NONE'
	    length_socket.attribute_domain = 'CURVE'
	    length_socket.description = "Length of each curve"
	
	    #Socket Direction
	    direction_socket = curve_info.interface.new_socket(name = "Direction", in_out='OUTPUT', socket_type = 'NodeSocketVector')
	    direction_socket.default_value = (0.0, 0.0, 0.0)
	    direction_socket.min_value = -3.4028234663852886e+38
	    direction_socket.max_value = 3.4028234663852886e+38
	    direction_socket.subtype = 'NONE'
	    direction_socket.attribute_domain = 'CURVE'
	    direction_socket.description = "Direction from root to tip of each curve"
	
	    #Socket Random
	    random_socket = curve_info.interface.new_socket(name = "Random", in_out='OUTPUT', socket_type = 'NodeSocketFloat')
	    random_socket.default_value = 0.0
	    random_socket.min_value = -3.4028234663852886e+38
	    random_socket.max_value = 3.4028234663852886e+38
	    random_socket.subtype = 'NONE'
	    random_socket.attribute_domain = 'CURVE'
	    random_socket.description = "Random vector for each curve"
	
	    #Socket Surface UV
	    surface_uv_socket = curve_info.interface.new_socket(name = "Surface UV", in_out='OUTPUT', socket_type = 'NodeSocketVector')
	    surface_uv_socket.default_value = (0.0, 0.0, 0.0)
	    surface_uv_socket.min_value = -3.4028234663852886e+38
	    surface_uv_socket.max_value = 3.4028234663852886e+38
	    surface_uv_socket.subtype = 'NONE'
	    surface_uv_socket.attribute_domain = 'CURVE'
	    surface_uv_socket.description = "Attachment surface UV coordinates of each curve"
	
	
	    #initialize curve_info nodes
	    #node Frame
	    frame = curve_info.nodes.new("NodeFrame")
	    frame.label = "ID per Curve"
	    frame.name = "Frame"
	    frame.label_size = 20
	    frame.shrink = True
	
	    #node Group Output
	    group_output_2 = curve_info.nodes.new("NodeGroupOutput")
	    group_output_2.name = "Group Output"
	    group_output_2.is_active_output = True
	
	    #node Named Attribute
	    named_attribute = curve_info.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute.name = "Named Attribute"
	    named_attribute.data_type = 'FLOAT_VECTOR'
	    #Name
	    named_attribute.inputs[0].default_value = "surface_uv_coordinate"
	
	    #node Group.002
	    group_002 = curve_info.nodes.new("GeometryNodeGroup")
	    group_002.name = "Group.002"
	    group_002.node_tree = curve_tip
	    group_002.outputs[0].hide = True
	    group_002.outputs[2].hide = True
	    group_002.outputs[3].hide = True
	
	    #node Group.001
	    group_001 = curve_info.nodes.new("GeometryNodeGroup")
	    group_001.name = "Group.001"
	    group_001.node_tree = curve_root_006
	    group_001.outputs[0].hide = True
	    group_001.outputs[2].hide = True
	    group_001.outputs[3].hide = True
	
	    #node Evaluate at Index
	    evaluate_at_index = curve_info.nodes.new("GeometryNodeFieldAtIndex")
	    evaluate_at_index.name = "Evaluate at Index"
	    evaluate_at_index.data_type = 'FLOAT'
	    evaluate_at_index.domain = 'POINT'
	
	    #node Evaluate on Domain.001
	    evaluate_on_domain_001 = curve_info.nodes.new("GeometryNodeFieldOnDomain")
	    evaluate_on_domain_001.name = "Evaluate on Domain.001"
	    evaluate_on_domain_001.data_type = 'FLOAT'
	    evaluate_on_domain_001.domain = 'CURVE'
	
	    #node Group.003
	    group_003 = curve_info.nodes.new("GeometryNodeGroup")
	    group_003.name = "Group.003"
	    group_003.node_tree = curve_root_006
	    group_003.outputs[0].hide = True
	    group_003.outputs[1].hide = True
	    group_003.outputs[2].hide = True
	
	    #node Random Value.002
	    random_value_002 = curve_info.nodes.new("FunctionNodeRandomValue")
	    random_value_002.name = "Random Value.002"
	    random_value_002.data_type = 'FLOAT'
	    #Min_001
	    random_value_002.inputs[2].default_value = 0.0
	    #Max_001
	    random_value_002.inputs[3].default_value = 1.0
	    #Seed
	    random_value_002.inputs[8].default_value = 0
	
	    #node Reroute
	    reroute = curve_info.nodes.new("NodeReroute")
	    reroute.name = "Reroute"
	    reroute.socket_idname = "NodeSocketInt"
	    #node Vector Math
	    vector_math = curve_info.nodes.new("ShaderNodeVectorMath")
	    vector_math.name = "Vector Math"
	    vector_math.operation = 'SUBTRACT'
	
	    #node Vector Math.001
	    vector_math_001 = curve_info.nodes.new("ShaderNodeVectorMath")
	    vector_math_001.name = "Vector Math.001"
	    vector_math_001.operation = 'NORMALIZE'
	
	    #node Evaluate on Domain
	    evaluate_on_domain = curve_info.nodes.new("GeometryNodeFieldOnDomain")
	    evaluate_on_domain.name = "Evaluate on Domain"
	    evaluate_on_domain.hide = True
	    evaluate_on_domain.data_type = 'INT'
	    evaluate_on_domain.domain = 'CURVE'
	
	    #node Index.001
	    index_001 = curve_info.nodes.new("GeometryNodeInputIndex")
	    index_001.name = "Index.001"
	
	    #node Spline Length
	    spline_length = curve_info.nodes.new("GeometryNodeSplineLength")
	    spline_length.name = "Spline Length"
	    spline_length.outputs[1].hide = True
	
	    #node Evaluate at Index.001
	    evaluate_at_index_001 = curve_info.nodes.new("GeometryNodeFieldAtIndex")
	    evaluate_at_index_001.name = "Evaluate at Index.001"
	    evaluate_at_index_001.data_type = 'INT'
	    evaluate_at_index_001.domain = 'POINT'
	
	    #node Evaluate on Domain.002
	    evaluate_on_domain_002 = curve_info.nodes.new("GeometryNodeFieldOnDomain")
	    evaluate_on_domain_002.name = "Evaluate on Domain.002"
	    evaluate_on_domain_002.data_type = 'INT'
	    evaluate_on_domain_002.domain = 'CURVE'
	
	    #node Group
	    group = curve_info.nodes.new("GeometryNodeGroup")
	    group.name = "Group"
	    group.node_tree = curve_root_006
	    group.outputs[0].hide = True
	    group.outputs[1].hide = True
	    group.outputs[2].hide = True
	
	    #node ID
	    id = curve_info.nodes.new("GeometryNodeInputID")
	    id.name = "ID"
	
	
	
	
	    #Set parents
	    evaluate_at_index_001.parent = frame
	    evaluate_on_domain_002.parent = frame
	    group.parent = frame
	    id.parent = frame
	
	    #Set locations
	    frame.location = (-1200.55810546875, 150.5814208984375)
	    group_output_2.location = (75.0, 50.0)
	    named_attribute.location = (-166.11627197265625, -371.9534912109375)
	    group_002.location = (-527.7907104492188, -90.65116882324219)
	    group_001.location = (-527.7907104492188, -171.02325439453125)
	    evaluate_at_index.location = (-346.9534912109375, -211.2093048095703)
	    evaluate_on_domain_001.location = (-166.11627197265625, -211.2093048095703)
	    group_003.location = (-527.7907104492188, -251.39535522460938)
	    random_value_002.location = (-527.7907104492188, -331.7674560546875)
	    reroute.location = (-608.162841796875, 29.906982421875)
	    vector_math.location = (-346.9534912109375, -70.55814361572266)
	    vector_math_001.location = (-166.11627197265625, -70.55814361572266)
	    evaluate_on_domain.location = (-166.11627197265625, 70.093017578125)
	    index_001.location = (-346.9534912109375, 110.27906799316406)
	    spline_length.location = (-166.11627197265625, -10.279067993164062)
	    evaluate_at_index_001.location = (210.62786865234375, -40.30235290527344)
	    evaluate_on_domain_002.location = (391.465087890625, -40.30235290527344)
	    group.location = (29.7906494140625, -60.3953857421875)
	    id.location = (29.7906494140625, -140.76747131347656)
	
	    #Set dimensions
	    frame.width, frame.height = 561.9534301757812, 225.93026733398438
	    group_output_2.width, group_output_2.height = 140.0, 100.0
	    named_attribute.width, named_attribute.height = 140.0, 100.0
	    group_002.width, group_002.height = 140.0, 100.0
	    group_001.width, group_001.height = 140.0, 100.0
	    evaluate_at_index.width, evaluate_at_index.height = 140.0, 100.0
	    evaluate_on_domain_001.width, evaluate_on_domain_001.height = 140.0, 100.0
	    group_003.width, group_003.height = 140.0, 100.0
	    random_value_002.width, random_value_002.height = 140.0, 100.0
	    reroute.width, reroute.height = 100.0, 100.0
	    vector_math.width, vector_math.height = 140.0, 100.0
	    vector_math_001.width, vector_math_001.height = 140.0, 100.0
	    evaluate_on_domain.width, evaluate_on_domain.height = 140.0, 100.0
	    index_001.width, index_001.height = 140.0, 100.0
	    spline_length.width, spline_length.height = 140.0, 100.0
	    evaluate_at_index_001.width, evaluate_at_index_001.height = 140.0, 100.0
	    evaluate_on_domain_002.width, evaluate_on_domain_002.height = 140.0, 100.0
	    group.width, group.height = 140.0, 100.0
	    id.width, id.height = 140.0, 100.0
	
	    #initialize curve_info links
	    #index_001.Index -> evaluate_on_domain.Value
	    curve_info.links.new(index_001.outputs[0], evaluate_on_domain.inputs[0])
	    #evaluate_on_domain.Value -> group_output_2.Curve Index
	    curve_info.links.new(evaluate_on_domain.outputs[0], group_output_2.inputs[0])
	    #named_attribute.Attribute -> group_output_2.Surface UV
	    curve_info.links.new(named_attribute.outputs[0], group_output_2.inputs[5])
	    #evaluate_at_index_001.Value -> evaluate_on_domain_002.Value
	    curve_info.links.new(evaluate_at_index_001.outputs[0], evaluate_on_domain_002.inputs[0])
	    #group.Root Index -> evaluate_at_index_001.Index
	    curve_info.links.new(group.outputs[3], evaluate_at_index_001.inputs[0])
	    #reroute.Output -> group_output_2.Curve ID
	    curve_info.links.new(reroute.outputs[0], group_output_2.inputs[1])
	    #id.ID -> evaluate_at_index_001.Value
	    curve_info.links.new(id.outputs[0], evaluate_at_index_001.inputs[1])
	    #spline_length.Length -> group_output_2.Length
	    curve_info.links.new(spline_length.outputs[0], group_output_2.inputs[2])
	    #group_002.Tip Position -> vector_math.Vector
	    curve_info.links.new(group_002.outputs[1], vector_math.inputs[0])
	    #group_001.Root Position -> vector_math.Vector
	    curve_info.links.new(group_001.outputs[1], vector_math.inputs[1])
	    #vector_math_001.Vector -> group_output_2.Direction
	    curve_info.links.new(vector_math_001.outputs[0], group_output_2.inputs[3])
	    #vector_math.Vector -> vector_math_001.Vector
	    curve_info.links.new(vector_math.outputs[0], vector_math_001.inputs[0])
	    #reroute.Output -> random_value_002.ID
	    curve_info.links.new(reroute.outputs[0], random_value_002.inputs[7])
	    #evaluate_at_index.Value -> evaluate_on_domain_001.Value
	    curve_info.links.new(evaluate_at_index.outputs[0], evaluate_on_domain_001.inputs[0])
	    #evaluate_on_domain_001.Value -> group_output_2.Random
	    curve_info.links.new(evaluate_on_domain_001.outputs[0], group_output_2.inputs[4])
	    #random_value_002.Value -> evaluate_at_index.Value
	    curve_info.links.new(random_value_002.outputs[1], evaluate_at_index.inputs[1])
	    #group_003.Root Index -> evaluate_at_index.Index
	    curve_info.links.new(group_003.outputs[3], evaluate_at_index.inputs[0])
	    #evaluate_on_domain_002.Value -> reroute.Input
	    curve_info.links.new(evaluate_on_domain_002.outputs[0], reroute.inputs[0])
	    return curve_info
	
	curve_info = curve_info_node_group()
	
	#initialize duplicate_hair_curves node group
	def duplicate_hair_curves_node_group():
	    duplicate_hair_curves = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Duplicate Hair Curves")
	
	    duplicate_hair_curves.color_tag = 'NONE'
	    duplicate_hair_curves.description = "Duplicates hair curves a certain number of times within a radius"
	    duplicate_hair_curves.default_group_node_width = 140
	    
	
	    duplicate_hair_curves.is_modifier = True
	
	    #duplicate_hair_curves interface
	    #Socket Geometry
	    geometry_socket = duplicate_hair_curves.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket.attribute_domain = 'POINT'
	
	    #Socket Guide Index
	    guide_index_socket = duplicate_hair_curves.interface.new_socket(name = "Guide Index", in_out='OUTPUT', socket_type = 'NodeSocketInt')
	    guide_index_socket.default_value = 0
	    guide_index_socket.min_value = -2147483648
	    guide_index_socket.max_value = 2147483647
	    guide_index_socket.subtype = 'NONE'
	    guide_index_socket.attribute_domain = 'CURVE'
	    guide_index_socket.description = "Guide index map that was used for the operation"
	
	    #Socket Geometry
	    geometry_socket_1 = duplicate_hair_curves.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_1.attribute_domain = 'POINT'
	    geometry_socket_1.description = "Input Geometry (May include other than curves)"
	
	    #Socket Amount
	    amount_socket = duplicate_hair_curves.interface.new_socket(name = "Amount", in_out='INPUT', socket_type = 'NodeSocketInt')
	    amount_socket.default_value = 10
	    amount_socket.min_value = 0
	    amount_socket.max_value = 2147483647
	    amount_socket.subtype = 'NONE'
	    amount_socket.attribute_domain = 'POINT'
	    amount_socket.description = "Amount of duplicates per curve"
	
	    #Socket Viewport Amount
	    viewport_amount_socket = duplicate_hair_curves.interface.new_socket(name = "Viewport Amount", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    viewport_amount_socket.default_value = 1.0
	    viewport_amount_socket.min_value = 0.0
	    viewport_amount_socket.max_value = 1.0
	    viewport_amount_socket.subtype = 'FACTOR'
	    viewport_amount_socket.attribute_domain = 'POINT'
	    viewport_amount_socket.description = "Percentage of amount used for the viewport"
	
	    #Socket Radius
	    radius_socket = duplicate_hair_curves.interface.new_socket(name = "Radius", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    radius_socket.default_value = 0.10000000149011612
	    radius_socket.min_value = 0.0
	    radius_socket.max_value = 3.4028234663852886e+38
	    radius_socket.subtype = 'DISTANCE'
	    radius_socket.attribute_domain = 'POINT'
	    radius_socket.description = "Radius in which the duplicate curves are offset from the guides"
	
	    #Socket Distribution Shape
	    distribution_shape_socket = duplicate_hair_curves.interface.new_socket(name = "Distribution Shape", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    distribution_shape_socket.default_value = 0.0
	    distribution_shape_socket.min_value = -10.0
	    distribution_shape_socket.max_value = 10.0
	    distribution_shape_socket.subtype = 'NONE'
	    distribution_shape_socket.attribute_domain = 'POINT'
	    distribution_shape_socket.description = "Shape of distribution from center to the edge around the guide"
	
	    #Socket Tip Roundness
	    tip_roundness_socket = duplicate_hair_curves.interface.new_socket(name = "Tip Roundness", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    tip_roundness_socket.default_value = 0.0
	    tip_roundness_socket.min_value = 0.0
	    tip_roundness_socket.max_value = 1.0
	    tip_roundness_socket.subtype = 'FACTOR'
	    tip_roundness_socket.attribute_domain = 'POINT'
	    tip_roundness_socket.description = "Offset of the curves to round the tip"
	
	    #Socket Even Thickness
	    even_thickness_socket = duplicate_hair_curves.interface.new_socket(name = "Even Thickness", in_out='INPUT', socket_type = 'NodeSocketBool')
	    even_thickness_socket.default_value = False
	    even_thickness_socket.attribute_domain = 'POINT'
	    even_thickness_socket.description = "Keep an even thickness of the distribution of duplicates"
	
	    #Socket Seed
	    seed_socket = duplicate_hair_curves.interface.new_socket(name = "Seed", in_out='INPUT', socket_type = 'NodeSocketInt')
	    seed_socket.default_value = 0
	    seed_socket.min_value = -10000
	    seed_socket.max_value = 10000
	    seed_socket.subtype = 'NONE'
	    seed_socket.attribute_domain = 'POINT'
	    seed_socket.description = "Random Seed for the operation"
	
	
	    #initialize duplicate_hair_curves nodes
	    #node Frame.002
	    frame_002 = duplicate_hair_curves.nodes.new("NodeFrame")
	    frame_002.label = "Random Disc Position"
	    frame_002.name = "Frame.002"
	    frame_002.label_size = 20
	    frame_002.shrink = True
	
	    #node Frame.001
	    frame_001 = duplicate_hair_curves.nodes.new("NodeFrame")
	    frame_001.label = "Tangent Space per Point"
	    frame_001.name = "Frame.001"
	    frame_001.label_size = 20
	    frame_001.shrink = True
	
	    #node Frame
	    frame_1 = duplicate_hair_curves.nodes.new("NodeFrame")
	    frame_1.label = "Tangent Space of Root Point"
	    frame_1.name = "Frame"
	    frame_1.label_size = 20
	    frame_1.shrink = True
	
	    #node Frame.004
	    frame_004 = duplicate_hair_curves.nodes.new("NodeFrame")
	    frame_004.label = "Duplicate Curves"
	    frame_004.name = "Frame.004"
	    frame_004.label_size = 20
	    frame_004.shrink = True
	
	    #node Frame.003
	    frame_003 = duplicate_hair_curves.nodes.new("NodeFrame")
	    frame_003.label = "Random Vector per Curve"
	    frame_003.name = "Frame.003"
	    frame_003.label_size = 20
	    frame_003.shrink = True
	
	    #node Reroute.016
	    reroute_016 = duplicate_hair_curves.nodes.new("NodeReroute")
	    reroute_016.name = "Reroute.016"
	    reroute_016.socket_idname = "NodeSocketGeometry"
	    #node Reroute.017
	    reroute_017 = duplicate_hair_curves.nodes.new("NodeReroute")
	    reroute_017.name = "Reroute.017"
	    reroute_017.socket_idname = "NodeSocketGeometry"
	    #node Reroute.019
	    reroute_019 = duplicate_hair_curves.nodes.new("NodeReroute")
	    reroute_019.name = "Reroute.019"
	    reroute_019.socket_idname = "NodeSocketGeometry"
	    #node Reroute.018
	    reroute_018 = duplicate_hair_curves.nodes.new("NodeReroute")
	    reroute_018.name = "Reroute.018"
	    reroute_018.socket_idname = "NodeSocketGeometry"
	    #node Group Input
	    group_input = duplicate_hair_curves.nodes.new("NodeGroupInput")
	    group_input.name = "Group Input"
	    group_input.outputs[1].hide = True
	    group_input.outputs[2].hide = True
	    group_input.outputs[3].hide = True
	    group_input.outputs[4].hide = True
	    group_input.outputs[5].hide = True
	    group_input.outputs[6].hide = True
	    group_input.outputs[7].hide = True
	    group_input.outputs[8].hide = True
	
	    #node Group Output
	    group_output_3 = duplicate_hair_curves.nodes.new("NodeGroupOutput")
	    group_output_3.name = "Group Output"
	    group_output_3.is_active_output = True
	
	    #node Separate Components
	    separate_components = duplicate_hair_curves.nodes.new("GeometryNodeSeparateComponents")
	    separate_components.name = "Separate Components"
	    separate_components.hide = True
	
	    #node Math.053
	    math_053 = duplicate_hair_curves.nodes.new("ShaderNodeMath")
	    math_053.name = "Math.053"
	    math_053.hide = True
	    math_053.operation = 'ARCCOSINE'
	    math_053.use_clamp = False
	
	    #node Math.055
	    math_055 = duplicate_hair_curves.nodes.new("ShaderNodeMath")
	    math_055.name = "Math.055"
	    math_055.hide = True
	    math_055.operation = 'DIVIDE'
	    math_055.use_clamp = False
	    #Value_001
	    math_055.inputs[1].default_value = 1.5707963705062866
	
	    #node Math.056
	    math_056 = duplicate_hair_curves.nodes.new("ShaderNodeMath")
	    math_056.name = "Math.056"
	    math_056.hide = True
	    math_056.operation = 'POWER'
	    math_056.use_clamp = False
	    #Value
	    math_056.inputs[0].default_value = 2.0
	
	    #node Group Input.006
	    group_input_006 = duplicate_hair_curves.nodes.new("NodeGroupInput")
	    group_input_006.name = "Group Input.006"
	    group_input_006.outputs[0].hide = True
	    group_input_006.outputs[1].hide = True
	    group_input_006.outputs[2].hide = True
	    group_input_006.outputs[3].hide = True
	    group_input_006.outputs[5].hide = True
	    group_input_006.outputs[6].hide = True
	    group_input_006.outputs[7].hide = True
	    group_input_006.outputs[8].hide = True
	
	    #node Separate XYZ.002
	    separate_xyz_002 = duplicate_hair_curves.nodes.new("ShaderNodeSeparateXYZ")
	    separate_xyz_002.name = "Separate XYZ.002"
	
	    #node Math.054
	    math_054 = duplicate_hair_curves.nodes.new("ShaderNodeMath")
	    math_054.name = "Math.054"
	    math_054.operation = 'POWER'
	    math_054.use_clamp = False
	
	    #node Math.052
	    math_052 = duplicate_hair_curves.nodes.new("ShaderNodeMath")
	    math_052.name = "Math.052"
	    math_052.hide = True
	    math_052.operation = 'MULTIPLY'
	    math_052.use_clamp = False
	    #Value_001
	    math_052.inputs[1].default_value = 6.2831854820251465
	
	    #node Combine XYZ.002
	    combine_xyz_002 = duplicate_hair_curves.nodes.new("ShaderNodeCombineXYZ")
	    combine_xyz_002.name = "Combine XYZ.002"
	    combine_xyz_002.inputs[1].hide = True
	    combine_xyz_002.inputs[2].hide = True
	    #Y
	    combine_xyz_002.inputs[1].default_value = 0.0
	    #Z
	    combine_xyz_002.inputs[2].default_value = 0.0
	
	    #node Math.059
	    math_059 = duplicate_hair_curves.nodes.new("ShaderNodeMath")
	    math_059.name = "Math.059"
	    math_059.hide = True
	    math_059.operation = 'SUBTRACT'
	    math_059.use_clamp = False
	    #Value_001
	    math_059.inputs[1].default_value = 0.5
	
	    #node Math.058
	    math_058 = duplicate_hair_curves.nodes.new("ShaderNodeMath")
	    math_058.name = "Math.058"
	    math_058.hide = True
	    math_058.operation = 'POWER'
	    math_058.use_clamp = False
	    #Value_001
	    math_058.inputs[1].default_value = 2.0
	
	    #node Vector Rotate
	    vector_rotate = duplicate_hair_curves.nodes.new("ShaderNodeVectorRotate")
	    vector_rotate.name = "Vector Rotate"
	    vector_rotate.invert = False
	    vector_rotate.rotation_type = 'Z_AXIS'
	    vector_rotate.inputs[1].hide = True
	    vector_rotate.inputs[2].hide = True
	    vector_rotate.inputs[4].hide = True
	    #Center
	    vector_rotate.inputs[1].default_value = (0.0, 0.0, 0.0)
	
	    #node Math.057
	    math_057 = duplicate_hair_curves.nodes.new("ShaderNodeMath")
	    math_057.name = "Math.057"
	    math_057.operation = 'ADD'
	    math_057.use_clamp = False
	
	    #node Group Input.007
	    group_input_007 = duplicate_hair_curves.nodes.new("NodeGroupInput")
	    group_input_007.name = "Group Input.007"
	    group_input_007.outputs[0].hide = True
	    group_input_007.outputs[1].hide = True
	    group_input_007.outputs[2].hide = True
	    group_input_007.outputs[3].hide = True
	    group_input_007.outputs[4].hide = True
	    group_input_007.outputs[6].hide = True
	    group_input_007.outputs[7].hide = True
	    group_input_007.outputs[8].hide = True
	
	    #node Combine XYZ
	    combine_xyz = duplicate_hair_curves.nodes.new("ShaderNodeCombineXYZ")
	    combine_xyz.name = "Combine XYZ"
	    combine_xyz.inputs[0].hide = True
	    combine_xyz.inputs[1].hide = True
	    #X
	    combine_xyz.inputs[0].default_value = 0.0
	    #Y
	    combine_xyz.inputs[1].default_value = 0.0
	
	    #node Vector Math.014
	    vector_math_014 = duplicate_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_014.name = "Vector Math.014"
	    vector_math_014.operation = 'SCALE'
	
	    #node Vector Math.013
	    vector_math_013 = duplicate_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_013.name = "Vector Math.013"
	    vector_math_013.operation = 'SUBTRACT'
	
	    #node Reroute.001
	    reroute_001 = duplicate_hair_curves.nodes.new("NodeReroute")
	    reroute_001.name = "Reroute.001"
	    reroute_001.socket_idname = "NodeSocketGeometry"
	    #node Reroute.003
	    reroute_003 = duplicate_hair_curves.nodes.new("NodeReroute")
	    reroute_003.name = "Reroute.003"
	    reroute_003.socket_idname = "NodeSocketBool"
	    #node Set Position
	    set_position = duplicate_hair_curves.nodes.new("GeometryNodeSetPosition")
	    set_position.name = "Set Position"
	    #Position
	    set_position.inputs[2].default_value = (0.0, 0.0, 0.0)
	
	    #node Set Position.001
	    set_position_001 = duplicate_hair_curves.nodes.new("GeometryNodeSetPosition")
	    set_position_001.name = "Set Position.001"
	    #Position
	    set_position_001.inputs[2].default_value = (0.0, 0.0, 0.0)
	
	    #node Normal
	    normal = duplicate_hair_curves.nodes.new("GeometryNodeInputNormal")
	    normal.name = "Normal"
	    normal.legacy_corner_normals = True
	
	    #node Curve Tangent
	    curve_tangent_2 = duplicate_hair_curves.nodes.new("GeometryNodeInputTangent")
	    curve_tangent_2.name = "Curve Tangent"
	
	    #node Separate XYZ
	    separate_xyz = duplicate_hair_curves.nodes.new("ShaderNodeSeparateXYZ")
	    separate_xyz.name = "Separate XYZ"
	
	    #node Vector Math.001
	    vector_math_001_1 = duplicate_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_001_1.name = "Vector Math.001"
	    vector_math_001_1.operation = 'SCALE'
	
	    #node Vector Math.003
	    vector_math_003 = duplicate_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_003.name = "Vector Math.003"
	    vector_math_003.operation = 'ADD'
	
	    #node Vector Math.002
	    vector_math_002 = duplicate_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_002.name = "Vector Math.002"
	    vector_math_002.operation = 'SCALE'
	
	    #node Vector Math.009
	    vector_math_009 = duplicate_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_009.name = "Vector Math.009"
	    vector_math_009.operation = 'ADD'
	
	    #node Vector Math.010
	    vector_math_010 = duplicate_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_010.name = "Vector Math.010"
	    vector_math_010.operation = 'SCALE'
	
	    #node Vector Math
	    vector_math_1 = duplicate_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_1.name = "Vector Math"
	    vector_math_1.operation = 'CROSS_PRODUCT'
	
	    #node Group.001
	    group_001_1 = duplicate_hair_curves.nodes.new("GeometryNodeGroup")
	    group_001_1.name = "Group.001"
	    group_001_1.node_tree = curve_root_006
	    group_001_1.outputs[0].hide = True
	    group_001_1.outputs[1].hide = True
	    group_001_1.outputs[2].hide = True
	
	    #node Evaluate on Domain.002
	    evaluate_on_domain_002_1 = duplicate_hair_curves.nodes.new("GeometryNodeFieldOnDomain")
	    evaluate_on_domain_002_1.name = "Evaluate on Domain.002"
	    evaluate_on_domain_002_1.data_type = 'FLOAT_VECTOR'
	    evaluate_on_domain_002_1.domain = 'CURVE'
	
	    #node Separate XYZ.001
	    separate_xyz_001 = duplicate_hair_curves.nodes.new("ShaderNodeSeparateXYZ")
	    separate_xyz_001.name = "Separate XYZ.001"
	
	    #node Vector Math.011
	    vector_math_011 = duplicate_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_011.name = "Vector Math.011"
	    vector_math_011.operation = 'ADD'
	
	    #node Vector Math.005
	    vector_math_005 = duplicate_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_005.name = "Vector Math.005"
	    vector_math_005.operation = 'ADD'
	
	    #node Vector Math.007
	    vector_math_007 = duplicate_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_007.name = "Vector Math.007"
	    vector_math_007.operation = 'SCALE'
	
	    #node Vector Math.008
	    vector_math_008 = duplicate_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_008.name = "Vector Math.008"
	    vector_math_008.operation = 'CROSS_PRODUCT'
	
	    #node Evaluate at Index
	    evaluate_at_index_1 = duplicate_hair_curves.nodes.new("GeometryNodeFieldAtIndex")
	    evaluate_at_index_1.name = "Evaluate at Index"
	    evaluate_at_index_1.data_type = 'FLOAT_VECTOR'
	    evaluate_at_index_1.domain = 'POINT'
	
	    #node Vector Math.012
	    vector_math_012 = duplicate_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_012.name = "Vector Math.012"
	    vector_math_012.operation = 'SCALE'
	
	    #node Vector Math.006
	    vector_math_006 = duplicate_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_006.name = "Vector Math.006"
	    vector_math_006.operation = 'SCALE'
	
	    #node Evaluate on Domain.001
	    evaluate_on_domain_001_1 = duplicate_hair_curves.nodes.new("GeometryNodeFieldOnDomain")
	    evaluate_on_domain_001_1.name = "Evaluate on Domain.001"
	    evaluate_on_domain_001_1.hide = True
	    evaluate_on_domain_001_1.data_type = 'FLOAT_VECTOR'
	    evaluate_on_domain_001_1.domain = 'POINT'
	
	    #node Curve Tangent.001
	    curve_tangent_001 = duplicate_hair_curves.nodes.new("GeometryNodeInputTangent")
	    curve_tangent_001.name = "Curve Tangent.001"
	
	    #node Normal.001
	    normal_001 = duplicate_hair_curves.nodes.new("GeometryNodeInputNormal")
	    normal_001.name = "Normal.001"
	    normal_001.legacy_corner_normals = True
	
	    #node Reroute.014
	    reroute_014 = duplicate_hair_curves.nodes.new("NodeReroute")
	    reroute_014.name = "Reroute.014"
	    reroute_014.socket_idname = "NodeSocketGeometry"
	    #node Reroute.015
	    reroute_015 = duplicate_hair_curves.nodes.new("NodeReroute")
	    reroute_015.name = "Reroute.015"
	    reroute_015.socket_idname = "NodeSocketGeometry"
	    #node Reroute.013
	    reroute_013 = duplicate_hair_curves.nodes.new("NodeReroute")
	    reroute_013.name = "Reroute.013"
	    reroute_013.socket_idname = "NodeSocketGeometry"
	    #node Reroute.012
	    reroute_012 = duplicate_hair_curves.nodes.new("NodeReroute")
	    reroute_012.name = "Reroute.012"
	    reroute_012.socket_idname = "NodeSocketGeometry"
	    #node Is Viewport
	    is_viewport = duplicate_hair_curves.nodes.new("GeometryNodeIsViewport")
	    is_viewport.name = "Is Viewport"
	
	    #node Switch
	    switch = duplicate_hair_curves.nodes.new("GeometryNodeSwitch")
	    switch.name = "Switch"
	    switch.input_type = 'INT'
	
	    #node ID
	    id_1 = duplicate_hair_curves.nodes.new("GeometryNodeInputID")
	    id_1.name = "ID"
	
	    #node Reroute.004
	    reroute_004 = duplicate_hair_curves.nodes.new("NodeReroute")
	    reroute_004.name = "Reroute.004"
	    reroute_004.socket_idname = "NodeSocketInt"
	    #node Reroute.002
	    reroute_002 = duplicate_hair_curves.nodes.new("NodeReroute")
	    reroute_002.name = "Reroute.002"
	    reroute_002.socket_idname = "NodeSocketGeometry"
	    #node Join Geometry
	    join_geometry = duplicate_hair_curves.nodes.new("GeometryNodeJoinGeometry")
	    join_geometry.name = "Join Geometry"
	
	    #node Set ID
	    set_id = duplicate_hair_curves.nodes.new("GeometryNodeSetID")
	    set_id.name = "Set ID"
	    #Selection
	    set_id.inputs[1].default_value = True
	
	    #node Store Named Attribute
	    store_named_attribute = duplicate_hair_curves.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute.name = "Store Named Attribute"
	    store_named_attribute.data_type = 'INT'
	    store_named_attribute.domain = 'CURVE'
	    #Selection
	    store_named_attribute.inputs[1].default_value = True
	    #Name
	    store_named_attribute.inputs[2].default_value = "guide_curve_index"
	
	    #node Math
	    math = duplicate_hair_curves.nodes.new("ShaderNodeMath")
	    math.name = "Math"
	    math.hide = True
	    math.operation = 'MULTIPLY'
	    math.use_clamp = False
	
	    #node Group Input.002
	    group_input_002 = duplicate_hair_curves.nodes.new("NodeGroupInput")
	    group_input_002.name = "Group Input.002"
	    group_input_002.outputs[0].hide = True
	    group_input_002.outputs[1].hide = True
	    group_input_002.outputs[3].hide = True
	    group_input_002.outputs[4].hide = True
	    group_input_002.outputs[5].hide = True
	    group_input_002.outputs[6].hide = True
	    group_input_002.outputs[7].hide = True
	    group_input_002.outputs[8].hide = True
	
	    #node Group Input.004
	    group_input_004 = duplicate_hair_curves.nodes.new("NodeGroupInput")
	    group_input_004.name = "Group Input.004"
	    group_input_004.outputs[0].hide = True
	    group_input_004.outputs[2].hide = True
	    group_input_004.outputs[3].hide = True
	    group_input_004.outputs[4].hide = True
	    group_input_004.outputs[5].hide = True
	    group_input_004.outputs[6].hide = True
	    group_input_004.outputs[7].hide = True
	    group_input_004.outputs[8].hide = True
	
	    #node Capture Attribute.002
	    capture_attribute_002 = duplicate_hair_curves.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_002.name = "Capture Attribute.002"
	    capture_attribute_002.active_index = 0
	    capture_attribute_002.capture_items.clear()
	    capture_attribute_002.capture_items.new('FLOAT', "Value")
	    capture_attribute_002.capture_items["Value"].data_type = 'BOOLEAN'
	    capture_attribute_002.domain = 'POINT'
	    #Value
	    capture_attribute_002.inputs[1].default_value = True
	
	    #node Vector Math.004
	    vector_math_004 = duplicate_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_004.name = "Vector Math.004"
	    vector_math_004.operation = 'SCALE'
	
	    #node Group Input.003
	    group_input_003 = duplicate_hair_curves.nodes.new("NodeGroupInput")
	    group_input_003.name = "Group Input.003"
	    group_input_003.outputs[0].hide = True
	    group_input_003.outputs[1].hide = True
	    group_input_003.outputs[2].hide = True
	    group_input_003.outputs[4].hide = True
	    group_input_003.outputs[5].hide = True
	    group_input_003.outputs[6].hide = True
	    group_input_003.outputs[7].hide = True
	    group_input_003.outputs[8].hide = True
	
	    #node Random Value.001
	    random_value_001 = duplicate_hair_curves.nodes.new("FunctionNodeRandomValue")
	    random_value_001.name = "Random Value.001"
	    random_value_001.data_type = 'FLOAT_VECTOR'
	    #Min
	    random_value_001.inputs[0].default_value = (0.0, 0.0, 0.0)
	    #Max
	    random_value_001.inputs[1].default_value = (1.0, 1.0, 1.0)
	
	    #node Capture Attribute
	    capture_attribute = duplicate_hair_curves.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute.name = "Capture Attribute"
	    capture_attribute.active_index = 0
	    capture_attribute.capture_items.clear()
	    capture_attribute.capture_items.new('FLOAT', "Value")
	    capture_attribute.capture_items["Value"].data_type = 'INT'
	    capture_attribute.domain = 'POINT'
	
	    #node Duplicate Elements
	    duplicate_elements = duplicate_hair_curves.nodes.new("GeometryNodeDuplicateElements")
	    duplicate_elements.name = "Duplicate Elements"
	    duplicate_elements.domain = 'SPLINE'
	    #Selection
	    duplicate_elements.inputs[1].default_value = True
	
	    #node Join Geometry.001
	    join_geometry_001 = duplicate_hair_curves.nodes.new("GeometryNodeJoinGeometry")
	    join_geometry_001.name = "Join Geometry.001"
	
	    #node Random Value
	    random_value = duplicate_hair_curves.nodes.new("FunctionNodeRandomValue")
	    random_value.name = "Random Value"
	    random_value.data_type = 'INT'
	    #Min_002
	    random_value.inputs[4].default_value = -1073741823
	    #Max_002
	    random_value.inputs[5].default_value = 1073741823
	
	    #node Reroute.020
	    reroute_020 = duplicate_hair_curves.nodes.new("NodeReroute")
	    reroute_020.name = "Reroute.020"
	    reroute_020.socket_idname = "NodeSocketGeometry"
	    #node Index
	    index = duplicate_hair_curves.nodes.new("GeometryNodeInputIndex")
	    index.name = "Index"
	
	    #node Capture Attribute.001
	    capture_attribute_001 = duplicate_hair_curves.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_001.name = "Capture Attribute.001"
	    capture_attribute_001.active_index = 0
	    capture_attribute_001.capture_items.clear()
	    capture_attribute_001.capture_items.new('FLOAT', "Value")
	    capture_attribute_001.capture_items["Value"].data_type = 'INT'
	    capture_attribute_001.domain = 'CURVE'
	
	    #node Switch.001
	    switch_001 = duplicate_hair_curves.nodes.new("GeometryNodeSwitch")
	    switch_001.name = "Switch.001"
	    switch_001.input_type = 'GEOMETRY'
	
	    #node Group
	    group_1 = duplicate_hair_curves.nodes.new("GeometryNodeGroup")
	    group_1.name = "Group"
	    group_1.node_tree = curve_info
	    group_1.outputs[0].hide = True
	    group_1.outputs[2].hide = True
	    group_1.outputs[3].hide = True
	    group_1.outputs[4].hide = True
	    group_1.outputs[5].hide = True
	
	    #node Group Input.001
	    group_input_001 = duplicate_hair_curves.nodes.new("NodeGroupInput")
	    group_input_001.name = "Group Input.001"
	    group_input_001.outputs[0].hide = True
	    group_input_001.outputs[1].hide = True
	    group_input_001.outputs[2].hide = True
	    group_input_001.outputs[3].hide = True
	    group_input_001.outputs[4].hide = True
	    group_input_001.outputs[5].hide = True
	    group_input_001.outputs[6].hide = True
	    group_input_001.outputs[8].hide = True
	
	    #node Group Input.005
	    group_input_005 = duplicate_hair_curves.nodes.new("NodeGroupInput")
	    group_input_005.name = "Group Input.005"
	    group_input_005.outputs[0].hide = True
	    group_input_005.outputs[1].hide = True
	    group_input_005.outputs[2].hide = True
	    group_input_005.outputs[3].hide = True
	    group_input_005.outputs[4].hide = True
	    group_input_005.outputs[5].hide = True
	    group_input_005.outputs[7].hide = True
	    group_input_005.outputs[8].hide = True
	
	    #node Random Value.004
	    random_value_004 = duplicate_hair_curves.nodes.new("FunctionNodeRandomValue")
	    random_value_004.name = "Random Value.004"
	    random_value_004.data_type = 'INT'
	    #Min_002
	    random_value_004.inputs[4].default_value = -1073741823
	    #Max_002
	    random_value_004.inputs[5].default_value = 1073741823
	    #Seed
	    random_value_004.inputs[8].default_value = 296
	
	
	
	
	    #Set parents
	    math_053.parent = frame_002
	    math_055.parent = frame_002
	    math_056.parent = frame_002
	    group_input_006.parent = frame_002
	    separate_xyz_002.parent = frame_002
	    math_054.parent = frame_002
	    math_052.parent = frame_002
	    combine_xyz_002.parent = frame_002
	    math_059.parent = frame_002
	    math_058.parent = frame_002
	    vector_rotate.parent = frame_002
	    math_057.parent = frame_002
	    group_input_007.parent = frame_002
	    combine_xyz.parent = frame_002
	    vector_math_014.parent = frame_002
	    vector_math_013.parent = frame_002
	    normal.parent = frame_001
	    curve_tangent_2.parent = frame_001
	    separate_xyz.parent = frame_001
	    vector_math_001_1.parent = frame_001
	    vector_math_003.parent = frame_001
	    vector_math_002.parent = frame_001
	    vector_math_009.parent = frame_001
	    vector_math_010.parent = frame_001
	    vector_math_1.parent = frame_001
	    group_001_1.parent = frame_1
	    evaluate_on_domain_002_1.parent = frame_1
	    separate_xyz_001.parent = frame_1
	    vector_math_011.parent = frame_1
	    vector_math_005.parent = frame_1
	    vector_math_007.parent = frame_1
	    vector_math_008.parent = frame_1
	    evaluate_at_index_1.parent = frame_1
	    vector_math_012.parent = frame_1
	    vector_math_006.parent = frame_1
	    evaluate_on_domain_001_1.parent = frame_1
	    curve_tangent_001.parent = frame_1
	    normal_001.parent = frame_1
	    is_viewport.parent = frame_004
	    switch.parent = frame_004
	    id_1.parent = frame_004
	    reroute_004.parent = frame_004
	    reroute_002.parent = frame_004
	    join_geometry.parent = frame_004
	    set_id.parent = frame_004
	    store_named_attribute.parent = frame_004
	    math.parent = frame_004
	    group_input_002.parent = frame_004
	    group_input_004.parent = frame_004
	    capture_attribute_002.parent = frame_004
	    random_value_001.parent = frame_003
	    capture_attribute.parent = frame_004
	    duplicate_elements.parent = frame_004
	    random_value.parent = frame_004
	    group_1.parent = frame_003
	    group_input_001.parent = frame_003
	    random_value_004.parent = frame_003
	
	    #Set locations
	    frame_002.location = (-4255.0, -613.0)
	    frame_001.location = (-1965.0, -734.0)
	    frame_1.location = (-2265.0, -272.0)
	    frame_004.location = (-2910.0, 228.0)
	    frame_003.location = (-4868.0, -613.0)
	    reroute_016.location = (-431.521728515625, 395.1722106933594)
	    reroute_017.location = (-431.521728515625, 354.9861755371094)
	    reroute_019.location = (-431.521728515625, 314.8001403808594)
	    reroute_018.location = (-431.521728515625, 274.6141052246094)
	    group_input.location = (-3843.1396484375, 29.906982421875)
	    group_output_3.location = (75.0, 50.0)
	    separate_components.location = (-3652.255859375, 19.86041259765625)
	    math_053.location = (230.622802734375, -60.3717041015625)
	    math_055.location = (230.622802734375, -100.5577392578125)
	    math_056.location = (190.436767578125, -221.11590576171875)
	    group_input_006.location = (29.6923828125, -221.11590576171875)
	    separate_xyz_002.location = (29.6923828125, -60.3717041015625)
	    math_054.location = (411.4599609375, -80.4647216796875)
	    math_052.location = (411.4599609375, -201.02288818359375)
	    combine_xyz_002.location = (592.29736328125, -40.2786865234375)
	    math_059.location = (592.29736328125, -281.39495849609375)
	    math_058.location = (592.29736328125, -241.20892333984375)
	    vector_rotate.location = (773.13427734375, -60.3717041015625)
	    math_057.location = (773.13427734375, -201.02288818359375)
	    group_input_007.location = (953.9716796875, -301.48797607421875)
	    combine_xyz.location = (953.9716796875, -201.02288818359375)
	    vector_math_014.location = (1134.808837890625, -221.11590576171875)
	    vector_math_013.location = (1335.739013671875, -140.7437744140625)
	    reroute_001.location = (-839.232666015625, -160.97679138183594)
	    reroute_003.location = (-839.232666015625, -281.5349426269531)
	    set_position.location = (-738.7674560546875, -241.348876953125)
	    set_position_001.location = (-738.7674560546875, -80.60469055175781)
	    normal.location = (30.2864990234375, -160.773193359375)
	    curve_tangent_2.location = (30.2864990234375, -100.494140625)
	    separate_xyz.location = (231.216796875, -221.05230712890625)
	    vector_math_001_1.location = (412.053955078125, -40.215087890625)
	    vector_math_003.location = (592.8912353515625, -40.215087890625)
	    vector_math_002.location = (412.053955078125, -180.86627197265625)
	    vector_math_009.location = (793.8214111328125, -40.215087890625)
	    vector_math_010.location = (592.8912353515625, -200.95928955078125)
	    vector_math_1.location = (231.216796875, -40.215087890625)
	    group_001_1.location = (743.9742431640625, -60.11541748046875)
	    evaluate_on_domain_002_1.location = (1105.648681640625, -40.02239990234375)
	    separate_xyz_001.location = (201.46240234375, -261.045654296875)
	    vector_math_011.location = (743.9742431640625, -140.487548828125)
	    vector_math_005.location = (563.136962890625, -140.487548828125)
	    vector_math_007.location = (382.2998046875, -120.39453125)
	    vector_math_008.location = (201.46240234375, -120.39453125)
	    evaluate_at_index_1.location = (924.8114013671875, -40.02239990234375)
	    vector_math_012.location = (563.136962890625, -301.231689453125)
	    vector_math_006.location = (382.2998046875, -261.045654296875)
	    evaluate_on_domain_001_1.location = (29.70654296875, -339.79510498046875)
	    curve_tangent_001.location = (29.70654296875, -118.77178955078125)
	    normal_001.location = (29.70654296875, -179.0509033203125)
	    reroute_014.location = (-3230.302490234375, 341.3487854003906)
	    reroute_015.location = (-3230.302490234375, 301.1627502441406)
	    reroute_013.location = (-3230.302490234375, 260.9767150878906)
	    reroute_012.location = (-3230.302490234375, 381.5348815917969)
	    is_viewport.location = (280.716064453125, -275.73028564453125)
	    switch.location = (461.55322265625, -235.54425048828125)
	    id_1.location = (29.55322265625, -205.40472412109375)
	    reroute_004.location = (1375.44677734375, -241.39447021484375)
	    reroute_002.location = (571.725830078125, -100.7432861328125)
	    join_geometry.location = (1074.0513916015625, -60.5572509765625)
	    set_id.location = (1274.981689453125, -60.5572509765625)
	    store_named_attribute.location = (1475.911865234375, -40.464202880859375)
	    math.location = (290.423583984375, -382.0456237792969)
	    group_input_002.location = (89.4931640625, -382.0456237792969)
	    group_input_004.location = (89.4931640625, -321.7665710449219)
	    capture_attribute_002.location = (843.28857421875, -131.15524291992188)
	    vector_math_004.location = (-2506.95361328125, -703.4884033203125)
	    group_input_003.location = (-2687.790771484375, -824.0465698242188)
	    random_value_001.location = (381.48486328125, -40.2786865234375)
	    capture_attribute.location = (224.854736328125, -51.218994140625)
	    duplicate_elements.location = (652.097900390625, -120.83633422851562)
	    join_geometry_001.location = (-130.127197265625, 53.59075927734375)
	    random_value.location = (1074.0513916015625, -161.02236938476562)
	    reroute_020.location = (-223.732666015625, -87.405517578125)
	    index.location = (-3431.232666015625, -100.69772338867188)
	    capture_attribute_001.location = (-3210.20947265625, 60.046478271484375)
	    switch_001.location = (-507.69775390625, -50.46514892578125)
	    group_1.location = (211.0927734375, -211.04656982421875)
	    group_input_001.location = (30.255859375, -331.604736328125)
	    group_input_005.location = (-738.7674560546875, -0.23260498046875)
	    random_value_004.location = (211.0927734375, -291.418701171875)
	
	    #Set dimensions
	    frame_002.width, frame_002.height = 1506.0, 383.0
	    frame_001.width, frame_001.height = 964.0, 370.0
	    frame_1.width, frame_1.height = 1276.0, 454.0
	    frame_004.width, frame_004.height = 1646.0, 464.0
	    frame_003.width, frame_003.height = 551.0, 488.0
	    reroute_016.width, reroute_016.height = 100.0, 100.0
	    reroute_017.width, reroute_017.height = 100.0, 100.0
	    reroute_019.width, reroute_019.height = 100.0, 100.0
	    reroute_018.width, reroute_018.height = 100.0, 100.0
	    group_input.width, group_input.height = 140.0, 100.0
	    group_output_3.width, group_output_3.height = 140.0, 100.0
	    separate_components.width, separate_components.height = 140.0, 100.0
	    math_053.width, math_053.height = 140.0, 100.0
	    math_055.width, math_055.height = 140.0, 100.0
	    math_056.width, math_056.height = 140.0, 100.0
	    group_input_006.width, group_input_006.height = 140.0, 100.0
	    separate_xyz_002.width, separate_xyz_002.height = 140.0, 100.0
	    math_054.width, math_054.height = 140.0, 100.0
	    math_052.width, math_052.height = 140.0, 100.0
	    combine_xyz_002.width, combine_xyz_002.height = 140.0, 100.0
	    math_059.width, math_059.height = 140.0, 100.0
	    math_058.width, math_058.height = 140.0, 100.0
	    vector_rotate.width, vector_rotate.height = 140.0, 100.0
	    math_057.width, math_057.height = 140.0, 100.0
	    group_input_007.width, group_input_007.height = 140.0, 100.0
	    combine_xyz.width, combine_xyz.height = 140.0, 100.0
	    vector_math_014.width, vector_math_014.height = 140.0, 100.0
	    vector_math_013.width, vector_math_013.height = 140.0, 100.0
	    reroute_001.width, reroute_001.height = 100.0, 100.0
	    reroute_003.width, reroute_003.height = 100.0, 100.0
	    set_position.width, set_position.height = 140.0, 100.0
	    set_position_001.width, set_position_001.height = 140.0, 100.0
	    normal.width, normal.height = 140.0, 100.0
	    curve_tangent_2.width, curve_tangent_2.height = 140.0, 100.0
	    separate_xyz.width, separate_xyz.height = 140.0, 100.0
	    vector_math_001_1.width, vector_math_001_1.height = 140.0, 100.0
	    vector_math_003.width, vector_math_003.height = 140.0, 100.0
	    vector_math_002.width, vector_math_002.height = 140.0, 100.0
	    vector_math_009.width, vector_math_009.height = 140.0, 100.0
	    vector_math_010.width, vector_math_010.height = 140.0, 100.0
	    vector_math_1.width, vector_math_1.height = 140.0, 100.0
	    group_001_1.width, group_001_1.height = 140.0, 100.0
	    evaluate_on_domain_002_1.width, evaluate_on_domain_002_1.height = 140.0, 100.0
	    separate_xyz_001.width, separate_xyz_001.height = 140.0, 100.0
	    vector_math_011.width, vector_math_011.height = 140.0, 100.0
	    vector_math_005.width, vector_math_005.height = 140.0, 100.0
	    vector_math_007.width, vector_math_007.height = 140.0, 100.0
	    vector_math_008.width, vector_math_008.height = 140.0, 100.0
	    evaluate_at_index_1.width, evaluate_at_index_1.height = 140.0, 100.0
	    vector_math_012.width, vector_math_012.height = 140.0, 100.0
	    vector_math_006.width, vector_math_006.height = 140.0, 100.0
	    evaluate_on_domain_001_1.width, evaluate_on_domain_001_1.height = 140.0, 100.0
	    curve_tangent_001.width, curve_tangent_001.height = 140.0, 100.0
	    normal_001.width, normal_001.height = 140.0, 100.0
	    reroute_014.width, reroute_014.height = 100.0, 100.0
	    reroute_015.width, reroute_015.height = 100.0, 100.0
	    reroute_013.width, reroute_013.height = 100.0, 100.0
	    reroute_012.width, reroute_012.height = 100.0, 100.0
	    is_viewport.width, is_viewport.height = 140.0, 100.0
	    switch.width, switch.height = 140.0, 100.0
	    id_1.width, id_1.height = 140.0, 100.0
	    reroute_004.width, reroute_004.height = 100.0, 100.0
	    reroute_002.width, reroute_002.height = 100.0, 100.0
	    join_geometry.width, join_geometry.height = 140.0, 100.0
	    set_id.width, set_id.height = 140.0, 100.0
	    store_named_attribute.width, store_named_attribute.height = 140.0, 100.0
	    math.width, math.height = 140.0, 100.0
	    group_input_002.width, group_input_002.height = 140.0, 100.0
	    group_input_004.width, group_input_004.height = 140.0, 100.0
	    capture_attribute_002.width, capture_attribute_002.height = 140.0, 100.0
	    vector_math_004.width, vector_math_004.height = 140.0, 100.0
	    group_input_003.width, group_input_003.height = 140.0, 100.0
	    random_value_001.width, random_value_001.height = 140.0, 100.0
	    capture_attribute.width, capture_attribute.height = 140.0, 100.0
	    duplicate_elements.width, duplicate_elements.height = 140.0, 100.0
	    join_geometry_001.width, join_geometry_001.height = 140.0, 100.0
	    random_value.width, random_value.height = 140.0, 100.0
	    reroute_020.width, reroute_020.height = 100.0, 100.0
	    index.width, index.height = 140.0, 100.0
	    capture_attribute_001.width, capture_attribute_001.height = 140.0, 100.0
	    switch_001.width, switch_001.height = 140.0, 100.0
	    group_1.width, group_1.height = 140.0, 100.0
	    group_input_001.width, group_input_001.height = 140.0, 100.0
	    group_input_005.width, group_input_005.height = 140.0, 100.0
	    random_value_004.width, random_value_004.height = 140.0, 100.0
	
	    #initialize duplicate_hair_curves links
	    #join_geometry_001.Geometry -> group_output_3.Geometry
	    duplicate_hair_curves.links.new(join_geometry_001.outputs[0], group_output_3.inputs[0])
	    #reroute_002.Output -> duplicate_elements.Geometry
	    duplicate_hair_curves.links.new(reroute_002.outputs[0], duplicate_elements.inputs[0])
	    #capture_attribute_001.Geometry -> capture_attribute.Geometry
	    duplicate_hair_curves.links.new(capture_attribute_001.outputs[0], capture_attribute.inputs[0])
	    #random_value.Value -> set_id.ID
	    duplicate_hair_curves.links.new(random_value.outputs[2], set_id.inputs[2])
	    #capture_attribute.Value -> random_value.ID
	    duplicate_hair_curves.links.new(capture_attribute.outputs[1], random_value.inputs[7])
	    #duplicate_elements.Duplicate Index -> random_value.Seed
	    duplicate_hair_curves.links.new(duplicate_elements.outputs[1], random_value.inputs[8])
	    #random_value_001.Value -> separate_xyz_002.Vector
	    duplicate_hair_curves.links.new(random_value_001.outputs[0], separate_xyz_002.inputs[0])
	    #math_052.Value -> vector_rotate.Angle
	    duplicate_hair_curves.links.new(math_052.outputs[0], vector_rotate.inputs[3])
	    #combine_xyz_002.Vector -> vector_rotate.Vector
	    duplicate_hair_curves.links.new(combine_xyz_002.outputs[0], vector_rotate.inputs[0])
	    #separate_xyz_002.Y -> math_052.Value
	    duplicate_hair_curves.links.new(separate_xyz_002.outputs[1], math_052.inputs[0])
	    #separate_xyz_002.X -> math_053.Value
	    duplicate_hair_curves.links.new(separate_xyz_002.outputs[0], math_053.inputs[0])
	    #math_054.Value -> combine_xyz_002.X
	    duplicate_hair_curves.links.new(math_054.outputs[0], combine_xyz_002.inputs[0])
	    #group_1.Curve ID -> random_value_001.ID
	    duplicate_hair_curves.links.new(group_1.outputs[1], random_value_001.inputs[7])
	    #vector_math_004.Vector -> separate_xyz.Vector
	    duplicate_hair_curves.links.new(vector_math_004.outputs[0], separate_xyz.inputs[0])
	    #reroute_001.Output -> set_position.Geometry
	    duplicate_hair_curves.links.new(reroute_001.outputs[0], set_position.inputs[0])
	    #curve_tangent_2.Tangent -> vector_math_1.Vector
	    duplicate_hair_curves.links.new(curve_tangent_2.outputs[0], vector_math_1.inputs[0])
	    #normal.Normal -> vector_math_1.Vector
	    duplicate_hair_curves.links.new(normal.outputs[0], vector_math_1.inputs[1])
	    #vector_math_1.Vector -> vector_math_001_1.Vector
	    duplicate_hair_curves.links.new(vector_math_1.outputs[0], vector_math_001_1.inputs[0])
	    #vector_math_001_1.Vector -> vector_math_003.Vector
	    duplicate_hair_curves.links.new(vector_math_001_1.outputs[0], vector_math_003.inputs[0])
	    #vector_math_002.Vector -> vector_math_003.Vector
	    duplicate_hair_curves.links.new(vector_math_002.outputs[0], vector_math_003.inputs[1])
	    #separate_xyz.X -> vector_math_001_1.Scale
	    duplicate_hair_curves.links.new(separate_xyz.outputs[0], vector_math_001_1.inputs[3])
	    #separate_xyz.Y -> vector_math_002.Scale
	    duplicate_hair_curves.links.new(separate_xyz.outputs[1], vector_math_002.inputs[3])
	    #normal.Normal -> vector_math_002.Vector
	    duplicate_hair_curves.links.new(normal.outputs[0], vector_math_002.inputs[0])
	    #index.Index -> capture_attribute_001.Value
	    duplicate_hair_curves.links.new(index.outputs[0], capture_attribute_001.inputs[1])
	    #set_id.Geometry -> store_named_attribute.Geometry
	    duplicate_hair_curves.links.new(set_id.outputs[0], store_named_attribute.inputs[0])
	    #capture_attribute_002.Geometry -> join_geometry.Geometry
	    duplicate_hair_curves.links.new(capture_attribute_002.outputs[0], join_geometry.inputs[0])
	    #reroute_004.Output -> store_named_attribute.Value
	    duplicate_hair_curves.links.new(reroute_004.outputs[0], store_named_attribute.inputs[3])
	    #group_input_004.Amount -> switch.False
	    duplicate_hair_curves.links.new(group_input_004.outputs[1], switch.inputs[1])
	    #switch.Output -> duplicate_elements.Amount
	    duplicate_hair_curves.links.new(switch.outputs[0], duplicate_elements.inputs[2])
	    #is_viewport.Is Viewport -> switch.Switch
	    duplicate_hair_curves.links.new(is_viewport.outputs[0], switch.inputs[0])
	    #group_input_004.Amount -> math.Value
	    duplicate_hair_curves.links.new(group_input_004.outputs[1], math.inputs[0])
	    #math.Value -> switch.True
	    duplicate_hair_curves.links.new(math.outputs[0], switch.inputs[2])
	    #group_input_002.Viewport Amount -> math.Value
	    duplicate_hair_curves.links.new(group_input_002.outputs[2], math.inputs[1])
	    #id_1.ID -> capture_attribute.Value
	    duplicate_hair_curves.links.new(id_1.outputs[0], capture_attribute.inputs[1])
	    #vector_math_009.Vector -> set_position.Offset
	    duplicate_hair_curves.links.new(vector_math_009.outputs[0], set_position.inputs[3])
	    #group_input_005.Even Thickness -> switch_001.Switch
	    duplicate_hair_curves.links.new(group_input_005.outputs[6], switch_001.inputs[0])
	    #vector_math_007.Vector -> vector_math_005.Vector
	    duplicate_hair_curves.links.new(vector_math_007.outputs[0], vector_math_005.inputs[0])
	    #vector_math_006.Vector -> vector_math_005.Vector
	    duplicate_hair_curves.links.new(vector_math_006.outputs[0], vector_math_005.inputs[1])
	    #separate_xyz_001.X -> vector_math_007.Scale
	    duplicate_hair_curves.links.new(separate_xyz_001.outputs[0], vector_math_007.inputs[3])
	    #separate_xyz_001.Y -> vector_math_006.Scale
	    duplicate_hair_curves.links.new(separate_xyz_001.outputs[1], vector_math_006.inputs[3])
	    #evaluate_on_domain_002_1.Value -> set_position_001.Offset
	    duplicate_hair_curves.links.new(evaluate_on_domain_002_1.outputs[0], set_position_001.inputs[3])
	    #curve_tangent_001.Tangent -> vector_math_008.Vector
	    duplicate_hair_curves.links.new(curve_tangent_001.outputs[0], vector_math_008.inputs[0])
	    #normal_001.Normal -> vector_math_008.Vector
	    duplicate_hair_curves.links.new(normal_001.outputs[0], vector_math_008.inputs[1])
	    #evaluate_at_index_1.Value -> evaluate_on_domain_002_1.Value
	    duplicate_hair_curves.links.new(evaluate_at_index_1.outputs[0], evaluate_on_domain_002_1.inputs[0])
	    #vector_math_008.Vector -> vector_math_007.Vector
	    duplicate_hair_curves.links.new(vector_math_008.outputs[0], vector_math_007.inputs[0])
	    #normal_001.Normal -> vector_math_006.Vector
	    duplicate_hair_curves.links.new(normal_001.outputs[0], vector_math_006.inputs[0])
	    #evaluate_on_domain_001_1.Value -> separate_xyz_001.Vector
	    duplicate_hair_curves.links.new(evaluate_on_domain_001_1.outputs[0], separate_xyz_001.inputs[0])
	    #store_named_attribute.Geometry -> reroute_001.Input
	    duplicate_hair_curves.links.new(store_named_attribute.outputs[0], reroute_001.inputs[0])
	    #reroute_001.Output -> set_position_001.Geometry
	    duplicate_hair_curves.links.new(reroute_001.outputs[0], set_position_001.inputs[0])
	    #vector_math_011.Vector -> evaluate_at_index_1.Value
	    duplicate_hair_curves.links.new(vector_math_011.outputs[0], evaluate_at_index_1.inputs[1])
	    #group_001_1.Root Index -> evaluate_at_index_1.Index
	    duplicate_hair_curves.links.new(group_001_1.outputs[3], evaluate_at_index_1.inputs[0])
	    #capture_attribute.Geometry -> reroute_002.Input
	    duplicate_hair_curves.links.new(capture_attribute.outputs[0], reroute_002.inputs[0])
	    #math_055.Value -> math_054.Value
	    duplicate_hair_curves.links.new(math_055.outputs[0], math_054.inputs[0])
	    #math_053.Value -> math_055.Value
	    duplicate_hair_curves.links.new(math_053.outputs[0], math_055.inputs[0])
	    #math_056.Value -> math_054.Value
	    duplicate_hair_curves.links.new(math_056.outputs[0], math_054.inputs[1])
	    #group_input_006.Distribution Shape -> math_056.Value
	    duplicate_hair_curves.links.new(group_input_006.outputs[4], math_056.inputs[1])
	    #vector_math_003.Vector -> vector_math_009.Vector
	    duplicate_hair_curves.links.new(vector_math_003.outputs[0], vector_math_009.inputs[0])
	    #separate_xyz.Z -> vector_math_010.Scale
	    duplicate_hair_curves.links.new(separate_xyz.outputs[2], vector_math_010.inputs[3])
	    #curve_tangent_2.Tangent -> vector_math_010.Vector
	    duplicate_hair_curves.links.new(curve_tangent_2.outputs[0], vector_math_010.inputs[0])
	    #vector_math_010.Vector -> vector_math_009.Vector
	    duplicate_hair_curves.links.new(vector_math_010.outputs[0], vector_math_009.inputs[1])
	    #vector_math_005.Vector -> vector_math_011.Vector
	    duplicate_hair_curves.links.new(vector_math_005.outputs[0], vector_math_011.inputs[0])
	    #vector_math_012.Vector -> vector_math_011.Vector
	    duplicate_hair_curves.links.new(vector_math_012.outputs[0], vector_math_011.inputs[1])
	    #separate_xyz_001.Z -> vector_math_012.Scale
	    duplicate_hair_curves.links.new(separate_xyz_001.outputs[2], vector_math_012.inputs[3])
	    #curve_tangent_001.Tangent -> vector_math_012.Vector
	    duplicate_hair_curves.links.new(curve_tangent_001.outputs[0], vector_math_012.inputs[0])
	    #vector_rotate.Vector -> vector_math_013.Vector
	    duplicate_hair_curves.links.new(vector_rotate.outputs[0], vector_math_013.inputs[0])
	    #vector_math_014.Vector -> vector_math_013.Vector
	    duplicate_hair_curves.links.new(vector_math_014.outputs[0], vector_math_013.inputs[1])
	    #math_057.Value -> combine_xyz.Z
	    duplicate_hair_curves.links.new(math_057.outputs[0], combine_xyz.inputs[2])
	    #vector_math_013.Vector -> vector_math_004.Vector
	    duplicate_hair_curves.links.new(vector_math_013.outputs[0], vector_math_004.inputs[0])
	    #group_input_003.Radius -> vector_math_004.Scale
	    duplicate_hair_curves.links.new(group_input_003.outputs[3], vector_math_004.inputs[3])
	    #math_058.Value -> math_057.Value
	    duplicate_hair_curves.links.new(math_058.outputs[0], math_057.inputs[0])
	    #math_059.Value -> math_057.Value
	    duplicate_hair_curves.links.new(math_059.outputs[0], math_057.inputs[1])
	    #math_054.Value -> math_058.Value
	    duplicate_hair_curves.links.new(math_054.outputs[0], math_058.inputs[0])
	    #combine_xyz.Vector -> vector_math_014.Vector
	    duplicate_hair_curves.links.new(combine_xyz.outputs[0], vector_math_014.inputs[0])
	    #group_input_007.Tip Roundness -> vector_math_014.Scale
	    duplicate_hair_curves.links.new(group_input_007.outputs[5], vector_math_014.inputs[3])
	    #separate_xyz_002.Z -> math_059.Value
	    duplicate_hair_curves.links.new(separate_xyz_002.outputs[2], math_059.inputs[0])
	    #set_position_001.Geometry -> switch_001.False
	    duplicate_hair_curves.links.new(set_position_001.outputs[0], switch_001.inputs[1])
	    #set_position.Geometry -> switch_001.True
	    duplicate_hair_curves.links.new(set_position.outputs[0], switch_001.inputs[2])
	    #reroute_003.Output -> set_position.Selection
	    duplicate_hair_curves.links.new(reroute_003.outputs[0], set_position.inputs[1])
	    #reroute_003.Output -> set_position_001.Selection
	    duplicate_hair_curves.links.new(reroute_003.outputs[0], set_position_001.inputs[1])
	    #capture_attribute_002.Value -> reroute_003.Input
	    duplicate_hair_curves.links.new(capture_attribute_002.outputs[1], reroute_003.inputs[0])
	    #capture_attribute_001.Value -> reroute_004.Input
	    duplicate_hair_curves.links.new(capture_attribute_001.outputs[1], reroute_004.inputs[0])
	    #join_geometry.Geometry -> set_id.Geometry
	    duplicate_hair_curves.links.new(join_geometry.outputs[0], set_id.inputs[0])
	    #duplicate_elements.Geometry -> capture_attribute_002.Geometry
	    duplicate_hair_curves.links.new(duplicate_elements.outputs[0], capture_attribute_002.inputs[0])
	    #group_input_001.Seed -> random_value_004.ID
	    duplicate_hair_curves.links.new(group_input_001.outputs[7], random_value_004.inputs[7])
	    #random_value_004.Value -> random_value_001.Seed
	    duplicate_hair_curves.links.new(random_value_004.outputs[2], random_value_001.inputs[8])
	    #vector_math_004.Vector -> evaluate_on_domain_001_1.Value
	    duplicate_hair_curves.links.new(vector_math_004.outputs[0], evaluate_on_domain_001_1.inputs[0])
	    #reroute_018.Output -> join_geometry_001.Geometry
	    duplicate_hair_curves.links.new(reroute_018.outputs[0], join_geometry_001.inputs[0])
	    #separate_components.Mesh -> reroute_012.Input
	    duplicate_hair_curves.links.new(separate_components.outputs[0], reroute_012.inputs[0])
	    #separate_components.Instances -> reroute_013.Input
	    duplicate_hair_curves.links.new(separate_components.outputs[5], reroute_013.inputs[0])
	    #separate_components.Point Cloud -> reroute_014.Input
	    duplicate_hair_curves.links.new(separate_components.outputs[3], reroute_014.inputs[0])
	    #separate_components.Volume -> reroute_015.Input
	    duplicate_hair_curves.links.new(separate_components.outputs[4], reroute_015.inputs[0])
	    #reroute_012.Output -> reroute_016.Input
	    duplicate_hair_curves.links.new(reroute_012.outputs[0], reroute_016.inputs[0])
	    #reroute_014.Output -> reroute_017.Input
	    duplicate_hair_curves.links.new(reroute_014.outputs[0], reroute_017.inputs[0])
	    #reroute_013.Output -> reroute_018.Input
	    duplicate_hair_curves.links.new(reroute_013.outputs[0], reroute_018.inputs[0])
	    #reroute_015.Output -> reroute_019.Input
	    duplicate_hair_curves.links.new(reroute_015.outputs[0], reroute_019.inputs[0])
	    #switch_001.Output -> reroute_020.Input
	    duplicate_hair_curves.links.new(switch_001.outputs[0], reroute_020.inputs[0])
	    #group_input.Geometry -> separate_components.Geometry
	    duplicate_hair_curves.links.new(group_input.outputs[0], separate_components.inputs[0])
	    #separate_components.Curve -> capture_attribute_001.Geometry
	    duplicate_hair_curves.links.new(separate_components.outputs[1], capture_attribute_001.inputs[0])
	    #reroute_004.Output -> group_output_3.Guide Index
	    duplicate_hair_curves.links.new(reroute_004.outputs[0], group_output_3.inputs[1])
	    #reroute_002.Output -> join_geometry.Geometry
	    duplicate_hair_curves.links.new(reroute_002.outputs[0], join_geometry.inputs[0])
	    #reroute_019.Output -> join_geometry_001.Geometry
	    duplicate_hair_curves.links.new(reroute_019.outputs[0], join_geometry_001.inputs[0])
	    #reroute_020.Output -> join_geometry_001.Geometry
	    duplicate_hair_curves.links.new(reroute_020.outputs[0], join_geometry_001.inputs[0])
	    #reroute_017.Output -> join_geometry_001.Geometry
	    duplicate_hair_curves.links.new(reroute_017.outputs[0], join_geometry_001.inputs[0])
	    #reroute_016.Output -> join_geometry_001.Geometry
	    duplicate_hair_curves.links.new(reroute_016.outputs[0], join_geometry_001.inputs[0])
	    return duplicate_hair_curves
	
	duplicate_hair_curves = duplicate_hair_curves_node_group()
	
	#initialize curve_segment node group
	def curve_segment_node_group():
	    curve_segment = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Curve Segment")
	
	    curve_segment.color_tag = 'NONE'
	    curve_segment.description = "Reads information each point's previous curve segment"
	    curve_segment.default_group_node_width = 140
	    
	
	
	    #curve_segment interface
	    #Socket Segment Length
	    segment_length_socket = curve_segment.interface.new_socket(name = "Segment Length", in_out='OUTPUT', socket_type = 'NodeSocketFloat')
	    segment_length_socket.default_value = 0.0
	    segment_length_socket.min_value = -3.4028234663852886e+38
	    segment_length_socket.max_value = 3.4028234663852886e+38
	    segment_length_socket.subtype = 'NONE'
	    segment_length_socket.attribute_domain = 'POINT'
	    segment_length_socket.description = "Distance to previous point on curve"
	
	    #Socket Segment Direction
	    segment_direction_socket = curve_segment.interface.new_socket(name = "Segment Direction", in_out='OUTPUT', socket_type = 'NodeSocketVector')
	    segment_direction_socket.default_value = (0.0, 0.0, 0.0)
	    segment_direction_socket.min_value = -3.4028234663852886e+38
	    segment_direction_socket.max_value = 3.4028234663852886e+38
	    segment_direction_socket.subtype = 'NONE'
	    segment_direction_socket.attribute_domain = 'POINT'
	    segment_direction_socket.description = "Direction from previous neighboring point on segment"
	
	    #Socket Neighbor Index
	    neighbor_index_socket = curve_segment.interface.new_socket(name = "Neighbor Index", in_out='OUTPUT', socket_type = 'NodeSocketInt')
	    neighbor_index_socket.default_value = 0
	    neighbor_index_socket.min_value = -2147483648
	    neighbor_index_socket.max_value = 2147483647
	    neighbor_index_socket.subtype = 'NONE'
	    neighbor_index_socket.attribute_domain = 'POINT'
	    neighbor_index_socket.description = "Index of previous neighboring point on segment"
	
	
	    #initialize curve_segment nodes
	    #node Vector Math.009
	    vector_math_009_1 = curve_segment.nodes.new("ShaderNodeVectorMath")
	    vector_math_009_1.name = "Vector Math.009"
	    vector_math_009_1.operation = 'NORMALIZE'
	
	    #node Reroute.015
	    reroute_015_1 = curve_segment.nodes.new("NodeReroute")
	    reroute_015_1.name = "Reroute.015"
	    reroute_015_1.socket_idname = "NodeSocketVector"
	    #node Reroute.017
	    reroute_017_1 = curve_segment.nodes.new("NodeReroute")
	    reroute_017_1.name = "Reroute.017"
	    reroute_017_1.socket_idname = "NodeSocketVector"
	    #node Field at Index.001
	    field_at_index_001 = curve_segment.nodes.new("GeometryNodeFieldAtIndex")
	    field_at_index_001.name = "Field at Index.001"
	    field_at_index_001.data_type = 'FLOAT_VECTOR'
	    field_at_index_001.domain = 'POINT'
	
	    #node Vector Math.008
	    vector_math_008_1 = curve_segment.nodes.new("ShaderNodeVectorMath")
	    vector_math_008_1.name = "Vector Math.008"
	    vector_math_008_1.operation = 'SUBTRACT'
	
	    #node Reroute.018
	    reroute_018_1 = curve_segment.nodes.new("NodeReroute")
	    reroute_018_1.name = "Reroute.018"
	    reroute_018_1.socket_idname = "NodeSocketInt"
	    #node Interpolate Domain.002
	    interpolate_domain_002_2 = curve_segment.nodes.new("GeometryNodeFieldOnDomain")
	    interpolate_domain_002_2.name = "Interpolate Domain.002"
	    interpolate_domain_002_2.data_type = 'FLOAT_VECTOR'
	    interpolate_domain_002_2.domain = 'POINT'
	
	    #node Group Output
	    group_output_4 = curve_segment.nodes.new("NodeGroupOutput")
	    group_output_4.name = "Group Output"
	    group_output_4.is_active_output = True
	
	    #node Vector Math.007
	    vector_math_007_1 = curve_segment.nodes.new("ShaderNodeVectorMath")
	    vector_math_007_1.name = "Vector Math.007"
	    vector_math_007_1.operation = 'LENGTH'
	
	    #node Interpolate Domain.003
	    interpolate_domain_003 = curve_segment.nodes.new("GeometryNodeFieldOnDomain")
	    interpolate_domain_003.name = "Interpolate Domain.003"
	    interpolate_domain_003.data_type = 'INT'
	    interpolate_domain_003.domain = 'POINT'
	
	    #node Reroute
	    reroute_1 = curve_segment.nodes.new("NodeReroute")
	    reroute_1.name = "Reroute"
	    reroute_1.socket_idname = "NodeSocketBool"
	    #node Switch.004
	    switch_004 = curve_segment.nodes.new("GeometryNodeSwitch")
	    switch_004.name = "Switch.004"
	    switch_004.hide = True
	    switch_004.input_type = 'VECTOR'
	    #False
	    switch_004.inputs[1].default_value = (0.0, 0.0, 0.0)
	
	    #node Switch.003
	    switch_003 = curve_segment.nodes.new("GeometryNodeSwitch")
	    switch_003.name = "Switch.003"
	    switch_003.hide = True
	    switch_003.input_type = 'FLOAT'
	    #False
	    switch_003.inputs[1].default_value = 0.0
	
	    #node Boolean
	    boolean = curve_segment.nodes.new("FunctionNodeInputBool")
	    boolean.name = "Boolean"
	    boolean.boolean = True
	
	    #node Interpolate Domain
	    interpolate_domain_2 = curve_segment.nodes.new("GeometryNodeFieldOnDomain")
	    interpolate_domain_2.name = "Interpolate Domain"
	    interpolate_domain_2.data_type = 'BOOLEAN'
	    interpolate_domain_2.domain = 'CURVE'
	
	    #node Switch.005
	    switch_005 = curve_segment.nodes.new("GeometryNodeSwitch")
	    switch_005.name = "Switch.005"
	    switch_005.hide = True
	    switch_005.input_type = 'INT'
	    #False
	    switch_005.inputs[1].default_value = 0
	
	    #node Index.002
	    index_002 = curve_segment.nodes.new("GeometryNodeInputIndex")
	    index_002.name = "Index.002"
	
	    #node Switch.001
	    switch_001_1 = curve_segment.nodes.new("GeometryNodeSwitch")
	    switch_001_1.name = "Switch.001"
	    switch_001_1.input_type = 'INT'
	
	    #node Offset Point in Curve
	    offset_point_in_curve = curve_segment.nodes.new("GeometryNodeOffsetPointInCurve")
	    offset_point_in_curve.name = "Offset Point in Curve"
	    #Point Index
	    offset_point_in_curve.inputs[0].default_value = 0
	    #Offset
	    offset_point_in_curve.inputs[1].default_value = -1
	
	    #node Position.002
	    position_002_2 = curve_segment.nodes.new("GeometryNodeInputPosition")
	    position_002_2.name = "Position.002"
	
	
	
	
	
	    #Set locations
	    vector_math_009_1.location = (-389.8524169921875, 30.443286895751953)
	    reroute_015_1.location = (-456.8948974609375, 4.604297637939453)
	    reroute_017_1.location = (-1012.7362060546875, -9.742748260498047)
	    field_at_index_001.location = (-992.6431884765625, 70.62931823730469)
	    vector_math_008_1.location = (-811.805908203125, 70.62931823730469)
	    reroute_018_1.location = (-1032.8292236328125, 110.81541442871094)
	    interpolate_domain_002_2.location = (-630.9686279296875, 70.62931823730469)
	    group_output_4.location = (75.0, 50.0)
	    vector_math_007_1.location = (-389.8524169921875, 151.00144958496094)
	    interpolate_domain_003.location = (-390.85833740234375, -97.25408935546875)
	    reroute_1.location = (-342.979248046875, 193.345458984375)
	    switch_004.location = (-178.8756103515625, 10.35025405883789)
	    switch_003.location = (-178.8756103515625, 90.72234344482422)
	    boolean.location = (-781.6663208007812, 291.652587890625)
	    interpolate_domain_2.location = (-600.8291015625, 311.74560546875)
	    switch_005.location = (-178.8756103515625, -70.0218505859375)
	    index_002.location = (-1404.550048828125, 211.28048706054688)
	    switch_001_1.location = (-1223.712890625, 231.37350463867188)
	    offset_point_in_curve.location = (-1404.550048828125, 151.0014190673828)
	    position_002_2.location = (-1223.712890625, 30.44327163696289)
	
	    #Set dimensions
	    vector_math_009_1.width, vector_math_009_1.height = 140.0, 100.0
	    reroute_015_1.width, reroute_015_1.height = 100.0, 100.0
	    reroute_017_1.width, reroute_017_1.height = 100.0, 100.0
	    field_at_index_001.width, field_at_index_001.height = 140.0, 100.0
	    vector_math_008_1.width, vector_math_008_1.height = 140.0, 100.0
	    reroute_018_1.width, reroute_018_1.height = 100.0, 100.0
	    interpolate_domain_002_2.width, interpolate_domain_002_2.height = 140.0, 100.0
	    group_output_4.width, group_output_4.height = 140.0, 100.0
	    vector_math_007_1.width, vector_math_007_1.height = 140.0, 100.0
	    interpolate_domain_003.width, interpolate_domain_003.height = 140.0, 100.0
	    reroute_1.width, reroute_1.height = 100.0, 100.0
	    switch_004.width, switch_004.height = 140.0, 100.0
	    switch_003.width, switch_003.height = 140.0, 100.0
	    boolean.width, boolean.height = 140.0, 100.0
	    interpolate_domain_2.width, interpolate_domain_2.height = 140.0, 100.0
	    switch_005.width, switch_005.height = 140.0, 100.0
	    index_002.width, index_002.height = 140.0, 100.0
	    switch_001_1.width, switch_001_1.height = 140.0, 100.0
	    offset_point_in_curve.width, offset_point_in_curve.height = 140.0, 100.0
	    position_002_2.width, position_002_2.height = 140.0, 100.0
	
	    #initialize curve_segment links
	    #reroute_015_1.Output -> vector_math_007_1.Vector
	    curve_segment.links.new(reroute_015_1.outputs[0], vector_math_007_1.inputs[0])
	    #reroute_018_1.Output -> field_at_index_001.Index
	    curve_segment.links.new(reroute_018_1.outputs[0], field_at_index_001.inputs[0])
	    #vector_math_008_1.Vector -> interpolate_domain_002_2.Value
	    curve_segment.links.new(vector_math_008_1.outputs[0], interpolate_domain_002_2.inputs[0])
	    #reroute_017_1.Output -> vector_math_008_1.Vector
	    curve_segment.links.new(reroute_017_1.outputs[0], vector_math_008_1.inputs[0])
	    #reroute_015_1.Output -> vector_math_009_1.Vector
	    curve_segment.links.new(reroute_015_1.outputs[0], vector_math_009_1.inputs[0])
	    #reroute_017_1.Output -> field_at_index_001.Value
	    curve_segment.links.new(reroute_017_1.outputs[0], field_at_index_001.inputs[1])
	    #field_at_index_001.Value -> vector_math_008_1.Vector
	    curve_segment.links.new(field_at_index_001.outputs[0], vector_math_008_1.inputs[1])
	    #position_002_2.Position -> reroute_017_1.Input
	    curve_segment.links.new(position_002_2.outputs[0], reroute_017_1.inputs[0])
	    #interpolate_domain_002_2.Value -> reroute_015_1.Input
	    curve_segment.links.new(interpolate_domain_002_2.outputs[0], reroute_015_1.inputs[0])
	    #switch_004.Output -> group_output_4.Segment Direction
	    curve_segment.links.new(switch_004.outputs[0], group_output_4.inputs[1])
	    #switch_005.Output -> group_output_4.Neighbor Index
	    curve_segment.links.new(switch_005.outputs[0], group_output_4.inputs[2])
	    #boolean.Boolean -> interpolate_domain_2.Value
	    curve_segment.links.new(boolean.outputs[0], interpolate_domain_2.inputs[0])
	    #reroute_018_1.Output -> interpolate_domain_003.Value
	    curve_segment.links.new(reroute_018_1.outputs[0], interpolate_domain_003.inputs[0])
	    #vector_math_007_1.Value -> switch_003.True
	    curve_segment.links.new(vector_math_007_1.outputs[1], switch_003.inputs[2])
	    #reroute_1.Output -> switch_003.Switch
	    curve_segment.links.new(reroute_1.outputs[0], switch_003.inputs[0])
	    #switch_003.Output -> group_output_4.Segment Length
	    curve_segment.links.new(switch_003.outputs[0], group_output_4.inputs[0])
	    #vector_math_009_1.Vector -> switch_004.True
	    curve_segment.links.new(vector_math_009_1.outputs[0], switch_004.inputs[2])
	    #interpolate_domain_2.Value -> reroute_1.Input
	    curve_segment.links.new(interpolate_domain_2.outputs[0], reroute_1.inputs[0])
	    #reroute_1.Output -> switch_004.Switch
	    curve_segment.links.new(reroute_1.outputs[0], switch_004.inputs[0])
	    #interpolate_domain_003.Value -> switch_005.True
	    curve_segment.links.new(interpolate_domain_003.outputs[0], switch_005.inputs[2])
	    #reroute_1.Output -> switch_005.Switch
	    curve_segment.links.new(reroute_1.outputs[0], switch_005.inputs[0])
	    #offset_point_in_curve.Is Valid Offset -> switch_001_1.Switch
	    curve_segment.links.new(offset_point_in_curve.outputs[0], switch_001_1.inputs[0])
	    #offset_point_in_curve.Point Index -> switch_001_1.True
	    curve_segment.links.new(offset_point_in_curve.outputs[1], switch_001_1.inputs[2])
	    #index_002.Index -> switch_001_1.False
	    curve_segment.links.new(index_002.outputs[0], switch_001_1.inputs[1])
	    #switch_001_1.Output -> reroute_018_1.Input
	    curve_segment.links.new(switch_001_1.outputs[0], reroute_018_1.inputs[0])
	    return curve_segment
	
	curve_segment = curve_segment_node_group()
	
	#initialize curve_root node group
	def curve_root_node_group():
	    curve_root = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Curve Root")
	
	    curve_root.color_tag = 'INPUT'
	    curve_root.description = "Reads information about each curve's root point"
	    curve_root.default_group_node_width = 140
	    
	
	
	    #curve_root interface
	    #Socket Root Selection
	    root_selection_socket_1 = curve_root.interface.new_socket(name = "Root Selection", in_out='OUTPUT', socket_type = 'NodeSocketBool')
	    root_selection_socket_1.default_value = False
	    root_selection_socket_1.attribute_domain = 'POINT'
	    root_selection_socket_1.description = "Boolean selection of curve root points"
	
	    #Socket Root Position
	    root_position_socket_1 = curve_root.interface.new_socket(name = "Root Position", in_out='OUTPUT', socket_type = 'NodeSocketVector')
	    root_position_socket_1.default_value = (0.0, 0.0, 0.0)
	    root_position_socket_1.min_value = -3.4028234663852886e+38
	    root_position_socket_1.max_value = 3.4028234663852886e+38
	    root_position_socket_1.subtype = 'NONE'
	    root_position_socket_1.attribute_domain = 'CURVE'
	    root_position_socket_1.description = "Position of the root point of a curve"
	
	    #Socket Root Direction
	    root_direction_socket_1 = curve_root.interface.new_socket(name = "Root Direction", in_out='OUTPUT', socket_type = 'NodeSocketVector')
	    root_direction_socket_1.default_value = (0.0, 0.0, 0.0)
	    root_direction_socket_1.min_value = -3.4028234663852886e+38
	    root_direction_socket_1.max_value = 3.4028234663852886e+38
	    root_direction_socket_1.subtype = 'NONE'
	    root_direction_socket_1.attribute_domain = 'CURVE'
	    root_direction_socket_1.description = "Direction of the root segment of a curve"
	
	    #Socket Root Index
	    root_index_socket_1 = curve_root.interface.new_socket(name = "Root Index", in_out='OUTPUT', socket_type = 'NodeSocketInt')
	    root_index_socket_1.default_value = 0
	    root_index_socket_1.min_value = -2147483648
	    root_index_socket_1.max_value = 2147483647
	    root_index_socket_1.subtype = 'NONE'
	    root_index_socket_1.attribute_domain = 'CURVE'
	    root_index_socket_1.description = "Index of the root point of a curve"
	
	
	    #initialize curve_root nodes
	    #node Position.002
	    position_002_3 = curve_root.nodes.new("GeometryNodeInputPosition")
	    position_002_3.name = "Position.002"
	
	    #node Interpolate Domain
	    interpolate_domain_3 = curve_root.nodes.new("GeometryNodeFieldOnDomain")
	    interpolate_domain_3.name = "Interpolate Domain"
	    interpolate_domain_3.data_type = 'INT'
	    interpolate_domain_3.domain = 'CURVE'
	
	    #node Field at Index.003
	    field_at_index_003_2 = curve_root.nodes.new("GeometryNodeFieldAtIndex")
	    field_at_index_003_2.name = "Field at Index.003"
	    field_at_index_003_2.data_type = 'FLOAT_VECTOR'
	    field_at_index_003_2.domain = 'POINT'
	
	    #node Interpolate Domain.001
	    interpolate_domain_001_2 = curve_root.nodes.new("GeometryNodeFieldOnDomain")
	    interpolate_domain_001_2.name = "Interpolate Domain.001"
	    interpolate_domain_001_2.data_type = 'FLOAT_VECTOR'
	    interpolate_domain_001_2.domain = 'CURVE'
	
	    #node Curve Tangent
	    curve_tangent_3 = curve_root.nodes.new("GeometryNodeInputTangent")
	    curve_tangent_3.name = "Curve Tangent"
	
	    #node Endpoint Selection
	    endpoint_selection_2 = curve_root.nodes.new("GeometryNodeCurveEndpointSelection")
	    endpoint_selection_2.name = "Endpoint Selection"
	    #Start Size
	    endpoint_selection_2.inputs[0].default_value = 1
	    #End Size
	    endpoint_selection_2.inputs[1].default_value = 0
	
	    #node Field at Index.004
	    field_at_index_004_2 = curve_root.nodes.new("GeometryNodeFieldAtIndex")
	    field_at_index_004_2.name = "Field at Index.004"
	    field_at_index_004_2.data_type = 'FLOAT_VECTOR'
	    field_at_index_004_2.domain = 'POINT'
	
	    #node Interpolate Domain.002
	    interpolate_domain_002_3 = curve_root.nodes.new("GeometryNodeFieldOnDomain")
	    interpolate_domain_002_3.name = "Interpolate Domain.002"
	    interpolate_domain_002_3.data_type = 'FLOAT_VECTOR'
	    interpolate_domain_002_3.domain = 'CURVE'
	
	    #node Group Output
	    group_output_5 = curve_root.nodes.new("NodeGroupOutput")
	    group_output_5.name = "Group Output"
	    group_output_5.is_active_output = True
	
	    #node Points of Curve
	    points_of_curve_2 = curve_root.nodes.new("GeometryNodePointsOfCurve")
	    points_of_curve_2.name = "Points of Curve"
	    points_of_curve_2.inputs[0].hide = True
	    points_of_curve_2.inputs[1].hide = True
	    points_of_curve_2.outputs[1].hide = True
	    #Curve Index
	    points_of_curve_2.inputs[0].default_value = 0
	    #Weights
	    points_of_curve_2.inputs[1].default_value = 0.0
	    #Sort Index
	    points_of_curve_2.inputs[2].default_value = 0
	
	
	
	
	
	    #Set locations
	    position_002_3.location = (-608.1627807617188, -70.55814361572266)
	    interpolate_domain_3.location = (-608.1627807617188, 90.18604278564453)
	    field_at_index_003_2.location = (-407.2325439453125, 70.09302520751953)
	    interpolate_domain_001_2.location = (-206.30230712890625, 70.09302520751953)
	    curve_tangent_3.location = (-608.1627807617188, -271.4883728027344)
	    endpoint_selection_2.location = (-206.30230712890625, 190.65118408203125)
	    field_at_index_004_2.location = (-407.2325439453125, -130.83721923828125)
	    interpolate_domain_002_3.location = (-206.30230712890625, -130.83721923828125)
	    group_output_5.location = (75.0, 50.0)
	    points_of_curve_2.location = (-789.0, 50.0)
	
	    #Set dimensions
	    position_002_3.width, position_002_3.height = 140.0, 100.0
	    interpolate_domain_3.width, interpolate_domain_3.height = 140.0, 100.0
	    field_at_index_003_2.width, field_at_index_003_2.height = 140.0, 100.0
	    interpolate_domain_001_2.width, interpolate_domain_001_2.height = 140.0, 100.0
	    curve_tangent_3.width, curve_tangent_3.height = 140.0, 100.0
	    endpoint_selection_2.width, endpoint_selection_2.height = 140.0, 100.0
	    field_at_index_004_2.width, field_at_index_004_2.height = 140.0, 100.0
	    interpolate_domain_002_3.width, interpolate_domain_002_3.height = 140.0, 100.0
	    group_output_5.width, group_output_5.height = 140.0, 100.0
	    points_of_curve_2.width, points_of_curve_2.height = 140.0, 100.0
	
	    #initialize curve_root links
	    #position_002_3.Position -> field_at_index_003_2.Value
	    curve_root.links.new(position_002_3.outputs[0], field_at_index_003_2.inputs[1])
	    #interpolate_domain_001_2.Value -> group_output_5.Root Position
	    curve_root.links.new(interpolate_domain_001_2.outputs[0], group_output_5.inputs[1])
	    #interpolate_domain_3.Value -> field_at_index_003_2.Index
	    curve_root.links.new(interpolate_domain_3.outputs[0], field_at_index_003_2.inputs[0])
	    #points_of_curve_2.Point Index -> interpolate_domain_3.Value
	    curve_root.links.new(points_of_curve_2.outputs[0], interpolate_domain_3.inputs[0])
	    #interpolate_domain_3.Value -> group_output_5.Root Index
	    curve_root.links.new(interpolate_domain_3.outputs[0], group_output_5.inputs[3])
	    #endpoint_selection_2.Selection -> group_output_5.Root Selection
	    curve_root.links.new(endpoint_selection_2.outputs[0], group_output_5.inputs[0])
	    #field_at_index_003_2.Value -> interpolate_domain_001_2.Value
	    curve_root.links.new(field_at_index_003_2.outputs[0], interpolate_domain_001_2.inputs[0])
	    #interpolate_domain_002_3.Value -> group_output_5.Root Direction
	    curve_root.links.new(interpolate_domain_002_3.outputs[0], group_output_5.inputs[2])
	    #interpolate_domain_3.Value -> field_at_index_004_2.Index
	    curve_root.links.new(interpolate_domain_3.outputs[0], field_at_index_004_2.inputs[0])
	    #curve_tangent_3.Tangent -> field_at_index_004_2.Value
	    curve_root.links.new(curve_tangent_3.outputs[0], field_at_index_004_2.inputs[1])
	    #field_at_index_004_2.Value -> interpolate_domain_002_3.Value
	    curve_root.links.new(field_at_index_004_2.outputs[0], interpolate_domain_002_3.inputs[0])
	    return curve_root
	
	curve_root = curve_root_node_group()
	
	#initialize restore_curve_segment_length node group
	def restore_curve_segment_length_node_group():
	    restore_curve_segment_length = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Restore Curve Segment Length")
	
	    restore_curve_segment_length.color_tag = 'NONE'
	    restore_curve_segment_length.description = "Restores the length of each curve segment using a previous state after deformation"
	    restore_curve_segment_length.default_group_node_width = 140
	    
	
	    restore_curve_segment_length.is_modifier = True
	
	    #restore_curve_segment_length interface
	    #Socket Curves
	    curves_socket = restore_curve_segment_length.interface.new_socket(name = "Curves", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    curves_socket.attribute_domain = 'POINT'
	
	    #Socket Curves
	    curves_socket_1 = restore_curve_segment_length.interface.new_socket(name = "Curves", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    curves_socket_1.attribute_domain = 'POINT'
	
	    #Socket Selection
	    selection_socket = restore_curve_segment_length.interface.new_socket(name = "Selection", in_out='INPUT', socket_type = 'NodeSocketBool')
	    selection_socket.default_value = True
	    selection_socket.attribute_domain = 'POINT'
	    selection_socket.hide_value = True
	    selection_socket.description = "Only affect selected elements"
	
	    #Socket Factor
	    factor_socket = restore_curve_segment_length.interface.new_socket(name = "Factor", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    factor_socket.default_value = 1.0
	    factor_socket.min_value = 0.0
	    factor_socket.max_value = 1.0
	    factor_socket.subtype = 'FACTOR'
	    factor_socket.attribute_domain = 'POINT'
	    factor_socket.description = "Factor to blend overall effect"
	
	    #Socket Reference Position
	    reference_position_socket = restore_curve_segment_length.interface.new_socket(name = "Reference Position", in_out='INPUT', socket_type = 'NodeSocketVector')
	    reference_position_socket.default_value = (8.146539688110352, 4.969870090484619, 9.874540328979492)
	    reference_position_socket.min_value = -3.4028234663852886e+38
	    reference_position_socket.max_value = 3.4028234663852886e+38
	    reference_position_socket.subtype = 'NONE'
	    reference_position_socket.default_attribute_name = "rest_position"
	    reference_position_socket.attribute_domain = 'POINT'
	    reference_position_socket.hide_value = True
	    reference_position_socket.description = "Reference position before deformation"
	
	    #Socket Pin at Parameter
	    pin_at_parameter_socket = restore_curve_segment_length.interface.new_socket(name = "Pin at Parameter", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    pin_at_parameter_socket.default_value = 0.0
	    pin_at_parameter_socket.min_value = 0.0
	    pin_at_parameter_socket.max_value = 1.0
	    pin_at_parameter_socket.subtype = 'FACTOR'
	    pin_at_parameter_socket.attribute_domain = 'POINT'
	    pin_at_parameter_socket.description = "Pin each curve at a certain point for the operation"
	
	
	    #initialize restore_curve_segment_length nodes
	    #node Frame.001
	    frame_001_1 = restore_curve_segment_length.nodes.new("NodeFrame")
	    frame_001_1.label = "Pin at Parameter"
	    frame_001_1.name = "Frame.001"
	    frame_001_1.label_size = 20
	    frame_001_1.shrink = True
	
	    #node Frame
	    frame_2 = restore_curve_segment_length.nodes.new("NodeFrame")
	    frame_2.label = "Restore Segment Lengths"
	    frame_2.name = "Frame"
	    frame_2.label_size = 20
	    frame_2.shrink = True
	
	    #node Frame.002
	    frame_002_1 = restore_curve_segment_length.nodes.new("NodeFrame")
	    frame_002_1.label = "Default Fallback"
	    frame_002_1.name = "Frame.002"
	    frame_002_1.label_size = 20
	    frame_002_1.shrink = True
	
	    #node Reroute.009
	    reroute_009 = restore_curve_segment_length.nodes.new("NodeReroute")
	    reroute_009.name = "Reroute.009"
	    reroute_009.socket_idname = "NodeSocketVector"
	    #node Group Input.006
	    group_input_006_1 = restore_curve_segment_length.nodes.new("NodeGroupInput")
	    group_input_006_1.name = "Group Input.006"
	    group_input_006_1.outputs[0].hide = True
	    group_input_006_1.outputs[1].hide = True
	    group_input_006_1.outputs[2].hide = True
	    group_input_006_1.outputs[3].hide = True
	    group_input_006_1.outputs[5].hide = True
	
	    #node Reroute.013
	    reroute_013_1 = restore_curve_segment_length.nodes.new("NodeReroute")
	    reroute_013_1.name = "Reroute.013"
	    reroute_013_1.socket_idname = "NodeSocketGeometry"
	    #node Index
	    index_1 = restore_curve_segment_length.nodes.new("GeometryNodeInputIndex")
	    index_1.name = "Index"
	
	    #node Sample Curve.001
	    sample_curve_001 = restore_curve_segment_length.nodes.new("GeometryNodeSampleCurve")
	    sample_curve_001.name = "Sample Curve.001"
	    sample_curve_001.data_type = 'FLOAT_VECTOR'
	    sample_curve_001.mode = 'FACTOR'
	    sample_curve_001.use_all_curves = False
	
	    #node Group Input.003
	    group_input_003_1 = restore_curve_segment_length.nodes.new("NodeGroupInput")
	    group_input_003_1.name = "Group Input.003"
	    group_input_003_1.outputs[0].hide = True
	    group_input_003_1.outputs[1].hide = True
	    group_input_003_1.outputs[2].hide = True
	    group_input_003_1.outputs[3].hide = True
	    group_input_003_1.outputs[5].hide = True
	
	    #node Vector Math.006
	    vector_math_006_1 = restore_curve_segment_length.nodes.new("ShaderNodeVectorMath")
	    vector_math_006_1.name = "Vector Math.006"
	    vector_math_006_1.hide = True
	    vector_math_006_1.operation = 'SUBTRACT'
	
	    #node Interpolate Domain
	    interpolate_domain_4 = restore_curve_segment_length.nodes.new("GeometryNodeFieldOnDomain")
	    interpolate_domain_4.name = "Interpolate Domain"
	    interpolate_domain_4.hide = True
	    interpolate_domain_4.data_type = 'FLOAT_VECTOR'
	    interpolate_domain_4.domain = 'CURVE'
	
	    #node Group Input.005
	    group_input_005_1 = restore_curve_segment_length.nodes.new("NodeGroupInput")
	    group_input_005_1.name = "Group Input.005"
	    group_input_005_1.outputs[0].hide = True
	    group_input_005_1.outputs[2].hide = True
	    group_input_005_1.outputs[3].hide = True
	    group_input_005_1.outputs[4].hide = True
	    group_input_005_1.outputs[5].hide = True
	
	    #node Boolean Math.002
	    boolean_math_002 = restore_curve_segment_length.nodes.new("FunctionNodeBooleanMath")
	    boolean_math_002.name = "Boolean Math.002"
	    boolean_math_002.hide = True
	    boolean_math_002.operation = 'AND'
	
	    #node Field at Index.002
	    field_at_index_002 = restore_curve_segment_length.nodes.new("GeometryNodeFieldAtIndex")
	    field_at_index_002.name = "Field at Index.002"
	    field_at_index_002.data_type = 'FLOAT_VECTOR'
	    field_at_index_002.domain = 'POINT'
	
	    #node Vector Math.004
	    vector_math_004_1 = restore_curve_segment_length.nodes.new("ShaderNodeVectorMath")
	    vector_math_004_1.name = "Vector Math.004"
	    vector_math_004_1.operation = 'DISTANCE'
	
	    #node Accumulate Field
	    accumulate_field = restore_curve_segment_length.nodes.new("GeometryNodeAccumulateField")
	    accumulate_field.name = "Accumulate Field"
	    accumulate_field.data_type = 'FLOAT_VECTOR'
	    accumulate_field.domain = 'POINT'
	    accumulate_field.outputs[1].hide = True
	    accumulate_field.outputs[2].hide = True
	
	    #node Curve of Point
	    curve_of_point = restore_curve_segment_length.nodes.new("GeometryNodeCurveOfPoint")
	    curve_of_point.name = "Curve of Point"
	    curve_of_point.inputs[0].hide = True
	    curve_of_point.outputs[1].hide = True
	    #Point Index
	    curve_of_point.inputs[0].default_value = 0
	
	    #node Vector Math
	    vector_math_2 = restore_curve_segment_length.nodes.new("ShaderNodeVectorMath")
	    vector_math_2.name = "Vector Math"
	    vector_math_2.operation = 'SCALE'
	
	    #node Index.001
	    index_001_1 = restore_curve_segment_length.nodes.new("GeometryNodeInputIndex")
	    index_001_1.name = "Index.001"
	
	    #node Curve of Point.001
	    curve_of_point_001 = restore_curve_segment_length.nodes.new("GeometryNodeCurveOfPoint")
	    curve_of_point_001.name = "Curve of Point.001"
	    curve_of_point_001.inputs[0].hide = True
	    curve_of_point_001.outputs[0].hide = True
	    #Point Index
	    curve_of_point_001.inputs[0].default_value = 0
	
	    #node Switch
	    switch_1 = restore_curve_segment_length.nodes.new("GeometryNodeSwitch")
	    switch_1.name = "Switch"
	    switch_1.input_type = 'INT'
	
	    #node Math
	    math_1 = restore_curve_segment_length.nodes.new("ShaderNodeMath")
	    math_1.name = "Math"
	    math_1.hide = True
	    math_1.operation = 'SUBTRACT'
	    math_1.use_clamp = False
	    #Value_001
	    math_1.inputs[1].default_value = 1.0
	
	    #node Compare
	    compare = restore_curve_segment_length.nodes.new("FunctionNodeCompare")
	    compare.name = "Compare"
	    compare.hide = True
	    compare.data_type = 'INT'
	    compare.mode = 'ELEMENT'
	    compare.operation = 'EQUAL'
	    #B_INT
	    compare.inputs[3].default_value = 0
	
	    #node Reroute.001
	    reroute_001_1 = restore_curve_segment_length.nodes.new("NodeReroute")
	    reroute_001_1.name = "Reroute.001"
	    reroute_001_1.socket_idname = "NodeSocketVector"
	    #node Set Position.001
	    set_position_001_1 = restore_curve_segment_length.nodes.new("GeometryNodeSetPosition")
	    set_position_001_1.name = "Set Position.001"
	
	    #node Boolean Math
	    boolean_math = restore_curve_segment_length.nodes.new("FunctionNodeBooleanMath")
	    boolean_math.name = "Boolean Math"
	    boolean_math.operation = 'AND'
	
	    #node Compare.002
	    compare_002 = restore_curve_segment_length.nodes.new("FunctionNodeCompare")
	    compare_002.name = "Compare.002"
	    compare_002.data_type = 'FLOAT'
	    compare_002.mode = 'ELEMENT'
	    compare_002.operation = 'GREATER_THAN'
	    #B
	    compare_002.inputs[1].default_value = 0.0
	
	    #node Group Input.002
	    group_input_002_1 = restore_curve_segment_length.nodes.new("NodeGroupInput")
	    group_input_002_1.name = "Group Input.002"
	    group_input_002_1.outputs[0].hide = True
	    group_input_002_1.outputs[3].hide = True
	    group_input_002_1.outputs[4].hide = True
	    group_input_002_1.outputs[5].hide = True
	
	    #node Reroute.016
	    reroute_016_1 = restore_curve_segment_length.nodes.new("NodeReroute")
	    reroute_016_1.name = "Reroute.016"
	    reroute_016_1.socket_idname = "NodeSocketBool"
	    #node Reroute.014
	    reroute_014_1 = restore_curve_segment_length.nodes.new("NodeReroute")
	    reroute_014_1.name = "Reroute.014"
	    reroute_014_1.socket_idname = "NodeSocketGeometry"
	    #node Switch.001
	    switch_001_2 = restore_curve_segment_length.nodes.new("GeometryNodeSwitch")
	    switch_001_2.name = "Switch.001"
	    switch_001_2.input_type = 'GEOMETRY'
	
	    #node Group Output
	    group_output_6 = restore_curve_segment_length.nodes.new("NodeGroupOutput")
	    group_output_6.name = "Group Output"
	    group_output_6.is_active_output = True
	
	    #node Attribute Statistic
	    attribute_statistic = restore_curve_segment_length.nodes.new("GeometryNodeAttributeStatistic")
	    attribute_statistic.name = "Attribute Statistic"
	    attribute_statistic.hide = True
	    attribute_statistic.data_type = 'FLOAT'
	    attribute_statistic.domain = 'CURVE'
	    attribute_statistic.inputs[1].hide = True
	    attribute_statistic.outputs[0].hide = True
	    attribute_statistic.outputs[1].hide = True
	    attribute_statistic.outputs[2].hide = True
	    attribute_statistic.outputs[3].hide = True
	    attribute_statistic.outputs[5].hide = True
	    attribute_statistic.outputs[6].hide = True
	    attribute_statistic.outputs[7].hide = True
	    #Selection
	    attribute_statistic.inputs[1].default_value = True
	
	    #node Reroute.007
	    reroute_007 = restore_curve_segment_length.nodes.new("NodeReroute")
	    reroute_007.name = "Reroute.007"
	    reroute_007.socket_idname = "NodeSocketVector"
	    #node Reroute.004
	    reroute_004_1 = restore_curve_segment_length.nodes.new("NodeReroute")
	    reroute_004_1.name = "Reroute.004"
	    reroute_004_1.socket_idname = "NodeSocketGeometry"
	    #node Position.001
	    position_001 = restore_curve_segment_length.nodes.new("GeometryNodeInputPosition")
	    position_001.name = "Position.001"
	
	    #node Named Attribute
	    named_attribute_1 = restore_curve_segment_length.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute_1.name = "Named Attribute"
	    named_attribute_1.data_type = 'FLOAT_VECTOR'
	    #Name
	    named_attribute_1.inputs[0].default_value = "rest_position"
	
	    #node Switch.003
	    switch_003_1 = restore_curve_segment_length.nodes.new("GeometryNodeSwitch")
	    switch_003_1.name = "Switch.003"
	    switch_003_1.input_type = 'VECTOR'
	
	    #node Reroute.006
	    reroute_006 = restore_curve_segment_length.nodes.new("NodeReroute")
	    reroute_006.name = "Reroute.006"
	    reroute_006.socket_idname = "NodeSocketVector"
	    #node Switch.002
	    switch_002 = restore_curve_segment_length.nodes.new("GeometryNodeSwitch")
	    switch_002.name = "Switch.002"
	    switch_002.input_type = 'VECTOR'
	
	    #node Compare.004
	    compare_004 = restore_curve_segment_length.nodes.new("FunctionNodeCompare")
	    compare_004.name = "Compare.004"
	    compare_004.data_type = 'VECTOR'
	    compare_004.mode = 'ELEMENT'
	    compare_004.operation = 'EQUAL'
	    #B_VEC3
	    compare_004.inputs[5].default_value = (8.146539688110352, 4.969870090484619, 9.874540328979492)
	    #Epsilon
	    compare_004.inputs[12].default_value = 0.0
	
	    #node Group Input
	    group_input_1 = restore_curve_segment_length.nodes.new("NodeGroupInput")
	    group_input_1.name = "Group Input"
	    group_input_1.outputs[1].hide = True
	    group_input_1.outputs[2].hide = True
	    group_input_1.outputs[4].hide = True
	    group_input_1.outputs[5].hide = True
	
	    #node Reroute.011
	    reroute_011 = restore_curve_segment_length.nodes.new("NodeReroute")
	    reroute_011.name = "Reroute.011"
	    reroute_011.socket_idname = "NodeSocketGeometry"
	    #node Reroute.005
	    reroute_005 = restore_curve_segment_length.nodes.new("NodeReroute")
	    reroute_005.name = "Reroute.005"
	    reroute_005.socket_idname = "NodeSocketGeometry"
	    #node Reroute.008
	    reroute_008 = restore_curve_segment_length.nodes.new("NodeReroute")
	    reroute_008.name = "Reroute.008"
	    reroute_008.socket_idname = "NodeSocketVector"
	    #node Set Position.002
	    set_position_002 = restore_curve_segment_length.nodes.new("GeometryNodeSetPosition")
	    set_position_002.name = "Set Position.002"
	    set_position_002.inputs[2].hide = True
	    #Position
	    set_position_002.inputs[2].default_value = (0.0, 0.0, 0.0)
	
	    #node Reroute.012
	    reroute_012_1 = restore_curve_segment_length.nodes.new("NodeReroute")
	    reroute_012_1.name = "Reroute.012"
	    reroute_012_1.socket_idname = "NodeSocketGeometry"
	    #node Group Input.001
	    group_input_001_1 = restore_curve_segment_length.nodes.new("NodeGroupInput")
	    group_input_001_1.name = "Group Input.001"
	    group_input_001_1.outputs[0].hide = True
	    group_input_001_1.outputs[1].hide = True
	    group_input_001_1.outputs[3].hide = True
	    group_input_001_1.outputs[4].hide = True
	    group_input_001_1.outputs[5].hide = True
	
	    #node Mix
	    mix = restore_curve_segment_length.nodes.new("ShaderNodeMix")
	    mix.name = "Mix"
	    mix.blend_type = 'MIX'
	    mix.clamp_factor = True
	    mix.clamp_result = False
	    mix.data_type = 'FLOAT'
	    mix.factor_mode = 'UNIFORM'
	
	    #node Group.001
	    group_001_2 = restore_curve_segment_length.nodes.new("GeometryNodeGroup")
	    group_001_2.name = "Group.001"
	    group_001_2.node_tree = curve_segment
	    group_001_2.outputs[2].hide = True
	
	    #node Compare.003
	    compare_003 = restore_curve_segment_length.nodes.new("FunctionNodeCompare")
	    compare_003.name = "Compare.003"
	    compare_003.hide = True
	    compare_003.data_type = 'FLOAT'
	    compare_003.mode = 'ELEMENT'
	    compare_003.operation = 'NOT_EQUAL'
	    #B
	    compare_003.inputs[1].default_value = 0.0
	    #Epsilon
	    compare_003.inputs[12].default_value = 0.0
	
	    #node Compare.005
	    compare_005 = restore_curve_segment_length.nodes.new("FunctionNodeCompare")
	    compare_005.name = "Compare.005"
	    compare_005.hide = True
	    compare_005.data_type = 'FLOAT'
	    compare_005.mode = 'ELEMENT'
	    compare_005.operation = 'GREATER_THAN'
	    #B
	    compare_005.inputs[1].default_value = 0.0
	
	    #node Group.002
	    group_002_1 = restore_curve_segment_length.nodes.new("GeometryNodeGroup")
	    group_002_1.name = "Group.002"
	    group_002_1.node_tree = curve_root
	    group_002_1.outputs[0].hide = True
	    group_002_1.outputs[2].hide = True
	    group_002_1.outputs[3].hide = True
	
	
	
	
	    #Set parents
	    group_input_006_1.parent = frame_001_1
	    reroute_013_1.parent = frame_001_1
	    index_1.parent = frame_001_1
	    sample_curve_001.parent = frame_001_1
	    group_input_003_1.parent = frame_001_1
	    vector_math_006_1.parent = frame_001_1
	    interpolate_domain_4.parent = frame_001_1
	    group_input_005_1.parent = frame_001_1
	    boolean_math_002.parent = frame_001_1
	    field_at_index_002.parent = frame_2
	    vector_math_004_1.parent = frame_2
	    accumulate_field.parent = frame_2
	    curve_of_point.parent = frame_2
	    vector_math_2.parent = frame_2
	    index_001_1.parent = frame_2
	    curve_of_point_001.parent = frame_2
	    switch_1.parent = frame_2
	    math_1.parent = frame_2
	    compare.parent = frame_2
	    reroute_001_1.parent = frame_2
	    set_position_001_1.parent = frame_2
	    boolean_math.parent = frame_2
	    compare_002.parent = frame_2
	    group_input_002_1.parent = frame_2
	    reroute_016_1.parent = frame_001_1
	    reroute_014_1.parent = frame_001_1
	    switch_001_2.parent = frame_001_1
	    attribute_statistic.parent = frame_001_1
	    reroute_004_1.parent = frame_2
	    position_001.parent = frame_002_1
	    named_attribute_1.parent = frame_002_1
	    switch_003_1.parent = frame_002_1
	    reroute_006.parent = frame_002_1
	    switch_002.parent = frame_002_1
	    compare_004.parent = frame_002_1
	    reroute_005.parent = frame_2
	    set_position_002.parent = frame_001_1
	    reroute_012_1.parent = frame_001_1
	    group_input_001_1.parent = frame_2
	    mix.parent = frame_2
	    group_001_2.parent = frame_2
	    compare_003.parent = frame_001_1
	    compare_005.parent = frame_001_1
	    group_002_1.parent = frame_2
	
	    #Set locations
	    frame_001_1.location = (-1286.139892578125, 110.0)
	    frame_2.location = (-3491.0, 54.813934326171875)
	    frame_002_1.location = (-4464.1865234375, -101.0)
	    reroute_009.location = (-1431.9771728515625, -673.348876953125)
	    group_input_006_1.location = (215.837158203125, -140.37210083007812)
	    reroute_013_1.location = (175.651123046875, -120.2790756225586)
	    index_1.location = (35.0, -481.9534912109375)
	    sample_curve_001.location = (215.837158203125, -220.7441864013672)
	    group_input_003_1.location = (35.0, -421.6744384765625)
	    vector_math_006_1.location = (396.6744384765625, -260.93023681640625)
	    interpolate_domain_4.location = (577.5116577148438, -260.93023681640625)
	    group_input_005_1.location = (396.6744384765625, -180.5581512451172)
	    boolean_math_002.location = (577.5116577148438, -180.5581512451172)
	    field_at_index_002.location = (652.51123046875, -245.93023681640625)
	    vector_math_004_1.location = (833.348388671875, -225.83721923828125)
	    accumulate_field.location = (1556.697265625, -406.6744384765625)
	    curve_of_point.location = (1355.76708984375, -547.3255615234375)
	    vector_math_2.location = (1355.76708984375, -386.5813903808594)
	    index_001_1.location = (29.62744140625, -466.9534912109375)
	    curve_of_point_001.location = (29.62744140625, -386.5813903808594)
	    switch_1.location = (411.39501953125, -366.4883728027344)
	    math_1.location = (210.46484375, -466.9534912109375)
	    compare.location = (210.46484375, -426.7674560546875)
	    reroute_001_1.location = (612.3251953125, -306.20928955078125)
	    set_position_001_1.location = (1797.8135986328125, -145.46511840820312)
	    boolean_math.location = (1493.957763671875, -93.53775024414062)
	    compare_002.location = (1293.02783203125, -113.63077545166016)
	    group_input_002_1.location = (1112.19091796875, -133.7238006591797)
	    reroute_016_1.location = (798.534912109375, -160.46511840820312)
	    reroute_014_1.location = (798.534912109375, -120.2790756225586)
	    switch_001_2.location = (1079.837158203125, -39.906982421875)
	    group_output_6.location = (75.0, 50.0)
	    attribute_statistic.location = (858.81396484375, -60.0)
	    reroute_007.location = (-3762.76806640625, -251.3953857421875)
	    reroute_004_1.location = (1637.0693359375, -45.0)
	    position_001.location = (57.345703125, -240.45068359375)
	    named_attribute_1.location = (57.345703125, -300.729736328125)
	    switch_003_1.location = (238.1826171875, -220.357666015625)
	    reroute_006.location = (35.0, -71.92265319824219)
	    switch_002.location = (439.11279296875, -99.79951477050781)
	    compare_004.location = (57.34619140625, -39.52044677734375)
	    group_input_1.location = (-4707.1396484375, -30.37213134765625)
	    reroute_011.location = (-3581.9306640625, -70.55816650390625)
	    reroute_005.location = (49.720703125, -45.0)
	    reroute_008.location = (-3561.83740234375, -673.348876953125)
	    set_position_002.location = (858.81396484375, -140.37210083007812)
	    reroute_012_1.location = (35.0, -240.83721923828125)
	    group_input_001_1.location = (833.348388671875, -165.55813598632812)
	    mix.location = (1114.65087890625, -326.3023376464844)
	    group_001_2.location = (833.348388671875, -406.6744384765625)
	    compare_003.location = (396.6744384765625, -140.37210083007812)
	    compare_005.location = (858.81396484375, -100.18605041503906)
	    group_002_1.location = (1502.224365234375, -243.76693725585938)
	
	    #Set dimensions
	    frame_001_1.width, frame_001_1.height = 1250.139892578125, 562.0
	    frame_2.width, frame_2.height = 1968.0, 629.81396484375
	    frame_002_1.width, frame_002_1.height = 609.1865234375, 452.0
	    reroute_009.width, reroute_009.height = 10.0, 100.0
	    group_input_006_1.width, group_input_006_1.height = 140.0, 100.0
	    reroute_013_1.width, reroute_013_1.height = 10.0, 100.0
	    index_1.width, index_1.height = 140.0, 100.0
	    sample_curve_001.width, sample_curve_001.height = 140.0, 100.0
	    group_input_003_1.width, group_input_003_1.height = 140.0, 100.0
	    vector_math_006_1.width, vector_math_006_1.height = 140.0, 100.0
	    interpolate_domain_4.width, interpolate_domain_4.height = 140.0, 100.0
	    group_input_005_1.width, group_input_005_1.height = 140.0, 100.0
	    boolean_math_002.width, boolean_math_002.height = 140.0, 100.0
	    field_at_index_002.width, field_at_index_002.height = 140.0, 100.0
	    vector_math_004_1.width, vector_math_004_1.height = 140.0, 100.0
	    accumulate_field.width, accumulate_field.height = 140.0, 100.0
	    curve_of_point.width, curve_of_point.height = 140.0, 100.0
	    vector_math_2.width, vector_math_2.height = 140.0, 100.0
	    index_001_1.width, index_001_1.height = 140.0, 100.0
	    curve_of_point_001.width, curve_of_point_001.height = 140.0, 100.0
	    switch_1.width, switch_1.height = 140.0, 100.0
	    math_1.width, math_1.height = 140.0, 100.0
	    compare.width, compare.height = 140.0, 100.0
	    reroute_001_1.width, reroute_001_1.height = 10.0, 100.0
	    set_position_001_1.width, set_position_001_1.height = 140.0, 100.0
	    boolean_math.width, boolean_math.height = 140.0, 100.0
	    compare_002.width, compare_002.height = 140.0, 100.0
	    group_input_002_1.width, group_input_002_1.height = 140.0, 100.0
	    reroute_016_1.width, reroute_016_1.height = 10.0, 100.0
	    reroute_014_1.width, reroute_014_1.height = 10.0, 100.0
	    switch_001_2.width, switch_001_2.height = 140.0, 100.0
	    group_output_6.width, group_output_6.height = 140.0, 100.0
	    attribute_statistic.width, attribute_statistic.height = 140.0, 100.0
	    reroute_007.width, reroute_007.height = 10.0, 100.0
	    reroute_004_1.width, reroute_004_1.height = 10.0, 100.0
	    position_001.width, position_001.height = 140.0, 100.0
	    named_attribute_1.width, named_attribute_1.height = 140.0, 100.0
	    switch_003_1.width, switch_003_1.height = 140.0, 100.0
	    reroute_006.width, reroute_006.height = 10.0, 100.0
	    switch_002.width, switch_002.height = 140.0, 100.0
	    compare_004.width, compare_004.height = 140.0, 100.0
	    group_input_1.width, group_input_1.height = 140.0, 100.0
	    reroute_011.width, reroute_011.height = 10.0, 100.0
	    reroute_005.width, reroute_005.height = 10.0, 100.0
	    reroute_008.width, reroute_008.height = 10.0, 100.0
	    set_position_002.width, set_position_002.height = 140.0, 100.0
	    reroute_012_1.width, reroute_012_1.height = 10.0, 100.0
	    group_input_001_1.width, group_input_001_1.height = 140.0, 100.0
	    mix.width, mix.height = 140.0, 100.0
	    group_001_2.width, group_001_2.height = 140.0, 100.0
	    compare_003.width, compare_003.height = 140.0, 100.0
	    compare_005.width, compare_005.height = 140.0, 100.0
	    group_002_1.width, group_002_1.height = 140.0, 100.0
	
	    #initialize restore_curve_segment_length links
	    #reroute_004_1.Output -> set_position_001_1.Geometry
	    restore_curve_segment_length.links.new(reroute_004_1.outputs[0], set_position_001_1.inputs[0])
	    #curve_of_point.Curve Index -> accumulate_field.Group ID
	    restore_curve_segment_length.links.new(curve_of_point.outputs[0], accumulate_field.inputs[1])
	    #field_at_index_002.Value -> vector_math_004_1.Vector
	    restore_curve_segment_length.links.new(field_at_index_002.outputs[0], vector_math_004_1.inputs[0])
	    #reroute_001_1.Output -> vector_math_004_1.Vector
	    restore_curve_segment_length.links.new(reroute_001_1.outputs[0], vector_math_004_1.inputs[1])
	    #reroute_001_1.Output -> field_at_index_002.Value
	    restore_curve_segment_length.links.new(reroute_001_1.outputs[0], field_at_index_002.inputs[1])
	    #index_001_1.Index -> math_1.Value
	    restore_curve_segment_length.links.new(index_001_1.outputs[0], math_1.inputs[0])
	    #switch_1.Output -> field_at_index_002.Index
	    restore_curve_segment_length.links.new(switch_1.outputs[0], field_at_index_002.inputs[0])
	    #vector_math_2.Vector -> accumulate_field.Value
	    restore_curve_segment_length.links.new(vector_math_2.outputs[0], accumulate_field.inputs[0])
	    #curve_of_point_001.Index in Curve -> compare.A
	    restore_curve_segment_length.links.new(curve_of_point_001.outputs[1], compare.inputs[2])
	    #math_1.Value -> switch_1.False
	    restore_curve_segment_length.links.new(math_1.outputs[0], switch_1.inputs[1])
	    #compare.Result -> switch_1.Switch
	    restore_curve_segment_length.links.new(compare.outputs[0], switch_1.inputs[0])
	    #index_001_1.Index -> switch_1.True
	    restore_curve_segment_length.links.new(index_001_1.outputs[0], switch_1.inputs[2])
	    #reroute_006.Output -> switch_002.False
	    restore_curve_segment_length.links.new(reroute_006.outputs[0], switch_002.inputs[1])
	    #vector_math_004_1.Value -> mix.B
	    restore_curve_segment_length.links.new(vector_math_004_1.outputs[1], mix.inputs[3])
	    #mix.Result -> vector_math_2.Scale
	    restore_curve_segment_length.links.new(mix.outputs[0], vector_math_2.inputs[3])
	    #group_input_001_1.Factor -> mix.Factor
	    restore_curve_segment_length.links.new(group_input_001_1.outputs[2], mix.inputs[0])
	    #group_input_002_1.Factor -> compare_002.A
	    restore_curve_segment_length.links.new(group_input_002_1.outputs[2], compare_002.inputs[0])
	    #accumulate_field.Leading -> set_position_001_1.Offset
	    restore_curve_segment_length.links.new(accumulate_field.outputs[0], set_position_001_1.inputs[3])
	    #compare_002.Result -> boolean_math.Boolean
	    restore_curve_segment_length.links.new(compare_002.outputs[0], boolean_math.inputs[0])
	    #group_input_002_1.Selection -> boolean_math.Boolean
	    restore_curve_segment_length.links.new(group_input_002_1.outputs[1], boolean_math.inputs[1])
	    #reroute_005.Output -> reroute_004_1.Input
	    restore_curve_segment_length.links.new(reroute_005.outputs[0], reroute_004_1.inputs[0])
	    #reroute_012_1.Output -> sample_curve_001.Curves
	    restore_curve_segment_length.links.new(reroute_012_1.outputs[0], sample_curve_001.inputs[0])
	    #sample_curve_001.Position -> vector_math_006_1.Vector
	    restore_curve_segment_length.links.new(sample_curve_001.outputs[1], vector_math_006_1.inputs[1])
	    #sample_curve_001.Value -> vector_math_006_1.Vector
	    restore_curve_segment_length.links.new(sample_curve_001.outputs[0], vector_math_006_1.inputs[0])
	    #reroute_014_1.Output -> set_position_002.Geometry
	    restore_curve_segment_length.links.new(reroute_014_1.outputs[0], set_position_002.inputs[0])
	    #interpolate_domain_4.Value -> set_position_002.Offset
	    restore_curve_segment_length.links.new(interpolate_domain_4.outputs[0], set_position_002.inputs[3])
	    #index_1.Index -> sample_curve_001.Curve Index
	    restore_curve_segment_length.links.new(index_1.outputs[0], sample_curve_001.inputs[4])
	    #reroute_012_1.Output -> reroute_013_1.Input
	    restore_curve_segment_length.links.new(reroute_012_1.outputs[0], reroute_013_1.inputs[0])
	    #group_input_005_1.Selection -> boolean_math_002.Boolean
	    restore_curve_segment_length.links.new(group_input_005_1.outputs[1], boolean_math_002.inputs[1])
	    #compare_003.Result -> boolean_math_002.Boolean
	    restore_curve_segment_length.links.new(compare_003.outputs[0], boolean_math_002.inputs[0])
	    #reroute_011.Output -> reroute_005.Input
	    restore_curve_segment_length.links.new(reroute_011.outputs[0], reroute_005.inputs[0])
	    #group_input_003_1.Pin at Parameter -> sample_curve_001.Factor
	    restore_curve_segment_length.links.new(group_input_003_1.outputs[4], sample_curve_001.inputs[2])
	    #group_input_006_1.Pin at Parameter -> compare_003.A
	    restore_curve_segment_length.links.new(group_input_006_1.outputs[4], compare_003.inputs[0])
	    #reroute_006.Output -> compare_004.A
	    restore_curve_segment_length.links.new(reroute_006.outputs[0], compare_004.inputs[4])
	    #compare_004.Result -> switch_002.Switch
	    restore_curve_segment_length.links.new(compare_004.outputs[0], switch_002.inputs[0])
	    #named_attribute_1.Attribute -> switch_003_1.True
	    restore_curve_segment_length.links.new(named_attribute_1.outputs[0], switch_003_1.inputs[2])
	    #named_attribute_1.Exists -> switch_003_1.Switch
	    restore_curve_segment_length.links.new(named_attribute_1.outputs[1], switch_003_1.inputs[0])
	    #position_001.Position -> switch_003_1.False
	    restore_curve_segment_length.links.new(position_001.outputs[0], switch_003_1.inputs[1])
	    #switch_003_1.Output -> switch_002.True
	    restore_curve_segment_length.links.new(switch_003_1.outputs[0], switch_002.inputs[2])
	    #reroute_009.Output -> sample_curve_001.Value
	    restore_curve_segment_length.links.new(reroute_009.outputs[0], sample_curve_001.inputs[1])
	    #switch_002.Output -> reroute_007.Input
	    restore_curve_segment_length.links.new(switch_002.outputs[0], reroute_007.inputs[0])
	    #reroute_007.Output -> reroute_001_1.Input
	    restore_curve_segment_length.links.new(reroute_007.outputs[0], reroute_001_1.inputs[0])
	    #group_input_1.Reference Position -> reroute_006.Input
	    restore_curve_segment_length.links.new(group_input_1.outputs[3], reroute_006.inputs[0])
	    #reroute_007.Output -> reroute_008.Input
	    restore_curve_segment_length.links.new(reroute_007.outputs[0], reroute_008.inputs[0])
	    #reroute_008.Output -> reroute_009.Input
	    restore_curve_segment_length.links.new(reroute_008.outputs[0], reroute_009.inputs[0])
	    #group_input_1.Curves -> reroute_011.Input
	    restore_curve_segment_length.links.new(group_input_1.outputs[0], reroute_011.inputs[0])
	    #group_001_2.Segment Length -> mix.A
	    restore_curve_segment_length.links.new(group_001_2.outputs[0], mix.inputs[2])
	    #group_001_2.Segment Direction -> vector_math_2.Vector
	    restore_curve_segment_length.links.new(group_001_2.outputs[1], vector_math_2.inputs[0])
	    #vector_math_006_1.Vector -> interpolate_domain_4.Value
	    restore_curve_segment_length.links.new(vector_math_006_1.outputs[0], interpolate_domain_4.inputs[0])
	    #reroute_016_1.Output -> attribute_statistic.Attribute
	    restore_curve_segment_length.links.new(reroute_016_1.outputs[0], attribute_statistic.inputs[2])
	    #attribute_statistic.Max -> compare_005.A
	    restore_curve_segment_length.links.new(attribute_statistic.outputs[4], compare_005.inputs[0])
	    #set_position_002.Geometry -> switch_001_2.True
	    restore_curve_segment_length.links.new(set_position_002.outputs[0], switch_001_2.inputs[2])
	    #reroute_014_1.Output -> switch_001_2.False
	    restore_curve_segment_length.links.new(reroute_014_1.outputs[0], switch_001_2.inputs[1])
	    #reroute_016_1.Output -> set_position_002.Selection
	    restore_curve_segment_length.links.new(reroute_016_1.outputs[0], set_position_002.inputs[1])
	    #compare_005.Result -> switch_001_2.Switch
	    restore_curve_segment_length.links.new(compare_005.outputs[0], switch_001_2.inputs[0])
	    #reroute_014_1.Output -> attribute_statistic.Geometry
	    restore_curve_segment_length.links.new(reroute_014_1.outputs[0], attribute_statistic.inputs[0])
	    #boolean_math.Boolean -> set_position_001_1.Selection
	    restore_curve_segment_length.links.new(boolean_math.outputs[0], set_position_001_1.inputs[1])
	    #boolean_math_002.Boolean -> reroute_016_1.Input
	    restore_curve_segment_length.links.new(boolean_math_002.outputs[0], reroute_016_1.inputs[0])
	    #reroute_013_1.Output -> reroute_014_1.Input
	    restore_curve_segment_length.links.new(reroute_013_1.outputs[0], reroute_014_1.inputs[0])
	    #set_position_001_1.Geometry -> reroute_012_1.Input
	    restore_curve_segment_length.links.new(set_position_001_1.outputs[0], reroute_012_1.inputs[0])
	    #switch_001_2.Output -> group_output_6.Curves
	    restore_curve_segment_length.links.new(switch_001_2.outputs[0], group_output_6.inputs[0])
	    #group_002_1.Root Position -> set_position_001_1.Position
	    restore_curve_segment_length.links.new(group_002_1.outputs[1], set_position_001_1.inputs[2])
	    return restore_curve_segment_length
	
	restore_curve_segment_length = restore_curve_segment_length_node_group()
	
	#initialize create_guide_index_map node group
	def create_guide_index_map_node_group():
	    create_guide_index_map = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Create Guide Index Map")
	
	    create_guide_index_map.color_tag = 'NONE'
	    create_guide_index_map.description = "Creates an attribute that maps each curve to its nearest guide via index"
	    create_guide_index_map.default_group_node_width = 140
	    
	
	    create_guide_index_map.is_modifier = True
	
	    #create_guide_index_map interface
	    #Socket Geometry
	    geometry_socket_2 = create_guide_index_map.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_2.attribute_domain = 'POINT'
	
	    #Socket Guide Curves
	    guide_curves_socket = create_guide_index_map.interface.new_socket(name = "Guide Curves", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    guide_curves_socket.attribute_domain = 'POINT'
	
	    #Socket Guide Index
	    guide_index_socket_1 = create_guide_index_map.interface.new_socket(name = "Guide Index", in_out='OUTPUT', socket_type = 'NodeSocketInt')
	    guide_index_socket_1.default_value = 0
	    guide_index_socket_1.min_value = 0
	    guide_index_socket_1.max_value = 1
	    guide_index_socket_1.subtype = 'NONE'
	    guide_index_socket_1.attribute_domain = 'CURVE'
	
	    #Socket Guide Selection
	    guide_selection_socket = create_guide_index_map.interface.new_socket(name = "Guide Selection", in_out='OUTPUT', socket_type = 'NodeSocketBool')
	    guide_selection_socket.default_value = False
	    guide_selection_socket.attribute_domain = 'CURVE'
	
	    #Socket Geometry
	    geometry_socket_3 = create_guide_index_map.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_3.attribute_domain = 'POINT'
	
	    #Socket Guides
	    guides_socket = create_guide_index_map.interface.new_socket(name = "Guides", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    guides_socket.attribute_domain = 'POINT'
	    guides_socket.description = "Guide curves or points used for the selection of guide curves"
	
	    #Socket Guide Distance
	    guide_distance_socket = create_guide_index_map.interface.new_socket(name = "Guide Distance", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    guide_distance_socket.default_value = 0.0
	    guide_distance_socket.min_value = 0.0
	    guide_distance_socket.max_value = 3.4028234663852886e+38
	    guide_distance_socket.subtype = 'DISTANCE'
	    guide_distance_socket.attribute_domain = 'POINT'
	    guide_distance_socket.description = "Minimum distance between two guides"
	
	    #Socket Guide Mask
	    guide_mask_socket = create_guide_index_map.interface.new_socket(name = "Guide Mask", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    guide_mask_socket.default_value = 1.0
	    guide_mask_socket.min_value = 0.0
	    guide_mask_socket.max_value = 1.0
	    guide_mask_socket.subtype = 'NONE'
	    guide_mask_socket.attribute_domain = 'POINT'
	    guide_mask_socket.description = "Mask for which curves are eligible to be selected as guides"
	
	    #Socket Group ID
	    group_id_socket = create_guide_index_map.interface.new_socket(name = "Group ID", in_out='INPUT', socket_type = 'NodeSocketInt')
	    group_id_socket.default_value = 0
	    group_id_socket.min_value = -2147483648
	    group_id_socket.max_value = 2147483647
	    group_id_socket.subtype = 'NONE'
	    group_id_socket.attribute_domain = 'POINT'
	    group_id_socket.description = "ID to group curves together for guide map creation"
	
	
	    #initialize create_guide_index_map nodes
	    #node Frame.003
	    frame_003_1 = create_guide_index_map.nodes.new("NodeFrame")
	    frame_003_1.label = "Sample Guide Index"
	    frame_003_1.name = "Frame.003"
	    frame_003_1.label_size = 20
	    frame_003_1.shrink = True
	
	    #node Frame.004
	    frame_004_1 = create_guide_index_map.nodes.new("NodeFrame")
	    frame_004_1.label = "Isolate Guide Points"
	    frame_004_1.name = "Frame.004"
	    frame_004_1.label_size = 20
	    frame_004_1.shrink = True
	
	    #node Frame.006
	    frame_006 = create_guide_index_map.nodes.new("NodeFrame")
	    frame_006.label = "Input Guide Geometry Points"
	    frame_006.name = "Frame.006"
	    frame_006.label_size = 20
	    frame_006.shrink = True
	
	    #node Frame
	    frame_3 = create_guide_index_map.nodes.new("NodeFrame")
	    frame_3.label = "Ensure Data on Input Points"
	    frame_3.name = "Frame"
	    frame_3.label_size = 20
	    frame_3.shrink = True
	
	    #node Frame.007
	    frame_007 = create_guide_index_map.nodes.new("NodeFrame")
	    frame_007.label = "Switch Guide Input"
	    frame_007.name = "Frame.007"
	    frame_007.label_size = 20
	    frame_007.shrink = True
	
	    #node Frame.002
	    frame_002_2 = create_guide_index_map.nodes.new("NodeFrame")
	    frame_002_2.label = "Sample per Group ID"
	    frame_002_2.name = "Frame.002"
	    frame_002_2.label_size = 20
	    frame_002_2.shrink = True
	
	    #node Frame.005
	    frame_005 = create_guide_index_map.nodes.new("NodeFrame")
	    frame_005.label = "Optimization"
	    frame_005.name = "Frame.005"
	    frame_005.label_size = 20
	    frame_005.shrink = True
	
	    #node Reroute.019
	    reroute_019_1 = create_guide_index_map.nodes.new("NodeReroute")
	    reroute_019_1.name = "Reroute.019"
	    reroute_019_1.socket_idname = "NodeSocketGeometry"
	    #node Reroute.021
	    reroute_021 = create_guide_index_map.nodes.new("NodeReroute")
	    reroute_021.name = "Reroute.021"
	    reroute_021.socket_idname = "NodeSocketGeometry"
	    #node Reroute.022
	    reroute_022 = create_guide_index_map.nodes.new("NodeReroute")
	    reroute_022.name = "Reroute.022"
	    reroute_022.socket_idname = "NodeSocketGeometry"
	    #node Reroute.023
	    reroute_023 = create_guide_index_map.nodes.new("NodeReroute")
	    reroute_023.name = "Reroute.023"
	    reroute_023.socket_idname = "NodeSocketGeometry"
	    #node Reroute.001
	    reroute_001_2 = create_guide_index_map.nodes.new("NodeReroute")
	    reroute_001_2.name = "Reroute.001"
	    reroute_001_2.socket_idname = "NodeSocketGeometry"
	    #node Reroute
	    reroute_2 = create_guide_index_map.nodes.new("NodeReroute")
	    reroute_2.name = "Reroute"
	    reroute_2.socket_idname = "NodeSocketGeometry"
	    #node Set Position.002
	    set_position_002_1 = create_guide_index_map.nodes.new("GeometryNodeSetPosition")
	    set_position_002_1.name = "Set Position.002"
	    set_position_002_1.inputs[1].hide = True
	    set_position_002_1.inputs[2].hide = True
	    #Selection
	    set_position_002_1.inputs[1].default_value = True
	    #Position
	    set_position_002_1.inputs[2].default_value = (0.0, 0.0, 0.0)
	
	    #node Switch.002
	    switch_002_1 = create_guide_index_map.nodes.new("GeometryNodeSwitch")
	    switch_002_1.name = "Switch.002"
	    switch_002_1.input_type = 'GEOMETRY'
	
	    #node Set Position
	    set_position_1 = create_guide_index_map.nodes.new("GeometryNodeSetPosition")
	    set_position_1.name = "Set Position"
	    set_position_1.inputs[1].hide = True
	    set_position_1.inputs[2].hide = True
	    #Selection
	    set_position_1.inputs[1].default_value = True
	    #Position
	    set_position_1.inputs[2].default_value = (0.0, 0.0, 0.0)
	
	    #node Vector Math.003
	    vector_math_003_1 = create_guide_index_map.nodes.new("ShaderNodeVectorMath")
	    vector_math_003_1.name = "Vector Math.003"
	    vector_math_003_1.hide = True
	    vector_math_003_1.operation = 'SCALE'
	    #Vector
	    vector_math_003_1.inputs[0].default_value = (100.0, 100.0, 100.0)
	
	    #node Vector Math.004
	    vector_math_004_2 = create_guide_index_map.nodes.new("ShaderNodeVectorMath")
	    vector_math_004_2.name = "Vector Math.004"
	    vector_math_004_2.hide = True
	    vector_math_004_2.operation = 'SCALE'
	    #Scale
	    vector_math_004_2.inputs[3].default_value = -1.0
	
	    #node Merge by Distance
	    merge_by_distance = create_guide_index_map.nodes.new("GeometryNodeMergeByDistance")
	    merge_by_distance.name = "Merge by Distance"
	    merge_by_distance.hide = True
	    merge_by_distance.mode = 'ALL'
	
	    #node Merge by Distance.001
	    merge_by_distance_001 = create_guide_index_map.nodes.new("GeometryNodeMergeByDistance")
	    merge_by_distance_001.name = "Merge by Distance.001"
	    merge_by_distance_001.hide = True
	    merge_by_distance_001.mode = 'ALL'
	
	    #node Group Input.001
	    group_input_001_2 = create_guide_index_map.nodes.new("NodeGroupInput")
	    group_input_001_2.name = "Group Input.001"
	    group_input_001_2.outputs[0].hide = True
	    group_input_001_2.outputs[1].hide = True
	    group_input_001_2.outputs[3].hide = True
	    group_input_001_2.outputs[4].hide = True
	    group_input_001_2.outputs[5].hide = True
	
	    #node Reroute.026
	    reroute_026 = create_guide_index_map.nodes.new("NodeReroute")
	    reroute_026.name = "Reroute.026"
	    reroute_026.socket_idname = "NodeSocketFloatDistance"
	    #node Compare.004
	    compare_004_1 = create_guide_index_map.nodes.new("FunctionNodeCompare")
	    compare_004_1.name = "Compare.004"
	    compare_004_1.hide = True
	    compare_004_1.data_type = 'FLOAT'
	    compare_004_1.mode = 'ELEMENT'
	    compare_004_1.operation = 'GREATER_THAN'
	    #B
	    compare_004_1.inputs[1].default_value = 0.0
	
	    #node Reroute.015
	    reroute_015_2 = create_guide_index_map.nodes.new("NodeReroute")
	    reroute_015_2.name = "Reroute.015"
	    reroute_015_2.socket_idname = "NodeSocketGeometry"
	    #node Reroute.016
	    reroute_016_2 = create_guide_index_map.nodes.new("NodeReroute")
	    reroute_016_2.name = "Reroute.016"
	    reroute_016_2.socket_idname = "NodeSocketGeometry"
	    #node Reroute.013
	    reroute_013_2 = create_guide_index_map.nodes.new("NodeReroute")
	    reroute_013_2.name = "Reroute.013"
	    reroute_013_2.socket_idname = "NodeSocketGeometry"
	    #node Reroute.017
	    reroute_017_2 = create_guide_index_map.nodes.new("NodeReroute")
	    reroute_017_2.name = "Reroute.017"
	    reroute_017_2.socket_idname = "NodeSocketGeometry"
	    #node Group Input
	    group_input_2 = create_guide_index_map.nodes.new("NodeGroupInput")
	    group_input_2.name = "Group Input"
	    group_input_2.outputs[1].hide = True
	    group_input_2.outputs[2].hide = True
	    group_input_2.outputs[3].hide = True
	    group_input_2.outputs[4].hide = True
	    group_input_2.outputs[5].hide = True
	
	    #node Separate Components.001
	    separate_components_001 = create_guide_index_map.nodes.new("GeometryNodeSeparateComponents")
	    separate_components_001.name = "Separate Components.001"
	
	    #node Group Input.003
	    group_input_003_2 = create_guide_index_map.nodes.new("NodeGroupInput")
	    group_input_003_2.name = "Group Input.003"
	    group_input_003_2.outputs[0].hide = True
	    group_input_003_2.outputs[1].hide = True
	    group_input_003_2.outputs[2].hide = True
	    group_input_003_2.outputs[4].hide = True
	    group_input_003_2.outputs[5].hide = True
	
	    #node Capture Attribute.003
	    capture_attribute_003 = create_guide_index_map.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_003.name = "Capture Attribute.003"
	    capture_attribute_003.active_index = 0
	    capture_attribute_003.capture_items.clear()
	    capture_attribute_003.capture_items.new('FLOAT', "Value")
	    capture_attribute_003.capture_items["Value"].data_type = 'FLOAT'
	    capture_attribute_003.domain = 'CURVE'
	
	    #node Group Input.010
	    group_input_010 = create_guide_index_map.nodes.new("NodeGroupInput")
	    group_input_010.name = "Group Input.010"
	    group_input_010.outputs[0].hide = True
	    group_input_010.outputs[1].hide = True
	    group_input_010.outputs[2].hide = True
	    group_input_010.outputs[3].hide = True
	    group_input_010.outputs[5].hide = True
	
	    #node Capture Attribute.006
	    capture_attribute_006 = create_guide_index_map.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_006.name = "Capture Attribute.006"
	    capture_attribute_006.active_index = 0
	    capture_attribute_006.capture_items.clear()
	    capture_attribute_006.capture_items.new('FLOAT', "Value")
	    capture_attribute_006.capture_items["Value"].data_type = 'INT'
	    capture_attribute_006.domain = 'CURVE'
	
	    #node Reroute.005
	    reroute_005_1 = create_guide_index_map.nodes.new("NodeReroute")
	    reroute_005_1.name = "Reroute.005"
	    reroute_005_1.socket_idname = "NodeSocketGeometry"
	    #node Capture Attribute.001
	    capture_attribute_001_1 = create_guide_index_map.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_001_1.name = "Capture Attribute.001"
	    capture_attribute_001_1.active_index = 0
	    capture_attribute_001_1.capture_items.clear()
	    capture_attribute_001_1.capture_items.new('FLOAT', "Value")
	    capture_attribute_001_1.capture_items["Value"].data_type = 'INT'
	    capture_attribute_001_1.domain = 'CURVE'
	
	    #node Curve to Points
	    curve_to_points = create_guide_index_map.nodes.new("GeometryNodeCurveToPoints")
	    curve_to_points.name = "Curve to Points"
	    curve_to_points.mode = 'COUNT'
	    curve_to_points.inputs[2].hide = True
	    curve_to_points.outputs[1].hide = True
	    curve_to_points.outputs[2].hide = True
	    curve_to_points.outputs[3].hide = True
	    #Count
	    curve_to_points.inputs[1].default_value = 1
	
	    #node Index.001
	    index_001_2 = create_guide_index_map.nodes.new("GeometryNodeInputIndex")
	    index_001_2.name = "Index.001"
	
	    #node Reroute.014
	    reroute_014_2 = create_guide_index_map.nodes.new("NodeReroute")
	    reroute_014_2.name = "Reroute.014"
	    reroute_014_2.socket_idname = "NodeSocketGeometry"
	    #node Reroute.027
	    reroute_027 = create_guide_index_map.nodes.new("NodeReroute")
	    reroute_027.name = "Reroute.027"
	    reroute_027.socket_idname = "NodeSocketGeometry"
	    #node Reroute.007
	    reroute_007_1 = create_guide_index_map.nodes.new("NodeReroute")
	    reroute_007_1.name = "Reroute.007"
	    reroute_007_1.socket_idname = "NodeSocketGeometry"
	    #node Reroute.004
	    reroute_004_2 = create_guide_index_map.nodes.new("NodeReroute")
	    reroute_004_2.name = "Reroute.004"
	    reroute_004_2.socket_idname = "NodeSocketGeometry"
	    #node Curve to Points.001
	    curve_to_points_001 = create_guide_index_map.nodes.new("GeometryNodeCurveToPoints")
	    curve_to_points_001.name = "Curve to Points.001"
	    curve_to_points_001.mode = 'COUNT'
	    curve_to_points_001.inputs[2].hide = True
	    curve_to_points_001.outputs[1].hide = True
	    curve_to_points_001.outputs[2].hide = True
	    curve_to_points_001.outputs[3].hide = True
	    #Count
	    curve_to_points_001.inputs[1].default_value = 1
	
	    #node Group Input.004
	    group_input_004_1 = create_guide_index_map.nodes.new("NodeGroupInput")
	    group_input_004_1.name = "Group Input.004"
	    group_input_004_1.outputs[0].hide = True
	    group_input_004_1.outputs[2].hide = True
	    group_input_004_1.outputs[3].hide = True
	    group_input_004_1.outputs[4].hide = True
	    group_input_004_1.outputs[5].hide = True
	
	    #node Mesh to Points
	    mesh_to_points = create_guide_index_map.nodes.new("GeometryNodeMeshToPoints")
	    mesh_to_points.name = "Mesh to Points"
	    mesh_to_points.mode = 'VERTICES'
	    mesh_to_points.inputs[1].hide = True
	    mesh_to_points.inputs[2].hide = True
	    mesh_to_points.inputs[3].hide = True
	    #Selection
	    mesh_to_points.inputs[1].default_value = True
	    #Position
	    mesh_to_points.inputs[2].default_value = (0.0, 0.0, 0.0)
	    #Radius
	    mesh_to_points.inputs[3].default_value = 0.05000000074505806
	
	    #node Separate Components
	    separate_components_1 = create_guide_index_map.nodes.new("GeometryNodeSeparateComponents")
	    separate_components_1.name = "Separate Components"
	    separate_components_1.outputs[4].hide = True
	    separate_components_1.outputs[5].hide = True
	
	    #node Join Geometry
	    join_geometry_1 = create_guide_index_map.nodes.new("GeometryNodeJoinGeometry")
	    join_geometry_1.name = "Join Geometry"
	
	    #node Domain Size
	    domain_size = create_guide_index_map.nodes.new("GeometryNodeAttributeDomainSize")
	    domain_size.name = "Domain Size"
	    domain_size.hide = True
	    domain_size.component = 'POINTCLOUD'
	    domain_size.outputs[1].hide = True
	    domain_size.outputs[2].hide = True
	    domain_size.outputs[3].hide = True
	    domain_size.outputs[4].hide = True
	    domain_size.outputs[5].hide = True
	
	    #node Compare.003
	    compare_003_1 = create_guide_index_map.nodes.new("FunctionNodeCompare")
	    compare_003_1.name = "Compare.003"
	    compare_003_1.data_type = 'INT'
	    compare_003_1.mode = 'ELEMENT'
	    compare_003_1.operation = 'GREATER_THAN'
	    #B_INT
	    compare_003_1.inputs[3].default_value = 0
	
	    #node Group Input.008
	    group_input_008 = create_guide_index_map.nodes.new("NodeGroupInput")
	    group_input_008.name = "Group Input.008"
	    group_input_008.outputs[0].hide = True
	    group_input_008.outputs[1].hide = True
	    group_input_008.outputs[2].hide = True
	    group_input_008.outputs[4].hide = True
	    group_input_008.outputs[5].hide = True
	
	    #node Reroute.020
	    reroute_020_1 = create_guide_index_map.nodes.new("NodeReroute")
	    reroute_020_1.name = "Reroute.020"
	    reroute_020_1.socket_idname = "NodeSocketGeometry"
	    #node Sample Nearest.002
	    sample_nearest_002 = create_guide_index_map.nodes.new("GeometryNodeSampleNearest")
	    sample_nearest_002.name = "Sample Nearest.002"
	    sample_nearest_002.domain = 'POINT'
	    #Sample Position
	    sample_nearest_002.inputs[1].default_value = (0.0, 0.0, 0.0)
	
	    #node Sample Index.004
	    sample_index_004 = create_guide_index_map.nodes.new("GeometryNodeSampleIndex")
	    sample_index_004.name = "Sample Index.004"
	    sample_index_004.clamp = False
	    sample_index_004.data_type = 'INT'
	    sample_index_004.domain = 'POINT'
	
	    #node Group Input.009
	    group_input_009 = create_guide_index_map.nodes.new("NodeGroupInput")
	    group_input_009.name = "Group Input.009"
	    group_input_009.outputs[0].hide = True
	    group_input_009.outputs[1].hide = True
	    group_input_009.outputs[2].hide = True
	    group_input_009.outputs[3].hide = True
	    group_input_009.outputs[5].hide = True
	
	    #node Math.003
	    math_003 = create_guide_index_map.nodes.new("ShaderNodeMath")
	    math_003.name = "Math.003"
	    math_003.operation = 'ADD'
	    math_003.use_clamp = False
	
	    #node Capture Attribute.005
	    capture_attribute_005 = create_guide_index_map.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_005.name = "Capture Attribute.005"
	    capture_attribute_005.active_index = 0
	    capture_attribute_005.capture_items.clear()
	    capture_attribute_005.capture_items.new('FLOAT', "Value")
	    capture_attribute_005.capture_items["Value"].data_type = 'INT'
	    capture_attribute_005.domain = 'POINT'
	
	    #node Capture Attribute.004
	    capture_attribute_004 = create_guide_index_map.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_004.name = "Capture Attribute.004"
	    capture_attribute_004.active_index = 0
	    capture_attribute_004.capture_items.clear()
	    capture_attribute_004.capture_items.new('FLOAT', "Value")
	    capture_attribute_004.capture_items["Value"].data_type = 'FLOAT'
	    capture_attribute_004.domain = 'POINT'
	
	    #node Switch.003
	    switch_003_2 = create_guide_index_map.nodes.new("GeometryNodeSwitch")
	    switch_003_2.name = "Switch.003"
	    switch_003_2.input_type = 'FLOAT'
	
	    #node Reroute.024
	    reroute_024 = create_guide_index_map.nodes.new("NodeReroute")
	    reroute_024.name = "Reroute.024"
	    reroute_024.socket_idname = "NodeSocketBool"
	    #node Reroute.028
	    reroute_028 = create_guide_index_map.nodes.new("NodeReroute")
	    reroute_028.name = "Reroute.028"
	    reroute_028.socket_idname = "NodeSocketGeometry"
	    #node Compare.002
	    compare_002_1 = create_guide_index_map.nodes.new("FunctionNodeCompare")
	    compare_002_1.name = "Compare.002"
	    compare_002_1.data_type = 'FLOAT'
	    compare_002_1.mode = 'ELEMENT'
	    compare_002_1.operation = 'LESS_THAN'
	
	    #node Boolean Math
	    boolean_math_1 = create_guide_index_map.nodes.new("FunctionNodeBooleanMath")
	    boolean_math_1.name = "Boolean Math"
	    boolean_math_1.operation = 'NOT'
	
	    #node Random Value.001
	    random_value_001_1 = create_guide_index_map.nodes.new("FunctionNodeRandomValue")
	    random_value_001_1.name = "Random Value.001"
	    random_value_001_1.data_type = 'FLOAT'
	    #Min_001
	    random_value_001_1.inputs[2].default_value = 0.0
	    #Max_001
	    random_value_001_1.inputs[3].default_value = 1.0
	    #ID
	    random_value_001_1.inputs[7].default_value = 0
	    #Seed
	    random_value_001_1.inputs[8].default_value = 568746
	
	    #node Switch
	    switch_2 = create_guide_index_map.nodes.new("GeometryNodeSwitch")
	    switch_2.name = "Switch"
	    switch_2.input_type = 'GEOMETRY'
	
	    #node Delete Geometry.002
	    delete_geometry_002 = create_guide_index_map.nodes.new("GeometryNodeDeleteGeometry")
	    delete_geometry_002.name = "Delete Geometry.002"
	    delete_geometry_002.domain = 'POINT'
	    delete_geometry_002.mode = 'ALL'
	
	    #node Reroute.008
	    reroute_008_1 = create_guide_index_map.nodes.new("NodeReroute")
	    reroute_008_1.name = "Reroute.008"
	    reroute_008_1.socket_idname = "NodeSocketGeometry"
	    #node Position
	    position = create_guide_index_map.nodes.new("GeometryNodeInputPosition")
	    position.name = "Position"
	
	    #node Vector Math.002
	    vector_math_002_1 = create_guide_index_map.nodes.new("ShaderNodeVectorMath")
	    vector_math_002_1.name = "Vector Math.002"
	    vector_math_002_1.operation = 'ADD'
	
	    #node Vector Math.001
	    vector_math_001_2 = create_guide_index_map.nodes.new("ShaderNodeVectorMath")
	    vector_math_001_2.name = "Vector Math.001"
	    vector_math_001_2.operation = 'SCALE'
	    #Vector
	    vector_math_001_2.inputs[0].default_value = (100.0, 100.0, 100.0)
	
	    #node Set Position.001
	    set_position_001_2 = create_guide_index_map.nodes.new("GeometryNodeSetPosition")
	    set_position_001_2.name = "Set Position.001"
	    set_position_001_2.inputs[1].hide = True
	    set_position_001_2.inputs[2].hide = True
	    #Selection
	    set_position_001_2.inputs[1].default_value = True
	    #Position
	    set_position_001_2.inputs[2].default_value = (0.0, 0.0, 0.0)
	
	    #node Reroute.010
	    reroute_010 = create_guide_index_map.nodes.new("NodeReroute")
	    reroute_010.name = "Reroute.010"
	    reroute_010.hide = True
	    reroute_010.socket_idname = "NodeSocketGeometry"
	    #node Sample Nearest.007
	    sample_nearest_007 = create_guide_index_map.nodes.new("GeometryNodeSampleNearest")
	    sample_nearest_007.name = "Sample Nearest.007"
	    sample_nearest_007.domain = 'POINT'
	    sample_nearest_007.inputs[1].hide = True
	    #Sample Position
	    sample_nearest_007.inputs[1].default_value = (0.0, 0.0, 0.0)
	
	    #node Switch.001
	    switch_001_3 = create_guide_index_map.nodes.new("GeometryNodeSwitch")
	    switch_001_3.name = "Switch.001"
	    switch_001_3.input_type = 'INT'
	
	    #node Group Input.007
	    group_input_007_1 = create_guide_index_map.nodes.new("NodeGroupInput")
	    group_input_007_1.name = "Group Input.007"
	    group_input_007_1.outputs[0].hide = True
	    group_input_007_1.outputs[1].hide = True
	    group_input_007_1.outputs[2].hide = True
	    group_input_007_1.outputs[3].hide = True
	    group_input_007_1.outputs[5].hide = True
	
	    #node Math
	    math_2 = create_guide_index_map.nodes.new("ShaderNodeMath")
	    math_2.name = "Math"
	    math_2.hide = True
	    math_2.operation = 'SUBTRACT'
	    math_2.use_clamp = False
	
	    #node Math.001
	    math_001 = create_guide_index_map.nodes.new("ShaderNodeMath")
	    math_001.name = "Math.001"
	    math_001.hide = True
	    math_001.operation = 'ABSOLUTE'
	    math_001.use_clamp = False
	
	    #node Evaluate at Index
	    evaluate_at_index_2 = create_guide_index_map.nodes.new("GeometryNodeFieldAtIndex")
	    evaluate_at_index_2.name = "Evaluate at Index"
	    evaluate_at_index_2.hide = True
	    evaluate_at_index_2.data_type = 'INT'
	    evaluate_at_index_2.domain = 'POINT'
	    #Index
	    evaluate_at_index_2.inputs[0].default_value = 0
	
	    #node Accumulate Field.001
	    accumulate_field_001 = create_guide_index_map.nodes.new("GeometryNodeAccumulateField")
	    accumulate_field_001.name = "Accumulate Field.001"
	    accumulate_field_001.hide = True
	    accumulate_field_001.data_type = 'INT'
	    accumulate_field_001.domain = 'POINT'
	    accumulate_field_001.inputs[1].hide = True
	    accumulate_field_001.outputs[0].hide = True
	    accumulate_field_001.outputs[1].hide = True
	    #Value
	    accumulate_field_001.inputs[0].default_value = 1
	    #Group Index
	    accumulate_field_001.inputs[1].default_value = 0
	
	    #node Sample Index.003
	    sample_index_003 = create_guide_index_map.nodes.new("GeometryNodeSampleIndex")
	    sample_index_003.name = "Sample Index.003"
	    sample_index_003.hide = True
	    sample_index_003.clamp = False
	    sample_index_003.data_type = 'INT'
	    sample_index_003.domain = 'POINT'
	    #Index
	    sample_index_003.inputs[2].default_value = 0
	
	    #node Sample Nearest.001
	    sample_nearest_001 = create_guide_index_map.nodes.new("GeometryNodeSampleNearest")
	    sample_nearest_001.name = "Sample Nearest.001"
	    sample_nearest_001.domain = 'POINT'
	    #Sample Position
	    sample_nearest_001.inputs[1].default_value = (0.0, 0.0, 0.0)
	
	    #node Index
	    index_2 = create_guide_index_map.nodes.new("GeometryNodeInputIndex")
	    index_2.name = "Index"
	
	    #node Sample Index
	    sample_index = create_guide_index_map.nodes.new("GeometryNodeSampleIndex")
	    sample_index.name = "Sample Index"
	    sample_index.clamp = False
	    sample_index.data_type = 'INT'
	    sample_index.domain = 'POINT'
	
	    #node Sample Index.002
	    sample_index_002 = create_guide_index_map.nodes.new("GeometryNodeSampleIndex")
	    sample_index_002.name = "Sample Index.002"
	    sample_index_002.clamp = False
	    sample_index_002.data_type = 'INT'
	    sample_index_002.domain = 'POINT'
	
	    #node Reroute.018
	    reroute_018_2 = create_guide_index_map.nodes.new("NodeReroute")
	    reroute_018_2.name = "Reroute.018"
	    reroute_018_2.socket_idname = "NodeSocketGeometry"
	    #node Sample Nearest.005
	    sample_nearest_005 = create_guide_index_map.nodes.new("GeometryNodeSampleNearest")
	    sample_nearest_005.name = "Sample Nearest.005"
	    sample_nearest_005.domain = 'POINT'
	
	    #node Compare
	    compare_1 = create_guide_index_map.nodes.new("FunctionNodeCompare")
	    compare_1.name = "Compare"
	    compare_1.hide = True
	    compare_1.data_type = 'INT'
	    compare_1.mode = 'ELEMENT'
	    compare_1.operation = 'NOT_EQUAL'
	    #B_INT
	    compare_1.inputs[3].default_value = 0
	
	    #node Capture Attribute.002
	    capture_attribute_002_1 = create_guide_index_map.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_002_1.name = "Capture Attribute.002"
	    capture_attribute_002_1.active_index = 0
	    capture_attribute_002_1.capture_items.clear()
	    capture_attribute_002_1.capture_items.new('FLOAT', "Value")
	    capture_attribute_002_1.capture_items["Value"].data_type = 'BOOLEAN'
	    capture_attribute_002_1.domain = 'CURVE'
	
	    #node Compare.001
	    compare_001 = create_guide_index_map.nodes.new("FunctionNodeCompare")
	    compare_001.name = "Compare.001"
	    compare_001.hide = True
	    compare_001.data_type = 'INT'
	    compare_001.mode = 'ELEMENT'
	    compare_001.operation = 'EQUAL'
	
	    #node Index.002
	    index_002_1 = create_guide_index_map.nodes.new("GeometryNodeInputIndex")
	    index_002_1.name = "Index.002"
	
	    #node Reroute.011
	    reroute_011_1 = create_guide_index_map.nodes.new("NodeReroute")
	    reroute_011_1.name = "Reroute.011"
	    reroute_011_1.socket_idname = "NodeSocketInt"
	    #node Reroute.012
	    reroute_012_2 = create_guide_index_map.nodes.new("NodeReroute")
	    reroute_012_2.name = "Reroute.012"
	    reroute_012_2.socket_idname = "NodeSocketGeometry"
	    #node Join Geometry.001
	    join_geometry_001_1 = create_guide_index_map.nodes.new("GeometryNodeJoinGeometry")
	    join_geometry_001_1.name = "Join Geometry.001"
	
	    #node Reroute.003
	    reroute_003_1 = create_guide_index_map.nodes.new("NodeReroute")
	    reroute_003_1.name = "Reroute.003"
	    reroute_003_1.socket_idname = "NodeSocketBool"
	    #node Reroute.002
	    reroute_002_1 = create_guide_index_map.nodes.new("NodeReroute")
	    reroute_002_1.name = "Reroute.002"
	    reroute_002_1.socket_idname = "NodeSocketInt"
	    #node Reroute.009
	    reroute_009_1 = create_guide_index_map.nodes.new("NodeReroute")
	    reroute_009_1.name = "Reroute.009"
	    reroute_009_1.socket_idname = "NodeSocketGeometry"
	    #node Group Output
	    group_output_7 = create_guide_index_map.nodes.new("NodeGroupOutput")
	    group_output_7.name = "Group Output"
	    group_output_7.is_active_output = True
	
	    #node Reroute.006
	    reroute_006_1 = create_guide_index_map.nodes.new("NodeReroute")
	    reroute_006_1.name = "Reroute.006"
	    reroute_006_1.socket_idname = "NodeSocketBool"
	    #node Capture Attribute
	    capture_attribute_1 = create_guide_index_map.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_1.name = "Capture Attribute"
	    capture_attribute_1.active_index = 0
	    capture_attribute_1.capture_items.clear()
	    capture_attribute_1.capture_items.new('FLOAT', "Value")
	    capture_attribute_1.capture_items["Value"].data_type = 'INT'
	    capture_attribute_1.domain = 'CURVE'
	
	    #node Separate Geometry
	    separate_geometry = create_guide_index_map.nodes.new("GeometryNodeSeparateGeometry")
	    separate_geometry.name = "Separate Geometry"
	    separate_geometry.hide = True
	    separate_geometry.domain = 'CURVE'
	
	    #node Sample Index.001
	    sample_index_001 = create_guide_index_map.nodes.new("GeometryNodeSampleIndex")
	    sample_index_001.name = "Sample Index.001"
	    sample_index_001.clamp = False
	    sample_index_001.data_type = 'INT'
	    sample_index_001.domain = 'POINT'
	
	    #node Store Named Attribute
	    store_named_attribute_1 = create_guide_index_map.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_1.name = "Store Named Attribute"
	    store_named_attribute_1.data_type = 'INT'
	    store_named_attribute_1.domain = 'CURVE'
	    store_named_attribute_1.inputs[1].hide = True
	    #Selection
	    store_named_attribute_1.inputs[1].default_value = True
	    #Name
	    store_named_attribute_1.inputs[2].default_value = "guide_curve_index"
	
	
	
	
	    #Set parents
	    reroute_001_2.parent = frame_003_1
	    reroute_2.parent = frame_004_1
	    set_position_002_1.parent = frame_004_1
	    switch_002_1.parent = frame_004_1
	    set_position_1.parent = frame_004_1
	    vector_math_003_1.parent = frame_004_1
	    vector_math_004_2.parent = frame_004_1
	    merge_by_distance.parent = frame_004_1
	    merge_by_distance_001.parent = frame_004_1
	    group_input_001_2.parent = frame_004_1
	    reroute_026.parent = frame_004_1
	    compare_004_1.parent = frame_004_1
	    reroute_014_2.parent = frame_003_1
	    reroute_004_2.parent = frame_003_1
	    curve_to_points_001.parent = frame_006
	    group_input_004_1.parent = frame_006
	    mesh_to_points.parent = frame_006
	    separate_components_1.parent = frame_006
	    join_geometry_1.parent = frame_006
	    domain_size.parent = frame_3
	    compare_003_1.parent = frame_3
	    group_input_008.parent = frame_3
	    reroute_020_1.parent = frame_3
	    sample_nearest_002.parent = frame_3
	    sample_index_004.parent = frame_3
	    group_input_009.parent = frame_3
	    math_003.parent = frame_3
	    capture_attribute_005.parent = frame_3
	    capture_attribute_004.parent = frame_3
	    switch_003_2.parent = frame_3
	    reroute_024.parent = frame_3
	    compare_002_1.parent = frame_004_1
	    boolean_math_1.parent = frame_004_1
	    random_value_001_1.parent = frame_004_1
	    switch_2.parent = frame_007
	    delete_geometry_002.parent = frame_004_1
	    position.parent = frame_002_2
	    vector_math_002_1.parent = frame_002_2
	    vector_math_001_2.parent = frame_002_2
	    set_position_001_2.parent = frame_002_2
	    reroute_010.parent = frame_002_2
	    sample_nearest_007.parent = frame_002_2
	    switch_001_3.parent = frame_002_2
	    group_input_007_1.parent = frame_005
	    math_2.parent = frame_005
	    math_001.parent = frame_005
	    evaluate_at_index_2.parent = frame_005
	    accumulate_field_001.parent = frame_005
	    sample_index_003.parent = frame_005
	    sample_nearest_001.parent = frame_003_1
	    index_2.parent = frame_003_1
	    sample_index.parent = frame_003_1
	    sample_index_002.parent = frame_003_1
	    reroute_018_2.parent = frame_003_1
	    sample_nearest_005.parent = frame_002_2
	    compare_1.parent = frame_005
	    capture_attribute_1.parent = frame_003_1
	    sample_index_001.parent = frame_003_1
	
	    #Set locations
	    frame_003_1.location = (-2290.790771484375, 42.0)
	    frame_004_1.location = (-3952.0, -435.4815673828125)
	    frame_006.location = (-6505.0, -653.0)
	    frame_3.location = (-5614.0, -572.0)
	    frame_007.location = (-4275.0, -292.0)
	    frame_002_2.location = (-2708.0, -712.0)
	    frame_005.location = (-3763.0, -141.0)
	    reroute_019_1.location = (-467.51171875, 351.3953552246094)
	    reroute_021.location = (-467.51171875, 311.2093200683594)
	    reroute_022.location = (-467.51171875, 271.0232849121094)
	    reroute_023.location = (-467.51171875, 230.83718872070312)
	    reroute_001_2.location = (135.465087890625, -273.08349609375)
	    reroute_2.location = (180.188720703125, -45.0)
	    set_position_002_1.location = (612.74560546875, -165.0853271484375)
	    switch_002_1.location = (793.582763671875, -64.62017822265625)
	    set_position_1.location = (210.88525390625, -104.8062744140625)
	    vector_math_003_1.location = (30.0478515625, -165.0853271484375)
	    vector_math_004_2.location = (30.0478515625, -205.2713623046875)
	    merge_by_distance.location = (431.908447265625, -185.1783447265625)
	    merge_by_distance_001.location = (431.908447265625, -144.9923095703125)
	    group_input_001_2.location = (30.0478515625, -265.5504150390625)
	    reroute_026.location = (391.722412109375, -205.2713623046875)
	    compare_004_1.location = (230.97802734375, -285.6434326171875)
	    reroute_015_2.location = (-6535.60498046875, 311.2093200683594)
	    reroute_016_2.location = (-6535.60498046875, 271.0232849121094)
	    reroute_013_2.location = (-6535.60498046875, 230.83718872070312)
	    reroute_017_2.location = (-6535.60498046875, 351.3953552246094)
	    group_input_2.location = (-7299.1396484375, 29.906982421875)
	    separate_components_001.location = (-7078.1162109375, 130.37210083007812)
	    group_input_003_2.location = (-7017.837890625, -130.83721923828125)
	    capture_attribute_003.location = (-6837.0, 29.906982421875)
	    group_input_010.location = (-6837.0, -191.11627197265625)
	    capture_attribute_006.location = (-6615.97705078125, 29.906982421875)
	    reroute_005_1.location = (-6314.58154296875, -10.279083251953125)
	    capture_attribute_001_1.location = (-6194.0234375, -130.83721923828125)
	    curve_to_points.location = (-5993.09326171875, -30.372100830078125)
	    index_001_2.location = (-6354.767578125, -251.39535522460938)
	    reroute_014_2.location = (838.720947265625, -52.279083251953125)
	    reroute_027.location = (-3569.653076171875, -70.55813598632812)
	    reroute_007_1.location = (-5731.8837890625, -70.55813598632812)
	    reroute_004_2.location = (35.0, -112.55813598632812)
	    curve_to_points_001.location = (471.720703125, -161.0)
	    group_input_004_1.location = (29.67431640625, -181.093017578125)
	    mesh_to_points.location = (471.720703125, -40.44189453125)
	    separate_components_1.location = (230.6044921875, -100.720947265625)
	    join_geometry_1.location = (672.65087890625, -80.6279296875)
	    domain_size.location = (29.79248046875, -100.5830078125)
	    compare_003_1.location = (210.6298828125, -40.303955078125)
	    group_input_008.location = (189.599609375, -296.9095458984375)
	    reroute_020_1.location = (484.7216796875, -359.65960693359375)
	    sample_nearest_002.location = (537.9306640625, -412.66845703125)
	    sample_index_004.location = (734.16845703125, -343.8978271484375)
	    group_input_009.location = (314.2822265625, -403.006591796875)
	    math_003.location = (1081.162109375, -230.92529296875)
	    capture_attribute_005.location = (912.05322265625, -175.35284423828125)
	    capture_attribute_004.location = (384.44140625, -201.81396484375)
	    switch_003_2.location = (625.5576171875, -101.348876953125)
	    reroute_024.location = (532.91259765625, -80.378173828125)
	    reroute_028.location = (-4506.20947265625, -70.55813598632812)
	    compare_002_1.location = (611.185791015625, -298.1463623046875)
	    boolean_math_1.location = (792.023193359375, -298.1463623046875)
	    random_value_001_1.location = (430.3486328125, -318.2393798828125)
	    switch_2.location = (30.0, -39.7674560546875)
	    delete_geometry_002.location = (1013.04638671875, -117.3092041015625)
	    reroute_008_1.location = (-1994.58154296875, -613.0697631835938)
	    position.location = (204.96826171875, -297.1309814453125)
	    vector_math_002_1.location = (380.771484375, -260.3577880859375)
	    vector_math_001_2.location = (29.95361328125, -248.4031982421875)
	    set_position_001_2.location = (380.731689453125, -150.0113525390625)
	    reroute_010.location = (320.9609375, -160.3013916015625)
	    sample_nearest_007.location = (381.239990234375, -59.8363037109375)
	    switch_001_3.location = (722.8212890625, -39.7432861328125)
	    group_input_007_1.location = (30.19091796875, -40.478729248046875)
	    math_2.location = (391.865234375, -60.571746826171875)
	    math_001.location = (391.865234375, -100.75784301757812)
	    evaluate_at_index_2.location = (211.028076171875, -60.571746826171875)
	    accumulate_field_001.location = (391.865234375, -140.94387817382812)
	    sample_index_003.location = (391.865234375, -181.12991333007812)
	    sample_nearest_001.location = (195.744140625, -313.26953125)
	    index_2.location = (648.4879150390625, -448.82733154296875)
	    sample_index.location = (647.746826171875, -310.1185607910156)
	    sample_index_002.location = (376.581298828125, -212.80441284179688)
	    reroute_018_2.location = (617.6976318359375, -112.55813598632812)
	    sample_nearest_005.location = (550.50927734375, -176.5732421875)
	    compare_1.location = (391.865234375, -221.31594848632812)
	    capture_attribute_002_1.location = (-723.348876953125, 20.0930233001709)
	    compare_001.location = (-723.348876953125, -180.83721923828125)
	    index_002_1.location = (-904.1860961914062, -180.83721923828125)
	    reroute_011_1.location = (-884.093017578125, -120.55814361572266)
	    reroute_012_2.location = (-884.093017578125, -80.3720932006836)
	    join_geometry_001_1.location = (-20.0930233001709, 100.46511840820312)
	    reroute_003_1.location = (-180.83721923828125, -180.83721923828125)
	    reroute_002_1.location = (-180.83721923828125, -140.6511688232422)
	    reroute_009_1.location = (-281.3023376464844, -20.0930233001709)
	    group_output_7.location = (200.93023681640625, 40.1860466003418)
	    reroute_006_1.location = (-522.4186401367188, -60.27907180786133)
	    capture_attribute_1.location = (1020.0968017578125, -39.618896484375)
	    separate_geometry.location = (-241.1162872314453, -40.1860466003418)
	    sample_index_001.location = (847.6214599609375, -217.20046997070312)
	    store_named_attribute_1.location = (-1063.311279296875, 23.636491775512695)
	
	    #Set dimensions
	    frame_003_1.width, frame_003_1.height = 1189.790771484375, 533.0
	    frame_004_1.width, frame_004_1.height = 1183.0, 515.5184326171875
	    frame_006.width, frame_006.height = 843.0, 316.0
	    frame_3.width, frame_3.height = 1251.0, 567.0
	    frame_007.width, frame_007.height = 200.0, 213.0
	    frame_002_2.width, frame_002_2.height = 893.0, 463.0
	    frame_005.width, frame_005.height = 562.0, 276.0
	    reroute_019_1.width, reroute_019_1.height = 10.0, 100.0
	    reroute_021.width, reroute_021.height = 10.0, 100.0
	    reroute_022.width, reroute_022.height = 10.0, 100.0
	    reroute_023.width, reroute_023.height = 10.0, 100.0
	    reroute_001_2.width, reroute_001_2.height = 10.0, 100.0
	    reroute_2.width, reroute_2.height = 10.0, 100.0
	    set_position_002_1.width, set_position_002_1.height = 140.0, 100.0
	    switch_002_1.width, switch_002_1.height = 140.0, 100.0
	    set_position_1.width, set_position_1.height = 140.0, 100.0
	    vector_math_003_1.width, vector_math_003_1.height = 140.0, 100.0
	    vector_math_004_2.width, vector_math_004_2.height = 140.0, 100.0
	    merge_by_distance.width, merge_by_distance.height = 140.0, 100.0
	    merge_by_distance_001.width, merge_by_distance_001.height = 140.0, 100.0
	    group_input_001_2.width, group_input_001_2.height = 140.0, 100.0
	    reroute_026.width, reroute_026.height = 10.0, 100.0
	    compare_004_1.width, compare_004_1.height = 140.0, 100.0
	    reroute_015_2.width, reroute_015_2.height = 10.0, 100.0
	    reroute_016_2.width, reroute_016_2.height = 10.0, 100.0
	    reroute_013_2.width, reroute_013_2.height = 10.0, 100.0
	    reroute_017_2.width, reroute_017_2.height = 10.0, 100.0
	    group_input_2.width, group_input_2.height = 140.0, 100.0
	    separate_components_001.width, separate_components_001.height = 140.0, 100.0
	    group_input_003_2.width, group_input_003_2.height = 140.0, 100.0
	    capture_attribute_003.width, capture_attribute_003.height = 140.0, 100.0
	    group_input_010.width, group_input_010.height = 140.0, 100.0
	    capture_attribute_006.width, capture_attribute_006.height = 140.0, 100.0
	    reroute_005_1.width, reroute_005_1.height = 10.0, 100.0
	    capture_attribute_001_1.width, capture_attribute_001_1.height = 140.0, 100.0
	    curve_to_points.width, curve_to_points.height = 140.0, 100.0
	    index_001_2.width, index_001_2.height = 140.0, 100.0
	    reroute_014_2.width, reroute_014_2.height = 10.0, 100.0
	    reroute_027.width, reroute_027.height = 10.0, 100.0
	    reroute_007_1.width, reroute_007_1.height = 10.0, 100.0
	    reroute_004_2.width, reroute_004_2.height = 10.0, 100.0
	    curve_to_points_001.width, curve_to_points_001.height = 140.0, 100.0
	    group_input_004_1.width, group_input_004_1.height = 140.0, 100.0
	    mesh_to_points.width, mesh_to_points.height = 140.0, 100.0
	    separate_components_1.width, separate_components_1.height = 140.0, 100.0
	    join_geometry_1.width, join_geometry_1.height = 140.0, 100.0
	    domain_size.width, domain_size.height = 140.0, 100.0
	    compare_003_1.width, compare_003_1.height = 140.0, 100.0
	    group_input_008.width, group_input_008.height = 140.0, 100.0
	    reroute_020_1.width, reroute_020_1.height = 10.0, 100.0
	    sample_nearest_002.width, sample_nearest_002.height = 140.0, 100.0
	    sample_index_004.width, sample_index_004.height = 140.0, 100.0
	    group_input_009.width, group_input_009.height = 140.0, 100.0
	    math_003.width, math_003.height = 140.0, 100.0
	    capture_attribute_005.width, capture_attribute_005.height = 140.0, 100.0
	    capture_attribute_004.width, capture_attribute_004.height = 140.0, 100.0
	    switch_003_2.width, switch_003_2.height = 140.0, 100.0
	    reroute_024.width, reroute_024.height = 10.0, 100.0
	    reroute_028.width, reroute_028.height = 10.0, 100.0
	    compare_002_1.width, compare_002_1.height = 140.0, 100.0
	    boolean_math_1.width, boolean_math_1.height = 140.0, 100.0
	    random_value_001_1.width, random_value_001_1.height = 140.0, 100.0
	    switch_2.width, switch_2.height = 140.0, 100.0
	    delete_geometry_002.width, delete_geometry_002.height = 140.0, 100.0
	    reroute_008_1.width, reroute_008_1.height = 10.0, 100.0
	    position.width, position.height = 140.0, 100.0
	    vector_math_002_1.width, vector_math_002_1.height = 140.0, 100.0
	    vector_math_001_2.width, vector_math_001_2.height = 140.0, 100.0
	    set_position_001_2.width, set_position_001_2.height = 140.0, 100.0
	    reroute_010.width, reroute_010.height = 10.0, 100.0
	    sample_nearest_007.width, sample_nearest_007.height = 140.0, 100.0
	    switch_001_3.width, switch_001_3.height = 140.0, 100.0
	    group_input_007_1.width, group_input_007_1.height = 140.0, 100.0
	    math_2.width, math_2.height = 140.0, 100.0
	    math_001.width, math_001.height = 140.0, 100.0
	    evaluate_at_index_2.width, evaluate_at_index_2.height = 140.0, 100.0
	    accumulate_field_001.width, accumulate_field_001.height = 140.0, 100.0
	    sample_index_003.width, sample_index_003.height = 140.0, 100.0
	    sample_nearest_001.width, sample_nearest_001.height = 140.0, 100.0
	    index_2.width, index_2.height = 140.0, 100.0
	    sample_index.width, sample_index.height = 140.0, 100.0
	    sample_index_002.width, sample_index_002.height = 140.0, 100.0
	    reroute_018_2.width, reroute_018_2.height = 10.0, 100.0
	    sample_nearest_005.width, sample_nearest_005.height = 140.0, 100.0
	    compare_1.width, compare_1.height = 140.0, 100.0
	    capture_attribute_002_1.width, capture_attribute_002_1.height = 140.0, 100.0
	    compare_001.width, compare_001.height = 140.0, 100.0
	    index_002_1.width, index_002_1.height = 140.0, 100.0
	    reroute_011_1.width, reroute_011_1.height = 10.0, 100.0
	    reroute_012_2.width, reroute_012_2.height = 10.0, 100.0
	    join_geometry_001_1.width, join_geometry_001_1.height = 140.0, 100.0
	    reroute_003_1.width, reroute_003_1.height = 10.0, 100.0
	    reroute_002_1.width, reroute_002_1.height = 10.0, 100.0
	    reroute_009_1.width, reroute_009_1.height = 10.0, 100.0
	    group_output_7.width, group_output_7.height = 140.0, 100.0
	    reroute_006_1.width, reroute_006_1.height = 10.0, 100.0
	    capture_attribute_1.width, capture_attribute_1.height = 140.0, 100.0
	    separate_geometry.width, separate_geometry.height = 140.0, 100.0
	    sample_index_001.width, sample_index_001.height = 140.0, 100.0
	    store_named_attribute_1.width, store_named_attribute_1.height = 140.0, 100.0
	
	    #initialize create_guide_index_map links
	    #reroute_002_1.Output -> group_output_7.Guide Index
	    create_guide_index_map.links.new(reroute_002_1.outputs[0], group_output_7.inputs[2])
	    #reroute_005_1.Output -> capture_attribute_001_1.Geometry
	    create_guide_index_map.links.new(reroute_005_1.outputs[0], capture_attribute_001_1.inputs[0])
	    #reroute_026.Output -> merge_by_distance.Distance
	    create_guide_index_map.links.new(reroute_026.outputs[0], merge_by_distance.inputs[2])
	    #reroute_018_2.Output -> sample_index_001.Geometry
	    create_guide_index_map.links.new(reroute_018_2.outputs[0], sample_index_001.inputs[0])
	    #sample_index_001.Value -> capture_attribute_1.Value
	    create_guide_index_map.links.new(sample_index_001.outputs[0], capture_attribute_1.inputs[1])
	    #reroute_008_1.Output -> sample_index.Geometry
	    create_guide_index_map.links.new(reroute_008_1.outputs[0], sample_index.inputs[0])
	    #index_001_2.Index -> capture_attribute_001_1.Value
	    create_guide_index_map.links.new(index_001_2.outputs[0], capture_attribute_001_1.inputs[1])
	    #index_2.Index -> sample_index_001.Index
	    create_guide_index_map.links.new(index_2.outputs[0], sample_index_001.inputs[2])
	    #reroute_014_2.Output -> capture_attribute_1.Geometry
	    create_guide_index_map.links.new(reroute_014_2.outputs[0], capture_attribute_1.inputs[0])
	    #reroute_001_2.Output -> sample_nearest_001.Geometry
	    create_guide_index_map.links.new(reroute_001_2.outputs[0], sample_nearest_001.inputs[0])
	    #reroute_001_2.Output -> sample_index_002.Geometry
	    create_guide_index_map.links.new(reroute_001_2.outputs[0], sample_index_002.inputs[0])
	    #sample_nearest_001.Index -> sample_index_002.Index
	    create_guide_index_map.links.new(sample_nearest_001.outputs[0], sample_index_002.inputs[2])
	    #reroute_011_1.Output -> compare_001.A
	    create_guide_index_map.links.new(reroute_011_1.outputs[0], compare_001.inputs[2])
	    #reroute_003_1.Output -> group_output_7.Guide Selection
	    create_guide_index_map.links.new(reroute_003_1.outputs[0], group_output_7.inputs[3])
	    #index_002_1.Index -> compare_001.B
	    create_guide_index_map.links.new(index_002_1.outputs[0], compare_001.inputs[3])
	    #reroute_011_1.Output -> reroute_002_1.Input
	    create_guide_index_map.links.new(reroute_011_1.outputs[0], reroute_002_1.inputs[0])
	    #reroute_006_1.Output -> reroute_003_1.Input
	    create_guide_index_map.links.new(reroute_006_1.outputs[0], reroute_003_1.inputs[0])
	    #reroute_027.Output -> reroute_004_2.Input
	    create_guide_index_map.links.new(reroute_027.outputs[0], reroute_004_2.inputs[0])
	    #curve_to_points.Points -> reroute_007_1.Input
	    create_guide_index_map.links.new(curve_to_points.outputs[0], reroute_007_1.inputs[0])
	    #delete_geometry_002.Geometry -> reroute_008_1.Input
	    create_guide_index_map.links.new(delete_geometry_002.outputs[0], reroute_008_1.inputs[0])
	    #capture_attribute_006.Geometry -> reroute_005_1.Input
	    create_guide_index_map.links.new(capture_attribute_006.outputs[0], reroute_005_1.inputs[0])
	    #reroute_009_1.Output -> separate_geometry.Geometry
	    create_guide_index_map.links.new(reroute_009_1.outputs[0], separate_geometry.inputs[0])
	    #reroute_006_1.Output -> separate_geometry.Selection
	    create_guide_index_map.links.new(reroute_006_1.outputs[0], separate_geometry.inputs[1])
	    #separate_geometry.Selection -> group_output_7.Guide Curves
	    create_guide_index_map.links.new(separate_geometry.outputs[0], group_output_7.inputs[1])
	    #capture_attribute_002_1.Geometry -> reroute_009_1.Input
	    create_guide_index_map.links.new(capture_attribute_002_1.outputs[0], reroute_009_1.inputs[0])
	    #reroute_012_2.Output -> capture_attribute_002_1.Geometry
	    create_guide_index_map.links.new(reroute_012_2.outputs[0], capture_attribute_002_1.inputs[0])
	    #compare_001.Result -> capture_attribute_002_1.Value
	    create_guide_index_map.links.new(compare_001.outputs[0], capture_attribute_002_1.inputs[1])
	    #capture_attribute_002_1.Value -> reroute_006_1.Input
	    create_guide_index_map.links.new(capture_attribute_002_1.outputs[1], reroute_006_1.inputs[0])
	    #random_value_001_1.Value -> compare_002_1.A
	    create_guide_index_map.links.new(random_value_001_1.outputs[1], compare_002_1.inputs[0])
	    #compare_002_1.Result -> boolean_math_1.Boolean
	    create_guide_index_map.links.new(compare_002_1.outputs[0], boolean_math_1.inputs[0])
	    #switch_002_1.Output -> delete_geometry_002.Geometry
	    create_guide_index_map.links.new(switch_002_1.outputs[0], delete_geometry_002.inputs[0])
	    #boolean_math_1.Boolean -> delete_geometry_002.Selection
	    create_guide_index_map.links.new(boolean_math_1.outputs[0], delete_geometry_002.inputs[1])
	    #group_input_003_2.Guide Mask -> capture_attribute_003.Value
	    create_guide_index_map.links.new(group_input_003_2.outputs[3], capture_attribute_003.inputs[1])
	    #reroute_010.Output -> set_position_001_2.Geometry
	    create_guide_index_map.links.new(reroute_010.outputs[0], set_position_001_2.inputs[0])
	    #vector_math_001_2.Vector -> set_position_001_2.Offset
	    create_guide_index_map.links.new(vector_math_001_2.outputs[0], set_position_001_2.inputs[3])
	    #set_position_001_2.Geometry -> sample_nearest_005.Geometry
	    create_guide_index_map.links.new(set_position_001_2.outputs[0], sample_nearest_005.inputs[0])
	    #reroute_010.Output -> sample_nearest_007.Geometry
	    create_guide_index_map.links.new(reroute_010.outputs[0], sample_nearest_007.inputs[0])
	    #vector_math_002_1.Vector -> sample_nearest_005.Sample Position
	    create_guide_index_map.links.new(vector_math_002_1.outputs[0], sample_nearest_005.inputs[1])
	    #position.Position -> vector_math_002_1.Vector
	    create_guide_index_map.links.new(position.outputs[0], vector_math_002_1.inputs[0])
	    #vector_math_001_2.Vector -> vector_math_002_1.Vector
	    create_guide_index_map.links.new(vector_math_001_2.outputs[0], vector_math_002_1.inputs[1])
	    #group_input_004_1.Guides -> separate_components_1.Geometry
	    create_guide_index_map.links.new(group_input_004_1.outputs[1], separate_components_1.inputs[0])
	    #separate_components_1.Mesh -> mesh_to_points.Mesh
	    create_guide_index_map.links.new(separate_components_1.outputs[0], mesh_to_points.inputs[0])
	    #curve_to_points_001.Points -> join_geometry_1.Geometry
	    create_guide_index_map.links.new(curve_to_points_001.outputs[0], join_geometry_1.inputs[0])
	    #capture_attribute_1.Value -> reroute_011_1.Input
	    create_guide_index_map.links.new(capture_attribute_1.outputs[1], reroute_011_1.inputs[0])
	    #domain_size.Point Count -> compare_003_1.A
	    create_guide_index_map.links.new(domain_size.outputs[0], compare_003_1.inputs[2])
	    #store_named_attribute_1.Geometry -> reroute_012_2.Input
	    create_guide_index_map.links.new(store_named_attribute_1.outputs[0], reroute_012_2.inputs[0])
	    #sample_nearest_005.Index -> switch_001_3.True
	    create_guide_index_map.links.new(sample_nearest_005.outputs[0], switch_001_3.inputs[2])
	    #sample_nearest_007.Index -> switch_001_3.False
	    create_guide_index_map.links.new(sample_nearest_007.outputs[0], switch_001_3.inputs[1])
	    #switch_001_3.Output -> sample_index.Index
	    create_guide_index_map.links.new(switch_001_3.outputs[0], sample_index.inputs[2])
	    #reroute_023.Output -> join_geometry_001_1.Geometry
	    create_guide_index_map.links.new(reroute_023.outputs[0], join_geometry_001_1.inputs[0])
	    #separate_components_001.Mesh -> reroute_017_2.Input
	    create_guide_index_map.links.new(separate_components_001.outputs[0], reroute_017_2.inputs[0])
	    #separate_components_001.Instances -> reroute_013_2.Input
	    create_guide_index_map.links.new(separate_components_001.outputs[5], reroute_013_2.inputs[0])
	    #separate_components_001.Point Cloud -> reroute_015_2.Input
	    create_guide_index_map.links.new(separate_components_001.outputs[3], reroute_015_2.inputs[0])
	    #separate_components_001.Volume -> reroute_016_2.Input
	    create_guide_index_map.links.new(separate_components_001.outputs[4], reroute_016_2.inputs[0])
	    #reroute_017_2.Output -> reroute_019_1.Input
	    create_guide_index_map.links.new(reroute_017_2.outputs[0], reroute_019_1.inputs[0])
	    #reroute_015_2.Output -> reroute_021.Input
	    create_guide_index_map.links.new(reroute_015_2.outputs[0], reroute_021.inputs[0])
	    #reroute_013_2.Output -> reroute_023.Input
	    create_guide_index_map.links.new(reroute_013_2.outputs[0], reroute_023.inputs[0])
	    #reroute_016_2.Output -> reroute_022.Input
	    create_guide_index_map.links.new(reroute_016_2.outputs[0], reroute_022.inputs[0])
	    #join_geometry_001_1.Geometry -> group_output_7.Geometry
	    create_guide_index_map.links.new(join_geometry_001_1.outputs[0], group_output_7.inputs[0])
	    #separate_components_001.Curve -> capture_attribute_003.Geometry
	    create_guide_index_map.links.new(separate_components_001.outputs[1], capture_attribute_003.inputs[0])
	    #group_input_2.Geometry -> separate_components_001.Geometry
	    create_guide_index_map.links.new(group_input_2.outputs[0], separate_components_001.inputs[0])
	    #reroute_004_2.Output -> reroute_001_2.Input
	    create_guide_index_map.links.new(reroute_004_2.outputs[0], reroute_001_2.inputs[0])
	    #reroute_005_1.Output -> reroute_014_2.Input
	    create_guide_index_map.links.new(reroute_005_1.outputs[0], reroute_014_2.inputs[0])
	    #reroute_004_2.Output -> reroute_018_2.Input
	    create_guide_index_map.links.new(reroute_004_2.outputs[0], reroute_018_2.inputs[0])
	    #separate_components_1.Curve -> curve_to_points_001.Curve
	    create_guide_index_map.links.new(separate_components_1.outputs[1], curve_to_points_001.inputs[0])
	    #capture_attribute_001_1.Geometry -> curve_to_points.Curve
	    create_guide_index_map.links.new(capture_attribute_001_1.outputs[0], curve_to_points.inputs[0])
	    #set_position_1.Geometry -> merge_by_distance.Geometry
	    create_guide_index_map.links.new(set_position_1.outputs[0], merge_by_distance.inputs[0])
	    #reroute_2.Output -> set_position_1.Geometry
	    create_guide_index_map.links.new(reroute_2.outputs[0], set_position_1.inputs[0])
	    #vector_math_003_1.Vector -> set_position_1.Offset
	    create_guide_index_map.links.new(vector_math_003_1.outputs[0], set_position_1.inputs[3])
	    #merge_by_distance.Geometry -> set_position_002_1.Geometry
	    create_guide_index_map.links.new(merge_by_distance.outputs[0], set_position_002_1.inputs[0])
	    #vector_math_003_1.Vector -> vector_math_004_2.Vector
	    create_guide_index_map.links.new(vector_math_003_1.outputs[0], vector_math_004_2.inputs[0])
	    #vector_math_004_2.Vector -> set_position_002_1.Offset
	    create_guide_index_map.links.new(vector_math_004_2.outputs[0], set_position_002_1.inputs[3])
	    #group_input_007_1.Group ID -> math_2.Value
	    create_guide_index_map.links.new(group_input_007_1.outputs[4], math_2.inputs[0])
	    #group_input_007_1.Group ID -> evaluate_at_index_2.Value
	    create_guide_index_map.links.new(group_input_007_1.outputs[4], evaluate_at_index_2.inputs[1])
	    #reroute_027.Output -> sample_index_003.Geometry
	    create_guide_index_map.links.new(reroute_027.outputs[0], sample_index_003.inputs[0])
	    #evaluate_at_index_2.Value -> math_2.Value
	    create_guide_index_map.links.new(evaluate_at_index_2.outputs[0], math_2.inputs[1])
	    #accumulate_field_001.Total -> sample_index_003.Value
	    create_guide_index_map.links.new(accumulate_field_001.outputs[2], sample_index_003.inputs[1])
	    #math_2.Value -> math_001.Value
	    create_guide_index_map.links.new(math_2.outputs[0], math_001.inputs[0])
	    #sample_index_003.Value -> compare_1.A
	    create_guide_index_map.links.new(sample_index_003.outputs[0], compare_1.inputs[2])
	    #compare_1.Result -> switch_001_3.Switch
	    create_guide_index_map.links.new(compare_1.outputs[0], switch_001_3.inputs[0])
	    #set_position_002_1.Geometry -> switch_002_1.True
	    create_guide_index_map.links.new(set_position_002_1.outputs[0], switch_002_1.inputs[2])
	    #compare_1.Result -> switch_002_1.Switch
	    create_guide_index_map.links.new(compare_1.outputs[0], switch_002_1.inputs[0])
	    #reroute_2.Output -> merge_by_distance_001.Geometry
	    create_guide_index_map.links.new(reroute_2.outputs[0], merge_by_distance_001.inputs[0])
	    #switch_2.Output -> reroute_2.Input
	    create_guide_index_map.links.new(switch_2.outputs[0], reroute_2.inputs[0])
	    #merge_by_distance_001.Geometry -> switch_002_1.False
	    create_guide_index_map.links.new(merge_by_distance_001.outputs[0], switch_002_1.inputs[1])
	    #reroute_026.Output -> merge_by_distance_001.Distance
	    create_guide_index_map.links.new(reroute_026.outputs[0], merge_by_distance_001.inputs[2])
	    #sample_index.Value -> sample_index_001.Value
	    create_guide_index_map.links.new(sample_index.outputs[0], sample_index_001.inputs[1])
	    #capture_attribute_001_1.Value -> sample_index_002.Value
	    create_guide_index_map.links.new(capture_attribute_001_1.outputs[1], sample_index_002.inputs[1])
	    #sample_index_002.Value -> sample_index.Value
	    create_guide_index_map.links.new(sample_index_002.outputs[0], sample_index.inputs[1])
	    #delete_geometry_002.Geometry -> reroute_010.Input
	    create_guide_index_map.links.new(delete_geometry_002.outputs[0], reroute_010.inputs[0])
	    #join_geometry_1.Geometry -> domain_size.Geometry
	    create_guide_index_map.links.new(join_geometry_1.outputs[0], domain_size.inputs[0])
	    #join_geometry_1.Geometry -> capture_attribute_004.Geometry
	    create_guide_index_map.links.new(join_geometry_1.outputs[0], capture_attribute_004.inputs[0])
	    #capture_attribute_003.Value -> switch_003_2.False
	    create_guide_index_map.links.new(capture_attribute_003.outputs[1], switch_003_2.inputs[1])
	    #capture_attribute_004.Value -> switch_003_2.True
	    create_guide_index_map.links.new(capture_attribute_004.outputs[1], switch_003_2.inputs[2])
	    #switch_003_2.Output -> compare_002_1.B
	    create_guide_index_map.links.new(switch_003_2.outputs[0], compare_002_1.inputs[1])
	    #reroute_024.Output -> switch_003_2.Switch
	    create_guide_index_map.links.new(reroute_024.outputs[0], switch_003_2.inputs[0])
	    #compare_003_1.Result -> reroute_024.Input
	    create_guide_index_map.links.new(compare_003_1.outputs[0], reroute_024.inputs[0])
	    #group_input_008.Guide Mask -> capture_attribute_004.Value
	    create_guide_index_map.links.new(group_input_008.outputs[3], capture_attribute_004.inputs[1])
	    #group_input_001_2.Guide Distance -> compare_004_1.A
	    create_guide_index_map.links.new(group_input_001_2.outputs[2], compare_004_1.inputs[0])
	    #compare_004_1.Result -> merge_by_distance.Selection
	    create_guide_index_map.links.new(compare_004_1.outputs[0], merge_by_distance.inputs[1])
	    #compare_004_1.Result -> merge_by_distance_001.Selection
	    create_guide_index_map.links.new(compare_004_1.outputs[0], merge_by_distance_001.inputs[1])
	    #group_input_001_2.Guide Distance -> reroute_026.Input
	    create_guide_index_map.links.new(group_input_001_2.outputs[2], reroute_026.inputs[0])
	    #reroute_020_1.Output -> sample_nearest_002.Geometry
	    create_guide_index_map.links.new(reroute_020_1.outputs[0], sample_nearest_002.inputs[0])
	    #reroute_007_1.Output -> reroute_020_1.Input
	    create_guide_index_map.links.new(reroute_007_1.outputs[0], reroute_020_1.inputs[0])
	    #reroute_020_1.Output -> sample_index_004.Geometry
	    create_guide_index_map.links.new(reroute_020_1.outputs[0], sample_index_004.inputs[0])
	    #sample_nearest_002.Index -> sample_index_004.Index
	    create_guide_index_map.links.new(sample_nearest_002.outputs[0], sample_index_004.inputs[2])
	    #group_input_009.Group ID -> sample_index_004.Value
	    create_guide_index_map.links.new(group_input_009.outputs[4], sample_index_004.inputs[1])
	    #capture_attribute_004.Geometry -> capture_attribute_005.Geometry
	    create_guide_index_map.links.new(capture_attribute_004.outputs[0], capture_attribute_005.inputs[0])
	    #sample_index_004.Value -> capture_attribute_005.Value
	    create_guide_index_map.links.new(sample_index_004.outputs[0], capture_attribute_005.inputs[1])
	    #capture_attribute_003.Geometry -> capture_attribute_006.Geometry
	    create_guide_index_map.links.new(capture_attribute_003.outputs[0], capture_attribute_006.inputs[0])
	    #group_input_010.Group ID -> capture_attribute_006.Value
	    create_guide_index_map.links.new(group_input_010.outputs[4], capture_attribute_006.inputs[1])
	    #capture_attribute_005.Value -> math_003.Value
	    create_guide_index_map.links.new(capture_attribute_005.outputs[1], math_003.inputs[0])
	    #capture_attribute_006.Value -> math_003.Value
	    create_guide_index_map.links.new(capture_attribute_006.outputs[1], math_003.inputs[1])
	    #math_003.Value -> vector_math_003_1.Scale
	    create_guide_index_map.links.new(math_003.outputs[0], vector_math_003_1.inputs[3])
	    #math_003.Value -> vector_math_001_2.Scale
	    create_guide_index_map.links.new(math_003.outputs[0], vector_math_001_2.inputs[3])
	    #reroute_028.Output -> switch_2.False
	    create_guide_index_map.links.new(reroute_028.outputs[0], switch_2.inputs[1])
	    #reroute_024.Output -> switch_2.Switch
	    create_guide_index_map.links.new(reroute_024.outputs[0], switch_2.inputs[0])
	    #capture_attribute_005.Geometry -> switch_2.True
	    create_guide_index_map.links.new(capture_attribute_005.outputs[0], switch_2.inputs[2])
	    #reroute_028.Output -> reroute_027.Input
	    create_guide_index_map.links.new(reroute_028.outputs[0], reroute_027.inputs[0])
	    #reroute_007_1.Output -> reroute_028.Input
	    create_guide_index_map.links.new(reroute_007_1.outputs[0], reroute_028.inputs[0])
	    #capture_attribute_1.Geometry -> store_named_attribute_1.Geometry
	    create_guide_index_map.links.new(capture_attribute_1.outputs[0], store_named_attribute_1.inputs[0])
	    #capture_attribute_1.Value -> store_named_attribute_1.Value
	    create_guide_index_map.links.new(capture_attribute_1.outputs[1], store_named_attribute_1.inputs[3])
	    #separate_components_1.Point Cloud -> join_geometry_1.Geometry
	    create_guide_index_map.links.new(separate_components_1.outputs[3], join_geometry_1.inputs[0])
	    #reroute_022.Output -> join_geometry_001_1.Geometry
	    create_guide_index_map.links.new(reroute_022.outputs[0], join_geometry_001_1.inputs[0])
	    #mesh_to_points.Points -> join_geometry_1.Geometry
	    create_guide_index_map.links.new(mesh_to_points.outputs[0], join_geometry_1.inputs[0])
	    #reroute_009_1.Output -> join_geometry_001_1.Geometry
	    create_guide_index_map.links.new(reroute_009_1.outputs[0], join_geometry_001_1.inputs[0])
	    #reroute_021.Output -> join_geometry_001_1.Geometry
	    create_guide_index_map.links.new(reroute_021.outputs[0], join_geometry_001_1.inputs[0])
	    #reroute_019_1.Output -> join_geometry_001_1.Geometry
	    create_guide_index_map.links.new(reroute_019_1.outputs[0], join_geometry_001_1.inputs[0])
	    return create_guide_index_map
	
	create_guide_index_map = create_guide_index_map_node_group()
	
	#initialize shape_range node group
	def shape_range_node_group():
	    shape_range = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "shape_range")
	
	    shape_range.color_tag = 'NONE'
	    shape_range.description = ""
	    shape_range.default_group_node_width = 140
	    
	
	
	    #shape_range interface
	    #Socket Value
	    value_socket = shape_range.interface.new_socket(name = "Value", in_out='OUTPUT', socket_type = 'NodeSocketFloat')
	    value_socket.default_value = 0.0
	    value_socket.min_value = -3.4028234663852886e+38
	    value_socket.max_value = 3.4028234663852886e+38
	    value_socket.subtype = 'NONE'
	    value_socket.attribute_domain = 'POINT'
	
	    #Socket Value
	    value_socket_1 = shape_range.interface.new_socket(name = "Value", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    value_socket_1.default_value = 0.0
	    value_socket_1.min_value = 0.0
	    value_socket_1.max_value = 1.0
	    value_socket_1.subtype = 'NONE'
	    value_socket_1.attribute_domain = 'POINT'
	    value_socket_1.hide_value = True
	
	    #Socket Min
	    min_socket = shape_range.interface.new_socket(name = "Min", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    min_socket.default_value = 0.0
	    min_socket.min_value = -10000.0
	    min_socket.max_value = 10000.0
	    min_socket.subtype = 'NONE'
	    min_socket.attribute_domain = 'POINT'
	    min_socket.description = "rdghrhd"
	
	    #Socket Max
	    max_socket = shape_range.interface.new_socket(name = "Max", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    max_socket.default_value = 1.0
	    max_socket.min_value = -10000.0
	    max_socket.max_value = 10000.0
	    max_socket.subtype = 'NONE'
	    max_socket.attribute_domain = 'POINT'
	
	    #Socket Shape
	    shape_socket = shape_range.interface.new_socket(name = "Shape", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    shape_socket.default_value = 0.0
	    shape_socket.min_value = -1.0
	    shape_socket.max_value = 1.0
	    shape_socket.subtype = 'NONE'
	    shape_socket.attribute_domain = 'POINT'
	
	    #Socket Base
	    base_socket = shape_range.interface.new_socket(name = "Base", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    base_socket.default_value = 2.0
	    base_socket.min_value = 1.0
	    base_socket.max_value = 10000.0
	    base_socket.subtype = 'NONE'
	    base_socket.attribute_domain = 'POINT'
	
	
	    #initialize shape_range nodes
	    #node Switch.001
	    switch_001_4 = shape_range.nodes.new("GeometryNodeSwitch")
	    switch_001_4.name = "Switch.001"
	    switch_001_4.hide = True
	    switch_001_4.input_type = 'FLOAT'
	
	    #node Math.016
	    math_016 = shape_range.nodes.new("ShaderNodeMath")
	    math_016.name = "Math.016"
	    math_016.hide = True
	    math_016.operation = 'SUBTRACT'
	    math_016.use_clamp = False
	    #Value
	    math_016.inputs[0].default_value = 1.0
	
	    #node Math.004
	    math_004 = shape_range.nodes.new("ShaderNodeMath")
	    math_004.name = "Math.004"
	    math_004.hide = True
	    math_004.operation = 'SUBTRACT'
	    math_004.use_clamp = False
	    #Value
	    math_004.inputs[0].default_value = 1.0
	
	    #node Reroute
	    reroute_3 = shape_range.nodes.new("NodeReroute")
	    reroute_3.name = "Reroute"
	    reroute_3.socket_idname = "NodeSocketFloat"
	    #node Map Range
	    map_range = shape_range.nodes.new("ShaderNodeMapRange")
	    map_range.name = "Map Range"
	    map_range.hide = True
	    map_range.clamp = False
	    map_range.data_type = 'FLOAT'
	    map_range.interpolation_type = 'LINEAR'
	    map_range.inputs[3].hide = True
	    map_range.inputs[4].hide = True
	    map_range.inputs[5].hide = True
	    map_range.inputs[6].hide = True
	    map_range.inputs[7].hide = True
	    map_range.inputs[8].hide = True
	    map_range.inputs[9].hide = True
	    map_range.inputs[10].hide = True
	    map_range.inputs[11].hide = True
	    map_range.outputs[1].hide = True
	    #To Min
	    map_range.inputs[3].default_value = 0.0
	    #To Max
	    map_range.inputs[4].default_value = 1.0
	
	    #node Math.001
	    math_001_1 = shape_range.nodes.new("ShaderNodeMath")
	    math_001_1.name = "Math.001"
	    math_001_1.hide = True
	    math_001_1.operation = 'DIVIDE'
	    math_001_1.use_clamp = False
	    #Value
	    math_001_1.inputs[0].default_value = 1.0
	
	    #node Math.012
	    math_012 = shape_range.nodes.new("ShaderNodeMath")
	    math_012.name = "Math.012"
	    math_012.hide = True
	    math_012.operation = 'SUBTRACT'
	    math_012.use_clamp = False
	    #Value
	    math_012.inputs[0].default_value = 1.0
	
	    #node Math.013
	    math_013 = shape_range.nodes.new("ShaderNodeMath")
	    math_013.name = "Math.013"
	    math_013.hide = True
	    math_013.operation = 'MULTIPLY'
	    math_013.use_clamp = False
	    #Value_001
	    math_013.inputs[1].default_value = 2.0
	
	    #node Math
	    math_3 = shape_range.nodes.new("ShaderNodeMath")
	    math_3.name = "Math"
	    math_3.hide = True
	    math_3.operation = 'MULTIPLY'
	    math_3.use_clamp = False
	
	    #node Reroute.001
	    reroute_001_3 = shape_range.nodes.new("NodeReroute")
	    reroute_001_3.name = "Reroute.001"
	    reroute_001_3.socket_idname = "NodeSocketFloat"
	    #node Compare.004
	    compare_004_2 = shape_range.nodes.new("FunctionNodeCompare")
	    compare_004_2.name = "Compare.004"
	    compare_004_2.hide = True
	    compare_004_2.data_type = 'FLOAT'
	    compare_004_2.mode = 'ELEMENT'
	    compare_004_2.operation = 'LESS_THAN'
	    #B
	    compare_004_2.inputs[1].default_value = 0.0
	
	    #node Compare
	    compare_2 = shape_range.nodes.new("FunctionNodeCompare")
	    compare_2.name = "Compare"
	    compare_2.hide = True
	    compare_2.data_type = 'FLOAT'
	    compare_2.mode = 'ELEMENT'
	    compare_2.operation = 'GREATER_THAN'
	    #B
	    compare_2.inputs[1].default_value = 0.5
	
	    #node Boolean Math.002
	    boolean_math_002_1 = shape_range.nodes.new("FunctionNodeBooleanMath")
	    boolean_math_002_1.name = "Boolean Math.002"
	    boolean_math_002_1.hide = True
	    boolean_math_002_1.operation = 'NOT'
	
	    #node Switch
	    switch_3 = shape_range.nodes.new("GeometryNodeSwitch")
	    switch_3.name = "Switch"
	    switch_3.hide = True
	    switch_3.input_type = 'BOOLEAN'
	
	    #node Math.014
	    math_014 = shape_range.nodes.new("ShaderNodeMath")
	    math_014.name = "Math.014"
	    math_014.hide = True
	    math_014.operation = 'MAXIMUM'
	    math_014.use_clamp = False
	    #Value_001
	    math_014.inputs[1].default_value = 1.0000100135803223
	
	    #node Math.006
	    math_006 = shape_range.nodes.new("ShaderNodeMath")
	    math_006.name = "Math.006"
	    math_006.hide = True
	    math_006.operation = 'MULTIPLY'
	    math_006.use_clamp = False
	    #Value_001
	    math_006.inputs[1].default_value = -1.0
	
	    #node Math.007
	    math_007 = shape_range.nodes.new("ShaderNodeMath")
	    math_007.name = "Math.007"
	    math_007.hide = True
	    math_007.operation = 'SUBTRACT'
	    math_007.use_clamp = False
	    #Value
	    math_007.inputs[0].default_value = 1.0
	
	    #node Math.010
	    math_010 = shape_range.nodes.new("ShaderNodeMath")
	    math_010.name = "Math.010"
	    math_010.hide = True
	    math_010.operation = 'MAXIMUM'
	    math_010.use_clamp = False
	    #Value_001
	    math_010.inputs[1].default_value = 1.0000009536743164
	
	    #node Math.009
	    math_009 = shape_range.nodes.new("ShaderNodeMath")
	    math_009.name = "Math.009"
	    math_009.hide = True
	    math_009.operation = 'MAXIMUM'
	    math_009.use_clamp = False
	    #Value_001
	    math_009.inputs[1].default_value = 9.999999747378752e-06
	
	    #node Math.002
	    math_002 = shape_range.nodes.new("ShaderNodeMath")
	    math_002.name = "Math.002"
	    math_002.operation = 'POWER'
	    math_002.use_clamp = False
	
	    #node Math.005
	    math_005 = shape_range.nodes.new("ShaderNodeMath")
	    math_005.name = "Math.005"
	    math_005.hide = True
	    math_005.operation = 'LOGARITHM'
	    math_005.use_clamp = False
	
	    #node Math.015
	    math_015 = shape_range.nodes.new("ShaderNodeMath")
	    math_015.name = "Math.015"
	    math_015.hide = True
	    math_015.operation = 'PINGPONG'
	    math_015.use_clamp = False
	    #Value_001
	    math_015.inputs[1].default_value = 0.5
	
	    #node Math.017
	    math_017 = shape_range.nodes.new("ShaderNodeMath")
	    math_017.name = "Math.017"
	    math_017.operation = 'MINIMUM'
	    math_017.use_clamp = False
	    #Value_001
	    math_017.inputs[1].default_value = 0.9999989867210388
	
	    #node Math.003
	    math_003_1 = shape_range.nodes.new("ShaderNodeMath")
	    math_003_1.name = "Math.003"
	    math_003_1.operation = 'ABSOLUTE'
	    math_003_1.use_clamp = False
	
	    #node Map Range.001
	    map_range_001 = shape_range.nodes.new("ShaderNodeMapRange")
	    map_range_001.name = "Map Range.001"
	    map_range_001.clamp = True
	    map_range_001.data_type = 'FLOAT'
	    map_range_001.interpolation_type = 'LINEAR'
	    map_range_001.inputs[1].hide = True
	    map_range_001.inputs[2].hide = True
	    map_range_001.inputs[5].hide = True
	    map_range_001.inputs[6].hide = True
	    map_range_001.inputs[7].hide = True
	    map_range_001.inputs[8].hide = True
	    map_range_001.inputs[9].hide = True
	    map_range_001.inputs[10].hide = True
	    map_range_001.inputs[11].hide = True
	    map_range_001.outputs[1].hide = True
	    #From Min
	    map_range_001.inputs[1].default_value = 0.0
	    #From Max
	    map_range_001.inputs[2].default_value = 1.0
	
	    #node Group Input
	    group_input_3 = shape_range.nodes.new("NodeGroupInput")
	    group_input_3.name = "Group Input"
	
	    #node Group Output
	    group_output_8 = shape_range.nodes.new("NodeGroupOutput")
	    group_output_8.name = "Group Output"
	    group_output_8.is_active_output = True
	
	    #node Switch.002
	    switch_002_2 = shape_range.nodes.new("GeometryNodeSwitch")
	    switch_002_2.name = "Switch.002"
	    switch_002_2.hide = True
	    switch_002_2.input_type = 'FLOAT'
	
	    #node Switch.003
	    switch_003_3 = shape_range.nodes.new("GeometryNodeSwitch")
	    switch_003_3.name = "Switch.003"
	    switch_003_3.input_type = 'FLOAT'
	    #True
	    switch_003_3.inputs[2].default_value = 1.0
	
	    #node Compare.001
	    compare_001_1 = shape_range.nodes.new("FunctionNodeCompare")
	    compare_001_1.name = "Compare.001"
	    compare_001_1.data_type = 'FLOAT'
	    compare_001_1.mode = 'ELEMENT'
	    compare_001_1.operation = 'EQUAL'
	    #B
	    compare_001_1.inputs[1].default_value = 0.0
	    #Epsilon
	    compare_001_1.inputs[12].default_value = 9.999999747378752e-06
	
	
	
	
	
	    #Set locations
	    switch_001_4.location = (-1034.40283203125, 93.75666046142578)
	    math_016.location = (-632.5424194335938, 53.57061004638672)
	    math_004.location = (-1295.6121826171875, 133.94271850585938)
	    reroute_3.location = (-1315.7052001953125, 93.75666046142578)
	    map_range.location = (-1516.635498046875, 73.66363525390625)
	    math_001_1.location = (-1858.2169189453125, -147.359619140625)
	    math_012.location = (-1858.2169189453125, -107.17357635498047)
	    math_013.location = (-1858.2169189453125, -66.9875259399414)
	    math_3.location = (-1858.2169189453125, -26.801475524902344)
	    reroute_001_3.location = (-2119.42626953125, -147.359619140625)
	    compare_004_2.location = (-1637.193603515625, -66.9875259399414)
	    compare_2.location = (-1637.193603515625, -107.17357635498047)
	    boolean_math_002_1.location = (-1456.3564453125, -107.17357635498047)
	    switch_3.location = (-1456.3564453125, -66.9875259399414)
	    math_014.location = (-2059.14697265625, -107.17357635498047)
	    math_006.location = (-1034.40283203125, -87.0805435180664)
	    math_007.location = (-1034.40283203125, 33.47759246826172)
	    math_010.location = (-1195.1470947265625, -107.17357635498047)
	    math_009.location = (-1034.40283203125, -6.708457946777344)
	    math_002.location = (-833.47265625, 113.84968566894531)
	    math_005.location = (-1034.40283203125, -46.894508361816406)
	    math_015.location = (-2059.14697265625, -147.359619140625)
	    math_017.location = (-2280.17041015625, -127.26660919189453)
	    math_003_1.location = (-2461.007568359375, -127.26660919189453)
	    map_range_001.location = (-411.5191650390625, 53.57061004638672)
	    group_input_3.location = (-2682.03076171875, 13.384567260742188)
	    group_output_8.location = (75.0, 50.0)
	    switch_002_2.location = (-632.5424194335938, 93.75666046142578)
	    switch_003_3.location = (-164.938232421875, 110.71707153320312)
	    compare_001_1.location = (-828.0901489257812, 397.66241455078125)
	
	    #Set dimensions
	    switch_001_4.width, switch_001_4.height = 140.0, 100.0
	    math_016.width, math_016.height = 140.0, 100.0
	    math_004.width, math_004.height = 140.0, 100.0
	    reroute_3.width, reroute_3.height = 10.0, 100.0
	    map_range.width, map_range.height = 140.0, 100.0
	    math_001_1.width, math_001_1.height = 140.0, 100.0
	    math_012.width, math_012.height = 140.0, 100.0
	    math_013.width, math_013.height = 140.0, 100.0
	    math_3.width, math_3.height = 140.0, 100.0
	    reroute_001_3.width, reroute_001_3.height = 10.0, 100.0
	    compare_004_2.width, compare_004_2.height = 140.0, 100.0
	    compare_2.width, compare_2.height = 140.0, 100.0
	    boolean_math_002_1.width, boolean_math_002_1.height = 140.0, 100.0
	    switch_3.width, switch_3.height = 140.0, 100.0
	    math_014.width, math_014.height = 140.0, 100.0
	    math_006.width, math_006.height = 140.0, 100.0
	    math_007.width, math_007.height = 140.0, 100.0
	    math_010.width, math_010.height = 140.0, 100.0
	    math_009.width, math_009.height = 140.0, 100.0
	    math_002.width, math_002.height = 140.0, 100.0
	    math_005.width, math_005.height = 140.0, 100.0
	    math_015.width, math_015.height = 140.0, 100.0
	    math_017.width, math_017.height = 140.0, 100.0
	    math_003_1.width, math_003_1.height = 140.0, 100.0
	    map_range_001.width, map_range_001.height = 140.0, 100.0
	    group_input_3.width, group_input_3.height = 140.0, 100.0
	    group_output_8.width, group_output_8.height = 140.0, 100.0
	    switch_002_2.width, switch_002_2.height = 140.0, 100.0
	    switch_003_3.width, switch_003_3.height = 140.0, 100.0
	    compare_001_1.width, compare_001_1.height = 140.0, 100.0
	
	    #initialize shape_range links
	    #math_009.Value -> math_005.Value
	    shape_range.links.new(math_009.outputs[0], math_005.inputs[0])
	    #math_005.Value -> math_006.Value
	    shape_range.links.new(math_005.outputs[0], math_006.inputs[0])
	    #math_004.Value -> switch_001_4.True
	    shape_range.links.new(math_004.outputs[0], switch_001_4.inputs[2])
	    #math_3.Value -> math_007.Value
	    shape_range.links.new(math_3.outputs[0], math_007.inputs[1])
	    #switch_001_4.Output -> math_002.Value
	    shape_range.links.new(switch_001_4.outputs[0], math_002.inputs[0])
	    #reroute_3.Output -> math_004.Value
	    shape_range.links.new(reroute_3.outputs[0], math_004.inputs[1])
	    #math_006.Value -> math_002.Value
	    shape_range.links.new(math_006.outputs[0], math_002.inputs[1])
	    #reroute_3.Output -> switch_001_4.False
	    shape_range.links.new(reroute_3.outputs[0], switch_001_4.inputs[1])
	    #math_010.Value -> math_005.Value
	    shape_range.links.new(math_010.outputs[0], math_005.inputs[1])
	    #map_range.Result -> reroute_3.Input
	    shape_range.links.new(map_range.outputs[0], reroute_3.inputs[0])
	    #group_input_3.Value -> map_range.Value
	    shape_range.links.new(group_input_3.outputs[0], map_range.inputs[0])
	    #group_input_3.Min -> map_range.From Min
	    shape_range.links.new(group_input_3.outputs[1], map_range.inputs[1])
	    #group_input_3.Max -> map_range.From Max
	    shape_range.links.new(group_input_3.outputs[2], map_range.inputs[2])
	    #switch_002_2.Output -> map_range_001.Value
	    shape_range.links.new(switch_002_2.outputs[0], map_range_001.inputs[0])
	    #group_input_3.Min -> map_range_001.To Min
	    shape_range.links.new(group_input_3.outputs[1], map_range_001.inputs[3])
	    #group_input_3.Max -> map_range_001.To Max
	    shape_range.links.new(group_input_3.outputs[2], map_range_001.inputs[4])
	    #math_007.Value -> math_009.Value
	    shape_range.links.new(math_007.outputs[0], math_009.inputs[0])
	    #math_014.Value -> math_010.Value
	    shape_range.links.new(math_014.outputs[0], math_010.inputs[0])
	    #switch_003_3.Output -> group_output_8.Value
	    shape_range.links.new(switch_003_3.outputs[0], group_output_8.inputs[0])
	    #math_013.Value -> math_3.Value
	    shape_range.links.new(math_013.outputs[0], math_3.inputs[1])
	    #math_001_1.Value -> math_012.Value
	    shape_range.links.new(math_001_1.outputs[0], math_012.inputs[1])
	    #math_014.Value -> math_001_1.Value
	    shape_range.links.new(math_014.outputs[0], math_001_1.inputs[1])
	    #math_012.Value -> math_013.Value
	    shape_range.links.new(math_012.outputs[0], math_013.inputs[0])
	    #group_input_3.Base -> math_014.Value
	    shape_range.links.new(group_input_3.outputs[4], math_014.inputs[0])
	    #math_015.Value -> math_3.Value
	    shape_range.links.new(math_015.outputs[0], math_3.inputs[0])
	    #reroute_001_3.Output -> math_015.Value
	    shape_range.links.new(reroute_001_3.outputs[0], math_015.inputs[0])
	    #switch_3.Output -> switch_001_4.Switch
	    shape_range.links.new(switch_3.outputs[0], switch_001_4.inputs[0])
	    #reroute_001_3.Output -> compare_2.A
	    shape_range.links.new(reroute_001_3.outputs[0], compare_2.inputs[0])
	    #math_002.Value -> switch_002_2.False
	    shape_range.links.new(math_002.outputs[0], switch_002_2.inputs[1])
	    #math_016.Value -> switch_002_2.True
	    shape_range.links.new(math_016.outputs[0], switch_002_2.inputs[2])
	    #compare_2.Result -> switch_002_2.Switch
	    shape_range.links.new(compare_2.outputs[0], switch_002_2.inputs[0])
	    #math_002.Value -> math_016.Value
	    shape_range.links.new(math_002.outputs[0], math_016.inputs[1])
	    #group_input_3.Shape -> compare_004_2.A
	    shape_range.links.new(group_input_3.outputs[3], compare_004_2.inputs[0])
	    #math_017.Value -> reroute_001_3.Input
	    shape_range.links.new(math_017.outputs[0], reroute_001_3.inputs[0])
	    #group_input_3.Shape -> math_003_1.Value
	    shape_range.links.new(group_input_3.outputs[3], math_003_1.inputs[0])
	    #compare_004_2.Result -> boolean_math_002_1.Boolean
	    shape_range.links.new(compare_004_2.outputs[0], boolean_math_002_1.inputs[0])
	    #compare_2.Result -> switch_3.Switch
	    shape_range.links.new(compare_2.outputs[0], switch_3.inputs[0])
	    #compare_004_2.Result -> switch_3.False
	    shape_range.links.new(compare_004_2.outputs[0], switch_3.inputs[1])
	    #boolean_math_002_1.Boolean -> switch_3.True
	    shape_range.links.new(boolean_math_002_1.outputs[0], switch_3.inputs[2])
	    #math_003_1.Value -> math_017.Value
	    shape_range.links.new(math_003_1.outputs[0], math_017.inputs[0])
	    #group_input_3.Shape -> compare_001_1.A
	    shape_range.links.new(group_input_3.outputs[3], compare_001_1.inputs[0])
	    #map_range_001.Result -> switch_003_3.False
	    shape_range.links.new(map_range_001.outputs[0], switch_003_3.inputs[1])
	    #compare_001_1.Result -> switch_003_3.Switch
	    shape_range.links.new(compare_001_1.outputs[0], switch_003_3.inputs[0])
	    return shape_range
	
	shape_range = shape_range_node_group()
	
	#initialize clump_hair_curves node group
	def clump_hair_curves_node_group():
	    clump_hair_curves = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Clump Hair Curves")
	
	    clump_hair_curves.color_tag = 'NONE'
	    clump_hair_curves.description = "Clumps together existing hair curves using guide curves"
	    clump_hair_curves.default_group_node_width = 140
	    
	
	    clump_hair_curves.is_modifier = True
	
	    #clump_hair_curves interface
	    #Socket Geometry
	    geometry_socket_4 = clump_hair_curves.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_4.attribute_domain = 'POINT'
	
	    #Socket Guide Index
	    guide_index_socket_2 = clump_hair_curves.interface.new_socket(name = "Guide Index", in_out='OUTPUT', socket_type = 'NodeSocketInt')
	    guide_index_socket_2.default_value = 0
	    guide_index_socket_2.min_value = -2147483648
	    guide_index_socket_2.max_value = 2147483647
	    guide_index_socket_2.subtype = 'NONE'
	    guide_index_socket_2.attribute_domain = 'CURVE'
	    guide_index_socket_2.description = "Guide index map that was used for the operation"
	
	    #Socket Geometry
	    geometry_socket_5 = clump_hair_curves.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_5.attribute_domain = 'POINT'
	    geometry_socket_5.description = "Input Geometry (May include other than curves)"
	
	    #Socket Guide Index
	    guide_index_socket_3 = clump_hair_curves.interface.new_socket(name = "Guide Index", in_out='INPUT', socket_type = 'NodeSocketInt')
	    guide_index_socket_3.default_value = -987654
	    guide_index_socket_3.min_value = -2147483648
	    guide_index_socket_3.max_value = 2147483647
	    guide_index_socket_3.subtype = 'NONE'
	    guide_index_socket_3.attribute_domain = 'POINT'
	    guide_index_socket_3.hide_value = True
	    guide_index_socket_3.hide_in_modifier = True
	    guide_index_socket_3.description = "Guide index map to be used. This input has priority"
	
	    #Socket Guide Distance
	    guide_distance_socket_1 = clump_hair_curves.interface.new_socket(name = "Guide Distance", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    guide_distance_socket_1.default_value = 0.10000000149011612
	    guide_distance_socket_1.min_value = 0.0
	    guide_distance_socket_1.max_value = 3.4028234663852886e+38
	    guide_distance_socket_1.subtype = 'DISTANCE'
	    guide_distance_socket_1.attribute_domain = 'POINT'
	    guide_distance_socket_1.description = "Minimum distance between two guides for new guide map"
	
	    #Socket Guide Mask
	    guide_mask_socket_1 = clump_hair_curves.interface.new_socket(name = "Guide Mask", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    guide_mask_socket_1.default_value = 1.0
	    guide_mask_socket_1.min_value = 0.0
	    guide_mask_socket_1.max_value = 1.0
	    guide_mask_socket_1.subtype = 'NONE'
	    guide_mask_socket_1.attribute_domain = 'POINT'
	    guide_mask_socket_1.description = "Mask for which curves are eligible to be selected as guides"
	
	    #Socket Existing Guide Map
	    existing_guide_map_socket = clump_hair_curves.interface.new_socket(name = "Existing Guide Map", in_out='INPUT', socket_type = 'NodeSocketBool')
	    existing_guide_map_socket.default_value = True
	    existing_guide_map_socket.attribute_domain = 'POINT'
	    existing_guide_map_socket.description = "Use the existing guide map attribute if available"
	
	    #Socket Factor
	    factor_socket_1 = clump_hair_curves.interface.new_socket(name = "Factor", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    factor_socket_1.default_value = 1.0
	    factor_socket_1.min_value = 0.0
	    factor_socket_1.max_value = 1.0
	    factor_socket_1.subtype = 'FACTOR'
	    factor_socket_1.attribute_domain = 'POINT'
	    factor_socket_1.description = "Factor to blend overall effect"
	
	    #Socket Shape
	    shape_socket_1 = clump_hair_curves.interface.new_socket(name = "Shape", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    shape_socket_1.default_value = 0.5
	    shape_socket_1.min_value = -1.0
	    shape_socket_1.max_value = 1.0
	    shape_socket_1.subtype = 'NONE'
	    shape_socket_1.attribute_domain = 'POINT'
	    shape_socket_1.description = "Shape of the influence along curves (0=constant, 0.5=linear)"
	
	    #Socket Tip Spread
	    tip_spread_socket = clump_hair_curves.interface.new_socket(name = "Tip Spread", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    tip_spread_socket.default_value = 0.0
	    tip_spread_socket.min_value = 0.0
	    tip_spread_socket.max_value = 10.0
	    tip_spread_socket.subtype = 'NONE'
	    tip_spread_socket.attribute_domain = 'POINT'
	    tip_spread_socket.description = "Distance of random spread at the curve tips"
	
	    #Socket Clump Offset
	    clump_offset_socket = clump_hair_curves.interface.new_socket(name = "Clump Offset", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    clump_offset_socket.default_value = 0.0
	    clump_offset_socket.min_value = -3.4028234663852886e+38
	    clump_offset_socket.max_value = 3.4028234663852886e+38
	    clump_offset_socket.subtype = 'DISTANCE'
	    clump_offset_socket.attribute_domain = 'POINT'
	    clump_offset_socket.description = "Offset of each clump in a random direction"
	
	    #Socket Distance Falloff
	    distance_falloff_socket = clump_hair_curves.interface.new_socket(name = "Distance Falloff", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    distance_falloff_socket.default_value = 0.0
	    distance_falloff_socket.min_value = 0.0
	    distance_falloff_socket.max_value = 3.4028234663852886e+38
	    distance_falloff_socket.subtype = 'DISTANCE'
	    distance_falloff_socket.attribute_domain = 'POINT'
	    distance_falloff_socket.description = "Falloff distance for the clumping effect (0 means no falloff)"
	
	    #Socket Distance Threshold
	    distance_threshold_socket = clump_hair_curves.interface.new_socket(name = "Distance Threshold", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    distance_threshold_socket.default_value = 0.0
	    distance_threshold_socket.min_value = 0.0
	    distance_threshold_socket.max_value = 3.4028234663852886e+38
	    distance_threshold_socket.subtype = 'DISTANCE'
	    distance_threshold_socket.attribute_domain = 'POINT'
	    distance_threshold_socket.description = "Distance threshold for the falloff around the guide"
	
	    #Socket Seed
	    seed_socket_1 = clump_hair_curves.interface.new_socket(name = "Seed", in_out='INPUT', socket_type = 'NodeSocketInt')
	    seed_socket_1.default_value = 0
	    seed_socket_1.min_value = -10000
	    seed_socket_1.max_value = 10000
	    seed_socket_1.subtype = 'NONE'
	    seed_socket_1.attribute_domain = 'POINT'
	    seed_socket_1.description = "Random seed for the operation"
	
	    #Socket Preserve Length
	    preserve_length_socket = clump_hair_curves.interface.new_socket(name = "Preserve Length", in_out='INPUT', socket_type = 'NodeSocketBool')
	    preserve_length_socket.default_value = False
	    preserve_length_socket.attribute_domain = 'POINT'
	    preserve_length_socket.description = "Preserve each curve's length during deformation"
	
	
	    #initialize clump_hair_curves nodes
	    #node Frame.001
	    frame_001_2 = clump_hair_curves.nodes.new("NodeFrame")
	    frame_001_2.label = "Optimization"
	    frame_001_2.name = "Frame.001"
	    frame_001_2.label_size = 20
	    frame_001_2.shrink = True
	
	    #node Frame
	    frame_4 = clump_hair_curves.nodes.new("NodeFrame")
	    frame_4.label = "Optimization"
	    frame_4.name = "Frame"
	    frame_4.label_size = 20
	    frame_4.shrink = True
	
	    #node Frame.003
	    frame_003_2 = clump_hair_curves.nodes.new("NodeFrame")
	    frame_003_2.label = "Length Preservation"
	    frame_003_2.name = "Frame.003"
	    frame_003_2.label_size = 20
	    frame_003_2.shrink = True
	
	    #node Frame.005
	    frame_005_1 = clump_hair_curves.nodes.new("NodeFrame")
	    frame_005_1.name = "Frame.005"
	    frame_005_1.label_size = 20
	    frame_005_1.shrink = True
	
	    #node Frame.006
	    frame_006_1 = clump_hair_curves.nodes.new("NodeFrame")
	    frame_006_1.label = "Displacement"
	    frame_006_1.name = "Frame.006"
	    frame_006_1.label_size = 20
	    frame_006_1.shrink = True
	
	    #node Frame.007
	    frame_007_1 = clump_hair_curves.nodes.new("NodeFrame")
	    frame_007_1.label = "Guide Map Fallback"
	    frame_007_1.name = "Frame.007"
	    frame_007_1.label_size = 20
	    frame_007_1.shrink = True
	
	    #node Frame.002
	    frame_002_3 = clump_hair_curves.nodes.new("NodeFrame")
	    frame_002_3.label = "Random Displacement"
	    frame_002_3.name = "Frame.002"
	    frame_002_3.label_size = 20
	    frame_002_3.shrink = True
	
	    #node Frame.004
	    frame_004_2 = clump_hair_curves.nodes.new("NodeFrame")
	    frame_004_2.label = "Root Distance Falloff"
	    frame_004_2.name = "Frame.004"
	    frame_004_2.label_size = 20
	    frame_004_2.shrink = True
	
	    #node Group Input.003
	    group_input_003_3 = clump_hair_curves.nodes.new("NodeGroupInput")
	    group_input_003_3.name = "Group Input.003"
	    group_input_003_3.outputs[1].hide = True
	    group_input_003_3.outputs[2].hide = True
	    group_input_003_3.outputs[3].hide = True
	    group_input_003_3.outputs[4].hide = True
	    group_input_003_3.outputs[5].hide = True
	    group_input_003_3.outputs[6].hide = True
	    group_input_003_3.outputs[7].hide = True
	    group_input_003_3.outputs[8].hide = True
	    group_input_003_3.outputs[9].hide = True
	    group_input_003_3.outputs[10].hide = True
	    group_input_003_3.outputs[11].hide = True
	    group_input_003_3.outputs[12].hide = True
	
	    #node Reroute.014
	    reroute_014_3 = clump_hair_curves.nodes.new("NodeReroute")
	    reroute_014_3.name = "Reroute.014"
	    reroute_014_3.socket_idname = "NodeSocketGeometry"
	    #node Reroute.015
	    reroute_015_3 = clump_hair_curves.nodes.new("NodeReroute")
	    reroute_015_3.name = "Reroute.015"
	    reroute_015_3.socket_idname = "NodeSocketGeometry"
	    #node Reroute.013
	    reroute_013_3 = clump_hair_curves.nodes.new("NodeReroute")
	    reroute_013_3.name = "Reroute.013"
	    reroute_013_3.socket_idname = "NodeSocketGeometry"
	    #node Reroute.012
	    reroute_012_3 = clump_hair_curves.nodes.new("NodeReroute")
	    reroute_012_3.name = "Reroute.012"
	    reroute_012_3.socket_idname = "NodeSocketGeometry"
	    #node Separate Components
	    separate_components_2 = clump_hair_curves.nodes.new("GeometryNodeSeparateComponents")
	    separate_components_2.name = "Separate Components"
	
	    #node Group Output.001
	    group_output_001 = clump_hair_curves.nodes.new("NodeGroupOutput")
	    group_output_001.name = "Group Output.001"
	    group_output_001.is_active_output = True
	
	    #node Join Geometry.001
	    join_geometry_001_2 = clump_hair_curves.nodes.new("GeometryNodeJoinGeometry")
	    join_geometry_001_2.name = "Join Geometry.001"
	
	    #node Reroute.016
	    reroute_016_3 = clump_hair_curves.nodes.new("NodeReroute")
	    reroute_016_3.name = "Reroute.016"
	    reroute_016_3.socket_idname = "NodeSocketGeometry"
	    #node Reroute.017
	    reroute_017_3 = clump_hair_curves.nodes.new("NodeReroute")
	    reroute_017_3.name = "Reroute.017"
	    reroute_017_3.socket_idname = "NodeSocketGeometry"
	    #node Reroute.019
	    reroute_019_2 = clump_hair_curves.nodes.new("NodeReroute")
	    reroute_019_2.name = "Reroute.019"
	    reroute_019_2.socket_idname = "NodeSocketGeometry"
	    #node Reroute.018
	    reroute_018_3 = clump_hair_curves.nodes.new("NodeReroute")
	    reroute_018_3.name = "Reroute.018"
	    reroute_018_3.socket_idname = "NodeSocketGeometry"
	    #node Capture Attribute
	    capture_attribute_2 = clump_hair_curves.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_2.name = "Capture Attribute"
	    capture_attribute_2.active_index = 0
	    capture_attribute_2.capture_items.clear()
	    capture_attribute_2.capture_items.new('FLOAT', "Value")
	    capture_attribute_2.capture_items["Value"].data_type = 'FLOAT_VECTOR'
	    capture_attribute_2.domain = 'POINT'
	
	    #node Position.001
	    position_001_1 = clump_hair_curves.nodes.new("GeometryNodeInputPosition")
	    position_001_1.name = "Position.001"
	
	    #node Capture Attribute.002
	    capture_attribute_002_2 = clump_hair_curves.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_002_2.name = "Capture Attribute.002"
	    capture_attribute_002_2.active_index = 0
	    capture_attribute_002_2.capture_items.clear()
	    capture_attribute_002_2.capture_items.new('FLOAT', "Value")
	    capture_attribute_002_2.capture_items["Value"].data_type = 'INT'
	    capture_attribute_002_2.domain = 'CURVE'
	
	    #node Spline Resolution
	    spline_resolution = clump_hair_curves.nodes.new("GeometryNodeInputSplineResolution")
	    spline_resolution.name = "Spline Resolution"
	
	    #node Set Spline Type.002
	    set_spline_type_002 = clump_hair_curves.nodes.new("GeometryNodeCurveSplineType")
	    set_spline_type_002.name = "Set Spline Type.002"
	    set_spline_type_002.spline_type = 'POLY'
	    #Selection
	    set_spline_type_002.inputs[1].default_value = True
	
	    #node Reroute.021
	    reroute_021_1 = clump_hair_curves.nodes.new("NodeReroute")
	    reroute_021_1.name = "Reroute.021"
	    reroute_021_1.socket_idname = "NodeSocketInt"
	    #node Switch.006
	    switch_006 = clump_hair_curves.nodes.new("GeometryNodeSwitch")
	    switch_006.name = "Switch.006"
	    switch_006.input_type = 'INT'
	    #True
	    switch_006.inputs[2].default_value = 12
	
	    #node Compare.004
	    compare_004_3 = clump_hair_curves.nodes.new("FunctionNodeCompare")
	    compare_004_3.name = "Compare.004"
	    compare_004_3.data_type = 'INT'
	    compare_004_3.mode = 'ELEMENT'
	    compare_004_3.operation = 'EQUAL'
	    #B_INT
	    compare_004_3.inputs[3].default_value = 0
	
	    #node Set Spline Resolution.001
	    set_spline_resolution_001 = clump_hair_curves.nodes.new("GeometryNodeSetSplineResolution")
	    set_spline_resolution_001.name = "Set Spline Resolution.001"
	    set_spline_resolution_001.inputs[1].hide = True
	    #Selection
	    set_spline_resolution_001.inputs[1].default_value = True
	
	    #node Set Spline Type.001
	    set_spline_type_001 = clump_hair_curves.nodes.new("GeometryNodeCurveSplineType")
	    set_spline_type_001.name = "Set Spline Type.001"
	    set_spline_type_001.spline_type = 'CATMULL_ROM'
	    set_spline_type_001.inputs[1].hide = True
	    #Selection
	    set_spline_type_001.inputs[1].default_value = True
	
	    #node Reroute.025
	    reroute_025 = clump_hair_curves.nodes.new("NodeReroute")
	    reroute_025.name = "Reroute.025"
	    reroute_025.socket_idname = "NodeSocketGeometry"
	    #node Group.005
	    group_005 = clump_hair_curves.nodes.new("GeometryNodeGroup")
	    group_005.name = "Group.005"
	    group_005.node_tree = restore_curve_segment_length
	    #Socket_3
	    group_005.inputs[2].default_value = 1.0
	    #Socket_5
	    group_005.inputs[4].default_value = 0.0
	
	    #node Group Input.010
	    group_input_010_1 = clump_hair_curves.nodes.new("NodeGroupInput")
	    group_input_010_1.name = "Group Input.010"
	    group_input_010_1.outputs[0].hide = True
	    group_input_010_1.outputs[1].hide = True
	    group_input_010_1.outputs[2].hide = True
	    group_input_010_1.outputs[3].hide = True
	    group_input_010_1.outputs[4].hide = True
	    group_input_010_1.outputs[5].hide = True
	    group_input_010_1.outputs[6].hide = True
	    group_input_010_1.outputs[7].hide = True
	    group_input_010_1.outputs[8].hide = True
	    group_input_010_1.outputs[9].hide = True
	    group_input_010_1.outputs[10].hide = True
	    group_input_010_1.outputs[11].hide = True
	    group_input_010_1.outputs[13].hide = True
	
	    #node Reroute.003
	    reroute_003_2 = clump_hair_curves.nodes.new("NodeReroute")
	    reroute_003_2.name = "Reroute.003"
	    reroute_003_2.socket_idname = "NodeSocketGeometry"
	    #node Reroute.005
	    reroute_005_2 = clump_hair_curves.nodes.new("NodeReroute")
	    reroute_005_2.name = "Reroute.005"
	    reroute_005_2.socket_idname = "NodeSocketGeometry"
	    #node Reroute.002
	    reroute_002_2 = clump_hair_curves.nodes.new("NodeReroute")
	    reroute_002_2.name = "Reroute.002"
	    reroute_002_2.socket_idname = "NodeSocketInt"
	    #node Reroute.010
	    reroute_010_1 = clump_hair_curves.nodes.new("NodeReroute")
	    reroute_010_1.name = "Reroute.010"
	    reroute_010_1.socket_idname = "NodeSocketVector"
	    #node Reroute.022
	    reroute_022_1 = clump_hair_curves.nodes.new("NodeReroute")
	    reroute_022_1.name = "Reroute.022"
	    reroute_022_1.socket_idname = "NodeSocketVector"
	    #node Reroute.023
	    reroute_023_1 = clump_hair_curves.nodes.new("NodeReroute")
	    reroute_023_1.name = "Reroute.023"
	    reroute_023_1.socket_idname = "NodeSocketInt"
	    #node Reroute.024
	    reroute_024_1 = clump_hair_curves.nodes.new("NodeReroute")
	    reroute_024_1.name = "Reroute.024"
	    reroute_024_1.socket_idname = "NodeSocketInt"
	    #node Vector Math
	    vector_math_3 = clump_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_3.name = "Vector Math"
	    vector_math_3.hide = True
	    vector_math_3.operation = 'CROSS_PRODUCT'
	
	    #node Sample Curve
	    sample_curve = clump_hair_curves.nodes.new("GeometryNodeSampleCurve")
	    sample_curve.name = "Sample Curve"
	    sample_curve.data_type = 'FLOAT'
	    sample_curve.mode = 'FACTOR'
	    sample_curve.use_all_curves = False
	    sample_curve.inputs[1].hide = True
	    sample_curve.outputs[0].hide = True
	    #Value
	    sample_curve.inputs[1].default_value = 0.0
	
	    #node Spline Parameter
	    spline_parameter = clump_hair_curves.nodes.new("GeometryNodeSplineParameter")
	    spline_parameter.name = "Spline Parameter"
	    spline_parameter.outputs[1].hide = True
	    spline_parameter.outputs[2].hide = True
	
	    #node Vector Math.001
	    vector_math_001_3 = clump_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_001_3.name = "Vector Math.001"
	    vector_math_001_3.hide = True
	    vector_math_001_3.operation = 'SCALE'
	
	    #node Vector Math.002
	    vector_math_002_2 = clump_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_002_2.name = "Vector Math.002"
	    vector_math_002_2.hide = True
	    vector_math_002_2.operation = 'SCALE'
	
	    #node Separate XYZ
	    separate_xyz_1 = clump_hair_curves.nodes.new("ShaderNodeSeparateXYZ")
	    separate_xyz_1.name = "Separate XYZ"
	    separate_xyz_1.outputs[2].hide = True
	
	    #node Vector Math.006
	    vector_math_006_2 = clump_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_006_2.name = "Vector Math.006"
	    vector_math_006_2.hide = True
	    vector_math_006_2.operation = 'ADD'
	
	    #node Evaluate on Domain
	    evaluate_on_domain_1 = clump_hair_curves.nodes.new("GeometryNodeFieldOnDomain")
	    evaluate_on_domain_1.name = "Evaluate on Domain"
	    evaluate_on_domain_1.data_type = 'FLOAT_VECTOR'
	    evaluate_on_domain_1.domain = 'CURVE'
	
	    #node Combine XYZ
	    combine_xyz_1 = clump_hair_curves.nodes.new("ShaderNodeCombineXYZ")
	    combine_xyz_1.name = "Combine XYZ"
	    #Z
	    combine_xyz_1.inputs[2].default_value = 0.0
	
	    #node Vector Math.004
	    vector_math_004_3 = clump_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_004_3.name = "Vector Math.004"
	    vector_math_004_3.hide = True
	    vector_math_004_3.operation = 'DOT_PRODUCT'
	
	    #node Vector Math.005
	    vector_math_005_1 = clump_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_005_1.name = "Vector Math.005"
	    vector_math_005_1.hide = True
	    vector_math_005_1.operation = 'DOT_PRODUCT'
	
	    #node Reroute
	    reroute_4 = clump_hair_curves.nodes.new("NodeReroute")
	    reroute_4.name = "Reroute"
	    reroute_4.socket_idname = "NodeSocketVector"
	    #node Vector Math.008
	    vector_math_008_2 = clump_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_008_2.name = "Vector Math.008"
	    vector_math_008_2.operation = 'SUBTRACT'
	
	    #node Vector Math.003
	    vector_math_003_2 = clump_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_003_2.name = "Vector Math.003"
	    vector_math_003_2.hide = True
	    vector_math_003_2.operation = 'CROSS_PRODUCT'
	
	    #node Sample Curve.001
	    sample_curve_001_1 = clump_hair_curves.nodes.new("GeometryNodeSampleCurve")
	    sample_curve_001_1.name = "Sample Curve.001"
	    sample_curve_001_1.data_type = 'FLOAT'
	    sample_curve_001_1.mode = 'FACTOR'
	    sample_curve_001_1.use_all_curves = False
	    sample_curve_001_1.inputs[1].hide = True
	    sample_curve_001_1.inputs[2].hide = True
	    sample_curve_001_1.outputs[0].hide = True
	    sample_curve_001_1.outputs[1].hide = True
	    #Value
	    sample_curve_001_1.inputs[1].default_value = 0.0
	    #Factor
	    sample_curve_001_1.inputs[2].default_value = 0.0
	
	    #node Evaluate at Index
	    evaluate_at_index_3 = clump_hair_curves.nodes.new("GeometryNodeFieldAtIndex")
	    evaluate_at_index_3.name = "Evaluate at Index"
	    evaluate_at_index_3.data_type = 'FLOAT_VECTOR'
	    evaluate_at_index_3.domain = 'CURVE'
	
	    #node Reroute.001
	    reroute_001_4 = clump_hair_curves.nodes.new("NodeReroute")
	    reroute_001_4.name = "Reroute.001"
	    reroute_001_4.socket_idname = "NodeSocketInt"
	    #node Reroute.008
	    reroute_008_2 = clump_hair_curves.nodes.new("NodeReroute")
	    reroute_008_2.name = "Reroute.008"
	    reroute_008_2.socket_idname = "NodeSocketInt"
	    #node Reroute.007
	    reroute_007_2 = clump_hair_curves.nodes.new("NodeReroute")
	    reroute_007_2.name = "Reroute.007"
	    reroute_007_2.socket_idname = "NodeSocketInt"
	    #node Reroute.026
	    reroute_026_1 = clump_hair_curves.nodes.new("NodeReroute")
	    reroute_026_1.name = "Reroute.026"
	    reroute_026_1.socket_idname = "NodeSocketInt"
	    #node Reroute.027
	    reroute_027_1 = clump_hair_curves.nodes.new("NodeReroute")
	    reroute_027_1.name = "Reroute.027"
	    reroute_027_1.socket_idname = "NodeSocketInt"
	    #node Evaluate on Domain.001
	    evaluate_on_domain_001_2 = clump_hair_curves.nodes.new("GeometryNodeFieldOnDomain")
	    evaluate_on_domain_001_2.name = "Evaluate on Domain.001"
	    evaluate_on_domain_001_2.data_type = 'FLOAT_VECTOR'
	    evaluate_on_domain_001_2.domain = 'CURVE'
	
	    #node Sample Index
	    sample_index_1 = clump_hair_curves.nodes.new("GeometryNodeSampleIndex")
	    sample_index_1.name = "Sample Index"
	    sample_index_1.hide = True
	    sample_index_1.clamp = False
	    sample_index_1.data_type = 'INT'
	    sample_index_1.domain = 'POINT'
	    #Index
	    sample_index_1.inputs[2].default_value = 0
	
	    #node Accumulate Field.002
	    accumulate_field_002 = clump_hair_curves.nodes.new("GeometryNodeAccumulateField")
	    accumulate_field_002.name = "Accumulate Field.002"
	    accumulate_field_002.hide = True
	    accumulate_field_002.data_type = 'INT'
	    accumulate_field_002.domain = 'POINT'
	    #Group Index
	    accumulate_field_002.inputs[1].default_value = 0
	
	    #node Group Input.002
	    group_input_002_2 = clump_hair_curves.nodes.new("NodeGroupInput")
	    group_input_002_2.name = "Group Input.002"
	    group_input_002_2.outputs[0].hide = True
	    group_input_002_2.outputs[1].hide = True
	    group_input_002_2.outputs[2].hide = True
	    group_input_002_2.outputs[3].hide = True
	    group_input_002_2.outputs[5].hide = True
	    group_input_002_2.outputs[6].hide = True
	    group_input_002_2.outputs[7].hide = True
	    group_input_002_2.outputs[8].hide = True
	    group_input_002_2.outputs[9].hide = True
	    group_input_002_2.outputs[10].hide = True
	    group_input_002_2.outputs[11].hide = True
	    group_input_002_2.outputs[12].hide = True
	    group_input_002_2.outputs[13].hide = True
	
	    #node Reroute.032
	    reroute_032 = clump_hair_curves.nodes.new("NodeReroute")
	    reroute_032.name = "Reroute.032"
	    reroute_032.socket_idname = "NodeSocketGeometry"
	    #node Boolean Math.001
	    boolean_math_001 = clump_hair_curves.nodes.new("FunctionNodeBooleanMath")
	    boolean_math_001.name = "Boolean Math.001"
	    boolean_math_001.operation = 'AND'
	
	    #node Switch.001
	    switch_001_5 = clump_hair_curves.nodes.new("GeometryNodeSwitch")
	    switch_001_5.name = "Switch.001"
	    switch_001_5.input_type = 'GEOMETRY'
	
	    #node Named Attribute.003
	    named_attribute_003 = clump_hair_curves.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute_003.name = "Named Attribute.003"
	    named_attribute_003.data_type = 'INT'
	    #Name
	    named_attribute_003.inputs[0].default_value = "guide_curve_index"
	
	    #node Group Input.013
	    group_input_013 = clump_hair_curves.nodes.new("NodeGroupInput")
	    group_input_013.name = "Group Input.013"
	    group_input_013.outputs[0].hide = True
	    group_input_013.outputs[1].hide = True
	    group_input_013.outputs[2].hide = True
	    group_input_013.outputs[4].hide = True
	    group_input_013.outputs[5].hide = True
	    group_input_013.outputs[6].hide = True
	    group_input_013.outputs[7].hide = True
	    group_input_013.outputs[8].hide = True
	    group_input_013.outputs[9].hide = True
	    group_input_013.outputs[10].hide = True
	    group_input_013.outputs[11].hide = True
	    group_input_013.outputs[12].hide = True
	    group_input_013.outputs[13].hide = True
	
	    #node Group Input.004
	    group_input_004_2 = clump_hair_curves.nodes.new("NodeGroupInput")
	    group_input_004_2.name = "Group Input.004"
	    group_input_004_2.outputs[0].hide = True
	    group_input_004_2.outputs[1].hide = True
	    group_input_004_2.outputs[3].hide = True
	    group_input_004_2.outputs[4].hide = True
	    group_input_004_2.outputs[5].hide = True
	    group_input_004_2.outputs[6].hide = True
	    group_input_004_2.outputs[7].hide = True
	    group_input_004_2.outputs[8].hide = True
	    group_input_004_2.outputs[9].hide = True
	    group_input_004_2.outputs[10].hide = True
	    group_input_004_2.outputs[11].hide = True
	    group_input_004_2.outputs[12].hide = True
	    group_input_004_2.outputs[13].hide = True
	
	    #node Reroute.006
	    reroute_006_2 = clump_hair_curves.nodes.new("NodeReroute")
	    reroute_006_2.name = "Reroute.006"
	    reroute_006_2.socket_idname = "NodeSocketInt"
	    #node Compare.003
	    compare_003_2 = clump_hair_curves.nodes.new("FunctionNodeCompare")
	    compare_003_2.name = "Compare.003"
	    compare_003_2.data_type = 'INT'
	    compare_003_2.mode = 'ELEMENT'
	    compare_003_2.operation = 'NOT_EQUAL'
	    #B_INT
	    compare_003_2.inputs[3].default_value = -987654
	
	    #node Group Input.011
	    group_input_011 = clump_hair_curves.nodes.new("NodeGroupInput")
	    group_input_011.name = "Group Input.011"
	    group_input_011.outputs[0].hide = True
	    group_input_011.outputs[2].hide = True
	    group_input_011.outputs[3].hide = True
	    group_input_011.outputs[4].hide = True
	    group_input_011.outputs[5].hide = True
	    group_input_011.outputs[6].hide = True
	    group_input_011.outputs[7].hide = True
	    group_input_011.outputs[8].hide = True
	    group_input_011.outputs[9].hide = True
	    group_input_011.outputs[10].hide = True
	    group_input_011.outputs[11].hide = True
	    group_input_011.outputs[12].hide = True
	    group_input_011.outputs[13].hide = True
	
	    #node Accumulate Field
	    accumulate_field_1 = clump_hair_curves.nodes.new("GeometryNodeAccumulateField")
	    accumulate_field_1.name = "Accumulate Field"
	    accumulate_field_1.data_type = 'INT'
	    accumulate_field_1.domain = 'CURVE'
	    accumulate_field_1.inputs[1].hide = True
	    accumulate_field_1.outputs[0].hide = True
	    accumulate_field_1.outputs[1].hide = True
	    #Group Index
	    accumulate_field_1.inputs[1].default_value = 0
	
	    #node Switch.003
	    switch_003_4 = clump_hair_curves.nodes.new("GeometryNodeSwitch")
	    switch_003_4.name = "Switch.003"
	    switch_003_4.input_type = 'INT'
	
	    #node Compare.001
	    compare_001_2 = clump_hair_curves.nodes.new("FunctionNodeCompare")
	    compare_001_2.name = "Compare.001"
	    compare_001_2.hide = True
	    compare_001_2.data_type = 'INT'
	    compare_001_2.mode = 'ELEMENT'
	    compare_001_2.operation = 'GREATER_THAN'
	    #B_INT
	    compare_001_2.inputs[3].default_value = 0
	
	    #node Group.003
	    group_003_1 = clump_hair_curves.nodes.new("GeometryNodeGroup")
	    group_003_1.name = "Group.003"
	    group_003_1.node_tree = create_guide_index_map
	    group_003_1.inputs[1].hide = True
	    group_003_1.inputs[4].hide = True
	    group_003_1.outputs[1].hide = True
	    group_003_1.outputs[3].hide = True
	    #Socket_8
	    group_003_1.inputs[4].default_value = 0
	
	    #node Boolean Math.002
	    boolean_math_002_2 = clump_hair_curves.nodes.new("FunctionNodeBooleanMath")
	    boolean_math_002_2.name = "Boolean Math.002"
	    boolean_math_002_2.operation = 'NIMPLY'
	
	    #node Sample Index.001
	    sample_index_001_1 = clump_hair_curves.nodes.new("GeometryNodeSampleIndex")
	    sample_index_001_1.name = "Sample Index.001"
	    sample_index_001_1.hide = True
	    sample_index_001_1.clamp = False
	    sample_index_001_1.data_type = 'BOOLEAN'
	    sample_index_001_1.domain = 'CURVE'
	    #Index
	    sample_index_001_1.inputs[2].default_value = 0
	
	    #node Reroute.029
	    reroute_029 = clump_hair_curves.nodes.new("NodeReroute")
	    reroute_029.name = "Reroute.029"
	    reroute_029.socket_idname = "NodeSocketInt"
	    #node Capture Attribute.001
	    capture_attribute_001_2 = clump_hair_curves.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_001_2.name = "Capture Attribute.001"
	    capture_attribute_001_2.active_index = 0
	    capture_attribute_001_2.capture_items.clear()
	    capture_attribute_001_2.capture_items.new('FLOAT', "Value")
	    capture_attribute_001_2.capture_items["Value"].data_type = 'INT'
	    capture_attribute_001_2.domain = 'CURVE'
	
	    #node Position
	    position_1 = clump_hair_curves.nodes.new("GeometryNodeInputPosition")
	    position_1.name = "Position"
	
	    #node Mix
	    mix_1 = clump_hair_curves.nodes.new("ShaderNodeMix")
	    mix_1.name = "Mix"
	    mix_1.blend_type = 'MIX'
	    mix_1.clamp_factor = True
	    mix_1.clamp_result = False
	    mix_1.data_type = 'VECTOR'
	    mix_1.factor_mode = 'UNIFORM'
	
	    #node Vector Math.009
	    vector_math_009_2 = clump_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_009_2.name = "Vector Math.009"
	    vector_math_009_2.operation = 'ADD'
	
	    #node Math.002
	    math_002_1 = clump_hair_curves.nodes.new("ShaderNodeMath")
	    math_002_1.name = "Math.002"
	    math_002_1.operation = 'MULTIPLY'
	    math_002_1.use_clamp = False
	
	    #node Set Position
	    set_position_2 = clump_hair_curves.nodes.new("GeometryNodeSetPosition")
	    set_position_2.name = "Set Position"
	    set_position_2.inputs[1].hide = True
	    set_position_2.inputs[3].hide = True
	    #Selection
	    set_position_2.inputs[1].default_value = True
	    #Offset
	    set_position_2.inputs[3].default_value = (0.0, 0.0, 0.0)
	
	    #node Group Input.001
	    group_input_001_3 = clump_hair_curves.nodes.new("NodeGroupInput")
	    group_input_001_3.name = "Group Input.001"
	    group_input_001_3.outputs[0].hide = True
	    group_input_001_3.outputs[1].hide = True
	    group_input_001_3.outputs[2].hide = True
	    group_input_001_3.outputs[3].hide = True
	    group_input_001_3.outputs[4].hide = True
	    group_input_001_3.outputs[6].hide = True
	    group_input_001_3.outputs[7].hide = True
	    group_input_001_3.outputs[8].hide = True
	    group_input_001_3.outputs[9].hide = True
	    group_input_001_3.outputs[10].hide = True
	    group_input_001_3.outputs[11].hide = True
	    group_input_001_3.outputs[12].hide = True
	    group_input_001_3.outputs[13].hide = True
	
	    #node Math
	    math_4 = clump_hair_curves.nodes.new("ShaderNodeMath")
	    math_4.name = "Math"
	    math_4.operation = 'SUBTRACT'
	    math_4.use_clamp = False
	    #Value
	    math_4.inputs[0].default_value = 1.0
	
	    #node Vector Math.013
	    vector_math_013_1 = clump_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_013_1.name = "Vector Math.013"
	    vector_math_013_1.hide = True
	    vector_math_013_1.operation = 'SCALE'
	
	    #node Vector Math.007
	    vector_math_007_2 = clump_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_007_2.name = "Vector Math.007"
	    vector_math_007_2.hide = True
	    vector_math_007_2.operation = 'SCALE'
	
	    #node Vector Math.011
	    vector_math_011_1 = clump_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_011_1.name = "Vector Math.011"
	    vector_math_011_1.hide = True
	    vector_math_011_1.operation = 'ADD'
	
	    #node Reroute.020
	    reroute_020_2 = clump_hair_curves.nodes.new("NodeReroute")
	    reroute_020_2.name = "Reroute.020"
	    reroute_020_2.socket_idname = "NodeSocketFloat"
	    #node Math.001
	    math_001_2 = clump_hair_curves.nodes.new("ShaderNodeMath")
	    math_001_2.name = "Math.001"
	    math_001_2.operation = 'MULTIPLY'
	    math_001_2.use_clamp = False
	
	    #node Reroute.004
	    reroute_004_3 = clump_hair_curves.nodes.new("NodeReroute")
	    reroute_004_3.name = "Reroute.004"
	    reroute_004_3.socket_idname = "NodeSocketFloat"
	    #node Vector Math.025
	    vector_math_025 = clump_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_025.name = "Vector Math.025"
	    vector_math_025.hide = True
	    vector_math_025.operation = 'ADD'
	
	    #node Switch.002
	    switch_002_3 = clump_hair_curves.nodes.new("GeometryNodeSwitch")
	    switch_002_3.name = "Switch.002"
	    switch_002_3.hide = True
	    switch_002_3.input_type = 'VECTOR'
	    #True
	    switch_002_3.inputs[2].default_value = (0.0, 0.0, 0.0)
	
	    #node Vector Math.020
	    vector_math_020 = clump_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_020.name = "Vector Math.020"
	    vector_math_020.hide = True
	    vector_math_020.operation = 'SCALE'
	
	    #node Vector Math.021
	    vector_math_021 = clump_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_021.name = "Vector Math.021"
	    vector_math_021.hide = True
	    vector_math_021.operation = 'SCALE'
	
	    #node Vector Math.022
	    vector_math_022 = clump_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_022.name = "Vector Math.022"
	    vector_math_022.hide = True
	    vector_math_022.operation = 'ADD'
	
	    #node Vector Math.015
	    vector_math_015 = clump_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_015.name = "Vector Math.015"
	    vector_math_015.hide = True
	    vector_math_015.operation = 'SCALE'
	
	    #node Vector Math.016
	    vector_math_016 = clump_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_016.name = "Vector Math.016"
	    vector_math_016.hide = True
	    vector_math_016.operation = 'SCALE'
	
	    #node Vector Math.018
	    vector_math_018 = clump_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_018.name = "Vector Math.018"
	    vector_math_018.hide = True
	    vector_math_018.operation = 'ADD'
	
	    #node Vector Math.019
	    vector_math_019 = clump_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_019.name = "Vector Math.019"
	    vector_math_019.hide = True
	    vector_math_019.operation = 'ADD'
	
	    #node Vector Math.014
	    vector_math_014_1 = clump_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_014_1.name = "Vector Math.014"
	    vector_math_014_1.hide = True
	    vector_math_014_1.operation = 'SCALE'
	
	    #node Switch
	    switch_4 = clump_hair_curves.nodes.new("GeometryNodeSwitch")
	    switch_4.name = "Switch"
	    switch_4.hide = True
	    switch_4.input_type = 'VECTOR'
	    #True
	    switch_4.inputs[2].default_value = (0.0, 0.0, 0.0)
	
	    #node Sample Curve.002
	    sample_curve_002 = clump_hair_curves.nodes.new("GeometryNodeSampleCurve")
	    sample_curve_002.name = "Sample Curve.002"
	    sample_curve_002.data_type = 'FLOAT'
	    sample_curve_002.mode = 'FACTOR'
	    sample_curve_002.use_all_curves = False
	    sample_curve_002.inputs[1].hide = True
	    sample_curve_002.inputs[2].hide = True
	    sample_curve_002.outputs[0].hide = True
	    sample_curve_002.outputs[1].hide = True
	    #Value
	    sample_curve_002.inputs[1].default_value = 0.0
	    #Factor
	    sample_curve_002.inputs[2].default_value = 1.0
	
	    #node Reroute.011
	    reroute_011_2 = clump_hair_curves.nodes.new("NodeReroute")
	    reroute_011_2.name = "Reroute.011"
	    reroute_011_2.socket_idname = "NodeSocketInt"
	    #node Vector Math.017
	    vector_math_017 = clump_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_017.name = "Vector Math.017"
	    vector_math_017.hide = True
	    vector_math_017.operation = 'CROSS_PRODUCT'
	
	    #node Random Value
	    random_value_1 = clump_hair_curves.nodes.new("FunctionNodeRandomValue")
	    random_value_1.name = "Random Value"
	    random_value_1.hide = True
	    random_value_1.data_type = 'FLOAT_VECTOR'
	    #Min
	    random_value_1.inputs[0].default_value = (-1.0, -1.0, -1.0)
	    #Max
	    random_value_1.inputs[1].default_value = (1.0, 1.0, 1.0)
	
	    #node Vector Math.026
	    vector_math_026 = clump_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_026.name = "Vector Math.026"
	    vector_math_026.operation = 'SCALE'
	
	    #node Separate XYZ.002
	    separate_xyz_002_1 = clump_hair_curves.nodes.new("ShaderNodeSeparateXYZ")
	    separate_xyz_002_1.name = "Separate XYZ.002"
	    separate_xyz_002_1.outputs[2].hide = True
	
	    #node Separate XYZ.001
	    separate_xyz_001_1 = clump_hair_curves.nodes.new("ShaderNodeSeparateXYZ")
	    separate_xyz_001_1.name = "Separate XYZ.001"
	
	    #node Reroute.009
	    reroute_009_2 = clump_hair_curves.nodes.new("NodeReroute")
	    reroute_009_2.name = "Reroute.009"
	    reroute_009_2.socket_idname = "NodeSocketFloatDistance"
	    #node Vector Math.012
	    vector_math_012_1 = clump_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_012_1.name = "Vector Math.012"
	    vector_math_012_1.operation = 'SCALE'
	
	    #node Group Input.009
	    group_input_009_1 = clump_hair_curves.nodes.new("NodeGroupInput")
	    group_input_009_1.name = "Group Input.009"
	    group_input_009_1.outputs[0].hide = True
	    group_input_009_1.outputs[1].hide = True
	    group_input_009_1.outputs[2].hide = True
	    group_input_009_1.outputs[3].hide = True
	    group_input_009_1.outputs[4].hide = True
	    group_input_009_1.outputs[5].hide = True
	    group_input_009_1.outputs[6].hide = True
	    group_input_009_1.outputs[7].hide = True
	    group_input_009_1.outputs[9].hide = True
	    group_input_009_1.outputs[10].hide = True
	    group_input_009_1.outputs[11].hide = True
	    group_input_009_1.outputs[12].hide = True
	    group_input_009_1.outputs[13].hide = True
	
	    #node Group Input.012
	    group_input_012 = clump_hair_curves.nodes.new("NodeGroupInput")
	    group_input_012.name = "Group Input.012"
	    group_input_012.outputs[0].hide = True
	    group_input_012.outputs[1].hide = True
	    group_input_012.outputs[2].hide = True
	    group_input_012.outputs[3].hide = True
	    group_input_012.outputs[4].hide = True
	    group_input_012.outputs[5].hide = True
	    group_input_012.outputs[6].hide = True
	    group_input_012.outputs[8].hide = True
	    group_input_012.outputs[9].hide = True
	    group_input_012.outputs[10].hide = True
	    group_input_012.outputs[11].hide = True
	    group_input_012.outputs[12].hide = True
	    group_input_012.outputs[13].hide = True
	
	    #node Group Input.008
	    group_input_008_1 = clump_hair_curves.nodes.new("NodeGroupInput")
	    group_input_008_1.name = "Group Input.008"
	    group_input_008_1.outputs[0].hide = True
	    group_input_008_1.outputs[1].hide = True
	    group_input_008_1.outputs[2].hide = True
	    group_input_008_1.outputs[3].hide = True
	    group_input_008_1.outputs[4].hide = True
	    group_input_008_1.outputs[5].hide = True
	    group_input_008_1.outputs[6].hide = True
	    group_input_008_1.outputs[8].hide = True
	    group_input_008_1.outputs[9].hide = True
	    group_input_008_1.outputs[10].hide = True
	    group_input_008_1.outputs[11].hide = True
	    group_input_008_1.outputs[12].hide = True
	    group_input_008_1.outputs[13].hide = True
	
	    #node Random Value.001
	    random_value_001_2 = clump_hair_curves.nodes.new("FunctionNodeRandomValue")
	    random_value_001_2.name = "Random Value.001"
	    random_value_001_2.hide = True
	    random_value_001_2.data_type = 'FLOAT_VECTOR'
	    #Min
	    random_value_001_2.inputs[0].default_value = (-1.0, -1.0, -1.0)
	    #Max
	    random_value_001_2.inputs[1].default_value = (1.0, 1.0, 1.0)
	
	    #node Reroute.028
	    reroute_028_1 = clump_hair_curves.nodes.new("NodeReroute")
	    reroute_028_1.name = "Reroute.028"
	    reroute_028_1.socket_idname = "NodeSocketInt"
	    #node Evaluate at Index.001
	    evaluate_at_index_001_1 = clump_hair_curves.nodes.new("GeometryNodeFieldAtIndex")
	    evaluate_at_index_001_1.name = "Evaluate at Index.001"
	    evaluate_at_index_001_1.data_type = 'INT'
	    evaluate_at_index_001_1.domain = 'CURVE'
	
	    #node Group.006
	    group_006 = clump_hair_curves.nodes.new("GeometryNodeGroup")
	    group_006.name = "Group.006"
	    group_006.node_tree = curve_info
	    group_006.outputs[0].hide = True
	    group_006.outputs[2].hide = True
	    group_006.outputs[3].hide = True
	    group_006.outputs[4].hide = True
	    group_006.outputs[5].hide = True
	
	    #node Group.007
	    group_007 = clump_hair_curves.nodes.new("GeometryNodeGroup")
	    group_007.name = "Group.007"
	    group_007.node_tree = curve_info
	    group_007.outputs[0].hide = True
	    group_007.outputs[2].hide = True
	    group_007.outputs[3].hide = True
	    group_007.outputs[4].hide = True
	    group_007.outputs[5].hide = True
	
	    #node Random Value.004
	    random_value_004_1 = clump_hair_curves.nodes.new("FunctionNodeRandomValue")
	    random_value_004_1.label = "Hash Seed"
	    random_value_004_1.name = "Random Value.004"
	    random_value_004_1.data_type = 'INT'
	    #Min_002
	    random_value_004_1.inputs[4].default_value = -1073741823
	    #Max_002
	    random_value_004_1.inputs[5].default_value = 1073741823
	    #Seed
	    random_value_004_1.inputs[8].default_value = 148762
	
	    #node Group Input.005
	    group_input_005_2 = clump_hair_curves.nodes.new("NodeGroupInput")
	    group_input_005_2.name = "Group Input.005"
	    group_input_005_2.outputs[0].hide = True
	    group_input_005_2.outputs[1].hide = True
	    group_input_005_2.outputs[2].hide = True
	    group_input_005_2.outputs[3].hide = True
	    group_input_005_2.outputs[4].hide = True
	    group_input_005_2.outputs[5].hide = True
	    group_input_005_2.outputs[6].hide = True
	    group_input_005_2.outputs[7].hide = True
	    group_input_005_2.outputs[8].hide = True
	    group_input_005_2.outputs[9].hide = True
	    group_input_005_2.outputs[10].hide = True
	    group_input_005_2.outputs[12].hide = True
	    group_input_005_2.outputs[13].hide = True
	
	    #node Compare
	    compare_3 = clump_hair_curves.nodes.new("FunctionNodeCompare")
	    compare_3.name = "Compare"
	    compare_3.hide = True
	    compare_3.data_type = 'FLOAT'
	    compare_3.mode = 'ELEMENT'
	    compare_3.operation = 'EQUAL'
	    #B
	    compare_3.inputs[1].default_value = 0.0
	    #Epsilon
	    compare_3.inputs[12].default_value = 0.0
	
	    #node Compare.002
	    compare_002_2 = clump_hair_curves.nodes.new("FunctionNodeCompare")
	    compare_002_2.name = "Compare.002"
	    compare_002_2.hide = True
	    compare_002_2.data_type = 'FLOAT'
	    compare_002_2.mode = 'ELEMENT'
	    compare_002_2.operation = 'EQUAL'
	    #A
	    compare_002_2.inputs[0].default_value = 0.0
	    #Epsilon
	    compare_002_2.inputs[12].default_value = 0.0
	
	    #node Spline Parameter.001
	    spline_parameter_001 = clump_hair_curves.nodes.new("GeometryNodeSplineParameter")
	    spline_parameter_001.name = "Spline Parameter.001"
	    spline_parameter_001.outputs[1].hide = True
	    spline_parameter_001.outputs[2].hide = True
	
	    #node Group Input
	    group_input_4 = clump_hair_curves.nodes.new("NodeGroupInput")
	    group_input_4.name = "Group Input"
	    group_input_4.outputs[0].hide = True
	    group_input_4.outputs[1].hide = True
	    group_input_4.outputs[2].hide = True
	    group_input_4.outputs[3].hide = True
	    group_input_4.outputs[4].hide = True
	    group_input_4.outputs[5].hide = True
	    group_input_4.outputs[7].hide = True
	    group_input_4.outputs[8].hide = True
	    group_input_4.outputs[9].hide = True
	    group_input_4.outputs[10].hide = True
	    group_input_4.outputs[11].hide = True
	    group_input_4.outputs[12].hide = True
	    group_input_4.outputs[13].hide = True
	
	    #node Group.001
	    group_001_3 = clump_hair_curves.nodes.new("GeometryNodeGroup")
	    group_001_3.name = "Group.001"
	    group_001_3.node_tree = shape_range
	    group_001_3.inputs[1].hide = True
	    group_001_3.inputs[2].hide = True
	    group_001_3.inputs[4].hide = True
	    #Socket_2
	    group_001_3.inputs[1].default_value = 0.0
	    #Socket_3
	    group_001_3.inputs[2].default_value = 1.0
	    #Socket_5
	    group_001_3.inputs[4].default_value = 2.0
	
	    #node Math.003
	    math_003_2 = clump_hair_curves.nodes.new("ShaderNodeMath")
	    math_003_2.name = "Math.003"
	    math_003_2.operation = 'ADD'
	    math_003_2.use_clamp = False
	    math_003_2.inputs[2].hide = True
	
	    #node Vector Math.010
	    vector_math_010_1 = clump_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_010_1.name = "Vector Math.010"
	    vector_math_010_1.hide = True
	    vector_math_010_1.operation = 'LENGTH'
	
	    #node Compare.006
	    compare_006 = clump_hair_curves.nodes.new("FunctionNodeCompare")
	    compare_006.name = "Compare.006"
	    compare_006.hide = True
	    compare_006.data_type = 'FLOAT'
	    compare_006.mode = 'ELEMENT'
	    compare_006.operation = 'NOT_EQUAL'
	    #B
	    compare_006.inputs[1].default_value = 0.0
	    #Epsilon
	    compare_006.inputs[12].default_value = 0.0
	
	    #node Compare.007
	    compare_007 = clump_hair_curves.nodes.new("FunctionNodeCompare")
	    compare_007.name = "Compare.007"
	    compare_007.hide = True
	    compare_007.data_type = 'FLOAT'
	    compare_007.mode = 'ELEMENT'
	    compare_007.operation = 'EQUAL'
	    #B
	    compare_007.inputs[1].default_value = 0.0
	    #Epsilon
	    compare_007.inputs[12].default_value = 0.0
	
	    #node Reroute.030
	    reroute_030 = clump_hair_curves.nodes.new("NodeReroute")
	    reroute_030.name = "Reroute.030"
	    reroute_030.socket_idname = "NodeSocketFloatDistance"
	    #node Group Input.007
	    group_input_007_2 = clump_hair_curves.nodes.new("NodeGroupInput")
	    group_input_007_2.name = "Group Input.007"
	    group_input_007_2.outputs[0].hide = True
	    group_input_007_2.outputs[1].hide = True
	    group_input_007_2.outputs[2].hide = True
	    group_input_007_2.outputs[3].hide = True
	    group_input_007_2.outputs[4].hide = True
	    group_input_007_2.outputs[5].hide = True
	    group_input_007_2.outputs[6].hide = True
	    group_input_007_2.outputs[7].hide = True
	    group_input_007_2.outputs[8].hide = True
	    group_input_007_2.outputs[10].hide = True
	    group_input_007_2.outputs[11].hide = True
	    group_input_007_2.outputs[12].hide = True
	    group_input_007_2.outputs[13].hide = True
	
	    #node Group Input.006
	    group_input_006_2 = clump_hair_curves.nodes.new("NodeGroupInput")
	    group_input_006_2.name = "Group Input.006"
	    group_input_006_2.outputs[0].hide = True
	    group_input_006_2.outputs[1].hide = True
	    group_input_006_2.outputs[2].hide = True
	    group_input_006_2.outputs[3].hide = True
	    group_input_006_2.outputs[4].hide = True
	    group_input_006_2.outputs[5].hide = True
	    group_input_006_2.outputs[6].hide = True
	    group_input_006_2.outputs[7].hide = True
	    group_input_006_2.outputs[8].hide = True
	    group_input_006_2.outputs[9].hide = True
	    group_input_006_2.outputs[11].hide = True
	    group_input_006_2.outputs[12].hide = True
	    group_input_006_2.outputs[13].hide = True
	
	    #node Compare.005
	    compare_005_1 = clump_hair_curves.nodes.new("FunctionNodeCompare")
	    compare_005_1.name = "Compare.005"
	    compare_005_1.hide = True
	    compare_005_1.data_type = 'FLOAT'
	    compare_005_1.mode = 'ELEMENT'
	    compare_005_1.operation = 'LESS_EQUAL'
	
	    #node Map Range.001
	    map_range_001_1 = clump_hair_curves.nodes.new("ShaderNodeMapRange")
	    map_range_001_1.name = "Map Range.001"
	    map_range_001_1.hide = True
	    map_range_001_1.clamp = True
	    map_range_001_1.data_type = 'FLOAT'
	    map_range_001_1.interpolation_type = 'SMOOTHSTEP'
	    map_range_001_1.inputs[3].hide = True
	    map_range_001_1.inputs[4].hide = True
	    map_range_001_1.inputs[5].hide = True
	    map_range_001_1.inputs[6].hide = True
	    map_range_001_1.inputs[7].hide = True
	    map_range_001_1.inputs[8].hide = True
	    map_range_001_1.inputs[9].hide = True
	    map_range_001_1.inputs[10].hide = True
	    map_range_001_1.inputs[11].hide = True
	    map_range_001_1.outputs[1].hide = True
	    #To Min
	    map_range_001_1.inputs[3].default_value = 1.0
	    #To Max
	    map_range_001_1.inputs[4].default_value = 0.0
	
	    #node Boolean Math
	    boolean_math_2 = clump_hair_curves.nodes.new("FunctionNodeBooleanMath")
	    boolean_math_2.name = "Boolean Math"
	    boolean_math_2.hide = True
	    boolean_math_2.operation = 'AND'
	
	    #node Switch.004
	    switch_004_1 = clump_hair_curves.nodes.new("GeometryNodeSwitch")
	    switch_004_1.name = "Switch.004"
	    switch_004_1.input_type = 'FLOAT'
	
	    #node Group.002
	    group_002_2 = clump_hair_curves.nodes.new("GeometryNodeGroup")
	    group_002_2.name = "Group.002"
	    group_002_2.node_tree = curve_root
	    group_002_2.outputs[0].hide = True
	    group_002_2.outputs[2].hide = True
	    group_002_2.outputs[3].hide = True
	
	
	
	
	    #Set parents
	    frame_004_2.parent = frame_006_1
	    capture_attribute_002_2.parent = frame_001_2
	    spline_resolution.parent = frame_001_2
	    set_spline_type_002.parent = frame_001_2
	    reroute_021_1.parent = frame_4
	    switch_006.parent = frame_4
	    compare_004_3.parent = frame_4
	    set_spline_resolution_001.parent = frame_4
	    set_spline_type_001.parent = frame_4
	    group_005.parent = frame_003_2
	    group_input_010_1.parent = frame_003_2
	    vector_math_3.parent = frame_005_1
	    sample_curve.parent = frame_005_1
	    spline_parameter.parent = frame_005_1
	    vector_math_001_3.parent = frame_005_1
	    vector_math_002_2.parent = frame_005_1
	    separate_xyz_1.parent = frame_005_1
	    vector_math_006_2.parent = frame_005_1
	    evaluate_on_domain_1.parent = frame_005_1
	    combine_xyz_1.parent = frame_005_1
	    vector_math_004_3.parent = frame_005_1
	    vector_math_005_1.parent = frame_005_1
	    reroute_4.parent = frame_005_1
	    vector_math_008_2.parent = frame_005_1
	    vector_math_003_2.parent = frame_005_1
	    sample_curve_001_1.parent = frame_005_1
	    evaluate_at_index_3.parent = frame_005_1
	    reroute_001_4.parent = frame_005_1
	    evaluate_on_domain_001_2.parent = frame_006_1
	    sample_index_1.parent = frame_007_1
	    accumulate_field_002.parent = frame_007_1
	    group_input_002_2.parent = frame_007_1
	    reroute_032.parent = frame_007_1
	    boolean_math_001.parent = frame_007_1
	    switch_001_5.parent = frame_007_1
	    named_attribute_003.parent = frame_007_1
	    group_input_013.parent = frame_007_1
	    group_input_004_2.parent = frame_007_1
	    reroute_006_2.parent = frame_007_1
	    compare_003_2.parent = frame_007_1
	    group_input_011.parent = frame_007_1
	    accumulate_field_1.parent = frame_007_1
	    switch_003_4.parent = frame_007_1
	    compare_001_2.parent = frame_007_1
	    group_003_1.parent = frame_007_1
	    boolean_math_002_2.parent = frame_007_1
	    sample_index_001_1.parent = frame_007_1
	    capture_attribute_001_2.parent = frame_007_1
	    position_1.parent = frame_006_1
	    mix_1.parent = frame_006_1
	    vector_math_009_2.parent = frame_006_1
	    math_002_1.parent = frame_006_1
	    set_position_2.parent = frame_006_1
	    group_input_001_3.parent = frame_006_1
	    math_4.parent = frame_006_1
	    vector_math_013_1.parent = frame_006_1
	    vector_math_007_2.parent = frame_006_1
	    vector_math_011_1.parent = frame_006_1
	    reroute_020_2.parent = frame_006_1
	    math_001_2.parent = frame_006_1
	    reroute_004_3.parent = frame_006_1
	    vector_math_025.parent = frame_002_3
	    switch_002_3.parent = frame_002_3
	    vector_math_020.parent = frame_002_3
	    vector_math_021.parent = frame_002_3
	    vector_math_022.parent = frame_002_3
	    vector_math_015.parent = frame_002_3
	    vector_math_016.parent = frame_002_3
	    vector_math_018.parent = frame_002_3
	    vector_math_019.parent = frame_002_3
	    vector_math_014_1.parent = frame_002_3
	    switch_4.parent = frame_002_3
	    sample_curve_002.parent = frame_002_3
	    reroute_011_2.parent = frame_002_3
	    vector_math_017.parent = frame_002_3
	    random_value_1.parent = frame_002_3
	    vector_math_026.parent = frame_002_3
	    separate_xyz_002_1.parent = frame_002_3
	    separate_xyz_001_1.parent = frame_002_3
	    reroute_009_2.parent = frame_002_3
	    vector_math_012_1.parent = frame_002_3
	    group_input_009_1.parent = frame_002_3
	    group_input_012.parent = frame_002_3
	    group_input_008_1.parent = frame_002_3
	    random_value_001_2.parent = frame_002_3
	    reroute_028_1.parent = frame_002_3
	    evaluate_at_index_001_1.parent = frame_002_3
	    group_006.parent = frame_002_3
	    group_007.parent = frame_002_3
	    random_value_004_1.parent = frame_002_3
	    group_input_005_2.parent = frame_002_3
	    compare_3.parent = frame_002_3
	    compare_002_2.parent = frame_002_3
	    math_003_2.parent = frame_004_2
	    vector_math_010_1.parent = frame_004_2
	    compare_006.parent = frame_004_2
	    compare_007.parent = frame_004_2
	    reroute_030.parent = frame_004_2
	    group_input_007_2.parent = frame_004_2
	    group_input_006_2.parent = frame_004_2
	    compare_005_1.parent = frame_004_2
	    map_range_001_1.parent = frame_004_2
	    boolean_math_2.parent = frame_004_2
	    switch_004_1.parent = frame_004_2
	    group_002_2.parent = frame_005_1
	
	    #Set locations
	    frame_001_2.location = (-7469.0, -30.0)
	    frame_4.location = (-727.3564453125, -106.0)
	    frame_003_2.location = (-1181.0, -157.0)
	    frame_005_1.location = (-4982.0, -297.0)
	    frame_006_1.location = (-2652.0, -121.0)
	    frame_007_1.location = (-6576.0, -63.0)
	    frame_002_3.location = (-4984.310546875, -795.0)
	    frame_004_2.location = (30.0, -220.0)
	    group_input_003_3.location = (-8175.67333984375, 29.46435546875)
	    reroute_014_3.location = (-7339.32568359375, 411.67431640625)
	    reroute_015_3.location = (-7339.32568359375, 371.48828125)
	    reroute_013_3.location = (-7339.32568359375, 331.30224609375)
	    reroute_012_3.location = (-7339.32568359375, 451.860595703125)
	    separate_components_2.location = (-7958.42626953125, 110.1392822265625)
	    group_output_001.location = (75.0, 50.0)
	    join_geometry_001_2.location = (-125.9296875, 50.0)
	    reroute_016_3.location = (-427.3251953125, 391.581298828125)
	    reroute_017_3.location = (-427.3251953125, 351.395263671875)
	    reroute_019_2.location = (-427.3251953125, 311.209228515625)
	    reroute_018_3.location = (-427.3251953125, 271.023193359375)
	    capture_attribute_2.location = (-6837.00048828125, -211.2093505859375)
	    position_001_1.location = (-7037.93017578125, -432.2325439453125)
	    capture_attribute_002_2.location = (210.40673828125, -40.42852783203125)
	    spline_resolution.location = (29.56982421875, -221.26580810546875)
	    set_spline_type_002.location = (390.77099609375, -46.18804931640625)
	    reroute_021_1.location = (35.0, -301.52880859375)
	    switch_006.location = (296.20928955078125, -160.87762451171875)
	    compare_004_3.location = (115.3720703125, -160.87762451171875)
	    set_spline_resolution_001.location = (296.20928955078125, -40.31951904296875)
	    set_spline_type_001.location = (115.3720703125, -40.31951904296875)
	    reroute_025.location = (-3984.263427734375, -200.02154541015625)
	    group_005.location = (230.7830810546875, -39.87579345703125)
	    group_input_010_1.location = (29.852783203125, -120.24789428710938)
	    reroute_003_2.location = (-5089.3798828125, -196.87579345703125)
	    reroute_005_2.location = (-4325.8447265625, -196.87579345703125)
	    reroute_002_2.location = (-5089.3798828125, -237.06182861328125)
	    reroute_010_1.location = (-5350.5888671875, -1583.29443359375)
	    reroute_022_1.location = (-2075.42626953125, -1583.29443359375)
	    reroute_023_1.location = (-5390.77490234375, -1643.573486328125)
	    reroute_024_1.location = (-2035.240234375, -1643.573486328125)
	    vector_math_3.location = (1350.24658203125, -130.533447265625)
	    sample_curve.location = (1149.31640625, -30.068267822265625)
	    spline_parameter.location = (968.006103515625, -116.19989013671875)
	    vector_math_001_3.location = (1530.610595703125, -113.0540771484375)
	    vector_math_002_2.location = (1530.610595703125, -153.24014282226562)
	    separate_xyz_1.location = (1148.84326171875, -213.51919555664062)
	    vector_math_006_2.location = (1711.447998046875, -133.1470947265625)
	    evaluate_on_domain_1.location = (968.006103515625, -213.51919555664062)
	    combine_xyz_1.location = (787.1689453125, -213.51919555664062)
	    vector_math_004_3.location = (606.33154296875, -293.89129638671875)
	    vector_math_005_1.location = (606.33154296875, -253.70526123046875)
	    reroute_4.location = (566.1455078125, -293.89129638671875)
	    vector_math_008_2.location = (385.30859375, -253.70526123046875)
	    vector_math_003_2.location = (385.30859375, -173.33316040039062)
	    sample_curve_001_1.location = (204.47119140625, -133.1470947265625)
	    evaluate_at_index_3.location = (204.47119140625, -273.79827880859375)
	    reroute_001_4.location = (164.28515625, -253.70526123046875)
	    reroute_008_2.location = (-4004.3564453125, -237.06182861328125)
	    reroute_007_2.location = (-2919.333251953125, -237.06182861328125)
	    reroute_026_1.location = (-2738.49609375, -96.41070556640625)
	    reroute_027_1.location = (-5.84478759765625, -96.41070556640625)
	    evaluate_on_domain_001_2.location = (194.80615234375, -698.759521484375)
	    sample_index_1.location = (322.6123046875, -85.6318359375)
	    accumulate_field_002.location = (322.6123046875, -125.81787109375)
	    group_input_002_2.location = (322.6123046875, -166.00390625)
	    reroute_032.location = (242.240234375, -186.0970458984375)
	    boolean_math_001.location = (557.375, -91.3914794921875)
	    switch_001_5.location = (959.2353515625, -211.9495849609375)
	    named_attribute_003.location = (55.04931640625, -211.9495849609375)
	    group_input_013.location = (75.142578125, -392.786865234375)
	    group_input_004_2.location = (75.142578125, -332.5078125)
	    reroute_006_2.location = (230.73388671875, -604.3935546875)
	    compare_003_2.location = (291.01318359375, -443.6494140625)
	    group_input_011.location = (29.80419921875, -584.30078125)
	    accumulate_field_1.location = (471.8505859375, -443.6494140625)
	    switch_003_4.location = (960.75, -359.45849609375)
	    compare_001_2.location = (322.6123046875, -45.44580078125)
	    group_003_1.location = (302.51953125, -246.3760986328125)
	    boolean_math_002_2.location = (765.20068359375, -125.9888916015625)
	    sample_index_001_1.location = (632.7431640625, -426.048583984375)
	    reroute_029.location = (-5204.09326171875, -301.3953552246094)
	    capture_attribute_001_2.location = (1170.9765625, -158.023193359375)
	    position_1.location = (863.720947265625, -240.6744384765625)
	    mix_1.location = (1064.651123046875, -160.30233764648438)
	    vector_math_009_2.location = (863.720947265625, -300.9534912109375)
	    math_002_1.location = (863.720947265625, -120.11627197265625)
	    set_position_2.location = (1245.48828125, -39.74420166015625)
	    group_input_001_3.location = (393.505126953125, -115.955322265625)
	    math_4.location = (200.651123046875, -582.255859375)
	    vector_math_013_1.location = (401.581298828125, -642.534912109375)
	    vector_math_007_2.location = (401.581298828125, -602.348876953125)
	    vector_math_011_1.location = (582.41845703125, -622.44189453125)
	    reroute_020_2.location = (160.465087890625, -682.720947265625)
	    math_001_2.location = (631.386474609375, -113.4744873046875)
	    reroute_004_3.location = (39.906982421875, -602.348876953125)
	    vector_math_025.location = (1805.08935546875, -300.1107177734375)
	    switch_002_3.location = (1584.06591796875, -380.4830322265625)
	    vector_math_020.location = (1222.3916015625, -380.4830322265625)
	    vector_math_021.location = (1222.3916015625, -420.6690673828125)
	    vector_math_022.location = (1383.1357421875, -400.5760498046875)
	    vector_math_015.location = (1221.918212890625, -185.31219482421875)
	    vector_math_016.location = (1221.918212890625, -225.49822998046875)
	    vector_math_018.location = (1382.66259765625, -205.40521240234375)
	    vector_math_019.location = (1382.66259765625, -245.59130859375)
	    vector_math_014_1.location = (1221.918212890625, -265.684326171875)
	    switch_4.location = (1583.5927734375, -225.49822998046875)
	    sample_curve_002.location = (960.708984375, -104.9400634765625)
	    reroute_011_2.location = (35.0, -270.18017578125)
	    vector_math_017.location = (1220.995361328125, -131.715087890625)
	    random_value_1.location = (603.92333984375, -280.7939453125)
	    vector_math_026.location = (784.7607421875, -401.35205078125)
	    separate_xyz_002_1.location = (965.59765625, -401.35205078125)
	    separate_xyz_001_1.location = (965.59765625, -260.700927734375)
	    reroute_009_2.location = (724.4814453125, -542.003173828125)
	    vector_math_012_1.location = (784.7607421875, -260.700927734375)
	    group_input_009_1.location = (503.4580078125, -542.003173828125)
	    group_input_012.location = (1206.7138671875, -39.6776123046875)
	    group_input_008_1.location = (603.92333984375, -320.97998046875)
	    random_value_001_2.location = (603.92333984375, -441.5380859375)
	    reroute_028_1.location = (530.4716796875, -361.898681640625)
	    evaluate_at_index_001_1.location = (329.54150390625, -462.3638916015625)
	    group_006.location = (128.611328125, -542.7359619140625)
	    group_007.location = (409.91357421875, -221.24755859375)
	    random_value_004_1.location = (329.54150390625, -301.61962890625)
	    group_input_005_2.location = (148.7041015625, -361.898681640625)
	    compare_3.location = (1387.55126953125, -59.7706298828125)
	    compare_002_2.location = (960.708984375, -567.07958984375)
	    spline_parameter_001.location = (-3013.938720703125, -662.9942016601562)
	    group_input_4.location = (-3013.938720703125, -723.2733154296875)
	    group_001_3.location = (-2833.10205078125, -622.8081665039062)
	    math_003_2.location = (210.736572265625, -180.57012939453125)
	    vector_math_010_1.location = (210.736572265625, -140.38406372070312)
	    compare_006.location = (210.736572265625, -60.011962890625)
	    compare_007.location = (210.736572265625, -100.197998046875)
	    reroute_030.location = (391.57373046875, -180.57012939453125)
	    group_input_007_2.location = (29.8994140625, -180.57012939453125)
	    group_input_006_2.location = (29.8994140625, -120.29104614257812)
	    compare_005_1.location = (431.759765625, -180.57012939453125)
	    map_range_001_1.location = (431.759765625, -140.38406372070312)
	    boolean_math_2.location = (431.759765625, -80.10498046875)
	    switch_004_1.location = (612.596923828125, -39.9189453125)
	    group_002_2.location = (30.32861328125, -311.9451904296875)
	
	    #Set dimensions
	    frame_001_2.width, frame_001_2.height = 561.0, 301.0
	    frame_4.width, frame_4.height = 466.3564453125, 339.0
	    frame_003_2.width, frame_003_2.height = 401.0, 254.0
	    frame_005_1.width, frame_005_1.height = 1881.0, 450.0
	    frame_006_1.width, frame_006_1.height = 1415.0, 853.0
	    frame_007_1.width, frame_007_1.height = 1341.0, 666.0
	    frame_002_3.width, frame_002_3.height = 1975.310546875, 651.0
	    frame_004_2.width, frame_004_2.height = 783.0, 359.0
	    group_input_003_3.width, group_input_003_3.height = 140.0, 100.0
	    reroute_014_3.width, reroute_014_3.height = 10.0, 100.0
	    reroute_015_3.width, reroute_015_3.height = 10.0, 100.0
	    reroute_013_3.width, reroute_013_3.height = 10.0, 100.0
	    reroute_012_3.width, reroute_012_3.height = 10.0, 100.0
	    separate_components_2.width, separate_components_2.height = 140.0, 100.0
	    group_output_001.width, group_output_001.height = 140.0, 100.0
	    join_geometry_001_2.width, join_geometry_001_2.height = 140.0, 100.0
	    reroute_016_3.width, reroute_016_3.height = 10.0, 100.0
	    reroute_017_3.width, reroute_017_3.height = 10.0, 100.0
	    reroute_019_2.width, reroute_019_2.height = 10.0, 100.0
	    reroute_018_3.width, reroute_018_3.height = 10.0, 100.0
	    capture_attribute_2.width, capture_attribute_2.height = 140.0, 100.0
	    position_001_1.width, position_001_1.height = 140.0, 100.0
	    capture_attribute_002_2.width, capture_attribute_002_2.height = 140.0, 100.0
	    spline_resolution.width, spline_resolution.height = 140.0, 100.0
	    set_spline_type_002.width, set_spline_type_002.height = 140.0, 100.0
	    reroute_021_1.width, reroute_021_1.height = 10.0, 100.0
	    switch_006.width, switch_006.height = 140.0, 100.0
	    compare_004_3.width, compare_004_3.height = 140.0, 100.0
	    set_spline_resolution_001.width, set_spline_resolution_001.height = 140.0, 100.0
	    set_spline_type_001.width, set_spline_type_001.height = 140.0, 100.0
	    reroute_025.width, reroute_025.height = 10.0, 100.0
	    group_005.width, group_005.height = 140.0, 100.0
	    group_input_010_1.width, group_input_010_1.height = 140.0, 100.0
	    reroute_003_2.width, reroute_003_2.height = 10.0, 100.0
	    reroute_005_2.width, reroute_005_2.height = 10.0, 100.0
	    reroute_002_2.width, reroute_002_2.height = 10.0, 100.0
	    reroute_010_1.width, reroute_010_1.height = 10.0, 100.0
	    reroute_022_1.width, reroute_022_1.height = 10.0, 100.0
	    reroute_023_1.width, reroute_023_1.height = 10.0, 100.0
	    reroute_024_1.width, reroute_024_1.height = 10.0, 100.0
	    vector_math_3.width, vector_math_3.height = 140.0, 100.0
	    sample_curve.width, sample_curve.height = 140.0, 100.0
	    spline_parameter.width, spline_parameter.height = 140.0, 100.0
	    vector_math_001_3.width, vector_math_001_3.height = 140.0, 100.0
	    vector_math_002_2.width, vector_math_002_2.height = 140.0, 100.0
	    separate_xyz_1.width, separate_xyz_1.height = 140.0, 100.0
	    vector_math_006_2.width, vector_math_006_2.height = 140.0, 100.0
	    evaluate_on_domain_1.width, evaluate_on_domain_1.height = 140.0, 100.0
	    combine_xyz_1.width, combine_xyz_1.height = 140.0, 100.0
	    vector_math_004_3.width, vector_math_004_3.height = 140.0, 100.0
	    vector_math_005_1.width, vector_math_005_1.height = 140.0, 100.0
	    reroute_4.width, reroute_4.height = 10.0, 100.0
	    vector_math_008_2.width, vector_math_008_2.height = 140.0, 100.0
	    vector_math_003_2.width, vector_math_003_2.height = 140.0, 100.0
	    sample_curve_001_1.width, sample_curve_001_1.height = 140.0, 100.0
	    evaluate_at_index_3.width, evaluate_at_index_3.height = 140.0, 100.0
	    reroute_001_4.width, reroute_001_4.height = 10.0, 100.0
	    reroute_008_2.width, reroute_008_2.height = 10.0, 100.0
	    reroute_007_2.width, reroute_007_2.height = 10.0, 100.0
	    reroute_026_1.width, reroute_026_1.height = 10.0, 100.0
	    reroute_027_1.width, reroute_027_1.height = 10.0, 100.0
	    evaluate_on_domain_001_2.width, evaluate_on_domain_001_2.height = 140.0, 100.0
	    sample_index_1.width, sample_index_1.height = 140.0, 100.0
	    accumulate_field_002.width, accumulate_field_002.height = 140.0, 100.0
	    group_input_002_2.width, group_input_002_2.height = 140.0, 100.0
	    reroute_032.width, reroute_032.height = 10.0, 100.0
	    boolean_math_001.width, boolean_math_001.height = 140.0, 100.0
	    switch_001_5.width, switch_001_5.height = 140.0, 100.0
	    named_attribute_003.width, named_attribute_003.height = 167.335205078125, 100.0
	    group_input_013.width, group_input_013.height = 140.0, 100.0
	    group_input_004_2.width, group_input_004_2.height = 140.0, 100.0
	    reroute_006_2.width, reroute_006_2.height = 10.0, 100.0
	    compare_003_2.width, compare_003_2.height = 140.0, 100.0
	    group_input_011.width, group_input_011.height = 140.0, 100.0
	    accumulate_field_1.width, accumulate_field_1.height = 140.0, 100.0
	    switch_003_4.width, switch_003_4.height = 140.0, 100.0
	    compare_001_2.width, compare_001_2.height = 140.0, 100.0
	    group_003_1.width, group_003_1.height = 201.331298828125, 100.0
	    boolean_math_002_2.width, boolean_math_002_2.height = 140.0, 100.0
	    sample_index_001_1.width, sample_index_001_1.height = 140.0, 100.0
	    reroute_029.width, reroute_029.height = 10.0, 100.0
	    capture_attribute_001_2.width, capture_attribute_001_2.height = 140.0, 100.0
	    position_1.width, position_1.height = 140.0, 100.0
	    mix_1.width, mix_1.height = 140.0, 100.0
	    vector_math_009_2.width, vector_math_009_2.height = 140.0, 100.0
	    math_002_1.width, math_002_1.height = 140.0, 100.0
	    set_position_2.width, set_position_2.height = 140.0, 100.0
	    group_input_001_3.width, group_input_001_3.height = 140.0, 100.0
	    math_4.width, math_4.height = 140.0, 100.0
	    vector_math_013_1.width, vector_math_013_1.height = 140.0, 100.0
	    vector_math_007_2.width, vector_math_007_2.height = 140.0, 100.0
	    vector_math_011_1.width, vector_math_011_1.height = 140.0, 100.0
	    reroute_020_2.width, reroute_020_2.height = 10.0, 100.0
	    math_001_2.width, math_001_2.height = 140.0, 100.0
	    reroute_004_3.width, reroute_004_3.height = 10.0, 100.0
	    vector_math_025.width, vector_math_025.height = 140.0, 100.0
	    switch_002_3.width, switch_002_3.height = 140.0, 100.0
	    vector_math_020.width, vector_math_020.height = 140.0, 100.0
	    vector_math_021.width, vector_math_021.height = 140.0, 100.0
	    vector_math_022.width, vector_math_022.height = 140.0, 100.0
	    vector_math_015.width, vector_math_015.height = 140.0, 100.0
	    vector_math_016.width, vector_math_016.height = 140.0, 100.0
	    vector_math_018.width, vector_math_018.height = 140.0, 100.0
	    vector_math_019.width, vector_math_019.height = 140.0, 100.0
	    vector_math_014_1.width, vector_math_014_1.height = 140.0, 100.0
	    switch_4.width, switch_4.height = 140.0, 100.0
	    sample_curve_002.width, sample_curve_002.height = 140.0, 100.0
	    reroute_011_2.width, reroute_011_2.height = 10.0, 100.0
	    vector_math_017.width, vector_math_017.height = 140.0, 100.0
	    random_value_1.width, random_value_1.height = 140.0, 100.0
	    vector_math_026.width, vector_math_026.height = 140.0, 100.0
	    separate_xyz_002_1.width, separate_xyz_002_1.height = 140.0, 100.0
	    separate_xyz_001_1.width, separate_xyz_001_1.height = 140.0, 100.0
	    reroute_009_2.width, reroute_009_2.height = 10.0, 100.0
	    vector_math_012_1.width, vector_math_012_1.height = 140.0, 100.0
	    group_input_009_1.width, group_input_009_1.height = 140.0, 100.0
	    group_input_012.width, group_input_012.height = 140.0, 100.0
	    group_input_008_1.width, group_input_008_1.height = 140.0, 100.0
	    random_value_001_2.width, random_value_001_2.height = 140.0, 100.0
	    reroute_028_1.width, reroute_028_1.height = 10.0, 100.0
	    evaluate_at_index_001_1.width, evaluate_at_index_001_1.height = 140.0, 100.0
	    group_006.width, group_006.height = 140.0, 100.0
	    group_007.width, group_007.height = 140.0, 100.0
	    random_value_004_1.width, random_value_004_1.height = 140.0, 100.0
	    group_input_005_2.width, group_input_005_2.height = 140.0, 100.0
	    compare_3.width, compare_3.height = 140.0, 100.0
	    compare_002_2.width, compare_002_2.height = 140.0, 100.0
	    spline_parameter_001.width, spline_parameter_001.height = 140.0, 100.0
	    group_input_4.width, group_input_4.height = 140.0, 100.0
	    group_001_3.width, group_001_3.height = 140.0, 100.0
	    math_003_2.width, math_003_2.height = 140.0, 100.0
	    vector_math_010_1.width, vector_math_010_1.height = 140.0, 100.0
	    compare_006.width, compare_006.height = 140.0, 100.0
	    compare_007.width, compare_007.height = 140.0, 100.0
	    reroute_030.width, reroute_030.height = 10.0, 100.0
	    group_input_007_2.width, group_input_007_2.height = 140.0, 100.0
	    group_input_006_2.width, group_input_006_2.height = 140.0, 100.0
	    compare_005_1.width, compare_005_1.height = 140.0, 100.0
	    map_range_001_1.width, map_range_001_1.height = 140.0, 100.0
	    boolean_math_2.width, boolean_math_2.height = 140.0, 100.0
	    switch_004_1.width, switch_004_1.height = 140.0, 100.0
	    group_002_2.width, group_002_2.height = 140.0, 100.0
	
	    #initialize clump_hair_curves links
	    #group_input_003_3.Geometry -> separate_components_2.Geometry
	    clump_hair_curves.links.new(group_input_003_3.outputs[0], separate_components_2.inputs[0])
	    #reroute_032.Output -> group_003_1.Geometry
	    clump_hair_curves.links.new(reroute_032.outputs[0], group_003_1.inputs[0])
	    #accumulate_field_002.Total -> sample_index_1.Value
	    clump_hair_curves.links.new(accumulate_field_002.outputs[2], sample_index_1.inputs[1])
	    #reroute_032.Output -> sample_index_1.Geometry
	    clump_hair_curves.links.new(reroute_032.outputs[0], sample_index_1.inputs[0])
	    #named_attribute_003.Exists -> accumulate_field_002.Value
	    clump_hair_curves.links.new(named_attribute_003.outputs[1], accumulate_field_002.inputs[0])
	    #sample_index_1.Value -> compare_001_2.A
	    clump_hair_curves.links.new(sample_index_1.outputs[0], compare_001_2.inputs[2])
	    #group_003_1.Geometry -> switch_001_5.False
	    clump_hair_curves.links.new(group_003_1.outputs[0], switch_001_5.inputs[1])
	    #reroute_032.Output -> switch_001_5.True
	    clump_hair_curves.links.new(reroute_032.outputs[0], switch_001_5.inputs[2])
	    #compare_001_2.Result -> boolean_math_001.Boolean
	    clump_hair_curves.links.new(compare_001_2.outputs[0], boolean_math_001.inputs[0])
	    #boolean_math_002_2.Boolean -> switch_001_5.Switch
	    clump_hair_curves.links.new(boolean_math_002_2.outputs[0], switch_001_5.inputs[0])
	    #reroute_008_2.Output -> sample_curve.Curve Index
	    clump_hair_curves.links.new(reroute_008_2.outputs[0], sample_curve.inputs[4])
	    #reroute_025.Output -> sample_curve.Curves
	    clump_hair_curves.links.new(reroute_025.outputs[0], sample_curve.inputs[0])
	    #sample_curve.Tangent -> vector_math_3.Vector
	    clump_hair_curves.links.new(sample_curve.outputs[2], vector_math_3.inputs[0])
	    #sample_curve.Normal -> vector_math_3.Vector
	    clump_hair_curves.links.new(sample_curve.outputs[3], vector_math_3.inputs[1])
	    #sample_curve_001_1.Tangent -> vector_math_003_2.Vector
	    clump_hair_curves.links.new(sample_curve_001_1.outputs[2], vector_math_003_2.inputs[0])
	    #sample_curve_001_1.Normal -> vector_math_003_2.Vector
	    clump_hair_curves.links.new(sample_curve_001_1.outputs[3], vector_math_003_2.inputs[1])
	    #vector_math_003_2.Vector -> vector_math_004_3.Vector
	    clump_hair_curves.links.new(vector_math_003_2.outputs[0], vector_math_004_3.inputs[0])
	    #sample_curve_001_1.Normal -> vector_math_005_1.Vector
	    clump_hair_curves.links.new(sample_curve_001_1.outputs[3], vector_math_005_1.inputs[0])
	    #reroute_003_2.Output -> sample_curve_001_1.Curves
	    clump_hair_curves.links.new(reroute_003_2.outputs[0], sample_curve_001_1.inputs[0])
	    #reroute_001_4.Output -> sample_curve_001_1.Curve Index
	    clump_hair_curves.links.new(reroute_001_4.outputs[0], sample_curve_001_1.inputs[4])
	    #evaluate_on_domain_1.Value -> separate_xyz_1.Vector
	    clump_hair_curves.links.new(evaluate_on_domain_1.outputs[0], separate_xyz_1.inputs[0])
	    #sample_curve.Normal -> vector_math_001_3.Vector
	    clump_hair_curves.links.new(sample_curve.outputs[3], vector_math_001_3.inputs[0])
	    #separate_xyz_1.X -> vector_math_001_3.Scale
	    clump_hair_curves.links.new(separate_xyz_1.outputs[0], vector_math_001_3.inputs[3])
	    #vector_math_3.Vector -> vector_math_002_2.Vector
	    clump_hair_curves.links.new(vector_math_3.outputs[0], vector_math_002_2.inputs[0])
	    #separate_xyz_1.Y -> vector_math_002_2.Scale
	    clump_hair_curves.links.new(separate_xyz_1.outputs[1], vector_math_002_2.inputs[3])
	    #vector_math_001_3.Vector -> vector_math_006_2.Vector
	    clump_hair_curves.links.new(vector_math_001_3.outputs[0], vector_math_006_2.inputs[0])
	    #vector_math_002_2.Vector -> vector_math_006_2.Vector
	    clump_hair_curves.links.new(vector_math_002_2.outputs[0], vector_math_006_2.inputs[1])
	    #vector_math_005_1.Value -> combine_xyz_1.X
	    clump_hair_curves.links.new(vector_math_005_1.outputs[1], combine_xyz_1.inputs[0])
	    #vector_math_004_3.Value -> combine_xyz_1.Y
	    clump_hair_curves.links.new(vector_math_004_3.outputs[1], combine_xyz_1.inputs[1])
	    #combine_xyz_1.Vector -> evaluate_on_domain_1.Value
	    clump_hair_curves.links.new(combine_xyz_1.outputs[0], evaluate_on_domain_1.inputs[0])
	    #reroute_4.Output -> vector_math_005_1.Vector
	    clump_hair_curves.links.new(reroute_4.outputs[0], vector_math_005_1.inputs[1])
	    #reroute_4.Output -> vector_math_004_3.Vector
	    clump_hair_curves.links.new(reroute_4.outputs[0], vector_math_004_3.inputs[1])
	    #evaluate_at_index_3.Value -> vector_math_008_2.Vector
	    clump_hair_curves.links.new(evaluate_at_index_3.outputs[0], vector_math_008_2.inputs[1])
	    #reroute_001_4.Output -> evaluate_at_index_3.Index
	    clump_hair_curves.links.new(reroute_001_4.outputs[0], evaluate_at_index_3.inputs[0])
	    #reroute_002_2.Output -> reroute_001_4.Input
	    clump_hair_curves.links.new(reroute_002_2.outputs[0], reroute_001_4.inputs[0])
	    #mix_1.Result -> set_position_2.Position
	    clump_hair_curves.links.new(mix_1.outputs[1], set_position_2.inputs[2])
	    #vector_math_011_1.Vector -> vector_math_009_2.Vector
	    clump_hair_curves.links.new(vector_math_011_1.outputs[0], vector_math_009_2.inputs[1])
	    #sample_curve.Position -> vector_math_009_2.Vector
	    clump_hair_curves.links.new(sample_curve.outputs[1], vector_math_009_2.inputs[0])
	    #vector_math_006_2.Vector -> vector_math_007_2.Vector
	    clump_hair_curves.links.new(vector_math_006_2.outputs[0], vector_math_007_2.inputs[0])
	    #reroute_020_2.Output -> math_4.Value
	    clump_hair_curves.links.new(reroute_020_2.outputs[0], math_4.inputs[1])
	    #math_4.Value -> vector_math_007_2.Scale
	    clump_hair_curves.links.new(math_4.outputs[0], vector_math_007_2.inputs[3])
	    #vector_math_009_2.Vector -> mix_1.B
	    clump_hair_curves.links.new(vector_math_009_2.outputs[0], mix_1.inputs[5])
	    #position_1.Position -> mix_1.A
	    clump_hair_curves.links.new(position_1.outputs[0], mix_1.inputs[4])
	    #reroute_029.Output -> reroute_002_2.Input
	    clump_hair_curves.links.new(reroute_029.outputs[0], reroute_002_2.inputs[0])
	    #spline_parameter_001.Factor -> group_001_3.Value
	    clump_hair_curves.links.new(spline_parameter_001.outputs[0], group_001_3.inputs[0])
	    #group_input_4.Shape -> group_001_3.Shape
	    clump_hair_curves.links.new(group_input_4.outputs[6], group_001_3.inputs[3])
	    #group_001_3.Value -> reroute_004_3.Input
	    clump_hair_curves.links.new(group_001_3.outputs[0], reroute_004_3.inputs[0])
	    #reroute_004_3.Output -> math_001_2.Value
	    clump_hair_curves.links.new(reroute_004_3.outputs[0], math_001_2.inputs[0])
	    #group_input_001_3.Factor -> math_001_2.Value
	    clump_hair_curves.links.new(group_input_001_3.outputs[5], math_001_2.inputs[1])
	    #math_002_1.Value -> mix_1.Factor
	    clump_hair_curves.links.new(math_002_1.outputs[0], mix_1.inputs[0])
	    #group_input_002_2.Existing Guide Map -> boolean_math_001.Boolean
	    clump_hair_curves.links.new(group_input_002_2.outputs[4], boolean_math_001.inputs[1])
	    #group_input_004_2.Guide Distance -> group_003_1.Guide Distance
	    clump_hair_curves.links.new(group_input_004_2.outputs[2], group_003_1.inputs[2])
	    #reroute_003_2.Output -> reroute_005_2.Input
	    clump_hair_curves.links.new(reroute_003_2.outputs[0], reroute_005_2.inputs[0])
	    #vector_math_008_2.Vector -> reroute_4.Input
	    clump_hair_curves.links.new(vector_math_008_2.outputs[0], reroute_4.inputs[0])
	    #math_001_2.Value -> math_002_1.Value
	    clump_hair_curves.links.new(math_001_2.outputs[0], math_002_1.inputs[0])
	    #vector_math_008_2.Vector -> vector_math_010_1.Vector
	    clump_hair_curves.links.new(vector_math_008_2.outputs[0], vector_math_010_1.inputs[0])
	    #vector_math_010_1.Value -> map_range_001_1.Value
	    clump_hair_curves.links.new(vector_math_010_1.outputs[1], map_range_001_1.inputs[0])
	    #switch_004_1.Output -> math_002_1.Value
	    clump_hair_curves.links.new(switch_004_1.outputs[0], math_002_1.inputs[1])
	    #reroute_030.Output -> map_range_001_1.From Min
	    clump_hair_curves.links.new(reroute_030.outputs[0], map_range_001_1.inputs[1])
	    #group_input_006_2.Distance Threshold -> math_003_2.Value
	    clump_hair_curves.links.new(group_input_006_2.outputs[10], math_003_2.inputs[0])
	    #group_input_007_2.Distance Falloff -> math_003_2.Value
	    clump_hair_curves.links.new(group_input_007_2.outputs[9], math_003_2.inputs[1])
	    #math_003_2.Value -> map_range_001_1.From Max
	    clump_hair_curves.links.new(math_003_2.outputs[0], map_range_001_1.inputs[2])
	    #group_input_008_1.Tip Spread -> vector_math_012_1.Scale
	    clump_hair_curves.links.new(group_input_008_1.outputs[7], vector_math_012_1.inputs[3])
	    #random_value_1.Value -> vector_math_012_1.Vector
	    clump_hair_curves.links.new(random_value_1.outputs[0], vector_math_012_1.inputs[0])
	    #evaluate_on_domain_001_2.Value -> vector_math_013_1.Vector
	    clump_hair_curves.links.new(evaluate_on_domain_001_2.outputs[0], vector_math_013_1.inputs[0])
	    #reroute_020_2.Output -> vector_math_013_1.Scale
	    clump_hair_curves.links.new(reroute_020_2.outputs[0], vector_math_013_1.inputs[3])
	    #vector_math_007_2.Vector -> vector_math_011_1.Vector
	    clump_hair_curves.links.new(vector_math_007_2.outputs[0], vector_math_011_1.inputs[0])
	    #reroute_005_2.Output -> sample_curve_002.Curves
	    clump_hair_curves.links.new(reroute_005_2.outputs[0], sample_curve_002.inputs[0])
	    #vector_math_012_1.Vector -> separate_xyz_001_1.Vector
	    clump_hair_curves.links.new(vector_math_012_1.outputs[0], separate_xyz_001_1.inputs[0])
	    #sample_curve_002.Tangent -> vector_math_014_1.Vector
	    clump_hair_curves.links.new(sample_curve_002.outputs[2], vector_math_014_1.inputs[0])
	    #sample_curve_002.Normal -> vector_math_015.Vector
	    clump_hair_curves.links.new(sample_curve_002.outputs[3], vector_math_015.inputs[0])
	    #separate_xyz_001_1.Z -> vector_math_014_1.Scale
	    clump_hair_curves.links.new(separate_xyz_001_1.outputs[2], vector_math_014_1.inputs[3])
	    #separate_xyz_001_1.X -> vector_math_015.Scale
	    clump_hair_curves.links.new(separate_xyz_001_1.outputs[0], vector_math_015.inputs[3])
	    #sample_curve_002.Tangent -> vector_math_017.Vector
	    clump_hair_curves.links.new(sample_curve_002.outputs[2], vector_math_017.inputs[0])
	    #sample_curve_002.Normal -> vector_math_017.Vector
	    clump_hair_curves.links.new(sample_curve_002.outputs[3], vector_math_017.inputs[1])
	    #separate_xyz_001_1.Y -> vector_math_016.Scale
	    clump_hair_curves.links.new(separate_xyz_001_1.outputs[1], vector_math_016.inputs[3])
	    #vector_math_017.Vector -> vector_math_016.Vector
	    clump_hair_curves.links.new(vector_math_017.outputs[0], vector_math_016.inputs[0])
	    #vector_math_015.Vector -> vector_math_018.Vector
	    clump_hair_curves.links.new(vector_math_015.outputs[0], vector_math_018.inputs[0])
	    #vector_math_016.Vector -> vector_math_018.Vector
	    clump_hair_curves.links.new(vector_math_016.outputs[0], vector_math_018.inputs[1])
	    #vector_math_018.Vector -> vector_math_019.Vector
	    clump_hair_curves.links.new(vector_math_018.outputs[0], vector_math_019.inputs[0])
	    #vector_math_014_1.Vector -> vector_math_019.Vector
	    clump_hair_curves.links.new(vector_math_014_1.outputs[0], vector_math_019.inputs[1])
	    #reroute_011_2.Output -> sample_curve_002.Curve Index
	    clump_hair_curves.links.new(reroute_011_2.outputs[0], sample_curve_002.inputs[4])
	    #vector_math_026.Vector -> separate_xyz_002_1.Vector
	    clump_hair_curves.links.new(vector_math_026.outputs[0], separate_xyz_002_1.inputs[0])
	    #sample_curve_002.Normal -> vector_math_020.Vector
	    clump_hair_curves.links.new(sample_curve_002.outputs[3], vector_math_020.inputs[0])
	    #separate_xyz_002_1.X -> vector_math_020.Scale
	    clump_hair_curves.links.new(separate_xyz_002_1.outputs[0], vector_math_020.inputs[3])
	    #separate_xyz_002_1.Y -> vector_math_021.Scale
	    clump_hair_curves.links.new(separate_xyz_002_1.outputs[1], vector_math_021.inputs[3])
	    #vector_math_020.Vector -> vector_math_022.Vector
	    clump_hair_curves.links.new(vector_math_020.outputs[0], vector_math_022.inputs[0])
	    #vector_math_021.Vector -> vector_math_022.Vector
	    clump_hair_curves.links.new(vector_math_021.outputs[0], vector_math_022.inputs[1])
	    #vector_math_017.Vector -> vector_math_021.Vector
	    clump_hair_curves.links.new(vector_math_017.outputs[0], vector_math_021.inputs[0])
	    #random_value_001_2.Value -> vector_math_026.Vector
	    clump_hair_curves.links.new(random_value_001_2.outputs[0], vector_math_026.inputs[0])
	    #reroute_009_2.Output -> vector_math_026.Scale
	    clump_hair_curves.links.new(reroute_009_2.outputs[0], vector_math_026.inputs[3])
	    #vector_math_013_1.Vector -> vector_math_011_1.Vector
	    clump_hair_curves.links.new(vector_math_013_1.outputs[0], vector_math_011_1.inputs[1])
	    #switch_4.Output -> vector_math_025.Vector
	    clump_hair_curves.links.new(switch_4.outputs[0], vector_math_025.inputs[0])
	    #switch_002_3.Output -> vector_math_025.Vector
	    clump_hair_curves.links.new(switch_002_3.outputs[0], vector_math_025.inputs[1])
	    #vector_math_025.Vector -> evaluate_on_domain_001_2.Value
	    clump_hair_curves.links.new(vector_math_025.outputs[0], evaluate_on_domain_001_2.inputs[0])
	    #vector_math_022.Vector -> switch_002_3.False
	    clump_hair_curves.links.new(vector_math_022.outputs[0], switch_002_3.inputs[1])
	    #vector_math_019.Vector -> switch_4.False
	    clump_hair_curves.links.new(vector_math_019.outputs[0], switch_4.inputs[1])
	    #reroute_009_2.Output -> compare_002_2.B
	    clump_hair_curves.links.new(reroute_009_2.outputs[0], compare_002_2.inputs[1])
	    #compare_002_2.Result -> switch_002_3.Switch
	    clump_hair_curves.links.new(compare_002_2.outputs[0], switch_002_3.inputs[0])
	    #group_input_009_1.Clump Offset -> reroute_009_2.Input
	    clump_hair_curves.links.new(group_input_009_1.outputs[8], reroute_009_2.inputs[0])
	    #reroute_028_1.Output -> random_value_1.Seed
	    clump_hair_curves.links.new(reroute_028_1.outputs[0], random_value_1.inputs[8])
	    #reroute_028_1.Output -> random_value_001_2.Seed
	    clump_hair_curves.links.new(reroute_028_1.outputs[0], random_value_001_2.inputs[8])
	    #reroute_011_2.Output -> evaluate_at_index_001_1.Index
	    clump_hair_curves.links.new(reroute_011_2.outputs[0], evaluate_at_index_001_1.inputs[0])
	    #capture_attribute_2.Geometry -> reroute_032.Input
	    clump_hair_curves.links.new(capture_attribute_2.outputs[0], reroute_032.inputs[0])
	    #capture_attribute_001_2.Geometry -> reroute_003_2.Input
	    clump_hair_curves.links.new(capture_attribute_001_2.outputs[0], reroute_003_2.inputs[0])
	    #reroute_018_3.Output -> join_geometry_001_2.Geometry
	    clump_hair_curves.links.new(reroute_018_3.outputs[0], join_geometry_001_2.inputs[0])
	    #separate_components_2.Mesh -> reroute_012_3.Input
	    clump_hair_curves.links.new(separate_components_2.outputs[0], reroute_012_3.inputs[0])
	    #separate_components_2.Instances -> reroute_013_3.Input
	    clump_hair_curves.links.new(separate_components_2.outputs[5], reroute_013_3.inputs[0])
	    #separate_components_2.Point Cloud -> reroute_014_3.Input
	    clump_hair_curves.links.new(separate_components_2.outputs[3], reroute_014_3.inputs[0])
	    #separate_components_2.Volume -> reroute_015_3.Input
	    clump_hair_curves.links.new(separate_components_2.outputs[4], reroute_015_3.inputs[0])
	    #join_geometry_001_2.Geometry -> group_output_001.Geometry
	    clump_hair_curves.links.new(join_geometry_001_2.outputs[0], group_output_001.inputs[0])
	    #reroute_012_3.Output -> reroute_016_3.Input
	    clump_hair_curves.links.new(reroute_012_3.outputs[0], reroute_016_3.inputs[0])
	    #reroute_014_3.Output -> reroute_017_3.Input
	    clump_hair_curves.links.new(reroute_014_3.outputs[0], reroute_017_3.inputs[0])
	    #reroute_013_3.Output -> reroute_018_3.Input
	    clump_hair_curves.links.new(reroute_013_3.outputs[0], reroute_018_3.inputs[0])
	    #reroute_015_3.Output -> reroute_019_2.Input
	    clump_hair_curves.links.new(reroute_015_3.outputs[0], reroute_019_2.inputs[0])
	    #set_position_2.Geometry -> group_005.Curves
	    clump_hair_curves.links.new(set_position_2.outputs[0], group_005.inputs[0])
	    #position_001_1.Position -> capture_attribute_2.Value
	    clump_hair_curves.links.new(position_001_1.outputs[0], capture_attribute_2.inputs[1])
	    #reroute_022_1.Output -> group_005.Reference Position
	    clump_hair_curves.links.new(reroute_022_1.outputs[0], group_005.inputs[3])
	    #group_input_010_1.Preserve Length -> group_005.Selection
	    clump_hair_curves.links.new(group_input_010_1.outputs[12], group_005.inputs[1])
	    #spline_parameter.Factor -> sample_curve.Factor
	    clump_hair_curves.links.new(spline_parameter.outputs[0], sample_curve.inputs[2])
	    #reroute_006_2.Output -> compare_003_2.A
	    clump_hair_curves.links.new(reroute_006_2.outputs[0], compare_003_2.inputs[2])
	    #named_attribute_003.Attribute -> switch_003_4.False
	    clump_hair_curves.links.new(named_attribute_003.outputs[0], switch_003_4.inputs[1])
	    #compare_003_2.Result -> switch_003_4.Switch
	    clump_hair_curves.links.new(compare_003_2.outputs[0], switch_003_4.inputs[0])
	    #reroute_006_2.Output -> switch_003_4.True
	    clump_hair_curves.links.new(reroute_006_2.outputs[0], switch_003_4.inputs[2])
	    #boolean_math_001.Boolean -> boolean_math_002_2.Boolean
	    clump_hair_curves.links.new(boolean_math_001.outputs[0], boolean_math_002_2.inputs[0])
	    #reroute_027_1.Output -> group_output_001.Guide Index
	    clump_hair_curves.links.new(reroute_027_1.outputs[0], group_output_001.inputs[1])
	    #separate_components_2.Curve -> capture_attribute_002_2.Geometry
	    clump_hair_curves.links.new(separate_components_2.outputs[1], capture_attribute_002_2.inputs[0])
	    #spline_resolution.Resolution -> capture_attribute_002_2.Value
	    clump_hair_curves.links.new(spline_resolution.outputs[0], capture_attribute_002_2.inputs[1])
	    #set_spline_type_001.Curve -> set_spline_resolution_001.Geometry
	    clump_hair_curves.links.new(set_spline_type_001.outputs[0], set_spline_resolution_001.inputs[0])
	    #set_spline_type_002.Curve -> capture_attribute_2.Geometry
	    clump_hair_curves.links.new(set_spline_type_002.outputs[0], capture_attribute_2.inputs[0])
	    #group_006.Curve ID -> evaluate_at_index_001_1.Value
	    clump_hair_curves.links.new(group_006.outputs[1], evaluate_at_index_001_1.inputs[1])
	    #evaluate_at_index_001_1.Value -> random_value_001_2.ID
	    clump_hair_curves.links.new(evaluate_at_index_001_1.outputs[0], random_value_001_2.inputs[7])
	    #group_007.Curve ID -> random_value_1.ID
	    clump_hair_curves.links.new(group_007.outputs[1], random_value_1.inputs[7])
	    #group_input_013.Guide Mask -> group_003_1.Guide Mask
	    clump_hair_curves.links.new(group_input_013.outputs[3], group_003_1.inputs[3])
	    #reroute_021_1.Output -> compare_004_3.A
	    clump_hair_curves.links.new(reroute_021_1.outputs[0], compare_004_3.inputs[2])
	    #compare_004_3.Result -> switch_006.Switch
	    clump_hair_curves.links.new(compare_004_3.outputs[0], switch_006.inputs[0])
	    #reroute_021_1.Output -> switch_006.False
	    clump_hair_curves.links.new(reroute_021_1.outputs[0], switch_006.inputs[1])
	    #group_005.Curves -> set_spline_type_001.Curve
	    clump_hair_curves.links.new(group_005.outputs[0], set_spline_type_001.inputs[0])
	    #reroute_024_1.Output -> reroute_021_1.Input
	    clump_hair_curves.links.new(reroute_024_1.outputs[0], reroute_021_1.inputs[0])
	    #switch_006.Output -> set_spline_resolution_001.Resolution
	    clump_hair_curves.links.new(switch_006.outputs[0], set_spline_resolution_001.inputs[2])
	    #capture_attribute_002_2.Geometry -> set_spline_type_002.Curve
	    clump_hair_curves.links.new(capture_attribute_002_2.outputs[0], set_spline_type_002.inputs[0])
	    #compare_003_2.Result -> accumulate_field_1.Value
	    clump_hair_curves.links.new(compare_003_2.outputs[0], accumulate_field_1.inputs[0])
	    #accumulate_field_1.Total -> sample_index_001_1.Value
	    clump_hair_curves.links.new(accumulate_field_1.outputs[2], sample_index_001_1.inputs[1])
	    #reroute_032.Output -> sample_index_001_1.Geometry
	    clump_hair_curves.links.new(reroute_032.outputs[0], sample_index_001_1.inputs[0])
	    #sample_index_001_1.Value -> boolean_math_002_2.Boolean
	    clump_hair_curves.links.new(sample_index_001_1.outputs[0], boolean_math_002_2.inputs[1])
	    #group_input_011.Guide Index -> reroute_006_2.Input
	    clump_hair_curves.links.new(group_input_011.outputs[1], reroute_006_2.inputs[0])
	    #reroute_002_2.Output -> reroute_008_2.Input
	    clump_hair_curves.links.new(reroute_002_2.outputs[0], reroute_008_2.inputs[0])
	    #reroute_004_3.Output -> reroute_020_2.Input
	    clump_hair_curves.links.new(reroute_004_3.outputs[0], reroute_020_2.inputs[0])
	    #reroute_025.Output -> set_position_2.Geometry
	    clump_hair_curves.links.new(reroute_025.outputs[0], set_position_2.inputs[0])
	    #reroute_029.Output -> reroute_011_2.Input
	    clump_hair_curves.links.new(reroute_029.outputs[0], reroute_011_2.inputs[0])
	    #capture_attribute_2.Value -> reroute_010_1.Input
	    clump_hair_curves.links.new(capture_attribute_2.outputs[1], reroute_010_1.inputs[0])
	    #reroute_010_1.Output -> reroute_022_1.Input
	    clump_hair_curves.links.new(reroute_010_1.outputs[0], reroute_022_1.inputs[0])
	    #capture_attribute_002_2.Value -> reroute_023_1.Input
	    clump_hair_curves.links.new(capture_attribute_002_2.outputs[1], reroute_023_1.inputs[0])
	    #reroute_023_1.Output -> reroute_024_1.Input
	    clump_hair_curves.links.new(reroute_023_1.outputs[0], reroute_024_1.inputs[0])
	    #reroute_005_2.Output -> reroute_025.Input
	    clump_hair_curves.links.new(reroute_005_2.outputs[0], reroute_025.inputs[0])
	    #group_input_012.Tip Spread -> compare_3.A
	    clump_hair_curves.links.new(group_input_012.outputs[7], compare_3.inputs[0])
	    #compare_3.Result -> switch_4.Switch
	    clump_hair_curves.links.new(compare_3.outputs[0], switch_4.inputs[0])
	    #reroute_008_2.Output -> reroute_007_2.Input
	    clump_hair_curves.links.new(reroute_008_2.outputs[0], reroute_007_2.inputs[0])
	    #reroute_007_2.Output -> reroute_026_1.Input
	    clump_hair_curves.links.new(reroute_007_2.outputs[0], reroute_026_1.inputs[0])
	    #reroute_026_1.Output -> reroute_027_1.Input
	    clump_hair_curves.links.new(reroute_026_1.outputs[0], reroute_027_1.inputs[0])
	    #random_value_004_1.Value -> reroute_028_1.Input
	    clump_hair_curves.links.new(random_value_004_1.outputs[2], reroute_028_1.inputs[0])
	    #group_input_005_2.Seed -> random_value_004_1.ID
	    clump_hair_curves.links.new(group_input_005_2.outputs[11], random_value_004_1.inputs[7])
	    #switch_001_5.Output -> capture_attribute_001_2.Geometry
	    clump_hair_curves.links.new(switch_001_5.outputs[0], capture_attribute_001_2.inputs[0])
	    #switch_003_4.Output -> capture_attribute_001_2.Value
	    clump_hair_curves.links.new(switch_003_4.outputs[0], capture_attribute_001_2.inputs[1])
	    #capture_attribute_001_2.Value -> reroute_029.Input
	    clump_hair_curves.links.new(capture_attribute_001_2.outputs[1], reroute_029.inputs[0])
	    #map_range_001_1.Result -> switch_004_1.False
	    clump_hair_curves.links.new(map_range_001_1.outputs[0], switch_004_1.inputs[1])
	    #vector_math_010_1.Value -> compare_005_1.A
	    clump_hair_curves.links.new(vector_math_010_1.outputs[1], compare_005_1.inputs[0])
	    #compare_005_1.Result -> switch_004_1.True
	    clump_hair_curves.links.new(compare_005_1.outputs[0], switch_004_1.inputs[2])
	    #reroute_030.Output -> compare_005_1.B
	    clump_hair_curves.links.new(reroute_030.outputs[0], compare_005_1.inputs[1])
	    #group_input_006_2.Distance Threshold -> compare_006.A
	    clump_hair_curves.links.new(group_input_006_2.outputs[10], compare_006.inputs[0])
	    #group_input_007_2.Distance Falloff -> compare_007.A
	    clump_hair_curves.links.new(group_input_007_2.outputs[9], compare_007.inputs[0])
	    #compare_006.Result -> boolean_math_2.Boolean
	    clump_hair_curves.links.new(compare_006.outputs[0], boolean_math_2.inputs[0])
	    #compare_007.Result -> boolean_math_2.Boolean
	    clump_hair_curves.links.new(compare_007.outputs[0], boolean_math_2.inputs[1])
	    #boolean_math_2.Boolean -> switch_004_1.Switch
	    clump_hair_curves.links.new(boolean_math_2.outputs[0], switch_004_1.inputs[0])
	    #group_input_006_2.Distance Threshold -> reroute_030.Input
	    clump_hair_curves.links.new(group_input_006_2.outputs[10], reroute_030.inputs[0])
	    #group_002_2.Root Position -> vector_math_008_2.Vector
	    clump_hair_curves.links.new(group_002_2.outputs[1], vector_math_008_2.inputs[0])
	    #group_002_2.Root Position -> evaluate_at_index_3.Value
	    clump_hair_curves.links.new(group_002_2.outputs[1], evaluate_at_index_3.inputs[1])
	    #reroute_019_2.Output -> join_geometry_001_2.Geometry
	    clump_hair_curves.links.new(reroute_019_2.outputs[0], join_geometry_001_2.inputs[0])
	    #set_spline_resolution_001.Geometry -> join_geometry_001_2.Geometry
	    clump_hair_curves.links.new(set_spline_resolution_001.outputs[0], join_geometry_001_2.inputs[0])
	    #reroute_017_3.Output -> join_geometry_001_2.Geometry
	    clump_hair_curves.links.new(reroute_017_3.outputs[0], join_geometry_001_2.inputs[0])
	    #reroute_016_3.Output -> join_geometry_001_2.Geometry
	    clump_hair_curves.links.new(reroute_016_3.outputs[0], join_geometry_001_2.inputs[0])
	    return clump_hair_curves
	
	clump_hair_curves = clump_hair_curves_node_group()
	
	#initialize hair_shrinkwrap node group
	def hair_shrinkwrap_node_group():
	    hair_shrinkwrap = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Hair_Shrinkwrap")
	
	    hair_shrinkwrap.color_tag = 'NONE'
	    hair_shrinkwrap.description = ""
	    hair_shrinkwrap.default_group_node_width = 140
	    
	
	    hair_shrinkwrap.is_modifier = True
	
	    #hair_shrinkwrap interface
	    #Socket Geometry
	    geometry_socket_6 = hair_shrinkwrap.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_6.attribute_domain = 'POINT'
	
	    #Socket Geometry
	    geometry_socket_7 = hair_shrinkwrap.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_7.attribute_domain = 'POINT'
	
	    #Socket Surface
	    surface_socket = hair_shrinkwrap.interface.new_socket(name = "Surface", in_out='INPUT', socket_type = 'NodeSocketObject')
	    surface_socket.attribute_domain = 'POINT'
	
	    #Socket Offset
	    offset_socket = hair_shrinkwrap.interface.new_socket(name = "Offset", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    offset_socket.default_value = 0.0010000000474974513
	    offset_socket.min_value = 0.0
	    offset_socket.max_value = 10000.0
	    offset_socket.subtype = 'NONE'
	    offset_socket.attribute_domain = 'POINT'
	
	
	    #initialize hair_shrinkwrap nodes
	    #node Group Input
	    group_input_5 = hair_shrinkwrap.nodes.new("NodeGroupInput")
	    group_input_5.name = "Group Input"
	
	    #node Group Output
	    group_output_9 = hair_shrinkwrap.nodes.new("NodeGroupOutput")
	    group_output_9.name = "Group Output"
	    group_output_9.is_active_output = True
	
	    #node Object Info
	    object_info = hair_shrinkwrap.nodes.new("GeometryNodeObjectInfo")
	    object_info.name = "Object Info"
	    object_info.hide = True
	    object_info.transform_space = 'RELATIVE'
	    #As Instance
	    object_info.inputs[1].default_value = False
	
	    #node Geometry Proximity
	    geometry_proximity = hair_shrinkwrap.nodes.new("GeometryNodeProximity")
	    geometry_proximity.name = "Geometry Proximity"
	    geometry_proximity.hide = True
	    geometry_proximity.target_element = 'FACES'
	    #Group ID
	    geometry_proximity.inputs[1].default_value = 0
	    #Sample Group ID
	    geometry_proximity.inputs[3].default_value = 0
	
	    #node Capture Attribute
	    capture_attribute_3 = hair_shrinkwrap.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_3.name = "Capture Attribute"
	    capture_attribute_3.hide = True
	    capture_attribute_3.active_index = 0
	    capture_attribute_3.capture_items.clear()
	    capture_attribute_3.capture_items.new('FLOAT', "Position")
	    capture_attribute_3.capture_items["Position"].data_type = 'FLOAT_VECTOR'
	    capture_attribute_3.domain = 'POINT'
	
	    #node Position
	    position_2 = hair_shrinkwrap.nodes.new("GeometryNodeInputPosition")
	    position_2.name = "Position"
	    position_2.hide = True
	
	    #node Set Position
	    set_position_3 = hair_shrinkwrap.nodes.new("GeometryNodeSetPosition")
	    set_position_3.name = "Set Position"
	    set_position_3.hide = True
	    #Offset
	    set_position_3.inputs[3].default_value = (0.0, 0.0, 0.0)
	
	    #node Vector Math
	    vector_math_4 = hair_shrinkwrap.nodes.new("ShaderNodeVectorMath")
	    vector_math_4.name = "Vector Math"
	    vector_math_4.hide = True
	    vector_math_4.operation = 'SUBTRACT'
	
	    #node Vector Math.001
	    vector_math_001_4 = hair_shrinkwrap.nodes.new("ShaderNodeVectorMath")
	    vector_math_001_4.name = "Vector Math.001"
	    vector_math_001_4.hide = True
	    vector_math_001_4.operation = 'ADD'
	
	    #node Vector Math.002
	    vector_math_002_3 = hair_shrinkwrap.nodes.new("ShaderNodeVectorMath")
	    vector_math_002_3.name = "Vector Math.002"
	    vector_math_002_3.hide = True
	    vector_math_002_3.operation = 'NORMALIZE'
	
	    #node Vector Math.003
	    vector_math_003_3 = hair_shrinkwrap.nodes.new("ShaderNodeVectorMath")
	    vector_math_003_3.name = "Vector Math.003"
	    vector_math_003_3.hide = True
	    vector_math_003_3.operation = 'SCALE'
	
	    #node Reroute
	    reroute_5 = hair_shrinkwrap.nodes.new("NodeReroute")
	    reroute_5.name = "Reroute"
	    reroute_5.socket_idname = "NodeSocketVector"
	    #node Reroute.001
	    reroute_001_5 = hair_shrinkwrap.nodes.new("NodeReroute")
	    reroute_001_5.name = "Reroute.001"
	    reroute_001_5.socket_idname = "NodeSocketVector"
	    #node Reroute.002
	    reroute_002_3 = hair_shrinkwrap.nodes.new("NodeReroute")
	    reroute_002_3.name = "Reroute.002"
	    reroute_002_3.socket_idname = "NodeSocketVector"
	    #node Reroute.003
	    reroute_003_3 = hair_shrinkwrap.nodes.new("NodeReroute")
	    reroute_003_3.name = "Reroute.003"
	    reroute_003_3.socket_idname = "NodeSocketVector"
	    #node Frame
	    frame_5 = hair_shrinkwrap.nodes.new("NodeFrame")
	    frame_5.name = "Frame"
	    frame_5.label_size = 20
	    frame_5.shrink = True
	
	    #node Reroute.004
	    reroute_004_4 = hair_shrinkwrap.nodes.new("NodeReroute")
	    reroute_004_4.name = "Reroute.004"
	    reroute_004_4.socket_idname = "NodeSocketFloat"
	    #node Reroute.005
	    reroute_005_3 = hair_shrinkwrap.nodes.new("NodeReroute")
	    reroute_005_3.name = "Reroute.005"
	    reroute_005_3.socket_idname = "NodeSocketFloat"
	    #node Reroute.006
	    reroute_006_3 = hair_shrinkwrap.nodes.new("NodeReroute")
	    reroute_006_3.name = "Reroute.006"
	    reroute_006_3.socket_idname = "NodeSocketVector"
	    #node Reroute.007
	    reroute_007_3 = hair_shrinkwrap.nodes.new("NodeReroute")
	    reroute_007_3.name = "Reroute.007"
	    reroute_007_3.socket_idname = "NodeSocketVector"
	    #node Boolean Math
	    boolean_math_3 = hair_shrinkwrap.nodes.new("FunctionNodeBooleanMath")
	    boolean_math_3.name = "Boolean Math"
	    boolean_math_3.hide = True
	    boolean_math_3.operation = 'NOT'
	
	    #node Set Position.001
	    set_position_001_3 = hair_shrinkwrap.nodes.new("GeometryNodeSetPosition")
	    set_position_001_3.name = "Set Position.001"
	    set_position_001_3.hide = True
	    #Offset
	    set_position_001_3.inputs[3].default_value = (0.0, 0.0, 0.0)
	
	    #node Geometry Proximity.001
	    geometry_proximity_001 = hair_shrinkwrap.nodes.new("GeometryNodeProximity")
	    geometry_proximity_001.name = "Geometry Proximity.001"
	    geometry_proximity_001.hide = True
	    geometry_proximity_001.target_element = 'FACES'
	    #Group ID
	    geometry_proximity_001.inputs[1].default_value = 0
	    #Sample Group ID
	    geometry_proximity_001.inputs[3].default_value = 0
	
	    #node Reroute.008
	    reroute_008_3 = hair_shrinkwrap.nodes.new("NodeReroute")
	    reroute_008_3.name = "Reroute.008"
	    reroute_008_3.socket_idname = "NodeSocketGeometry"
	    #node Reroute.009
	    reroute_009_3 = hair_shrinkwrap.nodes.new("NodeReroute")
	    reroute_009_3.name = "Reroute.009"
	    reroute_009_3.socket_idname = "NodeSocketGeometry"
	    #node Reroute.010
	    reroute_010_2 = hair_shrinkwrap.nodes.new("NodeReroute")
	    reroute_010_2.name = "Reroute.010"
	    reroute_010_2.socket_idname = "NodeSocketVector"
	    #node Reroute.011
	    reroute_011_3 = hair_shrinkwrap.nodes.new("NodeReroute")
	    reroute_011_3.name = "Reroute.011"
	    reroute_011_3.socket_idname = "NodeSocketBool"
	    #node Reroute.012
	    reroute_012_4 = hair_shrinkwrap.nodes.new("NodeReroute")
	    reroute_012_4.name = "Reroute.012"
	    reroute_012_4.socket_idname = "NodeSocketVector"
	    #node Group.001
	    group_001_4 = hair_shrinkwrap.nodes.new("GeometryNodeGroup")
	    group_001_4.name = "Group.001"
	    group_001_4.hide = True
	    group_001_4.node_tree = curve_root
	    group_001_4.outputs[2].hide = True
	    group_001_4.outputs[3].hide = True
	
	
	
	
	    #Set parents
	    vector_math_4.parent = frame_5
	    vector_math_002_3.parent = frame_5
	    vector_math_003_3.parent = frame_5
	
	    #Set locations
	    group_input_5.location = (-340.0, 0.0)
	    group_output_9.location = (1026.4234619140625, -23.50284194946289)
	    object_info.location = (-125.76961517333984, -56.2663688659668)
	    geometry_proximity.location = (246.0714874267578, -85.30731201171875)
	    capture_attribute_3.location = (34.87336349487305, -33.59607696533203)
	    position_2.location = (32.304588317871094, 20.49018096923828)
	    set_position_3.location = (598.3317260742188, -37.141319274902344)
	    vector_math_4.location = (30.1131591796875, -35.27717590332031)
	    vector_math_001_4.location = (599.7997436523438, -80.27210998535156)
	    vector_math_002_3.location = (31.7452392578125, -69.64241027832031)
	    vector_math_003_3.location = (33.37713623046875, -104.00765991210938)
	    reroute_5.location = (198.13858032226562, -44.358219146728516)
	    reroute_001_5.location = (199.3470001220703, -194.38702392578125)
	    reroute_002_3.location = (198.45127868652344, -101.33867645263672)
	    reroute_003_3.location = (399.9706115722656, -85.22796630859375)
	    frame_5.location = (382.0, -153.0)
	    reroute_004_4.location = (-170.80995178222656, -77.34846496582031)
	    reroute_005_3.location = (-167.71401977539062, -278.49591064453125)
	    reroute_006_3.location = (402.7818908691406, -207.76275634765625)
	    reroute_007_3.location = (603.0008544921875, -266.2869567871094)
	    boolean_math_3.location = (598.4335327148438, 16.009042739868164)
	    set_position_001_3.location = (843.1641235351562, -48.994876861572266)
	    geometry_proximity_001.location = (840.4232177734375, -119.17461395263672)
	    reroute_008_3.location = (45.334922790527344, -84.02496337890625)
	    reroute_009_3.location = (45.33495330810547, -119.9047622680664)
	    reroute_010_2.location = (783.8638916015625, 46.56462478637695)
	    reroute_011_3.location = (839.1802978515625, 56.635406494140625)
	    reroute_012_4.location = (789.7108154296875, -135.4138641357422)
	    group_001_4.location = (595.2744750976562, 59.634674072265625)
	
	    #Set dimensions
	    group_input_5.width, group_input_5.height = 140.0, 100.0
	    group_output_9.width, group_output_9.height = 140.0, 100.0
	    object_info.width, object_info.height = 140.0, 100.0
	    geometry_proximity.width, geometry_proximity.height = 140.0, 100.0
	    capture_attribute_3.width, capture_attribute_3.height = 140.0, 100.0
	    position_2.width, position_2.height = 140.0, 100.0
	    set_position_3.width, set_position_3.height = 140.0, 100.0
	    vector_math_4.width, vector_math_4.height = 140.0, 100.0
	    vector_math_001_4.width, vector_math_001_4.height = 140.0, 100.0
	    vector_math_002_3.width, vector_math_002_3.height = 140.0, 100.0
	    vector_math_003_3.width, vector_math_003_3.height = 140.0, 100.0
	    reroute_5.width, reroute_5.height = 10.0, 100.0
	    reroute_001_5.width, reroute_001_5.height = 10.0, 100.0
	    reroute_002_3.width, reroute_002_3.height = 10.0, 100.0
	    reroute_003_3.width, reroute_003_3.height = 10.0, 100.0
	    frame_5.width, frame_5.height = 203.0, 159.0
	    reroute_004_4.width, reroute_004_4.height = 10.0, 100.0
	    reroute_005_3.width, reroute_005_3.height = 10.0, 100.0
	    reroute_006_3.width, reroute_006_3.height = 10.0, 100.0
	    reroute_007_3.width, reroute_007_3.height = 10.0, 100.0
	    boolean_math_3.width, boolean_math_3.height = 140.0, 100.0
	    set_position_001_3.width, set_position_001_3.height = 140.0, 100.0
	    geometry_proximity_001.width, geometry_proximity_001.height = 140.0, 100.0
	    reroute_008_3.width, reroute_008_3.height = 10.0, 100.0
	    reroute_009_3.width, reroute_009_3.height = 10.0, 100.0
	    reroute_010_2.width, reroute_010_2.height = 10.0, 100.0
	    reroute_011_3.width, reroute_011_3.height = 10.0, 100.0
	    reroute_012_4.width, reroute_012_4.height = 10.0, 100.0
	    group_001_4.width, group_001_4.height = 140.0, 100.0
	
	    #initialize hair_shrinkwrap links
	    #set_position_001_3.Geometry -> group_output_9.Geometry
	    hair_shrinkwrap.links.new(set_position_001_3.outputs[0], group_output_9.inputs[0])
	    #position_2.Position -> capture_attribute_3.Position
	    hair_shrinkwrap.links.new(position_2.outputs[0], capture_attribute_3.inputs[1])
	    #reroute_008_3.Output -> geometry_proximity.Geometry
	    hair_shrinkwrap.links.new(reroute_008_3.outputs[0], geometry_proximity.inputs[0])
	    #group_input_5.Geometry -> capture_attribute_3.Geometry
	    hair_shrinkwrap.links.new(group_input_5.outputs[0], capture_attribute_3.inputs[0])
	    #capture_attribute_3.Geometry -> set_position_3.Geometry
	    hair_shrinkwrap.links.new(capture_attribute_3.outputs[0], set_position_3.inputs[0])
	    #group_input_5.Surface -> object_info.Object
	    hair_shrinkwrap.links.new(group_input_5.outputs[1], object_info.inputs[0])
	    #reroute_001_5.Output -> vector_math_4.Vector
	    hair_shrinkwrap.links.new(reroute_001_5.outputs[0], vector_math_4.inputs[0])
	    #reroute_006_3.Output -> vector_math_4.Vector
	    hair_shrinkwrap.links.new(reroute_006_3.outputs[0], vector_math_4.inputs[1])
	    #reroute_003_3.Output -> vector_math_001_4.Vector
	    hair_shrinkwrap.links.new(reroute_003_3.outputs[0], vector_math_001_4.inputs[0])
	    #vector_math_4.Vector -> vector_math_002_3.Vector
	    hair_shrinkwrap.links.new(vector_math_4.outputs[0], vector_math_002_3.inputs[0])
	    #vector_math_002_3.Vector -> vector_math_003_3.Vector
	    hair_shrinkwrap.links.new(vector_math_002_3.outputs[0], vector_math_003_3.inputs[0])
	    #reroute_005_3.Output -> vector_math_003_3.Scale
	    hair_shrinkwrap.links.new(reroute_005_3.outputs[0], vector_math_003_3.inputs[3])
	    #reroute_007_3.Output -> vector_math_001_4.Vector
	    hair_shrinkwrap.links.new(reroute_007_3.outputs[0], vector_math_001_4.inputs[1])
	    #vector_math_001_4.Vector -> set_position_3.Position
	    hair_shrinkwrap.links.new(vector_math_001_4.outputs[0], set_position_3.inputs[2])
	    #capture_attribute_3.Position -> reroute_5.Input
	    hair_shrinkwrap.links.new(capture_attribute_3.outputs[1], reroute_5.inputs[0])
	    #reroute_002_3.Output -> reroute_001_5.Input
	    hair_shrinkwrap.links.new(reroute_002_3.outputs[0], reroute_001_5.inputs[0])
	    #reroute_5.Output -> reroute_002_3.Input
	    hair_shrinkwrap.links.new(reroute_5.outputs[0], reroute_002_3.inputs[0])
	    #reroute_002_3.Output -> geometry_proximity.Sample Position
	    hair_shrinkwrap.links.new(reroute_002_3.outputs[0], geometry_proximity.inputs[2])
	    #geometry_proximity.Position -> reroute_003_3.Input
	    hair_shrinkwrap.links.new(geometry_proximity.outputs[0], reroute_003_3.inputs[0])
	    #group_input_5.Offset -> reroute_004_4.Input
	    hair_shrinkwrap.links.new(group_input_5.outputs[2], reroute_004_4.inputs[0])
	    #reroute_004_4.Output -> reroute_005_3.Input
	    hair_shrinkwrap.links.new(reroute_004_4.outputs[0], reroute_005_3.inputs[0])
	    #reroute_003_3.Output -> reroute_006_3.Input
	    hair_shrinkwrap.links.new(reroute_003_3.outputs[0], reroute_006_3.inputs[0])
	    #vector_math_003_3.Vector -> reroute_007_3.Input
	    hair_shrinkwrap.links.new(vector_math_003_3.outputs[0], reroute_007_3.inputs[0])
	    #boolean_math_3.Boolean -> set_position_3.Selection
	    hair_shrinkwrap.links.new(boolean_math_3.outputs[0], set_position_3.inputs[1])
	    #set_position_3.Geometry -> set_position_001_3.Geometry
	    hair_shrinkwrap.links.new(set_position_3.outputs[0], set_position_001_3.inputs[0])
	    #reroute_009_3.Output -> geometry_proximity_001.Geometry
	    hair_shrinkwrap.links.new(reroute_009_3.outputs[0], geometry_proximity_001.inputs[0])
	    #reroute_012_4.Output -> geometry_proximity_001.Sample Position
	    hair_shrinkwrap.links.new(reroute_012_4.outputs[0], geometry_proximity_001.inputs[2])
	    #reroute_011_3.Output -> set_position_001_3.Selection
	    hair_shrinkwrap.links.new(reroute_011_3.outputs[0], set_position_001_3.inputs[1])
	    #geometry_proximity_001.Position -> set_position_001_3.Position
	    hair_shrinkwrap.links.new(geometry_proximity_001.outputs[0], set_position_001_3.inputs[2])
	    #object_info.Geometry -> reroute_008_3.Input
	    hair_shrinkwrap.links.new(object_info.outputs[4], reroute_008_3.inputs[0])
	    #reroute_008_3.Output -> reroute_009_3.Input
	    hair_shrinkwrap.links.new(reroute_008_3.outputs[0], reroute_009_3.inputs[0])
	    #reroute_010_2.Output -> reroute_012_4.Input
	    hair_shrinkwrap.links.new(reroute_010_2.outputs[0], reroute_012_4.inputs[0])
	    #group_001_4.Root Selection -> reroute_011_3.Input
	    hair_shrinkwrap.links.new(group_001_4.outputs[0], reroute_011_3.inputs[0])
	    #group_001_4.Root Position -> reroute_010_2.Input
	    hair_shrinkwrap.links.new(group_001_4.outputs[1], reroute_010_2.inputs[0])
	    #group_001_4.Root Selection -> boolean_math_3.Boolean
	    hair_shrinkwrap.links.new(group_001_4.outputs[0], boolean_math_3.inputs[0])
	    return hair_shrinkwrap
	
	hair_shrinkwrap = hair_shrinkwrap_node_group()
	
	#initialize mesh_geometry_priority node group
	def mesh_geometry_priority_node_group():
	    mesh_geometry_priority = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Mesh Geometry Priority")
	
	    mesh_geometry_priority.color_tag = 'NONE'
	    mesh_geometry_priority.description = ""
	    mesh_geometry_priority.default_group_node_width = 140
	    
	
	
	    #mesh_geometry_priority interface
	    #Socket Geometry
	    geometry_socket_8 = mesh_geometry_priority.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_8.attribute_domain = 'POINT'
	
	    #Socket Geometry
	    geometry_socket_9 = mesh_geometry_priority.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_9.attribute_domain = 'POINT'
	
	    #Socket Object
	    object_socket = mesh_geometry_priority.interface.new_socket(name = "Object", in_out='INPUT', socket_type = 'NodeSocketObject')
	    object_socket.attribute_domain = 'POINT'
	
	
	    #initialize mesh_geometry_priority nodes
	    #node Group Output
	    group_output_10 = mesh_geometry_priority.nodes.new("NodeGroupOutput")
	    group_output_10.name = "Group Output"
	    group_output_10.is_active_output = True
	
	    #node Group Input
	    group_input_6 = mesh_geometry_priority.nodes.new("NodeGroupInput")
	    group_input_6.name = "Group Input"
	
	    #node Object Info
	    object_info_1 = mesh_geometry_priority.nodes.new("GeometryNodeObjectInfo")
	    object_info_1.name = "Object Info"
	    object_info_1.hide = True
	    object_info_1.transform_space = 'RELATIVE'
	    object_info_1.inputs[1].hide = True
	    object_info_1.outputs[0].hide = True
	    object_info_1.outputs[1].hide = True
	    object_info_1.outputs[2].hide = True
	    object_info_1.outputs[3].hide = True
	    #As Instance
	    object_info_1.inputs[1].default_value = False
	
	    #node Switch.001
	    switch_001_6 = mesh_geometry_priority.nodes.new("GeometryNodeSwitch")
	    switch_001_6.name = "Switch.001"
	    switch_001_6.hide = True
	    switch_001_6.input_type = 'GEOMETRY'
	
	    #node Domain Size
	    domain_size_1 = mesh_geometry_priority.nodes.new("GeometryNodeAttributeDomainSize")
	    domain_size_1.name = "Domain Size"
	    domain_size_1.hide = True
	    domain_size_1.component = 'MESH'
	    domain_size_1.outputs[1].hide = True
	    domain_size_1.outputs[2].hide = True
	    domain_size_1.outputs[3].hide = True
	    domain_size_1.outputs[4].hide = True
	    domain_size_1.outputs[5].hide = True
	    domain_size_1.outputs[6].hide = True
	
	    #node Compare.002
	    compare_002_3 = mesh_geometry_priority.nodes.new("FunctionNodeCompare")
	    compare_002_3.name = "Compare.002"
	    compare_002_3.hide = True
	    compare_002_3.data_type = 'FLOAT'
	    compare_002_3.mode = 'ELEMENT'
	    compare_002_3.operation = 'EQUAL'
	    #B
	    compare_002_3.inputs[1].default_value = 0.0
	    #Epsilon
	    compare_002_3.inputs[12].default_value = 0.0
	
	    #node Reroute
	    reroute_6 = mesh_geometry_priority.nodes.new("NodeReroute")
	    reroute_6.name = "Reroute"
	    reroute_6.socket_idname = "NodeSocketGeometry"
	
	
	
	
	    #Set locations
	    group_output_10.location = (331.4979553222656, 0.0)
	    group_input_6.location = (-341.49798583984375, 0.0)
	    object_info_1.location = (-141.49798583984375, -48.543128967285156)
	    switch_001_6.location = (141.49795532226562, -25.427536010742188)
	    domain_size_1.location = (-37.58526611328125, 25.427532196044922)
	    compare_002_3.location = (138.00750732421875, 13.003349304199219)
	    reroute_6.location = (-98.26019287109375, -34.39356231689453)
	
	    #Set dimensions
	    group_output_10.width, group_output_10.height = 140.0, 100.0
	    group_input_6.width, group_input_6.height = 140.0, 100.0
	    object_info_1.width, object_info_1.height = 140.0, 100.0
	    switch_001_6.width, switch_001_6.height = 140.0, 100.0
	    domain_size_1.width, domain_size_1.height = 140.0, 100.0
	    compare_002_3.width, compare_002_3.height = 140.0, 100.0
	    reroute_6.width, reroute_6.height = 100.0, 100.0
	
	    #initialize mesh_geometry_priority links
	    #reroute_6.Output -> domain_size_1.Geometry
	    mesh_geometry_priority.links.new(reroute_6.outputs[0], domain_size_1.inputs[0])
	    #domain_size_1.Point Count -> compare_002_3.A
	    mesh_geometry_priority.links.new(domain_size_1.outputs[0], compare_002_3.inputs[0])
	    #compare_002_3.Result -> switch_001_6.Switch
	    mesh_geometry_priority.links.new(compare_002_3.outputs[0], switch_001_6.inputs[0])
	    #object_info_1.Geometry -> switch_001_6.True
	    mesh_geometry_priority.links.new(object_info_1.outputs[4], switch_001_6.inputs[2])
	    #reroute_6.Output -> switch_001_6.False
	    mesh_geometry_priority.links.new(reroute_6.outputs[0], switch_001_6.inputs[1])
	    #group_input_6.Object -> object_info_1.Object
	    mesh_geometry_priority.links.new(group_input_6.outputs[1], object_info_1.inputs[0])
	    #group_input_6.Geometry -> reroute_6.Input
	    mesh_geometry_priority.links.new(group_input_6.outputs[0], reroute_6.inputs[0])
	    #switch_001_6.Output -> group_output_10.Geometry
	    mesh_geometry_priority.links.new(switch_001_6.outputs[0], group_output_10.inputs[0])
	    return mesh_geometry_priority
	
	mesh_geometry_priority = mesh_geometry_priority_node_group()
	
	#initialize align_curve_to_surface node group
	def align_curve_to_surface_node_group():
	    align_curve_to_surface = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Align_Curve_to_Surface")
	
	    align_curve_to_surface.color_tag = 'NONE'
	    align_curve_to_surface.description = ""
	    align_curve_to_surface.default_group_node_width = 140
	    
	
	
	    #align_curve_to_surface interface
	    #Socket Geometry
	    geometry_socket_10 = align_curve_to_surface.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_10.attribute_domain = 'POINT'
	
	    #Socket Tilt
	    tilt_socket = align_curve_to_surface.interface.new_socket(name = "Tilt", in_out='OUTPUT', socket_type = 'NodeSocketFloat')
	    tilt_socket.default_value = 0.0
	    tilt_socket.min_value = -3.4028234663852886e+38
	    tilt_socket.max_value = 3.4028234663852886e+38
	    tilt_socket.subtype = 'NONE'
	    tilt_socket.attribute_domain = 'POINT'
	
	    #Socket Geometry
	    geometry_socket_11 = align_curve_to_surface.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_11.attribute_domain = 'POINT'
	
	    #Socket Surface
	    surface_socket_1 = align_curve_to_surface.interface.new_socket(name = "Surface", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    surface_socket_1.attribute_domain = 'POINT'
	
	    #Socket Surface
	    surface_socket_2 = align_curve_to_surface.interface.new_socket(name = "Surface", in_out='INPUT', socket_type = 'NodeSocketObject')
	    surface_socket_2.attribute_domain = 'POINT'
	
	    #Socket Surface Align Factor
	    surface_align_factor_socket = align_curve_to_surface.interface.new_socket(name = "Surface Align Factor", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    surface_align_factor_socket.default_value = 1.0
	    surface_align_factor_socket.min_value = 0.0
	    surface_align_factor_socket.max_value = 1.0
	    surface_align_factor_socket.subtype = 'FACTOR'
	    surface_align_factor_socket.attribute_domain = 'POINT'
	
	
	    #initialize align_curve_to_surface nodes
	    #node Group Output
	    group_output_11 = align_curve_to_surface.nodes.new("NodeGroupOutput")
	    group_output_11.name = "Group Output"
	    group_output_11.is_active_output = True
	    group_output_11.inputs[2].hide = True
	
	    #node Group Input
	    group_input_7 = align_curve_to_surface.nodes.new("NodeGroupInput")
	    group_input_7.name = "Group Input"
	    group_input_7.outputs[3].hide = True
	    group_input_7.outputs[4].hide = True
	
	    #node Capture Attribute.004
	    capture_attribute_004_1 = align_curve_to_surface.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_004_1.name = "Capture Attribute.004"
	    capture_attribute_004_1.active_index = 2
	    capture_attribute_004_1.capture_items.clear()
	    capture_attribute_004_1.capture_items.new('FLOAT', "Normal")
	    capture_attribute_004_1.capture_items["Normal"].data_type = 'FLOAT_VECTOR'
	    capture_attribute_004_1.capture_items.new('FLOAT', "Tangent")
	    capture_attribute_004_1.capture_items["Tangent"].data_type = 'FLOAT_VECTOR'
	    capture_attribute_004_1.capture_items.new('FLOAT', "Position")
	    capture_attribute_004_1.capture_items["Position"].data_type = 'FLOAT_VECTOR'
	    capture_attribute_004_1.domain = 'POINT'
	    capture_attribute_004_1.inputs[4].hide = True
	    capture_attribute_004_1.outputs[4].hide = True
	
	    #node Normal.005
	    normal_005 = align_curve_to_surface.nodes.new("GeometryNodeInputNormal")
	    normal_005.name = "Normal.005"
	    normal_005.hide = True
	    normal_005.legacy_corner_normals = True
	
	    #node Curve Tangent.002
	    curve_tangent_002 = align_curve_to_surface.nodes.new("GeometryNodeInputTangent")
	    curve_tangent_002.name = "Curve Tangent.002"
	    curve_tangent_002.hide = True
	
	    #node Vector Math.004
	    vector_math_004_4 = align_curve_to_surface.nodes.new("ShaderNodeVectorMath")
	    vector_math_004_4.name = "Vector Math.004"
	    vector_math_004_4.hide = True
	    vector_math_004_4.operation = 'CROSS_PRODUCT'
	
	    #node Vector Math.007
	    vector_math_007_3 = align_curve_to_surface.nodes.new("ShaderNodeVectorMath")
	    vector_math_007_3.name = "Vector Math.007"
	    vector_math_007_3.hide = True
	    vector_math_007_3.operation = 'DOT_PRODUCT'
	
	    #node Sample Nearest.003
	    sample_nearest_003 = align_curve_to_surface.nodes.new("GeometryNodeSampleNearest")
	    sample_nearest_003.name = "Sample Nearest.003"
	    sample_nearest_003.hide = True
	    sample_nearest_003.domain = 'POINT'
	
	    #node Sample Index.003
	    sample_index_003_1 = align_curve_to_surface.nodes.new("GeometryNodeSampleIndex")
	    sample_index_003_1.name = "Sample Index.003"
	    sample_index_003_1.hide = True
	    sample_index_003_1.clamp = False
	    sample_index_003_1.data_type = 'FLOAT_VECTOR'
	    sample_index_003_1.domain = 'POINT'
	
	    #node Normal.006
	    normal_006 = align_curve_to_surface.nodes.new("GeometryNodeInputNormal")
	    normal_006.name = "Normal.006"
	    normal_006.legacy_corner_normals = True
	
	    #node Position.004
	    position_004 = align_curve_to_surface.nodes.new("GeometryNodeInputPosition")
	    position_004.name = "Position.004"
	    position_004.hide = True
	
	    #node Frame.007
	    frame_007_2 = align_curve_to_surface.nodes.new("NodeFrame")
	    frame_007_2.name = "Frame.007"
	    frame_007_2.label_size = 20
	    frame_007_2.shrink = True
	
	    #node Math.008
	    math_008 = align_curve_to_surface.nodes.new("ShaderNodeMath")
	    math_008.name = "Math.008"
	    math_008.hide = True
	    math_008.operation = 'ARCTAN2'
	    math_008.use_clamp = False
	
	    #node Vector Math.008
	    vector_math_008_3 = align_curve_to_surface.nodes.new("ShaderNodeVectorMath")
	    vector_math_008_3.name = "Vector Math.008"
	    vector_math_008_3.hide = True
	    vector_math_008_3.operation = 'DOT_PRODUCT'
	
	    #node Math.009
	    math_009_1 = align_curve_to_surface.nodes.new("ShaderNodeMath")
	    math_009_1.name = "Math.009"
	    math_009_1.hide = True
	    math_009_1.operation = 'ADD'
	    math_009_1.use_clamp = False
	    #Value_001
	    math_009_1.inputs[1].default_value = 90.0
	
	    #node Frame.006
	    frame_006_2 = align_curve_to_surface.nodes.new("NodeFrame")
	    frame_006_2.name = "Frame.006"
	    frame_006_2.label_size = 20
	    frame_006_2.shrink = True
	
	    #node Reroute
	    reroute_7 = align_curve_to_surface.nodes.new("NodeReroute")
	    reroute_7.name = "Reroute"
	    reroute_7.socket_idname = "NodeSocketGeometry"
	    #node Group
	    group_2 = align_curve_to_surface.nodes.new("GeometryNodeGroup")
	    group_2.name = "Group"
	    group_2.hide = True
	    group_2.node_tree = mesh_geometry_priority
	
	    #node Map Range
	    map_range_1 = align_curve_to_surface.nodes.new("ShaderNodeMapRange")
	    map_range_1.name = "Map Range"
	    map_range_1.hide = True
	    map_range_1.clamp = False
	    map_range_1.data_type = 'FLOAT'
	    map_range_1.interpolation_type = 'LINEAR'
	    map_range_1.inputs[1].hide = True
	    map_range_1.inputs[2].hide = True
	    map_range_1.inputs[3].hide = True
	    map_range_1.inputs[5].hide = True
	    map_range_1.inputs[6].hide = True
	    map_range_1.inputs[7].hide = True
	    map_range_1.inputs[8].hide = True
	    map_range_1.inputs[9].hide = True
	    map_range_1.inputs[10].hide = True
	    map_range_1.inputs[11].hide = True
	    map_range_1.outputs[1].hide = True
	    #From Min
	    map_range_1.inputs[1].default_value = 0.0
	    #From Max
	    map_range_1.inputs[2].default_value = 1.0
	    #To Min
	    map_range_1.inputs[3].default_value = 0.0
	
	    #node Group Input.001
	    group_input_001_4 = align_curve_to_surface.nodes.new("NodeGroupInput")
	    group_input_001_4.name = "Group Input.001"
	    group_input_001_4.outputs[0].hide = True
	    group_input_001_4.outputs[1].hide = True
	    group_input_001_4.outputs[2].hide = True
	    group_input_001_4.outputs[4].hide = True
	
	
	
	
	    #Set parents
	    vector_math_004_4.parent = frame_007_2
	    vector_math_007_3.parent = frame_007_2
	    math_008.parent = frame_006_2
	    vector_math_008_3.parent = frame_006_2
	    math_009_1.parent = frame_006_2
	
	    #Set locations
	    group_output_11.location = (697.721435546875, 165.50466918945312)
	    group_input_7.location = (-531.6859130859375, 0.0)
	    capture_attribute_004_1.location = (-331.6859130859375, 193.2864990234375)
	    normal_005.location = (-331.6859130859375, 46.861083984375)
	    curve_tangent_002.location = (-331.6859130859375, 10.7730712890625)
	    vector_math_004_4.location = (29.613037109375, -35.04705810546875)
	    vector_math_007_3.location = (30.90576171875, -73.6961669921875)
	    sample_nearest_003.location = (-133.015869140625, -107.3826904296875)
	    sample_index_003_1.location = (-133.1280517578125, -156.7822265625)
	    normal_006.location = (-130.652099609375, -193.28662109375)
	    position_004.location = (-327.815673828125, -24.2001953125)
	    frame_007_2.location = (65.0, -72.0)
	    math_008.location = (32.670166015625, -69.58648681640625)
	    vector_math_008_3.location = (36.68603515625, -105.55633544921875)
	    math_009_1.location = (30.263671875, -34.89862060546875)
	    frame_006_2.location = (295.0, -77.0)
	    reroute_7.location = (-170.5524139404297, -136.1621856689453)
	    group_2.location = (-324.8177185058594, -125.7967529296875)
	    map_range_1.location = (559.6337280273438, -103.24618530273438)
	    group_input_001_4.location = (557.1717529296875, -43.553863525390625)
	
	    #Set dimensions
	    group_output_11.width, group_output_11.height = 140.0, 100.0
	    group_input_7.width, group_input_7.height = 140.0, 100.0
	    capture_attribute_004_1.width, capture_attribute_004_1.height = 140.0, 100.0
	    normal_005.width, normal_005.height = 140.0, 100.0
	    curve_tangent_002.width, curve_tangent_002.height = 140.0, 100.0
	    vector_math_004_4.width, vector_math_004_4.height = 140.0, 100.0
	    vector_math_007_3.width, vector_math_007_3.height = 140.0, 100.0
	    sample_nearest_003.width, sample_nearest_003.height = 140.0, 100.0
	    sample_index_003_1.width, sample_index_003_1.height = 140.0, 100.0
	    normal_006.width, normal_006.height = 140.0, 100.0
	    position_004.width, position_004.height = 140.0, 100.0
	    frame_007_2.width, frame_007_2.height = 201.0, 129.0
	    math_008.width, math_008.height = 140.0, 100.0
	    vector_math_008_3.width, vector_math_008_3.height = 140.0, 100.0
	    math_009_1.width, math_009_1.height = 140.0, 100.0
	    frame_006_2.width, frame_006_2.height = 207.0, 161.0
	    reroute_7.width, reroute_7.height = 100.0, 100.0
	    group_2.width, group_2.height = 140.0, 100.0
	    map_range_1.width, map_range_1.height = 140.0, 100.0
	    group_input_001_4.width, group_input_001_4.height = 140.0, 100.0
	
	    #initialize align_curve_to_surface links
	    #curve_tangent_002.Tangent -> capture_attribute_004_1.Tangent
	    align_curve_to_surface.links.new(curve_tangent_002.outputs[0], capture_attribute_004_1.inputs[2])
	    #position_004.Position -> capture_attribute_004_1.Position
	    align_curve_to_surface.links.new(position_004.outputs[0], capture_attribute_004_1.inputs[3])
	    #math_008.Value -> math_009_1.Value
	    align_curve_to_surface.links.new(math_008.outputs[0], math_009_1.inputs[0])
	    #normal_005.Normal -> capture_attribute_004_1.Normal
	    align_curve_to_surface.links.new(normal_005.outputs[0], capture_attribute_004_1.inputs[1])
	    #capture_attribute_004_1.Position -> sample_nearest_003.Sample Position
	    align_curve_to_surface.links.new(capture_attribute_004_1.outputs[3], sample_nearest_003.inputs[1])
	    #reroute_7.Output -> sample_nearest_003.Geometry
	    align_curve_to_surface.links.new(reroute_7.outputs[0], sample_nearest_003.inputs[0])
	    #sample_index_003_1.Value -> vector_math_007_3.Vector
	    align_curve_to_surface.links.new(sample_index_003_1.outputs[0], vector_math_007_3.inputs[1])
	    #vector_math_008_3.Value -> math_008.Value
	    align_curve_to_surface.links.new(vector_math_008_3.outputs[1], math_008.inputs[1])
	    #capture_attribute_004_1.Tangent -> vector_math_004_4.Vector
	    align_curve_to_surface.links.new(capture_attribute_004_1.outputs[2], vector_math_004_4.inputs[0])
	    #normal_006.Normal -> sample_index_003_1.Value
	    align_curve_to_surface.links.new(normal_006.outputs[0], sample_index_003_1.inputs[1])
	    #vector_math_004_4.Vector -> vector_math_007_3.Vector
	    align_curve_to_surface.links.new(vector_math_004_4.outputs[0], vector_math_007_3.inputs[0])
	    #vector_math_007_3.Value -> math_008.Value
	    align_curve_to_surface.links.new(vector_math_007_3.outputs[1], math_008.inputs[0])
	    #reroute_7.Output -> sample_index_003_1.Geometry
	    align_curve_to_surface.links.new(reroute_7.outputs[0], sample_index_003_1.inputs[0])
	    #sample_nearest_003.Index -> sample_index_003_1.Index
	    align_curve_to_surface.links.new(sample_nearest_003.outputs[0], sample_index_003_1.inputs[2])
	    #capture_attribute_004_1.Normal -> vector_math_004_4.Vector
	    align_curve_to_surface.links.new(capture_attribute_004_1.outputs[1], vector_math_004_4.inputs[1])
	    #capture_attribute_004_1.Normal -> vector_math_008_3.Vector
	    align_curve_to_surface.links.new(capture_attribute_004_1.outputs[1], vector_math_008_3.inputs[0])
	    #sample_index_003_1.Value -> vector_math_008_3.Vector
	    align_curve_to_surface.links.new(sample_index_003_1.outputs[0], vector_math_008_3.inputs[1])
	    #group_input_7.Geometry -> capture_attribute_004_1.Geometry
	    align_curve_to_surface.links.new(group_input_7.outputs[0], capture_attribute_004_1.inputs[0])
	    #capture_attribute_004_1.Geometry -> group_output_11.Geometry
	    align_curve_to_surface.links.new(capture_attribute_004_1.outputs[0], group_output_11.inputs[0])
	    #group_input_7.Surface -> group_2.Object
	    align_curve_to_surface.links.new(group_input_7.outputs[2], group_2.inputs[1])
	    #group_input_7.Surface -> group_2.Geometry
	    align_curve_to_surface.links.new(group_input_7.outputs[1], group_2.inputs[0])
	    #group_2.Geometry -> reroute_7.Input
	    align_curve_to_surface.links.new(group_2.outputs[0], reroute_7.inputs[0])
	    #group_input_001_4.Surface Align Factor -> map_range_1.Value
	    align_curve_to_surface.links.new(group_input_001_4.outputs[3], map_range_1.inputs[0])
	    #math_009_1.Value -> map_range_1.To Max
	    align_curve_to_surface.links.new(math_009_1.outputs[0], map_range_1.inputs[4])
	    #map_range_1.Result -> group_output_11.Tilt
	    align_curve_to_surface.links.new(map_range_1.outputs[0], group_output_11.inputs[1])
	    return align_curve_to_surface
	
	align_curve_to_surface = align_curve_to_surface_node_group()
	
	#initialize hair_curve_strip node group
	def hair_curve_strip_node_group():
	    hair_curve_strip = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "HAIR CURVE STRIP")
	
	    hair_curve_strip.color_tag = 'NONE'
	    hair_curve_strip.description = ""
	    hair_curve_strip.default_group_node_width = 140
	    
	
	    hair_curve_strip.is_modifier = True
	
	    #hair_curve_strip interface
	    #Socket Geometry
	    geometry_socket_12 = hair_curve_strip.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_12.attribute_domain = 'POINT'
	
	    #Socket Curve
	    curve_socket = hair_curve_strip.interface.new_socket(name = "Curve", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    curve_socket.attribute_domain = 'POINT'
	
	    #Socket Surface
	    surface_socket_3 = hair_curve_strip.interface.new_socket(name = "Surface", in_out='INPUT', socket_type = 'NodeSocketObject')
	    surface_socket_3.attribute_domain = 'POINT'
	
	    #Socket Length
	    length_socket_1 = hair_curve_strip.interface.new_socket(name = "Length", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    length_socket_1.default_value = 1.0
	    length_socket_1.min_value = 0.0
	    length_socket_1.max_value = 3.4028234663852886e+38
	    length_socket_1.subtype = 'DISTANCE'
	    length_socket_1.attribute_domain = 'POINT'
	
	    #Socket Count
	    count_socket = hair_curve_strip.interface.new_socket(name = "Count", in_out='INPUT', socket_type = 'NodeSocketInt')
	    count_socket.default_value = 10
	    count_socket.min_value = 0
	    count_socket.max_value = 100000
	    count_socket.subtype = 'NONE'
	    count_socket.attribute_domain = 'POINT'
	
	    #Socket Rotation Factor
	    rotation_factor_socket = hair_curve_strip.interface.new_socket(name = "Rotation Factor", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    rotation_factor_socket.default_value = 0.0
	    rotation_factor_socket.min_value = 0.0
	    rotation_factor_socket.max_value = 1.0
	    rotation_factor_socket.subtype = 'FACTOR'
	    rotation_factor_socket.attribute_domain = 'POINT'
	
	    #Socket Surface Align Factor
	    surface_align_factor_socket_1 = hair_curve_strip.interface.new_socket(name = "Surface Align Factor", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    surface_align_factor_socket_1.default_value = 1.0
	    surface_align_factor_socket_1.min_value = 0.0
	    surface_align_factor_socket_1.max_value = 1.0
	    surface_align_factor_socket_1.subtype = 'FACTOR'
	    surface_align_factor_socket_1.attribute_domain = 'POINT'
	
	
	    #initialize hair_curve_strip nodes
	    #node Group Output
	    group_output_12 = hair_curve_strip.nodes.new("NodeGroupOutput")
	    group_output_12.name = "Group Output"
	    group_output_12.is_active_output = True
	
	    #node Group Input
	    group_input_8 = hair_curve_strip.nodes.new("NodeGroupInput")
	    group_input_8.name = "Group Input"
	    group_input_8.outputs[2].hide = True
	    group_input_8.outputs[3].hide = True
	    group_input_8.outputs[4].hide = True
	    group_input_8.outputs[6].hide = True
	
	    #node Curve Line
	    curve_line = hair_curve_strip.nodes.new("GeometryNodeCurvePrimitiveLine")
	    curve_line.name = "Curve Line"
	    curve_line.hide = True
	    curve_line.mode = 'DIRECTION'
	    #Start
	    curve_line.inputs[0].default_value = (0.0, 0.0, 0.0)
	
	    #node Curve to Points
	    curve_to_points_1 = hair_curve_strip.nodes.new("GeometryNodeCurveToPoints")
	    curve_to_points_1.name = "Curve to Points"
	    curve_to_points_1.hide = True
	    curve_to_points_1.mode = 'COUNT'
	
	    #node Sample Curve.003
	    sample_curve_003 = hair_curve_strip.nodes.new("GeometryNodeSampleCurve")
	    sample_curve_003.name = "Sample Curve.003"
	    sample_curve_003.hide = True
	    sample_curve_003.data_type = 'FLOAT'
	    sample_curve_003.mode = 'FACTOR'
	    sample_curve_003.use_all_curves = False
	    #Value
	    sample_curve_003.inputs[1].default_value = 0.0
	    #Factor
	    sample_curve_003.inputs[2].default_value = 0.0
	    #Curve Index
	    sample_curve_003.inputs[4].default_value = 0
	
	    #node Instance on Points.001
	    instance_on_points_001 = hair_curve_strip.nodes.new("GeometryNodeInstanceOnPoints")
	    instance_on_points_001.name = "Instance on Points.001"
	    instance_on_points_001.hide = True
	    instance_on_points_001.inputs[1].hide = True
	    instance_on_points_001.inputs[3].hide = True
	    instance_on_points_001.inputs[4].hide = True
	    instance_on_points_001.inputs[6].hide = True
	    #Selection
	    instance_on_points_001.inputs[1].default_value = True
	    #Pick Instance
	    instance_on_points_001.inputs[3].default_value = False
	    #Instance Index
	    instance_on_points_001.inputs[4].default_value = 0
	    #Scale
	    instance_on_points_001.inputs[6].default_value = (1.0, 1.0, 1.0)
	
	    #node Align Rotation to Vector
	    align_rotation_to_vector = hair_curve_strip.nodes.new("FunctionNodeAlignRotationToVector")
	    align_rotation_to_vector.name = "Align Rotation to Vector"
	    align_rotation_to_vector.hide = True
	    align_rotation_to_vector.axis = 'Z'
	    align_rotation_to_vector.pivot_axis = 'AUTO'
	
	    #node Vector Math
	    vector_math_5 = hair_curve_strip.nodes.new("ShaderNodeVectorMath")
	    vector_math_5.name = "Vector Math"
	    vector_math_5.hide = True
	    vector_math_5.operation = 'SCALE'
	    #Scale
	    vector_math_5.inputs[3].default_value = -1.0
	
	    #node Switch
	    switch_5 = hair_curve_strip.nodes.new("GeometryNodeSwitch")
	    switch_5.name = "Switch"
	    switch_5.hide = True
	    switch_5.input_type = 'ROTATION'
	    #True
	    switch_5.inputs[2].default_value = (0.0, 0.0, 0.0)
	
	    #node Group Input.002
	    group_input_002_3 = hair_curve_strip.nodes.new("NodeGroupInput")
	    group_input_002_3.name = "Group Input.002"
	    group_input_002_3.outputs[0].hide = True
	    group_input_002_3.outputs[1].hide = True
	    group_input_002_3.outputs[3].hide = True
	    group_input_002_3.outputs[4].hide = True
	    group_input_002_3.outputs[5].hide = True
	    group_input_002_3.outputs[6].hide = True
	
	    #node Group Input.003
	    group_input_003_4 = hair_curve_strip.nodes.new("NodeGroupInput")
	    group_input_003_4.name = "Group Input.003"
	    group_input_003_4.outputs[0].hide = True
	    group_input_003_4.outputs[1].hide = True
	    group_input_003_4.outputs[2].hide = True
	    group_input_003_4.outputs[3].hide = True
	    group_input_003_4.outputs[5].hide = True
	    group_input_003_4.outputs[6].hide = True
	
	    #node Group Input.004
	    group_input_004_3 = hair_curve_strip.nodes.new("NodeGroupInput")
	    group_input_004_3.name = "Group Input.004"
	    group_input_004_3.outputs[0].hide = True
	    group_input_004_3.outputs[1].hide = True
	    group_input_004_3.outputs[2].hide = True
	    group_input_004_3.outputs[4].hide = True
	    group_input_004_3.outputs[5].hide = True
	    group_input_004_3.outputs[6].hide = True
	
	    #node Reroute
	    reroute_8 = hair_curve_strip.nodes.new("NodeReroute")
	    reroute_8.name = "Reroute"
	    reroute_8.socket_idname = "NodeSocketGeometry"
	    #node Reroute.001
	    reroute_001_6 = hair_curve_strip.nodes.new("NodeReroute")
	    reroute_001_6.name = "Reroute.001"
	    reroute_001_6.socket_idname = "NodeSocketGeometry"
	    #node Reroute.002
	    reroute_002_4 = hair_curve_strip.nodes.new("NodeReroute")
	    reroute_002_4.name = "Reroute.002"
	    reroute_002_4.socket_idname = "NodeSocketGeometry"
	    #node Reroute.003
	    reroute_003_4 = hair_curve_strip.nodes.new("NodeReroute")
	    reroute_003_4.name = "Reroute.003"
	    reroute_003_4.socket_idname = "NodeSocketGeometry"
	    #node Reroute.004
	    reroute_004_5 = hair_curve_strip.nodes.new("NodeReroute")
	    reroute_004_5.name = "Reroute.004"
	    reroute_004_5.socket_idname = "NodeSocketGeometry"
	    #node Realize Instances
	    realize_instances = hair_curve_strip.nodes.new("GeometryNodeRealizeInstances")
	    realize_instances.name = "Realize Instances"
	    realize_instances.hide = True
	    #Selection
	    realize_instances.inputs[1].default_value = True
	    #Realize All
	    realize_instances.inputs[2].default_value = True
	    #Depth
	    realize_instances.inputs[3].default_value = 0
	
	    #node Compare
	    compare_4 = hair_curve_strip.nodes.new("FunctionNodeCompare")
	    compare_4.name = "Compare"
	    compare_4.hide = True
	    compare_4.data_type = 'FLOAT'
	    compare_4.mode = 'ELEMENT'
	    compare_4.operation = 'EQUAL'
	    #B
	    compare_4.inputs[1].default_value = 0.0
	    #Epsilon
	    compare_4.inputs[12].default_value = 0.0
	
	    #node Reroute.005
	    reroute_005_4 = hair_curve_strip.nodes.new("NodeReroute")
	    reroute_005_4.name = "Reroute.005"
	    reroute_005_4.socket_idname = "NodeSocketFloatFactor"
	    #node Group
	    group_3 = hair_curve_strip.nodes.new("GeometryNodeGroup")
	    group_3.name = "Group"
	    group_3.node_tree = align_curve_to_surface
	    group_3.inputs[1].hide = True
	
	    #node Set Curve Tilt
	    set_curve_tilt = hair_curve_strip.nodes.new("GeometryNodeSetCurveTilt")
	    set_curve_tilt.name = "Set Curve Tilt"
	    set_curve_tilt.inputs[1].hide = True
	    #Selection
	    set_curve_tilt.inputs[1].default_value = True
	
	
	
	
	
	    #Set locations
	    group_output_12.location = (743.4810791015625, 147.91737365722656)
	    group_input_8.location = (-612.6851196289062, -22.58694076538086)
	    curve_line.location = (194.23831176757812, -50.249080657958984)
	    curve_to_points_1.location = (-27.80976104736328, 134.21023559570312)
	    sample_curve_003.location = (-23.507253646850586, -39.277034759521484)
	    instance_on_points_001.location = (404.9884033203125, 133.65586853027344)
	    align_rotation_to_vector.location = (185.803466796875, 79.73634338378906)
	    vector_math_5.location = (185.71070861816406, 113.6890640258789)
	    switch_5.location = (408.90802001953125, 96.9107437133789)
	    group_input_002_3.location = (187.04635620117188, -81.6124267578125)
	    group_input_003_4.location = (-32.528804779052734, 41.98052978515625)
	    group_input_004_3.location = (-34.48928451538086, 100.83431243896484)
	    reroute_8.location = (-77.29409790039062, 35.08960723876953)
	    reroute_001_6.location = (-79.17546081542969, 131.93484497070312)
	    reroute_002_4.location = (-75.4971694946289, -36.9482307434082)
	    reroute_003_4.location = (368.8102111816406, 124.42196655273438)
	    reroute_004_5.location = (370.10211181640625, -60.56672668457031)
	    realize_instances.location = (571.6881103515625, 122.28421783447266)
	    compare_4.location = (175.94508361816406, 42.58403778076172)
	    reroute_005_4.location = (125.19293212890625, 8.107183456420898)
	    group_3.location = (-446.2073059082031, 44.95358657836914)
	    set_curve_tilt.location = (-265.7646789550781, 69.27800750732422)
	
	    #Set dimensions
	    group_output_12.width, group_output_12.height = 140.0, 100.0
	    group_input_8.width, group_input_8.height = 140.0, 100.0
	    curve_line.width, curve_line.height = 140.0, 100.0
	    curve_to_points_1.width, curve_to_points_1.height = 140.0, 100.0
	    sample_curve_003.width, sample_curve_003.height = 140.0, 100.0
	    instance_on_points_001.width, instance_on_points_001.height = 140.0, 100.0
	    align_rotation_to_vector.width, align_rotation_to_vector.height = 140.0, 100.0
	    vector_math_5.width, vector_math_5.height = 140.0, 100.0
	    switch_5.width, switch_5.height = 140.0, 100.0
	    group_input_002_3.width, group_input_002_3.height = 140.0, 100.0
	    group_input_003_4.width, group_input_003_4.height = 140.0, 100.0
	    group_input_004_3.width, group_input_004_3.height = 140.0, 100.0
	    reroute_8.width, reroute_8.height = 100.0, 100.0
	    reroute_001_6.width, reroute_001_6.height = 100.0, 100.0
	    reroute_002_4.width, reroute_002_4.height = 100.0, 100.0
	    reroute_003_4.width, reroute_003_4.height = 100.0, 100.0
	    reroute_004_5.width, reroute_004_5.height = 100.0, 100.0
	    realize_instances.width, realize_instances.height = 140.0, 100.0
	    compare_4.width, compare_4.height = 140.0, 100.0
	    reroute_005_4.width, reroute_005_4.height = 100.0, 100.0
	    group_3.width, group_3.height = 140.0, 100.0
	    set_curve_tilt.width, set_curve_tilt.height = 140.0, 100.0
	
	    #initialize hair_curve_strip links
	    #reroute_001_6.Output -> curve_to_points_1.Curve
	    hair_curve_strip.links.new(reroute_001_6.outputs[0], curve_to_points_1.inputs[0])
	    #sample_curve_003.Normal -> curve_line.Direction
	    hair_curve_strip.links.new(sample_curve_003.outputs[3], curve_line.inputs[2])
	    #curve_to_points_1.Points -> instance_on_points_001.Points
	    hair_curve_strip.links.new(curve_to_points_1.outputs[0], instance_on_points_001.inputs[0])
	    #reroute_003_4.Output -> instance_on_points_001.Instance
	    hair_curve_strip.links.new(reroute_003_4.outputs[0], instance_on_points_001.inputs[2])
	    #reroute_002_4.Output -> sample_curve_003.Curves
	    hair_curve_strip.links.new(reroute_002_4.outputs[0], sample_curve_003.inputs[0])
	    #realize_instances.Geometry -> group_output_12.Geometry
	    hair_curve_strip.links.new(realize_instances.outputs[0], group_output_12.inputs[0])
	    #curve_to_points_1.Rotation -> align_rotation_to_vector.Rotation
	    hair_curve_strip.links.new(curve_to_points_1.outputs[3], align_rotation_to_vector.inputs[0])
	    #vector_math_5.Vector -> align_rotation_to_vector.Vector
	    hair_curve_strip.links.new(vector_math_5.outputs[0], align_rotation_to_vector.inputs[2])
	    #curve_to_points_1.Normal -> vector_math_5.Vector
	    hair_curve_strip.links.new(curve_to_points_1.outputs[2], vector_math_5.inputs[0])
	    #switch_5.Output -> instance_on_points_001.Rotation
	    hair_curve_strip.links.new(switch_5.outputs[0], instance_on_points_001.inputs[5])
	    #group_input_002_3.Length -> curve_line.Length
	    hair_curve_strip.links.new(group_input_002_3.outputs[2], curve_line.inputs[3])
	    #reroute_005_4.Output -> align_rotation_to_vector.Factor
	    hair_curve_strip.links.new(reroute_005_4.outputs[0], align_rotation_to_vector.inputs[1])
	    #group_input_004_3.Count -> curve_to_points_1.Count
	    hair_curve_strip.links.new(group_input_004_3.outputs[3], curve_to_points_1.inputs[1])
	    #reroute_8.Output -> reroute_001_6.Input
	    hair_curve_strip.links.new(reroute_8.outputs[0], reroute_001_6.inputs[0])
	    #reroute_8.Output -> reroute_002_4.Input
	    hair_curve_strip.links.new(reroute_8.outputs[0], reroute_002_4.inputs[0])
	    #reroute_004_5.Output -> reroute_003_4.Input
	    hair_curve_strip.links.new(reroute_004_5.outputs[0], reroute_003_4.inputs[0])
	    #curve_line.Curve -> reroute_004_5.Input
	    hair_curve_strip.links.new(curve_line.outputs[0], reroute_004_5.inputs[0])
	    #instance_on_points_001.Instances -> realize_instances.Geometry
	    hair_curve_strip.links.new(instance_on_points_001.outputs[0], realize_instances.inputs[0])
	    #reroute_005_4.Output -> compare_4.A
	    hair_curve_strip.links.new(reroute_005_4.outputs[0], compare_4.inputs[0])
	    #align_rotation_to_vector.Rotation -> switch_5.False
	    hair_curve_strip.links.new(align_rotation_to_vector.outputs[0], switch_5.inputs[1])
	    #compare_4.Result -> switch_5.Switch
	    hair_curve_strip.links.new(compare_4.outputs[0], switch_5.inputs[0])
	    #group_input_003_4.Rotation Factor -> reroute_005_4.Input
	    hair_curve_strip.links.new(group_input_003_4.outputs[4], reroute_005_4.inputs[0])
	    #group_input_8.Surface -> group_3.Surface
	    hair_curve_strip.links.new(group_input_8.outputs[1], group_3.inputs[2])
	    #group_input_8.Curve -> group_3.Geometry
	    hair_curve_strip.links.new(group_input_8.outputs[0], group_3.inputs[0])
	    #set_curve_tilt.Curve -> reroute_8.Input
	    hair_curve_strip.links.new(set_curve_tilt.outputs[0], reroute_8.inputs[0])
	    #group_3.Geometry -> set_curve_tilt.Curve
	    hair_curve_strip.links.new(group_3.outputs[0], set_curve_tilt.inputs[0])
	    #group_3.Tilt -> set_curve_tilt.Tilt
	    hair_curve_strip.links.new(group_3.outputs[1], set_curve_tilt.inputs[2])
	    #group_input_8.Surface Align Factor -> group_3.Surface Align Factor
	    hair_curve_strip.links.new(group_input_8.outputs[5], group_3.inputs[3])
	    return hair_curve_strip
	
	hair_curve_strip = hair_curve_strip_node_group()
	
	#initialize frizz_hair_curves node group
	def frizz_hair_curves_node_group():
	    frizz_hair_curves = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Frizz Hair Curves")
	
	    frizz_hair_curves.color_tag = 'NONE'
	    frizz_hair_curves.description = "Deforms hair curves using a random vector per point to frizz them"
	    frizz_hair_curves.default_group_node_width = 140
	    
	
	    frizz_hair_curves.is_modifier = True
	
	    #frizz_hair_curves interface
	    #Socket Geometry
	    geometry_socket_13 = frizz_hair_curves.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_13.attribute_domain = 'POINT'
	
	    #Socket Offset Vector
	    offset_vector_socket = frizz_hair_curves.interface.new_socket(name = "Offset Vector", in_out='OUTPUT', socket_type = 'NodeSocketVector')
	    offset_vector_socket.default_value = (0.0, 0.0, 0.0)
	    offset_vector_socket.min_value = -3.4028234663852886e+38
	    offset_vector_socket.max_value = 3.4028234663852886e+38
	    offset_vector_socket.subtype = 'NONE'
	    offset_vector_socket.attribute_domain = 'POINT'
	    offset_vector_socket.description = "Vector by which each point was offset during deformation"
	
	    #Socket Geometry
	    geometry_socket_14 = frizz_hair_curves.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_14.attribute_domain = 'POINT'
	    geometry_socket_14.description = "Input Geometry (May include other than curves)"
	
	    #Socket Cumulative Offset
	    cumulative_offset_socket = frizz_hair_curves.interface.new_socket(name = "Cumulative Offset", in_out='INPUT', socket_type = 'NodeSocketBool')
	    cumulative_offset_socket.default_value = True
	    cumulative_offset_socket.attribute_domain = 'POINT'
	    cumulative_offset_socket.description = "Apply offset cumulatively (previous points affect points after)"
	
	    #Socket Factor
	    factor_socket_2 = frizz_hair_curves.interface.new_socket(name = "Factor", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    factor_socket_2.default_value = 1.0
	    factor_socket_2.min_value = 0.0
	    factor_socket_2.max_value = 1.0
	    factor_socket_2.subtype = 'FACTOR'
	    factor_socket_2.attribute_domain = 'POINT'
	    factor_socket_2.description = "Factor to blend overall effect"
	
	    #Socket Distance
	    distance_socket = frizz_hair_curves.interface.new_socket(name = "Distance", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    distance_socket.default_value = 0.009999999776482582
	    distance_socket.min_value = 0.0
	    distance_socket.max_value = 3.4028234663852886e+38
	    distance_socket.subtype = 'DISTANCE'
	    distance_socket.attribute_domain = 'POINT'
	    distance_socket.description = "Overall distance factor for the deformation"
	
	    #Socket Shape
	    shape_socket_2 = frizz_hair_curves.interface.new_socket(name = "Shape", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    shape_socket_2.default_value = 0.5
	    shape_socket_2.min_value = -1.0
	    shape_socket_2.max_value = 1.0
	    shape_socket_2.subtype = 'NONE'
	    shape_socket_2.attribute_domain = 'POINT'
	    shape_socket_2.description = "Shape of the influence along curves (0=constant, 0.5=linear)"
	
	    #Socket Seed
	    seed_socket_2 = frizz_hair_curves.interface.new_socket(name = "Seed", in_out='INPUT', socket_type = 'NodeSocketInt')
	    seed_socket_2.default_value = 0
	    seed_socket_2.min_value = -10000
	    seed_socket_2.max_value = 10000
	    seed_socket_2.subtype = 'NONE'
	    seed_socket_2.attribute_domain = 'POINT'
	    seed_socket_2.description = "Random Seed for the operation"
	
	    #Socket Preserve Length
	    preserve_length_socket_1 = frizz_hair_curves.interface.new_socket(name = "Preserve Length", in_out='INPUT', socket_type = 'NodeSocketBool')
	    preserve_length_socket_1.default_value = False
	    preserve_length_socket_1.attribute_domain = 'POINT'
	    preserve_length_socket_1.description = "Preserve each curve's length during deformation"
	
	
	    #initialize frizz_hair_curves nodes
	    #node Frame
	    frame_6 = frizz_hair_curves.nodes.new("NodeFrame")
	    frame_6.label = "Optimization"
	    frame_6.name = "Frame"
	    frame_6.label_size = 20
	    frame_6.shrink = True
	
	    #node Frame.004
	    frame_004_3 = frizz_hair_curves.nodes.new("NodeFrame")
	    frame_004_3.label = "Offset Vector per Point"
	    frame_004_3.name = "Frame.004"
	    frame_004_3.label_size = 20
	    frame_004_3.shrink = True
	
	    #node Frame.001
	    frame_001_3 = frizz_hair_curves.nodes.new("NodeFrame")
	    frame_001_3.label = "Optimization"
	    frame_001_3.name = "Frame.001"
	    frame_001_3.label_size = 20
	    frame_001_3.shrink = True
	
	    #node Frame.002
	    frame_002_4 = frizz_hair_curves.nodes.new("NodeFrame")
	    frame_002_4.label = "Curve Tangent Space"
	    frame_002_4.name = "Frame.002"
	    frame_002_4.label_size = 20
	    frame_002_4.shrink = True
	
	    #node Frame.003
	    frame_003_3 = frizz_hair_curves.nodes.new("NodeFrame")
	    frame_003_3.label = "Random Vector per Point"
	    frame_003_3.name = "Frame.003"
	    frame_003_3.label_size = 20
	    frame_003_3.shrink = True
	
	    #node Frame.006
	    frame_006_3 = frizz_hair_curves.nodes.new("NodeFrame")
	    frame_006_3.label = "Length Preservation"
	    frame_006_3.name = "Frame.006"
	    frame_006_3.label_size = 20
	    frame_006_3.shrink = True
	
	    #node Frame.005
	    frame_005_2 = frizz_hair_curves.nodes.new("NodeFrame")
	    frame_005_2.label = "Optimization"
	    frame_005_2.name = "Frame.005"
	    frame_005_2.label_size = 20
	    frame_005_2.shrink = True
	
	    #node Math.001
	    math_001_3 = frizz_hair_curves.nodes.new("ShaderNodeMath")
	    math_001_3.name = "Math.001"
	    math_001_3.operation = 'MULTIPLY'
	    math_001_3.use_clamp = False
	
	    #node Group Input.001
	    group_input_001_5 = frizz_hair_curves.nodes.new("NodeGroupInput")
	    group_input_001_5.name = "Group Input.001"
	    group_input_001_5.outputs[0].hide = True
	    group_input_001_5.outputs[1].hide = True
	    group_input_001_5.outputs[3].hide = True
	    group_input_001_5.outputs[4].hide = True
	    group_input_001_5.outputs[5].hide = True
	    group_input_001_5.outputs[6].hide = True
	    group_input_001_5.outputs[7].hide = True
	
	    #node Group Input.006
	    group_input_006_3 = frizz_hair_curves.nodes.new("NodeGroupInput")
	    group_input_006_3.name = "Group Input.006"
	    group_input_006_3.outputs[0].hide = True
	    group_input_006_3.outputs[1].hide = True
	    group_input_006_3.outputs[2].hide = True
	    group_input_006_3.outputs[4].hide = True
	    group_input_006_3.outputs[5].hide = True
	    group_input_006_3.outputs[6].hide = True
	    group_input_006_3.outputs[7].hide = True
	
	    #node Capture Attribute.001
	    capture_attribute_001_3 = frizz_hair_curves.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_001_3.name = "Capture Attribute.001"
	    capture_attribute_001_3.active_index = 0
	    capture_attribute_001_3.capture_items.clear()
	    capture_attribute_001_3.capture_items.new('FLOAT', "Value")
	    capture_attribute_001_3.capture_items["Value"].data_type = 'FLOAT_VECTOR'
	    capture_attribute_001_3.domain = 'POINT'
	
	    #node Group Output
	    group_output_13 = frizz_hair_curves.nodes.new("NodeGroupOutput")
	    group_output_13.name = "Group Output"
	    group_output_13.is_active_output = True
	
	    #node Reroute.007
	    reroute_007_4 = frizz_hair_curves.nodes.new("NodeReroute")
	    reroute_007_4.name = "Reroute.007"
	    reroute_007_4.socket_idname = "NodeSocketGeometry"
	    #node Reroute.009
	    reroute_009_4 = frizz_hair_curves.nodes.new("NodeReroute")
	    reroute_009_4.name = "Reroute.009"
	    reroute_009_4.socket_idname = "NodeSocketGeometry"
	    #node Reroute.006
	    reroute_006_4 = frizz_hair_curves.nodes.new("NodeReroute")
	    reroute_006_4.name = "Reroute.006"
	    reroute_006_4.socket_idname = "NodeSocketGeometry"
	    #node Reroute.008
	    reroute_008_4 = frizz_hair_curves.nodes.new("NodeReroute")
	    reroute_008_4.name = "Reroute.008"
	    reroute_008_4.socket_idname = "NodeSocketGeometry"
	    #node Join Geometry
	    join_geometry_2 = frizz_hair_curves.nodes.new("GeometryNodeJoinGeometry")
	    join_geometry_2.name = "Join Geometry"
	
	    #node Set Spline Resolution.001
	    set_spline_resolution_001_1 = frizz_hair_curves.nodes.new("GeometryNodeSetSplineResolution")
	    set_spline_resolution_001_1.name = "Set Spline Resolution.001"
	    #Selection
	    set_spline_resolution_001_1.inputs[1].default_value = True
	
	    #node Set Spline Type.001
	    set_spline_type_001_1 = frizz_hair_curves.nodes.new("GeometryNodeCurveSplineType")
	    set_spline_type_001_1.name = "Set Spline Type.001"
	    set_spline_type_001_1.spline_type = 'CATMULL_ROM'
	    #Selection
	    set_spline_type_001_1.inputs[1].default_value = True
	
	    #node Reroute.002
	    reroute_002_5 = frizz_hair_curves.nodes.new("NodeReroute")
	    reroute_002_5.name = "Reroute.002"
	    reroute_002_5.socket_idname = "NodeSocketInt"
	    #node Switch.004
	    switch_004_2 = frizz_hair_curves.nodes.new("GeometryNodeSwitch")
	    switch_004_2.name = "Switch.004"
	    switch_004_2.input_type = 'INT'
	    #True
	    switch_004_2.inputs[2].default_value = 12
	
	    #node Compare.003
	    compare_003_3 = frizz_hair_curves.nodes.new("FunctionNodeCompare")
	    compare_003_3.name = "Compare.003"
	    compare_003_3.data_type = 'INT'
	    compare_003_3.mode = 'ELEMENT'
	    compare_003_3.operation = 'EQUAL'
	    #B_INT
	    compare_003_3.inputs[3].default_value = 0
	
	    #node Reroute.015
	    reroute_015_4 = frizz_hair_curves.nodes.new("NodeReroute")
	    reroute_015_4.name = "Reroute.015"
	    reroute_015_4.socket_idname = "NodeSocketVector"
	    #node Position.002
	    position_002_4 = frizz_hair_curves.nodes.new("GeometryNodeInputPosition")
	    position_002_4.name = "Position.002"
	
	    #node Vector Math.007
	    vector_math_007_4 = frizz_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_007_4.name = "Vector Math.007"
	    vector_math_007_4.operation = 'SUBTRACT'
	
	    #node Curve of Point
	    curve_of_point_1 = frizz_hair_curves.nodes.new("GeometryNodeCurveOfPoint")
	    curve_of_point_1.name = "Curve of Point"
	    curve_of_point_1.inputs[0].hide = True
	    curve_of_point_1.outputs[1].hide = True
	    #Point Index
	    curve_of_point_1.inputs[0].default_value = 0
	
	    #node Field at Index
	    field_at_index = frizz_hair_curves.nodes.new("GeometryNodeFieldAtIndex")
	    field_at_index.name = "Field at Index"
	    field_at_index.data_type = 'FLOAT_VECTOR'
	    field_at_index.domain = 'POINT'
	
	    #node Group.002
	    group_002_3 = frizz_hair_curves.nodes.new("GeometryNodeGroup")
	    group_002_3.name = "Group.002"
	    group_002_3.node_tree = curve_root_006
	    group_002_3.outputs[0].hide = True
	    group_002_3.outputs[1].hide = True
	    group_002_3.outputs[2].hide = True
	
	    #node Spline Parameter
	    spline_parameter_1 = frizz_hair_curves.nodes.new("GeometryNodeSplineParameter")
	    spline_parameter_1.name = "Spline Parameter"
	    spline_parameter_1.outputs[1].hide = True
	    spline_parameter_1.outputs[2].hide = True
	
	    #node Group
	    group_4 = frizz_hair_curves.nodes.new("GeometryNodeGroup")
	    group_4.name = "Group"
	    group_4.node_tree = shape_range
	    #Socket_2
	    group_4.inputs[1].default_value = 0.0
	    #Socket_3
	    group_4.inputs[2].default_value = 1.0
	    #Socket_5
	    group_4.inputs[4].default_value = 2.0
	
	    #node Group Input.007
	    group_input_007_3 = frizz_hair_curves.nodes.new("NodeGroupInput")
	    group_input_007_3.name = "Group Input.007"
	    group_input_007_3.outputs[0].hide = True
	    group_input_007_3.outputs[1].hide = True
	    group_input_007_3.outputs[2].hide = True
	    group_input_007_3.outputs[3].hide = True
	    group_input_007_3.outputs[5].hide = True
	    group_input_007_3.outputs[6].hide = True
	    group_input_007_3.outputs[7].hide = True
	
	    #node Vector Math.016
	    vector_math_016_1 = frizz_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_016_1.name = "Vector Math.016"
	    vector_math_016_1.operation = 'SUBTRACT'
	
	    #node Vector Math.014
	    vector_math_014_2 = frizz_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_014_2.name = "Vector Math.014"
	    vector_math_014_2.operation = 'ADD'
	
	    #node Vector Math.013
	    vector_math_013_2 = frizz_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_013_2.name = "Vector Math.013"
	    vector_math_013_2.operation = 'SUBTRACT'
	
	    #node Vector Math.015
	    vector_math_015_1 = frizz_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_015_1.name = "Vector Math.015"
	    vector_math_015_1.operation = 'SCALE'
	    #Scale
	    vector_math_015_1.inputs[3].default_value = 0.5
	
	    #node Group Input.005
	    group_input_005_3 = frizz_hair_curves.nodes.new("NodeGroupInput")
	    group_input_005_3.name = "Group Input.005"
	    group_input_005_3.outputs[0].hide = True
	    group_input_005_3.outputs[2].hide = True
	    group_input_005_3.outputs[3].hide = True
	    group_input_005_3.outputs[4].hide = True
	    group_input_005_3.outputs[5].hide = True
	    group_input_005_3.outputs[6].hide = True
	    group_input_005_3.outputs[7].hide = True
	
	    #node Switch
	    switch_6 = frizz_hair_curves.nodes.new("GeometryNodeSwitch")
	    switch_6.name = "Switch"
	    switch_6.input_type = 'VECTOR'
	
	    #node Vector Math.012
	    vector_math_012_2 = frizz_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_012_2.name = "Vector Math.012"
	    vector_math_012_2.operation = 'SCALE'
	
	    #node Vector Math.017
	    vector_math_017_1 = frizz_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_017_1.name = "Vector Math.017"
	    vector_math_017_1.operation = 'SCALE'
	
	    #node Position.001
	    position_001_2 = frizz_hair_curves.nodes.new("GeometryNodeInputPosition")
	    position_001_2.name = "Position.001"
	
	    #node Capture Attribute.003
	    capture_attribute_003_1 = frizz_hair_curves.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_003_1.name = "Capture Attribute.003"
	    capture_attribute_003_1.active_index = 0
	    capture_attribute_003_1.capture_items.clear()
	    capture_attribute_003_1.capture_items.new('FLOAT', "Value")
	    capture_attribute_003_1.capture_items["Value"].data_type = 'FLOAT_VECTOR'
	    capture_attribute_003_1.domain = 'POINT'
	
	    #node Group Input
	    group_input_9 = frizz_hair_curves.nodes.new("NodeGroupInput")
	    group_input_9.name = "Group Input"
	    group_input_9.outputs[1].hide = True
	    group_input_9.outputs[2].hide = True
	    group_input_9.outputs[3].hide = True
	    group_input_9.outputs[4].hide = True
	    group_input_9.outputs[5].hide = True
	    group_input_9.outputs[6].hide = True
	    group_input_9.outputs[7].hide = True
	
	    #node Reroute.012
	    reroute_012_5 = frizz_hair_curves.nodes.new("NodeReroute")
	    reroute_012_5.name = "Reroute.012"
	    reroute_012_5.socket_idname = "NodeSocketGeometry"
	    #node Reroute.010
	    reroute_010_3 = frizz_hair_curves.nodes.new("NodeReroute")
	    reroute_010_3.name = "Reroute.010"
	    reroute_010_3.socket_idname = "NodeSocketGeometry"
	    #node Reroute.011
	    reroute_011_4 = frizz_hair_curves.nodes.new("NodeReroute")
	    reroute_011_4.name = "Reroute.011"
	    reroute_011_4.socket_idname = "NodeSocketGeometry"
	    #node Reroute.013
	    reroute_013_4 = frizz_hair_curves.nodes.new("NodeReroute")
	    reroute_013_4.name = "Reroute.013"
	    reroute_013_4.socket_idname = "NodeSocketGeometry"
	    #node Separate Components
	    separate_components_3 = frizz_hair_curves.nodes.new("GeometryNodeSeparateComponents")
	    separate_components_3.name = "Separate Components"
	    separate_components_3.hide = True
	
	    #node Set Spline Type
	    set_spline_type = frizz_hair_curves.nodes.new("GeometryNodeCurveSplineType")
	    set_spline_type.name = "Set Spline Type"
	    set_spline_type.spline_type = 'POLY'
	    #Selection
	    set_spline_type.inputs[1].default_value = True
	
	    #node Spline Resolution
	    spline_resolution_1 = frizz_hair_curves.nodes.new("GeometryNodeInputSplineResolution")
	    spline_resolution_1.name = "Spline Resolution"
	
	    #node Capture Attribute.002
	    capture_attribute_002_3 = frizz_hair_curves.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_002_3.name = "Capture Attribute.002"
	    capture_attribute_002_3.active_index = 0
	    capture_attribute_002_3.capture_items.clear()
	    capture_attribute_002_3.capture_items.new('FLOAT', "Value")
	    capture_attribute_002_3.capture_items["Value"].data_type = 'INT'
	    capture_attribute_002_3.domain = 'CURVE'
	
	    #node Reroute
	    reroute_9 = frizz_hair_curves.nodes.new("NodeReroute")
	    reroute_9.name = "Reroute"
	    reroute_9.socket_idname = "NodeSocketBool"
	    #node Set Position
	    set_position_4 = frizz_hair_curves.nodes.new("GeometryNodeSetPosition")
	    set_position_4.name = "Set Position"
	    set_position_4.inputs[2].hide = True
	    #Position
	    set_position_4.inputs[2].default_value = (0.0, 0.0, 0.0)
	
	    #node Group Input.002
	    group_input_002_4 = frizz_hair_curves.nodes.new("NodeGroupInput")
	    group_input_002_4.name = "Group Input.002"
	    group_input_002_4.outputs[0].hide = True
	    group_input_002_4.outputs[1].hide = True
	    group_input_002_4.outputs[3].hide = True
	    group_input_002_4.outputs[4].hide = True
	    group_input_002_4.outputs[5].hide = True
	    group_input_002_4.outputs[6].hide = True
	    group_input_002_4.outputs[7].hide = True
	
	    #node Compare
	    compare_5 = frizz_hair_curves.nodes.new("FunctionNodeCompare")
	    compare_5.name = "Compare"
	    compare_5.data_type = 'FLOAT'
	    compare_5.mode = 'ELEMENT'
	    compare_5.operation = 'NOT_EQUAL'
	    #B
	    compare_5.inputs[1].default_value = 0.0
	    #Epsilon
	    compare_5.inputs[12].default_value = 0.0
	
	    #node Reroute.003
	    reroute_003_5 = frizz_hair_curves.nodes.new("NodeReroute")
	    reroute_003_5.name = "Reroute.003"
	    reroute_003_5.socket_idname = "NodeSocketVector"
	    #node Accumulate Field
	    accumulate_field_2 = frizz_hair_curves.nodes.new("GeometryNodeAccumulateField")
	    accumulate_field_2.name = "Accumulate Field"
	    accumulate_field_2.data_type = 'FLOAT_VECTOR'
	    accumulate_field_2.domain = 'POINT'
	    accumulate_field_2.outputs[2].hide = True
	
	    #node Separate XYZ
	    separate_xyz_2 = frizz_hair_curves.nodes.new("ShaderNodeSeparateXYZ")
	    separate_xyz_2.name = "Separate XYZ"
	
	    #node Curve Tangent
	    curve_tangent_4 = frizz_hair_curves.nodes.new("GeometryNodeInputTangent")
	    curve_tangent_4.name = "Curve Tangent"
	
	    #node Normal
	    normal_1 = frizz_hair_curves.nodes.new("GeometryNodeInputNormal")
	    normal_1.name = "Normal"
	    normal_1.legacy_corner_normals = True
	
	    #node Vector Math.003
	    vector_math_003_4 = frizz_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_003_4.name = "Vector Math.003"
	    vector_math_003_4.hide = True
	    vector_math_003_4.operation = 'SCALE'
	
	    #node Vector Math.002
	    vector_math_002_4 = frizz_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_002_4.name = "Vector Math.002"
	    vector_math_002_4.hide = True
	    vector_math_002_4.operation = 'SCALE'
	
	    #node Vector Math.004
	    vector_math_004_5 = frizz_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_004_5.name = "Vector Math.004"
	    vector_math_004_5.hide = True
	    vector_math_004_5.operation = 'SCALE'
	
	    #node Vector Math.010
	    vector_math_010_2 = frizz_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_010_2.name = "Vector Math.010"
	    vector_math_010_2.hide = True
	    vector_math_010_2.operation = 'ADD'
	
	    #node Vector Math.011
	    vector_math_011_2 = frizz_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_011_2.name = "Vector Math.011"
	    vector_math_011_2.hide = True
	    vector_math_011_2.operation = 'ADD'
	
	    #node Vector Math
	    vector_math_6 = frizz_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_6.name = "Vector Math"
	    vector_math_6.hide = True
	    vector_math_6.operation = 'CROSS_PRODUCT'
	
	    #node Random Value
	    random_value_2 = frizz_hair_curves.nodes.new("FunctionNodeRandomValue")
	    random_value_2.name = "Random Value"
	    random_value_2.data_type = 'FLOAT_VECTOR'
	    #Min
	    random_value_2.inputs[0].default_value = (-1.0, -1.0, -1.0)
	    #Max
	    random_value_2.inputs[1].default_value = (1.0, 1.0, 1.0)
	    #ID
	    random_value_2.inputs[7].default_value = 0
	
	    #node Switch.001
	    switch_001_7 = frizz_hair_curves.nodes.new("GeometryNodeSwitch")
	    switch_001_7.name = "Switch.001"
	    switch_001_7.input_type = 'GEOMETRY'
	
	    #node Reroute.004
	    reroute_004_6 = frizz_hair_curves.nodes.new("NodeReroute")
	    reroute_004_6.name = "Reroute.004"
	    reroute_004_6.socket_idname = "NodeSocketGeometry"
	    #node Group.005
	    group_005_1 = frizz_hair_curves.nodes.new("GeometryNodeGroup")
	    group_005_1.name = "Group.005"
	    group_005_1.node_tree = restore_curve_segment_length
	    #Socket_5
	    group_005_1.inputs[4].default_value = 0.0
	
	    #node Sample Index
	    sample_index_2 = frizz_hair_curves.nodes.new("GeometryNodeSampleIndex")
	    sample_index_2.name = "Sample Index"
	    sample_index_2.hide = True
	    sample_index_2.clamp = False
	    sample_index_2.data_type = 'INT'
	    sample_index_2.domain = 'POINT'
	    #Index
	    sample_index_2.inputs[2].default_value = 0
	
	    #node Accumulate Field.001
	    accumulate_field_001_1 = frizz_hair_curves.nodes.new("GeometryNodeAccumulateField")
	    accumulate_field_001_1.name = "Accumulate Field.001"
	    accumulate_field_001_1.hide = True
	    accumulate_field_001_1.data_type = 'INT'
	    accumulate_field_001_1.domain = 'POINT'
	    #Group Index
	    accumulate_field_001_1.inputs[1].default_value = 0
	
	    #node Compare.002
	    compare_002_4 = frizz_hair_curves.nodes.new("FunctionNodeCompare")
	    compare_002_4.name = "Compare.002"
	    compare_002_4.data_type = 'FLOAT'
	    compare_002_4.mode = 'ELEMENT'
	    compare_002_4.operation = 'GREATER_THAN'
	    #B
	    compare_002_4.inputs[1].default_value = 0.0
	
	    #node Boolean Math
	    boolean_math_4 = frizz_hair_curves.nodes.new("FunctionNodeBooleanMath")
	    boolean_math_4.name = "Boolean Math"
	    boolean_math_4.hide = True
	    boolean_math_4.operation = 'AND'
	
	    #node Group Input.008
	    group_input_008_2 = frizz_hair_curves.nodes.new("NodeGroupInput")
	    group_input_008_2.name = "Group Input.008"
	    group_input_008_2.outputs[0].hide = True
	    group_input_008_2.outputs[1].hide = True
	    group_input_008_2.outputs[2].hide = True
	    group_input_008_2.outputs[3].hide = True
	    group_input_008_2.outputs[4].hide = True
	    group_input_008_2.outputs[5].hide = True
	    group_input_008_2.outputs[7].hide = True
	
	    #node Group Input.003
	    group_input_003_5 = frizz_hair_curves.nodes.new("NodeGroupInput")
	    group_input_003_5.name = "Group Input.003"
	    group_input_003_5.outputs[0].hide = True
	    group_input_003_5.outputs[1].hide = True
	    group_input_003_5.outputs[2].hide = True
	    group_input_003_5.outputs[3].hide = True
	    group_input_003_5.outputs[4].hide = True
	    group_input_003_5.outputs[6].hide = True
	    group_input_003_5.outputs[7].hide = True
	
	    #node Random Value.004
	    random_value_004_2 = frizz_hair_curves.nodes.new("FunctionNodeRandomValue")
	    random_value_004_2.label = "Hash Seed"
	    random_value_004_2.name = "Random Value.004"
	    random_value_004_2.data_type = 'INT'
	    #Min_002
	    random_value_004_2.inputs[4].default_value = -1073741823
	    #Max_002
	    random_value_004_2.inputs[5].default_value = 1073741823
	    #Seed
	    random_value_004_2.inputs[8].default_value = 64785
	
	
	
	
	    #Set parents
	    frame_005_2.parent = frame_006_3
	    set_spline_resolution_001_1.parent = frame_6
	    set_spline_type_001_1.parent = frame_6
	    reroute_002_5.parent = frame_6
	    switch_004_2.parent = frame_6
	    compare_003_3.parent = frame_6
	    curve_of_point_1.parent = frame_004_3
	    field_at_index.parent = frame_004_3
	    group_002_3.parent = frame_004_3
	    spline_parameter_1.parent = frame_004_3
	    group_4.parent = frame_004_3
	    group_input_007_3.parent = frame_004_3
	    vector_math_016_1.parent = frame_004_3
	    vector_math_014_2.parent = frame_004_3
	    vector_math_013_2.parent = frame_004_3
	    vector_math_015_1.parent = frame_004_3
	    group_input_005_3.parent = frame_004_3
	    switch_6.parent = frame_004_3
	    vector_math_012_2.parent = frame_004_3
	    vector_math_017_1.parent = frame_004_3
	    set_spline_type.parent = frame_001_3
	    spline_resolution_1.parent = frame_001_3
	    capture_attribute_002_3.parent = frame_001_3
	    reroute_003_5.parent = frame_004_3
	    accumulate_field_2.parent = frame_004_3
	    separate_xyz_2.parent = frame_002_4
	    curve_tangent_4.parent = frame_002_4
	    normal_1.parent = frame_002_4
	    vector_math_003_4.parent = frame_002_4
	    vector_math_002_4.parent = frame_002_4
	    vector_math_004_5.parent = frame_002_4
	    vector_math_010_2.parent = frame_002_4
	    vector_math_011_2.parent = frame_002_4
	    vector_math_6.parent = frame_002_4
	    random_value_2.parent = frame_003_3
	    switch_001_7.parent = frame_006_3
	    reroute_004_6.parent = frame_006_3
	    group_005_1.parent = frame_006_3
	    sample_index_2.parent = frame_005_2
	    accumulate_field_001_1.parent = frame_005_2
	    compare_002_4.parent = frame_005_2
	    boolean_math_4.parent = frame_006_3
	    group_input_008_2.parent = frame_006_3
	    group_input_003_5.parent = frame_003_3
	    random_value_004_2.parent = frame_003_3
	
	    #Set locations
	    frame_6.location = (-1246.265380859375, -71.0)
	    frame_004_3.location = (-4295.0, -652.0)
	    frame_001_3.location = (-3477.0, -46.0)
	    frame_002_4.location = (-4928.0, -623.0)
	    frame_003_3.location = (-5541.0, -623.0)
	    frame_006_3.location = (-2282.0, -9.0)
	    frame_005_2.location = (367.0, -40.0)
	    math_001_3.location = (-4486.1142578125, -1035.02294921875)
	    group_input_001_5.location = (-4666.9521484375, -1075.2091064453125)
	    group_input_006_3.location = (-4666.9521484375, -1155.5811767578125)
	    capture_attribute_001_3.location = (-523.780517578125, -124.394775390625)
	    group_output_13.location = (75.0, 50.0)
	    reroute_007_4.location = (-266.58154296875, 170.55810546875)
	    reroute_009_4.location = (-266.58154296875, 150.465087890625)
	    reroute_006_4.location = (-266.58154296875, 210.7442626953125)
	    reroute_008_4.location = (-266.58154296875, 190.651123046875)
	    join_geometry_2.location = (-125.930419921875, 50.0)
	    set_spline_resolution_001_1.location = (477.3583984375, -100.023193359375)
	    set_spline_type_001_1.location = (236.2421875, -39.74412536621094)
	    reroute_002_5.location = (35.0, -267.40777587890625)
	    switch_004_2.location = (256.0234375, -227.22171020507812)
	    compare_003_3.location = (75.186279296875, -227.22171020507812)
	    reroute_015_4.location = (-1914.2093505859375, -572.8834228515625)
	    position_002_4.location = (-969.83740234375, -512.6043701171875)
	    vector_math_007_4.location = (-789.000244140625, -492.5113525390625)
	    curve_of_point_1.location = (230.7509765625, -351.99322509765625)
	    field_at_index.location = (411.58837890625, -412.2723388671875)
	    group_002_3.location = (236.51513671875, -435.149169921875)
	    spline_parameter_1.location = (1011.646484375, -321.7235107421875)
	    group_4.location = (1192.48388671875, -261.4444580078125)
	    group_input_007_3.location = (1011.646484375, -382.0025634765625)
	    vector_math_016_1.location = (629.879150390625, -40.42120361328125)
	    vector_math_014_2.location = (629.879150390625, -160.97930908203125)
	    vector_math_013_2.location = (629.879150390625, -281.5374755859375)
	    vector_math_015_1.location = (810.71630859375, -221.2584228515625)
	    group_input_005_3.location = (810.71630859375, -120.79327392578125)
	    switch_6.location = (1011.646484375, -120.79327392578125)
	    vector_math_012_2.location = (29.82080078125, -251.52813720703125)
	    vector_math_017_1.location = (1380.00390625, -144.06353759765625)
	    position_001_2.location = (-4003.882568359375, -211.2093505859375)
	    capture_attribute_003_1.location = (-3823.046630859375, -110.744140625)
	    group_input_9.location = (-4445.9287109375, 9.81396484375)
	    reroute_012_5.location = (-3863.232666015625, 190.651123046875)
	    reroute_010_3.location = (-3863.232666015625, 210.7442626953125)
	    reroute_011_4.location = (-3863.232666015625, 170.55810546875)
	    reroute_013_4.location = (-3863.232666015625, 150.465087890625)
	    separate_components_3.location = (-4224.9052734375, -50.465087890625)
	    set_spline_type.location = (468.02783203125, -40.377174377441406)
	    spline_resolution_1.location = (29.975341796875, -190.07485961914062)
	    capture_attribute_002_3.location = (230.905517578125, -49.42369842529297)
	    reroute_9.location = (-2577.279052734375, -512.6043701171875)
	    set_position_4.location = (-2496.906982421875, -351.8601989746094)
	    group_input_002_4.location = (-2979.1396484375, -492.5113525390625)
	    compare_5.location = (-2778.20947265625, -472.4183349609375)
	    reroute_003_5.location = (352.711669921875, -173.0606689453125)
	    accumulate_field_2.location = (411.58837890625, -151.0631103515625)
	    separate_xyz_2.location = (30.22705078125, -40.1751708984375)
	    curve_tangent_4.location = (30.22705078125, -180.82635498046875)
	    normal_1.location = (30.22705078125, -281.29150390625)
	    vector_math_003_4.location = (231.1572265625, -180.82635498046875)
	    vector_math_002_4.location = (231.1572265625, -140.64031982421875)
	    vector_math_004_5.location = (231.1572265625, -221.01239013671875)
	    vector_math_010_2.location = (391.9013671875, -160.73333740234375)
	    vector_math_011_2.location = (391.9013671875, -200.91937255859375)
	    vector_math_6.location = (30.22705078125, -241.10546875)
	    random_value_2.location = (401.955078125, -40.1171875)
	    switch_001_7.location = (793.6678466796875, -98.78160095214844)
	    reroute_004_6.location = (210.97021484375, -219.33973693847656)
	    group_005_1.location = (431.993408203125, -259.52581787109375)
	    sample_index_2.location = (29.9866943359375, -60.56507873535156)
	    accumulate_field_001_1.location = (29.9866943359375, -100.75112915039062)
	    compare_002_4.location = (210.8238525390625, -40.47205352783203)
	    boolean_math_4.location = (231.063232421875, -339.89788818359375)
	    group_input_008_2.location = (30.1328125, -380.08392333984375)
	    group_input_003_5.location = (30.140625, -244.14654541015625)
	    random_value_004_2.location = (210.97802734375, -163.7744140625)
	
	    #Set dimensions
	    frame_6.width, frame_6.height = 647.265380859375, 405.0
	    frame_004_3.width, frame_004_3.height = 1550.0, 588.0
	    frame_001_3.width, frame_001_3.height = 638.0, 270.0
	    frame_002_4.width, frame_002_4.height = 562.0, 361.0
	    frame_003_3.width, frame_003_3.height = 572.0, 361.0
	    frame_006_3.width, frame_006_3.height = 964.0, 474.0
	    frame_005_2.width, frame_005_2.height = 381.0, 218.0
	    math_001_3.width, math_001_3.height = 140.0, 100.0
	    group_input_001_5.width, group_input_001_5.height = 140.0, 100.0
	    group_input_006_3.width, group_input_006_3.height = 140.0, 100.0
	    capture_attribute_001_3.width, capture_attribute_001_3.height = 140.0, 100.0
	    group_output_13.width, group_output_13.height = 140.0, 100.0
	    reroute_007_4.width, reroute_007_4.height = 10.0, 100.0
	    reroute_009_4.width, reroute_009_4.height = 10.0, 100.0
	    reroute_006_4.width, reroute_006_4.height = 10.0, 100.0
	    reroute_008_4.width, reroute_008_4.height = 10.0, 100.0
	    join_geometry_2.width, join_geometry_2.height = 140.0, 100.0
	    set_spline_resolution_001_1.width, set_spline_resolution_001_1.height = 140.0, 100.0
	    set_spline_type_001_1.width, set_spline_type_001_1.height = 140.0, 100.0
	    reroute_002_5.width, reroute_002_5.height = 10.0, 100.0
	    switch_004_2.width, switch_004_2.height = 140.0, 100.0
	    compare_003_3.width, compare_003_3.height = 140.0, 100.0
	    reroute_015_4.width, reroute_015_4.height = 10.0, 100.0
	    position_002_4.width, position_002_4.height = 140.0, 100.0
	    vector_math_007_4.width, vector_math_007_4.height = 140.0, 100.0
	    curve_of_point_1.width, curve_of_point_1.height = 140.0, 100.0
	    field_at_index.width, field_at_index.height = 140.0, 100.0
	    group_002_3.width, group_002_3.height = 140.0, 100.0
	    spline_parameter_1.width, spline_parameter_1.height = 140.0, 100.0
	    group_4.width, group_4.height = 140.0, 100.0
	    group_input_007_3.width, group_input_007_3.height = 140.0, 100.0
	    vector_math_016_1.width, vector_math_016_1.height = 140.0, 100.0
	    vector_math_014_2.width, vector_math_014_2.height = 140.0, 100.0
	    vector_math_013_2.width, vector_math_013_2.height = 140.0, 100.0
	    vector_math_015_1.width, vector_math_015_1.height = 140.0, 100.0
	    group_input_005_3.width, group_input_005_3.height = 140.0, 100.0
	    switch_6.width, switch_6.height = 140.0, 100.0
	    vector_math_012_2.width, vector_math_012_2.height = 140.0, 100.0
	    vector_math_017_1.width, vector_math_017_1.height = 140.0, 100.0
	    position_001_2.width, position_001_2.height = 140.0, 100.0
	    capture_attribute_003_1.width, capture_attribute_003_1.height = 140.0, 100.0
	    group_input_9.width, group_input_9.height = 140.0, 100.0
	    reroute_012_5.width, reroute_012_5.height = 10.0, 100.0
	    reroute_010_3.width, reroute_010_3.height = 10.0, 100.0
	    reroute_011_4.width, reroute_011_4.height = 10.0, 100.0
	    reroute_013_4.width, reroute_013_4.height = 10.0, 100.0
	    separate_components_3.width, separate_components_3.height = 140.0, 100.0
	    set_spline_type.width, set_spline_type.height = 140.0, 100.0
	    spline_resolution_1.width, spline_resolution_1.height = 140.0, 100.0
	    capture_attribute_002_3.width, capture_attribute_002_3.height = 140.0, 100.0
	    reroute_9.width, reroute_9.height = 10.0, 100.0
	    set_position_4.width, set_position_4.height = 140.0, 100.0
	    group_input_002_4.width, group_input_002_4.height = 140.0, 100.0
	    compare_5.width, compare_5.height = 140.0, 100.0
	    reroute_003_5.width, reroute_003_5.height = 10.0, 100.0
	    accumulate_field_2.width, accumulate_field_2.height = 140.0, 100.0
	    separate_xyz_2.width, separate_xyz_2.height = 140.0, 100.0
	    curve_tangent_4.width, curve_tangent_4.height = 140.0, 100.0
	    normal_1.width, normal_1.height = 140.0, 100.0
	    vector_math_003_4.width, vector_math_003_4.height = 140.0, 100.0
	    vector_math_002_4.width, vector_math_002_4.height = 140.0, 100.0
	    vector_math_004_5.width, vector_math_004_5.height = 140.0, 100.0
	    vector_math_010_2.width, vector_math_010_2.height = 140.0, 100.0
	    vector_math_011_2.width, vector_math_011_2.height = 140.0, 100.0
	    vector_math_6.width, vector_math_6.height = 140.0, 100.0
	    random_value_2.width, random_value_2.height = 140.0, 100.0
	    switch_001_7.width, switch_001_7.height = 140.0, 100.0
	    reroute_004_6.width, reroute_004_6.height = 10.0, 100.0
	    group_005_1.width, group_005_1.height = 251.53790283203125, 100.0
	    sample_index_2.width, sample_index_2.height = 140.0, 100.0
	    accumulate_field_001_1.width, accumulate_field_001_1.height = 140.0, 100.0
	    compare_002_4.width, compare_002_4.height = 140.0, 100.0
	    boolean_math_4.width, boolean_math_4.height = 140.0, 100.0
	    group_input_008_2.width, group_input_008_2.height = 140.0, 100.0
	    group_input_003_5.width, group_input_003_5.height = 140.0, 100.0
	    random_value_004_2.width, random_value_004_2.height = 140.0, 100.0
	
	    #initialize frizz_hair_curves links
	    #set_spline_type.Curve -> set_position_4.Geometry
	    frizz_hair_curves.links.new(set_spline_type.outputs[0], set_position_4.inputs[0])
	    #random_value_2.Value -> separate_xyz_2.Vector
	    frizz_hair_curves.links.new(random_value_2.outputs[0], separate_xyz_2.inputs[0])
	    #curve_tangent_4.Tangent -> vector_math_6.Vector
	    frizz_hair_curves.links.new(curve_tangent_4.outputs[0], vector_math_6.inputs[0])
	    #normal_1.Normal -> vector_math_6.Vector
	    frizz_hair_curves.links.new(normal_1.outputs[0], vector_math_6.inputs[1])
	    #curve_tangent_4.Tangent -> vector_math_002_4.Vector
	    frizz_hair_curves.links.new(curve_tangent_4.outputs[0], vector_math_002_4.inputs[0])
	    #vector_math_6.Vector -> vector_math_003_4.Vector
	    frizz_hair_curves.links.new(vector_math_6.outputs[0], vector_math_003_4.inputs[0])
	    #normal_1.Normal -> vector_math_004_5.Vector
	    frizz_hair_curves.links.new(normal_1.outputs[0], vector_math_004_5.inputs[0])
	    #separate_xyz_2.X -> vector_math_002_4.Scale
	    frizz_hair_curves.links.new(separate_xyz_2.outputs[0], vector_math_002_4.inputs[3])
	    #separate_xyz_2.Y -> vector_math_003_4.Scale
	    frizz_hair_curves.links.new(separate_xyz_2.outputs[1], vector_math_003_4.inputs[3])
	    #separate_xyz_2.Z -> vector_math_004_5.Scale
	    frizz_hair_curves.links.new(separate_xyz_2.outputs[2], vector_math_004_5.inputs[3])
	    #vector_math_002_4.Vector -> vector_math_010_2.Vector
	    frizz_hair_curves.links.new(vector_math_002_4.outputs[0], vector_math_010_2.inputs[0])
	    #vector_math_003_4.Vector -> vector_math_010_2.Vector
	    frizz_hair_curves.links.new(vector_math_003_4.outputs[0], vector_math_010_2.inputs[1])
	    #vector_math_010_2.Vector -> vector_math_011_2.Vector
	    frizz_hair_curves.links.new(vector_math_010_2.outputs[0], vector_math_011_2.inputs[0])
	    #vector_math_004_5.Vector -> vector_math_011_2.Vector
	    frizz_hair_curves.links.new(vector_math_004_5.outputs[0], vector_math_011_2.inputs[1])
	    #vector_math_011_2.Vector -> vector_math_012_2.Vector
	    frizz_hair_curves.links.new(vector_math_011_2.outputs[0], vector_math_012_2.inputs[0])
	    #math_001_3.Value -> vector_math_012_2.Scale
	    frizz_hair_curves.links.new(math_001_3.outputs[0], vector_math_012_2.inputs[3])
	    #spline_parameter_1.Factor -> group_4.Value
	    frizz_hair_curves.links.new(spline_parameter_1.outputs[0], group_4.inputs[0])
	    #curve_of_point_1.Curve Index -> accumulate_field_2.Group ID
	    frizz_hair_curves.links.new(curve_of_point_1.outputs[0], accumulate_field_2.inputs[1])
	    #reroute_003_5.Output -> accumulate_field_2.Value
	    frizz_hair_curves.links.new(reroute_003_5.outputs[0], accumulate_field_2.inputs[0])
	    #group_input_002_4.Factor -> compare_5.A
	    frizz_hair_curves.links.new(group_input_002_4.outputs[2], compare_5.inputs[0])
	    #reroute_9.Output -> set_position_4.Selection
	    frizz_hair_curves.links.new(reroute_9.outputs[0], set_position_4.inputs[1])
	    #compare_5.Result -> reroute_9.Input
	    frizz_hair_curves.links.new(compare_5.outputs[0], reroute_9.inputs[0])
	    #random_value_004_2.Value -> random_value_2.Seed
	    frizz_hair_curves.links.new(random_value_004_2.outputs[2], random_value_2.inputs[8])
	    #group_002_3.Root Index -> field_at_index.Index
	    frizz_hair_curves.links.new(group_002_3.outputs[3], field_at_index.inputs[0])
	    #vector_math_012_2.Vector -> field_at_index.Value
	    frizz_hair_curves.links.new(vector_math_012_2.outputs[0], field_at_index.inputs[1])
	    #reroute_004_6.Output -> group_005_1.Curves
	    frizz_hair_curves.links.new(reroute_004_6.outputs[0], group_005_1.inputs[0])
	    #group_input_008_2.Preserve Length -> group_005_1.Factor
	    frizz_hair_curves.links.new(group_input_008_2.outputs[6], group_005_1.inputs[2])
	    #reroute_015_4.Output -> group_005_1.Reference Position
	    frizz_hair_curves.links.new(reroute_015_4.outputs[0], group_005_1.inputs[3])
	    #vector_math_017_1.Vector -> set_position_4.Offset
	    frizz_hair_curves.links.new(vector_math_017_1.outputs[0], set_position_4.inputs[3])
	    #field_at_index.Value -> vector_math_013_2.Vector
	    frizz_hair_curves.links.new(field_at_index.outputs[0], vector_math_013_2.inputs[1])
	    #accumulate_field_2.Leading -> vector_math_014_2.Vector
	    frizz_hair_curves.links.new(accumulate_field_2.outputs[0], vector_math_014_2.inputs[0])
	    #accumulate_field_2.Trailing -> vector_math_014_2.Vector
	    frizz_hair_curves.links.new(accumulate_field_2.outputs[1], vector_math_014_2.inputs[1])
	    #vector_math_014_2.Vector -> vector_math_013_2.Vector
	    frizz_hair_curves.links.new(vector_math_014_2.outputs[0], vector_math_013_2.inputs[0])
	    #vector_math_013_2.Vector -> vector_math_015_1.Vector
	    frizz_hair_curves.links.new(vector_math_013_2.outputs[0], vector_math_015_1.inputs[0])
	    #reroute_9.Output -> boolean_math_4.Boolean
	    frizz_hair_curves.links.new(reroute_9.outputs[0], boolean_math_4.inputs[0])
	    #group_input_008_2.Preserve Length -> boolean_math_4.Boolean
	    frizz_hair_curves.links.new(group_input_008_2.outputs[6], boolean_math_4.inputs[1])
	    #group_input_9.Geometry -> separate_components_3.Geometry
	    frizz_hair_curves.links.new(group_input_9.outputs[0], separate_components_3.inputs[0])
	    #reroute_009_4.Output -> join_geometry_2.Geometry
	    frizz_hair_curves.links.new(reroute_009_4.outputs[0], join_geometry_2.inputs[0])
	    #vector_math_015_1.Vector -> switch_6.True
	    frizz_hair_curves.links.new(vector_math_015_1.outputs[0], switch_6.inputs[2])
	    #group_input_005_3.Cumulative Offset -> switch_6.Switch
	    frizz_hair_curves.links.new(group_input_005_3.outputs[1], switch_6.inputs[0])
	    #boolean_math_4.Boolean -> group_005_1.Selection
	    frizz_hair_curves.links.new(boolean_math_4.outputs[0], group_005_1.inputs[1])
	    #reroute_004_6.Output -> switch_001_7.False
	    frizz_hair_curves.links.new(reroute_004_6.outputs[0], switch_001_7.inputs[1])
	    #reroute_010_3.Output -> reroute_006_4.Input
	    frizz_hair_curves.links.new(reroute_010_3.outputs[0], reroute_006_4.inputs[0])
	    #reroute_011_4.Output -> reroute_007_4.Input
	    frizz_hair_curves.links.new(reroute_011_4.outputs[0], reroute_007_4.inputs[0])
	    #reroute_012_5.Output -> reroute_008_4.Input
	    frizz_hair_curves.links.new(reroute_012_5.outputs[0], reroute_008_4.inputs[0])
	    #reroute_013_4.Output -> reroute_009_4.Input
	    frizz_hair_curves.links.new(reroute_013_4.outputs[0], reroute_009_4.inputs[0])
	    #separate_components_3.Mesh -> reroute_010_3.Input
	    frizz_hair_curves.links.new(separate_components_3.outputs[0], reroute_010_3.inputs[0])
	    #separate_components_3.Volume -> reroute_011_4.Input
	    frizz_hair_curves.links.new(separate_components_3.outputs[4], reroute_011_4.inputs[0])
	    #separate_components_3.Point Cloud -> reroute_012_5.Input
	    frizz_hair_curves.links.new(separate_components_3.outputs[3], reroute_012_5.inputs[0])
	    #separate_components_3.Instances -> reroute_013_4.Input
	    frizz_hair_curves.links.new(separate_components_3.outputs[5], reroute_013_4.inputs[0])
	    #boolean_math_4.Boolean -> accumulate_field_001_1.Value
	    frizz_hair_curves.links.new(boolean_math_4.outputs[0], accumulate_field_001_1.inputs[0])
	    #compare_002_4.Result -> switch_001_7.Switch
	    frizz_hair_curves.links.new(compare_002_4.outputs[0], switch_001_7.inputs[0])
	    #reroute_004_6.Output -> sample_index_2.Geometry
	    frizz_hair_curves.links.new(reroute_004_6.outputs[0], sample_index_2.inputs[0])
	    #sample_index_2.Value -> compare_002_4.A
	    frizz_hair_curves.links.new(sample_index_2.outputs[0], compare_002_4.inputs[0])
	    #accumulate_field_001_1.Total -> sample_index_2.Value
	    frizz_hair_curves.links.new(accumulate_field_001_1.outputs[2], sample_index_2.inputs[1])
	    #join_geometry_2.Geometry -> group_output_13.Geometry
	    frizz_hair_curves.links.new(join_geometry_2.outputs[0], group_output_13.inputs[0])
	    #reroute_003_5.Output -> vector_math_016_1.Vector
	    frizz_hair_curves.links.new(reroute_003_5.outputs[0], vector_math_016_1.inputs[0])
	    #field_at_index.Value -> vector_math_016_1.Vector
	    frizz_hair_curves.links.new(field_at_index.outputs[0], vector_math_016_1.inputs[1])
	    #vector_math_016_1.Vector -> switch_6.False
	    frizz_hair_curves.links.new(vector_math_016_1.outputs[0], switch_6.inputs[1])
	    #group_005_1.Curves -> switch_001_7.True
	    frizz_hair_curves.links.new(group_005_1.outputs[0], switch_001_7.inputs[2])
	    #group_input_001_5.Factor -> math_001_3.Value
	    frizz_hair_curves.links.new(group_input_001_5.outputs[2], math_001_3.inputs[0])
	    #group_input_006_3.Distance -> math_001_3.Value
	    frizz_hair_curves.links.new(group_input_006_3.outputs[3], math_001_3.inputs[1])
	    #switch_6.Output -> vector_math_017_1.Vector
	    frizz_hair_curves.links.new(switch_6.outputs[0], vector_math_017_1.inputs[0])
	    #group_4.Value -> vector_math_017_1.Scale
	    frizz_hair_curves.links.new(group_4.outputs[0], vector_math_017_1.inputs[3])
	    #group_input_007_3.Shape -> group_4.Shape
	    frizz_hair_curves.links.new(group_input_007_3.outputs[4], group_4.inputs[3])
	    #spline_resolution_1.Resolution -> capture_attribute_002_3.Value
	    frizz_hair_curves.links.new(spline_resolution_1.outputs[0], capture_attribute_002_3.inputs[1])
	    #set_spline_type_001_1.Curve -> set_spline_resolution_001_1.Geometry
	    frizz_hair_curves.links.new(set_spline_type_001_1.outputs[0], set_spline_resolution_001_1.inputs[0])
	    #capture_attribute_002_3.Geometry -> set_spline_type.Curve
	    frizz_hair_curves.links.new(capture_attribute_002_3.outputs[0], set_spline_type.inputs[0])
	    #switch_001_7.Output -> set_spline_type_001_1.Curve
	    frizz_hair_curves.links.new(switch_001_7.outputs[0], set_spline_type_001_1.inputs[0])
	    #capture_attribute_002_3.Value -> reroute_002_5.Input
	    frizz_hair_curves.links.new(capture_attribute_002_3.outputs[1], reroute_002_5.inputs[0])
	    #reroute_002_5.Output -> compare_003_3.A
	    frizz_hair_curves.links.new(reroute_002_5.outputs[0], compare_003_3.inputs[2])
	    #compare_003_3.Result -> switch_004_2.Switch
	    frizz_hair_curves.links.new(compare_003_3.outputs[0], switch_004_2.inputs[0])
	    #reroute_002_5.Output -> switch_004_2.False
	    frizz_hair_curves.links.new(reroute_002_5.outputs[0], switch_004_2.inputs[1])
	    #switch_004_2.Output -> set_spline_resolution_001_1.Resolution
	    frizz_hair_curves.links.new(switch_004_2.outputs[0], set_spline_resolution_001_1.inputs[2])
	    #position_001_2.Position -> capture_attribute_003_1.Value
	    frizz_hair_curves.links.new(position_001_2.outputs[0], capture_attribute_003_1.inputs[1])
	    #position_002_4.Position -> vector_math_007_4.Vector
	    frizz_hair_curves.links.new(position_002_4.outputs[0], vector_math_007_4.inputs[0])
	    #reroute_015_4.Output -> vector_math_007_4.Vector
	    frizz_hair_curves.links.new(reroute_015_4.outputs[0], vector_math_007_4.inputs[1])
	    #vector_math_007_4.Vector -> capture_attribute_001_3.Value
	    frizz_hair_curves.links.new(vector_math_007_4.outputs[0], capture_attribute_001_3.inputs[1])
	    #separate_components_3.Curve -> capture_attribute_003_1.Geometry
	    frizz_hair_curves.links.new(separate_components_3.outputs[1], capture_attribute_003_1.inputs[0])
	    #capture_attribute_003_1.Geometry -> capture_attribute_002_3.Geometry
	    frizz_hair_curves.links.new(capture_attribute_003_1.outputs[0], capture_attribute_002_3.inputs[0])
	    #set_spline_resolution_001_1.Geometry -> capture_attribute_001_3.Geometry
	    frizz_hair_curves.links.new(set_spline_resolution_001_1.outputs[0], capture_attribute_001_3.inputs[0])
	    #capture_attribute_001_3.Value -> group_output_13.Offset Vector
	    frizz_hair_curves.links.new(capture_attribute_001_3.outputs[1], group_output_13.inputs[1])
	    #set_position_4.Geometry -> reroute_004_6.Input
	    frizz_hair_curves.links.new(set_position_4.outputs[0], reroute_004_6.inputs[0])
	    #capture_attribute_003_1.Value -> reroute_015_4.Input
	    frizz_hair_curves.links.new(capture_attribute_003_1.outputs[1], reroute_015_4.inputs[0])
	    #vector_math_012_2.Vector -> reroute_003_5.Input
	    frizz_hair_curves.links.new(vector_math_012_2.outputs[0], reroute_003_5.inputs[0])
	    #group_input_003_5.Seed -> random_value_004_2.ID
	    frizz_hair_curves.links.new(group_input_003_5.outputs[5], random_value_004_2.inputs[7])
	    #reroute_007_4.Output -> join_geometry_2.Geometry
	    frizz_hair_curves.links.new(reroute_007_4.outputs[0], join_geometry_2.inputs[0])
	    #capture_attribute_001_3.Geometry -> join_geometry_2.Geometry
	    frizz_hair_curves.links.new(capture_attribute_001_3.outputs[0], join_geometry_2.inputs[0])
	    #reroute_008_4.Output -> join_geometry_2.Geometry
	    frizz_hair_curves.links.new(reroute_008_4.outputs[0], join_geometry_2.inputs[0])
	    #reroute_006_4.Output -> join_geometry_2.Geometry
	    frizz_hair_curves.links.new(reroute_006_4.outputs[0], join_geometry_2.inputs[0])
	    return frizz_hair_curves
	
	frizz_hair_curves = frizz_hair_curves_node_group()
	
	#initialize smooth_hair_curves node group
	def smooth_hair_curves_node_group():
	    smooth_hair_curves = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Smooth Hair Curves")
	
	    smooth_hair_curves.color_tag = 'NONE'
	    smooth_hair_curves.description = "Smoothes the shape of hair curves"
	    smooth_hair_curves.default_group_node_width = 140
	    
	
	    smooth_hair_curves.is_modifier = True
	
	    #smooth_hair_curves interface
	    #Socket Geometry
	    geometry_socket_15 = smooth_hair_curves.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_15.attribute_domain = 'POINT'
	
	    #Socket Geometry
	    geometry_socket_16 = smooth_hair_curves.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_16.attribute_domain = 'POINT'
	    geometry_socket_16.description = "Input Geometry (May include other than curves)"
	
	    #Socket Amount
	    amount_socket_1 = smooth_hair_curves.interface.new_socket(name = "Amount", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    amount_socket_1.default_value = 1.0
	    amount_socket_1.min_value = -1.0
	    amount_socket_1.max_value = 1.0
	    amount_socket_1.subtype = 'FACTOR'
	    amount_socket_1.attribute_domain = 'POINT'
	    amount_socket_1.description = "Amount of smoothing"
	
	    #Socket Shape
	    shape_socket_3 = smooth_hair_curves.interface.new_socket(name = "Shape", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    shape_socket_3.default_value = 0.0
	    shape_socket_3.min_value = -1.0
	    shape_socket_3.max_value = 1.0
	    shape_socket_3.subtype = 'NONE'
	    shape_socket_3.attribute_domain = 'POINT'
	    shape_socket_3.description = "Shape of the influence along curves (0=constant, 0.5=linear)"
	
	    #Socket Iterations
	    iterations_socket = smooth_hair_curves.interface.new_socket(name = "Iterations", in_out='INPUT', socket_type = 'NodeSocketInt')
	    iterations_socket.default_value = 10
	    iterations_socket.min_value = 0
	    iterations_socket.max_value = 10000
	    iterations_socket.subtype = 'NONE'
	    iterations_socket.attribute_domain = 'POINT'
	    iterations_socket.description = "Amount of smoothing steps"
	
	    #Socket Weight
	    weight_socket = smooth_hair_curves.interface.new_socket(name = "Weight", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    weight_socket.default_value = 0.5
	    weight_socket.min_value = 0.0
	    weight_socket.max_value = 1.0
	    weight_socket.subtype = 'FACTOR'
	    weight_socket.attribute_domain = 'POINT'
	    weight_socket.description = "Weight used for smoothing"
	
	    #Socket Lock Tips
	    lock_tips_socket = smooth_hair_curves.interface.new_socket(name = "Lock Tips", in_out='INPUT', socket_type = 'NodeSocketBool')
	    lock_tips_socket.default_value = False
	    lock_tips_socket.attribute_domain = 'POINT'
	    lock_tips_socket.description = "Lock tip position when smoothing"
	
	    #Socket Preserve Length
	    preserve_length_socket_2 = smooth_hair_curves.interface.new_socket(name = "Preserve Length", in_out='INPUT', socket_type = 'NodeSocketBool')
	    preserve_length_socket_2.default_value = True
	    preserve_length_socket_2.attribute_domain = 'POINT'
	    preserve_length_socket_2.description = "Preserve each curve's length during deformation"
	
	
	    #initialize smooth_hair_curves nodes
	    #node Frame
	    frame_7 = smooth_hair_curves.nodes.new("NodeFrame")
	    frame_7.label = "Optimization"
	    frame_7.name = "Frame"
	    frame_7.label_size = 20
	    frame_7.shrink = True
	
	    #node Frame.006
	    frame_006_4 = smooth_hair_curves.nodes.new("NodeFrame")
	    frame_006_4.label = "Smooth Weight"
	    frame_006_4.name = "Frame.006"
	    frame_006_4.label_size = 20
	    frame_006_4.shrink = True
	
	    #node Frame.001
	    frame_001_4 = smooth_hair_curves.nodes.new("NodeFrame")
	    frame_001_4.label = "Optimization"
	    frame_001_4.name = "Frame.001"
	    frame_001_4.label_size = 20
	    frame_001_4.shrink = True
	
	    #node Frame.002
	    frame_002_5 = smooth_hair_curves.nodes.new("NodeFrame")
	    frame_002_5.label = "Optimization"
	    frame_002_5.name = "Frame.002"
	    frame_002_5.label_size = 20
	    frame_002_5.shrink = True
	
	    #node Frame.003
	    frame_003_4 = smooth_hair_curves.nodes.new("NodeFrame")
	    frame_003_4.label = "Length Preservation"
	    frame_003_4.name = "Frame.003"
	    frame_003_4.label_size = 20
	    frame_003_4.shrink = True
	
	    #node Frame.005
	    frame_005_3 = smooth_hair_curves.nodes.new("NodeFrame")
	    frame_005_3.label = "Blurred Position Attribute"
	    frame_005_3.name = "Frame.005"
	    frame_005_3.label_size = 20
	    frame_005_3.shrink = True
	
	    #node Frame.004
	    frame_004_4 = smooth_hair_curves.nodes.new("NodeFrame")
	    frame_004_4.label = "Root Pinning"
	    frame_004_4.name = "Frame.004"
	    frame_004_4.label_size = 20
	    frame_004_4.shrink = True
	
	    #node Frame.007
	    frame_007_3 = smooth_hair_curves.nodes.new("NodeFrame")
	    frame_007_3.label = "Smoothing Mask"
	    frame_007_3.name = "Frame.007"
	    frame_007_3.label_size = 20
	    frame_007_3.shrink = True
	
	    #node Group Input
	    group_input_10 = smooth_hair_curves.nodes.new("NodeGroupInput")
	    group_input_10.name = "Group Input"
	    group_input_10.outputs[1].hide = True
	    group_input_10.outputs[2].hide = True
	    group_input_10.outputs[3].hide = True
	    group_input_10.outputs[4].hide = True
	    group_input_10.outputs[5].hide = True
	    group_input_10.outputs[6].hide = True
	    group_input_10.outputs[7].hide = True
	
	    #node Separate Components
	    separate_components_4 = smooth_hair_curves.nodes.new("GeometryNodeSeparateComponents")
	    separate_components_4.name = "Separate Components"
	    separate_components_4.hide = True
	
	    #node Reroute.012
	    reroute_012_6 = smooth_hair_curves.nodes.new("NodeReroute")
	    reroute_012_6.name = "Reroute.012"
	    reroute_012_6.socket_idname = "NodeSocketGeometry"
	    #node Reroute.010
	    reroute_010_4 = smooth_hair_curves.nodes.new("NodeReroute")
	    reroute_010_4.name = "Reroute.010"
	    reroute_010_4.socket_idname = "NodeSocketGeometry"
	    #node Reroute.011
	    reroute_011_5 = smooth_hair_curves.nodes.new("NodeReroute")
	    reroute_011_5.name = "Reroute.011"
	    reroute_011_5.socket_idname = "NodeSocketGeometry"
	    #node Reroute.013
	    reroute_013_5 = smooth_hair_curves.nodes.new("NodeReroute")
	    reroute_013_5.name = "Reroute.013"
	    reroute_013_5.socket_idname = "NodeSocketGeometry"
	    #node Reroute.007
	    reroute_007_5 = smooth_hair_curves.nodes.new("NodeReroute")
	    reroute_007_5.name = "Reroute.007"
	    reroute_007_5.socket_idname = "NodeSocketGeometry"
	    #node Reroute.009
	    reroute_009_5 = smooth_hair_curves.nodes.new("NodeReroute")
	    reroute_009_5.name = "Reroute.009"
	    reroute_009_5.socket_idname = "NodeSocketGeometry"
	    #node Reroute.006
	    reroute_006_5 = smooth_hair_curves.nodes.new("NodeReroute")
	    reroute_006_5.name = "Reroute.006"
	    reroute_006_5.socket_idname = "NodeSocketGeometry"
	    #node Reroute.008
	    reroute_008_5 = smooth_hair_curves.nodes.new("NodeReroute")
	    reroute_008_5.name = "Reroute.008"
	    reroute_008_5.socket_idname = "NodeSocketGeometry"
	    #node Capture Attribute.001
	    capture_attribute_001_4 = smooth_hair_curves.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_001_4.name = "Capture Attribute.001"
	    capture_attribute_001_4.active_index = 0
	    capture_attribute_001_4.capture_items.clear()
	    capture_attribute_001_4.capture_items.new('FLOAT', "Value")
	    capture_attribute_001_4.capture_items["Value"].data_type = 'FLOAT_VECTOR'
	    capture_attribute_001_4.domain = 'POINT'
	
	    #node Position.007
	    position_007 = smooth_hair_curves.nodes.new("GeometryNodeInputPosition")
	    position_007.name = "Position.007"
	
	    #node Set Spline Resolution.001
	    set_spline_resolution_001_2 = smooth_hair_curves.nodes.new("GeometryNodeSetSplineResolution")
	    set_spline_resolution_001_2.name = "Set Spline Resolution.001"
	    set_spline_resolution_001_2.inputs[1].hide = True
	    #Selection
	    set_spline_resolution_001_2.inputs[1].default_value = True
	
	    #node Set Spline Type
	    set_spline_type_1 = smooth_hair_curves.nodes.new("GeometryNodeCurveSplineType")
	    set_spline_type_1.name = "Set Spline Type"
	    set_spline_type_1.spline_type = 'CATMULL_ROM'
	    set_spline_type_1.inputs[1].hide = True
	    #Selection
	    set_spline_type_1.inputs[1].default_value = True
	
	    #node Compare.003
	    compare_003_4 = smooth_hair_curves.nodes.new("FunctionNodeCompare")
	    compare_003_4.name = "Compare.003"
	    compare_003_4.data_type = 'INT'
	    compare_003_4.mode = 'ELEMENT'
	    compare_003_4.operation = 'EQUAL'
	    #B_INT
	    compare_003_4.inputs[3].default_value = 0
	
	    #node Switch.004
	    switch_004_3 = smooth_hair_curves.nodes.new("GeometryNodeSwitch")
	    switch_004_3.name = "Switch.004"
	    switch_004_3.input_type = 'INT'
	    #True
	    switch_004_3.inputs[2].default_value = 12
	
	    #node Reroute.028
	    reroute_028_2 = smooth_hair_curves.nodes.new("NodeReroute")
	    reroute_028_2.name = "Reroute.028"
	    reroute_028_2.socket_idname = "NodeSocketInt"
	    #node Group.005
	    group_005_2 = smooth_hair_curves.nodes.new("GeometryNodeGroup")
	    group_005_2.name = "Group.005"
	    group_005_2.node_tree = shape_range
	    group_005_2.inputs[1].hide = True
	    group_005_2.inputs[2].hide = True
	    group_005_2.inputs[4].hide = True
	    #Socket_2
	    group_005_2.inputs[1].default_value = 0.0
	    #Socket_3
	    group_005_2.inputs[2].default_value = 1.0
	    #Socket_5
	    group_005_2.inputs[4].default_value = 2.7182817459106445
	
	    #node Boolean Math
	    boolean_math_5 = smooth_hair_curves.nodes.new("FunctionNodeBooleanMath")
	    boolean_math_5.name = "Boolean Math"
	    boolean_math_5.operation = 'NOT'
	
	    #node Group Input.005
	    group_input_005_4 = smooth_hair_curves.nodes.new("NodeGroupInput")
	    group_input_005_4.name = "Group Input.005"
	    group_input_005_4.outputs[0].hide = True
	    group_input_005_4.outputs[1].hide = True
	    group_input_005_4.outputs[3].hide = True
	    group_input_005_4.outputs[4].hide = True
	    group_input_005_4.outputs[5].hide = True
	    group_input_005_4.outputs[6].hide = True
	    group_input_005_4.outputs[7].hide = True
	
	    #node Spline Parameter.002
	    spline_parameter_002 = smooth_hair_curves.nodes.new("GeometryNodeSplineParameter")
	    spline_parameter_002.name = "Spline Parameter.002"
	    spline_parameter_002.outputs[1].hide = True
	    spline_parameter_002.outputs[2].hide = True
	
	    #node Math
	    math_5 = smooth_hair_curves.nodes.new("ShaderNodeMath")
	    math_5.name = "Math"
	    math_5.operation = 'MULTIPLY'
	    math_5.use_clamp = False
	
	    #node Math.007
	    math_007_1 = smooth_hair_curves.nodes.new("ShaderNodeMath")
	    math_007_1.name = "Math.007"
	    math_007_1.operation = 'MULTIPLY'
	    math_007_1.use_clamp = False
	
	    #node Math.006
	    math_006_1 = smooth_hair_curves.nodes.new("ShaderNodeMath")
	    math_006_1.name = "Math.006"
	    math_006_1.operation = 'MULTIPLY'
	    math_006_1.use_clamp = False
	
	    #node Group Input.016
	    group_input_016 = smooth_hair_curves.nodes.new("NodeGroupInput")
	    group_input_016.name = "Group Input.016"
	    group_input_016.outputs[0].hide = True
	    group_input_016.outputs[1].hide = True
	    group_input_016.outputs[2].hide = True
	    group_input_016.outputs[3].hide = True
	    group_input_016.outputs[5].hide = True
	    group_input_016.outputs[6].hide = True
	    group_input_016.outputs[7].hide = True
	
	    #node Spline Resolution
	    spline_resolution_2 = smooth_hair_curves.nodes.new("GeometryNodeInputSplineResolution")
	    spline_resolution_2.name = "Spline Resolution"
	
	    #node Capture Attribute.002
	    capture_attribute_002_4 = smooth_hair_curves.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_002_4.name = "Capture Attribute.002"
	    capture_attribute_002_4.active_index = 0
	    capture_attribute_002_4.capture_items.clear()
	    capture_attribute_002_4.capture_items.new('FLOAT', "Value")
	    capture_attribute_002_4.capture_items["Value"].data_type = 'INT'
	    capture_attribute_002_4.domain = 'CURVE'
	
	    #node Set Spline Type.001
	    set_spline_type_001_2 = smooth_hair_curves.nodes.new("GeometryNodeCurveSplineType")
	    set_spline_type_001_2.name = "Set Spline Type.001"
	    set_spline_type_001_2.spline_type = 'POLY'
	    #Selection
	    set_spline_type_001_2.inputs[1].default_value = True
	
	    #node Group Output.001
	    group_output_001_1 = smooth_hair_curves.nodes.new("NodeGroupOutput")
	    group_output_001_1.name = "Group Output.001"
	    group_output_001_1.is_active_output = True
	
	    #node Join Geometry
	    join_geometry_3 = smooth_hair_curves.nodes.new("GeometryNodeJoinGeometry")
	    join_geometry_3.name = "Join Geometry"
	
	    #node Switch
	    switch_7 = smooth_hair_curves.nodes.new("GeometryNodeSwitch")
	    switch_7.name = "Switch"
	    switch_7.input_type = 'GEOMETRY'
	
	    #node Compare.008
	    compare_008 = smooth_hair_curves.nodes.new("FunctionNodeCompare")
	    compare_008.name = "Compare.008"
	    compare_008.hide = True
	    compare_008.data_type = 'FLOAT'
	    compare_008.mode = 'ELEMENT'
	    compare_008.operation = 'NOT_EQUAL'
	    #B
	    compare_008.inputs[1].default_value = 0.0
	    #Epsilon
	    compare_008.inputs[12].default_value = 0.0
	
	    #node Accumulate Field
	    accumulate_field_3 = smooth_hair_curves.nodes.new("GeometryNodeAccumulateField")
	    accumulate_field_3.name = "Accumulate Field"
	    accumulate_field_3.hide = True
	    accumulate_field_3.data_type = 'INT'
	    accumulate_field_3.domain = 'CURVE'
	    accumulate_field_3.inputs[1].hide = True
	    accumulate_field_3.outputs[0].hide = True
	    accumulate_field_3.outputs[1].hide = True
	    #Group Index
	    accumulate_field_3.inputs[1].default_value = 0
	
	    #node Reroute
	    reroute_10 = smooth_hair_curves.nodes.new("NodeReroute")
	    reroute_10.name = "Reroute"
	    reroute_10.socket_idname = "NodeSocketGeometry"
	    #node Group Input.007
	    group_input_007_4 = smooth_hair_curves.nodes.new("NodeGroupInput")
	    group_input_007_4.name = "Group Input.007"
	    group_input_007_4.outputs[0].hide = True
	    group_input_007_4.outputs[2].hide = True
	    group_input_007_4.outputs[3].hide = True
	    group_input_007_4.outputs[4].hide = True
	    group_input_007_4.outputs[5].hide = True
	    group_input_007_4.outputs[6].hide = True
	    group_input_007_4.outputs[7].hide = True
	
	    #node Group Input.008
	    group_input_008_3 = smooth_hair_curves.nodes.new("NodeGroupInput")
	    group_input_008_3.name = "Group Input.008"
	    group_input_008_3.outputs[1].hide = True
	    group_input_008_3.outputs[2].hide = True
	    group_input_008_3.outputs[3].hide = True
	    group_input_008_3.outputs[4].hide = True
	    group_input_008_3.outputs[5].hide = True
	    group_input_008_3.outputs[6].hide = True
	    group_input_008_3.outputs[7].hide = True
	
	    #node Boolean Math.001
	    boolean_math_001_1 = smooth_hair_curves.nodes.new("FunctionNodeBooleanMath")
	    boolean_math_001_1.name = "Boolean Math.001"
	    boolean_math_001_1.operation = 'OR'
	
	    #node Group Input.003
	    group_input_003_6 = smooth_hair_curves.nodes.new("NodeGroupInput")
	    group_input_003_6.name = "Group Input.003"
	    group_input_003_6.outputs[0].hide = True
	    group_input_003_6.outputs[1].hide = True
	    group_input_003_6.outputs[2].hide = True
	    group_input_003_6.outputs[4].hide = True
	    group_input_003_6.outputs[5].hide = True
	    group_input_003_6.outputs[6].hide = True
	    group_input_003_6.outputs[7].hide = True
	
	    #node Compare
	    compare_6 = smooth_hair_curves.nodes.new("FunctionNodeCompare")
	    compare_6.name = "Compare"
	    compare_6.data_type = 'INT'
	    compare_6.mode = 'ELEMENT'
	    compare_6.operation = 'EQUAL'
	    #B_INT
	    compare_6.inputs[3].default_value = 0
	
	    #node Sample Index
	    sample_index_3 = smooth_hair_curves.nodes.new("GeometryNodeSampleIndex")
	    sample_index_3.name = "Sample Index"
	    sample_index_3.hide = True
	    sample_index_3.clamp = False
	    sample_index_3.data_type = 'INT'
	    sample_index_3.domain = 'CURVE'
	    #Index
	    sample_index_3.inputs[2].default_value = 0
	
	    #node Compare.004
	    compare_004_4 = smooth_hair_curves.nodes.new("FunctionNodeCompare")
	    compare_004_4.name = "Compare.004"
	    compare_004_4.hide = True
	    compare_004_4.data_type = 'INT'
	    compare_004_4.mode = 'ELEMENT'
	    compare_004_4.operation = 'EQUAL'
	    #B_INT
	    compare_004_4.inputs[3].default_value = 0
	
	    #node Group.001
	    group_001_5 = smooth_hair_curves.nodes.new("GeometryNodeGroup")
	    group_001_5.name = "Group.001"
	    group_001_5.node_tree = restore_curve_segment_length
	    #Socket_3
	    group_001_5.inputs[2].default_value = 1.0
	    #Socket_5
	    group_001_5.inputs[4].default_value = 0.0
	
	    #node Boolean Math.004
	    boolean_math_004 = smooth_hair_curves.nodes.new("FunctionNodeBooleanMath")
	    boolean_math_004.name = "Boolean Math.004"
	    boolean_math_004.hide = True
	    boolean_math_004.operation = 'AND'
	
	    #node Group Input.012
	    group_input_012_1 = smooth_hair_curves.nodes.new("NodeGroupInput")
	    group_input_012_1.name = "Group Input.012"
	    group_input_012_1.outputs[0].hide = True
	    group_input_012_1.outputs[1].hide = True
	    group_input_012_1.outputs[2].hide = True
	    group_input_012_1.outputs[3].hide = True
	    group_input_012_1.outputs[4].hide = True
	    group_input_012_1.outputs[5].hide = True
	    group_input_012_1.outputs[7].hide = True
	
	    #node Set Position.005
	    set_position_005 = smooth_hair_curves.nodes.new("GeometryNodeSetPosition")
	    set_position_005.name = "Set Position.005"
	    set_position_005.inputs[2].hide = True
	    #Position
	    set_position_005.inputs[2].default_value = (0.0, 0.0, 0.0)
	
	    #node Vector Math.002
	    vector_math_002_5 = smooth_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_002_5.name = "Vector Math.002"
	    vector_math_002_5.operation = 'SUBTRACT'
	
	    #node Vector Math.003
	    vector_math_003_5 = smooth_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_003_5.name = "Vector Math.003"
	    vector_math_003_5.operation = 'SCALE'
	
	    #node Group Input.001
	    group_input_001_6 = smooth_hair_curves.nodes.new("NodeGroupInput")
	    group_input_001_6.name = "Group Input.001"
	    group_input_001_6.outputs[0].hide = True
	    group_input_001_6.outputs[2].hide = True
	    group_input_001_6.outputs[3].hide = True
	    group_input_001_6.outputs[4].hide = True
	    group_input_001_6.outputs[5].hide = True
	    group_input_001_6.outputs[6].hide = True
	    group_input_001_6.outputs[7].hide = True
	
	    #node Position.008
	    position_008 = smooth_hair_curves.nodes.new("GeometryNodeInputPosition")
	    position_008.name = "Position.008"
	
	    #node Blur Attribute.004
	    blur_attribute_004 = smooth_hair_curves.nodes.new("GeometryNodeBlurAttribute")
	    blur_attribute_004.name = "Blur Attribute.004"
	    blur_attribute_004.data_type = 'FLOAT_VECTOR'
	
	    #node Group Input.002
	    group_input_002_5 = smooth_hair_curves.nodes.new("NodeGroupInput")
	    group_input_002_5.name = "Group Input.002"
	    group_input_002_5.outputs[0].hide = True
	    group_input_002_5.outputs[1].hide = True
	    group_input_002_5.outputs[2].hide = True
	    group_input_002_5.outputs[4].hide = True
	    group_input_002_5.outputs[5].hide = True
	    group_input_002_5.outputs[6].hide = True
	    group_input_002_5.outputs[7].hide = True
	
	    #node Position.006
	    position_006 = smooth_hair_curves.nodes.new("GeometryNodeInputPosition")
	    position_006.name = "Position.006"
	
	    #node Vector Math.001
	    vector_math_001_5 = smooth_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_001_5.name = "Vector Math.001"
	    vector_math_001_5.operation = 'SUBTRACT'
	
	    #node Field at Index.001
	    field_at_index_001_1 = smooth_hair_curves.nodes.new("GeometryNodeFieldAtIndex")
	    field_at_index_001_1.name = "Field at Index.001"
	    field_at_index_001_1.hide = True
	    field_at_index_001_1.data_type = 'FLOAT_VECTOR'
	    field_at_index_001_1.domain = 'POINT'
	
	    #node Field at Index.002
	    field_at_index_002_1 = smooth_hair_curves.nodes.new("GeometryNodeFieldAtIndex")
	    field_at_index_002_1.name = "Field at Index.002"
	    field_at_index_002_1.hide = True
	    field_at_index_002_1.data_type = 'FLOAT_VECTOR'
	    field_at_index_002_1.domain = 'POINT'
	
	    #node Vector Math
	    vector_math_7 = smooth_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_7.name = "Vector Math"
	    vector_math_7.operation = 'SUBTRACT'
	
	    #node Reroute.003
	    reroute_003_6 = smooth_hair_curves.nodes.new("NodeReroute")
	    reroute_003_6.name = "Reroute.003"
	    reroute_003_6.socket_idname = "NodeSocketBool"
	    #node Reroute.004
	    reroute_004_7 = smooth_hair_curves.nodes.new("NodeReroute")
	    reroute_004_7.name = "Reroute.004"
	    reroute_004_7.socket_idname = "NodeSocketBool"
	    #node Reroute.001
	    reroute_001_7 = smooth_hair_curves.nodes.new("NodeReroute")
	    reroute_001_7.name = "Reroute.001"
	    reroute_001_7.socket_idname = "NodeSocketInt"
	    #node Reroute.021
	    reroute_021_2 = smooth_hair_curves.nodes.new("NodeReroute")
	    reroute_021_2.name = "Reroute.021"
	    reroute_021_2.socket_idname = "NodeSocketVector"
	    #node Reroute.016
	    reroute_016_4 = smooth_hair_curves.nodes.new("NodeReroute")
	    reroute_016_4.name = "Reroute.016"
	    reroute_016_4.socket_idname = "NodeSocketVector"
	    #node Reroute.014
	    reroute_014_4 = smooth_hair_curves.nodes.new("NodeReroute")
	    reroute_014_4.name = "Reroute.014"
	    reroute_014_4.socket_idname = "NodeSocketBool"
	    #node Reroute.005
	    reroute_005_5 = smooth_hair_curves.nodes.new("NodeReroute")
	    reroute_005_5.name = "Reroute.005"
	    reroute_005_5.socket_idname = "NodeSocketBool"
	    #node Reroute.002
	    reroute_002_6 = smooth_hair_curves.nodes.new("NodeReroute")
	    reroute_002_6.name = "Reroute.002"
	    reroute_002_6.socket_idname = "NodeSocketVector"
	    #node Reroute.017
	    reroute_017_4 = smooth_hair_curves.nodes.new("NodeReroute")
	    reroute_017_4.name = "Reroute.017"
	    reroute_017_4.socket_idname = "NodeSocketVector"
	    #node Reroute.015
	    reroute_015_5 = smooth_hair_curves.nodes.new("NodeReroute")
	    reroute_015_5.name = "Reroute.015"
	    reroute_015_5.socket_idname = "NodeSocketInt"
	    #node Reroute.018
	    reroute_018_4 = smooth_hair_curves.nodes.new("NodeReroute")
	    reroute_018_4.name = "Reroute.018"
	    reroute_018_4.socket_idname = "NodeSocketBool"
	    #node Reroute.020
	    reroute_020_3 = smooth_hair_curves.nodes.new("NodeReroute")
	    reroute_020_3.name = "Reroute.020"
	    reroute_020_3.socket_idname = "NodeSocketBool"
	    #node Boolean Math.005
	    boolean_math_005 = smooth_hair_curves.nodes.new("FunctionNodeBooleanMath")
	    boolean_math_005.name = "Boolean Math.005"
	    boolean_math_005.hide = True
	    boolean_math_005.operation = 'AND'
	
	    #node Compare.006
	    compare_006_1 = smooth_hair_curves.nodes.new("FunctionNodeCompare")
	    compare_006_1.name = "Compare.006"
	    compare_006_1.data_type = 'FLOAT'
	    compare_006_1.mode = 'ELEMENT'
	    compare_006_1.operation = 'GREATER_THAN'
	    #B
	    compare_006_1.inputs[1].default_value = 0.0
	
	    #node Compare.007
	    compare_007_1 = smooth_hair_curves.nodes.new("FunctionNodeCompare")
	    compare_007_1.name = "Compare.007"
	    compare_007_1.data_type = 'FLOAT'
	    compare_007_1.mode = 'ELEMENT'
	    compare_007_1.operation = 'NOT_EQUAL'
	    #B
	    compare_007_1.inputs[1].default_value = 0.0
	    #Epsilon
	    compare_007_1.inputs[12].default_value = 0.0
	
	    #node Group Input.006
	    group_input_006_4 = smooth_hair_curves.nodes.new("NodeGroupInput")
	    group_input_006_4.name = "Group Input.006"
	    group_input_006_4.outputs[0].hide = True
	    group_input_006_4.outputs[2].hide = True
	    group_input_006_4.outputs[3].hide = True
	    group_input_006_4.outputs[4].hide = True
	    group_input_006_4.outputs[5].hide = True
	    group_input_006_4.outputs[6].hide = True
	    group_input_006_4.outputs[7].hide = True
	
	    #node Group Input.015
	    group_input_015 = smooth_hair_curves.nodes.new("NodeGroupInput")
	    group_input_015.name = "Group Input.015"
	    group_input_015.outputs[0].hide = True
	    group_input_015.outputs[1].hide = True
	    group_input_015.outputs[2].hide = True
	    group_input_015.outputs[3].hide = True
	    group_input_015.outputs[5].hide = True
	    group_input_015.outputs[6].hide = True
	    group_input_015.outputs[7].hide = True
	
	    #node Group Input.013
	    group_input_013_1 = smooth_hair_curves.nodes.new("NodeGroupInput")
	    group_input_013_1.name = "Group Input.013"
	    group_input_013_1.outputs[0].hide = True
	    group_input_013_1.outputs[1].hide = True
	    group_input_013_1.outputs[2].hide = True
	    group_input_013_1.outputs[3].hide = True
	    group_input_013_1.outputs[4].hide = True
	    group_input_013_1.outputs[6].hide = True
	    group_input_013_1.outputs[7].hide = True
	
	    #node Boolean Math.002
	    boolean_math_002_3 = smooth_hair_curves.nodes.new("FunctionNodeBooleanMath")
	    boolean_math_002_3.name = "Boolean Math.002"
	    boolean_math_002_3.hide = True
	    boolean_math_002_3.operation = 'NOT'
	
	    #node Boolean Math.003
	    boolean_math_003 = smooth_hair_curves.nodes.new("FunctionNodeBooleanMath")
	    boolean_math_003.name = "Boolean Math.003"
	    boolean_math_003.hide = True
	    boolean_math_003.operation = 'AND'
	
	    #node Group
	    group_5 = smooth_hair_curves.nodes.new("GeometryNodeGroup")
	    group_5.name = "Group"
	    group_5.node_tree = curve_tip
	    group_5.outputs[1].hide = True
	    group_5.outputs[2].hide = True
	    group_5.outputs[3].hide = True
	
	    #node Boolean Math.007
	    boolean_math_007 = smooth_hair_curves.nodes.new("FunctionNodeBooleanMath")
	    boolean_math_007.name = "Boolean Math.007"
	    boolean_math_007.hide = True
	    boolean_math_007.operation = 'AND'
	
	    #node Group.004
	    group_004 = smooth_hair_curves.nodes.new("GeometryNodeGroup")
	    group_004.name = "Group.004"
	    group_004.node_tree = curve_root
	    group_004.outputs[0].hide = True
	    group_004.outputs[1].hide = True
	    group_004.outputs[2].hide = True
	
	    #node Group.006
	    group_006_1 = smooth_hair_curves.nodes.new("GeometryNodeGroup")
	    group_006_1.name = "Group.006"
	    group_006_1.node_tree = curve_root
	    group_006_1.outputs[1].hide = True
	    group_006_1.outputs[2].hide = True
	    group_006_1.outputs[3].hide = True
	
	
	
	
	    #Set parents
	    frame_004_4.parent = frame_005_3
	    set_spline_resolution_001_2.parent = frame_7
	    set_spline_type_1.parent = frame_7
	    compare_003_4.parent = frame_7
	    switch_004_3.parent = frame_7
	    reroute_028_2.parent = frame_7
	    group_005_2.parent = frame_006_4
	    boolean_math_5.parent = frame_006_4
	    group_input_005_4.parent = frame_006_4
	    spline_parameter_002.parent = frame_006_4
	    math_5.parent = frame_006_4
	    math_007_1.parent = frame_006_4
	    math_006_1.parent = frame_006_4
	    group_input_016.parent = frame_006_4
	    spline_resolution_2.parent = frame_001_4
	    capture_attribute_002_4.parent = frame_001_4
	    set_spline_type_001_2.parent = frame_001_4
	    switch_7.parent = frame_002_5
	    compare_008.parent = frame_002_5
	    accumulate_field_3.parent = frame_002_5
	    reroute_10.parent = frame_002_5
	    group_input_007_4.parent = frame_002_5
	    group_input_008_3.parent = frame_002_5
	    boolean_math_001_1.parent = frame_002_5
	    group_input_003_6.parent = frame_002_5
	    compare_6.parent = frame_002_5
	    sample_index_3.parent = frame_002_5
	    compare_004_4.parent = frame_002_5
	    group_001_5.parent = frame_003_4
	    boolean_math_004.parent = frame_003_4
	    group_input_012_1.parent = frame_003_4
	    vector_math_002_5.parent = frame_005_3
	    vector_math_003_5.parent = frame_005_3
	    group_input_001_6.parent = frame_005_3
	    position_008.parent = frame_005_3
	    blur_attribute_004.parent = frame_005_3
	    group_input_002_5.parent = frame_005_3
	    position_006.parent = frame_005_3
	    vector_math_001_5.parent = frame_004_4
	    field_at_index_001_1.parent = frame_004_4
	    field_at_index_002_1.parent = frame_004_4
	    vector_math_7.parent = frame_004_4
	    boolean_math_005.parent = frame_007_3
	    compare_006_1.parent = frame_007_3
	    compare_007_1.parent = frame_007_3
	    group_input_006_4.parent = frame_007_3
	    group_input_015.parent = frame_007_3
	    group_input_013_1.parent = frame_007_3
	    boolean_math_002_3.parent = frame_007_3
	    boolean_math_003.parent = frame_007_3
	    group_5.parent = frame_007_3
	    boolean_math_007.parent = frame_007_3
	    group_004.parent = frame_004_4
	    group_006_1.parent = frame_006_4
	
	    #Set locations
	    frame_7.location = (-1588.4208984375, -82.0)
	    frame_006_4.location = (-5210.0, -826.0)
	    frame_001_4.location = (-5753.0, -22.0)
	    frame_002_5.location = (-770.0, 299.0)
	    frame_003_4.location = (-2257.0, -103.0)
	    frame_005_3.location = (-4467.0, -374.0)
	    frame_004_4.location = (387.0, -40.0)
	    frame_007_3.location = (-5933.0, -323.0)
	    group_input_10.location = (-6697.2431640625, 48.27825927734375)
	    separate_components_4.location = (-6255.1962890625, 48.27825927734375)
	    reroute_012_6.location = (-5973.89453125, 168.83642578125)
	    reroute_010_4.location = (-5973.89453125, 188.929443359375)
	    reroute_011_5.location = (-5973.89453125, 148.743408203125)
	    reroute_013_5.location = (-5973.89453125, 128.65032958984375)
	    reroute_007_5.location = (-1291.356689453125, 148.743408203125)
	    reroute_009_5.location = (-1291.356689453125, 128.65032958984375)
	    reroute_006_5.location = (-1291.356689453125, 188.929443359375)
	    reroute_008_5.location = (-1291.356689453125, 168.83642578125)
	    capture_attribute_001_4.location = (-4908.9638671875, 8.0921630859375)
	    position_007.location = (-5109.89453125, -132.5589599609375)
	    set_spline_resolution_001_2.location = (252.6748046875, -40.3079833984375)
	    set_spline_type_1.location = (71.83740234375, -40.3079833984375)
	    compare_003_4.location = (71.83740234375, -160.8660888671875)
	    switch_004_3.location = (252.6748046875, -160.8660888671875)
	    reroute_028_2.location = (35.0, -291.6752624511719)
	    group_005_2.location = (230.55615234375, -155.244140625)
	    boolean_math_5.location = (230.55615234375, -275.80224609375)
	    group_input_005_4.location = (29.6259765625, -235.6162109375)
	    spline_parameter_002.location = (29.6259765625, -155.244140625)
	    math_5.location = (441.64501953125, -39.8294677734375)
	    math_007_1.location = (441.64501953125, -180.4805908203125)
	    math_006_1.location = (642.5751953125, -80.0155029296875)
	    group_input_016.location = (240.71435546875, -39.8294677734375)
	    spline_resolution_2.location = (30.00537109375, -183.7294921875)
	    capture_attribute_002_4.location = (221.67578125, -40.06304931640625)
	    set_spline_type_001_2.location = (391.328125, -51.06201171875)
	    group_output_001_1.location = (75.0, 50.0)
	    join_geometry_3.location = (-1031.010009765625, -12.0008544921875)
	    switch_7.location = (614.2080078125, -259.1695556640625)
	    compare_008.location = (251.4814453125, -160.1485595703125)
	    accumulate_field_3.location = (251.4814453125, -200.33465576171875)
	    reroute_10.location = (211.294921875, -200.33465576171875)
	    group_input_007_4.location = (30.4580078125, -99.86956787109375)
	    group_input_008_3.location = (30.4580078125, -160.1485595703125)
	    boolean_math_001_1.location = (432.318359375, -160.1485595703125)
	    group_input_003_6.location = (30.4580078125, -39.59051513671875)
	    compare_6.location = (251.4814453125, -39.59051513671875)
	    sample_index_3.location = (251.4814453125, -240.52069091796875)
	    compare_004_4.location = (251.4814453125, -280.70672607421875)
	    group_001_5.location = (412.22900390625, -39.540557861328125)
	    boolean_math_004.location = (231.39208984375, -140.00570678710938)
	    group_input_012_1.location = (30.4619140625, -99.81967163085938)
	    set_position_005.location = (-2477.707763671875, -112.4659423828125)
	    vector_math_002_5.location = (1316.37939453125, -100.11053466796875)
	    vector_math_003_5.location = (1517.3095703125, -100.11053466796875)
	    group_input_001_6.location = (1316.37939453125, -240.76171875)
	    position_008.location = (1115.44873046875, -240.76171875)
	    blur_attribute_004.location = (211.2626953125, -200.57568359375)
	    group_input_002_5.location = (30.42578125, -240.76171875)
	    position_006.location = (30.42578125, -160.3896484375)
	    vector_math_001_5.location = (607.890625, -40.01751708984375)
	    field_at_index_001_1.location = (246.21630859375, -220.854736328125)
	    field_at_index_002_1.location = (246.21630859375, -261.040771484375)
	    vector_math_7.location = (406.96044921875, -140.482666015625)
	    reroute_003_6.location = (-4527.1962890625, -273.2101745605469)
	    reroute_004_7.location = (-4527.1962890625, -293.3031921386719)
	    reroute_001_7.location = (-4527.1962890625, -333.4892272949219)
	    reroute_021_2.location = (-4527.1962890625, -313.3962097167969)
	    reroute_016_4.location = (-4065.056884765625, -313.3962097167969)
	    reroute_014_4.location = (-2598.266357421875, -273.2101745605469)
	    reroute_005_5.location = (-2598.266357421875, -293.3031921386719)
	    reroute_002_6.location = (-2598.266357421875, -313.3962097167969)
	    reroute_017_4.location = (-2598.266357421875, -353.582275390625)
	    reroute_015_5.location = (-2598.266357421875, -333.4892272949219)
	    reroute_018_4.location = (-5109.89453125, -574.6055297851562)
	    reroute_020_3.location = (-5109.89453125, -534.4194946289062)
	    boolean_math_005.location = (411.28466796875, -304.5013427734375)
	    compare_006_1.location = (210.3544921875, -344.6873779296875)
	    compare_007_1.location = (210.3544921875, -204.03619384765625)
	    group_input_006_4.location = (29.51708984375, -204.03619384765625)
	    group_input_015.location = (29.51708984375, -404.9664306640625)
	    group_input_013_1.location = (225.43359375, -120.60028076171875)
	    boolean_math_002_3.location = (406.2705078125, -140.69326782226562)
	    boolean_math_003.location = (406.2705078125, -100.50726318359375)
	    group_5.location = (225.43359375, -40.2281494140625)
	    boolean_math_007.location = (587.1083984375, -180.87930297851562)
	    group_004.location = (29.650390625, -214.593505859375)
	    group_006_1.location = (35.677734375, -326.27197265625)
	
	    #Set dimensions
	    frame_7.width, frame_7.height = 422.4208984375, 339.0
	    frame_006_4.width, frame_006_4.height = 813.0, 434.0
	    frame_001_4.width, frame_001_4.height = 561.0, 264.0
	    frame_002_5.width, frame_002_5.height = 784.0, 432.0
	    frame_003_4.width, frame_003_4.height = 582.0, 254.0
	    frame_005_3.width, frame_005_3.height = 1687.0, 393.0
	    frame_004_4.width, frame_004_4.height = 778.0, 323.0
	    frame_007_3.width, frame_007_3.height = 757.0, 523.0
	    group_input_10.width, group_input_10.height = 140.0, 100.0
	    separate_components_4.width, separate_components_4.height = 140.0, 100.0
	    reroute_012_6.width, reroute_012_6.height = 10.0, 100.0
	    reroute_010_4.width, reroute_010_4.height = 10.0, 100.0
	    reroute_011_5.width, reroute_011_5.height = 10.0, 100.0
	    reroute_013_5.width, reroute_013_5.height = 10.0, 100.0
	    reroute_007_5.width, reroute_007_5.height = 10.0, 100.0
	    reroute_009_5.width, reroute_009_5.height = 10.0, 100.0
	    reroute_006_5.width, reroute_006_5.height = 10.0, 100.0
	    reroute_008_5.width, reroute_008_5.height = 10.0, 100.0
	    capture_attribute_001_4.width, capture_attribute_001_4.height = 140.0, 100.0
	    position_007.width, position_007.height = 140.0, 100.0
	    set_spline_resolution_001_2.width, set_spline_resolution_001_2.height = 140.0, 100.0
	    set_spline_type_1.width, set_spline_type_1.height = 140.0, 100.0
	    compare_003_4.width, compare_003_4.height = 140.0, 100.0
	    switch_004_3.width, switch_004_3.height = 140.0, 100.0
	    reroute_028_2.width, reroute_028_2.height = 10.0, 100.0
	    group_005_2.width, group_005_2.height = 140.0, 100.0
	    boolean_math_5.width, boolean_math_5.height = 140.0, 100.0
	    group_input_005_4.width, group_input_005_4.height = 140.0, 100.0
	    spline_parameter_002.width, spline_parameter_002.height = 140.0, 100.0
	    math_5.width, math_5.height = 140.0, 100.0
	    math_007_1.width, math_007_1.height = 140.0, 100.0
	    math_006_1.width, math_006_1.height = 140.0, 100.0
	    group_input_016.width, group_input_016.height = 140.0, 100.0
	    spline_resolution_2.width, spline_resolution_2.height = 140.0, 100.0
	    capture_attribute_002_4.width, capture_attribute_002_4.height = 140.0, 100.0
	    set_spline_type_001_2.width, set_spline_type_001_2.height = 140.0, 100.0
	    group_output_001_1.width, group_output_001_1.height = 140.0, 100.0
	    join_geometry_3.width, join_geometry_3.height = 140.0, 100.0
	    switch_7.width, switch_7.height = 140.0, 100.0
	    compare_008.width, compare_008.height = 140.0, 100.0
	    accumulate_field_3.width, accumulate_field_3.height = 140.0, 100.0
	    reroute_10.width, reroute_10.height = 10.0, 100.0
	    group_input_007_4.width, group_input_007_4.height = 140.0, 100.0
	    group_input_008_3.width, group_input_008_3.height = 140.0, 100.0
	    boolean_math_001_1.width, boolean_math_001_1.height = 140.0, 100.0
	    group_input_003_6.width, group_input_003_6.height = 140.0, 100.0
	    compare_6.width, compare_6.height = 140.0, 100.0
	    sample_index_3.width, sample_index_3.height = 140.0, 100.0
	    compare_004_4.width, compare_004_4.height = 140.0, 100.0
	    group_001_5.width, group_001_5.height = 140.0, 100.0
	    boolean_math_004.width, boolean_math_004.height = 140.0, 100.0
	    group_input_012_1.width, group_input_012_1.height = 140.0, 100.0
	    set_position_005.width, set_position_005.height = 140.0, 100.0
	    vector_math_002_5.width, vector_math_002_5.height = 140.0, 100.0
	    vector_math_003_5.width, vector_math_003_5.height = 140.0, 100.0
	    group_input_001_6.width, group_input_001_6.height = 140.0, 100.0
	    position_008.width, position_008.height = 140.0, 100.0
	    blur_attribute_004.width, blur_attribute_004.height = 140.0, 100.0
	    group_input_002_5.width, group_input_002_5.height = 140.0, 100.0
	    position_006.width, position_006.height = 140.0, 100.0
	    vector_math_001_5.width, vector_math_001_5.height = 140.0, 100.0
	    field_at_index_001_1.width, field_at_index_001_1.height = 140.0, 100.0
	    field_at_index_002_1.width, field_at_index_002_1.height = 140.0, 100.0
	    vector_math_7.width, vector_math_7.height = 140.0, 100.0
	    reroute_003_6.width, reroute_003_6.height = 10.0, 100.0
	    reroute_004_7.width, reroute_004_7.height = 10.0, 100.0
	    reroute_001_7.width, reroute_001_7.height = 10.0, 100.0
	    reroute_021_2.width, reroute_021_2.height = 10.0, 100.0
	    reroute_016_4.width, reroute_016_4.height = 10.0, 100.0
	    reroute_014_4.width, reroute_014_4.height = 10.0, 100.0
	    reroute_005_5.width, reroute_005_5.height = 10.0, 100.0
	    reroute_002_6.width, reroute_002_6.height = 10.0, 100.0
	    reroute_017_4.width, reroute_017_4.height = 10.0, 100.0
	    reroute_015_5.width, reroute_015_5.height = 10.0, 100.0
	    reroute_018_4.width, reroute_018_4.height = 10.0, 100.0
	    reroute_020_3.width, reroute_020_3.height = 10.0, 100.0
	    boolean_math_005.width, boolean_math_005.height = 140.0, 100.0
	    compare_006_1.width, compare_006_1.height = 140.0, 100.0
	    compare_007_1.width, compare_007_1.height = 140.0, 100.0
	    group_input_006_4.width, group_input_006_4.height = 140.0, 100.0
	    group_input_015.width, group_input_015.height = 140.0, 100.0
	    group_input_013_1.width, group_input_013_1.height = 140.0, 100.0
	    boolean_math_002_3.width, boolean_math_002_3.height = 140.0, 100.0
	    boolean_math_003.width, boolean_math_003.height = 140.0, 100.0
	    group_5.width, group_5.height = 140.0, 100.0
	    boolean_math_007.width, boolean_math_007.height = 140.0, 100.0
	    group_004.width, group_004.height = 140.0, 100.0
	    group_006_1.width, group_006_1.height = 140.0, 100.0
	
	    #initialize smooth_hair_curves links
	    #capture_attribute_001_4.Geometry -> set_position_005.Geometry
	    smooth_hair_curves.links.new(capture_attribute_001_4.outputs[0], set_position_005.inputs[0])
	    #position_006.Position -> blur_attribute_004.Value
	    smooth_hair_curves.links.new(position_006.outputs[0], blur_attribute_004.inputs[0])
	    #group_input_002_5.Iterations -> blur_attribute_004.Iterations
	    smooth_hair_curves.links.new(group_input_002_5.outputs[3], blur_attribute_004.inputs[1])
	    #math_006_1.Value -> blur_attribute_004.Weight
	    smooth_hair_curves.links.new(math_006_1.outputs[0], blur_attribute_004.inputs[2])
	    #set_position_005.Geometry -> group_001_5.Curves
	    smooth_hair_curves.links.new(set_position_005.outputs[0], group_001_5.inputs[0])
	    #position_007.Position -> capture_attribute_001_4.Value
	    smooth_hair_curves.links.new(position_007.outputs[0], capture_attribute_001_4.inputs[1])
	    #reroute_002_6.Output -> group_001_5.Reference Position
	    smooth_hair_curves.links.new(reroute_002_6.outputs[0], group_001_5.inputs[3])
	    #reroute_014_4.Output -> set_position_005.Selection
	    smooth_hair_curves.links.new(reroute_014_4.outputs[0], set_position_005.inputs[1])
	    #reroute_020_3.Output -> math_5.Value
	    smooth_hair_curves.links.new(reroute_020_3.outputs[0], math_5.inputs[1])
	    #reroute_016_4.Output -> field_at_index_001_1.Value
	    smooth_hair_curves.links.new(reroute_016_4.outputs[0], field_at_index_001_1.inputs[1])
	    #blur_attribute_004.Value -> field_at_index_002_1.Value
	    smooth_hair_curves.links.new(blur_attribute_004.outputs[0], field_at_index_002_1.inputs[1])
	    #field_at_index_001_1.Value -> vector_math_7.Vector
	    smooth_hair_curves.links.new(field_at_index_001_1.outputs[0], vector_math_7.inputs[0])
	    #field_at_index_002_1.Value -> vector_math_7.Vector
	    smooth_hair_curves.links.new(field_at_index_002_1.outputs[0], vector_math_7.inputs[1])
	    #boolean_math_003.Boolean -> boolean_math_002_3.Boolean
	    smooth_hair_curves.links.new(boolean_math_003.outputs[0], boolean_math_002_3.inputs[0])
	    #boolean_math_007.Boolean -> reroute_020_3.Input
	    smooth_hair_curves.links.new(boolean_math_007.outputs[0], reroute_020_3.inputs[0])
	    #capture_attribute_001_4.Value -> reroute_021_2.Input
	    smooth_hair_curves.links.new(capture_attribute_001_4.outputs[1], reroute_021_2.inputs[0])
	    #group_input_013_1.Lock Tips -> boolean_math_003.Boolean
	    smooth_hair_curves.links.new(group_input_013_1.outputs[5], boolean_math_003.inputs[1])
	    #group_input_012_1.Preserve Length -> boolean_math_004.Boolean
	    smooth_hair_curves.links.new(group_input_012_1.outputs[6], boolean_math_004.inputs[0])
	    #boolean_math_004.Boolean -> group_001_5.Selection
	    smooth_hair_curves.links.new(boolean_math_004.outputs[0], group_001_5.inputs[1])
	    #compare_006_1.Result -> boolean_math_005.Boolean
	    smooth_hair_curves.links.new(compare_006_1.outputs[0], boolean_math_005.inputs[1])
	    #reroute_005_5.Output -> boolean_math_004.Boolean
	    smooth_hair_curves.links.new(reroute_005_5.outputs[0], boolean_math_004.inputs[1])
	    #group_input_015.Weight -> compare_006_1.A
	    smooth_hair_curves.links.new(group_input_015.outputs[4], compare_006_1.inputs[0])
	    #blur_attribute_004.Value -> vector_math_001_5.Vector
	    smooth_hair_curves.links.new(blur_attribute_004.outputs[0], vector_math_001_5.inputs[0])
	    #vector_math_7.Vector -> vector_math_001_5.Vector
	    smooth_hair_curves.links.new(vector_math_7.outputs[0], vector_math_001_5.inputs[1])
	    #vector_math_001_5.Vector -> vector_math_002_5.Vector
	    smooth_hair_curves.links.new(vector_math_001_5.outputs[0], vector_math_002_5.inputs[0])
	    #position_008.Position -> vector_math_002_5.Vector
	    smooth_hair_curves.links.new(position_008.outputs[0], vector_math_002_5.inputs[1])
	    #reroute_017_4.Output -> set_position_005.Offset
	    smooth_hair_curves.links.new(reroute_017_4.outputs[0], set_position_005.inputs[3])
	    #vector_math_002_5.Vector -> vector_math_003_5.Vector
	    smooth_hair_curves.links.new(vector_math_002_5.outputs[0], vector_math_003_5.inputs[0])
	    #group_input_003_6.Iterations -> compare_6.A
	    smooth_hair_curves.links.new(group_input_003_6.outputs[3], compare_6.inputs[2])
	    #reroute_009_5.Output -> join_geometry_3.Geometry
	    smooth_hair_curves.links.new(reroute_009_5.outputs[0], join_geometry_3.inputs[0])
	    #reroute_010_4.Output -> reroute_006_5.Input
	    smooth_hair_curves.links.new(reroute_010_4.outputs[0], reroute_006_5.inputs[0])
	    #reroute_011_5.Output -> reroute_007_5.Input
	    smooth_hair_curves.links.new(reroute_011_5.outputs[0], reroute_007_5.inputs[0])
	    #reroute_012_6.Output -> reroute_008_5.Input
	    smooth_hair_curves.links.new(reroute_012_6.outputs[0], reroute_008_5.inputs[0])
	    #reroute_013_5.Output -> reroute_009_5.Input
	    smooth_hair_curves.links.new(reroute_013_5.outputs[0], reroute_009_5.inputs[0])
	    #separate_components_4.Mesh -> reroute_010_4.Input
	    smooth_hair_curves.links.new(separate_components_4.outputs[0], reroute_010_4.inputs[0])
	    #separate_components_4.Volume -> reroute_011_5.Input
	    smooth_hair_curves.links.new(separate_components_4.outputs[4], reroute_011_5.inputs[0])
	    #separate_components_4.Point Cloud -> reroute_012_6.Input
	    smooth_hair_curves.links.new(separate_components_4.outputs[3], reroute_012_6.inputs[0])
	    #separate_components_4.Instances -> reroute_013_5.Input
	    smooth_hair_curves.links.new(separate_components_4.outputs[5], reroute_013_5.inputs[0])
	    #separate_components_4.Curve -> capture_attribute_002_4.Geometry
	    smooth_hair_curves.links.new(separate_components_4.outputs[1], capture_attribute_002_4.inputs[0])
	    #spline_resolution_2.Resolution -> capture_attribute_002_4.Value
	    smooth_hair_curves.links.new(spline_resolution_2.outputs[0], capture_attribute_002_4.inputs[1])
	    #set_spline_type_1.Curve -> set_spline_resolution_001_2.Geometry
	    smooth_hair_curves.links.new(set_spline_type_1.outputs[0], set_spline_resolution_001_2.inputs[0])
	    #group_input_10.Geometry -> separate_components_4.Geometry
	    smooth_hair_curves.links.new(group_input_10.outputs[0], separate_components_4.inputs[0])
	    #boolean_math_005.Boolean -> boolean_math_007.Boolean
	    smooth_hair_curves.links.new(boolean_math_005.outputs[0], boolean_math_007.inputs[1])
	    #group_001_5.Curves -> set_spline_type_1.Curve
	    smooth_hair_curves.links.new(group_001_5.outputs[0], set_spline_type_1.inputs[0])
	    #reroute_028_2.Output -> compare_003_4.A
	    smooth_hair_curves.links.new(reroute_028_2.outputs[0], compare_003_4.inputs[2])
	    #compare_003_4.Result -> switch_004_3.Switch
	    smooth_hair_curves.links.new(compare_003_4.outputs[0], switch_004_3.inputs[0])
	    #reroute_028_2.Output -> switch_004_3.False
	    smooth_hair_curves.links.new(reroute_028_2.outputs[0], switch_004_3.inputs[1])
	    #reroute_015_5.Output -> reroute_028_2.Input
	    smooth_hair_curves.links.new(reroute_015_5.outputs[0], reroute_028_2.inputs[0])
	    #switch_004_3.Output -> set_spline_resolution_001_2.Resolution
	    smooth_hair_curves.links.new(switch_004_3.outputs[0], set_spline_resolution_001_2.inputs[2])
	    #set_spline_type_001_2.Curve -> capture_attribute_001_4.Geometry
	    smooth_hair_curves.links.new(set_spline_type_001_2.outputs[0], capture_attribute_001_4.inputs[0])
	    #capture_attribute_002_4.Geometry -> set_spline_type_001_2.Curve
	    smooth_hair_curves.links.new(capture_attribute_002_4.outputs[0], set_spline_type_001_2.inputs[0])
	    #compare_007_1.Result -> boolean_math_005.Boolean
	    smooth_hair_curves.links.new(compare_007_1.outputs[0], boolean_math_005.inputs[0])
	    #group_input_001_6.Amount -> vector_math_003_5.Scale
	    smooth_hair_curves.links.new(group_input_001_6.outputs[1], vector_math_003_5.inputs[3])
	    #group_input_006_4.Amount -> compare_007_1.A
	    smooth_hair_curves.links.new(group_input_006_4.outputs[1], compare_007_1.inputs[0])
	    #switch_7.Output -> group_output_001_1.Geometry
	    smooth_hair_curves.links.new(switch_7.outputs[0], group_output_001_1.inputs[0])
	    #spline_parameter_002.Factor -> group_005_2.Value
	    smooth_hair_curves.links.new(spline_parameter_002.outputs[0], group_005_2.inputs[0])
	    #group_input_005_4.Shape -> group_005_2.Shape
	    smooth_hair_curves.links.new(group_input_005_4.outputs[2], group_005_2.inputs[3])
	    #math_5.Value -> math_006_1.Value
	    smooth_hair_curves.links.new(math_5.outputs[0], math_006_1.inputs[0])
	    #math_007_1.Value -> math_006_1.Value
	    smooth_hair_curves.links.new(math_007_1.outputs[0], math_006_1.inputs[1])
	    #group_5.Tip Selection -> boolean_math_003.Boolean
	    smooth_hair_curves.links.new(group_5.outputs[0], boolean_math_003.inputs[0])
	    #group_005_2.Value -> math_007_1.Value
	    smooth_hair_curves.links.new(group_005_2.outputs[0], math_007_1.inputs[0])
	    #boolean_math_5.Boolean -> math_007_1.Value
	    smooth_hair_curves.links.new(boolean_math_5.outputs[0], math_007_1.inputs[1])
	    #join_geometry_3.Geometry -> switch_7.False
	    smooth_hair_curves.links.new(join_geometry_3.outputs[0], switch_7.inputs[1])
	    #group_input_016.Weight -> math_5.Value
	    smooth_hair_curves.links.new(group_input_016.outputs[4], math_5.inputs[0])
	    #compare_008.Result -> accumulate_field_3.Value
	    smooth_hair_curves.links.new(compare_008.outputs[0], accumulate_field_3.inputs[0])
	    #accumulate_field_3.Total -> sample_index_3.Value
	    smooth_hair_curves.links.new(accumulate_field_3.outputs[2], sample_index_3.inputs[1])
	    #sample_index_3.Value -> compare_004_4.A
	    smooth_hair_curves.links.new(sample_index_3.outputs[0], compare_004_4.inputs[2])
	    #reroute_10.Output -> sample_index_3.Geometry
	    smooth_hair_curves.links.new(reroute_10.outputs[0], sample_index_3.inputs[0])
	    #group_input_007_4.Amount -> compare_008.A
	    smooth_hair_curves.links.new(group_input_007_4.outputs[1], compare_008.inputs[0])
	    #compare_004_4.Result -> boolean_math_001_1.Boolean
	    smooth_hair_curves.links.new(compare_004_4.outputs[0], boolean_math_001_1.inputs[1])
	    #boolean_math_001_1.Boolean -> switch_7.Switch
	    smooth_hair_curves.links.new(boolean_math_001_1.outputs[0], switch_7.inputs[0])
	    #compare_6.Result -> boolean_math_001_1.Boolean
	    smooth_hair_curves.links.new(compare_6.outputs[0], boolean_math_001_1.inputs[0])
	    #group_input_008_3.Geometry -> reroute_10.Input
	    smooth_hair_curves.links.new(group_input_008_3.outputs[0], reroute_10.inputs[0])
	    #reroute_10.Output -> switch_7.True
	    smooth_hair_curves.links.new(reroute_10.outputs[0], switch_7.inputs[2])
	    #capture_attribute_002_4.Value -> reroute_001_7.Input
	    smooth_hair_curves.links.new(capture_attribute_002_4.outputs[1], reroute_001_7.inputs[0])
	    #reroute_016_4.Output -> reroute_002_6.Input
	    smooth_hair_curves.links.new(reroute_016_4.outputs[0], reroute_002_6.inputs[0])
	    #reroute_018_4.Output -> reroute_004_7.Input
	    smooth_hair_curves.links.new(reroute_018_4.outputs[0], reroute_004_7.inputs[0])
	    #reroute_004_7.Output -> reroute_005_5.Input
	    smooth_hair_curves.links.new(reroute_004_7.outputs[0], reroute_005_5.inputs[0])
	    #reroute_020_3.Output -> reroute_003_6.Input
	    smooth_hair_curves.links.new(reroute_020_3.outputs[0], reroute_003_6.inputs[0])
	    #reroute_003_6.Output -> reroute_014_4.Input
	    smooth_hair_curves.links.new(reroute_003_6.outputs[0], reroute_014_4.inputs[0])
	    #reroute_001_7.Output -> reroute_015_5.Input
	    smooth_hair_curves.links.new(reroute_001_7.outputs[0], reroute_015_5.inputs[0])
	    #reroute_021_2.Output -> reroute_016_4.Input
	    smooth_hair_curves.links.new(reroute_021_2.outputs[0], reroute_016_4.inputs[0])
	    #vector_math_003_5.Vector -> reroute_017_4.Input
	    smooth_hair_curves.links.new(vector_math_003_5.outputs[0], reroute_017_4.inputs[0])
	    #boolean_math_005.Boolean -> reroute_018_4.Input
	    smooth_hair_curves.links.new(boolean_math_005.outputs[0], reroute_018_4.inputs[0])
	    #boolean_math_002_3.Boolean -> boolean_math_007.Boolean
	    smooth_hair_curves.links.new(boolean_math_002_3.outputs[0], boolean_math_007.inputs[0])
	    #group_004.Root Index -> field_at_index_001_1.Index
	    smooth_hair_curves.links.new(group_004.outputs[3], field_at_index_001_1.inputs[0])
	    #group_004.Root Index -> field_at_index_002_1.Index
	    smooth_hair_curves.links.new(group_004.outputs[3], field_at_index_002_1.inputs[0])
	    #group_006_1.Root Selection -> boolean_math_5.Boolean
	    smooth_hair_curves.links.new(group_006_1.outputs[0], boolean_math_5.inputs[0])
	    #reroute_007_5.Output -> join_geometry_3.Geometry
	    smooth_hair_curves.links.new(reroute_007_5.outputs[0], join_geometry_3.inputs[0])
	    #set_spline_resolution_001_2.Geometry -> join_geometry_3.Geometry
	    smooth_hair_curves.links.new(set_spline_resolution_001_2.outputs[0], join_geometry_3.inputs[0])
	    #reroute_008_5.Output -> join_geometry_3.Geometry
	    smooth_hair_curves.links.new(reroute_008_5.outputs[0], join_geometry_3.inputs[0])
	    #reroute_006_5.Output -> join_geometry_3.Geometry
	    smooth_hair_curves.links.new(reroute_006_5.outputs[0], join_geometry_3.inputs[0])
	    return smooth_hair_curves
	
	smooth_hair_curves = smooth_hair_curves_node_group()
	
	#initialize roll_hair_curves node group
	def roll_hair_curves_node_group():
	    roll_hair_curves = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Roll Hair Curves")
	
	    roll_hair_curves.color_tag = 'NONE'
	    roll_hair_curves.description = "Rolls up hair curves starting from their tips"
	    roll_hair_curves.default_group_node_width = 140
	    
	
	    roll_hair_curves.is_modifier = True
	
	    #roll_hair_curves interface
	    #Socket Geometry
	    geometry_socket_17 = roll_hair_curves.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_17.attribute_domain = 'POINT'
	
	    #Socket Geometry
	    geometry_socket_18 = roll_hair_curves.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_18.attribute_domain = 'POINT'
	
	    #Socket Factor
	    factor_socket_3 = roll_hair_curves.interface.new_socket(name = "Factor", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    factor_socket_3.default_value = 1.0
	    factor_socket_3.min_value = 0.0
	    factor_socket_3.max_value = 1.0
	    factor_socket_3.subtype = 'FACTOR'
	    factor_socket_3.attribute_domain = 'POINT'
	    factor_socket_3.description = "Factor to blend overall effect"
	
	    #Socket Subdivision
	    subdivision_socket = roll_hair_curves.interface.new_socket(name = "Subdivision", in_out='INPUT', socket_type = 'NodeSocketInt')
	    subdivision_socket.default_value = 1
	    subdivision_socket.min_value = 0
	    subdivision_socket.max_value = 6
	    subdivision_socket.subtype = 'NONE'
	    subdivision_socket.attribute_domain = 'POINT'
	    subdivision_socket.description = "Subdivision level applied before deformation"
	
	    #Socket Variation Level
	    variation_level_socket = roll_hair_curves.interface.new_socket(name = "Variation Level", in_out='INPUT', socket_type = 'NodeSocketInt')
	    variation_level_socket.default_value = 10
	    variation_level_socket.min_value = 0
	    variation_level_socket.max_value = 100
	    variation_level_socket.subtype = 'NONE'
	    variation_level_socket.attribute_domain = 'POINT'
	    variation_level_socket.description = "Level of smoothing on the roll path to include shape variation"
	
	    #Socket Roll Length
	    roll_length_socket = roll_hair_curves.interface.new_socket(name = "Roll Length", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    roll_length_socket.default_value = 0.10000000149011612
	    roll_length_socket.min_value = 0.0
	    roll_length_socket.max_value = 3.4028234663852886e+38
	    roll_length_socket.subtype = 'DISTANCE'
	    roll_length_socket.attribute_domain = 'POINT'
	    roll_length_socket.description = "Length of each curve to be rolled"
	
	    #Socket Roll Radius
	    roll_radius_socket = roll_hair_curves.interface.new_socket(name = "Roll Radius", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    roll_radius_socket.default_value = 0.05000000074505806
	    roll_radius_socket.min_value = 0.0
	    roll_radius_socket.max_value = 3.4028234663852886e+38
	    roll_radius_socket.subtype = 'DISTANCE'
	    roll_radius_socket.attribute_domain = 'POINT'
	    roll_radius_socket.description = "Radius of the rolls"
	
	    #Socket Roll Depth
	    roll_depth_socket = roll_hair_curves.interface.new_socket(name = "Roll Depth", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    roll_depth_socket.default_value = 0.0
	    roll_depth_socket.min_value = -3.4028234663852886e+38
	    roll_depth_socket.max_value = 3.4028234663852886e+38
	    roll_depth_socket.subtype = 'DISTANCE'
	    roll_depth_socket.attribute_domain = 'POINT'
	    roll_depth_socket.description = "Depth offset of the roll"
	
	    #Socket Roll Taper
	    roll_taper_socket = roll_hair_curves.interface.new_socket(name = "Roll Taper", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    roll_taper_socket.default_value = 0.0
	    roll_taper_socket.min_value = 0.0
	    roll_taper_socket.max_value = 1.0
	    roll_taper_socket.subtype = 'FACTOR'
	    roll_taper_socket.attribute_domain = 'POINT'
	    roll_taper_socket.description = "Taper of the roll"
	
	    #Socket Retain Overall Shape
	    retain_overall_shape_socket = roll_hair_curves.interface.new_socket(name = "Retain Overall Shape", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    retain_overall_shape_socket.default_value = 0.0
	    retain_overall_shape_socket.min_value = 0.0
	    retain_overall_shape_socket.max_value = 1.0
	    retain_overall_shape_socket.subtype = 'FACTOR'
	    retain_overall_shape_socket.attribute_domain = 'POINT'
	    retain_overall_shape_socket.description = "Offset the roll along the original curve to retain shape"
	
	    #Socket Roll Direction
	    roll_direction_socket = roll_hair_curves.interface.new_socket(name = "Roll Direction", in_out='INPUT', socket_type = 'NodeSocketVector')
	    roll_direction_socket.default_value = (0.0, 0.0, 0.0)
	    roll_direction_socket.min_value = -3.4028234663852886e+38
	    roll_direction_socket.max_value = 3.4028234663852886e+38
	    roll_direction_socket.subtype = 'NONE'
	    roll_direction_socket.attribute_domain = 'POINT'
	    roll_direction_socket.hide_value = True
	    roll_direction_socket.hide_in_modifier = True
	    roll_direction_socket.description = "Axis around which each curve is rolled"
	
	    #Socket Random Orientation
	    random_orientation_socket = roll_hair_curves.interface.new_socket(name = "Random Orientation", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    random_orientation_socket.default_value = 0.5
	    random_orientation_socket.min_value = 0.0
	    random_orientation_socket.max_value = 1.0
	    random_orientation_socket.subtype = 'FACTOR'
	    random_orientation_socket.attribute_domain = 'POINT'
	    random_orientation_socket.description = "Amount of randomization of the direction of the roll"
	
	    #Socket Seed
	    seed_socket_3 = roll_hair_curves.interface.new_socket(name = "Seed", in_out='INPUT', socket_type = 'NodeSocketInt')
	    seed_socket_3.default_value = 0
	    seed_socket_3.min_value = -10000
	    seed_socket_3.max_value = 10000
	    seed_socket_3.subtype = 'NONE'
	    seed_socket_3.attribute_domain = 'POINT'
	    seed_socket_3.description = "Random Seed for the operation"
	
	    #Socket Preserve Length
	    preserve_length_socket_3 = roll_hair_curves.interface.new_socket(name = "Preserve Length", in_out='INPUT', socket_type = 'NodeSocketBool')
	    preserve_length_socket_3.default_value = False
	    preserve_length_socket_3.attribute_domain = 'POINT'
	    preserve_length_socket_3.description = "Preserve each curve's length during deformation"
	
	
	    #initialize roll_hair_curves nodes
	    #node Frame.008
	    frame_008 = roll_hair_curves.nodes.new("NodeFrame")
	    frame_008.label = "Optimization"
	    frame_008.name = "Frame.008"
	    frame_008.label_size = 20
	    frame_008.shrink = True
	
	    #node Frame.007
	    frame_007_4 = roll_hair_curves.nodes.new("NodeFrame")
	    frame_007_4.label = "Smoothed Curve as Roll Base"
	    frame_007_4.name = "Frame.007"
	    frame_007_4.label_size = 20
	    frame_007_4.shrink = True
	
	    #node Frame.006
	    frame_006_5 = roll_hair_curves.nodes.new("NodeFrame")
	    frame_006_5.label = "Store Detail in Tangent Space"
	    frame_006_5.name = "Frame.006"
	    frame_006_5.label_size = 20
	    frame_006_5.shrink = True
	
	    #node Frame.004
	    frame_004_5 = roll_hair_curves.nodes.new("NodeFrame")
	    frame_004_5.label = "Randomization"
	    frame_004_5.name = "Frame.004"
	    frame_004_5.label_size = 20
	    frame_004_5.shrink = True
	
	    #node Frame.001
	    frame_001_5 = roll_hair_curves.nodes.new("NodeFrame")
	    frame_001_5.label = "Normal Fallback"
	    frame_001_5.name = "Frame.001"
	    frame_001_5.label_size = 20
	    frame_001_5.shrink = True
	
	    #node Frame.009
	    frame_009 = roll_hair_curves.nodes.new("NodeFrame")
	    frame_009.label = "Length Preservation"
	    frame_009.name = "Frame.009"
	    frame_009.label_size = 20
	    frame_009.shrink = True
	
	    #node Frame
	    frame_8 = roll_hair_curves.nodes.new("NodeFrame")
	    frame_8.label = "Roll Displacement Vector"
	    frame_8.name = "Frame"
	    frame_8.label_size = 20
	    frame_8.shrink = True
	
	    #node Frame.010
	    frame_010 = roll_hair_curves.nodes.new("NodeFrame")
	    frame_010.label = "Displacement"
	    frame_010.name = "Frame.010"
	    frame_010.label_size = 20
	    frame_010.shrink = True
	
	    #node Frame.011
	    frame_011 = roll_hair_curves.nodes.new("NodeFrame")
	    frame_011.label = "Optimization"
	    frame_011.name = "Frame.011"
	    frame_011.label_size = 20
	    frame_011.shrink = True
	
	    #node Frame.002
	    frame_002_6 = roll_hair_curves.nodes.new("NodeFrame")
	    frame_002_6.label = "Cumulative Segment Length"
	    frame_002_6.name = "Frame.002"
	    frame_002_6.label_size = 20
	    frame_002_6.shrink = True
	
	    #node Frame.005
	    frame_005_4 = roll_hair_curves.nodes.new("NodeFrame")
	    frame_005_4.label = "Restore Detail"
	    frame_005_4.name = "Frame.005"
	    frame_005_4.label_size = 20
	    frame_005_4.shrink = True
	
	    #node Frame.012
	    frame_012 = roll_hair_curves.nodes.new("NodeFrame")
	    frame_012.label = "Subdivision"
	    frame_012.name = "Frame.012"
	    frame_012.label_size = 20
	    frame_012.shrink = True
	
	    #node Frame.003
	    frame_003_5 = roll_hair_curves.nodes.new("NodeFrame")
	    frame_003_5.label = "Radius"
	    frame_003_5.name = "Frame.003"
	    frame_003_5.label_size = 20
	    frame_003_5.shrink = True
	
	    #node Reroute.015
	    reroute_015_6 = roll_hair_curves.nodes.new("NodeReroute")
	    reroute_015_6.name = "Reroute.015"
	    reroute_015_6.socket_idname = "NodeSocketGeometry"
	    #node Reroute.016
	    reroute_016_5 = roll_hair_curves.nodes.new("NodeReroute")
	    reroute_016_5.name = "Reroute.016"
	    reroute_016_5.socket_idname = "NodeSocketGeometry"
	    #node Reroute.017
	    reroute_017_5 = roll_hair_curves.nodes.new("NodeReroute")
	    reroute_017_5.name = "Reroute.017"
	    reroute_017_5.socket_idname = "NodeSocketGeometry"
	    #node Reroute.018
	    reroute_018_5 = roll_hair_curves.nodes.new("NodeReroute")
	    reroute_018_5.name = "Reroute.018"
	    reroute_018_5.socket_idname = "NodeSocketGeometry"
	    #node Compare.005
	    compare_005_2 = roll_hair_curves.nodes.new("FunctionNodeCompare")
	    compare_005_2.name = "Compare.005"
	    compare_005_2.data_type = 'INT'
	    compare_005_2.mode = 'ELEMENT'
	    compare_005_2.operation = 'EQUAL'
	    #B_INT
	    compare_005_2.inputs[3].default_value = 0
	
	    #node Reroute.019
	    reroute_019_3 = roll_hair_curves.nodes.new("NodeReroute")
	    reroute_019_3.name = "Reroute.019"
	    reroute_019_3.socket_idname = "NodeSocketInt"
	    #node Switch.004
	    switch_004_4 = roll_hair_curves.nodes.new("GeometryNodeSwitch")
	    switch_004_4.name = "Switch.004"
	    switch_004_4.input_type = 'INT'
	    #True
	    switch_004_4.inputs[2].default_value = 12
	
	    #node Set Spline Type
	    set_spline_type_2 = roll_hair_curves.nodes.new("GeometryNodeCurveSplineType")
	    set_spline_type_2.name = "Set Spline Type"
	    set_spline_type_2.spline_type = 'CATMULL_ROM'
	    set_spline_type_2.inputs[1].hide = True
	    #Selection
	    set_spline_type_2.inputs[1].default_value = True
	
	    #node Set Spline Resolution
	    set_spline_resolution = roll_hair_curves.nodes.new("GeometryNodeSetSplineResolution")
	    set_spline_resolution.name = "Set Spline Resolution"
	    set_spline_resolution.inputs[1].hide = True
	    #Selection
	    set_spline_resolution.inputs[1].default_value = True
	
	    #node Separate Components
	    separate_components_5 = roll_hair_curves.nodes.new("GeometryNodeSeparateComponents")
	    separate_components_5.name = "Separate Components"
	    separate_components_5.hide = True
	
	    #node Group Input.022
	    group_input_022 = roll_hair_curves.nodes.new("NodeGroupInput")
	    group_input_022.name = "Group Input.022"
	    group_input_022.outputs[0].hide = True
	    group_input_022.outputs[1].hide = True
	    group_input_022.outputs[2].hide = True
	    group_input_022.outputs[4].hide = True
	    group_input_022.outputs[5].hide = True
	    group_input_022.outputs[6].hide = True
	    group_input_022.outputs[7].hide = True
	    group_input_022.outputs[8].hide = True
	    group_input_022.outputs[9].hide = True
	    group_input_022.outputs[10].hide = True
	    group_input_022.outputs[11].hide = True
	    group_input_022.outputs[12].hide = True
	    group_input_022.outputs[13].hide = True
	
	    #node Reroute.006
	    reroute_006_6 = roll_hair_curves.nodes.new("NodeReroute")
	    reroute_006_6.name = "Reroute.006"
	    reroute_006_6.socket_idname = "NodeSocketGeometry"
	    #node Group.004
	    group_004_1 = roll_hair_curves.nodes.new("GeometryNodeGroup")
	    group_004_1.name = "Group.004"
	    group_004_1.node_tree = smooth_hair_curves
	    #Socket_2
	    group_004_1.inputs[1].default_value = 1.0
	    #Socket_3
	    group_004_1.inputs[2].default_value = 0.0
	    #Socket_5
	    group_004_1.inputs[4].default_value = 1.0
	    #Socket_6
	    group_004_1.inputs[5].default_value = True
	    #Socket_7
	    group_004_1.inputs[6].default_value = False
	
	    #node Capture Attribute.002
	    capture_attribute_002_5 = roll_hair_curves.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_002_5.name = "Capture Attribute.002"
	    capture_attribute_002_5.hide = True
	    capture_attribute_002_5.active_index = 0
	    capture_attribute_002_5.capture_items.clear()
	    capture_attribute_002_5.capture_items.new('FLOAT', "Value")
	    capture_attribute_002_5.capture_items["Value"].data_type = 'FLOAT_VECTOR'
	    capture_attribute_002_5.domain = 'CURVE'
	
	    #node Capture Attribute.001
	    capture_attribute_001_5 = roll_hair_curves.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_001_5.name = "Capture Attribute.001"
	    capture_attribute_001_5.hide = True
	    capture_attribute_001_5.active_index = 0
	    capture_attribute_001_5.capture_items.clear()
	    capture_attribute_001_5.capture_items.new('FLOAT', "Value")
	    capture_attribute_001_5.capture_items["Value"].data_type = 'FLOAT_VECTOR'
	    capture_attribute_001_5.domain = 'CURVE'
	
	    #node Capture Attribute.003
	    capture_attribute_003_2 = roll_hair_curves.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_003_2.name = "Capture Attribute.003"
	    capture_attribute_003_2.hide = True
	    capture_attribute_003_2.active_index = 0
	    capture_attribute_003_2.capture_items.clear()
	    capture_attribute_003_2.capture_items.new('FLOAT', "Value")
	    capture_attribute_003_2.capture_items["Value"].data_type = 'FLOAT_VECTOR'
	    capture_attribute_003_2.domain = 'CURVE'
	
	    #node Sample Curve
	    sample_curve_1 = roll_hair_curves.nodes.new("GeometryNodeSampleCurve")
	    sample_curve_1.name = "Sample Curve"
	    sample_curve_1.data_type = 'FLOAT_VECTOR'
	    sample_curve_1.mode = 'LENGTH'
	    sample_curve_1.use_all_curves = False
	    sample_curve_1.inputs[1].hide = True
	    sample_curve_1.outputs[0].hide = True
	    #Value
	    sample_curve_1.inputs[1].default_value = (0.0, 0.0, 0.0)
	
	    #node Group Input.023
	    group_input_023 = roll_hair_curves.nodes.new("NodeGroupInput")
	    group_input_023.name = "Group Input.023"
	    group_input_023.outputs[0].hide = True
	    group_input_023.outputs[1].hide = True
	    group_input_023.outputs[2].hide = True
	    group_input_023.outputs[4].hide = True
	    group_input_023.outputs[5].hide = True
	    group_input_023.outputs[6].hide = True
	    group_input_023.outputs[7].hide = True
	    group_input_023.outputs[8].hide = True
	    group_input_023.outputs[9].hide = True
	    group_input_023.outputs[10].hide = True
	    group_input_023.outputs[11].hide = True
	    group_input_023.outputs[12].hide = True
	    group_input_023.outputs[13].hide = True
	
	    #node Set Position.002
	    set_position_002_2 = roll_hair_curves.nodes.new("GeometryNodeSetPosition")
	    set_position_002_2.name = "Set Position.002"
	    set_position_002_2.inputs[2].hide = True
	    #Position
	    set_position_002_2.inputs[2].default_value = (0.0, 0.0, 0.0)
	
	    #node Compare.004
	    compare_004_5 = roll_hair_curves.nodes.new("FunctionNodeCompare")
	    compare_004_5.name = "Compare.004"
	    compare_004_5.data_type = 'INT'
	    compare_004_5.mode = 'ELEMENT'
	    compare_004_5.operation = 'GREATER_THAN'
	    #B_INT
	    compare_004_5.inputs[3].default_value = 0
	
	    #node Join Geometry
	    join_geometry_4 = roll_hair_curves.nodes.new("GeometryNodeJoinGeometry")
	    join_geometry_4.name = "Join Geometry"
	
	    #node Group Output
	    group_output_14 = roll_hair_curves.nodes.new("NodeGroupOutput")
	    group_output_14.name = "Group Output"
	    group_output_14.is_active_output = True
	
	    #node Reroute.010
	    reroute_010_5 = roll_hair_curves.nodes.new("NodeReroute")
	    reroute_010_5.name = "Reroute.010"
	    reroute_010_5.socket_idname = "NodeSocketGeometry"
	    #node Reroute.011
	    reroute_011_6 = roll_hair_curves.nodes.new("NodeReroute")
	    reroute_011_6.name = "Reroute.011"
	    reroute_011_6.socket_idname = "NodeSocketGeometry"
	    #node Reroute.013
	    reroute_013_6 = roll_hair_curves.nodes.new("NodeReroute")
	    reroute_013_6.name = "Reroute.013"
	    reroute_013_6.socket_idname = "NodeSocketGeometry"
	    #node Reroute.014
	    reroute_014_5 = roll_hair_curves.nodes.new("NodeReroute")
	    reroute_014_5.name = "Reroute.014"
	    reroute_014_5.socket_idname = "NodeSocketGeometry"
	    #node Reroute.029
	    reroute_029_1 = roll_hair_curves.nodes.new("NodeReroute")
	    reroute_029_1.name = "Reroute.029"
	    reroute_029_1.socket_idname = "NodeSocketVector"
	    #node Capture Attribute.008
	    capture_attribute_008 = roll_hair_curves.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_008.name = "Capture Attribute.008"
	    capture_attribute_008.hide = True
	    capture_attribute_008.active_index = 0
	    capture_attribute_008.capture_items.clear()
	    capture_attribute_008.capture_items.new('FLOAT', "Value")
	    capture_attribute_008.capture_items["Value"].data_type = 'FLOAT_VECTOR'
	    capture_attribute_008.domain = 'POINT'
	
	    #node Vector Math.027
	    vector_math_027 = roll_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_027.name = "Vector Math.027"
	    vector_math_027.hide = True
	    vector_math_027.operation = 'DOT_PRODUCT'
	
	    #node Vector Math.029
	    vector_math_029 = roll_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_029.name = "Vector Math.029"
	    vector_math_029.hide = True
	    vector_math_029.operation = 'DOT_PRODUCT'
	
	    #node Vector Math.026
	    vector_math_026_1 = roll_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_026_1.name = "Vector Math.026"
	    vector_math_026_1.hide = True
	    vector_math_026_1.operation = 'DOT_PRODUCT'
	
	    #node Combine XYZ
	    combine_xyz_2 = roll_hair_curves.nodes.new("ShaderNodeCombineXYZ")
	    combine_xyz_2.name = "Combine XYZ"
	
	    #node Reroute.012
	    reroute_012_7 = roll_hair_curves.nodes.new("NodeReroute")
	    reroute_012_7.name = "Reroute.012"
	    reroute_012_7.socket_idname = "NodeSocketVector"
	    #node Curve Tangent.002
	    curve_tangent_002_1 = roll_hair_curves.nodes.new("GeometryNodeInputTangent")
	    curve_tangent_002_1.name = "Curve Tangent.002"
	
	    #node Normal.001
	    normal_001_1 = roll_hair_curves.nodes.new("GeometryNodeInputNormal")
	    normal_001_1.name = "Normal.001"
	    normal_001_1.legacy_corner_normals = True
	
	    #node Reroute.023
	    reroute_023_2 = roll_hair_curves.nodes.new("NodeReroute")
	    reroute_023_2.name = "Reroute.023"
	    reroute_023_2.socket_idname = "NodeSocketVector"
	    #node Vector Math.032
	    vector_math_032 = roll_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_032.name = "Vector Math.032"
	    vector_math_032.hide = True
	    vector_math_032.operation = 'CROSS_PRODUCT'
	
	    #node Reroute.020
	    reroute_020_4 = roll_hair_curves.nodes.new("NodeReroute")
	    reroute_020_4.name = "Reroute.020"
	    reroute_020_4.socket_idname = "NodeSocketVector"
	    #node Vector Math.025
	    vector_math_025_1 = roll_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_025_1.name = "Vector Math.025"
	    vector_math_025_1.hide = True
	    vector_math_025_1.operation = 'SUBTRACT'
	
	    #node Position.005
	    position_005 = roll_hair_curves.nodes.new("GeometryNodeInputPosition")
	    position_005.name = "Position.005"
	
	    #node Reroute.022
	    reroute_022_2 = roll_hair_curves.nodes.new("NodeReroute")
	    reroute_022_2.name = "Reroute.022"
	    reroute_022_2.socket_idname = "NodeSocketVector"
	    #node Group Input.007
	    group_input_007_5 = roll_hair_curves.nodes.new("NodeGroupInput")
	    group_input_007_5.name = "Group Input.007"
	    group_input_007_5.outputs[0].hide = True
	    group_input_007_5.outputs[1].hide = True
	    group_input_007_5.outputs[2].hide = True
	    group_input_007_5.outputs[3].hide = True
	    group_input_007_5.outputs[4].hide = True
	    group_input_007_5.outputs[5].hide = True
	    group_input_007_5.outputs[6].hide = True
	    group_input_007_5.outputs[7].hide = True
	    group_input_007_5.outputs[8].hide = True
	    group_input_007_5.outputs[10].hide = True
	    group_input_007_5.outputs[11].hide = True
	    group_input_007_5.outputs[12].hide = True
	    group_input_007_5.outputs[13].hide = True
	
	    #node Reroute.028
	    reroute_028_3 = roll_hair_curves.nodes.new("NodeReroute")
	    reroute_028_3.name = "Reroute.028"
	    reroute_028_3.socket_idname = "NodeSocketVector"
	    #node Math.015
	    math_015_1 = roll_hair_curves.nodes.new("ShaderNodeMath")
	    math_015_1.name = "Math.015"
	    math_015_1.operation = 'MULTIPLY'
	    math_015_1.use_clamp = False
	
	    #node Random Value
	    random_value_3 = roll_hair_curves.nodes.new("FunctionNodeRandomValue")
	    random_value_3.name = "Random Value"
	    random_value_3.data_type = 'FLOAT'
	    #Min_001
	    random_value_3.inputs[2].default_value = -3.1415927410125732
	    #Max_001
	    random_value_3.inputs[3].default_value = 3.1415927410125732
	
	    #node Group.007
	    group_007_1 = roll_hair_curves.nodes.new("GeometryNodeGroup")
	    group_007_1.name = "Group.007"
	    group_007_1.node_tree = curve_info
	    group_007_1.outputs[0].hide = True
	    group_007_1.outputs[2].hide = True
	    group_007_1.outputs[3].hide = True
	    group_007_1.outputs[4].hide = True
	    group_007_1.outputs[5].hide = True
	
	    #node Group Input.004
	    group_input_004_4 = roll_hair_curves.nodes.new("NodeGroupInput")
	    group_input_004_4.name = "Group Input.004"
	    group_input_004_4.outputs[0].hide = True
	    group_input_004_4.outputs[1].hide = True
	    group_input_004_4.outputs[2].hide = True
	    group_input_004_4.outputs[3].hide = True
	    group_input_004_4.outputs[4].hide = True
	    group_input_004_4.outputs[5].hide = True
	    group_input_004_4.outputs[6].hide = True
	    group_input_004_4.outputs[7].hide = True
	    group_input_004_4.outputs[8].hide = True
	    group_input_004_4.outputs[9].hide = True
	    group_input_004_4.outputs[11].hide = True
	    group_input_004_4.outputs[12].hide = True
	    group_input_004_4.outputs[13].hide = True
	
	    #node Vector Math.007
	    vector_math_007_5 = roll_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_007_5.name = "Vector Math.007"
	    vector_math_007_5.hide = True
	    vector_math_007_5.operation = 'PROJECT'
	
	    #node Reroute.009
	    reroute_009_6 = roll_hair_curves.nodes.new("NodeReroute")
	    reroute_009_6.name = "Reroute.009"
	    reroute_009_6.socket_idname = "NodeSocketVector"
	    #node Vector Math.008
	    vector_math_008_4 = roll_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_008_4.name = "Vector Math.008"
	    vector_math_008_4.hide = True
	    vector_math_008_4.operation = 'SUBTRACT'
	
	    #node Compare.001
	    compare_001_3 = roll_hair_curves.nodes.new("FunctionNodeCompare")
	    compare_001_3.name = "Compare.001"
	    compare_001_3.hide = True
	    compare_001_3.data_type = 'VECTOR'
	    compare_001_3.mode = 'ELEMENT'
	    compare_001_3.operation = 'NOT_EQUAL'
	    #B_VEC3
	    compare_001_3.inputs[5].default_value = (0.0, 0.0, 0.0)
	    #Epsilon
	    compare_001_3.inputs[12].default_value = 0.0
	
	    #node Vector Math.009
	    vector_math_009_3 = roll_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_009_3.name = "Vector Math.009"
	    vector_math_009_3.hide = True
	    vector_math_009_3.operation = 'NORMALIZE'
	
	    #node Switch
	    switch_8 = roll_hair_curves.nodes.new("GeometryNodeSwitch")
	    switch_8.name = "Switch"
	    switch_8.input_type = 'VECTOR'
	
	    #node Vector Rotate
	    vector_rotate_1 = roll_hair_curves.nodes.new("ShaderNodeVectorRotate")
	    vector_rotate_1.name = "Vector Rotate"
	    vector_rotate_1.invert = False
	    vector_rotate_1.rotation_type = 'AXIS_ANGLE'
	    vector_rotate_1.inputs[1].hide = True
	    vector_rotate_1.inputs[4].hide = True
	    #Center
	    vector_rotate_1.inputs[1].default_value = (0.0, 0.0, 0.0)
	
	    #node Evaluate on Domain.004
	    evaluate_on_domain_004 = roll_hair_curves.nodes.new("GeometryNodeFieldOnDomain")
	    evaluate_on_domain_004.name = "Evaluate on Domain.004"
	    evaluate_on_domain_004.data_type = 'FLOAT_VECTOR'
	    evaluate_on_domain_004.domain = 'CURVE'
	
	    #node Group Input.009
	    group_input_009_2 = roll_hair_curves.nodes.new("NodeGroupInput")
	    group_input_009_2.name = "Group Input.009"
	    group_input_009_2.outputs[0].hide = True
	    group_input_009_2.outputs[1].hide = True
	    group_input_009_2.outputs[2].hide = True
	    group_input_009_2.outputs[3].hide = True
	    group_input_009_2.outputs[4].hide = True
	    group_input_009_2.outputs[5].hide = True
	    group_input_009_2.outputs[6].hide = True
	    group_input_009_2.outputs[7].hide = True
	    group_input_009_2.outputs[8].hide = True
	    group_input_009_2.outputs[9].hide = True
	    group_input_009_2.outputs[10].hide = True
	    group_input_009_2.outputs[11].hide = True
	    group_input_009_2.outputs[13].hide = True
	
	    #node Group.005
	    group_005_3 = roll_hair_curves.nodes.new("GeometryNodeGroup")
	    group_005_3.name = "Group.005"
	    group_005_3.node_tree = restore_curve_segment_length
	    #Socket_3
	    group_005_3.inputs[2].default_value = 1.0
	    #Socket_5
	    group_005_3.inputs[4].default_value = 0.0
	
	    #node Math.003
	    math_003_3 = roll_hair_curves.nodes.new("ShaderNodeMath")
	    math_003_3.name = "Math.003"
	    math_003_3.hide = True
	    math_003_3.operation = 'COSINE'
	    math_003_3.use_clamp = False
	
	    #node Math.002
	    math_002_2 = roll_hair_curves.nodes.new("ShaderNodeMath")
	    math_002_2.name = "Math.002"
	    math_002_2.hide = True
	    math_002_2.operation = 'SINE'
	    math_002_2.use_clamp = False
	
	    #node Math.007
	    math_007_2 = roll_hair_curves.nodes.new("ShaderNodeMath")
	    math_007_2.name = "Math.007"
	    math_007_2.hide = True
	    math_007_2.operation = 'MULTIPLY'
	    math_007_2.use_clamp = False
	
	    #node Math.006
	    math_006_2 = roll_hair_curves.nodes.new("ShaderNodeMath")
	    math_006_2.name = "Math.006"
	    math_006_2.hide = True
	    math_006_2.operation = 'MULTIPLY'
	    math_006_2.use_clamp = False
	
	    #node Math.004
	    math_004_1 = roll_hair_curves.nodes.new("ShaderNodeMath")
	    math_004_1.name = "Math.004"
	    math_004_1.hide = True
	    math_004_1.operation = 'SUBTRACT'
	    math_004_1.use_clamp = False
	
	    #node Reroute
	    reroute_11 = roll_hair_curves.nodes.new("NodeReroute")
	    reroute_11.name = "Reroute"
	    reroute_11.socket_idname = "NodeSocketFloat"
	    #node Vector Math
	    vector_math_8 = roll_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_8.name = "Vector Math"
	    vector_math_8.hide = True
	    vector_math_8.operation = 'SCALE'
	
	    #node Vector Math.004
	    vector_math_004_6 = roll_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_004_6.name = "Vector Math.004"
	    vector_math_004_6.hide = True
	    vector_math_004_6.operation = 'ADD'
	
	    #node Vector Math.002
	    vector_math_002_6 = roll_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_002_6.name = "Vector Math.002"
	    vector_math_002_6.hide = True
	    vector_math_002_6.operation = 'SCALE'
	
	    #node Vector Math.005
	    vector_math_005_2 = roll_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_005_2.name = "Vector Math.005"
	    vector_math_005_2.hide = True
	    vector_math_005_2.operation = 'SCALE'
	
	    #node Vector Math.003
	    vector_math_003_6 = roll_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_003_6.name = "Vector Math.003"
	    vector_math_003_6.hide = True
	    vector_math_003_6.operation = 'ADD'
	
	    #node Vector Math.006
	    vector_math_006_3 = roll_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_006_3.name = "Vector Math.006"
	    vector_math_006_3.hide = True
	    vector_math_006_3.operation = 'CROSS_PRODUCT'
	
	    #node Math.008
	    math_008_1 = roll_hair_curves.nodes.new("ShaderNodeMath")
	    math_008_1.name = "Math.008"
	    math_008_1.hide = True
	    math_008_1.operation = 'MULTIPLY'
	    math_008_1.use_clamp = False
	
	    #node Reroute.004
	    reroute_004_8 = roll_hair_curves.nodes.new("NodeReroute")
	    reroute_004_8.name = "Reroute.004"
	    reroute_004_8.socket_idname = "NodeSocketVector"
	    #node Position
	    position_3 = roll_hair_curves.nodes.new("GeometryNodeInputPosition")
	    position_3.name = "Position"
	
	    #node Mix.001
	    mix_001 = roll_hair_curves.nodes.new("ShaderNodeMix")
	    mix_001.name = "Mix.001"
	    mix_001.blend_type = 'MIX'
	    mix_001.clamp_factor = True
	    mix_001.clamp_result = False
	    mix_001.data_type = 'VECTOR'
	    mix_001.factor_mode = 'UNIFORM'
	
	    #node Group Input.002
	    group_input_002_6 = roll_hair_curves.nodes.new("NodeGroupInput")
	    group_input_002_6.name = "Group Input.002"
	    group_input_002_6.outputs[0].hide = True
	    group_input_002_6.outputs[1].hide = True
	    group_input_002_6.outputs[2].hide = True
	    group_input_002_6.outputs[3].hide = True
	    group_input_002_6.outputs[4].hide = True
	    group_input_002_6.outputs[5].hide = True
	    group_input_002_6.outputs[6].hide = True
	    group_input_002_6.outputs[7].hide = True
	    group_input_002_6.outputs[9].hide = True
	    group_input_002_6.outputs[10].hide = True
	    group_input_002_6.outputs[11].hide = True
	    group_input_002_6.outputs[12].hide = True
	    group_input_002_6.outputs[13].hide = True
	
	    #node Vector Math.001
	    vector_math_001_6 = roll_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_001_6.name = "Vector Math.001"
	    vector_math_001_6.operation = 'ADD'
	
	    #node Reroute.005
	    reroute_005_6 = roll_hair_curves.nodes.new("NodeReroute")
	    reroute_005_6.name = "Reroute.005"
	    reroute_005_6.socket_idname = "NodeSocketVector"
	    #node Reroute.008
	    reroute_008_6 = roll_hair_curves.nodes.new("NodeReroute")
	    reroute_008_6.name = "Reroute.008"
	    reroute_008_6.socket_idname = "NodeSocketFloat"
	    #node Reroute.001
	    reroute_001_8 = roll_hair_curves.nodes.new("NodeReroute")
	    reroute_001_8.name = "Reroute.001"
	    reroute_001_8.socket_idname = "NodeSocketFloat"
	    #node Math.017
	    math_017_1 = roll_hair_curves.nodes.new("ShaderNodeMath")
	    math_017_1.name = "Math.017"
	    math_017_1.operation = 'DIVIDE'
	    math_017_1.use_clamp = False
	    #Value_001
	    math_017_1.inputs[1].default_value = 6.2831854820251465
	
	    #node Group Input.006
	    group_input_006_5 = roll_hair_curves.nodes.new("NodeGroupInput")
	    group_input_006_5.name = "Group Input.006"
	    group_input_006_5.outputs[0].hide = True
	    group_input_006_5.outputs[1].hide = True
	    group_input_006_5.outputs[2].hide = True
	    group_input_006_5.outputs[3].hide = True
	    group_input_006_5.outputs[4].hide = True
	    group_input_006_5.outputs[5].hide = True
	    group_input_006_5.outputs[7].hide = True
	    group_input_006_5.outputs[8].hide = True
	    group_input_006_5.outputs[9].hide = True
	    group_input_006_5.outputs[10].hide = True
	    group_input_006_5.outputs[11].hide = True
	    group_input_006_5.outputs[12].hide = True
	    group_input_006_5.outputs[13].hide = True
	
	    #node Reroute.027
	    reroute_027_2 = roll_hair_curves.nodes.new("NodeReroute")
	    reroute_027_2.name = "Reroute.027"
	    reroute_027_2.socket_idname = "NodeSocketBool"
	    #node Group Input.010
	    group_input_010_2 = roll_hair_curves.nodes.new("NodeGroupInput")
	    group_input_010_2.name = "Group Input.010"
	    group_input_010_2.outputs[0].hide = True
	    group_input_010_2.outputs[2].hide = True
	    group_input_010_2.outputs[3].hide = True
	    group_input_010_2.outputs[4].hide = True
	    group_input_010_2.outputs[5].hide = True
	    group_input_010_2.outputs[6].hide = True
	    group_input_010_2.outputs[7].hide = True
	    group_input_010_2.outputs[8].hide = True
	    group_input_010_2.outputs[9].hide = True
	    group_input_010_2.outputs[10].hide = True
	    group_input_010_2.outputs[11].hide = True
	    group_input_010_2.outputs[12].hide = True
	    group_input_010_2.outputs[13].hide = True
	
	    #node Set Position
	    set_position_5 = roll_hair_curves.nodes.new("GeometryNodeSetPosition")
	    set_position_5.name = "Set Position"
	    #Offset
	    set_position_5.inputs[3].default_value = (0.0, 0.0, 0.0)
	
	    #node Compare.003
	    compare_003_5 = roll_hair_curves.nodes.new("FunctionNodeCompare")
	    compare_003_5.name = "Compare.003"
	    compare_003_5.data_type = 'FLOAT'
	    compare_003_5.mode = 'ELEMENT'
	    compare_003_5.operation = 'GREATER_THAN'
	    #B
	    compare_003_5.inputs[1].default_value = 0.0
	
	    #node Boolean Math
	    boolean_math_6 = roll_hair_curves.nodes.new("FunctionNodeBooleanMath")
	    boolean_math_6.name = "Boolean Math"
	    boolean_math_6.hide = True
	    boolean_math_6.operation = 'AND'
	
	    #node Mix.006
	    mix_006 = roll_hair_curves.nodes.new("ShaderNodeMix")
	    mix_006.name = "Mix.006"
	    mix_006.blend_type = 'MIX'
	    mix_006.clamp_factor = True
	    mix_006.clamp_result = False
	    mix_006.data_type = 'VECTOR'
	    mix_006.factor_mode = 'UNIFORM'
	
	    #node Position.006
	    position_006_1 = roll_hair_curves.nodes.new("GeometryNodeInputPosition")
	    position_006_1.name = "Position.006"
	
	    #node Capture Attribute.007
	    capture_attribute_007 = roll_hair_curves.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_007.name = "Capture Attribute.007"
	    capture_attribute_007.hide = True
	    capture_attribute_007.active_index = 0
	    capture_attribute_007.capture_items.clear()
	    capture_attribute_007.capture_items.new('FLOAT', "Value")
	    capture_attribute_007.capture_items["Value"].data_type = 'FLOAT_VECTOR'
	    capture_attribute_007.domain = 'POINT'
	
	    #node Position.004
	    position_004_1 = roll_hair_curves.nodes.new("GeometryNodeInputPosition")
	    position_004_1.name = "Position.004"
	
	    #node Group Input
	    group_input_11 = roll_hair_curves.nodes.new("NodeGroupInput")
	    group_input_11.name = "Group Input"
	    group_input_11.outputs[1].hide = True
	    group_input_11.outputs[2].hide = True
	    group_input_11.outputs[3].hide = True
	    group_input_11.outputs[5].hide = True
	    group_input_11.outputs[6].hide = True
	    group_input_11.outputs[7].hide = True
	    group_input_11.outputs[8].hide = True
	    group_input_11.outputs[9].hide = True
	    group_input_11.outputs[10].hide = True
	    group_input_11.outputs[11].hide = True
	    group_input_11.outputs[12].hide = True
	    group_input_11.outputs[13].hide = True
	
	    #node Group
	    group_6 = roll_hair_curves.nodes.new("GeometryNodeGroup")
	    group_6.name = "Group"
	    group_6.node_tree = curve_info
	    group_6.outputs[0].hide = True
	    group_6.outputs[1].hide = True
	    group_6.outputs[3].hide = True
	    group_6.outputs[4].hide = True
	    group_6.outputs[5].hide = True
	
	    #node Math.009
	    math_009_2 = roll_hair_curves.nodes.new("ShaderNodeMath")
	    math_009_2.name = "Math.009"
	    math_009_2.hide = True
	    math_009_2.operation = 'MINIMUM'
	    math_009_2.use_clamp = False
	
	    #node Reroute.026
	    reroute_026_2 = roll_hair_curves.nodes.new("NodeReroute")
	    reroute_026_2.name = "Reroute.026"
	    reroute_026_2.socket_idname = "NodeSocketFloat"
	    #node Group Input.012
	    group_input_012_2 = roll_hair_curves.nodes.new("NodeGroupInput")
	    group_input_012_2.name = "Group Input.012"
	    group_input_012_2.outputs[0].hide = True
	    group_input_012_2.outputs[1].hide = True
	    group_input_012_2.outputs[2].hide = True
	    group_input_012_2.outputs[3].hide = True
	    group_input_012_2.outputs[5].hide = True
	    group_input_012_2.outputs[6].hide = True
	    group_input_012_2.outputs[7].hide = True
	    group_input_012_2.outputs[8].hide = True
	    group_input_012_2.outputs[9].hide = True
	    group_input_012_2.outputs[10].hide = True
	    group_input_012_2.outputs[11].hide = True
	    group_input_012_2.outputs[12].hide = True
	    group_input_012_2.outputs[13].hide = True
	
	    #node Group Input.011
	    group_input_011_1 = roll_hair_curves.nodes.new("NodeGroupInput")
	    group_input_011_1.name = "Group Input.011"
	    group_input_011_1.outputs[0].hide = True
	    group_input_011_1.outputs[2].hide = True
	    group_input_011_1.outputs[3].hide = True
	    group_input_011_1.outputs[4].hide = True
	    group_input_011_1.outputs[5].hide = True
	    group_input_011_1.outputs[6].hide = True
	    group_input_011_1.outputs[7].hide = True
	    group_input_011_1.outputs[8].hide = True
	    group_input_011_1.outputs[9].hide = True
	    group_input_011_1.outputs[10].hide = True
	    group_input_011_1.outputs[11].hide = True
	    group_input_011_1.outputs[12].hide = True
	    group_input_011_1.outputs[13].hide = True
	
	    #node Math.016
	    math_016_1 = roll_hair_curves.nodes.new("ShaderNodeMath")
	    math_016_1.name = "Math.016"
	    math_016_1.hide = True
	    math_016_1.operation = 'MULTIPLY'
	    math_016_1.use_clamp = False
	
	    #node Math
	    math_6 = roll_hair_curves.nodes.new("ShaderNodeMath")
	    math_6.name = "Math"
	    math_6.operation = 'SUBTRACT'
	    math_6.use_clamp = False
	
	    #node Group.001
	    group_001_6 = roll_hair_curves.nodes.new("GeometryNodeGroup")
	    group_001_6.name = "Group.001"
	    group_001_6.node_tree = curve_info
	    group_001_6.outputs[1].hide = True
	    group_001_6.outputs[2].hide = True
	    group_001_6.outputs[3].hide = True
	    group_001_6.outputs[4].hide = True
	    group_001_6.outputs[5].hide = True
	
	    #node Evaluate on Domain.001
	    evaluate_on_domain_001_3 = roll_hair_curves.nodes.new("GeometryNodeFieldOnDomain")
	    evaluate_on_domain_001_3.name = "Evaluate on Domain.001"
	    evaluate_on_domain_001_3.hide = True
	    evaluate_on_domain_001_3.data_type = 'FLOAT'
	    evaluate_on_domain_001_3.domain = 'CURVE'
	
	    #node Capture Attribute.009
	    capture_attribute_009 = roll_hair_curves.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_009.name = "Capture Attribute.009"
	    capture_attribute_009.active_index = 0
	    capture_attribute_009.capture_items.clear()
	    capture_attribute_009.capture_items.new('FLOAT', "Value")
	    capture_attribute_009.capture_items["Value"].data_type = 'INT'
	    capture_attribute_009.domain = 'POINT'
	
	    #node Spline Resolution
	    spline_resolution_3 = roll_hair_curves.nodes.new("GeometryNodeInputSplineResolution")
	    spline_resolution_3.name = "Spline Resolution"
	
	    #node Set Spline Type.001
	    set_spline_type_001_3 = roll_hair_curves.nodes.new("GeometryNodeCurveSplineType")
	    set_spline_type_001_3.name = "Set Spline Type.001"
	    set_spline_type_001_3.spline_type = 'POLY'
	    #Selection
	    set_spline_type_001_3.inputs[1].default_value = True
	
	    #node Reroute.025
	    reroute_025_1 = roll_hair_curves.nodes.new("NodeReroute")
	    reroute_025_1.name = "Reroute.025"
	    reroute_025_1.socket_idname = "NodeSocketVector"
	    #node Reroute.024
	    reroute_024_2 = roll_hair_curves.nodes.new("NodeReroute")
	    reroute_024_2.name = "Reroute.024"
	    reroute_024_2.socket_idname = "NodeSocketVector"
	    #node Group.003
	    group_003_2 = roll_hair_curves.nodes.new("GeometryNodeGroup")
	    group_003_2.name = "Group.003"
	    group_003_2.node_tree = curve_segment
	    group_003_2.outputs[1].hide = True
	    group_003_2.outputs[2].hide = True
	
	    #node Accumulate Field
	    accumulate_field_4 = roll_hair_curves.nodes.new("GeometryNodeAccumulateField")
	    accumulate_field_4.name = "Accumulate Field"
	    accumulate_field_4.data_type = 'FLOAT'
	    accumulate_field_4.domain = 'POINT'
	    accumulate_field_4.outputs[1].hide = True
	    accumulate_field_4.outputs[2].hide = True
	
	    #node Group.002
	    group_002_4 = roll_hair_curves.nodes.new("GeometryNodeGroup")
	    group_002_4.name = "Group.002"
	    group_002_4.node_tree = curve_info
	    group_002_4.outputs[1].hide = True
	    group_002_4.outputs[2].hide = True
	    group_002_4.outputs[3].hide = True
	    group_002_4.outputs[4].hide = True
	    group_002_4.outputs[5].hide = True
	
	    #node Math.014
	    math_014_1 = roll_hair_curves.nodes.new("ShaderNodeMath")
	    math_014_1.name = "Math.014"
	    math_014_1.operation = 'MULTIPLY'
	    math_014_1.use_clamp = False
	
	    #node Math.013
	    math_013_1 = roll_hair_curves.nodes.new("ShaderNodeMath")
	    math_013_1.name = "Math.013"
	    math_013_1.operation = 'DIVIDE'
	    math_013_1.use_clamp = False
	
	    #node Switch.001
	    switch_001_8 = roll_hair_curves.nodes.new("GeometryNodeSwitch")
	    switch_001_8.name = "Switch.001"
	    switch_001_8.input_type = 'FLOAT'
	
	    #node Group Input.008
	    group_input_008_4 = roll_hair_curves.nodes.new("NodeGroupInput")
	    group_input_008_4.name = "Group Input.008"
	    group_input_008_4.outputs[0].hide = True
	    group_input_008_4.outputs[1].hide = True
	    group_input_008_4.outputs[2].hide = True
	    group_input_008_4.outputs[3].hide = True
	    group_input_008_4.outputs[4].hide = True
	    group_input_008_4.outputs[5].hide = True
	    group_input_008_4.outputs[6].hide = True
	    group_input_008_4.outputs[8].hide = True
	    group_input_008_4.outputs[9].hide = True
	    group_input_008_4.outputs[10].hide = True
	    group_input_008_4.outputs[11].hide = True
	    group_input_008_4.outputs[12].hide = True
	    group_input_008_4.outputs[13].hide = True
	
	    #node Compare.002
	    compare_002_5 = roll_hair_curves.nodes.new("FunctionNodeCompare")
	    compare_002_5.name = "Compare.002"
	    compare_002_5.data_type = 'FLOAT'
	    compare_002_5.mode = 'ELEMENT'
	    compare_002_5.operation = 'EQUAL'
	    #B
	    compare_002_5.inputs[1].default_value = 0.0
	    #Epsilon
	    compare_002_5.inputs[12].default_value = 0.0
	
	    #node Vector Math.014
	    vector_math_014_3 = roll_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_014_3.name = "Vector Math.014"
	    vector_math_014_3.hide = True
	    vector_math_014_3.operation = 'CROSS_PRODUCT'
	
	    #node Normal
	    normal_2 = roll_hair_curves.nodes.new("GeometryNodeInputNormal")
	    normal_2.name = "Normal"
	    normal_2.legacy_corner_normals = True
	
	    #node Curve Tangent.001
	    curve_tangent_001_1 = roll_hair_curves.nodes.new("GeometryNodeInputTangent")
	    curve_tangent_001_1.name = "Curve Tangent.001"
	
	    #node Separate XYZ
	    separate_xyz_3 = roll_hair_curves.nodes.new("ShaderNodeSeparateXYZ")
	    separate_xyz_3.name = "Separate XYZ"
	
	    #node Vector Math.016
	    vector_math_016_2 = roll_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_016_2.name = "Vector Math.016"
	    vector_math_016_2.hide = True
	    vector_math_016_2.operation = 'SCALE'
	
	    #node Vector Math.030
	    vector_math_030 = roll_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_030.name = "Vector Math.030"
	    vector_math_030.hide = True
	    vector_math_030.operation = 'SCALE'
	
	    #node Vector Math.031
	    vector_math_031 = roll_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_031.name = "Vector Math.031"
	    vector_math_031.hide = True
	    vector_math_031.operation = 'ADD'
	
	    #node Vector Math.013
	    vector_math_013_3 = roll_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_013_3.name = "Vector Math.013"
	    vector_math_013_3.hide = True
	    vector_math_013_3.operation = 'ADD'
	
	    #node Vector Math.012
	    vector_math_012_3 = roll_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_012_3.name = "Vector Math.012"
	    vector_math_012_3.hide = True
	    vector_math_012_3.operation = 'SCALE'
	
	    #node Subdivide Curve.004
	    subdivide_curve_004 = roll_hair_curves.nodes.new("GeometryNodeSubdivideCurve")
	    subdivide_curve_004.name = "Subdivide Curve.004"
	
	    #node Math.022
	    math_022 = roll_hair_curves.nodes.new("ShaderNodeMath")
	    math_022.name = "Math.022"
	    math_022.operation = 'POWER'
	    math_022.use_clamp = False
	    #Value
	    math_022.inputs[0].default_value = 2.0
	
	    #node Math.023
	    math_023 = roll_hair_curves.nodes.new("ShaderNodeMath")
	    math_023.name = "Math.023"
	    math_023.operation = 'SUBTRACT'
	    math_023.use_clamp = False
	    #Value_001
	    math_023.inputs[1].default_value = 1.0
	
	    #node Group Input.014
	    group_input_014 = roll_hair_curves.nodes.new("NodeGroupInput")
	    group_input_014.name = "Group Input.014"
	    group_input_014.outputs[0].hide = True
	    group_input_014.outputs[1].hide = True
	    group_input_014.outputs[3].hide = True
	    group_input_014.outputs[4].hide = True
	    group_input_014.outputs[5].hide = True
	    group_input_014.outputs[6].hide = True
	    group_input_014.outputs[7].hide = True
	    group_input_014.outputs[8].hide = True
	    group_input_014.outputs[9].hide = True
	    group_input_014.outputs[10].hide = True
	    group_input_014.outputs[11].hide = True
	    group_input_014.outputs[12].hide = True
	    group_input_014.outputs[13].hide = True
	
	    #node Reroute.007
	    reroute_007_6 = roll_hair_curves.nodes.new("NodeReroute")
	    reroute_007_6.name = "Reroute.007"
	    reroute_007_6.socket_idname = "NodeSocketFloat"
	    #node Compare
	    compare_7 = roll_hair_curves.nodes.new("FunctionNodeCompare")
	    compare_7.name = "Compare"
	    compare_7.data_type = 'FLOAT'
	    compare_7.mode = 'ELEMENT'
	    compare_7.operation = 'GREATER_THAN'
	    #B
	    compare_7.inputs[1].default_value = 0.0
	
	    #node Reroute.031
	    reroute_031 = roll_hair_curves.nodes.new("NodeReroute")
	    reroute_031.name = "Reroute.031"
	    reroute_031.socket_idname = "NodeSocketFloat"
	    #node Reroute.021
	    reroute_021_3 = roll_hair_curves.nodes.new("NodeReroute")
	    reroute_021_3.name = "Reroute.021"
	    reroute_021_3.socket_idname = "NodeSocketFloat"
	    #node Spline Parameter
	    spline_parameter_2 = roll_hair_curves.nodes.new("GeometryNodeSplineParameter")
	    spline_parameter_2.name = "Spline Parameter"
	    spline_parameter_2.outputs[0].hide = True
	    spline_parameter_2.outputs[2].hide = True
	
	    #node Math.001
	    math_001_4 = roll_hair_curves.nodes.new("ShaderNodeMath")
	    math_001_4.name = "Math.001"
	    math_001_4.hide = True
	    math_001_4.operation = 'SUBTRACT'
	    math_001_4.use_clamp = False
	
	    #node Reroute.003
	    reroute_003_7 = roll_hair_curves.nodes.new("NodeReroute")
	    reroute_003_7.name = "Reroute.003"
	    reroute_003_7.socket_idname = "NodeSocketFloat"
	    #node Reroute.002
	    reroute_002_7 = roll_hair_curves.nodes.new("NodeReroute")
	    reroute_002_7.name = "Reroute.002"
	    reroute_002_7.socket_idname = "NodeSocketFloat"
	    #node Evaluate on Domain
	    evaluate_on_domain_2 = roll_hair_curves.nodes.new("GeometryNodeFieldOnDomain")
	    evaluate_on_domain_2.name = "Evaluate on Domain"
	    evaluate_on_domain_2.hide = True
	    evaluate_on_domain_2.data_type = 'FLOAT'
	    evaluate_on_domain_2.domain = 'CURVE'
	
	    #node Group Input.005
	    group_input_005_5 = roll_hair_curves.nodes.new("NodeGroupInput")
	    group_input_005_5.name = "Group Input.005"
	    group_input_005_5.outputs[0].hide = True
	    group_input_005_5.outputs[1].hide = True
	    group_input_005_5.outputs[2].hide = True
	    group_input_005_5.outputs[3].hide = True
	    group_input_005_5.outputs[4].hide = True
	    group_input_005_5.outputs[6].hide = True
	    group_input_005_5.outputs[7].hide = True
	    group_input_005_5.outputs[8].hide = True
	    group_input_005_5.outputs[9].hide = True
	    group_input_005_5.outputs[10].hide = True
	    group_input_005_5.outputs[11].hide = True
	    group_input_005_5.outputs[12].hide = True
	    group_input_005_5.outputs[13].hide = True
	
	    #node Math.012
	    math_012_1 = roll_hair_curves.nodes.new("ShaderNodeMath")
	    math_012_1.name = "Math.012"
	    math_012_1.operation = 'MULTIPLY'
	    math_012_1.use_clamp = False
	
	    #node Math.005
	    math_005_1 = roll_hair_curves.nodes.new("ShaderNodeMath")
	    math_005_1.name = "Math.005"
	    math_005_1.operation = 'DIVIDE'
	    math_005_1.use_clamp = False
	
	    #node Mix
	    mix_2 = roll_hair_curves.nodes.new("ShaderNodeMix")
	    mix_2.name = "Mix"
	    mix_2.blend_type = 'MIX'
	    mix_2.clamp_factor = True
	    mix_2.clamp_result = False
	    mix_2.data_type = 'FLOAT'
	    mix_2.factor_mode = 'UNIFORM'
	    #A_Float
	    mix_2.inputs[2].default_value = 1.0
	
	    #node Group Input.001
	    group_input_001_7 = roll_hair_curves.nodes.new("NodeGroupInput")
	    group_input_001_7.name = "Group Input.001"
	    group_input_001_7.outputs[0].hide = True
	    group_input_001_7.outputs[1].hide = True
	    group_input_001_7.outputs[2].hide = True
	    group_input_001_7.outputs[3].hide = True
	    group_input_001_7.outputs[4].hide = True
	    group_input_001_7.outputs[5].hide = True
	    group_input_001_7.outputs[6].hide = True
	    group_input_001_7.outputs[8].hide = True
	    group_input_001_7.outputs[9].hide = True
	    group_input_001_7.outputs[10].hide = True
	    group_input_001_7.outputs[11].hide = True
	    group_input_001_7.outputs[12].hide = True
	    group_input_001_7.outputs[13].hide = True
	
	    #node Math.011
	    math_011 = roll_hair_curves.nodes.new("ShaderNodeMath")
	    math_011.name = "Math.011"
	    math_011.operation = 'SUBTRACT'
	    math_011.use_clamp = False
	    #Value
	    math_011.inputs[0].default_value = 1.0
	
	    #node Math.010
	    math_010_1 = roll_hair_curves.nodes.new("ShaderNodeMath")
	    math_010_1.name = "Math.010"
	    math_010_1.operation = 'DIVIDE'
	    math_010_1.use_clamp = False
	
	    #node Reroute.030
	    reroute_030_1 = roll_hair_curves.nodes.new("NodeReroute")
	    reroute_030_1.name = "Reroute.030"
	    reroute_030_1.socket_idname = "NodeSocketFloat"
	    #node Group Input.003
	    group_input_003_7 = roll_hair_curves.nodes.new("NodeGroupInput")
	    group_input_003_7.name = "Group Input.003"
	    group_input_003_7.outputs[0].hide = True
	    group_input_003_7.outputs[1].hide = True
	    group_input_003_7.outputs[2].hide = True
	    group_input_003_7.outputs[3].hide = True
	    group_input_003_7.outputs[4].hide = True
	    group_input_003_7.outputs[5].hide = True
	    group_input_003_7.outputs[6].hide = True
	    group_input_003_7.outputs[7].hide = True
	    group_input_003_7.outputs[8].hide = True
	    group_input_003_7.outputs[9].hide = True
	    group_input_003_7.outputs[10].hide = True
	    group_input_003_7.outputs[12].hide = True
	    group_input_003_7.outputs[13].hide = True
	
	    #node Random Value.004
	    random_value_004_3 = roll_hair_curves.nodes.new("FunctionNodeRandomValue")
	    random_value_004_3.label = "Hash Seed"
	    random_value_004_3.name = "Random Value.004"
	    random_value_004_3.data_type = 'INT'
	    #Min_002
	    random_value_004_3.inputs[4].default_value = -1073741823
	    #Max_002
	    random_value_004_3.inputs[5].default_value = 1073741823
	    #Seed
	    random_value_004_3.inputs[8].default_value = -615487
	
	
	
	
	    #Set parents
	    compare_005_2.parent = frame_008
	    reroute_019_3.parent = frame_008
	    switch_004_4.parent = frame_008
	    set_spline_type_2.parent = frame_008
	    set_spline_resolution.parent = frame_008
	    reroute_006_6.parent = frame_007_4
	    group_004_1.parent = frame_007_4
	    vector_math_027.parent = frame_006_5
	    vector_math_029.parent = frame_006_5
	    vector_math_026_1.parent = frame_006_5
	    combine_xyz_2.parent = frame_006_5
	    reroute_012_7.parent = frame_006_5
	    curve_tangent_002_1.parent = frame_006_5
	    normal_001_1.parent = frame_006_5
	    reroute_023_2.parent = frame_006_5
	    vector_math_032.parent = frame_006_5
	    reroute_020_4.parent = frame_006_5
	    vector_math_025_1.parent = frame_006_5
	    position_005.parent = frame_006_5
	    math_015_1.parent = frame_004_5
	    random_value_3.parent = frame_004_5
	    group_007_1.parent = frame_004_5
	    group_input_004_4.parent = frame_004_5
	    vector_math_007_5.parent = frame_001_5
	    reroute_009_6.parent = frame_001_5
	    vector_math_008_4.parent = frame_001_5
	    compare_001_3.parent = frame_001_5
	    vector_math_009_3.parent = frame_001_5
	    switch_8.parent = frame_001_5
	    group_input_009_2.parent = frame_009
	    group_005_3.parent = frame_009
	    math_003_3.parent = frame_8
	    math_002_2.parent = frame_8
	    math_007_2.parent = frame_8
	    math_006_2.parent = frame_8
	    math_004_1.parent = frame_8
	    reroute_11.parent = frame_8
	    vector_math_8.parent = frame_8
	    vector_math_004_6.parent = frame_8
	    vector_math_002_6.parent = frame_8
	    vector_math_005_2.parent = frame_8
	    vector_math_003_6.parent = frame_8
	    vector_math_006_3.parent = frame_8
	    math_008_1.parent = frame_8
	    reroute_004_8.parent = frame_8
	    position_3.parent = frame_8
	    mix_001.parent = frame_8
	    group_input_002_6.parent = frame_8
	    vector_math_001_6.parent = frame_8
	    reroute_005_6.parent = frame_8
	    reroute_008_6.parent = frame_8
	    reroute_001_8.parent = frame_8
	    math_017_1.parent = frame_8
	    group_input_006_5.parent = frame_8
	    reroute_027_2.parent = frame_010
	    group_input_010_2.parent = frame_010
	    set_position_5.parent = frame_010
	    compare_003_5.parent = frame_010
	    boolean_math_6.parent = frame_010
	    mix_006.parent = frame_010
	    position_006_1.parent = frame_010
	    capture_attribute_009.parent = frame_011
	    spline_resolution_3.parent = frame_011
	    set_spline_type_001_3.parent = frame_011
	    group_003_2.parent = frame_002_6
	    accumulate_field_4.parent = frame_002_6
	    group_002_4.parent = frame_002_6
	    math_014_1.parent = frame_002_6
	    math_013_1.parent = frame_002_6
	    switch_001_8.parent = frame_002_6
	    group_input_008_4.parent = frame_002_6
	    compare_002_5.parent = frame_002_6
	    vector_math_014_3.parent = frame_005_4
	    normal_2.parent = frame_005_4
	    curve_tangent_001_1.parent = frame_005_4
	    separate_xyz_3.parent = frame_005_4
	    vector_math_016_2.parent = frame_005_4
	    vector_math_030.parent = frame_005_4
	    vector_math_031.parent = frame_005_4
	    vector_math_013_3.parent = frame_005_4
	    vector_math_012_3.parent = frame_005_4
	    subdivide_curve_004.parent = frame_012
	    math_022.parent = frame_012
	    math_023.parent = frame_012
	    group_input_014.parent = frame_012
	    compare_7.parent = frame_002_6
	    reroute_003_7.parent = frame_003_5
	    reroute_002_7.parent = frame_003_5
	    evaluate_on_domain_2.parent = frame_003_5
	    group_input_005_5.parent = frame_003_5
	    math_012_1.parent = frame_003_5
	    math_005_1.parent = frame_003_5
	    mix_2.parent = frame_003_5
	    group_input_001_7.parent = frame_003_5
	    math_011.parent = frame_003_5
	    math_010_1.parent = frame_003_5
	    reroute_030_1.parent = frame_003_5
	    group_input_003_7.parent = frame_004_5
	    random_value_004_3.parent = frame_004_5
	
	    #Set locations
	    frame_008.location = (-947.904052734375, -31.0)
	    frame_007_4.location = (-8846.0, -362.0)
	    frame_006_5.location = (-7711.0, 120.0)
	    frame_004_5.location = (-7711.0, -663.0)
	    frame_001_5.location = (-7377.67138671875, -403.0)
	    frame_009.location = (-1392.0, -20.0)
	    frame_8.location = (-4204.0, -201.0)
	    frame_010.location = (-3017.4853515625, 200.0)
	    frame_011.location = (-9951.0, -101.0)
	    frame_002_6.location = (-5651.0, -40.0)
	    frame_005_4.location = (-2336.0, -302.0)
	    frame_012.location = (-4034.0, 190.0)
	    frame_003_5.location = (-6654.32275390625, -704.0)
	    reroute_015_6.location = (-9951.4189453125, 291.11627197265625)
	    reroute_016_5.location = (-9951.4189453125, 311.2093505859375)
	    reroute_017_5.location = (-9951.4189453125, 331.3023681640625)
	    reroute_018_5.location = (-9951.4189453125, 271.02325439453125)
	    compare_005_2.location = (75.18603515625, -131.55880737304688)
	    reroute_019_3.location = (35.0, -252.11691284179688)
	    switch_004_4.location = (256.02294921875, -131.55880737304688)
	    set_spline_type_2.location = (259.3720703125, -39.55812072753906)
	    set_spline_resolution.location = (440.209228515625, -59.65113830566406)
	    separate_components_5.location = (-10313.09375, 90.18606567382812)
	    group_input_022.location = (-9047.2294921875, -572.8837280273438)
	    reroute_006_6.location = (411.6689453125, -80.56439208984375)
	    group_004_1.location = (29.9013671875, -40.37835693359375)
	    capture_attribute_002_5.location = (-7901.927734375, -532.6976928710938)
	    capture_attribute_001_5.location = (-7901.927734375, -472.41864013671875)
	    capture_attribute_003_2.location = (-7901.927734375, -412.1395263671875)
	    sample_curve_1.location = (-8102.857421875, -452.32562255859375)
	    group_input_023.location = (-1974.4853515625, -90.65115356445312)
	    set_position_002_2.location = (-1592.720703125, -50.465118408203125)
	    compare_004_5.location = (-1793.648193359375, -90.65115356445312)
	    join_geometry_4.location = (-166.1162109375, 150.46514892578125)
	    group_output_14.location = (75.0, 50.0)
	    reroute_010_5.location = (-547.8837890625, 311.2093505859375)
	    reroute_011_6.location = (-547.8837890625, 291.11627197265625)
	    reroute_013_6.location = (-547.8837890625, 351.3953857421875)
	    reroute_014_5.location = (-547.8837890625, 331.3023681640625)
	    reroute_029_1.location = (-7821.5556640625, -191.1162872314453)
	    capture_attribute_008.location = (-6495.416015625, 90.18606567382812)
	    vector_math_027.location = (625.115234375, -105.63532257080078)
	    vector_math_029.location = (625.115234375, -165.91439819335938)
	    vector_math_026_1.location = (625.115234375, -45.35624694824219)
	    combine_xyz_2.location = (826.04541015625, -45.35624694824219)
	    reroute_012_7.location = (402.603515625, -125.72834777832031)
	    curve_tangent_002_1.location = (221.7666015625, -85.54229736328125)
	    normal_001_1.location = (221.7666015625, -145.8213653564453)
	    reroute_023_2.location = (402.20458984375, -165.47821044921875)
	    vector_math_032.location = (442.390625, -145.3851776123047)
	    reroute_020_4.location = (542.85546875, -65.0130844116211)
	    vector_math_025_1.location = (221.3671875, -44.92005920410156)
	    position_005.location = (30.095703125, -69.9999771118164)
	    reroute_022_2.location = (-7439.7880859375, -351.8604736328125)
	    group_input_007_5.location = (-7580.43896484375, -432.2325439453125)
	    reroute_028_3.location = (-7439.7880859375, -291.5814208984375)
	    math_015_1.location = (584.18115234375, -60.32342529296875)
	    random_value_3.location = (383.2509765625, -40.23040771484375)
	    group_007_1.location = (200.92578125, -80.41644287109375)
	    group_input_004_4.location = (381.7626953125, -200.974609375)
	    vector_math_007_5.location = (55.09326171875, -84.75344848632812)
	    reroute_009_6.location = (35.0, -104.84649658203125)
	    vector_math_008_4.location = (55.09326171875, -124.93951416015625)
	    compare_001_3.location = (55.09326171875, -44.5673828125)
	    vector_math_009_3.location = (55.09326171875, -165.12554931640625)
	    switch_8.location = (256.02294921875, -64.660400390625)
	    vector_rotate_1.location = (-6877.18359375, -512.6046752929688)
	    evaluate_on_domain_004.location = (-6696.345703125, -492.51165771484375)
	    group_input_009_2.location = (30.435302734375, -100.75691223144531)
	    group_005_3.location = (211.272705078125, -40.47783660888672)
	    math_003_3.location = (221.72607421875, -281.8193359375)
	    math_002_2.location = (221.72607421875, -241.63323974609375)
	    math_007_2.location = (221.72607421875, -322.00537109375)
	    math_006_2.location = (421.16796875, -241.63323974609375)
	    math_004_1.location = (421.16796875, -281.81927490234375)
	    reroute_11.location = (180.0517578125, -261.72625732421875)
	    vector_math_8.location = (622.09814453125, -261.72625732421875)
	    vector_math_004_6.location = (802.935302734375, -322.00531005859375)
	    vector_math_002_6.location = (622.09814453125, -301.91229248046875)
	    vector_math_005_2.location = (622.09814453125, -342.09832763671875)
	    vector_math_003_6.location = (802.935302734375, -281.81927490234375)
	    vector_math_006_3.location = (421.16796875, -382.284423828125)
	    math_008_1.location = (421.16796875, -422.470458984375)
	    reroute_004_8.location = (360.888916015625, -382.284423828125)
	    position_3.location = (722.60400390625, -160.88800048828125)
	    mix_001.location = (923.5341796875, -40.329864501953125)
	    group_input_002_6.location = (722.60400390625, -40.329864501953125)
	    vector_math_001_6.location = (1144.5576171875, -80.51589965820312)
	    reroute_005_6.location = (351.22412109375, -151.258544921875)
	    reroute_008_6.location = (49.8291015625, -412.46783447265625)
	    reroute_001_8.location = (170.386962890625, -332.09576416015625)
	    math_017_1.location = (210.572998046875, -452.65386962890625)
	    group_input_006_5.location = (29.73583984375, -472.74688720703125)
	    reroute_027_2.location = (35.0, -200.3566436767578)
	    group_input_010_2.location = (135.46533203125, -140.0775909423828)
	    set_position_5.location = (718.162841796875, -39.612457275390625)
	    compare_003_5.location = (336.3955078125, -119.98455810546875)
	    boolean_math_6.location = (517.232666015625, -119.98455810546875)
	    mix_006.location = (336.3955078125, -240.54270935058594)
	    position_006_1.location = (135.46533203125, -300.82177734375)
	    capture_attribute_007.location = (-9087.416015625, -311.6744384765625)
	    position_004_1.location = (-9288.345703125, -331.7674560546875)
	    group_input_11.location = (-10534.1171875, 130.37213134765625)
	    group_6.location = (-8886.4853515625, -733.6279296875)
	    math_009_2.location = (-8685.5556640625, -814.0)
	    reroute_026_2.location = (-8524.8115234375, -773.81396484375)
	    group_input_012_2.location = (-9067.3232421875, -793.906982421875)
	    group_input_011_1.location = (-9067.3232421875, -854.1860961914062)
	    math_016_1.location = (-8886.4853515625, -854.1860961914062)
	    math_6.location = (-8464.5322265625, -713.534912109375)
	    group_001_6.location = (-8464.5322265625, -834.0930786132812)
	    evaluate_on_domain_001_3.location = (-8886.4853515625, -894.3721313476562)
	    capture_attribute_009.location = (210.673828125, -40.28590393066406)
	    spline_resolution_3.location = (29.8369140625, -180.93707275390625)
	    set_spline_type_001_3.location = (401.4130859375, -50.20829772949219)
	    reroute_025_1.location = (-2778.20654296875, -914.4651489257812)
	    reroute_024_2.location = (-5129.09033203125, -914.4651489257812)
	    group_003_2.location = (29.70751953125, -209.1890869140625)
	    accumulate_field_4.location = (612.4052734375, -209.1890869140625)
	    group_002_4.location = (418.396484375, -331.8721923828125)
	    math_014_1.location = (411.47509765625, -148.91001892089844)
	    math_013_1.location = (230.6376953125, -148.91001892089844)
	    switch_001_8.location = (799.298828125, -114.92507934570312)
	    group_input_008_4.location = (421.7041015625, -60.459716796875)
	    compare_002_5.location = (622.63427734375, -40.36668395996094)
	    vector_math_014_3.location = (29.7568359375, -100.021484375)
	    normal_2.location = (29.7568359375, -39.742431640625)
	    curve_tangent_001_1.location = (29.7568359375, -140.20751953125)
	    separate_xyz_3.location = (29.7568359375, -200.486572265625)
	    vector_math_016_2.location = (240.33447265625, -166.708740234375)
	    vector_math_030.location = (240.33447265625, -206.894775390625)
	    vector_math_031.location = (421.171630859375, -186.8017578125)
	    vector_math_013_3.location = (421.171630859375, -146.61572265625)
	    vector_math_012_3.location = (240.33447265625, -126.5225830078125)
	    subdivide_curve_004.location = (592.723876953125, -39.534881591796875)
	    math_022.location = (210.956298828125, -140.0)
	    math_023.location = (371.70068359375, -140.0)
	    group_input_014.location = (30.119140625, -180.18605041503906)
	    reroute_007_6.location = (-5390.29931640625, -1135.4884033203125)
	    compare_7.location = (230.6376953125, -339.10443115234375)
	    reroute_031.location = (-6796.81103515625, -773.81396484375)
	    reroute_021_3.location = (-6615.9736328125, -653.255859375)
	    spline_parameter_2.location = (-7399.6015625, -1035.0233154296875)
	    math_001_4.location = (-7198.671875, -1115.3953857421875)
	    reroute_003_7.location = (514.1044921875, -137.55267333984375)
	    reroute_002_7.location = (835.59326171875, -157.64569091796875)
	    evaluate_on_domain_2.location = (293.08154296875, -97.36663818359375)
	    group_input_005_5.location = (94.44970703125, -120.47216796875)
	    math_012_1.location = (634.66259765625, -97.36663818359375)
	    math_005_1.location = (917.88818359375, -39.845947265625)
	    mix_2.location = (435.65576171875, -180.4970703125)
	    group_input_001_7.location = (254.818359375, -200.590087890625)
	    math_011.location = (254.818359375, -280.962158203125)
	    math_010_1.location = (73.98095703125, -280.962158203125)
	    reroute_030_1.location = (35.0, -229.56280517578125)
	    group_input_003_7.location = (30.09326171875, -211.279052734375)
	    random_value_004_3.location = (210.9306640625, -151.0)
	
	    #Set dimensions
	    frame_008.width, frame_008.height = 609.904052734375, 310.0
	    frame_007_4.width, frame_007_4.height = 446.6689453125, 298.0
	    frame_006_5.width, frame_006_5.height = 996.0, 226.0
	    frame_004_5.width, frame_004_5.height = 754.0, 348.0
	    frame_001_5.width, frame_001_5.height = 425.67138671875, 238.0
	    frame_009.width, frame_009.height = 381.0, 254.0
	    frame_8.width, frame_8.height = 1315.0, 631.0
	    frame_010.width, frame_010.height = 888.4853515625, 468.0
	    frame_011.width, frame_011.height = 571.0, 261.0
	    frame_002_6.width, frame_002_6.height = 969.0, 517.0
	    frame_005_4.width, frame_005_4.height = 591.0, 349.0
	    frame_012.width, frame_012.height = 763.0, 318.0
	    frame_003_5.width, frame_003_5.height = 1088.32275390625, 459.0
	    reroute_015_6.width, reroute_015_6.height = 10.0, 100.0
	    reroute_016_5.width, reroute_016_5.height = 10.0, 100.0
	    reroute_017_5.width, reroute_017_5.height = 10.0, 100.0
	    reroute_018_5.width, reroute_018_5.height = 10.0, 100.0
	    compare_005_2.width, compare_005_2.height = 140.0, 100.0
	    reroute_019_3.width, reroute_019_3.height = 10.0, 100.0
	    switch_004_4.width, switch_004_4.height = 140.0, 100.0
	    set_spline_type_2.width, set_spline_type_2.height = 140.0, 100.0
	    set_spline_resolution.width, set_spline_resolution.height = 140.0, 100.0
	    separate_components_5.width, separate_components_5.height = 140.0, 100.0
	    group_input_022.width, group_input_022.height = 140.0, 100.0
	    reroute_006_6.width, reroute_006_6.height = 10.0, 100.0
	    group_004_1.width, group_004_1.height = 140.0, 100.0
	    capture_attribute_002_5.width, capture_attribute_002_5.height = 140.0, 100.0
	    capture_attribute_001_5.width, capture_attribute_001_5.height = 140.0, 100.0
	    capture_attribute_003_2.width, capture_attribute_003_2.height = 140.0, 100.0
	    sample_curve_1.width, sample_curve_1.height = 140.0, 100.0
	    group_input_023.width, group_input_023.height = 140.0, 100.0
	    set_position_002_2.width, set_position_002_2.height = 140.0, 100.0
	    compare_004_5.width, compare_004_5.height = 140.0, 100.0
	    join_geometry_4.width, join_geometry_4.height = 140.0, 100.0
	    group_output_14.width, group_output_14.height = 140.0, 100.0
	    reroute_010_5.width, reroute_010_5.height = 10.0, 100.0
	    reroute_011_6.width, reroute_011_6.height = 10.0, 100.0
	    reroute_013_6.width, reroute_013_6.height = 10.0, 100.0
	    reroute_014_5.width, reroute_014_5.height = 10.0, 100.0
	    reroute_029_1.width, reroute_029_1.height = 10.0, 100.0
	    capture_attribute_008.width, capture_attribute_008.height = 140.0, 100.0
	    vector_math_027.width, vector_math_027.height = 140.0, 100.0
	    vector_math_029.width, vector_math_029.height = 140.0, 100.0
	    vector_math_026_1.width, vector_math_026_1.height = 140.0, 100.0
	    combine_xyz_2.width, combine_xyz_2.height = 140.0, 100.0
	    reroute_012_7.width, reroute_012_7.height = 10.0, 100.0
	    curve_tangent_002_1.width, curve_tangent_002_1.height = 140.0, 100.0
	    normal_001_1.width, normal_001_1.height = 140.0, 100.0
	    reroute_023_2.width, reroute_023_2.height = 10.0, 100.0
	    vector_math_032.width, vector_math_032.height = 140.0, 100.0
	    reroute_020_4.width, reroute_020_4.height = 10.0, 100.0
	    vector_math_025_1.width, vector_math_025_1.height = 140.0, 100.0
	    position_005.width, position_005.height = 140.0, 100.0
	    reroute_022_2.width, reroute_022_2.height = 10.0, 100.0
	    group_input_007_5.width, group_input_007_5.height = 140.0, 100.0
	    reroute_028_3.width, reroute_028_3.height = 10.0, 100.0
	    math_015_1.width, math_015_1.height = 140.0, 100.0
	    random_value_3.width, random_value_3.height = 140.0, 100.0
	    group_007_1.width, group_007_1.height = 140.0, 100.0
	    group_input_004_4.width, group_input_004_4.height = 140.0, 100.0
	    vector_math_007_5.width, vector_math_007_5.height = 140.0, 100.0
	    reroute_009_6.width, reroute_009_6.height = 10.0, 100.0
	    vector_math_008_4.width, vector_math_008_4.height = 140.0, 100.0
	    compare_001_3.width, compare_001_3.height = 140.0, 100.0
	    vector_math_009_3.width, vector_math_009_3.height = 140.0, 100.0
	    switch_8.width, switch_8.height = 140.0, 100.0
	    vector_rotate_1.width, vector_rotate_1.height = 140.0, 100.0
	    evaluate_on_domain_004.width, evaluate_on_domain_004.height = 140.0, 100.0
	    group_input_009_2.width, group_input_009_2.height = 140.0, 100.0
	    group_005_3.width, group_005_3.height = 140.0, 100.0
	    math_003_3.width, math_003_3.height = 140.0, 100.0
	    math_002_2.width, math_002_2.height = 140.0, 100.0
	    math_007_2.width, math_007_2.height = 140.0, 100.0
	    math_006_2.width, math_006_2.height = 140.0, 100.0
	    math_004_1.width, math_004_1.height = 140.0, 100.0
	    reroute_11.width, reroute_11.height = 10.0, 100.0
	    vector_math_8.width, vector_math_8.height = 140.0, 100.0
	    vector_math_004_6.width, vector_math_004_6.height = 140.0, 100.0
	    vector_math_002_6.width, vector_math_002_6.height = 140.0, 100.0
	    vector_math_005_2.width, vector_math_005_2.height = 140.0, 100.0
	    vector_math_003_6.width, vector_math_003_6.height = 140.0, 100.0
	    vector_math_006_3.width, vector_math_006_3.height = 140.0, 100.0
	    math_008_1.width, math_008_1.height = 140.0, 100.0
	    reroute_004_8.width, reroute_004_8.height = 10.0, 100.0
	    position_3.width, position_3.height = 140.0, 100.0
	    mix_001.width, mix_001.height = 140.0, 100.0
	    group_input_002_6.width, group_input_002_6.height = 140.0, 100.0
	    vector_math_001_6.width, vector_math_001_6.height = 140.0, 100.0
	    reroute_005_6.width, reroute_005_6.height = 10.0, 100.0
	    reroute_008_6.width, reroute_008_6.height = 10.0, 100.0
	    reroute_001_8.width, reroute_001_8.height = 10.0, 100.0
	    math_017_1.width, math_017_1.height = 140.0, 100.0
	    group_input_006_5.width, group_input_006_5.height = 140.0, 100.0
	    reroute_027_2.width, reroute_027_2.height = 10.0, 100.0
	    group_input_010_2.width, group_input_010_2.height = 140.0, 100.0
	    set_position_5.width, set_position_5.height = 140.0, 100.0
	    compare_003_5.width, compare_003_5.height = 140.0, 100.0
	    boolean_math_6.width, boolean_math_6.height = 140.0, 100.0
	    mix_006.width, mix_006.height = 140.0, 100.0
	    position_006_1.width, position_006_1.height = 140.0, 100.0
	    capture_attribute_007.width, capture_attribute_007.height = 140.0, 100.0
	    position_004_1.width, position_004_1.height = 140.0, 100.0
	    group_input_11.width, group_input_11.height = 140.0, 100.0
	    group_6.width, group_6.height = 140.0, 100.0
	    math_009_2.width, math_009_2.height = 140.0, 100.0
	    reroute_026_2.width, reroute_026_2.height = 10.0, 100.0
	    group_input_012_2.width, group_input_012_2.height = 140.0, 100.0
	    group_input_011_1.width, group_input_011_1.height = 140.0, 100.0
	    math_016_1.width, math_016_1.height = 140.0, 100.0
	    math_6.width, math_6.height = 140.0, 100.0
	    group_001_6.width, group_001_6.height = 140.0, 100.0
	    evaluate_on_domain_001_3.width, evaluate_on_domain_001_3.height = 140.0, 100.0
	    capture_attribute_009.width, capture_attribute_009.height = 140.0, 100.0
	    spline_resolution_3.width, spline_resolution_3.height = 140.0, 100.0
	    set_spline_type_001_3.width, set_spline_type_001_3.height = 140.0, 100.0
	    reroute_025_1.width, reroute_025_1.height = 10.0, 100.0
	    reroute_024_2.width, reroute_024_2.height = 10.0, 100.0
	    group_003_2.width, group_003_2.height = 140.0, 100.0
	    accumulate_field_4.width, accumulate_field_4.height = 140.0, 100.0
	    group_002_4.width, group_002_4.height = 140.0, 100.0
	    math_014_1.width, math_014_1.height = 140.0, 100.0
	    math_013_1.width, math_013_1.height = 140.0, 100.0
	    switch_001_8.width, switch_001_8.height = 140.0, 100.0
	    group_input_008_4.width, group_input_008_4.height = 140.0, 100.0
	    compare_002_5.width, compare_002_5.height = 140.0, 100.0
	    vector_math_014_3.width, vector_math_014_3.height = 140.0, 100.0
	    normal_2.width, normal_2.height = 140.0, 100.0
	    curve_tangent_001_1.width, curve_tangent_001_1.height = 140.0, 100.0
	    separate_xyz_3.width, separate_xyz_3.height = 140.0, 100.0
	    vector_math_016_2.width, vector_math_016_2.height = 140.0, 100.0
	    vector_math_030.width, vector_math_030.height = 140.0, 100.0
	    vector_math_031.width, vector_math_031.height = 140.0, 100.0
	    vector_math_013_3.width, vector_math_013_3.height = 140.0, 100.0
	    vector_math_012_3.width, vector_math_012_3.height = 140.0, 100.0
	    subdivide_curve_004.width, subdivide_curve_004.height = 140.0, 100.0
	    math_022.width, math_022.height = 140.0, 100.0
	    math_023.width, math_023.height = 140.0, 100.0
	    group_input_014.width, group_input_014.height = 140.0, 100.0
	    reroute_007_6.width, reroute_007_6.height = 10.0, 100.0
	    compare_7.width, compare_7.height = 140.0, 100.0
	    reroute_031.width, reroute_031.height = 10.0, 100.0
	    reroute_021_3.width, reroute_021_3.height = 10.0, 100.0
	    spline_parameter_2.width, spline_parameter_2.height = 140.0, 100.0
	    math_001_4.width, math_001_4.height = 140.0, 100.0
	    reroute_003_7.width, reroute_003_7.height = 10.0, 100.0
	    reroute_002_7.width, reroute_002_7.height = 10.0, 100.0
	    evaluate_on_domain_2.width, evaluate_on_domain_2.height = 140.0, 100.0
	    group_input_005_5.width, group_input_005_5.height = 140.0, 100.0
	    math_012_1.width, math_012_1.height = 140.0, 100.0
	    math_005_1.width, math_005_1.height = 140.0, 100.0
	    mix_2.width, mix_2.height = 140.0, 100.0
	    group_input_001_7.width, group_input_001_7.height = 140.0, 100.0
	    math_011.width, math_011.height = 140.0, 100.0
	    math_010_1.width, math_010_1.height = 140.0, 100.0
	    reroute_030_1.width, reroute_030_1.height = 10.0, 100.0
	    group_input_003_7.width, group_input_003_7.height = 140.0, 100.0
	    random_value_004_3.width, random_value_004_3.height = 140.0, 100.0
	
	    #initialize roll_hair_curves links
	    #reroute_006_6.Output -> sample_curve_1.Curves
	    roll_hair_curves.links.new(reroute_006_6.outputs[0], sample_curve_1.inputs[0])
	    #reroute_026_2.Output -> math_6.Value
	    roll_hair_curves.links.new(reroute_026_2.outputs[0], math_6.inputs[0])
	    #math_6.Value -> sample_curve_1.Length
	    roll_hair_curves.links.new(math_6.outputs[0], sample_curve_1.inputs[3])
	    #math_009_2.Value -> math_6.Value
	    roll_hair_curves.links.new(math_009_2.outputs[0], math_6.inputs[1])
	    #group_001_6.Curve Index -> sample_curve_1.Curve Index
	    roll_hair_curves.links.new(group_001_6.outputs[0], sample_curve_1.inputs[4])
	    #capture_attribute_003_2.Geometry -> capture_attribute_001_5.Geometry
	    roll_hair_curves.links.new(capture_attribute_003_2.outputs[0], capture_attribute_001_5.inputs[0])
	    #capture_attribute_001_5.Geometry -> capture_attribute_002_5.Geometry
	    roll_hair_curves.links.new(capture_attribute_001_5.outputs[0], capture_attribute_002_5.inputs[0])
	    #sample_curve_1.Tangent -> capture_attribute_001_5.Value
	    roll_hair_curves.links.new(sample_curve_1.outputs[2], capture_attribute_001_5.inputs[1])
	    #mix_001.Result -> vector_math_001_6.Vector
	    roll_hair_curves.links.new(mix_001.outputs[1], vector_math_001_6.inputs[0])
	    #reroute_005_6.Output -> vector_math_8.Vector
	    roll_hair_curves.links.new(reroute_005_6.outputs[0], vector_math_8.inputs[0])
	    #reroute_004_8.Output -> vector_math_002_6.Vector
	    roll_hair_curves.links.new(reroute_004_8.outputs[0], vector_math_002_6.inputs[0])
	    #spline_parameter_2.Length -> math_001_4.Value
	    roll_hair_curves.links.new(spline_parameter_2.outputs[1], math_001_4.inputs[0])
	    #reroute_11.Output -> math_002_2.Value
	    roll_hair_curves.links.new(reroute_11.outputs[0], math_002_2.inputs[0])
	    #reroute_11.Output -> math_003_3.Value
	    roll_hair_curves.links.new(reroute_11.outputs[0], math_003_3.inputs[0])
	    #math_006_2.Value -> vector_math_8.Scale
	    roll_hair_curves.links.new(math_006_2.outputs[0], vector_math_8.inputs[3])
	    #vector_math_8.Vector -> vector_math_003_6.Vector
	    roll_hair_curves.links.new(vector_math_8.outputs[0], vector_math_003_6.inputs[0])
	    #vector_math_002_6.Vector -> vector_math_003_6.Vector
	    roll_hair_curves.links.new(vector_math_002_6.outputs[0], vector_math_003_6.inputs[1])
	    #math_004_1.Value -> vector_math_002_6.Scale
	    roll_hair_curves.links.new(math_004_1.outputs[0], vector_math_002_6.inputs[3])
	    #reroute_021_3.Output -> compare_7.A
	    roll_hair_curves.links.new(reroute_021_3.outputs[0], compare_7.inputs[0])
	    #math_6.Value -> math_001_4.Value
	    roll_hair_curves.links.new(math_6.outputs[0], math_001_4.inputs[1])
	    #reroute_030_1.Output -> math_005_1.Value
	    roll_hair_curves.links.new(reroute_030_1.outputs[0], math_005_1.inputs[0])
	    #math_002_2.Value -> math_006_2.Value
	    roll_hair_curves.links.new(math_002_2.outputs[0], math_006_2.inputs[0])
	    #math_003_3.Value -> math_007_2.Value
	    roll_hair_curves.links.new(math_003_3.outputs[0], math_007_2.inputs[0])
	    #reroute_002_7.Output -> math_005_1.Value
	    roll_hair_curves.links.new(reroute_002_7.outputs[0], math_005_1.inputs[1])
	    #reroute_001_8.Output -> math_006_2.Value
	    roll_hair_curves.links.new(reroute_001_8.outputs[0], math_006_2.inputs[1])
	    #reroute_001_8.Output -> math_007_2.Value
	    roll_hair_curves.links.new(reroute_001_8.outputs[0], math_007_2.inputs[1])
	    #reroute_002_7.Output -> reroute_001_8.Input
	    roll_hair_curves.links.new(reroute_002_7.outputs[0], reroute_001_8.inputs[0])
	    #reroute_005_6.Output -> vector_math_006_3.Vector
	    roll_hair_curves.links.new(reroute_005_6.outputs[0], vector_math_006_3.inputs[0])
	    #reroute_004_8.Output -> vector_math_006_3.Vector
	    roll_hair_curves.links.new(reroute_004_8.outputs[0], vector_math_006_3.inputs[1])
	    #vector_math_006_3.Vector -> vector_math_005_2.Vector
	    roll_hair_curves.links.new(vector_math_006_3.outputs[0], vector_math_005_2.inputs[0])
	    #math_008_1.Value -> vector_math_005_2.Scale
	    roll_hair_curves.links.new(math_008_1.outputs[0], vector_math_005_2.inputs[3])
	    #vector_math_003_6.Vector -> vector_math_004_6.Vector
	    roll_hair_curves.links.new(vector_math_003_6.outputs[0], vector_math_004_6.inputs[0])
	    #vector_math_005_2.Vector -> vector_math_004_6.Vector
	    roll_hair_curves.links.new(vector_math_005_2.outputs[0], vector_math_004_6.inputs[1])
	    #vector_math_004_6.Vector -> vector_math_001_6.Vector
	    roll_hair_curves.links.new(vector_math_004_6.outputs[0], vector_math_001_6.inputs[1])
	    #group_6.Length -> math_009_2.Value
	    roll_hair_curves.links.new(group_6.outputs[2], math_009_2.inputs[0])
	    #math_012_1.Value -> reroute_002_7.Input
	    roll_hair_curves.links.new(math_012_1.outputs[0], reroute_002_7.inputs[0])
	    #reroute_030_1.Output -> math_010_1.Value
	    roll_hair_curves.links.new(reroute_030_1.outputs[0], math_010_1.inputs[0])
	    #reroute_026_2.Output -> math_010_1.Value
	    roll_hair_curves.links.new(reroute_026_2.outputs[0], math_010_1.inputs[1])
	    #math_010_1.Value -> math_011.Value
	    roll_hair_curves.links.new(math_010_1.outputs[0], math_011.inputs[1])
	    #reroute_003_7.Output -> math_012_1.Value
	    roll_hair_curves.links.new(reroute_003_7.outputs[0], math_012_1.inputs[0])
	    #mix_2.Result -> math_012_1.Value
	    roll_hair_curves.links.new(mix_2.outputs[0], math_012_1.inputs[1])
	    #math_011.Value -> mix_2.B
	    roll_hair_curves.links.new(math_011.outputs[0], mix_2.inputs[3])
	    #group_input_001_7.Roll Taper -> mix_2.Factor
	    roll_hair_curves.links.new(group_input_001_7.outputs[7], mix_2.inputs[0])
	    #math_007_2.Value -> math_004_1.Value
	    roll_hair_curves.links.new(math_007_2.outputs[0], math_004_1.inputs[1])
	    #reroute_003_7.Output -> math_004_1.Value
	    roll_hair_curves.links.new(reroute_003_7.outputs[0], math_004_1.inputs[0])
	    #reroute_028_3.Output -> mix_001.A
	    roll_hair_curves.links.new(reroute_028_3.outputs[0], mix_001.inputs[4])
	    #position_3.Position -> mix_001.B
	    roll_hair_curves.links.new(position_3.outputs[0], mix_001.inputs[5])
	    #math_017_1.Value -> math_008_1.Value
	    roll_hair_curves.links.new(math_017_1.outputs[0], math_008_1.inputs[1])
	    #group_input_002_6.Retain Overall Shape -> mix_001.Factor
	    roll_hair_curves.links.new(group_input_002_6.outputs[8], mix_001.inputs[0])
	    #group_002_4.Curve Index -> accumulate_field_4.Group ID
	    roll_hair_curves.links.new(group_002_4.outputs[0], accumulate_field_4.inputs[1])
	    #group_003_2.Segment Length -> math_013_1.Value
	    roll_hair_curves.links.new(group_003_2.outputs[0], math_013_1.inputs[0])
	    #math_014_1.Value -> accumulate_field_4.Value
	    roll_hair_curves.links.new(math_014_1.outputs[0], accumulate_field_4.inputs[0])
	    #math_013_1.Value -> math_014_1.Value
	    roll_hair_curves.links.new(math_013_1.outputs[0], math_014_1.inputs[0])
	    #reroute_002_7.Output -> math_013_1.Value
	    roll_hair_curves.links.new(reroute_002_7.outputs[0], math_013_1.inputs[1])
	    #compare_7.Result -> math_014_1.Value
	    roll_hair_curves.links.new(compare_7.outputs[0], math_014_1.inputs[1])
	    #evaluate_on_domain_2.Value -> reroute_003_7.Input
	    roll_hair_curves.links.new(evaluate_on_domain_2.outputs[0], reroute_003_7.inputs[0])
	    #math_016_1.Value -> evaluate_on_domain_001_3.Value
	    roll_hair_curves.links.new(math_016_1.outputs[0], evaluate_on_domain_001_3.inputs[0])
	    #evaluate_on_domain_004.Value -> reroute_004_8.Input
	    roll_hair_curves.links.new(evaluate_on_domain_004.outputs[0], reroute_004_8.inputs[0])
	    #reroute_022_2.Output -> reroute_005_6.Input
	    roll_hair_curves.links.new(reroute_022_2.outputs[0], reroute_005_6.inputs[0])
	    #reroute_022_2.Output -> vector_rotate_1.Axis
	    roll_hair_curves.links.new(reroute_022_2.outputs[0], vector_rotate_1.inputs[2])
	    #math_015_1.Value -> vector_rotate_1.Angle
	    roll_hair_curves.links.new(math_015_1.outputs[0], vector_rotate_1.inputs[3])
	    #random_value_004_3.Value -> random_value_3.Seed
	    roll_hair_curves.links.new(random_value_004_3.outputs[2], random_value_3.inputs[8])
	    #random_value_3.Value -> math_015_1.Value
	    roll_hair_curves.links.new(random_value_3.outputs[1], math_015_1.inputs[0])
	    #group_input_004_4.Random Orientation -> math_015_1.Value
	    roll_hair_curves.links.new(group_input_004_4.outputs[10], math_015_1.inputs[1])
	    #group_004_1.Geometry -> reroute_006_6.Input
	    roll_hair_curves.links.new(group_004_1.outputs[0], reroute_006_6.inputs[0])
	    #group_input_005_5.Roll Radius -> evaluate_on_domain_2.Value
	    roll_hair_curves.links.new(group_input_005_5.outputs[5], evaluate_on_domain_2.inputs[0])
	    #switch_8.Output -> vector_rotate_1.Vector
	    roll_hair_curves.links.new(switch_8.outputs[0], vector_rotate_1.inputs[0])
	    #group_input_006_5.Roll Depth -> math_017_1.Value
	    roll_hair_curves.links.new(group_input_006_5.outputs[6], math_017_1.inputs[0])
	    #reroute_007_6.Output -> reroute_008_6.Input
	    roll_hair_curves.links.new(reroute_007_6.outputs[0], reroute_008_6.inputs[0])
	    #reroute_008_6.Output -> math_008_1.Value
	    roll_hair_curves.links.new(reroute_008_6.outputs[0], math_008_1.inputs[0])
	    #compare_001_3.Result -> switch_8.Switch
	    roll_hair_curves.links.new(compare_001_3.outputs[0], switch_8.inputs[0])
	    #vector_math_009_3.Vector -> switch_8.True
	    roll_hair_curves.links.new(vector_math_009_3.outputs[0], switch_8.inputs[2])
	    #reroute_009_6.Output -> vector_math_007_5.Vector
	    roll_hair_curves.links.new(reroute_009_6.outputs[0], vector_math_007_5.inputs[0])
	    #reroute_009_6.Output -> vector_math_008_4.Vector
	    roll_hair_curves.links.new(reroute_009_6.outputs[0], vector_math_008_4.inputs[0])
	    #vector_math_007_5.Vector -> vector_math_008_4.Vector
	    roll_hair_curves.links.new(vector_math_007_5.outputs[0], vector_math_008_4.inputs[1])
	    #vector_math_008_4.Vector -> vector_math_009_3.Vector
	    roll_hair_curves.links.new(vector_math_008_4.outputs[0], vector_math_009_3.inputs[0])
	    #group_input_007_5.Roll Direction -> compare_001_3.A
	    roll_hair_curves.links.new(group_input_007_5.outputs[9], compare_001_3.inputs[4])
	    #group_input_007_5.Roll Direction -> reroute_009_6.Input
	    roll_hair_curves.links.new(group_input_007_5.outputs[9], reroute_009_6.inputs[0])
	    #math_005_1.Value -> switch_001_8.True
	    roll_hair_curves.links.new(math_005_1.outputs[0], switch_001_8.inputs[2])
	    #compare_002_5.Result -> switch_001_8.Switch
	    roll_hair_curves.links.new(compare_002_5.outputs[0], switch_001_8.inputs[0])
	    #group_input_008_4.Roll Taper -> compare_002_5.A
	    roll_hair_curves.links.new(group_input_008_4.outputs[7], compare_002_5.inputs[0])
	    #switch_001_8.Output -> reroute_11.Input
	    roll_hair_curves.links.new(switch_001_8.outputs[0], reroute_11.inputs[0])
	    #accumulate_field_4.Leading -> switch_001_8.False
	    roll_hair_curves.links.new(accumulate_field_4.outputs[0], switch_001_8.inputs[1])
	    #group_input_010_2.Factor -> compare_003_5.A
	    roll_hair_curves.links.new(group_input_010_2.outputs[1], compare_003_5.inputs[0])
	    #compare_003_5.Result -> boolean_math_6.Boolean
	    roll_hair_curves.links.new(compare_003_5.outputs[0], boolean_math_6.inputs[1])
	    #reroute_006_6.Output -> capture_attribute_003_2.Geometry
	    roll_hair_curves.links.new(reroute_006_6.outputs[0], capture_attribute_003_2.inputs[0])
	    #vector_math_012_3.Vector -> vector_math_013_3.Vector
	    roll_hair_curves.links.new(vector_math_012_3.outputs[0], vector_math_013_3.inputs[0])
	    #vector_math_016_2.Vector -> vector_math_013_3.Vector
	    roll_hair_curves.links.new(vector_math_016_2.outputs[0], vector_math_013_3.inputs[1])
	    #normal_2.Normal -> vector_math_012_3.Vector
	    roll_hair_curves.links.new(normal_2.outputs[0], vector_math_012_3.inputs[0])
	    #normal_2.Normal -> vector_math_014_3.Vector
	    roll_hair_curves.links.new(normal_2.outputs[0], vector_math_014_3.inputs[1])
	    #vector_math_014_3.Vector -> vector_math_016_2.Vector
	    roll_hair_curves.links.new(vector_math_014_3.outputs[0], vector_math_016_2.inputs[0])
	    #reroute_027_2.Output -> boolean_math_6.Boolean
	    roll_hair_curves.links.new(reroute_027_2.outputs[0], boolean_math_6.inputs[0])
	    #boolean_math_6.Boolean -> set_position_5.Selection
	    roll_hair_curves.links.new(boolean_math_6.outputs[0], set_position_5.inputs[1])
	    #sample_curve_1.Position -> capture_attribute_003_2.Value
	    roll_hair_curves.links.new(sample_curve_1.outputs[1], capture_attribute_003_2.inputs[1])
	    #capture_attribute_007.Geometry -> group_004_1.Geometry
	    roll_hair_curves.links.new(capture_attribute_007.outputs[0], group_004_1.inputs[0])
	    #position_004_1.Position -> capture_attribute_007.Value
	    roll_hair_curves.links.new(position_004_1.outputs[0], capture_attribute_007.inputs[1])
	    #capture_attribute_002_5.Value -> switch_8.False
	    roll_hair_curves.links.new(capture_attribute_002_5.outputs[1], switch_8.inputs[1])
	    #sample_curve_1.Normal -> capture_attribute_002_5.Value
	    roll_hair_curves.links.new(sample_curve_1.outputs[3], capture_attribute_002_5.inputs[1])
	    #reroute_022_2.Output -> vector_math_007_5.Vector
	    roll_hair_curves.links.new(reroute_022_2.outputs[0], vector_math_007_5.inputs[1])
	    #vector_rotate_1.Vector -> evaluate_on_domain_004.Value
	    roll_hair_curves.links.new(vector_rotate_1.outputs[0], evaluate_on_domain_004.inputs[0])
	    #reroute_020_4.Output -> vector_math_026_1.Vector
	    roll_hair_curves.links.new(reroute_020_4.outputs[0], vector_math_026_1.inputs[0])
	    #separate_xyz_3.X -> vector_math_012_3.Scale
	    roll_hair_curves.links.new(separate_xyz_3.outputs[0], vector_math_012_3.inputs[3])
	    #separate_xyz_3.Y -> vector_math_016_2.Scale
	    roll_hair_curves.links.new(separate_xyz_3.outputs[1], vector_math_016_2.inputs[3])
	    #vector_math_013_3.Vector -> vector_math_031.Vector
	    roll_hair_curves.links.new(vector_math_013_3.outputs[0], vector_math_031.inputs[0])
	    #vector_math_030.Vector -> vector_math_031.Vector
	    roll_hair_curves.links.new(vector_math_030.outputs[0], vector_math_031.inputs[1])
	    #curve_tangent_001_1.Tangent -> vector_math_030.Vector
	    roll_hair_curves.links.new(curve_tangent_001_1.outputs[0], vector_math_030.inputs[0])
	    #separate_xyz_3.Z -> vector_math_030.Scale
	    roll_hair_curves.links.new(separate_xyz_3.outputs[2], vector_math_030.inputs[3])
	    #reroute_020_4.Output -> vector_math_029.Vector
	    roll_hair_curves.links.new(reroute_020_4.outputs[0], vector_math_029.inputs[0])
	    #reroute_020_4.Output -> vector_math_027.Vector
	    roll_hair_curves.links.new(reroute_020_4.outputs[0], vector_math_027.inputs[0])
	    #reroute_023_2.Output -> vector_math_032.Vector
	    roll_hair_curves.links.new(reroute_023_2.outputs[0], vector_math_032.inputs[1])
	    #reroute_012_7.Output -> vector_math_032.Vector
	    roll_hair_curves.links.new(reroute_012_7.outputs[0], vector_math_032.inputs[0])
	    #vector_math_032.Vector -> vector_math_027.Vector
	    roll_hair_curves.links.new(vector_math_032.outputs[0], vector_math_027.inputs[1])
	    #reroute_012_7.Output -> vector_math_029.Vector
	    roll_hair_curves.links.new(reroute_012_7.outputs[0], vector_math_029.inputs[1])
	    #reroute_023_2.Output -> vector_math_026_1.Vector
	    roll_hair_curves.links.new(reroute_023_2.outputs[0], vector_math_026_1.inputs[1])
	    #curve_tangent_001_1.Tangent -> vector_math_014_3.Vector
	    roll_hair_curves.links.new(curve_tangent_001_1.outputs[0], vector_math_014_3.inputs[0])
	    #vector_math_026_1.Value -> combine_xyz_2.X
	    roll_hair_curves.links.new(vector_math_026_1.outputs[1], combine_xyz_2.inputs[0])
	    #vector_math_027.Value -> combine_xyz_2.Y
	    roll_hair_curves.links.new(vector_math_027.outputs[1], combine_xyz_2.inputs[1])
	    #vector_math_029.Value -> combine_xyz_2.Z
	    roll_hair_curves.links.new(vector_math_029.outputs[1], combine_xyz_2.inputs[2])
	    #capture_attribute_002_5.Geometry -> capture_attribute_008.Geometry
	    roll_hair_curves.links.new(capture_attribute_002_5.outputs[0], capture_attribute_008.inputs[0])
	    #combine_xyz_2.Vector -> capture_attribute_008.Value
	    roll_hair_curves.links.new(combine_xyz_2.outputs[0], capture_attribute_008.inputs[1])
	    #reroute_025_1.Output -> separate_xyz_3.Vector
	    roll_hair_curves.links.new(reroute_025_1.outputs[0], separate_xyz_3.inputs[0])
	    #position_006_1.Position -> mix_006.A
	    roll_hair_curves.links.new(position_006_1.outputs[0], mix_006.inputs[4])
	    #vector_math_001_6.Vector -> mix_006.B
	    roll_hair_curves.links.new(vector_math_001_6.outputs[0], mix_006.inputs[5])
	    #compare_7.Result -> reroute_027_2.Input
	    roll_hair_curves.links.new(compare_7.outputs[0], reroute_027_2.inputs[0])
	    #reroute_027_2.Output -> mix_006.Factor
	    roll_hair_curves.links.new(reroute_027_2.outputs[0], mix_006.inputs[0])
	    #normal_001_1.Normal -> reroute_023_2.Input
	    roll_hair_curves.links.new(normal_001_1.outputs[0], reroute_023_2.inputs[0])
	    #curve_tangent_002_1.Tangent -> reroute_012_7.Input
	    roll_hair_curves.links.new(curve_tangent_002_1.outputs[0], reroute_012_7.inputs[0])
	    #set_position_5.Geometry -> set_position_002_2.Geometry
	    roll_hair_curves.links.new(set_position_5.outputs[0], set_position_002_2.inputs[0])
	    #vector_math_031.Vector -> set_position_002_2.Offset
	    roll_hair_curves.links.new(vector_math_031.outputs[0], set_position_002_2.inputs[3])
	    #reroute_029_1.Output -> vector_math_025_1.Vector
	    roll_hair_curves.links.new(reroute_029_1.outputs[0], vector_math_025_1.inputs[0])
	    #position_005.Position -> vector_math_025_1.Vector
	    roll_hair_curves.links.new(position_005.outputs[0], vector_math_025_1.inputs[1])
	    #group_input_022.Variation Level -> group_004_1.Iterations
	    roll_hair_curves.links.new(group_input_022.outputs[3], group_004_1.inputs[3])
	    #group_input_023.Variation Level -> compare_004_5.A
	    roll_hair_curves.links.new(group_input_023.outputs[3], compare_004_5.inputs[2])
	    #compare_004_5.Result -> set_position_002_2.Selection
	    roll_hair_curves.links.new(compare_004_5.outputs[0], set_position_002_2.inputs[1])
	    #mix_006.Result -> set_position_5.Position
	    roll_hair_curves.links.new(mix_006.outputs[1], set_position_5.inputs[2])
	    #group_input_011_1.Factor -> math_016_1.Value
	    roll_hair_curves.links.new(group_input_011_1.outputs[1], math_016_1.inputs[1])
	    #set_position_002_2.Geometry -> group_005_3.Curves
	    roll_hair_curves.links.new(set_position_002_2.outputs[0], group_005_3.inputs[0])
	    #reroute_029_1.Output -> group_005_3.Reference Position
	    roll_hair_curves.links.new(reroute_029_1.outputs[0], group_005_3.inputs[3])
	    #group_input_009_2.Preserve Length -> group_005_3.Selection
	    roll_hair_curves.links.new(group_input_009_2.outputs[12], group_005_3.inputs[1])
	    #reroute_011_6.Output -> join_geometry_4.Geometry
	    roll_hair_curves.links.new(reroute_011_6.outputs[0], join_geometry_4.inputs[0])
	    #reroute_017_5.Output -> reroute_013_6.Input
	    roll_hair_curves.links.new(reroute_017_5.outputs[0], reroute_013_6.inputs[0])
	    #reroute_015_6.Output -> reroute_010_5.Input
	    roll_hair_curves.links.new(reroute_015_6.outputs[0], reroute_010_5.inputs[0])
	    #reroute_016_5.Output -> reroute_014_5.Input
	    roll_hair_curves.links.new(reroute_016_5.outputs[0], reroute_014_5.inputs[0])
	    #reroute_018_5.Output -> reroute_011_6.Input
	    roll_hair_curves.links.new(reroute_018_5.outputs[0], reroute_011_6.inputs[0])
	    #separate_components_5.Mesh -> reroute_017_5.Input
	    roll_hair_curves.links.new(separate_components_5.outputs[0], reroute_017_5.inputs[0])
	    #separate_components_5.Volume -> reroute_015_6.Input
	    roll_hair_curves.links.new(separate_components_5.outputs[4], reroute_015_6.inputs[0])
	    #separate_components_5.Point Cloud -> reroute_016_5.Input
	    roll_hair_curves.links.new(separate_components_5.outputs[3], reroute_016_5.inputs[0])
	    #separate_components_5.Instances -> reroute_018_5.Input
	    roll_hair_curves.links.new(separate_components_5.outputs[5], reroute_018_5.inputs[0])
	    #join_geometry_4.Geometry -> group_output_14.Geometry
	    roll_hair_curves.links.new(join_geometry_4.outputs[0], group_output_14.inputs[0])
	    #group_input_11.Geometry -> separate_components_5.Geometry
	    roll_hair_curves.links.new(group_input_11.outputs[0], separate_components_5.inputs[0])
	    #group_007_1.Curve ID -> random_value_3.ID
	    roll_hair_curves.links.new(group_007_1.outputs[1], random_value_3.inputs[7])
	    #group_005_3.Curves -> set_spline_type_2.Curve
	    roll_hair_curves.links.new(group_005_3.outputs[0], set_spline_type_2.inputs[0])
	    #set_spline_type_2.Curve -> set_spline_resolution.Geometry
	    roll_hair_curves.links.new(set_spline_type_2.outputs[0], set_spline_resolution.inputs[0])
	    #separate_components_5.Curve -> capture_attribute_009.Geometry
	    roll_hair_curves.links.new(separate_components_5.outputs[1], capture_attribute_009.inputs[0])
	    #capture_attribute_009.Geometry -> set_spline_type_001_3.Curve
	    roll_hair_curves.links.new(capture_attribute_009.outputs[0], set_spline_type_001_3.inputs[0])
	    #spline_resolution_3.Resolution -> capture_attribute_009.Value
	    roll_hair_curves.links.new(spline_resolution_3.outputs[0], capture_attribute_009.inputs[1])
	    #subdivide_curve_004.Curve -> set_position_5.Geometry
	    roll_hair_curves.links.new(subdivide_curve_004.outputs[0], set_position_5.inputs[0])
	    #math_022.Value -> math_023.Value
	    roll_hair_curves.links.new(math_022.outputs[0], math_023.inputs[0])
	    #math_023.Value -> subdivide_curve_004.Cuts
	    roll_hair_curves.links.new(math_023.outputs[0], subdivide_curve_004.inputs[1])
	    #group_input_014.Subdivision -> math_022.Value
	    roll_hair_curves.links.new(group_input_014.outputs[2], math_022.inputs[1])
	    #capture_attribute_008.Geometry -> subdivide_curve_004.Curve
	    roll_hair_curves.links.new(capture_attribute_008.outputs[0], subdivide_curve_004.inputs[0])
	    #capture_attribute_001_5.Value -> reroute_022_2.Input
	    roll_hair_curves.links.new(capture_attribute_001_5.outputs[1], reroute_022_2.inputs[0])
	    #set_spline_type_001_3.Curve -> capture_attribute_007.Geometry
	    roll_hair_curves.links.new(set_spline_type_001_3.outputs[0], capture_attribute_007.inputs[0])
	    #reroute_019_3.Output -> compare_005_2.A
	    roll_hair_curves.links.new(reroute_019_3.outputs[0], compare_005_2.inputs[2])
	    #compare_005_2.Result -> switch_004_4.Switch
	    roll_hair_curves.links.new(compare_005_2.outputs[0], switch_004_4.inputs[0])
	    #reroute_019_3.Output -> switch_004_4.False
	    roll_hair_curves.links.new(reroute_019_3.outputs[0], switch_004_4.inputs[1])
	    #capture_attribute_009.Value -> reroute_019_3.Input
	    roll_hair_curves.links.new(capture_attribute_009.outputs[1], reroute_019_3.inputs[0])
	    #switch_004_4.Output -> set_spline_resolution.Resolution
	    roll_hair_curves.links.new(switch_004_4.outputs[0], set_spline_resolution.inputs[2])
	    #reroute_024_2.Output -> reroute_025_1.Input
	    roll_hair_curves.links.new(reroute_024_2.outputs[0], reroute_025_1.inputs[0])
	    #capture_attribute_008.Value -> reroute_024_2.Input
	    roll_hair_curves.links.new(capture_attribute_008.outputs[1], reroute_024_2.inputs[0])
	    #evaluate_on_domain_001_3.Value -> math_009_2.Value
	    roll_hair_curves.links.new(evaluate_on_domain_001_3.outputs[0], math_009_2.inputs[1])
	    #group_6.Length -> reroute_026_2.Input
	    roll_hair_curves.links.new(group_6.outputs[2], reroute_026_2.inputs[0])
	    #capture_attribute_003_2.Value -> reroute_028_3.Input
	    roll_hair_curves.links.new(capture_attribute_003_2.outputs[1], reroute_028_3.inputs[0])
	    #capture_attribute_007.Value -> reroute_029_1.Input
	    roll_hair_curves.links.new(capture_attribute_007.outputs[1], reroute_029_1.inputs[0])
	    #vector_math_025_1.Vector -> reroute_020_4.Input
	    roll_hair_curves.links.new(vector_math_025_1.outputs[0], reroute_020_4.inputs[0])
	    #group_input_012_2.Roll Length -> math_016_1.Value
	    roll_hair_curves.links.new(group_input_012_2.outputs[4], math_016_1.inputs[0])
	    #math_001_4.Value -> reroute_007_6.Input
	    roll_hair_curves.links.new(math_001_4.outputs[0], reroute_007_6.inputs[0])
	    #reroute_031.Output -> reroute_021_3.Input
	    roll_hair_curves.links.new(reroute_031.outputs[0], reroute_021_3.inputs[0])
	    #reroute_031.Output -> reroute_030_1.Input
	    roll_hair_curves.links.new(reroute_031.outputs[0], reroute_030_1.inputs[0])
	    #math_001_4.Value -> reroute_031.Input
	    roll_hair_curves.links.new(math_001_4.outputs[0], reroute_031.inputs[0])
	    #group_input_003_7.Seed -> random_value_004_3.ID
	    roll_hair_curves.links.new(group_input_003_7.outputs[11], random_value_004_3.inputs[7])
	    #reroute_010_5.Output -> join_geometry_4.Geometry
	    roll_hair_curves.links.new(reroute_010_5.outputs[0], join_geometry_4.inputs[0])
	    #set_spline_resolution.Geometry -> join_geometry_4.Geometry
	    roll_hair_curves.links.new(set_spline_resolution.outputs[0], join_geometry_4.inputs[0])
	    #reroute_014_5.Output -> join_geometry_4.Geometry
	    roll_hair_curves.links.new(reroute_014_5.outputs[0], join_geometry_4.inputs[0])
	    #reroute_013_6.Output -> join_geometry_4.Geometry
	    roll_hair_curves.links.new(reroute_013_6.outputs[0], join_geometry_4.inputs[0])
	    return roll_hair_curves
	
	roll_hair_curves = roll_hair_curves_node_group()
	
	#initialize attach_hair_curves_to_surface node group
	def attach_hair_curves_to_surface_node_group():
	    attach_hair_curves_to_surface = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Attach Hair Curves to Surface")
	
	    attach_hair_curves_to_surface.color_tag = 'GEOMETRY'
	    attach_hair_curves_to_surface.description = "Attaches hair curves to a surface mesh"
	    attach_hair_curves_to_surface.default_group_node_width = 140
	    
	
	    attach_hair_curves_to_surface.is_modifier = True
	
	    #attach_hair_curves_to_surface interface
	    #Socket Geometry
	    geometry_socket_19 = attach_hair_curves_to_surface.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_19.attribute_domain = 'POINT'
	
	    #Socket Surface UV Coordinate
	    surface_uv_coordinate_socket = attach_hair_curves_to_surface.interface.new_socket(name = "Surface UV Coordinate", in_out='OUTPUT', socket_type = 'NodeSocketVector')
	    surface_uv_coordinate_socket.default_value = (0.0, 0.0, 0.0)
	    surface_uv_coordinate_socket.min_value = -3.4028234663852886e+38
	    surface_uv_coordinate_socket.max_value = 3.4028234663852886e+38
	    surface_uv_coordinate_socket.subtype = 'NONE'
	    surface_uv_coordinate_socket.attribute_domain = 'CURVE'
	    surface_uv_coordinate_socket.description = "Surface UV coordinates at the attachment point"
	
	    #Socket Surface Normal
	    surface_normal_socket = attach_hair_curves_to_surface.interface.new_socket(name = "Surface Normal", in_out='OUTPUT', socket_type = 'NodeSocketVector')
	    surface_normal_socket.default_value = (0.0, 0.0, 0.0)
	    surface_normal_socket.min_value = -3.4028234663852886e+38
	    surface_normal_socket.max_value = 3.4028234663852886e+38
	    surface_normal_socket.subtype = 'NONE'
	    surface_normal_socket.attribute_domain = 'CURVE'
	    surface_normal_socket.description = "Surface normal at the attachment point"
	
	    #Socket Geometry
	    geometry_socket_20 = attach_hair_curves_to_surface.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_20.attribute_domain = 'POINT'
	    geometry_socket_20.description = "Input Geometry (may include other than curves)"
	
	    #Socket Surface
	    surface_socket_4 = attach_hair_curves_to_surface.interface.new_socket(name = "Surface", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    surface_socket_4.attribute_domain = 'POINT'
	    surface_socket_4.description = "Surface geometry to attach hair curves to"
	
	    #Socket Surface
	    surface_socket_5 = attach_hair_curves_to_surface.interface.new_socket(name = "Surface", in_out='INPUT', socket_type = 'NodeSocketObject')
	    surface_socket_5.attribute_domain = 'POINT'
	    surface_socket_5.description = "Surface Object to attach to (needs to have matching transforms)"
	
	    #Socket Surface UV Map
	    surface_uv_map_socket = attach_hair_curves_to_surface.interface.new_socket(name = "Surface UV Map", in_out='INPUT', socket_type = 'NodeSocketVector')
	    surface_uv_map_socket.default_value = (0.0, 0.0, 0.0)
	    surface_uv_map_socket.min_value = -3.4028234663852886e+38
	    surface_uv_map_socket.max_value = 3.4028234663852886e+38
	    surface_uv_map_socket.subtype = 'NONE'
	    surface_uv_map_socket.default_attribute_name = "UVMap"
	    surface_uv_map_socket.attribute_domain = 'POINT'
	    surface_uv_map_socket.hide_value = True
	    surface_uv_map_socket.description = "Surface UV map used for attachment"
	
	    #Socket Surface Rest Position
	    surface_rest_position_socket = attach_hair_curves_to_surface.interface.new_socket(name = "Surface Rest Position", in_out='INPUT', socket_type = 'NodeSocketBool')
	    surface_rest_position_socket.default_value = False
	    surface_rest_position_socket.attribute_domain = 'POINT'
	    surface_rest_position_socket.description = "Set the surface mesh into its rest position before attachment"
	
	    #Socket Sample Attachment UV
	    sample_attachment_uv_socket = attach_hair_curves_to_surface.interface.new_socket(name = "Sample Attachment UV", in_out='INPUT', socket_type = 'NodeSocketBool')
	    sample_attachment_uv_socket.default_value = True
	    sample_attachment_uv_socket.attribute_domain = 'POINT'
	    sample_attachment_uv_socket.description = "Sample the surface UV map at the attachment point"
	
	    #Socket Snap to Surface
	    snap_to_surface_socket = attach_hair_curves_to_surface.interface.new_socket(name = "Snap to Surface", in_out='INPUT', socket_type = 'NodeSocketBool')
	    snap_to_surface_socket.default_value = True
	    snap_to_surface_socket.attribute_domain = 'POINT'
	    snap_to_surface_socket.description = "Snap the root of each curve to the closest surface point"
	
	    #Socket Align to Surface Normal
	    align_to_surface_normal_socket = attach_hair_curves_to_surface.interface.new_socket(name = "Align to Surface Normal", in_out='INPUT', socket_type = 'NodeSocketBool')
	    align_to_surface_normal_socket.default_value = True
	    align_to_surface_normal_socket.attribute_domain = 'POINT'
	    align_to_surface_normal_socket.description = "Align the curve to the surface normal (needs a guide as reference)"
	
	    #Socket Blend along Curve
	    blend_along_curve_socket = attach_hair_curves_to_surface.interface.new_socket(name = "Blend along Curve", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    blend_along_curve_socket.default_value = 0.0
	    blend_along_curve_socket.min_value = 0.0
	    blend_along_curve_socket.max_value = 1.0
	    blend_along_curve_socket.subtype = 'FACTOR'
	    blend_along_curve_socket.attribute_domain = 'POINT'
	    blend_along_curve_socket.description = "Blend deformation along each curve from the root"
	
	
	    #initialize attach_hair_curves_to_surface nodes
	    #node Frame.004
	    frame_004_6 = attach_hair_curves_to_surface.nodes.new("NodeFrame")
	    frame_004_6.label = "Write Data"
	    frame_004_6.name = "Frame.004"
	    frame_004_6.label_size = 20
	    frame_004_6.shrink = True
	
	    #node Frame.005
	    frame_005_5 = attach_hair_curves_to_surface.nodes.new("NodeFrame")
	    frame_005_5.label = "Sample Surface"
	    frame_005_5.name = "Frame.005"
	    frame_005_5.label_size = 20
	    frame_005_5.shrink = True
	
	    #node Frame
	    frame_9 = attach_hair_curves_to_surface.nodes.new("NodeFrame")
	    frame_9.label = "Surface Geometry Input"
	    frame_9.name = "Frame"
	    frame_9.label_size = 20
	    frame_9.shrink = True
	
	    #node Frame.006
	    frame_006_6 = attach_hair_curves_to_surface.nodes.new("NodeFrame")
	    frame_006_6.label = "Geometry Socket with Priority"
	    frame_006_6.name = "Frame.006"
	    frame_006_6.label_size = 20
	    frame_006_6.shrink = True
	
	    #node Frame.007
	    frame_007_5 = attach_hair_curves_to_surface.nodes.new("NodeFrame")
	    frame_007_5.label = "Object in Local Space"
	    frame_007_5.name = "Frame.007"
	    frame_007_5.label_size = 20
	    frame_007_5.shrink = True
	
	    #node Frame.011
	    frame_011_1 = attach_hair_curves_to_surface.nodes.new("NodeFrame")
	    frame_011_1.label = "Sample Attachment UV"
	    frame_011_1.name = "Frame.011"
	    frame_011_1.label_size = 20
	    frame_011_1.shrink = True
	
	    #node Frame.001
	    frame_001_6 = attach_hair_curves_to_surface.nodes.new("NodeFrame")
	    frame_001_6.label = "Smooth Normals"
	    frame_001_6.name = "Frame.001"
	    frame_001_6.label_size = 20
	    frame_001_6.shrink = True
	
	    #node Frame.010
	    frame_010_1 = attach_hair_curves_to_surface.nodes.new("NodeFrame")
	    frame_010_1.label = "Calculate New Position"
	    frame_010_1.name = "Frame.010"
	    frame_010_1.use_custom_color = True
	    frame_010_1.color = (0.13328450918197632, 0.13328450918197632, 0.13328450918197632)
	    frame_010_1.label_size = 20
	    frame_010_1.shrink = True
	
	    #node Frame.003
	    frame_003_6 = attach_hair_curves_to_surface.nodes.new("NodeFrame")
	    frame_003_6.label = "Blend Deformation"
	    frame_003_6.name = "Frame.003"
	    frame_003_6.label_size = 20
	    frame_003_6.shrink = True
	
	    #node Frame.002
	    frame_002_7 = attach_hair_curves_to_surface.nodes.new("NodeFrame")
	    frame_002_7.label = "Align to Normal"
	    frame_002_7.name = "Frame.002"
	    frame_002_7.use_custom_color = True
	    frame_002_7.color = (0.08883915841579437, 0.08883915841579437, 0.08883915841579437)
	    frame_002_7.label_size = 20
	    frame_002_7.shrink = True
	
	    #node Frame.008
	    frame_008_1 = attach_hair_curves_to_surface.nodes.new("NodeFrame")
	    frame_008_1.label = "Optimize"
	    frame_008_1.name = "Frame.008"
	    frame_008_1.label_size = 20
	    frame_008_1.shrink = True
	
	    #node Frame.009
	    frame_009_1 = attach_hair_curves_to_surface.nodes.new("NodeFrame")
	    frame_009_1.label = "Sample from Guide"
	    frame_009_1.name = "Frame.009"
	    frame_009_1.label_size = 20
	    frame_009_1.shrink = True
	
	    #node Reroute.010
	    reroute_010_6 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_010_6.name = "Reroute.010"
	    reroute_010_6.socket_idname = "NodeSocketGeometry"
	    #node Reroute.013
	    reroute_013_7 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_013_7.name = "Reroute.013"
	    reroute_013_7.socket_idname = "NodeSocketBool"
	    #node Group Output
	    group_output_15 = attach_hair_curves_to_surface.nodes.new("NodeGroupOutput")
	    group_output_15.name = "Group Output"
	    group_output_15.is_active_output = True
	
	    #node Reroute.003
	    reroute_003_8 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_003_8.name = "Reroute.003"
	    reroute_003_8.socket_idname = "NodeSocketVector"
	    #node Switch
	    switch_9 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSwitch")
	    switch_9.name = "Switch"
	    switch_9.input_type = 'GEOMETRY'
	
	    #node Store Named Attribute
	    store_named_attribute_2 = attach_hair_curves_to_surface.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_2.name = "Store Named Attribute"
	    store_named_attribute_2.data_type = 'FLOAT2'
	    store_named_attribute_2.domain = 'CURVE'
	    #Selection
	    store_named_attribute_2.inputs[1].default_value = True
	    #Name
	    store_named_attribute_2.inputs[2].default_value = "surface_uv_coordinate"
	
	    #node Group Input.007
	    group_input_007_6 = attach_hair_curves_to_surface.nodes.new("NodeGroupInput")
	    group_input_007_6.name = "Group Input.007"
	    group_input_007_6.outputs[0].hide = True
	    group_input_007_6.outputs[1].hide = True
	    group_input_007_6.outputs[2].hide = True
	    group_input_007_6.outputs[3].hide = True
	    group_input_007_6.outputs[4].hide = True
	    group_input_007_6.outputs[6].hide = True
	    group_input_007_6.outputs[7].hide = True
	    group_input_007_6.outputs[8].hide = True
	    group_input_007_6.outputs[9].hide = True
	
	    #node Reroute.016
	    reroute_016_6 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_016_6.name = "Reroute.016"
	    reroute_016_6.socket_idname = "NodeSocketGeometry"
	    #node Reroute.005
	    reroute_005_7 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_005_7.name = "Reroute.005"
	    reroute_005_7.socket_idname = "NodeSocketVector"
	    #node Store Named Attribute.001
	    store_named_attribute_001 = attach_hair_curves_to_surface.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_001.name = "Store Named Attribute.001"
	    store_named_attribute_001.data_type = 'FLOAT_VECTOR'
	    store_named_attribute_001.domain = 'CURVE'
	    #Selection
	    store_named_attribute_001.inputs[1].default_value = True
	    #Name
	    store_named_attribute_001.inputs[2].default_value = "surface_normal"
	
	    #node Named Attribute.004
	    named_attribute_004 = attach_hair_curves_to_surface.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute_004.name = "Named Attribute.004"
	    named_attribute_004.data_type = 'FLOAT_VECTOR'
	    #Name
	    named_attribute_004.inputs[0].default_value = "surface_normal"
	
	    #node Reroute.012
	    reroute_012_8 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_012_8.name = "Reroute.012"
	    reroute_012_8.socket_idname = "NodeSocketBool"
	    #node Reroute.014
	    reroute_014_6 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_014_6.name = "Reroute.014"
	    reroute_014_6.socket_idname = "NodeSocketBool"
	    #node Reroute.006
	    reroute_006_7 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_006_7.name = "Reroute.006"
	    reroute_006_7.socket_idname = "NodeSocketGeometry"
	    #node Named Attribute.003
	    named_attribute_003_1 = attach_hair_curves_to_surface.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute_003_1.name = "Named Attribute.003"
	    named_attribute_003_1.data_type = 'FLOAT_VECTOR'
	    #Name
	    named_attribute_003_1.inputs[0].default_value = "surface_uv_coordinate"
	
	    #node Switch.008
	    switch_008 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSwitch")
	    switch_008.name = "Switch.008"
	    switch_008.input_type = 'GEOMETRY'
	
	    #node Switch.009
	    switch_009 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSwitch")
	    switch_009.name = "Switch.009"
	    switch_009.input_type = 'VECTOR'
	
	    #node Switch.010
	    switch_010 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSwitch")
	    switch_010.name = "Switch.010"
	    switch_010.input_type = 'VECTOR'
	
	    #node Set Position.001
	    set_position_001_4 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSetPosition")
	    set_position_001_4.name = "Set Position.001"
	    set_position_001_4.inputs[2].hide = True
	    #Position
	    set_position_001_4.inputs[2].default_value = (0.0, 0.0, 0.0)
	
	    #node Reroute.002
	    reroute_002_8 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_002_8.name = "Reroute.002"
	    reroute_002_8.socket_idname = "NodeSocketVector"
	    #node Reroute.018
	    reroute_018_6 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_018_6.name = "Reroute.018"
	    reroute_018_6.socket_idname = "NodeSocketVector"
	    #node Reroute.017
	    reroute_017_6 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_017_6.name = "Reroute.017"
	    reroute_017_6.socket_idname = "NodeSocketGeometry"
	    #node Group Input.009
	    group_input_009_3 = attach_hair_curves_to_surface.nodes.new("NodeGroupInput")
	    group_input_009_3.name = "Group Input.009"
	    group_input_009_3.outputs[0].hide = True
	    group_input_009_3.outputs[1].hide = True
	    group_input_009_3.outputs[2].hide = True
	    group_input_009_3.outputs[4].hide = True
	    group_input_009_3.outputs[5].hide = True
	    group_input_009_3.outputs[6].hide = True
	    group_input_009_3.outputs[7].hide = True
	    group_input_009_3.outputs[8].hide = True
	    group_input_009_3.outputs[9].hide = True
	
	    #node Position
	    position_4 = attach_hair_curves_to_surface.nodes.new("GeometryNodeInputPosition")
	    position_4.name = "Position"
	
	    #node Named Attribute.001
	    named_attribute_001 = attach_hair_curves_to_surface.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute_001.name = "Named Attribute.001"
	    named_attribute_001.data_type = 'FLOAT_VECTOR'
	    #Name
	    named_attribute_001.inputs[0].default_value = "surface_uv_coordinate"
	
	    #node Capture Attribute.001
	    capture_attribute_001_6 = attach_hair_curves_to_surface.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_001_6.name = "Capture Attribute.001"
	    capture_attribute_001_6.active_index = 0
	    capture_attribute_001_6.capture_items.clear()
	    capture_attribute_001_6.capture_items.new('FLOAT', "Value")
	    capture_attribute_001_6.capture_items["Value"].data_type = 'FLOAT_VECTOR'
	    capture_attribute_001_6.domain = 'CURVE'
	
	    #node Group Input.004
	    group_input_004_5 = attach_hair_curves_to_surface.nodes.new("NodeGroupInput")
	    group_input_004_5.name = "Group Input.004"
	    group_input_004_5.outputs[0].hide = True
	    group_input_004_5.outputs[2].hide = True
	    group_input_004_5.outputs[3].hide = True
	    group_input_004_5.outputs[4].hide = True
	    group_input_004_5.outputs[5].hide = True
	    group_input_004_5.outputs[6].hide = True
	    group_input_004_5.outputs[7].hide = True
	    group_input_004_5.outputs[8].hide = True
	    group_input_004_5.outputs[9].hide = True
	
	    #node Domain Size.002
	    domain_size_002 = attach_hair_curves_to_surface.nodes.new("GeometryNodeAttributeDomainSize")
	    domain_size_002.name = "Domain Size.002"
	    domain_size_002.component = 'MESH'
	    domain_size_002.outputs[0].hide = True
	    domain_size_002.outputs[1].hide = True
	    domain_size_002.outputs[3].hide = True
	    domain_size_002.outputs[4].hide = True
	    domain_size_002.outputs[5].hide = True
	
	    #node Compare.001
	    compare_001_4 = attach_hair_curves_to_surface.nodes.new("FunctionNodeCompare")
	    compare_001_4.name = "Compare.001"
	    compare_001_4.data_type = 'INT'
	    compare_001_4.mode = 'ELEMENT'
	    compare_001_4.operation = 'NOT_EQUAL'
	    #B_INT
	    compare_001_4.inputs[3].default_value = 0
	
	    #node Object Info.001
	    object_info_001 = attach_hair_curves_to_surface.nodes.new("GeometryNodeObjectInfo")
	    object_info_001.name = "Object Info.001"
	    object_info_001.transform_space = 'ORIGINAL'
	    object_info_001.inputs[1].hide = True
	    object_info_001.outputs[1].hide = True
	    object_info_001.outputs[3].hide = True
	    #As Instance
	    object_info_001.inputs[1].default_value = False
	
	    #node Group Input.002
	    group_input_002_7 = attach_hair_curves_to_surface.nodes.new("NodeGroupInput")
	    group_input_002_7.name = "Group Input.002"
	    group_input_002_7.outputs[0].hide = True
	    group_input_002_7.outputs[1].hide = True
	    group_input_002_7.outputs[3].hide = True
	    group_input_002_7.outputs[4].hide = True
	    group_input_002_7.outputs[5].hide = True
	    group_input_002_7.outputs[6].hide = True
	    group_input_002_7.outputs[7].hide = True
	    group_input_002_7.outputs[8].hide = True
	    group_input_002_7.outputs[9].hide = True
	
	    #node Switch.005
	    switch_005_1 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSwitch")
	    switch_005_1.name = "Switch.005"
	    switch_005_1.input_type = 'GEOMETRY'
	
	    #node Domain Size.003
	    domain_size_003 = attach_hair_curves_to_surface.nodes.new("GeometryNodeAttributeDomainSize")
	    domain_size_003.name = "Domain Size.003"
	    domain_size_003.component = 'MESH'
	    domain_size_003.outputs[0].hide = True
	    domain_size_003.outputs[1].hide = True
	    domain_size_003.outputs[3].hide = True
	    domain_size_003.outputs[4].hide = True
	    domain_size_003.outputs[5].hide = True
	
	    #node Compare.002
	    compare_002_6 = attach_hair_curves_to_surface.nodes.new("FunctionNodeCompare")
	    compare_002_6.name = "Compare.002"
	    compare_002_6.data_type = 'INT'
	    compare_002_6.mode = 'ELEMENT'
	    compare_002_6.operation = 'EQUAL'
	    #B_INT
	    compare_002_6.inputs[3].default_value = 0
	
	    #node Named Attribute
	    named_attribute_2 = attach_hair_curves_to_surface.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute_2.name = "Named Attribute"
	    named_attribute_2.data_type = 'FLOAT_VECTOR'
	    #Name
	    named_attribute_2.inputs[0].default_value = "rest_position"
	
	    #node Reroute
	    reroute_12 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_12.name = "Reroute"
	    reroute_12.socket_idname = "NodeSocketGeometry"
	    #node Group Input.005
	    group_input_005_6 = attach_hair_curves_to_surface.nodes.new("NodeGroupInput")
	    group_input_005_6.name = "Group Input.005"
	    group_input_005_6.outputs[0].hide = True
	    group_input_005_6.outputs[1].hide = True
	    group_input_005_6.outputs[2].hide = True
	    group_input_005_6.outputs[3].hide = True
	    group_input_005_6.outputs[5].hide = True
	    group_input_005_6.outputs[6].hide = True
	    group_input_005_6.outputs[7].hide = True
	    group_input_005_6.outputs[8].hide = True
	    group_input_005_6.outputs[9].hide = True
	
	    #node Set Position
	    set_position_6 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSetPosition")
	    set_position_6.name = "Set Position"
	    set_position_6.inputs[3].hide = True
	    #Offset
	    set_position_6.inputs[3].default_value = (0.0, 0.0, 0.0)
	
	    #node Switch.007
	    switch_007 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSwitch")
	    switch_007.name = "Switch.007"
	    switch_007.input_type = 'GEOMETRY'
	
	    #node Reroute.015
	    reroute_015_7 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_015_7.name = "Reroute.015"
	    reroute_015_7.socket_idname = "NodeSocketBool"
	    #node Reroute.011
	    reroute_011_7 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_011_7.name = "Reroute.011"
	    reroute_011_7.socket_idname = "NodeSocketGeometry"
	    #node Group Input
	    group_input_12 = attach_hair_curves_to_surface.nodes.new("NodeGroupInput")
	    group_input_12.name = "Group Input"
	    group_input_12.outputs[1].hide = True
	    group_input_12.outputs[2].hide = True
	    group_input_12.outputs[3].hide = True
	    group_input_12.outputs[4].hide = True
	    group_input_12.outputs[5].hide = True
	    group_input_12.outputs[6].hide = True
	    group_input_12.outputs[7].hide = True
	    group_input_12.outputs[8].hide = True
	    group_input_12.outputs[9].hide = True
	
	    #node Capture Attribute.002
	    capture_attribute_002_6 = attach_hair_curves_to_surface.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_002_6.name = "Capture Attribute.002"
	    capture_attribute_002_6.active_index = 0
	    capture_attribute_002_6.capture_items.clear()
	    capture_attribute_002_6.capture_items.new('FLOAT', "Value")
	    capture_attribute_002_6.capture_items["Value"].data_type = 'FLOAT_VECTOR'
	    capture_attribute_002_6.domain = 'CURVE'
	
	    #node Reroute.001
	    reroute_001_9 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_001_9.name = "Reroute.001"
	    reroute_001_9.socket_idname = "NodeSocketGeometry"
	    #node Sample Nearest Surface
	    sample_nearest_surface = attach_hair_curves_to_surface.nodes.new("GeometryNodeSampleNearestSurface")
	    sample_nearest_surface.name = "Sample Nearest Surface"
	    sample_nearest_surface.data_type = 'FLOAT_VECTOR'
	    #Group ID
	    sample_nearest_surface.inputs[2].default_value = 0
	    #Sample Group ID
	    sample_nearest_surface.inputs[4].default_value = 0
	
	    #node Group
	    group_7 = attach_hair_curves_to_surface.nodes.new("GeometryNodeGroup")
	    group_7.name = "Group"
	    group_7.node_tree = curve_root
	    group_7.outputs[0].hide = True
	    group_7.outputs[2].hide = True
	    group_7.outputs[3].hide = True
	
	    #node Group Input.001
	    group_input_001_8 = attach_hair_curves_to_surface.nodes.new("NodeGroupInput")
	    group_input_001_8.name = "Group Input.001"
	    group_input_001_8.outputs[0].hide = True
	    group_input_001_8.outputs[1].hide = True
	    group_input_001_8.outputs[2].hide = True
	    group_input_001_8.outputs[4].hide = True
	    group_input_001_8.outputs[5].hide = True
	    group_input_001_8.outputs[6].hide = True
	    group_input_001_8.outputs[7].hide = True
	    group_input_001_8.outputs[8].hide = True
	    group_input_001_8.outputs[9].hide = True
	
	    #node Reroute.020
	    reroute_020_5 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_020_5.name = "Reroute.020"
	    reroute_020_5.socket_idname = "NodeSocketGeometry"
	    #node Normal
	    normal_3 = attach_hair_curves_to_surface.nodes.new("GeometryNodeInputNormal")
	    normal_3.name = "Normal"
	    normal_3.legacy_corner_normals = True
	
	    #node Capture Attribute
	    capture_attribute_4 = attach_hair_curves_to_surface.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_4.name = "Capture Attribute"
	    capture_attribute_4.hide = True
	    capture_attribute_4.active_index = 0
	    capture_attribute_4.capture_items.clear()
	    capture_attribute_4.capture_items.new('FLOAT', "Value")
	    capture_attribute_4.capture_items["Value"].data_type = 'FLOAT_VECTOR'
	    capture_attribute_4.domain = 'POINT'
	
	    #node Sample UV Surface
	    sample_uv_surface = attach_hair_curves_to_surface.nodes.new("GeometryNodeSampleUVSurface")
	    sample_uv_surface.name = "Sample UV Surface"
	    sample_uv_surface.hide = True
	    sample_uv_surface.data_type = 'FLOAT_VECTOR'
	    sample_uv_surface.outputs[1].hide = True
	
	    #node Sample UV Surface.003
	    sample_uv_surface_003 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSampleUVSurface")
	    sample_uv_surface_003.name = "Sample UV Surface.003"
	    sample_uv_surface_003.hide = True
	    sample_uv_surface_003.data_type = 'FLOAT_VECTOR'
	    sample_uv_surface_003.outputs[1].hide = True
	
	    #node Reroute.004
	    reroute_004_9 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_004_9.name = "Reroute.004"
	    reroute_004_9.socket_idname = "NodeSocketVector"
	    #node Sample UV Surface.001
	    sample_uv_surface_001 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSampleUVSurface")
	    sample_uv_surface_001.name = "Sample UV Surface.001"
	    sample_uv_surface_001.hide = True
	    sample_uv_surface_001.data_type = 'FLOAT_VECTOR'
	    sample_uv_surface_001.outputs[1].hide = True
	
	    #node Group.001
	    group_001_7 = attach_hair_curves_to_surface.nodes.new("GeometryNodeGroup")
	    group_001_7.name = "Group.001"
	    group_001_7.node_tree = curve_root
	    group_001_7.outputs[0].hide = True
	    group_001_7.outputs[2].hide = True
	    group_001_7.outputs[3].hide = True
	
	    #node Position.001
	    position_001_3 = attach_hair_curves_to_surface.nodes.new("GeometryNodeInputPosition")
	    position_001_3.name = "Position.001"
	
	    #node Vector Math
	    vector_math_9 = attach_hair_curves_to_surface.nodes.new("ShaderNodeVectorMath")
	    vector_math_9.name = "Vector Math"
	    vector_math_9.operation = 'SUBTRACT'
	
	    #node Vector Math.001
	    vector_math_001_7 = attach_hair_curves_to_surface.nodes.new("ShaderNodeVectorMath")
	    vector_math_001_7.name = "Vector Math.001"
	    vector_math_001_7.operation = 'SUBTRACT'
	
	    #node Vector Math.004
	    vector_math_004_7 = attach_hair_curves_to_surface.nodes.new("ShaderNodeVectorMath")
	    vector_math_004_7.name = "Vector Math.004"
	    vector_math_004_7.operation = 'SUBTRACT'
	
	    #node Vector Math.003
	    vector_math_003_7 = attach_hair_curves_to_surface.nodes.new("ShaderNodeVectorMath")
	    vector_math_003_7.name = "Vector Math.003"
	    vector_math_003_7.operation = 'SUBTRACT'
	
	    #node Group Input.003
	    group_input_003_8 = attach_hair_curves_to_surface.nodes.new("NodeGroupInput")
	    group_input_003_8.name = "Group Input.003"
	    group_input_003_8.outputs[0].hide = True
	    group_input_003_8.outputs[1].hide = True
	    group_input_003_8.outputs[2].hide = True
	    group_input_003_8.outputs[3].hide = True
	    group_input_003_8.outputs[4].hide = True
	    group_input_003_8.outputs[5].hide = True
	    group_input_003_8.outputs[6].hide = True
	    group_input_003_8.outputs[8].hide = True
	    group_input_003_8.outputs[9].hide = True
	
	    #node Group Input.006
	    group_input_006_6 = attach_hair_curves_to_surface.nodes.new("NodeGroupInput")
	    group_input_006_6.name = "Group Input.006"
	    group_input_006_6.outputs[0].hide = True
	    group_input_006_6.outputs[1].hide = True
	    group_input_006_6.outputs[2].hide = True
	    group_input_006_6.outputs[3].hide = True
	    group_input_006_6.outputs[4].hide = True
	    group_input_006_6.outputs[5].hide = True
	    group_input_006_6.outputs[7].hide = True
	    group_input_006_6.outputs[8].hide = True
	    group_input_006_6.outputs[9].hide = True
	
	    #node Switch.003
	    switch_003_5 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSwitch")
	    switch_003_5.name = "Switch.003"
	    switch_003_5.hide = True
	    switch_003_5.input_type = 'VECTOR'
	    #False
	    switch_003_5.inputs[1].default_value = (0.0, 0.0, 0.0)
	
	    #node Switch.002
	    switch_002_4 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSwitch")
	    switch_002_4.name = "Switch.002"
	    switch_002_4.input_type = 'VECTOR'
	
	    #node Vector Math.002
	    vector_math_002_7 = attach_hair_curves_to_surface.nodes.new("ShaderNodeVectorMath")
	    vector_math_002_7.name = "Vector Math.002"
	    vector_math_002_7.operation = 'ADD'
	
	    #node Vector Math.005
	    vector_math_005_3 = attach_hair_curves_to_surface.nodes.new("ShaderNodeVectorMath")
	    vector_math_005_3.name = "Vector Math.005"
	    vector_math_005_3.operation = 'SCALE'
	
	    #node Boolean Math
	    boolean_math_7 = attach_hair_curves_to_surface.nodes.new("FunctionNodeBooleanMath")
	    boolean_math_7.name = "Boolean Math"
	    boolean_math_7.operation = 'OR'
	
	    #node Spline Parameter
	    spline_parameter_3 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSplineParameter")
	    spline_parameter_3.name = "Spline Parameter"
	    spline_parameter_3.outputs[1].hide = True
	    spline_parameter_3.outputs[2].hide = True
	
	    #node Group Input.008
	    group_input_008_5 = attach_hair_curves_to_surface.nodes.new("NodeGroupInput")
	    group_input_008_5.name = "Group Input.008"
	    group_input_008_5.outputs[0].hide = True
	    group_input_008_5.outputs[1].hide = True
	    group_input_008_5.outputs[2].hide = True
	    group_input_008_5.outputs[3].hide = True
	    group_input_008_5.outputs[4].hide = True
	    group_input_008_5.outputs[5].hide = True
	    group_input_008_5.outputs[6].hide = True
	    group_input_008_5.outputs[7].hide = True
	    group_input_008_5.outputs[9].hide = True
	
	    #node Map Range
	    map_range_2 = attach_hair_curves_to_surface.nodes.new("ShaderNodeMapRange")
	    map_range_2.name = "Map Range"
	    map_range_2.hide = True
	    map_range_2.clamp = True
	    map_range_2.data_type = 'FLOAT'
	    map_range_2.interpolation_type = 'SMOOTHSTEP'
	    #From Min
	    map_range_2.inputs[1].default_value = 0.0
	    #To Min
	    map_range_2.inputs[3].default_value = 1.0
	    #To Max
	    map_range_2.inputs[4].default_value = 0.0
	
	    #node Compare
	    compare_8 = attach_hair_curves_to_surface.nodes.new("FunctionNodeCompare")
	    compare_8.name = "Compare"
	    compare_8.data_type = 'FLOAT'
	    compare_8.mode = 'ELEMENT'
	    compare_8.operation = 'EQUAL'
	    #B
	    compare_8.inputs[1].default_value = 0.0
	    #Epsilon
	    compare_8.inputs[12].default_value = 0.0
	
	    #node Switch.004
	    switch_004_5 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSwitch")
	    switch_004_5.name = "Switch.004"
	    switch_004_5.input_type = 'FLOAT'
	    #True
	    switch_004_5.inputs[2].default_value = 1.0
	
	    #node Position.002
	    position_002_5 = attach_hair_curves_to_surface.nodes.new("GeometryNodeInputPosition")
	    position_002_5.name = "Position.002"
	
	    #node Evaluate on Domain
	    evaluate_on_domain_3 = attach_hair_curves_to_surface.nodes.new("GeometryNodeFieldOnDomain")
	    evaluate_on_domain_3.name = "Evaluate on Domain"
	    evaluate_on_domain_3.data_type = 'FLOAT_VECTOR'
	    evaluate_on_domain_3.domain = 'CURVE'
	
	    #node Reroute.009
	    reroute_009_7 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_009_7.name = "Reroute.009"
	    reroute_009_7.socket_idname = "NodeSocketVector"
	    #node Evaluate on Domain.002
	    evaluate_on_domain_002_2 = attach_hair_curves_to_surface.nodes.new("GeometryNodeFieldOnDomain")
	    evaluate_on_domain_002_2.name = "Evaluate on Domain.002"
	    evaluate_on_domain_002_2.hide = True
	    evaluate_on_domain_002_2.data_type = 'FLOAT_VECTOR'
	    evaluate_on_domain_002_2.domain = 'CURVE'
	
	    #node Switch.006
	    switch_006_1 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSwitch")
	    switch_006_1.name = "Switch.006"
	    switch_006_1.input_type = 'VECTOR'
	
	    #node Vector Rotate
	    vector_rotate_2 = attach_hair_curves_to_surface.nodes.new("ShaderNodeVectorRotate")
	    vector_rotate_2.name = "Vector Rotate"
	    vector_rotate_2.invert = False
	    vector_rotate_2.rotation_type = 'EULER_XYZ'
	    vector_rotate_2.inputs[1].hide = True
	    vector_rotate_2.inputs[2].hide = True
	    vector_rotate_2.inputs[3].hide = True
	    #Center
	    vector_rotate_2.inputs[1].default_value = (0.0, 0.0, 0.0)
	
	    #node Vector Rotate.003
	    vector_rotate_003 = attach_hair_curves_to_surface.nodes.new("ShaderNodeVectorRotate")
	    vector_rotate_003.name = "Vector Rotate.003"
	    vector_rotate_003.invert = True
	    vector_rotate_003.rotation_type = 'EULER_XYZ'
	    vector_rotate_003.inputs[1].hide = True
	    vector_rotate_003.inputs[2].hide = True
	    vector_rotate_003.inputs[3].hide = True
	    #Center
	    vector_rotate_003.inputs[1].default_value = (0.0, 0.0, 0.0)
	
	    #node Align Euler to Vector.003
	    align_euler_to_vector_003 = attach_hair_curves_to_surface.nodes.new("FunctionNodeAlignEulerToVector")
	    align_euler_to_vector_003.name = "Align Euler to Vector.003"
	    align_euler_to_vector_003.axis = 'Z'
	    align_euler_to_vector_003.pivot_axis = 'AUTO'
	    align_euler_to_vector_003.inputs[0].hide = True
	    align_euler_to_vector_003.inputs[1].hide = True
	    #Rotation
	    align_euler_to_vector_003.inputs[0].default_value = (0.0, 0.0, 0.0)
	    #Factor
	    align_euler_to_vector_003.inputs[1].default_value = 1.0
	
	    #node Align Euler to Vector.002
	    align_euler_to_vector_002 = attach_hair_curves_to_surface.nodes.new("FunctionNodeAlignEulerToVector")
	    align_euler_to_vector_002.name = "Align Euler to Vector.002"
	    align_euler_to_vector_002.axis = 'Z'
	    align_euler_to_vector_002.pivot_axis = 'AUTO'
	    align_euler_to_vector_002.inputs[0].hide = True
	    align_euler_to_vector_002.inputs[1].hide = True
	    #Rotation
	    align_euler_to_vector_002.inputs[0].default_value = (0.0, 0.0, 0.0)
	    #Factor
	    align_euler_to_vector_002.inputs[1].default_value = 1.0
	
	    #node Evaluate on Domain.003
	    evaluate_on_domain_003 = attach_hair_curves_to_surface.nodes.new("GeometryNodeFieldOnDomain")
	    evaluate_on_domain_003.name = "Evaluate on Domain.003"
	    evaluate_on_domain_003.hide = True
	    evaluate_on_domain_003.data_type = 'FLOAT_VECTOR'
	    evaluate_on_domain_003.domain = 'CURVE'
	
	    #node Switch.001
	    switch_001_9 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSwitch")
	    switch_001_9.name = "Switch.001"
	    switch_001_9.hide = True
	    switch_001_9.input_type = 'VECTOR'
	
	    #node Accumulate Field
	    accumulate_field_5 = attach_hair_curves_to_surface.nodes.new("GeometryNodeAccumulateField")
	    accumulate_field_5.name = "Accumulate Field"
	    accumulate_field_5.hide = True
	    accumulate_field_5.data_type = 'FLOAT'
	    accumulate_field_5.domain = 'POINT'
	    #Group Index
	    accumulate_field_5.inputs[1].default_value = 0
	
	    #node Sample Index.001
	    sample_index_001_2 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSampleIndex")
	    sample_index_001_2.name = "Sample Index.001"
	    sample_index_001_2.hide = True
	    sample_index_001_2.clamp = False
	    sample_index_001_2.data_type = 'BOOLEAN'
	    sample_index_001_2.domain = 'CURVE'
	    #Index
	    sample_index_001_2.inputs[2].default_value = 0
	
	    #node Reroute.019
	    reroute_019_4 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_019_4.name = "Reroute.019"
	    reroute_019_4.socket_idname = "NodeSocketVector"
	    #node Named Attribute.002
	    named_attribute_002 = attach_hair_curves_to_surface.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute_002.name = "Named Attribute.002"
	    named_attribute_002.data_type = 'INT'
	    #Name
	    named_attribute_002.inputs[0].default_value = "guide_curve_index"
	
	    #node Reroute.007
	    reroute_007_7 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_007_7.name = "Reroute.007"
	    reroute_007_7.socket_idname = "NodeSocketGeometry"
	    #node Reroute.008
	    reroute_008_7 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_008_7.name = "Reroute.008"
	    reroute_008_7.socket_idname = "NodeSocketVector"
	    #node Sample Index
	    sample_index_4 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSampleIndex")
	    sample_index_4.name = "Sample Index"
	    sample_index_4.hide = True
	    sample_index_4.clamp = False
	    sample_index_4.data_type = 'FLOAT_VECTOR'
	    sample_index_4.domain = 'CURVE'
	
	
	
	
	    #Set parents
	    frame_006_6.parent = frame_9
	    frame_007_5.parent = frame_9
	    frame_003_6.parent = frame_010_1
	    frame_002_7.parent = frame_010_1
	    frame_008_1.parent = frame_002_7
	    frame_009_1.parent = frame_002_7
	    reroute_003_8.parent = frame_004_6
	    switch_9.parent = frame_004_6
	    store_named_attribute_2.parent = frame_004_6
	    group_input_007_6.parent = frame_004_6
	    reroute_016_6.parent = frame_004_6
	    reroute_005_7.parent = frame_004_6
	    store_named_attribute_001.parent = frame_004_6
	    named_attribute_004.parent = frame_004_6
	    reroute_012_8.parent = frame_004_6
	    named_attribute_003_1.parent = frame_004_6
	    switch_008.parent = frame_004_6
	    switch_009.parent = frame_004_6
	    switch_010.parent = frame_004_6
	    reroute_002_8.parent = frame_005_5
	    reroute_018_6.parent = frame_005_5
	    reroute_017_6.parent = frame_005_5
	    group_input_009_3.parent = frame_005_5
	    position_4.parent = frame_005_5
	    named_attribute_001.parent = frame_005_5
	    group_input_004_5.parent = frame_006_6
	    domain_size_002.parent = frame_006_6
	    compare_001_4.parent = frame_006_6
	    object_info_001.parent = frame_007_5
	    group_input_002_7.parent = frame_007_5
	    switch_005_1.parent = frame_9
	    domain_size_003.parent = frame_9
	    compare_002_6.parent = frame_9
	    named_attribute_2.parent = frame_9
	    reroute_12.parent = frame_9
	    group_input_005_6.parent = frame_9
	    set_position_6.parent = frame_9
	    switch_007.parent = frame_9
	    sample_nearest_surface.parent = frame_011_1
	    group_7.parent = frame_011_1
	    group_input_001_8.parent = frame_011_1
	    normal_3.parent = frame_001_6
	    capture_attribute_4.parent = frame_001_6
	    sample_uv_surface.parent = frame_005_5
	    sample_uv_surface_003.parent = frame_005_5
	    reroute_004_9.parent = frame_005_5
	    sample_uv_surface_001.parent = frame_005_5
	    group_001_7.parent = frame_010_1
	    position_001_3.parent = frame_010_1
	    vector_math_9.parent = frame_010_1
	    vector_math_001_7.parent = frame_010_1
	    vector_math_004_7.parent = frame_010_1
	    vector_math_003_7.parent = frame_010_1
	    group_input_003_8.parent = frame_010_1
	    group_input_006_6.parent = frame_010_1
	    switch_003_5.parent = frame_010_1
	    switch_002_4.parent = frame_010_1
	    vector_math_002_7.parent = frame_010_1
	    vector_math_005_3.parent = frame_010_1
	    boolean_math_7.parent = frame_010_1
	    spline_parameter_3.parent = frame_003_6
	    group_input_008_5.parent = frame_003_6
	    map_range_2.parent = frame_003_6
	    compare_8.parent = frame_003_6
	    switch_004_5.parent = frame_003_6
	    position_002_5.parent = frame_010_1
	    evaluate_on_domain_3.parent = frame_010_1
	    reroute_009_7.parent = frame_002_7
	    evaluate_on_domain_002_2.parent = frame_002_7
	    switch_006_1.parent = frame_002_7
	    vector_rotate_2.parent = frame_002_7
	    vector_rotate_003.parent = frame_002_7
	    align_euler_to_vector_003.parent = frame_002_7
	    align_euler_to_vector_002.parent = frame_002_7
	    evaluate_on_domain_003.parent = frame_002_7
	    switch_001_9.parent = frame_008_1
	    accumulate_field_5.parent = frame_008_1
	    sample_index_001_2.parent = frame_008_1
	    reroute_019_4.parent = frame_002_7
	    named_attribute_002.parent = frame_009_1
	    reroute_007_7.parent = frame_009_1
	    reroute_008_7.parent = frame_009_1
	    sample_index_4.parent = frame_009_1
	
	    #Set locations
	    frame_004_6.location = (-1215.903076171875, 262.0)
	    frame_005_5.location = (-4968.0, -121.0)
	    frame_9.location = (-7319.0, 140.0)
	    frame_006_6.location = (30.0, -355.0)
	    frame_007_5.location = (207.0, -181.0)
	    frame_011_1.location = (-5752.0, 120.0)
	    frame_001_6.location = (-5510.0, -382.0)
	    frame_010_1.location = (-4110.3515625, 32.0)
	    frame_003_6.location = (1565.3515625, -503.0)
	    frame_002_7.location = (29.999755859375, -437.0)
	    frame_008_1.location = (219.351806640625, -40.0)
	    frame_009_1.location = (30.0, -217.5032958984375)
	    reroute_010_6.location = (-798.60986328125, 472.99615478515625)
	    reroute_013_7.location = (-789.0, 512.1389770507812)
	    group_output_15.location = (75.0, 50.0)
	    reroute_003_8.location = (35.0, -292.3721618652344)
	    switch_9.location = (320.95263671875, -40.143096923828125)
	    store_named_attribute_2.location = (115.3720703125, -151.72100830078125)
	    group_input_007_6.location = (122.9049072265625, -39.53450012207031)
	    reroute_016_6.location = (45.1358642578125, -151.72100830078125)
	    reroute_005_7.location = (406.810302734375, -272.2791442871094)
	    store_named_attribute_001.location = (527.368408203125, -51.255889892578125)
	    named_attribute_004.location = (607.740478515625, -513.3954467773438)
	    reroute_012_8.location = (768.484619140625, -252.18612670898438)
	    reroute_014_6.location = (-507.69775390625, 311.209228515625)
	    reroute_006_7.location = (-547.8837890625, 291.1162109375)
	    named_attribute_003_1.location = (607.740478515625, -352.6512451171875)
	    switch_008.location = (808.670654296875, -71.34890747070312)
	    switch_009.location = (808.670654296875, -212.00006103515625)
	    switch_010.location = (808.670654296875, -392.8372802734375)
	    set_position_001_4.location = (-1472.16259765625, 230.837158203125)
	    reroute_002_8.location = (220.65625, -190.25262451171875)
	    reroute_018_6.location = (220.65625, -150.06658935546875)
	    reroute_017_6.location = (220.65625, -109.88055419921875)
	    group_input_009_3.location = (29.99072265625, -180.322021484375)
	    position_4.location = (29.99072265625, -39.67083740234375)
	    named_attribute_001.location = (29.99072265625, -260.694091796875)
	    capture_attribute_001_6.location = (-4365.55810546875, 210.744140625)
	    group_input_004_5.location = (29.669921875, -178.9044189453125)
	    domain_size_002.location = (207.6806640625, -80.07354736328125)
	    compare_001_4.location = (388.517578125, -39.88751220703125)
	    object_info_001.location = (210.88330078125, -39.64691162109375)
	    group_input_002_7.location = (30.0458984375, -79.83294677734375)
	    switch_005_1.location = (640.525390625, -283.5823974609375)
	    domain_size_003.location = (938.8193359375, -79.91128540039062)
	    compare_002_6.location = (1119.65625, -39.725250244140625)
	    named_attribute_2.location = (820.7041015625, -432.90301513671875)
	    reroute_12.location = (961.35546875, -332.43792724609375)
	    group_input_005_6.location = (1021.63427734375, -252.0657958984375)
	    set_position_6.location = (1021.63427734375, -352.53094482421875)
	    switch_007.location = (1222.564453125, -231.9727783203125)
	    reroute_015_7.location = (-5129.0927734375, 532.2319946289062)
	    reroute_011_7.location = (-5109.0, 492.04595947265625)
	    group_input_12.location = (-5510.8603515625, 351.395263671875)
	    capture_attribute_002_6.location = (-5209.46484375, 230.837158203125)
	    reroute_001_9.location = (-4887.9765625, -653.2559814453125)
	    sample_nearest_surface.location = (210.7509765625, -40.199798583984375)
	    group_7.location = (29.9140625, -180.85098266601562)
	    group_input_001_8.location = (29.9140625, -100.4788818359375)
	    reroute_020_5.location = (-4526.30224609375, -10.2791748046875)
	    normal_3.location = (29.5712890625, -45.01953125)
	    capture_attribute_4.location = (230.50146484375, -45.01953125)
	    sample_uv_surface.location = (321.1396484375, -50.02386474609375)
	    sample_uv_surface_003.location = (321.1396484375, -130.39593505859375)
	    reroute_004_9.location = (220.6748046875, -230.86102294921875)
	    sample_uv_surface_001.location = (321.1396484375, -210.76800537109375)
	    group_001_7.location = (158.627685546875, -240.71258544921875)
	    position_001_3.location = (339.46484375, -321.08465576171875)
	    vector_math_9.location = (339.46484375, -140.2474365234375)
	    vector_math_001_7.location = (540.39501953125, -321.08465576171875)
	    vector_math_004_7.location = (1826.3486328125, -341.17767333984375)
	    vector_math_003_7.location = (2027.27880859375, -200.52651977539062)
	    group_input_003_8.location = (1424.48828125, -220.79666137695312)
	    group_input_006_6.location = (1424.48828125, -100.238525390625)
	    switch_003_5.location = (1625.41845703125, -180.61062622070312)
	    switch_002_4.location = (1625.41845703125, -220.79666137695312)
	    vector_math_002_7.location = (1826.3486328125, -140.424560546875)
	    vector_math_005_3.location = (2248.30224609375, -200.70364379882812)
	    boolean_math_7.location = (1625.41845703125, -39.959442138671875)
	    spline_parameter_3.location = (32.72265625, -81.9400634765625)
	    group_input_008_5.location = (30.322265625, -161.4296875)
	    map_range_2.location = (205.259765625, -190.3057861328125)
	    compare_8.location = (205.20068359375, -39.6795654296875)
	    switch_004_5.location = (386.037841796875, -59.772705078125)
	    position_002_5.location = (1625.41845703125, -371.6761474609375)
	    evaluate_on_domain_3.location = (531.248291015625, -115.30325317382812)
	    reroute_009_7.location = (731.747802734375, -64.921875)
	    evaluate_on_domain_002_2.location = (630.95361328125, -265.85211181640625)
	    switch_006_1.location = (992.6279296875, -64.921875)
	    vector_rotate_2.location = (1173.465087890625, -64.921875)
	    vector_rotate_003.location = (811.790771484375, -165.386962890625)
	    align_euler_to_vector_003.location = (630.95361328125, -165.386962890625)
	    align_euler_to_vector_002.location = (630.95361328125, -306.0382080078125)
	    evaluate_on_domain_003.location = (630.95361328125, -406.5032958984375)
	    switch_001_9.location = (210.67138671875, -105.2939453125)
	    accumulate_field_5.location = (29.834228515625, -45.014892578125)
	    sample_index_001_2.location = (29.834228515625, -85.200927734375)
	    reroute_019_4.location = (48.255859375, -185.48004150390625)
	    named_attribute_002.location = (35.0, -105.279052734375)
	    reroute_007_7.location = (35.0, -45.0)
	    reroute_008_7.location = (35.0, -85.18603515625)
	    sample_index_4.location = (215.837158203125, -65.093017578125)
	
	    #Set dimensions
	    frame_004_6.width, frame_004_6.height = 978.903076171875, 664.0
	    frame_005_5.width, frame_005_5.height = 491.0, 412.0
	    frame_9.width, frame_9.height = 1393.0, 646.0
	    frame_006_6.width, frame_006_6.height = 559.0, 261.0
	    frame_007_5.width, frame_007_5.height = 381.0, 215.0
	    frame_011_1.width, frame_011_1.height = 390.33642578125, 289.0
	    frame_001_6.width, frame_001_6.height = 401.0, 125.0
	    frame_010_1.width, frame_010_1.height = 2418.3515625, 971.0
	    frame_003_6.width, frame_003_6.height = 556.0, 250.0
	    frame_002_7.width, frame_002_7.height = 1343.351806640625, 504.0
	    frame_008_1.width, frame_008_1.height = 381.0, 160.0
	    frame_009_1.width, frame_009_1.height = 385.351806640625, 256.4967041015625
	    reroute_010_6.width, reroute_010_6.height = 10.0, 100.0
	    reroute_013_7.width, reroute_013_7.height = 10.0, 100.0
	    group_output_15.width, group_output_15.height = 140.0, 100.0
	    reroute_003_8.width, reroute_003_8.height = 10.0, 100.0
	    switch_9.width, switch_9.height = 140.0, 100.0
	    store_named_attribute_2.width, store_named_attribute_2.height = 140.0, 100.0
	    group_input_007_6.width, group_input_007_6.height = 140.0, 100.0
	    reroute_016_6.width, reroute_016_6.height = 10.0, 100.0
	    reroute_005_7.width, reroute_005_7.height = 10.0, 100.0
	    store_named_attribute_001.width, store_named_attribute_001.height = 140.0, 100.0
	    named_attribute_004.width, named_attribute_004.height = 140.0, 100.0
	    reroute_012_8.width, reroute_012_8.height = 10.0, 100.0
	    reroute_014_6.width, reroute_014_6.height = 10.0, 100.0
	    reroute_006_7.width, reroute_006_7.height = 10.0, 100.0
	    named_attribute_003_1.width, named_attribute_003_1.height = 140.0, 100.0
	    switch_008.width, switch_008.height = 140.0, 100.0
	    switch_009.width, switch_009.height = 140.0, 100.0
	    switch_010.width, switch_010.height = 140.0, 100.0
	    set_position_001_4.width, set_position_001_4.height = 140.0, 100.0
	    reroute_002_8.width, reroute_002_8.height = 10.0, 100.0
	    reroute_018_6.width, reroute_018_6.height = 10.0, 100.0
	    reroute_017_6.width, reroute_017_6.height = 10.0, 100.0
	    group_input_009_3.width, group_input_009_3.height = 140.0, 100.0
	    position_4.width, position_4.height = 140.0, 100.0
	    named_attribute_001.width, named_attribute_001.height = 140.0, 100.0
	    capture_attribute_001_6.width, capture_attribute_001_6.height = 140.0, 100.0
	    group_input_004_5.width, group_input_004_5.height = 140.0, 100.0
	    domain_size_002.width, domain_size_002.height = 140.0, 100.0
	    compare_001_4.width, compare_001_4.height = 140.0, 100.0
	    object_info_001.width, object_info_001.height = 140.0, 100.0
	    group_input_002_7.width, group_input_002_7.height = 140.0, 100.0
	    switch_005_1.width, switch_005_1.height = 140.0, 100.0
	    domain_size_003.width, domain_size_003.height = 140.0, 100.0
	    compare_002_6.width, compare_002_6.height = 140.0, 100.0
	    named_attribute_2.width, named_attribute_2.height = 140.0, 100.0
	    reroute_12.width, reroute_12.height = 10.0, 100.0
	    group_input_005_6.width, group_input_005_6.height = 140.0, 100.0
	    set_position_6.width, set_position_6.height = 140.0, 100.0
	    switch_007.width, switch_007.height = 140.0, 100.0
	    reroute_015_7.width, reroute_015_7.height = 10.0, 100.0
	    reroute_011_7.width, reroute_011_7.height = 10.0, 100.0
	    group_input_12.width, group_input_12.height = 140.0, 100.0
	    capture_attribute_002_6.width, capture_attribute_002_6.height = 140.0, 100.0
	    reroute_001_9.width, reroute_001_9.height = 10.0, 100.0
	    sample_nearest_surface.width, sample_nearest_surface.height = 149.33627319335938, 100.0
	    group_7.width, group_7.height = 140.0, 100.0
	    group_input_001_8.width, group_input_001_8.height = 140.0, 100.0
	    reroute_020_5.width, reroute_020_5.height = 10.0, 100.0
	    normal_3.width, normal_3.height = 140.0, 100.0
	    capture_attribute_4.width, capture_attribute_4.height = 140.0, 100.0
	    sample_uv_surface.width, sample_uv_surface.height = 140.0, 100.0
	    sample_uv_surface_003.width, sample_uv_surface_003.height = 140.0, 100.0
	    reroute_004_9.width, reroute_004_9.height = 10.0, 100.0
	    sample_uv_surface_001.width, sample_uv_surface_001.height = 140.0, 100.0
	    group_001_7.width, group_001_7.height = 140.0, 100.0
	    position_001_3.width, position_001_3.height = 140.0, 100.0
	    vector_math_9.width, vector_math_9.height = 140.0, 100.0
	    vector_math_001_7.width, vector_math_001_7.height = 140.0, 100.0
	    vector_math_004_7.width, vector_math_004_7.height = 140.0, 100.0
	    vector_math_003_7.width, vector_math_003_7.height = 140.0, 100.0
	    group_input_003_8.width, group_input_003_8.height = 140.0, 100.0
	    group_input_006_6.width, group_input_006_6.height = 140.0, 100.0
	    switch_003_5.width, switch_003_5.height = 140.0, 100.0
	    switch_002_4.width, switch_002_4.height = 140.0, 100.0
	    vector_math_002_7.width, vector_math_002_7.height = 140.0, 100.0
	    vector_math_005_3.width, vector_math_005_3.height = 140.0, 100.0
	    boolean_math_7.width, boolean_math_7.height = 140.0, 100.0
	    spline_parameter_3.width, spline_parameter_3.height = 140.0, 100.0
	    group_input_008_5.width, group_input_008_5.height = 140.0, 100.0
	    map_range_2.width, map_range_2.height = 140.0, 100.0
	    compare_8.width, compare_8.height = 140.0, 100.0
	    switch_004_5.width, switch_004_5.height = 140.0, 100.0
	    position_002_5.width, position_002_5.height = 140.0, 100.0
	    evaluate_on_domain_3.width, evaluate_on_domain_3.height = 140.0, 100.0
	    reroute_009_7.width, reroute_009_7.height = 10.0, 100.0
	    evaluate_on_domain_002_2.width, evaluate_on_domain_002_2.height = 140.0, 100.0
	    switch_006_1.width, switch_006_1.height = 140.0, 100.0
	    vector_rotate_2.width, vector_rotate_2.height = 140.0, 100.0
	    vector_rotate_003.width, vector_rotate_003.height = 140.0, 100.0
	    align_euler_to_vector_003.width, align_euler_to_vector_003.height = 140.0, 100.0
	    align_euler_to_vector_002.width, align_euler_to_vector_002.height = 140.0, 100.0
	    evaluate_on_domain_003.width, evaluate_on_domain_003.height = 140.0, 100.0
	    switch_001_9.width, switch_001_9.height = 140.0, 100.0
	    accumulate_field_5.width, accumulate_field_5.height = 140.0, 100.0
	    sample_index_001_2.width, sample_index_001_2.height = 140.0, 100.0
	    reroute_019_4.width, reroute_019_4.height = 10.0, 100.0
	    named_attribute_002.width, named_attribute_002.height = 140.0, 100.0
	    reroute_007_7.width, reroute_007_7.height = 10.0, 100.0
	    reroute_008_7.width, reroute_008_7.height = 10.0, 100.0
	    sample_index_4.width, sample_index_4.height = 140.0, 100.0
	
	    #initialize attach_hair_curves_to_surface links
	    #domain_size_002.Face Count -> compare_001_4.A
	    attach_hair_curves_to_surface.links.new(domain_size_002.outputs[2], compare_001_4.inputs[2])
	    #compare_001_4.Result -> switch_005_1.Switch
	    attach_hair_curves_to_surface.links.new(compare_001_4.outputs[0], switch_005_1.inputs[0])
	    #group_input_002_7.Surface -> object_info_001.Object
	    attach_hair_curves_to_surface.links.new(group_input_002_7.outputs[2], object_info_001.inputs[0])
	    #group_input_004_5.Surface -> domain_size_002.Geometry
	    attach_hair_curves_to_surface.links.new(group_input_004_5.outputs[1], domain_size_002.inputs[0])
	    #group_input_004_5.Surface -> switch_005_1.True
	    attach_hair_curves_to_surface.links.new(group_input_004_5.outputs[1], switch_005_1.inputs[2])
	    #group_input_001_8.Surface UV Map -> sample_nearest_surface.Value
	    attach_hair_curves_to_surface.links.new(group_input_001_8.outputs[3], sample_nearest_surface.inputs[1])
	    #reroute_12.Output -> set_position_6.Geometry
	    attach_hair_curves_to_surface.links.new(reroute_12.outputs[0], set_position_6.inputs[0])
	    #reroute_12.Output -> switch_007.False
	    attach_hair_curves_to_surface.links.new(reroute_12.outputs[0], switch_007.inputs[1])
	    #set_position_6.Geometry -> switch_007.True
	    attach_hair_curves_to_surface.links.new(set_position_6.outputs[0], switch_007.inputs[2])
	    #switch_005_1.Output -> reroute_12.Input
	    attach_hair_curves_to_surface.links.new(switch_005_1.outputs[0], reroute_12.inputs[0])
	    #group_input_005_6.Surface Rest Position -> switch_007.Switch
	    attach_hair_curves_to_surface.links.new(group_input_005_6.outputs[4], switch_007.inputs[0])
	    #named_attribute_2.Attribute -> set_position_6.Position
	    attach_hair_curves_to_surface.links.new(named_attribute_2.outputs[0], set_position_6.inputs[2])
	    #named_attribute_2.Exists -> set_position_6.Selection
	    attach_hair_curves_to_surface.links.new(named_attribute_2.outputs[1], set_position_6.inputs[1])
	    #switch_007.Output -> sample_nearest_surface.Mesh
	    attach_hair_curves_to_surface.links.new(switch_007.outputs[0], sample_nearest_surface.inputs[0])
	    #object_info_001.Geometry -> switch_005_1.False
	    attach_hair_curves_to_surface.links.new(object_info_001.outputs[4], switch_005_1.inputs[1])
	    #group_7.Root Position -> sample_nearest_surface.Sample Position
	    attach_hair_curves_to_surface.links.new(group_7.outputs[1], sample_nearest_surface.inputs[3])
	    #reroute_002_8.Output -> sample_uv_surface.UV Map
	    attach_hair_curves_to_surface.links.new(reroute_002_8.outputs[0], sample_uv_surface.inputs[2])
	    #position_4.Position -> sample_uv_surface.Value
	    attach_hair_curves_to_surface.links.new(position_4.outputs[0], sample_uv_surface.inputs[1])
	    #reroute_004_9.Output -> sample_uv_surface.Sample UV
	    attach_hair_curves_to_surface.links.new(reroute_004_9.outputs[0], sample_uv_surface.inputs[3])
	    #capture_attribute_001_6.Geometry -> set_position_001_4.Geometry
	    attach_hair_curves_to_surface.links.new(capture_attribute_001_6.outputs[0], set_position_001_4.inputs[0])
	    #reroute_017_6.Output -> sample_uv_surface_001.Mesh
	    attach_hair_curves_to_surface.links.new(reroute_017_6.outputs[0], sample_uv_surface_001.inputs[0])
	    #reroute_004_9.Output -> sample_uv_surface_001.Sample UV
	    attach_hair_curves_to_surface.links.new(reroute_004_9.outputs[0], sample_uv_surface_001.inputs[3])
	    #reroute_002_8.Output -> sample_uv_surface_001.UV Map
	    attach_hair_curves_to_surface.links.new(reroute_002_8.outputs[0], sample_uv_surface_001.inputs[2])
	    #normal_3.Normal -> capture_attribute_4.Value
	    attach_hair_curves_to_surface.links.new(normal_3.outputs[0], capture_attribute_4.inputs[1])
	    #reroute_018_6.Output -> sample_uv_surface_001.Value
	    attach_hair_curves_to_surface.links.new(reroute_018_6.outputs[0], sample_uv_surface_001.inputs[1])
	    #sample_uv_surface.Value -> vector_math_9.Vector
	    attach_hair_curves_to_surface.links.new(sample_uv_surface.outputs[0], vector_math_9.inputs[0])
	    #group_001_7.Root Position -> vector_math_9.Vector
	    attach_hair_curves_to_surface.links.new(group_001_7.outputs[1], vector_math_9.inputs[1])
	    #vector_math_9.Vector -> evaluate_on_domain_3.Value
	    attach_hair_curves_to_surface.links.new(vector_math_9.outputs[0], evaluate_on_domain_3.inputs[0])
	    #position_001_3.Position -> vector_math_001_7.Vector
	    attach_hair_curves_to_surface.links.new(position_001_3.outputs[0], vector_math_001_7.inputs[0])
	    #group_001_7.Root Position -> vector_math_001_7.Vector
	    attach_hair_curves_to_surface.links.new(group_001_7.outputs[1], vector_math_001_7.inputs[1])
	    #switch_006_1.Output -> vector_rotate_2.Vector
	    attach_hair_curves_to_surface.links.new(switch_006_1.outputs[0], vector_rotate_2.inputs[0])
	    #reroute_007_7.Output -> sample_index_4.Geometry
	    attach_hair_curves_to_surface.links.new(reroute_007_7.outputs[0], sample_index_4.inputs[0])
	    #named_attribute_002.Attribute -> sample_index_4.Index
	    attach_hair_curves_to_surface.links.new(named_attribute_002.outputs[0], sample_index_4.inputs[2])
	    #position_002_5.Position -> vector_math_004_7.Vector
	    attach_hair_curves_to_surface.links.new(position_002_5.outputs[0], vector_math_004_7.inputs[0])
	    #vector_math_002_7.Vector -> vector_math_003_7.Vector
	    attach_hair_curves_to_surface.links.new(vector_math_002_7.outputs[0], vector_math_003_7.inputs[0])
	    #switch_003_5.Output -> vector_math_002_7.Vector
	    attach_hair_curves_to_surface.links.new(switch_003_5.outputs[0], vector_math_002_7.inputs[0])
	    #switch_002_4.Output -> vector_math_002_7.Vector
	    attach_hair_curves_to_surface.links.new(switch_002_4.outputs[0], vector_math_002_7.inputs[1])
	    #reroute_009_7.Output -> vector_rotate_003.Vector
	    attach_hair_curves_to_surface.links.new(reroute_009_7.outputs[0], vector_rotate_003.inputs[0])
	    #evaluate_on_domain_002_2.Value -> vector_rotate_003.Rotation
	    attach_hair_curves_to_surface.links.new(evaluate_on_domain_002_2.outputs[0], vector_rotate_003.inputs[4])
	    #evaluate_on_domain_003.Value -> vector_rotate_2.Rotation
	    attach_hair_curves_to_surface.links.new(evaluate_on_domain_003.outputs[0], vector_rotate_2.inputs[4])
	    #group_001_7.Root Position -> vector_math_004_7.Vector
	    attach_hair_curves_to_surface.links.new(group_001_7.outputs[1], vector_math_004_7.inputs[1])
	    #vector_math_004_7.Vector -> vector_math_003_7.Vector
	    attach_hair_curves_to_surface.links.new(vector_math_004_7.outputs[0], vector_math_003_7.inputs[1])
	    #reroute_016_6.Output -> store_named_attribute_2.Geometry
	    attach_hair_curves_to_surface.links.new(reroute_016_6.outputs[0], store_named_attribute_2.inputs[0])
	    #group_input_12.Geometry -> capture_attribute_002_6.Geometry
	    attach_hair_curves_to_surface.links.new(group_input_12.outputs[0], capture_attribute_002_6.inputs[0])
	    #reroute_003_8.Output -> store_named_attribute_2.Value
	    attach_hair_curves_to_surface.links.new(reroute_003_8.outputs[0], store_named_attribute_2.inputs[3])
	    #sample_nearest_surface.Value -> capture_attribute_002_6.Value
	    attach_hair_curves_to_surface.links.new(sample_nearest_surface.outputs[0], capture_attribute_002_6.inputs[1])
	    #capture_attribute_002_6.Value -> reroute_004_9.Input
	    attach_hair_curves_to_surface.links.new(capture_attribute_002_6.outputs[1], reroute_004_9.inputs[0])
	    #switch_007.Output -> capture_attribute_4.Geometry
	    attach_hair_curves_to_surface.links.new(switch_007.outputs[0], capture_attribute_4.inputs[0])
	    #align_euler_to_vector_003.Rotation -> evaluate_on_domain_002_2.Value
	    attach_hair_curves_to_surface.links.new(align_euler_to_vector_003.outputs[0], evaluate_on_domain_002_2.inputs[0])
	    #align_euler_to_vector_002.Rotation -> evaluate_on_domain_003.Value
	    attach_hair_curves_to_surface.links.new(align_euler_to_vector_002.outputs[0], evaluate_on_domain_003.inputs[0])
	    #capture_attribute_4.Geometry -> reroute_001_9.Input
	    attach_hair_curves_to_surface.links.new(capture_attribute_4.outputs[0], reroute_001_9.inputs[0])
	    #reroute_018_6.Output -> sample_uv_surface_003.Value
	    attach_hair_curves_to_surface.links.new(reroute_018_6.outputs[0], sample_uv_surface_003.inputs[1])
	    #reroute_002_8.Output -> sample_uv_surface_003.UV Map
	    attach_hair_curves_to_surface.links.new(reroute_002_8.outputs[0], sample_uv_surface_003.inputs[2])
	    #reroute_017_6.Output -> sample_uv_surface_003.Mesh
	    attach_hair_curves_to_surface.links.new(reroute_017_6.outputs[0], sample_uv_surface_003.inputs[0])
	    #named_attribute_001.Attribute -> sample_uv_surface_003.Sample UV
	    attach_hair_curves_to_surface.links.new(named_attribute_001.outputs[0], sample_uv_surface_003.inputs[3])
	    #reroute_019_4.Output -> switch_001_9.True
	    attach_hair_curves_to_surface.links.new(reroute_019_4.outputs[0], switch_001_9.inputs[2])
	    #reroute_020_5.Output -> sample_index_001_2.Geometry
	    attach_hair_curves_to_surface.links.new(reroute_020_5.outputs[0], sample_index_001_2.inputs[0])
	    #named_attribute_001.Exists -> accumulate_field_5.Value
	    attach_hair_curves_to_surface.links.new(named_attribute_001.outputs[1], accumulate_field_5.inputs[0])
	    #accumulate_field_5.Total -> sample_index_001_2.Value
	    attach_hair_curves_to_surface.links.new(accumulate_field_5.outputs[2], sample_index_001_2.inputs[1])
	    #sample_index_001_2.Value -> switch_001_9.Switch
	    attach_hair_curves_to_surface.links.new(sample_index_001_2.outputs[0], switch_001_9.inputs[0])
	    #reroute_008_7.Output -> sample_index_4.Value
	    attach_hair_curves_to_surface.links.new(reroute_008_7.outputs[0], sample_index_4.inputs[1])
	    #vector_rotate_2.Vector -> switch_002_4.True
	    attach_hair_curves_to_surface.links.new(vector_rotate_2.outputs[0], switch_002_4.inputs[2])
	    #vector_math_001_7.Vector -> switch_002_4.False
	    attach_hair_curves_to_surface.links.new(vector_math_001_7.outputs[0], switch_002_4.inputs[1])
	    #group_input_003_8.Align to Surface Normal -> switch_002_4.Switch
	    attach_hair_curves_to_surface.links.new(group_input_003_8.outputs[7], switch_002_4.inputs[0])
	    #vector_math_005_3.Vector -> set_position_001_4.Offset
	    attach_hair_curves_to_surface.links.new(vector_math_005_3.outputs[0], set_position_001_4.inputs[3])
	    #evaluate_on_domain_3.Value -> switch_003_5.True
	    attach_hair_curves_to_surface.links.new(evaluate_on_domain_3.outputs[0], switch_003_5.inputs[2])
	    #group_input_006_6.Snap to Surface -> switch_003_5.Switch
	    attach_hair_curves_to_surface.links.new(group_input_006_6.outputs[6], switch_003_5.inputs[0])
	    #group_input_006_6.Snap to Surface -> boolean_math_7.Boolean
	    attach_hair_curves_to_surface.links.new(group_input_006_6.outputs[6], boolean_math_7.inputs[0])
	    #group_input_003_8.Align to Surface Normal -> boolean_math_7.Boolean
	    attach_hair_curves_to_surface.links.new(group_input_003_8.outputs[7], boolean_math_7.inputs[1])
	    #boolean_math_7.Boolean -> set_position_001_4.Selection
	    attach_hair_curves_to_surface.links.new(boolean_math_7.outputs[0], set_position_001_4.inputs[1])
	    #capture_attribute_002_6.Value -> reroute_003_8.Input
	    attach_hair_curves_to_surface.links.new(capture_attribute_002_6.outputs[1], reroute_003_8.inputs[0])
	    #switch_009.Output -> group_output_15.Surface UV Coordinate
	    attach_hair_curves_to_surface.links.new(switch_009.outputs[0], group_output_15.inputs[1])
	    #store_named_attribute_2.Geometry -> switch_9.True
	    attach_hair_curves_to_surface.links.new(store_named_attribute_2.outputs[0], switch_9.inputs[2])
	    #group_input_007_6.Sample Attachment UV -> switch_9.Switch
	    attach_hair_curves_to_surface.links.new(group_input_007_6.outputs[5], switch_9.inputs[0])
	    #reroute_016_6.Output -> switch_9.False
	    attach_hair_curves_to_surface.links.new(reroute_016_6.outputs[0], switch_9.inputs[1])
	    #switch_9.Output -> store_named_attribute_001.Geometry
	    attach_hair_curves_to_surface.links.new(switch_9.outputs[0], store_named_attribute_001.inputs[0])
	    #reroute_020_5.Output -> capture_attribute_001_6.Geometry
	    attach_hair_curves_to_surface.links.new(reroute_020_5.outputs[0], capture_attribute_001_6.inputs[0])
	    #reroute_005_7.Output -> store_named_attribute_001.Value
	    attach_hair_curves_to_surface.links.new(reroute_005_7.outputs[0], store_named_attribute_001.inputs[3])
	    #capture_attribute_001_6.Value -> reroute_005_7.Input
	    attach_hair_curves_to_surface.links.new(capture_attribute_001_6.outputs[1], reroute_005_7.inputs[0])
	    #switch_010.Output -> group_output_15.Surface Normal
	    attach_hair_curves_to_surface.links.new(switch_010.outputs[0], group_output_15.inputs[2])
	    #sample_uv_surface_001.Value -> capture_attribute_001_6.Value
	    attach_hair_curves_to_surface.links.new(sample_uv_surface_001.outputs[0], capture_attribute_001_6.inputs[1])
	    #vector_math_003_7.Vector -> vector_math_005_3.Vector
	    attach_hair_curves_to_surface.links.new(vector_math_003_7.outputs[0], vector_math_005_3.inputs[0])
	    #spline_parameter_3.Factor -> map_range_2.Value
	    attach_hair_curves_to_surface.links.new(spline_parameter_3.outputs[0], map_range_2.inputs[0])
	    #group_input_008_5.Blend along Curve -> map_range_2.From Max
	    attach_hair_curves_to_surface.links.new(group_input_008_5.outputs[8], map_range_2.inputs[2])
	    #group_input_008_5.Blend along Curve -> compare_8.A
	    attach_hair_curves_to_surface.links.new(group_input_008_5.outputs[8], compare_8.inputs[0])
	    #compare_8.Result -> switch_004_5.Switch
	    attach_hair_curves_to_surface.links.new(compare_8.outputs[0], switch_004_5.inputs[0])
	    #map_range_2.Result -> switch_004_5.False
	    attach_hair_curves_to_surface.links.new(map_range_2.outputs[0], switch_004_5.inputs[1])
	    #switch_004_5.Output -> vector_math_005_3.Scale
	    attach_hair_curves_to_surface.links.new(switch_004_5.outputs[0], vector_math_005_3.inputs[3])
	    #switch_001_9.Output -> align_euler_to_vector_003.Vector
	    attach_hair_curves_to_surface.links.new(switch_001_9.outputs[0], align_euler_to_vector_003.inputs[2])
	    #sample_index_4.Value -> switch_001_9.False
	    attach_hair_curves_to_surface.links.new(sample_index_4.outputs[0], switch_001_9.inputs[1])
	    #named_attribute_002.Exists -> switch_006_1.Switch
	    attach_hair_curves_to_surface.links.new(named_attribute_002.outputs[1], switch_006_1.inputs[0])
	    #reroute_009_7.Output -> switch_006_1.False
	    attach_hair_curves_to_surface.links.new(reroute_009_7.outputs[0], switch_006_1.inputs[1])
	    #vector_rotate_003.Vector -> switch_006_1.True
	    attach_hair_curves_to_surface.links.new(vector_rotate_003.outputs[0], switch_006_1.inputs[2])
	    #vector_math_001_7.Vector -> reroute_009_7.Input
	    attach_hair_curves_to_surface.links.new(vector_math_001_7.outputs[0], reroute_009_7.inputs[0])
	    #reroute_011_7.Output -> reroute_010_6.Input
	    attach_hair_curves_to_surface.links.new(reroute_011_7.outputs[0], reroute_010_6.inputs[0])
	    #group_input_12.Geometry -> reroute_011_7.Input
	    attach_hair_curves_to_surface.links.new(group_input_12.outputs[0], reroute_011_7.inputs[0])
	    #store_named_attribute_001.Geometry -> switch_008.False
	    attach_hair_curves_to_surface.links.new(store_named_attribute_001.outputs[0], switch_008.inputs[1])
	    #reroute_006_7.Output -> switch_008.True
	    attach_hair_curves_to_surface.links.new(reroute_006_7.outputs[0], switch_008.inputs[2])
	    #switch_008.Output -> group_output_15.Geometry
	    attach_hair_curves_to_surface.links.new(switch_008.outputs[0], group_output_15.inputs[0])
	    #reroute_003_8.Output -> switch_009.False
	    attach_hair_curves_to_surface.links.new(reroute_003_8.outputs[0], switch_009.inputs[1])
	    #reroute_005_7.Output -> switch_010.False
	    attach_hair_curves_to_surface.links.new(reroute_005_7.outputs[0], switch_010.inputs[1])
	    #domain_size_003.Face Count -> compare_002_6.A
	    attach_hair_curves_to_surface.links.new(domain_size_003.outputs[2], compare_002_6.inputs[2])
	    #switch_005_1.Output -> domain_size_003.Geometry
	    attach_hair_curves_to_surface.links.new(switch_005_1.outputs[0], domain_size_003.inputs[0])
	    #reroute_012_8.Output -> switch_008.Switch
	    attach_hair_curves_to_surface.links.new(reroute_012_8.outputs[0], switch_008.inputs[0])
	    #reroute_014_6.Output -> reroute_012_8.Input
	    attach_hair_curves_to_surface.links.new(reroute_014_6.outputs[0], reroute_012_8.inputs[0])
	    #reroute_012_8.Output -> switch_009.Switch
	    attach_hair_curves_to_surface.links.new(reroute_012_8.outputs[0], switch_009.inputs[0])
	    #reroute_012_8.Output -> switch_010.Switch
	    attach_hair_curves_to_surface.links.new(reroute_012_8.outputs[0], switch_010.inputs[0])
	    #named_attribute_003_1.Attribute -> switch_009.True
	    attach_hair_curves_to_surface.links.new(named_attribute_003_1.outputs[0], switch_009.inputs[2])
	    #named_attribute_004.Attribute -> switch_010.True
	    attach_hair_curves_to_surface.links.new(named_attribute_004.outputs[0], switch_010.inputs[2])
	    #reroute_015_7.Output -> reroute_013_7.Input
	    attach_hair_curves_to_surface.links.new(reroute_015_7.outputs[0], reroute_013_7.inputs[0])
	    #reroute_013_7.Output -> reroute_014_6.Input
	    attach_hair_curves_to_surface.links.new(reroute_013_7.outputs[0], reroute_014_6.inputs[0])
	    #compare_002_6.Result -> reroute_015_7.Input
	    attach_hair_curves_to_surface.links.new(compare_002_6.outputs[0], reroute_015_7.inputs[0])
	    #set_position_001_4.Geometry -> reroute_016_6.Input
	    attach_hair_curves_to_surface.links.new(set_position_001_4.outputs[0], reroute_016_6.inputs[0])
	    #capture_attribute_4.Geometry -> reroute_017_6.Input
	    attach_hair_curves_to_surface.links.new(capture_attribute_4.outputs[0], reroute_017_6.inputs[0])
	    #capture_attribute_4.Value -> reroute_018_6.Input
	    attach_hair_curves_to_surface.links.new(capture_attribute_4.outputs[1], reroute_018_6.inputs[0])
	    #reroute_010_6.Output -> reroute_006_7.Input
	    attach_hair_curves_to_surface.links.new(reroute_010_6.outputs[0], reroute_006_7.inputs[0])
	    #reroute_001_9.Output -> reroute_007_7.Input
	    attach_hair_curves_to_surface.links.new(reroute_001_9.outputs[0], reroute_007_7.inputs[0])
	    #sample_uv_surface_001.Value -> reroute_008_7.Input
	    attach_hair_curves_to_surface.links.new(sample_uv_surface_001.outputs[0], reroute_008_7.inputs[0])
	    #reroute_008_7.Output -> align_euler_to_vector_002.Vector
	    attach_hair_curves_to_surface.links.new(reroute_008_7.outputs[0], align_euler_to_vector_002.inputs[2])
	    #sample_uv_surface_003.Value -> reroute_019_4.Input
	    attach_hair_curves_to_surface.links.new(sample_uv_surface_003.outputs[0], reroute_019_4.inputs[0])
	    #reroute_017_6.Output -> sample_uv_surface.Mesh
	    attach_hair_curves_to_surface.links.new(reroute_017_6.outputs[0], sample_uv_surface.inputs[0])
	    #group_input_009_3.Surface UV Map -> reroute_002_8.Input
	    attach_hair_curves_to_surface.links.new(group_input_009_3.outputs[3], reroute_002_8.inputs[0])
	    #capture_attribute_002_6.Geometry -> reroute_020_5.Input
	    attach_hair_curves_to_surface.links.new(capture_attribute_002_6.outputs[0], reroute_020_5.inputs[0])
	    return attach_hair_curves_to_surface
	
	attach_hair_curves_to_surface = attach_hair_curves_to_surface_node_group()
	
	#initialize attach_hair node group
	def attach_hair_node_group():
	    attach_hair = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "ATTACH_HAIR")
	
	    attach_hair.color_tag = 'NONE'
	    attach_hair.description = ""
	    attach_hair.default_group_node_width = 140
	    
	
	    attach_hair.is_modifier = True
	
	    #attach_hair interface
	    #Socket Geometry
	    geometry_socket_21 = attach_hair.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_21.attribute_domain = 'POINT'
	
	    #Socket Geometry
	    geometry_socket_22 = attach_hair.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_22.attribute_domain = 'POINT'
	
	    #Socket Surface
	    surface_socket_6 = attach_hair.interface.new_socket(name = "Surface", in_out='INPUT', socket_type = 'NodeSocketObject')
	    surface_socket_6.attribute_domain = 'POINT'
	    surface_socket_6.description = "Surface Object to attach to (needs to have matching transforms)"
	
	    #Socket UV Map
	    uv_map_socket = attach_hair.interface.new_socket(name = "UV Map", in_out='INPUT', socket_type = 'NodeSocketString')
	    uv_map_socket.default_value = "UVMap"
	    uv_map_socket.subtype = 'NONE'
	    uv_map_socket.attribute_domain = 'POINT'
	    uv_map_socket.description = "Surface UV Map used to attach hair."
	
	    #Socket Blend along Curve
	    blend_along_curve_socket_1 = attach_hair.interface.new_socket(name = "Blend along Curve", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    blend_along_curve_socket_1.default_value = 0.05000000074505806
	    blend_along_curve_socket_1.min_value = 0.0
	    blend_along_curve_socket_1.max_value = 1.0
	    blend_along_curve_socket_1.subtype = 'FACTOR'
	    blend_along_curve_socket_1.attribute_domain = 'POINT'
	    blend_along_curve_socket_1.description = "Blend deformation along each curve from the root"
	
	
	    #initialize attach_hair nodes
	    #node Group Input
	    group_input_13 = attach_hair.nodes.new("NodeGroupInput")
	    group_input_13.name = "Group Input"
	    group_input_13.outputs[4].hide = True
	
	    #node Group Output
	    group_output_16 = attach_hair.nodes.new("NodeGroupOutput")
	    group_output_16.name = "Group Output"
	    group_output_16.is_active_output = True
	    group_output_16.inputs[1].hide = True
	
	    #node Group
	    group_8 = attach_hair.nodes.new("GeometryNodeGroup")
	    group_8.name = "Group"
	    group_8.node_tree = attach_hair_curves_to_surface
	    group_8.inputs[1].hide = True
	    group_8.inputs[4].hide = True
	    group_8.inputs[5].hide = True
	    group_8.inputs[6].hide = True
	    group_8.inputs[7].hide = True
	    group_8.outputs[1].hide = True
	    group_8.outputs[2].hide = True
	    #Socket_7
	    group_8.inputs[4].default_value = False
	    #Socket_8
	    group_8.inputs[5].default_value = True
	    #Socket_9
	    group_8.inputs[6].default_value = True
	    #Socket_10
	    group_8.inputs[7].default_value = False
	
	    #node Named Attribute
	    named_attribute_3 = attach_hair.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute_3.name = "Named Attribute"
	    named_attribute_3.hide = True
	    named_attribute_3.data_type = 'FLOAT_VECTOR'
	
	
	
	
	
	    #Set locations
	    group_input_13.location = (-340.0, 0.0)
	    group_output_16.location = (82.01471710205078, 24.076622009277344)
	    group_8.location = (-156.17784118652344, 22.037841796875)
	    named_attribute_3.location = (-333.9075622558594, -146.13522338867188)
	
	    #Set dimensions
	    group_input_13.width, group_input_13.height = 140.0, 100.0
	    group_output_16.width, group_output_16.height = 140.0, 100.0
	    group_8.width, group_8.height = 197.8995361328125, 100.0
	    named_attribute_3.width, named_attribute_3.height = 140.0, 100.0
	
	    #initialize attach_hair links
	    #group_8.Geometry -> group_output_16.Geometry
	    attach_hair.links.new(group_8.outputs[0], group_output_16.inputs[0])
	    #group_input_13.Geometry -> group_8.Geometry
	    attach_hair.links.new(group_input_13.outputs[0], group_8.inputs[0])
	    #named_attribute_3.Attribute -> group_8.Surface UV Map
	    attach_hair.links.new(named_attribute_3.outputs[0], group_8.inputs[3])
	    #group_input_13.Surface -> group_8.Surface
	    attach_hair.links.new(group_input_13.outputs[1], group_8.inputs[2])
	    #group_input_13.UV Map -> named_attribute_3.Name
	    attach_hair.links.new(group_input_13.outputs[2], named_attribute_3.inputs[0])
	    #group_input_13.Blend along Curve -> group_8.Blend along Curve
	    attach_hair.links.new(group_input_13.outputs[3], group_8.inputs[8])
	    return attach_hair
	
	attach_hair = attach_hair_node_group()
	
	#initialize hair_card node group
	def hair_card_node_group():
	    hair_card = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Hair_Card")
	
	    hair_card.color_tag = 'NONE'
	    hair_card.description = ""
	    hair_card.default_group_node_width = 140
	    
	
	    hair_card.is_modifier = True
	
	    #hair_card interface
	    #Socket Geometry
	    geometry_socket_23 = hair_card.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_23.attribute_domain = 'POINT'
	
	    #Socket Geometry
	    geometry_socket_24 = hair_card.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_24.attribute_domain = 'POINT'
	
	    #Socket Material
	    material_socket = hair_card.interface.new_socket(name = "Material", in_out='INPUT', socket_type = 'NodeSocketMaterial')
	    material_socket.attribute_domain = 'POINT'
	
	    #Socket Curve Radius
	    curve_radius_socket = hair_card.interface.new_socket(name = "Curve Radius", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    curve_radius_socket.default_value = 1.0
	    curve_radius_socket.min_value = 0.0
	    curve_radius_socket.max_value = 3.4028234663852886e+38
	    curve_radius_socket.subtype = 'DISTANCE'
	    curve_radius_socket.attribute_domain = 'POINT'
	    curve_radius_socket.hide_value = True
	    curve_radius_socket.hide_in_modifier = True
	
	    #Socket Resolution
	    resolution_socket = hair_card.interface.new_socket(name = "Resolution", in_out='INPUT', socket_type = 'NodeSocketInt')
	    resolution_socket.default_value = 0
	    resolution_socket.min_value = 2
	    resolution_socket.max_value = 512
	    resolution_socket.subtype = 'NONE'
	    resolution_socket.attribute_domain = 'POINT'
	
	    #Socket Width
	    width_socket = hair_card.interface.new_socket(name = "Width", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    width_socket.default_value = 0.10000000149011612
	    width_socket.min_value = 0.0
	    width_socket.max_value = 3.4028234663852886e+38
	    width_socket.subtype = 'DISTANCE'
	    width_socket.attribute_domain = 'POINT'
	
	    #Socket Angle
	    angle_socket = hair_card.interface.new_socket(name = "Angle", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    angle_socket.default_value = 45.0
	    angle_socket.min_value = -90.0
	    angle_socket.max_value = 90.0
	    angle_socket.subtype = 'ANGLE'
	    angle_socket.attribute_domain = 'POINT'
	
	
	    #initialize hair_card nodes
	    #node Group Input
	    group_input_14 = hair_card.nodes.new("NodeGroupInput")
	    group_input_14.name = "Group Input"
	    group_input_14.outputs[1].hide = True
	    group_input_14.outputs[2].hide = True
	    group_input_14.outputs[5].hide = True
	    group_input_14.outputs[6].hide = True
	
	    #node Group Output
	    group_output_17 = hair_card.nodes.new("NodeGroupOutput")
	    group_output_17.name = "Group Output"
	    group_output_17.is_active_output = True
	
	    #node Curve to Mesh
	    curve_to_mesh = hair_card.nodes.new("GeometryNodeCurveToMesh")
	    curve_to_mesh.name = "Curve to Mesh"
	    curve_to_mesh.hide = True
	    #Fill Caps
	    curve_to_mesh.inputs[2].default_value = False
	
	    #node Capture Attribute
	    capture_attribute_5 = hair_card.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_5.name = "Capture Attribute"
	    capture_attribute_5.hide = True
	    capture_attribute_5.active_index = 0
	    capture_attribute_5.capture_items.clear()
	    capture_attribute_5.capture_items.new('FLOAT', "Factor")
	    capture_attribute_5.capture_items["Factor"].data_type = 'FLOAT'
	    capture_attribute_5.domain = 'POINT'
	
	    #node Spline Parameter
	    spline_parameter_4 = hair_card.nodes.new("GeometryNodeSplineParameter")
	    spline_parameter_4.name = "Spline Parameter"
	    spline_parameter_4.hide = True
	
	    #node Combine XYZ
	    combine_xyz_3 = hair_card.nodes.new("ShaderNodeCombineXYZ")
	    combine_xyz_3.name = "Combine XYZ"
	    combine_xyz_3.hide = True
	    #Z
	    combine_xyz_3.inputs[2].default_value = 0.0
	
	    #node Store Named Attribute
	    store_named_attribute_3 = hair_card.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_3.name = "Store Named Attribute"
	    store_named_attribute_3.data_type = 'FLOAT2'
	    store_named_attribute_3.domain = 'CORNER'
	    #Selection
	    store_named_attribute_3.inputs[1].default_value = True
	    #Name
	    store_named_attribute_3.inputs[2].default_value = "hair_card_UV"
	
	    #node Set Material
	    set_material = hair_card.nodes.new("GeometryNodeSetMaterial")
	    set_material.name = "Set Material"
	    set_material.hide = True
	    #Selection
	    set_material.inputs[1].default_value = True
	
	    #node Capture Attribute.002
	    capture_attribute_002_7 = hair_card.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_002_7.name = "Capture Attribute.002"
	    capture_attribute_002_7.hide = True
	    capture_attribute_002_7.active_index = 0
	    capture_attribute_002_7.capture_items.clear()
	    capture_attribute_002_7.capture_items.new('FLOAT', "Factor")
	    capture_attribute_002_7.capture_items["Factor"].data_type = 'FLOAT'
	    capture_attribute_002_7.domain = 'POINT'
	
	    #node Reroute
	    reroute_13 = hair_card.nodes.new("NodeReroute")
	    reroute_13.name = "Reroute"
	    reroute_13.socket_idname = "NodeSocketFloat"
	    #node Group Input.001
	    group_input_001_9 = hair_card.nodes.new("NodeGroupInput")
	    group_input_001_9.name = "Group Input.001"
	    group_input_001_9.outputs[0].hide = True
	    group_input_001_9.outputs[2].hide = True
	    group_input_001_9.outputs[3].hide = True
	    group_input_001_9.outputs[4].hide = True
	    group_input_001_9.outputs[5].hide = True
	    group_input_001_9.outputs[6].hide = True
	
	    #node Reroute.001
	    reroute_001_10 = hair_card.nodes.new("NodeReroute")
	    reroute_001_10.name = "Reroute.001"
	    reroute_001_10.socket_idname = "NodeSocketFloatDistance"
	    #node Resample Curve
	    resample_curve = hair_card.nodes.new("GeometryNodeResampleCurve")
	    resample_curve.name = "Resample Curve"
	    resample_curve.hide = True
	    resample_curve.keep_last_segment = False
	    resample_curve.mode = 'COUNT'
	    #Selection
	    resample_curve.inputs[1].default_value = True
	
	    #node Switch
	    switch_10 = hair_card.nodes.new("GeometryNodeSwitch")
	    switch_10.name = "Switch"
	    switch_10.hide = True
	    switch_10.input_type = 'GEOMETRY'
	
	    #node Group Input.002
	    group_input_002_8 = hair_card.nodes.new("NodeGroupInput")
	    group_input_002_8.name = "Group Input.002"
	    group_input_002_8.outputs[0].hide = True
	    group_input_002_8.outputs[1].hide = True
	    group_input_002_8.outputs[2].hide = True
	    group_input_002_8.outputs[4].hide = True
	    group_input_002_8.outputs[5].hide = True
	    group_input_002_8.outputs[6].hide = True
	
	    #node Compare
	    compare_9 = hair_card.nodes.new("FunctionNodeCompare")
	    compare_9.name = "Compare"
	    compare_9.hide = True
	    compare_9.data_type = 'INT'
	    compare_9.mode = 'ELEMENT'
	    compare_9.operation = 'LESS_THAN'
	    #B_INT
	    compare_9.inputs[3].default_value = 2
	
	    #node Reroute.002
	    reroute_002_9 = hair_card.nodes.new("NodeReroute")
	    reroute_002_9.name = "Reroute.002"
	    reroute_002_9.socket_idname = "NodeSocketGeometry"
	    #node Group Input.003
	    group_input_003_9 = hair_card.nodes.new("NodeGroupInput")
	    group_input_003_9.name = "Group Input.003"
	    group_input_003_9.outputs[0].hide = True
	    group_input_003_9.outputs[1].hide = True
	    group_input_003_9.outputs[2].hide = True
	    group_input_003_9.outputs[3].hide = True
	    group_input_003_9.outputs[4].hide = True
	    group_input_003_9.outputs[6].hide = True
	
	    #node Points
	    points = hair_card.nodes.new("GeometryNodePoints")
	    points.name = "Points"
	    points.hide = True
	    #Count
	    points.inputs[0].default_value = 1
	    #Position
	    points.inputs[1].default_value = (0.0, 0.0, 0.0)
	    #Radius
	    points.inputs[2].default_value = 0.10000000149011612
	
	    #node Points.001
	    points_001 = hair_card.nodes.new("GeometryNodePoints")
	    points_001.name = "Points.001"
	    points_001.hide = True
	    #Count
	    points_001.inputs[0].default_value = 1
	    #Radius
	    points_001.inputs[2].default_value = 0.10000000149011612
	
	    #node Points.002
	    points_002 = hair_card.nodes.new("GeometryNodePoints")
	    points_002.name = "Points.002"
	    points_002.hide = True
	    #Count
	    points_002.inputs[0].default_value = 1
	    #Radius
	    points_002.inputs[2].default_value = 0.10000000149011612
	
	    #node Points to Curves
	    points_to_curves = hair_card.nodes.new("GeometryNodePointsToCurves")
	    points_to_curves.name = "Points to Curves"
	    points_to_curves.hide = True
	    #Curve Group ID
	    points_to_curves.inputs[1].default_value = 0
	    #Weight
	    points_to_curves.inputs[2].default_value = 0.0
	
	    #node Join Geometry
	    join_geometry_5 = hair_card.nodes.new("GeometryNodeJoinGeometry")
	    join_geometry_5.name = "Join Geometry"
	    join_geometry_5.hide = True
	
	    #node Vector Rotate
	    vector_rotate_3 = hair_card.nodes.new("ShaderNodeVectorRotate")
	    vector_rotate_3.name = "Vector Rotate"
	    vector_rotate_3.hide = True
	    vector_rotate_3.invert = False
	    vector_rotate_3.rotation_type = 'AXIS_ANGLE'
	    #Center
	    vector_rotate_3.inputs[1].default_value = (0.0, 0.0, 0.0)
	    #Axis
	    vector_rotate_3.inputs[2].default_value = (0.0, 0.0, 1.0)
	
	    #node Combine XYZ.003
	    combine_xyz_003 = hair_card.nodes.new("ShaderNodeCombineXYZ")
	    combine_xyz_003.name = "Combine XYZ.003"
	    combine_xyz_003.hide = True
	    #Y
	    combine_xyz_003.inputs[1].default_value = 0.0
	    #Z
	    combine_xyz_003.inputs[2].default_value = 0.0
	
	    #node Vector Math
	    vector_math_10 = hair_card.nodes.new("ShaderNodeVectorMath")
	    vector_math_10.name = "Vector Math"
	    vector_math_10.hide = True
	    vector_math_10.operation = 'MULTIPLY'
	    #Vector_001
	    vector_math_10.inputs[1].default_value = (-1.0, 1.0, 1.0)
	
	    #node Set Curve Radius
	    set_curve_radius = hair_card.nodes.new("GeometryNodeSetCurveRadius")
	    set_curve_radius.name = "Set Curve Radius"
	    set_curve_radius.hide = True
	    #Selection
	    set_curve_radius.inputs[1].default_value = True
	
	    #node Group Input.004
	    group_input_004_6 = hair_card.nodes.new("NodeGroupInput")
	    group_input_004_6.name = "Group Input.004"
	    group_input_004_6.outputs[0].hide = True
	    group_input_004_6.outputs[1].hide = True
	    group_input_004_6.outputs[3].hide = True
	    group_input_004_6.outputs[4].hide = True
	    group_input_004_6.outputs[5].hide = True
	    group_input_004_6.outputs[6].hide = True
	
	    #node Reroute.003
	    reroute_003_9 = hair_card.nodes.new("NodeReroute")
	    reroute_003_9.name = "Reroute.003"
	    reroute_003_9.socket_idname = "NodeSocketFloatDistance"
	    #node Reroute.004
	    reroute_004_10 = hair_card.nodes.new("NodeReroute")
	    reroute_004_10.name = "Reroute.004"
	    reroute_004_10.socket_idname = "NodeSocketFloatDistance"
	
	
	
	
	    #Set locations
	    group_input_14.location = (-340.0, 0.0)
	    group_output_17.location = (1204.581787109375, 58.388336181640625)
	    curve_to_mesh.location = (717.3101196289062, -30.657630920410156)
	    capture_attribute_5.location = (532.3717651367188, -13.901289939880371)
	    spline_parameter_4.location = (329.8749084472656, -144.0863800048828)
	    combine_xyz_3.location = (717.11865234375, -93.34249114990234)
	    store_named_attribute_3.location = (883.1387329101562, 66.61811828613281)
	    set_material.location = (1044.3658447265625, 32.40200424194336)
	    capture_attribute_002_7.location = (534.5352783203125, -74.45401000976562)
	    reroute_13.location = (496.6486511230469, -141.76992797851562)
	    group_input_001_9.location = (1041.4315185546875, 1.5365350246429443)
	    reroute_001_10.location = (-187.22337341308594, -77.96863555908203)
	    resample_curve.location = (-5.360104560852051, -28.505603790283203)
	    switch_10.location = (-5.43592643737793, 6.486942291259766)
	    group_input_002_8.location = (-336.779052734375, 70.9764633178711)
	    compare_9.location = (-8.656487464904785, 41.045326232910156)
	    reroute_002_9.location = (-99.20211791992188, -32.54893493652344)
	    group_input_003_9.location = (-339.9999694824219, -103.2856674194336)
	    points.location = (156.70631408691406, -123.0439224243164)
	    points_001.location = (156.70632934570312, -81.72965240478516)
	    points_002.location = (158.99679565429688, -168.9486846923828)
	    points_to_curves.location = (321.6205749511719, -74.84392547607422)
	    join_geometry_5.location = (328.4919128417969, -106.97728729248047)
	    vector_rotate_3.location = (-8.371872901916504, -97.79617309570312)
	    combine_xyz_003.location = (-168.62094116210938, -79.79706573486328)
	    vector_math_10.location = (-6.081514358520508, -135.33193969726562)
	    set_curve_radius.location = (320.7674560546875, -1.0603179931640625)
	    group_input_004_6.location = (-334.8185729980469, 133.8203125)
	    reroute_003_9.location = (237.70924377441406, 97.4658203125)
	    reroute_004_10.location = (241.74778747558594, -21.909408569335938)
	
	    #Set dimensions
	    group_input_14.width, group_input_14.height = 140.0, 100.0
	    group_output_17.width, group_output_17.height = 140.0, 100.0
	    curve_to_mesh.width, curve_to_mesh.height = 140.0, 100.0
	    capture_attribute_5.width, capture_attribute_5.height = 140.0, 100.0
	    spline_parameter_4.width, spline_parameter_4.height = 140.0, 100.0
	    combine_xyz_3.width, combine_xyz_3.height = 140.0, 100.0
	    store_named_attribute_3.width, store_named_attribute_3.height = 140.0, 100.0
	    set_material.width, set_material.height = 140.0, 100.0
	    capture_attribute_002_7.width, capture_attribute_002_7.height = 140.0, 100.0
	    reroute_13.width, reroute_13.height = 100.0, 100.0
	    group_input_001_9.width, group_input_001_9.height = 140.0, 100.0
	    reroute_001_10.width, reroute_001_10.height = 100.0, 100.0
	    resample_curve.width, resample_curve.height = 140.0, 100.0
	    switch_10.width, switch_10.height = 140.0, 100.0
	    group_input_002_8.width, group_input_002_8.height = 140.0, 100.0
	    compare_9.width, compare_9.height = 140.0, 100.0
	    reroute_002_9.width, reroute_002_9.height = 100.0, 100.0
	    group_input_003_9.width, group_input_003_9.height = 140.0, 100.0
	    points.width, points.height = 140.0, 100.0
	    points_001.width, points_001.height = 140.0, 100.0
	    points_002.width, points_002.height = 140.0, 100.0
	    points_to_curves.width, points_to_curves.height = 140.0, 100.0
	    join_geometry_5.width, join_geometry_5.height = 140.0, 100.0
	    vector_rotate_3.width, vector_rotate_3.height = 140.0, 100.0
	    combine_xyz_003.width, combine_xyz_003.height = 140.0, 100.0
	    vector_math_10.width, vector_math_10.height = 140.0, 100.0
	    set_curve_radius.width, set_curve_radius.height = 140.0, 100.0
	    group_input_004_6.width, group_input_004_6.height = 140.0, 100.0
	    reroute_003_9.width, reroute_003_9.height = 100.0, 100.0
	    reroute_004_10.width, reroute_004_10.height = 100.0, 100.0
	
	    #initialize hair_card links
	    #set_material.Geometry -> group_output_17.Geometry
	    hair_card.links.new(set_material.outputs[0], group_output_17.inputs[0])
	    #capture_attribute_5.Geometry -> curve_to_mesh.Curve
	    hair_card.links.new(capture_attribute_5.outputs[0], curve_to_mesh.inputs[0])
	    #reroute_13.Output -> capture_attribute_5.Factor
	    hair_card.links.new(reroute_13.outputs[0], capture_attribute_5.inputs[1])
	    #capture_attribute_5.Factor -> combine_xyz_3.X
	    hair_card.links.new(capture_attribute_5.outputs[1], combine_xyz_3.inputs[0])
	    #curve_to_mesh.Mesh -> store_named_attribute_3.Geometry
	    hair_card.links.new(curve_to_mesh.outputs[0], store_named_attribute_3.inputs[0])
	    #combine_xyz_3.Vector -> store_named_attribute_3.Value
	    hair_card.links.new(combine_xyz_3.outputs[0], store_named_attribute_3.inputs[3])
	    #store_named_attribute_3.Geometry -> set_material.Geometry
	    hair_card.links.new(store_named_attribute_3.outputs[0], set_material.inputs[0])
	    #reroute_13.Output -> capture_attribute_002_7.Factor
	    hair_card.links.new(reroute_13.outputs[0], capture_attribute_002_7.inputs[1])
	    #capture_attribute_002_7.Factor -> combine_xyz_3.Y
	    hair_card.links.new(capture_attribute_002_7.outputs[1], combine_xyz_3.inputs[1])
	    #spline_parameter_4.Factor -> reroute_13.Input
	    hair_card.links.new(spline_parameter_4.outputs[0], reroute_13.inputs[0])
	    #group_input_001_9.Material -> set_material.Material
	    hair_card.links.new(group_input_001_9.outputs[1], set_material.inputs[2])
	    #group_input_14.Width -> reroute_001_10.Input
	    hair_card.links.new(group_input_14.outputs[4], reroute_001_10.inputs[0])
	    #reroute_002_9.Output -> resample_curve.Curve
	    hair_card.links.new(reroute_002_9.outputs[0], resample_curve.inputs[0])
	    #group_input_14.Resolution -> resample_curve.Count
	    hair_card.links.new(group_input_14.outputs[3], resample_curve.inputs[2])
	    #group_input_002_8.Resolution -> compare_9.A
	    hair_card.links.new(group_input_002_8.outputs[3], compare_9.inputs[2])
	    #compare_9.Result -> switch_10.Switch
	    hair_card.links.new(compare_9.outputs[0], switch_10.inputs[0])
	    #set_curve_radius.Curve -> capture_attribute_5.Geometry
	    hair_card.links.new(set_curve_radius.outputs[0], capture_attribute_5.inputs[0])
	    #group_input_14.Geometry -> reroute_002_9.Input
	    hair_card.links.new(group_input_14.outputs[0], reroute_002_9.inputs[0])
	    #reroute_002_9.Output -> switch_10.True
	    hair_card.links.new(reroute_002_9.outputs[0], switch_10.inputs[2])
	    #resample_curve.Curve -> switch_10.False
	    hair_card.links.new(resample_curve.outputs[0], switch_10.inputs[1])
	    #join_geometry_5.Geometry -> points_to_curves.Points
	    hair_card.links.new(join_geometry_5.outputs[0], points_to_curves.inputs[0])
	    #points_002.Points -> join_geometry_5.Geometry
	    hair_card.links.new(points_002.outputs[0], join_geometry_5.inputs[0])
	    #group_input_003_9.Angle -> vector_rotate_3.Angle
	    hair_card.links.new(group_input_003_9.outputs[5], vector_rotate_3.inputs[3])
	    #vector_rotate_3.Vector -> vector_math_10.Vector
	    hair_card.links.new(vector_rotate_3.outputs[0], vector_math_10.inputs[0])
	    #vector_rotate_3.Vector -> points_001.Position
	    hair_card.links.new(vector_rotate_3.outputs[0], points_001.inputs[1])
	    #vector_math_10.Vector -> points_002.Position
	    hair_card.links.new(vector_math_10.outputs[0], points_002.inputs[1])
	    #combine_xyz_003.Vector -> vector_rotate_3.Vector
	    hair_card.links.new(combine_xyz_003.outputs[0], vector_rotate_3.inputs[0])
	    #reroute_001_10.Output -> combine_xyz_003.X
	    hair_card.links.new(reroute_001_10.outputs[0], combine_xyz_003.inputs[0])
	    #points_to_curves.Curves -> capture_attribute_002_7.Geometry
	    hair_card.links.new(points_to_curves.outputs[0], capture_attribute_002_7.inputs[0])
	    #capture_attribute_002_7.Geometry -> curve_to_mesh.Profile Curve
	    hair_card.links.new(capture_attribute_002_7.outputs[0], curve_to_mesh.inputs[1])
	    #switch_10.Output -> set_curve_radius.Curve
	    hair_card.links.new(switch_10.outputs[0], set_curve_radius.inputs[0])
	    #reroute_004_10.Output -> set_curve_radius.Radius
	    hair_card.links.new(reroute_004_10.outputs[0], set_curve_radius.inputs[2])
	    #group_input_004_6.Curve Radius -> reroute_003_9.Input
	    hair_card.links.new(group_input_004_6.outputs[2], reroute_003_9.inputs[0])
	    #reroute_003_9.Output -> reroute_004_10.Input
	    hair_card.links.new(reroute_003_9.outputs[0], reroute_004_10.inputs[0])
	    #points.Points -> join_geometry_5.Geometry
	    hair_card.links.new(points.outputs[0], join_geometry_5.inputs[0])
	    #points_001.Points -> join_geometry_5.Geometry
	    hair_card.links.new(points_001.outputs[0], join_geometry_5.inputs[0])
	    return hair_card
	
	hair_card = hair_card_node_group()
	
	#initialize stylized_hair node group
	def stylized_hair_node_group():
	    stylized_hair = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Stylized_Hair")
	
	    stylized_hair.color_tag = 'NONE'
	    stylized_hair.description = ""
	    stylized_hair.default_group_node_width = 140
	    
	
	    stylized_hair.is_modifier = True
	
	    #stylized_hair interface
	    #Socket Geometry
	    geometry_socket_25 = stylized_hair.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_25.attribute_domain = 'POINT'
	
	    #Socket Geometry
	    geometry_socket_26 = stylized_hair.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_26.attribute_domain = 'POINT'
	
	    #Socket Profile
	    profile_socket = stylized_hair.interface.new_socket(name = "Profile", in_out='INPUT', socket_type = 'NodeSocketObject')
	    profile_socket.attribute_domain = 'POINT'
	
	    #Socket Material
	    material_socket_1 = stylized_hair.interface.new_socket(name = "Material", in_out='INPUT', socket_type = 'NodeSocketMaterial')
	    material_socket_1.attribute_domain = 'POINT'
	
	    #Socket Curve Radius
	    curve_radius_socket_1 = stylized_hair.interface.new_socket(name = "Curve Radius", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    curve_radius_socket_1.default_value = 1.0
	    curve_radius_socket_1.min_value = 0.0
	    curve_radius_socket_1.max_value = 3.4028234663852886e+38
	    curve_radius_socket_1.subtype = 'DISTANCE'
	    curve_radius_socket_1.attribute_domain = 'POINT'
	    curve_radius_socket_1.hide_value = True
	    curve_radius_socket_1.hide_in_modifier = True
	
	    #Socket Resolution
	    resolution_socket_1 = stylized_hair.interface.new_socket(name = "Resolution", in_out='INPUT', socket_type = 'NodeSocketInt')
	    resolution_socket_1.default_value = 10
	    resolution_socket_1.min_value = 1
	    resolution_socket_1.max_value = 100000
	    resolution_socket_1.subtype = 'NONE'
	    resolution_socket_1.attribute_domain = 'POINT'
	
	    #Socket Fill Caps
	    fill_caps_socket = stylized_hair.interface.new_socket(name = "Fill Caps", in_out='INPUT', socket_type = 'NodeSocketBool')
	    fill_caps_socket.default_value = True
	    fill_caps_socket.attribute_domain = 'POINT'
	
	    #Socket Translation
	    translation_socket = stylized_hair.interface.new_socket(name = "Translation", in_out='INPUT', socket_type = 'NodeSocketVector')
	    translation_socket.default_value = (0.0, 0.0, 0.0)
	    translation_socket.min_value = -3.4028234663852886e+38
	    translation_socket.max_value = 3.4028234663852886e+38
	    translation_socket.subtype = 'TRANSLATION'
	    translation_socket.attribute_domain = 'POINT'
	
	    #Socket Rotation
	    rotation_socket = stylized_hair.interface.new_socket(name = "Rotation", in_out='INPUT', socket_type = 'NodeSocketRotation')
	    rotation_socket.default_value = (0.0, 0.0, 0.0)
	    rotation_socket.attribute_domain = 'POINT'
	
	    #Socket Scale
	    scale_socket = stylized_hair.interface.new_socket(name = "Scale", in_out='INPUT', socket_type = 'NodeSocketVector')
	    scale_socket.default_value = (1.0, 1.0, 1.0)
	    scale_socket.min_value = -3.4028234663852886e+38
	    scale_socket.max_value = 3.4028234663852886e+38
	    scale_socket.subtype = 'XYZ'
	    scale_socket.attribute_domain = 'POINT'
	
	
	    #initialize stylized_hair nodes
	    #node Group Input
	    group_input_15 = stylized_hair.nodes.new("NodeGroupInput")
	    group_input_15.name = "Group Input"
	    group_input_15.outputs[2].hide = True
	    group_input_15.outputs[3].hide = True
	    group_input_15.outputs[4].hide = True
	    group_input_15.outputs[5].hide = True
	    group_input_15.outputs[6].hide = True
	    group_input_15.outputs[7].hide = True
	    group_input_15.outputs[8].hide = True
	    group_input_15.outputs[9].hide = True
	
	    #node Group Output
	    group_output_18 = stylized_hair.nodes.new("NodeGroupOutput")
	    group_output_18.name = "Group Output"
	    group_output_18.is_active_output = True
	
	    #node Curve to Mesh
	    curve_to_mesh_1 = stylized_hair.nodes.new("GeometryNodeCurveToMesh")
	    curve_to_mesh_1.name = "Curve to Mesh"
	    curve_to_mesh_1.hide = True
	
	    #node Capture Attribute
	    capture_attribute_6 = stylized_hair.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_6.name = "Capture Attribute"
	    capture_attribute_6.hide = True
	    capture_attribute_6.active_index = 0
	    capture_attribute_6.capture_items.clear()
	    capture_attribute_6.capture_items.new('FLOAT', "Factor")
	    capture_attribute_6.capture_items["Factor"].data_type = 'FLOAT'
	    capture_attribute_6.domain = 'POINT'
	
	    #node Spline Parameter
	    spline_parameter_5 = stylized_hair.nodes.new("GeometryNodeSplineParameter")
	    spline_parameter_5.name = "Spline Parameter"
	    spline_parameter_5.hide = True
	
	    #node Combine XYZ
	    combine_xyz_4 = stylized_hair.nodes.new("ShaderNodeCombineXYZ")
	    combine_xyz_4.name = "Combine XYZ"
	    combine_xyz_4.hide = True
	    #Z
	    combine_xyz_4.inputs[2].default_value = 0.0
	
	    #node Store Named Attribute
	    store_named_attribute_4 = stylized_hair.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_4.name = "Store Named Attribute"
	    store_named_attribute_4.data_type = 'FLOAT2'
	    store_named_attribute_4.domain = 'CORNER'
	    #Selection
	    store_named_attribute_4.inputs[1].default_value = True
	    #Name
	    store_named_attribute_4.inputs[2].default_value = "stylized_hair_UV"
	
	    #node Set Material
	    set_material_1 = stylized_hair.nodes.new("GeometryNodeSetMaterial")
	    set_material_1.name = "Set Material"
	    set_material_1.hide = True
	    #Selection
	    set_material_1.inputs[1].default_value = True
	
	    #node Capture Attribute.002
	    capture_attribute_002_8 = stylized_hair.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_002_8.name = "Capture Attribute.002"
	    capture_attribute_002_8.hide = True
	    capture_attribute_002_8.active_index = 0
	    capture_attribute_002_8.capture_items.clear()
	    capture_attribute_002_8.capture_items.new('FLOAT', "Factor")
	    capture_attribute_002_8.capture_items["Factor"].data_type = 'FLOAT'
	    capture_attribute_002_8.domain = 'POINT'
	
	    #node Reroute
	    reroute_14 = stylized_hair.nodes.new("NodeReroute")
	    reroute_14.name = "Reroute"
	    reroute_14.socket_idname = "NodeSocketFloat"
	    #node Group Input.001
	    group_input_001_10 = stylized_hair.nodes.new("NodeGroupInput")
	    group_input_001_10.name = "Group Input.001"
	    group_input_001_10.outputs[0].hide = True
	    group_input_001_10.outputs[1].hide = True
	    group_input_001_10.outputs[3].hide = True
	    group_input_001_10.outputs[4].hide = True
	    group_input_001_10.outputs[5].hide = True
	    group_input_001_10.outputs[6].hide = True
	    group_input_001_10.outputs[7].hide = True
	    group_input_001_10.outputs[8].hide = True
	    group_input_001_10.outputs[9].hide = True
	
	    #node Group Input.002
	    group_input_002_9 = stylized_hair.nodes.new("NodeGroupInput")
	    group_input_002_9.name = "Group Input.002"
	    group_input_002_9.outputs[0].hide = True
	    group_input_002_9.outputs[1].hide = True
	    group_input_002_9.outputs[2].hide = True
	    group_input_002_9.outputs[3].hide = True
	    group_input_002_9.outputs[4].hide = True
	    group_input_002_9.outputs[6].hide = True
	    group_input_002_9.outputs[7].hide = True
	    group_input_002_9.outputs[8].hide = True
	    group_input_002_9.outputs[9].hide = True
	
	    #node Object Info
	    object_info_2 = stylized_hair.nodes.new("GeometryNodeObjectInfo")
	    object_info_2.name = "Object Info"
	    object_info_2.hide = True
	    object_info_2.transform_space = 'RELATIVE'
	    #As Instance
	    object_info_2.inputs[1].default_value = False
	
	    #node Transform Geometry
	    transform_geometry = stylized_hair.nodes.new("GeometryNodeTransform")
	    transform_geometry.name = "Transform Geometry"
	    transform_geometry.hide = True
	    transform_geometry.mode = 'COMPONENTS'
	
	    #node Group Input.003
	    group_input_003_10 = stylized_hair.nodes.new("NodeGroupInput")
	    group_input_003_10.name = "Group Input.003"
	    group_input_003_10.outputs[0].hide = True
	    group_input_003_10.outputs[1].hide = True
	    group_input_003_10.outputs[2].hide = True
	    group_input_003_10.outputs[4].hide = True
	    group_input_003_10.outputs[5].hide = True
	    group_input_003_10.outputs[6].hide = True
	    group_input_003_10.outputs[7].hide = True
	    group_input_003_10.outputs[8].hide = True
	    group_input_003_10.outputs[9].hide = True
	
	    #node Group Input.004
	    group_input_004_7 = stylized_hair.nodes.new("NodeGroupInput")
	    group_input_004_7.name = "Group Input.004"
	    group_input_004_7.outputs[0].hide = True
	    group_input_004_7.outputs[1].hide = True
	    group_input_004_7.outputs[2].hide = True
	    group_input_004_7.outputs[3].hide = True
	    group_input_004_7.outputs[4].hide = True
	    group_input_004_7.outputs[5].hide = True
	    group_input_004_7.outputs[9].hide = True
	
	    #node Set Curve Radius
	    set_curve_radius_1 = stylized_hair.nodes.new("GeometryNodeSetCurveRadius")
	    set_curve_radius_1.name = "Set Curve Radius"
	    set_curve_radius_1.hide = True
	    #Selection
	    set_curve_radius_1.inputs[1].default_value = True
	
	    #node Reroute.001
	    reroute_001_11 = stylized_hair.nodes.new("NodeReroute")
	    reroute_001_11.name = "Reroute.001"
	    reroute_001_11.socket_idname = "NodeSocketGeometry"
	    #node Reroute.002
	    reroute_002_10 = stylized_hair.nodes.new("NodeReroute")
	    reroute_002_10.name = "Reroute.002"
	    reroute_002_10.socket_idname = "NodeSocketGeometry"
	    #node Resample Curve
	    resample_curve_1 = stylized_hair.nodes.new("GeometryNodeResampleCurve")
	    resample_curve_1.name = "Resample Curve"
	    resample_curve_1.hide = True
	    resample_curve_1.keep_last_segment = False
	    resample_curve_1.mode = 'COUNT'
	    #Selection
	    resample_curve_1.inputs[1].default_value = True
	
	    #node Switch
	    switch_11 = stylized_hair.nodes.new("GeometryNodeSwitch")
	    switch_11.name = "Switch"
	    switch_11.hide = True
	    switch_11.input_type = 'GEOMETRY'
	
	    #node Compare
	    compare_10 = stylized_hair.nodes.new("FunctionNodeCompare")
	    compare_10.name = "Compare"
	    compare_10.hide = True
	    compare_10.data_type = 'INT'
	    compare_10.mode = 'ELEMENT'
	    compare_10.operation = 'LESS_THAN'
	    #B_INT
	    compare_10.inputs[3].default_value = 2
	
	    #node Reroute.005
	    reroute_005_8 = stylized_hair.nodes.new("NodeReroute")
	    reroute_005_8.name = "Reroute.005"
	    reroute_005_8.socket_idname = "NodeSocketGeometry"
	    #node Group Input.005
	    group_input_005_7 = stylized_hair.nodes.new("NodeGroupInput")
	    group_input_005_7.name = "Group Input.005"
	    group_input_005_7.outputs[0].hide = True
	    group_input_005_7.outputs[1].hide = True
	    group_input_005_7.outputs[2].hide = True
	    group_input_005_7.outputs[3].hide = True
	    group_input_005_7.outputs[5].hide = True
	    group_input_005_7.outputs[6].hide = True
	    group_input_005_7.outputs[7].hide = True
	    group_input_005_7.outputs[8].hide = True
	    group_input_005_7.outputs[9].hide = True
	
	
	
	
	
	    #Set locations
	    group_input_15.location = (-340.0, -125.68765258789062)
	    group_output_18.location = (1046.0562744140625, -35.87745666503906)
	    curve_to_mesh_1.location = (546.74853515625, -108.79241180419922)
	    capture_attribute_6.location = (361.8101501464844, -82.63687133789062)
	    spline_parameter_5.location = (156.93017578125, -142.56178283691406)
	    combine_xyz_4.location = (546.5570068359375, -195.67379760742188)
	    store_named_attribute_4.location = (712.5771484375, -27.647676467895508)
	    set_material_1.location = (873.80419921875, -61.86378860473633)
	    capture_attribute_002_8.location = (363.9737243652344, -168.7198028564453)
	    reroute_14.location = (319.04217529296875, -141.52703857421875)
	    group_input_001_10.location = (870.8699951171875, -92.72925567626953)
	    group_input_002_9.location = (542.2694702148438, -137.2887725830078)
	    object_info_2.location = (-173.28436279296875, -181.30752563476562)
	    transform_geometry.location = (156.43304443359375, -206.8249053955078)
	    group_input_003_10.location = (-339.0907897949219, -62.643611907958984)
	    group_input_004_7.location = (-338.4869689941406, -211.2111053466797)
	    set_curve_radius_1.location = (158.24813842773438, -76.21592712402344)
	    reroute_001_11.location = (-164.16294860839844, -159.83448791503906)
	    reroute_002_10.location = (-164.90399169921875, -71.62743377685547)
	    resample_curve_1.location = (-36.965057373046875, -67.16246032714844)
	    switch_11.location = (-37.0408821105957, -32.16990661621094)
	    compare_10.location = (-40.26144027709961, 2.388460159301758)
	    reroute_005_8.location = (-130.80706787109375, -71.2057876586914)
	    group_input_005_7.location = (-338.4869689941406, -2.108567237854004)
	
	    #Set dimensions
	    group_input_15.width, group_input_15.height = 140.0, 100.0
	    group_output_18.width, group_output_18.height = 140.0, 100.0
	    curve_to_mesh_1.width, curve_to_mesh_1.height = 140.0, 100.0
	    capture_attribute_6.width, capture_attribute_6.height = 140.0, 100.0
	    spline_parameter_5.width, spline_parameter_5.height = 140.0, 100.0
	    combine_xyz_4.width, combine_xyz_4.height = 140.0, 100.0
	    store_named_attribute_4.width, store_named_attribute_4.height = 140.0, 100.0
	    set_material_1.width, set_material_1.height = 140.0, 100.0
	    capture_attribute_002_8.width, capture_attribute_002_8.height = 140.0, 100.0
	    reroute_14.width, reroute_14.height = 100.0, 100.0
	    group_input_001_10.width, group_input_001_10.height = 140.0, 100.0
	    group_input_002_9.width, group_input_002_9.height = 140.0, 100.0
	    object_info_2.width, object_info_2.height = 140.0, 100.0
	    transform_geometry.width, transform_geometry.height = 140.0, 100.0
	    group_input_003_10.width, group_input_003_10.height = 140.0, 100.0
	    group_input_004_7.width, group_input_004_7.height = 140.0, 100.0
	    set_curve_radius_1.width, set_curve_radius_1.height = 140.0, 100.0
	    reroute_001_11.width, reroute_001_11.height = 100.0, 100.0
	    reroute_002_10.width, reroute_002_10.height = 100.0, 100.0
	    resample_curve_1.width, resample_curve_1.height = 140.0, 100.0
	    switch_11.width, switch_11.height = 140.0, 100.0
	    compare_10.width, compare_10.height = 140.0, 100.0
	    reroute_005_8.width, reroute_005_8.height = 100.0, 100.0
	    group_input_005_7.width, group_input_005_7.height = 140.0, 100.0
	
	    #initialize stylized_hair links
	    #set_material_1.Geometry -> group_output_18.Geometry
	    stylized_hair.links.new(set_material_1.outputs[0], group_output_18.inputs[0])
	    #capture_attribute_6.Geometry -> curve_to_mesh_1.Curve
	    stylized_hair.links.new(capture_attribute_6.outputs[0], curve_to_mesh_1.inputs[0])
	    #set_curve_radius_1.Curve -> capture_attribute_6.Geometry
	    stylized_hair.links.new(set_curve_radius_1.outputs[0], capture_attribute_6.inputs[0])
	    #reroute_14.Output -> capture_attribute_6.Factor
	    stylized_hair.links.new(reroute_14.outputs[0], capture_attribute_6.inputs[1])
	    #capture_attribute_6.Factor -> combine_xyz_4.X
	    stylized_hair.links.new(capture_attribute_6.outputs[1], combine_xyz_4.inputs[0])
	    #curve_to_mesh_1.Mesh -> store_named_attribute_4.Geometry
	    stylized_hair.links.new(curve_to_mesh_1.outputs[0], store_named_attribute_4.inputs[0])
	    #combine_xyz_4.Vector -> store_named_attribute_4.Value
	    stylized_hair.links.new(combine_xyz_4.outputs[0], store_named_attribute_4.inputs[3])
	    #store_named_attribute_4.Geometry -> set_material_1.Geometry
	    stylized_hair.links.new(store_named_attribute_4.outputs[0], set_material_1.inputs[0])
	    #reroute_14.Output -> capture_attribute_002_8.Factor
	    stylized_hair.links.new(reroute_14.outputs[0], capture_attribute_002_8.inputs[1])
	    #capture_attribute_002_8.Factor -> combine_xyz_4.Y
	    stylized_hair.links.new(capture_attribute_002_8.outputs[1], combine_xyz_4.inputs[1])
	    #capture_attribute_002_8.Geometry -> curve_to_mesh_1.Profile Curve
	    stylized_hair.links.new(capture_attribute_002_8.outputs[0], curve_to_mesh_1.inputs[1])
	    #spline_parameter_5.Factor -> reroute_14.Input
	    stylized_hair.links.new(spline_parameter_5.outputs[0], reroute_14.inputs[0])
	    #group_input_001_10.Material -> set_material_1.Material
	    stylized_hair.links.new(group_input_001_10.outputs[2], set_material_1.inputs[2])
	    #group_input_002_9.Fill Caps -> curve_to_mesh_1.Fill Caps
	    stylized_hair.links.new(group_input_002_9.outputs[5], curve_to_mesh_1.inputs[2])
	    #group_input_15.Profile -> object_info_2.Object
	    stylized_hair.links.new(group_input_15.outputs[1], object_info_2.inputs[0])
	    #object_info_2.Geometry -> transform_geometry.Geometry
	    stylized_hair.links.new(object_info_2.outputs[4], transform_geometry.inputs[0])
	    #transform_geometry.Geometry -> capture_attribute_002_8.Geometry
	    stylized_hair.links.new(transform_geometry.outputs[0], capture_attribute_002_8.inputs[0])
	    #group_input_003_10.Curve Radius -> set_curve_radius_1.Radius
	    stylized_hair.links.new(group_input_003_10.outputs[3], set_curve_radius_1.inputs[2])
	    #group_input_004_7.Translation -> transform_geometry.Translation
	    stylized_hair.links.new(group_input_004_7.outputs[6], transform_geometry.inputs[1])
	    #group_input_004_7.Rotation -> transform_geometry.Rotation
	    stylized_hair.links.new(group_input_004_7.outputs[7], transform_geometry.inputs[2])
	    #group_input_004_7.Scale -> transform_geometry.Scale
	    stylized_hair.links.new(group_input_004_7.outputs[8], transform_geometry.inputs[3])
	    #group_input_15.Geometry -> reroute_001_11.Input
	    stylized_hair.links.new(group_input_15.outputs[0], reroute_001_11.inputs[0])
	    #reroute_001_11.Output -> reroute_002_10.Input
	    stylized_hair.links.new(reroute_001_11.outputs[0], reroute_002_10.inputs[0])
	    #reroute_005_8.Output -> resample_curve_1.Curve
	    stylized_hair.links.new(reroute_005_8.outputs[0], resample_curve_1.inputs[0])
	    #compare_10.Result -> switch_11.Switch
	    stylized_hair.links.new(compare_10.outputs[0], switch_11.inputs[0])
	    #reroute_005_8.Output -> switch_11.True
	    stylized_hair.links.new(reroute_005_8.outputs[0], switch_11.inputs[2])
	    #resample_curve_1.Curve -> switch_11.False
	    stylized_hair.links.new(resample_curve_1.outputs[0], switch_11.inputs[1])
	    #group_input_005_7.Resolution -> resample_curve_1.Count
	    stylized_hair.links.new(group_input_005_7.outputs[4], resample_curve_1.inputs[2])
	    #group_input_005_7.Resolution -> compare_10.A
	    stylized_hair.links.new(group_input_005_7.outputs[4], compare_10.inputs[2])
	    #switch_11.Output -> set_curve_radius_1.Curve
	    stylized_hair.links.new(switch_11.outputs[0], set_curve_radius_1.inputs[0])
	    #reroute_002_10.Output -> reroute_005_8.Input
	    stylized_hair.links.new(reroute_002_10.outputs[0], reroute_005_8.inputs[0])
	    return stylized_hair
	
	stylized_hair = stylized_hair_node_group()
	
	#initialize tube_mesh node group
	def tube_mesh_node_group():
	    tube_mesh = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Tube_Mesh")
	
	    tube_mesh.color_tag = 'NONE'
	    tube_mesh.description = ""
	    tube_mesh.default_group_node_width = 140
	    
	
	    tube_mesh.is_modifier = True
	
	    #tube_mesh interface
	    #Socket Geometry
	    geometry_socket_27 = tube_mesh.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_27.attribute_domain = 'POINT'
	
	    #Socket Geometry
	    geometry_socket_28 = tube_mesh.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_28.attribute_domain = 'POINT'
	
	    #Socket Material
	    material_socket_2 = tube_mesh.interface.new_socket(name = "Material", in_out='INPUT', socket_type = 'NodeSocketMaterial')
	    material_socket_2.attribute_domain = 'POINT'
	
	    #Socket Curve Radius
	    curve_radius_socket_2 = tube_mesh.interface.new_socket(name = "Curve Radius", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    curve_radius_socket_2.default_value = 1.0
	    curve_radius_socket_2.min_value = 0.0
	    curve_radius_socket_2.max_value = 3.4028234663852886e+38
	    curve_radius_socket_2.subtype = 'DISTANCE'
	    curve_radius_socket_2.attribute_domain = 'POINT'
	    curve_radius_socket_2.hide_value = True
	    curve_radius_socket_2.hide_in_modifier = True
	
	    #Socket Resolution
	    resolution_socket_2 = tube_mesh.interface.new_socket(name = "Resolution", in_out='INPUT', socket_type = 'NodeSocketInt')
	    resolution_socket_2.default_value = 32
	    resolution_socket_2.min_value = 3
	    resolution_socket_2.max_value = 512
	    resolution_socket_2.subtype = 'NONE'
	    resolution_socket_2.attribute_domain = 'POINT'
	
	    #Socket Width
	    width_socket_1 = tube_mesh.interface.new_socket(name = "Width", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    width_socket_1.default_value = 0.10000000149011612
	    width_socket_1.min_value = 0.0
	    width_socket_1.max_value = 3.4028234663852886e+38
	    width_socket_1.subtype = 'DISTANCE'
	    width_socket_1.attribute_domain = 'POINT'
	
	    #Socket Fill Caps
	    fill_caps_socket_1 = tube_mesh.interface.new_socket(name = "Fill Caps", in_out='INPUT', socket_type = 'NodeSocketBool')
	    fill_caps_socket_1.default_value = True
	    fill_caps_socket_1.attribute_domain = 'POINT'
	
	
	    #initialize tube_mesh nodes
	    #node Group Input
	    group_input_16 = tube_mesh.nodes.new("NodeGroupInput")
	    group_input_16.name = "Group Input"
	    group_input_16.outputs[1].hide = True
	    group_input_16.outputs[2].hide = True
	    group_input_16.outputs[5].hide = True
	    group_input_16.outputs[6].hide = True
	
	    #node Group Output
	    group_output_19 = tube_mesh.nodes.new("NodeGroupOutput")
	    group_output_19.name = "Group Output"
	    group_output_19.is_active_output = True
	
	    #node Curve to Mesh
	    curve_to_mesh_2 = tube_mesh.nodes.new("GeometryNodeCurveToMesh")
	    curve_to_mesh_2.name = "Curve to Mesh"
	    curve_to_mesh_2.hide = True
	
	    #node Capture Attribute
	    capture_attribute_7 = tube_mesh.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_7.name = "Capture Attribute"
	    capture_attribute_7.hide = True
	    capture_attribute_7.active_index = 0
	    capture_attribute_7.capture_items.clear()
	    capture_attribute_7.capture_items.new('FLOAT', "Factor")
	    capture_attribute_7.capture_items["Factor"].data_type = 'FLOAT'
	    capture_attribute_7.domain = 'POINT'
	
	    #node Spline Parameter
	    spline_parameter_6 = tube_mesh.nodes.new("GeometryNodeSplineParameter")
	    spline_parameter_6.name = "Spline Parameter"
	    spline_parameter_6.hide = True
	
	    #node Combine XYZ
	    combine_xyz_5 = tube_mesh.nodes.new("ShaderNodeCombineXYZ")
	    combine_xyz_5.name = "Combine XYZ"
	    combine_xyz_5.hide = True
	    #Z
	    combine_xyz_5.inputs[2].default_value = 0.0
	
	    #node Store Named Attribute
	    store_named_attribute_5 = tube_mesh.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_5.name = "Store Named Attribute"
	    store_named_attribute_5.data_type = 'FLOAT2'
	    store_named_attribute_5.domain = 'CORNER'
	    #Selection
	    store_named_attribute_5.inputs[1].default_value = True
	    #Name
	    store_named_attribute_5.inputs[2].default_value = "tube_mesh_UV"
	
	    #node Set Material
	    set_material_2 = tube_mesh.nodes.new("GeometryNodeSetMaterial")
	    set_material_2.name = "Set Material"
	    set_material_2.hide = True
	    #Selection
	    set_material_2.inputs[1].default_value = True
	
	    #node Curve Circle
	    curve_circle = tube_mesh.nodes.new("GeometryNodeCurvePrimitiveCircle")
	    curve_circle.name = "Curve Circle"
	    curve_circle.hide = True
	    curve_circle.mode = 'RADIUS'
	    #Resolution
	    curve_circle.inputs[0].default_value = 16
	
	    #node Capture Attribute.002
	    capture_attribute_002_9 = tube_mesh.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_002_9.name = "Capture Attribute.002"
	    capture_attribute_002_9.hide = True
	    capture_attribute_002_9.active_index = 0
	    capture_attribute_002_9.capture_items.clear()
	    capture_attribute_002_9.capture_items.new('FLOAT', "Factor")
	    capture_attribute_002_9.capture_items["Factor"].data_type = 'FLOAT'
	    capture_attribute_002_9.domain = 'POINT'
	
	    #node Reroute
	    reroute_15 = tube_mesh.nodes.new("NodeReroute")
	    reroute_15.name = "Reroute"
	    reroute_15.socket_idname = "NodeSocketFloat"
	    #node Group Input.001
	    group_input_001_11 = tube_mesh.nodes.new("NodeGroupInput")
	    group_input_001_11.name = "Group Input.001"
	    group_input_001_11.outputs[0].hide = True
	    group_input_001_11.outputs[2].hide = True
	    group_input_001_11.outputs[3].hide = True
	    group_input_001_11.outputs[4].hide = True
	    group_input_001_11.outputs[5].hide = True
	    group_input_001_11.outputs[6].hide = True
	
	    #node Group Input.002
	    group_input_002_10 = tube_mesh.nodes.new("NodeGroupInput")
	    group_input_002_10.name = "Group Input.002"
	    group_input_002_10.outputs[0].hide = True
	    group_input_002_10.outputs[1].hide = True
	    group_input_002_10.outputs[2].hide = True
	    group_input_002_10.outputs[3].hide = True
	    group_input_002_10.outputs[4].hide = True
	    group_input_002_10.outputs[6].hide = True
	
	    #node Set Curve Radius
	    set_curve_radius_2 = tube_mesh.nodes.new("GeometryNodeSetCurveRadius")
	    set_curve_radius_2.name = "Set Curve Radius"
	    set_curve_radius_2.hide = True
	    #Selection
	    set_curve_radius_2.inputs[1].default_value = True
	
	    #node Group Input.003
	    group_input_003_11 = tube_mesh.nodes.new("NodeGroupInput")
	    group_input_003_11.name = "Group Input.003"
	    group_input_003_11.outputs[0].hide = True
	    group_input_003_11.outputs[1].hide = True
	    group_input_003_11.outputs[3].hide = True
	    group_input_003_11.outputs[4].hide = True
	    group_input_003_11.outputs[5].hide = True
	    group_input_003_11.outputs[6].hide = True
	
	    #node Resample Curve
	    resample_curve_2 = tube_mesh.nodes.new("GeometryNodeResampleCurve")
	    resample_curve_2.name = "Resample Curve"
	    resample_curve_2.hide = True
	    resample_curve_2.keep_last_segment = False
	    resample_curve_2.mode = 'COUNT'
	    #Selection
	    resample_curve_2.inputs[1].default_value = True
	
	    #node Switch
	    switch_12 = tube_mesh.nodes.new("GeometryNodeSwitch")
	    switch_12.name = "Switch"
	    switch_12.hide = True
	    switch_12.input_type = 'GEOMETRY'
	
	    #node Compare
	    compare_11 = tube_mesh.nodes.new("FunctionNodeCompare")
	    compare_11.name = "Compare"
	    compare_11.hide = True
	    compare_11.data_type = 'INT'
	    compare_11.mode = 'ELEMENT'
	    compare_11.operation = 'LESS_THAN'
	    #B_INT
	    compare_11.inputs[3].default_value = 2
	
	    #node Reroute.003
	    reroute_003_10 = tube_mesh.nodes.new("NodeReroute")
	    reroute_003_10.name = "Reroute.003"
	    reroute_003_10.socket_idname = "NodeSocketGeometry"
	    #node Group Input.004
	    group_input_004_8 = tube_mesh.nodes.new("NodeGroupInput")
	    group_input_004_8.name = "Group Input.004"
	    group_input_004_8.outputs[0].hide = True
	    group_input_004_8.outputs[1].hide = True
	    group_input_004_8.outputs[2].hide = True
	    group_input_004_8.outputs[4].hide = True
	    group_input_004_8.outputs[5].hide = True
	    group_input_004_8.outputs[6].hide = True
	
	    #node Reroute.006
	    reroute_006_8 = tube_mesh.nodes.new("NodeReroute")
	    reroute_006_8.name = "Reroute.006"
	    reroute_006_8.socket_idname = "NodeSocketFloatDistance"
	    #node Reroute.007
	    reroute_007_8 = tube_mesh.nodes.new("NodeReroute")
	    reroute_007_8.name = "Reroute.007"
	    reroute_007_8.socket_idname = "NodeSocketFloatDistance"
	    #node Reroute.008
	    reroute_008_8 = tube_mesh.nodes.new("NodeReroute")
	    reroute_008_8.name = "Reroute.008"
	    reroute_008_8.socket_idname = "NodeSocketInt"
	    #node Reroute.009
	    reroute_009_8 = tube_mesh.nodes.new("NodeReroute")
	    reroute_009_8.name = "Reroute.009"
	    reroute_009_8.socket_idname = "NodeSocketInt"
	
	
	
	
	    #Set locations
	    group_input_16.location = (-340.0, 0.0)
	    group_output_19.location = (953.9598388671875, 58.388336181640625)
	    curve_to_mesh_2.location = (466.6881408691406, -14.526612281799316)
	    capture_attribute_7.location = (281.749755859375, -33.53998565673828)
	    spline_parameter_6.location = (84.9455795288086, -92.41136169433594)
	    combine_xyz_5.location = (466.4966735839844, -101.40799713134766)
	    store_named_attribute_5.location = (632.5167846679688, 66.61811828613281)
	    set_material_2.location = (793.743896484375, 32.40200424194336)
	    curve_circle.location = (87.1727523803711, -56.81591033935547)
	    capture_attribute_002_9.location = (283.9133605957031, -74.45401000976562)
	    reroute_15.location = (247.05758666992188, -91.37664031982422)
	    group_input_001_11.location = (790.8096313476562, 1.5365350246429443)
	    group_input_002_10.location = (462.2091369628906, -43.022979736328125)
	    set_curve_radius_2.location = (93.72252655029297, -22.188615798950195)
	    group_input_003_11.location = (-339.80987548828125, 120.61366271972656)
	    resample_curve_2.location = (-105.32349395751953, -15.050445556640625)
	    switch_12.location = (-105.3993148803711, 19.942108154296875)
	    compare_11.location = (-108.61988830566406, 54.5004768371582)
	    reroute_003_10.location = (-169.31845092773438, -19.093738555908203)
	    group_input_004_8.location = (-340.0, 59.733726501464844)
	    reroute_006_8.location = (58.51203918457031, -44.47895431518555)
	    reroute_007_8.location = (51.51875686645508, 91.57743072509766)
	    reroute_008_8.location = (-135.7594451904297, -35.677268981933594)
	    reroute_009_8.location = (-140.79913330078125, 26.496713638305664)
	
	    #Set dimensions
	    group_input_16.width, group_input_16.height = 140.0, 100.0
	    group_output_19.width, group_output_19.height = 140.0, 100.0
	    curve_to_mesh_2.width, curve_to_mesh_2.height = 140.0, 100.0
	    capture_attribute_7.width, capture_attribute_7.height = 140.0, 100.0
	    spline_parameter_6.width, spline_parameter_6.height = 140.0, 100.0
	    combine_xyz_5.width, combine_xyz_5.height = 140.0, 100.0
	    store_named_attribute_5.width, store_named_attribute_5.height = 140.0, 100.0
	    set_material_2.width, set_material_2.height = 140.0, 100.0
	    curve_circle.width, curve_circle.height = 140.0, 100.0
	    capture_attribute_002_9.width, capture_attribute_002_9.height = 140.0, 100.0
	    reroute_15.width, reroute_15.height = 100.0, 100.0
	    group_input_001_11.width, group_input_001_11.height = 140.0, 100.0
	    group_input_002_10.width, group_input_002_10.height = 140.0, 100.0
	    set_curve_radius_2.width, set_curve_radius_2.height = 140.0, 100.0
	    group_input_003_11.width, group_input_003_11.height = 140.0, 100.0
	    resample_curve_2.width, resample_curve_2.height = 140.0, 100.0
	    switch_12.width, switch_12.height = 140.0, 100.0
	    compare_11.width, compare_11.height = 140.0, 100.0
	    reroute_003_10.width, reroute_003_10.height = 100.0, 100.0
	    group_input_004_8.width, group_input_004_8.height = 140.0, 100.0
	    reroute_006_8.width, reroute_006_8.height = 100.0, 100.0
	    reroute_007_8.width, reroute_007_8.height = 100.0, 100.0
	    reroute_008_8.width, reroute_008_8.height = 100.0, 100.0
	    reroute_009_8.width, reroute_009_8.height = 100.0, 100.0
	
	    #initialize tube_mesh links
	    #set_material_2.Geometry -> group_output_19.Geometry
	    tube_mesh.links.new(set_material_2.outputs[0], group_output_19.inputs[0])
	    #capture_attribute_7.Geometry -> curve_to_mesh_2.Curve
	    tube_mesh.links.new(capture_attribute_7.outputs[0], curve_to_mesh_2.inputs[0])
	    #set_curve_radius_2.Curve -> capture_attribute_7.Geometry
	    tube_mesh.links.new(set_curve_radius_2.outputs[0], capture_attribute_7.inputs[0])
	    #reroute_15.Output -> capture_attribute_7.Factor
	    tube_mesh.links.new(reroute_15.outputs[0], capture_attribute_7.inputs[1])
	    #capture_attribute_7.Factor -> combine_xyz_5.X
	    tube_mesh.links.new(capture_attribute_7.outputs[1], combine_xyz_5.inputs[0])
	    #curve_to_mesh_2.Mesh -> store_named_attribute_5.Geometry
	    tube_mesh.links.new(curve_to_mesh_2.outputs[0], store_named_attribute_5.inputs[0])
	    #combine_xyz_5.Vector -> store_named_attribute_5.Value
	    tube_mesh.links.new(combine_xyz_5.outputs[0], store_named_attribute_5.inputs[3])
	    #store_named_attribute_5.Geometry -> set_material_2.Geometry
	    tube_mesh.links.new(store_named_attribute_5.outputs[0], set_material_2.inputs[0])
	    #curve_circle.Curve -> capture_attribute_002_9.Geometry
	    tube_mesh.links.new(curve_circle.outputs[0], capture_attribute_002_9.inputs[0])
	    #reroute_15.Output -> capture_attribute_002_9.Factor
	    tube_mesh.links.new(reroute_15.outputs[0], capture_attribute_002_9.inputs[1])
	    #capture_attribute_002_9.Factor -> combine_xyz_5.Y
	    tube_mesh.links.new(capture_attribute_002_9.outputs[1], combine_xyz_5.inputs[1])
	    #capture_attribute_002_9.Geometry -> curve_to_mesh_2.Profile Curve
	    tube_mesh.links.new(capture_attribute_002_9.outputs[0], curve_to_mesh_2.inputs[1])
	    #group_input_16.Width -> curve_circle.Radius
	    tube_mesh.links.new(group_input_16.outputs[4], curve_circle.inputs[4])
	    #spline_parameter_6.Factor -> reroute_15.Input
	    tube_mesh.links.new(spline_parameter_6.outputs[0], reroute_15.inputs[0])
	    #group_input_001_11.Material -> set_material_2.Material
	    tube_mesh.links.new(group_input_001_11.outputs[1], set_material_2.inputs[2])
	    #group_input_002_10.Fill Caps -> curve_to_mesh_2.Fill Caps
	    tube_mesh.links.new(group_input_002_10.outputs[5], curve_to_mesh_2.inputs[2])
	    #reroute_006_8.Output -> set_curve_radius_2.Radius
	    tube_mesh.links.new(reroute_006_8.outputs[0], set_curve_radius_2.inputs[2])
	    #reroute_003_10.Output -> resample_curve_2.Curve
	    tube_mesh.links.new(reroute_003_10.outputs[0], resample_curve_2.inputs[0])
	    #compare_11.Result -> switch_12.Switch
	    tube_mesh.links.new(compare_11.outputs[0], switch_12.inputs[0])
	    #reroute_003_10.Output -> switch_12.True
	    tube_mesh.links.new(reroute_003_10.outputs[0], switch_12.inputs[2])
	    #resample_curve_2.Curve -> switch_12.False
	    tube_mesh.links.new(resample_curve_2.outputs[0], switch_12.inputs[1])
	    #reroute_008_8.Output -> resample_curve_2.Count
	    tube_mesh.links.new(reroute_008_8.outputs[0], resample_curve_2.inputs[2])
	    #group_input_16.Geometry -> reroute_003_10.Input
	    tube_mesh.links.new(group_input_16.outputs[0], reroute_003_10.inputs[0])
	    #reroute_007_8.Output -> reroute_006_8.Input
	    tube_mesh.links.new(reroute_007_8.outputs[0], reroute_006_8.inputs[0])
	    #group_input_003_11.Curve Radius -> reroute_007_8.Input
	    tube_mesh.links.new(group_input_003_11.outputs[2], reroute_007_8.inputs[0])
	    #reroute_009_8.Output -> reroute_008_8.Input
	    tube_mesh.links.new(reroute_009_8.outputs[0], reroute_008_8.inputs[0])
	    #group_input_004_8.Resolution -> reroute_009_8.Input
	    tube_mesh.links.new(group_input_004_8.outputs[3], reroute_009_8.inputs[0])
	    #reroute_009_8.Output -> compare_11.A
	    tube_mesh.links.new(reroute_009_8.outputs[0], compare_11.inputs[2])
	    #switch_12.Output -> set_curve_radius_2.Curve
	    tube_mesh.links.new(switch_12.outputs[0], set_curve_radius_2.inputs[0])
	    return tube_mesh
	
	tube_mesh = tube_mesh_node_group()
	
	#initialize tube_ribbon node group
	def tube_ribbon_node_group():
	    tube_ribbon = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Tube_Ribbon")
	
	    tube_ribbon.color_tag = 'NONE'
	    tube_ribbon.description = ""
	    tube_ribbon.default_group_node_width = 140
	    
	
	    tube_ribbon.is_modifier = True
	
	    #tube_ribbon interface
	    #Socket Geometry
	    geometry_socket_29 = tube_ribbon.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_29.attribute_domain = 'POINT'
	
	    #Socket Geometry
	    geometry_socket_30 = tube_ribbon.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_30.attribute_domain = 'POINT'
	
	    #Socket Material
	    material_socket_3 = tube_ribbon.interface.new_socket(name = "Material", in_out='INPUT', socket_type = 'NodeSocketMaterial')
	    material_socket_3.attribute_domain = 'POINT'
	
	    #Socket Curve Radius
	    curve_radius_socket_3 = tube_ribbon.interface.new_socket(name = "Curve Radius", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    curve_radius_socket_3.default_value = 1.0
	    curve_radius_socket_3.min_value = 0.0
	    curve_radius_socket_3.max_value = 3.4028234663852886e+38
	    curve_radius_socket_3.subtype = 'DISTANCE'
	    curve_radius_socket_3.attribute_domain = 'POINT'
	    curve_radius_socket_3.hide_value = True
	    curve_radius_socket_3.hide_in_modifier = True
	
	    #Socket Ribbon Count
	    ribbon_count_socket = tube_ribbon.interface.new_socket(name = "Ribbon Count", in_out='INPUT', socket_type = 'NodeSocketInt')
	    ribbon_count_socket.default_value = 8
	    ribbon_count_socket.min_value = 1
	    ribbon_count_socket.max_value = 180
	    ribbon_count_socket.subtype = 'NONE'
	    ribbon_count_socket.attribute_domain = 'POINT'
	
	    #Socket Resolution
	    resolution_socket_3 = tube_ribbon.interface.new_socket(name = "Resolution", in_out='INPUT', socket_type = 'NodeSocketInt')
	    resolution_socket_3.default_value = 0
	    resolution_socket_3.min_value = 2
	    resolution_socket_3.max_value = 512
	    resolution_socket_3.subtype = 'NONE'
	    resolution_socket_3.attribute_domain = 'POINT'
	
	    #Socket Width
	    width_socket_2 = tube_ribbon.interface.new_socket(name = "Width", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    width_socket_2.default_value = 0.10000000149011612
	    width_socket_2.min_value = 0.0
	    width_socket_2.max_value = 3.4028234663852886e+38
	    width_socket_2.subtype = 'DISTANCE'
	    width_socket_2.attribute_domain = 'POINT'
	
	
	    #initialize tube_ribbon nodes
	    #node Group Input
	    group_input_17 = tube_ribbon.nodes.new("NodeGroupInput")
	    group_input_17.name = "Group Input"
	    group_input_17.outputs[1].hide = True
	    group_input_17.outputs[2].hide = True
	    group_input_17.outputs[3].hide = True
	    group_input_17.outputs[6].hide = True
	
	    #node Group Output
	    group_output_20 = tube_ribbon.nodes.new("NodeGroupOutput")
	    group_output_20.name = "Group Output"
	    group_output_20.is_active_output = True
	
	    #node Curve to Mesh
	    curve_to_mesh_3 = tube_ribbon.nodes.new("GeometryNodeCurveToMesh")
	    curve_to_mesh_3.name = "Curve to Mesh"
	    curve_to_mesh_3.hide = True
	    #Fill Caps
	    curve_to_mesh_3.inputs[2].default_value = True
	
	    #node Capture Attribute
	    capture_attribute_8 = tube_ribbon.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_8.name = "Capture Attribute"
	    capture_attribute_8.hide = True
	    capture_attribute_8.active_index = 0
	    capture_attribute_8.capture_items.clear()
	    capture_attribute_8.capture_items.new('FLOAT', "Factor")
	    capture_attribute_8.capture_items["Factor"].data_type = 'FLOAT'
	    capture_attribute_8.domain = 'POINT'
	
	    #node Spline Parameter
	    spline_parameter_7 = tube_ribbon.nodes.new("GeometryNodeSplineParameter")
	    spline_parameter_7.name = "Spline Parameter"
	    spline_parameter_7.hide = True
	
	    #node Combine XYZ
	    combine_xyz_6 = tube_ribbon.nodes.new("ShaderNodeCombineXYZ")
	    combine_xyz_6.name = "Combine XYZ"
	    combine_xyz_6.hide = True
	    #Z
	    combine_xyz_6.inputs[2].default_value = 0.0
	
	    #node Store Named Attribute
	    store_named_attribute_6 = tube_ribbon.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_6.name = "Store Named Attribute"
	    store_named_attribute_6.data_type = 'FLOAT2'
	    store_named_attribute_6.domain = 'CORNER'
	    #Selection
	    store_named_attribute_6.inputs[1].default_value = True
	    #Name
	    store_named_attribute_6.inputs[2].default_value = "ribbon_mesh_UV"
	
	    #node Set Material
	    set_material_3 = tube_ribbon.nodes.new("GeometryNodeSetMaterial")
	    set_material_3.name = "Set Material"
	    set_material_3.hide = True
	    #Selection
	    set_material_3.inputs[1].default_value = True
	
	    #node Capture Attribute.002
	    capture_attribute_002_10 = tube_ribbon.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_002_10.name = "Capture Attribute.002"
	    capture_attribute_002_10.hide = True
	    capture_attribute_002_10.active_index = 0
	    capture_attribute_002_10.capture_items.clear()
	    capture_attribute_002_10.capture_items.new('FLOAT', "Factor")
	    capture_attribute_002_10.capture_items["Factor"].data_type = 'FLOAT'
	    capture_attribute_002_10.domain = 'POINT'
	
	    #node Reroute
	    reroute_16 = tube_ribbon.nodes.new("NodeReroute")
	    reroute_16.name = "Reroute"
	    reroute_16.socket_idname = "NodeSocketFloat"
	    #node Group Input.001
	    group_input_001_12 = tube_ribbon.nodes.new("NodeGroupInput")
	    group_input_001_12.name = "Group Input.001"
	    group_input_001_12.outputs[0].hide = True
	    group_input_001_12.outputs[2].hide = True
	    group_input_001_12.outputs[3].hide = True
	    group_input_001_12.outputs[4].hide = True
	    group_input_001_12.outputs[5].hide = True
	    group_input_001_12.outputs[6].hide = True
	
	    #node Curve Line
	    curve_line_1 = tube_ribbon.nodes.new("GeometryNodeCurvePrimitiveLine")
	    curve_line_1.name = "Curve Line"
	    curve_line_1.hide = True
	    curve_line_1.mode = 'POINTS'
	
	    #node Combine XYZ.001
	    combine_xyz_001 = tube_ribbon.nodes.new("ShaderNodeCombineXYZ")
	    combine_xyz_001.name = "Combine XYZ.001"
	    combine_xyz_001.hide = True
	    #Y
	    combine_xyz_001.inputs[1].default_value = 0.0
	    #Z
	    combine_xyz_001.inputs[2].default_value = 0.0
	
	    #node Math.001
	    math_001_5 = tube_ribbon.nodes.new("ShaderNodeMath")
	    math_001_5.name = "Math.001"
	    math_001_5.hide = True
	    math_001_5.operation = 'MULTIPLY'
	    math_001_5.use_clamp = False
	    #Value_001
	    math_001_5.inputs[1].default_value = -1.0
	
	    #node Combine XYZ.002
	    combine_xyz_002_1 = tube_ribbon.nodes.new("ShaderNodeCombineXYZ")
	    combine_xyz_002_1.name = "Combine XYZ.002"
	    combine_xyz_002_1.hide = True
	    #Y
	    combine_xyz_002_1.inputs[1].default_value = 0.0
	    #Z
	    combine_xyz_002_1.inputs[2].default_value = 0.0
	
	    #node Reroute.001
	    reroute_001_12 = tube_ribbon.nodes.new("NodeReroute")
	    reroute_001_12.name = "Reroute.001"
	    reroute_001_12.socket_idname = "NodeSocketFloatDistance"
	    #node Resample Curve
	    resample_curve_3 = tube_ribbon.nodes.new("GeometryNodeResampleCurve")
	    resample_curve_3.name = "Resample Curve"
	    resample_curve_3.hide = True
	    resample_curve_3.keep_last_segment = False
	    resample_curve_3.mode = 'COUNT'
	    #Selection
	    resample_curve_3.inputs[1].default_value = True
	
	    #node Switch
	    switch_13 = tube_ribbon.nodes.new("GeometryNodeSwitch")
	    switch_13.name = "Switch"
	    switch_13.hide = True
	    switch_13.input_type = 'GEOMETRY'
	
	    #node Group Input.002
	    group_input_002_11 = tube_ribbon.nodes.new("NodeGroupInput")
	    group_input_002_11.name = "Group Input.002"
	    group_input_002_11.outputs[0].hide = True
	    group_input_002_11.outputs[1].hide = True
	    group_input_002_11.outputs[2].hide = True
	    group_input_002_11.outputs[3].hide = True
	    group_input_002_11.outputs[5].hide = True
	    group_input_002_11.outputs[6].hide = True
	
	    #node Compare
	    compare_12 = tube_ribbon.nodes.new("FunctionNodeCompare")
	    compare_12.name = "Compare"
	    compare_12.hide = True
	    compare_12.data_type = 'INT'
	    compare_12.mode = 'ELEMENT'
	    compare_12.operation = 'LESS_THAN'
	    #B_INT
	    compare_12.inputs[3].default_value = 2
	
	    #node Reroute.002
	    reroute_002_11 = tube_ribbon.nodes.new("NodeReroute")
	    reroute_002_11.name = "Reroute.002"
	    reroute_002_11.socket_idname = "NodeSocketGeometry"
	    #node Frame
	    frame_10 = tube_ribbon.nodes.new("NodeFrame")
	    frame_10.name = "Frame"
	    frame_10.label_size = 20
	    frame_10.shrink = True
	
	    #node Join Geometry
	    join_geometry_6 = tube_ribbon.nodes.new("GeometryNodeJoinGeometry")
	    join_geometry_6.name = "Join Geometry"
	
	    #node Set Curve Tilt
	    set_curve_tilt_1 = tube_ribbon.nodes.new("GeometryNodeSetCurveTilt")
	    set_curve_tilt_1.name = "Set Curve Tilt"
	    #Selection
	    set_curve_tilt_1.inputs[1].default_value = True
	
	    #node Repeat Input
	    repeat_input = tube_ribbon.nodes.new("GeometryNodeRepeatInput")
	    repeat_input.name = "Repeat Input"
	    #node Repeat Output
	    repeat_output = tube_ribbon.nodes.new("GeometryNodeRepeatOutput")
	    repeat_output.name = "Repeat Output"
	    repeat_output.active_index = 1
	    repeat_output.inspection_index = 0
	    repeat_output.repeat_items.clear()
	    # Create item "Geometry"
	    repeat_output.repeat_items.new('GEOMETRY', "Geometry")
	    # Create item "Index"
	    repeat_output.repeat_items.new('INT', "Index")
	
	    #node Math.002
	    math_002_3 = tube_ribbon.nodes.new("ShaderNodeMath")
	    math_002_3.name = "Math.002"
	    math_002_3.hide = True
	    math_002_3.operation = 'DIVIDE'
	    math_002_3.use_clamp = False
	    #Value
	    math_002_3.inputs[0].default_value = 180.0
	
	    #node Group Input.003
	    group_input_003_12 = tube_ribbon.nodes.new("NodeGroupInput")
	    group_input_003_12.name = "Group Input.003"
	    group_input_003_12.outputs[0].hide = True
	    group_input_003_12.outputs[1].hide = True
	    group_input_003_12.outputs[2].hide = True
	    group_input_003_12.outputs[4].hide = True
	    group_input_003_12.outputs[5].hide = True
	    group_input_003_12.outputs[6].hide = True
	
	    #node Group Input.004
	    group_input_004_9 = tube_ribbon.nodes.new("NodeGroupInput")
	    group_input_004_9.name = "Group Input.004"
	    group_input_004_9.outputs[0].hide = True
	    group_input_004_9.outputs[1].hide = True
	    group_input_004_9.outputs[2].hide = True
	    group_input_004_9.outputs[4].hide = True
	    group_input_004_9.outputs[5].hide = True
	    group_input_004_9.outputs[6].hide = True
	
	    #node Math.003
	    math_003_4 = tube_ribbon.nodes.new("ShaderNodeMath")
	    math_003_4.name = "Math.003"
	    math_003_4.hide = True
	    math_003_4.operation = 'ADD'
	    math_003_4.use_clamp = False
	    #Value_001
	    math_003_4.inputs[1].default_value = 1.0
	
	    #node Math.004
	    math_004_2 = tube_ribbon.nodes.new("ShaderNodeMath")
	    math_004_2.name = "Math.004"
	    math_004_2.hide = True
	    math_004_2.operation = 'MULTIPLY'
	    math_004_2.use_clamp = False
	
	    #node Reroute.003
	    reroute_003_11 = tube_ribbon.nodes.new("NodeReroute")
	    reroute_003_11.name = "Reroute.003"
	    reroute_003_11.socket_idname = "NodeSocketInt"
	    #node Curve Tilt
	    curve_tilt = tube_ribbon.nodes.new("GeometryNodeInputCurveTilt")
	    curve_tilt.name = "Curve Tilt"
	    curve_tilt.hide = True
	
	    #node Math.005
	    math_005_2 = tube_ribbon.nodes.new("ShaderNodeMath")
	    math_005_2.name = "Math.005"
	    math_005_2.hide = True
	    math_005_2.operation = 'ADD'
	    math_005_2.use_clamp = False
	
	    #node Set Curve Radius
	    set_curve_radius_3 = tube_ribbon.nodes.new("GeometryNodeSetCurveRadius")
	    set_curve_radius_3.name = "Set Curve Radius"
	    set_curve_radius_3.hide = True
	    #Selection
	    set_curve_radius_3.inputs[1].default_value = True
	
	    #node Group Input.005
	    group_input_005_8 = tube_ribbon.nodes.new("NodeGroupInput")
	    group_input_005_8.name = "Group Input.005"
	    group_input_005_8.outputs[0].hide = True
	    group_input_005_8.outputs[1].hide = True
	    group_input_005_8.outputs[3].hide = True
	    group_input_005_8.outputs[4].hide = True
	    group_input_005_8.outputs[5].hide = True
	    group_input_005_8.outputs[6].hide = True
	
	    #node Reroute.004
	    reroute_004_11 = tube_ribbon.nodes.new("NodeReroute")
	    reroute_004_11.name = "Reroute.004"
	    reroute_004_11.socket_idname = "NodeSocketFloatDistance"
	    #node Reroute.005
	    reroute_005_9 = tube_ribbon.nodes.new("NodeReroute")
	    reroute_005_9.name = "Reroute.005"
	    reroute_005_9.socket_idname = "NodeSocketFloatDistance"
	
	    #Process zone input Repeat Input
	    repeat_input.pair_with_output(repeat_output)
	    #Item_2
	    repeat_input.inputs[2].default_value = 0
	
	
	
	
	    #Set parents
	    group_input_17.parent = frame_10
	    curve_to_mesh_3.parent = frame_10
	    capture_attribute_8.parent = frame_10
	    spline_parameter_7.parent = frame_10
	    combine_xyz_6.parent = frame_10
	    store_named_attribute_6.parent = frame_10
	    set_material_3.parent = frame_10
	    capture_attribute_002_10.parent = frame_10
	    reroute_16.parent = frame_10
	    group_input_001_12.parent = frame_10
	    curve_line_1.parent = frame_10
	    combine_xyz_001.parent = frame_10
	    math_001_5.parent = frame_10
	    combine_xyz_002_1.parent = frame_10
	    reroute_001_12.parent = frame_10
	    resample_curve_3.parent = frame_10
	    switch_13.parent = frame_10
	    group_input_002_11.parent = frame_10
	    compare_12.parent = frame_10
	    reroute_002_11.parent = frame_10
	    set_curve_tilt_1.parent = frame_10
	    math_004_2.parent = frame_10
	    math_005_2.parent = frame_10
	    set_curve_radius_3.parent = frame_10
	    group_input_005_8.parent = frame_10
	    reroute_004_11.parent = frame_10
	    reroute_005_9.parent = frame_10
	
	    #Set locations
	    group_input_17.location = (46.5567626953125, -187.68907165527344)
	    group_output_20.location = (1687.6083984375, 27.941242218017578)
	    curve_to_mesh_3.location = (937.7008666992188, -218.34669494628906)
	    capture_attribute_8.location = (764.834716796875, -223.1929168701172)
	    spline_parameter_7.location = (408.7358093261719, -288.16595458984375)
	    combine_xyz_6.location = (937.5093383789062, -281.03155517578125)
	    store_named_attribute_6.location = (1093.46923828125, -121.07095336914062)
	    set_material_3.location = (1254.6962890625, -155.2870635986328)
	    capture_attribute_002_10.location = (766.9982299804688, -262.14312744140625)
	    reroute_16.location = (566.0176391601562, -285.51812744140625)
	    group_input_001_12.location = (1251.76220703125, -186.1525421142578)
	    curve_line_1.location = (409.7470397949219, -252.2234649658203)
	    combine_xyz_001.location = (242.35899353027344, -260.64910888671875)
	    math_001_5.location = (247.1505889892578, -332.52447509765625)
	    combine_xyz_002_1.location = (245.62991333007812, -296.69708251953125)
	    reroute_001_12.location = (199.33338928222656, -265.65771484375)
	    resample_curve_3.location = (380.4243469238281, -216.19468688964844)
	    switch_13.location = (380.3485412597656, -181.20213317871094)
	    group_input_002_11.location = (375.72821044921875, -86.50663757324219)
	    compare_12.location = (377.1279602050781, -146.6437530517578)
	    reroute_002_11.location = (333.6315612792969, -213.35231018066406)
	    frame_10.location = (-58.76470947265625, -48.17646789550781)
	    join_geometry_6.location = (1331.0086669921875, 47.14059066772461)
	    set_curve_tilt_1.location = (192.23997497558594, -54.01100158691406)
	    repeat_input.location = (-184.79876708984375, 46.944000244140625)
	    repeat_output.location = (1511.4083251953125, 27.655336380004883)
	    math_002_3.location = (-195.4779510498047, -161.6897735595703)
	    group_input_003_12.location = (-346.3707580566406, 47.1754035949707)
	    group_input_004_9.location = (-353.25665283203125, -145.0489044189453)
	    math_003_4.location = (1134.1580810546875, -24.601409912109375)
	    math_004_2.location = (30.277496337890625, -106.62132263183594)
	    reroute_003_11.location = (-25.963211059570312, -31.35608673095703)
	    curve_tilt.location = (-197.5312957763672, -198.6190185546875)
	    math_005_2.location = (31.753875732421875, -145.03323364257812)
	    set_curve_radius_3.location = (591.83837890625, -194.33396911621094)
	    group_input_005_8.location = (377.0597229003906, -29.650436401367188)
	    reroute_004_11.location = (563.5545654296875, -215.4977264404297)
	    reroute_005_9.location = (561.7288208007812, -64.61457824707031)
	
	    #Set dimensions
	    group_input_17.width, group_input_17.height = 140.0, 100.0
	    group_output_20.width, group_output_20.height = 140.0, 100.0
	    curve_to_mesh_3.width, curve_to_mesh_3.height = 140.0, 100.0
	    capture_attribute_8.width, capture_attribute_8.height = 140.0, 100.0
	    spline_parameter_7.width, spline_parameter_7.height = 140.0, 100.0
	    combine_xyz_6.width, combine_xyz_6.height = 140.0, 100.0
	    store_named_attribute_6.width, store_named_attribute_6.height = 140.0, 100.0
	    set_material_3.width, set_material_3.height = 140.0, 100.0
	    capture_attribute_002_10.width, capture_attribute_002_10.height = 140.0, 100.0
	    reroute_16.width, reroute_16.height = 100.0, 100.0
	    group_input_001_12.width, group_input_001_12.height = 140.0, 100.0
	    curve_line_1.width, curve_line_1.height = 140.0, 100.0
	    combine_xyz_001.width, combine_xyz_001.height = 140.0, 100.0
	    math_001_5.width, math_001_5.height = 140.0, 100.0
	    combine_xyz_002_1.width, combine_xyz_002_1.height = 140.0, 100.0
	    reroute_001_12.width, reroute_001_12.height = 100.0, 100.0
	    resample_curve_3.width, resample_curve_3.height = 140.0, 100.0
	    switch_13.width, switch_13.height = 140.0, 100.0
	    group_input_002_11.width, group_input_002_11.height = 140.0, 100.0
	    compare_12.width, compare_12.height = 140.0, 100.0
	    reroute_002_11.width, reroute_002_11.height = 100.0, 100.0
	    frame_10.width, frame_10.height = 1424.3529052734375, 388.32354736328125
	    join_geometry_6.width, join_geometry_6.height = 140.0, 100.0
	    set_curve_tilt_1.width, set_curve_tilt_1.height = 140.0, 100.0
	    repeat_input.width, repeat_input.height = 140.0, 100.0
	    repeat_output.width, repeat_output.height = 140.0, 100.0
	    math_002_3.width, math_002_3.height = 140.0, 100.0
	    group_input_003_12.width, group_input_003_12.height = 140.0, 100.0
	    group_input_004_9.width, group_input_004_9.height = 140.0, 100.0
	    math_003_4.width, math_003_4.height = 140.0, 100.0
	    math_004_2.width, math_004_2.height = 140.0, 100.0
	    reroute_003_11.width, reroute_003_11.height = 100.0, 100.0
	    curve_tilt.width, curve_tilt.height = 140.0, 100.0
	    math_005_2.width, math_005_2.height = 140.0, 100.0
	    set_curve_radius_3.width, set_curve_radius_3.height = 140.0, 100.0
	    group_input_005_8.width, group_input_005_8.height = 140.0, 100.0
	    reroute_004_11.width, reroute_004_11.height = 100.0, 100.0
	    reroute_005_9.width, reroute_005_9.height = 100.0, 100.0
	
	    #initialize tube_ribbon links
	    #capture_attribute_8.Geometry -> curve_to_mesh_3.Curve
	    tube_ribbon.links.new(capture_attribute_8.outputs[0], curve_to_mesh_3.inputs[0])
	    #reroute_16.Output -> capture_attribute_8.Factor
	    tube_ribbon.links.new(reroute_16.outputs[0], capture_attribute_8.inputs[1])
	    #capture_attribute_8.Factor -> combine_xyz_6.X
	    tube_ribbon.links.new(capture_attribute_8.outputs[1], combine_xyz_6.inputs[0])
	    #curve_to_mesh_3.Mesh -> store_named_attribute_6.Geometry
	    tube_ribbon.links.new(curve_to_mesh_3.outputs[0], store_named_attribute_6.inputs[0])
	    #combine_xyz_6.Vector -> store_named_attribute_6.Value
	    tube_ribbon.links.new(combine_xyz_6.outputs[0], store_named_attribute_6.inputs[3])
	    #store_named_attribute_6.Geometry -> set_material_3.Geometry
	    tube_ribbon.links.new(store_named_attribute_6.outputs[0], set_material_3.inputs[0])
	    #reroute_16.Output -> capture_attribute_002_10.Factor
	    tube_ribbon.links.new(reroute_16.outputs[0], capture_attribute_002_10.inputs[1])
	    #capture_attribute_002_10.Factor -> combine_xyz_6.Y
	    tube_ribbon.links.new(capture_attribute_002_10.outputs[1], combine_xyz_6.inputs[1])
	    #capture_attribute_002_10.Geometry -> curve_to_mesh_3.Profile Curve
	    tube_ribbon.links.new(capture_attribute_002_10.outputs[0], curve_to_mesh_3.inputs[1])
	    #spline_parameter_7.Factor -> reroute_16.Input
	    tube_ribbon.links.new(spline_parameter_7.outputs[0], reroute_16.inputs[0])
	    #group_input_001_12.Material -> set_material_3.Material
	    tube_ribbon.links.new(group_input_001_12.outputs[1], set_material_3.inputs[2])
	    #combine_xyz_001.Vector -> curve_line_1.Start
	    tube_ribbon.links.new(combine_xyz_001.outputs[0], curve_line_1.inputs[0])
	    #math_001_5.Value -> combine_xyz_002_1.X
	    tube_ribbon.links.new(math_001_5.outputs[0], combine_xyz_002_1.inputs[0])
	    #combine_xyz_002_1.Vector -> curve_line_1.End
	    tube_ribbon.links.new(combine_xyz_002_1.outputs[0], curve_line_1.inputs[1])
	    #reroute_001_12.Output -> math_001_5.Value
	    tube_ribbon.links.new(reroute_001_12.outputs[0], math_001_5.inputs[0])
	    #curve_line_1.Curve -> capture_attribute_002_10.Geometry
	    tube_ribbon.links.new(curve_line_1.outputs[0], capture_attribute_002_10.inputs[0])
	    #group_input_17.Width -> reroute_001_12.Input
	    tube_ribbon.links.new(group_input_17.outputs[5], reroute_001_12.inputs[0])
	    #reroute_002_11.Output -> resample_curve_3.Curve
	    tube_ribbon.links.new(reroute_002_11.outputs[0], resample_curve_3.inputs[0])
	    #group_input_17.Resolution -> resample_curve_3.Count
	    tube_ribbon.links.new(group_input_17.outputs[4], resample_curve_3.inputs[2])
	    #group_input_002_11.Resolution -> compare_12.A
	    tube_ribbon.links.new(group_input_002_11.outputs[4], compare_12.inputs[2])
	    #compare_12.Result -> switch_13.Switch
	    tube_ribbon.links.new(compare_12.outputs[0], switch_13.inputs[0])
	    #set_curve_radius_3.Curve -> capture_attribute_8.Geometry
	    tube_ribbon.links.new(set_curve_radius_3.outputs[0], capture_attribute_8.inputs[0])
	    #reroute_002_11.Output -> switch_13.True
	    tube_ribbon.links.new(reroute_002_11.outputs[0], switch_13.inputs[2])
	    #resample_curve_3.Curve -> switch_13.False
	    tube_ribbon.links.new(resample_curve_3.outputs[0], switch_13.inputs[1])
	    #group_input_17.Geometry -> set_curve_tilt_1.Curve
	    tube_ribbon.links.new(group_input_17.outputs[0], set_curve_tilt_1.inputs[0])
	    #set_curve_tilt_1.Curve -> reroute_002_11.Input
	    tube_ribbon.links.new(set_curve_tilt_1.outputs[0], reroute_002_11.inputs[0])
	    #join_geometry_6.Geometry -> repeat_output.Geometry
	    tube_ribbon.links.new(join_geometry_6.outputs[0], repeat_output.inputs[0])
	    #group_input_003_12.Ribbon Count -> repeat_input.Iterations
	    tube_ribbon.links.new(group_input_003_12.outputs[3], repeat_input.inputs[0])
	    #math_003_4.Value -> repeat_output.Index
	    tube_ribbon.links.new(math_003_4.outputs[0], repeat_output.inputs[1])
	    #repeat_output.Geometry -> group_output_20.Geometry
	    tube_ribbon.links.new(repeat_output.outputs[0], group_output_20.inputs[0])
	    #reroute_003_11.Output -> math_003_4.Value
	    tube_ribbon.links.new(reroute_003_11.outputs[0], math_003_4.inputs[0])
	    #group_input_004_9.Ribbon Count -> math_002_3.Value
	    tube_ribbon.links.new(group_input_004_9.outputs[3], math_002_3.inputs[1])
	    #math_002_3.Value -> math_004_2.Value
	    tube_ribbon.links.new(math_002_3.outputs[0], math_004_2.inputs[1])
	    #reroute_003_11.Output -> math_004_2.Value
	    tube_ribbon.links.new(reroute_003_11.outputs[0], math_004_2.inputs[0])
	    #repeat_input.Index -> reroute_003_11.Input
	    tube_ribbon.links.new(repeat_input.outputs[2], reroute_003_11.inputs[0])
	    #set_material_3.Geometry -> join_geometry_6.Geometry
	    tube_ribbon.links.new(set_material_3.outputs[0], join_geometry_6.inputs[0])
	    #curve_tilt.Tilt -> math_005_2.Value
	    tube_ribbon.links.new(curve_tilt.outputs[0], math_005_2.inputs[1])
	    #math_004_2.Value -> math_005_2.Value
	    tube_ribbon.links.new(math_004_2.outputs[0], math_005_2.inputs[0])
	    #math_005_2.Value -> set_curve_tilt_1.Tilt
	    tube_ribbon.links.new(math_005_2.outputs[0], set_curve_tilt_1.inputs[2])
	    #switch_13.Output -> set_curve_radius_3.Curve
	    tube_ribbon.links.new(switch_13.outputs[0], set_curve_radius_3.inputs[0])
	    #reroute_004_11.Output -> set_curve_radius_3.Radius
	    tube_ribbon.links.new(reroute_004_11.outputs[0], set_curve_radius_3.inputs[2])
	    #reroute_005_9.Output -> reroute_004_11.Input
	    tube_ribbon.links.new(reroute_005_9.outputs[0], reroute_004_11.inputs[0])
	    #group_input_005_8.Curve Radius -> reroute_005_9.Input
	    tube_ribbon.links.new(group_input_005_8.outputs[2], reroute_005_9.inputs[0])
	    #reroute_001_12.Output -> combine_xyz_001.X
	    tube_ribbon.links.new(reroute_001_12.outputs[0], combine_xyz_001.inputs[0])
	    #repeat_input.Geometry -> join_geometry_6.Geometry
	    tube_ribbon.links.new(repeat_input.outputs[1], join_geometry_6.inputs[0])
	    return tube_ribbon
	
	tube_ribbon = tube_ribbon_node_group()
	
	#initialize mesh_hair_selector node group
	def mesh_hair_selector_node_group():
	    mesh_hair_selector = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "MESH_HAIR_SELECTOR")
	
	    mesh_hair_selector.color_tag = 'NONE'
	    mesh_hair_selector.description = "Convert hair to mesh object."
	    mesh_hair_selector.default_group_node_width = 140
	    
	
	    mesh_hair_selector.is_modifier = True
	
	    #mesh_hair_selector interface
	    #Socket Geometry
	    geometry_socket_31 = mesh_hair_selector.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_31.attribute_domain = 'POINT'
	    geometry_socket_31.description = "Mesh object."
	
	    #Socket Geometry
	    geometry_socket_32 = mesh_hair_selector.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_32.attribute_domain = 'POINT'
	    geometry_socket_32.description = "Curve object"
	
	    #Socket Style Select
	    style_select_socket = mesh_hair_selector.interface.new_socket(name = "Style Select", in_out='INPUT', socket_type = 'NodeSocketMenu')
	    style_select_socket.attribute_domain = 'POINT'
	    style_select_socket.description = "Mesh style to convert curve."
	
	    #Socket Material
	    material_socket_4 = mesh_hair_selector.interface.new_socket(name = "Material", in_out='INPUT', socket_type = 'NodeSocketMaterial')
	    material_socket_4.attribute_domain = 'POINT'
	    material_socket_4.description = "Material used for mesh."
	
	    #Socket Resolution
	    resolution_socket_4 = mesh_hair_selector.interface.new_socket(name = "Resolution", in_out='INPUT', socket_type = 'NodeSocketInt')
	    resolution_socket_4.default_value = 0
	    resolution_socket_4.min_value = 2
	    resolution_socket_4.max_value = 512
	    resolution_socket_4.subtype = 'NONE'
	    resolution_socket_4.attribute_domain = 'POINT'
	    resolution_socket_4.description = "Control mesh smoothness by add and removing points along curve."
	
	    #Socket Width
	    width_socket_3 = mesh_hair_selector.interface.new_socket(name = "Width", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    width_socket_3.default_value = 0.10000000149011612
	    width_socket_3.min_value = 0.0
	    width_socket_3.max_value = 3.4028234663852886e+38
	    width_socket_3.subtype = 'DISTANCE'
	    width_socket_3.attribute_domain = 'POINT'
	    width_socket_3.description = "Width of mesh object."
	
	    #Socket Fill Caps
	    fill_caps_socket_2 = mesh_hair_selector.interface.new_socket(name = "Fill Caps", in_out='INPUT', socket_type = 'NodeSocketBool')
	    fill_caps_socket_2.default_value = False
	    fill_caps_socket_2.attribute_domain = 'POINT'
	    fill_caps_socket_2.description = "Fill openings with mesh surface. (Used only for [Tube Mesh | Stylized] mesh styles)"
	
	    #Socket Shade Smooth
	    shade_smooth_socket = mesh_hair_selector.interface.new_socket(name = "Shade Smooth", in_out='INPUT', socket_type = 'NodeSocketBool')
	    shade_smooth_socket.default_value = False
	    shade_smooth_socket.attribute_domain = 'POINT'
	    shade_smooth_socket.description = "Use Smooth Shade for mesh."
	
	    #Socket Hair Card Angle
	    hair_card_angle_socket = mesh_hair_selector.interface.new_socket(name = "Hair Card Angle", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    hair_card_angle_socket.default_value = 0.0
	    hair_card_angle_socket.min_value = -90.0
	    hair_card_angle_socket.max_value = 90.0
	    hair_card_angle_socket.subtype = 'ANGLE'
	    hair_card_angle_socket.attribute_domain = 'POINT'
	    hair_card_angle_socket.description = "Angle used to bend hair card. (Mesh Style=Hair Card)"
	
	    #Socket Tube Ribbon Count
	    tube_ribbon_count_socket = mesh_hair_selector.interface.new_socket(name = "Tube Ribbon Count", in_out='INPUT', socket_type = 'NodeSocketInt')
	    tube_ribbon_count_socket.default_value = 8
	    tube_ribbon_count_socket.min_value = 1
	    tube_ribbon_count_socket.max_value = 180
	    tube_ribbon_count_socket.subtype = 'NONE'
	    tube_ribbon_count_socket.attribute_domain = 'POINT'
	    tube_ribbon_count_socket.description = "Amount of billboard like hair cards used to shape hair. (Mesh Style=Tube Ribbon)"
	
	    #Socket Profile Curve
	    profile_curve_socket = mesh_hair_selector.interface.new_socket(name = "Profile Curve", in_out='INPUT', socket_type = 'NodeSocketObject')
	    profile_curve_socket.attribute_domain = 'POINT'
	    profile_curve_socket.description = "Curve object used as the profile for stylized hair. (Mesh Style=Stylized)"
	
	    #Socket Profile Translation
	    profile_translation_socket = mesh_hair_selector.interface.new_socket(name = "Profile Translation", in_out='INPUT', socket_type = 'NodeSocketVector')
	    profile_translation_socket.default_value = (0.0, 0.0, 0.0)
	    profile_translation_socket.min_value = -3.4028234663852886e+38
	    profile_translation_socket.max_value = 3.4028234663852886e+38
	    profile_translation_socket.subtype = 'TRANSLATION'
	    profile_translation_socket.attribute_domain = 'POINT'
	    profile_translation_socket.description = "Move position of stylized profile from origin. (Mesh Style=Stylized)"
	
	    #Socket Profile Rotation
	    profile_rotation_socket = mesh_hair_selector.interface.new_socket(name = "Profile Rotation", in_out='INPUT', socket_type = 'NodeSocketRotation')
	    profile_rotation_socket.default_value = (0.0, 0.0, 0.0)
	    profile_rotation_socket.attribute_domain = 'POINT'
	    profile_rotation_socket.description = "Rotate the stylized profile from origin. (Mesh Style=Stylized)"
	
	    #Socket Profile Scale
	    profile_scale_socket = mesh_hair_selector.interface.new_socket(name = "Profile Scale", in_out='INPUT', socket_type = 'NodeSocketVector')
	    profile_scale_socket.default_value = (1.0, 1.0, 1.0)
	    profile_scale_socket.min_value = -3.4028234663852886e+38
	    profile_scale_socket.max_value = 3.4028234663852886e+38
	    profile_scale_socket.subtype = 'XYZ'
	    profile_scale_socket.attribute_domain = 'POINT'
	    profile_scale_socket.description = "Scale the stylized profile from origin. (Mesh Style=Stylized)"
	
	    #Socket Mesh Index
	    mesh_index_socket = mesh_hair_selector.interface.new_socket(name = "Mesh Index", in_out='INPUT', socket_type = 'NodeSocketInt')
	    mesh_index_socket.default_value = 0
	    mesh_index_socket.min_value = 0
	    mesh_index_socket.max_value = 2147483647
	    mesh_index_socket.subtype = 'NONE'
	    mesh_index_socket.attribute_domain = 'POINT'
	    mesh_index_socket.description = "Index used to offset uv coords."
	
	
	    #initialize mesh_hair_selector nodes
	    #node Group Output
	    group_output_21 = mesh_hair_selector.nodes.new("NodeGroupOutput")
	    group_output_21.name = "Group Output"
	    group_output_21.is_active_output = True
	    group_output_21.inputs[1].hide = True
	
	    #node Group
	    group_9 = mesh_hair_selector.nodes.new("GeometryNodeGroup")
	    group_9.name = "Group"
	    group_9.node_tree = hair_card
	
	    #node Group.001
	    group_001_8 = mesh_hair_selector.nodes.new("GeometryNodeGroup")
	    group_001_8.name = "Group.001"
	    group_001_8.node_tree = stylized_hair
	
	    #node Group.002
	    group_002_5 = mesh_hair_selector.nodes.new("GeometryNodeGroup")
	    group_002_5.name = "Group.002"
	    group_002_5.node_tree = tube_mesh
	
	    #node Group.003
	    group_003_3 = mesh_hair_selector.nodes.new("GeometryNodeGroup")
	    group_003_3.name = "Group.003"
	    group_003_3.node_tree = tube_ribbon
	
	    #node Group Input.001
	    group_input_001_13 = mesh_hair_selector.nodes.new("NodeGroupInput")
	    group_input_001_13.name = "Group Input.001"
	    group_input_001_13.outputs[1].hide = True
	    group_input_001_13.outputs[5].hide = True
	    group_input_001_13.outputs[6].hide = True
	    group_input_001_13.outputs[8].hide = True
	    group_input_001_13.outputs[9].hide = True
	    group_input_001_13.outputs[10].hide = True
	    group_input_001_13.outputs[11].hide = True
	    group_input_001_13.outputs[12].hide = True
	    group_input_001_13.outputs[13].hide = True
	    group_input_001_13.outputs[14].hide = True
	
	    #node Group Input.002
	    group_input_002_12 = mesh_hair_selector.nodes.new("NodeGroupInput")
	    group_input_002_12.name = "Group Input.002"
	    group_input_002_12.outputs[1].hide = True
	    group_input_002_12.outputs[6].hide = True
	    group_input_002_12.outputs[7].hide = True
	    group_input_002_12.outputs[8].hide = True
	    group_input_002_12.outputs[9].hide = True
	    group_input_002_12.outputs[10].hide = True
	    group_input_002_12.outputs[11].hide = True
	    group_input_002_12.outputs[12].hide = True
	    group_input_002_12.outputs[13].hide = True
	    group_input_002_12.outputs[14].hide = True
	
	    #node Group Input.003
	    group_input_003_13 = mesh_hair_selector.nodes.new("NodeGroupInput")
	    group_input_003_13.name = "Group Input.003"
	    group_input_003_13.outputs[1].hide = True
	    group_input_003_13.outputs[5].hide = True
	    group_input_003_13.outputs[6].hide = True
	    group_input_003_13.outputs[7].hide = True
	    group_input_003_13.outputs[9].hide = True
	    group_input_003_13.outputs[10].hide = True
	    group_input_003_13.outputs[11].hide = True
	    group_input_003_13.outputs[12].hide = True
	    group_input_003_13.outputs[13].hide = True
	    group_input_003_13.outputs[14].hide = True
	
	    #node Group Input.004
	    group_input_004_10 = mesh_hair_selector.nodes.new("NodeGroupInput")
	    group_input_004_10.name = "Group Input.004"
	    group_input_004_10.outputs[1].hide = True
	    group_input_004_10.outputs[4].hide = True
	    group_input_004_10.outputs[6].hide = True
	    group_input_004_10.outputs[7].hide = True
	    group_input_004_10.outputs[8].hide = True
	    group_input_004_10.outputs[9].hide = True
	    group_input_004_10.outputs[13].hide = True
	    group_input_004_10.outputs[14].hide = True
	
	    #node Menu Switch.001
	    menu_switch_001 = mesh_hair_selector.nodes.new("GeometryNodeMenuSwitch")
	    menu_switch_001.name = "Menu Switch.001"
	    menu_switch_001.active_index = 3
	    menu_switch_001.data_type = 'STRING'
	    menu_switch_001.enum_items.clear()
	    menu_switch_001.enum_items.new("Hair Card")
	    menu_switch_001.enum_items[0].description = ""
	    menu_switch_001.enum_items.new("Tube Mesh")
	    menu_switch_001.enum_items[1].description = ""
	    menu_switch_001.enum_items.new("Tube Ribbon")
	    menu_switch_001.enum_items[2].description = ""
	    menu_switch_001.enum_items.new("Stylized")
	    menu_switch_001.enum_items[3].description = ""
	    menu_switch_001.inputs[5].hide = True
	
	    #node Store Named Attribute
	    store_named_attribute_7 = mesh_hair_selector.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_7.name = "Store Named Attribute"
	    store_named_attribute_7.data_type = 'FLOAT2'
	    store_named_attribute_7.domain = 'CORNER'
	    #Selection
	    store_named_attribute_7.inputs[1].default_value = True
	    #Name
	    store_named_attribute_7.inputs[2].default_value = "UVMap"
	
	    #node Named Attribute
	    named_attribute_4 = mesh_hair_selector.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute_4.name = "Named Attribute"
	    named_attribute_4.data_type = 'FLOAT_VECTOR'
	
	    #node Group Input.005
	    group_input_005_9 = mesh_hair_selector.nodes.new("NodeGroupInput")
	    group_input_005_9.name = "Group Input.005"
	    group_input_005_9.outputs[0].hide = True
	    group_input_005_9.outputs[2].hide = True
	    group_input_005_9.outputs[3].hide = True
	    group_input_005_9.outputs[4].hide = True
	    group_input_005_9.outputs[5].hide = True
	    group_input_005_9.outputs[6].hide = True
	    group_input_005_9.outputs[7].hide = True
	    group_input_005_9.outputs[8].hide = True
	    group_input_005_9.outputs[9].hide = True
	    group_input_005_9.outputs[10].hide = True
	    group_input_005_9.outputs[11].hide = True
	    group_input_005_9.outputs[12].hide = True
	    group_input_005_9.outputs[13].hide = True
	    group_input_005_9.outputs[14].hide = True
	
	    #node Group Input.006
	    group_input_006_7 = mesh_hair_selector.nodes.new("NodeGroupInput")
	    group_input_006_7.name = "Group Input.006"
	    group_input_006_7.outputs[0].hide = True
	    group_input_006_7.outputs[1].hide = True
	    group_input_006_7.outputs[2].hide = True
	    group_input_006_7.outputs[3].hide = True
	    group_input_006_7.outputs[4].hide = True
	    group_input_006_7.outputs[5].hide = True
	    group_input_006_7.outputs[6].hide = True
	    group_input_006_7.outputs[7].hide = True
	    group_input_006_7.outputs[8].hide = True
	    group_input_006_7.outputs[10].hide = True
	    group_input_006_7.outputs[11].hide = True
	    group_input_006_7.outputs[12].hide = True
	    group_input_006_7.outputs[13].hide = True
	    group_input_006_7.outputs[14].hide = True
	
	    #node Compare
	    compare_13 = mesh_hair_selector.nodes.new("FunctionNodeCompare")
	    compare_13.name = "Compare"
	    compare_13.hide = True
	    compare_13.data_type = 'STRING'
	    compare_13.mode = 'ELEMENT'
	    compare_13.operation = 'EQUAL'
	
	    #node Switch
	    switch_14 = mesh_hair_selector.nodes.new("GeometryNodeSwitch")
	    switch_14.name = "Switch"
	    switch_14.hide = True
	    switch_14.input_type = 'GEOMETRY'
	
	    #node Compare.001
	    compare_001_5 = mesh_hair_selector.nodes.new("FunctionNodeCompare")
	    compare_001_5.name = "Compare.001"
	    compare_001_5.hide = True
	    compare_001_5.data_type = 'STRING'
	    compare_001_5.mode = 'ELEMENT'
	    compare_001_5.operation = 'EQUAL'
	
	    #node Switch.001
	    switch_001_10 = mesh_hair_selector.nodes.new("GeometryNodeSwitch")
	    switch_001_10.name = "Switch.001"
	    switch_001_10.hide = True
	    switch_001_10.input_type = 'GEOMETRY'
	
	    #node Compare.002
	    compare_002_7 = mesh_hair_selector.nodes.new("FunctionNodeCompare")
	    compare_002_7.name = "Compare.002"
	    compare_002_7.hide = True
	    compare_002_7.data_type = 'STRING'
	    compare_002_7.mode = 'ELEMENT'
	    compare_002_7.operation = 'EQUAL'
	
	    #node Switch.002
	    switch_002_5 = mesh_hair_selector.nodes.new("GeometryNodeSwitch")
	    switch_002_5.name = "Switch.002"
	    switch_002_5.hide = True
	    switch_002_5.input_type = 'GEOMETRY'
	
	    #node Compare.003
	    compare_003_6 = mesh_hair_selector.nodes.new("FunctionNodeCompare")
	    compare_003_6.name = "Compare.003"
	    compare_003_6.hide = True
	    compare_003_6.data_type = 'STRING'
	    compare_003_6.mode = 'ELEMENT'
	    compare_003_6.operation = 'EQUAL'
	
	    #node Switch.003
	    switch_003_6 = mesh_hair_selector.nodes.new("GeometryNodeSwitch")
	    switch_003_6.name = "Switch.003"
	    switch_003_6.hide = True
	    switch_003_6.input_type = 'GEOMETRY'
	
	    #node String
	    string = mesh_hair_selector.nodes.new("FunctionNodeInputString")
	    string.name = "String"
	    string.string = "hair_card_UV"
	
	    #node String.001
	    string_001 = mesh_hair_selector.nodes.new("FunctionNodeInputString")
	    string_001.name = "String.001"
	    string_001.string = "tube_mesh_UV"
	
	    #node String.002
	    string_002 = mesh_hair_selector.nodes.new("FunctionNodeInputString")
	    string_002.name = "String.002"
	    string_002.string = "ribbon_mesh_UV"
	
	    #node String.003
	    string_003 = mesh_hair_selector.nodes.new("FunctionNodeInputString")
	    string_003.name = "String.003"
	    string_003.string = "stylized_hair_UV"
	
	    #node Reroute
	    reroute_17 = mesh_hair_selector.nodes.new("NodeReroute")
	    reroute_17.name = "Reroute"
	    reroute_17.socket_idname = "NodeSocketString"
	    #node Reroute.001
	    reroute_001_13 = mesh_hair_selector.nodes.new("NodeReroute")
	    reroute_001_13.name = "Reroute.001"
	    reroute_001_13.socket_idname = "NodeSocketString"
	    #node Reroute.002
	    reroute_002_12 = mesh_hair_selector.nodes.new("NodeReroute")
	    reroute_002_12.name = "Reroute.002"
	    reroute_002_12.socket_idname = "NodeSocketString"
	    #node Reroute.003
	    reroute_003_12 = mesh_hair_selector.nodes.new("NodeReroute")
	    reroute_003_12.name = "Reroute.003"
	    reroute_003_12.socket_idname = "NodeSocketString"
	    #node Reroute.004
	    reroute_004_12 = mesh_hair_selector.nodes.new("NodeReroute")
	    reroute_004_12.name = "Reroute.004"
	    reroute_004_12.socket_idname = "NodeSocketString"
	    #node Reroute.005
	    reroute_005_10 = mesh_hair_selector.nodes.new("NodeReroute")
	    reroute_005_10.name = "Reroute.005"
	    reroute_005_10.socket_idname = "NodeSocketString"
	    #node Reroute.006
	    reroute_006_9 = mesh_hair_selector.nodes.new("NodeReroute")
	    reroute_006_9.name = "Reroute.006"
	    reroute_006_9.socket_idname = "NodeSocketString"
	    #node Reroute.007
	    reroute_007_9 = mesh_hair_selector.nodes.new("NodeReroute")
	    reroute_007_9.name = "Reroute.007"
	    reroute_007_9.socket_idname = "NodeSocketString"
	    #node Reroute.008
	    reroute_008_9 = mesh_hair_selector.nodes.new("NodeReroute")
	    reroute_008_9.name = "Reroute.008"
	    reroute_008_9.socket_idname = "NodeSocketString"
	    #node Reroute.009
	    reroute_009_9 = mesh_hair_selector.nodes.new("NodeReroute")
	    reroute_009_9.name = "Reroute.009"
	    reroute_009_9.socket_idname = "NodeSocketString"
	    #node Reroute.010
	    reroute_010_7 = mesh_hair_selector.nodes.new("NodeReroute")
	    reroute_010_7.name = "Reroute.010"
	    reroute_010_7.socket_idname = "NodeSocketString"
	    #node Reroute.011
	    reroute_011_8 = mesh_hair_selector.nodes.new("NodeReroute")
	    reroute_011_8.name = "Reroute.011"
	    reroute_011_8.socket_idname = "NodeSocketString"
	    #node Reroute.012
	    reroute_012_9 = mesh_hair_selector.nodes.new("NodeReroute")
	    reroute_012_9.name = "Reroute.012"
	    reroute_012_9.socket_idname = "NodeSocketString"
	    #node Reroute.013
	    reroute_013_8 = mesh_hair_selector.nodes.new("NodeReroute")
	    reroute_013_8.name = "Reroute.013"
	    reroute_013_8.socket_idname = "NodeSocketString"
	    #node Reroute.014
	    reroute_014_7 = mesh_hair_selector.nodes.new("NodeReroute")
	    reroute_014_7.name = "Reroute.014"
	    reroute_014_7.socket_idname = "NodeSocketString"
	    #node Group Input.007
	    group_input_007_7 = mesh_hair_selector.nodes.new("NodeGroupInput")
	    group_input_007_7.name = "Group Input.007"
	    group_input_007_7.outputs[0].hide = True
	    group_input_007_7.outputs[1].hide = True
	    group_input_007_7.outputs[2].hide = True
	    group_input_007_7.outputs[3].hide = True
	    group_input_007_7.outputs[4].hide = True
	    group_input_007_7.outputs[5].hide = True
	    group_input_007_7.outputs[6].hide = True
	    group_input_007_7.outputs[7].hide = True
	    group_input_007_7.outputs[8].hide = True
	    group_input_007_7.outputs[9].hide = True
	    group_input_007_7.outputs[10].hide = True
	    group_input_007_7.outputs[11].hide = True
	    group_input_007_7.outputs[12].hide = True
	    group_input_007_7.outputs[14].hide = True
	
	    #node Store Named Attribute.001
	    store_named_attribute_001_1 = mesh_hair_selector.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_001_1.name = "Store Named Attribute.001"
	    store_named_attribute_001_1.data_type = 'INT'
	    store_named_attribute_001_1.domain = 'CORNER'
	    #Selection
	    store_named_attribute_001_1.inputs[1].default_value = True
	    #Name
	    store_named_attribute_001_1.inputs[2].default_value = "mesh_idx"
	
	    #node Remove Named Attribute
	    remove_named_attribute = mesh_hair_selector.nodes.new("GeometryNodeRemoveAttribute")
	    remove_named_attribute.name = "Remove Named Attribute"
	    remove_named_attribute.pattern_mode = 'EXACT'
	
	    #node Reroute.015
	    reroute_015_8 = mesh_hair_selector.nodes.new("NodeReroute")
	    reroute_015_8.name = "Reroute.015"
	    reroute_015_8.socket_idname = "NodeSocketString"
	    #node Reroute.016
	    reroute_016_7 = mesh_hair_selector.nodes.new("NodeReroute")
	    reroute_016_7.name = "Reroute.016"
	    reroute_016_7.socket_idname = "NodeSocketString"
	    #node Set Shade Smooth
	    set_shade_smooth = mesh_hair_selector.nodes.new("GeometryNodeSetShadeSmooth")
	    set_shade_smooth.name = "Set Shade Smooth"
	    set_shade_smooth.domain = 'FACE'
	    set_shade_smooth.inputs[1].hide = True
	    #Selection
	    set_shade_smooth.inputs[1].default_value = True
	
	    #node Use Mesh Bake
	    use_mesh_bake = mesh_hair_selector.nodes.new("GeometryNodeBake")
	    use_mesh_bake.label = "Use Mesh Bake"
	    use_mesh_bake.name = "Use Mesh Bake"
	    use_mesh_bake.active_index = 0
	    use_mesh_bake.bake_items.clear()
	    use_mesh_bake.bake_items.new('GEOMETRY', "Geometry")
	    use_mesh_bake.bake_items[0].attribute_domain = 'POINT'
	    use_mesh_bake.inputs[1].hide = True
	    use_mesh_bake.outputs[1].hide = True
	
	    #node Group Input.008
	    group_input_008_6 = mesh_hair_selector.nodes.new("NodeGroupInput")
	    group_input_008_6.name = "Group Input.008"
	    group_input_008_6.outputs[0].hide = True
	    group_input_008_6.outputs[1].hide = True
	    group_input_008_6.outputs[2].hide = True
	    group_input_008_6.outputs[3].hide = True
	    group_input_008_6.outputs[4].hide = True
	    group_input_008_6.outputs[5].hide = True
	    group_input_008_6.outputs[7].hide = True
	    group_input_008_6.outputs[8].hide = True
	    group_input_008_6.outputs[9].hide = True
	    group_input_008_6.outputs[10].hide = True
	    group_input_008_6.outputs[11].hide = True
	    group_input_008_6.outputs[12].hide = True
	    group_input_008_6.outputs[13].hide = True
	    group_input_008_6.outputs[14].hide = True
	
	    #node Mesh Overall Shape
	    mesh_overall_shape = mesh_hair_selector.nodes.new("ShaderNodeFloatCurve")
	    mesh_overall_shape.label = "Mesh Overall Shape"
	    mesh_overall_shape.name = "Mesh Overall Shape"
	    #mapping settings
	    mesh_overall_shape.mapping.extend = 'EXTRAPOLATED'
	    mesh_overall_shape.mapping.tone = 'STANDARD'
	    mesh_overall_shape.mapping.black_level = (0.0, 0.0, 0.0)
	    mesh_overall_shape.mapping.white_level = (1.0, 1.0, 1.0)
	    mesh_overall_shape.mapping.clip_min_x = 0.0
	    mesh_overall_shape.mapping.clip_min_y = 0.0
	    mesh_overall_shape.mapping.clip_max_x = 1.0
	    mesh_overall_shape.mapping.clip_max_y = 1.0
	    mesh_overall_shape.mapping.use_clip = True
	    #curve 0
	    mesh_overall_shape_curve_0 = mesh_overall_shape.mapping.curves[0]
	    mesh_overall_shape_curve_0_point_0 = mesh_overall_shape_curve_0.points[0]
	    mesh_overall_shape_curve_0_point_0.location = (0.0, 1.0)
	    mesh_overall_shape_curve_0_point_0.handle_type = 'AUTO'
	    mesh_overall_shape_curve_0_point_1 = mesh_overall_shape_curve_0.points[1]
	    mesh_overall_shape_curve_0_point_1.location = (1.0, 1.0)
	    mesh_overall_shape_curve_0_point_1.handle_type = 'AUTO'
	    #update curve after changes
	    mesh_overall_shape.mapping.update()
	    #Factor
	    mesh_overall_shape.inputs[0].default_value = 1.0
	
	    #node Spline Parameter.001
	    spline_parameter_001_1 = mesh_hair_selector.nodes.new("GeometryNodeSplineParameter")
	    spline_parameter_001_1.name = "Spline Parameter.001"
	    spline_parameter_001_1.outputs[1].hide = True
	    spline_parameter_001_1.outputs[2].hide = True
	
	    #node Switch.004
	    switch_004_6 = mesh_hair_selector.nodes.new("GeometryNodeSwitch")
	    switch_004_6.name = "Switch.004"
	    switch_004_6.hide = True
	    switch_004_6.input_type = 'FLOAT'
	
	    #node Group Input.009
	    group_input_009_4 = mesh_hair_selector.nodes.new("NodeGroupInput")
	    group_input_009_4.name = "Group Input.009"
	    group_input_009_4.outputs[0].hide = True
	    group_input_009_4.outputs[1].hide = True
	    group_input_009_4.outputs[2].hide = True
	    group_input_009_4.outputs[3].hide = True
	    group_input_009_4.outputs[4].hide = True
	    group_input_009_4.outputs[6].hide = True
	    group_input_009_4.outputs[7].hide = True
	    group_input_009_4.outputs[8].hide = True
	    group_input_009_4.outputs[9].hide = True
	    group_input_009_4.outputs[10].hide = True
	    group_input_009_4.outputs[11].hide = True
	    group_input_009_4.outputs[12].hide = True
	    group_input_009_4.outputs[13].hide = True
	    group_input_009_4.outputs[14].hide = True
	
	    #node Attribute Statistic
	    attribute_statistic_1 = mesh_hair_selector.nodes.new("GeometryNodeAttributeStatistic")
	    attribute_statistic_1.name = "Attribute Statistic"
	    attribute_statistic_1.hide = True
	    attribute_statistic_1.data_type = 'FLOAT'
	    attribute_statistic_1.domain = 'POINT'
	    attribute_statistic_1.inputs[1].hide = True
	    attribute_statistic_1.outputs[0].hide = True
	    attribute_statistic_1.outputs[1].hide = True
	    attribute_statistic_1.outputs[3].hide = True
	    attribute_statistic_1.outputs[4].hide = True
	    attribute_statistic_1.outputs[5].hide = True
	    attribute_statistic_1.outputs[6].hide = True
	    attribute_statistic_1.outputs[7].hide = True
	    #Selection
	    attribute_statistic_1.inputs[1].default_value = True
	
	    #node Store Named Attribute.002
	    store_named_attribute_002 = mesh_hair_selector.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_002.name = "Store Named Attribute.002"
	    store_named_attribute_002.hide = True
	    store_named_attribute_002.data_type = 'FLOAT'
	    store_named_attribute_002.domain = 'POINT'
	    store_named_attribute_002.inputs[1].hide = True
	    store_named_attribute_002.inputs[2].hide = True
	    #Selection
	    store_named_attribute_002.inputs[1].default_value = True
	    #Name
	    store_named_attribute_002.inputs[2].default_value = "mcr"
	
	    #node Compare.005
	    compare_005_3 = mesh_hair_selector.nodes.new("FunctionNodeCompare")
	    compare_005_3.name = "Compare.005"
	    compare_005_3.hide = True
	    compare_005_3.data_type = 'FLOAT'
	    compare_005_3.mode = 'ELEMENT'
	    compare_005_3.operation = 'EQUAL'
	    compare_005_3.inputs[1].hide = True
	    compare_005_3.inputs[2].hide = True
	    compare_005_3.inputs[3].hide = True
	    compare_005_3.inputs[4].hide = True
	    compare_005_3.inputs[5].hide = True
	    compare_005_3.inputs[6].hide = True
	    compare_005_3.inputs[7].hide = True
	    compare_005_3.inputs[8].hide = True
	    compare_005_3.inputs[9].hide = True
	    compare_005_3.inputs[10].hide = True
	    compare_005_3.inputs[11].hide = True
	    compare_005_3.inputs[12].hide = True
	    #B
	    compare_005_3.inputs[1].default_value = 0.0
	    #Epsilon
	    compare_005_3.inputs[12].default_value = 0.0
	
	    #node Named Attribute.001
	    named_attribute_001_1 = mesh_hair_selector.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute_001_1.name = "Named Attribute.001"
	    named_attribute_001_1.hide = True
	    named_attribute_001_1.data_type = 'FLOAT'
	    #Name
	    named_attribute_001_1.inputs[0].default_value = "mcr"
	
	    #node Group Input.010
	    group_input_010_3 = mesh_hair_selector.nodes.new("NodeGroupInput")
	    group_input_010_3.name = "Group Input.010"
	    group_input_010_3.outputs[1].hide = True
	    group_input_010_3.outputs[2].hide = True
	    group_input_010_3.outputs[3].hide = True
	    group_input_010_3.outputs[4].hide = True
	    group_input_010_3.outputs[5].hide = True
	    group_input_010_3.outputs[6].hide = True
	    group_input_010_3.outputs[7].hide = True
	    group_input_010_3.outputs[8].hide = True
	    group_input_010_3.outputs[9].hide = True
	    group_input_010_3.outputs[10].hide = True
	    group_input_010_3.outputs[11].hide = True
	    group_input_010_3.outputs[12].hide = True
	    group_input_010_3.outputs[13].hide = True
	    group_input_010_3.outputs[14].hide = True
	
	
	
	
	
	    #Set locations
	    group_output_21.location = (2610.42724609375, -19.416736602783203)
	    group_9.location = (-79.76215362548828, -110.40367889404297)
	    group_001_8.location = (-81.79773712158203, -748.9313354492188)
	    group_002_5.location = (-78.79950714111328, -318.1512451171875)
	    group_003_3.location = (-78.67485809326172, -526.0662231445312)
	    group_input_001_13.location = (-338.60595703125, -155.34437561035156)
	    group_input_002_12.location = (-338.60595703125, -362.43890380859375)
	    group_input_003_13.location = (-338.60595703125, -569.8320922851562)
	    group_input_004_10.location = (-338.60595703125, -815.11083984375)
	    menu_switch_001.location = (469.07684326171875, 163.7274627685547)
	    store_named_attribute_7.location = (1647.7332763671875, -19.652393341064453)
	    named_attribute_4.location = (1475.844482421875, -157.7658233642578)
	    group_input_005_9.location = (265.0098571777344, 135.95323181152344)
	    group_input_006_7.location = (-338.60595703125, -756.4561767578125)
	    compare_13.location = (1238.7310791015625, -84.21184539794922)
	    switch_14.location = (1238.74365234375, -117.19403076171875)
	    compare_001_5.location = (1099.1707763671875, -299.4894104003906)
	    switch_001_10.location = (1106.2532958984375, -334.8301696777344)
	    compare_002_7.location = (970.40234375, -499.8262634277344)
	    switch_002_5.location = (975.1282958984375, -535.1670532226562)
	    compare_003_6.location = (837.8390502929688, -724.1065063476562)
	    switch_003_6.location = (840.2083740234375, -760.2830810546875)
	    string.location = (84.04959869384766, -54.475547790527344)
	    string_001.location = (82.85930633544922, -258.00762939453125)
	    string_002.location = (79.31243896484375, -471.3780517578125)
	    string_003.location = (76.95584106445312, -696.93603515625)
	    reroute_17.location = (266.1946716308594, -90.37294006347656)
	    reroute_001_13.location = (330.2995910644531, -295.4872741699219)
	    reroute_002_12.location = (386.08740234375, -507.37738037109375)
	    reroute_003_12.location = (432.0370178222656, -735.281005859375)
	    reroute_004_12.location = (267.64080810546875, 58.478363037109375)
	    reroute_005_10.location = (328.94110107421875, 33.61994552612305)
	    reroute_006_9.location = (388.06353759765625, 12.934127807617188)
	    reroute_007_9.location = (434.48321533203125, -6.701620101928711)
	    reroute_008_9.location = (790.6254272460938, 129.04226684570312)
	    reroute_009_9.location = (800.4947509765625, -727.48974609375)
	    reroute_010_7.location = (796.8050537109375, -498.8685607910156)
	    reroute_011_8.location = (792.9110107421875, -293.6495361328125)
	    reroute_012_9.location = (790.7710571289062, -80.90033721923828)
	    reroute_013_8.location = (1415.17578125, -264.01324462890625)
	    reroute_014_7.location = (1401.7613525390625, 129.6073760986328)
	    group_input_007_7.location = (1837.3367919921875, -221.13070678710938)
	    store_named_attribute_001_1.location = (1841.328125, -19.652393341064453)
	    remove_named_attribute.location = (2020.999755859375, -18.566680908203125)
	    reroute_015_8.location = (1997.9866943359375, 132.55369567871094)
	    reroute_016_7.location = (2003.16845703125, -126.52413940429688)
	    set_shade_smooth.location = (2246.024658203125, -17.58367919921875)
	    use_mesh_bake.location = (2430.91064453125, 27.558258056640625)
	    group_input_008_6.location = (2049.84326171875, -148.66607666015625)
	    mesh_overall_shape.location = (-836.517822265625, -661.2866821289062)
	    spline_parameter_001_1.location = (-839.99169921875, -978.5739135742188)
	    switch_004_6.location = (-595.0516357421875, -483.56573486328125)
	    group_input_009_4.location = (-835.753662109375, -601.5596313476562)
	    attribute_statistic_1.location = (-834.099853515625, -521.8562622070312)
	    store_named_attribute_002.location = (-842.1680908203125, -576.4926147460938)
	    compare_005_3.location = (-595.83642578125, -521.7107543945312)
	    named_attribute_001_1.location = (-837.260009765625, -465.05096435546875)
	    group_input_010_3.location = (-1010.263427734375, -544.5166625976562)
	
	    #Set dimensions
	    group_output_21.width, group_output_21.height = 140.0, 100.0
	    group_9.width, group_9.height = 140.0, 100.0
	    group_001_8.width, group_001_8.height = 140.0, 100.0
	    group_002_5.width, group_002_5.height = 140.0, 100.0
	    group_003_3.width, group_003_3.height = 140.0, 100.0
	    group_input_001_13.width, group_input_001_13.height = 140.0, 100.0
	    group_input_002_12.width, group_input_002_12.height = 140.0, 100.0
	    group_input_003_13.width, group_input_003_13.height = 140.0, 100.0
	    group_input_004_10.width, group_input_004_10.height = 140.0, 100.0
	    menu_switch_001.width, menu_switch_001.height = 245.18148803710938, 100.0
	    store_named_attribute_7.width, store_named_attribute_7.height = 140.0, 100.0
	    named_attribute_4.width, named_attribute_4.height = 140.0, 100.0
	    group_input_005_9.width, group_input_005_9.height = 140.0, 100.0
	    group_input_006_7.width, group_input_006_7.height = 140.0, 100.0
	    compare_13.width, compare_13.height = 140.0, 100.0
	    switch_14.width, switch_14.height = 140.0, 100.0
	    compare_001_5.width, compare_001_5.height = 140.0, 100.0
	    switch_001_10.width, switch_001_10.height = 140.0, 100.0
	    compare_002_7.width, compare_002_7.height = 140.0, 100.0
	    switch_002_5.width, switch_002_5.height = 140.0, 100.0
	    compare_003_6.width, compare_003_6.height = 140.0, 100.0
	    switch_003_6.width, switch_003_6.height = 140.0, 100.0
	    string.width, string.height = 140.0, 100.0
	    string_001.width, string_001.height = 140.0, 100.0
	    string_002.width, string_002.height = 140.0, 100.0
	    string_003.width, string_003.height = 140.0, 100.0
	    reroute_17.width, reroute_17.height = 100.0, 100.0
	    reroute_001_13.width, reroute_001_13.height = 100.0, 100.0
	    reroute_002_12.width, reroute_002_12.height = 100.0, 100.0
	    reroute_003_12.width, reroute_003_12.height = 100.0, 100.0
	    reroute_004_12.width, reroute_004_12.height = 100.0, 100.0
	    reroute_005_10.width, reroute_005_10.height = 100.0, 100.0
	    reroute_006_9.width, reroute_006_9.height = 100.0, 100.0
	    reroute_007_9.width, reroute_007_9.height = 100.0, 100.0
	    reroute_008_9.width, reroute_008_9.height = 100.0, 100.0
	    reroute_009_9.width, reroute_009_9.height = 100.0, 100.0
	    reroute_010_7.width, reroute_010_7.height = 100.0, 100.0
	    reroute_011_8.width, reroute_011_8.height = 100.0, 100.0
	    reroute_012_9.width, reroute_012_9.height = 100.0, 100.0
	    reroute_013_8.width, reroute_013_8.height = 100.0, 100.0
	    reroute_014_7.width, reroute_014_7.height = 100.0, 100.0
	    group_input_007_7.width, group_input_007_7.height = 140.0, 100.0
	    store_named_attribute_001_1.width, store_named_attribute_001_1.height = 140.0, 100.0
	    remove_named_attribute.width, remove_named_attribute.height = 170.0, 100.0
	    reroute_015_8.width, reroute_015_8.height = 100.0, 100.0
	    reroute_016_7.width, reroute_016_7.height = 100.0, 100.0
	    set_shade_smooth.width, set_shade_smooth.height = 140.0, 100.0
	    use_mesh_bake.width, use_mesh_bake.height = 140.0, 100.0
	    group_input_008_6.width, group_input_008_6.height = 140.0, 100.0
	    mesh_overall_shape.width, mesh_overall_shape.height = 240.0, 100.0
	    spline_parameter_001_1.width, spline_parameter_001_1.height = 140.0, 100.0
	    switch_004_6.width, switch_004_6.height = 140.0, 100.0
	    group_input_009_4.width, group_input_009_4.height = 140.0, 100.0
	    attribute_statistic_1.width, attribute_statistic_1.height = 140.0, 100.0
	    store_named_attribute_002.width, store_named_attribute_002.height = 140.0, 100.0
	    compare_005_3.width, compare_005_3.height = 140.0, 100.0
	    named_attribute_001_1.width, named_attribute_001_1.height = 140.0, 100.0
	    group_input_010_3.width, group_input_010_3.height = 140.0, 100.0
	
	    #initialize mesh_hair_selector links
	    #use_mesh_bake.Geometry -> group_output_21.Geometry
	    mesh_hair_selector.links.new(use_mesh_bake.outputs[0], group_output_21.inputs[0])
	    #group_input_001_13.Geometry -> group_9.Geometry
	    mesh_hair_selector.links.new(group_input_001_13.outputs[0], group_9.inputs[0])
	    #group_input_002_12.Geometry -> group_002_5.Geometry
	    mesh_hair_selector.links.new(group_input_002_12.outputs[0], group_002_5.inputs[0])
	    #group_input_003_13.Geometry -> group_003_3.Geometry
	    mesh_hair_selector.links.new(group_input_003_13.outputs[0], group_003_3.inputs[0])
	    #group_input_004_10.Geometry -> group_001_8.Geometry
	    mesh_hair_selector.links.new(group_input_004_10.outputs[0], group_001_8.inputs[0])
	    #group_input_001_13.Material -> group_9.Material
	    mesh_hair_selector.links.new(group_input_001_13.outputs[2], group_9.inputs[1])
	    #named_attribute_4.Attribute -> store_named_attribute_7.Value
	    mesh_hair_selector.links.new(named_attribute_4.outputs[0], store_named_attribute_7.inputs[3])
	    #reroute_013_8.Output -> named_attribute_4.Name
	    mesh_hair_selector.links.new(reroute_013_8.outputs[0], named_attribute_4.inputs[0])
	    #group_input_005_9.Style Select -> menu_switch_001.Menu
	    mesh_hair_selector.links.new(group_input_005_9.outputs[1], menu_switch_001.inputs[0])
	    #group_input_001_13.Resolution -> group_9.Resolution
	    mesh_hair_selector.links.new(group_input_001_13.outputs[3], group_9.inputs[3])
	    #group_input_001_13.Width -> group_9.Width
	    mesh_hair_selector.links.new(group_input_001_13.outputs[4], group_9.inputs[4])
	    #group_input_001_13.Hair Card Angle -> group_9.Angle
	    mesh_hair_selector.links.new(group_input_001_13.outputs[7], group_9.inputs[5])
	    #group_input_002_12.Material -> group_002_5.Material
	    mesh_hair_selector.links.new(group_input_002_12.outputs[2], group_002_5.inputs[1])
	    #group_input_002_12.Resolution -> group_002_5.Resolution
	    mesh_hair_selector.links.new(group_input_002_12.outputs[3], group_002_5.inputs[3])
	    #group_input_002_12.Width -> group_002_5.Width
	    mesh_hair_selector.links.new(group_input_002_12.outputs[4], group_002_5.inputs[4])
	    #group_input_002_12.Fill Caps -> group_002_5.Fill Caps
	    mesh_hair_selector.links.new(group_input_002_12.outputs[5], group_002_5.inputs[5])
	    #group_input_003_13.Material -> group_003_3.Material
	    mesh_hair_selector.links.new(group_input_003_13.outputs[2], group_003_3.inputs[1])
	    #group_input_003_13.Resolution -> group_003_3.Resolution
	    mesh_hair_selector.links.new(group_input_003_13.outputs[3], group_003_3.inputs[4])
	    #group_input_003_13.Width -> group_003_3.Width
	    mesh_hair_selector.links.new(group_input_003_13.outputs[4], group_003_3.inputs[5])
	    #group_input_003_13.Tube Ribbon Count -> group_003_3.Ribbon Count
	    mesh_hair_selector.links.new(group_input_003_13.outputs[8], group_003_3.inputs[3])
	    #group_input_004_10.Material -> group_001_8.Material
	    mesh_hair_selector.links.new(group_input_004_10.outputs[2], group_001_8.inputs[2])
	    #group_input_004_10.Fill Caps -> group_001_8.Fill Caps
	    mesh_hair_selector.links.new(group_input_004_10.outputs[5], group_001_8.inputs[5])
	    #group_input_004_10.Profile Translation -> group_001_8.Translation
	    mesh_hair_selector.links.new(group_input_004_10.outputs[10], group_001_8.inputs[6])
	    #group_input_004_10.Profile Rotation -> group_001_8.Rotation
	    mesh_hair_selector.links.new(group_input_004_10.outputs[11], group_001_8.inputs[7])
	    #group_input_004_10.Profile Scale -> group_001_8.Scale
	    mesh_hair_selector.links.new(group_input_004_10.outputs[12], group_001_8.inputs[8])
	    #group_input_006_7.Profile Curve -> group_001_8.Profile
	    mesh_hair_selector.links.new(group_input_006_7.outputs[9], group_001_8.inputs[1])
	    #group_input_004_10.Resolution -> group_001_8.Resolution
	    mesh_hair_selector.links.new(group_input_004_10.outputs[3], group_001_8.inputs[4])
	    #compare_13.Result -> switch_14.Switch
	    mesh_hair_selector.links.new(compare_13.outputs[0], switch_14.inputs[0])
	    #compare_001_5.Result -> switch_001_10.Switch
	    mesh_hair_selector.links.new(compare_001_5.outputs[0], switch_001_10.inputs[0])
	    #compare_002_7.Result -> switch_002_5.Switch
	    mesh_hair_selector.links.new(compare_002_7.outputs[0], switch_002_5.inputs[0])
	    #reroute_009_9.Output -> compare_003_6.A
	    mesh_hair_selector.links.new(reroute_009_9.outputs[0], compare_003_6.inputs[8])
	    #compare_003_6.Result -> switch_003_6.Switch
	    mesh_hair_selector.links.new(compare_003_6.outputs[0], switch_003_6.inputs[0])
	    #switch_001_10.Output -> switch_14.False
	    mesh_hair_selector.links.new(switch_001_10.outputs[0], switch_14.inputs[1])
	    #switch_002_5.Output -> switch_001_10.False
	    mesh_hair_selector.links.new(switch_002_5.outputs[0], switch_001_10.inputs[1])
	    #switch_003_6.Output -> switch_002_5.False
	    mesh_hair_selector.links.new(switch_003_6.outputs[0], switch_002_5.inputs[1])
	    #reroute_004_12.Output -> menu_switch_001.Hair Card
	    mesh_hair_selector.links.new(reroute_004_12.outputs[0], menu_switch_001.inputs[1])
	    #reroute_17.Output -> compare_13.B
	    mesh_hair_selector.links.new(reroute_17.outputs[0], compare_13.inputs[9])
	    #group_9.Geometry -> switch_14.True
	    mesh_hair_selector.links.new(group_9.outputs[0], switch_14.inputs[2])
	    #reroute_005_10.Output -> menu_switch_001.Tube Mesh
	    mesh_hair_selector.links.new(reroute_005_10.outputs[0], menu_switch_001.inputs[2])
	    #reroute_001_13.Output -> compare_001_5.B
	    mesh_hair_selector.links.new(reroute_001_13.outputs[0], compare_001_5.inputs[9])
	    #group_002_5.Geometry -> switch_001_10.True
	    mesh_hair_selector.links.new(group_002_5.outputs[0], switch_001_10.inputs[2])
	    #reroute_006_9.Output -> menu_switch_001.Tube Ribbon
	    mesh_hair_selector.links.new(reroute_006_9.outputs[0], menu_switch_001.inputs[3])
	    #reroute_002_12.Output -> compare_002_7.B
	    mesh_hair_selector.links.new(reroute_002_12.outputs[0], compare_002_7.inputs[9])
	    #group_003_3.Geometry -> switch_002_5.True
	    mesh_hair_selector.links.new(group_003_3.outputs[0], switch_002_5.inputs[2])
	    #reroute_007_9.Output -> menu_switch_001.Stylized
	    mesh_hair_selector.links.new(reroute_007_9.outputs[0], menu_switch_001.inputs[4])
	    #reroute_003_12.Output -> compare_003_6.B
	    mesh_hair_selector.links.new(reroute_003_12.outputs[0], compare_003_6.inputs[9])
	    #group_001_8.Geometry -> switch_003_6.True
	    mesh_hair_selector.links.new(group_001_8.outputs[0], switch_003_6.inputs[2])
	    #switch_14.Output -> store_named_attribute_7.Geometry
	    mesh_hair_selector.links.new(switch_14.outputs[0], store_named_attribute_7.inputs[0])
	    #string.String -> reroute_17.Input
	    mesh_hair_selector.links.new(string.outputs[0], reroute_17.inputs[0])
	    #string_001.String -> reroute_001_13.Input
	    mesh_hair_selector.links.new(string_001.outputs[0], reroute_001_13.inputs[0])
	    #string_002.String -> reroute_002_12.Input
	    mesh_hair_selector.links.new(string_002.outputs[0], reroute_002_12.inputs[0])
	    #string_003.String -> reroute_003_12.Input
	    mesh_hair_selector.links.new(string_003.outputs[0], reroute_003_12.inputs[0])
	    #reroute_17.Output -> reroute_004_12.Input
	    mesh_hair_selector.links.new(reroute_17.outputs[0], reroute_004_12.inputs[0])
	    #reroute_001_13.Output -> reroute_005_10.Input
	    mesh_hair_selector.links.new(reroute_001_13.outputs[0], reroute_005_10.inputs[0])
	    #reroute_002_12.Output -> reroute_006_9.Input
	    mesh_hair_selector.links.new(reroute_002_12.outputs[0], reroute_006_9.inputs[0])
	    #reroute_003_12.Output -> reroute_007_9.Input
	    mesh_hair_selector.links.new(reroute_003_12.outputs[0], reroute_007_9.inputs[0])
	    #menu_switch_001.Output -> reroute_008_9.Input
	    mesh_hair_selector.links.new(menu_switch_001.outputs[0], reroute_008_9.inputs[0])
	    #reroute_010_7.Output -> reroute_009_9.Input
	    mesh_hair_selector.links.new(reroute_010_7.outputs[0], reroute_009_9.inputs[0])
	    #reroute_011_8.Output -> reroute_010_7.Input
	    mesh_hair_selector.links.new(reroute_011_8.outputs[0], reroute_010_7.inputs[0])
	    #reroute_010_7.Output -> compare_002_7.A
	    mesh_hair_selector.links.new(reroute_010_7.outputs[0], compare_002_7.inputs[8])
	    #reroute_012_9.Output -> reroute_011_8.Input
	    mesh_hair_selector.links.new(reroute_012_9.outputs[0], reroute_011_8.inputs[0])
	    #reroute_008_9.Output -> reroute_012_9.Input
	    mesh_hair_selector.links.new(reroute_008_9.outputs[0], reroute_012_9.inputs[0])
	    #reroute_011_8.Output -> compare_001_5.A
	    mesh_hair_selector.links.new(reroute_011_8.outputs[0], compare_001_5.inputs[8])
	    #reroute_012_9.Output -> compare_13.A
	    mesh_hair_selector.links.new(reroute_012_9.outputs[0], compare_13.inputs[8])
	    #reroute_014_7.Output -> reroute_013_8.Input
	    mesh_hair_selector.links.new(reroute_014_7.outputs[0], reroute_013_8.inputs[0])
	    #reroute_008_9.Output -> reroute_014_7.Input
	    mesh_hair_selector.links.new(reroute_008_9.outputs[0], reroute_014_7.inputs[0])
	    #store_named_attribute_7.Geometry -> store_named_attribute_001_1.Geometry
	    mesh_hair_selector.links.new(store_named_attribute_7.outputs[0], store_named_attribute_001_1.inputs[0])
	    #group_input_007_7.Mesh Index -> store_named_attribute_001_1.Value
	    mesh_hair_selector.links.new(group_input_007_7.outputs[13], store_named_attribute_001_1.inputs[3])
	    #store_named_attribute_001_1.Geometry -> remove_named_attribute.Geometry
	    mesh_hair_selector.links.new(store_named_attribute_001_1.outputs[0], remove_named_attribute.inputs[0])
	    #reroute_016_7.Output -> remove_named_attribute.Name
	    mesh_hair_selector.links.new(reroute_016_7.outputs[0], remove_named_attribute.inputs[1])
	    #reroute_014_7.Output -> reroute_015_8.Input
	    mesh_hair_selector.links.new(reroute_014_7.outputs[0], reroute_015_8.inputs[0])
	    #reroute_015_8.Output -> reroute_016_7.Input
	    mesh_hair_selector.links.new(reroute_015_8.outputs[0], reroute_016_7.inputs[0])
	    #set_shade_smooth.Geometry -> use_mesh_bake.Geometry
	    mesh_hair_selector.links.new(set_shade_smooth.outputs[0], use_mesh_bake.inputs[0])
	    #remove_named_attribute.Geometry -> set_shade_smooth.Geometry
	    mesh_hair_selector.links.new(remove_named_attribute.outputs[0], set_shade_smooth.inputs[0])
	    #group_input_008_6.Shade Smooth -> set_shade_smooth.Shade Smooth
	    mesh_hair_selector.links.new(group_input_008_6.outputs[6], set_shade_smooth.inputs[2])
	    #spline_parameter_001_1.Factor -> mesh_overall_shape.Value
	    mesh_hair_selector.links.new(spline_parameter_001_1.outputs[0], mesh_overall_shape.inputs[1])
	    #group_input_009_4.Fill Caps -> store_named_attribute_002.Value
	    mesh_hair_selector.links.new(group_input_009_4.outputs[5], store_named_attribute_002.inputs[3])
	    #store_named_attribute_002.Geometry -> attribute_statistic_1.Geometry
	    mesh_hair_selector.links.new(store_named_attribute_002.outputs[0], attribute_statistic_1.inputs[0])
	    #attribute_statistic_1.Sum -> compare_005_3.A
	    mesh_hair_selector.links.new(attribute_statistic_1.outputs[2], compare_005_3.inputs[0])
	    #compare_005_3.Result -> switch_004_6.Switch
	    mesh_hair_selector.links.new(compare_005_3.outputs[0], switch_004_6.inputs[0])
	    #named_attribute_001_1.Attribute -> attribute_statistic_1.Attribute
	    mesh_hair_selector.links.new(named_attribute_001_1.outputs[0], attribute_statistic_1.inputs[2])
	    #mesh_overall_shape.Value -> switch_004_6.True
	    mesh_hair_selector.links.new(mesh_overall_shape.outputs[0], switch_004_6.inputs[2])
	    #group_input_009_4.Fill Caps -> switch_004_6.False
	    mesh_hair_selector.links.new(group_input_009_4.outputs[5], switch_004_6.inputs[1])
	    #group_input_010_3.Geometry -> store_named_attribute_002.Geometry
	    mesh_hair_selector.links.new(group_input_010_3.outputs[0], store_named_attribute_002.inputs[0])
	    #switch_004_6.Output -> group_9.Curve Radius
	    mesh_hair_selector.links.new(switch_004_6.outputs[0], group_9.inputs[2])
	    #switch_004_6.Output -> group_002_5.Curve Radius
	    mesh_hair_selector.links.new(switch_004_6.outputs[0], group_002_5.inputs[2])
	    #switch_004_6.Output -> group_003_3.Curve Radius
	    mesh_hair_selector.links.new(switch_004_6.outputs[0], group_003_3.inputs[2])
	    #switch_004_6.Output -> group_001_8.Curve Radius
	    mesh_hair_selector.links.new(switch_004_6.outputs[0], group_001_8.inputs[3])
	    style_select_socket.default_value = 'Hair Card'
	    return mesh_hair_selector
	
	mesh_hair_selector = mesh_hair_selector_node_group()
	
	#initialize facial_hairz node group
	def facial_hairz_node_group():
	    facial_hairz = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "FACIAL_HAIRZ")
	
	    facial_hairz.color_tag = 'NONE'
	    facial_hairz.description = "Draw curves to spawn hair under and across surface."
	    facial_hairz.default_group_node_width = 140
	    
	
	    facial_hairz.is_modifier = True
	
	    #facial_hairz interface
	    #Socket Geometry
	    geometry_socket_33 = facial_hairz.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_33.attribute_domain = 'POINT'
	    geometry_socket_33.description = "Facial hair."
	
	    #Socket Geometry
	    geometry_socket_34 = facial_hairz.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_34.attribute_domain = 'POINT'
	    geometry_socket_34.description = "Drawn hair curves."
	
	    #Socket Surface
	    surface_socket_7 = facial_hairz.interface.new_socket(name = "Surface", in_out='INPUT', socket_type = 'NodeSocketObject')
	    surface_socket_7.attribute_domain = 'POINT'
	    surface_socket_7.description = "Surface mesh to draw hair on and attach spawned hairs."
	
	    #Socket Material
	    material_socket_5 = facial_hairz.interface.new_socket(name = "Material", in_out='INPUT', socket_type = 'NodeSocketMaterial')
	    material_socket_5.attribute_domain = 'POINT'
	    material_socket_5.description = "Material for hair curve."
	
	    #Socket Mirror X
	    mirror_x_socket = facial_hairz.interface.new_socket(name = "Mirror X", in_out='INPUT', socket_type = 'NodeSocketBool')
	    mirror_x_socket.default_value = True
	    mirror_x_socket.attribute_domain = 'POINT'
	    mirror_x_socket.description = "Mirror hair across x axis."
	
	    #Socket Hair Count
	    hair_count_socket = facial_hairz.interface.new_socket(name = "Hair Count", in_out='INPUT', socket_type = 'NodeSocketInt')
	    hair_count_socket.default_value = 10
	    hair_count_socket.min_value = 2
	    hair_count_socket.max_value = 100000
	    hair_count_socket.subtype = 'NONE'
	    hair_count_socket.attribute_domain = 'POINT'
	    hair_count_socket.description = "Amount of spawned hairs for each curve."
	
	    #Socket Hair Length
	    hair_length_socket = facial_hairz.interface.new_socket(name = "Hair Length", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    hair_length_socket.default_value = 1.0
	    hair_length_socket.min_value = 0.0
	    hair_length_socket.max_value = 3.4028234663852886e+38
	    hair_length_socket.subtype = 'DISTANCE'
	    hair_length_socket.attribute_domain = 'POINT'
	    hair_length_socket.description = "Length of spawned hair."
	
	    #Socket Control Points
	    control_points_socket = facial_hairz.interface.new_socket(name = "Control Points", in_out='INPUT', socket_type = 'NodeSocketInt')
	    control_points_socket.default_value = 8
	    control_points_socket.min_value = 2
	    control_points_socket.max_value = 100000
	    control_points_socket.subtype = 'NONE'
	    control_points_socket.attribute_domain = 'POINT'
	    control_points_socket.description = "Amount of points for each curve."
	
	    #Socket Hair Radius
	    hair_radius_socket = facial_hairz.interface.new_socket(name = "Hair Radius", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    hair_radius_socket.default_value = 0.003000000026077032
	    hair_radius_socket.min_value = 0.0
	    hair_radius_socket.max_value = 3.4028234663852886e+38
	    hair_radius_socket.subtype = 'DISTANCE'
	    hair_radius_socket.attribute_domain = 'POINT'
	    hair_radius_socket.description = "Radius of hair strands."
	
	    #Socket UV Map
	    uv_map_socket_1 = facial_hairz.interface.new_socket(name = "UV Map", in_out='INPUT', socket_type = 'NodeSocketString')
	    uv_map_socket_1.default_value = "UVMap"
	    uv_map_socket_1.subtype = 'NONE'
	    uv_map_socket_1.attribute_domain = 'POINT'
	    uv_map_socket_1.description = "Surface UV Map used to attach hair."
	
	    #Socket Blend along Curve
	    blend_along_curve_socket_2 = facial_hairz.interface.new_socket(name = "Blend along Curve", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    blend_along_curve_socket_2.default_value = 0.05000000074505806
	    blend_along_curve_socket_2.min_value = 0.0
	    blend_along_curve_socket_2.max_value = 1.0
	    blend_along_curve_socket_2.subtype = 'FACTOR'
	    blend_along_curve_socket_2.attribute_domain = 'POINT'
	    blend_along_curve_socket_2.description = "Blend deformation along each curve from the root"
	
	    #Panel Shrinkwrap Settings
	    shrinkwrap_settings_panel = facial_hairz.interface.new_panel("Shrinkwrap Settings", default_closed=True)
	    shrinkwrap_settings_panel.description = "Settings for shrinkwrapping spawned hair to surface."
	    #Socket Use Shrinkwrap
	    use_shrinkwrap_socket = facial_hairz.interface.new_socket(name = "Use Shrinkwrap", in_out='INPUT', socket_type = 'NodeSocketBool', parent = shrinkwrap_settings_panel)
	    use_shrinkwrap_socket.default_value = False
	    use_shrinkwrap_socket.attribute_domain = 'POINT'
	    use_shrinkwrap_socket.description = "Shrinkwrap hair to surface."
	
	    #Socket Surface Offset
	    surface_offset_socket = facial_hairz.interface.new_socket(name = "Surface Offset", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = shrinkwrap_settings_panel)
	    surface_offset_socket.default_value = 0.0010000000474974513
	    surface_offset_socket.min_value = 0.0
	    surface_offset_socket.max_value = 10000.0
	    surface_offset_socket.subtype = 'NONE'
	    surface_offset_socket.attribute_domain = 'POINT'
	    surface_offset_socket.description = "Distance of hair tips to surface."
	
	    #Socket Rotation Factor
	    rotation_factor_socket_1 = facial_hairz.interface.new_socket(name = "Rotation Factor", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = shrinkwrap_settings_panel)
	    rotation_factor_socket_1.default_value = 0.0
	    rotation_factor_socket_1.min_value = 0.0
	    rotation_factor_socket_1.max_value = 1.0
	    rotation_factor_socket_1.subtype = 'FACTOR'
	    rotation_factor_socket_1.attribute_domain = 'POINT'
	    rotation_factor_socket_1.description = "Rotate the orientation of hairs on the surface."
	
	
	    #Panel Children Settings
	    children_settings_panel = facial_hairz.interface.new_panel("Children Settings", default_closed=True)
	    children_settings_panel.description = "Settings for hair duplicates."
	    #Socket Duplicate Amount
	    duplicate_amount_socket = facial_hairz.interface.new_socket(name = "Duplicate Amount", in_out='INPUT', socket_type = 'NodeSocketInt', parent = children_settings_panel)
	    duplicate_amount_socket.default_value = 10
	    duplicate_amount_socket.min_value = 0
	    duplicate_amount_socket.max_value = 2147483647
	    duplicate_amount_socket.subtype = 'NONE'
	    duplicate_amount_socket.attribute_domain = 'POINT'
	    duplicate_amount_socket.description = "Amount of duplicates per curve."
	
	    #Socket Duplicate Viewport Amount
	    duplicate_viewport_amount_socket = facial_hairz.interface.new_socket(name = "Duplicate Viewport Amount", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = children_settings_panel)
	    duplicate_viewport_amount_socket.default_value = 1.0
	    duplicate_viewport_amount_socket.min_value = 0.0
	    duplicate_viewport_amount_socket.max_value = 1.0
	    duplicate_viewport_amount_socket.subtype = 'FACTOR'
	    duplicate_viewport_amount_socket.attribute_domain = 'POINT'
	    duplicate_viewport_amount_socket.description = "Percentage of amount used for the viewport."
	
	    #Socket Duplicate Radius
	    duplicate_radius_socket = facial_hairz.interface.new_socket(name = "Duplicate Radius", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = children_settings_panel)
	    duplicate_radius_socket.default_value = 0.09999999403953552
	    duplicate_radius_socket.min_value = 0.0
	    duplicate_radius_socket.max_value = 3.4028234663852886e+38
	    duplicate_radius_socket.subtype = 'DISTANCE'
	    duplicate_radius_socket.attribute_domain = 'POINT'
	    duplicate_radius_socket.description = "Radius in which the duplicate curves are offset from the guides."
	
	    #Socket Duplicate Distribution Shape
	    duplicate_distribution_shape_socket = facial_hairz.interface.new_socket(name = "Duplicate Distribution Shape", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = children_settings_panel)
	    duplicate_distribution_shape_socket.default_value = 0.0
	    duplicate_distribution_shape_socket.min_value = -10.0
	    duplicate_distribution_shape_socket.max_value = 10.0
	    duplicate_distribution_shape_socket.subtype = 'NONE'
	    duplicate_distribution_shape_socket.attribute_domain = 'POINT'
	    duplicate_distribution_shape_socket.description = "Shape of distribution from center to the edge around the guide."
	
	    #Socket Duplicate Tip Roundness
	    duplicate_tip_roundness_socket = facial_hairz.interface.new_socket(name = "Duplicate Tip Roundness", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = children_settings_panel)
	    duplicate_tip_roundness_socket.default_value = 0.0
	    duplicate_tip_roundness_socket.min_value = 0.0
	    duplicate_tip_roundness_socket.max_value = 1.0
	    duplicate_tip_roundness_socket.subtype = 'FACTOR'
	    duplicate_tip_roundness_socket.attribute_domain = 'POINT'
	    duplicate_tip_roundness_socket.description = "Offset of the curves to round the tip."
	
	    #Socket Duplicate Even Thickness
	    duplicate_even_thickness_socket = facial_hairz.interface.new_socket(name = "Duplicate Even Thickness", in_out='INPUT', socket_type = 'NodeSocketBool', parent = children_settings_panel)
	    duplicate_even_thickness_socket.default_value = False
	    duplicate_even_thickness_socket.attribute_domain = 'POINT'
	    duplicate_even_thickness_socket.description = "Keep an even thickness of the distribution of duplicates."
	
	    #Socket Duplicate Seed
	    duplicate_seed_socket = facial_hairz.interface.new_socket(name = "Duplicate Seed", in_out='INPUT', socket_type = 'NodeSocketInt', parent = children_settings_panel)
	    duplicate_seed_socket.default_value = 0
	    duplicate_seed_socket.min_value = -10000
	    duplicate_seed_socket.max_value = 10000
	    duplicate_seed_socket.subtype = 'NONE'
	    duplicate_seed_socket.attribute_domain = 'POINT'
	    duplicate_seed_socket.description = "Random Seed for the duplicates."
	
	
	    #Panel Clump Settings
	    clump_settings_panel = facial_hairz.interface.new_panel("Clump Settings", default_closed=True)
	    clump_settings_panel.description = "Settings for hair clumping."
	    #Socket Clump Factor
	    clump_factor_socket = facial_hairz.interface.new_socket(name = "Clump Factor", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = clump_settings_panel)
	    clump_factor_socket.default_value = 0.0
	    clump_factor_socket.min_value = 0.0
	    clump_factor_socket.max_value = 1.0
	    clump_factor_socket.subtype = 'FACTOR'
	    clump_factor_socket.attribute_domain = 'POINT'
	    clump_factor_socket.description = "Factor to blend overall hair clumping."
	
	    #Socket Clump Guide Distance
	    clump_guide_distance_socket = facial_hairz.interface.new_socket(name = "Clump Guide Distance", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = clump_settings_panel)
	    clump_guide_distance_socket.default_value = 0.10000000149011612
	    clump_guide_distance_socket.min_value = 0.0
	    clump_guide_distance_socket.max_value = 3.4028234663852886e+38
	    clump_guide_distance_socket.subtype = 'DISTANCE'
	    clump_guide_distance_socket.attribute_domain = 'POINT'
	    clump_guide_distance_socket.description = "Minimum distance between two guides for new guide map."
	
	    #Socket Clump Shape
	    clump_shape_socket = facial_hairz.interface.new_socket(name = "Clump Shape", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = clump_settings_panel)
	    clump_shape_socket.default_value = 0.5
	    clump_shape_socket.min_value = -1.0
	    clump_shape_socket.max_value = 1.0
	    clump_shape_socket.subtype = 'NONE'
	    clump_shape_socket.attribute_domain = 'POINT'
	    clump_shape_socket.description = "Shape of the influence along curves. (0=constant, 0.5=linear)"
	
	    #Socket Clump Tip Spread
	    clump_tip_spread_socket = facial_hairz.interface.new_socket(name = "Clump Tip Spread", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = clump_settings_panel)
	    clump_tip_spread_socket.default_value = 0.0
	    clump_tip_spread_socket.min_value = 0.0
	    clump_tip_spread_socket.max_value = 10.0
	    clump_tip_spread_socket.subtype = 'NONE'
	    clump_tip_spread_socket.attribute_domain = 'POINT'
	    clump_tip_spread_socket.description = "Distance of random spread at the curve tips."
	
	    #Socket Clump Offset
	    clump_offset_socket_1 = facial_hairz.interface.new_socket(name = "Clump Offset", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = clump_settings_panel)
	    clump_offset_socket_1.default_value = 0.0
	    clump_offset_socket_1.min_value = -3.4028234663852886e+38
	    clump_offset_socket_1.max_value = 3.4028234663852886e+38
	    clump_offset_socket_1.subtype = 'DISTANCE'
	    clump_offset_socket_1.attribute_domain = 'POINT'
	    clump_offset_socket_1.description = "Offset of each clump in a random direction."
	
	    #Socket Clump Distance Falloff
	    clump_distance_falloff_socket = facial_hairz.interface.new_socket(name = "Clump Distance Falloff", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = clump_settings_panel)
	    clump_distance_falloff_socket.default_value = 0.0
	    clump_distance_falloff_socket.min_value = 0.0
	    clump_distance_falloff_socket.max_value = 3.4028234663852886e+38
	    clump_distance_falloff_socket.subtype = 'DISTANCE'
	    clump_distance_falloff_socket.attribute_domain = 'POINT'
	    clump_distance_falloff_socket.description = "Falloff distance for the clumping effect. (0 means no falloff)"
	
	    #Socket Clump Distance Threshold
	    clump_distance_threshold_socket = facial_hairz.interface.new_socket(name = "Clump Distance Threshold", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = clump_settings_panel)
	    clump_distance_threshold_socket.default_value = 0.0
	    clump_distance_threshold_socket.min_value = 0.0
	    clump_distance_threshold_socket.max_value = 3.4028234663852886e+38
	    clump_distance_threshold_socket.subtype = 'DISTANCE'
	    clump_distance_threshold_socket.attribute_domain = 'POINT'
	    clump_distance_threshold_socket.description = "Distance threshold for the falloff around the guide."
	
	    #Socket Clump Seed
	    clump_seed_socket = facial_hairz.interface.new_socket(name = "Clump Seed", in_out='INPUT', socket_type = 'NodeSocketInt', parent = clump_settings_panel)
	    clump_seed_socket.default_value = 0
	    clump_seed_socket.min_value = -10000
	    clump_seed_socket.max_value = 10000
	    clump_seed_socket.subtype = 'NONE'
	    clump_seed_socket.attribute_domain = 'POINT'
	    clump_seed_socket.description = "Random seed for hair clumping."
	
	    #Socket Clump Preserve Length
	    clump_preserve_length_socket = facial_hairz.interface.new_socket(name = "Clump Preserve Length", in_out='INPUT', socket_type = 'NodeSocketBool', parent = clump_settings_panel)
	    clump_preserve_length_socket.default_value = False
	    clump_preserve_length_socket.attribute_domain = 'POINT'
	    clump_preserve_length_socket.description = "Preserve each curve's length during deformation."
	
	
	    #Panel Frizz Settings
	    frizz_settings_panel = facial_hairz.interface.new_panel("Frizz Settings", default_closed=True)
	    frizz_settings_panel.description = "Settings for hair frizz."
	    #Socket Frizz Factor
	    frizz_factor_socket = facial_hairz.interface.new_socket(name = "Frizz Factor", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = frizz_settings_panel)
	    frizz_factor_socket.default_value = 0.0
	    frizz_factor_socket.min_value = 0.0
	    frizz_factor_socket.max_value = 1.0
	    frizz_factor_socket.subtype = 'FACTOR'
	    frizz_factor_socket.attribute_domain = 'POINT'
	    frizz_factor_socket.description = "Factor to blend overall hair frizz."
	
	    #Socket Frizz Distance
	    frizz_distance_socket = facial_hairz.interface.new_socket(name = "Frizz Distance", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = frizz_settings_panel)
	    frizz_distance_socket.default_value = 0.009999999776482582
	    frizz_distance_socket.min_value = 0.0
	    frizz_distance_socket.max_value = 3.4028234663852886e+38
	    frizz_distance_socket.subtype = 'DISTANCE'
	    frizz_distance_socket.attribute_domain = 'POINT'
	    frizz_distance_socket.description = "Overall distance factor for the deformation."
	
	    #Socket Frizz Shape
	    frizz_shape_socket = facial_hairz.interface.new_socket(name = "Frizz Shape", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = frizz_settings_panel)
	    frizz_shape_socket.default_value = 0.5
	    frizz_shape_socket.min_value = -1.0
	    frizz_shape_socket.max_value = 1.0
	    frizz_shape_socket.subtype = 'NONE'
	    frizz_shape_socket.attribute_domain = 'POINT'
	    frizz_shape_socket.description = "Shape of the influence along curves. (0=constant, 0.5=linear)"
	
	    #Socket Frizz Seed
	    frizz_seed_socket = facial_hairz.interface.new_socket(name = "Frizz Seed", in_out='INPUT', socket_type = 'NodeSocketInt', parent = frizz_settings_panel)
	    frizz_seed_socket.default_value = 0
	    frizz_seed_socket.min_value = -10000
	    frizz_seed_socket.max_value = 10000
	    frizz_seed_socket.subtype = 'NONE'
	    frizz_seed_socket.attribute_domain = 'POINT'
	    frizz_seed_socket.description = "Random Seed for hair frizz."
	
	    #Socket Frizz Preserve Length
	    frizz_preserve_length_socket = facial_hairz.interface.new_socket(name = "Frizz Preserve Length", in_out='INPUT', socket_type = 'NodeSocketBool', parent = frizz_settings_panel)
	    frizz_preserve_length_socket.default_value = False
	    frizz_preserve_length_socket.attribute_domain = 'POINT'
	    frizz_preserve_length_socket.description = "Preserve each curve's length during deformation."
	
	
	    #Panel Roll Settings
	    roll_settings_panel = facial_hairz.interface.new_panel("Roll Settings", default_closed=True)
	    roll_settings_panel.description = "Settings for hair rolling."
	    #Socket Roll Factor
	    roll_factor_socket = facial_hairz.interface.new_socket(name = "Roll Factor", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = roll_settings_panel)
	    roll_factor_socket.default_value = 0.0
	    roll_factor_socket.min_value = 0.0
	    roll_factor_socket.max_value = 1.0
	    roll_factor_socket.subtype = 'FACTOR'
	    roll_factor_socket.attribute_domain = 'POINT'
	    roll_factor_socket.description = "Factor to blend overall hair rolling."
	
	    #Socket Roll Subdivision
	    roll_subdivision_socket = facial_hairz.interface.new_socket(name = "Roll Subdivision", in_out='INPUT', socket_type = 'NodeSocketInt', parent = roll_settings_panel)
	    roll_subdivision_socket.default_value = 1
	    roll_subdivision_socket.min_value = 0
	    roll_subdivision_socket.max_value = 6
	    roll_subdivision_socket.subtype = 'NONE'
	    roll_subdivision_socket.attribute_domain = 'POINT'
	    roll_subdivision_socket.description = "Subdivision level applied before deformation."
	
	    #Socket Roll Variation Level
	    roll_variation_level_socket = facial_hairz.interface.new_socket(name = "Roll Variation Level", in_out='INPUT', socket_type = 'NodeSocketInt', parent = roll_settings_panel)
	    roll_variation_level_socket.default_value = 10
	    roll_variation_level_socket.min_value = 0
	    roll_variation_level_socket.max_value = 100
	    roll_variation_level_socket.subtype = 'NONE'
	    roll_variation_level_socket.attribute_domain = 'POINT'
	    roll_variation_level_socket.description = "Level of smoothing on the roll path to include shape variation."
	
	    #Socket Roll Length
	    roll_length_socket_1 = facial_hairz.interface.new_socket(name = "Roll Length", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = roll_settings_panel)
	    roll_length_socket_1.default_value = 0.10000000149011612
	    roll_length_socket_1.min_value = 0.0
	    roll_length_socket_1.max_value = 3.4028234663852886e+38
	    roll_length_socket_1.subtype = 'DISTANCE'
	    roll_length_socket_1.attribute_domain = 'POINT'
	    roll_length_socket_1.description = "Length of each curve to be rolled."
	
	    #Socket Roll Radius
	    roll_radius_socket_1 = facial_hairz.interface.new_socket(name = "Roll Radius", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = roll_settings_panel)
	    roll_radius_socket_1.default_value = 0.05000000074505806
	    roll_radius_socket_1.min_value = 0.0
	    roll_radius_socket_1.max_value = 3.4028234663852886e+38
	    roll_radius_socket_1.subtype = 'DISTANCE'
	    roll_radius_socket_1.attribute_domain = 'POINT'
	    roll_radius_socket_1.description = "Radius of the rolls."
	
	    #Socket Roll Depth
	    roll_depth_socket_1 = facial_hairz.interface.new_socket(name = "Roll Depth", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = roll_settings_panel)
	    roll_depth_socket_1.default_value = 0.0
	    roll_depth_socket_1.min_value = -3.4028234663852886e+38
	    roll_depth_socket_1.max_value = 3.4028234663852886e+38
	    roll_depth_socket_1.subtype = 'DISTANCE'
	    roll_depth_socket_1.attribute_domain = 'POINT'
	    roll_depth_socket_1.description = "Depth offset of the roll."
	
	    #Socket Roll Taper
	    roll_taper_socket_1 = facial_hairz.interface.new_socket(name = "Roll Taper", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = roll_settings_panel)
	    roll_taper_socket_1.default_value = 0.0
	    roll_taper_socket_1.min_value = 0.0
	    roll_taper_socket_1.max_value = 1.0
	    roll_taper_socket_1.subtype = 'FACTOR'
	    roll_taper_socket_1.attribute_domain = 'POINT'
	    roll_taper_socket_1.description = "Taper of the roll."
	
	    #Socket Roll Retain Overall Shape
	    roll_retain_overall_shape_socket = facial_hairz.interface.new_socket(name = "Roll Retain Overall Shape", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = roll_settings_panel)
	    roll_retain_overall_shape_socket.default_value = 0.0
	    roll_retain_overall_shape_socket.min_value = 0.0
	    roll_retain_overall_shape_socket.max_value = 1.0
	    roll_retain_overall_shape_socket.subtype = 'FACTOR'
	    roll_retain_overall_shape_socket.attribute_domain = 'POINT'
	    roll_retain_overall_shape_socket.description = "Offset the roll along the original curve to retain shape."
	
	    #Socket Roll Random Orientation
	    roll_random_orientation_socket = facial_hairz.interface.new_socket(name = "Roll Random Orientation", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = roll_settings_panel)
	    roll_random_orientation_socket.default_value = 0.5
	    roll_random_orientation_socket.min_value = 0.0
	    roll_random_orientation_socket.max_value = 1.0
	    roll_random_orientation_socket.subtype = 'FACTOR'
	    roll_random_orientation_socket.attribute_domain = 'POINT'
	    roll_random_orientation_socket.description = "Amount of randomization of the direction of the roll."
	
	    #Socket Roll Seed
	    roll_seed_socket = facial_hairz.interface.new_socket(name = "Roll Seed", in_out='INPUT', socket_type = 'NodeSocketInt', parent = roll_settings_panel)
	    roll_seed_socket.default_value = 0
	    roll_seed_socket.min_value = -10000
	    roll_seed_socket.max_value = 10000
	    roll_seed_socket.subtype = 'NONE'
	    roll_seed_socket.attribute_domain = 'POINT'
	    roll_seed_socket.description = "Random Seed for hair rolling."
	
	    #Socket Roll Preserve Length
	    roll_preserve_length_socket = facial_hairz.interface.new_socket(name = "Roll Preserve Length", in_out='INPUT', socket_type = 'NodeSocketBool', parent = roll_settings_panel)
	    roll_preserve_length_socket.default_value = False
	    roll_preserve_length_socket.attribute_domain = 'POINT'
	    roll_preserve_length_socket.description = "Preserve each curve's length during deformation."
	
	
	    #Panel Mesh Settings
	    mesh_settings_panel = facial_hairz.interface.new_panel("Mesh Settings", default_closed=True)
	    mesh_settings_panel.description = "Settings for mesh hair card."
	    #Socket Use Mesh
	    use_mesh_socket = facial_hairz.interface.new_socket(name = "Use Mesh", in_out='INPUT', socket_type = 'NodeSocketBool', parent = mesh_settings_panel)
	    use_mesh_socket.default_value = False
	    use_mesh_socket.attribute_domain = 'POINT'
	    use_mesh_socket.description = "Convert hair to mesh hair card."
	
	    #Socket Material
	    material_socket_6 = facial_hairz.interface.new_socket(name = "Material", in_out='INPUT', socket_type = 'NodeSocketMaterial', parent = mesh_settings_panel)
	    material_socket_6.attribute_domain = 'POINT'
	    material_socket_6.description = "Material used for mesh."
	
	    #Socket Resolution
	    resolution_socket_5 = facial_hairz.interface.new_socket(name = "Resolution", in_out='INPUT', socket_type = 'NodeSocketInt', parent = mesh_settings_panel)
	    resolution_socket_5.default_value = 0
	    resolution_socket_5.min_value = 2
	    resolution_socket_5.max_value = 512
	    resolution_socket_5.subtype = 'NONE'
	    resolution_socket_5.attribute_domain = 'POINT'
	    resolution_socket_5.description = "Control mesh smoothness by add and removing points along curve."
	
	    #Socket Width
	    width_socket_4 = facial_hairz.interface.new_socket(name = "Width", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = mesh_settings_panel)
	    width_socket_4.default_value = 0.009999999776482582
	    width_socket_4.min_value = 0.0
	    width_socket_4.max_value = 3.4028234663852886e+38
	    width_socket_4.subtype = 'DISTANCE'
	    width_socket_4.attribute_domain = 'POINT'
	    width_socket_4.description = "Width of mesh object."
	
	    #Socket Hair Card Angle
	    hair_card_angle_socket_1 = facial_hairz.interface.new_socket(name = "Hair Card Angle", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = mesh_settings_panel)
	    hair_card_angle_socket_1.default_value = 0.0
	    hair_card_angle_socket_1.min_value = -90.0
	    hair_card_angle_socket_1.max_value = 90.0
	    hair_card_angle_socket_1.subtype = 'ANGLE'
	    hair_card_angle_socket_1.attribute_domain = 'POINT'
	    hair_card_angle_socket_1.description = "Angle used to bend hair card. (Mesh Style=Hair Card)"
	
	
	
	    #initialize facial_hairz nodes
	    #node Group Input
	    group_input_18 = facial_hairz.nodes.new("NodeGroupInput")
	    group_input_18.name = "Group Input"
	    group_input_18.outputs[0].hide = True
	    group_input_18.outputs[1].hide = True
	    group_input_18.outputs[2].hide = True
	    group_input_18.outputs[3].hide = True
	    group_input_18.outputs[4].hide = True
	    group_input_18.outputs[5].hide = True
	    group_input_18.outputs[7].hide = True
	    group_input_18.outputs[8].hide = True
	    group_input_18.outputs[9].hide = True
	    group_input_18.outputs[10].hide = True
	    group_input_18.outputs[11].hide = True
	    group_input_18.outputs[12].hide = True
	    group_input_18.outputs[13].hide = True
	    group_input_18.outputs[14].hide = True
	    group_input_18.outputs[15].hide = True
	    group_input_18.outputs[16].hide = True
	    group_input_18.outputs[17].hide = True
	    group_input_18.outputs[18].hide = True
	    group_input_18.outputs[19].hide = True
	    group_input_18.outputs[20].hide = True
	    group_input_18.outputs[21].hide = True
	    group_input_18.outputs[22].hide = True
	    group_input_18.outputs[23].hide = True
	    group_input_18.outputs[24].hide = True
	    group_input_18.outputs[25].hide = True
	    group_input_18.outputs[26].hide = True
	    group_input_18.outputs[27].hide = True
	    group_input_18.outputs[28].hide = True
	    group_input_18.outputs[29].hide = True
	    group_input_18.outputs[30].hide = True
	    group_input_18.outputs[31].hide = True
	    group_input_18.outputs[32].hide = True
	    group_input_18.outputs[33].hide = True
	    group_input_18.outputs[34].hide = True
	    group_input_18.outputs[35].hide = True
	    group_input_18.outputs[36].hide = True
	    group_input_18.outputs[37].hide = True
	    group_input_18.outputs[38].hide = True
	    group_input_18.outputs[39].hide = True
	    group_input_18.outputs[40].hide = True
	    group_input_18.outputs[41].hide = True
	    group_input_18.outputs[42].hide = True
	    group_input_18.outputs[43].hide = True
	    group_input_18.outputs[44].hide = True
	    group_input_18.outputs[45].hide = True
	    group_input_18.outputs[46].hide = True
	    group_input_18.outputs[47].hide = True
	    group_input_18.outputs[48].hide = True
	    group_input_18.outputs[49].hide = True
	    group_input_18.outputs[50].hide = True
	
	    #node Group Output
	    group_output_22 = facial_hairz.nodes.new("NodeGroupOutput")
	    group_output_22.name = "Group Output"
	    group_output_22.is_active_output = True
	    group_output_22.inputs[1].hide = True
	
	    #node Resample Curve
	    resample_curve_4 = facial_hairz.nodes.new("GeometryNodeResampleCurve")
	    resample_curve_4.name = "Resample Curve"
	    resample_curve_4.keep_last_segment = False
	    resample_curve_4.mode = 'COUNT'
	    resample_curve_4.inputs[1].hide = True
	    resample_curve_4.inputs[3].hide = True
	    #Selection
	    resample_curve_4.inputs[1].default_value = True
	
	    #node Group
	    group_10 = facial_hairz.nodes.new("GeometryNodeGroup")
	    group_10.name = "Group"
	    group_10.node_tree = duplicate_hair_curves
	
	    #node Group.001
	    group_001_9 = facial_hairz.nodes.new("GeometryNodeGroup")
	    group_001_9.name = "Group.001"
	    group_001_9.node_tree = clump_hair_curves
	    group_001_9.inputs[3].hide = True
	    group_001_9.inputs[4].hide = True
	    group_001_9.outputs[1].hide = True
	    #Socket_5
	    group_001_9.inputs[3].default_value = 1.0
	    #Socket_6
	    group_001_9.inputs[4].default_value = True
	
	    #node Group.002
	    group_002_6 = facial_hairz.nodes.new("GeometryNodeGroup")
	    group_002_6.name = "Group.002"
	    group_002_6.node_tree = hair_shrinkwrap
	
	    #node Group Input.001
	    group_input_001_14 = facial_hairz.nodes.new("NodeGroupInput")
	    group_input_001_14.name = "Group Input.001"
	    group_input_001_14.outputs[0].hide = True
	    group_input_001_14.outputs[1].hide = True
	    group_input_001_14.outputs[2].hide = True
	    group_input_001_14.outputs[3].hide = True
	    group_input_001_14.outputs[4].hide = True
	    group_input_001_14.outputs[5].hide = True
	    group_input_001_14.outputs[6].hide = True
	    group_input_001_14.outputs[7].hide = True
	    group_input_001_14.outputs[8].hide = True
	    group_input_001_14.outputs[9].hide = True
	    group_input_001_14.outputs[10].hide = True
	    group_input_001_14.outputs[11].hide = True
	    group_input_001_14.outputs[12].hide = True
	    group_input_001_14.outputs[20].hide = True
	    group_input_001_14.outputs[21].hide = True
	    group_input_001_14.outputs[22].hide = True
	    group_input_001_14.outputs[23].hide = True
	    group_input_001_14.outputs[24].hide = True
	    group_input_001_14.outputs[25].hide = True
	    group_input_001_14.outputs[26].hide = True
	    group_input_001_14.outputs[27].hide = True
	    group_input_001_14.outputs[28].hide = True
	    group_input_001_14.outputs[29].hide = True
	    group_input_001_14.outputs[30].hide = True
	    group_input_001_14.outputs[31].hide = True
	    group_input_001_14.outputs[32].hide = True
	    group_input_001_14.outputs[33].hide = True
	    group_input_001_14.outputs[34].hide = True
	    group_input_001_14.outputs[35].hide = True
	    group_input_001_14.outputs[36].hide = True
	    group_input_001_14.outputs[37].hide = True
	    group_input_001_14.outputs[38].hide = True
	    group_input_001_14.outputs[39].hide = True
	    group_input_001_14.outputs[40].hide = True
	    group_input_001_14.outputs[41].hide = True
	    group_input_001_14.outputs[42].hide = True
	    group_input_001_14.outputs[43].hide = True
	    group_input_001_14.outputs[44].hide = True
	    group_input_001_14.outputs[45].hide = True
	    group_input_001_14.outputs[46].hide = True
	    group_input_001_14.outputs[47].hide = True
	    group_input_001_14.outputs[48].hide = True
	    group_input_001_14.outputs[49].hide = True
	    group_input_001_14.outputs[50].hide = True
	
	    #node Group Input.002
	    group_input_002_13 = facial_hairz.nodes.new("NodeGroupInput")
	    group_input_002_13.name = "Group Input.002"
	    group_input_002_13.outputs[0].hide = True
	    group_input_002_13.outputs[1].hide = True
	    group_input_002_13.outputs[2].hide = True
	    group_input_002_13.outputs[3].hide = True
	    group_input_002_13.outputs[4].hide = True
	    group_input_002_13.outputs[5].hide = True
	    group_input_002_13.outputs[6].hide = True
	    group_input_002_13.outputs[7].hide = True
	    group_input_002_13.outputs[8].hide = True
	    group_input_002_13.outputs[9].hide = True
	    group_input_002_13.outputs[10].hide = True
	    group_input_002_13.outputs[11].hide = True
	    group_input_002_13.outputs[12].hide = True
	    group_input_002_13.outputs[13].hide = True
	    group_input_002_13.outputs[14].hide = True
	    group_input_002_13.outputs[15].hide = True
	    group_input_002_13.outputs[16].hide = True
	    group_input_002_13.outputs[17].hide = True
	    group_input_002_13.outputs[18].hide = True
	    group_input_002_13.outputs[19].hide = True
	    group_input_002_13.outputs[29].hide = True
	    group_input_002_13.outputs[30].hide = True
	    group_input_002_13.outputs[31].hide = True
	    group_input_002_13.outputs[32].hide = True
	    group_input_002_13.outputs[33].hide = True
	    group_input_002_13.outputs[34].hide = True
	    group_input_002_13.outputs[35].hide = True
	    group_input_002_13.outputs[36].hide = True
	    group_input_002_13.outputs[37].hide = True
	    group_input_002_13.outputs[38].hide = True
	    group_input_002_13.outputs[39].hide = True
	    group_input_002_13.outputs[40].hide = True
	    group_input_002_13.outputs[41].hide = True
	    group_input_002_13.outputs[42].hide = True
	    group_input_002_13.outputs[43].hide = True
	    group_input_002_13.outputs[44].hide = True
	    group_input_002_13.outputs[45].hide = True
	    group_input_002_13.outputs[46].hide = True
	    group_input_002_13.outputs[47].hide = True
	    group_input_002_13.outputs[48].hide = True
	    group_input_002_13.outputs[49].hide = True
	    group_input_002_13.outputs[50].hide = True
	
	    #node Group Input.003
	    group_input_003_14 = facial_hairz.nodes.new("NodeGroupInput")
	    group_input_003_14.name = "Group Input.003"
	    group_input_003_14.outputs[0].hide = True
	    group_input_003_14.outputs[2].hide = True
	    group_input_003_14.outputs[3].hide = True
	    group_input_003_14.outputs[4].hide = True
	    group_input_003_14.outputs[5].hide = True
	    group_input_003_14.outputs[6].hide = True
	    group_input_003_14.outputs[7].hide = True
	    group_input_003_14.outputs[8].hide = True
	    group_input_003_14.outputs[9].hide = True
	    group_input_003_14.outputs[10].hide = True
	    group_input_003_14.outputs[12].hide = True
	    group_input_003_14.outputs[13].hide = True
	    group_input_003_14.outputs[14].hide = True
	    group_input_003_14.outputs[15].hide = True
	    group_input_003_14.outputs[16].hide = True
	    group_input_003_14.outputs[17].hide = True
	    group_input_003_14.outputs[18].hide = True
	    group_input_003_14.outputs[19].hide = True
	    group_input_003_14.outputs[20].hide = True
	    group_input_003_14.outputs[21].hide = True
	    group_input_003_14.outputs[22].hide = True
	    group_input_003_14.outputs[23].hide = True
	    group_input_003_14.outputs[24].hide = True
	    group_input_003_14.outputs[25].hide = True
	    group_input_003_14.outputs[26].hide = True
	    group_input_003_14.outputs[27].hide = True
	    group_input_003_14.outputs[28].hide = True
	    group_input_003_14.outputs[29].hide = True
	    group_input_003_14.outputs[30].hide = True
	    group_input_003_14.outputs[31].hide = True
	    group_input_003_14.outputs[32].hide = True
	    group_input_003_14.outputs[33].hide = True
	    group_input_003_14.outputs[34].hide = True
	    group_input_003_14.outputs[35].hide = True
	    group_input_003_14.outputs[36].hide = True
	    group_input_003_14.outputs[37].hide = True
	    group_input_003_14.outputs[38].hide = True
	    group_input_003_14.outputs[39].hide = True
	    group_input_003_14.outputs[40].hide = True
	    group_input_003_14.outputs[41].hide = True
	    group_input_003_14.outputs[42].hide = True
	    group_input_003_14.outputs[43].hide = True
	    group_input_003_14.outputs[44].hide = True
	    group_input_003_14.outputs[45].hide = True
	    group_input_003_14.outputs[46].hide = True
	    group_input_003_14.outputs[47].hide = True
	    group_input_003_14.outputs[48].hide = True
	    group_input_003_14.outputs[49].hide = True
	    group_input_003_14.outputs[50].hide = True
	
	    #node Set Material
	    set_material_4 = facial_hairz.nodes.new("GeometryNodeSetMaterial")
	    set_material_4.name = "Set Material"
	    set_material_4.inputs[1].hide = True
	    #Selection
	    set_material_4.inputs[1].default_value = True
	
	    #node Group Input.005
	    group_input_005_10 = facial_hairz.nodes.new("NodeGroupInput")
	    group_input_005_10.name = "Group Input.005"
	    group_input_005_10.outputs[0].hide = True
	    group_input_005_10.outputs[1].hide = True
	    group_input_005_10.outputs[3].hide = True
	    group_input_005_10.outputs[4].hide = True
	    group_input_005_10.outputs[5].hide = True
	    group_input_005_10.outputs[6].hide = True
	    group_input_005_10.outputs[7].hide = True
	    group_input_005_10.outputs[8].hide = True
	    group_input_005_10.outputs[9].hide = True
	    group_input_005_10.outputs[10].hide = True
	    group_input_005_10.outputs[11].hide = True
	    group_input_005_10.outputs[12].hide = True
	    group_input_005_10.outputs[13].hide = True
	    group_input_005_10.outputs[14].hide = True
	    group_input_005_10.outputs[15].hide = True
	    group_input_005_10.outputs[16].hide = True
	    group_input_005_10.outputs[17].hide = True
	    group_input_005_10.outputs[18].hide = True
	    group_input_005_10.outputs[19].hide = True
	    group_input_005_10.outputs[20].hide = True
	    group_input_005_10.outputs[21].hide = True
	    group_input_005_10.outputs[22].hide = True
	    group_input_005_10.outputs[23].hide = True
	    group_input_005_10.outputs[24].hide = True
	    group_input_005_10.outputs[25].hide = True
	    group_input_005_10.outputs[26].hide = True
	    group_input_005_10.outputs[27].hide = True
	    group_input_005_10.outputs[28].hide = True
	    group_input_005_10.outputs[29].hide = True
	    group_input_005_10.outputs[30].hide = True
	    group_input_005_10.outputs[31].hide = True
	    group_input_005_10.outputs[32].hide = True
	    group_input_005_10.outputs[33].hide = True
	    group_input_005_10.outputs[34].hide = True
	    group_input_005_10.outputs[35].hide = True
	    group_input_005_10.outputs[36].hide = True
	    group_input_005_10.outputs[37].hide = True
	    group_input_005_10.outputs[38].hide = True
	    group_input_005_10.outputs[39].hide = True
	    group_input_005_10.outputs[40].hide = True
	    group_input_005_10.outputs[41].hide = True
	    group_input_005_10.outputs[42].hide = True
	    group_input_005_10.outputs[43].hide = True
	    group_input_005_10.outputs[44].hide = True
	    group_input_005_10.outputs[45].hide = True
	    group_input_005_10.outputs[46].hide = True
	    group_input_005_10.outputs[47].hide = True
	    group_input_005_10.outputs[48].hide = True
	    group_input_005_10.outputs[49].hide = True
	    group_input_005_10.outputs[50].hide = True
	
	    #node Set Position
	    set_position_7 = facial_hairz.nodes.new("GeometryNodeSetPosition")
	    set_position_7.name = "Set Position"
	    set_position_7.hide = True
	    #Selection
	    set_position_7.inputs[1].default_value = True
	    #Offset
	    set_position_7.inputs[3].default_value = (0.0, 0.0, 0.0)
	
	    #node Vector Math
	    vector_math_11 = facial_hairz.nodes.new("ShaderNodeVectorMath")
	    vector_math_11.name = "Vector Math"
	    vector_math_11.hide = True
	    vector_math_11.operation = 'MULTIPLY'
	    #Vector_001
	    vector_math_11.inputs[1].default_value = (-1.0, 1.0, 1.0)
	
	    #node Capture Attribute
	    capture_attribute_9 = facial_hairz.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_9.name = "Capture Attribute"
	    capture_attribute_9.hide = True
	    capture_attribute_9.active_index = 0
	    capture_attribute_9.capture_items.clear()
	    capture_attribute_9.capture_items.new('FLOAT', "Position")
	    capture_attribute_9.capture_items["Position"].data_type = 'FLOAT_VECTOR'
	    capture_attribute_9.domain = 'POINT'
	
	    #node Position
	    position_5 = facial_hairz.nodes.new("GeometryNodeInputPosition")
	    position_5.name = "Position"
	    position_5.hide = True
	
	    #node Switch
	    switch_15 = facial_hairz.nodes.new("GeometryNodeSwitch")
	    switch_15.name = "Switch"
	    switch_15.hide = True
	    switch_15.input_type = 'GEOMETRY'
	
	    #node Join Geometry
	    join_geometry_7 = facial_hairz.nodes.new("GeometryNodeJoinGeometry")
	    join_geometry_7.name = "Join Geometry"
	    join_geometry_7.hide = True
	
	    #node Frame
	    frame_11 = facial_hairz.nodes.new("NodeFrame")
	    frame_11.label = "Mirror"
	    frame_11.name = "Frame"
	    frame_11.label_size = 20
	    frame_11.shrink = True
	
	    #node Group Input.006
	    group_input_006_8 = facial_hairz.nodes.new("NodeGroupInput")
	    group_input_006_8.name = "Group Input.006"
	    group_input_006_8.outputs[0].hide = True
	    group_input_006_8.outputs[1].hide = True
	    group_input_006_8.outputs[2].hide = True
	    group_input_006_8.outputs[4].hide = True
	    group_input_006_8.outputs[5].hide = True
	    group_input_006_8.outputs[6].hide = True
	    group_input_006_8.outputs[7].hide = True
	    group_input_006_8.outputs[8].hide = True
	    group_input_006_8.outputs[9].hide = True
	    group_input_006_8.outputs[10].hide = True
	    group_input_006_8.outputs[11].hide = True
	    group_input_006_8.outputs[12].hide = True
	    group_input_006_8.outputs[13].hide = True
	    group_input_006_8.outputs[14].hide = True
	    group_input_006_8.outputs[15].hide = True
	    group_input_006_8.outputs[16].hide = True
	    group_input_006_8.outputs[17].hide = True
	    group_input_006_8.outputs[18].hide = True
	    group_input_006_8.outputs[19].hide = True
	    group_input_006_8.outputs[20].hide = True
	    group_input_006_8.outputs[21].hide = True
	    group_input_006_8.outputs[22].hide = True
	    group_input_006_8.outputs[23].hide = True
	    group_input_006_8.outputs[24].hide = True
	    group_input_006_8.outputs[25].hide = True
	    group_input_006_8.outputs[26].hide = True
	    group_input_006_8.outputs[27].hide = True
	    group_input_006_8.outputs[28].hide = True
	    group_input_006_8.outputs[29].hide = True
	    group_input_006_8.outputs[30].hide = True
	    group_input_006_8.outputs[31].hide = True
	    group_input_006_8.outputs[32].hide = True
	    group_input_006_8.outputs[33].hide = True
	    group_input_006_8.outputs[34].hide = True
	    group_input_006_8.outputs[35].hide = True
	    group_input_006_8.outputs[36].hide = True
	    group_input_006_8.outputs[37].hide = True
	    group_input_006_8.outputs[38].hide = True
	    group_input_006_8.outputs[39].hide = True
	    group_input_006_8.outputs[40].hide = True
	    group_input_006_8.outputs[41].hide = True
	    group_input_006_8.outputs[42].hide = True
	    group_input_006_8.outputs[43].hide = True
	    group_input_006_8.outputs[44].hide = True
	    group_input_006_8.outputs[45].hide = True
	    group_input_006_8.outputs[46].hide = True
	    group_input_006_8.outputs[47].hide = True
	    group_input_006_8.outputs[48].hide = True
	    group_input_006_8.outputs[49].hide = True
	    group_input_006_8.outputs[50].hide = True
	
	    #node Reroute
	    reroute_18 = facial_hairz.nodes.new("NodeReroute")
	    reroute_18.name = "Reroute"
	    reroute_18.socket_idname = "NodeSocketGeometry"
	    #node Reroute.001
	    reroute_001_14 = facial_hairz.nodes.new("NodeReroute")
	    reroute_001_14.name = "Reroute.001"
	    reroute_001_14.socket_idname = "NodeSocketGeometry"
	    #node Reroute.002
	    reroute_002_13 = facial_hairz.nodes.new("NodeReroute")
	    reroute_002_13.name = "Reroute.002"
	    reroute_002_13.socket_idname = "NodeSocketGeometry"
	    #node Reroute.003
	    reroute_003_13 = facial_hairz.nodes.new("NodeReroute")
	    reroute_003_13.name = "Reroute.003"
	    reroute_003_13.socket_idname = "NodeSocketGeometry"
	    #node Reroute.004
	    reroute_004_13 = facial_hairz.nodes.new("NodeReroute")
	    reroute_004_13.name = "Reroute.004"
	    reroute_004_13.socket_idname = "NodeSocketGeometry"
	    #node Reroute.005
	    reroute_005_11 = facial_hairz.nodes.new("NodeReroute")
	    reroute_005_11.name = "Reroute.005"
	    reroute_005_11.socket_idname = "NodeSocketGeometry"
	    #node Reroute.044
	    reroute_044 = facial_hairz.nodes.new("NodeReroute")
	    reroute_044.name = "Reroute.044"
	    reroute_044.socket_idname = "NodeSocketGeometry"
	    #node Switch.002
	    switch_002_6 = facial_hairz.nodes.new("GeometryNodeSwitch")
	    switch_002_6.name = "Switch.002"
	    switch_002_6.hide = True
	    switch_002_6.input_type = 'GEOMETRY'
	
	    #node Compare.008
	    compare_008_1 = facial_hairz.nodes.new("FunctionNodeCompare")
	    compare_008_1.name = "Compare.008"
	    compare_008_1.hide = True
	    compare_008_1.data_type = 'FLOAT'
	    compare_008_1.mode = 'ELEMENT'
	    compare_008_1.operation = 'EQUAL'
	    #B
	    compare_008_1.inputs[1].default_value = 0.0
	    #Epsilon
	    compare_008_1.inputs[12].default_value = 0.0
	
	    #node Group Input.024
	    group_input_024 = facial_hairz.nodes.new("NodeGroupInput")
	    group_input_024.name = "Group Input.024"
	    group_input_024.outputs[0].hide = True
	    group_input_024.outputs[1].hide = True
	    group_input_024.outputs[2].hide = True
	    group_input_024.outputs[3].hide = True
	    group_input_024.outputs[4].hide = True
	    group_input_024.outputs[5].hide = True
	    group_input_024.outputs[6].hide = True
	    group_input_024.outputs[7].hide = True
	    group_input_024.outputs[8].hide = True
	    group_input_024.outputs[9].hide = True
	    group_input_024.outputs[10].hide = True
	    group_input_024.outputs[11].hide = True
	    group_input_024.outputs[12].hide = True
	    group_input_024.outputs[13].hide = True
	    group_input_024.outputs[14].hide = True
	    group_input_024.outputs[15].hide = True
	    group_input_024.outputs[16].hide = True
	    group_input_024.outputs[17].hide = True
	    group_input_024.outputs[18].hide = True
	    group_input_024.outputs[19].hide = True
	    group_input_024.outputs[21].hide = True
	    group_input_024.outputs[22].hide = True
	    group_input_024.outputs[23].hide = True
	    group_input_024.outputs[24].hide = True
	    group_input_024.outputs[25].hide = True
	    group_input_024.outputs[26].hide = True
	    group_input_024.outputs[27].hide = True
	    group_input_024.outputs[28].hide = True
	    group_input_024.outputs[29].hide = True
	    group_input_024.outputs[30].hide = True
	    group_input_024.outputs[31].hide = True
	    group_input_024.outputs[32].hide = True
	    group_input_024.outputs[33].hide = True
	    group_input_024.outputs[34].hide = True
	    group_input_024.outputs[35].hide = True
	    group_input_024.outputs[36].hide = True
	    group_input_024.outputs[37].hide = True
	    group_input_024.outputs[38].hide = True
	    group_input_024.outputs[39].hide = True
	    group_input_024.outputs[40].hide = True
	    group_input_024.outputs[41].hide = True
	    group_input_024.outputs[42].hide = True
	    group_input_024.outputs[43].hide = True
	    group_input_024.outputs[44].hide = True
	    group_input_024.outputs[45].hide = True
	    group_input_024.outputs[46].hide = True
	    group_input_024.outputs[47].hide = True
	    group_input_024.outputs[48].hide = True
	    group_input_024.outputs[49].hide = True
	    group_input_024.outputs[50].hide = True
	
	    #node Reroute.054
	    reroute_054 = facial_hairz.nodes.new("NodeReroute")
	    reroute_054.name = "Reroute.054"
	    reroute_054.socket_idname = "NodeSocketGeometry"
	    #node Reroute.055
	    reroute_055 = facial_hairz.nodes.new("NodeReroute")
	    reroute_055.name = "Reroute.055"
	    reroute_055.socket_idname = "NodeSocketGeometry"
	    #node Reroute.057
	    reroute_057 = facial_hairz.nodes.new("NodeReroute")
	    reroute_057.name = "Reroute.057"
	    reroute_057.socket_idname = "NodeSocketGeometry"
	    #node Group Input.008
	    group_input_008_7 = facial_hairz.nodes.new("NodeGroupInput")
	    group_input_008_7.name = "Group Input.008"
	    group_input_008_7.outputs[0].hide = True
	    group_input_008_7.outputs[2].hide = True
	    group_input_008_7.outputs[3].hide = True
	    group_input_008_7.outputs[4].hide = True
	    group_input_008_7.outputs[5].hide = True
	    group_input_008_7.outputs[6].hide = True
	    group_input_008_7.outputs[7].hide = True
	    group_input_008_7.outputs[8].hide = True
	    group_input_008_7.outputs[9].hide = True
	    group_input_008_7.outputs[10].hide = True
	    group_input_008_7.outputs[11].hide = True
	    group_input_008_7.outputs[12].hide = True
	    group_input_008_7.outputs[13].hide = True
	    group_input_008_7.outputs[14].hide = True
	    group_input_008_7.outputs[15].hide = True
	    group_input_008_7.outputs[16].hide = True
	    group_input_008_7.outputs[17].hide = True
	    group_input_008_7.outputs[18].hide = True
	    group_input_008_7.outputs[19].hide = True
	    group_input_008_7.outputs[20].hide = True
	    group_input_008_7.outputs[21].hide = True
	    group_input_008_7.outputs[22].hide = True
	    group_input_008_7.outputs[23].hide = True
	    group_input_008_7.outputs[24].hide = True
	    group_input_008_7.outputs[25].hide = True
	    group_input_008_7.outputs[26].hide = True
	    group_input_008_7.outputs[27].hide = True
	    group_input_008_7.outputs[28].hide = True
	    group_input_008_7.outputs[29].hide = True
	    group_input_008_7.outputs[30].hide = True
	    group_input_008_7.outputs[31].hide = True
	    group_input_008_7.outputs[32].hide = True
	    group_input_008_7.outputs[33].hide = True
	    group_input_008_7.outputs[34].hide = True
	    group_input_008_7.outputs[35].hide = True
	    group_input_008_7.outputs[36].hide = True
	    group_input_008_7.outputs[37].hide = True
	    group_input_008_7.outputs[38].hide = True
	    group_input_008_7.outputs[39].hide = True
	    group_input_008_7.outputs[40].hide = True
	    group_input_008_7.outputs[41].hide = True
	    group_input_008_7.outputs[42].hide = True
	    group_input_008_7.outputs[43].hide = True
	    group_input_008_7.outputs[44].hide = True
	    group_input_008_7.outputs[45].hide = True
	    group_input_008_7.outputs[46].hide = True
	    group_input_008_7.outputs[47].hide = True
	    group_input_008_7.outputs[48].hide = True
	    group_input_008_7.outputs[49].hide = True
	    group_input_008_7.outputs[50].hide = True
	
	    #node Group.008
	    group_008 = facial_hairz.nodes.new("GeometryNodeGroup")
	    group_008.name = "Group.008"
	    group_008.node_tree = hair_curve_strip
	    group_008.inputs[5].hide = True
	    #Socket_6
	    group_008.inputs[5].default_value = 1.0
	
	    #node Group Input.025
	    group_input_025 = facial_hairz.nodes.new("NodeGroupInput")
	    group_input_025.name = "Group Input.025"
	    group_input_025.outputs[0].hide = True
	    group_input_025.outputs[1].hide = True
	    group_input_025.outputs[2].hide = True
	    group_input_025.outputs[3].hide = True
	    group_input_025.outputs[5].hide = True
	    group_input_025.outputs[6].hide = True
	    group_input_025.outputs[7].hide = True
	    group_input_025.outputs[8].hide = True
	    group_input_025.outputs[9].hide = True
	    group_input_025.outputs[10].hide = True
	    group_input_025.outputs[11].hide = True
	    group_input_025.outputs[12].hide = True
	    group_input_025.outputs[13].hide = True
	    group_input_025.outputs[14].hide = True
	    group_input_025.outputs[15].hide = True
	    group_input_025.outputs[16].hide = True
	    group_input_025.outputs[17].hide = True
	    group_input_025.outputs[18].hide = True
	    group_input_025.outputs[19].hide = True
	    group_input_025.outputs[20].hide = True
	    group_input_025.outputs[21].hide = True
	    group_input_025.outputs[22].hide = True
	    group_input_025.outputs[23].hide = True
	    group_input_025.outputs[24].hide = True
	    group_input_025.outputs[25].hide = True
	    group_input_025.outputs[26].hide = True
	    group_input_025.outputs[27].hide = True
	    group_input_025.outputs[28].hide = True
	    group_input_025.outputs[29].hide = True
	    group_input_025.outputs[30].hide = True
	    group_input_025.outputs[31].hide = True
	    group_input_025.outputs[32].hide = True
	    group_input_025.outputs[33].hide = True
	    group_input_025.outputs[34].hide = True
	    group_input_025.outputs[35].hide = True
	    group_input_025.outputs[36].hide = True
	    group_input_025.outputs[37].hide = True
	    group_input_025.outputs[38].hide = True
	    group_input_025.outputs[39].hide = True
	    group_input_025.outputs[40].hide = True
	    group_input_025.outputs[41].hide = True
	    group_input_025.outputs[42].hide = True
	    group_input_025.outputs[43].hide = True
	    group_input_025.outputs[44].hide = True
	    group_input_025.outputs[45].hide = True
	    group_input_025.outputs[46].hide = True
	    group_input_025.outputs[47].hide = True
	    group_input_025.outputs[48].hide = True
	    group_input_025.outputs[49].hide = True
	    group_input_025.outputs[50].hide = True
	
	    #node Group Input.026
	    group_input_026 = facial_hairz.nodes.new("NodeGroupInput")
	    group_input_026.name = "Group Input.026"
	    group_input_026.outputs[0].hide = True
	    group_input_026.outputs[1].hide = True
	    group_input_026.outputs[2].hide = True
	    group_input_026.outputs[3].hide = True
	    group_input_026.outputs[4].hide = True
	    group_input_026.outputs[6].hide = True
	    group_input_026.outputs[7].hide = True
	    group_input_026.outputs[8].hide = True
	    group_input_026.outputs[9].hide = True
	    group_input_026.outputs[10].hide = True
	    group_input_026.outputs[11].hide = True
	    group_input_026.outputs[12].hide = True
	    group_input_026.outputs[13].hide = True
	    group_input_026.outputs[14].hide = True
	    group_input_026.outputs[15].hide = True
	    group_input_026.outputs[16].hide = True
	    group_input_026.outputs[17].hide = True
	    group_input_026.outputs[18].hide = True
	    group_input_026.outputs[19].hide = True
	    group_input_026.outputs[20].hide = True
	    group_input_026.outputs[21].hide = True
	    group_input_026.outputs[22].hide = True
	    group_input_026.outputs[23].hide = True
	    group_input_026.outputs[24].hide = True
	    group_input_026.outputs[25].hide = True
	    group_input_026.outputs[26].hide = True
	    group_input_026.outputs[27].hide = True
	    group_input_026.outputs[28].hide = True
	    group_input_026.outputs[29].hide = True
	    group_input_026.outputs[30].hide = True
	    group_input_026.outputs[31].hide = True
	    group_input_026.outputs[32].hide = True
	    group_input_026.outputs[33].hide = True
	    group_input_026.outputs[34].hide = True
	    group_input_026.outputs[35].hide = True
	    group_input_026.outputs[36].hide = True
	    group_input_026.outputs[37].hide = True
	    group_input_026.outputs[38].hide = True
	    group_input_026.outputs[39].hide = True
	    group_input_026.outputs[40].hide = True
	    group_input_026.outputs[41].hide = True
	    group_input_026.outputs[42].hide = True
	    group_input_026.outputs[43].hide = True
	    group_input_026.outputs[44].hide = True
	    group_input_026.outputs[45].hide = True
	    group_input_026.outputs[46].hide = True
	    group_input_026.outputs[47].hide = True
	    group_input_026.outputs[48].hide = True
	    group_input_026.outputs[49].hide = True
	    group_input_026.outputs[50].hide = True
	
	    #node Group Input.010
	    group_input_010_4 = facial_hairz.nodes.new("NodeGroupInput")
	    group_input_010_4.name = "Group Input.010"
	    group_input_010_4.outputs[0].hide = True
	    group_input_010_4.outputs[1].hide = True
	    group_input_010_4.outputs[2].hide = True
	    group_input_010_4.outputs[3].hide = True
	    group_input_010_4.outputs[4].hide = True
	    group_input_010_4.outputs[5].hide = True
	    group_input_010_4.outputs[6].hide = True
	    group_input_010_4.outputs[7].hide = True
	    group_input_010_4.outputs[8].hide = True
	    group_input_010_4.outputs[9].hide = True
	    group_input_010_4.outputs[10].hide = True
	    group_input_010_4.outputs[11].hide = True
	    group_input_010_4.outputs[13].hide = True
	    group_input_010_4.outputs[14].hide = True
	    group_input_010_4.outputs[15].hide = True
	    group_input_010_4.outputs[16].hide = True
	    group_input_010_4.outputs[17].hide = True
	    group_input_010_4.outputs[18].hide = True
	    group_input_010_4.outputs[19].hide = True
	    group_input_010_4.outputs[20].hide = True
	    group_input_010_4.outputs[21].hide = True
	    group_input_010_4.outputs[22].hide = True
	    group_input_010_4.outputs[23].hide = True
	    group_input_010_4.outputs[24].hide = True
	    group_input_010_4.outputs[25].hide = True
	    group_input_010_4.outputs[26].hide = True
	    group_input_010_4.outputs[27].hide = True
	    group_input_010_4.outputs[28].hide = True
	    group_input_010_4.outputs[29].hide = True
	    group_input_010_4.outputs[30].hide = True
	    group_input_010_4.outputs[31].hide = True
	    group_input_010_4.outputs[32].hide = True
	    group_input_010_4.outputs[33].hide = True
	    group_input_010_4.outputs[34].hide = True
	    group_input_010_4.outputs[35].hide = True
	    group_input_010_4.outputs[36].hide = True
	    group_input_010_4.outputs[37].hide = True
	    group_input_010_4.outputs[38].hide = True
	    group_input_010_4.outputs[39].hide = True
	    group_input_010_4.outputs[40].hide = True
	    group_input_010_4.outputs[41].hide = True
	    group_input_010_4.outputs[42].hide = True
	    group_input_010_4.outputs[43].hide = True
	    group_input_010_4.outputs[44].hide = True
	    group_input_010_4.outputs[45].hide = True
	    group_input_010_4.outputs[46].hide = True
	    group_input_010_4.outputs[47].hide = True
	    group_input_010_4.outputs[48].hide = True
	    group_input_010_4.outputs[49].hide = True
	    group_input_010_4.outputs[50].hide = True
	
	    #node Group Input.015
	    group_input_015_1 = facial_hairz.nodes.new("NodeGroupInput")
	    group_input_015_1.name = "Group Input.015"
	    group_input_015_1.outputs[0].hide = True
	    group_input_015_1.outputs[1].hide = True
	    group_input_015_1.outputs[2].hide = True
	    group_input_015_1.outputs[3].hide = True
	    group_input_015_1.outputs[4].hide = True
	    group_input_015_1.outputs[5].hide = True
	    group_input_015_1.outputs[6].hide = True
	    group_input_015_1.outputs[8].hide = True
	    group_input_015_1.outputs[9].hide = True
	    group_input_015_1.outputs[10].hide = True
	    group_input_015_1.outputs[11].hide = True
	    group_input_015_1.outputs[12].hide = True
	    group_input_015_1.outputs[13].hide = True
	    group_input_015_1.outputs[14].hide = True
	    group_input_015_1.outputs[15].hide = True
	    group_input_015_1.outputs[16].hide = True
	    group_input_015_1.outputs[17].hide = True
	    group_input_015_1.outputs[18].hide = True
	    group_input_015_1.outputs[19].hide = True
	    group_input_015_1.outputs[20].hide = True
	    group_input_015_1.outputs[21].hide = True
	    group_input_015_1.outputs[22].hide = True
	    group_input_015_1.outputs[23].hide = True
	    group_input_015_1.outputs[24].hide = True
	    group_input_015_1.outputs[25].hide = True
	    group_input_015_1.outputs[26].hide = True
	    group_input_015_1.outputs[27].hide = True
	    group_input_015_1.outputs[28].hide = True
	    group_input_015_1.outputs[29].hide = True
	    group_input_015_1.outputs[30].hide = True
	    group_input_015_1.outputs[31].hide = True
	    group_input_015_1.outputs[32].hide = True
	    group_input_015_1.outputs[33].hide = True
	    group_input_015_1.outputs[34].hide = True
	    group_input_015_1.outputs[35].hide = True
	    group_input_015_1.outputs[36].hide = True
	    group_input_015_1.outputs[37].hide = True
	    group_input_015_1.outputs[38].hide = True
	    group_input_015_1.outputs[39].hide = True
	    group_input_015_1.outputs[40].hide = True
	    group_input_015_1.outputs[41].hide = True
	    group_input_015_1.outputs[42].hide = True
	    group_input_015_1.outputs[43].hide = True
	    group_input_015_1.outputs[44].hide = True
	    group_input_015_1.outputs[45].hide = True
	    group_input_015_1.outputs[46].hide = True
	    group_input_015_1.outputs[47].hide = True
	    group_input_015_1.outputs[48].hide = True
	    group_input_015_1.outputs[49].hide = True
	    group_input_015_1.outputs[50].hide = True
	
	    #node Group.004
	    group_004_2 = facial_hairz.nodes.new("GeometryNodeGroup")
	    group_004_2.name = "Group.004"
	    group_004_2.node_tree = frizz_hair_curves
	    #Socket_3
	    group_004_2.inputs[1].default_value = True
	
	    #node Group Input.007
	    group_input_007_8 = facial_hairz.nodes.new("NodeGroupInput")
	    group_input_007_8.name = "Group Input.007"
	    group_input_007_8.outputs[0].hide = True
	    group_input_007_8.outputs[1].hide = True
	    group_input_007_8.outputs[2].hide = True
	    group_input_007_8.outputs[3].hide = True
	    group_input_007_8.outputs[4].hide = True
	    group_input_007_8.outputs[5].hide = True
	    group_input_007_8.outputs[6].hide = True
	    group_input_007_8.outputs[7].hide = True
	    group_input_007_8.outputs[8].hide = True
	    group_input_007_8.outputs[9].hide = True
	    group_input_007_8.outputs[10].hide = True
	    group_input_007_8.outputs[11].hide = True
	    group_input_007_8.outputs[12].hide = True
	    group_input_007_8.outputs[13].hide = True
	    group_input_007_8.outputs[14].hide = True
	    group_input_007_8.outputs[15].hide = True
	    group_input_007_8.outputs[16].hide = True
	    group_input_007_8.outputs[17].hide = True
	    group_input_007_8.outputs[18].hide = True
	    group_input_007_8.outputs[19].hide = True
	    group_input_007_8.outputs[20].hide = True
	    group_input_007_8.outputs[21].hide = True
	    group_input_007_8.outputs[22].hide = True
	    group_input_007_8.outputs[23].hide = True
	    group_input_007_8.outputs[24].hide = True
	    group_input_007_8.outputs[25].hide = True
	    group_input_007_8.outputs[26].hide = True
	    group_input_007_8.outputs[27].hide = True
	    group_input_007_8.outputs[28].hide = True
	    group_input_007_8.outputs[34].hide = True
	    group_input_007_8.outputs[35].hide = True
	    group_input_007_8.outputs[36].hide = True
	    group_input_007_8.outputs[37].hide = True
	    group_input_007_8.outputs[38].hide = True
	    group_input_007_8.outputs[39].hide = True
	    group_input_007_8.outputs[40].hide = True
	    group_input_007_8.outputs[41].hide = True
	    group_input_007_8.outputs[42].hide = True
	    group_input_007_8.outputs[43].hide = True
	    group_input_007_8.outputs[44].hide = True
	    group_input_007_8.outputs[45].hide = True
	    group_input_007_8.outputs[46].hide = True
	    group_input_007_8.outputs[47].hide = True
	    group_input_007_8.outputs[48].hide = True
	    group_input_007_8.outputs[49].hide = True
	    group_input_007_8.outputs[50].hide = True
	
	    #node Switch.001
	    switch_001_11 = facial_hairz.nodes.new("GeometryNodeSwitch")
	    switch_001_11.name = "Switch.001"
	    switch_001_11.hide = True
	    switch_001_11.input_type = 'GEOMETRY'
	
	    #node Group Input.011
	    group_input_011_2 = facial_hairz.nodes.new("NodeGroupInput")
	    group_input_011_2.name = "Group Input.011"
	    group_input_011_2.outputs[0].hide = True
	    group_input_011_2.outputs[1].hide = True
	    group_input_011_2.outputs[2].hide = True
	    group_input_011_2.outputs[3].hide = True
	    group_input_011_2.outputs[4].hide = True
	    group_input_011_2.outputs[5].hide = True
	    group_input_011_2.outputs[6].hide = True
	    group_input_011_2.outputs[7].hide = True
	    group_input_011_2.outputs[8].hide = True
	    group_input_011_2.outputs[9].hide = True
	    group_input_011_2.outputs[10].hide = True
	    group_input_011_2.outputs[11].hide = True
	    group_input_011_2.outputs[12].hide = True
	    group_input_011_2.outputs[13].hide = True
	    group_input_011_2.outputs[14].hide = True
	    group_input_011_2.outputs[15].hide = True
	    group_input_011_2.outputs[16].hide = True
	    group_input_011_2.outputs[17].hide = True
	    group_input_011_2.outputs[18].hide = True
	    group_input_011_2.outputs[19].hide = True
	    group_input_011_2.outputs[20].hide = True
	    group_input_011_2.outputs[21].hide = True
	    group_input_011_2.outputs[22].hide = True
	    group_input_011_2.outputs[23].hide = True
	    group_input_011_2.outputs[24].hide = True
	    group_input_011_2.outputs[25].hide = True
	    group_input_011_2.outputs[26].hide = True
	    group_input_011_2.outputs[27].hide = True
	    group_input_011_2.outputs[28].hide = True
	    group_input_011_2.outputs[30].hide = True
	    group_input_011_2.outputs[31].hide = True
	    group_input_011_2.outputs[32].hide = True
	    group_input_011_2.outputs[33].hide = True
	    group_input_011_2.outputs[34].hide = True
	    group_input_011_2.outputs[35].hide = True
	    group_input_011_2.outputs[36].hide = True
	    group_input_011_2.outputs[37].hide = True
	    group_input_011_2.outputs[38].hide = True
	    group_input_011_2.outputs[39].hide = True
	    group_input_011_2.outputs[40].hide = True
	    group_input_011_2.outputs[41].hide = True
	    group_input_011_2.outputs[42].hide = True
	    group_input_011_2.outputs[43].hide = True
	    group_input_011_2.outputs[44].hide = True
	    group_input_011_2.outputs[45].hide = True
	    group_input_011_2.outputs[46].hide = True
	    group_input_011_2.outputs[47].hide = True
	    group_input_011_2.outputs[48].hide = True
	    group_input_011_2.outputs[49].hide = True
	    group_input_011_2.outputs[50].hide = True
	
	    #node Compare
	    compare_14 = facial_hairz.nodes.new("FunctionNodeCompare")
	    compare_14.name = "Compare"
	    compare_14.hide = True
	    compare_14.data_type = 'FLOAT'
	    compare_14.mode = 'ELEMENT'
	    compare_14.operation = 'EQUAL'
	    #B
	    compare_14.inputs[1].default_value = 0.0
	    #Epsilon
	    compare_14.inputs[12].default_value = 0.0
	
	    #node Reroute.006
	    reroute_006_10 = facial_hairz.nodes.new("NodeReroute")
	    reroute_006_10.name = "Reroute.006"
	    reroute_006_10.socket_idname = "NodeSocketGeometry"
	    #node Group.005
	    group_005_4 = facial_hairz.nodes.new("GeometryNodeGroup")
	    group_005_4.name = "Group.005"
	    group_005_4.node_tree = roll_hair_curves
	    #Socket_10
	    group_005_4.inputs[9].default_value = (0.0, 0.0, 0.0)
	
	    #node Reroute.007
	    reroute_007_10 = facial_hairz.nodes.new("NodeReroute")
	    reroute_007_10.name = "Reroute.007"
	    reroute_007_10.socket_idname = "NodeSocketGeometry"
	    #node Switch.003
	    switch_003_7 = facial_hairz.nodes.new("GeometryNodeSwitch")
	    switch_003_7.name = "Switch.003"
	    switch_003_7.hide = True
	    switch_003_7.input_type = 'GEOMETRY'
	
	    #node Group Input.012
	    group_input_012_3 = facial_hairz.nodes.new("NodeGroupInput")
	    group_input_012_3.name = "Group Input.012"
	    group_input_012_3.outputs[0].hide = True
	    group_input_012_3.outputs[1].hide = True
	    group_input_012_3.outputs[2].hide = True
	    group_input_012_3.outputs[3].hide = True
	    group_input_012_3.outputs[4].hide = True
	    group_input_012_3.outputs[5].hide = True
	    group_input_012_3.outputs[6].hide = True
	    group_input_012_3.outputs[7].hide = True
	    group_input_012_3.outputs[8].hide = True
	    group_input_012_3.outputs[9].hide = True
	    group_input_012_3.outputs[10].hide = True
	    group_input_012_3.outputs[11].hide = True
	    group_input_012_3.outputs[12].hide = True
	    group_input_012_3.outputs[13].hide = True
	    group_input_012_3.outputs[14].hide = True
	    group_input_012_3.outputs[15].hide = True
	    group_input_012_3.outputs[16].hide = True
	    group_input_012_3.outputs[17].hide = True
	    group_input_012_3.outputs[18].hide = True
	    group_input_012_3.outputs[19].hide = True
	    group_input_012_3.outputs[20].hide = True
	    group_input_012_3.outputs[21].hide = True
	    group_input_012_3.outputs[22].hide = True
	    group_input_012_3.outputs[23].hide = True
	    group_input_012_3.outputs[24].hide = True
	    group_input_012_3.outputs[25].hide = True
	    group_input_012_3.outputs[26].hide = True
	    group_input_012_3.outputs[27].hide = True
	    group_input_012_3.outputs[28].hide = True
	    group_input_012_3.outputs[29].hide = True
	    group_input_012_3.outputs[30].hide = True
	    group_input_012_3.outputs[31].hide = True
	    group_input_012_3.outputs[32].hide = True
	    group_input_012_3.outputs[33].hide = True
	    group_input_012_3.outputs[45].hide = True
	    group_input_012_3.outputs[46].hide = True
	    group_input_012_3.outputs[47].hide = True
	    group_input_012_3.outputs[48].hide = True
	    group_input_012_3.outputs[49].hide = True
	    group_input_012_3.outputs[50].hide = True
	
	    #node Group Input.013
	    group_input_013_2 = facial_hairz.nodes.new("NodeGroupInput")
	    group_input_013_2.name = "Group Input.013"
	    group_input_013_2.outputs[0].hide = True
	    group_input_013_2.outputs[1].hide = True
	    group_input_013_2.outputs[2].hide = True
	    group_input_013_2.outputs[3].hide = True
	    group_input_013_2.outputs[4].hide = True
	    group_input_013_2.outputs[5].hide = True
	    group_input_013_2.outputs[6].hide = True
	    group_input_013_2.outputs[7].hide = True
	    group_input_013_2.outputs[8].hide = True
	    group_input_013_2.outputs[9].hide = True
	    group_input_013_2.outputs[10].hide = True
	    group_input_013_2.outputs[11].hide = True
	    group_input_013_2.outputs[12].hide = True
	    group_input_013_2.outputs[13].hide = True
	    group_input_013_2.outputs[14].hide = True
	    group_input_013_2.outputs[15].hide = True
	    group_input_013_2.outputs[16].hide = True
	    group_input_013_2.outputs[17].hide = True
	    group_input_013_2.outputs[18].hide = True
	    group_input_013_2.outputs[19].hide = True
	    group_input_013_2.outputs[20].hide = True
	    group_input_013_2.outputs[21].hide = True
	    group_input_013_2.outputs[22].hide = True
	    group_input_013_2.outputs[23].hide = True
	    group_input_013_2.outputs[24].hide = True
	    group_input_013_2.outputs[25].hide = True
	    group_input_013_2.outputs[26].hide = True
	    group_input_013_2.outputs[27].hide = True
	    group_input_013_2.outputs[28].hide = True
	    group_input_013_2.outputs[29].hide = True
	    group_input_013_2.outputs[30].hide = True
	    group_input_013_2.outputs[31].hide = True
	    group_input_013_2.outputs[32].hide = True
	    group_input_013_2.outputs[33].hide = True
	    group_input_013_2.outputs[35].hide = True
	    group_input_013_2.outputs[36].hide = True
	    group_input_013_2.outputs[37].hide = True
	    group_input_013_2.outputs[38].hide = True
	    group_input_013_2.outputs[39].hide = True
	    group_input_013_2.outputs[40].hide = True
	    group_input_013_2.outputs[41].hide = True
	    group_input_013_2.outputs[42].hide = True
	    group_input_013_2.outputs[43].hide = True
	    group_input_013_2.outputs[44].hide = True
	    group_input_013_2.outputs[45].hide = True
	    group_input_013_2.outputs[46].hide = True
	    group_input_013_2.outputs[47].hide = True
	    group_input_013_2.outputs[48].hide = True
	    group_input_013_2.outputs[49].hide = True
	    group_input_013_2.outputs[50].hide = True
	
	    #node Compare.001
	    compare_001_6 = facial_hairz.nodes.new("FunctionNodeCompare")
	    compare_001_6.name = "Compare.001"
	    compare_001_6.hide = True
	    compare_001_6.data_type = 'FLOAT'
	    compare_001_6.mode = 'ELEMENT'
	    compare_001_6.operation = 'EQUAL'
	    #B
	    compare_001_6.inputs[1].default_value = 0.0
	    #Epsilon
	    compare_001_6.inputs[12].default_value = 0.0
	
	    #node Switch.004
	    switch_004_7 = facial_hairz.nodes.new("GeometryNodeSwitch")
	    switch_004_7.name = "Switch.004"
	    switch_004_7.hide = True
	    switch_004_7.input_type = 'GEOMETRY'
	
	    #node Group Input.027
	    group_input_027 = facial_hairz.nodes.new("NodeGroupInput")
	    group_input_027.name = "Group Input.027"
	    group_input_027.outputs[0].hide = True
	    group_input_027.outputs[1].hide = True
	    group_input_027.outputs[2].hide = True
	    group_input_027.outputs[3].hide = True
	    group_input_027.outputs[4].hide = True
	    group_input_027.outputs[5].hide = True
	    group_input_027.outputs[6].hide = True
	    group_input_027.outputs[7].hide = True
	    group_input_027.outputs[8].hide = True
	    group_input_027.outputs[9].hide = True
	    group_input_027.outputs[11].hide = True
	    group_input_027.outputs[12].hide = True
	    group_input_027.outputs[13].hide = True
	    group_input_027.outputs[14].hide = True
	    group_input_027.outputs[15].hide = True
	    group_input_027.outputs[16].hide = True
	    group_input_027.outputs[17].hide = True
	    group_input_027.outputs[18].hide = True
	    group_input_027.outputs[19].hide = True
	    group_input_027.outputs[20].hide = True
	    group_input_027.outputs[21].hide = True
	    group_input_027.outputs[22].hide = True
	    group_input_027.outputs[23].hide = True
	    group_input_027.outputs[24].hide = True
	    group_input_027.outputs[25].hide = True
	    group_input_027.outputs[26].hide = True
	    group_input_027.outputs[27].hide = True
	    group_input_027.outputs[28].hide = True
	    group_input_027.outputs[29].hide = True
	    group_input_027.outputs[30].hide = True
	    group_input_027.outputs[31].hide = True
	    group_input_027.outputs[32].hide = True
	    group_input_027.outputs[33].hide = True
	    group_input_027.outputs[34].hide = True
	    group_input_027.outputs[35].hide = True
	    group_input_027.outputs[36].hide = True
	    group_input_027.outputs[37].hide = True
	    group_input_027.outputs[38].hide = True
	    group_input_027.outputs[39].hide = True
	    group_input_027.outputs[40].hide = True
	    group_input_027.outputs[41].hide = True
	    group_input_027.outputs[42].hide = True
	    group_input_027.outputs[43].hide = True
	    group_input_027.outputs[44].hide = True
	    group_input_027.outputs[45].hide = True
	    group_input_027.outputs[46].hide = True
	    group_input_027.outputs[47].hide = True
	    group_input_027.outputs[48].hide = True
	    group_input_027.outputs[49].hide = True
	    group_input_027.outputs[50].hide = True
	
	    #node Group Input.004
	    group_input_004_11 = facial_hairz.nodes.new("NodeGroupInput")
	    group_input_004_11.name = "Group Input.004"
	    group_input_004_11.outputs[1].hide = True
	    group_input_004_11.outputs[2].hide = True
	    group_input_004_11.outputs[3].hide = True
	    group_input_004_11.outputs[4].hide = True
	    group_input_004_11.outputs[5].hide = True
	    group_input_004_11.outputs[6].hide = True
	    group_input_004_11.outputs[7].hide = True
	    group_input_004_11.outputs[8].hide = True
	    group_input_004_11.outputs[9].hide = True
	    group_input_004_11.outputs[10].hide = True
	    group_input_004_11.outputs[11].hide = True
	    group_input_004_11.outputs[12].hide = True
	    group_input_004_11.outputs[13].hide = True
	    group_input_004_11.outputs[14].hide = True
	    group_input_004_11.outputs[15].hide = True
	    group_input_004_11.outputs[16].hide = True
	    group_input_004_11.outputs[17].hide = True
	    group_input_004_11.outputs[18].hide = True
	    group_input_004_11.outputs[19].hide = True
	    group_input_004_11.outputs[20].hide = True
	    group_input_004_11.outputs[21].hide = True
	    group_input_004_11.outputs[22].hide = True
	    group_input_004_11.outputs[23].hide = True
	    group_input_004_11.outputs[24].hide = True
	    group_input_004_11.outputs[25].hide = True
	    group_input_004_11.outputs[26].hide = True
	    group_input_004_11.outputs[27].hide = True
	    group_input_004_11.outputs[28].hide = True
	    group_input_004_11.outputs[29].hide = True
	    group_input_004_11.outputs[30].hide = True
	    group_input_004_11.outputs[31].hide = True
	    group_input_004_11.outputs[32].hide = True
	    group_input_004_11.outputs[33].hide = True
	    group_input_004_11.outputs[34].hide = True
	    group_input_004_11.outputs[35].hide = True
	    group_input_004_11.outputs[36].hide = True
	    group_input_004_11.outputs[37].hide = True
	    group_input_004_11.outputs[38].hide = True
	    group_input_004_11.outputs[39].hide = True
	    group_input_004_11.outputs[40].hide = True
	    group_input_004_11.outputs[41].hide = True
	    group_input_004_11.outputs[42].hide = True
	    group_input_004_11.outputs[43].hide = True
	    group_input_004_11.outputs[44].hide = True
	    group_input_004_11.outputs[45].hide = True
	    group_input_004_11.outputs[46].hide = True
	    group_input_004_11.outputs[47].hide = True
	    group_input_004_11.outputs[48].hide = True
	    group_input_004_11.outputs[49].hide = True
	    group_input_004_11.outputs[50].hide = True
	
	    #node Group.011
	    group_011 = facial_hairz.nodes.new("GeometryNodeGroup")
	    group_011.name = "Group.011"
	    group_011.node_tree = attach_hair
	
	    #node Group Input.016
	    group_input_016_1 = facial_hairz.nodes.new("NodeGroupInput")
	    group_input_016_1.name = "Group Input.016"
	    group_input_016_1.outputs[0].hide = True
	    group_input_016_1.outputs[2].hide = True
	    group_input_016_1.outputs[3].hide = True
	    group_input_016_1.outputs[4].hide = True
	    group_input_016_1.outputs[5].hide = True
	    group_input_016_1.outputs[6].hide = True
	    group_input_016_1.outputs[7].hide = True
	    group_input_016_1.outputs[10].hide = True
	    group_input_016_1.outputs[11].hide = True
	    group_input_016_1.outputs[12].hide = True
	    group_input_016_1.outputs[13].hide = True
	    group_input_016_1.outputs[14].hide = True
	    group_input_016_1.outputs[15].hide = True
	    group_input_016_1.outputs[16].hide = True
	    group_input_016_1.outputs[17].hide = True
	    group_input_016_1.outputs[18].hide = True
	    group_input_016_1.outputs[19].hide = True
	    group_input_016_1.outputs[20].hide = True
	    group_input_016_1.outputs[21].hide = True
	    group_input_016_1.outputs[22].hide = True
	    group_input_016_1.outputs[23].hide = True
	    group_input_016_1.outputs[24].hide = True
	    group_input_016_1.outputs[25].hide = True
	    group_input_016_1.outputs[26].hide = True
	    group_input_016_1.outputs[27].hide = True
	    group_input_016_1.outputs[28].hide = True
	    group_input_016_1.outputs[29].hide = True
	    group_input_016_1.outputs[30].hide = True
	    group_input_016_1.outputs[31].hide = True
	    group_input_016_1.outputs[32].hide = True
	    group_input_016_1.outputs[33].hide = True
	    group_input_016_1.outputs[34].hide = True
	    group_input_016_1.outputs[35].hide = True
	    group_input_016_1.outputs[36].hide = True
	    group_input_016_1.outputs[37].hide = True
	    group_input_016_1.outputs[38].hide = True
	    group_input_016_1.outputs[39].hide = True
	    group_input_016_1.outputs[40].hide = True
	    group_input_016_1.outputs[41].hide = True
	    group_input_016_1.outputs[42].hide = True
	    group_input_016_1.outputs[43].hide = True
	    group_input_016_1.outputs[44].hide = True
	    group_input_016_1.outputs[45].hide = True
	    group_input_016_1.outputs[46].hide = True
	    group_input_016_1.outputs[47].hide = True
	    group_input_016_1.outputs[48].hide = True
	    group_input_016_1.outputs[49].hide = True
	    group_input_016_1.outputs[50].hide = True
	
	    #node Set Curve Tilt
	    set_curve_tilt_2 = facial_hairz.nodes.new("GeometryNodeSetCurveTilt")
	    set_curve_tilt_2.name = "Set Curve Tilt"
	    set_curve_tilt_2.inputs[1].hide = True
	    set_curve_tilt_2.inputs[2].hide = True
	    #Selection
	    set_curve_tilt_2.inputs[1].default_value = True
	    #Tilt
	    set_curve_tilt_2.inputs[2].default_value = -1.5707963705062866
	
	    #node Group.010
	    group_010 = facial_hairz.nodes.new("GeometryNodeGroup")
	    group_010.name = "Group.010"
	    group_010.node_tree = mesh_hair_selector
	    group_010.inputs[1].hide = True
	    group_010.inputs[5].hide = True
	    group_010.inputs[6].hide = True
	    group_010.inputs[8].hide = True
	    group_010.inputs[9].hide = True
	    group_010.inputs[10].hide = True
	    group_010.inputs[11].hide = True
	    group_010.inputs[12].hide = True
	    group_010.inputs[13].hide = True
	    #Socket_2
	    group_010.inputs[1].default_value = 'Hair Card'
	    #Socket_6
	    group_010.inputs[5].default_value = False
	    #Socket_7
	    group_010.inputs[6].default_value = False
	    #Socket_9
	    group_010.inputs[8].default_value = 8
	    #Socket_11
	    group_010.inputs[10].default_value = (0.0, 0.0, 0.0)
	    #Socket_12
	    group_010.inputs[11].default_value = (0.0, 0.0, 0.0)
	    #Socket_13
	    group_010.inputs[12].default_value = (1.0, 1.0, 1.0)
	    #Socket_14
	    group_010.inputs[13].default_value = 0
	
	    #node Switch.005
	    switch_005_2 = facial_hairz.nodes.new("GeometryNodeSwitch")
	    switch_005_2.name = "Switch.005"
	    switch_005_2.hide = True
	    switch_005_2.input_type = 'GEOMETRY'
	
	    #node Group Input.009
	    group_input_009_5 = facial_hairz.nodes.new("NodeGroupInput")
	    group_input_009_5.name = "Group Input.009"
	    group_input_009_5.outputs[0].hide = True
	    group_input_009_5.outputs[1].hide = True
	    group_input_009_5.outputs[2].hide = True
	    group_input_009_5.outputs[3].hide = True
	    group_input_009_5.outputs[4].hide = True
	    group_input_009_5.outputs[5].hide = True
	    group_input_009_5.outputs[6].hide = True
	    group_input_009_5.outputs[7].hide = True
	    group_input_009_5.outputs[8].hide = True
	    group_input_009_5.outputs[9].hide = True
	    group_input_009_5.outputs[10].hide = True
	    group_input_009_5.outputs[11].hide = True
	    group_input_009_5.outputs[12].hide = True
	    group_input_009_5.outputs[14].hide = True
	    group_input_009_5.outputs[15].hide = True
	    group_input_009_5.outputs[16].hide = True
	    group_input_009_5.outputs[17].hide = True
	    group_input_009_5.outputs[18].hide = True
	    group_input_009_5.outputs[19].hide = True
	    group_input_009_5.outputs[20].hide = True
	    group_input_009_5.outputs[21].hide = True
	    group_input_009_5.outputs[22].hide = True
	    group_input_009_5.outputs[23].hide = True
	    group_input_009_5.outputs[24].hide = True
	    group_input_009_5.outputs[25].hide = True
	    group_input_009_5.outputs[26].hide = True
	    group_input_009_5.outputs[27].hide = True
	    group_input_009_5.outputs[28].hide = True
	    group_input_009_5.outputs[29].hide = True
	    group_input_009_5.outputs[30].hide = True
	    group_input_009_5.outputs[31].hide = True
	    group_input_009_5.outputs[32].hide = True
	    group_input_009_5.outputs[33].hide = True
	    group_input_009_5.outputs[34].hide = True
	    group_input_009_5.outputs[35].hide = True
	    group_input_009_5.outputs[36].hide = True
	    group_input_009_5.outputs[37].hide = True
	    group_input_009_5.outputs[38].hide = True
	    group_input_009_5.outputs[39].hide = True
	    group_input_009_5.outputs[40].hide = True
	    group_input_009_5.outputs[41].hide = True
	    group_input_009_5.outputs[42].hide = True
	    group_input_009_5.outputs[43].hide = True
	    group_input_009_5.outputs[44].hide = True
	    group_input_009_5.outputs[45].hide = True
	    group_input_009_5.outputs[46].hide = True
	    group_input_009_5.outputs[47].hide = True
	    group_input_009_5.outputs[48].hide = True
	    group_input_009_5.outputs[49].hide = True
	    group_input_009_5.outputs[50].hide = True
	
	    #node Compare.002
	    compare_002_8 = facial_hairz.nodes.new("FunctionNodeCompare")
	    compare_002_8.name = "Compare.002"
	    compare_002_8.hide = True
	    compare_002_8.data_type = 'INT'
	    compare_002_8.mode = 'ELEMENT'
	    compare_002_8.operation = 'EQUAL'
	    compare_002_8.inputs[0].hide = True
	    compare_002_8.inputs[1].hide = True
	    compare_002_8.inputs[3].hide = True
	    compare_002_8.inputs[4].hide = True
	    compare_002_8.inputs[5].hide = True
	    compare_002_8.inputs[6].hide = True
	    compare_002_8.inputs[7].hide = True
	    compare_002_8.inputs[8].hide = True
	    compare_002_8.inputs[9].hide = True
	    compare_002_8.inputs[10].hide = True
	    compare_002_8.inputs[11].hide = True
	    compare_002_8.inputs[12].hide = True
	    #B_INT
	    compare_002_8.inputs[3].default_value = 0
	
	    #node Index
	    index_3 = facial_hairz.nodes.new("GeometryNodeInputIndex")
	    index_3.name = "Index"
	
	    #node Switch.006
	    switch_006_2 = facial_hairz.nodes.new("GeometryNodeSwitch")
	    switch_006_2.name = "Switch.006"
	    switch_006_2.hide = True
	    switch_006_2.input_type = 'INT'
	
	    #node Switch.007
	    switch_007_1 = facial_hairz.nodes.new("GeometryNodeSwitch")
	    switch_007_1.name = "Switch.007"
	    switch_007_1.hide = True
	    switch_007_1.input_type = 'GEOMETRY'
	
	    #node Group Input.014
	    group_input_014_1 = facial_hairz.nodes.new("NodeGroupInput")
	    group_input_014_1.name = "Group Input.014"
	    group_input_014_1.outputs[0].hide = True
	    group_input_014_1.outputs[1].hide = True
	    group_input_014_1.outputs[2].hide = True
	    group_input_014_1.outputs[3].hide = True
	    group_input_014_1.outputs[4].hide = True
	    group_input_014_1.outputs[5].hide = True
	    group_input_014_1.outputs[6].hide = True
	    group_input_014_1.outputs[7].hide = True
	    group_input_014_1.outputs[8].hide = True
	    group_input_014_1.outputs[9].hide = True
	    group_input_014_1.outputs[10].hide = True
	    group_input_014_1.outputs[11].hide = True
	    group_input_014_1.outputs[12].hide = True
	    group_input_014_1.outputs[13].hide = True
	    group_input_014_1.outputs[14].hide = True
	    group_input_014_1.outputs[15].hide = True
	    group_input_014_1.outputs[16].hide = True
	    group_input_014_1.outputs[17].hide = True
	    group_input_014_1.outputs[18].hide = True
	    group_input_014_1.outputs[19].hide = True
	    group_input_014_1.outputs[20].hide = True
	    group_input_014_1.outputs[21].hide = True
	    group_input_014_1.outputs[22].hide = True
	    group_input_014_1.outputs[23].hide = True
	    group_input_014_1.outputs[24].hide = True
	    group_input_014_1.outputs[25].hide = True
	    group_input_014_1.outputs[26].hide = True
	    group_input_014_1.outputs[27].hide = True
	    group_input_014_1.outputs[28].hide = True
	    group_input_014_1.outputs[29].hide = True
	    group_input_014_1.outputs[30].hide = True
	    group_input_014_1.outputs[31].hide = True
	    group_input_014_1.outputs[32].hide = True
	    group_input_014_1.outputs[33].hide = True
	    group_input_014_1.outputs[34].hide = True
	    group_input_014_1.outputs[35].hide = True
	    group_input_014_1.outputs[36].hide = True
	    group_input_014_1.outputs[37].hide = True
	    group_input_014_1.outputs[38].hide = True
	    group_input_014_1.outputs[39].hide = True
	    group_input_014_1.outputs[40].hide = True
	    group_input_014_1.outputs[41].hide = True
	    group_input_014_1.outputs[42].hide = True
	    group_input_014_1.outputs[43].hide = True
	    group_input_014_1.outputs[44].hide = True
	    group_input_014_1.outputs[46].hide = True
	    group_input_014_1.outputs[47].hide = True
	    group_input_014_1.outputs[48].hide = True
	    group_input_014_1.outputs[49].hide = True
	    group_input_014_1.outputs[50].hide = True
	
	    #node Group Input.017
	    group_input_017 = facial_hairz.nodes.new("NodeGroupInput")
	    group_input_017.name = "Group Input.017"
	    group_input_017.outputs[0].hide = True
	    group_input_017.outputs[1].hide = True
	    group_input_017.outputs[2].hide = True
	    group_input_017.outputs[3].hide = True
	    group_input_017.outputs[4].hide = True
	    group_input_017.outputs[5].hide = True
	    group_input_017.outputs[6].hide = True
	    group_input_017.outputs[7].hide = True
	    group_input_017.outputs[8].hide = True
	    group_input_017.outputs[9].hide = True
	    group_input_017.outputs[10].hide = True
	    group_input_017.outputs[11].hide = True
	    group_input_017.outputs[12].hide = True
	    group_input_017.outputs[13].hide = True
	    group_input_017.outputs[14].hide = True
	    group_input_017.outputs[15].hide = True
	    group_input_017.outputs[16].hide = True
	    group_input_017.outputs[17].hide = True
	    group_input_017.outputs[18].hide = True
	    group_input_017.outputs[19].hide = True
	    group_input_017.outputs[20].hide = True
	    group_input_017.outputs[21].hide = True
	    group_input_017.outputs[22].hide = True
	    group_input_017.outputs[23].hide = True
	    group_input_017.outputs[24].hide = True
	    group_input_017.outputs[25].hide = True
	    group_input_017.outputs[26].hide = True
	    group_input_017.outputs[27].hide = True
	    group_input_017.outputs[28].hide = True
	    group_input_017.outputs[29].hide = True
	    group_input_017.outputs[30].hide = True
	    group_input_017.outputs[31].hide = True
	    group_input_017.outputs[32].hide = True
	    group_input_017.outputs[33].hide = True
	    group_input_017.outputs[34].hide = True
	    group_input_017.outputs[35].hide = True
	    group_input_017.outputs[36].hide = True
	    group_input_017.outputs[37].hide = True
	    group_input_017.outputs[38].hide = True
	    group_input_017.outputs[39].hide = True
	    group_input_017.outputs[40].hide = True
	    group_input_017.outputs[41].hide = True
	    group_input_017.outputs[42].hide = True
	    group_input_017.outputs[43].hide = True
	    group_input_017.outputs[44].hide = True
	    group_input_017.outputs[45].hide = True
	    group_input_017.outputs[50].hide = True
	
	    #node Final Bake
	    final_bake = facial_hairz.nodes.new("GeometryNodeBake")
	    final_bake.label = "Final Bake"
	    final_bake.name = "Final Bake"
	    final_bake.active_index = 0
	    final_bake.bake_items.clear()
	    final_bake.bake_items.new('GEOMETRY', "Geometry")
	    final_bake.bake_items[0].attribute_domain = 'POINT'
	    final_bake.inputs[1].hide = True
	    final_bake.outputs[1].hide = True
	
	    #node Reroute.008
	    reroute_008_10 = facial_hairz.nodes.new("NodeReroute")
	    reroute_008_10.name = "Reroute.008"
	    reroute_008_10.socket_idname = "NodeSocketGeometry"
	    #node Curve Bake
	    curve_bake = facial_hairz.nodes.new("GeometryNodeBake")
	    curve_bake.label = "Curve Bake"
	    curve_bake.name = "Curve Bake"
	    curve_bake.active_index = 0
	    curve_bake.bake_items.clear()
	    curve_bake.bake_items.new('GEOMETRY', "Geometry")
	    curve_bake.bake_items[0].attribute_domain = 'POINT'
	    curve_bake.inputs[1].hide = True
	    curve_bake.outputs[1].hide = True
	
	    #node Separate Components
	    separate_components_6 = facial_hairz.nodes.new("GeometryNodeSeparateComponents")
	    separate_components_6.name = "Separate Components"
	    separate_components_6.hide = True
	
	    #node Join Geometry.001
	    join_geometry_001_3 = facial_hairz.nodes.new("GeometryNodeJoinGeometry")
	    join_geometry_001_3.name = "Join Geometry.001"
	
	    #node Reroute.009
	    reroute_009_10 = facial_hairz.nodes.new("NodeReroute")
	    reroute_009_10.name = "Reroute.009"
	    reroute_009_10.socket_idname = "NodeSocketGeometry"
	    #node Reroute.010
	    reroute_010_8 = facial_hairz.nodes.new("NodeReroute")
	    reroute_010_8.name = "Reroute.010"
	    reroute_010_8.socket_idname = "NodeSocketGeometry"
	    #node Reroute.011
	    reroute_011_9 = facial_hairz.nodes.new("NodeReroute")
	    reroute_011_9.name = "Reroute.011"
	    reroute_011_9.socket_idname = "NodeSocketGeometry"
	    #node Reroute.012
	    reroute_012_10 = facial_hairz.nodes.new("NodeReroute")
	    reroute_012_10.name = "Reroute.012"
	    reroute_012_10.socket_idname = "NodeSocketGeometry"
	    #node Reroute.013
	    reroute_013_9 = facial_hairz.nodes.new("NodeReroute")
	    reroute_013_9.name = "Reroute.013"
	    reroute_013_9.socket_idname = "NodeSocketGeometry"
	    #node Reroute.014
	    reroute_014_8 = facial_hairz.nodes.new("NodeReroute")
	    reroute_014_8.name = "Reroute.014"
	    reroute_014_8.socket_idname = "NodeSocketGeometry"
	    #node Reroute.015
	    reroute_015_9 = facial_hairz.nodes.new("NodeReroute")
	    reroute_015_9.name = "Reroute.015"
	    reroute_015_9.socket_idname = "NodeSocketGeometry"
	    #node Reroute.016
	    reroute_016_8 = facial_hairz.nodes.new("NodeReroute")
	    reroute_016_8.name = "Reroute.016"
	    reroute_016_8.socket_idname = "NodeSocketGeometry"
	    #node Reroute.017
	    reroute_017_7 = facial_hairz.nodes.new("NodeReroute")
	    reroute_017_7.name = "Reroute.017"
	    reroute_017_7.socket_idname = "NodeSocketGeometry"
	    #node Reroute.018
	    reroute_018_7 = facial_hairz.nodes.new("NodeReroute")
	    reroute_018_7.name = "Reroute.018"
	    reroute_018_7.socket_idname = "NodeSocketGeometry"
	    #node Set Curve Radius
	    set_curve_radius_4 = facial_hairz.nodes.new("GeometryNodeSetCurveRadius")
	    set_curve_radius_4.name = "Set Curve Radius"
	    set_curve_radius_4.inputs[1].hide = True
	    #Selection
	    set_curve_radius_4.inputs[1].default_value = True
	
	    #node Hair Shape
	    hair_shape = facial_hairz.nodes.new("ShaderNodeFloatCurve")
	    hair_shape.label = "Hair Shape"
	    hair_shape.name = "Hair Shape"
	    #mapping settings
	    hair_shape.mapping.extend = 'EXTRAPOLATED'
	    hair_shape.mapping.tone = 'STANDARD'
	    hair_shape.mapping.black_level = (0.0, 0.0, 0.0)
	    hair_shape.mapping.white_level = (1.0, 1.0, 1.0)
	    hair_shape.mapping.clip_min_x = 0.0
	    hair_shape.mapping.clip_min_y = 0.0
	    hair_shape.mapping.clip_max_x = 1.0
	    hair_shape.mapping.clip_max_y = 1.0
	    hair_shape.mapping.use_clip = True
	    #curve 0
	    hair_shape_curve_0 = hair_shape.mapping.curves[0]
	    hair_shape_curve_0_point_0 = hair_shape_curve_0.points[0]
	    hair_shape_curve_0_point_0.location = (0.0, 0.6999994516372681)
	    hair_shape_curve_0_point_0.handle_type = 'AUTO'
	    hair_shape_curve_0_point_1 = hair_shape_curve_0.points[1]
	    hair_shape_curve_0_point_1.location = (0.044510386884212494, 1.0)
	    hair_shape_curve_0_point_1.handle_type = 'VECTOR'
	    hair_shape_curve_0_point_2 = hair_shape_curve_0.points.new(0.925815999507904, 0.96875)
	    hair_shape_curve_0_point_2.handle_type = 'VECTOR'
	    hair_shape_curve_0_point_3 = hair_shape_curve_0.points.new(1.0, 0.1124996766448021)
	    hair_shape_curve_0_point_3.handle_type = 'AUTO'
	    #update curve after changes
	    hair_shape.mapping.update()
	    hair_shape.inputs[0].hide = True
	    #Factor
	    hair_shape.inputs[0].default_value = 1.0
	
	    #node Spline Parameter
	    spline_parameter_8 = facial_hairz.nodes.new("GeometryNodeSplineParameter")
	    spline_parameter_8.name = "Spline Parameter"
	    spline_parameter_8.outputs[1].hide = True
	    spline_parameter_8.outputs[2].hide = True
	
	    #node Map Range
	    map_range_3 = facial_hairz.nodes.new("ShaderNodeMapRange")
	    map_range_3.name = "Map Range"
	    map_range_3.hide = True
	    map_range_3.clamp = True
	    map_range_3.data_type = 'FLOAT'
	    map_range_3.interpolation_type = 'LINEAR'
	    map_range_3.inputs[1].hide = True
	    map_range_3.inputs[2].hide = True
	    map_range_3.inputs[3].hide = True
	    map_range_3.inputs[5].hide = True
	    map_range_3.inputs[6].hide = True
	    map_range_3.inputs[7].hide = True
	    map_range_3.inputs[8].hide = True
	    map_range_3.inputs[9].hide = True
	    map_range_3.inputs[10].hide = True
	    map_range_3.inputs[11].hide = True
	    map_range_3.outputs[1].hide = True
	    #From Min
	    map_range_3.inputs[1].default_value = 0.0
	    #From Max
	    map_range_3.inputs[2].default_value = 1.0
	    #To Min
	    map_range_3.inputs[3].default_value = 0.0
	
	
	
	
	    #Set parents
	    set_position_7.parent = frame_11
	    vector_math_11.parent = frame_11
	    capture_attribute_9.parent = frame_11
	    position_5.parent = frame_11
	
	    #Set locations
	    group_input_18.location = (-165.20945739746094, 94.81048583984375)
	    group_output_22.location = (3880.293212890625, 391.63592529296875)
	    resample_curve_4.location = (-159.8823699951172, 224.35369873046875)
	    group_10.location = (500.7198791503906, 291.55401611328125)
	    group_001_9.location = (1214.3988037109375, 247.51080322265625)
	    group_002_6.location = (1545.6837158203125, 199.8958282470703)
	    group_input_001_14.location = (327.1558837890625, 180.7516632080078)
	    group_input_002_13.location = (1026.653076171875, 122.28914642333984)
	    group_input_003_14.location = (1369.1904296875, 129.47662353515625)
	    set_material_4.location = (1863.4146728515625, 344.8157958984375)
	    group_input_005_10.location = (1697.5443115234375, 259.28619384765625)
	    set_position_7.location = (356.17041015625, -50.08729553222656)
	    vector_math_11.location = (197.9052734375, -56.419097900390625)
	    capture_attribute_9.location = (34.4443359375, -45.42674255371094)
	    position_5.location = (30.17578125, -82.49327087402344)
	    switch_15.location = (2215.75537109375, 318.301025390625)
	    join_geometry_7.location = (2221.833984375, 278.37396240234375)
	    frame_11.location = (1868.0, 190.0)
	    group_input_006_8.location = (2214.564697265625, 382.40167236328125)
	    reroute_18.location = (2033.8333740234375, 309.224853515625)
	    reroute_001_14.location = (1905.8975830078125, 204.07704162597656)
	    reroute_002_13.location = (2363.476806640625, 202.84800720214844)
	    reroute_003_13.location = (2036.0384521484375, 203.49008178710938)
	    reroute_004_13.location = (2221.701171875, 203.48333740234375)
	    reroute_005_11.location = (2034.5189208984375, 270.68212890625)
	    reroute_044.location = (1542.1324462890625, 287.0569152832031)
	    switch_002_6.location = (1366.623046875, 297.7516784667969)
	    compare_008_1.location = (1348.6781005859375, 333.67279052734375)
	    group_input_024.location = (1347.75732421875, 395.50714111328125)
	    reroute_054.location = (1200.8179931640625, 275.337158203125)
	    reroute_055.location = (1201.8511962890625, 167.36972045898438)
	    reroute_057.location = (1353.10888671875, 288.4638977050781)
	    group_input_008_7.location = (0.8864351511001587, 74.1466293334961)
	    group_008.location = (175.47657775878906, 222.7748565673828)
	    group_input_025.location = (2.3938887119293213, 133.5665283203125)
	    group_input_026.location = (4.1739325523376465, 195.46487426757812)
	    group_input_010_4.location = (0.9917746186256409, 13.043569564819336)
	    group_input_015_1.location = (837.169189453125, 91.76907348632812)
	    group_004_2.location = (2425.331298828125, 129.4033203125)
	    group_input_007_8.location = (2248.8876953125, 14.514860153198242)
	    switch_001_11.location = (2561.809814453125, 333.18426513671875)
	    group_input_011_2.location = (2555.933349609375, 433.75238037109375)
	    compare_14.location = (2560.90966796875, 371.95672607421875)
	    reroute_006_10.location = (2421.38720703125, 309.30670166015625)
	    group_005_4.location = (2752.361328125, 169.49087524414062)
	    reroute_007_10.location = (2745.65576171875, 322.28045654296875)
	    switch_003_7.location = (2888.607666015625, 342.02392578125)
	    group_input_012_3.location = (2585.033935546875, 92.49749755859375)
	    group_input_013_2.location = (2882.1083984375, 437.63677978515625)
	    compare_001_6.location = (2885.8115234375, 376.1328125)
	    switch_004_7.location = (1682.5921630859375, 294.63494873046875)
	    group_input_027.location = (1683.3077392578125, 355.7777404785156)
	    group_input_004_11.location = (-515.7025146484375, 160.7974395751953)
	    group_011.location = (838.4221801757812, 259.8731689453125)
	    group_input_016_1.location = (652.9049682617188, 189.32591247558594)
	    set_curve_tilt_2.location = (8.602752685546875, 283.79779052734375)
	    group_010.location = (3293.905029296875, 289.0024719238281)
	    switch_005_2.location = (503.9166564941406, 360.261474609375)
	    group_input_009_5.location = (505.6639099121094, 458.31329345703125)
	    compare_002_8.location = (506.1878662109375, 392.9825744628906)
	    index_3.location = (841.1915283203125, 354.8017883300781)
	    switch_006_2.location = (841.6682739257812, 384.80902099609375)
	    switch_007_1.location = (3291.581298828125, 343.6639709472656)
	    group_input_014_1.location = (3288.6640625, 409.769287109375)
	    group_input_017.location = (3081.586181640625, 217.73651123046875)
	    final_bake.location = (3700.234375, 438.7387390136719)
	    reroute_008_10.location = (3254.000244140625, 332.252685546875)
	    curve_bake.location = (3068.999755859375, 417.3558044433594)
	    separate_components_6.location = (-341.32281494140625, 134.71751403808594)
	    join_geometry_001_3.location = (3525.32958984375, 391.82391357421875)
	    reroute_009_10.location = (-13.661376953125, 537.4422607421875)
	    reroute_010_8.location = (-13.661376953125, 532.0291137695312)
	    reroute_011_9.location = (-13.661376953125, 521.202880859375)
	    reroute_012_10.location = (-13.661376953125, 526.6160888671875)
	    reroute_013_9.location = (-13.661376953125, 543.3900146484375)
	    reroute_014_8.location = (3402.44189453125, 539.931396484375)
	    reroute_015_9.location = (3402.44189453125, 529.9247436523438)
	    reroute_016_8.location = (3402.44189453125, 534.9280395507812)
	    reroute_017_7.location = (3402.44189453125, 549.94287109375)
	    reroute_018_7.location = (3402.44189453125, 544.9349365234375)
	    set_curve_radius_4.location = (1023.4094848632812, 284.8009948730469)
	    hair_shape.location = (732.854736328125, 0.074188232421875)
	    spline_parameter_8.location = (732.2054443359375, -295.0316162109375)
	    map_range_3.location = (837.3677978515625, 29.8341064453125)
	
	    #Set dimensions
	    group_input_18.width, group_input_18.height = 140.0, 100.0
	    group_output_22.width, group_output_22.height = 140.0, 100.0
	    resample_curve_4.width, resample_curve_4.height = 140.0, 100.0
	    group_10.width, group_10.height = 140.0, 100.0
	    group_001_9.width, group_001_9.height = 140.0, 100.0
	    group_002_6.width, group_002_6.height = 140.0, 100.0
	    group_input_001_14.width, group_input_001_14.height = 140.0, 100.0
	    group_input_002_13.width, group_input_002_13.height = 140.0, 100.0
	    group_input_003_14.width, group_input_003_14.height = 140.0, 100.0
	    set_material_4.width, set_material_4.height = 140.0, 100.0
	    group_input_005_10.width, group_input_005_10.height = 140.0, 100.0
	    set_position_7.width, set_position_7.height = 140.0, 100.0
	    vector_math_11.width, vector_math_11.height = 140.0, 100.0
	    capture_attribute_9.width, capture_attribute_9.height = 140.0, 100.0
	    position_5.width, position_5.height = 140.0, 100.0
	    switch_15.width, switch_15.height = 140.0, 100.0
	    join_geometry_7.width, join_geometry_7.height = 140.0, 100.0
	    frame_11.width, frame_11.height = 526.0, 137.0
	    group_input_006_8.width, group_input_006_8.height = 140.0, 100.0
	    reroute_18.width, reroute_18.height = 10.0, 100.0
	    reroute_001_14.width, reroute_001_14.height = 10.0, 100.0
	    reroute_002_13.width, reroute_002_13.height = 10.0, 100.0
	    reroute_003_13.width, reroute_003_13.height = 10.0, 100.0
	    reroute_004_13.width, reroute_004_13.height = 10.0, 100.0
	    reroute_005_11.width, reroute_005_11.height = 10.0, 100.0
	    reroute_044.width, reroute_044.height = 10.0, 100.0
	    switch_002_6.width, switch_002_6.height = 140.0, 100.0
	    compare_008_1.width, compare_008_1.height = 140.0, 100.0
	    group_input_024.width, group_input_024.height = 140.0, 100.0
	    reroute_054.width, reroute_054.height = 10.0, 100.0
	    reroute_055.width, reroute_055.height = 10.0, 100.0
	    reroute_057.width, reroute_057.height = 10.0, 100.0
	    group_input_008_7.width, group_input_008_7.height = 140.0, 100.0
	    group_008.width, group_008.height = 140.0, 100.0
	    group_input_025.width, group_input_025.height = 140.0, 100.0
	    group_input_026.width, group_input_026.height = 140.0, 100.0
	    group_input_010_4.width, group_input_010_4.height = 140.0, 100.0
	    group_input_015_1.width, group_input_015_1.height = 140.0, 100.0
	    group_004_2.width, group_004_2.height = 140.0, 100.0
	    group_input_007_8.width, group_input_007_8.height = 140.0, 100.0
	    switch_001_11.width, switch_001_11.height = 140.0, 100.0
	    group_input_011_2.width, group_input_011_2.height = 140.0, 100.0
	    compare_14.width, compare_14.height = 140.0, 100.0
	    reroute_006_10.width, reroute_006_10.height = 10.0, 100.0
	    group_005_4.width, group_005_4.height = 140.0, 100.0
	    reroute_007_10.width, reroute_007_10.height = 10.0, 100.0
	    switch_003_7.width, switch_003_7.height = 140.0, 100.0
	    group_input_012_3.width, group_input_012_3.height = 140.0, 100.0
	    group_input_013_2.width, group_input_013_2.height = 140.0, 100.0
	    compare_001_6.width, compare_001_6.height = 140.0, 100.0
	    switch_004_7.width, switch_004_7.height = 140.0, 100.0
	    group_input_027.width, group_input_027.height = 140.0, 100.0
	    group_input_004_11.width, group_input_004_11.height = 140.0, 100.0
	    group_011.width, group_011.height = 140.0, 100.0
	    group_input_016_1.width, group_input_016_1.height = 140.0, 100.0
	    set_curve_tilt_2.width, set_curve_tilt_2.height = 140.0, 100.0
	    group_010.width, group_010.height = 140.0, 100.0
	    switch_005_2.width, switch_005_2.height = 140.0, 100.0
	    group_input_009_5.width, group_input_009_5.height = 140.0, 100.0
	    compare_002_8.width, compare_002_8.height = 140.0, 100.0
	    index_3.width, index_3.height = 140.0, 100.0
	    switch_006_2.width, switch_006_2.height = 140.0, 100.0
	    switch_007_1.width, switch_007_1.height = 140.0, 100.0
	    group_input_014_1.width, group_input_014_1.height = 140.0, 100.0
	    group_input_017.width, group_input_017.height = 140.0, 100.0
	    final_bake.width, final_bake.height = 140.0, 100.0
	    reroute_008_10.width, reroute_008_10.height = 10.0, 100.0
	    curve_bake.width, curve_bake.height = 140.0, 100.0
	    separate_components_6.width, separate_components_6.height = 140.0, 100.0
	    join_geometry_001_3.width, join_geometry_001_3.height = 140.0, 100.0
	    reroute_009_10.width, reroute_009_10.height = 10.0, 100.0
	    reroute_010_8.width, reroute_010_8.height = 10.0, 100.0
	    reroute_011_9.width, reroute_011_9.height = 10.0, 100.0
	    reroute_012_10.width, reroute_012_10.height = 10.0, 100.0
	    reroute_013_9.width, reroute_013_9.height = 10.0, 100.0
	    reroute_014_8.width, reroute_014_8.height = 10.0, 100.0
	    reroute_015_9.width, reroute_015_9.height = 10.0, 100.0
	    reroute_016_8.width, reroute_016_8.height = 10.0, 100.0
	    reroute_017_7.width, reroute_017_7.height = 10.0, 100.0
	    reroute_018_7.width, reroute_018_7.height = 10.0, 100.0
	    set_curve_radius_4.width, set_curve_radius_4.height = 140.0, 100.0
	    hair_shape.width, hair_shape.height = 240.0, 100.0
	    spline_parameter_8.width, spline_parameter_8.height = 140.0, 100.0
	    map_range_3.width, map_range_3.height = 140.0, 100.0
	
	    #initialize facial_hairz links
	    #reroute_055.Output -> group_001_9.Geometry
	    facial_hairz.links.new(reroute_055.outputs[0], group_001_9.inputs[0])
	    #group_input_18.Control Points -> resample_curve_4.Count
	    facial_hairz.links.new(group_input_18.outputs[6], resample_curve_4.inputs[2])
	    #group_input_001_14.Duplicate Amount -> group_10.Amount
	    facial_hairz.links.new(group_input_001_14.outputs[13], group_10.inputs[1])
	    #group_input_001_14.Duplicate Viewport Amount -> group_10.Viewport Amount
	    facial_hairz.links.new(group_input_001_14.outputs[14], group_10.inputs[2])
	    #group_input_001_14.Duplicate Radius -> group_10.Radius
	    facial_hairz.links.new(group_input_001_14.outputs[15], group_10.inputs[3])
	    #group_input_001_14.Duplicate Distribution Shape -> group_10.Distribution Shape
	    facial_hairz.links.new(group_input_001_14.outputs[16], group_10.inputs[4])
	    #group_input_001_14.Duplicate Tip Roundness -> group_10.Tip Roundness
	    facial_hairz.links.new(group_input_001_14.outputs[17], group_10.inputs[5])
	    #group_input_001_14.Duplicate Even Thickness -> group_10.Even Thickness
	    facial_hairz.links.new(group_input_001_14.outputs[18], group_10.inputs[6])
	    #group_input_001_14.Duplicate Seed -> group_10.Seed
	    facial_hairz.links.new(group_input_001_14.outputs[19], group_10.inputs[7])
	    #group_input_002_13.Clump Guide Distance -> group_001_9.Guide Distance
	    facial_hairz.links.new(group_input_002_13.outputs[21], group_001_9.inputs[2])
	    #group_input_002_13.Clump Factor -> group_001_9.Factor
	    facial_hairz.links.new(group_input_002_13.outputs[20], group_001_9.inputs[5])
	    #group_input_002_13.Clump Shape -> group_001_9.Shape
	    facial_hairz.links.new(group_input_002_13.outputs[22], group_001_9.inputs[6])
	    #group_input_002_13.Clump Tip Spread -> group_001_9.Tip Spread
	    facial_hairz.links.new(group_input_002_13.outputs[23], group_001_9.inputs[7])
	    #group_input_002_13.Clump Offset -> group_001_9.Clump Offset
	    facial_hairz.links.new(group_input_002_13.outputs[24], group_001_9.inputs[8])
	    #group_input_002_13.Clump Distance Falloff -> group_001_9.Distance Falloff
	    facial_hairz.links.new(group_input_002_13.outputs[25], group_001_9.inputs[9])
	    #group_input_002_13.Clump Distance Threshold -> group_001_9.Distance Threshold
	    facial_hairz.links.new(group_input_002_13.outputs[26], group_001_9.inputs[10])
	    #group_input_002_13.Clump Seed -> group_001_9.Seed
	    facial_hairz.links.new(group_input_002_13.outputs[27], group_001_9.inputs[11])
	    #group_input_002_13.Clump Preserve Length -> group_001_9.Preserve Length
	    facial_hairz.links.new(group_input_002_13.outputs[28], group_001_9.inputs[12])
	    #group_input_003_14.Surface -> group_002_6.Surface
	    facial_hairz.links.new(group_input_003_14.outputs[1], group_002_6.inputs[1])
	    #group_input_003_14.Surface Offset -> group_002_6.Offset
	    facial_hairz.links.new(group_input_003_14.outputs[11], group_002_6.inputs[2])
	    #group_input_005_10.Material -> set_material_4.Material
	    facial_hairz.links.new(group_input_005_10.outputs[2], set_material_4.inputs[2])
	    #reroute_18.Output -> switch_15.False
	    facial_hairz.links.new(reroute_18.outputs[0], switch_15.inputs[1])
	    #reroute_001_14.Output -> capture_attribute_9.Geometry
	    facial_hairz.links.new(reroute_001_14.outputs[0], capture_attribute_9.inputs[0])
	    #position_5.Position -> capture_attribute_9.Position
	    facial_hairz.links.new(position_5.outputs[0], capture_attribute_9.inputs[1])
	    #capture_attribute_9.Position -> vector_math_11.Vector
	    facial_hairz.links.new(capture_attribute_9.outputs[1], vector_math_11.inputs[0])
	    #capture_attribute_9.Geometry -> set_position_7.Geometry
	    facial_hairz.links.new(capture_attribute_9.outputs[0], set_position_7.inputs[0])
	    #vector_math_11.Vector -> set_position_7.Position
	    facial_hairz.links.new(vector_math_11.outputs[0], set_position_7.inputs[2])
	    #reroute_004_13.Output -> join_geometry_7.Geometry
	    facial_hairz.links.new(reroute_004_13.outputs[0], join_geometry_7.inputs[0])
	    #join_geometry_7.Geometry -> switch_15.True
	    facial_hairz.links.new(join_geometry_7.outputs[0], switch_15.inputs[2])
	    #group_input_006_8.Mirror X -> switch_15.Switch
	    facial_hairz.links.new(group_input_006_8.outputs[3], switch_15.inputs[0])
	    #set_material_4.Geometry -> reroute_18.Input
	    facial_hairz.links.new(set_material_4.outputs[0], reroute_18.inputs[0])
	    #reroute_003_13.Output -> reroute_001_14.Input
	    facial_hairz.links.new(reroute_003_13.outputs[0], reroute_001_14.inputs[0])
	    #set_position_7.Geometry -> reroute_002_13.Input
	    facial_hairz.links.new(set_position_7.outputs[0], reroute_002_13.inputs[0])
	    #reroute_005_11.Output -> reroute_003_13.Input
	    facial_hairz.links.new(reroute_005_11.outputs[0], reroute_003_13.inputs[0])
	    #reroute_002_13.Output -> reroute_004_13.Input
	    facial_hairz.links.new(reroute_002_13.outputs[0], reroute_004_13.inputs[0])
	    #reroute_18.Output -> reroute_005_11.Input
	    facial_hairz.links.new(reroute_18.outputs[0], reroute_005_11.inputs[0])
	    #reroute_044.Output -> group_002_6.Geometry
	    facial_hairz.links.new(reroute_044.outputs[0], group_002_6.inputs[0])
	    #group_input_024.Clump Factor -> compare_008_1.A
	    facial_hairz.links.new(group_input_024.outputs[20], compare_008_1.inputs[0])
	    #compare_008_1.Result -> switch_002_6.Switch
	    facial_hairz.links.new(compare_008_1.outputs[0], switch_002_6.inputs[0])
	    #reroute_054.Output -> switch_002_6.True
	    facial_hairz.links.new(reroute_054.outputs[0], switch_002_6.inputs[2])
	    #reroute_057.Output -> switch_002_6.False
	    facial_hairz.links.new(reroute_057.outputs[0], switch_002_6.inputs[1])
	    #reroute_054.Output -> reroute_055.Input
	    facial_hairz.links.new(reroute_054.outputs[0], reroute_055.inputs[0])
	    #group_001_9.Geometry -> reroute_057.Input
	    facial_hairz.links.new(group_001_9.outputs[0], reroute_057.inputs[0])
	    #group_input_008_7.Surface -> group_008.Surface
	    facial_hairz.links.new(group_input_008_7.outputs[1], group_008.inputs[1])
	    #group_input_025.Hair Count -> group_008.Count
	    facial_hairz.links.new(group_input_025.outputs[4], group_008.inputs[3])
	    #group_input_026.Hair Length -> group_008.Length
	    facial_hairz.links.new(group_input_026.outputs[5], group_008.inputs[2])
	    #group_input_010_4.Rotation Factor -> group_008.Rotation Factor
	    facial_hairz.links.new(group_input_010_4.outputs[12], group_008.inputs[4])
	    #reroute_006_10.Output -> group_004_2.Geometry
	    facial_hairz.links.new(reroute_006_10.outputs[0], group_004_2.inputs[0])
	    #group_input_007_8.Frizz Factor -> group_004_2.Factor
	    facial_hairz.links.new(group_input_007_8.outputs[29], group_004_2.inputs[2])
	    #group_input_007_8.Frizz Distance -> group_004_2.Distance
	    facial_hairz.links.new(group_input_007_8.outputs[30], group_004_2.inputs[3])
	    #group_input_007_8.Frizz Shape -> group_004_2.Shape
	    facial_hairz.links.new(group_input_007_8.outputs[31], group_004_2.inputs[4])
	    #group_input_007_8.Frizz Seed -> group_004_2.Seed
	    facial_hairz.links.new(group_input_007_8.outputs[32], group_004_2.inputs[5])
	    #group_input_007_8.Frizz Preserve Length -> group_004_2.Preserve Length
	    facial_hairz.links.new(group_input_007_8.outputs[33], group_004_2.inputs[6])
	    #compare_14.Result -> switch_001_11.Switch
	    facial_hairz.links.new(compare_14.outputs[0], switch_001_11.inputs[0])
	    #group_input_011_2.Frizz Factor -> compare_14.A
	    facial_hairz.links.new(group_input_011_2.outputs[29], compare_14.inputs[0])
	    #reroute_006_10.Output -> switch_001_11.True
	    facial_hairz.links.new(reroute_006_10.outputs[0], switch_001_11.inputs[2])
	    #group_004_2.Geometry -> switch_001_11.False
	    facial_hairz.links.new(group_004_2.outputs[0], switch_001_11.inputs[1])
	    #switch_15.Output -> reroute_006_10.Input
	    facial_hairz.links.new(switch_15.outputs[0], reroute_006_10.inputs[0])
	    #switch_001_11.Output -> reroute_007_10.Input
	    facial_hairz.links.new(switch_001_11.outputs[0], reroute_007_10.inputs[0])
	    #reroute_007_10.Output -> group_005_4.Geometry
	    facial_hairz.links.new(reroute_007_10.outputs[0], group_005_4.inputs[0])
	    #reroute_007_10.Output -> switch_003_7.True
	    facial_hairz.links.new(reroute_007_10.outputs[0], switch_003_7.inputs[2])
	    #group_input_012_3.Roll Factor -> group_005_4.Factor
	    facial_hairz.links.new(group_input_012_3.outputs[34], group_005_4.inputs[1])
	    #group_input_012_3.Roll Subdivision -> group_005_4.Subdivision
	    facial_hairz.links.new(group_input_012_3.outputs[35], group_005_4.inputs[2])
	    #group_input_012_3.Roll Variation Level -> group_005_4.Variation Level
	    facial_hairz.links.new(group_input_012_3.outputs[36], group_005_4.inputs[3])
	    #group_input_012_3.Roll Length -> group_005_4.Roll Length
	    facial_hairz.links.new(group_input_012_3.outputs[37], group_005_4.inputs[4])
	    #group_input_012_3.Roll Radius -> group_005_4.Roll Radius
	    facial_hairz.links.new(group_input_012_3.outputs[38], group_005_4.inputs[5])
	    #group_input_012_3.Roll Depth -> group_005_4.Roll Depth
	    facial_hairz.links.new(group_input_012_3.outputs[39], group_005_4.inputs[6])
	    #group_input_012_3.Roll Taper -> group_005_4.Roll Taper
	    facial_hairz.links.new(group_input_012_3.outputs[40], group_005_4.inputs[7])
	    #group_input_012_3.Roll Retain Overall Shape -> group_005_4.Retain Overall Shape
	    facial_hairz.links.new(group_input_012_3.outputs[41], group_005_4.inputs[8])
	    #group_input_012_3.Roll Random Orientation -> group_005_4.Random Orientation
	    facial_hairz.links.new(group_input_012_3.outputs[42], group_005_4.inputs[10])
	    #group_input_012_3.Roll Seed -> group_005_4.Seed
	    facial_hairz.links.new(group_input_012_3.outputs[43], group_005_4.inputs[11])
	    #group_input_012_3.Roll Preserve Length -> group_005_4.Preserve Length
	    facial_hairz.links.new(group_input_012_3.outputs[44], group_005_4.inputs[12])
	    #group_input_013_2.Roll Factor -> compare_001_6.A
	    facial_hairz.links.new(group_input_013_2.outputs[34], compare_001_6.inputs[0])
	    #compare_001_6.Result -> switch_003_7.Switch
	    facial_hairz.links.new(compare_001_6.outputs[0], switch_003_7.inputs[0])
	    #group_005_4.Geometry -> switch_003_7.False
	    facial_hairz.links.new(group_005_4.outputs[0], switch_003_7.inputs[1])
	    #group_input_027.Use Shrinkwrap -> switch_004_7.Switch
	    facial_hairz.links.new(group_input_027.outputs[10], switch_004_7.inputs[0])
	    #group_002_6.Geometry -> switch_004_7.True
	    facial_hairz.links.new(group_002_6.outputs[0], switch_004_7.inputs[2])
	    #reroute_044.Output -> switch_004_7.False
	    facial_hairz.links.new(reroute_044.outputs[0], switch_004_7.inputs[1])
	    #switch_004_7.Output -> set_material_4.Geometry
	    facial_hairz.links.new(switch_004_7.outputs[0], set_material_4.inputs[0])
	    #final_bake.Geometry -> group_output_22.Geometry
	    facial_hairz.links.new(final_bake.outputs[0], group_output_22.inputs[0])
	    #group_input_016_1.Surface -> group_011.Surface
	    facial_hairz.links.new(group_input_016_1.outputs[1], group_011.inputs[1])
	    #group_input_016_1.UV Map -> group_011.UV Map
	    facial_hairz.links.new(group_input_016_1.outputs[8], group_011.inputs[2])
	    #group_input_016_1.Blend along Curve -> group_011.Blend along Curve
	    facial_hairz.links.new(group_input_016_1.outputs[9], group_011.inputs[3])
	    #switch_002_6.Output -> reroute_044.Input
	    facial_hairz.links.new(switch_002_6.outputs[0], reroute_044.inputs[0])
	    #resample_curve_4.Curve -> set_curve_tilt_2.Curve
	    facial_hairz.links.new(resample_curve_4.outputs[0], set_curve_tilt_2.inputs[0])
	    #set_curve_tilt_2.Curve -> group_008.Curve
	    facial_hairz.links.new(set_curve_tilt_2.outputs[0], group_008.inputs[0])
	    #group_008.Geometry -> group_10.Geometry
	    facial_hairz.links.new(group_008.outputs[0], group_10.inputs[0])
	    #group_input_009_5.Duplicate Amount -> compare_002_8.A
	    facial_hairz.links.new(group_input_009_5.outputs[13], compare_002_8.inputs[2])
	    #compare_002_8.Result -> switch_005_2.Switch
	    facial_hairz.links.new(compare_002_8.outputs[0], switch_005_2.inputs[0])
	    #group_008.Geometry -> switch_005_2.True
	    facial_hairz.links.new(group_008.outputs[0], switch_005_2.inputs[2])
	    #group_10.Geometry -> switch_005_2.False
	    facial_hairz.links.new(group_10.outputs[0], switch_005_2.inputs[1])
	    #compare_002_8.Result -> switch_006_2.Switch
	    facial_hairz.links.new(compare_002_8.outputs[0], switch_006_2.inputs[0])
	    #index_3.Index -> switch_006_2.True
	    facial_hairz.links.new(index_3.outputs[0], switch_006_2.inputs[2])
	    #group_10.Guide Index -> switch_006_2.False
	    facial_hairz.links.new(group_10.outputs[1], switch_006_2.inputs[1])
	    #switch_005_2.Output -> group_011.Geometry
	    facial_hairz.links.new(switch_005_2.outputs[0], group_011.inputs[0])
	    #switch_006_2.Output -> group_001_9.Guide Index
	    facial_hairz.links.new(switch_006_2.outputs[0], group_001_9.inputs[1])
	    #reroute_008_10.Output -> switch_007_1.False
	    facial_hairz.links.new(reroute_008_10.outputs[0], switch_007_1.inputs[1])
	    #reroute_008_10.Output -> group_010.Geometry
	    facial_hairz.links.new(reroute_008_10.outputs[0], group_010.inputs[0])
	    #group_010.Geometry -> switch_007_1.True
	    facial_hairz.links.new(group_010.outputs[0], switch_007_1.inputs[2])
	    #group_input_014_1.Use Mesh -> switch_007_1.Switch
	    facial_hairz.links.new(group_input_014_1.outputs[45], switch_007_1.inputs[0])
	    #group_input_017.Material -> group_010.Material
	    facial_hairz.links.new(group_input_017.outputs[46], group_010.inputs[2])
	    #group_input_017.Resolution -> group_010.Resolution
	    facial_hairz.links.new(group_input_017.outputs[47], group_010.inputs[3])
	    #group_input_017.Width -> group_010.Width
	    facial_hairz.links.new(group_input_017.outputs[48], group_010.inputs[4])
	    #group_input_017.Hair Card Angle -> group_010.Hair Card Angle
	    facial_hairz.links.new(group_input_017.outputs[49], group_010.inputs[7])
	    #curve_bake.Geometry -> reroute_008_10.Input
	    facial_hairz.links.new(curve_bake.outputs[0], reroute_008_10.inputs[0])
	    #switch_003_7.Output -> curve_bake.Geometry
	    facial_hairz.links.new(switch_003_7.outputs[0], curve_bake.inputs[0])
	    #group_input_004_11.Geometry -> separate_components_6.Geometry
	    facial_hairz.links.new(group_input_004_11.outputs[0], separate_components_6.inputs[0])
	    #separate_components_6.Curve -> resample_curve_4.Curve
	    facial_hairz.links.new(separate_components_6.outputs[1], resample_curve_4.inputs[0])
	    #reroute_015_9.Output -> join_geometry_001_3.Geometry
	    facial_hairz.links.new(reroute_015_9.outputs[0], join_geometry_001_3.inputs[0])
	    #separate_components_6.Grease Pencil -> reroute_009_10.Input
	    facial_hairz.links.new(separate_components_6.outputs[2], reroute_009_10.inputs[0])
	    #separate_components_6.Point Cloud -> reroute_010_8.Input
	    facial_hairz.links.new(separate_components_6.outputs[3], reroute_010_8.inputs[0])
	    #separate_components_6.Instances -> reroute_011_9.Input
	    facial_hairz.links.new(separate_components_6.outputs[5], reroute_011_9.inputs[0])
	    #separate_components_6.Volume -> reroute_012_10.Input
	    facial_hairz.links.new(separate_components_6.outputs[4], reroute_012_10.inputs[0])
	    #separate_components_6.Mesh -> reroute_013_9.Input
	    facial_hairz.links.new(separate_components_6.outputs[0], reroute_013_9.inputs[0])
	    #reroute_010_8.Output -> reroute_014_8.Input
	    facial_hairz.links.new(reroute_010_8.outputs[0], reroute_014_8.inputs[0])
	    #reroute_011_9.Output -> reroute_015_9.Input
	    facial_hairz.links.new(reroute_011_9.outputs[0], reroute_015_9.inputs[0])
	    #reroute_012_10.Output -> reroute_016_8.Input
	    facial_hairz.links.new(reroute_012_10.outputs[0], reroute_016_8.inputs[0])
	    #reroute_013_9.Output -> reroute_017_7.Input
	    facial_hairz.links.new(reroute_013_9.outputs[0], reroute_017_7.inputs[0])
	    #reroute_009_10.Output -> reroute_018_7.Input
	    facial_hairz.links.new(reroute_009_10.outputs[0], reroute_018_7.inputs[0])
	    #join_geometry_001_3.Geometry -> final_bake.Geometry
	    facial_hairz.links.new(join_geometry_001_3.outputs[0], final_bake.inputs[0])
	    #spline_parameter_8.Factor -> hair_shape.Value
	    facial_hairz.links.new(spline_parameter_8.outputs[0], hair_shape.inputs[1])
	    #hair_shape.Value -> map_range_3.Value
	    facial_hairz.links.new(hair_shape.outputs[0], map_range_3.inputs[0])
	    #group_input_015_1.Hair Radius -> map_range_3.To Max
	    facial_hairz.links.new(group_input_015_1.outputs[7], map_range_3.inputs[4])
	    #map_range_3.Result -> set_curve_radius_4.Radius
	    facial_hairz.links.new(map_range_3.outputs[0], set_curve_radius_4.inputs[2])
	    #group_011.Geometry -> set_curve_radius_4.Curve
	    facial_hairz.links.new(group_011.outputs[0], set_curve_radius_4.inputs[0])
	    #set_curve_radius_4.Curve -> reroute_054.Input
	    facial_hairz.links.new(set_curve_radius_4.outputs[0], reroute_054.inputs[0])
	    #reroute_005_11.Output -> join_geometry_7.Geometry
	    facial_hairz.links.new(reroute_005_11.outputs[0], join_geometry_7.inputs[0])
	    #reroute_016_8.Output -> join_geometry_001_3.Geometry
	    facial_hairz.links.new(reroute_016_8.outputs[0], join_geometry_001_3.inputs[0])
	    #reroute_014_8.Output -> join_geometry_001_3.Geometry
	    facial_hairz.links.new(reroute_014_8.outputs[0], join_geometry_001_3.inputs[0])
	    #reroute_018_7.Output -> join_geometry_001_3.Geometry
	    facial_hairz.links.new(reroute_018_7.outputs[0], join_geometry_001_3.inputs[0])
	    #reroute_017_7.Output -> join_geometry_001_3.Geometry
	    facial_hairz.links.new(reroute_017_7.outputs[0], join_geometry_001_3.inputs[0])
	    #switch_007_1.Output -> join_geometry_001_3.Geometry
	    facial_hairz.links.new(switch_007_1.outputs[0], join_geometry_001_3.inputs[0])
	    return facial_hairz
	return facial_hairz_node_group()

	

	
