import bpy, mathutils

def node():
	#initialize random_points_on_curves node group
	def random_points_on_curves_node_group():
	    random_points_on_curves = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Random Points on Curves")
	
	    random_points_on_curves.color_tag = 'NONE'
	    random_points_on_curves.description = ""
	    random_points_on_curves.default_group_node_width = 140
	    
	
	    random_points_on_curves.is_modifier = True
	
	    #random_points_on_curves interface
	    #Socket Geometry
	    geometry_socket = random_points_on_curves.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket.attribute_domain = 'POINT'
	
	    #Socket Geometry
	    geometry_socket_1 = random_points_on_curves.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_1.attribute_domain = 'POINT'
	
	    #Socket Count
	    count_socket = random_points_on_curves.interface.new_socket(name = "Count", in_out='INPUT', socket_type = 'NodeSocketInt')
	    count_socket.default_value = 10
	    count_socket.min_value = 0
	    count_socket.max_value = 2147483647
	    count_socket.subtype = 'NONE'
	    count_socket.attribute_domain = 'POINT'
	
	    #Socket Min
	    min_socket = random_points_on_curves.interface.new_socket(name = "Min", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    min_socket.default_value = 0.0
	    min_socket.min_value = -3.4028234663852886e+38
	    min_socket.max_value = 3.4028234663852886e+38
	    min_socket.subtype = 'NONE'
	    min_socket.attribute_domain = 'POINT'
	
	    #Socket Max
	    max_socket = random_points_on_curves.interface.new_socket(name = "Max", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    max_socket.default_value = 1.0
	    max_socket.min_value = 0.0
	    max_socket.max_value = 3.4028234663852886e+38
	    max_socket.subtype = 'NONE'
	    max_socket.attribute_domain = 'POINT'
	
	    #Socket Seed
	    seed_socket = random_points_on_curves.interface.new_socket(name = "Seed", in_out='INPUT', socket_type = 'NodeSocketInt')
	    seed_socket.default_value = 0
	    seed_socket.min_value = -10000
	    seed_socket.max_value = 10000
	    seed_socket.subtype = 'NONE'
	    seed_socket.attribute_domain = 'POINT'
	
	    #Socket Include Curve
	    include_curve_socket = random_points_on_curves.interface.new_socket(name = "Include Curve", in_out='INPUT', socket_type = 'NodeSocketBool')
	    include_curve_socket.default_value = False
	    include_curve_socket.attribute_domain = 'POINT'
	
	
	    #initialize random_points_on_curves nodes
	    #node Group Input
	    group_input = random_points_on_curves.nodes.new("NodeGroupInput")
	    group_input.name = "Group Input"
	    group_input.outputs[0].hide = True
	    group_input.outputs[1].hide = True
	    group_input.outputs[5].hide = True
	    group_input.outputs[6].hide = True
	
	    #node Group Output
	    group_output = random_points_on_curves.nodes.new("NodeGroupOutput")
	    group_output.name = "Group Output"
	    group_output.is_active_output = True
	
	    #node Points
	    points = random_points_on_curves.nodes.new("GeometryNodePoints")
	    points.name = "Points"
	    points.hide = True
	    points.inputs[2].hide = True
	    #Radius
	    points.inputs[2].default_value = 0.10000000149011612
	
	    #node Sample Curve
	    sample_curve = random_points_on_curves.nodes.new("GeometryNodeSampleCurve")
	    sample_curve.name = "Sample Curve"
	    sample_curve.hide = True
	    sample_curve.data_type = 'FLOAT'
	    sample_curve.mode = 'FACTOR'
	    sample_curve.use_all_curves = False
	    sample_curve.inputs[1].hide = True
	    sample_curve.inputs[3].hide = True
	    sample_curve.outputs[0].hide = True
	    sample_curve.outputs[2].hide = True
	    sample_curve.outputs[3].hide = True
	    #Value
	    sample_curve.inputs[1].default_value = 0.0
	
	    #node Join Geometry
	    join_geometry = random_points_on_curves.nodes.new("GeometryNodeJoinGeometry")
	    join_geometry.name = "Join Geometry"
	    join_geometry.hide = True
	
	    #node Random Value
	    random_value = random_points_on_curves.nodes.new("FunctionNodeRandomValue")
	    random_value.name = "Random Value"
	    random_value.hide = True
	    random_value.data_type = 'FLOAT'
	    random_value.inputs[0].hide = True
	    random_value.inputs[1].hide = True
	    random_value.inputs[4].hide = True
	    random_value.inputs[5].hide = True
	    random_value.inputs[6].hide = True
	    random_value.inputs[7].hide = True
	    random_value.outputs[0].hide = True
	    random_value.outputs[2].hide = True
	    random_value.outputs[3].hide = True
	    #ID
	    random_value.inputs[7].default_value = 0
	
	    #node Domain Size
	    domain_size = random_points_on_curves.nodes.new("GeometryNodeAttributeDomainSize")
	    domain_size.name = "Domain Size"
	    domain_size.hide = True
	    domain_size.component = 'CURVE'
	    domain_size.outputs[0].hide = True
	    domain_size.outputs[1].hide = True
	    domain_size.outputs[2].hide = True
	    domain_size.outputs[3].hide = True
	    domain_size.outputs[5].hide = True
	    domain_size.outputs[6].hide = True
	
	    #node Random Value.001
	    random_value_001 = random_points_on_curves.nodes.new("FunctionNodeRandomValue")
	    random_value_001.name = "Random Value.001"
	    random_value_001.hide = True
	    random_value_001.data_type = 'INT'
	    random_value_001.inputs[0].hide = True
	    random_value_001.inputs[1].hide = True
	    random_value_001.inputs[2].hide = True
	    random_value_001.inputs[3].hide = True
	    random_value_001.inputs[4].hide = True
	    random_value_001.inputs[6].hide = True
	    random_value_001.inputs[7].hide = True
	    random_value_001.inputs[8].hide = True
	    random_value_001.outputs[0].hide = True
	    random_value_001.outputs[1].hide = True
	    random_value_001.outputs[3].hide = True
	    #Min_002
	    random_value_001.inputs[4].default_value = 0
	    #ID
	    random_value_001.inputs[7].default_value = 0
	    #Seed
	    random_value_001.inputs[8].default_value = 0
	
	    #node Math
	    math = random_points_on_curves.nodes.new("ShaderNodeMath")
	    math.name = "Math"
	    math.hide = True
	    math.operation = 'SUBTRACT'
	    math.use_clamp = False
	    #Value_001
	    math.inputs[1].default_value = 1.0
	
	    #node Group Input.001
	    group_input_001 = random_points_on_curves.nodes.new("NodeGroupInput")
	    group_input_001.name = "Group Input.001"
	    group_input_001.outputs[1].hide = True
	    group_input_001.outputs[2].hide = True
	    group_input_001.outputs[3].hide = True
	    group_input_001.outputs[4].hide = True
	    group_input_001.outputs[5].hide = True
	    group_input_001.outputs[6].hide = True
	
	    #node Group Input.002
	    group_input_002 = random_points_on_curves.nodes.new("NodeGroupInput")
	    group_input_002.name = "Group Input.002"
	    group_input_002.outputs[1].hide = True
	    group_input_002.outputs[2].hide = True
	    group_input_002.outputs[3].hide = True
	    group_input_002.outputs[4].hide = True
	    group_input_002.outputs[5].hide = True
	    group_input_002.outputs[6].hide = True
	
	    #node Group Input.003
	    group_input_003 = random_points_on_curves.nodes.new("NodeGroupInput")
	    group_input_003.name = "Group Input.003"
	    group_input_003.outputs[1].hide = True
	    group_input_003.outputs[2].hide = True
	    group_input_003.outputs[3].hide = True
	    group_input_003.outputs[4].hide = True
	    group_input_003.outputs[5].hide = True
	    group_input_003.outputs[6].hide = True
	
	    #node Group Input.004
	    group_input_004 = random_points_on_curves.nodes.new("NodeGroupInput")
	    group_input_004.name = "Group Input.004"
	    group_input_004.outputs[0].hide = True
	    group_input_004.outputs[2].hide = True
	    group_input_004.outputs[3].hide = True
	    group_input_004.outputs[4].hide = True
	    group_input_004.outputs[5].hide = True
	    group_input_004.outputs[6].hide = True
	
	    #node Switch
	    switch = random_points_on_curves.nodes.new("GeometryNodeSwitch")
	    switch.name = "Switch"
	    switch.hide = True
	    switch.input_type = 'GEOMETRY'
	
	    #node Group Input.005
	    group_input_005 = random_points_on_curves.nodes.new("NodeGroupInput")
	    group_input_005.name = "Group Input.005"
	    group_input_005.outputs[0].hide = True
	    group_input_005.outputs[1].hide = True
	    group_input_005.outputs[2].hide = True
	    group_input_005.outputs[3].hide = True
	    group_input_005.outputs[4].hide = True
	    group_input_005.outputs[6].hide = True
	
	    #node Reroute
	    reroute = random_points_on_curves.nodes.new("NodeReroute")
	    reroute.name = "Reroute"
	    reroute.socket_idname = "NodeSocketGeometry"
	    #node Reroute.001
	    reroute_001 = random_points_on_curves.nodes.new("NodeReroute")
	    reroute_001.name = "Reroute.001"
	    reroute_001.socket_idname = "NodeSocketGeometry"
	    #node Store Named Attribute.001
	    store_named_attribute_001 = random_points_on_curves.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_001.name = "Store Named Attribute.001"
	    store_named_attribute_001.data_type = 'FLOAT'
	    store_named_attribute_001.domain = 'POINT'
	    #Selection
	    store_named_attribute_001.inputs[1].default_value = True
	    #Name
	    store_named_attribute_001.inputs[2].default_value = "factor"
	
	    #node Store Named Attribute.002
	    store_named_attribute_002 = random_points_on_curves.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_002.name = "Store Named Attribute.002"
	    store_named_attribute_002.data_type = 'INT'
	    store_named_attribute_002.domain = 'POINT'
	    #Selection
	    store_named_attribute_002.inputs[1].default_value = True
	    #Name
	    store_named_attribute_002.inputs[2].default_value = "curve_attached_idx"
	
	    #node Reroute.002
	    reroute_002 = random_points_on_curves.nodes.new("NodeReroute")
	    reroute_002.name = "Reroute.002"
	    reroute_002.socket_idname = "NodeSocketFloat"
	    #node Reroute.003
	    reroute_003 = random_points_on_curves.nodes.new("NodeReroute")
	    reroute_003.name = "Reroute.003"
	    reroute_003.socket_idname = "NodeSocketFloat"
	    #node Reroute.004
	    reroute_004 = random_points_on_curves.nodes.new("NodeReroute")
	    reroute_004.name = "Reroute.004"
	    reroute_004.socket_idname = "NodeSocketInt"
	    #node Reroute.005
	    reroute_005 = random_points_on_curves.nodes.new("NodeReroute")
	    reroute_005.name = "Reroute.005"
	    reroute_005.socket_idname = "NodeSocketInt"
	    #node Reroute.006
	    reroute_006 = random_points_on_curves.nodes.new("NodeReroute")
	    reroute_006.name = "Reroute.006"
	    reroute_006.socket_idname = "NodeSocketInt"
	    #node Store Named Attribute.003
	    store_named_attribute_003 = random_points_on_curves.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_003.name = "Store Named Attribute.003"
	    store_named_attribute_003.data_type = 'FLOAT_VECTOR'
	    store_named_attribute_003.domain = 'POINT'
	    #Selection
	    store_named_attribute_003.inputs[1].default_value = True
	    #Name
	    store_named_attribute_003.inputs[2].default_value = "pt_tangent"
	
	    #node Store Named Attribute.004
	    store_named_attribute_004 = random_points_on_curves.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_004.name = "Store Named Attribute.004"
	    store_named_attribute_004.data_type = 'FLOAT_VECTOR'
	    store_named_attribute_004.domain = 'POINT'
	    #Selection
	    store_named_attribute_004.inputs[1].default_value = True
	    #Name
	    store_named_attribute_004.inputs[2].default_value = "pt_normal"
	
	    #node Sample Curve.001
	    sample_curve_001 = random_points_on_curves.nodes.new("GeometryNodeSampleCurve")
	    sample_curve_001.name = "Sample Curve.001"
	    sample_curve_001.data_type = 'FLOAT'
	    sample_curve_001.mode = 'FACTOR'
	    sample_curve_001.use_all_curves = False
	    sample_curve_001.inputs[1].hide = True
	    sample_curve_001.inputs[3].hide = True
	    sample_curve_001.outputs[0].hide = True
	    sample_curve_001.outputs[1].hide = True
	    #Value
	    sample_curve_001.inputs[1].default_value = 0.0
	
	    #node Named Attribute
	    named_attribute = random_points_on_curves.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute.name = "Named Attribute"
	    named_attribute.data_type = 'FLOAT'
	    #Name
	    named_attribute.inputs[0].default_value = "factor"
	
	    #node Named Attribute.001
	    named_attribute_001 = random_points_on_curves.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute_001.name = "Named Attribute.001"
	    named_attribute_001.data_type = 'INT'
	    #Name
	    named_attribute_001.inputs[0].default_value = "curve_attached_idx"
	
	    #node Group Input.006
	    group_input_006 = random_points_on_curves.nodes.new("NodeGroupInput")
	    group_input_006.name = "Group Input.006"
	    group_input_006.outputs[1].hide = True
	    group_input_006.outputs[2].hide = True
	    group_input_006.outputs[3].hide = True
	    group_input_006.outputs[4].hide = True
	    group_input_006.outputs[5].hide = True
	    group_input_006.outputs[6].hide = True
	
	    #node Align Rotation to Vector
	    align_rotation_to_vector = random_points_on_curves.nodes.new("FunctionNodeAlignRotationToVector")
	    align_rotation_to_vector.name = "Align Rotation to Vector"
	    align_rotation_to_vector.axis = 'Z'
	    align_rotation_to_vector.pivot_axis = 'AUTO'
	    align_rotation_to_vector.inputs[0].hide = True
	    align_rotation_to_vector.inputs[1].hide = True
	    #Rotation
	    align_rotation_to_vector.inputs[0].default_value = (0.0, 0.0, 0.0)
	    #Factor
	    align_rotation_to_vector.inputs[1].default_value = 1.0
	
	    #node Store Named Attribute.005
	    store_named_attribute_005 = random_points_on_curves.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_005.name = "Store Named Attribute.005"
	    store_named_attribute_005.data_type = 'FLOAT_VECTOR'
	    store_named_attribute_005.domain = 'POINT'
	    #Selection
	    store_named_attribute_005.inputs[1].default_value = True
	    #Name
	    store_named_attribute_005.inputs[2].default_value = "pt_rotation"
	
	    #node Vector Math
	    vector_math = random_points_on_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math.name = "Vector Math"
	    vector_math.operation = 'SCALE'
	    #Scale
	    vector_math.inputs[3].default_value = -1.0
	
	
	
	
	
	    #Set locations
	    group_input.location = (-340.0, 138.4361114501953)
	    group_output.location = (2122.140380859375, 81.65511322021484)
	    points.location = (494.22833251953125, -16.485088348388672)
	    sample_curve.location = (285.0389404296875, -24.79682159423828)
	    join_geometry.location = (1763.0184326171875, 28.69400405883789)
	    random_value.location = (-170.525390625, 95.87518310546875)
	    domain_size.location = (-169.74256896972656, 8.17296314239502)
	    random_value_001.location = (4.170151710510254, -35.207176208496094)
	    math.location = (5.162782669067383, 0.03237735480070114)
	    group_input_001.location = (106.94992065429688, 113.26591491699219)
	    group_input_002.location = (667.21923828125, -150.743896484375)
	    group_input_003.location = (-340.0, 30.563812255859375)
	    group_input_004.location = (297.7091064453125, 109.6701431274414)
	    switch.location = (1935.2496337890625, 58.812049865722656)
	    group_input_005.location = (1797.56396484375, 126.50640869140625)
	    reroute.location = (1761.5303955078125, 46.373321533203125)
	    reroute_001.location = (1764.2421875, -29.402347564697266)
	    store_named_attribute_001.location = (681.8870239257812, 78.00373840332031)
	    store_named_attribute_002.location = (861.8823852539062, 78.00373840332031)
	    reroute_002.location = (23.54385757446289, 85.78327178955078)
	    reroute_003.location = (27.09794807434082, -96.61649322509766)
	    reroute_004.location = (187.45448303222656, -46.4659423828125)
	    reroute_005.location = (188.3718719482422, -137.13870239257812)
	    reroute_006.location = (863.0440673828125, -134.8905487060547)
	    store_named_attribute_003.location = (1055.646484375, 78.00373840332031)
	    store_named_attribute_004.location = (1253.864990234375, 78.00373840332031)
	    sample_curve_001.location = (875.5424194335938, -154.51980590820312)
	    named_attribute.location = (666.8489379882812, -213.5001983642578)
	    named_attribute_001.location = (666.8489379882812, -343.0633850097656)
	    group_input_006.location = (1601.80419921875, 4.149496078491211)
	    align_rotation_to_vector.location = (1254.329833984375, -116.90047454833984)
	    store_named_attribute_005.location = (1439.94482421875, 78.00373840332031)
	    vector_math.location = (1074.0, -201.5477294921875)
	
	    #Set dimensions
	    group_input.width, group_input.height = 140.0, 100.0
	    group_output.width, group_output.height = 140.0, 100.0
	    points.width, points.height = 140.0, 100.0
	    sample_curve.width, sample_curve.height = 140.0, 100.0
	    join_geometry.width, join_geometry.height = 140.0, 100.0
	    random_value.width, random_value.height = 140.0, 100.0
	    domain_size.width, domain_size.height = 140.0, 100.0
	    random_value_001.width, random_value_001.height = 140.0, 100.0
	    math.width, math.height = 140.0, 100.0
	    group_input_001.width, group_input_001.height = 140.0, 100.0
	    group_input_002.width, group_input_002.height = 140.0, 100.0
	    group_input_003.width, group_input_003.height = 140.0, 100.0
	    group_input_004.width, group_input_004.height = 140.0, 100.0
	    switch.width, switch.height = 140.0, 100.0
	    group_input_005.width, group_input_005.height = 140.0, 100.0
	    reroute.width, reroute.height = 100.0, 100.0
	    reroute_001.width, reroute_001.height = 100.0, 100.0
	    store_named_attribute_001.width, store_named_attribute_001.height = 140.0, 100.0
	    store_named_attribute_002.width, store_named_attribute_002.height = 140.0, 100.0
	    reroute_002.width, reroute_002.height = 100.0, 100.0
	    reroute_003.width, reroute_003.height = 100.0, 100.0
	    reroute_004.width, reroute_004.height = 100.0, 100.0
	    reroute_005.width, reroute_005.height = 100.0, 100.0
	    reroute_006.width, reroute_006.height = 100.0, 100.0
	    store_named_attribute_003.width, store_named_attribute_003.height = 140.0, 100.0
	    store_named_attribute_004.width, store_named_attribute_004.height = 140.0, 100.0
	    sample_curve_001.width, sample_curve_001.height = 140.0, 100.0
	    named_attribute.width, named_attribute.height = 140.0, 100.0
	    named_attribute_001.width, named_attribute_001.height = 140.0, 100.0
	    group_input_006.width, group_input_006.height = 140.0, 100.0
	    align_rotation_to_vector.width, align_rotation_to_vector.height = 140.0, 100.0
	    store_named_attribute_005.width, store_named_attribute_005.height = 140.0, 100.0
	    vector_math.width, vector_math.height = 140.0, 100.0
	
	    #initialize random_points_on_curves links
	    #sample_curve.Position -> points.Position
	    random_points_on_curves.links.new(sample_curve.outputs[1], points.inputs[1])
	    #reroute.Output -> join_geometry.Geometry
	    random_points_on_curves.links.new(reroute.outputs[0], join_geometry.inputs[0])
	    #reroute_002.Output -> sample_curve.Factor
	    random_points_on_curves.links.new(reroute_002.outputs[0], sample_curve.inputs[2])
	    #math.Value -> random_value_001.Max
	    random_points_on_curves.links.new(math.outputs[0], random_value_001.inputs[5])
	    #reroute_004.Output -> sample_curve.Curve Index
	    random_points_on_curves.links.new(reroute_004.outputs[0], sample_curve.inputs[4])
	    #domain_size.Spline Count -> math.Value
	    random_points_on_curves.links.new(domain_size.outputs[4], math.inputs[0])
	    #group_input.Min -> random_value.Min
	    random_points_on_curves.links.new(group_input.outputs[2], random_value.inputs[2])
	    #group_input.Max -> random_value.Max
	    random_points_on_curves.links.new(group_input.outputs[3], random_value.inputs[3])
	    #group_input.Seed -> random_value.Seed
	    random_points_on_curves.links.new(group_input.outputs[4], random_value.inputs[8])
	    #group_input_001.Geometry -> sample_curve.Curves
	    random_points_on_curves.links.new(group_input_001.outputs[0], sample_curve.inputs[0])
	    #group_input_003.Geometry -> domain_size.Geometry
	    random_points_on_curves.links.new(group_input_003.outputs[0], domain_size.inputs[0])
	    #group_input_004.Count -> points.Count
	    random_points_on_curves.links.new(group_input_004.outputs[1], points.inputs[0])
	    #group_input_005.Include Curve -> switch.Switch
	    random_points_on_curves.links.new(group_input_005.outputs[5], switch.inputs[0])
	    #reroute.Output -> switch.False
	    random_points_on_curves.links.new(reroute.outputs[0], switch.inputs[1])
	    #join_geometry.Geometry -> switch.True
	    random_points_on_curves.links.new(join_geometry.outputs[0], switch.inputs[2])
	    #switch.Output -> group_output.Geometry
	    random_points_on_curves.links.new(switch.outputs[0], group_output.inputs[0])
	    #store_named_attribute_005.Geometry -> reroute.Input
	    random_points_on_curves.links.new(store_named_attribute_005.outputs[0], reroute.inputs[0])
	    #points.Points -> store_named_attribute_001.Geometry
	    random_points_on_curves.links.new(points.outputs[0], store_named_attribute_001.inputs[0])
	    #reroute_003.Output -> store_named_attribute_001.Value
	    random_points_on_curves.links.new(reroute_003.outputs[0], store_named_attribute_001.inputs[3])
	    #store_named_attribute_001.Geometry -> store_named_attribute_002.Geometry
	    random_points_on_curves.links.new(store_named_attribute_001.outputs[0], store_named_attribute_002.inputs[0])
	    #reroute_006.Output -> store_named_attribute_002.Value
	    random_points_on_curves.links.new(reroute_006.outputs[0], store_named_attribute_002.inputs[3])
	    #random_value.Value -> reroute_002.Input
	    random_points_on_curves.links.new(random_value.outputs[1], reroute_002.inputs[0])
	    #reroute_002.Output -> reroute_003.Input
	    random_points_on_curves.links.new(reroute_002.outputs[0], reroute_003.inputs[0])
	    #random_value_001.Value -> reroute_004.Input
	    random_points_on_curves.links.new(random_value_001.outputs[2], reroute_004.inputs[0])
	    #reroute_004.Output -> reroute_005.Input
	    random_points_on_curves.links.new(reroute_004.outputs[0], reroute_005.inputs[0])
	    #reroute_005.Output -> reroute_006.Input
	    random_points_on_curves.links.new(reroute_005.outputs[0], reroute_006.inputs[0])
	    #store_named_attribute_002.Geometry -> store_named_attribute_003.Geometry
	    random_points_on_curves.links.new(store_named_attribute_002.outputs[0], store_named_attribute_003.inputs[0])
	    #store_named_attribute_003.Geometry -> store_named_attribute_004.Geometry
	    random_points_on_curves.links.new(store_named_attribute_003.outputs[0], store_named_attribute_004.inputs[0])
	    #group_input_002.Geometry -> sample_curve_001.Curves
	    random_points_on_curves.links.new(group_input_002.outputs[0], sample_curve_001.inputs[0])
	    #named_attribute.Attribute -> sample_curve_001.Factor
	    random_points_on_curves.links.new(named_attribute.outputs[0], sample_curve_001.inputs[2])
	    #named_attribute_001.Attribute -> sample_curve_001.Curve Index
	    random_points_on_curves.links.new(named_attribute_001.outputs[0], sample_curve_001.inputs[4])
	    #sample_curve_001.Tangent -> store_named_attribute_003.Value
	    random_points_on_curves.links.new(sample_curve_001.outputs[2], store_named_attribute_003.inputs[3])
	    #sample_curve_001.Normal -> store_named_attribute_004.Value
	    random_points_on_curves.links.new(sample_curve_001.outputs[3], store_named_attribute_004.inputs[3])
	    #group_input_006.Geometry -> reroute_001.Input
	    random_points_on_curves.links.new(group_input_006.outputs[0], reroute_001.inputs[0])
	    #store_named_attribute_004.Geometry -> store_named_attribute_005.Geometry
	    random_points_on_curves.links.new(store_named_attribute_004.outputs[0], store_named_attribute_005.inputs[0])
	    #align_rotation_to_vector.Rotation -> store_named_attribute_005.Value
	    random_points_on_curves.links.new(align_rotation_to_vector.outputs[0], store_named_attribute_005.inputs[3])
	    #vector_math.Vector -> align_rotation_to_vector.Vector
	    random_points_on_curves.links.new(vector_math.outputs[0], align_rotation_to_vector.inputs[2])
	    #sample_curve_001.Tangent -> vector_math.Vector
	    random_points_on_curves.links.new(sample_curve_001.outputs[2], vector_math.inputs[0])
	    #reroute_001.Output -> join_geometry.Geometry
	    random_points_on_curves.links.new(reroute_001.outputs[0], join_geometry.inputs[0])
	    return random_points_on_curves
	
	random_points_on_curves = random_points_on_curves_node_group()
	
	#initialize mesh_geometry_priority node group
	def mesh_geometry_priority_node_group():
	    mesh_geometry_priority = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Mesh Geometry Priority")
	
	    mesh_geometry_priority.color_tag = 'NONE'
	    mesh_geometry_priority.description = ""
	    mesh_geometry_priority.default_group_node_width = 140
	    
	
	
	    #mesh_geometry_priority interface
	    #Socket Geometry
	    geometry_socket_2 = mesh_geometry_priority.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_2.attribute_domain = 'POINT'
	
	    #Socket Geometry
	    geometry_socket_3 = mesh_geometry_priority.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_3.attribute_domain = 'POINT'
	
	    #Socket Object
	    object_socket = mesh_geometry_priority.interface.new_socket(name = "Object", in_out='INPUT', socket_type = 'NodeSocketObject')
	    object_socket.attribute_domain = 'POINT'
	
	
	    #initialize mesh_geometry_priority nodes
	    #node Group Output
	    group_output_1 = mesh_geometry_priority.nodes.new("NodeGroupOutput")
	    group_output_1.name = "Group Output"
	    group_output_1.is_active_output = True
	
	    #node Group Input
	    group_input_1 = mesh_geometry_priority.nodes.new("NodeGroupInput")
	    group_input_1.name = "Group Input"
	
	    #node Object Info
	    object_info = mesh_geometry_priority.nodes.new("GeometryNodeObjectInfo")
	    object_info.name = "Object Info"
	    object_info.hide = True
	    object_info.transform_space = 'RELATIVE'
	    object_info.inputs[1].hide = True
	    object_info.outputs[0].hide = True
	    object_info.outputs[1].hide = True
	    object_info.outputs[2].hide = True
	    object_info.outputs[3].hide = True
	    #As Instance
	    object_info.inputs[1].default_value = False
	
	    #node Switch.001
	    switch_001 = mesh_geometry_priority.nodes.new("GeometryNodeSwitch")
	    switch_001.name = "Switch.001"
	    switch_001.hide = True
	    switch_001.input_type = 'GEOMETRY'
	
	    #node Domain Size
	    domain_size_1 = mesh_geometry_priority.nodes.new("GeometryNodeAttributeDomainSize")
	    domain_size_1.name = "Domain Size"
	    domain_size_1.hide = True
	    domain_size_1.component = 'MESH'
	    domain_size_1.outputs[1].hide = True
	    domain_size_1.outputs[2].hide = True
	    domain_size_1.outputs[3].hide = True
	    domain_size_1.outputs[4].hide = True
	    domain_size_1.outputs[5].hide = True
	    domain_size_1.outputs[6].hide = True
	
	    #node Compare.002
	    compare_002 = mesh_geometry_priority.nodes.new("FunctionNodeCompare")
	    compare_002.name = "Compare.002"
	    compare_002.hide = True
	    compare_002.data_type = 'FLOAT'
	    compare_002.mode = 'ELEMENT'
	    compare_002.operation = 'EQUAL'
	    #B
	    compare_002.inputs[1].default_value = 0.0
	    #Epsilon
	    compare_002.inputs[12].default_value = 0.0
	
	    #node Reroute
	    reroute_1 = mesh_geometry_priority.nodes.new("NodeReroute")
	    reroute_1.name = "Reroute"
	    reroute_1.socket_idname = "NodeSocketGeometry"
	
	
	
	
	    #Set locations
	    group_output_1.location = (331.4979553222656, 0.0)
	    group_input_1.location = (-341.49798583984375, 0.0)
	    object_info.location = (-141.49798583984375, -48.543128967285156)
	    switch_001.location = (141.49795532226562, -25.427536010742188)
	    domain_size_1.location = (-37.58526611328125, 25.427532196044922)
	    compare_002.location = (138.00750732421875, 13.003349304199219)
	    reroute_1.location = (-98.26019287109375, -34.39356231689453)
	
	    #Set dimensions
	    group_output_1.width, group_output_1.height = 140.0, 100.0
	    group_input_1.width, group_input_1.height = 140.0, 100.0
	    object_info.width, object_info.height = 140.0, 100.0
	    switch_001.width, switch_001.height = 140.0, 100.0
	    domain_size_1.width, domain_size_1.height = 140.0, 100.0
	    compare_002.width, compare_002.height = 140.0, 100.0
	    reroute_1.width, reroute_1.height = 100.0, 100.0
	
	    #initialize mesh_geometry_priority links
	    #reroute_1.Output -> domain_size_1.Geometry
	    mesh_geometry_priority.links.new(reroute_1.outputs[0], domain_size_1.inputs[0])
	    #domain_size_1.Point Count -> compare_002.A
	    mesh_geometry_priority.links.new(domain_size_1.outputs[0], compare_002.inputs[0])
	    #compare_002.Result -> switch_001.Switch
	    mesh_geometry_priority.links.new(compare_002.outputs[0], switch_001.inputs[0])
	    #object_info.Geometry -> switch_001.True
	    mesh_geometry_priority.links.new(object_info.outputs[4], switch_001.inputs[2])
	    #reroute_1.Output -> switch_001.False
	    mesh_geometry_priority.links.new(reroute_1.outputs[0], switch_001.inputs[1])
	    #group_input_1.Object -> object_info.Object
	    mesh_geometry_priority.links.new(group_input_1.outputs[1], object_info.inputs[0])
	    #group_input_1.Geometry -> reroute_1.Input
	    mesh_geometry_priority.links.new(group_input_1.outputs[0], reroute_1.inputs[0])
	    #switch_001.Output -> group_output_1.Geometry
	    mesh_geometry_priority.links.new(switch_001.outputs[0], group_output_1.inputs[0])
	    return mesh_geometry_priority
	
	mesh_geometry_priority = mesh_geometry_priority_node_group()
	
	#initialize random_curve_placement_assets node group
	def random_curve_placement_assets_node_group():
	    random_curve_placement_assets = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "RANDOM_CURVE_PLACEMENT_ASSETS")
	
	    random_curve_placement_assets.color_tag = 'NONE'
	    random_curve_placement_assets.description = "Randomly place assets along curve."
	    random_curve_placement_assets.default_group_node_width = 140
	    
	
	    random_curve_placement_assets.is_modifier = True
	
	    #random_curve_placement_assets interface
	    #Socket Geometry
	    geometry_socket_4 = random_curve_placement_assets.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_4.attribute_domain = 'POINT'
	    geometry_socket_4.description = "Curve and assets."
	
	    #Socket Geometry
	    geometry_socket_5 = random_curve_placement_assets.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_5.attribute_domain = 'POINT'
	    geometry_socket_5.description = "Curve Guide."
	
	    #Socket Asset
	    asset_socket = random_curve_placement_assets.interface.new_socket(name = "Asset", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    asset_socket.attribute_domain = 'POINT'
	    asset_socket.description = "Single asset to distribute along curve."
	
	    #Socket Asset
	    asset_socket_1 = random_curve_placement_assets.interface.new_socket(name = "Asset", in_out='INPUT', socket_type = 'NodeSocketObject')
	    asset_socket_1.attribute_domain = 'POINT'
	    asset_socket_1.description = "Single asset to distribute along curve."
	
	    #Socket Asset Collection
	    asset_collection_socket = random_curve_placement_assets.interface.new_socket(name = "Asset Collection", in_out='INPUT', socket_type = 'NodeSocketCollection')
	    asset_collection_socket.attribute_domain = 'POINT'
	    asset_collection_socket.description = "Collection of assets to distribute along curve."
	
	    #Socket Count
	    count_socket_1 = random_curve_placement_assets.interface.new_socket(name = "Count", in_out='INPUT', socket_type = 'NodeSocketInt')
	    count_socket_1.default_value = 1
	    count_socket_1.min_value = 0
	    count_socket_1.max_value = 2147483647
	    count_socket_1.subtype = 'NONE'
	    count_socket_1.attribute_domain = 'POINT'
	    count_socket_1.description = "Amount of assets to use."
	
	    #Socket Min Factor
	    min_factor_socket = random_curve_placement_assets.interface.new_socket(name = "Min Factor", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    min_factor_socket.default_value = 0.0
	    min_factor_socket.min_value = -3.4028234663852886e+38
	    min_factor_socket.max_value = 3.4028234663852886e+38
	    min_factor_socket.subtype = 'NONE'
	    min_factor_socket.attribute_domain = 'POINT'
	    min_factor_socket.description = "Minimal factor for random placement."
	
	    #Socket Max Factor
	    max_factor_socket = random_curve_placement_assets.interface.new_socket(name = "Max Factor", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    max_factor_socket.default_value = 1.0
	    max_factor_socket.min_value = 0.0
	    max_factor_socket.max_value = 3.4028234663852886e+38
	    max_factor_socket.subtype = 'NONE'
	    max_factor_socket.attribute_domain = 'POINT'
	    max_factor_socket.description = "Maximum factor for random placement."
	
	    #Socket Position Seed
	    position_seed_socket = random_curve_placement_assets.interface.new_socket(name = "Position Seed", in_out='INPUT', socket_type = 'NodeSocketInt')
	    position_seed_socket.default_value = 0
	    position_seed_socket.min_value = -10000
	    position_seed_socket.max_value = 10000
	    position_seed_socket.subtype = 'NONE'
	    position_seed_socket.attribute_domain = 'POINT'
	    position_seed_socket.description = "Random seed for asset distribution."
	
	    #Socket Asset Scale
	    asset_scale_socket = random_curve_placement_assets.interface.new_socket(name = "Asset Scale", in_out='INPUT', socket_type = 'NodeSocketVector')
	    asset_scale_socket.default_value = (1.0, 1.0, 1.0)
	    asset_scale_socket.min_value = -3.4028234663852886e+38
	    asset_scale_socket.max_value = 3.4028234663852886e+38
	    asset_scale_socket.subtype = 'XYZ'
	    asset_scale_socket.attribute_domain = 'POINT'
	    asset_scale_socket.description = "Scale for asset."
	
	    #Socket Instance Index
	    instance_index_socket = random_curve_placement_assets.interface.new_socket(name = "Instance Index", in_out='INPUT', socket_type = 'NodeSocketInt')
	    instance_index_socket.default_value = -1
	    instance_index_socket.min_value = -1
	    instance_index_socket.max_value = 2147483647
	    instance_index_socket.subtype = 'NONE'
	    instance_index_socket.attribute_domain = 'POINT'
	    instance_index_socket.hide_value = True
	    instance_index_socket.description = "Index of asset collection to use. (-1=all assets)"
	
	    #Socket Asset Collection Seed
	    asset_collection_seed_socket = random_curve_placement_assets.interface.new_socket(name = "Asset Collection Seed", in_out='INPUT', socket_type = 'NodeSocketInt')
	    asset_collection_seed_socket.default_value = 0
	    asset_collection_seed_socket.min_value = -10000
	    asset_collection_seed_socket.max_value = 10000
	    asset_collection_seed_socket.subtype = 'NONE'
	    asset_collection_seed_socket.attribute_domain = 'POINT'
	    asset_collection_seed_socket.description = "Random seed for asset collection index to use. (only valid if all assets are used)"
	
	
	    #initialize random_curve_placement_assets nodes
	    #node Group Input
	    group_input_2 = random_curve_placement_assets.nodes.new("NodeGroupInput")
	    group_input_2.name = "Group Input"
	    group_input_2.outputs[1].hide = True
	    group_input_2.outputs[2].hide = True
	    group_input_2.outputs[3].hide = True
	    group_input_2.outputs[4].hide = True
	    group_input_2.outputs[5].hide = True
	    group_input_2.outputs[6].hide = True
	    group_input_2.outputs[7].hide = True
	    group_input_2.outputs[8].hide = True
	    group_input_2.outputs[9].hide = True
	    group_input_2.outputs[10].hide = True
	    group_input_2.outputs[11].hide = True
	
	    #node Group Output
	    group_output_2 = random_curve_placement_assets.nodes.new("NodeGroupOutput")
	    group_output_2.name = "Group Output"
	    group_output_2.is_active_output = True
	    group_output_2.inputs[1].hide = True
	
	    #node Group
	    group = random_curve_placement_assets.nodes.new("GeometryNodeGroup")
	    group.name = "Group"
	    group.node_tree = random_points_on_curves
	    group.inputs[5].hide = True
	    #Socket_6
	    group.inputs[5].default_value = False
	
	    #node Instance on Points
	    instance_on_points = random_curve_placement_assets.nodes.new("GeometryNodeInstanceOnPoints")
	    instance_on_points.name = "Instance on Points"
	    instance_on_points.inputs[1].hide = True
	    instance_on_points.inputs[3].hide = True
	    instance_on_points.inputs[4].hide = True
	    #Selection
	    instance_on_points.inputs[1].default_value = True
	    #Pick Instance
	    instance_on_points.inputs[3].default_value = False
	    #Instance Index
	    instance_on_points.inputs[4].default_value = 0
	
	    #node Named Attribute
	    named_attribute_1 = random_curve_placement_assets.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute_1.name = "Named Attribute"
	    named_attribute_1.data_type = 'FLOAT_VECTOR'
	    #Name
	    named_attribute_1.inputs[0].default_value = "pt_rotation"
	
	    #node Group Input.001
	    group_input_001_1 = random_curve_placement_assets.nodes.new("NodeGroupInput")
	    group_input_001_1.name = "Group Input.001"
	    group_input_001_1.outputs[1].hide = True
	    group_input_001_1.outputs[2].hide = True
	    group_input_001_1.outputs[3].hide = True
	    group_input_001_1.outputs[4].hide = True
	    group_input_001_1.outputs[5].hide = True
	    group_input_001_1.outputs[6].hide = True
	    group_input_001_1.outputs[7].hide = True
	    group_input_001_1.outputs[8].hide = True
	    group_input_001_1.outputs[9].hide = True
	    group_input_001_1.outputs[10].hide = True
	    group_input_001_1.outputs[11].hide = True
	
	    #node Group.001
	    group_001 = random_curve_placement_assets.nodes.new("GeometryNodeGroup")
	    group_001.name = "Group.001"
	    group_001.hide = True
	    group_001.node_tree = mesh_geometry_priority
	
	    #node Group Input.002
	    group_input_002_1 = random_curve_placement_assets.nodes.new("NodeGroupInput")
	    group_input_002_1.name = "Group Input.002"
	    group_input_002_1.outputs[0].hide = True
	    group_input_002_1.outputs[3].hide = True
	    group_input_002_1.outputs[4].hide = True
	    group_input_002_1.outputs[5].hide = True
	    group_input_002_1.outputs[6].hide = True
	    group_input_002_1.outputs[7].hide = True
	    group_input_002_1.outputs[8].hide = True
	    group_input_002_1.outputs[9].hide = True
	    group_input_002_1.outputs[10].hide = True
	    group_input_002_1.outputs[11].hide = True
	
	    #node Group Input.003
	    group_input_003_1 = random_curve_placement_assets.nodes.new("NodeGroupInput")
	    group_input_003_1.name = "Group Input.003"
	    group_input_003_1.outputs[0].hide = True
	    group_input_003_1.outputs[1].hide = True
	    group_input_003_1.outputs[2].hide = True
	    group_input_003_1.outputs[3].hide = True
	    group_input_003_1.outputs[8].hide = True
	    group_input_003_1.outputs[9].hide = True
	    group_input_003_1.outputs[10].hide = True
	    group_input_003_1.outputs[11].hide = True
	
	    #node Group Input.004
	    group_input_004_1 = random_curve_placement_assets.nodes.new("NodeGroupInput")
	    group_input_004_1.name = "Group Input.004"
	    group_input_004_1.outputs[0].hide = True
	    group_input_004_1.outputs[1].hide = True
	    group_input_004_1.outputs[2].hide = True
	    group_input_004_1.outputs[3].hide = True
	    group_input_004_1.outputs[4].hide = True
	    group_input_004_1.outputs[5].hide = True
	    group_input_004_1.outputs[6].hide = True
	    group_input_004_1.outputs[7].hide = True
	    group_input_004_1.outputs[9].hide = True
	    group_input_004_1.outputs[10].hide = True
	    group_input_004_1.outputs[11].hide = True
	
	    #node Join Geometry
	    join_geometry_1 = random_curve_placement_assets.nodes.new("GeometryNodeJoinGeometry")
	    join_geometry_1.name = "Join Geometry"
	    join_geometry_1.hide = True
	
	    #node Instance on Points.001
	    instance_on_points_001 = random_curve_placement_assets.nodes.new("GeometryNodeInstanceOnPoints")
	    instance_on_points_001.name = "Instance on Points.001"
	    instance_on_points_001.inputs[1].hide = True
	    instance_on_points_001.inputs[3].hide = True
	    #Selection
	    instance_on_points_001.inputs[1].default_value = True
	    #Pick Instance
	    instance_on_points_001.inputs[3].default_value = True
	
	    #node Collection Info
	    collection_info = random_curve_placement_assets.nodes.new("GeometryNodeCollectionInfo")
	    collection_info.name = "Collection Info"
	    collection_info.transform_space = 'ORIGINAL'
	    #Separate Children
	    collection_info.inputs[1].default_value = True
	    #Reset Children
	    collection_info.inputs[2].default_value = False
	
	    #node Realize Instances
	    realize_instances = random_curve_placement_assets.nodes.new("GeometryNodeRealizeInstances")
	    realize_instances.name = "Realize Instances"
	    realize_instances.hide = True
	    realize_instances.inputs[1].hide = True
	    realize_instances.inputs[2].hide = True
	    realize_instances.inputs[3].hide = True
	    #Selection
	    realize_instances.inputs[1].default_value = True
	    #Realize All
	    realize_instances.inputs[2].default_value = True
	    #Depth
	    realize_instances.inputs[3].default_value = 0
	
	    #node Domain Size
	    domain_size_2 = random_curve_placement_assets.nodes.new("GeometryNodeAttributeDomainSize")
	    domain_size_2.name = "Domain Size"
	    domain_size_2.hide = True
	    domain_size_2.component = 'INSTANCES'
	
	    #node Random Value
	    random_value_1 = random_curve_placement_assets.nodes.new("FunctionNodeRandomValue")
	    random_value_1.name = "Random Value"
	    random_value_1.hide = True
	    random_value_1.data_type = 'INT'
	    random_value_1.inputs[0].hide = True
	    random_value_1.inputs[1].hide = True
	    random_value_1.inputs[2].hide = True
	    random_value_1.inputs[3].hide = True
	    random_value_1.inputs[4].hide = True
	    random_value_1.inputs[6].hide = True
	    random_value_1.inputs[7].hide = True
	    random_value_1.outputs[0].hide = True
	    random_value_1.outputs[1].hide = True
	    random_value_1.outputs[3].hide = True
	    #Min_002
	    random_value_1.inputs[4].default_value = 0
	    #ID
	    random_value_1.inputs[7].default_value = 0
	
	    #node Math
	    math_1 = random_curve_placement_assets.nodes.new("ShaderNodeMath")
	    math_1.name = "Math"
	    math_1.hide = True
	    math_1.operation = 'SUBTRACT'
	    math_1.use_clamp = False
	    math_1.inputs[1].hide = True
	    math_1.inputs[2].hide = True
	    #Value_001
	    math_1.inputs[1].default_value = 1.0
	
	    #node Group Input.005
	    group_input_005_1 = random_curve_placement_assets.nodes.new("NodeGroupInput")
	    group_input_005_1.name = "Group Input.005"
	    group_input_005_1.outputs[0].hide = True
	    group_input_005_1.outputs[1].hide = True
	    group_input_005_1.outputs[2].hide = True
	    group_input_005_1.outputs[4].hide = True
	    group_input_005_1.outputs[5].hide = True
	    group_input_005_1.outputs[6].hide = True
	    group_input_005_1.outputs[7].hide = True
	    group_input_005_1.outputs[8].hide = True
	    group_input_005_1.outputs[9].hide = True
	    group_input_005_1.outputs[10].hide = True
	    group_input_005_1.outputs[11].hide = True
	
	    #node Group Input.006
	    group_input_006_1 = random_curve_placement_assets.nodes.new("NodeGroupInput")
	    group_input_006_1.name = "Group Input.006"
	    group_input_006_1.outputs[0].hide = True
	    group_input_006_1.outputs[1].hide = True
	    group_input_006_1.outputs[2].hide = True
	    group_input_006_1.outputs[3].hide = True
	    group_input_006_1.outputs[4].hide = True
	    group_input_006_1.outputs[5].hide = True
	    group_input_006_1.outputs[6].hide = True
	    group_input_006_1.outputs[7].hide = True
	    group_input_006_1.outputs[8].hide = True
	    group_input_006_1.outputs[9].hide = True
	    group_input_006_1.outputs[11].hide = True
	
	    #node Switch
	    switch_1 = random_curve_placement_assets.nodes.new("GeometryNodeSwitch")
	    switch_1.name = "Switch"
	    switch_1.hide = True
	    switch_1.input_type = 'INT'
	
	    #node Compare
	    compare = random_curve_placement_assets.nodes.new("FunctionNodeCompare")
	    compare.name = "Compare"
	    compare.hide = True
	    compare.data_type = 'INT'
	    compare.mode = 'ELEMENT'
	    compare.operation = 'LESS_THAN'
	    compare.inputs[0].hide = True
	    compare.inputs[1].hide = True
	    compare.inputs[3].hide = True
	    compare.inputs[4].hide = True
	    compare.inputs[5].hide = True
	    compare.inputs[6].hide = True
	    compare.inputs[7].hide = True
	    compare.inputs[8].hide = True
	    compare.inputs[9].hide = True
	    compare.inputs[10].hide = True
	    compare.inputs[11].hide = True
	    compare.inputs[12].hide = True
	    #B_INT
	    compare.inputs[3].default_value = 0
	
	    #node Group Input.007
	    group_input_007 = random_curve_placement_assets.nodes.new("NodeGroupInput")
	    group_input_007.name = "Group Input.007"
	    group_input_007.outputs[0].hide = True
	    group_input_007.outputs[1].hide = True
	    group_input_007.outputs[2].hide = True
	    group_input_007.outputs[3].hide = True
	    group_input_007.outputs[4].hide = True
	    group_input_007.outputs[5].hide = True
	    group_input_007.outputs[6].hide = True
	    group_input_007.outputs[7].hide = True
	    group_input_007.outputs[8].hide = True
	    group_input_007.outputs[10].hide = True
	    group_input_007.outputs[11].hide = True
	
	    #node Group Input.008
	    group_input_008 = random_curve_placement_assets.nodes.new("NodeGroupInput")
	    group_input_008.name = "Group Input.008"
	    group_input_008.outputs[0].hide = True
	    group_input_008.outputs[1].hide = True
	    group_input_008.outputs[2].hide = True
	    group_input_008.outputs[3].hide = True
	    group_input_008.outputs[4].hide = True
	    group_input_008.outputs[5].hide = True
	    group_input_008.outputs[6].hide = True
	    group_input_008.outputs[7].hide = True
	    group_input_008.outputs[9].hide = True
	    group_input_008.outputs[10].hide = True
	    group_input_008.outputs[11].hide = True
	
	    #node Reroute
	    reroute_2 = random_curve_placement_assets.nodes.new("NodeReroute")
	    reroute_2.name = "Reroute"
	    reroute_2.socket_idname = "NodeSocketGeometry"
	    #node Reroute.001
	    reroute_001_1 = random_curve_placement_assets.nodes.new("NodeReroute")
	    reroute_001_1.name = "Reroute.001"
	    reroute_001_1.socket_idname = "NodeSocketGeometry"
	    #node Reroute.002
	    reroute_002_1 = random_curve_placement_assets.nodes.new("NodeReroute")
	    reroute_002_1.name = "Reroute.002"
	    reroute_002_1.socket_idname = "NodeSocketVector"
	    #node Switch.001
	    switch_001_1 = random_curve_placement_assets.nodes.new("GeometryNodeSwitch")
	    switch_001_1.name = "Switch.001"
	    switch_001_1.hide = True
	    switch_001_1.input_type = 'GEOMETRY'
	
	    #node Compare.001
	    compare_001 = random_curve_placement_assets.nodes.new("FunctionNodeCompare")
	    compare_001.name = "Compare.001"
	    compare_001.hide = True
	    compare_001.data_type = 'INT'
	    compare_001.mode = 'ELEMENT'
	    compare_001.operation = 'GREATER_THAN'
	    compare_001.inputs[0].hide = True
	    compare_001.inputs[1].hide = True
	    compare_001.inputs[3].hide = True
	    compare_001.inputs[4].hide = True
	    compare_001.inputs[5].hide = True
	    compare_001.inputs[6].hide = True
	    compare_001.inputs[7].hide = True
	    compare_001.inputs[8].hide = True
	    compare_001.inputs[9].hide = True
	    compare_001.inputs[10].hide = True
	    compare_001.inputs[11].hide = True
	    compare_001.inputs[12].hide = True
	    #B_INT
	    compare_001.inputs[3].default_value = 0
	
	    #node Reroute.003
	    reroute_003_1 = random_curve_placement_assets.nodes.new("NodeReroute")
	    reroute_003_1.name = "Reroute.003"
	    reroute_003_1.socket_idname = "NodeSocketInt"
	    #node Reroute.004
	    reroute_004_1 = random_curve_placement_assets.nodes.new("NodeReroute")
	    reroute_004_1.name = "Reroute.004"
	    reroute_004_1.socket_idname = "NodeSocketGeometry"
	    #node Reroute.005
	    reroute_005_1 = random_curve_placement_assets.nodes.new("NodeReroute")
	    reroute_005_1.name = "Reroute.005"
	    reroute_005_1.socket_idname = "NodeSocketGeometry"
	    #node Reroute.006
	    reroute_006_1 = random_curve_placement_assets.nodes.new("NodeReroute")
	    reroute_006_1.name = "Reroute.006"
	    reroute_006_1.socket_idname = "NodeSocketGeometry"
	    #node Reroute.007
	    reroute_007 = random_curve_placement_assets.nodes.new("NodeReroute")
	    reroute_007.name = "Reroute.007"
	    reroute_007.socket_idname = "NodeSocketVector"
	    #node Reroute.008
	    reroute_008 = random_curve_placement_assets.nodes.new("NodeReroute")
	    reroute_008.name = "Reroute.008"
	    reroute_008.socket_idname = "NodeSocketVector"
	    #node Separate Components
	    separate_components = random_curve_placement_assets.nodes.new("GeometryNodeSeparateComponents")
	    separate_components.name = "Separate Components"
	    separate_components.hide = True
	
	    #node Join Geometry.001
	    join_geometry_001 = random_curve_placement_assets.nodes.new("GeometryNodeJoinGeometry")
	    join_geometry_001.name = "Join Geometry.001"
	
	    #node Reroute.009
	    reroute_009 = random_curve_placement_assets.nodes.new("NodeReroute")
	    reroute_009.name = "Reroute.009"
	    reroute_009.socket_idname = "NodeSocketGeometry"
	    #node Reroute.010
	    reroute_010 = random_curve_placement_assets.nodes.new("NodeReroute")
	    reroute_010.name = "Reroute.010"
	    reroute_010.socket_idname = "NodeSocketGeometry"
	    #node Reroute.011
	    reroute_011 = random_curve_placement_assets.nodes.new("NodeReroute")
	    reroute_011.name = "Reroute.011"
	    reroute_011.socket_idname = "NodeSocketGeometry"
	    #node Reroute.012
	    reroute_012 = random_curve_placement_assets.nodes.new("NodeReroute")
	    reroute_012.name = "Reroute.012"
	    reroute_012.socket_idname = "NodeSocketGeometry"
	    #node Reroute.013
	    reroute_013 = random_curve_placement_assets.nodes.new("NodeReroute")
	    reroute_013.name = "Reroute.013"
	    reroute_013.socket_idname = "NodeSocketGeometry"
	    #node Random Curve Placement Assets Bake
	    random_curve_placement_assets_bake = random_curve_placement_assets.nodes.new("GeometryNodeBake")
	    random_curve_placement_assets_bake.label = "Random Curve Placement Assets Bake"
	    random_curve_placement_assets_bake.name = "Random Curve Placement Assets Bake"
	    random_curve_placement_assets_bake.active_index = 0
	    random_curve_placement_assets_bake.bake_items.clear()
	    random_curve_placement_assets_bake.bake_items.new('GEOMETRY', "Geometry")
	    random_curve_placement_assets_bake.bake_items[0].attribute_domain = 'POINT'
	    random_curve_placement_assets_bake.inputs[1].hide = True
	    random_curve_placement_assets_bake.outputs[1].hide = True
	
	    #node Reroute.014
	    reroute_014 = random_curve_placement_assets.nodes.new("NodeReroute")
	    reroute_014.name = "Reroute.014"
	    reroute_014.socket_idname = "NodeSocketGeometry"
	    #node Reroute.015
	    reroute_015 = random_curve_placement_assets.nodes.new("NodeReroute")
	    reroute_015.name = "Reroute.015"
	    reroute_015.socket_idname = "NodeSocketGeometry"
	    #node Reroute.016
	    reroute_016 = random_curve_placement_assets.nodes.new("NodeReroute")
	    reroute_016.name = "Reroute.016"
	    reroute_016.socket_idname = "NodeSocketGeometry"
	    #node Reroute.017
	    reroute_017 = random_curve_placement_assets.nodes.new("NodeReroute")
	    reroute_017.name = "Reroute.017"
	    reroute_017.socket_idname = "NodeSocketGeometry"
	    #node Reroute.018
	    reroute_018 = random_curve_placement_assets.nodes.new("NodeReroute")
	    reroute_018.name = "Reroute.018"
	    reroute_018.socket_idname = "NodeSocketGeometry"
	
	
	
	
	    #Set locations
	    group_input_2.location = (411.6765441894531, -152.0906982421875)
	    group_output_2.location = (1309.8746337890625, -129.03021240234375)
	    group.location = (-143.68772888183594, -2.2105865478515625)
	    instance_on_points.location = (228.4895477294922, -149.32688903808594)
	    named_attribute_1.location = (-339.606689453125, -263.71856689453125)
	    group_input_001_1.location = (-340.0, -11.116436004638672)
	    group_001.location = (-146.2489776611328, -219.276611328125)
	    group_input_002_1.location = (-340.0, -185.70318603515625)
	    group_input_003_1.location = (-340.0, -68.21805572509766)
	    group_input_004_1.location = (227.75291442871094, -289.98516845703125)
	    join_geometry_1.location = (582.350830078125, -175.59521484375)
	    instance_on_points_001.location = (227.10818481445312, -365.4469299316406)
	    collection_info.location = (-149.1145477294922, -367.5454406738281)
	    realize_instances.location = (748.3860473632812, -175.3485870361328)
	    domain_size_2.location = (18.178665161132812, -536.5281982421875)
	    random_value_1.location = (22.92148780822754, -607.8865966796875)
	    math_1.location = (22.95220947265625, -571.4413452148438)
	    group_input_005_1.location = (-340.0, -417.6280212402344)
	    group_input_006_1.location = (-149.6166534423828, -578.3189086914062)
	    switch_1.location = (26.212337493896484, -642.6754150390625)
	    compare.location = (24.55681037902832, -679.1206665039062)
	    group_input_007.location = (-149.6166534423828, -636.3001098632812)
	    group_input_008.location = (227.75291442871094, -532.619873046875)
	    reroute_2.location = (187.4457244873047, -34.475399017333984)
	    reroute_001_1.location = (14.386015892028809, -400.9383239746094)
	    reroute_002_1.location = (36.48207473754883, -297.3162841796875)
	    switch_001_1.location = (445.4209899902344, -378.461669921875)
	    compare_001.location = (445.0754089355469, -413.59588623046875)
	    reroute_003_1.location = (445.3830871582031, -544.6766357421875)
	    reroute_004_1.location = (193.61793518066406, -423.93768310546875)
	    reroute_005_1.location = (191.74449157714844, -209.1659698486328)
	    reroute_006_1.location = (15.507740020751953, -447.4701232910156)
	    reroute_007.location = (36.9168815612793, -251.79486083984375)
	    reroute_008.location = (43.05723190307617, -489.06640625)
	    separate_components.location = (-338.1427001953125, 26.559417724609375)
	    join_geometry_001.location = (961.4544677734375, -129.51358032226562)
	    reroute_009.location = (-143.5337677001953, 144.32762145996094)
	    reroute_010.location = (-144.90777587890625, 149.06410217285156)
	    reroute_011.location = (-143.46728515625, 139.31985473632812)
	    reroute_012.location = (-143.46728515625, 129.41612243652344)
	    reroute_013.location = (-143.46728515625, 134.3397979736328)
	    random_curve_placement_assets_bake.location = (1130.2255859375, -82.15300750732422)
	    reroute_014.location = (762.4273681640625, 134.99435424804688)
	    reroute_015.location = (762.4273681640625, 129.99501037597656)
	    reroute_016.location = (762.4273681640625, 139.99420166015625)
	    reroute_017.location = (762.4273681640625, 149.99203491210938)
	    reroute_018.location = (762.4273681640625, 144.9942169189453)
	
	    #Set dimensions
	    group_input_2.width, group_input_2.height = 140.0, 100.0
	    group_output_2.width, group_output_2.height = 140.0, 100.0
	    group.width, group.height = 140.0, 100.0
	    instance_on_points.width, instance_on_points.height = 140.0, 100.0
	    named_attribute_1.width, named_attribute_1.height = 140.0, 100.0
	    group_input_001_1.width, group_input_001_1.height = 140.0, 100.0
	    group_001.width, group_001.height = 140.0, 100.0
	    group_input_002_1.width, group_input_002_1.height = 140.0, 100.0
	    group_input_003_1.width, group_input_003_1.height = 140.0, 100.0
	    group_input_004_1.width, group_input_004_1.height = 140.0, 100.0
	    join_geometry_1.width, join_geometry_1.height = 140.0, 100.0
	    instance_on_points_001.width, instance_on_points_001.height = 140.0, 100.0
	    collection_info.width, collection_info.height = 140.0, 100.0
	    realize_instances.width, realize_instances.height = 140.0, 100.0
	    domain_size_2.width, domain_size_2.height = 140.0, 100.0
	    random_value_1.width, random_value_1.height = 140.0, 100.0
	    math_1.width, math_1.height = 140.0, 100.0
	    group_input_005_1.width, group_input_005_1.height = 140.0, 100.0
	    group_input_006_1.width, group_input_006_1.height = 140.0, 100.0
	    switch_1.width, switch_1.height = 140.0, 100.0
	    compare.width, compare.height = 140.0, 100.0
	    group_input_007.width, group_input_007.height = 140.0, 100.0
	    group_input_008.width, group_input_008.height = 140.0, 100.0
	    reroute_2.width, reroute_2.height = 10.0, 100.0
	    reroute_001_1.width, reroute_001_1.height = 10.0, 100.0
	    reroute_002_1.width, reroute_002_1.height = 10.0, 100.0
	    switch_001_1.width, switch_001_1.height = 140.0, 100.0
	    compare_001.width, compare_001.height = 140.0, 100.0
	    reroute_003_1.width, reroute_003_1.height = 10.0, 100.0
	    reroute_004_1.width, reroute_004_1.height = 10.0, 100.0
	    reroute_005_1.width, reroute_005_1.height = 10.0, 100.0
	    reroute_006_1.width, reroute_006_1.height = 10.0, 100.0
	    reroute_007.width, reroute_007.height = 10.0, 100.0
	    reroute_008.width, reroute_008.height = 10.0, 100.0
	    separate_components.width, separate_components.height = 140.0, 100.0
	    join_geometry_001.width, join_geometry_001.height = 140.0, 100.0
	    reroute_009.width, reroute_009.height = 10.0, 100.0
	    reroute_010.width, reroute_010.height = 10.0, 100.0
	    reroute_011.width, reroute_011.height = 10.0, 100.0
	    reroute_012.width, reroute_012.height = 10.0, 100.0
	    reroute_013.width, reroute_013.height = 10.0, 100.0
	    random_curve_placement_assets_bake.width, random_curve_placement_assets_bake.height = 140.0, 100.0
	    reroute_014.width, reroute_014.height = 10.0, 100.0
	    reroute_015.width, reroute_015.height = 10.0, 100.0
	    reroute_016.width, reroute_016.height = 10.0, 100.0
	    reroute_017.width, reroute_017.height = 10.0, 100.0
	    reroute_018.width, reroute_018.height = 10.0, 100.0
	
	    #initialize random_curve_placement_assets links
	    #random_curve_placement_assets_bake.Geometry -> group_output_2.Geometry
	    random_curve_placement_assets.links.new(random_curve_placement_assets_bake.outputs[0], group_output_2.inputs[0])
	    #reroute_007.Output -> instance_on_points.Rotation
	    random_curve_placement_assets.links.new(reroute_007.outputs[0], instance_on_points.inputs[5])
	    #group_input_002_1.Asset -> group_001.Geometry
	    random_curve_placement_assets.links.new(group_input_002_1.outputs[1], group_001.inputs[0])
	    #group_input_002_1.Asset -> group_001.Object
	    random_curve_placement_assets.links.new(group_input_002_1.outputs[2], group_001.inputs[1])
	    #group_input_003_1.Count -> group.Count
	    random_curve_placement_assets.links.new(group_input_003_1.outputs[4], group.inputs[1])
	    #group_input_003_1.Min Factor -> group.Min
	    random_curve_placement_assets.links.new(group_input_003_1.outputs[5], group.inputs[2])
	    #group_input_003_1.Max Factor -> group.Max
	    random_curve_placement_assets.links.new(group_input_003_1.outputs[6], group.inputs[3])
	    #group_input_003_1.Position Seed -> group.Seed
	    random_curve_placement_assets.links.new(group_input_003_1.outputs[7], group.inputs[4])
	    #group_input_004_1.Asset Scale -> instance_on_points.Scale
	    random_curve_placement_assets.links.new(group_input_004_1.outputs[8], instance_on_points.inputs[6])
	    #group_001.Geometry -> instance_on_points.Instance
	    random_curve_placement_assets.links.new(group_001.outputs[0], instance_on_points.inputs[2])
	    #reroute_004_1.Output -> instance_on_points_001.Points
	    random_curve_placement_assets.links.new(reroute_004_1.outputs[0], instance_on_points_001.inputs[0])
	    #reroute_008.Output -> instance_on_points_001.Rotation
	    random_curve_placement_assets.links.new(reroute_008.outputs[0], instance_on_points_001.inputs[5])
	    #join_geometry_1.Geometry -> realize_instances.Geometry
	    random_curve_placement_assets.links.new(join_geometry_1.outputs[0], realize_instances.inputs[0])
	    #reroute_006_1.Output -> domain_size_2.Geometry
	    random_curve_placement_assets.links.new(reroute_006_1.outputs[0], domain_size_2.inputs[0])
	    #domain_size_2.Instance Count -> math_1.Value
	    random_curve_placement_assets.links.new(domain_size_2.outputs[5], math_1.inputs[0])
	    #math_1.Value -> random_value_1.Max
	    random_curve_placement_assets.links.new(math_1.outputs[0], random_value_1.inputs[5])
	    #group_input_005_1.Asset Collection -> collection_info.Collection
	    random_curve_placement_assets.links.new(group_input_005_1.outputs[3], collection_info.inputs[0])
	    #group_input_006_1.Asset Collection Seed -> random_value_1.Seed
	    random_curve_placement_assets.links.new(group_input_006_1.outputs[10], random_value_1.inputs[8])
	    #group_input_007.Instance Index -> compare.A
	    random_curve_placement_assets.links.new(group_input_007.outputs[9], compare.inputs[2])
	    #compare.Result -> switch_1.Switch
	    random_curve_placement_assets.links.new(compare.outputs[0], switch_1.inputs[0])
	    #random_value_1.Value -> switch_1.True
	    random_curve_placement_assets.links.new(random_value_1.outputs[2], switch_1.inputs[2])
	    #group_input_007.Instance Index -> switch_1.False
	    random_curve_placement_assets.links.new(group_input_007.outputs[9], switch_1.inputs[1])
	    #switch_1.Output -> instance_on_points_001.Instance Index
	    random_curve_placement_assets.links.new(switch_1.outputs[0], instance_on_points_001.inputs[4])
	    #group_input_008.Asset Scale -> instance_on_points_001.Scale
	    random_curve_placement_assets.links.new(group_input_008.outputs[8], instance_on_points_001.inputs[6])
	    #group.Geometry -> reroute_2.Input
	    random_curve_placement_assets.links.new(group.outputs[0], reroute_2.inputs[0])
	    #collection_info.Instances -> reroute_001_1.Input
	    random_curve_placement_assets.links.new(collection_info.outputs[0], reroute_001_1.inputs[0])
	    #named_attribute_1.Attribute -> reroute_002_1.Input
	    random_curve_placement_assets.links.new(named_attribute_1.outputs[0], reroute_002_1.inputs[0])
	    #reroute_003_1.Output -> compare_001.A
	    random_curve_placement_assets.links.new(reroute_003_1.outputs[0], compare_001.inputs[2])
	    #compare_001.Result -> switch_001_1.Switch
	    random_curve_placement_assets.links.new(compare_001.outputs[0], switch_001_1.inputs[0])
	    #instance_on_points_001.Instances -> switch_001_1.True
	    random_curve_placement_assets.links.new(instance_on_points_001.outputs[0], switch_001_1.inputs[2])
	    #instance_on_points.Instances -> switch_001_1.False
	    random_curve_placement_assets.links.new(instance_on_points.outputs[0], switch_001_1.inputs[1])
	    #switch_001_1.Output -> join_geometry_1.Geometry
	    random_curve_placement_assets.links.new(switch_001_1.outputs[0], join_geometry_1.inputs[0])
	    #domain_size_2.Instance Count -> reroute_003_1.Input
	    random_curve_placement_assets.links.new(domain_size_2.outputs[5], reroute_003_1.inputs[0])
	    #reroute_005_1.Output -> reroute_004_1.Input
	    random_curve_placement_assets.links.new(reroute_005_1.outputs[0], reroute_004_1.inputs[0])
	    #reroute_2.Output -> reroute_005_1.Input
	    random_curve_placement_assets.links.new(reroute_2.outputs[0], reroute_005_1.inputs[0])
	    #reroute_005_1.Output -> instance_on_points.Points
	    random_curve_placement_assets.links.new(reroute_005_1.outputs[0], instance_on_points.inputs[0])
	    #reroute_001_1.Output -> reroute_006_1.Input
	    random_curve_placement_assets.links.new(reroute_001_1.outputs[0], reroute_006_1.inputs[0])
	    #reroute_006_1.Output -> instance_on_points_001.Instance
	    random_curve_placement_assets.links.new(reroute_006_1.outputs[0], instance_on_points_001.inputs[2])
	    #reroute_002_1.Output -> reroute_007.Input
	    random_curve_placement_assets.links.new(reroute_002_1.outputs[0], reroute_007.inputs[0])
	    #reroute_002_1.Output -> reroute_008.Input
	    random_curve_placement_assets.links.new(reroute_002_1.outputs[0], reroute_008.inputs[0])
	    #group_input_001_1.Geometry -> separate_components.Geometry
	    random_curve_placement_assets.links.new(group_input_001_1.outputs[0], separate_components.inputs[0])
	    #separate_components.Curve -> group.Geometry
	    random_curve_placement_assets.links.new(separate_components.outputs[1], group.inputs[0])
	    #reroute_015.Output -> join_geometry_001.Geometry
	    random_curve_placement_assets.links.new(reroute_015.outputs[0], join_geometry_001.inputs[0])
	    #separate_components.Grease Pencil -> reroute_009.Input
	    random_curve_placement_assets.links.new(separate_components.outputs[2], reroute_009.inputs[0])
	    #separate_components.Mesh -> reroute_010.Input
	    random_curve_placement_assets.links.new(separate_components.outputs[0], reroute_010.inputs[0])
	    #separate_components.Point Cloud -> reroute_011.Input
	    random_curve_placement_assets.links.new(separate_components.outputs[3], reroute_011.inputs[0])
	    #separate_components.Instances -> reroute_012.Input
	    random_curve_placement_assets.links.new(separate_components.outputs[5], reroute_012.inputs[0])
	    #separate_components.Volume -> reroute_013.Input
	    random_curve_placement_assets.links.new(separate_components.outputs[4], reroute_013.inputs[0])
	    #reroute_013.Output -> reroute_014.Input
	    random_curve_placement_assets.links.new(reroute_013.outputs[0], reroute_014.inputs[0])
	    #reroute_012.Output -> reroute_015.Input
	    random_curve_placement_assets.links.new(reroute_012.outputs[0], reroute_015.inputs[0])
	    #reroute_011.Output -> reroute_016.Input
	    random_curve_placement_assets.links.new(reroute_011.outputs[0], reroute_016.inputs[0])
	    #reroute_010.Output -> reroute_017.Input
	    random_curve_placement_assets.links.new(reroute_010.outputs[0], reroute_017.inputs[0])
	    #reroute_009.Output -> reroute_018.Input
	    random_curve_placement_assets.links.new(reroute_009.outputs[0], reroute_018.inputs[0])
	    #join_geometry_001.Geometry -> random_curve_placement_assets_bake.Geometry
	    random_curve_placement_assets.links.new(join_geometry_001.outputs[0], random_curve_placement_assets_bake.inputs[0])
	    #group_input_2.Geometry -> join_geometry_1.Geometry
	    random_curve_placement_assets.links.new(group_input_2.outputs[0], join_geometry_1.inputs[0])
	    #reroute_014.Output -> join_geometry_001.Geometry
	    random_curve_placement_assets.links.new(reroute_014.outputs[0], join_geometry_001.inputs[0])
	    #reroute_016.Output -> join_geometry_001.Geometry
	    random_curve_placement_assets.links.new(reroute_016.outputs[0], join_geometry_001.inputs[0])
	    #reroute_018.Output -> join_geometry_001.Geometry
	    random_curve_placement_assets.links.new(reroute_018.outputs[0], join_geometry_001.inputs[0])
	    #reroute_017.Output -> join_geometry_001.Geometry
	    random_curve_placement_assets.links.new(reroute_017.outputs[0], join_geometry_001.inputs[0])
	    #realize_instances.Geometry -> join_geometry_001.Geometry
	    random_curve_placement_assets.links.new(realize_instances.outputs[0], join_geometry_001.inputs[0])
	    return random_curve_placement_assets
	return random_curve_placement_assets_node_group()

	

	
