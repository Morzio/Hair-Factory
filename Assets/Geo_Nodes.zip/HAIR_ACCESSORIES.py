import bpy, mathutils

def node():
	#initialize multiple_material_instance node group
	def multiple_material_instance_node_group():
	    multiple_material_instance = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Multiple_Material_Instance")
	
	    multiple_material_instance.color_tag = 'NONE'
	    multiple_material_instance.description = ""
	    multiple_material_instance.default_group_node_width = 140
	    
	
	
	    #multiple_material_instance interface
	    #Socket Geometry
	    geometry_socket = multiple_material_instance.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket.attribute_domain = 'POINT'
	
	    #Socket Points
	    points_socket = multiple_material_instance.interface.new_socket(name = "Points", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    points_socket.attribute_domain = 'POINT'
	
	    #Socket Instance
	    instance_socket = multiple_material_instance.interface.new_socket(name = "Instance", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    instance_socket.attribute_domain = 'POINT'
	
	    #Socket Name
	    name_socket = multiple_material_instance.interface.new_socket(name = "Name", in_out='INPUT', socket_type = 'NodeSocketString')
	    name_socket.default_value = "inst_col"
	    name_socket.subtype = 'NONE'
	    name_socket.attribute_domain = 'POINT'
	
	    #Socket Color Method
	    color_method_socket = multiple_material_instance.interface.new_socket(name = "Color Method", in_out='INPUT', socket_type = 'NodeSocketMenu')
	    color_method_socket.attribute_domain = 'POINT'
	
	    #Socket Instance Count
	    instance_count_socket = multiple_material_instance.interface.new_socket(name = "Instance Count", in_out='INPUT', socket_type = 'NodeSocketInt')
	    instance_count_socket.default_value = 0
	    instance_count_socket.min_value = 0
	    instance_count_socket.max_value = 2147483647
	    instance_count_socket.subtype = 'NONE'
	    instance_count_socket.attribute_domain = 'POINT'
	
	    #Socket Sample
	    sample_socket = multiple_material_instance.interface.new_socket(name = "Sample", in_out='INPUT', socket_type = 'NodeSocketInt')
	    sample_socket.default_value = 0
	    sample_socket.min_value = 0
	    sample_socket.max_value = 2147483647
	    sample_socket.subtype = 'NONE'
	    sample_socket.attribute_domain = 'POINT'
	
	    #Socket Material
	    material_socket = multiple_material_instance.interface.new_socket(name = "Material", in_out='INPUT', socket_type = 'NodeSocketMaterial')
	    material_socket.attribute_domain = 'POINT'
	
	    #Socket Rotation
	    rotation_socket = multiple_material_instance.interface.new_socket(name = "Rotation", in_out='INPUT', socket_type = 'NodeSocketRotation')
	    rotation_socket.default_value = (0.0, 0.0, 0.0)
	    rotation_socket.attribute_domain = 'POINT'
	
	    #Socket Scale
	    scale_socket = multiple_material_instance.interface.new_socket(name = "Scale", in_out='INPUT', socket_type = 'NodeSocketVector')
	    scale_socket.default_value = (1.0, 1.0, 1.0)
	    scale_socket.min_value = -3.4028234663852886e+38
	    scale_socket.max_value = 3.4028234663852886e+38
	    scale_socket.subtype = 'XYZ'
	    scale_socket.attribute_domain = 'POINT'
	
	
	    #initialize multiple_material_instance nodes
	    #node Group Output
	    group_output = multiple_material_instance.nodes.new("NodeGroupOutput")
	    group_output.name = "Group Output"
	    group_output.is_active_output = True
	
	    #node Group Input
	    group_input = multiple_material_instance.nodes.new("NodeGroupInput")
	    group_input.name = "Group Input"
	    group_input.outputs[0].hide = True
	    group_input.outputs[2].hide = True
	    group_input.outputs[3].hide = True
	    group_input.outputs[4].hide = True
	    group_input.outputs[5].hide = True
	    group_input.outputs[6].hide = True
	    group_input.outputs[7].hide = True
	    group_input.outputs[8].hide = True
	    group_input.outputs[9].hide = True
	
	    #node Instance on Points
	    instance_on_points = multiple_material_instance.nodes.new("GeometryNodeInstanceOnPoints")
	    instance_on_points.name = "Instance on Points"
	    #Selection
	    instance_on_points.inputs[1].default_value = True
	    #Pick Instance
	    instance_on_points.inputs[3].default_value = False
	    #Instance Index
	    instance_on_points.inputs[4].default_value = 0
	
	    #node Realize Instances
	    realize_instances = multiple_material_instance.nodes.new("GeometryNodeRealizeInstances")
	    realize_instances.name = "Realize Instances"
	    realize_instances.inputs[1].hide = True
	    realize_instances.inputs[2].hide = True
	    realize_instances.inputs[3].hide = True
	    #Selection
	    realize_instances.inputs[1].default_value = True
	    #Realize All
	    realize_instances.inputs[2].default_value = True
	    #Depth
	    realize_instances.inputs[3].default_value = 0
	
	    #node Set Material
	    set_material = multiple_material_instance.nodes.new("GeometryNodeSetMaterial")
	    set_material.name = "Set Material"
	    set_material.inputs[1].hide = True
	    #Selection
	    set_material.inputs[1].default_value = True
	
	    #node Group Input.002
	    group_input_002 = multiple_material_instance.nodes.new("NodeGroupInput")
	    group_input_002.name = "Group Input.002"
	    group_input_002.outputs[0].hide = True
	    group_input_002.outputs[1].hide = True
	    group_input_002.outputs[2].hide = True
	    group_input_002.outputs[3].hide = True
	    group_input_002.outputs[4].hide = True
	    group_input_002.outputs[5].hide = True
	    group_input_002.outputs[7].hide = True
	    group_input_002.outputs[8].hide = True
	    group_input_002.outputs[9].hide = True
	
	    #node Index
	    index = multiple_material_instance.nodes.new("GeometryNodeInputIndex")
	    index.name = "Index"
	
	    #node Math
	    math = multiple_material_instance.nodes.new("ShaderNodeMath")
	    math.name = "Math"
	    math.hide = True
	    math.operation = 'DIVIDE'
	    math.use_clamp = False
	    #Value
	    math.inputs[0].default_value = 1.0
	
	    #node Group Input.003
	    group_input_003 = multiple_material_instance.nodes.new("NodeGroupInput")
	    group_input_003.name = "Group Input.003"
	    group_input_003.outputs[0].hide = True
	    group_input_003.outputs[1].hide = True
	    group_input_003.outputs[2].hide = True
	    group_input_003.outputs[3].hide = True
	    group_input_003.outputs[5].hide = True
	    group_input_003.outputs[6].hide = True
	    group_input_003.outputs[7].hide = True
	    group_input_003.outputs[8].hide = True
	    group_input_003.outputs[9].hide = True
	
	    #node Math.001
	    math_001 = multiple_material_instance.nodes.new("ShaderNodeMath")
	    math_001.name = "Math.001"
	    math_001.hide = True
	    math_001.operation = 'MULTIPLY'
	    math_001.use_clamp = False
	
	    #node Store Named Attribute.002
	    store_named_attribute_002 = multiple_material_instance.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_002.name = "Store Named Attribute.002"
	    store_named_attribute_002.data_type = 'FLOAT'
	    store_named_attribute_002.domain = 'POINT'
	    #Selection
	    store_named_attribute_002.inputs[1].default_value = True
	
	    #node Group Input.004
	    group_input_004 = multiple_material_instance.nodes.new("NodeGroupInput")
	    group_input_004.name = "Group Input.004"
	    group_input_004.outputs[1].hide = True
	    group_input_004.outputs[2].hide = True
	    group_input_004.outputs[3].hide = True
	    group_input_004.outputs[4].hide = True
	    group_input_004.outputs[5].hide = True
	    group_input_004.outputs[6].hide = True
	    group_input_004.outputs[7].hide = True
	    group_input_004.outputs[8].hide = True
	    group_input_004.outputs[9].hide = True
	
	    #node Math.002
	    math_002 = multiple_material_instance.nodes.new("ShaderNodeMath")
	    math_002.name = "Math.002"
	    math_002.hide = True
	    math_002.operation = 'FLOORED_MODULO'
	    math_002.use_clamp = False
	
	    #node Menu Switch
	    menu_switch = multiple_material_instance.nodes.new("GeometryNodeMenuSwitch")
	    menu_switch.name = "Menu Switch"
	    menu_switch.active_index = 2
	    menu_switch.data_type = 'FLOAT'
	    menu_switch.enum_items.clear()
	    menu_switch.enum_items.new("Default")
	    menu_switch.enum_items[0].description = ""
	    menu_switch.enum_items.new("Use Sample Count")
	    menu_switch.enum_items[1].description = ""
	    menu_switch.enum_items.new("Random")
	    menu_switch.enum_items[2].description = ""
	    menu_switch.inputs[4].hide = True
	
	    #node Frame
	    frame = multiple_material_instance.nodes.new("NodeFrame")
	    frame.label = "Repeat Color Ramp Values"
	    frame.name = "Frame"
	    frame.label_size = 20
	    frame.shrink = True
	
	    #node Index.001
	    index_001 = multiple_material_instance.nodes.new("GeometryNodeInputIndex")
	    index_001.name = "Index.001"
	
	    #node Math.003
	    math_003 = multiple_material_instance.nodes.new("ShaderNodeMath")
	    math_003.name = "Math.003"
	    math_003.hide = True
	    math_003.operation = 'DIVIDE'
	    math_003.use_clamp = False
	    #Value
	    math_003.inputs[0].default_value = 1.0
	
	    #node Group Input.005
	    group_input_005 = multiple_material_instance.nodes.new("NodeGroupInput")
	    group_input_005.name = "Group Input.005"
	    group_input_005.outputs[0].hide = True
	    group_input_005.outputs[1].hide = True
	    group_input_005.outputs[2].hide = True
	    group_input_005.outputs[3].hide = True
	    group_input_005.outputs[5].hide = True
	    group_input_005.outputs[6].hide = True
	    group_input_005.outputs[7].hide = True
	    group_input_005.outputs[8].hide = True
	    group_input_005.outputs[9].hide = True
	
	    #node Math.004
	    math_004 = multiple_material_instance.nodes.new("ShaderNodeMath")
	    math_004.name = "Math.004"
	    math_004.hide = True
	    math_004.operation = 'MULTIPLY'
	    math_004.use_clamp = False
	
	    #node Frame.001
	    frame_001 = multiple_material_instance.nodes.new("NodeFrame")
	    frame_001.label = "Random Color Ramp Values"
	    frame_001.name = "Frame.001"
	    frame_001.label_size = 20
	    frame_001.shrink = True
	
	    #node Index.002
	    index_002 = multiple_material_instance.nodes.new("GeometryNodeInputIndex")
	    index_002.name = "Index.002"
	
	    #node Math.006
	    math_006 = multiple_material_instance.nodes.new("ShaderNodeMath")
	    math_006.name = "Math.006"
	    math_006.hide = True
	    math_006.operation = 'DIVIDE'
	    math_006.use_clamp = False
	    #Value
	    math_006.inputs[0].default_value = 1.0
	
	    #node Group Input.006
	    group_input_006 = multiple_material_instance.nodes.new("NodeGroupInput")
	    group_input_006.name = "Group Input.006"
	    group_input_006.outputs[0].hide = True
	    group_input_006.outputs[1].hide = True
	    group_input_006.outputs[2].hide = True
	    group_input_006.outputs[3].hide = True
	    group_input_006.outputs[5].hide = True
	    group_input_006.outputs[6].hide = True
	    group_input_006.outputs[7].hide = True
	    group_input_006.outputs[8].hide = True
	    group_input_006.outputs[9].hide = True
	
	    #node Math.007
	    math_007 = multiple_material_instance.nodes.new("ShaderNodeMath")
	    math_007.name = "Math.007"
	    math_007.hide = True
	    math_007.operation = 'MULTIPLY'
	    math_007.use_clamp = False
	
	    #node Frame.002
	    frame_002 = multiple_material_instance.nodes.new("NodeFrame")
	    frame_002.label = "Default Color Ramp Values"
	    frame_002.name = "Frame.002"
	    frame_002.label_size = 20
	    frame_002.shrink = True
	
	    #node Group Input.007
	    group_input_007 = multiple_material_instance.nodes.new("NodeGroupInput")
	    group_input_007.name = "Group Input.007"
	    group_input_007.outputs[0].hide = True
	    group_input_007.outputs[1].hide = True
	    group_input_007.outputs[2].hide = True
	    group_input_007.outputs[4].hide = True
	    group_input_007.outputs[5].hide = True
	    group_input_007.outputs[6].hide = True
	    group_input_007.outputs[7].hide = True
	    group_input_007.outputs[8].hide = True
	    group_input_007.outputs[9].hide = True
	
	    #node Group Input.008
	    group_input_008 = multiple_material_instance.nodes.new("NodeGroupInput")
	    group_input_008.name = "Group Input.008"
	    group_input_008.outputs[0].hide = True
	    group_input_008.outputs[1].hide = True
	    group_input_008.outputs[2].hide = True
	    group_input_008.outputs[3].hide = True
	    group_input_008.outputs[4].hide = True
	    group_input_008.outputs[6].hide = True
	    group_input_008.outputs[7].hide = True
	    group_input_008.outputs[8].hide = True
	    group_input_008.outputs[9].hide = True
	
	    #node Random Value.001
	    random_value_001 = multiple_material_instance.nodes.new("FunctionNodeRandomValue")
	    random_value_001.name = "Random Value.001"
	    random_value_001.hide = True
	    random_value_001.data_type = 'INT'
	    #Min_002
	    random_value_001.inputs[4].default_value = 0
	
	    #node Group Input.009
	    group_input_009 = multiple_material_instance.nodes.new("NodeGroupInput")
	    group_input_009.name = "Group Input.009"
	    group_input_009.outputs[0].hide = True
	    group_input_009.outputs[1].hide = True
	    group_input_009.outputs[2].hide = True
	    group_input_009.outputs[3].hide = True
	    group_input_009.outputs[4].hide = True
	    group_input_009.outputs[6].hide = True
	    group_input_009.outputs[7].hide = True
	    group_input_009.outputs[8].hide = True
	    group_input_009.outputs[9].hide = True
	
	    #node Reroute
	    reroute = multiple_material_instance.nodes.new("NodeReroute")
	    reroute.name = "Reroute"
	    reroute.socket_idname = "NodeSocketMaterial"
	    #node Reroute.001
	    reroute_001 = multiple_material_instance.nodes.new("NodeReroute")
	    reroute_001.name = "Reroute.001"
	    reroute_001.socket_idname = "NodeSocketMaterial"
	    #node Reroute.002
	    reroute_002 = multiple_material_instance.nodes.new("NodeReroute")
	    reroute_002.name = "Reroute.002"
	    reroute_002.socket_idname = "NodeSocketGeometry"
	    #node Reroute.003
	    reroute_003 = multiple_material_instance.nodes.new("NodeReroute")
	    reroute_003.name = "Reroute.003"
	    reroute_003.socket_idname = "NodeSocketGeometry"
	    #node Group Input.001
	    group_input_001 = multiple_material_instance.nodes.new("NodeGroupInput")
	    group_input_001.name = "Group Input.001"
	    group_input_001.outputs[0].hide = True
	    group_input_001.outputs[1].hide = True
	    group_input_001.outputs[2].hide = True
	    group_input_001.outputs[3].hide = True
	    group_input_001.outputs[4].hide = True
	    group_input_001.outputs[5].hide = True
	    group_input_001.outputs[6].hide = True
	    group_input_001.outputs[9].hide = True
	
	    #node Group Input.010
	    group_input_010 = multiple_material_instance.nodes.new("NodeGroupInput")
	    group_input_010.name = "Group Input.010"
	    group_input_010.outputs[0].hide = True
	    group_input_010.outputs[1].hide = True
	    group_input_010.outputs[3].hide = True
	    group_input_010.outputs[4].hide = True
	    group_input_010.outputs[5].hide = True
	    group_input_010.outputs[6].hide = True
	    group_input_010.outputs[7].hide = True
	    group_input_010.outputs[8].hide = True
	    group_input_010.outputs[9].hide = True
	
	    #node Reroute.004
	    reroute_004 = multiple_material_instance.nodes.new("NodeReroute")
	    reroute_004.name = "Reroute.004"
	    reroute_004.socket_idname = "NodeSocketGeometry"
	    #node Reroute.005
	    reroute_005 = multiple_material_instance.nodes.new("NodeReroute")
	    reroute_005.name = "Reroute.005"
	    reroute_005.socket_idname = "NodeSocketGeometry"
	    #node Reroute.006
	    reroute_006 = multiple_material_instance.nodes.new("NodeReroute")
	    reroute_006.name = "Reroute.006"
	    reroute_006.socket_idname = "NodeSocketString"
	    #node Reroute.007
	    reroute_007 = multiple_material_instance.nodes.new("NodeReroute")
	    reroute_007.name = "Reroute.007"
	    reroute_007.socket_idname = "NodeSocketString"
	
	
	
	    #Set parents
	    index.parent = frame
	    math.parent = frame
	    group_input_003.parent = frame
	    math_001.parent = frame
	    math_002.parent = frame
	    index_001.parent = frame_001
	    math_003.parent = frame_001
	    group_input_005.parent = frame_001
	    math_004.parent = frame_001
	    index_002.parent = frame_002
	    math_006.parent = frame_002
	    group_input_006.parent = frame_002
	    math_007.parent = frame_002
	    group_input_008.parent = frame
	    random_value_001.parent = frame_001
	    group_input_009.parent = frame_001
	
	    #Set locations
	    group_output.location = (313.0694580078125, 156.51148986816406)
	    group_input.location = (-374.1824645996094, 37.14145278930664)
	    instance_on_points.location = (-199.08126831054688, 105.9302978515625)
	    realize_instances.location = (138.52767944335938, 156.20655822753906)
	    set_material.location = (-28.815444946289062, 130.8407440185547)
	    group_input_002.location = (-29.0930118560791, 16.302200317382812)
	    index.location = (29.939208984375, -98.44857788085938)
	    math.location = (206.37127685546875, -65.23776245117188)
	    group_input_003.location = (32.59320068359375, -39.6732177734375)
	    math_001.location = (207.42620849609375, -100.3790283203125)
	    store_named_attribute_002.location = (-374.5722961425781, 233.76991271972656)
	    group_input_004.location = (-560.3485107421875, 210.76744079589844)
	    math_002.location = (204.8179931640625, -135.25640869140625)
	    menu_switch.location = (-557.2462158203125, 93.09847259521484)
	    frame.location = (-1018.058837890625, 76.0882568359375)
	    index_001.location = (30.68524169921875, -98.877685546875)
	    math_003.location = (210.57891845703125, -48.347381591796875)
	    group_input_005.location = (33.3392333984375, -40.102325439453125)
	    math_004.location = (208.1722412109375, -83.48861694335938)
	    frame_001.location = (-1020.176513671875, -162.14706420898438)
	    index_002.location = (29.782958984375, -98.76724243164062)
	    math_006.location = (207.368896484375, -65.55642700195312)
	    group_input_006.location = (32.43695068359375, -39.99188232421875)
	    math_007.location = (207.26995849609375, -100.69769287109375)
	    frame_002.location = (-1019.11767578125, 258.2059020996094)
	    group_input_007.location = (-780.278076171875, 316.18768310546875)
	    group_input_008.location = (30.000732421875, -153.70458984375)
	    random_value_001.location = (206.39447021484375, -118.80194091796875)
	    group_input_009.location = (30.86370849609375, -157.14248657226562)
	    reroute.location = (-29.026859283447266, 27.641578674316406)
	    reroute_001.location = (110.3470458984375, 26.206117630004883)
	    reroute_002.location = (-214.0028839111328, 200.38072204589844)
	    reroute_003.location = (-212.6436309814453, 47.757240295410156)
	    group_input_001.location = (-372.7481994628906, -27.454771041870117)
	    group_input_010.location = (-560.3485107421875, 150.47772216796875)
	    reroute_004.location = (-391.73126220703125, 176.65310668945312)
	    reroute_005.location = (-390.6056823730469, 126.58975982666016)
	    reroute_006.location = (-403.60009765625, 115.96634674072266)
	    reroute_007.location = (-402.8964538574219, 82.75374603271484)
	
	    #Set dimensions
	    group_output.width, group_output.height = 140.0, 100.0
	    group_input.width, group_input.height = 140.0, 100.0
	    instance_on_points.width, instance_on_points.height = 140.0, 100.0
	    realize_instances.width, realize_instances.height = 140.0, 100.0
	    set_material.width, set_material.height = 140.0, 100.0
	    group_input_002.width, group_input_002.height = 140.0, 100.0
	    index.width, index.height = 140.0, 100.0
	    math.width, math.height = 140.0, 100.0
	    group_input_003.width, group_input_003.height = 140.0, 100.0
	    math_001.width, math_001.height = 140.0, 100.0
	    store_named_attribute_002.width, store_named_attribute_002.height = 140.0, 100.0
	    group_input_004.width, group_input_004.height = 140.0, 100.0
	    math_002.width, math_002.height = 140.0, 100.0
	    menu_switch.width, menu_switch.height = 140.0, 100.0
	    frame.width, frame.height = 377.17645263671875, 233.32354736328125
	    index_001.width, index_001.height = 140.0, 100.0
	    math_003.width, math_003.height = 140.0, 100.0
	    group_input_005.width, group_input_005.height = 140.0, 100.0
	    math_004.width, math_004.height = 140.0, 100.0
	    frame_001.width, frame_001.height = 380.35296630859375, 237.558837890625
	    index_002.width, index_002.height = 140.0, 100.0
	    math_006.width, math_006.height = 140.0, 100.0
	    group_input_006.width, group_input_006.height = 140.0, 100.0
	    math_007.width, math_007.height = 140.0, 100.0
	    frame_002.width, frame_002.height = 377.176513671875, 177.20590209960938
	    group_input_007.width, group_input_007.height = 140.0, 100.0
	    group_input_008.width, group_input_008.height = 140.0, 100.0
	    random_value_001.width, random_value_001.height = 140.0, 100.0
	    group_input_009.width, group_input_009.height = 140.0, 100.0
	    reroute.width, reroute.height = 100.0, 100.0
	    reroute_001.width, reroute_001.height = 100.0, 100.0
	    reroute_002.width, reroute_002.height = 100.0, 100.0
	    reroute_003.width, reroute_003.height = 100.0, 100.0
	    group_input_001.width, group_input_001.height = 140.0, 100.0
	    group_input_010.width, group_input_010.height = 140.0, 100.0
	    reroute_004.width, reroute_004.height = 100.0, 100.0
	    reroute_005.width, reroute_005.height = 100.0, 100.0
	    reroute_006.width, reroute_006.height = 100.0, 100.0
	    reroute_007.width, reroute_007.height = 100.0, 100.0
	
	    #initialize multiple_material_instance links
	    #instance_on_points.Instances -> set_material.Geometry
	    multiple_material_instance.links.new(instance_on_points.outputs[0], set_material.inputs[0])
	    #group_input.Instance -> instance_on_points.Instance
	    multiple_material_instance.links.new(group_input.outputs[1], instance_on_points.inputs[2])
	    #realize_instances.Geometry -> group_output.Geometry
	    multiple_material_instance.links.new(realize_instances.outputs[0], group_output.inputs[0])
	    #reroute.Output -> set_material.Material
	    multiple_material_instance.links.new(reroute.outputs[0], set_material.inputs[2])
	    #group_input_003.Instance Count -> math.Value
	    multiple_material_instance.links.new(group_input_003.outputs[4], math.inputs[1])
	    #math.Value -> math_001.Value
	    multiple_material_instance.links.new(math.outputs[0], math_001.inputs[0])
	    #reroute_005.Output -> store_named_attribute_002.Geometry
	    multiple_material_instance.links.new(reroute_005.outputs[0], store_named_attribute_002.inputs[0])
	    #reroute_003.Output -> instance_on_points.Points
	    multiple_material_instance.links.new(reroute_003.outputs[0], instance_on_points.inputs[0])
	    #set_material.Geometry -> realize_instances.Geometry
	    multiple_material_instance.links.new(set_material.outputs[0], realize_instances.inputs[0])
	    #index.Index -> math_002.Value
	    multiple_material_instance.links.new(index.outputs[0], math_002.inputs[0])
	    #math_002.Value -> math_001.Value
	    multiple_material_instance.links.new(math_002.outputs[0], math_001.inputs[1])
	    #group_input_005.Instance Count -> math_003.Value
	    multiple_material_instance.links.new(group_input_005.outputs[4], math_003.inputs[1])
	    #math_003.Value -> math_004.Value
	    multiple_material_instance.links.new(math_003.outputs[0], math_004.inputs[0])
	    #group_input_006.Instance Count -> math_006.Value
	    multiple_material_instance.links.new(group_input_006.outputs[4], math_006.inputs[1])
	    #math_006.Value -> math_007.Value
	    multiple_material_instance.links.new(math_006.outputs[0], math_007.inputs[0])
	    #index_002.Index -> math_007.Value
	    multiple_material_instance.links.new(index_002.outputs[0], math_007.inputs[1])
	    #math_007.Value -> menu_switch.Default
	    multiple_material_instance.links.new(math_007.outputs[0], menu_switch.inputs[1])
	    #math_001.Value -> menu_switch.Use Sample Count
	    multiple_material_instance.links.new(math_001.outputs[0], menu_switch.inputs[2])
	    #math_004.Value -> menu_switch.Random
	    multiple_material_instance.links.new(math_004.outputs[0], menu_switch.inputs[3])
	    #menu_switch.Output -> store_named_attribute_002.Value
	    multiple_material_instance.links.new(menu_switch.outputs[0], store_named_attribute_002.inputs[3])
	    #group_input_008.Sample -> math_002.Value
	    multiple_material_instance.links.new(group_input_008.outputs[5], math_002.inputs[1])
	    #index_001.Index -> random_value_001.ID
	    multiple_material_instance.links.new(index_001.outputs[0], random_value_001.inputs[7])
	    #group_input_005.Instance Count -> random_value_001.Max
	    multiple_material_instance.links.new(group_input_005.outputs[4], random_value_001.inputs[5])
	    #random_value_001.Value -> math_004.Value
	    multiple_material_instance.links.new(random_value_001.outputs[2], math_004.inputs[1])
	    #group_input_009.Sample -> random_value_001.Seed
	    multiple_material_instance.links.new(group_input_009.outputs[5], random_value_001.inputs[8])
	    #group_input_007.Color Method -> menu_switch.Menu
	    multiple_material_instance.links.new(group_input_007.outputs[3], menu_switch.inputs[0])
	    #reroute_001.Output -> reroute.Input
	    multiple_material_instance.links.new(reroute_001.outputs[0], reroute.inputs[0])
	    #group_input_002.Material -> reroute_001.Input
	    multiple_material_instance.links.new(group_input_002.outputs[6], reroute_001.inputs[0])
	    #store_named_attribute_002.Geometry -> reroute_002.Input
	    multiple_material_instance.links.new(store_named_attribute_002.outputs[0], reroute_002.inputs[0])
	    #reroute_002.Output -> reroute_003.Input
	    multiple_material_instance.links.new(reroute_002.outputs[0], reroute_003.inputs[0])
	    #group_input_001.Rotation -> instance_on_points.Rotation
	    multiple_material_instance.links.new(group_input_001.outputs[7], instance_on_points.inputs[5])
	    #group_input_001.Scale -> instance_on_points.Scale
	    multiple_material_instance.links.new(group_input_001.outputs[8], instance_on_points.inputs[6])
	    #reroute_007.Output -> store_named_attribute_002.Name
	    multiple_material_instance.links.new(reroute_007.outputs[0], store_named_attribute_002.inputs[2])
	    #group_input_004.Points -> reroute_004.Input
	    multiple_material_instance.links.new(group_input_004.outputs[0], reroute_004.inputs[0])
	    #reroute_004.Output -> reroute_005.Input
	    multiple_material_instance.links.new(reroute_004.outputs[0], reroute_005.inputs[0])
	    #group_input_010.Name -> reroute_006.Input
	    multiple_material_instance.links.new(group_input_010.outputs[2], reroute_006.inputs[0])
	    #reroute_006.Output -> reroute_007.Input
	    multiple_material_instance.links.new(reroute_006.outputs[0], reroute_007.inputs[0])
	    color_method_socket.default_value = 'Default'
	    return multiple_material_instance
	
	multiple_material_instance = multiple_material_instance_node_group()
	
	#initialize hair_beads node group
	def hair_beads_node_group():
	    hair_beads = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Hair Beads")
	
	    hair_beads.color_tag = 'NONE'
	    hair_beads.description = ""
	    hair_beads.default_group_node_width = 140
	    
	
	    hair_beads.is_modifier = True
	
	    #hair_beads interface
	    #Socket Geometry
	    geometry_socket_1 = hair_beads.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_1.attribute_domain = 'POINT'
	
	    #Socket Geometry
	    geometry_socket_2 = hair_beads.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_2.attribute_domain = 'POINT'
	
	    #Socket Bead
	    bead_socket = hair_beads.interface.new_socket(name = "Bead", in_out='INPUT', socket_type = 'NodeSocketObject')
	    bead_socket.attribute_domain = 'POINT'
	
	    #Socket Bead Count
	    bead_count_socket = hair_beads.interface.new_socket(name = "Bead Count", in_out='INPUT', socket_type = 'NodeSocketInt')
	    bead_count_socket.default_value = 0
	    bead_count_socket.min_value = 0
	    bead_count_socket.max_value = 2147483647
	    bead_count_socket.subtype = 'NONE'
	    bead_count_socket.attribute_domain = 'POINT'
	
	    #Socket Bead Scale
	    bead_scale_socket = hair_beads.interface.new_socket(name = "Bead Scale", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    bead_scale_socket.default_value = 1.0
	    bead_scale_socket.min_value = 0.0
	    bead_scale_socket.max_value = 3.4028234663852886e+38
	    bead_scale_socket.subtype = 'NONE'
	    bead_scale_socket.attribute_domain = 'POINT'
	
	    #Socket Offset
	    offset_socket = hair_beads.interface.new_socket(name = "Offset", in_out='INPUT', socket_type = 'NodeSocketInt')
	    offset_socket.default_value = 1
	    offset_socket.min_value = 0
	    offset_socket.max_value = 2147483647
	    offset_socket.subtype = 'NONE'
	    offset_socket.attribute_domain = 'POINT'
	
	    #Socket Material
	    material_socket_1 = hair_beads.interface.new_socket(name = "Material", in_out='INPUT', socket_type = 'NodeSocketMaterial')
	    material_socket_1.attribute_domain = 'POINT'
	
	    #Socket Name
	    name_socket_1 = hair_beads.interface.new_socket(name = "Name", in_out='INPUT', socket_type = 'NodeSocketString')
	    name_socket_1.default_value = "bead_col"
	    name_socket_1.subtype = 'NONE'
	    name_socket_1.attribute_domain = 'POINT'
	
	    #Socket Color Method
	    color_method_socket_1 = hair_beads.interface.new_socket(name = "Color Method", in_out='INPUT', socket_type = 'NodeSocketMenu')
	    color_method_socket_1.attribute_domain = 'POINT'
	
	    #Socket Sample
	    sample_socket_1 = hair_beads.interface.new_socket(name = "Sample", in_out='INPUT', socket_type = 'NodeSocketInt')
	    sample_socket_1.default_value = 0
	    sample_socket_1.min_value = 0
	    sample_socket_1.max_value = 2147483647
	    sample_socket_1.subtype = 'NONE'
	    sample_socket_1.attribute_domain = 'POINT'
	
	
	    #initialize hair_beads nodes
	    #node Group Input
	    group_input_1 = hair_beads.nodes.new("NodeGroupInput")
	    group_input_1.name = "Group Input"
	    group_input_1.outputs[5].hide = True
	    group_input_1.outputs[6].hide = True
	    group_input_1.outputs[7].hide = True
	    group_input_1.outputs[8].hide = True
	    group_input_1.outputs[9].hide = True
	
	    #node Group Output
	    group_output_1 = hair_beads.nodes.new("NodeGroupOutput")
	    group_output_1.name = "Group Output"
	    group_output_1.is_active_output = True
	
	    #node Domain Size
	    domain_size = hair_beads.nodes.new("GeometryNodeAttributeDomainSize")
	    domain_size.name = "Domain Size"
	    domain_size.hide = True
	    domain_size.component = 'CURVE'
	
	    #node Object Info.001
	    object_info_001 = hair_beads.nodes.new("GeometryNodeObjectInfo")
	    object_info_001.name = "Object Info.001"
	    object_info_001.hide = True
	    object_info_001.transform_space = 'RELATIVE'
	    #As Instance
	    object_info_001.inputs[1].default_value = True
	
	    #node Align Rotation to Vector.001
	    align_rotation_to_vector_001 = hair_beads.nodes.new("FunctionNodeAlignRotationToVector")
	    align_rotation_to_vector_001.name = "Align Rotation to Vector.001"
	    align_rotation_to_vector_001.hide = True
	    align_rotation_to_vector_001.axis = 'Z'
	    align_rotation_to_vector_001.pivot_axis = 'AUTO'
	    #Rotation
	    align_rotation_to_vector_001.inputs[0].default_value = (0.0, 0.0, 0.0)
	    #Factor
	    align_rotation_to_vector_001.inputs[1].default_value = 1.0
	
	    #node Points.001
	    points_001 = hair_beads.nodes.new("GeometryNodePoints")
	    points_001.name = "Points.001"
	    points_001.hide = True
	    #Count
	    points_001.inputs[0].default_value = 1
	    #Position
	    points_001.inputs[1].default_value = (0.0, 0.0, 0.0)
	    #Radius
	    points_001.inputs[2].default_value = 0.10000000149011612
	
	    #node Duplicate Elements.002
	    duplicate_elements_002 = hair_beads.nodes.new("GeometryNodeDuplicateElements")
	    duplicate_elements_002.name = "Duplicate Elements.002"
	    duplicate_elements_002.hide = True
	    duplicate_elements_002.domain = 'POINT'
	    #Selection
	    duplicate_elements_002.inputs[1].default_value = True
	
	    #node Set Position.002
	    set_position_002 = hair_beads.nodes.new("GeometryNodeSetPosition")
	    set_position_002.name = "Set Position.002"
	    set_position_002.hide = True
	    #Selection
	    set_position_002.inputs[1].default_value = True
	    #Offset
	    set_position_002.inputs[3].default_value = (0.0, 0.0, 0.0)
	
	    #node Sample Curve.002
	    sample_curve_002 = hair_beads.nodes.new("GeometryNodeSampleCurve")
	    sample_curve_002.name = "Sample Curve.002"
	    sample_curve_002.hide = True
	    sample_curve_002.data_type = 'FLOAT'
	    sample_curve_002.mode = 'LENGTH'
	    sample_curve_002.use_all_curves = False
	    #Value
	    sample_curve_002.inputs[1].default_value = 0.0
	
	    #node Reverse Curve
	    reverse_curve = hair_beads.nodes.new("GeometryNodeReverseCurve")
	    reverse_curve.name = "Reverse Curve"
	    reverse_curve.hide = True
	    #Selection
	    reverse_curve.inputs[1].default_value = True
	
	    #node Bounding Box
	    bounding_box = hair_beads.nodes.new("GeometryNodeBoundBox")
	    bounding_box.name = "Bounding Box"
	    bounding_box.hide = True
	
	    #node Separate XYZ
	    separate_xyz = hair_beads.nodes.new("ShaderNodeSeparateXYZ")
	    separate_xyz.name = "Separate XYZ"
	    separate_xyz.hide = True
	
	    #node Separate XYZ.001
	    separate_xyz_001 = hair_beads.nodes.new("ShaderNodeSeparateXYZ")
	    separate_xyz_001.name = "Separate XYZ.001"
	    separate_xyz_001.hide = True
	
	    #node Math
	    math_1 = hair_beads.nodes.new("ShaderNodeMath")
	    math_1.name = "Math"
	    math_1.hide = True
	    math_1.operation = 'SUBTRACT'
	    math_1.use_clamp = False
	
	    #node Math.001
	    math_001_1 = hair_beads.nodes.new("ShaderNodeMath")
	    math_001_1.name = "Math.001"
	    math_001_1.hide = True
	    math_001_1.operation = 'ABSOLUTE'
	    math_001_1.use_clamp = False
	
	    #node Math.002
	    math_002_1 = hair_beads.nodes.new("ShaderNodeMath")
	    math_002_1.name = "Math.002"
	    math_002_1.hide = True
	    math_002_1.operation = 'MULTIPLY'
	    math_002_1.use_clamp = False
	
	    #node Math.003
	    math_003_1 = hair_beads.nodes.new("ShaderNodeMath")
	    math_003_1.name = "Math.003"
	    math_003_1.hide = True
	    math_003_1.operation = 'MULTIPLY'
	    math_003_1.use_clamp = False
	
	    #node Join Geometry.001
	    join_geometry_001 = hair_beads.nodes.new("GeometryNodeJoinGeometry")
	    join_geometry_001.name = "Join Geometry.001"
	    join_geometry_001.hide = True
	
	    #node Realize Instances
	    realize_instances_1 = hair_beads.nodes.new("GeometryNodeRealizeInstances")
	    realize_instances_1.name = "Realize Instances"
	    realize_instances_1.hide = True
	    #Selection
	    realize_instances_1.inputs[1].default_value = True
	    #Realize All
	    realize_instances_1.inputs[2].default_value = True
	    #Depth
	    realize_instances_1.inputs[3].default_value = 0
	
	    #node Repeat Input
	    repeat_input = hair_beads.nodes.new("GeometryNodeRepeatInput")
	    repeat_input.name = "Repeat Input"
	    #node Repeat Output
	    repeat_output = hair_beads.nodes.new("GeometryNodeRepeatOutput")
	    repeat_output.name = "Repeat Output"
	    repeat_output.active_index = 1
	    repeat_output.inspection_index = 0
	    repeat_output.repeat_items.clear()
	    # Create item "Geometry"
	    repeat_output.repeat_items.new('GEOMETRY', "Geometry")
	    # Create item "Integer"
	    repeat_output.repeat_items.new('INT', "Integer")
	
	    #node Math.004
	    math_004_1 = hair_beads.nodes.new("ShaderNodeMath")
	    math_004_1.name = "Math.004"
	    math_004_1.hide = True
	    math_004_1.operation = 'ADD'
	    math_004_1.use_clamp = False
	    #Value_001
	    math_004_1.inputs[1].default_value = 1.0
	
	    #node Resample Curve
	    resample_curve = hair_beads.nodes.new("GeometryNodeResampleCurve")
	    resample_curve.name = "Resample Curve"
	    resample_curve.hide = True
	    resample_curve.keep_last_segment = False
	    resample_curve.mode = 'COUNT'
	    #Selection
	    resample_curve.inputs[1].default_value = True
	    #Count
	    resample_curve.inputs[2].default_value = 100
	
	    #node Math.005
	    math_005 = hair_beads.nodes.new("ShaderNodeMath")
	    math_005.name = "Math.005"
	    math_005.hide = True
	    math_005.operation = 'ADD'
	    math_005.use_clamp = False
	
	    #node Frame
	    frame_1 = hair_beads.nodes.new("NodeFrame")
	    frame_1.name = "Frame"
	    frame_1.label_size = 20
	    frame_1.shrink = True
	
	    #node Reroute
	    reroute_1 = hair_beads.nodes.new("NodeReroute")
	    reroute_1.name = "Reroute"
	    reroute_1.socket_idname = "NodeSocketGeometry"
	    #node Reroute.001
	    reroute_001_1 = hair_beads.nodes.new("NodeReroute")
	    reroute_001_1.name = "Reroute.001"
	    reroute_001_1.socket_idname = "NodeSocketObject"
	    #node Reroute.004
	    reroute_004_1 = hair_beads.nodes.new("NodeReroute")
	    reroute_004_1.name = "Reroute.004"
	    reroute_004_1.socket_idname = "NodeSocketFloat"
	    #node Reroute.005
	    reroute_005_1 = hair_beads.nodes.new("NodeReroute")
	    reroute_005_1.name = "Reroute.005"
	    reroute_005_1.socket_idname = "NodeSocketFloat"
	    #node Reroute.006
	    reroute_006_1 = hair_beads.nodes.new("NodeReroute")
	    reroute_006_1.name = "Reroute.006"
	    reroute_006_1.socket_idname = "NodeSocketFloat"
	    #node Reroute.007
	    reroute_007_1 = hair_beads.nodes.new("NodeReroute")
	    reroute_007_1.name = "Reroute.007"
	    reroute_007_1.socket_idname = "NodeSocketGeometry"
	    #node Reroute.008
	    reroute_008 = hair_beads.nodes.new("NodeReroute")
	    reroute_008.name = "Reroute.008"
	    reroute_008.socket_idname = "NodeSocketInt"
	    #node Reroute.009
	    reroute_009 = hair_beads.nodes.new("NodeReroute")
	    reroute_009.name = "Reroute.009"
	    reroute_009.socket_idname = "NodeSocketInt"
	    #node Reroute.010
	    reroute_010 = hair_beads.nodes.new("NodeReroute")
	    reroute_010.name = "Reroute.010"
	    reroute_010.socket_idname = "NodeSocketGeometry"
	    #node Reroute.011
	    reroute_011 = hair_beads.nodes.new("NodeReroute")
	    reroute_011.name = "Reroute.011"
	    reroute_011.socket_idname = "NodeSocketGeometry"
	    #node Reroute.012
	    reroute_012 = hair_beads.nodes.new("NodeReroute")
	    reroute_012.name = "Reroute.012"
	    reroute_012.socket_idname = "NodeSocketInt"
	    #node Reroute.013
	    reroute_013 = hair_beads.nodes.new("NodeReroute")
	    reroute_013.name = "Reroute.013"
	    reroute_013.socket_idname = "NodeSocketInt"
	    #node Group
	    group = hair_beads.nodes.new("GeometryNodeGroup")
	    group.name = "Group"
	    group.node_tree = multiple_material_instance
	
	    #node Group Input.001
	    group_input_001_1 = hair_beads.nodes.new("NodeGroupInput")
	    group_input_001_1.name = "Group Input.001"
	    group_input_001_1.outputs[0].hide = True
	    group_input_001_1.outputs[1].hide = True
	    group_input_001_1.outputs[3].hide = True
	    group_input_001_1.outputs[4].hide = True
	    group_input_001_1.outputs[6].hide = True
	    group_input_001_1.outputs[9].hide = True
	
	    #node Group Input.002
	    group_input_002_1 = hair_beads.nodes.new("NodeGroupInput")
	    group_input_002_1.name = "Group Input.002"
	    group_input_002_1.outputs[0].hide = True
	    group_input_002_1.outputs[1].hide = True
	    group_input_002_1.outputs[2].hide = True
	    group_input_002_1.outputs[4].hide = True
	    group_input_002_1.outputs[5].hide = True
	    group_input_002_1.outputs[6].hide = True
	    group_input_002_1.outputs[7].hide = True
	    group_input_002_1.outputs[8].hide = True
	    group_input_002_1.outputs[9].hide = True
	
	    #node Reroute.002
	    reroute_002_1 = hair_beads.nodes.new("NodeReroute")
	    reroute_002_1.name = "Reroute.002"
	    reroute_002_1.socket_idname = "NodeSocketRotation"
	    #node Reroute.003
	    reroute_003_1 = hair_beads.nodes.new("NodeReroute")
	    reroute_003_1.name = "Reroute.003"
	    reroute_003_1.socket_idname = "NodeSocketGeometry"
	    #node Reroute.014
	    reroute_014 = hair_beads.nodes.new("NodeReroute")
	    reroute_014.name = "Reroute.014"
	    reroute_014.socket_idname = "NodeSocketInt"
	    #node Reroute.015
	    reroute_015 = hair_beads.nodes.new("NodeReroute")
	    reroute_015.name = "Reroute.015"
	    reroute_015.socket_idname = "NodeSocketInt"
	    #node Group Input.003
	    group_input_003_1 = hair_beads.nodes.new("NodeGroupInput")
	    group_input_003_1.name = "Group Input.003"
	    group_input_003_1.outputs[0].hide = True
	    group_input_003_1.outputs[1].hide = True
	    group_input_003_1.outputs[2].hide = True
	    group_input_003_1.outputs[3].hide = True
	    group_input_003_1.outputs[4].hide = True
	    group_input_003_1.outputs[5].hide = True
	    group_input_003_1.outputs[7].hide = True
	    group_input_003_1.outputs[8].hide = True
	    group_input_003_1.outputs[9].hide = True
	
	
	    #Process zone input Repeat Input
	    repeat_input.pair_with_output(repeat_output)
	    #Item_2
	    repeat_input.inputs[2].default_value = 0
	
	
	
	
	    #Set parents
	    separate_xyz.parent = frame_1
	    separate_xyz_001.parent = frame_1
	    math_1.parent = frame_1
	    math_001_1.parent = frame_1
	    math_002_1.parent = frame_1
	
	    #Set locations
	    group_input_1.location = (-557.033203125, -10.441658973693848)
	    group_output_1.location = (1327.513427734375, -145.82321166992188)
	    domain_size.location = (-352.1491394042969, 28.171783447265625)
	    object_info_001.location = (-383.8388977050781, -281.8438415527344)
	    align_rotation_to_vector_001.location = (655.1964721679688, -71.56181335449219)
	    points_001.location = (-169.44772338867188, -5.846434593200684)
	    duplicate_elements_002.location = (-166.6284637451172, 30.70068359375)
	    set_position_002.location = (661.912353515625, -31.08664894104004)
	    sample_curve_002.location = (468.75115966796875, -60.15850067138672)
	    reverse_curve.location = (-337.43914794921875, -41.24885940551758)
	    bounding_box.location = (-213.44305419921875, -380.3084716796875)
	    separate_xyz.location = (29.994853973388672, -107.12796020507812)
	    separate_xyz_001.location = (32.10360336303711, -67.92520141601562)
	    math_1.location = (206.77301025390625, -114.59915161132812)
	    math_001_1.location = (209.45510864257812, -75.47650146484375)
	    math_002_1.location = (203.34848022460938, -35.59906005859375)
	    math_003_1.location = (326.7001037597656, -127.00873565673828)
	    join_geometry_001.location = (988.7920532226562, -167.80519104003906)
	    realize_instances_1.location = (-213.65028381347656, -345.93096923828125)
	    repeat_input.location = (-356.328369140625, -138.1380615234375)
	    repeat_output.location = (1154.7742919921875, -143.57061767578125)
	    math_004_1.location = (507.77667236328125, -197.67095947265625)
	    resample_curve.location = (-168.7435302734375, -51.70866012573242)
	    math_005.location = (-167.346923828125, -118.57404327392578)
	    frame_1.location = (-69.35294342041016, -289.8529357910156)
	    reroute_1.location = (-353.0357360839844, -43.2183837890625)
	    reroute_001_1.location = (-383.46337890625, -65.11857604980469)
	    reroute_004_1.location = (-400.5569152832031, -325.5744934082031)
	    reroute_005_1.location = (-399.9139099121094, -108.29559326171875)
	    reroute_006_1.location = (331.8807067871094, -334.5451965332031)
	    reroute_007_1.location = (665.5364990234375, 29.346660614013672)
	    reroute_008.location = (49.840179443359375, 12.435029029846191)
	    reroute_009.location = (51.75514221191406, -83.33052062988281)
	    reroute_010.location = (-207.68678283691406, -308.9499816894531)
	    reroute_011.location = (823.367919921875, -40.845680236816406)
	    reroute_012.location = (-190.40890502929688, -213.47146606445312)
	    reroute_013.location = (-192.18080139160156, -121.60594177246094)
	    group.location = (848.8018798828125, -213.79444885253906)
	    group_input_001_1.location = (605.1549072265625, -322.0130310058594)
	    group_input_002_1.location = (607.8082885742188, -444.17169189453125)
	    reroute_002_1.location = (805.4578247070312, -441.7245788574219)
	    reroute_003_1.location = (829.6383056640625, -293.2506408691406)
	    reroute_014.location = (-371.80059814453125, -171.1200714111328)
	    reroute_015.location = (-372.0785827636719, -87.43440246582031)
	    group_input_003_1.location = (604.6140747070312, -253.95758056640625)
	
	    #Set dimensions
	    group_input_1.width, group_input_1.height = 140.0, 100.0
	    group_output_1.width, group_output_1.height = 140.0, 100.0
	    domain_size.width, domain_size.height = 140.0, 100.0
	    object_info_001.width, object_info_001.height = 140.0, 100.0
	    align_rotation_to_vector_001.width, align_rotation_to_vector_001.height = 140.0, 100.0
	    points_001.width, points_001.height = 140.0, 100.0
	    duplicate_elements_002.width, duplicate_elements_002.height = 140.0, 100.0
	    set_position_002.width, set_position_002.height = 140.0, 100.0
	    sample_curve_002.width, sample_curve_002.height = 140.0, 100.0
	    reverse_curve.width, reverse_curve.height = 140.0, 100.0
	    bounding_box.width, bounding_box.height = 140.0, 100.0
	    separate_xyz.width, separate_xyz.height = 140.0, 100.0
	    separate_xyz_001.width, separate_xyz_001.height = 140.0, 100.0
	    math_1.width, math_1.height = 140.0, 100.0
	    math_001_1.width, math_001_1.height = 140.0, 100.0
	    math_002_1.width, math_002_1.height = 140.0, 100.0
	    math_003_1.width, math_003_1.height = 140.0, 100.0
	    join_geometry_001.width, join_geometry_001.height = 140.0, 100.0
	    realize_instances_1.width, realize_instances_1.height = 140.0, 100.0
	    repeat_input.width, repeat_input.height = 140.0, 100.0
	    repeat_output.width, repeat_output.height = 140.0, 100.0
	    math_004_1.width, math_004_1.height = 140.0, 100.0
	    resample_curve.width, resample_curve.height = 140.0, 100.0
	    math_005.width, math_005.height = 140.0, 100.0
	    frame_1.width, frame_1.height = 379.2941589355469, 169.94119262695312
	    reroute_1.width, reroute_1.height = 100.0, 100.0
	    reroute_001_1.width, reroute_001_1.height = 100.0, 100.0
	    reroute_004_1.width, reroute_004_1.height = 100.0, 100.0
	    reroute_005_1.width, reroute_005_1.height = 100.0, 100.0
	    reroute_006_1.width, reroute_006_1.height = 100.0, 100.0
	    reroute_007_1.width, reroute_007_1.height = 100.0, 100.0
	    reroute_008.width, reroute_008.height = 100.0, 100.0
	    reroute_009.width, reroute_009.height = 100.0, 100.0
	    reroute_010.width, reroute_010.height = 100.0, 100.0
	    reroute_011.width, reroute_011.height = 100.0, 100.0
	    reroute_012.width, reroute_012.height = 100.0, 100.0
	    reroute_013.width, reroute_013.height = 100.0, 100.0
	    group.width, group.height = 140.0, 100.0
	    group_input_001_1.width, group_input_001_1.height = 140.0, 100.0
	    group_input_002_1.width, group_input_002_1.height = 140.0, 100.0
	    reroute_002_1.width, reroute_002_1.height = 100.0, 100.0
	    reroute_003_1.width, reroute_003_1.height = 100.0, 100.0
	    reroute_014.width, reroute_014.height = 100.0, 100.0
	    reroute_015.width, reroute_015.height = 100.0, 100.0
	    group_input_003_1.width, group_input_003_1.height = 140.0, 100.0
	
	    #initialize hair_beads links
	    #points_001.Points -> duplicate_elements_002.Geometry
	    hair_beads.links.new(points_001.outputs[0], duplicate_elements_002.inputs[0])
	    #domain_size.Spline Count -> duplicate_elements_002.Amount
	    hair_beads.links.new(domain_size.outputs[4], duplicate_elements_002.inputs[2])
	    #resample_curve.Curve -> sample_curve_002.Curves
	    hair_beads.links.new(resample_curve.outputs[0], sample_curve_002.inputs[0])
	    #reroute_009.Output -> sample_curve_002.Curve Index
	    hair_beads.links.new(reroute_009.outputs[0], sample_curve_002.inputs[4])
	    #sample_curve_002.Tangent -> align_rotation_to_vector_001.Vector
	    hair_beads.links.new(sample_curve_002.outputs[2], align_rotation_to_vector_001.inputs[2])
	    #sample_curve_002.Position -> set_position_002.Position
	    hair_beads.links.new(sample_curve_002.outputs[1], set_position_002.inputs[2])
	    #reroute_1.Output -> reverse_curve.Curve
	    hair_beads.links.new(reroute_1.outputs[0], reverse_curve.inputs[0])
	    #reroute_001_1.Output -> object_info_001.Object
	    hair_beads.links.new(reroute_001_1.outputs[0], object_info_001.inputs[0])
	    #realize_instances_1.Geometry -> bounding_box.Geometry
	    hair_beads.links.new(realize_instances_1.outputs[0], bounding_box.inputs[0])
	    #bounding_box.Max -> separate_xyz.Vector
	    hair_beads.links.new(bounding_box.outputs[2], separate_xyz.inputs[0])
	    #bounding_box.Min -> separate_xyz_001.Vector
	    hair_beads.links.new(bounding_box.outputs[1], separate_xyz_001.inputs[0])
	    #separate_xyz_001.Z -> math_1.Value
	    hair_beads.links.new(separate_xyz_001.outputs[2], math_1.inputs[0])
	    #separate_xyz.Z -> math_1.Value
	    hair_beads.links.new(separate_xyz.outputs[2], math_1.inputs[1])
	    #math_1.Value -> math_001_1.Value
	    hair_beads.links.new(math_1.outputs[0], math_001_1.inputs[0])
	    #math_001_1.Value -> math_002_1.Value
	    hair_beads.links.new(math_001_1.outputs[0], math_002_1.inputs[1])
	    #reroute_004_1.Output -> math_002_1.Value
	    hair_beads.links.new(reroute_004_1.outputs[0], math_002_1.inputs[0])
	    #reroute_006_1.Output -> math_003_1.Value
	    hair_beads.links.new(reroute_006_1.outputs[0], math_003_1.inputs[1])
	    #reroute_007_1.Output -> set_position_002.Geometry
	    hair_beads.links.new(reroute_007_1.outputs[0], set_position_002.inputs[0])
	    #math_003_1.Value -> sample_curve_002.Length
	    hair_beads.links.new(math_003_1.outputs[0], sample_curve_002.inputs[3])
	    #join_geometry_001.Geometry -> repeat_output.Geometry
	    hair_beads.links.new(join_geometry_001.outputs[0], repeat_output.inputs[0])
	    #math_004_1.Value -> repeat_output.Integer
	    hair_beads.links.new(math_004_1.outputs[0], repeat_output.inputs[1])
	    #reroute_012.Output -> math_004_1.Value
	    hair_beads.links.new(reroute_012.outputs[0], math_004_1.inputs[0])
	    #math_005.Value -> math_003_1.Value
	    hair_beads.links.new(math_005.outputs[0], math_003_1.inputs[0])
	    #reroute_014.Output -> repeat_input.Iterations
	    hair_beads.links.new(reroute_014.outputs[0], repeat_input.inputs[0])
	    #reverse_curve.Curve -> resample_curve.Curve
	    hair_beads.links.new(reverse_curve.outputs[0], resample_curve.inputs[0])
	    #group_input_1.Offset -> math_005.Value
	    hair_beads.links.new(group_input_1.outputs[4], math_005.inputs[1])
	    #repeat_output.Geometry -> group_output_1.Geometry
	    hair_beads.links.new(repeat_output.outputs[0], group_output_1.inputs[0])
	    #group_input_1.Geometry -> reroute_1.Input
	    hair_beads.links.new(group_input_1.outputs[0], reroute_1.inputs[0])
	    #reroute_1.Output -> domain_size.Geometry
	    hair_beads.links.new(reroute_1.outputs[0], domain_size.inputs[0])
	    #group_input_1.Bead -> reroute_001_1.Input
	    hair_beads.links.new(group_input_1.outputs[1], reroute_001_1.inputs[0])
	    #group_input_1.Bead Scale -> reroute_005_1.Input
	    hair_beads.links.new(group_input_1.outputs[3], reroute_005_1.inputs[0])
	    #reroute_005_1.Output -> reroute_004_1.Input
	    hair_beads.links.new(reroute_005_1.outputs[0], reroute_004_1.inputs[0])
	    #math_002_1.Value -> reroute_006_1.Input
	    hair_beads.links.new(math_002_1.outputs[0], reroute_006_1.inputs[0])
	    #duplicate_elements_002.Geometry -> reroute_007_1.Input
	    hair_beads.links.new(duplicate_elements_002.outputs[0], reroute_007_1.inputs[0])
	    #duplicate_elements_002.Duplicate Index -> reroute_008.Input
	    hair_beads.links.new(duplicate_elements_002.outputs[1], reroute_008.inputs[0])
	    #reroute_008.Output -> reroute_009.Input
	    hair_beads.links.new(reroute_008.outputs[0], reroute_009.inputs[0])
	    #object_info_001.Geometry -> reroute_010.Input
	    hair_beads.links.new(object_info_001.outputs[4], reroute_010.inputs[0])
	    #reroute_010.Output -> realize_instances_1.Geometry
	    hair_beads.links.new(reroute_010.outputs[0], realize_instances_1.inputs[0])
	    #set_position_002.Geometry -> reroute_011.Input
	    hair_beads.links.new(set_position_002.outputs[0], reroute_011.inputs[0])
	    #repeat_input.Integer -> reroute_012.Input
	    hair_beads.links.new(repeat_input.outputs[2], reroute_012.inputs[0])
	    #reroute_013.Output -> math_005.Value
	    hair_beads.links.new(reroute_013.outputs[0], math_005.inputs[0])
	    #reroute_012.Output -> reroute_013.Input
	    hair_beads.links.new(reroute_012.outputs[0], reroute_013.inputs[0])
	    #group_input_001_1.Material -> group.Material
	    hair_beads.links.new(group_input_001_1.outputs[5], group.inputs[6])
	    #reroute_010.Output -> group.Instance
	    hair_beads.links.new(reroute_010.outputs[0], group.inputs[1])
	    #reroute_003_1.Output -> group.Points
	    hair_beads.links.new(reroute_003_1.outputs[0], group.inputs[0])
	    #group_input_001_1.Color Method -> group.Color Method
	    hair_beads.links.new(group_input_001_1.outputs[7], group.inputs[3])
	    #group_input_001_1.Bead Count -> group.Instance Count
	    hair_beads.links.new(group_input_001_1.outputs[2], group.inputs[4])
	    #group_input_001_1.Sample -> group.Sample
	    hair_beads.links.new(group_input_001_1.outputs[8], group.inputs[5])
	    #group_input_002_1.Bead Scale -> group.Scale
	    hair_beads.links.new(group_input_002_1.outputs[3], group.inputs[8])
	    #reroute_002_1.Output -> group.Rotation
	    hair_beads.links.new(reroute_002_1.outputs[0], group.inputs[7])
	    #group.Geometry -> join_geometry_001.Geometry
	    hair_beads.links.new(group.outputs[0], join_geometry_001.inputs[0])
	    #align_rotation_to_vector_001.Rotation -> reroute_002_1.Input
	    hair_beads.links.new(align_rotation_to_vector_001.outputs[0], reroute_002_1.inputs[0])
	    #reroute_011.Output -> reroute_003_1.Input
	    hair_beads.links.new(reroute_011.outputs[0], reroute_003_1.inputs[0])
	    #reroute_015.Output -> reroute_014.Input
	    hair_beads.links.new(reroute_015.outputs[0], reroute_014.inputs[0])
	    #group_input_1.Bead Count -> reroute_015.Input
	    hair_beads.links.new(group_input_1.outputs[2], reroute_015.inputs[0])
	    #group_input_003_1.Name -> group.Name
	    hair_beads.links.new(group_input_003_1.outputs[6], group.inputs[2])
	    #repeat_input.Geometry -> join_geometry_001.Geometry
	    hair_beads.links.new(repeat_input.outputs[1], join_geometry_001.inputs[0])
	    color_method_socket_1.default_value = 'Default'
	    return hair_beads
	
	hair_beads = hair_beads_node_group()
	
	#initialize hair_accessories node group
	def hair_accessories_node_group():
	    hair_accessories = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "HAIR_ACCESSORIES")
	
	    hair_accessories.color_tag = 'NONE'
	    hair_accessories.description = "Add hair accessories at hair tips and | or hair roots."
	    hair_accessories.default_group_node_width = 140
	    
	
	    hair_accessories.is_modifier = True
	
	    #hair_accessories interface
	    #Socket Geometry
	    geometry_socket_3 = hair_accessories.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_3.attribute_domain = 'POINT'
	    geometry_socket_3.description = "Hair with accessories."
	
	    #Socket Geometry
	    geometry_socket_4 = hair_accessories.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_4.attribute_domain = 'POINT'
	    geometry_socket_4.description = "Hair curve."
	
	    #Socket Curve_Guide
	    curve_guide_socket = hair_accessories.interface.new_socket(name = "Curve_Guide", in_out='INPUT', socket_type = 'NodeSocketObject')
	    curve_guide_socket.attribute_domain = 'POINT'
	    curve_guide_socket.description = "Hair curve."
	
	    #Socket Bead
	    bead_socket_1 = hair_accessories.interface.new_socket(name = "Bead", in_out='INPUT', socket_type = 'NodeSocketObject')
	    bead_socket_1.attribute_domain = 'POINT'
	    bead_socket_1.description = "Accessory object for hair tips."
	
	    #Socket Bead Count
	    bead_count_socket_1 = hair_accessories.interface.new_socket(name = "Bead Count", in_out='INPUT', socket_type = 'NodeSocketInt')
	    bead_count_socket_1.default_value = 0
	    bead_count_socket_1.min_value = 0
	    bead_count_socket_1.max_value = 2147483647
	    bead_count_socket_1.subtype = 'NONE'
	    bead_count_socket_1.attribute_domain = 'POINT'
	    bead_count_socket_1.description = "Amount of beads distributed at hair tip."
	
	    #Socket Bead Scale
	    bead_scale_socket_1 = hair_accessories.interface.new_socket(name = "Bead Scale", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    bead_scale_socket_1.default_value = 1.0
	    bead_scale_socket_1.min_value = 0.0
	    bead_scale_socket_1.max_value = 3.4028234663852886e+38
	    bead_scale_socket_1.subtype = 'NONE'
	    bead_scale_socket_1.attribute_domain = 'POINT'
	    bead_scale_socket_1.description = "Overall scale for bead."
	
	    #Socket Bead Offset
	    bead_offset_socket = hair_accessories.interface.new_socket(name = "Bead Offset", in_out='INPUT', socket_type = 'NodeSocketInt')
	    bead_offset_socket.default_value = 0
	    bead_offset_socket.min_value = 0
	    bead_offset_socket.max_value = 2147483647
	    bead_offset_socket.subtype = 'NONE'
	    bead_offset_socket.attribute_domain = 'POINT'
	    bead_offset_socket.description = "Spacing between beads."
	
	    #Socket Bead Material
	    bead_material_socket = hair_accessories.interface.new_socket(name = "Bead Material", in_out='INPUT', socket_type = 'NodeSocketMaterial')
	    bead_material_socket.attribute_domain = 'POINT'
	    bead_material_socket.description = "Material used for beads."
	
	    #Socket Bead Color Method
	    bead_color_method_socket = hair_accessories.interface.new_socket(name = "Bead Color Method", in_out='INPUT', socket_type = 'NodeSocketMenu')
	    bead_color_method_socket.attribute_domain = 'POINT'
	    bead_color_method_socket.description = "Coloring method used to display colors on bead object."
	
	    #Socket Bead Sample
	    bead_sample_socket = hair_accessories.interface.new_socket(name = "Bead Sample", in_out='INPUT', socket_type = 'NodeSocketInt')
	    bead_sample_socket.default_value = 0
	    bead_sample_socket.min_value = 0
	    bead_sample_socket.max_value = 2147483647
	    bead_sample_socket.subtype = 'NONE'
	    bead_sample_socket.attribute_domain = 'POINT'
	    bead_sample_socket.description = "Amount of colors to sample from the material colors."
	
	    #Socket Bow
	    bow_socket = hair_accessories.interface.new_socket(name = "Bow", in_out='INPUT', socket_type = 'NodeSocketObject')
	    bow_socket.attribute_domain = 'POINT'
	    bow_socket.description = "Accessory object for hair roots."
	
	    #Socket Bow Count
	    bow_count_socket = hair_accessories.interface.new_socket(name = "Bow Count", in_out='INPUT', socket_type = 'NodeSocketInt')
	    bow_count_socket.default_value = 0
	    bow_count_socket.min_value = 0
	    bow_count_socket.max_value = 2147483647
	    bow_count_socket.subtype = 'NONE'
	    bow_count_socket.attribute_domain = 'POINT'
	    bow_count_socket.description = "Amount of beads distributed at hair root."
	
	    #Socket Bow Scale
	    bow_scale_socket = hair_accessories.interface.new_socket(name = "Bow Scale", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    bow_scale_socket.default_value = 1.0
	    bow_scale_socket.min_value = 0.0
	    bow_scale_socket.max_value = 3.4028234663852886e+38
	    bow_scale_socket.subtype = 'NONE'
	    bow_scale_socket.attribute_domain = 'POINT'
	    bow_scale_socket.description = "Overall scale for bow."
	
	    #Socket Bow Offset
	    bow_offset_socket = hair_accessories.interface.new_socket(name = "Bow Offset", in_out='INPUT', socket_type = 'NodeSocketInt')
	    bow_offset_socket.default_value = 0
	    bow_offset_socket.min_value = 0
	    bow_offset_socket.max_value = 2147483647
	    bow_offset_socket.subtype = 'NONE'
	    bow_offset_socket.attribute_domain = 'POINT'
	    bow_offset_socket.description = "Spacing between bows."
	
	    #Socket Bow Material
	    bow_material_socket = hair_accessories.interface.new_socket(name = "Bow Material", in_out='INPUT', socket_type = 'NodeSocketMaterial')
	    bow_material_socket.attribute_domain = 'POINT'
	    bow_material_socket.description = "Material used for bows."
	
	    #Socket Bow Color Method
	    bow_color_method_socket = hair_accessories.interface.new_socket(name = "Bow Color Method", in_out='INPUT', socket_type = 'NodeSocketMenu')
	    bow_color_method_socket.attribute_domain = 'POINT'
	    bow_color_method_socket.description = "Coloring method used to display colors on bow object."
	
	    #Socket Bow Sample
	    bow_sample_socket = hair_accessories.interface.new_socket(name = "Bow Sample", in_out='INPUT', socket_type = 'NodeSocketInt')
	    bow_sample_socket.default_value = 0
	    bow_sample_socket.min_value = 0
	    bow_sample_socket.max_value = 2147483647
	    bow_sample_socket.subtype = 'NONE'
	    bow_sample_socket.attribute_domain = 'POINT'
	    bow_sample_socket.description = "Amount of colors to sample from the material colors."
	
	
	    #initialize hair_accessories nodes
	    #node Group Input
	    group_input_2 = hair_accessories.nodes.new("NodeGroupInput")
	    group_input_2.name = "Group Input"
	    group_input_2.outputs[0].hide = True
	    group_input_2.outputs[1].hide = True
	    group_input_2.outputs[7].hide = True
	    group_input_2.outputs[8].hide = True
	    group_input_2.outputs[9].hide = True
	    group_input_2.outputs[10].hide = True
	    group_input_2.outputs[11].hide = True
	    group_input_2.outputs[12].hide = True
	    group_input_2.outputs[13].hide = True
	    group_input_2.outputs[14].hide = True
	    group_input_2.outputs[15].hide = True
	    group_input_2.outputs[16].hide = True
	
	    #node Group Output
	    group_output_2 = hair_accessories.nodes.new("NodeGroupOutput")
	    group_output_2.name = "Group Output"
	    group_output_2.is_active_output = True
	    group_output_2.inputs[1].hide = True
	
	    #node Group
	    group_1 = hair_accessories.nodes.new("GeometryNodeGroup")
	    group_1.name = "Group"
	    group_1.node_tree = hair_beads
	
	    #node Group.001
	    group_001 = hair_accessories.nodes.new("GeometryNodeGroup")
	    group_001.name = "Group.001"
	    group_001.node_tree = hair_beads
	
	    #node Reverse Curve
	    reverse_curve_1 = hair_accessories.nodes.new("GeometryNodeReverseCurve")
	    reverse_curve_1.name = "Reverse Curve"
	    reverse_curve_1.hide = True
	    #Selection
	    reverse_curve_1.inputs[1].default_value = True
	
	    #node Object Info
	    object_info = hair_accessories.nodes.new("GeometryNodeObjectInfo")
	    object_info.name = "Object Info"
	    object_info.hide = True
	    object_info.transform_space = 'RELATIVE'
	    object_info.inputs[1].hide = True
	    object_info.outputs[0].hide = True
	    object_info.outputs[1].hide = True
	    object_info.outputs[2].hide = True
	    object_info.outputs[3].hide = True
	    #As Instance
	    object_info.inputs[1].default_value = False
	
	    #node Switch
	    switch = hair_accessories.nodes.new("GeometryNodeSwitch")
	    switch.name = "Switch"
	    switch.hide = True
	    switch.input_type = 'GEOMETRY'
	
	    #node Domain Size
	    domain_size_1 = hair_accessories.nodes.new("GeometryNodeAttributeDomainSize")
	    domain_size_1.name = "Domain Size"
	    domain_size_1.hide = True
	    domain_size_1.component = 'CURVE'
	
	    #node Compare
	    compare = hair_accessories.nodes.new("FunctionNodeCompare")
	    compare.name = "Compare"
	    compare.hide = True
	    compare.data_type = 'INT'
	    compare.mode = 'ELEMENT'
	    compare.operation = 'EQUAL'
	    #B_INT
	    compare.inputs[3].default_value = 0
	
	    #node Reroute
	    reroute_2 = hair_accessories.nodes.new("NodeReroute")
	    reroute_2.name = "Reroute"
	    reroute_2.socket_idname = "NodeSocketGeometry"
	    #node Frame
	    frame_2 = hair_accessories.nodes.new("NodeFrame")
	    frame_2.name = "Frame"
	    frame_2.label_size = 20
	    frame_2.shrink = True
	
	    #node String
	    string = hair_accessories.nodes.new("FunctionNodeInputString")
	    string.name = "String"
	    string.string = "bead_col"
	
	    #node String.001
	    string_001 = hair_accessories.nodes.new("FunctionNodeInputString")
	    string_001.name = "String.001"
	    string_001.string = "bow_col"
	
	    #node Group Input.001
	    group_input_001_2 = hair_accessories.nodes.new("NodeGroupInput")
	    group_input_001_2.name = "Group Input.001"
	    group_input_001_2.outputs[0].hide = True
	    group_input_001_2.outputs[1].hide = True
	    group_input_001_2.outputs[2].hide = True
	    group_input_001_2.outputs[3].hide = True
	    group_input_001_2.outputs[4].hide = True
	    group_input_001_2.outputs[5].hide = True
	    group_input_001_2.outputs[6].hide = True
	    group_input_001_2.outputs[7].hide = True
	    group_input_001_2.outputs[8].hide = True
	    group_input_001_2.outputs[14].hide = True
	    group_input_001_2.outputs[15].hide = True
	    group_input_001_2.outputs[16].hide = True
	
	    #node Group Input.002
	    group_input_002_2 = hair_accessories.nodes.new("NodeGroupInput")
	    group_input_002_2.name = "Group Input.002"
	    group_input_002_2.outputs[1].hide = True
	    group_input_002_2.outputs[2].hide = True
	    group_input_002_2.outputs[3].hide = True
	    group_input_002_2.outputs[4].hide = True
	    group_input_002_2.outputs[5].hide = True
	    group_input_002_2.outputs[6].hide = True
	    group_input_002_2.outputs[7].hide = True
	    group_input_002_2.outputs[8].hide = True
	    group_input_002_2.outputs[9].hide = True
	    group_input_002_2.outputs[10].hide = True
	    group_input_002_2.outputs[11].hide = True
	    group_input_002_2.outputs[12].hide = True
	    group_input_002_2.outputs[13].hide = True
	    group_input_002_2.outputs[14].hide = True
	    group_input_002_2.outputs[15].hide = True
	    group_input_002_2.outputs[16].hide = True
	
	    #node Group Input.003
	    group_input_003_2 = hair_accessories.nodes.new("NodeGroupInput")
	    group_input_003_2.name = "Group Input.003"
	    group_input_003_2.outputs[0].hide = True
	    group_input_003_2.outputs[2].hide = True
	    group_input_003_2.outputs[3].hide = True
	    group_input_003_2.outputs[4].hide = True
	    group_input_003_2.outputs[5].hide = True
	    group_input_003_2.outputs[6].hide = True
	    group_input_003_2.outputs[7].hide = True
	    group_input_003_2.outputs[8].hide = True
	    group_input_003_2.outputs[9].hide = True
	    group_input_003_2.outputs[10].hide = True
	    group_input_003_2.outputs[11].hide = True
	    group_input_003_2.outputs[12].hide = True
	    group_input_003_2.outputs[13].hide = True
	    group_input_003_2.outputs[14].hide = True
	    group_input_003_2.outputs[15].hide = True
	    group_input_003_2.outputs[16].hide = True
	
	    #node Reroute.001
	    reroute_001_2 = hair_accessories.nodes.new("NodeReroute")
	    reroute_001_2.name = "Reroute.001"
	    reroute_001_2.socket_idname = "NodeSocketGeometry"
	    #node Frame.001
	    frame_001_1 = hair_accessories.nodes.new("NodeFrame")
	    frame_001_1.label = "Beads"
	    frame_001_1.name = "Frame.001"
	    frame_001_1.label_size = 20
	    frame_001_1.shrink = True
	
	    #node Frame.002
	    frame_002_1 = hair_accessories.nodes.new("NodeFrame")
	    frame_002_1.label = "Bows"
	    frame_002_1.name = "Frame.002"
	    frame_002_1.label_size = 20
	    frame_002_1.shrink = True
	
	    #node Group Input.004
	    group_input_004_1 = hair_accessories.nodes.new("NodeGroupInput")
	    group_input_004_1.name = "Group Input.004"
	    group_input_004_1.outputs[0].hide = True
	    group_input_004_1.outputs[1].hide = True
	    group_input_004_1.outputs[2].hide = True
	    group_input_004_1.outputs[3].hide = True
	    group_input_004_1.outputs[4].hide = True
	    group_input_004_1.outputs[5].hide = True
	    group_input_004_1.outputs[6].hide = True
	    group_input_004_1.outputs[9].hide = True
	    group_input_004_1.outputs[10].hide = True
	    group_input_004_1.outputs[11].hide = True
	    group_input_004_1.outputs[12].hide = True
	    group_input_004_1.outputs[13].hide = True
	    group_input_004_1.outputs[14].hide = True
	    group_input_004_1.outputs[15].hide = True
	    group_input_004_1.outputs[16].hide = True
	
	    #node Group Input.005
	    group_input_005_1 = hair_accessories.nodes.new("NodeGroupInput")
	    group_input_005_1.name = "Group Input.005"
	    group_input_005_1.outputs[0].hide = True
	    group_input_005_1.outputs[1].hide = True
	    group_input_005_1.outputs[2].hide = True
	    group_input_005_1.outputs[3].hide = True
	    group_input_005_1.outputs[4].hide = True
	    group_input_005_1.outputs[5].hide = True
	    group_input_005_1.outputs[6].hide = True
	    group_input_005_1.outputs[7].hide = True
	    group_input_005_1.outputs[8].hide = True
	    group_input_005_1.outputs[9].hide = True
	    group_input_005_1.outputs[10].hide = True
	    group_input_005_1.outputs[11].hide = True
	    group_input_005_1.outputs[12].hide = True
	    group_input_005_1.outputs[13].hide = True
	    group_input_005_1.outputs[16].hide = True
	
	    #node Reroute.002
	    reroute_002_2 = hair_accessories.nodes.new("NodeReroute")
	    reroute_002_2.name = "Reroute.002"
	    reroute_002_2.socket_idname = "NodeSocketGeometry"
	    #node Reroute.003
	    reroute_003_2 = hair_accessories.nodes.new("NodeReroute")
	    reroute_003_2.name = "Reroute.003"
	    reroute_003_2.socket_idname = "NodeSocketGeometry"
	    #node Hair Accessories Bake
	    hair_accessories_bake = hair_accessories.nodes.new("GeometryNodeBake")
	    hair_accessories_bake.label = "Hair Accessories Bake"
	    hair_accessories_bake.name = "Hair Accessories Bake"
	    hair_accessories_bake.active_index = 0
	    hair_accessories_bake.bake_items.clear()
	    hair_accessories_bake.bake_items.new('GEOMETRY', "Geometry")
	    hair_accessories_bake.bake_items[0].attribute_domain = 'POINT'
	    hair_accessories_bake.inputs[1].hide = True
	    hair_accessories_bake.outputs[1].hide = True
	
	    #node Separate Components
	    separate_components = hair_accessories.nodes.new("GeometryNodeSeparateComponents")
	    separate_components.name = "Separate Components"
	    separate_components.hide = True
	
	    #node Join Geometry.001
	    join_geometry_001_1 = hair_accessories.nodes.new("GeometryNodeJoinGeometry")
	    join_geometry_001_1.name = "Join Geometry.001"
	    join_geometry_001_1.hide = True
	
	    #node Reroute.004
	    reroute_004_2 = hair_accessories.nodes.new("NodeReroute")
	    reroute_004_2.name = "Reroute.004"
	    reroute_004_2.socket_idname = "NodeSocketGeometry"
	    #node Reroute.005
	    reroute_005_2 = hair_accessories.nodes.new("NodeReroute")
	    reroute_005_2.name = "Reroute.005"
	    reroute_005_2.socket_idname = "NodeSocketGeometry"
	    #node Reroute.006
	    reroute_006_2 = hair_accessories.nodes.new("NodeReroute")
	    reroute_006_2.name = "Reroute.006"
	    reroute_006_2.socket_idname = "NodeSocketGeometry"
	    #node Reroute.007
	    reroute_007_2 = hair_accessories.nodes.new("NodeReroute")
	    reroute_007_2.name = "Reroute.007"
	    reroute_007_2.socket_idname = "NodeSocketGeometry"
	    #node Reroute.008
	    reroute_008_1 = hair_accessories.nodes.new("NodeReroute")
	    reroute_008_1.name = "Reroute.008"
	    reroute_008_1.socket_idname = "NodeSocketGeometry"
	    #node Reroute.009
	    reroute_009_1 = hair_accessories.nodes.new("NodeReroute")
	    reroute_009_1.name = "Reroute.009"
	    reroute_009_1.socket_idname = "NodeSocketGeometry"
	    #node Reroute.010
	    reroute_010_1 = hair_accessories.nodes.new("NodeReroute")
	    reroute_010_1.name = "Reroute.010"
	    reroute_010_1.socket_idname = "NodeSocketGeometry"
	    #node Reroute.011
	    reroute_011_1 = hair_accessories.nodes.new("NodeReroute")
	    reroute_011_1.name = "Reroute.011"
	    reroute_011_1.socket_idname = "NodeSocketGeometry"
	    #node Reroute.012
	    reroute_012_1 = hair_accessories.nodes.new("NodeReroute")
	    reroute_012_1.name = "Reroute.012"
	    reroute_012_1.socket_idname = "NodeSocketGeometry"
	    #node Reroute.013
	    reroute_013_1 = hair_accessories.nodes.new("NodeReroute")
	    reroute_013_1.name = "Reroute.013"
	    reroute_013_1.socket_idname = "NodeSocketGeometry"
	    #node Reroute.014
	    reroute_014_1 = hair_accessories.nodes.new("NodeReroute")
	    reroute_014_1.name = "Reroute.014"
	    reroute_014_1.socket_idname = "NodeSocketGeometry"
	    #node Reroute.015
	    reroute_015_1 = hair_accessories.nodes.new("NodeReroute")
	    reroute_015_1.name = "Reroute.015"
	    reroute_015_1.socket_idname = "NodeSocketGeometry"
	
	
	
	    #Set parents
	    group_input_2.parent = frame_001_1
	    group_1.parent = frame_001_1
	    group_001.parent = frame_002_1
	    switch.parent = frame_2
	    domain_size_1.parent = frame_2
	    compare.parent = frame_2
	    string.parent = frame_001_1
	    string_001.parent = frame_002_1
	    group_input_001_2.parent = frame_002_1
	    group_input_004_1.parent = frame_001_1
	    group_input_005_1.parent = frame_002_1
	    reroute_002_2.parent = frame_001_1
	    reroute_003_2.parent = frame_001_1
	
	    #Set locations
	    group_input_2.location = (30.32598876953125, -71.43766021728516)
	    group_output_2.location = (1465.7745361328125, -271.26885986328125)
	    group_1.location = (248.58349609375, -40.293575286865234)
	    group_001.location = (251.6328125, -40.389373779296875)
	    reverse_curve_1.location = (481.746337890625, -352.6398620605469)
	    object_info.location = (-202.17312622070312, -235.88238525390625)
	    switch.location = (31.704116821289062, -109.07174682617188)
	    domain_size_1.location = (29.54068374633789, -35.3785400390625)
	    compare.location = (31.704181671142578, -72.22518920898438)
	    reroute_2.location = (480.180419921875, -300.5879821777344)
	    frame_2.location = (-38.0, -196.0)
	    string.location = (33.0191650390625, -212.6028289794922)
	    string_001.location = (31.422088623046875, -212.8028564453125)
	    group_input_001_2.location = (30.325958251953125, -71.63778686523438)
	    group_input_002_2.location = (-199.45542907714844, -292.530029296875)
	    group_input_003_2.location = (-371.94195556640625, -211.00970458984375)
	    reroute_001_2.location = (480.83447265625, 43.044151306152344)
	    frame_001_1.location = (480.0, 99.0)
	    frame_002_1.location = (480.0, -311.0)
	    group_input_004_1.location = (33.5882568359375, -296.81744384765625)
	    group_input_005_1.location = (31.99090576171875, -297.017578125)
	    reroute_002_2.location = (227.9134521484375, -119.01350402832031)
	    reroute_003_2.location = (227.2862548828125, -57.2111701965332)
	    hair_accessories_bake.location = (1276.7425537109375, -223.98513793945312)
	    separate_components.location = (186.55178833007812, -305.96209716796875)
	    join_geometry_001_1.location = (1092.9725341796875, -297.29376220703125)
	    reroute_004_2.location = (459.554443359375, 195.17221069335938)
	    reroute_005_2.location = (459.554443359375, 200.19354248046875)
	    reroute_006_2.location = (459.554443359375, 180.16111755371094)
	    reroute_007_2.location = (459.554443359375, 190.1591339111328)
	    reroute_008_1.location = (459.554443359375, 185.15440368652344)
	    reroute_009_1.location = (459.554443359375, 175.18072509765625)
	    reroute_010_1.location = (894.538818359375, 185.4927215576172)
	    reroute_011_1.location = (894.538818359375, 195.4930877685547)
	    reroute_012_1.location = (896.1898193359375, 175.49441528320312)
	    reroute_013_1.location = (894.538818359375, 200.4935302734375)
	    reroute_014_1.location = (894.9407958984375, 180.49314880371094)
	    reroute_015_1.location = (894.538818359375, 190.49282836914062)
	
	    #Set dimensions
	    group_input_2.width, group_input_2.height = 140.0, 100.0
	    group_output_2.width, group_output_2.height = 140.0, 100.0
	    group_1.width, group_1.height = 140.0, 100.0
	    group_001.width, group_001.height = 140.0, 100.0
	    reverse_curve_1.width, reverse_curve_1.height = 140.0, 100.0
	    object_info.width, object_info.height = 140.0, 100.0
	    switch.width, switch.height = 140.0, 100.0
	    domain_size_1.width, domain_size_1.height = 140.0, 100.0
	    compare.width, compare.height = 140.0, 100.0
	    reroute_2.width, reroute_2.height = 10.0, 100.0
	    frame_2.width, frame_2.height = 202.0, 164.0
	    string.width, string.height = 140.0, 100.0
	    string_001.width, string_001.height = 140.0, 100.0
	    group_input_001_2.width, group_input_001_2.height = 140.0, 100.0
	    group_input_002_2.width, group_input_002_2.height = 140.0, 100.0
	    group_input_003_2.width, group_input_003_2.height = 140.0, 100.0
	    reroute_001_2.width, reroute_001_2.height = 10.0, 100.0
	    frame_001_1.width, frame_001_1.height = 419.0, 401.0
	    frame_002_1.width, frame_002_1.height = 422.0, 401.0
	    group_input_004_1.width, group_input_004_1.height = 140.0, 100.0
	    group_input_005_1.width, group_input_005_1.height = 140.0, 100.0
	    reroute_002_2.width, reroute_002_2.height = 10.0, 100.0
	    reroute_003_2.width, reroute_003_2.height = 10.0, 100.0
	    hair_accessories_bake.width, hair_accessories_bake.height = 140.0, 100.0
	    separate_components.width, separate_components.height = 140.0, 100.0
	    join_geometry_001_1.width, join_geometry_001_1.height = 140.0, 100.0
	    reroute_004_2.width, reroute_004_2.height = 10.0, 100.0
	    reroute_005_2.width, reroute_005_2.height = 10.0, 100.0
	    reroute_006_2.width, reroute_006_2.height = 10.0, 100.0
	    reroute_007_2.width, reroute_007_2.height = 10.0, 100.0
	    reroute_008_1.width, reroute_008_1.height = 10.0, 100.0
	    reroute_009_1.width, reroute_009_1.height = 10.0, 100.0
	    reroute_010_1.width, reroute_010_1.height = 10.0, 100.0
	    reroute_011_1.width, reroute_011_1.height = 10.0, 100.0
	    reroute_012_1.width, reroute_012_1.height = 10.0, 100.0
	    reroute_013_1.width, reroute_013_1.height = 10.0, 100.0
	    reroute_014_1.width, reroute_014_1.height = 10.0, 100.0
	    reroute_015_1.width, reroute_015_1.height = 10.0, 100.0
	
	    #initialize hair_accessories links
	    #hair_accessories_bake.Geometry -> group_output_2.Geometry
	    hair_accessories.links.new(hair_accessories_bake.outputs[0], group_output_2.inputs[0])
	    #group_input_2.Bead -> group_1.Bead
	    hair_accessories.links.new(group_input_2.outputs[2], group_1.inputs[1])
	    #group_input_2.Bead Count -> group_1.Bead Count
	    hair_accessories.links.new(group_input_2.outputs[3], group_1.inputs[2])
	    #group_input_2.Bead Scale -> group_1.Bead Scale
	    hair_accessories.links.new(group_input_2.outputs[4], group_1.inputs[3])
	    #group_input_2.Bead Offset -> group_1.Offset
	    hair_accessories.links.new(group_input_2.outputs[5], group_1.inputs[4])
	    #reroute_002_2.Output -> group_1.Geometry
	    hair_accessories.links.new(reroute_002_2.outputs[0], group_1.inputs[0])
	    #reroute_2.Output -> reverse_curve_1.Curve
	    hair_accessories.links.new(reroute_2.outputs[0], reverse_curve_1.inputs[0])
	    #reverse_curve_1.Curve -> group_001.Geometry
	    hair_accessories.links.new(reverse_curve_1.outputs[0], group_001.inputs[0])
	    #domain_size_1.Spline Count -> compare.A
	    hair_accessories.links.new(domain_size_1.outputs[4], compare.inputs[2])
	    #compare.Result -> switch.Switch
	    hair_accessories.links.new(compare.outputs[0], switch.inputs[0])
	    #object_info.Geometry -> switch.False
	    hair_accessories.links.new(object_info.outputs[4], switch.inputs[1])
	    #object_info.Geometry -> domain_size_1.Geometry
	    hair_accessories.links.new(object_info.outputs[4], domain_size_1.inputs[0])
	    #group_input_2.Bead Material -> group_1.Material
	    hair_accessories.links.new(group_input_2.outputs[6], group_1.inputs[5])
	    #string.String -> group_1.Name
	    hair_accessories.links.new(string.outputs[0], group_1.inputs[6])
	    #string_001.String -> group_001.Name
	    hair_accessories.links.new(string_001.outputs[0], group_001.inputs[6])
	    #group_input_002_2.Geometry -> switch.True
	    hair_accessories.links.new(group_input_002_2.outputs[0], switch.inputs[2])
	    #group_input_003_2.Curve_Guide -> object_info.Object
	    hair_accessories.links.new(group_input_003_2.outputs[1], object_info.inputs[0])
	    #group_input_001_2.Bow -> group_001.Bead
	    hair_accessories.links.new(group_input_001_2.outputs[9], group_001.inputs[1])
	    #group_input_001_2.Bow Count -> group_001.Bead Count
	    hair_accessories.links.new(group_input_001_2.outputs[10], group_001.inputs[2])
	    #group_input_001_2.Bow Scale -> group_001.Bead Scale
	    hair_accessories.links.new(group_input_001_2.outputs[11], group_001.inputs[3])
	    #group_input_001_2.Bow Offset -> group_001.Offset
	    hair_accessories.links.new(group_input_001_2.outputs[12], group_001.inputs[4])
	    #group_input_001_2.Bow Material -> group_001.Material
	    hair_accessories.links.new(group_input_001_2.outputs[13], group_001.inputs[5])
	    #reroute_2.Output -> reroute_001_2.Input
	    hair_accessories.links.new(reroute_2.outputs[0], reroute_001_2.inputs[0])
	    #group_input_004_1.Bead Color Method -> group_1.Color Method
	    hair_accessories.links.new(group_input_004_1.outputs[7], group_1.inputs[7])
	    #group_input_004_1.Bead Sample -> group_1.Sample
	    hair_accessories.links.new(group_input_004_1.outputs[8], group_1.inputs[8])
	    #reroute_003_2.Output -> reroute_002_2.Input
	    hair_accessories.links.new(reroute_003_2.outputs[0], reroute_002_2.inputs[0])
	    #reroute_001_2.Output -> reroute_003_2.Input
	    hair_accessories.links.new(reroute_001_2.outputs[0], reroute_003_2.inputs[0])
	    #group_input_005_1.Bow Color Method -> group_001.Color Method
	    hair_accessories.links.new(group_input_005_1.outputs[14], group_001.inputs[7])
	    #group_input_005_1.Bow Sample -> group_001.Sample
	    hair_accessories.links.new(group_input_005_1.outputs[15], group_001.inputs[8])
	    #switch.Output -> separate_components.Geometry
	    hair_accessories.links.new(switch.outputs[0], separate_components.inputs[0])
	    #separate_components.Curve -> reroute_2.Input
	    hair_accessories.links.new(separate_components.outputs[1], reroute_2.inputs[0])
	    #reroute_012_1.Output -> join_geometry_001_1.Geometry
	    hair_accessories.links.new(reroute_012_1.outputs[0], join_geometry_001_1.inputs[0])
	    #separate_components.Curve -> reroute_004_2.Input
	    hair_accessories.links.new(separate_components.outputs[1], reroute_004_2.inputs[0])
	    #separate_components.Mesh -> reroute_005_2.Input
	    hair_accessories.links.new(separate_components.outputs[0], reroute_005_2.inputs[0])
	    #separate_components.Volume -> reroute_006_2.Input
	    hair_accessories.links.new(separate_components.outputs[4], reroute_006_2.inputs[0])
	    #separate_components.Grease Pencil -> reroute_007_2.Input
	    hair_accessories.links.new(separate_components.outputs[2], reroute_007_2.inputs[0])
	    #separate_components.Point Cloud -> reroute_008_1.Input
	    hair_accessories.links.new(separate_components.outputs[3], reroute_008_1.inputs[0])
	    #separate_components.Instances -> reroute_009_1.Input
	    hair_accessories.links.new(separate_components.outputs[5], reroute_009_1.inputs[0])
	    #reroute_008_1.Output -> reroute_010_1.Input
	    hair_accessories.links.new(reroute_008_1.outputs[0], reroute_010_1.inputs[0])
	    #reroute_004_2.Output -> reroute_011_1.Input
	    hair_accessories.links.new(reroute_004_2.outputs[0], reroute_011_1.inputs[0])
	    #reroute_009_1.Output -> reroute_012_1.Input
	    hair_accessories.links.new(reroute_009_1.outputs[0], reroute_012_1.inputs[0])
	    #reroute_005_2.Output -> reroute_013_1.Input
	    hair_accessories.links.new(reroute_005_2.outputs[0], reroute_013_1.inputs[0])
	    #reroute_006_2.Output -> reroute_014_1.Input
	    hair_accessories.links.new(reroute_006_2.outputs[0], reroute_014_1.inputs[0])
	    #reroute_007_2.Output -> reroute_015_1.Input
	    hair_accessories.links.new(reroute_007_2.outputs[0], reroute_015_1.inputs[0])
	    #join_geometry_001_1.Geometry -> hair_accessories_bake.Geometry
	    hair_accessories.links.new(join_geometry_001_1.outputs[0], hair_accessories_bake.inputs[0])
	    #reroute_014_1.Output -> join_geometry_001_1.Geometry
	    hair_accessories.links.new(reroute_014_1.outputs[0], join_geometry_001_1.inputs[0])
	    #reroute_010_1.Output -> join_geometry_001_1.Geometry
	    hair_accessories.links.new(reroute_010_1.outputs[0], join_geometry_001_1.inputs[0])
	    #reroute_015_1.Output -> join_geometry_001_1.Geometry
	    hair_accessories.links.new(reroute_015_1.outputs[0], join_geometry_001_1.inputs[0])
	    #reroute_011_1.Output -> join_geometry_001_1.Geometry
	    hair_accessories.links.new(reroute_011_1.outputs[0], join_geometry_001_1.inputs[0])
	    #reroute_013_1.Output -> join_geometry_001_1.Geometry
	    hair_accessories.links.new(reroute_013_1.outputs[0], join_geometry_001_1.inputs[0])
	    #group_001.Geometry -> join_geometry_001_1.Geometry
	    hair_accessories.links.new(group_001.outputs[0], join_geometry_001_1.inputs[0])
	    #group_1.Geometry -> join_geometry_001_1.Geometry
	    hair_accessories.links.new(group_1.outputs[0], join_geometry_001_1.inputs[0])
	    bead_color_method_socket.default_value = 'Default'
	    bow_color_method_socket.default_value = 'Default'
	    return hair_accessories
	return hair_accessories_node_group()

	

	
