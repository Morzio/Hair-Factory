import bpy, mathutils

def node():
	#initialize hair_card node group
	def hair_card_node_group():
	    hair_card = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Hair_Card")
	
	    hair_card.color_tag = 'NONE'
	    hair_card.description = ""
	    hair_card.default_group_node_width = 140
	    
	
	    hair_card.is_modifier = True
	
	    #hair_card interface
	    #Socket Geometry
	    geometry_socket = hair_card.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket.attribute_domain = 'POINT'
	
	    #Socket Geometry
	    geometry_socket_1 = hair_card.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_1.attribute_domain = 'POINT'
	
	    #Socket Material
	    material_socket = hair_card.interface.new_socket(name = "Material", in_out='INPUT', socket_type = 'NodeSocketMaterial')
	    material_socket.attribute_domain = 'POINT'
	
	    #Socket Curve Radius
	    curve_radius_socket = hair_card.interface.new_socket(name = "Curve Radius", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    curve_radius_socket.default_value = 1.0
	    curve_radius_socket.min_value = 0.0
	    curve_radius_socket.max_value = 3.4028234663852886e+38
	    curve_radius_socket.subtype = 'DISTANCE'
	    curve_radius_socket.attribute_domain = 'POINT'
	    curve_radius_socket.hide_value = True
	    curve_radius_socket.hide_in_modifier = True
	
	    #Socket Resolution
	    resolution_socket = hair_card.interface.new_socket(name = "Resolution", in_out='INPUT', socket_type = 'NodeSocketInt')
	    resolution_socket.default_value = 0
	    resolution_socket.min_value = 2
	    resolution_socket.max_value = 512
	    resolution_socket.subtype = 'NONE'
	    resolution_socket.attribute_domain = 'POINT'
	
	    #Socket Width
	    width_socket = hair_card.interface.new_socket(name = "Width", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    width_socket.default_value = 0.10000000149011612
	    width_socket.min_value = 0.0
	    width_socket.max_value = 3.4028234663852886e+38
	    width_socket.subtype = 'DISTANCE'
	    width_socket.attribute_domain = 'POINT'
	
	    #Socket Angle
	    angle_socket = hair_card.interface.new_socket(name = "Angle", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    angle_socket.default_value = 45.0
	    angle_socket.min_value = -90.0
	    angle_socket.max_value = 90.0
	    angle_socket.subtype = 'ANGLE'
	    angle_socket.attribute_domain = 'POINT'
	
	
	    #initialize hair_card nodes
	    #node Group Input
	    group_input = hair_card.nodes.new("NodeGroupInput")
	    group_input.name = "Group Input"
	    group_input.outputs[1].hide = True
	    group_input.outputs[2].hide = True
	    group_input.outputs[5].hide = True
	    group_input.outputs[6].hide = True
	
	    #node Group Output
	    group_output = hair_card.nodes.new("NodeGroupOutput")
	    group_output.name = "Group Output"
	    group_output.is_active_output = True
	
	    #node Curve to Mesh
	    curve_to_mesh = hair_card.nodes.new("GeometryNodeCurveToMesh")
	    curve_to_mesh.name = "Curve to Mesh"
	    curve_to_mesh.hide = True
	    #Fill Caps
	    curve_to_mesh.inputs[2].default_value = False
	
	    #node Capture Attribute
	    capture_attribute = hair_card.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute.name = "Capture Attribute"
	    capture_attribute.hide = True
	    capture_attribute.active_index = 0
	    capture_attribute.capture_items.clear()
	    capture_attribute.capture_items.new('FLOAT', "Factor")
	    capture_attribute.capture_items["Factor"].data_type = 'FLOAT'
	    capture_attribute.domain = 'POINT'
	
	    #node Spline Parameter
	    spline_parameter = hair_card.nodes.new("GeometryNodeSplineParameter")
	    spline_parameter.name = "Spline Parameter"
	    spline_parameter.hide = True
	
	    #node Combine XYZ
	    combine_xyz = hair_card.nodes.new("ShaderNodeCombineXYZ")
	    combine_xyz.name = "Combine XYZ"
	    combine_xyz.hide = True
	    #Z
	    combine_xyz.inputs[2].default_value = 0.0
	
	    #node Store Named Attribute
	    store_named_attribute = hair_card.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute.name = "Store Named Attribute"
	    store_named_attribute.data_type = 'FLOAT2'
	    store_named_attribute.domain = 'CORNER'
	    #Selection
	    store_named_attribute.inputs[1].default_value = True
	    #Name
	    store_named_attribute.inputs[2].default_value = "hair_card_UV"
	
	    #node Set Material
	    set_material = hair_card.nodes.new("GeometryNodeSetMaterial")
	    set_material.name = "Set Material"
	    set_material.hide = True
	    #Selection
	    set_material.inputs[1].default_value = True
	
	    #node Capture Attribute.002
	    capture_attribute_002 = hair_card.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_002.name = "Capture Attribute.002"
	    capture_attribute_002.hide = True
	    capture_attribute_002.active_index = 0
	    capture_attribute_002.capture_items.clear()
	    capture_attribute_002.capture_items.new('FLOAT', "Factor")
	    capture_attribute_002.capture_items["Factor"].data_type = 'FLOAT'
	    capture_attribute_002.domain = 'POINT'
	
	    #node Reroute
	    reroute = hair_card.nodes.new("NodeReroute")
	    reroute.name = "Reroute"
	    reroute.socket_idname = "NodeSocketFloat"
	    #node Group Input.001
	    group_input_001 = hair_card.nodes.new("NodeGroupInput")
	    group_input_001.name = "Group Input.001"
	    group_input_001.outputs[0].hide = True
	    group_input_001.outputs[2].hide = True
	    group_input_001.outputs[3].hide = True
	    group_input_001.outputs[4].hide = True
	    group_input_001.outputs[5].hide = True
	    group_input_001.outputs[6].hide = True
	
	    #node Reroute.001
	    reroute_001 = hair_card.nodes.new("NodeReroute")
	    reroute_001.name = "Reroute.001"
	    reroute_001.socket_idname = "NodeSocketFloatDistance"
	    #node Resample Curve
	    resample_curve = hair_card.nodes.new("GeometryNodeResampleCurve")
	    resample_curve.name = "Resample Curve"
	    resample_curve.hide = True
	    resample_curve.keep_last_segment = False
	    resample_curve.mode = 'COUNT'
	    #Selection
	    resample_curve.inputs[1].default_value = True
	
	    #node Switch
	    switch = hair_card.nodes.new("GeometryNodeSwitch")
	    switch.name = "Switch"
	    switch.hide = True
	    switch.input_type = 'GEOMETRY'
	
	    #node Group Input.002
	    group_input_002 = hair_card.nodes.new("NodeGroupInput")
	    group_input_002.name = "Group Input.002"
	    group_input_002.outputs[0].hide = True
	    group_input_002.outputs[1].hide = True
	    group_input_002.outputs[2].hide = True
	    group_input_002.outputs[4].hide = True
	    group_input_002.outputs[5].hide = True
	    group_input_002.outputs[6].hide = True
	
	    #node Compare
	    compare = hair_card.nodes.new("FunctionNodeCompare")
	    compare.name = "Compare"
	    compare.hide = True
	    compare.data_type = 'INT'
	    compare.mode = 'ELEMENT'
	    compare.operation = 'LESS_THAN'
	    #B_INT
	    compare.inputs[3].default_value = 2
	
	    #node Reroute.002
	    reroute_002 = hair_card.nodes.new("NodeReroute")
	    reroute_002.name = "Reroute.002"
	    reroute_002.socket_idname = "NodeSocketGeometry"
	    #node Group Input.003
	    group_input_003 = hair_card.nodes.new("NodeGroupInput")
	    group_input_003.name = "Group Input.003"
	    group_input_003.outputs[0].hide = True
	    group_input_003.outputs[1].hide = True
	    group_input_003.outputs[2].hide = True
	    group_input_003.outputs[3].hide = True
	    group_input_003.outputs[4].hide = True
	    group_input_003.outputs[6].hide = True
	
	    #node Points
	    points = hair_card.nodes.new("GeometryNodePoints")
	    points.name = "Points"
	    points.hide = True
	    #Count
	    points.inputs[0].default_value = 1
	    #Position
	    points.inputs[1].default_value = (0.0, 0.0, 0.0)
	    #Radius
	    points.inputs[2].default_value = 0.10000000149011612
	
	    #node Points.001
	    points_001 = hair_card.nodes.new("GeometryNodePoints")
	    points_001.name = "Points.001"
	    points_001.hide = True
	    #Count
	    points_001.inputs[0].default_value = 1
	    #Radius
	    points_001.inputs[2].default_value = 0.10000000149011612
	
	    #node Points.002
	    points_002 = hair_card.nodes.new("GeometryNodePoints")
	    points_002.name = "Points.002"
	    points_002.hide = True
	    #Count
	    points_002.inputs[0].default_value = 1
	    #Radius
	    points_002.inputs[2].default_value = 0.10000000149011612
	
	    #node Points to Curves
	    points_to_curves = hair_card.nodes.new("GeometryNodePointsToCurves")
	    points_to_curves.name = "Points to Curves"
	    points_to_curves.hide = True
	    #Curve Group ID
	    points_to_curves.inputs[1].default_value = 0
	    #Weight
	    points_to_curves.inputs[2].default_value = 0.0
	
	    #node Join Geometry
	    join_geometry = hair_card.nodes.new("GeometryNodeJoinGeometry")
	    join_geometry.name = "Join Geometry"
	    join_geometry.hide = True
	
	    #node Vector Rotate
	    vector_rotate = hair_card.nodes.new("ShaderNodeVectorRotate")
	    vector_rotate.name = "Vector Rotate"
	    vector_rotate.hide = True
	    vector_rotate.invert = False
	    vector_rotate.rotation_type = 'AXIS_ANGLE'
	    #Center
	    vector_rotate.inputs[1].default_value = (0.0, 0.0, 0.0)
	    #Axis
	    vector_rotate.inputs[2].default_value = (0.0, 0.0, 1.0)
	
	    #node Combine XYZ.003
	    combine_xyz_003 = hair_card.nodes.new("ShaderNodeCombineXYZ")
	    combine_xyz_003.name = "Combine XYZ.003"
	    combine_xyz_003.hide = True
	    #Y
	    combine_xyz_003.inputs[1].default_value = 0.0
	    #Z
	    combine_xyz_003.inputs[2].default_value = 0.0
	
	    #node Vector Math
	    vector_math = hair_card.nodes.new("ShaderNodeVectorMath")
	    vector_math.name = "Vector Math"
	    vector_math.hide = True
	    vector_math.operation = 'MULTIPLY'
	    #Vector_001
	    vector_math.inputs[1].default_value = (-1.0, 1.0, 1.0)
	
	    #node Set Curve Radius
	    set_curve_radius = hair_card.nodes.new("GeometryNodeSetCurveRadius")
	    set_curve_radius.name = "Set Curve Radius"
	    set_curve_radius.hide = True
	    #Selection
	    set_curve_radius.inputs[1].default_value = True
	
	    #node Group Input.004
	    group_input_004 = hair_card.nodes.new("NodeGroupInput")
	    group_input_004.name = "Group Input.004"
	    group_input_004.outputs[0].hide = True
	    group_input_004.outputs[1].hide = True
	    group_input_004.outputs[3].hide = True
	    group_input_004.outputs[4].hide = True
	    group_input_004.outputs[5].hide = True
	    group_input_004.outputs[6].hide = True
	
	    #node Reroute.003
	    reroute_003 = hair_card.nodes.new("NodeReroute")
	    reroute_003.name = "Reroute.003"
	    reroute_003.socket_idname = "NodeSocketFloatDistance"
	    #node Reroute.004
	    reroute_004 = hair_card.nodes.new("NodeReroute")
	    reroute_004.name = "Reroute.004"
	    reroute_004.socket_idname = "NodeSocketFloatDistance"
	
	
	
	
	    #Set locations
	    group_input.location = (-340.0, 0.0)
	    group_output.location = (1204.581787109375, 58.388336181640625)
	    curve_to_mesh.location = (717.3101196289062, -30.657630920410156)
	    capture_attribute.location = (532.3717651367188, -13.901289939880371)
	    spline_parameter.location = (329.8749084472656, -144.0863800048828)
	    combine_xyz.location = (717.11865234375, -93.34249114990234)
	    store_named_attribute.location = (883.1387329101562, 66.61811828613281)
	    set_material.location = (1044.3658447265625, 32.40200424194336)
	    capture_attribute_002.location = (534.5352783203125, -74.45401000976562)
	    reroute.location = (496.6486511230469, -141.76992797851562)
	    group_input_001.location = (1041.4315185546875, 1.5365350246429443)
	    reroute_001.location = (-187.22337341308594, -77.96863555908203)
	    resample_curve.location = (-5.360104560852051, -28.505603790283203)
	    switch.location = (-5.43592643737793, 6.486942291259766)
	    group_input_002.location = (-336.779052734375, 70.9764633178711)
	    compare.location = (-8.656487464904785, 41.045326232910156)
	    reroute_002.location = (-99.20211791992188, -32.54893493652344)
	    group_input_003.location = (-339.9999694824219, -103.2856674194336)
	    points.location = (156.70631408691406, -123.0439224243164)
	    points_001.location = (156.70632934570312, -81.72965240478516)
	    points_002.location = (158.99679565429688, -168.9486846923828)
	    points_to_curves.location = (321.6205749511719, -74.84392547607422)
	    join_geometry.location = (328.4919128417969, -106.97728729248047)
	    vector_rotate.location = (-8.371872901916504, -97.79617309570312)
	    combine_xyz_003.location = (-168.62094116210938, -79.79706573486328)
	    vector_math.location = (-6.081514358520508, -135.33193969726562)
	    set_curve_radius.location = (320.7674560546875, -1.0603179931640625)
	    group_input_004.location = (-334.8185729980469, 133.8203125)
	    reroute_003.location = (237.70924377441406, 97.4658203125)
	    reroute_004.location = (241.74778747558594, -21.909408569335938)
	
	    #Set dimensions
	    group_input.width, group_input.height = 140.0, 100.0
	    group_output.width, group_output.height = 140.0, 100.0
	    curve_to_mesh.width, curve_to_mesh.height = 140.0, 100.0
	    capture_attribute.width, capture_attribute.height = 140.0, 100.0
	    spline_parameter.width, spline_parameter.height = 140.0, 100.0
	    combine_xyz.width, combine_xyz.height = 140.0, 100.0
	    store_named_attribute.width, store_named_attribute.height = 140.0, 100.0
	    set_material.width, set_material.height = 140.0, 100.0
	    capture_attribute_002.width, capture_attribute_002.height = 140.0, 100.0
	    reroute.width, reroute.height = 100.0, 100.0
	    group_input_001.width, group_input_001.height = 140.0, 100.0
	    reroute_001.width, reroute_001.height = 100.0, 100.0
	    resample_curve.width, resample_curve.height = 140.0, 100.0
	    switch.width, switch.height = 140.0, 100.0
	    group_input_002.width, group_input_002.height = 140.0, 100.0
	    compare.width, compare.height = 140.0, 100.0
	    reroute_002.width, reroute_002.height = 100.0, 100.0
	    group_input_003.width, group_input_003.height = 140.0, 100.0
	    points.width, points.height = 140.0, 100.0
	    points_001.width, points_001.height = 140.0, 100.0
	    points_002.width, points_002.height = 140.0, 100.0
	    points_to_curves.width, points_to_curves.height = 140.0, 100.0
	    join_geometry.width, join_geometry.height = 140.0, 100.0
	    vector_rotate.width, vector_rotate.height = 140.0, 100.0
	    combine_xyz_003.width, combine_xyz_003.height = 140.0, 100.0
	    vector_math.width, vector_math.height = 140.0, 100.0
	    set_curve_radius.width, set_curve_radius.height = 140.0, 100.0
	    group_input_004.width, group_input_004.height = 140.0, 100.0
	    reroute_003.width, reroute_003.height = 100.0, 100.0
	    reroute_004.width, reroute_004.height = 100.0, 100.0
	
	    #initialize hair_card links
	    #set_material.Geometry -> group_output.Geometry
	    hair_card.links.new(set_material.outputs[0], group_output.inputs[0])
	    #capture_attribute.Geometry -> curve_to_mesh.Curve
	    hair_card.links.new(capture_attribute.outputs[0], curve_to_mesh.inputs[0])
	    #reroute.Output -> capture_attribute.Factor
	    hair_card.links.new(reroute.outputs[0], capture_attribute.inputs[1])
	    #capture_attribute.Factor -> combine_xyz.X
	    hair_card.links.new(capture_attribute.outputs[1], combine_xyz.inputs[0])
	    #curve_to_mesh.Mesh -> store_named_attribute.Geometry
	    hair_card.links.new(curve_to_mesh.outputs[0], store_named_attribute.inputs[0])
	    #combine_xyz.Vector -> store_named_attribute.Value
	    hair_card.links.new(combine_xyz.outputs[0], store_named_attribute.inputs[3])
	    #store_named_attribute.Geometry -> set_material.Geometry
	    hair_card.links.new(store_named_attribute.outputs[0], set_material.inputs[0])
	    #reroute.Output -> capture_attribute_002.Factor
	    hair_card.links.new(reroute.outputs[0], capture_attribute_002.inputs[1])
	    #capture_attribute_002.Factor -> combine_xyz.Y
	    hair_card.links.new(capture_attribute_002.outputs[1], combine_xyz.inputs[1])
	    #spline_parameter.Factor -> reroute.Input
	    hair_card.links.new(spline_parameter.outputs[0], reroute.inputs[0])
	    #group_input_001.Material -> set_material.Material
	    hair_card.links.new(group_input_001.outputs[1], set_material.inputs[2])
	    #group_input.Width -> reroute_001.Input
	    hair_card.links.new(group_input.outputs[4], reroute_001.inputs[0])
	    #reroute_002.Output -> resample_curve.Curve
	    hair_card.links.new(reroute_002.outputs[0], resample_curve.inputs[0])
	    #group_input.Resolution -> resample_curve.Count
	    hair_card.links.new(group_input.outputs[3], resample_curve.inputs[2])
	    #group_input_002.Resolution -> compare.A
	    hair_card.links.new(group_input_002.outputs[3], compare.inputs[2])
	    #compare.Result -> switch.Switch
	    hair_card.links.new(compare.outputs[0], switch.inputs[0])
	    #set_curve_radius.Curve -> capture_attribute.Geometry
	    hair_card.links.new(set_curve_radius.outputs[0], capture_attribute.inputs[0])
	    #group_input.Geometry -> reroute_002.Input
	    hair_card.links.new(group_input.outputs[0], reroute_002.inputs[0])
	    #reroute_002.Output -> switch.True
	    hair_card.links.new(reroute_002.outputs[0], switch.inputs[2])
	    #resample_curve.Curve -> switch.False
	    hair_card.links.new(resample_curve.outputs[0], switch.inputs[1])
	    #join_geometry.Geometry -> points_to_curves.Points
	    hair_card.links.new(join_geometry.outputs[0], points_to_curves.inputs[0])
	    #points_002.Points -> join_geometry.Geometry
	    hair_card.links.new(points_002.outputs[0], join_geometry.inputs[0])
	    #group_input_003.Angle -> vector_rotate.Angle
	    hair_card.links.new(group_input_003.outputs[5], vector_rotate.inputs[3])
	    #vector_rotate.Vector -> vector_math.Vector
	    hair_card.links.new(vector_rotate.outputs[0], vector_math.inputs[0])
	    #vector_rotate.Vector -> points_001.Position
	    hair_card.links.new(vector_rotate.outputs[0], points_001.inputs[1])
	    #vector_math.Vector -> points_002.Position
	    hair_card.links.new(vector_math.outputs[0], points_002.inputs[1])
	    #combine_xyz_003.Vector -> vector_rotate.Vector
	    hair_card.links.new(combine_xyz_003.outputs[0], vector_rotate.inputs[0])
	    #reroute_001.Output -> combine_xyz_003.X
	    hair_card.links.new(reroute_001.outputs[0], combine_xyz_003.inputs[0])
	    #points_to_curves.Curves -> capture_attribute_002.Geometry
	    hair_card.links.new(points_to_curves.outputs[0], capture_attribute_002.inputs[0])
	    #capture_attribute_002.Geometry -> curve_to_mesh.Profile Curve
	    hair_card.links.new(capture_attribute_002.outputs[0], curve_to_mesh.inputs[1])
	    #switch.Output -> set_curve_radius.Curve
	    hair_card.links.new(switch.outputs[0], set_curve_radius.inputs[0])
	    #reroute_004.Output -> set_curve_radius.Radius
	    hair_card.links.new(reroute_004.outputs[0], set_curve_radius.inputs[2])
	    #group_input_004.Curve Radius -> reroute_003.Input
	    hair_card.links.new(group_input_004.outputs[2], reroute_003.inputs[0])
	    #reroute_003.Output -> reroute_004.Input
	    hair_card.links.new(reroute_003.outputs[0], reroute_004.inputs[0])
	    #points.Points -> join_geometry.Geometry
	    hair_card.links.new(points.outputs[0], join_geometry.inputs[0])
	    #points_001.Points -> join_geometry.Geometry
	    hair_card.links.new(points_001.outputs[0], join_geometry.inputs[0])
	    return hair_card
	
	hair_card = hair_card_node_group()
	
	#initialize stylized_hair node group
	def stylized_hair_node_group():
	    stylized_hair = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Stylized_Hair")
	
	    stylized_hair.color_tag = 'NONE'
	    stylized_hair.description = ""
	    stylized_hair.default_group_node_width = 140
	    
	
	    stylized_hair.is_modifier = True
	
	    #stylized_hair interface
	    #Socket Geometry
	    geometry_socket_2 = stylized_hair.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_2.attribute_domain = 'POINT'
	
	    #Socket Geometry
	    geometry_socket_3 = stylized_hair.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_3.attribute_domain = 'POINT'
	
	    #Socket Profile
	    profile_socket = stylized_hair.interface.new_socket(name = "Profile", in_out='INPUT', socket_type = 'NodeSocketObject')
	    profile_socket.attribute_domain = 'POINT'
	
	    #Socket Material
	    material_socket_1 = stylized_hair.interface.new_socket(name = "Material", in_out='INPUT', socket_type = 'NodeSocketMaterial')
	    material_socket_1.attribute_domain = 'POINT'
	
	    #Socket Curve Radius
	    curve_radius_socket_1 = stylized_hair.interface.new_socket(name = "Curve Radius", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    curve_radius_socket_1.default_value = 1.0
	    curve_radius_socket_1.min_value = 0.0
	    curve_radius_socket_1.max_value = 3.4028234663852886e+38
	    curve_radius_socket_1.subtype = 'DISTANCE'
	    curve_radius_socket_1.attribute_domain = 'POINT'
	    curve_radius_socket_1.hide_value = True
	    curve_radius_socket_1.hide_in_modifier = True
	
	    #Socket Resolution
	    resolution_socket_1 = stylized_hair.interface.new_socket(name = "Resolution", in_out='INPUT', socket_type = 'NodeSocketInt')
	    resolution_socket_1.default_value = 10
	    resolution_socket_1.min_value = 1
	    resolution_socket_1.max_value = 100000
	    resolution_socket_1.subtype = 'NONE'
	    resolution_socket_1.attribute_domain = 'POINT'
	
	    #Socket Fill Caps
	    fill_caps_socket = stylized_hair.interface.new_socket(name = "Fill Caps", in_out='INPUT', socket_type = 'NodeSocketBool')
	    fill_caps_socket.default_value = True
	    fill_caps_socket.attribute_domain = 'POINT'
	
	    #Socket Translation
	    translation_socket = stylized_hair.interface.new_socket(name = "Translation", in_out='INPUT', socket_type = 'NodeSocketVector')
	    translation_socket.default_value = (0.0, 0.0, 0.0)
	    translation_socket.min_value = -3.4028234663852886e+38
	    translation_socket.max_value = 3.4028234663852886e+38
	    translation_socket.subtype = 'TRANSLATION'
	    translation_socket.attribute_domain = 'POINT'
	
	    #Socket Rotation
	    rotation_socket = stylized_hair.interface.new_socket(name = "Rotation", in_out='INPUT', socket_type = 'NodeSocketRotation')
	    rotation_socket.default_value = (0.0, 0.0, 0.0)
	    rotation_socket.attribute_domain = 'POINT'
	
	    #Socket Scale
	    scale_socket = stylized_hair.interface.new_socket(name = "Scale", in_out='INPUT', socket_type = 'NodeSocketVector')
	    scale_socket.default_value = (1.0, 1.0, 1.0)
	    scale_socket.min_value = -3.4028234663852886e+38
	    scale_socket.max_value = 3.4028234663852886e+38
	    scale_socket.subtype = 'XYZ'
	    scale_socket.attribute_domain = 'POINT'
	
	
	    #initialize stylized_hair nodes
	    #node Group Input
	    group_input_1 = stylized_hair.nodes.new("NodeGroupInput")
	    group_input_1.name = "Group Input"
	    group_input_1.outputs[2].hide = True
	    group_input_1.outputs[3].hide = True
	    group_input_1.outputs[4].hide = True
	    group_input_1.outputs[5].hide = True
	    group_input_1.outputs[6].hide = True
	    group_input_1.outputs[7].hide = True
	    group_input_1.outputs[8].hide = True
	    group_input_1.outputs[9].hide = True
	
	    #node Group Output
	    group_output_1 = stylized_hair.nodes.new("NodeGroupOutput")
	    group_output_1.name = "Group Output"
	    group_output_1.is_active_output = True
	
	    #node Curve to Mesh
	    curve_to_mesh_1 = stylized_hair.nodes.new("GeometryNodeCurveToMesh")
	    curve_to_mesh_1.name = "Curve to Mesh"
	    curve_to_mesh_1.hide = True
	
	    #node Capture Attribute
	    capture_attribute_1 = stylized_hair.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_1.name = "Capture Attribute"
	    capture_attribute_1.hide = True
	    capture_attribute_1.active_index = 0
	    capture_attribute_1.capture_items.clear()
	    capture_attribute_1.capture_items.new('FLOAT', "Factor")
	    capture_attribute_1.capture_items["Factor"].data_type = 'FLOAT'
	    capture_attribute_1.domain = 'POINT'
	
	    #node Spline Parameter
	    spline_parameter_1 = stylized_hair.nodes.new("GeometryNodeSplineParameter")
	    spline_parameter_1.name = "Spline Parameter"
	    spline_parameter_1.hide = True
	
	    #node Combine XYZ
	    combine_xyz_1 = stylized_hair.nodes.new("ShaderNodeCombineXYZ")
	    combine_xyz_1.name = "Combine XYZ"
	    combine_xyz_1.hide = True
	    #Z
	    combine_xyz_1.inputs[2].default_value = 0.0
	
	    #node Store Named Attribute
	    store_named_attribute_1 = stylized_hair.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_1.name = "Store Named Attribute"
	    store_named_attribute_1.data_type = 'FLOAT2'
	    store_named_attribute_1.domain = 'CORNER'
	    #Selection
	    store_named_attribute_1.inputs[1].default_value = True
	    #Name
	    store_named_attribute_1.inputs[2].default_value = "stylized_hair_UV"
	
	    #node Set Material
	    set_material_1 = stylized_hair.nodes.new("GeometryNodeSetMaterial")
	    set_material_1.name = "Set Material"
	    set_material_1.hide = True
	    #Selection
	    set_material_1.inputs[1].default_value = True
	
	    #node Capture Attribute.002
	    capture_attribute_002_1 = stylized_hair.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_002_1.name = "Capture Attribute.002"
	    capture_attribute_002_1.hide = True
	    capture_attribute_002_1.active_index = 0
	    capture_attribute_002_1.capture_items.clear()
	    capture_attribute_002_1.capture_items.new('FLOAT', "Factor")
	    capture_attribute_002_1.capture_items["Factor"].data_type = 'FLOAT'
	    capture_attribute_002_1.domain = 'POINT'
	
	    #node Reroute
	    reroute_1 = stylized_hair.nodes.new("NodeReroute")
	    reroute_1.name = "Reroute"
	    reroute_1.socket_idname = "NodeSocketFloat"
	    #node Group Input.001
	    group_input_001_1 = stylized_hair.nodes.new("NodeGroupInput")
	    group_input_001_1.name = "Group Input.001"
	    group_input_001_1.outputs[0].hide = True
	    group_input_001_1.outputs[1].hide = True
	    group_input_001_1.outputs[3].hide = True
	    group_input_001_1.outputs[4].hide = True
	    group_input_001_1.outputs[5].hide = True
	    group_input_001_1.outputs[6].hide = True
	    group_input_001_1.outputs[7].hide = True
	    group_input_001_1.outputs[8].hide = True
	    group_input_001_1.outputs[9].hide = True
	
	    #node Group Input.002
	    group_input_002_1 = stylized_hair.nodes.new("NodeGroupInput")
	    group_input_002_1.name = "Group Input.002"
	    group_input_002_1.outputs[0].hide = True
	    group_input_002_1.outputs[1].hide = True
	    group_input_002_1.outputs[2].hide = True
	    group_input_002_1.outputs[3].hide = True
	    group_input_002_1.outputs[4].hide = True
	    group_input_002_1.outputs[6].hide = True
	    group_input_002_1.outputs[7].hide = True
	    group_input_002_1.outputs[8].hide = True
	    group_input_002_1.outputs[9].hide = True
	
	    #node Object Info
	    object_info = stylized_hair.nodes.new("GeometryNodeObjectInfo")
	    object_info.name = "Object Info"
	    object_info.hide = True
	    object_info.transform_space = 'RELATIVE'
	    #As Instance
	    object_info.inputs[1].default_value = False
	
	    #node Transform Geometry
	    transform_geometry = stylized_hair.nodes.new("GeometryNodeTransform")
	    transform_geometry.name = "Transform Geometry"
	    transform_geometry.hide = True
	    transform_geometry.mode = 'COMPONENTS'
	
	    #node Group Input.003
	    group_input_003_1 = stylized_hair.nodes.new("NodeGroupInput")
	    group_input_003_1.name = "Group Input.003"
	    group_input_003_1.outputs[0].hide = True
	    group_input_003_1.outputs[1].hide = True
	    group_input_003_1.outputs[2].hide = True
	    group_input_003_1.outputs[4].hide = True
	    group_input_003_1.outputs[5].hide = True
	    group_input_003_1.outputs[6].hide = True
	    group_input_003_1.outputs[7].hide = True
	    group_input_003_1.outputs[8].hide = True
	    group_input_003_1.outputs[9].hide = True
	
	    #node Group Input.004
	    group_input_004_1 = stylized_hair.nodes.new("NodeGroupInput")
	    group_input_004_1.name = "Group Input.004"
	    group_input_004_1.outputs[0].hide = True
	    group_input_004_1.outputs[1].hide = True
	    group_input_004_1.outputs[2].hide = True
	    group_input_004_1.outputs[3].hide = True
	    group_input_004_1.outputs[4].hide = True
	    group_input_004_1.outputs[5].hide = True
	    group_input_004_1.outputs[9].hide = True
	
	    #node Set Curve Radius
	    set_curve_radius_1 = stylized_hair.nodes.new("GeometryNodeSetCurveRadius")
	    set_curve_radius_1.name = "Set Curve Radius"
	    set_curve_radius_1.hide = True
	    #Selection
	    set_curve_radius_1.inputs[1].default_value = True
	
	    #node Reroute.001
	    reroute_001_1 = stylized_hair.nodes.new("NodeReroute")
	    reroute_001_1.name = "Reroute.001"
	    reroute_001_1.socket_idname = "NodeSocketGeometry"
	    #node Reroute.002
	    reroute_002_1 = stylized_hair.nodes.new("NodeReroute")
	    reroute_002_1.name = "Reroute.002"
	    reroute_002_1.socket_idname = "NodeSocketGeometry"
	    #node Resample Curve
	    resample_curve_1 = stylized_hair.nodes.new("GeometryNodeResampleCurve")
	    resample_curve_1.name = "Resample Curve"
	    resample_curve_1.hide = True
	    resample_curve_1.keep_last_segment = False
	    resample_curve_1.mode = 'COUNT'
	    #Selection
	    resample_curve_1.inputs[1].default_value = True
	
	    #node Switch
	    switch_1 = stylized_hair.nodes.new("GeometryNodeSwitch")
	    switch_1.name = "Switch"
	    switch_1.hide = True
	    switch_1.input_type = 'GEOMETRY'
	
	    #node Compare
	    compare_1 = stylized_hair.nodes.new("FunctionNodeCompare")
	    compare_1.name = "Compare"
	    compare_1.hide = True
	    compare_1.data_type = 'INT'
	    compare_1.mode = 'ELEMENT'
	    compare_1.operation = 'LESS_THAN'
	    #B_INT
	    compare_1.inputs[3].default_value = 2
	
	    #node Reroute.005
	    reroute_005 = stylized_hair.nodes.new("NodeReroute")
	    reroute_005.name = "Reroute.005"
	    reroute_005.socket_idname = "NodeSocketGeometry"
	    #node Group Input.005
	    group_input_005 = stylized_hair.nodes.new("NodeGroupInput")
	    group_input_005.name = "Group Input.005"
	    group_input_005.outputs[0].hide = True
	    group_input_005.outputs[1].hide = True
	    group_input_005.outputs[2].hide = True
	    group_input_005.outputs[3].hide = True
	    group_input_005.outputs[5].hide = True
	    group_input_005.outputs[6].hide = True
	    group_input_005.outputs[7].hide = True
	    group_input_005.outputs[8].hide = True
	    group_input_005.outputs[9].hide = True
	
	
	
	
	
	    #Set locations
	    group_input_1.location = (-340.0, -125.68765258789062)
	    group_output_1.location = (1046.0562744140625, -35.87745666503906)
	    curve_to_mesh_1.location = (546.74853515625, -108.79241180419922)
	    capture_attribute_1.location = (361.8101501464844, -82.63687133789062)
	    spline_parameter_1.location = (156.93017578125, -142.56178283691406)
	    combine_xyz_1.location = (546.5570068359375, -195.67379760742188)
	    store_named_attribute_1.location = (712.5771484375, -27.647676467895508)
	    set_material_1.location = (873.80419921875, -61.86378860473633)
	    capture_attribute_002_1.location = (363.9737243652344, -168.7198028564453)
	    reroute_1.location = (319.04217529296875, -141.52703857421875)
	    group_input_001_1.location = (870.8699951171875, -92.72925567626953)
	    group_input_002_1.location = (542.2694702148438, -137.2887725830078)
	    object_info.location = (-173.28436279296875, -181.30752563476562)
	    transform_geometry.location = (156.43304443359375, -206.8249053955078)
	    group_input_003_1.location = (-339.0907897949219, -62.643611907958984)
	    group_input_004_1.location = (-338.4869689941406, -211.2111053466797)
	    set_curve_radius_1.location = (158.24813842773438, -76.21592712402344)
	    reroute_001_1.location = (-164.16294860839844, -159.83448791503906)
	    reroute_002_1.location = (-164.90399169921875, -71.62743377685547)
	    resample_curve_1.location = (-36.965057373046875, -67.16246032714844)
	    switch_1.location = (-37.0408821105957, -32.16990661621094)
	    compare_1.location = (-40.26144027709961, 2.388460159301758)
	    reroute_005.location = (-130.80706787109375, -71.2057876586914)
	    group_input_005.location = (-338.4869689941406, -2.108567237854004)
	
	    #Set dimensions
	    group_input_1.width, group_input_1.height = 140.0, 100.0
	    group_output_1.width, group_output_1.height = 140.0, 100.0
	    curve_to_mesh_1.width, curve_to_mesh_1.height = 140.0, 100.0
	    capture_attribute_1.width, capture_attribute_1.height = 140.0, 100.0
	    spline_parameter_1.width, spline_parameter_1.height = 140.0, 100.0
	    combine_xyz_1.width, combine_xyz_1.height = 140.0, 100.0
	    store_named_attribute_1.width, store_named_attribute_1.height = 140.0, 100.0
	    set_material_1.width, set_material_1.height = 140.0, 100.0
	    capture_attribute_002_1.width, capture_attribute_002_1.height = 140.0, 100.0
	    reroute_1.width, reroute_1.height = 100.0, 100.0
	    group_input_001_1.width, group_input_001_1.height = 140.0, 100.0
	    group_input_002_1.width, group_input_002_1.height = 140.0, 100.0
	    object_info.width, object_info.height = 140.0, 100.0
	    transform_geometry.width, transform_geometry.height = 140.0, 100.0
	    group_input_003_1.width, group_input_003_1.height = 140.0, 100.0
	    group_input_004_1.width, group_input_004_1.height = 140.0, 100.0
	    set_curve_radius_1.width, set_curve_radius_1.height = 140.0, 100.0
	    reroute_001_1.width, reroute_001_1.height = 100.0, 100.0
	    reroute_002_1.width, reroute_002_1.height = 100.0, 100.0
	    resample_curve_1.width, resample_curve_1.height = 140.0, 100.0
	    switch_1.width, switch_1.height = 140.0, 100.0
	    compare_1.width, compare_1.height = 140.0, 100.0
	    reroute_005.width, reroute_005.height = 100.0, 100.0
	    group_input_005.width, group_input_005.height = 140.0, 100.0
	
	    #initialize stylized_hair links
	    #set_material_1.Geometry -> group_output_1.Geometry
	    stylized_hair.links.new(set_material_1.outputs[0], group_output_1.inputs[0])
	    #capture_attribute_1.Geometry -> curve_to_mesh_1.Curve
	    stylized_hair.links.new(capture_attribute_1.outputs[0], curve_to_mesh_1.inputs[0])
	    #set_curve_radius_1.Curve -> capture_attribute_1.Geometry
	    stylized_hair.links.new(set_curve_radius_1.outputs[0], capture_attribute_1.inputs[0])
	    #reroute_1.Output -> capture_attribute_1.Factor
	    stylized_hair.links.new(reroute_1.outputs[0], capture_attribute_1.inputs[1])
	    #capture_attribute_1.Factor -> combine_xyz_1.X
	    stylized_hair.links.new(capture_attribute_1.outputs[1], combine_xyz_1.inputs[0])
	    #curve_to_mesh_1.Mesh -> store_named_attribute_1.Geometry
	    stylized_hair.links.new(curve_to_mesh_1.outputs[0], store_named_attribute_1.inputs[0])
	    #combine_xyz_1.Vector -> store_named_attribute_1.Value
	    stylized_hair.links.new(combine_xyz_1.outputs[0], store_named_attribute_1.inputs[3])
	    #store_named_attribute_1.Geometry -> set_material_1.Geometry
	    stylized_hair.links.new(store_named_attribute_1.outputs[0], set_material_1.inputs[0])
	    #reroute_1.Output -> capture_attribute_002_1.Factor
	    stylized_hair.links.new(reroute_1.outputs[0], capture_attribute_002_1.inputs[1])
	    #capture_attribute_002_1.Factor -> combine_xyz_1.Y
	    stylized_hair.links.new(capture_attribute_002_1.outputs[1], combine_xyz_1.inputs[1])
	    #capture_attribute_002_1.Geometry -> curve_to_mesh_1.Profile Curve
	    stylized_hair.links.new(capture_attribute_002_1.outputs[0], curve_to_mesh_1.inputs[1])
	    #spline_parameter_1.Factor -> reroute_1.Input
	    stylized_hair.links.new(spline_parameter_1.outputs[0], reroute_1.inputs[0])
	    #group_input_001_1.Material -> set_material_1.Material
	    stylized_hair.links.new(group_input_001_1.outputs[2], set_material_1.inputs[2])
	    #group_input_002_1.Fill Caps -> curve_to_mesh_1.Fill Caps
	    stylized_hair.links.new(group_input_002_1.outputs[5], curve_to_mesh_1.inputs[2])
	    #group_input_1.Profile -> object_info.Object
	    stylized_hair.links.new(group_input_1.outputs[1], object_info.inputs[0])
	    #object_info.Geometry -> transform_geometry.Geometry
	    stylized_hair.links.new(object_info.outputs[4], transform_geometry.inputs[0])
	    #transform_geometry.Geometry -> capture_attribute_002_1.Geometry
	    stylized_hair.links.new(transform_geometry.outputs[0], capture_attribute_002_1.inputs[0])
	    #group_input_003_1.Curve Radius -> set_curve_radius_1.Radius
	    stylized_hair.links.new(group_input_003_1.outputs[3], set_curve_radius_1.inputs[2])
	    #group_input_004_1.Translation -> transform_geometry.Translation
	    stylized_hair.links.new(group_input_004_1.outputs[6], transform_geometry.inputs[1])
	    #group_input_004_1.Rotation -> transform_geometry.Rotation
	    stylized_hair.links.new(group_input_004_1.outputs[7], transform_geometry.inputs[2])
	    #group_input_004_1.Scale -> transform_geometry.Scale
	    stylized_hair.links.new(group_input_004_1.outputs[8], transform_geometry.inputs[3])
	    #group_input_1.Geometry -> reroute_001_1.Input
	    stylized_hair.links.new(group_input_1.outputs[0], reroute_001_1.inputs[0])
	    #reroute_001_1.Output -> reroute_002_1.Input
	    stylized_hair.links.new(reroute_001_1.outputs[0], reroute_002_1.inputs[0])
	    #reroute_005.Output -> resample_curve_1.Curve
	    stylized_hair.links.new(reroute_005.outputs[0], resample_curve_1.inputs[0])
	    #compare_1.Result -> switch_1.Switch
	    stylized_hair.links.new(compare_1.outputs[0], switch_1.inputs[0])
	    #reroute_005.Output -> switch_1.True
	    stylized_hair.links.new(reroute_005.outputs[0], switch_1.inputs[2])
	    #resample_curve_1.Curve -> switch_1.False
	    stylized_hair.links.new(resample_curve_1.outputs[0], switch_1.inputs[1])
	    #group_input_005.Resolution -> resample_curve_1.Count
	    stylized_hair.links.new(group_input_005.outputs[4], resample_curve_1.inputs[2])
	    #group_input_005.Resolution -> compare_1.A
	    stylized_hair.links.new(group_input_005.outputs[4], compare_1.inputs[2])
	    #switch_1.Output -> set_curve_radius_1.Curve
	    stylized_hair.links.new(switch_1.outputs[0], set_curve_radius_1.inputs[0])
	    #reroute_002_1.Output -> reroute_005.Input
	    stylized_hair.links.new(reroute_002_1.outputs[0], reroute_005.inputs[0])
	    return stylized_hair
	
	stylized_hair = stylized_hair_node_group()
	
	#initialize tube_mesh node group
	def tube_mesh_node_group():
	    tube_mesh = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Tube_Mesh")
	
	    tube_mesh.color_tag = 'NONE'
	    tube_mesh.description = ""
	    tube_mesh.default_group_node_width = 140
	    
	
	    tube_mesh.is_modifier = True
	
	    #tube_mesh interface
	    #Socket Geometry
	    geometry_socket_4 = tube_mesh.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_4.attribute_domain = 'POINT'
	
	    #Socket Geometry
	    geometry_socket_5 = tube_mesh.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_5.attribute_domain = 'POINT'
	
	    #Socket Material
	    material_socket_2 = tube_mesh.interface.new_socket(name = "Material", in_out='INPUT', socket_type = 'NodeSocketMaterial')
	    material_socket_2.attribute_domain = 'POINT'
	
	    #Socket Curve Radius
	    curve_radius_socket_2 = tube_mesh.interface.new_socket(name = "Curve Radius", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    curve_radius_socket_2.default_value = 1.0
	    curve_radius_socket_2.min_value = 0.0
	    curve_radius_socket_2.max_value = 3.4028234663852886e+38
	    curve_radius_socket_2.subtype = 'DISTANCE'
	    curve_radius_socket_2.attribute_domain = 'POINT'
	    curve_radius_socket_2.hide_value = True
	    curve_radius_socket_2.hide_in_modifier = True
	
	    #Socket Resolution
	    resolution_socket_2 = tube_mesh.interface.new_socket(name = "Resolution", in_out='INPUT', socket_type = 'NodeSocketInt')
	    resolution_socket_2.default_value = 32
	    resolution_socket_2.min_value = 3
	    resolution_socket_2.max_value = 512
	    resolution_socket_2.subtype = 'NONE'
	    resolution_socket_2.attribute_domain = 'POINT'
	
	    #Socket Width
	    width_socket_1 = tube_mesh.interface.new_socket(name = "Width", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    width_socket_1.default_value = 0.10000000149011612
	    width_socket_1.min_value = 0.0
	    width_socket_1.max_value = 3.4028234663852886e+38
	    width_socket_1.subtype = 'DISTANCE'
	    width_socket_1.attribute_domain = 'POINT'
	
	    #Socket Fill Caps
	    fill_caps_socket_1 = tube_mesh.interface.new_socket(name = "Fill Caps", in_out='INPUT', socket_type = 'NodeSocketBool')
	    fill_caps_socket_1.default_value = True
	    fill_caps_socket_1.attribute_domain = 'POINT'
	
	
	    #initialize tube_mesh nodes
	    #node Group Input
	    group_input_2 = tube_mesh.nodes.new("NodeGroupInput")
	    group_input_2.name = "Group Input"
	    group_input_2.outputs[1].hide = True
	    group_input_2.outputs[2].hide = True
	    group_input_2.outputs[5].hide = True
	    group_input_2.outputs[6].hide = True
	
	    #node Group Output
	    group_output_2 = tube_mesh.nodes.new("NodeGroupOutput")
	    group_output_2.name = "Group Output"
	    group_output_2.is_active_output = True
	
	    #node Curve to Mesh
	    curve_to_mesh_2 = tube_mesh.nodes.new("GeometryNodeCurveToMesh")
	    curve_to_mesh_2.name = "Curve to Mesh"
	    curve_to_mesh_2.hide = True
	
	    #node Capture Attribute
	    capture_attribute_2 = tube_mesh.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_2.name = "Capture Attribute"
	    capture_attribute_2.hide = True
	    capture_attribute_2.active_index = 0
	    capture_attribute_2.capture_items.clear()
	    capture_attribute_2.capture_items.new('FLOAT', "Factor")
	    capture_attribute_2.capture_items["Factor"].data_type = 'FLOAT'
	    capture_attribute_2.domain = 'POINT'
	
	    #node Spline Parameter
	    spline_parameter_2 = tube_mesh.nodes.new("GeometryNodeSplineParameter")
	    spline_parameter_2.name = "Spline Parameter"
	    spline_parameter_2.hide = True
	
	    #node Combine XYZ
	    combine_xyz_2 = tube_mesh.nodes.new("ShaderNodeCombineXYZ")
	    combine_xyz_2.name = "Combine XYZ"
	    combine_xyz_2.hide = True
	    #Z
	    combine_xyz_2.inputs[2].default_value = 0.0
	
	    #node Store Named Attribute
	    store_named_attribute_2 = tube_mesh.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_2.name = "Store Named Attribute"
	    store_named_attribute_2.data_type = 'FLOAT2'
	    store_named_attribute_2.domain = 'CORNER'
	    #Selection
	    store_named_attribute_2.inputs[1].default_value = True
	    #Name
	    store_named_attribute_2.inputs[2].default_value = "tube_mesh_UV"
	
	    #node Set Material
	    set_material_2 = tube_mesh.nodes.new("GeometryNodeSetMaterial")
	    set_material_2.name = "Set Material"
	    set_material_2.hide = True
	    #Selection
	    set_material_2.inputs[1].default_value = True
	
	    #node Curve Circle
	    curve_circle = tube_mesh.nodes.new("GeometryNodeCurvePrimitiveCircle")
	    curve_circle.name = "Curve Circle"
	    curve_circle.hide = True
	    curve_circle.mode = 'RADIUS'
	    #Resolution
	    curve_circle.inputs[0].default_value = 16
	
	    #node Capture Attribute.002
	    capture_attribute_002_2 = tube_mesh.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_002_2.name = "Capture Attribute.002"
	    capture_attribute_002_2.hide = True
	    capture_attribute_002_2.active_index = 0
	    capture_attribute_002_2.capture_items.clear()
	    capture_attribute_002_2.capture_items.new('FLOAT', "Factor")
	    capture_attribute_002_2.capture_items["Factor"].data_type = 'FLOAT'
	    capture_attribute_002_2.domain = 'POINT'
	
	    #node Reroute
	    reroute_2 = tube_mesh.nodes.new("NodeReroute")
	    reroute_2.name = "Reroute"
	    reroute_2.socket_idname = "NodeSocketFloat"
	    #node Group Input.001
	    group_input_001_2 = tube_mesh.nodes.new("NodeGroupInput")
	    group_input_001_2.name = "Group Input.001"
	    group_input_001_2.outputs[0].hide = True
	    group_input_001_2.outputs[2].hide = True
	    group_input_001_2.outputs[3].hide = True
	    group_input_001_2.outputs[4].hide = True
	    group_input_001_2.outputs[5].hide = True
	    group_input_001_2.outputs[6].hide = True
	
	    #node Group Input.002
	    group_input_002_2 = tube_mesh.nodes.new("NodeGroupInput")
	    group_input_002_2.name = "Group Input.002"
	    group_input_002_2.outputs[0].hide = True
	    group_input_002_2.outputs[1].hide = True
	    group_input_002_2.outputs[2].hide = True
	    group_input_002_2.outputs[3].hide = True
	    group_input_002_2.outputs[4].hide = True
	    group_input_002_2.outputs[6].hide = True
	
	    #node Set Curve Radius
	    set_curve_radius_2 = tube_mesh.nodes.new("GeometryNodeSetCurveRadius")
	    set_curve_radius_2.name = "Set Curve Radius"
	    set_curve_radius_2.hide = True
	    #Selection
	    set_curve_radius_2.inputs[1].default_value = True
	
	    #node Group Input.003
	    group_input_003_2 = tube_mesh.nodes.new("NodeGroupInput")
	    group_input_003_2.name = "Group Input.003"
	    group_input_003_2.outputs[0].hide = True
	    group_input_003_2.outputs[1].hide = True
	    group_input_003_2.outputs[3].hide = True
	    group_input_003_2.outputs[4].hide = True
	    group_input_003_2.outputs[5].hide = True
	    group_input_003_2.outputs[6].hide = True
	
	    #node Resample Curve
	    resample_curve_2 = tube_mesh.nodes.new("GeometryNodeResampleCurve")
	    resample_curve_2.name = "Resample Curve"
	    resample_curve_2.hide = True
	    resample_curve_2.keep_last_segment = False
	    resample_curve_2.mode = 'COUNT'
	    #Selection
	    resample_curve_2.inputs[1].default_value = True
	
	    #node Switch
	    switch_2 = tube_mesh.nodes.new("GeometryNodeSwitch")
	    switch_2.name = "Switch"
	    switch_2.hide = True
	    switch_2.input_type = 'GEOMETRY'
	
	    #node Compare
	    compare_2 = tube_mesh.nodes.new("FunctionNodeCompare")
	    compare_2.name = "Compare"
	    compare_2.hide = True
	    compare_2.data_type = 'INT'
	    compare_2.mode = 'ELEMENT'
	    compare_2.operation = 'LESS_THAN'
	    #B_INT
	    compare_2.inputs[3].default_value = 2
	
	    #node Reroute.003
	    reroute_003_1 = tube_mesh.nodes.new("NodeReroute")
	    reroute_003_1.name = "Reroute.003"
	    reroute_003_1.socket_idname = "NodeSocketGeometry"
	    #node Group Input.004
	    group_input_004_2 = tube_mesh.nodes.new("NodeGroupInput")
	    group_input_004_2.name = "Group Input.004"
	    group_input_004_2.outputs[0].hide = True
	    group_input_004_2.outputs[1].hide = True
	    group_input_004_2.outputs[2].hide = True
	    group_input_004_2.outputs[4].hide = True
	    group_input_004_2.outputs[5].hide = True
	    group_input_004_2.outputs[6].hide = True
	
	    #node Reroute.006
	    reroute_006 = tube_mesh.nodes.new("NodeReroute")
	    reroute_006.name = "Reroute.006"
	    reroute_006.socket_idname = "NodeSocketFloatDistance"
	    #node Reroute.007
	    reroute_007 = tube_mesh.nodes.new("NodeReroute")
	    reroute_007.name = "Reroute.007"
	    reroute_007.socket_idname = "NodeSocketFloatDistance"
	    #node Reroute.008
	    reroute_008 = tube_mesh.nodes.new("NodeReroute")
	    reroute_008.name = "Reroute.008"
	    reroute_008.socket_idname = "NodeSocketInt"
	    #node Reroute.009
	    reroute_009 = tube_mesh.nodes.new("NodeReroute")
	    reroute_009.name = "Reroute.009"
	    reroute_009.socket_idname = "NodeSocketInt"
	
	
	
	
	    #Set locations
	    group_input_2.location = (-340.0, 0.0)
	    group_output_2.location = (953.9598388671875, 58.388336181640625)
	    curve_to_mesh_2.location = (466.6881408691406, -14.526612281799316)
	    capture_attribute_2.location = (281.749755859375, -33.53998565673828)
	    spline_parameter_2.location = (84.9455795288086, -92.41136169433594)
	    combine_xyz_2.location = (466.4966735839844, -101.40799713134766)
	    store_named_attribute_2.location = (632.5167846679688, 66.61811828613281)
	    set_material_2.location = (793.743896484375, 32.40200424194336)
	    curve_circle.location = (87.1727523803711, -56.81591033935547)
	    capture_attribute_002_2.location = (283.9133605957031, -74.45401000976562)
	    reroute_2.location = (247.05758666992188, -91.37664031982422)
	    group_input_001_2.location = (790.8096313476562, 1.5365350246429443)
	    group_input_002_2.location = (462.2091369628906, -43.022979736328125)
	    set_curve_radius_2.location = (93.72252655029297, -22.188615798950195)
	    group_input_003_2.location = (-339.80987548828125, 120.61366271972656)
	    resample_curve_2.location = (-105.32349395751953, -15.050445556640625)
	    switch_2.location = (-105.3993148803711, 19.942108154296875)
	    compare_2.location = (-108.61988830566406, 54.5004768371582)
	    reroute_003_1.location = (-169.31845092773438, -19.093738555908203)
	    group_input_004_2.location = (-340.0, 59.733726501464844)
	    reroute_006.location = (58.51203918457031, -44.47895431518555)
	    reroute_007.location = (51.51875686645508, 91.57743072509766)
	    reroute_008.location = (-135.7594451904297, -35.677268981933594)
	    reroute_009.location = (-140.79913330078125, 26.496713638305664)
	
	    #Set dimensions
	    group_input_2.width, group_input_2.height = 140.0, 100.0
	    group_output_2.width, group_output_2.height = 140.0, 100.0
	    curve_to_mesh_2.width, curve_to_mesh_2.height = 140.0, 100.0
	    capture_attribute_2.width, capture_attribute_2.height = 140.0, 100.0
	    spline_parameter_2.width, spline_parameter_2.height = 140.0, 100.0
	    combine_xyz_2.width, combine_xyz_2.height = 140.0, 100.0
	    store_named_attribute_2.width, store_named_attribute_2.height = 140.0, 100.0
	    set_material_2.width, set_material_2.height = 140.0, 100.0
	    curve_circle.width, curve_circle.height = 140.0, 100.0
	    capture_attribute_002_2.width, capture_attribute_002_2.height = 140.0, 100.0
	    reroute_2.width, reroute_2.height = 100.0, 100.0
	    group_input_001_2.width, group_input_001_2.height = 140.0, 100.0
	    group_input_002_2.width, group_input_002_2.height = 140.0, 100.0
	    set_curve_radius_2.width, set_curve_radius_2.height = 140.0, 100.0
	    group_input_003_2.width, group_input_003_2.height = 140.0, 100.0
	    resample_curve_2.width, resample_curve_2.height = 140.0, 100.0
	    switch_2.width, switch_2.height = 140.0, 100.0
	    compare_2.width, compare_2.height = 140.0, 100.0
	    reroute_003_1.width, reroute_003_1.height = 100.0, 100.0
	    group_input_004_2.width, group_input_004_2.height = 140.0, 100.0
	    reroute_006.width, reroute_006.height = 100.0, 100.0
	    reroute_007.width, reroute_007.height = 100.0, 100.0
	    reroute_008.width, reroute_008.height = 100.0, 100.0
	    reroute_009.width, reroute_009.height = 100.0, 100.0
	
	    #initialize tube_mesh links
	    #set_material_2.Geometry -> group_output_2.Geometry
	    tube_mesh.links.new(set_material_2.outputs[0], group_output_2.inputs[0])
	    #capture_attribute_2.Geometry -> curve_to_mesh_2.Curve
	    tube_mesh.links.new(capture_attribute_2.outputs[0], curve_to_mesh_2.inputs[0])
	    #set_curve_radius_2.Curve -> capture_attribute_2.Geometry
	    tube_mesh.links.new(set_curve_radius_2.outputs[0], capture_attribute_2.inputs[0])
	    #reroute_2.Output -> capture_attribute_2.Factor
	    tube_mesh.links.new(reroute_2.outputs[0], capture_attribute_2.inputs[1])
	    #capture_attribute_2.Factor -> combine_xyz_2.X
	    tube_mesh.links.new(capture_attribute_2.outputs[1], combine_xyz_2.inputs[0])
	    #curve_to_mesh_2.Mesh -> store_named_attribute_2.Geometry
	    tube_mesh.links.new(curve_to_mesh_2.outputs[0], store_named_attribute_2.inputs[0])
	    #combine_xyz_2.Vector -> store_named_attribute_2.Value
	    tube_mesh.links.new(combine_xyz_2.outputs[0], store_named_attribute_2.inputs[3])
	    #store_named_attribute_2.Geometry -> set_material_2.Geometry
	    tube_mesh.links.new(store_named_attribute_2.outputs[0], set_material_2.inputs[0])
	    #curve_circle.Curve -> capture_attribute_002_2.Geometry
	    tube_mesh.links.new(curve_circle.outputs[0], capture_attribute_002_2.inputs[0])
	    #reroute_2.Output -> capture_attribute_002_2.Factor
	    tube_mesh.links.new(reroute_2.outputs[0], capture_attribute_002_2.inputs[1])
	    #capture_attribute_002_2.Factor -> combine_xyz_2.Y
	    tube_mesh.links.new(capture_attribute_002_2.outputs[1], combine_xyz_2.inputs[1])
	    #capture_attribute_002_2.Geometry -> curve_to_mesh_2.Profile Curve
	    tube_mesh.links.new(capture_attribute_002_2.outputs[0], curve_to_mesh_2.inputs[1])
	    #group_input_2.Width -> curve_circle.Radius
	    tube_mesh.links.new(group_input_2.outputs[4], curve_circle.inputs[4])
	    #spline_parameter_2.Factor -> reroute_2.Input
	    tube_mesh.links.new(spline_parameter_2.outputs[0], reroute_2.inputs[0])
	    #group_input_001_2.Material -> set_material_2.Material
	    tube_mesh.links.new(group_input_001_2.outputs[1], set_material_2.inputs[2])
	    #group_input_002_2.Fill Caps -> curve_to_mesh_2.Fill Caps
	    tube_mesh.links.new(group_input_002_2.outputs[5], curve_to_mesh_2.inputs[2])
	    #reroute_006.Output -> set_curve_radius_2.Radius
	    tube_mesh.links.new(reroute_006.outputs[0], set_curve_radius_2.inputs[2])
	    #reroute_003_1.Output -> resample_curve_2.Curve
	    tube_mesh.links.new(reroute_003_1.outputs[0], resample_curve_2.inputs[0])
	    #compare_2.Result -> switch_2.Switch
	    tube_mesh.links.new(compare_2.outputs[0], switch_2.inputs[0])
	    #reroute_003_1.Output -> switch_2.True
	    tube_mesh.links.new(reroute_003_1.outputs[0], switch_2.inputs[2])
	    #resample_curve_2.Curve -> switch_2.False
	    tube_mesh.links.new(resample_curve_2.outputs[0], switch_2.inputs[1])
	    #reroute_008.Output -> resample_curve_2.Count
	    tube_mesh.links.new(reroute_008.outputs[0], resample_curve_2.inputs[2])
	    #group_input_2.Geometry -> reroute_003_1.Input
	    tube_mesh.links.new(group_input_2.outputs[0], reroute_003_1.inputs[0])
	    #reroute_007.Output -> reroute_006.Input
	    tube_mesh.links.new(reroute_007.outputs[0], reroute_006.inputs[0])
	    #group_input_003_2.Curve Radius -> reroute_007.Input
	    tube_mesh.links.new(group_input_003_2.outputs[2], reroute_007.inputs[0])
	    #reroute_009.Output -> reroute_008.Input
	    tube_mesh.links.new(reroute_009.outputs[0], reroute_008.inputs[0])
	    #group_input_004_2.Resolution -> reroute_009.Input
	    tube_mesh.links.new(group_input_004_2.outputs[3], reroute_009.inputs[0])
	    #reroute_009.Output -> compare_2.A
	    tube_mesh.links.new(reroute_009.outputs[0], compare_2.inputs[2])
	    #switch_2.Output -> set_curve_radius_2.Curve
	    tube_mesh.links.new(switch_2.outputs[0], set_curve_radius_2.inputs[0])
	    return tube_mesh
	
	tube_mesh = tube_mesh_node_group()
	
	#initialize tube_ribbon node group
	def tube_ribbon_node_group():
	    tube_ribbon = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Tube_Ribbon")
	
	    tube_ribbon.color_tag = 'NONE'
	    tube_ribbon.description = ""
	    tube_ribbon.default_group_node_width = 140
	    
	
	    tube_ribbon.is_modifier = True
	
	    #tube_ribbon interface
	    #Socket Geometry
	    geometry_socket_6 = tube_ribbon.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_6.attribute_domain = 'POINT'
	
	    #Socket Geometry
	    geometry_socket_7 = tube_ribbon.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_7.attribute_domain = 'POINT'
	
	    #Socket Material
	    material_socket_3 = tube_ribbon.interface.new_socket(name = "Material", in_out='INPUT', socket_type = 'NodeSocketMaterial')
	    material_socket_3.attribute_domain = 'POINT'
	
	    #Socket Curve Radius
	    curve_radius_socket_3 = tube_ribbon.interface.new_socket(name = "Curve Radius", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    curve_radius_socket_3.default_value = 1.0
	    curve_radius_socket_3.min_value = 0.0
	    curve_radius_socket_3.max_value = 3.4028234663852886e+38
	    curve_radius_socket_3.subtype = 'DISTANCE'
	    curve_radius_socket_3.attribute_domain = 'POINT'
	    curve_radius_socket_3.hide_value = True
	    curve_radius_socket_3.hide_in_modifier = True
	
	    #Socket Ribbon Count
	    ribbon_count_socket = tube_ribbon.interface.new_socket(name = "Ribbon Count", in_out='INPUT', socket_type = 'NodeSocketInt')
	    ribbon_count_socket.default_value = 8
	    ribbon_count_socket.min_value = 1
	    ribbon_count_socket.max_value = 180
	    ribbon_count_socket.subtype = 'NONE'
	    ribbon_count_socket.attribute_domain = 'POINT'
	
	    #Socket Resolution
	    resolution_socket_3 = tube_ribbon.interface.new_socket(name = "Resolution", in_out='INPUT', socket_type = 'NodeSocketInt')
	    resolution_socket_3.default_value = 0
	    resolution_socket_3.min_value = 2
	    resolution_socket_3.max_value = 512
	    resolution_socket_3.subtype = 'NONE'
	    resolution_socket_3.attribute_domain = 'POINT'
	
	    #Socket Width
	    width_socket_2 = tube_ribbon.interface.new_socket(name = "Width", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    width_socket_2.default_value = 0.10000000149011612
	    width_socket_2.min_value = 0.0
	    width_socket_2.max_value = 3.4028234663852886e+38
	    width_socket_2.subtype = 'DISTANCE'
	    width_socket_2.attribute_domain = 'POINT'
	
	
	    #initialize tube_ribbon nodes
	    #node Group Input
	    group_input_3 = tube_ribbon.nodes.new("NodeGroupInput")
	    group_input_3.name = "Group Input"
	    group_input_3.outputs[1].hide = True
	    group_input_3.outputs[2].hide = True
	    group_input_3.outputs[3].hide = True
	    group_input_3.outputs[6].hide = True
	
	    #node Group Output
	    group_output_3 = tube_ribbon.nodes.new("NodeGroupOutput")
	    group_output_3.name = "Group Output"
	    group_output_3.is_active_output = True
	
	    #node Curve to Mesh
	    curve_to_mesh_3 = tube_ribbon.nodes.new("GeometryNodeCurveToMesh")
	    curve_to_mesh_3.name = "Curve to Mesh"
	    curve_to_mesh_3.hide = True
	    #Fill Caps
	    curve_to_mesh_3.inputs[2].default_value = True
	
	    #node Capture Attribute
	    capture_attribute_3 = tube_ribbon.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_3.name = "Capture Attribute"
	    capture_attribute_3.hide = True
	    capture_attribute_3.active_index = 0
	    capture_attribute_3.capture_items.clear()
	    capture_attribute_3.capture_items.new('FLOAT', "Factor")
	    capture_attribute_3.capture_items["Factor"].data_type = 'FLOAT'
	    capture_attribute_3.domain = 'POINT'
	
	    #node Spline Parameter
	    spline_parameter_3 = tube_ribbon.nodes.new("GeometryNodeSplineParameter")
	    spline_parameter_3.name = "Spline Parameter"
	    spline_parameter_3.hide = True
	
	    #node Combine XYZ
	    combine_xyz_3 = tube_ribbon.nodes.new("ShaderNodeCombineXYZ")
	    combine_xyz_3.name = "Combine XYZ"
	    combine_xyz_3.hide = True
	    #Z
	    combine_xyz_3.inputs[2].default_value = 0.0
	
	    #node Store Named Attribute
	    store_named_attribute_3 = tube_ribbon.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_3.name = "Store Named Attribute"
	    store_named_attribute_3.data_type = 'FLOAT2'
	    store_named_attribute_3.domain = 'CORNER'
	    #Selection
	    store_named_attribute_3.inputs[1].default_value = True
	    #Name
	    store_named_attribute_3.inputs[2].default_value = "ribbon_mesh_UV"
	
	    #node Set Material
	    set_material_3 = tube_ribbon.nodes.new("GeometryNodeSetMaterial")
	    set_material_3.name = "Set Material"
	    set_material_3.hide = True
	    #Selection
	    set_material_3.inputs[1].default_value = True
	
	    #node Capture Attribute.002
	    capture_attribute_002_3 = tube_ribbon.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_002_3.name = "Capture Attribute.002"
	    capture_attribute_002_3.hide = True
	    capture_attribute_002_3.active_index = 0
	    capture_attribute_002_3.capture_items.clear()
	    capture_attribute_002_3.capture_items.new('FLOAT', "Factor")
	    capture_attribute_002_3.capture_items["Factor"].data_type = 'FLOAT'
	    capture_attribute_002_3.domain = 'POINT'
	
	    #node Reroute
	    reroute_3 = tube_ribbon.nodes.new("NodeReroute")
	    reroute_3.name = "Reroute"
	    reroute_3.socket_idname = "NodeSocketFloat"
	    #node Group Input.001
	    group_input_001_3 = tube_ribbon.nodes.new("NodeGroupInput")
	    group_input_001_3.name = "Group Input.001"
	    group_input_001_3.outputs[0].hide = True
	    group_input_001_3.outputs[2].hide = True
	    group_input_001_3.outputs[3].hide = True
	    group_input_001_3.outputs[4].hide = True
	    group_input_001_3.outputs[5].hide = True
	    group_input_001_3.outputs[6].hide = True
	
	    #node Curve Line
	    curve_line = tube_ribbon.nodes.new("GeometryNodeCurvePrimitiveLine")
	    curve_line.name = "Curve Line"
	    curve_line.hide = True
	    curve_line.mode = 'POINTS'
	
	    #node Combine XYZ.001
	    combine_xyz_001 = tube_ribbon.nodes.new("ShaderNodeCombineXYZ")
	    combine_xyz_001.name = "Combine XYZ.001"
	    combine_xyz_001.hide = True
	    #Y
	    combine_xyz_001.inputs[1].default_value = 0.0
	    #Z
	    combine_xyz_001.inputs[2].default_value = 0.0
	
	    #node Math.001
	    math_001 = tube_ribbon.nodes.new("ShaderNodeMath")
	    math_001.name = "Math.001"
	    math_001.hide = True
	    math_001.operation = 'MULTIPLY'
	    math_001.use_clamp = False
	    #Value_001
	    math_001.inputs[1].default_value = -1.0
	
	    #node Combine XYZ.002
	    combine_xyz_002 = tube_ribbon.nodes.new("ShaderNodeCombineXYZ")
	    combine_xyz_002.name = "Combine XYZ.002"
	    combine_xyz_002.hide = True
	    #Y
	    combine_xyz_002.inputs[1].default_value = 0.0
	    #Z
	    combine_xyz_002.inputs[2].default_value = 0.0
	
	    #node Reroute.001
	    reroute_001_2 = tube_ribbon.nodes.new("NodeReroute")
	    reroute_001_2.name = "Reroute.001"
	    reroute_001_2.socket_idname = "NodeSocketFloatDistance"
	    #node Resample Curve
	    resample_curve_3 = tube_ribbon.nodes.new("GeometryNodeResampleCurve")
	    resample_curve_3.name = "Resample Curve"
	    resample_curve_3.hide = True
	    resample_curve_3.keep_last_segment = False
	    resample_curve_3.mode = 'COUNT'
	    #Selection
	    resample_curve_3.inputs[1].default_value = True
	
	    #node Switch
	    switch_3 = tube_ribbon.nodes.new("GeometryNodeSwitch")
	    switch_3.name = "Switch"
	    switch_3.hide = True
	    switch_3.input_type = 'GEOMETRY'
	
	    #node Group Input.002
	    group_input_002_3 = tube_ribbon.nodes.new("NodeGroupInput")
	    group_input_002_3.name = "Group Input.002"
	    group_input_002_3.outputs[0].hide = True
	    group_input_002_3.outputs[1].hide = True
	    group_input_002_3.outputs[2].hide = True
	    group_input_002_3.outputs[3].hide = True
	    group_input_002_3.outputs[5].hide = True
	    group_input_002_3.outputs[6].hide = True
	
	    #node Compare
	    compare_3 = tube_ribbon.nodes.new("FunctionNodeCompare")
	    compare_3.name = "Compare"
	    compare_3.hide = True
	    compare_3.data_type = 'INT'
	    compare_3.mode = 'ELEMENT'
	    compare_3.operation = 'LESS_THAN'
	    #B_INT
	    compare_3.inputs[3].default_value = 2
	
	    #node Reroute.002
	    reroute_002_2 = tube_ribbon.nodes.new("NodeReroute")
	    reroute_002_2.name = "Reroute.002"
	    reroute_002_2.socket_idname = "NodeSocketGeometry"
	    #node Frame
	    frame = tube_ribbon.nodes.new("NodeFrame")
	    frame.name = "Frame"
	    frame.label_size = 20
	    frame.shrink = True
	
	    #node Join Geometry
	    join_geometry_1 = tube_ribbon.nodes.new("GeometryNodeJoinGeometry")
	    join_geometry_1.name = "Join Geometry"
	
	    #node Set Curve Tilt
	    set_curve_tilt = tube_ribbon.nodes.new("GeometryNodeSetCurveTilt")
	    set_curve_tilt.name = "Set Curve Tilt"
	    #Selection
	    set_curve_tilt.inputs[1].default_value = True
	
	    #node Repeat Input
	    repeat_input = tube_ribbon.nodes.new("GeometryNodeRepeatInput")
	    repeat_input.name = "Repeat Input"
	    #node Repeat Output
	    repeat_output = tube_ribbon.nodes.new("GeometryNodeRepeatOutput")
	    repeat_output.name = "Repeat Output"
	    repeat_output.active_index = 1
	    repeat_output.inspection_index = 0
	    repeat_output.repeat_items.clear()
	    # Create item "Geometry"
	    repeat_output.repeat_items.new('GEOMETRY', "Geometry")
	    # Create item "Index"
	    repeat_output.repeat_items.new('INT', "Index")
	
	    #node Math.002
	    math_002 = tube_ribbon.nodes.new("ShaderNodeMath")
	    math_002.name = "Math.002"
	    math_002.hide = True
	    math_002.operation = 'DIVIDE'
	    math_002.use_clamp = False
	    #Value
	    math_002.inputs[0].default_value = 180.0
	
	    #node Group Input.003
	    group_input_003_3 = tube_ribbon.nodes.new("NodeGroupInput")
	    group_input_003_3.name = "Group Input.003"
	    group_input_003_3.outputs[0].hide = True
	    group_input_003_3.outputs[1].hide = True
	    group_input_003_3.outputs[2].hide = True
	    group_input_003_3.outputs[4].hide = True
	    group_input_003_3.outputs[5].hide = True
	    group_input_003_3.outputs[6].hide = True
	
	    #node Group Input.004
	    group_input_004_3 = tube_ribbon.nodes.new("NodeGroupInput")
	    group_input_004_3.name = "Group Input.004"
	    group_input_004_3.outputs[0].hide = True
	    group_input_004_3.outputs[1].hide = True
	    group_input_004_3.outputs[2].hide = True
	    group_input_004_3.outputs[4].hide = True
	    group_input_004_3.outputs[5].hide = True
	    group_input_004_3.outputs[6].hide = True
	
	    #node Math.003
	    math_003 = tube_ribbon.nodes.new("ShaderNodeMath")
	    math_003.name = "Math.003"
	    math_003.hide = True
	    math_003.operation = 'ADD'
	    math_003.use_clamp = False
	    #Value_001
	    math_003.inputs[1].default_value = 1.0
	
	    #node Math.004
	    math_004 = tube_ribbon.nodes.new("ShaderNodeMath")
	    math_004.name = "Math.004"
	    math_004.hide = True
	    math_004.operation = 'MULTIPLY'
	    math_004.use_clamp = False
	
	    #node Reroute.003
	    reroute_003_2 = tube_ribbon.nodes.new("NodeReroute")
	    reroute_003_2.name = "Reroute.003"
	    reroute_003_2.socket_idname = "NodeSocketInt"
	    #node Curve Tilt
	    curve_tilt = tube_ribbon.nodes.new("GeometryNodeInputCurveTilt")
	    curve_tilt.name = "Curve Tilt"
	    curve_tilt.hide = True
	
	    #node Math.005
	    math_005 = tube_ribbon.nodes.new("ShaderNodeMath")
	    math_005.name = "Math.005"
	    math_005.hide = True
	    math_005.operation = 'ADD'
	    math_005.use_clamp = False
	
	    #node Set Curve Radius
	    set_curve_radius_3 = tube_ribbon.nodes.new("GeometryNodeSetCurveRadius")
	    set_curve_radius_3.name = "Set Curve Radius"
	    set_curve_radius_3.hide = True
	    #Selection
	    set_curve_radius_3.inputs[1].default_value = True
	
	    #node Group Input.005
	    group_input_005_1 = tube_ribbon.nodes.new("NodeGroupInput")
	    group_input_005_1.name = "Group Input.005"
	    group_input_005_1.outputs[0].hide = True
	    group_input_005_1.outputs[1].hide = True
	    group_input_005_1.outputs[3].hide = True
	    group_input_005_1.outputs[4].hide = True
	    group_input_005_1.outputs[5].hide = True
	    group_input_005_1.outputs[6].hide = True
	
	    #node Reroute.004
	    reroute_004_1 = tube_ribbon.nodes.new("NodeReroute")
	    reroute_004_1.name = "Reroute.004"
	    reroute_004_1.socket_idname = "NodeSocketFloatDistance"
	    #node Reroute.005
	    reroute_005_1 = tube_ribbon.nodes.new("NodeReroute")
	    reroute_005_1.name = "Reroute.005"
	    reroute_005_1.socket_idname = "NodeSocketFloatDistance"
	
	    #Process zone input Repeat Input
	    repeat_input.pair_with_output(repeat_output)
	    #Item_2
	    repeat_input.inputs[2].default_value = 0
	
	
	
	
	    #Set parents
	    group_input_3.parent = frame
	    curve_to_mesh_3.parent = frame
	    capture_attribute_3.parent = frame
	    spline_parameter_3.parent = frame
	    combine_xyz_3.parent = frame
	    store_named_attribute_3.parent = frame
	    set_material_3.parent = frame
	    capture_attribute_002_3.parent = frame
	    reroute_3.parent = frame
	    group_input_001_3.parent = frame
	    curve_line.parent = frame
	    combine_xyz_001.parent = frame
	    math_001.parent = frame
	    combine_xyz_002.parent = frame
	    reroute_001_2.parent = frame
	    resample_curve_3.parent = frame
	    switch_3.parent = frame
	    group_input_002_3.parent = frame
	    compare_3.parent = frame
	    reroute_002_2.parent = frame
	    set_curve_tilt.parent = frame
	    math_004.parent = frame
	    math_005.parent = frame
	    set_curve_radius_3.parent = frame
	    group_input_005_1.parent = frame
	    reroute_004_1.parent = frame
	    reroute_005_1.parent = frame
	
	    #Set locations
	    group_input_3.location = (46.5567626953125, -187.68907165527344)
	    group_output_3.location = (1687.6083984375, 27.941242218017578)
	    curve_to_mesh_3.location = (937.7008666992188, -218.34669494628906)
	    capture_attribute_3.location = (764.834716796875, -223.1929168701172)
	    spline_parameter_3.location = (408.7358093261719, -288.16595458984375)
	    combine_xyz_3.location = (937.5093383789062, -281.03155517578125)
	    store_named_attribute_3.location = (1093.46923828125, -121.07095336914062)
	    set_material_3.location = (1254.6962890625, -155.2870635986328)
	    capture_attribute_002_3.location = (766.9982299804688, -262.14312744140625)
	    reroute_3.location = (566.0176391601562, -285.51812744140625)
	    group_input_001_3.location = (1251.76220703125, -186.1525421142578)
	    curve_line.location = (409.7470397949219, -252.2234649658203)
	    combine_xyz_001.location = (242.35899353027344, -260.64910888671875)
	    math_001.location = (247.1505889892578, -332.52447509765625)
	    combine_xyz_002.location = (245.62991333007812, -296.69708251953125)
	    reroute_001_2.location = (199.33338928222656, -265.65771484375)
	    resample_curve_3.location = (380.4243469238281, -216.19468688964844)
	    switch_3.location = (380.3485412597656, -181.20213317871094)
	    group_input_002_3.location = (375.72821044921875, -86.50663757324219)
	    compare_3.location = (377.1279602050781, -146.6437530517578)
	    reroute_002_2.location = (333.6315612792969, -213.35231018066406)
	    frame.location = (-58.76470947265625, -48.17646789550781)
	    join_geometry_1.location = (1331.0086669921875, 47.14059066772461)
	    set_curve_tilt.location = (192.23997497558594, -54.01100158691406)
	    repeat_input.location = (-184.79876708984375, 46.944000244140625)
	    repeat_output.location = (1511.4083251953125, 27.655336380004883)
	    math_002.location = (-195.4779510498047, -161.6897735595703)
	    group_input_003_3.location = (-346.3707580566406, 47.1754035949707)
	    group_input_004_3.location = (-353.25665283203125, -145.0489044189453)
	    math_003.location = (1134.1580810546875, -24.601409912109375)
	    math_004.location = (30.277496337890625, -106.62132263183594)
	    reroute_003_2.location = (-25.963211059570312, -31.35608673095703)
	    curve_tilt.location = (-197.5312957763672, -198.6190185546875)
	    math_005.location = (31.753875732421875, -145.03323364257812)
	    set_curve_radius_3.location = (591.83837890625, -194.33396911621094)
	    group_input_005_1.location = (377.0597229003906, -29.650436401367188)
	    reroute_004_1.location = (563.5545654296875, -215.4977264404297)
	    reroute_005_1.location = (561.7288208007812, -64.61457824707031)
	
	    #Set dimensions
	    group_input_3.width, group_input_3.height = 140.0, 100.0
	    group_output_3.width, group_output_3.height = 140.0, 100.0
	    curve_to_mesh_3.width, curve_to_mesh_3.height = 140.0, 100.0
	    capture_attribute_3.width, capture_attribute_3.height = 140.0, 100.0
	    spline_parameter_3.width, spline_parameter_3.height = 140.0, 100.0
	    combine_xyz_3.width, combine_xyz_3.height = 140.0, 100.0
	    store_named_attribute_3.width, store_named_attribute_3.height = 140.0, 100.0
	    set_material_3.width, set_material_3.height = 140.0, 100.0
	    capture_attribute_002_3.width, capture_attribute_002_3.height = 140.0, 100.0
	    reroute_3.width, reroute_3.height = 100.0, 100.0
	    group_input_001_3.width, group_input_001_3.height = 140.0, 100.0
	    curve_line.width, curve_line.height = 140.0, 100.0
	    combine_xyz_001.width, combine_xyz_001.height = 140.0, 100.0
	    math_001.width, math_001.height = 140.0, 100.0
	    combine_xyz_002.width, combine_xyz_002.height = 140.0, 100.0
	    reroute_001_2.width, reroute_001_2.height = 100.0, 100.0
	    resample_curve_3.width, resample_curve_3.height = 140.0, 100.0
	    switch_3.width, switch_3.height = 140.0, 100.0
	    group_input_002_3.width, group_input_002_3.height = 140.0, 100.0
	    compare_3.width, compare_3.height = 140.0, 100.0
	    reroute_002_2.width, reroute_002_2.height = 100.0, 100.0
	    frame.width, frame.height = 1424.3529052734375, 388.32354736328125
	    join_geometry_1.width, join_geometry_1.height = 140.0, 100.0
	    set_curve_tilt.width, set_curve_tilt.height = 140.0, 100.0
	    repeat_input.width, repeat_input.height = 140.0, 100.0
	    repeat_output.width, repeat_output.height = 140.0, 100.0
	    math_002.width, math_002.height = 140.0, 100.0
	    group_input_003_3.width, group_input_003_3.height = 140.0, 100.0
	    group_input_004_3.width, group_input_004_3.height = 140.0, 100.0
	    math_003.width, math_003.height = 140.0, 100.0
	    math_004.width, math_004.height = 140.0, 100.0
	    reroute_003_2.width, reroute_003_2.height = 100.0, 100.0
	    curve_tilt.width, curve_tilt.height = 140.0, 100.0
	    math_005.width, math_005.height = 140.0, 100.0
	    set_curve_radius_3.width, set_curve_radius_3.height = 140.0, 100.0
	    group_input_005_1.width, group_input_005_1.height = 140.0, 100.0
	    reroute_004_1.width, reroute_004_1.height = 100.0, 100.0
	    reroute_005_1.width, reroute_005_1.height = 100.0, 100.0
	
	    #initialize tube_ribbon links
	    #capture_attribute_3.Geometry -> curve_to_mesh_3.Curve
	    tube_ribbon.links.new(capture_attribute_3.outputs[0], curve_to_mesh_3.inputs[0])
	    #reroute_3.Output -> capture_attribute_3.Factor
	    tube_ribbon.links.new(reroute_3.outputs[0], capture_attribute_3.inputs[1])
	    #capture_attribute_3.Factor -> combine_xyz_3.X
	    tube_ribbon.links.new(capture_attribute_3.outputs[1], combine_xyz_3.inputs[0])
	    #curve_to_mesh_3.Mesh -> store_named_attribute_3.Geometry
	    tube_ribbon.links.new(curve_to_mesh_3.outputs[0], store_named_attribute_3.inputs[0])
	    #combine_xyz_3.Vector -> store_named_attribute_3.Value
	    tube_ribbon.links.new(combine_xyz_3.outputs[0], store_named_attribute_3.inputs[3])
	    #store_named_attribute_3.Geometry -> set_material_3.Geometry
	    tube_ribbon.links.new(store_named_attribute_3.outputs[0], set_material_3.inputs[0])
	    #reroute_3.Output -> capture_attribute_002_3.Factor
	    tube_ribbon.links.new(reroute_3.outputs[0], capture_attribute_002_3.inputs[1])
	    #capture_attribute_002_3.Factor -> combine_xyz_3.Y
	    tube_ribbon.links.new(capture_attribute_002_3.outputs[1], combine_xyz_3.inputs[1])
	    #capture_attribute_002_3.Geometry -> curve_to_mesh_3.Profile Curve
	    tube_ribbon.links.new(capture_attribute_002_3.outputs[0], curve_to_mesh_3.inputs[1])
	    #spline_parameter_3.Factor -> reroute_3.Input
	    tube_ribbon.links.new(spline_parameter_3.outputs[0], reroute_3.inputs[0])
	    #group_input_001_3.Material -> set_material_3.Material
	    tube_ribbon.links.new(group_input_001_3.outputs[1], set_material_3.inputs[2])
	    #combine_xyz_001.Vector -> curve_line.Start
	    tube_ribbon.links.new(combine_xyz_001.outputs[0], curve_line.inputs[0])
	    #math_001.Value -> combine_xyz_002.X
	    tube_ribbon.links.new(math_001.outputs[0], combine_xyz_002.inputs[0])
	    #combine_xyz_002.Vector -> curve_line.End
	    tube_ribbon.links.new(combine_xyz_002.outputs[0], curve_line.inputs[1])
	    #reroute_001_2.Output -> math_001.Value
	    tube_ribbon.links.new(reroute_001_2.outputs[0], math_001.inputs[0])
	    #curve_line.Curve -> capture_attribute_002_3.Geometry
	    tube_ribbon.links.new(curve_line.outputs[0], capture_attribute_002_3.inputs[0])
	    #group_input_3.Width -> reroute_001_2.Input
	    tube_ribbon.links.new(group_input_3.outputs[5], reroute_001_2.inputs[0])
	    #reroute_002_2.Output -> resample_curve_3.Curve
	    tube_ribbon.links.new(reroute_002_2.outputs[0], resample_curve_3.inputs[0])
	    #group_input_3.Resolution -> resample_curve_3.Count
	    tube_ribbon.links.new(group_input_3.outputs[4], resample_curve_3.inputs[2])
	    #group_input_002_3.Resolution -> compare_3.A
	    tube_ribbon.links.new(group_input_002_3.outputs[4], compare_3.inputs[2])
	    #compare_3.Result -> switch_3.Switch
	    tube_ribbon.links.new(compare_3.outputs[0], switch_3.inputs[0])
	    #set_curve_radius_3.Curve -> capture_attribute_3.Geometry
	    tube_ribbon.links.new(set_curve_radius_3.outputs[0], capture_attribute_3.inputs[0])
	    #reroute_002_2.Output -> switch_3.True
	    tube_ribbon.links.new(reroute_002_2.outputs[0], switch_3.inputs[2])
	    #resample_curve_3.Curve -> switch_3.False
	    tube_ribbon.links.new(resample_curve_3.outputs[0], switch_3.inputs[1])
	    #group_input_3.Geometry -> set_curve_tilt.Curve
	    tube_ribbon.links.new(group_input_3.outputs[0], set_curve_tilt.inputs[0])
	    #set_curve_tilt.Curve -> reroute_002_2.Input
	    tube_ribbon.links.new(set_curve_tilt.outputs[0], reroute_002_2.inputs[0])
	    #join_geometry_1.Geometry -> repeat_output.Geometry
	    tube_ribbon.links.new(join_geometry_1.outputs[0], repeat_output.inputs[0])
	    #group_input_003_3.Ribbon Count -> repeat_input.Iterations
	    tube_ribbon.links.new(group_input_003_3.outputs[3], repeat_input.inputs[0])
	    #math_003.Value -> repeat_output.Index
	    tube_ribbon.links.new(math_003.outputs[0], repeat_output.inputs[1])
	    #repeat_output.Geometry -> group_output_3.Geometry
	    tube_ribbon.links.new(repeat_output.outputs[0], group_output_3.inputs[0])
	    #reroute_003_2.Output -> math_003.Value
	    tube_ribbon.links.new(reroute_003_2.outputs[0], math_003.inputs[0])
	    #group_input_004_3.Ribbon Count -> math_002.Value
	    tube_ribbon.links.new(group_input_004_3.outputs[3], math_002.inputs[1])
	    #math_002.Value -> math_004.Value
	    tube_ribbon.links.new(math_002.outputs[0], math_004.inputs[1])
	    #reroute_003_2.Output -> math_004.Value
	    tube_ribbon.links.new(reroute_003_2.outputs[0], math_004.inputs[0])
	    #repeat_input.Index -> reroute_003_2.Input
	    tube_ribbon.links.new(repeat_input.outputs[2], reroute_003_2.inputs[0])
	    #set_material_3.Geometry -> join_geometry_1.Geometry
	    tube_ribbon.links.new(set_material_3.outputs[0], join_geometry_1.inputs[0])
	    #curve_tilt.Tilt -> math_005.Value
	    tube_ribbon.links.new(curve_tilt.outputs[0], math_005.inputs[1])
	    #math_004.Value -> math_005.Value
	    tube_ribbon.links.new(math_004.outputs[0], math_005.inputs[0])
	    #math_005.Value -> set_curve_tilt.Tilt
	    tube_ribbon.links.new(math_005.outputs[0], set_curve_tilt.inputs[2])
	    #switch_3.Output -> set_curve_radius_3.Curve
	    tube_ribbon.links.new(switch_3.outputs[0], set_curve_radius_3.inputs[0])
	    #reroute_004_1.Output -> set_curve_radius_3.Radius
	    tube_ribbon.links.new(reroute_004_1.outputs[0], set_curve_radius_3.inputs[2])
	    #reroute_005_1.Output -> reroute_004_1.Input
	    tube_ribbon.links.new(reroute_005_1.outputs[0], reroute_004_1.inputs[0])
	    #group_input_005_1.Curve Radius -> reroute_005_1.Input
	    tube_ribbon.links.new(group_input_005_1.outputs[2], reroute_005_1.inputs[0])
	    #reroute_001_2.Output -> combine_xyz_001.X
	    tube_ribbon.links.new(reroute_001_2.outputs[0], combine_xyz_001.inputs[0])
	    #repeat_input.Geometry -> join_geometry_1.Geometry
	    tube_ribbon.links.new(repeat_input.outputs[1], join_geometry_1.inputs[0])
	    return tube_ribbon
	
	tube_ribbon = tube_ribbon_node_group()
	
	#initialize mesh_hair_selector node group
	def mesh_hair_selector_node_group():
	    mesh_hair_selector = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "MESH_HAIR_SELECTOR")
	
	    mesh_hair_selector.color_tag = 'NONE'
	    mesh_hair_selector.description = "Convert hair to mesh object."
	    mesh_hair_selector.default_group_node_width = 140
	    
	
	    mesh_hair_selector.is_modifier = True
	
	    #mesh_hair_selector interface
	    #Socket Geometry
	    geometry_socket_8 = mesh_hair_selector.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_8.attribute_domain = 'POINT'
	    geometry_socket_8.description = "Mesh object."
	
	    #Socket Geometry
	    geometry_socket_9 = mesh_hair_selector.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_9.attribute_domain = 'POINT'
	    geometry_socket_9.description = "Curve object"
	
	    #Socket Style Select
	    style_select_socket = mesh_hair_selector.interface.new_socket(name = "Style Select", in_out='INPUT', socket_type = 'NodeSocketMenu')
	    style_select_socket.attribute_domain = 'POINT'
	    style_select_socket.description = "Mesh style to convert curve."
	
	    #Socket Material
	    material_socket_4 = mesh_hair_selector.interface.new_socket(name = "Material", in_out='INPUT', socket_type = 'NodeSocketMaterial')
	    material_socket_4.attribute_domain = 'POINT'
	    material_socket_4.description = "Material used for mesh."
	
	    #Socket Resolution
	    resolution_socket_4 = mesh_hair_selector.interface.new_socket(name = "Resolution", in_out='INPUT', socket_type = 'NodeSocketInt')
	    resolution_socket_4.default_value = 0
	    resolution_socket_4.min_value = 2
	    resolution_socket_4.max_value = 512
	    resolution_socket_4.subtype = 'NONE'
	    resolution_socket_4.attribute_domain = 'POINT'
	    resolution_socket_4.description = "Control mesh smoothness by add and removing points along curve."
	
	    #Socket Width
	    width_socket_3 = mesh_hair_selector.interface.new_socket(name = "Width", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    width_socket_3.default_value = 0.10000000149011612
	    width_socket_3.min_value = 0.0
	    width_socket_3.max_value = 3.4028234663852886e+38
	    width_socket_3.subtype = 'DISTANCE'
	    width_socket_3.attribute_domain = 'POINT'
	    width_socket_3.description = "Width of mesh object."
	
	    #Socket Curve Radius
	    curve_radius_socket_4 = mesh_hair_selector.interface.new_socket(name = "Curve Radius", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    curve_radius_socket_4.default_value = 0.0
	    curve_radius_socket_4.min_value = 0.0
	    curve_radius_socket_4.max_value = 0.0
	    curve_radius_socket_4.subtype = 'DISTANCE'
	    curve_radius_socket_4.attribute_domain = 'POINT'
	    curve_radius_socket_4.hide_value = True
	    curve_radius_socket_4.hide_in_modifier = True
	    curve_radius_socket_4.description = "Overall mesh shape float curve."
	
	    #Socket Fill Caps
	    fill_caps_socket_2 = mesh_hair_selector.interface.new_socket(name = "Fill Caps", in_out='INPUT', socket_type = 'NodeSocketBool')
	    fill_caps_socket_2.default_value = False
	    fill_caps_socket_2.attribute_domain = 'POINT'
	    fill_caps_socket_2.description = "Fill openings with mesh surface. (Used only for [Tube Mesh | Stylized] mesh styles)"
	
	    #Socket Shade Smooth
	    shade_smooth_socket = mesh_hair_selector.interface.new_socket(name = "Shade Smooth", in_out='INPUT', socket_type = 'NodeSocketBool')
	    shade_smooth_socket.default_value = False
	    shade_smooth_socket.attribute_domain = 'POINT'
	    shade_smooth_socket.description = "Use Smooth Shade for mesh."
	
	    #Socket Hair Card Angle
	    hair_card_angle_socket = mesh_hair_selector.interface.new_socket(name = "Hair Card Angle", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    hair_card_angle_socket.default_value = 0.0
	    hair_card_angle_socket.min_value = -90.0
	    hair_card_angle_socket.max_value = 90.0
	    hair_card_angle_socket.subtype = 'ANGLE'
	    hair_card_angle_socket.attribute_domain = 'POINT'
	    hair_card_angle_socket.description = "Angle used to bend hair card. (Mesh Style=Hair Card)"
	
	    #Socket Tube Ribbon Count
	    tube_ribbon_count_socket = mesh_hair_selector.interface.new_socket(name = "Tube Ribbon Count", in_out='INPUT', socket_type = 'NodeSocketInt')
	    tube_ribbon_count_socket.default_value = 8
	    tube_ribbon_count_socket.min_value = 1
	    tube_ribbon_count_socket.max_value = 180
	    tube_ribbon_count_socket.subtype = 'NONE'
	    tube_ribbon_count_socket.attribute_domain = 'POINT'
	    tube_ribbon_count_socket.description = "Amount of billboard like hair cards used to shape hair. (Mesh Style=Tube Ribbon)"
	
	    #Socket Profile Curve
	    profile_curve_socket = mesh_hair_selector.interface.new_socket(name = "Profile Curve", in_out='INPUT', socket_type = 'NodeSocketObject')
	    profile_curve_socket.attribute_domain = 'POINT'
	    profile_curve_socket.description = "Curve object used as the profile for stylized hair. (Mesh Style=Stylized)"
	
	    #Socket Profile Translation
	    profile_translation_socket = mesh_hair_selector.interface.new_socket(name = "Profile Translation", in_out='INPUT', socket_type = 'NodeSocketVector')
	    profile_translation_socket.default_value = (0.0, 0.0, 0.0)
	    profile_translation_socket.min_value = -3.4028234663852886e+38
	    profile_translation_socket.max_value = 3.4028234663852886e+38
	    profile_translation_socket.subtype = 'TRANSLATION'
	    profile_translation_socket.attribute_domain = 'POINT'
	    profile_translation_socket.description = "Move position of stylized profile from origin. (Mesh Style=Stylized)"
	
	    #Socket Profile Rotation
	    profile_rotation_socket = mesh_hair_selector.interface.new_socket(name = "Profile Rotation", in_out='INPUT', socket_type = 'NodeSocketRotation')
	    profile_rotation_socket.default_value = (0.0, 0.0, 0.0)
	    profile_rotation_socket.attribute_domain = 'POINT'
	    profile_rotation_socket.description = "Rotate the stylized profile from origin. (Mesh Style=Stylized)"
	
	    #Socket Profile Scale
	    profile_scale_socket = mesh_hair_selector.interface.new_socket(name = "Profile Scale", in_out='INPUT', socket_type = 'NodeSocketVector')
	    profile_scale_socket.default_value = (1.0, 1.0, 1.0)
	    profile_scale_socket.min_value = -3.4028234663852886e+38
	    profile_scale_socket.max_value = 3.4028234663852886e+38
	    profile_scale_socket.subtype = 'XYZ'
	    profile_scale_socket.attribute_domain = 'POINT'
	    profile_scale_socket.description = "Scale the stylized profile from origin. (Mesh Style=Stylized)"
	
	    #Socket Mesh Index
	    mesh_index_socket = mesh_hair_selector.interface.new_socket(name = "Mesh Index", in_out='INPUT', socket_type = 'NodeSocketInt')
	    mesh_index_socket.default_value = 0
	    mesh_index_socket.min_value = 0
	    mesh_index_socket.max_value = 2147483647
	    mesh_index_socket.subtype = 'NONE'
	    mesh_index_socket.attribute_domain = 'POINT'
	    mesh_index_socket.description = "Index used to offset uv coords."
	
	
	    #initialize mesh_hair_selector nodes
	    #node Group Output
	    group_output_4 = mesh_hair_selector.nodes.new("NodeGroupOutput")
	    group_output_4.name = "Group Output"
	    group_output_4.is_active_output = True
	    group_output_4.inputs[1].hide = True
	
	    #node Group
	    group = mesh_hair_selector.nodes.new("GeometryNodeGroup")
	    group.name = "Group"
	    group.node_tree = hair_card
	
	    #node Group.001
	    group_001 = mesh_hair_selector.nodes.new("GeometryNodeGroup")
	    group_001.name = "Group.001"
	    group_001.node_tree = stylized_hair
	
	    #node Group.002
	    group_002 = mesh_hair_selector.nodes.new("GeometryNodeGroup")
	    group_002.name = "Group.002"
	    group_002.node_tree = tube_mesh
	
	    #node Group.003
	    group_003 = mesh_hair_selector.nodes.new("GeometryNodeGroup")
	    group_003.name = "Group.003"
	    group_003.node_tree = tube_ribbon
	
	    #node Group Input.001
	    group_input_001_4 = mesh_hair_selector.nodes.new("NodeGroupInput")
	    group_input_001_4.name = "Group Input.001"
	    group_input_001_4.outputs[1].hide = True
	    group_input_001_4.outputs[5].hide = True
	    group_input_001_4.outputs[6].hide = True
	    group_input_001_4.outputs[7].hide = True
	    group_input_001_4.outputs[9].hide = True
	    group_input_001_4.outputs[10].hide = True
	    group_input_001_4.outputs[11].hide = True
	    group_input_001_4.outputs[12].hide = True
	    group_input_001_4.outputs[13].hide = True
	    group_input_001_4.outputs[14].hide = True
	    group_input_001_4.outputs[15].hide = True
	
	    #node Group Input.002
	    group_input_002_4 = mesh_hair_selector.nodes.new("NodeGroupInput")
	    group_input_002_4.name = "Group Input.002"
	    group_input_002_4.outputs[1].hide = True
	    group_input_002_4.outputs[5].hide = True
	    group_input_002_4.outputs[7].hide = True
	    group_input_002_4.outputs[8].hide = True
	    group_input_002_4.outputs[9].hide = True
	    group_input_002_4.outputs[10].hide = True
	    group_input_002_4.outputs[11].hide = True
	    group_input_002_4.outputs[12].hide = True
	    group_input_002_4.outputs[13].hide = True
	    group_input_002_4.outputs[14].hide = True
	    group_input_002_4.outputs[15].hide = True
	
	    #node Group Input.003
	    group_input_003_4 = mesh_hair_selector.nodes.new("NodeGroupInput")
	    group_input_003_4.name = "Group Input.003"
	    group_input_003_4.outputs[1].hide = True
	    group_input_003_4.outputs[5].hide = True
	    group_input_003_4.outputs[6].hide = True
	    group_input_003_4.outputs[7].hide = True
	    group_input_003_4.outputs[8].hide = True
	    group_input_003_4.outputs[10].hide = True
	    group_input_003_4.outputs[11].hide = True
	    group_input_003_4.outputs[12].hide = True
	    group_input_003_4.outputs[13].hide = True
	    group_input_003_4.outputs[14].hide = True
	    group_input_003_4.outputs[15].hide = True
	
	    #node Group Input.004
	    group_input_004_4 = mesh_hair_selector.nodes.new("NodeGroupInput")
	    group_input_004_4.name = "Group Input.004"
	    group_input_004_4.outputs[1].hide = True
	    group_input_004_4.outputs[4].hide = True
	    group_input_004_4.outputs[5].hide = True
	    group_input_004_4.outputs[7].hide = True
	    group_input_004_4.outputs[8].hide = True
	    group_input_004_4.outputs[9].hide = True
	    group_input_004_4.outputs[10].hide = True
	    group_input_004_4.outputs[14].hide = True
	    group_input_004_4.outputs[15].hide = True
	
	    #node Menu Switch.001
	    menu_switch_001 = mesh_hair_selector.nodes.new("GeometryNodeMenuSwitch")
	    menu_switch_001.name = "Menu Switch.001"
	    menu_switch_001.active_index = 3
	    menu_switch_001.data_type = 'STRING'
	    menu_switch_001.enum_items.clear()
	    menu_switch_001.enum_items.new("Hair Card")
	    menu_switch_001.enum_items[0].description = ""
	    menu_switch_001.enum_items.new("Tube Mesh")
	    menu_switch_001.enum_items[1].description = ""
	    menu_switch_001.enum_items.new("Tube Ribbon")
	    menu_switch_001.enum_items[2].description = ""
	    menu_switch_001.enum_items.new("Stylized")
	    menu_switch_001.enum_items[3].description = ""
	    menu_switch_001.inputs[5].hide = True
	
	    #node Store Named Attribute
	    store_named_attribute_4 = mesh_hair_selector.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_4.name = "Store Named Attribute"
	    store_named_attribute_4.data_type = 'FLOAT2'
	    store_named_attribute_4.domain = 'CORNER'
	    #Selection
	    store_named_attribute_4.inputs[1].default_value = True
	    #Name
	    store_named_attribute_4.inputs[2].default_value = "UVMap"
	
	    #node Named Attribute
	    named_attribute = mesh_hair_selector.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute.name = "Named Attribute"
	    named_attribute.data_type = 'FLOAT_VECTOR'
	
	    #node Group Input.005
	    group_input_005_2 = mesh_hair_selector.nodes.new("NodeGroupInput")
	    group_input_005_2.name = "Group Input.005"
	    group_input_005_2.outputs[0].hide = True
	    group_input_005_2.outputs[2].hide = True
	    group_input_005_2.outputs[3].hide = True
	    group_input_005_2.outputs[4].hide = True
	    group_input_005_2.outputs[5].hide = True
	    group_input_005_2.outputs[6].hide = True
	    group_input_005_2.outputs[7].hide = True
	    group_input_005_2.outputs[8].hide = True
	    group_input_005_2.outputs[9].hide = True
	    group_input_005_2.outputs[10].hide = True
	    group_input_005_2.outputs[11].hide = True
	    group_input_005_2.outputs[12].hide = True
	    group_input_005_2.outputs[13].hide = True
	    group_input_005_2.outputs[14].hide = True
	    group_input_005_2.outputs[15].hide = True
	
	    #node Group Input.006
	    group_input_006 = mesh_hair_selector.nodes.new("NodeGroupInput")
	    group_input_006.name = "Group Input.006"
	    group_input_006.outputs[0].hide = True
	    group_input_006.outputs[1].hide = True
	    group_input_006.outputs[2].hide = True
	    group_input_006.outputs[3].hide = True
	    group_input_006.outputs[4].hide = True
	    group_input_006.outputs[5].hide = True
	    group_input_006.outputs[6].hide = True
	    group_input_006.outputs[7].hide = True
	    group_input_006.outputs[8].hide = True
	    group_input_006.outputs[9].hide = True
	    group_input_006.outputs[11].hide = True
	    group_input_006.outputs[12].hide = True
	    group_input_006.outputs[13].hide = True
	    group_input_006.outputs[14].hide = True
	    group_input_006.outputs[15].hide = True
	
	    #node Compare
	    compare_4 = mesh_hair_selector.nodes.new("FunctionNodeCompare")
	    compare_4.name = "Compare"
	    compare_4.hide = True
	    compare_4.data_type = 'STRING'
	    compare_4.mode = 'ELEMENT'
	    compare_4.operation = 'EQUAL'
	
	    #node Switch
	    switch_4 = mesh_hair_selector.nodes.new("GeometryNodeSwitch")
	    switch_4.name = "Switch"
	    switch_4.hide = True
	    switch_4.input_type = 'GEOMETRY'
	
	    #node Compare.001
	    compare_001 = mesh_hair_selector.nodes.new("FunctionNodeCompare")
	    compare_001.name = "Compare.001"
	    compare_001.hide = True
	    compare_001.data_type = 'STRING'
	    compare_001.mode = 'ELEMENT'
	    compare_001.operation = 'EQUAL'
	
	    #node Switch.001
	    switch_001 = mesh_hair_selector.nodes.new("GeometryNodeSwitch")
	    switch_001.name = "Switch.001"
	    switch_001.hide = True
	    switch_001.input_type = 'GEOMETRY'
	
	    #node Compare.002
	    compare_002 = mesh_hair_selector.nodes.new("FunctionNodeCompare")
	    compare_002.name = "Compare.002"
	    compare_002.hide = True
	    compare_002.data_type = 'STRING'
	    compare_002.mode = 'ELEMENT'
	    compare_002.operation = 'EQUAL'
	
	    #node Switch.002
	    switch_002 = mesh_hair_selector.nodes.new("GeometryNodeSwitch")
	    switch_002.name = "Switch.002"
	    switch_002.hide = True
	    switch_002.input_type = 'GEOMETRY'
	
	    #node Compare.003
	    compare_003 = mesh_hair_selector.nodes.new("FunctionNodeCompare")
	    compare_003.name = "Compare.003"
	    compare_003.hide = True
	    compare_003.data_type = 'STRING'
	    compare_003.mode = 'ELEMENT'
	    compare_003.operation = 'EQUAL'
	
	    #node Switch.003
	    switch_003 = mesh_hair_selector.nodes.new("GeometryNodeSwitch")
	    switch_003.name = "Switch.003"
	    switch_003.hide = True
	    switch_003.input_type = 'GEOMETRY'
	
	    #node String
	    string = mesh_hair_selector.nodes.new("FunctionNodeInputString")
	    string.name = "String"
	    string.string = "hair_card_UV"
	
	    #node String.001
	    string_001 = mesh_hair_selector.nodes.new("FunctionNodeInputString")
	    string_001.name = "String.001"
	    string_001.string = "tube_mesh_UV"
	
	    #node String.002
	    string_002 = mesh_hair_selector.nodes.new("FunctionNodeInputString")
	    string_002.name = "String.002"
	    string_002.string = "ribbon_mesh_UV"
	
	    #node String.003
	    string_003 = mesh_hair_selector.nodes.new("FunctionNodeInputString")
	    string_003.name = "String.003"
	    string_003.string = "stylized_hair_UV"
	
	    #node Reroute
	    reroute_4 = mesh_hair_selector.nodes.new("NodeReroute")
	    reroute_4.name = "Reroute"
	    reroute_4.socket_idname = "NodeSocketString"
	    #node Reroute.001
	    reroute_001_3 = mesh_hair_selector.nodes.new("NodeReroute")
	    reroute_001_3.name = "Reroute.001"
	    reroute_001_3.socket_idname = "NodeSocketString"
	    #node Reroute.002
	    reroute_002_3 = mesh_hair_selector.nodes.new("NodeReroute")
	    reroute_002_3.name = "Reroute.002"
	    reroute_002_3.socket_idname = "NodeSocketString"
	    #node Reroute.003
	    reroute_003_3 = mesh_hair_selector.nodes.new("NodeReroute")
	    reroute_003_3.name = "Reroute.003"
	    reroute_003_3.socket_idname = "NodeSocketString"
	    #node Reroute.004
	    reroute_004_2 = mesh_hair_selector.nodes.new("NodeReroute")
	    reroute_004_2.name = "Reroute.004"
	    reroute_004_2.socket_idname = "NodeSocketString"
	    #node Reroute.005
	    reroute_005_2 = mesh_hair_selector.nodes.new("NodeReroute")
	    reroute_005_2.name = "Reroute.005"
	    reroute_005_2.socket_idname = "NodeSocketString"
	    #node Reroute.006
	    reroute_006_1 = mesh_hair_selector.nodes.new("NodeReroute")
	    reroute_006_1.name = "Reroute.006"
	    reroute_006_1.socket_idname = "NodeSocketString"
	    #node Reroute.007
	    reroute_007_1 = mesh_hair_selector.nodes.new("NodeReroute")
	    reroute_007_1.name = "Reroute.007"
	    reroute_007_1.socket_idname = "NodeSocketString"
	    #node Reroute.008
	    reroute_008_1 = mesh_hair_selector.nodes.new("NodeReroute")
	    reroute_008_1.name = "Reroute.008"
	    reroute_008_1.socket_idname = "NodeSocketString"
	    #node Reroute.009
	    reroute_009_1 = mesh_hair_selector.nodes.new("NodeReroute")
	    reroute_009_1.name = "Reroute.009"
	    reroute_009_1.socket_idname = "NodeSocketString"
	    #node Reroute.010
	    reroute_010 = mesh_hair_selector.nodes.new("NodeReroute")
	    reroute_010.name = "Reroute.010"
	    reroute_010.socket_idname = "NodeSocketString"
	    #node Reroute.011
	    reroute_011 = mesh_hair_selector.nodes.new("NodeReroute")
	    reroute_011.name = "Reroute.011"
	    reroute_011.socket_idname = "NodeSocketString"
	    #node Reroute.012
	    reroute_012 = mesh_hair_selector.nodes.new("NodeReroute")
	    reroute_012.name = "Reroute.012"
	    reroute_012.socket_idname = "NodeSocketString"
	    #node Reroute.013
	    reroute_013 = mesh_hair_selector.nodes.new("NodeReroute")
	    reroute_013.name = "Reroute.013"
	    reroute_013.socket_idname = "NodeSocketString"
	    #node Reroute.014
	    reroute_014 = mesh_hair_selector.nodes.new("NodeReroute")
	    reroute_014.name = "Reroute.014"
	    reroute_014.socket_idname = "NodeSocketString"
	    #node Group Input.007
	    group_input_007 = mesh_hair_selector.nodes.new("NodeGroupInput")
	    group_input_007.name = "Group Input.007"
	    group_input_007.outputs[0].hide = True
	    group_input_007.outputs[1].hide = True
	    group_input_007.outputs[2].hide = True
	    group_input_007.outputs[3].hide = True
	    group_input_007.outputs[4].hide = True
	    group_input_007.outputs[5].hide = True
	    group_input_007.outputs[6].hide = True
	    group_input_007.outputs[7].hide = True
	    group_input_007.outputs[8].hide = True
	    group_input_007.outputs[9].hide = True
	    group_input_007.outputs[10].hide = True
	    group_input_007.outputs[11].hide = True
	    group_input_007.outputs[12].hide = True
	    group_input_007.outputs[13].hide = True
	    group_input_007.outputs[15].hide = True
	
	    #node Store Named Attribute.001
	    store_named_attribute_001 = mesh_hair_selector.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_001.name = "Store Named Attribute.001"
	    store_named_attribute_001.data_type = 'INT'
	    store_named_attribute_001.domain = 'CORNER'
	    #Selection
	    store_named_attribute_001.inputs[1].default_value = True
	    #Name
	    store_named_attribute_001.inputs[2].default_value = "mesh_idx"
	
	    #node Remove Named Attribute
	    remove_named_attribute = mesh_hair_selector.nodes.new("GeometryNodeRemoveAttribute")
	    remove_named_attribute.name = "Remove Named Attribute"
	    remove_named_attribute.pattern_mode = 'EXACT'
	
	    #node Reroute.015
	    reroute_015 = mesh_hair_selector.nodes.new("NodeReroute")
	    reroute_015.name = "Reroute.015"
	    reroute_015.socket_idname = "NodeSocketString"
	    #node Reroute.016
	    reroute_016 = mesh_hair_selector.nodes.new("NodeReroute")
	    reroute_016.name = "Reroute.016"
	    reroute_016.socket_idname = "NodeSocketString"
	    #node Set Shade Smooth
	    set_shade_smooth = mesh_hair_selector.nodes.new("GeometryNodeSetShadeSmooth")
	    set_shade_smooth.name = "Set Shade Smooth"
	    set_shade_smooth.domain = 'FACE'
	    set_shade_smooth.inputs[1].hide = True
	    #Selection
	    set_shade_smooth.inputs[1].default_value = True
	
	    #node Use Mesh Bake
	    use_mesh_bake = mesh_hair_selector.nodes.new("GeometryNodeBake")
	    use_mesh_bake.label = "Use Mesh Bake"
	    use_mesh_bake.name = "Use Mesh Bake"
	    use_mesh_bake.active_index = 0
	    use_mesh_bake.bake_items.clear()
	    use_mesh_bake.bake_items.new('GEOMETRY', "Geometry")
	    use_mesh_bake.bake_items[0].attribute_domain = 'POINT'
	    use_mesh_bake.inputs[1].hide = True
	    use_mesh_bake.outputs[1].hide = True
	
	    #node Group Input.008
	    group_input_008 = mesh_hair_selector.nodes.new("NodeGroupInput")
	    group_input_008.name = "Group Input.008"
	    group_input_008.outputs[0].hide = True
	    group_input_008.outputs[1].hide = True
	    group_input_008.outputs[2].hide = True
	    group_input_008.outputs[3].hide = True
	    group_input_008.outputs[4].hide = True
	    group_input_008.outputs[5].hide = True
	    group_input_008.outputs[6].hide = True
	    group_input_008.outputs[8].hide = True
	    group_input_008.outputs[9].hide = True
	    group_input_008.outputs[10].hide = True
	    group_input_008.outputs[11].hide = True
	    group_input_008.outputs[12].hide = True
	    group_input_008.outputs[13].hide = True
	    group_input_008.outputs[14].hide = True
	    group_input_008.outputs[15].hide = True
	
	    #node Mesh Overall Shape
	    mesh_overall_shape = mesh_hair_selector.nodes.new("ShaderNodeFloatCurve")
	    mesh_overall_shape.label = "Mesh Overall Shape"
	    mesh_overall_shape.name = "Mesh Overall Shape"
	    #mapping settings
	    mesh_overall_shape.mapping.extend = 'EXTRAPOLATED'
	    mesh_overall_shape.mapping.tone = 'STANDARD'
	    mesh_overall_shape.mapping.black_level = (0.0, 0.0, 0.0)
	    mesh_overall_shape.mapping.white_level = (1.0, 1.0, 1.0)
	    mesh_overall_shape.mapping.clip_min_x = 0.0
	    mesh_overall_shape.mapping.clip_min_y = 0.0
	    mesh_overall_shape.mapping.clip_max_x = 1.0
	    mesh_overall_shape.mapping.clip_max_y = 1.0
	    mesh_overall_shape.mapping.use_clip = True
	    #curve 0
	    mesh_overall_shape_curve_0 = mesh_overall_shape.mapping.curves[0]
	    mesh_overall_shape_curve_0_point_0 = mesh_overall_shape_curve_0.points[0]
	    mesh_overall_shape_curve_0_point_0.location = (0.0, 1.0)
	    mesh_overall_shape_curve_0_point_0.handle_type = 'AUTO'
	    mesh_overall_shape_curve_0_point_1 = mesh_overall_shape_curve_0.points[1]
	    mesh_overall_shape_curve_0_point_1.location = (1.0, 1.0)
	    mesh_overall_shape_curve_0_point_1.handle_type = 'AUTO'
	    #update curve after changes
	    mesh_overall_shape.mapping.update()
	    #Factor
	    mesh_overall_shape.inputs[0].default_value = 1.0
	
	    #node Spline Parameter
	    spline_parameter_4 = mesh_hair_selector.nodes.new("GeometryNodeSplineParameter")
	    spline_parameter_4.name = "Spline Parameter"
	    spline_parameter_4.outputs[1].hide = True
	    spline_parameter_4.outputs[2].hide = True
	
	    #node Switch.004
	    switch_004 = mesh_hair_selector.nodes.new("GeometryNodeSwitch")
	    switch_004.name = "Switch.004"
	    switch_004.hide = True
	    switch_004.input_type = 'FLOAT'
	
	    #node Group Input.009
	    group_input_009 = mesh_hair_selector.nodes.new("NodeGroupInput")
	    group_input_009.name = "Group Input.009"
	    group_input_009.outputs[0].hide = True
	    group_input_009.outputs[1].hide = True
	    group_input_009.outputs[2].hide = True
	    group_input_009.outputs[3].hide = True
	    group_input_009.outputs[4].hide = True
	    group_input_009.outputs[6].hide = True
	    group_input_009.outputs[7].hide = True
	    group_input_009.outputs[8].hide = True
	    group_input_009.outputs[9].hide = True
	    group_input_009.outputs[10].hide = True
	    group_input_009.outputs[11].hide = True
	    group_input_009.outputs[12].hide = True
	    group_input_009.outputs[13].hide = True
	    group_input_009.outputs[14].hide = True
	    group_input_009.outputs[15].hide = True
	
	    #node Attribute Statistic
	    attribute_statistic = mesh_hair_selector.nodes.new("GeometryNodeAttributeStatistic")
	    attribute_statistic.name = "Attribute Statistic"
	    attribute_statistic.hide = True
	    attribute_statistic.data_type = 'FLOAT'
	    attribute_statistic.domain = 'POINT'
	    attribute_statistic.inputs[1].hide = True
	    attribute_statistic.outputs[0].hide = True
	    attribute_statistic.outputs[1].hide = True
	    attribute_statistic.outputs[3].hide = True
	    attribute_statistic.outputs[4].hide = True
	    attribute_statistic.outputs[5].hide = True
	    attribute_statistic.outputs[6].hide = True
	    attribute_statistic.outputs[7].hide = True
	    #Selection
	    attribute_statistic.inputs[1].default_value = True
	
	    #node Store Named Attribute.002
	    store_named_attribute_002 = mesh_hair_selector.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_002.name = "Store Named Attribute.002"
	    store_named_attribute_002.hide = True
	    store_named_attribute_002.data_type = 'FLOAT'
	    store_named_attribute_002.domain = 'POINT'
	    store_named_attribute_002.inputs[1].hide = True
	    store_named_attribute_002.inputs[2].hide = True
	    #Selection
	    store_named_attribute_002.inputs[1].default_value = True
	    #Name
	    store_named_attribute_002.inputs[2].default_value = "mcr"
	
	    #node Compare.005
	    compare_005 = mesh_hair_selector.nodes.new("FunctionNodeCompare")
	    compare_005.name = "Compare.005"
	    compare_005.hide = True
	    compare_005.data_type = 'FLOAT'
	    compare_005.mode = 'ELEMENT'
	    compare_005.operation = 'EQUAL'
	    compare_005.inputs[1].hide = True
	    compare_005.inputs[2].hide = True
	    compare_005.inputs[3].hide = True
	    compare_005.inputs[4].hide = True
	    compare_005.inputs[5].hide = True
	    compare_005.inputs[6].hide = True
	    compare_005.inputs[7].hide = True
	    compare_005.inputs[8].hide = True
	    compare_005.inputs[9].hide = True
	    compare_005.inputs[10].hide = True
	    compare_005.inputs[11].hide = True
	    compare_005.inputs[12].hide = True
	    #B
	    compare_005.inputs[1].default_value = 0.0
	    #Epsilon
	    compare_005.inputs[12].default_value = 0.0
	
	    #node Named Attribute.001
	    named_attribute_001 = mesh_hair_selector.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute_001.name = "Named Attribute.001"
	    named_attribute_001.hide = True
	    named_attribute_001.data_type = 'FLOAT'
	    #Name
	    named_attribute_001.inputs[0].default_value = "mcr"
	
	    #node Group Input.010
	    group_input_010 = mesh_hair_selector.nodes.new("NodeGroupInput")
	    group_input_010.name = "Group Input.010"
	    group_input_010.outputs[1].hide = True
	    group_input_010.outputs[2].hide = True
	    group_input_010.outputs[3].hide = True
	    group_input_010.outputs[4].hide = True
	    group_input_010.outputs[5].hide = True
	    group_input_010.outputs[6].hide = True
	    group_input_010.outputs[7].hide = True
	    group_input_010.outputs[8].hide = True
	    group_input_010.outputs[9].hide = True
	    group_input_010.outputs[10].hide = True
	    group_input_010.outputs[11].hide = True
	    group_input_010.outputs[12].hide = True
	    group_input_010.outputs[13].hide = True
	    group_input_010.outputs[14].hide = True
	    group_input_010.outputs[15].hide = True
	
	
	
	
	
	    #Set locations
	    group_output_4.location = (2610.42724609375, -19.416736602783203)
	    group.location = (-79.76215362548828, -110.40367889404297)
	    group_001.location = (-81.79773712158203, -748.9313354492188)
	    group_002.location = (-78.79950714111328, -318.1512451171875)
	    group_003.location = (-78.67485809326172, -526.0662231445312)
	    group_input_001_4.location = (-338.60595703125, -155.34437561035156)
	    group_input_002_4.location = (-338.60595703125, -362.43890380859375)
	    group_input_003_4.location = (-338.60595703125, -569.8320922851562)
	    group_input_004_4.location = (-338.60595703125, -815.11083984375)
	    menu_switch_001.location = (469.07684326171875, 163.7274627685547)
	    store_named_attribute_4.location = (1647.7332763671875, -19.652393341064453)
	    named_attribute.location = (1475.844482421875, -157.7658233642578)
	    group_input_005_2.location = (265.0098571777344, 135.95323181152344)
	    group_input_006.location = (-338.60595703125, -756.4561767578125)
	    compare_4.location = (1238.7310791015625, -84.21184539794922)
	    switch_4.location = (1238.74365234375, -117.19403076171875)
	    compare_001.location = (1099.1707763671875, -299.4894104003906)
	    switch_001.location = (1106.2532958984375, -334.8301696777344)
	    compare_002.location = (970.40234375, -499.8262634277344)
	    switch_002.location = (975.1282958984375, -535.1670532226562)
	    compare_003.location = (837.8390502929688, -724.1065063476562)
	    switch_003.location = (840.2083740234375, -760.2830810546875)
	    string.location = (84.04959869384766, -54.475547790527344)
	    string_001.location = (82.85930633544922, -258.00762939453125)
	    string_002.location = (79.31243896484375, -471.3780517578125)
	    string_003.location = (76.95584106445312, -696.93603515625)
	    reroute_4.location = (266.1946716308594, -90.37294006347656)
	    reroute_001_3.location = (330.2995910644531, -295.4872741699219)
	    reroute_002_3.location = (386.08740234375, -507.37738037109375)
	    reroute_003_3.location = (432.0370178222656, -735.281005859375)
	    reroute_004_2.location = (267.64080810546875, 58.478363037109375)
	    reroute_005_2.location = (328.94110107421875, 33.61994552612305)
	    reroute_006_1.location = (388.06353759765625, 12.934127807617188)
	    reroute_007_1.location = (434.48321533203125, -6.701620101928711)
	    reroute_008_1.location = (790.6254272460938, 129.04226684570312)
	    reroute_009_1.location = (800.4947509765625, -727.48974609375)
	    reroute_010.location = (796.8050537109375, -498.8685607910156)
	    reroute_011.location = (792.9110107421875, -293.6495361328125)
	    reroute_012.location = (790.7710571289062, -80.90033721923828)
	    reroute_013.location = (1415.17578125, -264.01324462890625)
	    reroute_014.location = (1401.7613525390625, 129.6073760986328)
	    group_input_007.location = (1837.3367919921875, -221.13070678710938)
	    store_named_attribute_001.location = (1841.328125, -19.652393341064453)
	    remove_named_attribute.location = (2020.999755859375, -18.566680908203125)
	    reroute_015.location = (1997.9866943359375, 132.55369567871094)
	    reroute_016.location = (2003.16845703125, -126.52413940429688)
	    set_shade_smooth.location = (2246.024658203125, -17.58367919921875)
	    use_mesh_bake.location = (2430.91064453125, 27.558258056640625)
	    group_input_008.location = (2049.84326171875, -148.66607666015625)
	    mesh_overall_shape.location = (-873.3704223632812, -650.7651977539062)
	    spline_parameter_4.location = (-876.84423828125, -968.0524291992188)
	    switch_004.location = (-631.904296875, -473.04425048828125)
	    group_input_009.location = (-872.6063232421875, -591.0381469726562)
	    attribute_statistic.location = (-870.9525146484375, -511.33477783203125)
	    store_named_attribute_002.location = (-879.0206909179688, -565.9711303710938)
	    compare_005.location = (-632.6890869140625, -511.18927001953125)
	    named_attribute_001.location = (-874.1126708984375, -454.52947998046875)
	    group_input_010.location = (-1047.1160888671875, -533.9951782226562)
	
	    #Set dimensions
	    group_output_4.width, group_output_4.height = 140.0, 100.0
	    group.width, group.height = 140.0, 100.0
	    group_001.width, group_001.height = 140.0, 100.0
	    group_002.width, group_002.height = 140.0, 100.0
	    group_003.width, group_003.height = 140.0, 100.0
	    group_input_001_4.width, group_input_001_4.height = 140.0, 100.0
	    group_input_002_4.width, group_input_002_4.height = 140.0, 100.0
	    group_input_003_4.width, group_input_003_4.height = 140.0, 100.0
	    group_input_004_4.width, group_input_004_4.height = 140.0, 100.0
	    menu_switch_001.width, menu_switch_001.height = 245.18148803710938, 100.0
	    store_named_attribute_4.width, store_named_attribute_4.height = 140.0, 100.0
	    named_attribute.width, named_attribute.height = 140.0, 100.0
	    group_input_005_2.width, group_input_005_2.height = 140.0, 100.0
	    group_input_006.width, group_input_006.height = 140.0, 100.0
	    compare_4.width, compare_4.height = 140.0, 100.0
	    switch_4.width, switch_4.height = 140.0, 100.0
	    compare_001.width, compare_001.height = 140.0, 100.0
	    switch_001.width, switch_001.height = 140.0, 100.0
	    compare_002.width, compare_002.height = 140.0, 100.0
	    switch_002.width, switch_002.height = 140.0, 100.0
	    compare_003.width, compare_003.height = 140.0, 100.0
	    switch_003.width, switch_003.height = 140.0, 100.0
	    string.width, string.height = 140.0, 100.0
	    string_001.width, string_001.height = 140.0, 100.0
	    string_002.width, string_002.height = 140.0, 100.0
	    string_003.width, string_003.height = 140.0, 100.0
	    reroute_4.width, reroute_4.height = 10.0, 100.0
	    reroute_001_3.width, reroute_001_3.height = 10.0, 100.0
	    reroute_002_3.width, reroute_002_3.height = 10.0, 100.0
	    reroute_003_3.width, reroute_003_3.height = 10.0, 100.0
	    reroute_004_2.width, reroute_004_2.height = 10.0, 100.0
	    reroute_005_2.width, reroute_005_2.height = 10.0, 100.0
	    reroute_006_1.width, reroute_006_1.height = 10.0, 100.0
	    reroute_007_1.width, reroute_007_1.height = 10.0, 100.0
	    reroute_008_1.width, reroute_008_1.height = 10.0, 100.0
	    reroute_009_1.width, reroute_009_1.height = 10.0, 100.0
	    reroute_010.width, reroute_010.height = 10.0, 100.0
	    reroute_011.width, reroute_011.height = 10.0, 100.0
	    reroute_012.width, reroute_012.height = 10.0, 100.0
	    reroute_013.width, reroute_013.height = 10.0, 100.0
	    reroute_014.width, reroute_014.height = 10.0, 100.0
	    group_input_007.width, group_input_007.height = 140.0, 100.0
	    store_named_attribute_001.width, store_named_attribute_001.height = 140.0, 100.0
	    remove_named_attribute.width, remove_named_attribute.height = 170.0, 100.0
	    reroute_015.width, reroute_015.height = 10.0, 100.0
	    reroute_016.width, reroute_016.height = 10.0, 100.0
	    set_shade_smooth.width, set_shade_smooth.height = 140.0, 100.0
	    use_mesh_bake.width, use_mesh_bake.height = 140.0, 100.0
	    group_input_008.width, group_input_008.height = 140.0, 100.0
	    mesh_overall_shape.width, mesh_overall_shape.height = 240.0, 100.0
	    spline_parameter_4.width, spline_parameter_4.height = 140.0, 100.0
	    switch_004.width, switch_004.height = 140.0, 100.0
	    group_input_009.width, group_input_009.height = 140.0, 100.0
	    attribute_statistic.width, attribute_statistic.height = 140.0, 100.0
	    store_named_attribute_002.width, store_named_attribute_002.height = 140.0, 100.0
	    compare_005.width, compare_005.height = 140.0, 100.0
	    named_attribute_001.width, named_attribute_001.height = 140.0, 100.0
	    group_input_010.width, group_input_010.height = 140.0, 100.0
	
	    #initialize mesh_hair_selector links
	    #use_mesh_bake.Geometry -> group_output_4.Geometry
	    mesh_hair_selector.links.new(use_mesh_bake.outputs[0], group_output_4.inputs[0])
	    #group_input_001_4.Geometry -> group.Geometry
	    mesh_hair_selector.links.new(group_input_001_4.outputs[0], group.inputs[0])
	    #group_input_002_4.Geometry -> group_002.Geometry
	    mesh_hair_selector.links.new(group_input_002_4.outputs[0], group_002.inputs[0])
	    #group_input_003_4.Geometry -> group_003.Geometry
	    mesh_hair_selector.links.new(group_input_003_4.outputs[0], group_003.inputs[0])
	    #group_input_001_4.Material -> group.Material
	    mesh_hair_selector.links.new(group_input_001_4.outputs[2], group.inputs[1])
	    #named_attribute.Attribute -> store_named_attribute_4.Value
	    mesh_hair_selector.links.new(named_attribute.outputs[0], store_named_attribute_4.inputs[3])
	    #reroute_013.Output -> named_attribute.Name
	    mesh_hair_selector.links.new(reroute_013.outputs[0], named_attribute.inputs[0])
	    #group_input_005_2.Style Select -> menu_switch_001.Menu
	    mesh_hair_selector.links.new(group_input_005_2.outputs[1], menu_switch_001.inputs[0])
	    #group_input_001_4.Resolution -> group.Resolution
	    mesh_hair_selector.links.new(group_input_001_4.outputs[3], group.inputs[3])
	    #group_input_001_4.Width -> group.Width
	    mesh_hair_selector.links.new(group_input_001_4.outputs[4], group.inputs[4])
	    #group_input_001_4.Hair Card Angle -> group.Angle
	    mesh_hair_selector.links.new(group_input_001_4.outputs[8], group.inputs[5])
	    #group_input_002_4.Material -> group_002.Material
	    mesh_hair_selector.links.new(group_input_002_4.outputs[2], group_002.inputs[1])
	    #group_input_002_4.Resolution -> group_002.Resolution
	    mesh_hair_selector.links.new(group_input_002_4.outputs[3], group_002.inputs[3])
	    #group_input_002_4.Width -> group_002.Width
	    mesh_hair_selector.links.new(group_input_002_4.outputs[4], group_002.inputs[4])
	    #group_input_002_4.Fill Caps -> group_002.Fill Caps
	    mesh_hair_selector.links.new(group_input_002_4.outputs[6], group_002.inputs[5])
	    #group_input_003_4.Material -> group_003.Material
	    mesh_hair_selector.links.new(group_input_003_4.outputs[2], group_003.inputs[1])
	    #group_input_003_4.Resolution -> group_003.Resolution
	    mesh_hair_selector.links.new(group_input_003_4.outputs[3], group_003.inputs[4])
	    #group_input_003_4.Width -> group_003.Width
	    mesh_hair_selector.links.new(group_input_003_4.outputs[4], group_003.inputs[5])
	    #group_input_003_4.Tube Ribbon Count -> group_003.Ribbon Count
	    mesh_hair_selector.links.new(group_input_003_4.outputs[9], group_003.inputs[3])
	    #group_input_004_4.Material -> group_001.Material
	    mesh_hair_selector.links.new(group_input_004_4.outputs[2], group_001.inputs[2])
	    #group_input_004_4.Fill Caps -> group_001.Fill Caps
	    mesh_hair_selector.links.new(group_input_004_4.outputs[6], group_001.inputs[5])
	    #group_input_004_4.Profile Translation -> group_001.Translation
	    mesh_hair_selector.links.new(group_input_004_4.outputs[11], group_001.inputs[6])
	    #group_input_004_4.Profile Rotation -> group_001.Rotation
	    mesh_hair_selector.links.new(group_input_004_4.outputs[12], group_001.inputs[7])
	    #group_input_004_4.Profile Scale -> group_001.Scale
	    mesh_hair_selector.links.new(group_input_004_4.outputs[13], group_001.inputs[8])
	    #group_input_006.Profile Curve -> group_001.Profile
	    mesh_hair_selector.links.new(group_input_006.outputs[10], group_001.inputs[1])
	    #group_input_004_4.Resolution -> group_001.Resolution
	    mesh_hair_selector.links.new(group_input_004_4.outputs[3], group_001.inputs[4])
	    #compare_4.Result -> switch_4.Switch
	    mesh_hair_selector.links.new(compare_4.outputs[0], switch_4.inputs[0])
	    #compare_001.Result -> switch_001.Switch
	    mesh_hair_selector.links.new(compare_001.outputs[0], switch_001.inputs[0])
	    #compare_002.Result -> switch_002.Switch
	    mesh_hair_selector.links.new(compare_002.outputs[0], switch_002.inputs[0])
	    #reroute_009_1.Output -> compare_003.A
	    mesh_hair_selector.links.new(reroute_009_1.outputs[0], compare_003.inputs[8])
	    #compare_003.Result -> switch_003.Switch
	    mesh_hair_selector.links.new(compare_003.outputs[0], switch_003.inputs[0])
	    #switch_001.Output -> switch_4.False
	    mesh_hair_selector.links.new(switch_001.outputs[0], switch_4.inputs[1])
	    #switch_002.Output -> switch_001.False
	    mesh_hair_selector.links.new(switch_002.outputs[0], switch_001.inputs[1])
	    #switch_003.Output -> switch_002.False
	    mesh_hair_selector.links.new(switch_003.outputs[0], switch_002.inputs[1])
	    #reroute_004_2.Output -> menu_switch_001.Hair Card
	    mesh_hair_selector.links.new(reroute_004_2.outputs[0], menu_switch_001.inputs[1])
	    #reroute_4.Output -> compare_4.B
	    mesh_hair_selector.links.new(reroute_4.outputs[0], compare_4.inputs[9])
	    #group.Geometry -> switch_4.True
	    mesh_hair_selector.links.new(group.outputs[0], switch_4.inputs[2])
	    #reroute_005_2.Output -> menu_switch_001.Tube Mesh
	    mesh_hair_selector.links.new(reroute_005_2.outputs[0], menu_switch_001.inputs[2])
	    #reroute_001_3.Output -> compare_001.B
	    mesh_hair_selector.links.new(reroute_001_3.outputs[0], compare_001.inputs[9])
	    #group_002.Geometry -> switch_001.True
	    mesh_hair_selector.links.new(group_002.outputs[0], switch_001.inputs[2])
	    #reroute_006_1.Output -> menu_switch_001.Tube Ribbon
	    mesh_hair_selector.links.new(reroute_006_1.outputs[0], menu_switch_001.inputs[3])
	    #reroute_002_3.Output -> compare_002.B
	    mesh_hair_selector.links.new(reroute_002_3.outputs[0], compare_002.inputs[9])
	    #group_003.Geometry -> switch_002.True
	    mesh_hair_selector.links.new(group_003.outputs[0], switch_002.inputs[2])
	    #reroute_007_1.Output -> menu_switch_001.Stylized
	    mesh_hair_selector.links.new(reroute_007_1.outputs[0], menu_switch_001.inputs[4])
	    #reroute_003_3.Output -> compare_003.B
	    mesh_hair_selector.links.new(reroute_003_3.outputs[0], compare_003.inputs[9])
	    #group_001.Geometry -> switch_003.True
	    mesh_hair_selector.links.new(group_001.outputs[0], switch_003.inputs[2])
	    #switch_4.Output -> store_named_attribute_4.Geometry
	    mesh_hair_selector.links.new(switch_4.outputs[0], store_named_attribute_4.inputs[0])
	    #string.String -> reroute_4.Input
	    mesh_hair_selector.links.new(string.outputs[0], reroute_4.inputs[0])
	    #string_001.String -> reroute_001_3.Input
	    mesh_hair_selector.links.new(string_001.outputs[0], reroute_001_3.inputs[0])
	    #string_002.String -> reroute_002_3.Input
	    mesh_hair_selector.links.new(string_002.outputs[0], reroute_002_3.inputs[0])
	    #string_003.String -> reroute_003_3.Input
	    mesh_hair_selector.links.new(string_003.outputs[0], reroute_003_3.inputs[0])
	    #reroute_4.Output -> reroute_004_2.Input
	    mesh_hair_selector.links.new(reroute_4.outputs[0], reroute_004_2.inputs[0])
	    #reroute_001_3.Output -> reroute_005_2.Input
	    mesh_hair_selector.links.new(reroute_001_3.outputs[0], reroute_005_2.inputs[0])
	    #reroute_002_3.Output -> reroute_006_1.Input
	    mesh_hair_selector.links.new(reroute_002_3.outputs[0], reroute_006_1.inputs[0])
	    #reroute_003_3.Output -> reroute_007_1.Input
	    mesh_hair_selector.links.new(reroute_003_3.outputs[0], reroute_007_1.inputs[0])
	    #menu_switch_001.Output -> reroute_008_1.Input
	    mesh_hair_selector.links.new(menu_switch_001.outputs[0], reroute_008_1.inputs[0])
	    #reroute_010.Output -> reroute_009_1.Input
	    mesh_hair_selector.links.new(reroute_010.outputs[0], reroute_009_1.inputs[0])
	    #reroute_011.Output -> reroute_010.Input
	    mesh_hair_selector.links.new(reroute_011.outputs[0], reroute_010.inputs[0])
	    #reroute_010.Output -> compare_002.A
	    mesh_hair_selector.links.new(reroute_010.outputs[0], compare_002.inputs[8])
	    #reroute_012.Output -> reroute_011.Input
	    mesh_hair_selector.links.new(reroute_012.outputs[0], reroute_011.inputs[0])
	    #reroute_008_1.Output -> reroute_012.Input
	    mesh_hair_selector.links.new(reroute_008_1.outputs[0], reroute_012.inputs[0])
	    #reroute_011.Output -> compare_001.A
	    mesh_hair_selector.links.new(reroute_011.outputs[0], compare_001.inputs[8])
	    #reroute_012.Output -> compare_4.A
	    mesh_hair_selector.links.new(reroute_012.outputs[0], compare_4.inputs[8])
	    #reroute_014.Output -> reroute_013.Input
	    mesh_hair_selector.links.new(reroute_014.outputs[0], reroute_013.inputs[0])
	    #reroute_008_1.Output -> reroute_014.Input
	    mesh_hair_selector.links.new(reroute_008_1.outputs[0], reroute_014.inputs[0])
	    #store_named_attribute_4.Geometry -> store_named_attribute_001.Geometry
	    mesh_hair_selector.links.new(store_named_attribute_4.outputs[0], store_named_attribute_001.inputs[0])
	    #group_input_007.Mesh Index -> store_named_attribute_001.Value
	    mesh_hair_selector.links.new(group_input_007.outputs[14], store_named_attribute_001.inputs[3])
	    #store_named_attribute_001.Geometry -> remove_named_attribute.Geometry
	    mesh_hair_selector.links.new(store_named_attribute_001.outputs[0], remove_named_attribute.inputs[0])
	    #reroute_016.Output -> remove_named_attribute.Name
	    mesh_hair_selector.links.new(reroute_016.outputs[0], remove_named_attribute.inputs[1])
	    #reroute_014.Output -> reroute_015.Input
	    mesh_hair_selector.links.new(reroute_014.outputs[0], reroute_015.inputs[0])
	    #reroute_015.Output -> reroute_016.Input
	    mesh_hair_selector.links.new(reroute_015.outputs[0], reroute_016.inputs[0])
	    #set_shade_smooth.Geometry -> use_mesh_bake.Geometry
	    mesh_hair_selector.links.new(set_shade_smooth.outputs[0], use_mesh_bake.inputs[0])
	    #remove_named_attribute.Geometry -> set_shade_smooth.Geometry
	    mesh_hair_selector.links.new(remove_named_attribute.outputs[0], set_shade_smooth.inputs[0])
	    #group_input_008.Shade Smooth -> set_shade_smooth.Shade Smooth
	    mesh_hair_selector.links.new(group_input_008.outputs[7], set_shade_smooth.inputs[2])
	    #switch_004.Output -> group_001.Curve Radius
	    mesh_hair_selector.links.new(switch_004.outputs[0], group_001.inputs[3])
	    #switch_004.Output -> group_003.Curve Radius
	    mesh_hair_selector.links.new(switch_004.outputs[0], group_003.inputs[2])
	    #switch_004.Output -> group_002.Curve Radius
	    mesh_hair_selector.links.new(switch_004.outputs[0], group_002.inputs[2])
	    #switch_004.Output -> group.Curve Radius
	    mesh_hair_selector.links.new(switch_004.outputs[0], group.inputs[2])
	    #spline_parameter_4.Factor -> mesh_overall_shape.Value
	    mesh_hair_selector.links.new(spline_parameter_4.outputs[0], mesh_overall_shape.inputs[1])
	    #group_input_009.Curve Radius -> store_named_attribute_002.Value
	    mesh_hair_selector.links.new(group_input_009.outputs[5], store_named_attribute_002.inputs[3])
	    #store_named_attribute_002.Geometry -> attribute_statistic.Geometry
	    mesh_hair_selector.links.new(store_named_attribute_002.outputs[0], attribute_statistic.inputs[0])
	    #attribute_statistic.Sum -> compare_005.A
	    mesh_hair_selector.links.new(attribute_statistic.outputs[2], compare_005.inputs[0])
	    #compare_005.Result -> switch_004.Switch
	    mesh_hair_selector.links.new(compare_005.outputs[0], switch_004.inputs[0])
	    #named_attribute_001.Attribute -> attribute_statistic.Attribute
	    mesh_hair_selector.links.new(named_attribute_001.outputs[0], attribute_statistic.inputs[2])
	    #mesh_overall_shape.Value -> switch_004.True
	    mesh_hair_selector.links.new(mesh_overall_shape.outputs[0], switch_004.inputs[2])
	    #group_input_009.Curve Radius -> switch_004.False
	    mesh_hair_selector.links.new(group_input_009.outputs[5], switch_004.inputs[1])
	    #group_input_010.Geometry -> store_named_attribute_002.Geometry
	    mesh_hair_selector.links.new(group_input_010.outputs[0], store_named_attribute_002.inputs[0])
	    #group_input_004_4.Geometry -> group_001.Geometry
	    mesh_hair_selector.links.new(group_input_004_4.outputs[0], group_001.inputs[0])
	    style_select_socket.default_value = 'Hair Card'
	    return mesh_hair_selector
	return mesh_hair_selector_node_group()

	

	
