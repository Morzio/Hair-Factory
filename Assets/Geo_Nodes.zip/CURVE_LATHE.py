import bpy, mathutils

def node():
	#initialize curve_lathe node group
	def curve_lathe_node_group():
	    curve_lathe = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "CURVE_LATHE")
	
	    curve_lathe.color_tag = 'NONE'
	    curve_lathe.description = "Place curve profile radially."
	    curve_lathe.default_group_node_width = 140
	    
	
	    curve_lathe.is_modifier = True
	
	    #curve_lathe interface
	    #Socket Geometry
	    geometry_socket = curve_lathe.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket.attribute_domain = 'POINT'
	    geometry_socket.description = "Radially placed curve profile."
	
	    #Socket Geometry
	    geometry_socket_1 = curve_lathe.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_1.attribute_domain = 'POINT'
	    geometry_socket_1.description = "Curve profile."
	
	    #Socket Count
	    count_socket = curve_lathe.interface.new_socket(name = "Count", in_out='INPUT', socket_type = 'NodeSocketInt')
	    count_socket.default_value = 8
	    count_socket.min_value = 1
	    count_socket.max_value = 100000
	    count_socket.subtype = 'NONE'
	    count_socket.attribute_domain = 'POINT'
	
	    #Socket Width
	    width_socket = curve_lathe.interface.new_socket(name = "Width", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    width_socket.default_value = 1.0
	    width_socket.min_value = 0.0
	    width_socket.max_value = 10000.0
	    width_socket.subtype = 'NONE'
	    width_socket.attribute_domain = 'POINT'
	    width_socket.description = "Overall width scale."
	
	    #Socket Height
	    height_socket = curve_lathe.interface.new_socket(name = "Height", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    height_socket.default_value = 1.0
	    height_socket.min_value = 0.0
	    height_socket.max_value = 10000.0
	    height_socket.subtype = 'NONE'
	    height_socket.attribute_domain = 'POINT'
	    height_socket.description = "Overall height scale."
	
	    #Socket Tilt Angle
	    tilt_angle_socket = curve_lathe.interface.new_socket(name = "Tilt Angle", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    tilt_angle_socket.default_value = 0.0
	    tilt_angle_socket.min_value = -180.0
	    tilt_angle_socket.max_value = 180.0
	    tilt_angle_socket.subtype = 'ANGLE'
	    tilt_angle_socket.attribute_domain = 'POINT'
	    tilt_angle_socket.description = "Angle for curve tilt."
	
	    #Socket Tilt Align Factor
	    tilt_align_factor_socket = curve_lathe.interface.new_socket(name = "Tilt Align Factor", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    tilt_align_factor_socket.default_value = 1.0
	    tilt_align_factor_socket.min_value = 0.0
	    tilt_align_factor_socket.max_value = 1.0
	    tilt_align_factor_socket.subtype = 'FACTOR'
	    tilt_align_factor_socket.attribute_domain = 'POINT'
	    tilt_align_factor_socket.description = "Percentage of tilt alignment to use."
	
	
	    #initialize curve_lathe nodes
	    #node Group Output
	    group_output = curve_lathe.nodes.new("NodeGroupOutput")
	    group_output.name = "Group Output"
	    group_output.is_active_output = True
	    group_output.inputs[1].hide = True
	
	    #node Group Input
	    group_input = curve_lathe.nodes.new("NodeGroupInput")
	    group_input.name = "Group Input"
	    group_input.outputs[2].hide = True
	    group_input.outputs[3].hide = True
	    group_input.outputs[4].hide = True
	    group_input.outputs[5].hide = True
	    group_input.outputs[6].hide = True
	
	    #node Curve Circle
	    curve_circle = curve_lathe.nodes.new("GeometryNodeCurvePrimitiveCircle")
	    curve_circle.name = "Curve Circle"
	    curve_circle.hide = True
	    curve_circle.mode = 'RADIUS'
	    curve_circle.inputs[0].hide = True
	    curve_circle.inputs[1].hide = True
	    curve_circle.inputs[2].hide = True
	    curve_circle.inputs[3].hide = True
	    curve_circle.inputs[4].hide = True
	    curve_circle.outputs[1].hide = True
	    #Resolution
	    curve_circle.inputs[0].default_value = 32
	    #Radius
	    curve_circle.inputs[4].default_value = 1.0
	
	    #node Curve to Points
	    curve_to_points = curve_lathe.nodes.new("GeometryNodeCurveToPoints")
	    curve_to_points.name = "Curve to Points"
	    curve_to_points.hide = True
	    curve_to_points.mode = 'COUNT'
	    curve_to_points.inputs[2].hide = True
	    curve_to_points.outputs[1].hide = True
	    curve_to_points.outputs[2].hide = True
	
	    #node Instance on Points
	    instance_on_points = curve_lathe.nodes.new("GeometryNodeInstanceOnPoints")
	    instance_on_points.name = "Instance on Points"
	    instance_on_points.hide = True
	    instance_on_points.inputs[1].hide = True
	    instance_on_points.inputs[3].hide = True
	    instance_on_points.inputs[4].hide = True
	    instance_on_points.inputs[6].hide = True
	    #Selection
	    instance_on_points.inputs[1].default_value = True
	    #Pick Instance
	    instance_on_points.inputs[3].default_value = False
	    #Instance Index
	    instance_on_points.inputs[4].default_value = 0
	    #Scale
	    instance_on_points.inputs[6].default_value = (1.0, 1.0, 1.0)
	
	    #node Transform Geometry
	    transform_geometry = curve_lathe.nodes.new("GeometryNodeTransform")
	    transform_geometry.name = "Transform Geometry"
	    transform_geometry.hide = True
	    transform_geometry.mode = 'COMPONENTS'
	    transform_geometry.inputs[1].hide = True
	    transform_geometry.inputs[2].hide = True
	    transform_geometry.inputs[3].hide = True
	    transform_geometry.inputs[4].hide = True
	    #Translation
	    transform_geometry.inputs[1].default_value = (-1.0, 0.0, 0.0)
	    #Rotation
	    transform_geometry.inputs[2].default_value = (0.0, 0.0, -1.5707963705062866)
	    #Scale
	    transform_geometry.inputs[3].default_value = (1.0, 1.0, 1.0)
	
	    #node Transform Geometry.001
	    transform_geometry_001 = curve_lathe.nodes.new("GeometryNodeTransform")
	    transform_geometry_001.name = "Transform Geometry.001"
	    transform_geometry_001.hide = True
	    transform_geometry_001.mode = 'COMPONENTS'
	    transform_geometry_001.inputs[1].hide = True
	    transform_geometry_001.inputs[2].hide = True
	    transform_geometry_001.inputs[4].hide = True
	    #Translation
	    transform_geometry_001.inputs[1].default_value = (0.0, 0.0, 0.0)
	    #Rotation
	    transform_geometry_001.inputs[2].default_value = (0.0, 0.0, 0.0)
	
	    #node Combine XYZ.002
	    combine_xyz_002 = curve_lathe.nodes.new("ShaderNodeCombineXYZ")
	    combine_xyz_002.name = "Combine XYZ.002"
	    combine_xyz_002.hide = True
	
	    #node Realize Instances
	    realize_instances = curve_lathe.nodes.new("GeometryNodeRealizeInstances")
	    realize_instances.name = "Realize Instances"
	    realize_instances.inputs[1].hide = True
	    realize_instances.inputs[2].hide = True
	    realize_instances.inputs[3].hide = True
	    #Selection
	    realize_instances.inputs[1].default_value = True
	    #Realize All
	    realize_instances.inputs[2].default_value = True
	    #Depth
	    realize_instances.inputs[3].default_value = 0
	
	    #node Store Named Attribute.001
	    store_named_attribute_001 = curve_lathe.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_001.name = "Store Named Attribute.001"
	    store_named_attribute_001.data_type = 'FLOAT_VECTOR'
	    store_named_attribute_001.domain = 'CURVE'
	    #Selection
	    store_named_attribute_001.inputs[1].default_value = True
	    #Name
	    store_named_attribute_001.inputs[2].default_value = "rot"
	
	    #node Set Curve Tilt
	    set_curve_tilt = curve_lathe.nodes.new("GeometryNodeSetCurveTilt")
	    set_curve_tilt.name = "Set Curve Tilt"
	    set_curve_tilt.inputs[1].hide = True
	    #Selection
	    set_curve_tilt.inputs[1].default_value = True
	
	    #node Named Attribute
	    named_attribute = curve_lathe.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute.name = "Named Attribute"
	    named_attribute.data_type = 'FLOAT_VECTOR'
	    #Name
	    named_attribute.inputs[0].default_value = "rot"
	
	    #node Separate XYZ.001
	    separate_xyz_001 = curve_lathe.nodes.new("ShaderNodeSeparateXYZ")
	    separate_xyz_001.name = "Separate XYZ.001"
	    separate_xyz_001.hide = True
	    separate_xyz_001.outputs[0].hide = True
	    separate_xyz_001.outputs[1].hide = True
	
	    #node Group Input.002
	    group_input_002 = curve_lathe.nodes.new("NodeGroupInput")
	    group_input_002.name = "Group Input.002"
	    group_input_002.outputs[0].hide = True
	    group_input_002.outputs[1].hide = True
	    group_input_002.outputs[4].hide = True
	    group_input_002.outputs[5].hide = True
	    group_input_002.outputs[6].hide = True
	
	    #node Separate Components
	    separate_components = curve_lathe.nodes.new("GeometryNodeSeparateComponents")
	    separate_components.name = "Separate Components"
	    separate_components.hide = True
	
	    #node Join Geometry
	    join_geometry = curve_lathe.nodes.new("GeometryNodeJoinGeometry")
	    join_geometry.name = "Join Geometry"
	
	    #node Reroute
	    reroute = curve_lathe.nodes.new("NodeReroute")
	    reroute.name = "Reroute"
	    reroute.socket_idname = "NodeSocketGeometry"
	    #node Reroute.001
	    reroute_001 = curve_lathe.nodes.new("NodeReroute")
	    reroute_001.name = "Reroute.001"
	    reroute_001.socket_idname = "NodeSocketGeometry"
	    #node Reroute.002
	    reroute_002 = curve_lathe.nodes.new("NodeReroute")
	    reroute_002.name = "Reroute.002"
	    reroute_002.socket_idname = "NodeSocketGeometry"
	    #node Reroute.003
	    reroute_003 = curve_lathe.nodes.new("NodeReroute")
	    reroute_003.name = "Reroute.003"
	    reroute_003.socket_idname = "NodeSocketGeometry"
	    #node Reroute.004
	    reroute_004 = curve_lathe.nodes.new("NodeReroute")
	    reroute_004.name = "Reroute.004"
	    reroute_004.socket_idname = "NodeSocketGeometry"
	    #node Reroute.005
	    reroute_005 = curve_lathe.nodes.new("NodeReroute")
	    reroute_005.name = "Reroute.005"
	    reroute_005.socket_idname = "NodeSocketGeometry"
	    #node Reroute.006
	    reroute_006 = curve_lathe.nodes.new("NodeReroute")
	    reroute_006.name = "Reroute.006"
	    reroute_006.socket_idname = "NodeSocketGeometry"
	    #node Reroute.007
	    reroute_007 = curve_lathe.nodes.new("NodeReroute")
	    reroute_007.name = "Reroute.007"
	    reroute_007.socket_idname = "NodeSocketGeometry"
	    #node Reroute.008
	    reroute_008 = curve_lathe.nodes.new("NodeReroute")
	    reroute_008.name = "Reroute.008"
	    reroute_008.socket_idname = "NodeSocketGeometry"
	    #node Reroute.009
	    reroute_009 = curve_lathe.nodes.new("NodeReroute")
	    reroute_009.name = "Reroute.009"
	    reroute_009.socket_idname = "NodeSocketGeometry"
	    #node Lathe Bake
	    lathe_bake = curve_lathe.nodes.new("GeometryNodeBake")
	    lathe_bake.label = "Lathe Bake"
	    lathe_bake.name = "Lathe Bake"
	    lathe_bake.active_index = 0
	    lathe_bake.bake_items.clear()
	    lathe_bake.bake_items.new('GEOMETRY', "Geometry")
	    lathe_bake.bake_items[0].attribute_domain = 'POINT'
	    lathe_bake.inputs[1].hide = True
	    lathe_bake.outputs[1].hide = True
	
	    #node Math
	    math = curve_lathe.nodes.new("ShaderNodeMath")
	    math.name = "Math"
	    math.hide = True
	    math.operation = 'MULTIPLY'
	    math.use_clamp = False
	    math.inputs[2].hide = True
	
	    #node Group Input.001
	    group_input_001 = curve_lathe.nodes.new("NodeGroupInput")
	    group_input_001.name = "Group Input.001"
	    group_input_001.outputs[0].hide = True
	    group_input_001.outputs[1].hide = True
	    group_input_001.outputs[2].hide = True
	    group_input_001.outputs[3].hide = True
	    group_input_001.outputs[6].hide = True
	
	    #node Math.001
	    math_001 = curve_lathe.nodes.new("ShaderNodeMath")
	    math_001.name = "Math.001"
	    math_001.hide = True
	    math_001.operation = 'ADD'
	    math_001.use_clamp = False
	    math_001.inputs[2].hide = True
	
	
	
	
	
	    #Set locations
	    group_output.location = (828.864501953125, 29.58548355102539)
	    group_input.location = (-680.58349609375, 0.0)
	    curve_circle.location = (-478.26416015625, 18.9736328125)
	    curve_to_points.location = (-478.4051513671875, -35.345951080322266)
	    instance_on_points.location = (-278.80810546875, -40.30720901489258)
	    transform_geometry.location = (-480.5835266113281, 83.7481689453125)
	    transform_geometry_001.location = (-278.6121826171875, -89.26876831054688)
	    combine_xyz_002.location = (-280.2974548339844, -127.42269897460938)
	    realize_instances.location = (-113.50007629394531, -38.545616149902344)
	    store_named_attribute_001.location = (43.13922119140625, -15.25759506225586)
	    set_curve_tilt.location = (216.15484619140625, 10.211101531982422)
	    named_attribute.location = (214.66302490234375, 189.1973876953125)
	    separate_xyz_001.location = (213.83294677734375, 56.68062973022461)
	    group_input_002.location = (-284.011474609375, -161.8499755859375)
	    separate_components.location = (-679.2163696289062, 39.14349365234375)
	    join_geometry.location = (465.2765197753906, 30.441936492919922)
	    reroute.location = (-460.0582275390625, 207.8434295654297)
	    reroute_001.location = (-460.7847595214844, 217.25393676757812)
	    reroute_002.location = (-461.7974853515625, 221.8878631591797)
	    reroute_003.location = (-461.7974853515625, 227.47117614746094)
	    reroute_004.location = (-460.0582275390625, 212.64866638183594)
	    reroute_005.location = (324.38916015625, 229.9725341796875)
	    reroute_006.location = (324.38916015625, 224.96649169921875)
	    reroute_007.location = (324.38916015625, 219.9702606201172)
	    reroute_008.location = (324.38916015625, 209.9764404296875)
	    reroute_009.location = (324.38916015625, 214.97438049316406)
	    lathe_bake.location = (648.974609375, 76.5741958618164)
	    math.location = (216.44424438476562, -137.65664672851562)
	    group_input_001.location = (213.44093322753906, -171.75669860839844)
	    math_001.location = (216.44424438476562, -97.52327728271484)
	
	    #Set dimensions
	    group_output.width, group_output.height = 140.0, 100.0
	    group_input.width, group_input.height = 140.0, 100.0
	    curve_circle.width, curve_circle.height = 140.0, 100.0
	    curve_to_points.width, curve_to_points.height = 140.0, 100.0
	    instance_on_points.width, instance_on_points.height = 140.0, 100.0
	    transform_geometry.width, transform_geometry.height = 140.0, 100.0
	    transform_geometry_001.width, transform_geometry_001.height = 140.0, 100.0
	    combine_xyz_002.width, combine_xyz_002.height = 140.0, 100.0
	    realize_instances.width, realize_instances.height = 140.0, 100.0
	    store_named_attribute_001.width, store_named_attribute_001.height = 140.0, 100.0
	    set_curve_tilt.width, set_curve_tilt.height = 140.0, 100.0
	    named_attribute.width, named_attribute.height = 140.0, 100.0
	    separate_xyz_001.width, separate_xyz_001.height = 140.0, 100.0
	    group_input_002.width, group_input_002.height = 140.0, 100.0
	    separate_components.width, separate_components.height = 140.0, 100.0
	    join_geometry.width, join_geometry.height = 140.0, 100.0
	    reroute.width, reroute.height = 10.0, 100.0
	    reroute_001.width, reroute_001.height = 10.0, 100.0
	    reroute_002.width, reroute_002.height = 10.0, 100.0
	    reroute_003.width, reroute_003.height = 10.0, 100.0
	    reroute_004.width, reroute_004.height = 10.0, 100.0
	    reroute_005.width, reroute_005.height = 10.0, 100.0
	    reroute_006.width, reroute_006.height = 10.0, 100.0
	    reroute_007.width, reroute_007.height = 10.0, 100.0
	    reroute_008.width, reroute_008.height = 10.0, 100.0
	    reroute_009.width, reroute_009.height = 10.0, 100.0
	    lathe_bake.width, lathe_bake.height = 140.0, 100.0
	    math.width, math.height = 140.0, 100.0
	    group_input_001.width, group_input_001.height = 140.0, 100.0
	    math_001.width, math_001.height = 140.0, 100.0
	
	    #initialize curve_lathe links
	    #combine_xyz_002.Vector -> transform_geometry_001.Scale
	    curve_lathe.links.new(combine_xyz_002.outputs[0], transform_geometry_001.inputs[3])
	    #curve_to_points.Points -> instance_on_points.Points
	    curve_lathe.links.new(curve_to_points.outputs[0], instance_on_points.inputs[0])
	    #instance_on_points.Instances -> transform_geometry_001.Geometry
	    curve_lathe.links.new(instance_on_points.outputs[0], transform_geometry_001.inputs[0])
	    #curve_circle.Curve -> curve_to_points.Curve
	    curve_lathe.links.new(curve_circle.outputs[0], curve_to_points.inputs[0])
	    #curve_to_points.Rotation -> instance_on_points.Rotation
	    curve_lathe.links.new(curve_to_points.outputs[3], instance_on_points.inputs[5])
	    #realize_instances.Geometry -> store_named_attribute_001.Geometry
	    curve_lathe.links.new(realize_instances.outputs[0], store_named_attribute_001.inputs[0])
	    #transform_geometry_001.Geometry -> realize_instances.Geometry
	    curve_lathe.links.new(transform_geometry_001.outputs[0], realize_instances.inputs[0])
	    #curve_to_points.Rotation -> store_named_attribute_001.Value
	    curve_lathe.links.new(curve_to_points.outputs[3], store_named_attribute_001.inputs[3])
	    #named_attribute.Attribute -> separate_xyz_001.Vector
	    curve_lathe.links.new(named_attribute.outputs[0], separate_xyz_001.inputs[0])
	    #transform_geometry.Geometry -> instance_on_points.Instance
	    curve_lathe.links.new(transform_geometry.outputs[0], instance_on_points.inputs[2])
	    #store_named_attribute_001.Geometry -> set_curve_tilt.Curve
	    curve_lathe.links.new(store_named_attribute_001.outputs[0], set_curve_tilt.inputs[0])
	    #group_input.Count -> curve_to_points.Count
	    curve_lathe.links.new(group_input.outputs[1], curve_to_points.inputs[1])
	    #lathe_bake.Geometry -> group_output.Geometry
	    curve_lathe.links.new(lathe_bake.outputs[0], group_output.inputs[0])
	    #group_input_002.Width -> combine_xyz_002.X
	    curve_lathe.links.new(group_input_002.outputs[2], combine_xyz_002.inputs[0])
	    #group_input_002.Width -> combine_xyz_002.Y
	    curve_lathe.links.new(group_input_002.outputs[2], combine_xyz_002.inputs[1])
	    #group_input_002.Height -> combine_xyz_002.Z
	    curve_lathe.links.new(group_input_002.outputs[3], combine_xyz_002.inputs[2])
	    #group_input.Geometry -> separate_components.Geometry
	    curve_lathe.links.new(group_input.outputs[0], separate_components.inputs[0])
	    #separate_components.Curve -> transform_geometry.Geometry
	    curve_lathe.links.new(separate_components.outputs[1], transform_geometry.inputs[0])
	    #reroute_008.Output -> join_geometry.Geometry
	    curve_lathe.links.new(reroute_008.outputs[0], join_geometry.inputs[0])
	    #separate_components.Instances -> reroute.Input
	    curve_lathe.links.new(separate_components.outputs[5], reroute.inputs[0])
	    #separate_components.Point Cloud -> reroute_001.Input
	    curve_lathe.links.new(separate_components.outputs[3], reroute_001.inputs[0])
	    #separate_components.Grease Pencil -> reroute_002.Input
	    curve_lathe.links.new(separate_components.outputs[2], reroute_002.inputs[0])
	    #separate_components.Mesh -> reroute_003.Input
	    curve_lathe.links.new(separate_components.outputs[0], reroute_003.inputs[0])
	    #separate_components.Volume -> reroute_004.Input
	    curve_lathe.links.new(separate_components.outputs[4], reroute_004.inputs[0])
	    #reroute_003.Output -> reroute_005.Input
	    curve_lathe.links.new(reroute_003.outputs[0], reroute_005.inputs[0])
	    #reroute_002.Output -> reroute_006.Input
	    curve_lathe.links.new(reroute_002.outputs[0], reroute_006.inputs[0])
	    #reroute_001.Output -> reroute_007.Input
	    curve_lathe.links.new(reroute_001.outputs[0], reroute_007.inputs[0])
	    #reroute.Output -> reroute_008.Input
	    curve_lathe.links.new(reroute.outputs[0], reroute_008.inputs[0])
	    #reroute_004.Output -> reroute_009.Input
	    curve_lathe.links.new(reroute_004.outputs[0], reroute_009.inputs[0])
	    #join_geometry.Geometry -> lathe_bake.Geometry
	    curve_lathe.links.new(join_geometry.outputs[0], lathe_bake.inputs[0])
	    #group_input_001.Tilt Align Factor -> math.Value
	    curve_lathe.links.new(group_input_001.outputs[5], math.inputs[1])
	    #group_input_001.Tilt Angle -> math_001.Value
	    curve_lathe.links.new(group_input_001.outputs[4], math_001.inputs[1])
	    #separate_xyz_001.Z -> math.Value
	    curve_lathe.links.new(separate_xyz_001.outputs[2], math.inputs[0])
	    #math.Value -> math_001.Value
	    curve_lathe.links.new(math.outputs[0], math_001.inputs[0])
	    #math_001.Value -> set_curve_tilt.Tilt
	    curve_lathe.links.new(math_001.outputs[0], set_curve_tilt.inputs[2])
	    #reroute_009.Output -> join_geometry.Geometry
	    curve_lathe.links.new(reroute_009.outputs[0], join_geometry.inputs[0])
	    #reroute_007.Output -> join_geometry.Geometry
	    curve_lathe.links.new(reroute_007.outputs[0], join_geometry.inputs[0])
	    #reroute_006.Output -> join_geometry.Geometry
	    curve_lathe.links.new(reroute_006.outputs[0], join_geometry.inputs[0])
	    #reroute_005.Output -> join_geometry.Geometry
	    curve_lathe.links.new(reroute_005.outputs[0], join_geometry.inputs[0])
	    #set_curve_tilt.Curve -> join_geometry.Geometry
	    curve_lathe.links.new(set_curve_tilt.outputs[0], join_geometry.inputs[0])
	    return curve_lathe
	return curve_lathe_node_group()

	

	
