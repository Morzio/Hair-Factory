import bpy, mathutils

def node():
	#initialize hair_to_mesh_grid node group
	def hair_to_mesh_grid_node_group():
	    hair_to_mesh_grid = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "HAIR_TO_MESH_GRID")
	
	    hair_to_mesh_grid.color_tag = 'NONE'
	    hair_to_mesh_grid.description = "Convert Hair to grid mesh."
	    hair_to_mesh_grid.default_group_node_width = 140
	    
	
	    hair_to_mesh_grid.is_modifier = True
	
	    #hair_to_mesh_grid interface
	    #Socket Geometry
	    geometry_socket = hair_to_mesh_grid.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket.attribute_domain = 'POINT'
	    geometry_socket.description = "Mesh hair."
	
	    #Socket Geometry
	    geometry_socket_1 = hair_to_mesh_grid.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_1.attribute_domain = 'POINT'
	    geometry_socket_1.description = "Hair Curve."
	
	    #Socket Count
	    count_socket = hair_to_mesh_grid.interface.new_socket(name = "Count", in_out='INPUT', socket_type = 'NodeSocketInt')
	    count_socket.default_value = 10
	    count_socket.min_value = 2
	    count_socket.max_value = 1000
	    count_socket.subtype = 'NONE'
	    count_socket.attribute_domain = 'POINT'
	    count_socket.description = "Amount of columns based on curve count."
	
	    #Socket Control Points
	    control_points_socket = hair_to_mesh_grid.interface.new_socket(name = "Control Points", in_out='INPUT', socket_type = 'NodeSocketInt')
	    control_points_socket.default_value = 10
	    control_points_socket.min_value = 2
	    control_points_socket.max_value = 1000
	    control_points_socket.subtype = 'NONE'
	    control_points_socket.attribute_domain = 'POINT'
	    control_points_socket.description = "Amount of rows based on point count."
	
	    #Socket Material
	    material_socket = hair_to_mesh_grid.interface.new_socket(name = "Material", in_out='INPUT', socket_type = 'NodeSocketMaterial')
	    material_socket.attribute_domain = 'POINT'
	    material_socket.description = "Material for mesh."
	
	    #Socket Shade Smooth
	    shade_smooth_socket = hair_to_mesh_grid.interface.new_socket(name = "Shade Smooth", in_out='INPUT', socket_type = 'NodeSocketBool')
	    shade_smooth_socket.default_value = True
	    shade_smooth_socket.attribute_domain = 'POINT'
	    shade_smooth_socket.description = "Mesh smooth shading."
	
	
	    #initialize hair_to_mesh_grid nodes
	    #node Group Input
	    group_input = hair_to_mesh_grid.nodes.new("NodeGroupInput")
	    group_input.name = "Group Input"
	    group_input.outputs[1].hide = True
	    group_input.outputs[2].hide = True
	    group_input.outputs[3].hide = True
	    group_input.outputs[4].hide = True
	    group_input.outputs[5].hide = True
	
	    #node Group Output
	    group_output = hair_to_mesh_grid.nodes.new("NodeGroupOutput")
	    group_output.name = "Group Output"
	    group_output.is_active_output = True
	    group_output.inputs[1].hide = True
	
	    #node Sample Index
	    sample_index = hair_to_mesh_grid.nodes.new("GeometryNodeSampleIndex")
	    sample_index.name = "Sample Index"
	    sample_index.hide = True
	    sample_index.clamp = False
	    sample_index.data_type = 'FLOAT_VECTOR'
	    sample_index.domain = 'POINT'
	
	    #node Index
	    index = hair_to_mesh_grid.nodes.new("GeometryNodeInputIndex")
	    index.name = "Index"
	
	    #node Position
	    position = hair_to_mesh_grid.nodes.new("GeometryNodeInputPosition")
	    position.name = "Position"
	
	    #node Grid
	    grid = hair_to_mesh_grid.nodes.new("GeometryNodeMeshGrid")
	    grid.name = "Grid"
	    grid.hide = True
	    grid.inputs[0].hide = True
	    grid.inputs[1].hide = True
	    #Size X
	    grid.inputs[0].default_value = 1.0
	    #Size Y
	    grid.inputs[1].default_value = 1.0
	
	    #node Set Position
	    set_position = hair_to_mesh_grid.nodes.new("GeometryNodeSetPosition")
	    set_position.name = "Set Position"
	    set_position.hide = True
	    set_position.inputs[1].hide = True
	    set_position.inputs[3].hide = True
	    #Selection
	    set_position.inputs[1].default_value = True
	    #Offset
	    set_position.inputs[3].default_value = (0.0, 0.0, 0.0)
	
	    #node Group Input.001
	    group_input_001 = hair_to_mesh_grid.nodes.new("NodeGroupInput")
	    group_input_001.name = "Group Input.001"
	    group_input_001.outputs[0].hide = True
	    group_input_001.outputs[3].hide = True
	    group_input_001.outputs[4].hide = True
	    group_input_001.outputs[5].hide = True
	
	    #node Set Material
	    set_material = hair_to_mesh_grid.nodes.new("GeometryNodeSetMaterial")
	    set_material.name = "Set Material"
	    set_material.hide = True
	    set_material.inputs[1].hide = True
	    #Selection
	    set_material.inputs[1].default_value = True
	
	    #node Group Input.002
	    group_input_002 = hair_to_mesh_grid.nodes.new("NodeGroupInput")
	    group_input_002.name = "Group Input.002"
	    group_input_002.outputs[0].hide = True
	    group_input_002.outputs[1].hide = True
	    group_input_002.outputs[2].hide = True
	    group_input_002.outputs[5].hide = True
	
	    #node Store Named Attribute
	    store_named_attribute = hair_to_mesh_grid.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute.name = "Store Named Attribute"
	    store_named_attribute.data_type = 'FLOAT2'
	    store_named_attribute.domain = 'CORNER'
	    #Selection
	    store_named_attribute.inputs[1].default_value = True
	    #Name
	    store_named_attribute.inputs[2].default_value = "UVMap"
	
	    #node Separate Components
	    separate_components = hair_to_mesh_grid.nodes.new("GeometryNodeSeparateComponents")
	    separate_components.name = "Separate Components"
	    separate_components.hide = True
	
	    #node Join Geometry
	    join_geometry = hair_to_mesh_grid.nodes.new("GeometryNodeJoinGeometry")
	    join_geometry.name = "Join Geometry"
	
	    #node Reroute
	    reroute = hair_to_mesh_grid.nodes.new("NodeReroute")
	    reroute.name = "Reroute"
	    reroute.socket_idname = "NodeSocketGeometry"
	    #node Reroute.001
	    reroute_001 = hair_to_mesh_grid.nodes.new("NodeReroute")
	    reroute_001.name = "Reroute.001"
	    reroute_001.socket_idname = "NodeSocketGeometry"
	    #node Reroute.002
	    reroute_002 = hair_to_mesh_grid.nodes.new("NodeReroute")
	    reroute_002.name = "Reroute.002"
	    reroute_002.socket_idname = "NodeSocketGeometry"
	    #node Reroute.003
	    reroute_003 = hair_to_mesh_grid.nodes.new("NodeReroute")
	    reroute_003.name = "Reroute.003"
	    reroute_003.socket_idname = "NodeSocketGeometry"
	    #node Reroute.004
	    reroute_004 = hair_to_mesh_grid.nodes.new("NodeReroute")
	    reroute_004.name = "Reroute.004"
	    reroute_004.socket_idname = "NodeSocketGeometry"
	    #node Reroute.005
	    reroute_005 = hair_to_mesh_grid.nodes.new("NodeReroute")
	    reroute_005.name = "Reroute.005"
	    reroute_005.socket_idname = "NodeSocketGeometry"
	    #node Reroute.006
	    reroute_006 = hair_to_mesh_grid.nodes.new("NodeReroute")
	    reroute_006.name = "Reroute.006"
	    reroute_006.socket_idname = "NodeSocketGeometry"
	    #node Reroute.007
	    reroute_007 = hair_to_mesh_grid.nodes.new("NodeReroute")
	    reroute_007.name = "Reroute.007"
	    reroute_007.socket_idname = "NodeSocketGeometry"
	    #node Reroute.008
	    reroute_008 = hair_to_mesh_grid.nodes.new("NodeReroute")
	    reroute_008.name = "Reroute.008"
	    reroute_008.socket_idname = "NodeSocketGeometry"
	    #node Reroute.009
	    reroute_009 = hair_to_mesh_grid.nodes.new("NodeReroute")
	    reroute_009.name = "Reroute.009"
	    reroute_009.socket_idname = "NodeSocketGeometry"
	    #node Separate XYZ
	    separate_xyz = hair_to_mesh_grid.nodes.new("ShaderNodeSeparateXYZ")
	    separate_xyz.name = "Separate XYZ"
	    separate_xyz.hide = True
	    separate_xyz.outputs[2].hide = True
	
	    #node Combine XYZ
	    combine_xyz = hair_to_mesh_grid.nodes.new("ShaderNodeCombineXYZ")
	    combine_xyz.name = "Combine XYZ"
	    combine_xyz.hide = True
	    combine_xyz.inputs[2].hide = True
	    #Z
	    combine_xyz.inputs[2].default_value = 0.0
	
	    #node Set Shade Smooth
	    set_shade_smooth = hair_to_mesh_grid.nodes.new("GeometryNodeSetShadeSmooth")
	    set_shade_smooth.name = "Set Shade Smooth"
	    set_shade_smooth.domain = 'FACE'
	    set_shade_smooth.inputs[1].hide = True
	    #Selection
	    set_shade_smooth.inputs[1].default_value = True
	
	    #node Hair to Mesh Grid Bake
	    hair_to_mesh_grid_bake = hair_to_mesh_grid.nodes.new("GeometryNodeBake")
	    hair_to_mesh_grid_bake.label = "Hair to Mesh Grid Bake"
	    hair_to_mesh_grid_bake.name = "Hair to Mesh Grid Bake"
	    hair_to_mesh_grid_bake.active_index = 0
	    hair_to_mesh_grid_bake.bake_items.clear()
	    hair_to_mesh_grid_bake.bake_items.new('GEOMETRY', "Geometry")
	    hair_to_mesh_grid_bake.bake_items[0].attribute_domain = 'POINT'
	    hair_to_mesh_grid_bake.inputs[1].hide = True
	    hair_to_mesh_grid_bake.outputs[1].hide = True
	
	
	
	
	
	    #Set locations
	    group_input.location = (-340.0, 0.0)
	    group_output.location = (1118.1949462890625, 9.460579872131348)
	    sample_index.location = (-170.96640014648438, -36.942352294921875)
	    index.location = (-336.3201904296875, -112.52987670898438)
	    position.location = (-337.41265869140625, -58.90559387207031)
	    grid.location = (-10.36965560913086, 24.21142578125)
	    set_position.location = (-6.7076416015625, -29.73076629638672)
	    group_input_001.location = (-172.19847106933594, 49.1075439453125)
	    set_material.location = (361.541015625, -87.62693786621094)
	    group_input_002.location = (359.4872741699219, -118.33622741699219)
	    store_named_attribute.location = (173.0, 70.37303924560547)
	    separate_components.location = (-340.2942810058594, 38.6043701171875)
	    join_geometry.location = (749.2598266601562, 9.17719841003418)
	    reroute.location = (-137.10089111328125, 154.97103881835938)
	    reroute_001.location = (-137.10089111328125, 160.07699584960938)
	    reroute_002.location = (-137.10089111328125, 165.53477478027344)
	    reroute_003.location = (-137.10089111328125, 150.0106658935547)
	    reroute_004.location = (-136.4912109375, 145.41824340820312)
	    reroute_005.location = (588.6714477539062, 166.9800567626953)
	    reroute_006.location = (588.6714477539062, 161.97410583496094)
	    reroute_007.location = (588.6714477539062, 146.97854614257812)
	    reroute_008.location = (588.6714477539062, 151.97328186035156)
	    reroute_009.location = (588.6714477539062, 156.9727325439453)
	    separate_xyz.location = (-7.538963317871094, -66.33451843261719)
	    combine_xyz.location = (-8.631401062011719, -102.44883728027344)
	    set_shade_smooth.location = (542.223876953125, -13.132492065429688)
	    hair_to_mesh_grid_bake.location = (937.9362182617188, 56.40458679199219)
	
	    #Set dimensions
	    group_input.width, group_input.height = 140.0, 100.0
	    group_output.width, group_output.height = 140.0, 100.0
	    sample_index.width, sample_index.height = 140.0, 100.0
	    index.width, index.height = 140.0, 100.0
	    position.width, position.height = 140.0, 100.0
	    grid.width, grid.height = 140.0, 100.0
	    set_position.width, set_position.height = 140.0, 100.0
	    group_input_001.width, group_input_001.height = 140.0, 100.0
	    set_material.width, set_material.height = 140.0, 100.0
	    group_input_002.width, group_input_002.height = 140.0, 100.0
	    store_named_attribute.width, store_named_attribute.height = 140.0, 100.0
	    separate_components.width, separate_components.height = 140.0, 100.0
	    join_geometry.width, join_geometry.height = 140.0, 100.0
	    reroute.width, reroute.height = 10.0, 100.0
	    reroute_001.width, reroute_001.height = 10.0, 100.0
	    reroute_002.width, reroute_002.height = 10.0, 100.0
	    reroute_003.width, reroute_003.height = 10.0, 100.0
	    reroute_004.width, reroute_004.height = 10.0, 100.0
	    reroute_005.width, reroute_005.height = 10.0, 100.0
	    reroute_006.width, reroute_006.height = 10.0, 100.0
	    reroute_007.width, reroute_007.height = 10.0, 100.0
	    reroute_008.width, reroute_008.height = 10.0, 100.0
	    reroute_009.width, reroute_009.height = 10.0, 100.0
	    separate_xyz.width, separate_xyz.height = 140.0, 100.0
	    combine_xyz.width, combine_xyz.height = 140.0, 100.0
	    set_shade_smooth.width, set_shade_smooth.height = 140.0, 100.0
	    hair_to_mesh_grid_bake.width, hair_to_mesh_grid_bake.height = 140.0, 100.0
	
	    #initialize hair_to_mesh_grid links
	    #index.Index -> sample_index.Index
	    hair_to_mesh_grid.links.new(index.outputs[0], sample_index.inputs[2])
	    #position.Position -> sample_index.Value
	    hair_to_mesh_grid.links.new(position.outputs[0], sample_index.inputs[1])
	    #grid.Mesh -> set_position.Geometry
	    hair_to_mesh_grid.links.new(grid.outputs[0], set_position.inputs[0])
	    #sample_index.Value -> set_position.Position
	    hair_to_mesh_grid.links.new(sample_index.outputs[0], set_position.inputs[2])
	    #group_input_001.Count -> grid.Vertices X
	    hair_to_mesh_grid.links.new(group_input_001.outputs[1], grid.inputs[2])
	    #group_input_001.Control Points -> grid.Vertices Y
	    hair_to_mesh_grid.links.new(group_input_001.outputs[2], grid.inputs[3])
	    #store_named_attribute.Geometry -> set_material.Geometry
	    hair_to_mesh_grid.links.new(store_named_attribute.outputs[0], set_material.inputs[0])
	    #group_input_002.Material -> set_material.Material
	    hair_to_mesh_grid.links.new(group_input_002.outputs[3], set_material.inputs[2])
	    #set_position.Geometry -> store_named_attribute.Geometry
	    hair_to_mesh_grid.links.new(set_position.outputs[0], store_named_attribute.inputs[0])
	    #group_input.Geometry -> separate_components.Geometry
	    hair_to_mesh_grid.links.new(group_input.outputs[0], separate_components.inputs[0])
	    #separate_components.Curve -> sample_index.Geometry
	    hair_to_mesh_grid.links.new(separate_components.outputs[1], sample_index.inputs[0])
	    #reroute_007.Output -> join_geometry.Geometry
	    hair_to_mesh_grid.links.new(reroute_007.outputs[0], join_geometry.inputs[0])
	    #separate_components.Point Cloud -> reroute.Input
	    hair_to_mesh_grid.links.new(separate_components.outputs[3], reroute.inputs[0])
	    #separate_components.Grease Pencil -> reroute_001.Input
	    hair_to_mesh_grid.links.new(separate_components.outputs[2], reroute_001.inputs[0])
	    #separate_components.Mesh -> reroute_002.Input
	    hair_to_mesh_grid.links.new(separate_components.outputs[0], reroute_002.inputs[0])
	    #separate_components.Volume -> reroute_003.Input
	    hair_to_mesh_grid.links.new(separate_components.outputs[4], reroute_003.inputs[0])
	    #separate_components.Instances -> reroute_004.Input
	    hair_to_mesh_grid.links.new(separate_components.outputs[5], reroute_004.inputs[0])
	    #reroute_002.Output -> reroute_005.Input
	    hair_to_mesh_grid.links.new(reroute_002.outputs[0], reroute_005.inputs[0])
	    #reroute_001.Output -> reroute_006.Input
	    hair_to_mesh_grid.links.new(reroute_001.outputs[0], reroute_006.inputs[0])
	    #reroute_004.Output -> reroute_007.Input
	    hair_to_mesh_grid.links.new(reroute_004.outputs[0], reroute_007.inputs[0])
	    #reroute_003.Output -> reroute_008.Input
	    hair_to_mesh_grid.links.new(reroute_003.outputs[0], reroute_008.inputs[0])
	    #reroute.Output -> reroute_009.Input
	    hair_to_mesh_grid.links.new(reroute.outputs[0], reroute_009.inputs[0])
	    #hair_to_mesh_grid_bake.Geometry -> group_output.Geometry
	    hair_to_mesh_grid.links.new(hair_to_mesh_grid_bake.outputs[0], group_output.inputs[0])
	    #grid.UV Map -> separate_xyz.Vector
	    hair_to_mesh_grid.links.new(grid.outputs[1], separate_xyz.inputs[0])
	    #separate_xyz.Y -> combine_xyz.X
	    hair_to_mesh_grid.links.new(separate_xyz.outputs[1], combine_xyz.inputs[0])
	    #separate_xyz.X -> combine_xyz.Y
	    hair_to_mesh_grid.links.new(separate_xyz.outputs[0], combine_xyz.inputs[1])
	    #combine_xyz.Vector -> store_named_attribute.Value
	    hair_to_mesh_grid.links.new(combine_xyz.outputs[0], store_named_attribute.inputs[3])
	    #set_material.Geometry -> set_shade_smooth.Geometry
	    hair_to_mesh_grid.links.new(set_material.outputs[0], set_shade_smooth.inputs[0])
	    #group_input_002.Shade Smooth -> set_shade_smooth.Shade Smooth
	    hair_to_mesh_grid.links.new(group_input_002.outputs[4], set_shade_smooth.inputs[2])
	    #join_geometry.Geometry -> hair_to_mesh_grid_bake.Geometry
	    hair_to_mesh_grid.links.new(join_geometry.outputs[0], hair_to_mesh_grid_bake.inputs[0])
	    #reroute_008.Output -> join_geometry.Geometry
	    hair_to_mesh_grid.links.new(reroute_008.outputs[0], join_geometry.inputs[0])
	    #reroute_009.Output -> join_geometry.Geometry
	    hair_to_mesh_grid.links.new(reroute_009.outputs[0], join_geometry.inputs[0])
	    #reroute_006.Output -> join_geometry.Geometry
	    hair_to_mesh_grid.links.new(reroute_006.outputs[0], join_geometry.inputs[0])
	    #reroute_005.Output -> join_geometry.Geometry
	    hair_to_mesh_grid.links.new(reroute_005.outputs[0], join_geometry.inputs[0])
	    #set_shade_smooth.Geometry -> join_geometry.Geometry
	    hair_to_mesh_grid.links.new(set_shade_smooth.outputs[0], join_geometry.inputs[0])
	    return hair_to_mesh_grid
	return hair_to_mesh_grid_node_group()

	

	
