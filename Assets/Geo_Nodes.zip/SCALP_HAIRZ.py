import bpy, mathutils

def node():
	#initialize curve_geometry_priority node group
	def curve_geometry_priority_node_group():
	    curve_geometry_priority = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Curve Geometry Priority")
	
	    curve_geometry_priority.color_tag = 'NONE'
	    curve_geometry_priority.description = ""
	    curve_geometry_priority.default_group_node_width = 140
	    
	
	
	    #curve_geometry_priority interface
	    #Socket Geometry
	    geometry_socket = curve_geometry_priority.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket.attribute_domain = 'POINT'
	
	    #Socket Geometry
	    geometry_socket_1 = curve_geometry_priority.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_1.attribute_domain = 'POINT'
	
	    #Socket Object
	    object_socket = curve_geometry_priority.interface.new_socket(name = "Object", in_out='INPUT', socket_type = 'NodeSocketObject')
	    object_socket.attribute_domain = 'POINT'
	
	
	    #initialize curve_geometry_priority nodes
	    #node Group Output
	    group_output = curve_geometry_priority.nodes.new("NodeGroupOutput")
	    group_output.name = "Group Output"
	    group_output.is_active_output = True
	
	    #node Group Input
	    group_input = curve_geometry_priority.nodes.new("NodeGroupInput")
	    group_input.name = "Group Input"
	
	    #node Object Info
	    object_info = curve_geometry_priority.nodes.new("GeometryNodeObjectInfo")
	    object_info.name = "Object Info"
	    object_info.hide = True
	    object_info.transform_space = 'RELATIVE'
	    object_info.inputs[1].hide = True
	    object_info.outputs[0].hide = True
	    object_info.outputs[1].hide = True
	    object_info.outputs[2].hide = True
	    object_info.outputs[3].hide = True
	    #As Instance
	    object_info.inputs[1].default_value = False
	
	    #node Switch.001
	    switch_001 = curve_geometry_priority.nodes.new("GeometryNodeSwitch")
	    switch_001.name = "Switch.001"
	    switch_001.hide = True
	    switch_001.input_type = 'GEOMETRY'
	
	    #node Domain Size
	    domain_size = curve_geometry_priority.nodes.new("GeometryNodeAttributeDomainSize")
	    domain_size.name = "Domain Size"
	    domain_size.hide = True
	    domain_size.component = 'CURVE'
	    domain_size.outputs[1].hide = True
	    domain_size.outputs[2].hide = True
	    domain_size.outputs[3].hide = True
	    domain_size.outputs[4].hide = True
	    domain_size.outputs[5].hide = True
	    domain_size.outputs[6].hide = True
	
	    #node Compare.002
	    compare_002 = curve_geometry_priority.nodes.new("FunctionNodeCompare")
	    compare_002.name = "Compare.002"
	    compare_002.hide = True
	    compare_002.data_type = 'FLOAT'
	    compare_002.mode = 'ELEMENT'
	    compare_002.operation = 'EQUAL'
	    #B
	    compare_002.inputs[1].default_value = 0.0
	    #Epsilon
	    compare_002.inputs[12].default_value = 0.0
	
	    #node Reroute
	    reroute = curve_geometry_priority.nodes.new("NodeReroute")
	    reroute.name = "Reroute"
	    reroute.socket_idname = "NodeSocketGeometry"
	
	
	
	
	    #Set locations
	    group_output.location = (331.4979553222656, 0.0)
	    group_input.location = (-341.49798583984375, 0.0)
	    object_info.location = (-141.49798583984375, -48.543128967285156)
	    switch_001.location = (141.49795532226562, -25.427536010742188)
	    domain_size.location = (-37.58526611328125, 25.427532196044922)
	    compare_002.location = (138.00750732421875, 13.003349304199219)
	    reroute.location = (-98.26019287109375, -34.39356231689453)
	
	    #Set dimensions
	    group_output.width, group_output.height = 140.0, 100.0
	    group_input.width, group_input.height = 140.0, 100.0
	    object_info.width, object_info.height = 140.0, 100.0
	    switch_001.width, switch_001.height = 140.0, 100.0
	    domain_size.width, domain_size.height = 140.0, 100.0
	    compare_002.width, compare_002.height = 140.0, 100.0
	    reroute.width, reroute.height = 100.0, 100.0
	
	    #initialize curve_geometry_priority links
	    #reroute.Output -> domain_size.Geometry
	    curve_geometry_priority.links.new(reroute.outputs[0], domain_size.inputs[0])
	    #domain_size.Point Count -> compare_002.A
	    curve_geometry_priority.links.new(domain_size.outputs[0], compare_002.inputs[0])
	    #compare_002.Result -> switch_001.Switch
	    curve_geometry_priority.links.new(compare_002.outputs[0], switch_001.inputs[0])
	    #object_info.Geometry -> switch_001.True
	    curve_geometry_priority.links.new(object_info.outputs[4], switch_001.inputs[2])
	    #reroute.Output -> switch_001.False
	    curve_geometry_priority.links.new(reroute.outputs[0], switch_001.inputs[1])
	    #group_input.Object -> object_info.Object
	    curve_geometry_priority.links.new(group_input.outputs[1], object_info.inputs[0])
	    #group_input.Geometry -> reroute.Input
	    curve_geometry_priority.links.new(group_input.outputs[0], reroute.inputs[0])
	    #switch_001.Output -> group_output.Geometry
	    curve_geometry_priority.links.new(switch_001.outputs[0], group_output.inputs[0])
	    return curve_geometry_priority
	
	curve_geometry_priority = curve_geometry_priority_node_group()
	
	#initialize mesh_geometry_priority node group
	def mesh_geometry_priority_node_group():
	    mesh_geometry_priority = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Mesh Geometry Priority")
	
	    mesh_geometry_priority.color_tag = 'NONE'
	    mesh_geometry_priority.description = ""
	    mesh_geometry_priority.default_group_node_width = 140
	    
	
	
	    #mesh_geometry_priority interface
	    #Socket Geometry
	    geometry_socket_2 = mesh_geometry_priority.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_2.attribute_domain = 'POINT'
	
	    #Socket Geometry
	    geometry_socket_3 = mesh_geometry_priority.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_3.attribute_domain = 'POINT'
	
	    #Socket Object
	    object_socket_1 = mesh_geometry_priority.interface.new_socket(name = "Object", in_out='INPUT', socket_type = 'NodeSocketObject')
	    object_socket_1.attribute_domain = 'POINT'
	
	
	    #initialize mesh_geometry_priority nodes
	    #node Group Output
	    group_output_1 = mesh_geometry_priority.nodes.new("NodeGroupOutput")
	    group_output_1.name = "Group Output"
	    group_output_1.is_active_output = True
	
	    #node Group Input
	    group_input_1 = mesh_geometry_priority.nodes.new("NodeGroupInput")
	    group_input_1.name = "Group Input"
	
	    #node Object Info
	    object_info_1 = mesh_geometry_priority.nodes.new("GeometryNodeObjectInfo")
	    object_info_1.name = "Object Info"
	    object_info_1.hide = True
	    object_info_1.transform_space = 'RELATIVE'
	    object_info_1.inputs[1].hide = True
	    object_info_1.outputs[0].hide = True
	    object_info_1.outputs[1].hide = True
	    object_info_1.outputs[2].hide = True
	    object_info_1.outputs[3].hide = True
	    #As Instance
	    object_info_1.inputs[1].default_value = False
	
	    #node Switch.001
	    switch_001_1 = mesh_geometry_priority.nodes.new("GeometryNodeSwitch")
	    switch_001_1.name = "Switch.001"
	    switch_001_1.hide = True
	    switch_001_1.input_type = 'GEOMETRY'
	
	    #node Domain Size
	    domain_size_1 = mesh_geometry_priority.nodes.new("GeometryNodeAttributeDomainSize")
	    domain_size_1.name = "Domain Size"
	    domain_size_1.hide = True
	    domain_size_1.component = 'MESH'
	    domain_size_1.outputs[1].hide = True
	    domain_size_1.outputs[2].hide = True
	    domain_size_1.outputs[3].hide = True
	    domain_size_1.outputs[4].hide = True
	    domain_size_1.outputs[5].hide = True
	    domain_size_1.outputs[6].hide = True
	
	    #node Compare.002
	    compare_002_1 = mesh_geometry_priority.nodes.new("FunctionNodeCompare")
	    compare_002_1.name = "Compare.002"
	    compare_002_1.hide = True
	    compare_002_1.data_type = 'FLOAT'
	    compare_002_1.mode = 'ELEMENT'
	    compare_002_1.operation = 'EQUAL'
	    #B
	    compare_002_1.inputs[1].default_value = 0.0
	    #Epsilon
	    compare_002_1.inputs[12].default_value = 0.0
	
	    #node Reroute
	    reroute_1 = mesh_geometry_priority.nodes.new("NodeReroute")
	    reroute_1.name = "Reroute"
	    reroute_1.socket_idname = "NodeSocketGeometry"
	
	
	
	
	    #Set locations
	    group_output_1.location = (331.4979553222656, 0.0)
	    group_input_1.location = (-341.49798583984375, 0.0)
	    object_info_1.location = (-141.49798583984375, -48.543128967285156)
	    switch_001_1.location = (141.49795532226562, -25.427536010742188)
	    domain_size_1.location = (-37.58526611328125, 25.427532196044922)
	    compare_002_1.location = (138.00750732421875, 13.003349304199219)
	    reroute_1.location = (-98.26019287109375, -34.39356231689453)
	
	    #Set dimensions
	    group_output_1.width, group_output_1.height = 140.0, 100.0
	    group_input_1.width, group_input_1.height = 140.0, 100.0
	    object_info_1.width, object_info_1.height = 140.0, 100.0
	    switch_001_1.width, switch_001_1.height = 140.0, 100.0
	    domain_size_1.width, domain_size_1.height = 140.0, 100.0
	    compare_002_1.width, compare_002_1.height = 140.0, 100.0
	    reroute_1.width, reroute_1.height = 100.0, 100.0
	
	    #initialize mesh_geometry_priority links
	    #reroute_1.Output -> domain_size_1.Geometry
	    mesh_geometry_priority.links.new(reroute_1.outputs[0], domain_size_1.inputs[0])
	    #domain_size_1.Point Count -> compare_002_1.A
	    mesh_geometry_priority.links.new(domain_size_1.outputs[0], compare_002_1.inputs[0])
	    #compare_002_1.Result -> switch_001_1.Switch
	    mesh_geometry_priority.links.new(compare_002_1.outputs[0], switch_001_1.inputs[0])
	    #object_info_1.Geometry -> switch_001_1.True
	    mesh_geometry_priority.links.new(object_info_1.outputs[4], switch_001_1.inputs[2])
	    #reroute_1.Output -> switch_001_1.False
	    mesh_geometry_priority.links.new(reroute_1.outputs[0], switch_001_1.inputs[1])
	    #group_input_1.Object -> object_info_1.Object
	    mesh_geometry_priority.links.new(group_input_1.outputs[1], object_info_1.inputs[0])
	    #group_input_1.Geometry -> reroute_1.Input
	    mesh_geometry_priority.links.new(group_input_1.outputs[0], reroute_1.inputs[0])
	    #switch_001_1.Output -> group_output_1.Geometry
	    mesh_geometry_priority.links.new(switch_001_1.outputs[0], group_output_1.inputs[0])
	    return mesh_geometry_priority
	
	mesh_geometry_priority = mesh_geometry_priority_node_group()
	
	#initialize curve_root node group
	def curve_root_node_group():
	    curve_root = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Curve Root")
	
	    curve_root.color_tag = 'NONE'
	    curve_root.description = "Reads information about each curve's root point"
	    curve_root.default_group_node_width = 140
	    
	
	
	    #curve_root interface
	    #Socket Root Selection
	    root_selection_socket = curve_root.interface.new_socket(name = "Root Selection", in_out='OUTPUT', socket_type = 'NodeSocketBool')
	    root_selection_socket.default_value = False
	    root_selection_socket.attribute_domain = 'POINT'
	    root_selection_socket.description = "Boolean selection of curve root points"
	
	    #Socket Root Position
	    root_position_socket = curve_root.interface.new_socket(name = "Root Position", in_out='OUTPUT', socket_type = 'NodeSocketVector')
	    root_position_socket.default_value = (0.0, 0.0, 0.0)
	    root_position_socket.min_value = -3.4028234663852886e+38
	    root_position_socket.max_value = 3.4028234663852886e+38
	    root_position_socket.subtype = 'NONE'
	    root_position_socket.attribute_domain = 'CURVE'
	    root_position_socket.description = "Position of the root point of a curve"
	
	    #Socket Root Direction
	    root_direction_socket = curve_root.interface.new_socket(name = "Root Direction", in_out='OUTPUT', socket_type = 'NodeSocketVector')
	    root_direction_socket.default_value = (0.0, 0.0, 0.0)
	    root_direction_socket.min_value = -3.4028234663852886e+38
	    root_direction_socket.max_value = 3.4028234663852886e+38
	    root_direction_socket.subtype = 'NONE'
	    root_direction_socket.attribute_domain = 'CURVE'
	    root_direction_socket.description = "Direction of the root segment of a curve"
	
	    #Socket Root Index
	    root_index_socket = curve_root.interface.new_socket(name = "Root Index", in_out='OUTPUT', socket_type = 'NodeSocketInt')
	    root_index_socket.default_value = 0
	    root_index_socket.min_value = -2147483648
	    root_index_socket.max_value = 2147483647
	    root_index_socket.subtype = 'NONE'
	    root_index_socket.attribute_domain = 'CURVE'
	    root_index_socket.description = "Index of the root point of a curve"
	
	
	    #initialize curve_root nodes
	    #node Position.002
	    position_002 = curve_root.nodes.new("GeometryNodeInputPosition")
	    position_002.name = "Position.002"
	
	    #node Interpolate Domain
	    interpolate_domain = curve_root.nodes.new("GeometryNodeFieldOnDomain")
	    interpolate_domain.name = "Interpolate Domain"
	    interpolate_domain.data_type = 'INT'
	    interpolate_domain.domain = 'CURVE'
	
	    #node Field at Index.003
	    field_at_index_003 = curve_root.nodes.new("GeometryNodeFieldAtIndex")
	    field_at_index_003.name = "Field at Index.003"
	    field_at_index_003.data_type = 'FLOAT_VECTOR'
	    field_at_index_003.domain = 'POINT'
	
	    #node Interpolate Domain.001
	    interpolate_domain_001 = curve_root.nodes.new("GeometryNodeFieldOnDomain")
	    interpolate_domain_001.name = "Interpolate Domain.001"
	    interpolate_domain_001.data_type = 'FLOAT_VECTOR'
	    interpolate_domain_001.domain = 'CURVE'
	
	    #node Curve Tangent
	    curve_tangent = curve_root.nodes.new("GeometryNodeInputTangent")
	    curve_tangent.name = "Curve Tangent"
	
	    #node Endpoint Selection
	    endpoint_selection = curve_root.nodes.new("GeometryNodeCurveEndpointSelection")
	    endpoint_selection.name = "Endpoint Selection"
	    #Start Size
	    endpoint_selection.inputs[0].default_value = 1
	    #End Size
	    endpoint_selection.inputs[1].default_value = 0
	
	    #node Field at Index.004
	    field_at_index_004 = curve_root.nodes.new("GeometryNodeFieldAtIndex")
	    field_at_index_004.name = "Field at Index.004"
	    field_at_index_004.data_type = 'FLOAT_VECTOR'
	    field_at_index_004.domain = 'POINT'
	
	    #node Interpolate Domain.002
	    interpolate_domain_002 = curve_root.nodes.new("GeometryNodeFieldOnDomain")
	    interpolate_domain_002.name = "Interpolate Domain.002"
	    interpolate_domain_002.data_type = 'FLOAT_VECTOR'
	    interpolate_domain_002.domain = 'CURVE'
	
	    #node Group Output
	    group_output_2 = curve_root.nodes.new("NodeGroupOutput")
	    group_output_2.name = "Group Output"
	    group_output_2.is_active_output = True
	
	    #node Points of Curve
	    points_of_curve = curve_root.nodes.new("GeometryNodePointsOfCurve")
	    points_of_curve.name = "Points of Curve"
	    points_of_curve.inputs[0].hide = True
	    points_of_curve.inputs[1].hide = True
	    points_of_curve.outputs[1].hide = True
	    #Curve Index
	    points_of_curve.inputs[0].default_value = 0
	    #Weights
	    points_of_curve.inputs[1].default_value = 0.0
	    #Sort Index
	    points_of_curve.inputs[2].default_value = 0
	
	
	
	
	
	    #Set locations
	    position_002.location = (-608.1627807617188, -70.55814361572266)
	    interpolate_domain.location = (-608.1627807617188, 90.18604278564453)
	    field_at_index_003.location = (-407.2325439453125, 70.09302520751953)
	    interpolate_domain_001.location = (-206.30230712890625, 70.09302520751953)
	    curve_tangent.location = (-608.1627807617188, -271.4883728027344)
	    endpoint_selection.location = (-206.30230712890625, 190.65118408203125)
	    field_at_index_004.location = (-407.2325439453125, -130.83721923828125)
	    interpolate_domain_002.location = (-206.30230712890625, -130.83721923828125)
	    group_output_2.location = (75.0, 50.0)
	    points_of_curve.location = (-789.0, 50.0)
	
	    #Set dimensions
	    position_002.width, position_002.height = 140.0, 100.0
	    interpolate_domain.width, interpolate_domain.height = 140.0, 100.0
	    field_at_index_003.width, field_at_index_003.height = 140.0, 100.0
	    interpolate_domain_001.width, interpolate_domain_001.height = 140.0, 100.0
	    curve_tangent.width, curve_tangent.height = 140.0, 100.0
	    endpoint_selection.width, endpoint_selection.height = 140.0, 100.0
	    field_at_index_004.width, field_at_index_004.height = 140.0, 100.0
	    interpolate_domain_002.width, interpolate_domain_002.height = 140.0, 100.0
	    group_output_2.width, group_output_2.height = 140.0, 100.0
	    points_of_curve.width, points_of_curve.height = 140.0, 100.0
	
	    #initialize curve_root links
	    #position_002.Position -> field_at_index_003.Value
	    curve_root.links.new(position_002.outputs[0], field_at_index_003.inputs[1])
	    #interpolate_domain_001.Value -> group_output_2.Root Position
	    curve_root.links.new(interpolate_domain_001.outputs[0], group_output_2.inputs[1])
	    #interpolate_domain.Value -> field_at_index_003.Index
	    curve_root.links.new(interpolate_domain.outputs[0], field_at_index_003.inputs[0])
	    #points_of_curve.Point Index -> interpolate_domain.Value
	    curve_root.links.new(points_of_curve.outputs[0], interpolate_domain.inputs[0])
	    #interpolate_domain.Value -> group_output_2.Root Index
	    curve_root.links.new(interpolate_domain.outputs[0], group_output_2.inputs[3])
	    #endpoint_selection.Selection -> group_output_2.Root Selection
	    curve_root.links.new(endpoint_selection.outputs[0], group_output_2.inputs[0])
	    #field_at_index_003.Value -> interpolate_domain_001.Value
	    curve_root.links.new(field_at_index_003.outputs[0], interpolate_domain_001.inputs[0])
	    #interpolate_domain_002.Value -> group_output_2.Root Direction
	    curve_root.links.new(interpolate_domain_002.outputs[0], group_output_2.inputs[2])
	    #interpolate_domain.Value -> field_at_index_004.Index
	    curve_root.links.new(interpolate_domain.outputs[0], field_at_index_004.inputs[0])
	    #curve_tangent.Tangent -> field_at_index_004.Value
	    curve_root.links.new(curve_tangent.outputs[0], field_at_index_004.inputs[1])
	    #field_at_index_004.Value -> interpolate_domain_002.Value
	    curve_root.links.new(field_at_index_004.outputs[0], interpolate_domain_002.inputs[0])
	    return curve_root
	
	curve_root = curve_root_node_group()
	
	#initialize shape_curve_to_closest_point node group
	def shape_curve_to_closest_point_node_group():
	    shape_curve_to_closest_point = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "SHAPE_CURVE_TO_CLOSEST_POINT")
	
	    shape_curve_to_closest_point.color_tag = 'NONE'
	    shape_curve_to_closest_point.description = ""
	    shape_curve_to_closest_point.default_group_node_width = 140
	    
	
	    shape_curve_to_closest_point.is_modifier = True
	
	    #shape_curve_to_closest_point interface
	    #Socket Geometry
	    geometry_socket_4 = shape_curve_to_closest_point.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_4.attribute_domain = 'POINT'
	
	    #Socket Geometry
	    geometry_socket_5 = shape_curve_to_closest_point.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_5.attribute_domain = 'POINT'
	
	    #Socket Surface
	    surface_socket = shape_curve_to_closest_point.interface.new_socket(name = "Surface", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    surface_socket.attribute_domain = 'POINT'
	
	    #Socket Surface
	    surface_socket_1 = shape_curve_to_closest_point.interface.new_socket(name = "Surface", in_out='INPUT', socket_type = 'NodeSocketObject')
	    surface_socket_1.attribute_domain = 'POINT'
	
	    #Socket Guide Curve
	    guide_curve_socket = shape_curve_to_closest_point.interface.new_socket(name = "Guide Curve", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    guide_curve_socket.attribute_domain = 'POINT'
	
	    #Socket Guide Curve
	    guide_curve_socket_1 = shape_curve_to_closest_point.interface.new_socket(name = "Guide Curve", in_out='INPUT', socket_type = 'NodeSocketObject')
	    guide_curve_socket_1.attribute_domain = 'POINT'
	
	    #Socket Control Points
	    control_points_socket = shape_curve_to_closest_point.interface.new_socket(name = "Control Points", in_out='INPUT', socket_type = 'NodeSocketInt')
	    control_points_socket.default_value = 10
	    control_points_socket.min_value = 3
	    control_points_socket.max_value = 100000
	    control_points_socket.subtype = 'NONE'
	    control_points_socket.attribute_domain = 'POINT'
	
	    #Socket Hair Shape Offset
	    hair_shape_offset_socket = shape_curve_to_closest_point.interface.new_socket(name = "Hair Shape Offset", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    hair_shape_offset_socket.default_value = 0.009999999776482582
	    hair_shape_offset_socket.min_value = 0.0
	    hair_shape_offset_socket.max_value = 10000.0
	    hair_shape_offset_socket.subtype = 'NONE'
	    hair_shape_offset_socket.attribute_domain = 'POINT'
	
	    #Socket Sample Surface Count
	    sample_surface_count_socket = shape_curve_to_closest_point.interface.new_socket(name = "Sample Surface Count", in_out='INPUT', socket_type = 'NodeSocketInt')
	    sample_surface_count_socket.default_value = 1
	    sample_surface_count_socket.min_value = 1
	    sample_surface_count_socket.max_value = 100000
	    sample_surface_count_socket.subtype = 'NONE'
	    sample_surface_count_socket.attribute_domain = 'POINT'
	
	    #Socket Sample Surface Distance
	    sample_surface_distance_socket = shape_curve_to_closest_point.interface.new_socket(name = "Sample Surface Distance", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    sample_surface_distance_socket.default_value = 0.0
	    sample_surface_distance_socket.min_value = 0.0
	    sample_surface_distance_socket.max_value = 10000.0
	    sample_surface_distance_socket.subtype = 'NONE'
	    sample_surface_distance_socket.attribute_domain = 'POINT'
	
	    #Socket Max Influence Distance
	    max_influence_distance_socket = shape_curve_to_closest_point.interface.new_socket(name = "Max Influence Distance", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    max_influence_distance_socket.default_value = 0.0
	    max_influence_distance_socket.min_value = 0.0
	    max_influence_distance_socket.max_value = 10000.0
	    max_influence_distance_socket.subtype = 'NONE'
	    max_influence_distance_socket.attribute_domain = 'POINT'
	
	    #Socket Offset from Surface
	    offset_from_surface_socket = shape_curve_to_closest_point.interface.new_socket(name = "Offset from Surface", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    offset_from_surface_socket.default_value = 0.0
	    offset_from_surface_socket.min_value = 0.0
	    offset_from_surface_socket.max_value = 0.0
	    offset_from_surface_socket.subtype = 'NONE'
	    offset_from_surface_socket.attribute_domain = 'POINT'
	    offset_from_surface_socket.hide_value = True
	    offset_from_surface_socket.hide_in_modifier = True
	
	
	    #initialize shape_curve_to_closest_point nodes
	    #node Group Input
	    group_input_2 = shape_curve_to_closest_point.nodes.new("NodeGroupInput")
	    group_input_2.name = "Group Input"
	    group_input_2.outputs[1].hide = True
	    group_input_2.outputs[2].hide = True
	    group_input_2.outputs[3].hide = True
	    group_input_2.outputs[4].hide = True
	    group_input_2.outputs[5].hide = True
	    group_input_2.outputs[6].hide = True
	    group_input_2.outputs[7].hide = True
	    group_input_2.outputs[8].hide = True
	    group_input_2.outputs[9].hide = True
	    group_input_2.outputs[10].hide = True
	    group_input_2.outputs[11].hide = True
	
	    #node Group Output
	    group_output_3 = shape_curve_to_closest_point.nodes.new("NodeGroupOutput")
	    group_output_3.name = "Group Output"
	    group_output_3.is_active_output = True
	
	    #node Store Named Attribute
	    store_named_attribute = shape_curve_to_closest_point.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute.name = "Store Named Attribute"
	    store_named_attribute.data_type = 'INT'
	    store_named_attribute.domain = 'CURVE'
	    #Selection
	    store_named_attribute.inputs[1].default_value = True
	    #Name
	    store_named_attribute.inputs[2].default_value = "closest_idx"
	
	    #node Sample Nearest
	    sample_nearest = shape_curve_to_closest_point.nodes.new("GeometryNodeSampleNearest")
	    sample_nearest.name = "Sample Nearest"
	    sample_nearest.hide = True
	    sample_nearest.domain = 'POINT'
	
	    #node Sample Curve
	    sample_curve = shape_curve_to_closest_point.nodes.new("GeometryNodeSampleCurve")
	    sample_curve.name = "Sample Curve"
	    sample_curve.hide = True
	    sample_curve.data_type = 'FLOAT'
	    sample_curve.mode = 'FACTOR'
	    sample_curve.use_all_curves = False
	    sample_curve.inputs[1].hide = True
	    sample_curve.inputs[2].hide = True
	    sample_curve.inputs[3].hide = True
	    sample_curve.outputs[0].hide = True
	    sample_curve.outputs[2].hide = True
	    sample_curve.outputs[3].hide = True
	    #Value
	    sample_curve.inputs[1].default_value = 0.0
	    #Factor
	    sample_curve.inputs[2].default_value = 0.0
	
	    #node Index
	    index = shape_curve_to_closest_point.nodes.new("GeometryNodeInputIndex")
	    index.name = "Index"
	
	    #node Group Input.002
	    group_input_002 = shape_curve_to_closest_point.nodes.new("NodeGroupInput")
	    group_input_002.name = "Group Input.002"
	    group_input_002.outputs[1].hide = True
	    group_input_002.outputs[2].hide = True
	    group_input_002.outputs[3].hide = True
	    group_input_002.outputs[4].hide = True
	    group_input_002.outputs[5].hide = True
	    group_input_002.outputs[6].hide = True
	    group_input_002.outputs[7].hide = True
	    group_input_002.outputs[8].hide = True
	    group_input_002.outputs[9].hide = True
	    group_input_002.outputs[10].hide = True
	    group_input_002.outputs[11].hide = True
	
	    #node Group Input.003
	    group_input_003 = shape_curve_to_closest_point.nodes.new("NodeGroupInput")
	    group_input_003.name = "Group Input.003"
	    group_input_003.outputs[0].hide = True
	    group_input_003.outputs[1].hide = True
	    group_input_003.outputs[2].hide = True
	    group_input_003.outputs[5].hide = True
	    group_input_003.outputs[6].hide = True
	    group_input_003.outputs[7].hide = True
	    group_input_003.outputs[8].hide = True
	    group_input_003.outputs[9].hide = True
	    group_input_003.outputs[10].hide = True
	    group_input_003.outputs[11].hide = True
	
	    #node Group Input.008
	    group_input_008 = shape_curve_to_closest_point.nodes.new("NodeGroupInput")
	    group_input_008.name = "Group Input.008"
	    group_input_008.outputs[0].hide = True
	    group_input_008.outputs[3].hide = True
	    group_input_008.outputs[4].hide = True
	    group_input_008.outputs[5].hide = True
	    group_input_008.outputs[6].hide = True
	    group_input_008.outputs[7].hide = True
	    group_input_008.outputs[8].hide = True
	    group_input_008.outputs[9].hide = True
	    group_input_008.outputs[10].hide = True
	    group_input_008.outputs[11].hide = True
	
	    #node Group.001
	    group_001 = shape_curve_to_closest_point.nodes.new("GeometryNodeGroup")
	    group_001.name = "Group.001"
	    group_001.hide = True
	    group_001.node_tree = curve_geometry_priority
	
	    #node Group Input.007
	    group_input_007 = shape_curve_to_closest_point.nodes.new("NodeGroupInput")
	    group_input_007.name = "Group Input.007"
	    group_input_007.outputs[0].hide = True
	    group_input_007.outputs[1].hide = True
	    group_input_007.outputs[2].hide = True
	    group_input_007.outputs[3].hide = True
	    group_input_007.outputs[4].hide = True
	    group_input_007.outputs[5].hide = True
	    group_input_007.outputs[6].hide = True
	    group_input_007.outputs[8].hide = True
	    group_input_007.outputs[9].hide = True
	    group_input_007.outputs[10].hide = True
	    group_input_007.outputs[11].hide = True
	
	    #node Group.002
	    group_002 = shape_curve_to_closest_point.nodes.new("GeometryNodeGroup")
	    group_002.name = "Group.002"
	    group_002.hide = True
	    group_002.node_tree = mesh_geometry_priority
	
	    #node Group Input.009
	    group_input_009 = shape_curve_to_closest_point.nodes.new("NodeGroupInput")
	    group_input_009.name = "Group Input.009"
	    group_input_009.outputs[0].hide = True
	    group_input_009.outputs[3].hide = True
	    group_input_009.outputs[4].hide = True
	    group_input_009.outputs[5].hide = True
	    group_input_009.outputs[6].hide = True
	    group_input_009.outputs[7].hide = True
	    group_input_009.outputs[8].hide = True
	    group_input_009.outputs[9].hide = True
	    group_input_009.outputs[10].hide = True
	    group_input_009.outputs[11].hide = True
	
	    #node Geometry Proximity
	    geometry_proximity = shape_curve_to_closest_point.nodes.new("GeometryNodeProximity")
	    geometry_proximity.name = "Geometry Proximity"
	    geometry_proximity.hide = True
	    geometry_proximity.target_element = 'FACES'
	    geometry_proximity.inputs[1].hide = True
	    geometry_proximity.inputs[3].hide = True
	    geometry_proximity.outputs[0].hide = True
	    geometry_proximity.outputs[2].hide = True
	    #Group ID
	    geometry_proximity.inputs[1].default_value = 0
	    #Sample Group ID
	    geometry_proximity.inputs[3].default_value = 0
	
	    #node Capture Attribute
	    capture_attribute = shape_curve_to_closest_point.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute.name = "Capture Attribute"
	    capture_attribute.hide = True
	    capture_attribute.active_index = 0
	    capture_attribute.capture_items.clear()
	    capture_attribute.capture_items.new('FLOAT', "Position")
	    capture_attribute.capture_items["Position"].data_type = 'FLOAT_VECTOR'
	    capture_attribute.domain = 'POINT'
	    capture_attribute.inputs[2].hide = True
	    capture_attribute.outputs[2].hide = True
	
	    #node Position
	    position = shape_curve_to_closest_point.nodes.new("GeometryNodeInputPosition")
	    position.name = "Position"
	
	    #node Compare
	    compare = shape_curve_to_closest_point.nodes.new("FunctionNodeCompare")
	    compare.name = "Compare"
	    compare.hide = True
	    compare.data_type = 'FLOAT'
	    compare.mode = 'ELEMENT'
	    compare.operation = 'GREATER_THAN'
	
	    #node Group Input.010
	    group_input_010 = shape_curve_to_closest_point.nodes.new("NodeGroupInput")
	    group_input_010.name = "Group Input.010"
	    group_input_010.outputs[0].hide = True
	    group_input_010.outputs[1].hide = True
	    group_input_010.outputs[2].hide = True
	    group_input_010.outputs[3].hide = True
	    group_input_010.outputs[4].hide = True
	    group_input_010.outputs[5].hide = True
	    group_input_010.outputs[6].hide = True
	    group_input_010.outputs[7].hide = True
	    group_input_010.outputs[9].hide = True
	    group_input_010.outputs[10].hide = True
	    group_input_010.outputs[11].hide = True
	
	    #node Delete Geometry
	    delete_geometry = shape_curve_to_closest_point.nodes.new("GeometryNodeDeleteGeometry")
	    delete_geometry.name = "Delete Geometry"
	    delete_geometry.hide = True
	    delete_geometry.domain = 'POINT'
	    delete_geometry.mode = 'ALL'
	
	    #node Frame.001
	    frame_001 = shape_curve_to_closest_point.nodes.new("NodeFrame")
	    frame_001.label = "Sample Points"
	    frame_001.name = "Frame.001"
	    frame_001.label_size = 20
	    frame_001.shrink = True
	
	    #node Store Named Attribute.001
	    store_named_attribute_001 = shape_curve_to_closest_point.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_001.name = "Store Named Attribute.001"
	    store_named_attribute_001.data_type = 'FLOAT_VECTOR'
	    store_named_attribute_001.domain = 'CURVE'
	    #Selection
	    store_named_attribute_001.inputs[1].default_value = True
	    #Name
	    store_named_attribute_001.inputs[2].default_value = "root_points"
	
	    #node Group.004
	    group_004 = shape_curve_to_closest_point.nodes.new("GeometryNodeGroup")
	    group_004.name = "Group.004"
	    group_004.hide = True
	    group_004.node_tree = curve_root
	    group_004.outputs[0].hide = True
	    group_004.outputs[2].hide = True
	    group_004.outputs[3].hide = True
	
	    #node Geometry Proximity.001
	    geometry_proximity_001 = shape_curve_to_closest_point.nodes.new("GeometryNodeProximity")
	    geometry_proximity_001.name = "Geometry Proximity.001"
	    geometry_proximity_001.hide = True
	    geometry_proximity_001.target_element = 'FACES'
	    geometry_proximity_001.inputs[1].hide = True
	    geometry_proximity_001.inputs[3].hide = True
	    geometry_proximity_001.outputs[1].hide = True
	    geometry_proximity_001.outputs[2].hide = True
	    #Group ID
	    geometry_proximity_001.inputs[1].default_value = 0
	    #Sample Group ID
	    geometry_proximity_001.inputs[3].default_value = 0
	
	    #node Reroute.001
	    reroute_001 = shape_curve_to_closest_point.nodes.new("NodeReroute")
	    reroute_001.name = "Reroute.001"
	    reroute_001.socket_idname = "NodeSocketGeometry"
	    #node Reroute.002
	    reroute_002 = shape_curve_to_closest_point.nodes.new("NodeReroute")
	    reroute_002.name = "Reroute.002"
	    reroute_002.socket_idname = "NodeSocketGeometry"
	    #node Sample Index
	    sample_index = shape_curve_to_closest_point.nodes.new("GeometryNodeSampleIndex")
	    sample_index.name = "Sample Index"
	    sample_index.hide = True
	    sample_index.clamp = False
	    sample_index.data_type = 'FLOAT_VECTOR'
	    sample_index.domain = 'POINT'
	
	    #node Position.001
	    position_001 = shape_curve_to_closest_point.nodes.new("GeometryNodeInputPosition")
	    position_001.name = "Position.001"
	    position_001.hide = True
	
	    #node Vector Math
	    vector_math = shape_curve_to_closest_point.nodes.new("ShaderNodeVectorMath")
	    vector_math.name = "Vector Math"
	    vector_math.hide = True
	    vector_math.operation = 'SUBTRACT'
	
	    #node Vector Math.001
	    vector_math_001 = shape_curve_to_closest_point.nodes.new("ShaderNodeVectorMath")
	    vector_math_001.name = "Vector Math.001"
	    vector_math_001.hide = True
	    vector_math_001.operation = 'LENGTH'
	
	    #node Sample Index.002
	    sample_index_002 = shape_curve_to_closest_point.nodes.new("GeometryNodeSampleIndex")
	    sample_index_002.name = "Sample Index.002"
	    sample_index_002.hide = True
	    sample_index_002.clamp = False
	    sample_index_002.data_type = 'INT'
	    sample_index_002.domain = 'POINT'
	
	    #node Mesh Island
	    mesh_island = shape_curve_to_closest_point.nodes.new("GeometryNodeInputMeshIsland")
	    mesh_island.name = "Mesh Island"
	    mesh_island.outputs[1].hide = True
	
	    #node Frame.003
	    frame_003 = shape_curve_to_closest_point.nodes.new("NodeFrame")
	    frame_003.label = "Closest Spline"
	    frame_003.name = "Frame.003"
	    frame_003.label_size = 20
	    frame_003.shrink = True
	
	    #node Store Named Attribute.003
	    store_named_attribute_003 = shape_curve_to_closest_point.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_003.name = "Store Named Attribute.003"
	    store_named_attribute_003.data_type = 'FLOAT_VECTOR'
	    store_named_attribute_003.domain = 'CURVE'
	    #Selection
	    store_named_attribute_003.inputs[1].default_value = True
	    #Name
	    store_named_attribute_003.inputs[2].default_value = "closest_spline_vec"
	
	    #node Curve to Mesh.001
	    curve_to_mesh_001 = shape_curve_to_closest_point.nodes.new("GeometryNodeCurveToMesh")
	    curve_to_mesh_001.name = "Curve to Mesh.001"
	    curve_to_mesh_001.hide = True
	    curve_to_mesh_001.inputs[1].hide = True
	    curve_to_mesh_001.inputs[2].hide = True
	    #Fill Caps
	    curve_to_mesh_001.inputs[2].default_value = False
	
	    #node Resample Curve
	    resample_curve = shape_curve_to_closest_point.nodes.new("GeometryNodeResampleCurve")
	    resample_curve.name = "Resample Curve"
	    resample_curve.hide = True
	    resample_curve.keep_last_segment = False
	    resample_curve.mode = 'COUNT'
	    #Selection
	    resample_curve.inputs[1].default_value = True
	
	    #node Store Named Attribute.004
	    store_named_attribute_004 = shape_curve_to_closest_point.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_004.name = "Store Named Attribute.004"
	    store_named_attribute_004.data_type = 'FLOAT_VECTOR'
	    store_named_attribute_004.domain = 'CURVE'
	    #Selection
	    store_named_attribute_004.inputs[1].default_value = True
	    #Name
	    store_named_attribute_004.inputs[2].default_value = "closetst_pt"
	
	    #node Store Named Attribute.005
	    store_named_attribute_005 = shape_curve_to_closest_point.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_005.name = "Store Named Attribute.005"
	    store_named_attribute_005.data_type = 'FLOAT'
	    store_named_attribute_005.domain = 'CURVE'
	    #Selection
	    store_named_attribute_005.inputs[1].default_value = True
	    #Name
	    store_named_attribute_005.inputs[2].default_value = "closetst_dist"
	
	    #node Store Named Attribute.006
	    store_named_attribute_006 = shape_curve_to_closest_point.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_006.name = "Store Named Attribute.006"
	    store_named_attribute_006.data_type = 'INT'
	    store_named_attribute_006.domain = 'CURVE'
	    #Selection
	    store_named_attribute_006.inputs[1].default_value = True
	    #Name
	    store_named_attribute_006.inputs[2].default_value = "closest_spline_idx"
	
	    #node Set Position.001
	    set_position_001 = shape_curve_to_closest_point.nodes.new("GeometryNodeSetPosition")
	    set_position_001.name = "Set Position.001"
	    set_position_001.inputs[3].hide = True
	    #Offset
	    set_position_001.inputs[3].default_value = (0.0, 0.0, 0.0)
	
	    #node Resample Curve.001
	    resample_curve_001 = shape_curve_to_closest_point.nodes.new("GeometryNodeResampleCurve")
	    resample_curve_001.name = "Resample Curve.001"
	    resample_curve_001.keep_last_segment = False
	    resample_curve_001.mode = 'COUNT'
	    resample_curve_001.inputs[1].hide = True
	    resample_curve_001.inputs[2].hide = True
	    resample_curve_001.inputs[3].hide = True
	    #Selection
	    resample_curve_001.inputs[1].default_value = True
	    #Count
	    resample_curve_001.inputs[2].default_value = 2
	
	    #node Named Attribute.001
	    named_attribute_001 = shape_curve_to_closest_point.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute_001.name = "Named Attribute.001"
	    named_attribute_001.data_type = 'FLOAT_VECTOR'
	    #Name
	    named_attribute_001.inputs[0].default_value = "closetst_pt"
	
	    #node Set Position.002
	    set_position_002 = shape_curve_to_closest_point.nodes.new("GeometryNodeSetPosition")
	    set_position_002.name = "Set Position.002"
	    set_position_002.inputs[1].hide = True
	    set_position_002.inputs[3].hide = True
	    #Selection
	    set_position_002.inputs[1].default_value = True
	    #Offset
	    set_position_002.inputs[3].default_value = (0.0, 0.0, 0.0)
	
	    #node Group
	    group = shape_curve_to_closest_point.nodes.new("GeometryNodeGroup")
	    group.name = "Group"
	    group.node_tree = mesh_geometry_priority
	
	    #node Geometry Proximity.002
	    geometry_proximity_002 = shape_curve_to_closest_point.nodes.new("GeometryNodeProximity")
	    geometry_proximity_002.name = "Geometry Proximity.002"
	    geometry_proximity_002.hide = True
	    geometry_proximity_002.target_element = 'FACES'
	    geometry_proximity_002.inputs[1].hide = True
	    geometry_proximity_002.inputs[3].hide = True
	    geometry_proximity_002.outputs[1].hide = True
	    geometry_proximity_002.outputs[2].hide = True
	    #Group ID
	    geometry_proximity_002.inputs[1].default_value = 0
	    #Sample Group ID
	    geometry_proximity_002.inputs[3].default_value = 0
	
	    #node Position.003
	    position_003 = shape_curve_to_closest_point.nodes.new("GeometryNodeInputPosition")
	    position_003.name = "Position.003"
	    position_003.hide = True
	
	    #node Capture Attribute.003
	    capture_attribute_003 = shape_curve_to_closest_point.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_003.name = "Capture Attribute.003"
	    capture_attribute_003.hide = True
	    capture_attribute_003.active_index = 0
	    capture_attribute_003.capture_items.clear()
	    capture_attribute_003.capture_items.new('FLOAT', "Position")
	    capture_attribute_003.capture_items["Position"].data_type = 'FLOAT_VECTOR'
	    capture_attribute_003.domain = 'POINT'
	    capture_attribute_003.inputs[2].hide = True
	    capture_attribute_003.outputs[2].hide = True
	
	    #node Hair to Surface Shape
	    hair_to_surface_shape = shape_curve_to_closest_point.nodes.new("ShaderNodeFloatCurve")
	    hair_to_surface_shape.label = "Hair to Surface Shape"
	    hair_to_surface_shape.name = "Hair to Surface Shape"
	    #mapping settings
	    hair_to_surface_shape.mapping.extend = 'EXTRAPOLATED'
	    hair_to_surface_shape.mapping.tone = 'STANDARD'
	    hair_to_surface_shape.mapping.black_level = (0.0, 0.0, 0.0)
	    hair_to_surface_shape.mapping.white_level = (1.0, 1.0, 1.0)
	    hair_to_surface_shape.mapping.clip_min_x = 0.0
	    hair_to_surface_shape.mapping.clip_min_y = 0.0
	    hair_to_surface_shape.mapping.clip_max_x = 1.0
	    hair_to_surface_shape.mapping.clip_max_y = 1.0
	    hair_to_surface_shape.mapping.use_clip = True
	    #curve 0
	    hair_to_surface_shape_curve_0 = hair_to_surface_shape.mapping.curves[0]
	    hair_to_surface_shape_curve_0_point_0 = hair_to_surface_shape_curve_0.points[0]
	    hair_to_surface_shape_curve_0_point_0.location = (0.0, 0.0)
	    hair_to_surface_shape_curve_0_point_0.handle_type = 'AUTO'
	    hair_to_surface_shape_curve_0_point_1 = hair_to_surface_shape_curve_0.points[1]
	    hair_to_surface_shape_curve_0_point_1.location = (0.5, 1.0)
	    hair_to_surface_shape_curve_0_point_1.handle_type = 'AUTO'
	    hair_to_surface_shape_curve_0_point_2 = hair_to_surface_shape_curve_0.points.new(1.0, 0.013157878071069717)
	    hair_to_surface_shape_curve_0_point_2.handle_type = 'AUTO'
	    #update curve after changes
	    hair_to_surface_shape.mapping.update()
	    hair_to_surface_shape.inputs[0].hide = True
	    #Factor
	    hair_to_surface_shape.inputs[0].default_value = 1.0
	
	    #node Spline Parameter
	    spline_parameter = shape_curve_to_closest_point.nodes.new("GeometryNodeSplineParameter")
	    spline_parameter.name = "Spline Parameter"
	    spline_parameter.outputs[1].hide = True
	    spline_parameter.outputs[2].hide = True
	
	    #node Sample Nearest.001
	    sample_nearest_001 = shape_curve_to_closest_point.nodes.new("GeometryNodeSampleNearest")
	    sample_nearest_001.name = "Sample Nearest.001"
	    sample_nearest_001.hide = True
	    sample_nearest_001.domain = 'FACE'
	
	    #node Sample Index.001
	    sample_index_001 = shape_curve_to_closest_point.nodes.new("GeometryNodeSampleIndex")
	    sample_index_001.name = "Sample Index.001"
	    sample_index_001.hide = True
	    sample_index_001.clamp = False
	    sample_index_001.data_type = 'FLOAT_VECTOR'
	    sample_index_001.domain = 'FACE'
	
	    #node Normal
	    normal = shape_curve_to_closest_point.nodes.new("GeometryNodeInputNormal")
	    normal.name = "Normal"
	    normal.hide = True
	    normal.legacy_corner_normals = True
	
	    #node Vector Math.002
	    vector_math_002 = shape_curve_to_closest_point.nodes.new("ShaderNodeVectorMath")
	    vector_math_002.name = "Vector Math.002"
	    vector_math_002.hide = True
	    vector_math_002.operation = 'ADD'
	
	    #node Vector Math.003
	    vector_math_003 = shape_curve_to_closest_point.nodes.new("ShaderNodeVectorMath")
	    vector_math_003.name = "Vector Math.003"
	    vector_math_003.operation = 'SCALE'
	
	    #node Frame
	    frame = shape_curve_to_closest_point.nodes.new("NodeFrame")
	    frame.label = "Surface Data"
	    frame.name = "Frame"
	    frame.label_size = 20
	    frame.shrink = True
	
	    #node Set Position.003
	    set_position_003 = shape_curve_to_closest_point.nodes.new("GeometryNodeSetPosition")
	    set_position_003.name = "Set Position.003"
	    set_position_003.inputs[3].hide = True
	    #Offset
	    set_position_003.inputs[3].default_value = (0.0, 0.0, 0.0)
	
	    #node Endpoint Selection.003
	    endpoint_selection_003 = shape_curve_to_closest_point.nodes.new("GeometryNodeCurveEndpointSelection")
	    endpoint_selection_003.name = "Endpoint Selection.003"
	    #Start Size
	    endpoint_selection_003.inputs[0].default_value = 1
	    #End Size
	    endpoint_selection_003.inputs[1].default_value = 0
	
	    #node Named Attribute.003
	    named_attribute_003 = shape_curve_to_closest_point.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute_003.name = "Named Attribute.003"
	    named_attribute_003.data_type = 'FLOAT_VECTOR'
	    #Name
	    named_attribute_003.inputs[0].default_value = "root_points"
	
	    #node Endpoint Selection.004
	    endpoint_selection_004 = shape_curve_to_closest_point.nodes.new("GeometryNodeCurveEndpointSelection")
	    endpoint_selection_004.name = "Endpoint Selection.004"
	    endpoint_selection_004.inputs[0].hide = True
	    endpoint_selection_004.inputs[1].hide = True
	    #Start Size
	    endpoint_selection_004.inputs[0].default_value = 0
	    #End Size
	    endpoint_selection_004.inputs[1].default_value = 1
	
	    #node Resample Curve.002
	    resample_curve_002 = shape_curve_to_closest_point.nodes.new("GeometryNodeResampleCurve")
	    resample_curve_002.name = "Resample Curve.002"
	    resample_curve_002.keep_last_segment = False
	    resample_curve_002.mode = 'COUNT'
	    #Selection
	    resample_curve_002.inputs[1].default_value = True
	
	    #node Frame.002
	    frame_002 = shape_curve_to_closest_point.nodes.new("NodeFrame")
	    frame_002.label = "Attributes"
	    frame_002.name = "Frame.002"
	    frame_002.label_size = 20
	    frame_002.shrink = True
	
	    #node Frame.004
	    frame_004 = shape_curve_to_closest_point.nodes.new("NodeFrame")
	    frame_004.label = "Wrap Hair to Closest Point"
	    frame_004.name = "Frame.004"
	    frame_004.label_size = 20
	    frame_004.shrink = True
	
	    #node Frame.005
	    frame_005 = shape_curve_to_closest_point.nodes.new("NodeFrame")
	    frame_005.label = "Hair to Surface Shape"
	    frame_005.name = "Frame.005"
	    frame_005.label_size = 20
	    frame_005.shrink = True
	
	    #node Group Input.011
	    group_input_011 = shape_curve_to_closest_point.nodes.new("NodeGroupInput")
	    group_input_011.name = "Group Input.011"
	    group_input_011.outputs[0].hide = True
	    group_input_011.outputs[1].hide = True
	    group_input_011.outputs[2].hide = True
	    group_input_011.outputs[3].hide = True
	    group_input_011.outputs[4].hide = True
	    group_input_011.outputs[6].hide = True
	    group_input_011.outputs[7].hide = True
	    group_input_011.outputs[8].hide = True
	    group_input_011.outputs[9].hide = True
	    group_input_011.outputs[10].hide = True
	    group_input_011.outputs[11].hide = True
	
	    #node Store Named Attribute.002
	    store_named_attribute_002 = shape_curve_to_closest_point.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_002.name = "Store Named Attribute.002"
	    store_named_attribute_002.data_type = 'FLOAT'
	    store_named_attribute_002.domain = 'CURVE'
	    #Selection
	    store_named_attribute_002.inputs[1].default_value = True
	    #Name
	    store_named_attribute_002.inputs[2].default_value = "closest_factor"
	
	    #node Named Attribute
	    named_attribute = shape_curve_to_closest_point.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute.name = "Named Attribute"
	    named_attribute.data_type = 'INT'
	    #Name
	    named_attribute.inputs[0].default_value = "closest_spline_idx"
	
	    #node Sample Curve.001
	    sample_curve_001 = shape_curve_to_closest_point.nodes.new("GeometryNodeSampleCurve")
	    sample_curve_001.name = "Sample Curve.001"
	    sample_curve_001.data_type = 'FLOAT'
	    sample_curve_001.mode = 'FACTOR'
	    sample_curve_001.use_all_curves = False
	    sample_curve_001.inputs[3].hide = True
	    sample_curve_001.outputs[1].hide = True
	    sample_curve_001.outputs[2].hide = True
	    sample_curve_001.outputs[3].hide = True
	
	    #node Named Attribute.002
	    named_attribute_002 = shape_curve_to_closest_point.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute_002.name = "Named Attribute.002"
	    named_attribute_002.data_type = 'FLOAT_VECTOR'
	    #Name
	    named_attribute_002.inputs[0].default_value = "closetst_pt"
	
	    #node Spline Parameter.001
	    spline_parameter_001 = shape_curve_to_closest_point.nodes.new("GeometryNodeSplineParameter")
	    spline_parameter_001.name = "Spline Parameter.001"
	    spline_parameter_001.outputs[1].hide = True
	    spline_parameter_001.outputs[2].hide = True
	
	    #node Group Input.001
	    group_input_001 = shape_curve_to_closest_point.nodes.new("NodeGroupInput")
	    group_input_001.name = "Group Input.001"
	    group_input_001.outputs[1].hide = True
	    group_input_001.outputs[2].hide = True
	    group_input_001.outputs[3].hide = True
	    group_input_001.outputs[4].hide = True
	    group_input_001.outputs[5].hide = True
	    group_input_001.outputs[6].hide = True
	    group_input_001.outputs[7].hide = True
	    group_input_001.outputs[8].hide = True
	    group_input_001.outputs[9].hide = True
	    group_input_001.outputs[10].hide = True
	    group_input_001.outputs[11].hide = True
	
	    #node Frame.006
	    frame_006 = shape_curve_to_closest_point.nodes.new("NodeFrame")
	    frame_006.label = "Factor at Closest Point"
	    frame_006.name = "Frame.006"
	    frame_006.label_size = 20
	    frame_006.shrink = True
	
	    #node Compare.001
	    compare_001 = shape_curve_to_closest_point.nodes.new("FunctionNodeCompare")
	    compare_001.name = "Compare.001"
	    compare_001.hide = True
	    compare_001.data_type = 'FLOAT'
	    compare_001.mode = 'ELEMENT'
	    compare_001.operation = 'GREATER_THAN'
	    compare_001.inputs[1].hide = True
	    compare_001.inputs[2].hide = True
	    compare_001.inputs[3].hide = True
	    compare_001.inputs[4].hide = True
	    compare_001.inputs[5].hide = True
	    compare_001.inputs[6].hide = True
	    compare_001.inputs[7].hide = True
	    compare_001.inputs[8].hide = True
	    compare_001.inputs[9].hide = True
	    compare_001.inputs[10].hide = True
	    compare_001.inputs[11].hide = True
	    compare_001.inputs[12].hide = True
	    #B
	    compare_001.inputs[1].default_value = 0.0
	
	    #node Switch
	    switch = shape_curve_to_closest_point.nodes.new("GeometryNodeSwitch")
	    switch.name = "Switch"
	    switch.hide = True
	    switch.input_type = 'GEOMETRY'
	
	    #node Reroute
	    reroute_2 = shape_curve_to_closest_point.nodes.new("NodeReroute")
	    reroute_2.name = "Reroute"
	    reroute_2.socket_idname = "NodeSocketGeometry"
	    #node Reroute.003
	    reroute_003 = shape_curve_to_closest_point.nodes.new("NodeReroute")
	    reroute_003.name = "Reroute.003"
	    reroute_003.socket_idname = "NodeSocketGeometry"
	    #node Group Input.012
	    group_input_012 = shape_curve_to_closest_point.nodes.new("NodeGroupInput")
	    group_input_012.name = "Group Input.012"
	    group_input_012.outputs[0].hide = True
	    group_input_012.outputs[3].hide = True
	    group_input_012.outputs[4].hide = True
	    group_input_012.outputs[5].hide = True
	    group_input_012.outputs[6].hide = True
	    group_input_012.outputs[7].hide = True
	    group_input_012.outputs[8].hide = True
	    group_input_012.outputs[9].hide = True
	    group_input_012.outputs[10].hide = True
	    group_input_012.outputs[11].hide = True
	
	    #node Set Position.004
	    set_position_004 = shape_curve_to_closest_point.nodes.new("GeometryNodeSetPosition")
	    set_position_004.name = "Set Position.004"
	    set_position_004.inputs[3].hide = True
	    #Offset
	    set_position_004.inputs[3].default_value = (0.0, 0.0, 0.0)
	
	    #node Resample Curve.003
	    resample_curve_003 = shape_curve_to_closest_point.nodes.new("GeometryNodeResampleCurve")
	    resample_curve_003.name = "Resample Curve.003"
	    resample_curve_003.keep_last_segment = False
	    resample_curve_003.mode = 'COUNT'
	    resample_curve_003.inputs[2].hide = True
	    resample_curve_003.inputs[3].hide = True
	    #Count
	    resample_curve_003.inputs[2].default_value = 2
	
	    #node Named Attribute.005
	    named_attribute_005 = shape_curve_to_closest_point.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute_005.name = "Named Attribute.005"
	    named_attribute_005.data_type = 'FLOAT_VECTOR'
	    #Name
	    named_attribute_005.inputs[0].default_value = "closetst_pt"
	
	    #node Set Position.005
	    set_position_005 = shape_curve_to_closest_point.nodes.new("GeometryNodeSetPosition")
	    set_position_005.name = "Set Position.005"
	    set_position_005.inputs[3].hide = True
	    #Offset
	    set_position_005.inputs[3].default_value = (0.0, 0.0, 0.0)
	
	    #node Group.003
	    group_003 = shape_curve_to_closest_point.nodes.new("GeometryNodeGroup")
	    group_003.name = "Group.003"
	    group_003.node_tree = mesh_geometry_priority
	
	    #node Geometry Proximity.003
	    geometry_proximity_003 = shape_curve_to_closest_point.nodes.new("GeometryNodeProximity")
	    geometry_proximity_003.name = "Geometry Proximity.003"
	    geometry_proximity_003.hide = True
	    geometry_proximity_003.target_element = 'FACES'
	    geometry_proximity_003.inputs[1].hide = True
	    geometry_proximity_003.inputs[3].hide = True
	    geometry_proximity_003.outputs[1].hide = True
	    geometry_proximity_003.outputs[2].hide = True
	    #Group ID
	    geometry_proximity_003.inputs[1].default_value = 0
	    #Sample Group ID
	    geometry_proximity_003.inputs[3].default_value = 0
	
	    #node Position.004
	    position_004 = shape_curve_to_closest_point.nodes.new("GeometryNodeInputPosition")
	    position_004.name = "Position.004"
	    position_004.hide = True
	
	    #node Capture Attribute.004
	    capture_attribute_004 = shape_curve_to_closest_point.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_004.name = "Capture Attribute.004"
	    capture_attribute_004.hide = True
	    capture_attribute_004.active_index = 0
	    capture_attribute_004.capture_items.clear()
	    capture_attribute_004.capture_items.new('FLOAT', "Position")
	    capture_attribute_004.capture_items["Position"].data_type = 'FLOAT_VECTOR'
	    capture_attribute_004.domain = 'POINT'
	    capture_attribute_004.inputs[2].hide = True
	    capture_attribute_004.outputs[2].hide = True
	
	    #node Sample Nearest.002
	    sample_nearest_002 = shape_curve_to_closest_point.nodes.new("GeometryNodeSampleNearest")
	    sample_nearest_002.name = "Sample Nearest.002"
	    sample_nearest_002.hide = True
	    sample_nearest_002.domain = 'FACE'
	
	    #node Sample Index.003
	    sample_index_003 = shape_curve_to_closest_point.nodes.new("GeometryNodeSampleIndex")
	    sample_index_003.name = "Sample Index.003"
	    sample_index_003.hide = True
	    sample_index_003.clamp = False
	    sample_index_003.data_type = 'FLOAT_VECTOR'
	    sample_index_003.domain = 'FACE'
	
	    #node Normal.001
	    normal_001 = shape_curve_to_closest_point.nodes.new("GeometryNodeInputNormal")
	    normal_001.name = "Normal.001"
	    normal_001.hide = True
	    normal_001.legacy_corner_normals = True
	
	    #node Vector Math.004
	    vector_math_004 = shape_curve_to_closest_point.nodes.new("ShaderNodeVectorMath")
	    vector_math_004.name = "Vector Math.004"
	    vector_math_004.hide = True
	    vector_math_004.operation = 'ADD'
	
	    #node Vector Math.005
	    vector_math_005 = shape_curve_to_closest_point.nodes.new("ShaderNodeVectorMath")
	    vector_math_005.name = "Vector Math.005"
	    vector_math_005.operation = 'SCALE'
	
	    #node Frame.007
	    frame_007 = shape_curve_to_closest_point.nodes.new("NodeFrame")
	    frame_007.label = "Surface Data"
	    frame_007.name = "Frame.007"
	    frame_007.label_size = 20
	    frame_007.shrink = True
	
	    #node Set Position.006
	    set_position_006 = shape_curve_to_closest_point.nodes.new("GeometryNodeSetPosition")
	    set_position_006.name = "Set Position.006"
	    set_position_006.inputs[3].hide = True
	    #Offset
	    set_position_006.inputs[3].default_value = (0.0, 0.0, 0.0)
	
	    #node Endpoint Selection.005
	    endpoint_selection_005 = shape_curve_to_closest_point.nodes.new("GeometryNodeCurveEndpointSelection")
	    endpoint_selection_005.name = "Endpoint Selection.005"
	    #Start Size
	    endpoint_selection_005.inputs[0].default_value = 1
	    #End Size
	    endpoint_selection_005.inputs[1].default_value = 0
	
	    #node Named Attribute.006
	    named_attribute_006 = shape_curve_to_closest_point.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute_006.name = "Named Attribute.006"
	    named_attribute_006.data_type = 'FLOAT_VECTOR'
	    #Name
	    named_attribute_006.inputs[0].default_value = "root_points"
	
	    #node Endpoint Selection.006
	    endpoint_selection_006 = shape_curve_to_closest_point.nodes.new("GeometryNodeCurveEndpointSelection")
	    endpoint_selection_006.name = "Endpoint Selection.006"
	    endpoint_selection_006.inputs[0].hide = True
	    endpoint_selection_006.inputs[1].hide = True
	    #Start Size
	    endpoint_selection_006.inputs[0].default_value = 0
	    #End Size
	    endpoint_selection_006.inputs[1].default_value = 1
	
	    #node Resample Curve.004
	    resample_curve_004 = shape_curve_to_closest_point.nodes.new("GeometryNodeResampleCurve")
	    resample_curve_004.name = "Resample Curve.004"
	    resample_curve_004.keep_last_segment = False
	    resample_curve_004.mode = 'COUNT'
	    #Selection
	    resample_curve_004.inputs[1].default_value = True
	
	    #node Frame.008
	    frame_008 = shape_curve_to_closest_point.nodes.new("NodeFrame")
	    frame_008.label = "Wrap Hair to Closest Point Using Influence Distance"
	    frame_008.name = "Frame.008"
	    frame_008.label_size = 20
	    frame_008.shrink = True
	
	    #node Group Input.013
	    group_input_013 = shape_curve_to_closest_point.nodes.new("NodeGroupInput")
	    group_input_013.name = "Group Input.013"
	    group_input_013.outputs[0].hide = True
	    group_input_013.outputs[1].hide = True
	    group_input_013.outputs[2].hide = True
	    group_input_013.outputs[3].hide = True
	    group_input_013.outputs[4].hide = True
	    group_input_013.outputs[6].hide = True
	    group_input_013.outputs[7].hide = True
	    group_input_013.outputs[8].hide = True
	    group_input_013.outputs[9].hide = True
	    group_input_013.outputs[10].hide = True
	    group_input_013.outputs[11].hide = True
	
	    #node Named Attribute.007
	    named_attribute_007 = shape_curve_to_closest_point.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute_007.name = "Named Attribute.007"
	    named_attribute_007.data_type = 'FLOAT'
	    #Name
	    named_attribute_007.inputs[0].default_value = "closetst_dist"
	
	    #node Compare.002
	    compare_002_2 = shape_curve_to_closest_point.nodes.new("FunctionNodeCompare")
	    compare_002_2.name = "Compare.002"
	    compare_002_2.hide = True
	    compare_002_2.data_type = 'FLOAT'
	    compare_002_2.mode = 'ELEMENT'
	    compare_002_2.operation = 'LESS_EQUAL'
	
	    #node Boolean Math.001
	    boolean_math_001 = shape_curve_to_closest_point.nodes.new("FunctionNodeBooleanMath")
	    boolean_math_001.name = "Boolean Math.001"
	    boolean_math_001.hide = True
	    boolean_math_001.operation = 'AND'
	
	    #node Group Input.004
	    group_input_004 = shape_curve_to_closest_point.nodes.new("NodeGroupInput")
	    group_input_004.name = "Group Input.004"
	    group_input_004.outputs[0].hide = True
	    group_input_004.outputs[1].hide = True
	    group_input_004.outputs[2].hide = True
	    group_input_004.outputs[3].hide = True
	    group_input_004.outputs[4].hide = True
	    group_input_004.outputs[5].hide = True
	    group_input_004.outputs[6].hide = True
	    group_input_004.outputs[7].hide = True
	    group_input_004.outputs[8].hide = True
	    group_input_004.outputs[10].hide = True
	    group_input_004.outputs[11].hide = True
	
	    #node Group Input.005
	    group_input_005 = shape_curve_to_closest_point.nodes.new("NodeGroupInput")
	    group_input_005.name = "Group Input.005"
	    group_input_005.outputs[0].hide = True
	    group_input_005.outputs[1].hide = True
	    group_input_005.outputs[2].hide = True
	    group_input_005.outputs[3].hide = True
	    group_input_005.outputs[4].hide = True
	    group_input_005.outputs[5].hide = True
	    group_input_005.outputs[6].hide = True
	    group_input_005.outputs[7].hide = True
	    group_input_005.outputs[8].hide = True
	    group_input_005.outputs[10].hide = True
	    group_input_005.outputs[11].hide = True
	
	    #node Reroute.004
	    reroute_004 = shape_curve_to_closest_point.nodes.new("NodeReroute")
	    reroute_004.name = "Reroute.004"
	    reroute_004.socket_idname = "NodeSocketBool"
	    #node Reroute.005
	    reroute_005 = shape_curve_to_closest_point.nodes.new("NodeReroute")
	    reroute_005.name = "Reroute.005"
	    reroute_005.socket_idname = "NodeSocketBool"
	    #node Reroute.006
	    reroute_006 = shape_curve_to_closest_point.nodes.new("NodeReroute")
	    reroute_006.name = "Reroute.006"
	    reroute_006.socket_idname = "NodeSocketBool"
	    #node Reroute.007
	    reroute_007 = shape_curve_to_closest_point.nodes.new("NodeReroute")
	    reroute_007.name = "Reroute.007"
	    reroute_007.socket_idname = "NodeSocketGeometry"
	    #node Reroute.008
	    reroute_008 = shape_curve_to_closest_point.nodes.new("NodeReroute")
	    reroute_008.name = "Reroute.008"
	    reroute_008.socket_idname = "NodeSocketGeometry"
	    #node Reroute.009
	    reroute_009 = shape_curve_to_closest_point.nodes.new("NodeReroute")
	    reroute_009.name = "Reroute.009"
	    reroute_009.socket_idname = "NodeSocketGeometry"
	    #node Reroute.010
	    reroute_010 = shape_curve_to_closest_point.nodes.new("NodeReroute")
	    reroute_010.name = "Reroute.010"
	    reroute_010.socket_idname = "NodeSocketGeometry"
	    #node Reroute.011
	    reroute_011 = shape_curve_to_closest_point.nodes.new("NodeReroute")
	    reroute_011.name = "Reroute.011"
	    reroute_011.socket_idname = "NodeSocketBool"
	    #node Reroute.012
	    reroute_012 = shape_curve_to_closest_point.nodes.new("NodeReroute")
	    reroute_012.name = "Reroute.012"
	    reroute_012.socket_idname = "NodeSocketBool"
	    #node Reroute.013
	    reroute_013 = shape_curve_to_closest_point.nodes.new("NodeReroute")
	    reroute_013.name = "Reroute.013"
	    reroute_013.socket_idname = "NodeSocketBool"
	    #node Reroute.014
	    reroute_014 = shape_curve_to_closest_point.nodes.new("NodeReroute")
	    reroute_014.name = "Reroute.014"
	    reroute_014.socket_idname = "NodeSocketBool"
	    #node Reroute.015
	    reroute_015 = shape_curve_to_closest_point.nodes.new("NodeReroute")
	    reroute_015.name = "Reroute.015"
	    reroute_015.socket_idname = "NodeSocketBool"
	    #node Compare.003
	    compare_003 = shape_curve_to_closest_point.nodes.new("FunctionNodeCompare")
	    compare_003.name = "Compare.003"
	    compare_003.hide = True
	    compare_003.data_type = 'FLOAT'
	    compare_003.mode = 'ELEMENT'
	    compare_003.operation = 'EQUAL'
	    compare_003.inputs[1].hide = True
	    compare_003.inputs[2].hide = True
	    compare_003.inputs[3].hide = True
	    compare_003.inputs[4].hide = True
	    compare_003.inputs[5].hide = True
	    compare_003.inputs[6].hide = True
	    compare_003.inputs[7].hide = True
	    compare_003.inputs[8].hide = True
	    compare_003.inputs[9].hide = True
	    compare_003.inputs[10].hide = True
	    compare_003.inputs[11].hide = True
	    compare_003.inputs[12].hide = True
	    #B
	    compare_003.inputs[1].default_value = 0.0
	    #Epsilon
	    compare_003.inputs[12].default_value = 0.0
	
	    #node Switch.001
	    switch_001_2 = shape_curve_to_closest_point.nodes.new("GeometryNodeSwitch")
	    switch_001_2.name = "Switch.001"
	    switch_001_2.hide = True
	    switch_001_2.input_type = 'FLOAT'
	
	    #node Group Input.006
	    group_input_006 = shape_curve_to_closest_point.nodes.new("NodeGroupInput")
	    group_input_006.name = "Group Input.006"
	    group_input_006.outputs[0].hide = True
	    group_input_006.outputs[1].hide = True
	    group_input_006.outputs[2].hide = True
	    group_input_006.outputs[3].hide = True
	    group_input_006.outputs[4].hide = True
	    group_input_006.outputs[5].hide = True
	    group_input_006.outputs[6].hide = True
	    group_input_006.outputs[7].hide = True
	    group_input_006.outputs[8].hide = True
	    group_input_006.outputs[9].hide = True
	    group_input_006.outputs[11].hide = True
	
	    #node Group Input.014
	    group_input_014 = shape_curve_to_closest_point.nodes.new("NodeGroupInput")
	    group_input_014.name = "Group Input.014"
	    group_input_014.outputs[0].hide = True
	    group_input_014.outputs[1].hide = True
	    group_input_014.outputs[2].hide = True
	    group_input_014.outputs[3].hide = True
	    group_input_014.outputs[4].hide = True
	    group_input_014.outputs[5].hide = True
	    group_input_014.outputs[7].hide = True
	    group_input_014.outputs[8].hide = True
	    group_input_014.outputs[9].hide = True
	    group_input_014.outputs[10].hide = True
	    group_input_014.outputs[11].hide = True
	
	    #node Math
	    math = shape_curve_to_closest_point.nodes.new("ShaderNodeMath")
	    math.name = "Math"
	    math.hide = True
	    math.operation = 'MULTIPLY'
	    math.use_clamp = False
	
	
	
	
	    #Set parents
	    store_named_attribute.parent = frame_002
	    sample_nearest.parent = frame_001
	    group_input_008.parent = frame_004
	    group_001.parent = frame_001
	    geometry_proximity.parent = frame_001
	    capture_attribute.parent = frame_001
	    position.parent = frame_001
	    compare.parent = frame_001
	    group_input_010.parent = frame_001
	    delete_geometry.parent = frame_001
	    store_named_attribute_001.parent = frame_002
	    sample_index_002.parent = frame_003
	    mesh_island.parent = frame_003
	    store_named_attribute_003.parent = frame_002
	    curve_to_mesh_001.parent = frame_001
	    resample_curve.parent = frame_001
	    store_named_attribute_004.parent = frame_002
	    store_named_attribute_005.parent = frame_002
	    store_named_attribute_006.parent = frame_002
	    set_position_001.parent = frame_004
	    resample_curve_001.parent = frame_004
	    named_attribute_001.parent = frame_004
	    set_position_002.parent = frame_004
	    group.parent = frame
	    geometry_proximity_002.parent = frame
	    position_003.parent = frame_004
	    capture_attribute_003.parent = frame_004
	    hair_to_surface_shape.parent = frame_005
	    spline_parameter.parent = frame_005
	    sample_nearest_001.parent = frame
	    sample_index_001.parent = frame
	    normal.parent = frame
	    vector_math_002.parent = frame
	    vector_math_003.parent = frame
	    frame.parent = frame_004
	    set_position_003.parent = frame_004
	    endpoint_selection_003.parent = frame_004
	    named_attribute_003.parent = frame_004
	    endpoint_selection_004.parent = frame_004
	    resample_curve_002.parent = frame_004
	    group_input_011.parent = frame_004
	    store_named_attribute_002.parent = frame_002
	    named_attribute.parent = frame_006
	    sample_curve_001.parent = frame_006
	    named_attribute_002.parent = frame_006
	    spline_parameter_001.parent = frame_006
	    group_input_001.parent = frame_006
	    group_input_012.parent = frame_008
	    set_position_004.parent = frame_008
	    resample_curve_003.parent = frame_008
	    named_attribute_005.parent = frame_008
	    set_position_005.parent = frame_008
	    group_003.parent = frame_007
	    geometry_proximity_003.parent = frame_007
	    position_004.parent = frame_008
	    capture_attribute_004.parent = frame_008
	    sample_nearest_002.parent = frame_007
	    sample_index_003.parent = frame_007
	    normal_001.parent = frame_007
	    vector_math_004.parent = frame_007
	    vector_math_005.parent = frame_007
	    frame_007.parent = frame_008
	    set_position_006.parent = frame_008
	    endpoint_selection_005.parent = frame_008
	    named_attribute_006.parent = frame_008
	    endpoint_selection_006.parent = frame_008
	    resample_curve_004.parent = frame_008
	    group_input_013.parent = frame_008
	    named_attribute_007.parent = frame_008
	    compare_002_2.parent = frame_008
	    boolean_math_001.parent = frame_008
	    group_input_004.parent = frame_008
	    reroute_004.parent = frame_008
	    reroute_005.parent = frame_008
	    reroute_006.parent = frame_008
	    reroute_011.parent = frame_008
	    reroute_012.parent = frame_008
	    reroute_013.parent = frame_008
	
	    #Set locations
	    group_input_2.location = (-340.0, 156.41966247558594)
	    group_output_3.location = (3500.55126953125, 454.9473876953125)
	    store_named_attribute.location = (562.0911254882812, -49.04585266113281)
	    sample_nearest.location = (651.8779296875, -176.2069549560547)
	    sample_curve.location = (325.2962341308594, -372.614990234375)
	    index.location = (322.2127990722656, -406.8524169921875)
	    group_input_002.location = (138.57611083984375, -340.81732177734375)
	    group_input_003.location = (-340.0, -84.70687103271484)
	    group_input_008.location = (481.392822265625, -289.31573486328125)
	    group_001.location = (34.146636962890625, -116.17027282714844)
	    group_input_007.location = (-340.0, -162.97471618652344)
	    group_002.location = (-152.2979736328125, -37.125938415527344)
	    group_input_009.location = (-341.2811279296875, -7.327460765838623)
	    geometry_proximity.location = (340.542724609375, -45.305564880371094)
	    capture_attribute.location = (204.13388061523438, -235.54849243164062)
	    position.location = (29.71649169921875, -253.83291625976562)
	    compare.location = (499.0704040527344, -54.53212356567383)
	    group_input_010.location = (488.7305908203125, -86.27949523925781)
	    delete_geometry.location = (646.8992919921875, -229.87411499023438)
	    frame_001.location = (-191.0, -4.0)
	    store_named_attribute_001.location = (29.892730712890625, -48.47975158691406)
	    group_004.location = (-339.7350769042969, 60.86855697631836)
	    geometry_proximity_001.location = (-166.70086669921875, 65.34036254882812)
	    reroute_001.location = (-163.66197204589844, 24.428974151611328)
	    reroute_002.location = (-13.835042953491211, 26.491931915283203)
	    sample_index.location = (649.0642700195312, -37.377750396728516)
	    position_001.location = (644.3075561523438, -72.78196716308594)
	    vector_math.location = (813.8873291015625, -104.7253189086914)
	    vector_math_001.location = (813.8964233398438, -71.30670166015625)
	    sample_index_002.location = (31.6943359375, -45.200439453125)
	    mesh_island.location = (29.976806640625, -78.60165405273438)
	    frame_003.location = (1113.0, -127.0)
	    store_named_attribute_003.location = (1080.6876220703125, -46.67137145996094)
	    curve_to_mesh_001.location = (32.0604248046875, -221.23919677734375)
	    resample_curve.location = (32.555877685546875, -167.46231079101562)
	    store_named_attribute_004.location = (754.3668823242188, -46.6717529296875)
	    store_named_attribute_005.location = (918.1805419921875, -46.6717529296875)
	    store_named_attribute_006.location = (1246.6669921875, -46.67137145996094)
	    set_position_001.location = (248.5238037109375, -132.20654296875)
	    resample_curve_001.location = (38.7724609375, -157.1170654296875)
	    named_attribute_001.location = (31.5091552734375, -328.77972412109375)
	    set_position_002.location = (1288.53662109375, -64.1368408203125)
	    group.location = (30.181640625, -40.1806640625)
	    geometry_proximity_002.location = (226.56689453125, -55.932373046875)
	    position_003.location = (600.649169921875, -156.1644287109375)
	    capture_attribute_003.location = (605.345458984375, -117.1715087890625)
	    hair_to_surface_shape.location = (30.0157470703125, -40.402313232421875)
	    spline_parameter.location = (34.825439453125, -333.481689453125)
	    sample_nearest_001.location = (219.09765625, -108.320556640625)
	    sample_index_001.location = (218.489990234375, -164.6488037109375)
	    normal.location = (218.097900390625, -207.24951171875)
	    vector_math_002.location = (427.796142578125, -125.0545654296875)
	    vector_math_003.location = (431.01025390625, -162.28515625)
	    frame.location = (645.0, -201.0)
	    set_position_003.location = (1479.87646484375, -40.052001953125)
	    endpoint_selection_003.location = (1483.92578125, -169.96868896484375)
	    named_attribute_003.location = (1482.82568359375, -278.99554443359375)
	    endpoint_selection_004.location = (30.308837890625, -268.9384765625)
	    resample_curve_002.location = (423.59375, -83.68798828125)
	    frame_002.location = (33.0, 279.0)
	    frame_004.location = (1642.0, 916.0)
	    frame_005.location = (1641.0, -364.0)
	    group_input_011.location = (251.0174560546875, -292.35418701171875)
	    store_named_attribute_002.location = (1414.361328125, -39.95143127441406)
	    named_attribute.location = (184.399169921875, -333.18597412109375)
	    sample_curve_001.location = (401.980224609375, -39.946044921875)
	    named_attribute_002.location = (185.58740234375, -204.16964721679688)
	    spline_parameter_001.location = (29.58026123046875, -160.53384399414062)
	    group_input_001.location = (180.9580078125, -136.86257934570312)
	    frame_006.location = (912.0, -294.0)
	    compare_001.location = (3337.4560546875, 471.3868408203125)
	    switch.location = (3339.28564453125, 430.76947021484375)
	    reroute_2.location = (1628.2098388671875, 205.41177368164062)
	    reroute_003.location = (3306.314697265625, 420.6519470214844)
	    group_input_012.location = (481.392822265625, -289.1431884765625)
	    set_position_004.location = (248.5238037109375, -132.03399658203125)
	    resample_curve_003.location = (31.8914794921875, -136.28439331054688)
	    named_attribute_005.location = (31.5091552734375, -264.3312072753906)
	    set_position_005.location = (1288.53662109375, -63.96429443359375)
	    group_003.location = (30.181640625, -40.00811767578125)
	    geometry_proximity_003.location = (226.56689453125, -55.75982666015625)
	    position_004.location = (600.649169921875, -155.99188232421875)
	    capture_attribute_004.location = (605.345458984375, -116.99896240234375)
	    sample_nearest_002.location = (219.09765625, -108.14801025390625)
	    sample_index_003.location = (218.489990234375, -164.47625732421875)
	    normal_001.location = (218.097900390625, -207.07696533203125)
	    vector_math_004.location = (427.796142578125, -124.88201904296875)
	    vector_math_005.location = (431.01025390625, -162.11260986328125)
	    frame_007.location = (645.0, -201.0)
	    set_position_006.location = (1479.87646484375, -39.87945556640625)
	    endpoint_selection_005.location = (1483.92578125, -169.796142578125)
	    named_attribute_006.location = (1482.82568359375, -278.822998046875)
	    endpoint_selection_006.location = (30.308837890625, -392.72674560546875)
	    resample_curve_004.location = (423.59375, -83.51544189453125)
	    frame_008.location = (1642.0, 362.0)
	    group_input_013.location = (251.0174560546875, -292.181640625)
	    named_attribute_007.location = (32.5084228515625, -447.3848571777344)
	    compare_002_2.location = (245.789306640625, -479.08599853515625)
	    boolean_math_001.location = (246.29541015625, -444.54998779296875)
	    group_input_004.location = (107.7052001953125, -574.0958251953125)
	    group_input_005.location = (3334.1142578125, 533.6339721679688)
	    reroute_004.location = (384.0848388671875, -403.8489685058594)
	    reroute_005.location = (216.0511474609375, -404.75439453125)
	    reroute_006.location = (212.7392578125, -213.84542846679688)
	    reroute_007.location = (3346.520263671875, 289.7437438964844)
	    reroute_008.location = (3305.447509765625, 843.1121215820312)
	    reroute_009.location = (1628.7208251953125, 676.697265625)
	    reroute_010.location = (1630.5013427734375, 142.2026824951172)
	    reroute_011.location = (1276.199951171875, -489.1041564941406)
	    reroute_012.location = (1271.703857421875, -146.008544921875)
	    reroute_013.location = (389.7847900390625, -535.7088623046875)
	    reroute_014.location = (1648.470947265625, -173.8117218017578)
	    reroute_015.location = (1648.327880859375, 120.57612609863281)
	    compare_003.location = (2574.45703125, -377.06903076171875)
	    switch_001_2.location = (2576.286865234375, -417.6863708496094)
	    group_input_006.location = (2415.0146484375, -375.71240234375)
	    group_input_014.location = (2414.96044921875, -313.86309814453125)
	    math.location = (2577.8759765625, -335.2984313964844)
	
	    #Set dimensions
	    group_input_2.width, group_input_2.height = 140.0, 100.0
	    group_output_3.width, group_output_3.height = 140.0, 100.0
	    store_named_attribute.width, store_named_attribute.height = 140.0, 100.0
	    sample_nearest.width, sample_nearest.height = 140.0, 100.0
	    sample_curve.width, sample_curve.height = 140.0, 100.0
	    index.width, index.height = 140.0, 100.0
	    group_input_002.width, group_input_002.height = 140.0, 100.0
	    group_input_003.width, group_input_003.height = 140.0, 100.0
	    group_input_008.width, group_input_008.height = 140.0, 100.0
	    group_001.width, group_001.height = 140.0, 100.0
	    group_input_007.width, group_input_007.height = 140.0, 100.0
	    group_002.width, group_002.height = 140.0, 100.0
	    group_input_009.width, group_input_009.height = 140.0, 100.0
	    geometry_proximity.width, geometry_proximity.height = 140.0, 100.0
	    capture_attribute.width, capture_attribute.height = 140.0, 100.0
	    position.width, position.height = 140.0, 100.0
	    compare.width, compare.height = 140.0, 100.0
	    group_input_010.width, group_input_010.height = 140.0, 100.0
	    delete_geometry.width, delete_geometry.height = 140.0, 100.0
	    frame_001.width, frame_001.height = 822.0, 334.0
	    store_named_attribute_001.width, store_named_attribute_001.height = 140.0, 100.0
	    group_004.width, group_004.height = 140.0, 100.0
	    geometry_proximity_001.width, geometry_proximity_001.height = 140.0, 100.0
	    reroute_001.width, reroute_001.height = 100.0, 100.0
	    reroute_002.width, reroute_002.height = 100.0, 100.0
	    sample_index.width, sample_index.height = 140.0, 100.0
	    position_001.width, position_001.height = 140.0, 100.0
	    vector_math.width, vector_math.height = 140.0, 100.0
	    vector_math_001.width, vector_math_001.height = 140.0, 100.0
	    sample_index_002.width, sample_index_002.height = 140.0, 100.0
	    mesh_island.width, mesh_island.height = 140.0, 100.0
	    frame_003.width, frame_003.height = 202.0, 161.0
	    store_named_attribute_003.width, store_named_attribute_003.height = 140.0, 100.0
	    curve_to_mesh_001.width, curve_to_mesh_001.height = 140.0, 100.0
	    resample_curve.width, resample_curve.height = 140.0, 100.0
	    store_named_attribute_004.width, store_named_attribute_004.height = 140.0, 100.0
	    store_named_attribute_005.width, store_named_attribute_005.height = 140.0, 100.0
	    store_named_attribute_006.width, store_named_attribute_006.height = 140.0, 100.0
	    set_position_001.width, set_position_001.height = 140.0, 100.0
	    resample_curve_001.width, resample_curve_001.height = 140.0, 100.0
	    named_attribute_001.width, named_attribute_001.height = 140.0, 100.0
	    set_position_002.width, set_position_002.height = 140.0, 100.0
	    group.width, group.height = 140.0, 100.0
	    geometry_proximity_002.width, geometry_proximity_002.height = 140.0, 100.0
	    position_003.width, position_003.height = 140.0, 100.0
	    capture_attribute_003.width, capture_attribute_003.height = 140.0, 100.0
	    hair_to_surface_shape.width, hair_to_surface_shape.height = 700.0, 100.0
	    spline_parameter.width, spline_parameter.height = 140.0, 100.0
	    sample_nearest_001.width, sample_nearest_001.height = 140.0, 100.0
	    sample_index_001.width, sample_index_001.height = 140.0, 100.0
	    normal.width, normal.height = 140.0, 100.0
	    vector_math_002.width, vector_math_002.height = 140.0, 100.0
	    vector_math_003.width, vector_math_003.height = 140.0, 100.0
	    frame.width, frame.height = 601.0, 315.0
	    set_position_003.width, set_position_003.height = 140.0, 100.0
	    endpoint_selection_003.width, endpoint_selection_003.height = 140.0, 100.0
	    named_attribute_003.width, named_attribute_003.height = 140.0, 100.0
	    endpoint_selection_004.width, endpoint_selection_004.height = 140.0, 100.0
	    resample_curve_002.width, resample_curve_002.height = 140.0, 100.0
	    frame_002.width, frame_002.height = 1584.0, 269.0
	    frame_004.width, frame_004.height = 1654.0, 546.0
	    frame_005.width, frame_005.height = 760.0, 415.0
	    group_input_011.width, group_input_011.height = 140.0, 100.0
	    store_named_attribute_002.width, store_named_attribute_002.height = 140.0, 100.0
	    named_attribute.width, named_attribute.height = 140.0, 100.0
	    sample_curve_001.width, sample_curve_001.height = 140.0, 100.0
	    named_attribute_002.width, named_attribute_002.height = 140.0, 100.0
	    spline_parameter_001.width, spline_parameter_001.height = 140.0, 100.0
	    group_input_001.width, group_input_001.height = 140.0, 100.0
	    frame_006.width, frame_006.height = 572.0, 484.0
	    compare_001.width, compare_001.height = 140.0, 100.0
	    switch.width, switch.height = 140.0, 100.0
	    reroute_2.width, reroute_2.height = 100.0, 100.0
	    reroute_003.width, reroute_003.height = 100.0, 100.0
	    group_input_012.width, group_input_012.height = 140.0, 100.0
	    set_position_004.width, set_position_004.height = 140.0, 100.0
	    resample_curve_003.width, resample_curve_003.height = 140.0, 100.0
	    named_attribute_005.width, named_attribute_005.height = 140.0, 100.0
	    set_position_005.width, set_position_005.height = 140.0, 100.0
	    group_003.width, group_003.height = 140.0, 100.0
	    geometry_proximity_003.width, geometry_proximity_003.height = 140.0, 100.0
	    position_004.width, position_004.height = 140.0, 100.0
	    capture_attribute_004.width, capture_attribute_004.height = 140.0, 100.0
	    sample_nearest_002.width, sample_nearest_002.height = 140.0, 100.0
	    sample_index_003.width, sample_index_003.height = 140.0, 100.0
	    normal_001.width, normal_001.height = 140.0, 100.0
	    vector_math_004.width, vector_math_004.height = 140.0, 100.0
	    vector_math_005.width, vector_math_005.height = 140.0, 100.0
	    frame_007.width, frame_007.height = 601.0, 315.0
	    set_position_006.width, set_position_006.height = 140.0, 100.0
	    endpoint_selection_005.width, endpoint_selection_005.height = 140.0, 100.0
	    named_attribute_006.width, named_attribute_006.height = 140.0, 100.0
	    endpoint_selection_006.width, endpoint_selection_006.height = 140.0, 100.0
	    resample_curve_004.width, resample_curve_004.height = 140.0, 100.0
	    frame_008.width, frame_008.height = 1654.0, 656.0
	    group_input_013.width, group_input_013.height = 140.0, 100.0
	    named_attribute_007.width, named_attribute_007.height = 140.0, 100.0
	    compare_002_2.width, compare_002_2.height = 140.0, 100.0
	    boolean_math_001.width, boolean_math_001.height = 140.0, 100.0
	    group_input_004.width, group_input_004.height = 140.0, 100.0
	    group_input_005.width, group_input_005.height = 140.0, 100.0
	    reroute_004.width, reroute_004.height = 100.0, 100.0
	    reroute_005.width, reroute_005.height = 100.0, 100.0
	    reroute_006.width, reroute_006.height = 100.0, 100.0
	    reroute_007.width, reroute_007.height = 100.0, 100.0
	    reroute_008.width, reroute_008.height = 100.0, 100.0
	    reroute_009.width, reroute_009.height = 100.0, 100.0
	    reroute_010.width, reroute_010.height = 100.0, 100.0
	    reroute_011.width, reroute_011.height = 100.0, 100.0
	    reroute_012.width, reroute_012.height = 100.0, 100.0
	    reroute_013.width, reroute_013.height = 100.0, 100.0
	    reroute_014.width, reroute_014.height = 100.0, 100.0
	    reroute_015.width, reroute_015.height = 100.0, 100.0
	    compare_003.width, compare_003.height = 140.0, 100.0
	    switch_001_2.width, switch_001_2.height = 140.0, 100.0
	    group_input_006.width, group_input_006.height = 140.0, 100.0
	    group_input_014.width, group_input_014.height = 140.0, 100.0
	    math.width, math.height = 140.0, 100.0
	
	    #initialize shape_curve_to_closest_point links
	    #store_named_attribute_001.Geometry -> store_named_attribute.Geometry
	    shape_curve_to_closest_point.links.new(store_named_attribute_001.outputs[0], store_named_attribute.inputs[0])
	    #index.Index -> sample_curve.Curve Index
	    shape_curve_to_closest_point.links.new(index.outputs[0], sample_curve.inputs[4])
	    #sample_curve.Position -> sample_nearest.Sample Position
	    shape_curve_to_closest_point.links.new(sample_curve.outputs[1], sample_nearest.inputs[1])
	    #group_input_002.Geometry -> sample_curve.Curves
	    shape_curve_to_closest_point.links.new(group_input_002.outputs[0], sample_curve.inputs[0])
	    #group_input_003.Guide Curve -> group_001.Geometry
	    shape_curve_to_closest_point.links.new(group_input_003.outputs[3], group_001.inputs[0])
	    #group_input_009.Surface -> group_002.Geometry
	    shape_curve_to_closest_point.links.new(group_input_009.outputs[1], group_002.inputs[0])
	    #group_input_009.Surface -> group_002.Object
	    shape_curve_to_closest_point.links.new(group_input_009.outputs[2], group_002.inputs[1])
	    #group_002.Geometry -> geometry_proximity.Geometry
	    shape_curve_to_closest_point.links.new(group_002.outputs[0], geometry_proximity.inputs[0])
	    #group_input_003.Guide Curve -> group_001.Object
	    shape_curve_to_closest_point.links.new(group_input_003.outputs[4], group_001.inputs[1])
	    #group_input_010.Sample Surface Distance -> compare.B
	    shape_curve_to_closest_point.links.new(group_input_010.outputs[8], compare.inputs[1])
	    #geometry_proximity.Distance -> compare.A
	    shape_curve_to_closest_point.links.new(geometry_proximity.outputs[1], compare.inputs[0])
	    #position.Position -> capture_attribute.Position
	    shape_curve_to_closest_point.links.new(position.outputs[0], capture_attribute.inputs[1])
	    #capture_attribute.Position -> geometry_proximity.Sample Position
	    shape_curve_to_closest_point.links.new(capture_attribute.outputs[1], geometry_proximity.inputs[2])
	    #capture_attribute.Geometry -> delete_geometry.Geometry
	    shape_curve_to_closest_point.links.new(capture_attribute.outputs[0], delete_geometry.inputs[0])
	    #compare.Result -> delete_geometry.Selection
	    shape_curve_to_closest_point.links.new(compare.outputs[0], delete_geometry.inputs[1])
	    #delete_geometry.Geometry -> sample_nearest.Geometry
	    shape_curve_to_closest_point.links.new(delete_geometry.outputs[0], sample_nearest.inputs[0])
	    #group_input_2.Geometry -> store_named_attribute_001.Geometry
	    shape_curve_to_closest_point.links.new(group_input_2.outputs[0], store_named_attribute_001.inputs[0])
	    #reroute_001.Output -> geometry_proximity_001.Geometry
	    shape_curve_to_closest_point.links.new(reroute_001.outputs[0], geometry_proximity_001.inputs[0])
	    #group_004.Root Position -> geometry_proximity_001.Sample Position
	    shape_curve_to_closest_point.links.new(group_004.outputs[1], geometry_proximity_001.inputs[2])
	    #geometry_proximity_001.Position -> store_named_attribute_001.Value
	    shape_curve_to_closest_point.links.new(geometry_proximity_001.outputs[0], store_named_attribute_001.inputs[3])
	    #reroute_002.Output -> reroute_001.Input
	    shape_curve_to_closest_point.links.new(reroute_002.outputs[0], reroute_001.inputs[0])
	    #group_002.Geometry -> reroute_002.Input
	    shape_curve_to_closest_point.links.new(group_002.outputs[0], reroute_002.inputs[0])
	    #sample_nearest.Index -> store_named_attribute.Value
	    shape_curve_to_closest_point.links.new(sample_nearest.outputs[0], store_named_attribute.inputs[3])
	    #sample_nearest.Index -> sample_index.Index
	    shape_curve_to_closest_point.links.new(sample_nearest.outputs[0], sample_index.inputs[2])
	    #position_001.Position -> sample_index.Value
	    shape_curve_to_closest_point.links.new(position_001.outputs[0], sample_index.inputs[1])
	    #delete_geometry.Geometry -> sample_index.Geometry
	    shape_curve_to_closest_point.links.new(delete_geometry.outputs[0], sample_index.inputs[0])
	    #vector_math.Vector -> vector_math_001.Vector
	    shape_curve_to_closest_point.links.new(vector_math.outputs[0], vector_math_001.inputs[0])
	    #sample_nearest.Index -> sample_index_002.Index
	    shape_curve_to_closest_point.links.new(sample_nearest.outputs[0], sample_index_002.inputs[2])
	    #delete_geometry.Geometry -> sample_index_002.Geometry
	    shape_curve_to_closest_point.links.new(delete_geometry.outputs[0], sample_index_002.inputs[0])
	    #mesh_island.Island Index -> sample_index_002.Value
	    shape_curve_to_closest_point.links.new(mesh_island.outputs[0], sample_index_002.inputs[1])
	    #store_named_attribute_005.Geometry -> store_named_attribute_003.Geometry
	    shape_curve_to_closest_point.links.new(store_named_attribute_005.outputs[0], store_named_attribute_003.inputs[0])
	    #curve_to_mesh_001.Mesh -> capture_attribute.Geometry
	    shape_curve_to_closest_point.links.new(curve_to_mesh_001.outputs[0], capture_attribute.inputs[0])
	    #group_input_007.Sample Surface Count -> resample_curve.Count
	    shape_curve_to_closest_point.links.new(group_input_007.outputs[7], resample_curve.inputs[2])
	    #group_001.Geometry -> resample_curve.Curve
	    shape_curve_to_closest_point.links.new(group_001.outputs[0], resample_curve.inputs[0])
	    #resample_curve.Curve -> curve_to_mesh_001.Curve
	    shape_curve_to_closest_point.links.new(resample_curve.outputs[0], curve_to_mesh_001.inputs[0])
	    #store_named_attribute.Geometry -> store_named_attribute_004.Geometry
	    shape_curve_to_closest_point.links.new(store_named_attribute.outputs[0], store_named_attribute_004.inputs[0])
	    #sample_index.Value -> store_named_attribute_004.Value
	    shape_curve_to_closest_point.links.new(sample_index.outputs[0], store_named_attribute_004.inputs[3])
	    #store_named_attribute_004.Geometry -> store_named_attribute_005.Geometry
	    shape_curve_to_closest_point.links.new(store_named_attribute_004.outputs[0], store_named_attribute_005.inputs[0])
	    #vector_math_001.Value -> store_named_attribute_005.Value
	    shape_curve_to_closest_point.links.new(vector_math_001.outputs[1], store_named_attribute_005.inputs[3])
	    #store_named_attribute_003.Geometry -> store_named_attribute_006.Geometry
	    shape_curve_to_closest_point.links.new(store_named_attribute_003.outputs[0], store_named_attribute_006.inputs[0])
	    #sample_index_002.Value -> store_named_attribute_006.Value
	    shape_curve_to_closest_point.links.new(sample_index_002.outputs[0], store_named_attribute_006.inputs[3])
	    #sample_curve.Position -> vector_math.Vector
	    shape_curve_to_closest_point.links.new(sample_curve.outputs[1], vector_math.inputs[1])
	    #sample_index.Value -> vector_math.Vector
	    shape_curve_to_closest_point.links.new(sample_index.outputs[0], vector_math.inputs[0])
	    #vector_math.Vector -> store_named_attribute_003.Value
	    shape_curve_to_closest_point.links.new(vector_math.outputs[0], store_named_attribute_003.inputs[3])
	    #resample_curve_001.Curve -> set_position_001.Geometry
	    shape_curve_to_closest_point.links.new(resample_curve_001.outputs[0], set_position_001.inputs[0])
	    #named_attribute_001.Attribute -> set_position_001.Position
	    shape_curve_to_closest_point.links.new(named_attribute_001.outputs[0], set_position_001.inputs[2])
	    #capture_attribute_003.Geometry -> set_position_002.Geometry
	    shape_curve_to_closest_point.links.new(capture_attribute_003.outputs[0], set_position_002.inputs[0])
	    #group.Geometry -> geometry_proximity_002.Geometry
	    shape_curve_to_closest_point.links.new(group.outputs[0], geometry_proximity_002.inputs[0])
	    #resample_curve_002.Curve -> capture_attribute_003.Geometry
	    shape_curve_to_closest_point.links.new(resample_curve_002.outputs[0], capture_attribute_003.inputs[0])
	    #position_003.Position -> capture_attribute_003.Position
	    shape_curve_to_closest_point.links.new(position_003.outputs[0], capture_attribute_003.inputs[1])
	    #capture_attribute_003.Position -> geometry_proximity_002.Sample Position
	    shape_curve_to_closest_point.links.new(capture_attribute_003.outputs[1], geometry_proximity_002.inputs[2])
	    #spline_parameter.Factor -> hair_to_surface_shape.Value
	    shape_curve_to_closest_point.links.new(spline_parameter.outputs[0], hair_to_surface_shape.inputs[1])
	    #group.Geometry -> sample_nearest_001.Geometry
	    shape_curve_to_closest_point.links.new(group.outputs[0], sample_nearest_001.inputs[0])
	    #capture_attribute_003.Position -> sample_nearest_001.Sample Position
	    shape_curve_to_closest_point.links.new(capture_attribute_003.outputs[1], sample_nearest_001.inputs[1])
	    #group.Geometry -> sample_index_001.Geometry
	    shape_curve_to_closest_point.links.new(group.outputs[0], sample_index_001.inputs[0])
	    #sample_nearest_001.Index -> sample_index_001.Index
	    shape_curve_to_closest_point.links.new(sample_nearest_001.outputs[0], sample_index_001.inputs[2])
	    #normal.Normal -> sample_index_001.Value
	    shape_curve_to_closest_point.links.new(normal.outputs[0], sample_index_001.inputs[1])
	    #geometry_proximity_002.Position -> vector_math_002.Vector
	    shape_curve_to_closest_point.links.new(geometry_proximity_002.outputs[0], vector_math_002.inputs[0])
	    #set_position_002.Geometry -> set_position_003.Geometry
	    shape_curve_to_closest_point.links.new(set_position_002.outputs[0], set_position_003.inputs[0])
	    #endpoint_selection_003.Selection -> set_position_003.Selection
	    shape_curve_to_closest_point.links.new(endpoint_selection_003.outputs[0], set_position_003.inputs[1])
	    #sample_index_001.Value -> vector_math_003.Vector
	    shape_curve_to_closest_point.links.new(sample_index_001.outputs[0], vector_math_003.inputs[0])
	    #vector_math_003.Vector -> vector_math_002.Vector
	    shape_curve_to_closest_point.links.new(vector_math_003.outputs[0], vector_math_002.inputs[1])
	    #vector_math_002.Vector -> set_position_002.Position
	    shape_curve_to_closest_point.links.new(vector_math_002.outputs[0], set_position_002.inputs[2])
	    #named_attribute_003.Attribute -> set_position_003.Position
	    shape_curve_to_closest_point.links.new(named_attribute_003.outputs[0], set_position_003.inputs[2])
	    #endpoint_selection_004.Selection -> set_position_001.Selection
	    shape_curve_to_closest_point.links.new(endpoint_selection_004.outputs[0], set_position_001.inputs[1])
	    #set_position_001.Geometry -> resample_curve_002.Curve
	    shape_curve_to_closest_point.links.new(set_position_001.outputs[0], resample_curve_002.inputs[0])
	    #reroute_009.Output -> resample_curve_001.Curve
	    shape_curve_to_closest_point.links.new(reroute_009.outputs[0], resample_curve_001.inputs[0])
	    #group_input_008.Surface -> group.Geometry
	    shape_curve_to_closest_point.links.new(group_input_008.outputs[1], group.inputs[0])
	    #group_input_008.Surface -> group.Object
	    shape_curve_to_closest_point.links.new(group_input_008.outputs[2], group.inputs[1])
	    #group_input_011.Control Points -> resample_curve_002.Count
	    shape_curve_to_closest_point.links.new(group_input_011.outputs[5], resample_curve_002.inputs[2])
	    #named_attribute.Attribute -> sample_curve_001.Curve Index
	    shape_curve_to_closest_point.links.new(named_attribute.outputs[0], sample_curve_001.inputs[4])
	    #named_attribute_002.Attribute -> sample_curve_001.Factor
	    shape_curve_to_closest_point.links.new(named_attribute_002.outputs[0], sample_curve_001.inputs[2])
	    #spline_parameter_001.Factor -> sample_curve_001.Value
	    shape_curve_to_closest_point.links.new(spline_parameter_001.outputs[0], sample_curve_001.inputs[1])
	    #store_named_attribute_006.Geometry -> store_named_attribute_002.Geometry
	    shape_curve_to_closest_point.links.new(store_named_attribute_006.outputs[0], store_named_attribute_002.inputs[0])
	    #group_input_001.Geometry -> sample_curve_001.Curves
	    shape_curve_to_closest_point.links.new(group_input_001.outputs[0], sample_curve_001.inputs[0])
	    #sample_curve_001.Value -> store_named_attribute_002.Value
	    shape_curve_to_closest_point.links.new(sample_curve_001.outputs[0], store_named_attribute_002.inputs[3])
	    #store_named_attribute_002.Geometry -> reroute_2.Input
	    shape_curve_to_closest_point.links.new(store_named_attribute_002.outputs[0], reroute_2.inputs[0])
	    #reroute_008.Output -> reroute_003.Input
	    shape_curve_to_closest_point.links.new(reroute_008.outputs[0], reroute_003.inputs[0])
	    #resample_curve_003.Curve -> set_position_004.Geometry
	    shape_curve_to_closest_point.links.new(resample_curve_003.outputs[0], set_position_004.inputs[0])
	    #named_attribute_005.Attribute -> set_position_004.Position
	    shape_curve_to_closest_point.links.new(named_attribute_005.outputs[0], set_position_004.inputs[2])
	    #capture_attribute_004.Geometry -> set_position_005.Geometry
	    shape_curve_to_closest_point.links.new(capture_attribute_004.outputs[0], set_position_005.inputs[0])
	    #group_003.Geometry -> geometry_proximity_003.Geometry
	    shape_curve_to_closest_point.links.new(group_003.outputs[0], geometry_proximity_003.inputs[0])
	    #resample_curve_004.Curve -> capture_attribute_004.Geometry
	    shape_curve_to_closest_point.links.new(resample_curve_004.outputs[0], capture_attribute_004.inputs[0])
	    #position_004.Position -> capture_attribute_004.Position
	    shape_curve_to_closest_point.links.new(position_004.outputs[0], capture_attribute_004.inputs[1])
	    #capture_attribute_004.Position -> geometry_proximity_003.Sample Position
	    shape_curve_to_closest_point.links.new(capture_attribute_004.outputs[1], geometry_proximity_003.inputs[2])
	    #group_003.Geometry -> sample_nearest_002.Geometry
	    shape_curve_to_closest_point.links.new(group_003.outputs[0], sample_nearest_002.inputs[0])
	    #capture_attribute_004.Position -> sample_nearest_002.Sample Position
	    shape_curve_to_closest_point.links.new(capture_attribute_004.outputs[1], sample_nearest_002.inputs[1])
	    #group_003.Geometry -> sample_index_003.Geometry
	    shape_curve_to_closest_point.links.new(group_003.outputs[0], sample_index_003.inputs[0])
	    #sample_nearest_002.Index -> sample_index_003.Index
	    shape_curve_to_closest_point.links.new(sample_nearest_002.outputs[0], sample_index_003.inputs[2])
	    #normal_001.Normal -> sample_index_003.Value
	    shape_curve_to_closest_point.links.new(normal_001.outputs[0], sample_index_003.inputs[1])
	    #geometry_proximity_003.Position -> vector_math_004.Vector
	    shape_curve_to_closest_point.links.new(geometry_proximity_003.outputs[0], vector_math_004.inputs[0])
	    #set_position_005.Geometry -> set_position_006.Geometry
	    shape_curve_to_closest_point.links.new(set_position_005.outputs[0], set_position_006.inputs[0])
	    #endpoint_selection_005.Selection -> set_position_006.Selection
	    shape_curve_to_closest_point.links.new(endpoint_selection_005.outputs[0], set_position_006.inputs[1])
	    #sample_index_003.Value -> vector_math_005.Vector
	    shape_curve_to_closest_point.links.new(sample_index_003.outputs[0], vector_math_005.inputs[0])
	    #vector_math_005.Vector -> vector_math_004.Vector
	    shape_curve_to_closest_point.links.new(vector_math_005.outputs[0], vector_math_004.inputs[1])
	    #vector_math_004.Vector -> set_position_005.Position
	    shape_curve_to_closest_point.links.new(vector_math_004.outputs[0], set_position_005.inputs[2])
	    #named_attribute_006.Attribute -> set_position_006.Position
	    shape_curve_to_closest_point.links.new(named_attribute_006.outputs[0], set_position_006.inputs[2])
	    #set_position_004.Geometry -> resample_curve_004.Curve
	    shape_curve_to_closest_point.links.new(set_position_004.outputs[0], resample_curve_004.inputs[0])
	    #group_input_012.Surface -> group_003.Geometry
	    shape_curve_to_closest_point.links.new(group_input_012.outputs[1], group_003.inputs[0])
	    #group_input_012.Surface -> group_003.Object
	    shape_curve_to_closest_point.links.new(group_input_012.outputs[2], group_003.inputs[1])
	    #group_input_013.Control Points -> resample_curve_004.Count
	    shape_curve_to_closest_point.links.new(group_input_013.outputs[5], resample_curve_004.inputs[2])
	    #named_attribute_007.Attribute -> compare_002_2.A
	    shape_curve_to_closest_point.links.new(named_attribute_007.outputs[0], compare_002_2.inputs[0])
	    #compare_002_2.Result -> boolean_math_001.Boolean
	    shape_curve_to_closest_point.links.new(compare_002_2.outputs[0], boolean_math_001.inputs[1])
	    #reroute_010.Output -> resample_curve_003.Curve
	    shape_curve_to_closest_point.links.new(reroute_010.outputs[0], resample_curve_003.inputs[0])
	    #group_input_004.Max Influence Distance -> compare_002_2.B
	    shape_curve_to_closest_point.links.new(group_input_004.outputs[9], compare_002_2.inputs[1])
	    #group_input_005.Max Influence Distance -> compare_001.A
	    shape_curve_to_closest_point.links.new(group_input_005.outputs[9], compare_001.inputs[0])
	    #compare_001.Result -> switch.Switch
	    shape_curve_to_closest_point.links.new(compare_001.outputs[0], switch.inputs[0])
	    #reroute_003.Output -> switch.False
	    shape_curve_to_closest_point.links.new(reroute_003.outputs[0], switch.inputs[1])
	    #reroute_007.Output -> switch.True
	    shape_curve_to_closest_point.links.new(reroute_007.outputs[0], switch.inputs[2])
	    #endpoint_selection_006.Selection -> boolean_math_001.Boolean
	    shape_curve_to_closest_point.links.new(endpoint_selection_006.outputs[0], boolean_math_001.inputs[0])
	    #reroute_006.Output -> set_position_004.Selection
	    shape_curve_to_closest_point.links.new(reroute_006.outputs[0], set_position_004.inputs[1])
	    #boolean_math_001.Boolean -> reroute_004.Input
	    shape_curve_to_closest_point.links.new(boolean_math_001.outputs[0], reroute_004.inputs[0])
	    #reroute_004.Output -> reroute_005.Input
	    shape_curve_to_closest_point.links.new(reroute_004.outputs[0], reroute_005.inputs[0])
	    #reroute_005.Output -> reroute_006.Input
	    shape_curve_to_closest_point.links.new(reroute_005.outputs[0], reroute_006.inputs[0])
	    #reroute_015.Output -> resample_curve_003.Selection
	    shape_curve_to_closest_point.links.new(reroute_015.outputs[0], resample_curve_003.inputs[1])
	    #reroute_012.Output -> set_position_005.Selection
	    shape_curve_to_closest_point.links.new(reroute_012.outputs[0], set_position_005.inputs[1])
	    #switch.Output -> group_output_3.Geometry
	    shape_curve_to_closest_point.links.new(switch.outputs[0], group_output_3.inputs[0])
	    #set_position_006.Geometry -> reroute_007.Input
	    shape_curve_to_closest_point.links.new(set_position_006.outputs[0], reroute_007.inputs[0])
	    #set_position_003.Geometry -> reroute_008.Input
	    shape_curve_to_closest_point.links.new(set_position_003.outputs[0], reroute_008.inputs[0])
	    #reroute_2.Output -> reroute_009.Input
	    shape_curve_to_closest_point.links.new(reroute_2.outputs[0], reroute_009.inputs[0])
	    #reroute_2.Output -> reroute_010.Input
	    shape_curve_to_closest_point.links.new(reroute_2.outputs[0], reroute_010.inputs[0])
	    #compare_002_2.Result -> reroute_011.Input
	    shape_curve_to_closest_point.links.new(compare_002_2.outputs[0], reroute_011.inputs[0])
	    #reroute_011.Output -> reroute_012.Input
	    shape_curve_to_closest_point.links.new(reroute_011.outputs[0], reroute_012.inputs[0])
	    #compare_002_2.Result -> reroute_013.Input
	    shape_curve_to_closest_point.links.new(compare_002_2.outputs[0], reroute_013.inputs[0])
	    #reroute_013.Output -> reroute_014.Input
	    shape_curve_to_closest_point.links.new(reroute_013.outputs[0], reroute_014.inputs[0])
	    #reroute_014.Output -> reroute_015.Input
	    shape_curve_to_closest_point.links.new(reroute_014.outputs[0], reroute_015.inputs[0])
	    #compare_003.Result -> switch_001_2.Switch
	    shape_curve_to_closest_point.links.new(compare_003.outputs[0], switch_001_2.inputs[0])
	    #group_input_006.Offset from Surface -> compare_003.A
	    shape_curve_to_closest_point.links.new(group_input_006.outputs[10], compare_003.inputs[0])
	    #group_input_006.Offset from Surface -> switch_001_2.False
	    shape_curve_to_closest_point.links.new(group_input_006.outputs[10], switch_001_2.inputs[1])
	    #hair_to_surface_shape.Value -> switch_001_2.True
	    shape_curve_to_closest_point.links.new(hair_to_surface_shape.outputs[0], switch_001_2.inputs[2])
	    #group_input_014.Hair Shape Offset -> math.Value
	    shape_curve_to_closest_point.links.new(group_input_014.outputs[6], math.inputs[0])
	    #switch_001_2.Output -> math.Value
	    shape_curve_to_closest_point.links.new(switch_001_2.outputs[0], math.inputs[1])
	    #math.Value -> vector_math_005.Scale
	    shape_curve_to_closest_point.links.new(math.outputs[0], vector_math_005.inputs[3])
	    #math.Value -> vector_math_003.Scale
	    shape_curve_to_closest_point.links.new(math.outputs[0], vector_math_003.inputs[3])
	    return shape_curve_to_closest_point
	
	shape_curve_to_closest_point = shape_curve_to_closest_point_node_group()
	
	#initialize curve_tip node group
	def curve_tip_node_group():
	    curve_tip = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Curve Tip")
	
	    curve_tip.color_tag = 'NONE'
	    curve_tip.description = "Reads information about each curve's tip point"
	    curve_tip.default_group_node_width = 140
	    
	
	
	    #curve_tip interface
	    #Socket Tip Selection
	    tip_selection_socket = curve_tip.interface.new_socket(name = "Tip Selection", in_out='OUTPUT', socket_type = 'NodeSocketBool')
	    tip_selection_socket.default_value = False
	    tip_selection_socket.attribute_domain = 'POINT'
	    tip_selection_socket.description = "Boolean selection of curve tip points"
	
	    #Socket Tip Position
	    tip_position_socket = curve_tip.interface.new_socket(name = "Tip Position", in_out='OUTPUT', socket_type = 'NodeSocketVector')
	    tip_position_socket.default_value = (0.0, 0.0, 0.0)
	    tip_position_socket.min_value = -3.4028234663852886e+38
	    tip_position_socket.max_value = 3.4028234663852886e+38
	    tip_position_socket.subtype = 'NONE'
	    tip_position_socket.attribute_domain = 'CURVE'
	    tip_position_socket.description = "Position of the tip point of a curve"
	
	    #Socket Tip Direction
	    tip_direction_socket = curve_tip.interface.new_socket(name = "Tip Direction", in_out='OUTPUT', socket_type = 'NodeSocketVector')
	    tip_direction_socket.default_value = (0.0, 0.0, 0.0)
	    tip_direction_socket.min_value = -3.4028234663852886e+38
	    tip_direction_socket.max_value = 3.4028234663852886e+38
	    tip_direction_socket.subtype = 'NONE'
	    tip_direction_socket.attribute_domain = 'CURVE'
	    tip_direction_socket.description = "Direction of the tip segment of a curve"
	
	    #Socket Tip Index
	    tip_index_socket = curve_tip.interface.new_socket(name = "Tip Index", in_out='OUTPUT', socket_type = 'NodeSocketInt')
	    tip_index_socket.default_value = 0
	    tip_index_socket.min_value = -2147483648
	    tip_index_socket.max_value = 2147483647
	    tip_index_socket.subtype = 'NONE'
	    tip_index_socket.attribute_domain = 'CURVE'
	    tip_index_socket.description = "Index of the tip point of a curve"
	
	
	    #initialize curve_tip nodes
	    #node Position.002
	    position_002_1 = curve_tip.nodes.new("GeometryNodeInputPosition")
	    position_002_1.name = "Position.002"
	
	    #node Interpolate Domain
	    interpolate_domain_1 = curve_tip.nodes.new("GeometryNodeFieldOnDomain")
	    interpolate_domain_1.name = "Interpolate Domain"
	    interpolate_domain_1.data_type = 'INT'
	    interpolate_domain_1.domain = 'CURVE'
	
	    #node Interpolate Domain.001
	    interpolate_domain_001_1 = curve_tip.nodes.new("GeometryNodeFieldOnDomain")
	    interpolate_domain_001_1.name = "Interpolate Domain.001"
	    interpolate_domain_001_1.data_type = 'FLOAT_VECTOR'
	    interpolate_domain_001_1.domain = 'CURVE'
	
	    #node Field at Index.003
	    field_at_index_003_1 = curve_tip.nodes.new("GeometryNodeFieldAtIndex")
	    field_at_index_003_1.name = "Field at Index.003"
	    field_at_index_003_1.data_type = 'FLOAT_VECTOR'
	    field_at_index_003_1.domain = 'POINT'
	
	    #node Curve Tangent
	    curve_tangent_1 = curve_tip.nodes.new("GeometryNodeInputTangent")
	    curve_tangent_1.name = "Curve Tangent"
	
	    #node Endpoint Selection
	    endpoint_selection_1 = curve_tip.nodes.new("GeometryNodeCurveEndpointSelection")
	    endpoint_selection_1.name = "Endpoint Selection"
	    #Start Size
	    endpoint_selection_1.inputs[0].default_value = 0
	    #End Size
	    endpoint_selection_1.inputs[1].default_value = 1
	
	    #node Field at Index.004
	    field_at_index_004_1 = curve_tip.nodes.new("GeometryNodeFieldAtIndex")
	    field_at_index_004_1.name = "Field at Index.004"
	    field_at_index_004_1.data_type = 'FLOAT_VECTOR'
	    field_at_index_004_1.domain = 'POINT'
	
	    #node Interpolate Domain.002
	    interpolate_domain_002_1 = curve_tip.nodes.new("GeometryNodeFieldOnDomain")
	    interpolate_domain_002_1.name = "Interpolate Domain.002"
	    interpolate_domain_002_1.data_type = 'FLOAT_VECTOR'
	    interpolate_domain_002_1.domain = 'CURVE'
	
	    #node Group Output
	    group_output_4 = curve_tip.nodes.new("NodeGroupOutput")
	    group_output_4.name = "Group Output"
	    group_output_4.is_active_output = True
	
	    #node Points of Curve
	    points_of_curve_1 = curve_tip.nodes.new("GeometryNodePointsOfCurve")
	    points_of_curve_1.name = "Points of Curve"
	    points_of_curve_1.inputs[0].hide = True
	    points_of_curve_1.inputs[1].hide = True
	    points_of_curve_1.outputs[1].hide = True
	    #Curve Index
	    points_of_curve_1.inputs[0].default_value = 0
	    #Weights
	    points_of_curve_1.inputs[1].default_value = 0.0
	    #Sort Index
	    points_of_curve_1.inputs[2].default_value = -1
	
	
	
	
	
	    #Set locations
	    position_002_1.location = (-628.2557983398438, -70.55813598632812)
	    interpolate_domain_1.location = (-628.2557983398438, 90.18605041503906)
	    interpolate_domain_001_1.location = (-246.4883575439453, 90.18605041503906)
	    field_at_index_003_1.location = (-427.3255615234375, 90.18605041503906)
	    curve_tangent_1.location = (-628.2557983398438, -231.3023223876953)
	    endpoint_selection_1.location = (-246.4883575439453, 210.7441864013672)
	    field_at_index_004_1.location = (-427.3255615234375, -90.65116882324219)
	    interpolate_domain_002_1.location = (-246.4883575439453, -90.65116882324219)
	    group_output_4.location = (75.0, 50.0)
	    points_of_curve_1.location = (-829.18603515625, 50.0)
	
	    #Set dimensions
	    position_002_1.width, position_002_1.height = 140.0, 100.0
	    interpolate_domain_1.width, interpolate_domain_1.height = 140.0, 100.0
	    interpolate_domain_001_1.width, interpolate_domain_001_1.height = 140.0, 100.0
	    field_at_index_003_1.width, field_at_index_003_1.height = 140.0, 100.0
	    curve_tangent_1.width, curve_tangent_1.height = 140.0, 100.0
	    endpoint_selection_1.width, endpoint_selection_1.height = 140.0, 100.0
	    field_at_index_004_1.width, field_at_index_004_1.height = 140.0, 100.0
	    interpolate_domain_002_1.width, interpolate_domain_002_1.height = 140.0, 100.0
	    group_output_4.width, group_output_4.height = 140.0, 100.0
	    points_of_curve_1.width, points_of_curve_1.height = 140.0, 100.0
	
	    #initialize curve_tip links
	    #position_002_1.Position -> field_at_index_003_1.Value
	    curve_tip.links.new(position_002_1.outputs[0], field_at_index_003_1.inputs[1])
	    #interpolate_domain_1.Value -> field_at_index_003_1.Index
	    curve_tip.links.new(interpolate_domain_1.outputs[0], field_at_index_003_1.inputs[0])
	    #points_of_curve_1.Point Index -> interpolate_domain_1.Value
	    curve_tip.links.new(points_of_curve_1.outputs[0], interpolate_domain_1.inputs[0])
	    #interpolate_domain_001_1.Value -> group_output_4.Tip Position
	    curve_tip.links.new(interpolate_domain_001_1.outputs[0], group_output_4.inputs[1])
	    #interpolate_domain_1.Value -> group_output_4.Tip Index
	    curve_tip.links.new(interpolate_domain_1.outputs[0], group_output_4.inputs[3])
	    #endpoint_selection_1.Selection -> group_output_4.Tip Selection
	    curve_tip.links.new(endpoint_selection_1.outputs[0], group_output_4.inputs[0])
	    #field_at_index_003_1.Value -> interpolate_domain_001_1.Value
	    curve_tip.links.new(field_at_index_003_1.outputs[0], interpolate_domain_001_1.inputs[0])
	    #interpolate_domain_002_1.Value -> group_output_4.Tip Direction
	    curve_tip.links.new(interpolate_domain_002_1.outputs[0], group_output_4.inputs[2])
	    #curve_tangent_1.Tangent -> field_at_index_004_1.Value
	    curve_tip.links.new(curve_tangent_1.outputs[0], field_at_index_004_1.inputs[1])
	    #interpolate_domain_1.Value -> field_at_index_004_1.Index
	    curve_tip.links.new(interpolate_domain_1.outputs[0], field_at_index_004_1.inputs[0])
	    #field_at_index_004_1.Value -> interpolate_domain_002_1.Value
	    curve_tip.links.new(field_at_index_004_1.outputs[0], interpolate_domain_002_1.inputs[0])
	    return curve_tip
	
	curve_tip = curve_tip_node_group()
	
	#initialize curve_info node group
	def curve_info_node_group():
	    curve_info = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Curve Info")
	
	    curve_info.color_tag = 'NONE'
	    curve_info.description = "Reads information about each curve"
	    curve_info.default_group_node_width = 140
	    
	
	
	    #curve_info interface
	    #Socket Curve Index
	    curve_index_socket = curve_info.interface.new_socket(name = "Curve Index", in_out='OUTPUT', socket_type = 'NodeSocketInt')
	    curve_index_socket.default_value = 0
	    curve_index_socket.min_value = -2147483648
	    curve_index_socket.max_value = 2147483647
	    curve_index_socket.subtype = 'NONE'
	    curve_index_socket.attribute_domain = 'CURVE'
	    curve_index_socket.description = "Index of each Curve"
	
	    #Socket Curve ID
	    curve_id_socket = curve_info.interface.new_socket(name = "Curve ID", in_out='OUTPUT', socket_type = 'NodeSocketInt')
	    curve_id_socket.default_value = 0
	    curve_id_socket.min_value = -2147483648
	    curve_id_socket.max_value = 2147483647
	    curve_id_socket.subtype = 'NONE'
	    curve_id_socket.attribute_domain = 'CURVE'
	    curve_id_socket.description = "ID of each curve"
	
	    #Socket Length
	    length_socket = curve_info.interface.new_socket(name = "Length", in_out='OUTPUT', socket_type = 'NodeSocketFloat')
	    length_socket.default_value = 0.0
	    length_socket.min_value = -3.4028234663852886e+38
	    length_socket.max_value = 3.4028234663852886e+38
	    length_socket.subtype = 'NONE'
	    length_socket.attribute_domain = 'CURVE'
	    length_socket.description = "Length of each curve"
	
	    #Socket Direction
	    direction_socket = curve_info.interface.new_socket(name = "Direction", in_out='OUTPUT', socket_type = 'NodeSocketVector')
	    direction_socket.default_value = (0.0, 0.0, 0.0)
	    direction_socket.min_value = -3.4028234663852886e+38
	    direction_socket.max_value = 3.4028234663852886e+38
	    direction_socket.subtype = 'NONE'
	    direction_socket.attribute_domain = 'CURVE'
	    direction_socket.description = "Direction from root to tip of each curve"
	
	    #Socket Random
	    random_socket = curve_info.interface.new_socket(name = "Random", in_out='OUTPUT', socket_type = 'NodeSocketFloat')
	    random_socket.default_value = 0.0
	    random_socket.min_value = -3.4028234663852886e+38
	    random_socket.max_value = 3.4028234663852886e+38
	    random_socket.subtype = 'NONE'
	    random_socket.attribute_domain = 'CURVE'
	    random_socket.description = "Random vector for each curve"
	
	    #Socket Surface UV
	    surface_uv_socket = curve_info.interface.new_socket(name = "Surface UV", in_out='OUTPUT', socket_type = 'NodeSocketVector')
	    surface_uv_socket.default_value = (0.0, 0.0, 0.0)
	    surface_uv_socket.min_value = -3.4028234663852886e+38
	    surface_uv_socket.max_value = 3.4028234663852886e+38
	    surface_uv_socket.subtype = 'NONE'
	    surface_uv_socket.attribute_domain = 'CURVE'
	    surface_uv_socket.description = "Attachment surface UV coordinates of each curve"
	
	
	    #initialize curve_info nodes
	    #node Frame
	    frame_1 = curve_info.nodes.new("NodeFrame")
	    frame_1.label = "ID per Curve"
	    frame_1.name = "Frame"
	    frame_1.label_size = 20
	    frame_1.shrink = True
	
	    #node Group Output
	    group_output_5 = curve_info.nodes.new("NodeGroupOutput")
	    group_output_5.name = "Group Output"
	    group_output_5.is_active_output = True
	
	    #node Named Attribute
	    named_attribute_1 = curve_info.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute_1.name = "Named Attribute"
	    named_attribute_1.data_type = 'FLOAT_VECTOR'
	    #Name
	    named_attribute_1.inputs[0].default_value = "surface_uv_coordinate"
	
	    #node Group.002
	    group_002_1 = curve_info.nodes.new("GeometryNodeGroup")
	    group_002_1.name = "Group.002"
	    group_002_1.node_tree = curve_tip
	    group_002_1.outputs[0].hide = True
	    group_002_1.outputs[2].hide = True
	    group_002_1.outputs[3].hide = True
	
	    #node Evaluate at Index
	    evaluate_at_index = curve_info.nodes.new("GeometryNodeFieldAtIndex")
	    evaluate_at_index.name = "Evaluate at Index"
	    evaluate_at_index.data_type = 'FLOAT'
	    evaluate_at_index.domain = 'POINT'
	
	    #node Evaluate on Domain.001
	    evaluate_on_domain_001 = curve_info.nodes.new("GeometryNodeFieldOnDomain")
	    evaluate_on_domain_001.name = "Evaluate on Domain.001"
	    evaluate_on_domain_001.data_type = 'FLOAT'
	    evaluate_on_domain_001.domain = 'CURVE'
	
	    #node Random Value.002
	    random_value_002 = curve_info.nodes.new("FunctionNodeRandomValue")
	    random_value_002.name = "Random Value.002"
	    random_value_002.data_type = 'FLOAT'
	    #Min_001
	    random_value_002.inputs[2].default_value = 0.0
	    #Max_001
	    random_value_002.inputs[3].default_value = 1.0
	    #Seed
	    random_value_002.inputs[8].default_value = 0
	
	    #node Reroute
	    reroute_3 = curve_info.nodes.new("NodeReroute")
	    reroute_3.name = "Reroute"
	    reroute_3.socket_idname = "NodeSocketInt"
	    #node Vector Math
	    vector_math_1 = curve_info.nodes.new("ShaderNodeVectorMath")
	    vector_math_1.name = "Vector Math"
	    vector_math_1.operation = 'SUBTRACT'
	
	    #node Vector Math.001
	    vector_math_001_1 = curve_info.nodes.new("ShaderNodeVectorMath")
	    vector_math_001_1.name = "Vector Math.001"
	    vector_math_001_1.operation = 'NORMALIZE'
	
	    #node Evaluate on Domain
	    evaluate_on_domain = curve_info.nodes.new("GeometryNodeFieldOnDomain")
	    evaluate_on_domain.name = "Evaluate on Domain"
	    evaluate_on_domain.hide = True
	    evaluate_on_domain.data_type = 'INT'
	    evaluate_on_domain.domain = 'CURVE'
	
	    #node Index.001
	    index_001 = curve_info.nodes.new("GeometryNodeInputIndex")
	    index_001.name = "Index.001"
	
	    #node Spline Length
	    spline_length = curve_info.nodes.new("GeometryNodeSplineLength")
	    spline_length.name = "Spline Length"
	    spline_length.outputs[1].hide = True
	
	    #node Evaluate at Index.001
	    evaluate_at_index_001 = curve_info.nodes.new("GeometryNodeFieldAtIndex")
	    evaluate_at_index_001.name = "Evaluate at Index.001"
	    evaluate_at_index_001.data_type = 'INT'
	    evaluate_at_index_001.domain = 'POINT'
	
	    #node Evaluate on Domain.002
	    evaluate_on_domain_002 = curve_info.nodes.new("GeometryNodeFieldOnDomain")
	    evaluate_on_domain_002.name = "Evaluate on Domain.002"
	    evaluate_on_domain_002.data_type = 'INT'
	    evaluate_on_domain_002.domain = 'CURVE'
	
	    #node ID
	    id = curve_info.nodes.new("GeometryNodeInputID")
	    id.name = "ID"
	
	    #node Group.004
	    group_004_1 = curve_info.nodes.new("GeometryNodeGroup")
	    group_004_1.name = "Group.004"
	    group_004_1.node_tree = curve_root
	    group_004_1.outputs[0].hide = True
	    group_004_1.outputs[1].hide = True
	    group_004_1.outputs[2].hide = True
	
	    #node Group.005
	    group_005 = curve_info.nodes.new("GeometryNodeGroup")
	    group_005.name = "Group.005"
	    group_005.node_tree = curve_root
	    group_005.outputs[0].hide = True
	    group_005.outputs[2].hide = True
	    group_005.outputs[3].hide = True
	
	    #node Group.006
	    group_006 = curve_info.nodes.new("GeometryNodeGroup")
	    group_006.name = "Group.006"
	    group_006.node_tree = curve_root
	    group_006.outputs[0].hide = True
	    group_006.outputs[1].hide = True
	    group_006.outputs[2].hide = True
	
	
	
	
	    #Set parents
	    evaluate_at_index_001.parent = frame_1
	    evaluate_on_domain_002.parent = frame_1
	    id.parent = frame_1
	    group_004_1.parent = frame_1
	
	    #Set locations
	    frame_1.location = (-1201.0, 150.0)
	    group_output_5.location = (75.0, 50.0)
	    named_attribute_1.location = (-166.11627197265625, -371.9534912109375)
	    group_002_1.location = (-527.7907104492188, -90.65116882324219)
	    evaluate_at_index.location = (-346.9534912109375, -211.2093048095703)
	    evaluate_on_domain_001.location = (-166.11627197265625, -211.2093048095703)
	    random_value_002.location = (-527.7907104492188, -331.7674560546875)
	    reroute_3.location = (-608.162841796875, 29.906982421875)
	    vector_math_1.location = (-346.9534912109375, -70.55814361572266)
	    vector_math_001_1.location = (-166.11627197265625, -70.55814361572266)
	    evaluate_on_domain.location = (-166.11627197265625, 70.093017578125)
	    index_001.location = (-346.9534912109375, 110.27906799316406)
	    spline_length.location = (-166.11627197265625, -10.279067993164062)
	    evaluate_at_index_001.location = (211.06976318359375, -39.72093200683594)
	    evaluate_on_domain_002.location = (391.906982421875, -39.72093200683594)
	    id.location = (30.2325439453125, -140.18605041503906)
	    group_004_1.location = (30.3040771484375, -56.363525390625)
	    group_005.location = (-528.7048950195312, -171.3199462890625)
	    group_006.location = (-527.281982421875, -252.69052124023438)
	
	    #Set dimensions
	    frame_1.width, frame_1.height = 562.0, 220.0
	    group_output_5.width, group_output_5.height = 140.0, 100.0
	    named_attribute_1.width, named_attribute_1.height = 140.0, 100.0
	    group_002_1.width, group_002_1.height = 140.0, 100.0
	    evaluate_at_index.width, evaluate_at_index.height = 140.0, 100.0
	    evaluate_on_domain_001.width, evaluate_on_domain_001.height = 140.0, 100.0
	    random_value_002.width, random_value_002.height = 140.0, 100.0
	    reroute_3.width, reroute_3.height = 10.0, 100.0
	    vector_math_1.width, vector_math_1.height = 140.0, 100.0
	    vector_math_001_1.width, vector_math_001_1.height = 140.0, 100.0
	    evaluate_on_domain.width, evaluate_on_domain.height = 140.0, 100.0
	    index_001.width, index_001.height = 140.0, 100.0
	    spline_length.width, spline_length.height = 140.0, 100.0
	    evaluate_at_index_001.width, evaluate_at_index_001.height = 140.0, 100.0
	    evaluate_on_domain_002.width, evaluate_on_domain_002.height = 140.0, 100.0
	    id.width, id.height = 140.0, 100.0
	    group_004_1.width, group_004_1.height = 140.0, 100.0
	    group_005.width, group_005.height = 140.0, 100.0
	    group_006.width, group_006.height = 140.0, 100.0
	
	    #initialize curve_info links
	    #index_001.Index -> evaluate_on_domain.Value
	    curve_info.links.new(index_001.outputs[0], evaluate_on_domain.inputs[0])
	    #evaluate_on_domain.Value -> group_output_5.Curve Index
	    curve_info.links.new(evaluate_on_domain.outputs[0], group_output_5.inputs[0])
	    #named_attribute_1.Attribute -> group_output_5.Surface UV
	    curve_info.links.new(named_attribute_1.outputs[0], group_output_5.inputs[5])
	    #evaluate_at_index_001.Value -> evaluate_on_domain_002.Value
	    curve_info.links.new(evaluate_at_index_001.outputs[0], evaluate_on_domain_002.inputs[0])
	    #reroute_3.Output -> group_output_5.Curve ID
	    curve_info.links.new(reroute_3.outputs[0], group_output_5.inputs[1])
	    #id.ID -> evaluate_at_index_001.Value
	    curve_info.links.new(id.outputs[0], evaluate_at_index_001.inputs[1])
	    #spline_length.Length -> group_output_5.Length
	    curve_info.links.new(spline_length.outputs[0], group_output_5.inputs[2])
	    #group_002_1.Tip Position -> vector_math_1.Vector
	    curve_info.links.new(group_002_1.outputs[1], vector_math_1.inputs[0])
	    #vector_math_001_1.Vector -> group_output_5.Direction
	    curve_info.links.new(vector_math_001_1.outputs[0], group_output_5.inputs[3])
	    #vector_math_1.Vector -> vector_math_001_1.Vector
	    curve_info.links.new(vector_math_1.outputs[0], vector_math_001_1.inputs[0])
	    #reroute_3.Output -> random_value_002.ID
	    curve_info.links.new(reroute_3.outputs[0], random_value_002.inputs[7])
	    #evaluate_at_index.Value -> evaluate_on_domain_001.Value
	    curve_info.links.new(evaluate_at_index.outputs[0], evaluate_on_domain_001.inputs[0])
	    #evaluate_on_domain_001.Value -> group_output_5.Random
	    curve_info.links.new(evaluate_on_domain_001.outputs[0], group_output_5.inputs[4])
	    #random_value_002.Value -> evaluate_at_index.Value
	    curve_info.links.new(random_value_002.outputs[1], evaluate_at_index.inputs[1])
	    #evaluate_on_domain_002.Value -> reroute_3.Input
	    curve_info.links.new(evaluate_on_domain_002.outputs[0], reroute_3.inputs[0])
	    #group_004_1.Root Index -> evaluate_at_index_001.Index
	    curve_info.links.new(group_004_1.outputs[3], evaluate_at_index_001.inputs[0])
	    #group_005.Root Position -> vector_math_1.Vector
	    curve_info.links.new(group_005.outputs[1], vector_math_1.inputs[1])
	    #group_006.Root Index -> evaluate_at_index.Index
	    curve_info.links.new(group_006.outputs[3], evaluate_at_index.inputs[0])
	    return curve_info
	
	curve_info = curve_info_node_group()
	
	#initialize duplicate_hair_curves node group
	def duplicate_hair_curves_node_group():
	    duplicate_hair_curves = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Duplicate Hair Curves")
	
	    duplicate_hair_curves.color_tag = 'NONE'
	    duplicate_hair_curves.description = "Duplicates hair curves a certain number of times within a radius"
	    duplicate_hair_curves.default_group_node_width = 140
	    
	
	    duplicate_hair_curves.is_modifier = True
	
	    #duplicate_hair_curves interface
	    #Socket Geometry
	    geometry_socket_6 = duplicate_hair_curves.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_6.attribute_domain = 'POINT'
	
	    #Socket Guide Index
	    guide_index_socket = duplicate_hair_curves.interface.new_socket(name = "Guide Index", in_out='OUTPUT', socket_type = 'NodeSocketInt')
	    guide_index_socket.default_value = 0
	    guide_index_socket.min_value = -2147483648
	    guide_index_socket.max_value = 2147483647
	    guide_index_socket.subtype = 'NONE'
	    guide_index_socket.attribute_domain = 'CURVE'
	    guide_index_socket.description = "Guide index map that was used for the operation"
	
	    #Socket Geometry
	    geometry_socket_7 = duplicate_hair_curves.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_7.attribute_domain = 'POINT'
	    geometry_socket_7.description = "Input Geometry (May include other than curves)"
	
	    #Socket Amount
	    amount_socket = duplicate_hair_curves.interface.new_socket(name = "Amount", in_out='INPUT', socket_type = 'NodeSocketInt')
	    amount_socket.default_value = 10
	    amount_socket.min_value = 0
	    amount_socket.max_value = 2147483647
	    amount_socket.subtype = 'NONE'
	    amount_socket.attribute_domain = 'POINT'
	    amount_socket.description = "Amount of duplicates per curve"
	
	    #Socket Viewport Amount
	    viewport_amount_socket = duplicate_hair_curves.interface.new_socket(name = "Viewport Amount", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    viewport_amount_socket.default_value = 1.0
	    viewport_amount_socket.min_value = 0.0
	    viewport_amount_socket.max_value = 1.0
	    viewport_amount_socket.subtype = 'FACTOR'
	    viewport_amount_socket.attribute_domain = 'POINT'
	    viewport_amount_socket.description = "Percentage of amount used for the viewport"
	
	    #Socket Radius
	    radius_socket = duplicate_hair_curves.interface.new_socket(name = "Radius", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    radius_socket.default_value = 0.10000000149011612
	    radius_socket.min_value = 0.0
	    radius_socket.max_value = 3.4028234663852886e+38
	    radius_socket.subtype = 'DISTANCE'
	    radius_socket.attribute_domain = 'POINT'
	    radius_socket.description = "Radius in which the duplicate curves are offset from the guides"
	
	    #Socket Distribution Shape
	    distribution_shape_socket = duplicate_hair_curves.interface.new_socket(name = "Distribution Shape", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    distribution_shape_socket.default_value = 0.0
	    distribution_shape_socket.min_value = -10.0
	    distribution_shape_socket.max_value = 10.0
	    distribution_shape_socket.subtype = 'NONE'
	    distribution_shape_socket.attribute_domain = 'POINT'
	    distribution_shape_socket.description = "Shape of distribution from center to the edge around the guide"
	
	    #Socket Tip Roundness
	    tip_roundness_socket = duplicate_hair_curves.interface.new_socket(name = "Tip Roundness", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    tip_roundness_socket.default_value = 0.0
	    tip_roundness_socket.min_value = 0.0
	    tip_roundness_socket.max_value = 1.0
	    tip_roundness_socket.subtype = 'FACTOR'
	    tip_roundness_socket.attribute_domain = 'POINT'
	    tip_roundness_socket.description = "Offset of the curves to round the tip"
	
	    #Socket Even Thickness
	    even_thickness_socket = duplicate_hair_curves.interface.new_socket(name = "Even Thickness", in_out='INPUT', socket_type = 'NodeSocketBool')
	    even_thickness_socket.default_value = False
	    even_thickness_socket.attribute_domain = 'POINT'
	    even_thickness_socket.description = "Keep an even thickness of the distribution of duplicates"
	
	    #Socket Seed
	    seed_socket = duplicate_hair_curves.interface.new_socket(name = "Seed", in_out='INPUT', socket_type = 'NodeSocketInt')
	    seed_socket.default_value = 0
	    seed_socket.min_value = -10000
	    seed_socket.max_value = 10000
	    seed_socket.subtype = 'NONE'
	    seed_socket.attribute_domain = 'POINT'
	    seed_socket.description = "Random Seed for the operation"
	
	
	    #initialize duplicate_hair_curves nodes
	    #node Frame.002
	    frame_002_1 = duplicate_hair_curves.nodes.new("NodeFrame")
	    frame_002_1.label = "Random Disc Position"
	    frame_002_1.name = "Frame.002"
	    frame_002_1.label_size = 20
	    frame_002_1.shrink = True
	
	    #node Frame.001
	    frame_001_1 = duplicate_hair_curves.nodes.new("NodeFrame")
	    frame_001_1.label = "Tangent Space per Point"
	    frame_001_1.name = "Frame.001"
	    frame_001_1.label_size = 20
	    frame_001_1.shrink = True
	
	    #node Frame
	    frame_2 = duplicate_hair_curves.nodes.new("NodeFrame")
	    frame_2.label = "Tangent Space of Root Point"
	    frame_2.name = "Frame"
	    frame_2.label_size = 20
	    frame_2.shrink = True
	
	    #node Frame.004
	    frame_004_1 = duplicate_hair_curves.nodes.new("NodeFrame")
	    frame_004_1.label = "Duplicate Curves"
	    frame_004_1.name = "Frame.004"
	    frame_004_1.label_size = 20
	    frame_004_1.shrink = True
	
	    #node Frame.003
	    frame_003_1 = duplicate_hair_curves.nodes.new("NodeFrame")
	    frame_003_1.label = "Random Vector per Curve"
	    frame_003_1.name = "Frame.003"
	    frame_003_1.label_size = 20
	    frame_003_1.shrink = True
	
	    #node Reroute.016
	    reroute_016 = duplicate_hair_curves.nodes.new("NodeReroute")
	    reroute_016.name = "Reroute.016"
	    reroute_016.socket_idname = "NodeSocketGeometry"
	    #node Reroute.017
	    reroute_017 = duplicate_hair_curves.nodes.new("NodeReroute")
	    reroute_017.name = "Reroute.017"
	    reroute_017.socket_idname = "NodeSocketGeometry"
	    #node Reroute.019
	    reroute_019 = duplicate_hair_curves.nodes.new("NodeReroute")
	    reroute_019.name = "Reroute.019"
	    reroute_019.socket_idname = "NodeSocketGeometry"
	    #node Reroute.018
	    reroute_018 = duplicate_hair_curves.nodes.new("NodeReroute")
	    reroute_018.name = "Reroute.018"
	    reroute_018.socket_idname = "NodeSocketGeometry"
	    #node Group Input
	    group_input_3 = duplicate_hair_curves.nodes.new("NodeGroupInput")
	    group_input_3.name = "Group Input"
	    group_input_3.outputs[1].hide = True
	    group_input_3.outputs[2].hide = True
	    group_input_3.outputs[3].hide = True
	    group_input_3.outputs[4].hide = True
	    group_input_3.outputs[5].hide = True
	    group_input_3.outputs[6].hide = True
	    group_input_3.outputs[7].hide = True
	    group_input_3.outputs[8].hide = True
	
	    #node Group Output
	    group_output_6 = duplicate_hair_curves.nodes.new("NodeGroupOutput")
	    group_output_6.name = "Group Output"
	    group_output_6.is_active_output = True
	
	    #node Separate Components
	    separate_components = duplicate_hair_curves.nodes.new("GeometryNodeSeparateComponents")
	    separate_components.name = "Separate Components"
	    separate_components.hide = True
	
	    #node Math.053
	    math_053 = duplicate_hair_curves.nodes.new("ShaderNodeMath")
	    math_053.name = "Math.053"
	    math_053.hide = True
	    math_053.operation = 'ARCCOSINE'
	    math_053.use_clamp = False
	
	    #node Math.055
	    math_055 = duplicate_hair_curves.nodes.new("ShaderNodeMath")
	    math_055.name = "Math.055"
	    math_055.hide = True
	    math_055.operation = 'DIVIDE'
	    math_055.use_clamp = False
	    #Value_001
	    math_055.inputs[1].default_value = 1.5707963705062866
	
	    #node Math.056
	    math_056 = duplicate_hair_curves.nodes.new("ShaderNodeMath")
	    math_056.name = "Math.056"
	    math_056.hide = True
	    math_056.operation = 'POWER'
	    math_056.use_clamp = False
	    #Value
	    math_056.inputs[0].default_value = 2.0
	
	    #node Group Input.006
	    group_input_006_1 = duplicate_hair_curves.nodes.new("NodeGroupInput")
	    group_input_006_1.name = "Group Input.006"
	    group_input_006_1.outputs[0].hide = True
	    group_input_006_1.outputs[1].hide = True
	    group_input_006_1.outputs[2].hide = True
	    group_input_006_1.outputs[3].hide = True
	    group_input_006_1.outputs[5].hide = True
	    group_input_006_1.outputs[6].hide = True
	    group_input_006_1.outputs[7].hide = True
	    group_input_006_1.outputs[8].hide = True
	
	    #node Separate XYZ.002
	    separate_xyz_002 = duplicate_hair_curves.nodes.new("ShaderNodeSeparateXYZ")
	    separate_xyz_002.name = "Separate XYZ.002"
	
	    #node Math.054
	    math_054 = duplicate_hair_curves.nodes.new("ShaderNodeMath")
	    math_054.name = "Math.054"
	    math_054.operation = 'POWER'
	    math_054.use_clamp = False
	
	    #node Math.052
	    math_052 = duplicate_hair_curves.nodes.new("ShaderNodeMath")
	    math_052.name = "Math.052"
	    math_052.hide = True
	    math_052.operation = 'MULTIPLY'
	    math_052.use_clamp = False
	    #Value_001
	    math_052.inputs[1].default_value = 6.2831854820251465
	
	    #node Combine XYZ.002
	    combine_xyz_002 = duplicate_hair_curves.nodes.new("ShaderNodeCombineXYZ")
	    combine_xyz_002.name = "Combine XYZ.002"
	    combine_xyz_002.inputs[1].hide = True
	    combine_xyz_002.inputs[2].hide = True
	    #Y
	    combine_xyz_002.inputs[1].default_value = 0.0
	    #Z
	    combine_xyz_002.inputs[2].default_value = 0.0
	
	    #node Math.059
	    math_059 = duplicate_hair_curves.nodes.new("ShaderNodeMath")
	    math_059.name = "Math.059"
	    math_059.hide = True
	    math_059.operation = 'SUBTRACT'
	    math_059.use_clamp = False
	    #Value_001
	    math_059.inputs[1].default_value = 0.5
	
	    #node Math.058
	    math_058 = duplicate_hair_curves.nodes.new("ShaderNodeMath")
	    math_058.name = "Math.058"
	    math_058.hide = True
	    math_058.operation = 'POWER'
	    math_058.use_clamp = False
	    #Value_001
	    math_058.inputs[1].default_value = 2.0
	
	    #node Vector Rotate
	    vector_rotate = duplicate_hair_curves.nodes.new("ShaderNodeVectorRotate")
	    vector_rotate.name = "Vector Rotate"
	    vector_rotate.invert = False
	    vector_rotate.rotation_type = 'Z_AXIS'
	    vector_rotate.inputs[1].hide = True
	    vector_rotate.inputs[2].hide = True
	    vector_rotate.inputs[4].hide = True
	    #Center
	    vector_rotate.inputs[1].default_value = (0.0, 0.0, 0.0)
	
	    #node Math.057
	    math_057 = duplicate_hair_curves.nodes.new("ShaderNodeMath")
	    math_057.name = "Math.057"
	    math_057.operation = 'ADD'
	    math_057.use_clamp = False
	
	    #node Group Input.007
	    group_input_007_1 = duplicate_hair_curves.nodes.new("NodeGroupInput")
	    group_input_007_1.name = "Group Input.007"
	    group_input_007_1.outputs[0].hide = True
	    group_input_007_1.outputs[1].hide = True
	    group_input_007_1.outputs[2].hide = True
	    group_input_007_1.outputs[3].hide = True
	    group_input_007_1.outputs[4].hide = True
	    group_input_007_1.outputs[6].hide = True
	    group_input_007_1.outputs[7].hide = True
	    group_input_007_1.outputs[8].hide = True
	
	    #node Combine XYZ
	    combine_xyz = duplicate_hair_curves.nodes.new("ShaderNodeCombineXYZ")
	    combine_xyz.name = "Combine XYZ"
	    combine_xyz.inputs[0].hide = True
	    combine_xyz.inputs[1].hide = True
	    #X
	    combine_xyz.inputs[0].default_value = 0.0
	    #Y
	    combine_xyz.inputs[1].default_value = 0.0
	
	    #node Vector Math.014
	    vector_math_014 = duplicate_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_014.name = "Vector Math.014"
	    vector_math_014.operation = 'SCALE'
	
	    #node Vector Math.013
	    vector_math_013 = duplicate_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_013.name = "Vector Math.013"
	    vector_math_013.operation = 'SUBTRACT'
	
	    #node Reroute.001
	    reroute_001_1 = duplicate_hair_curves.nodes.new("NodeReroute")
	    reroute_001_1.name = "Reroute.001"
	    reroute_001_1.socket_idname = "NodeSocketGeometry"
	    #node Reroute.003
	    reroute_003_1 = duplicate_hair_curves.nodes.new("NodeReroute")
	    reroute_003_1.name = "Reroute.003"
	    reroute_003_1.socket_idname = "NodeSocketBool"
	    #node Set Position
	    set_position = duplicate_hair_curves.nodes.new("GeometryNodeSetPosition")
	    set_position.name = "Set Position"
	    #Position
	    set_position.inputs[2].default_value = (0.0, 0.0, 0.0)
	
	    #node Set Position.001
	    set_position_001_1 = duplicate_hair_curves.nodes.new("GeometryNodeSetPosition")
	    set_position_001_1.name = "Set Position.001"
	    #Position
	    set_position_001_1.inputs[2].default_value = (0.0, 0.0, 0.0)
	
	    #node Normal
	    normal_1 = duplicate_hair_curves.nodes.new("GeometryNodeInputNormal")
	    normal_1.name = "Normal"
	    normal_1.legacy_corner_normals = True
	
	    #node Curve Tangent
	    curve_tangent_2 = duplicate_hair_curves.nodes.new("GeometryNodeInputTangent")
	    curve_tangent_2.name = "Curve Tangent"
	
	    #node Separate XYZ
	    separate_xyz = duplicate_hair_curves.nodes.new("ShaderNodeSeparateXYZ")
	    separate_xyz.name = "Separate XYZ"
	
	    #node Vector Math.001
	    vector_math_001_2 = duplicate_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_001_2.name = "Vector Math.001"
	    vector_math_001_2.operation = 'SCALE'
	
	    #node Vector Math.003
	    vector_math_003_1 = duplicate_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_003_1.name = "Vector Math.003"
	    vector_math_003_1.operation = 'ADD'
	
	    #node Vector Math.002
	    vector_math_002_1 = duplicate_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_002_1.name = "Vector Math.002"
	    vector_math_002_1.operation = 'SCALE'
	
	    #node Vector Math.009
	    vector_math_009 = duplicate_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_009.name = "Vector Math.009"
	    vector_math_009.operation = 'ADD'
	
	    #node Vector Math.010
	    vector_math_010 = duplicate_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_010.name = "Vector Math.010"
	    vector_math_010.operation = 'SCALE'
	
	    #node Vector Math
	    vector_math_2 = duplicate_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_2.name = "Vector Math"
	    vector_math_2.operation = 'CROSS_PRODUCT'
	
	    #node Evaluate on Domain.002
	    evaluate_on_domain_002_1 = duplicate_hair_curves.nodes.new("GeometryNodeFieldOnDomain")
	    evaluate_on_domain_002_1.name = "Evaluate on Domain.002"
	    evaluate_on_domain_002_1.data_type = 'FLOAT_VECTOR'
	    evaluate_on_domain_002_1.domain = 'CURVE'
	
	    #node Separate XYZ.001
	    separate_xyz_001 = duplicate_hair_curves.nodes.new("ShaderNodeSeparateXYZ")
	    separate_xyz_001.name = "Separate XYZ.001"
	
	    #node Vector Math.011
	    vector_math_011 = duplicate_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_011.name = "Vector Math.011"
	    vector_math_011.operation = 'ADD'
	
	    #node Vector Math.005
	    vector_math_005_1 = duplicate_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_005_1.name = "Vector Math.005"
	    vector_math_005_1.operation = 'ADD'
	
	    #node Vector Math.007
	    vector_math_007 = duplicate_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_007.name = "Vector Math.007"
	    vector_math_007.operation = 'SCALE'
	
	    #node Vector Math.008
	    vector_math_008 = duplicate_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_008.name = "Vector Math.008"
	    vector_math_008.operation = 'CROSS_PRODUCT'
	
	    #node Evaluate at Index
	    evaluate_at_index_1 = duplicate_hair_curves.nodes.new("GeometryNodeFieldAtIndex")
	    evaluate_at_index_1.name = "Evaluate at Index"
	    evaluate_at_index_1.data_type = 'FLOAT_VECTOR'
	    evaluate_at_index_1.domain = 'POINT'
	
	    #node Vector Math.012
	    vector_math_012 = duplicate_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_012.name = "Vector Math.012"
	    vector_math_012.operation = 'SCALE'
	
	    #node Vector Math.006
	    vector_math_006 = duplicate_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_006.name = "Vector Math.006"
	    vector_math_006.operation = 'SCALE'
	
	    #node Evaluate on Domain.001
	    evaluate_on_domain_001_1 = duplicate_hair_curves.nodes.new("GeometryNodeFieldOnDomain")
	    evaluate_on_domain_001_1.name = "Evaluate on Domain.001"
	    evaluate_on_domain_001_1.hide = True
	    evaluate_on_domain_001_1.data_type = 'FLOAT_VECTOR'
	    evaluate_on_domain_001_1.domain = 'POINT'
	
	    #node Curve Tangent.001
	    curve_tangent_001 = duplicate_hair_curves.nodes.new("GeometryNodeInputTangent")
	    curve_tangent_001.name = "Curve Tangent.001"
	
	    #node Normal.001
	    normal_001_1 = duplicate_hair_curves.nodes.new("GeometryNodeInputNormal")
	    normal_001_1.name = "Normal.001"
	    normal_001_1.legacy_corner_normals = True
	
	    #node Reroute.014
	    reroute_014_1 = duplicate_hair_curves.nodes.new("NodeReroute")
	    reroute_014_1.name = "Reroute.014"
	    reroute_014_1.socket_idname = "NodeSocketGeometry"
	    #node Reroute.015
	    reroute_015_1 = duplicate_hair_curves.nodes.new("NodeReroute")
	    reroute_015_1.name = "Reroute.015"
	    reroute_015_1.socket_idname = "NodeSocketGeometry"
	    #node Reroute.013
	    reroute_013_1 = duplicate_hair_curves.nodes.new("NodeReroute")
	    reroute_013_1.name = "Reroute.013"
	    reroute_013_1.socket_idname = "NodeSocketGeometry"
	    #node Reroute.012
	    reroute_012_1 = duplicate_hair_curves.nodes.new("NodeReroute")
	    reroute_012_1.name = "Reroute.012"
	    reroute_012_1.socket_idname = "NodeSocketGeometry"
	    #node Is Viewport
	    is_viewport = duplicate_hair_curves.nodes.new("GeometryNodeIsViewport")
	    is_viewport.name = "Is Viewport"
	
	    #node Switch
	    switch_1 = duplicate_hair_curves.nodes.new("GeometryNodeSwitch")
	    switch_1.name = "Switch"
	    switch_1.input_type = 'INT'
	
	    #node ID
	    id_1 = duplicate_hair_curves.nodes.new("GeometryNodeInputID")
	    id_1.name = "ID"
	
	    #node Reroute.004
	    reroute_004_1 = duplicate_hair_curves.nodes.new("NodeReroute")
	    reroute_004_1.name = "Reroute.004"
	    reroute_004_1.socket_idname = "NodeSocketInt"
	    #node Reroute.002
	    reroute_002_1 = duplicate_hair_curves.nodes.new("NodeReroute")
	    reroute_002_1.name = "Reroute.002"
	    reroute_002_1.socket_idname = "NodeSocketGeometry"
	    #node Join Geometry
	    join_geometry = duplicate_hair_curves.nodes.new("GeometryNodeJoinGeometry")
	    join_geometry.name = "Join Geometry"
	
	    #node Set ID
	    set_id = duplicate_hair_curves.nodes.new("GeometryNodeSetID")
	    set_id.name = "Set ID"
	    #Selection
	    set_id.inputs[1].default_value = True
	
	    #node Store Named Attribute
	    store_named_attribute_1 = duplicate_hair_curves.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_1.name = "Store Named Attribute"
	    store_named_attribute_1.data_type = 'INT'
	    store_named_attribute_1.domain = 'CURVE'
	    #Selection
	    store_named_attribute_1.inputs[1].default_value = True
	    #Name
	    store_named_attribute_1.inputs[2].default_value = "guide_curve_index"
	
	    #node Math
	    math_1 = duplicate_hair_curves.nodes.new("ShaderNodeMath")
	    math_1.name = "Math"
	    math_1.hide = True
	    math_1.operation = 'MULTIPLY'
	    math_1.use_clamp = False
	
	    #node Group Input.002
	    group_input_002_1 = duplicate_hair_curves.nodes.new("NodeGroupInput")
	    group_input_002_1.name = "Group Input.002"
	    group_input_002_1.outputs[0].hide = True
	    group_input_002_1.outputs[1].hide = True
	    group_input_002_1.outputs[3].hide = True
	    group_input_002_1.outputs[4].hide = True
	    group_input_002_1.outputs[5].hide = True
	    group_input_002_1.outputs[6].hide = True
	    group_input_002_1.outputs[7].hide = True
	    group_input_002_1.outputs[8].hide = True
	
	    #node Group Input.004
	    group_input_004_1 = duplicate_hair_curves.nodes.new("NodeGroupInput")
	    group_input_004_1.name = "Group Input.004"
	    group_input_004_1.outputs[0].hide = True
	    group_input_004_1.outputs[2].hide = True
	    group_input_004_1.outputs[3].hide = True
	    group_input_004_1.outputs[4].hide = True
	    group_input_004_1.outputs[5].hide = True
	    group_input_004_1.outputs[6].hide = True
	    group_input_004_1.outputs[7].hide = True
	    group_input_004_1.outputs[8].hide = True
	
	    #node Capture Attribute.002
	    capture_attribute_002 = duplicate_hair_curves.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_002.name = "Capture Attribute.002"
	    capture_attribute_002.active_index = 0
	    capture_attribute_002.capture_items.clear()
	    capture_attribute_002.capture_items.new('FLOAT', "Value")
	    capture_attribute_002.capture_items["Value"].data_type = 'BOOLEAN'
	    capture_attribute_002.domain = 'POINT'
	    #Value
	    capture_attribute_002.inputs[1].default_value = True
	
	    #node Vector Math.004
	    vector_math_004_1 = duplicate_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_004_1.name = "Vector Math.004"
	    vector_math_004_1.operation = 'SCALE'
	
	    #node Group Input.003
	    group_input_003_1 = duplicate_hair_curves.nodes.new("NodeGroupInput")
	    group_input_003_1.name = "Group Input.003"
	    group_input_003_1.outputs[0].hide = True
	    group_input_003_1.outputs[1].hide = True
	    group_input_003_1.outputs[2].hide = True
	    group_input_003_1.outputs[4].hide = True
	    group_input_003_1.outputs[5].hide = True
	    group_input_003_1.outputs[6].hide = True
	    group_input_003_1.outputs[7].hide = True
	    group_input_003_1.outputs[8].hide = True
	
	    #node Random Value.001
	    random_value_001 = duplicate_hair_curves.nodes.new("FunctionNodeRandomValue")
	    random_value_001.name = "Random Value.001"
	    random_value_001.data_type = 'FLOAT_VECTOR'
	    #Min
	    random_value_001.inputs[0].default_value = (0.0, 0.0, 0.0)
	    #Max
	    random_value_001.inputs[1].default_value = (1.0, 1.0, 1.0)
	
	    #node Capture Attribute
	    capture_attribute_1 = duplicate_hair_curves.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_1.name = "Capture Attribute"
	    capture_attribute_1.active_index = 0
	    capture_attribute_1.capture_items.clear()
	    capture_attribute_1.capture_items.new('FLOAT', "Value")
	    capture_attribute_1.capture_items["Value"].data_type = 'INT'
	    capture_attribute_1.domain = 'POINT'
	
	    #node Duplicate Elements
	    duplicate_elements = duplicate_hair_curves.nodes.new("GeometryNodeDuplicateElements")
	    duplicate_elements.name = "Duplicate Elements"
	    duplicate_elements.domain = 'SPLINE'
	    #Selection
	    duplicate_elements.inputs[1].default_value = True
	
	    #node Join Geometry.001
	    join_geometry_001 = duplicate_hair_curves.nodes.new("GeometryNodeJoinGeometry")
	    join_geometry_001.name = "Join Geometry.001"
	
	    #node Random Value
	    random_value = duplicate_hair_curves.nodes.new("FunctionNodeRandomValue")
	    random_value.name = "Random Value"
	    random_value.data_type = 'INT'
	    #Min_002
	    random_value.inputs[4].default_value = -1073741823
	    #Max_002
	    random_value.inputs[5].default_value = 1073741823
	
	    #node Reroute.020
	    reroute_020 = duplicate_hair_curves.nodes.new("NodeReroute")
	    reroute_020.name = "Reroute.020"
	    reroute_020.socket_idname = "NodeSocketGeometry"
	    #node Index
	    index_1 = duplicate_hair_curves.nodes.new("GeometryNodeInputIndex")
	    index_1.name = "Index"
	
	    #node Capture Attribute.001
	    capture_attribute_001 = duplicate_hair_curves.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_001.name = "Capture Attribute.001"
	    capture_attribute_001.active_index = 0
	    capture_attribute_001.capture_items.clear()
	    capture_attribute_001.capture_items.new('FLOAT', "Value")
	    capture_attribute_001.capture_items["Value"].data_type = 'INT'
	    capture_attribute_001.domain = 'CURVE'
	
	    #node Switch.001
	    switch_001_3 = duplicate_hair_curves.nodes.new("GeometryNodeSwitch")
	    switch_001_3.name = "Switch.001"
	    switch_001_3.input_type = 'GEOMETRY'
	
	    #node Group
	    group_1 = duplicate_hair_curves.nodes.new("GeometryNodeGroup")
	    group_1.name = "Group"
	    group_1.node_tree = curve_info
	    group_1.outputs[0].hide = True
	    group_1.outputs[2].hide = True
	    group_1.outputs[3].hide = True
	    group_1.outputs[4].hide = True
	    group_1.outputs[5].hide = True
	
	    #node Group Input.001
	    group_input_001_1 = duplicate_hair_curves.nodes.new("NodeGroupInput")
	    group_input_001_1.name = "Group Input.001"
	    group_input_001_1.outputs[0].hide = True
	    group_input_001_1.outputs[1].hide = True
	    group_input_001_1.outputs[2].hide = True
	    group_input_001_1.outputs[3].hide = True
	    group_input_001_1.outputs[4].hide = True
	    group_input_001_1.outputs[5].hide = True
	    group_input_001_1.outputs[6].hide = True
	    group_input_001_1.outputs[8].hide = True
	
	    #node Group Input.005
	    group_input_005_1 = duplicate_hair_curves.nodes.new("NodeGroupInput")
	    group_input_005_1.name = "Group Input.005"
	    group_input_005_1.outputs[0].hide = True
	    group_input_005_1.outputs[1].hide = True
	    group_input_005_1.outputs[2].hide = True
	    group_input_005_1.outputs[3].hide = True
	    group_input_005_1.outputs[4].hide = True
	    group_input_005_1.outputs[5].hide = True
	    group_input_005_1.outputs[7].hide = True
	    group_input_005_1.outputs[8].hide = True
	
	    #node Random Value.004
	    random_value_004 = duplicate_hair_curves.nodes.new("FunctionNodeRandomValue")
	    random_value_004.name = "Random Value.004"
	    random_value_004.data_type = 'INT'
	    #Min_002
	    random_value_004.inputs[4].default_value = -1073741823
	    #Max_002
	    random_value_004.inputs[5].default_value = 1073741823
	    #Seed
	    random_value_004.inputs[8].default_value = 296
	
	    #node Group.002
	    group_002_2 = duplicate_hair_curves.nodes.new("GeometryNodeGroup")
	    group_002_2.name = "Group.002"
	    group_002_2.node_tree = curve_root
	    group_002_2.outputs[0].hide = True
	    group_002_2.outputs[1].hide = True
	    group_002_2.outputs[2].hide = True
	
	
	
	
	    #Set parents
	    math_053.parent = frame_002_1
	    math_055.parent = frame_002_1
	    math_056.parent = frame_002_1
	    group_input_006_1.parent = frame_002_1
	    separate_xyz_002.parent = frame_002_1
	    math_054.parent = frame_002_1
	    math_052.parent = frame_002_1
	    combine_xyz_002.parent = frame_002_1
	    math_059.parent = frame_002_1
	    math_058.parent = frame_002_1
	    vector_rotate.parent = frame_002_1
	    math_057.parent = frame_002_1
	    group_input_007_1.parent = frame_002_1
	    combine_xyz.parent = frame_002_1
	    vector_math_014.parent = frame_002_1
	    vector_math_013.parent = frame_002_1
	    normal_1.parent = frame_001_1
	    curve_tangent_2.parent = frame_001_1
	    separate_xyz.parent = frame_001_1
	    vector_math_001_2.parent = frame_001_1
	    vector_math_003_1.parent = frame_001_1
	    vector_math_002_1.parent = frame_001_1
	    vector_math_009.parent = frame_001_1
	    vector_math_010.parent = frame_001_1
	    vector_math_2.parent = frame_001_1
	    evaluate_on_domain_002_1.parent = frame_2
	    separate_xyz_001.parent = frame_2
	    vector_math_011.parent = frame_2
	    vector_math_005_1.parent = frame_2
	    vector_math_007.parent = frame_2
	    vector_math_008.parent = frame_2
	    evaluate_at_index_1.parent = frame_2
	    vector_math_012.parent = frame_2
	    vector_math_006.parent = frame_2
	    evaluate_on_domain_001_1.parent = frame_2
	    curve_tangent_001.parent = frame_2
	    normal_001_1.parent = frame_2
	    is_viewport.parent = frame_004_1
	    switch_1.parent = frame_004_1
	    id_1.parent = frame_004_1
	    reroute_004_1.parent = frame_004_1
	    reroute_002_1.parent = frame_004_1
	    join_geometry.parent = frame_004_1
	    set_id.parent = frame_004_1
	    store_named_attribute_1.parent = frame_004_1
	    math_1.parent = frame_004_1
	    group_input_002_1.parent = frame_004_1
	    group_input_004_1.parent = frame_004_1
	    capture_attribute_002.parent = frame_004_1
	    random_value_001.parent = frame_003_1
	    capture_attribute_1.parent = frame_004_1
	    duplicate_elements.parent = frame_004_1
	    random_value.parent = frame_004_1
	    group_1.parent = frame_003_1
	    group_input_001_1.parent = frame_003_1
	    random_value_004.parent = frame_003_1
	    group_002_2.parent = frame_2
	
	    #Set locations
	    frame_002_1.location = (-4255.0, -613.0)
	    frame_001_1.location = (-1965.0, -734.0)
	    frame_2.location = (-2265.0, -272.0)
	    frame_004_1.location = (-2910.0, 228.0)
	    frame_003_1.location = (-4868.0, -613.0)
	    reroute_016.location = (-431.521728515625, 395.1722106933594)
	    reroute_017.location = (-431.521728515625, 354.9861755371094)
	    reroute_019.location = (-431.521728515625, 314.8001403808594)
	    reroute_018.location = (-431.521728515625, 274.6141052246094)
	    group_input_3.location = (-3843.1396484375, 29.906982421875)
	    group_output_6.location = (75.0, 50.0)
	    separate_components.location = (-3652.255859375, 19.86041259765625)
	    math_053.location = (230.622802734375, -60.3717041015625)
	    math_055.location = (230.622802734375, -100.5577392578125)
	    math_056.location = (190.436767578125, -221.11590576171875)
	    group_input_006_1.location = (29.6923828125, -221.11590576171875)
	    separate_xyz_002.location = (29.6923828125, -60.3717041015625)
	    math_054.location = (411.4599609375, -80.4647216796875)
	    math_052.location = (411.4599609375, -201.02288818359375)
	    combine_xyz_002.location = (592.29736328125, -40.2786865234375)
	    math_059.location = (592.29736328125, -281.39495849609375)
	    math_058.location = (592.29736328125, -241.20892333984375)
	    vector_rotate.location = (773.13427734375, -60.3717041015625)
	    math_057.location = (773.13427734375, -201.02288818359375)
	    group_input_007_1.location = (953.9716796875, -301.48797607421875)
	    combine_xyz.location = (953.9716796875, -201.02288818359375)
	    vector_math_014.location = (1134.808837890625, -221.11590576171875)
	    vector_math_013.location = (1335.739013671875, -140.7437744140625)
	    reroute_001_1.location = (-839.232666015625, -160.97679138183594)
	    reroute_003_1.location = (-839.232666015625, -281.5349426269531)
	    set_position.location = (-738.7674560546875, -241.348876953125)
	    set_position_001_1.location = (-738.7674560546875, -80.60469055175781)
	    normal_1.location = (30.2864990234375, -160.773193359375)
	    curve_tangent_2.location = (30.2864990234375, -100.494140625)
	    separate_xyz.location = (231.216796875, -221.05230712890625)
	    vector_math_001_2.location = (412.053955078125, -40.215087890625)
	    vector_math_003_1.location = (592.8912353515625, -40.215087890625)
	    vector_math_002_1.location = (412.053955078125, -180.86627197265625)
	    vector_math_009.location = (793.8214111328125, -40.215087890625)
	    vector_math_010.location = (592.8912353515625, -200.95928955078125)
	    vector_math_2.location = (231.216796875, -40.215087890625)
	    evaluate_on_domain_002_1.location = (1105.648681640625, -40.02239990234375)
	    separate_xyz_001.location = (201.46240234375, -261.045654296875)
	    vector_math_011.location = (743.9742431640625, -140.487548828125)
	    vector_math_005_1.location = (563.136962890625, -140.487548828125)
	    vector_math_007.location = (382.2998046875, -120.39453125)
	    vector_math_008.location = (201.46240234375, -120.39453125)
	    evaluate_at_index_1.location = (924.8114013671875, -40.02239990234375)
	    vector_math_012.location = (563.136962890625, -301.231689453125)
	    vector_math_006.location = (382.2998046875, -261.045654296875)
	    evaluate_on_domain_001_1.location = (29.70654296875, -339.79510498046875)
	    curve_tangent_001.location = (29.70654296875, -118.77178955078125)
	    normal_001_1.location = (29.70654296875, -179.0509033203125)
	    reroute_014_1.location = (-3230.302490234375, 341.3487854003906)
	    reroute_015_1.location = (-3230.302490234375, 301.1627502441406)
	    reroute_013_1.location = (-3230.302490234375, 260.9767150878906)
	    reroute_012_1.location = (-3230.302490234375, 381.5348815917969)
	    is_viewport.location = (280.716064453125, -275.73028564453125)
	    switch_1.location = (461.55322265625, -235.54425048828125)
	    id_1.location = (29.55322265625, -205.40472412109375)
	    reroute_004_1.location = (1375.44677734375, -241.39447021484375)
	    reroute_002_1.location = (571.725830078125, -100.7432861328125)
	    join_geometry.location = (1074.0513916015625, -60.5572509765625)
	    set_id.location = (1274.981689453125, -60.5572509765625)
	    store_named_attribute_1.location = (1475.911865234375, -40.464202880859375)
	    math_1.location = (290.423583984375, -382.0456237792969)
	    group_input_002_1.location = (89.4931640625, -382.0456237792969)
	    group_input_004_1.location = (89.4931640625, -321.76654052734375)
	    capture_attribute_002.location = (843.28857421875, -131.15524291992188)
	    vector_math_004_1.location = (-2506.95361328125, -703.4884033203125)
	    group_input_003_1.location = (-2687.790771484375, -824.0465698242188)
	    random_value_001.location = (381.48486328125, -40.2786865234375)
	    capture_attribute_1.location = (224.854736328125, -51.218994140625)
	    duplicate_elements.location = (652.097900390625, -120.83633422851562)
	    join_geometry_001.location = (-130.127197265625, 53.59075927734375)
	    random_value.location = (1074.0513916015625, -161.02236938476562)
	    reroute_020.location = (-223.732666015625, -87.405517578125)
	    index_1.location = (-3431.232666015625, -100.69772338867188)
	    capture_attribute_001.location = (-3210.20947265625, 60.046478271484375)
	    switch_001_3.location = (-507.69775390625, -50.46514892578125)
	    group_1.location = (211.0927734375, -211.04656982421875)
	    group_input_001_1.location = (30.255859375, -331.604736328125)
	    group_input_005_1.location = (-738.7674560546875, -0.23260498046875)
	    random_value_004.location = (211.0927734375, -291.418701171875)
	    group_002_2.location = (743.265869140625, -55.601104736328125)
	
	    #Set dimensions
	    frame_002_1.width, frame_002_1.height = 1506.0, 383.0
	    frame_001_1.width, frame_001_1.height = 964.0, 370.0
	    frame_2.width, frame_2.height = 1276.0, 454.0
	    frame_004_1.width, frame_004_1.height = 1646.0, 464.0
	    frame_003_1.width, frame_003_1.height = 551.0, 488.0
	    reroute_016.width, reroute_016.height = 10.0, 100.0
	    reroute_017.width, reroute_017.height = 10.0, 100.0
	    reroute_019.width, reroute_019.height = 10.0, 100.0
	    reroute_018.width, reroute_018.height = 10.0, 100.0
	    group_input_3.width, group_input_3.height = 140.0, 100.0
	    group_output_6.width, group_output_6.height = 140.0, 100.0
	    separate_components.width, separate_components.height = 140.0, 100.0
	    math_053.width, math_053.height = 140.0, 100.0
	    math_055.width, math_055.height = 140.0, 100.0
	    math_056.width, math_056.height = 140.0, 100.0
	    group_input_006_1.width, group_input_006_1.height = 140.0, 100.0
	    separate_xyz_002.width, separate_xyz_002.height = 140.0, 100.0
	    math_054.width, math_054.height = 140.0, 100.0
	    math_052.width, math_052.height = 140.0, 100.0
	    combine_xyz_002.width, combine_xyz_002.height = 140.0, 100.0
	    math_059.width, math_059.height = 140.0, 100.0
	    math_058.width, math_058.height = 140.0, 100.0
	    vector_rotate.width, vector_rotate.height = 140.0, 100.0
	    math_057.width, math_057.height = 140.0, 100.0
	    group_input_007_1.width, group_input_007_1.height = 140.0, 100.0
	    combine_xyz.width, combine_xyz.height = 140.0, 100.0
	    vector_math_014.width, vector_math_014.height = 140.0, 100.0
	    vector_math_013.width, vector_math_013.height = 140.0, 100.0
	    reroute_001_1.width, reroute_001_1.height = 10.0, 100.0
	    reroute_003_1.width, reroute_003_1.height = 10.0, 100.0
	    set_position.width, set_position.height = 140.0, 100.0
	    set_position_001_1.width, set_position_001_1.height = 140.0, 100.0
	    normal_1.width, normal_1.height = 140.0, 100.0
	    curve_tangent_2.width, curve_tangent_2.height = 140.0, 100.0
	    separate_xyz.width, separate_xyz.height = 140.0, 100.0
	    vector_math_001_2.width, vector_math_001_2.height = 140.0, 100.0
	    vector_math_003_1.width, vector_math_003_1.height = 140.0, 100.0
	    vector_math_002_1.width, vector_math_002_1.height = 140.0, 100.0
	    vector_math_009.width, vector_math_009.height = 140.0, 100.0
	    vector_math_010.width, vector_math_010.height = 140.0, 100.0
	    vector_math_2.width, vector_math_2.height = 140.0, 100.0
	    evaluate_on_domain_002_1.width, evaluate_on_domain_002_1.height = 140.0, 100.0
	    separate_xyz_001.width, separate_xyz_001.height = 140.0, 100.0
	    vector_math_011.width, vector_math_011.height = 140.0, 100.0
	    vector_math_005_1.width, vector_math_005_1.height = 140.0, 100.0
	    vector_math_007.width, vector_math_007.height = 140.0, 100.0
	    vector_math_008.width, vector_math_008.height = 140.0, 100.0
	    evaluate_at_index_1.width, evaluate_at_index_1.height = 140.0, 100.0
	    vector_math_012.width, vector_math_012.height = 140.0, 100.0
	    vector_math_006.width, vector_math_006.height = 140.0, 100.0
	    evaluate_on_domain_001_1.width, evaluate_on_domain_001_1.height = 140.0, 100.0
	    curve_tangent_001.width, curve_tangent_001.height = 140.0, 100.0
	    normal_001_1.width, normal_001_1.height = 140.0, 100.0
	    reroute_014_1.width, reroute_014_1.height = 10.0, 100.0
	    reroute_015_1.width, reroute_015_1.height = 10.0, 100.0
	    reroute_013_1.width, reroute_013_1.height = 10.0, 100.0
	    reroute_012_1.width, reroute_012_1.height = 10.0, 100.0
	    is_viewport.width, is_viewport.height = 140.0, 100.0
	    switch_1.width, switch_1.height = 140.0, 100.0
	    id_1.width, id_1.height = 140.0, 100.0
	    reroute_004_1.width, reroute_004_1.height = 10.0, 100.0
	    reroute_002_1.width, reroute_002_1.height = 10.0, 100.0
	    join_geometry.width, join_geometry.height = 140.0, 100.0
	    set_id.width, set_id.height = 140.0, 100.0
	    store_named_attribute_1.width, store_named_attribute_1.height = 140.0, 100.0
	    math_1.width, math_1.height = 140.0, 100.0
	    group_input_002_1.width, group_input_002_1.height = 140.0, 100.0
	    group_input_004_1.width, group_input_004_1.height = 140.0, 100.0
	    capture_attribute_002.width, capture_attribute_002.height = 140.0, 100.0
	    vector_math_004_1.width, vector_math_004_1.height = 140.0, 100.0
	    group_input_003_1.width, group_input_003_1.height = 140.0, 100.0
	    random_value_001.width, random_value_001.height = 140.0, 100.0
	    capture_attribute_1.width, capture_attribute_1.height = 140.0, 100.0
	    duplicate_elements.width, duplicate_elements.height = 140.0, 100.0
	    join_geometry_001.width, join_geometry_001.height = 140.0, 100.0
	    random_value.width, random_value.height = 140.0, 100.0
	    reroute_020.width, reroute_020.height = 10.0, 100.0
	    index_1.width, index_1.height = 140.0, 100.0
	    capture_attribute_001.width, capture_attribute_001.height = 140.0, 100.0
	    switch_001_3.width, switch_001_3.height = 140.0, 100.0
	    group_1.width, group_1.height = 140.0, 100.0
	    group_input_001_1.width, group_input_001_1.height = 140.0, 100.0
	    group_input_005_1.width, group_input_005_1.height = 140.0, 100.0
	    random_value_004.width, random_value_004.height = 140.0, 100.0
	    group_002_2.width, group_002_2.height = 140.0, 100.0
	
	    #initialize duplicate_hair_curves links
	    #join_geometry_001.Geometry -> group_output_6.Geometry
	    duplicate_hair_curves.links.new(join_geometry_001.outputs[0], group_output_6.inputs[0])
	    #reroute_002_1.Output -> duplicate_elements.Geometry
	    duplicate_hair_curves.links.new(reroute_002_1.outputs[0], duplicate_elements.inputs[0])
	    #capture_attribute_001.Geometry -> capture_attribute_1.Geometry
	    duplicate_hair_curves.links.new(capture_attribute_001.outputs[0], capture_attribute_1.inputs[0])
	    #random_value.Value -> set_id.ID
	    duplicate_hair_curves.links.new(random_value.outputs[2], set_id.inputs[2])
	    #capture_attribute_1.Value -> random_value.ID
	    duplicate_hair_curves.links.new(capture_attribute_1.outputs[1], random_value.inputs[7])
	    #duplicate_elements.Duplicate Index -> random_value.Seed
	    duplicate_hair_curves.links.new(duplicate_elements.outputs[1], random_value.inputs[8])
	    #random_value_001.Value -> separate_xyz_002.Vector
	    duplicate_hair_curves.links.new(random_value_001.outputs[0], separate_xyz_002.inputs[0])
	    #math_052.Value -> vector_rotate.Angle
	    duplicate_hair_curves.links.new(math_052.outputs[0], vector_rotate.inputs[3])
	    #combine_xyz_002.Vector -> vector_rotate.Vector
	    duplicate_hair_curves.links.new(combine_xyz_002.outputs[0], vector_rotate.inputs[0])
	    #separate_xyz_002.Y -> math_052.Value
	    duplicate_hair_curves.links.new(separate_xyz_002.outputs[1], math_052.inputs[0])
	    #separate_xyz_002.X -> math_053.Value
	    duplicate_hair_curves.links.new(separate_xyz_002.outputs[0], math_053.inputs[0])
	    #math_054.Value -> combine_xyz_002.X
	    duplicate_hair_curves.links.new(math_054.outputs[0], combine_xyz_002.inputs[0])
	    #group_1.Curve ID -> random_value_001.ID
	    duplicate_hair_curves.links.new(group_1.outputs[1], random_value_001.inputs[7])
	    #vector_math_004_1.Vector -> separate_xyz.Vector
	    duplicate_hair_curves.links.new(vector_math_004_1.outputs[0], separate_xyz.inputs[0])
	    #reroute_001_1.Output -> set_position.Geometry
	    duplicate_hair_curves.links.new(reroute_001_1.outputs[0], set_position.inputs[0])
	    #curve_tangent_2.Tangent -> vector_math_2.Vector
	    duplicate_hair_curves.links.new(curve_tangent_2.outputs[0], vector_math_2.inputs[0])
	    #normal_1.Normal -> vector_math_2.Vector
	    duplicate_hair_curves.links.new(normal_1.outputs[0], vector_math_2.inputs[1])
	    #vector_math_2.Vector -> vector_math_001_2.Vector
	    duplicate_hair_curves.links.new(vector_math_2.outputs[0], vector_math_001_2.inputs[0])
	    #vector_math_001_2.Vector -> vector_math_003_1.Vector
	    duplicate_hair_curves.links.new(vector_math_001_2.outputs[0], vector_math_003_1.inputs[0])
	    #vector_math_002_1.Vector -> vector_math_003_1.Vector
	    duplicate_hair_curves.links.new(vector_math_002_1.outputs[0], vector_math_003_1.inputs[1])
	    #separate_xyz.X -> vector_math_001_2.Scale
	    duplicate_hair_curves.links.new(separate_xyz.outputs[0], vector_math_001_2.inputs[3])
	    #separate_xyz.Y -> vector_math_002_1.Scale
	    duplicate_hair_curves.links.new(separate_xyz.outputs[1], vector_math_002_1.inputs[3])
	    #normal_1.Normal -> vector_math_002_1.Vector
	    duplicate_hair_curves.links.new(normal_1.outputs[0], vector_math_002_1.inputs[0])
	    #index_1.Index -> capture_attribute_001.Value
	    duplicate_hair_curves.links.new(index_1.outputs[0], capture_attribute_001.inputs[1])
	    #set_id.Geometry -> store_named_attribute_1.Geometry
	    duplicate_hair_curves.links.new(set_id.outputs[0], store_named_attribute_1.inputs[0])
	    #capture_attribute_002.Geometry -> join_geometry.Geometry
	    duplicate_hair_curves.links.new(capture_attribute_002.outputs[0], join_geometry.inputs[0])
	    #reroute_004_1.Output -> store_named_attribute_1.Value
	    duplicate_hair_curves.links.new(reroute_004_1.outputs[0], store_named_attribute_1.inputs[3])
	    #group_input_004_1.Amount -> switch_1.False
	    duplicate_hair_curves.links.new(group_input_004_1.outputs[1], switch_1.inputs[1])
	    #switch_1.Output -> duplicate_elements.Amount
	    duplicate_hair_curves.links.new(switch_1.outputs[0], duplicate_elements.inputs[2])
	    #is_viewport.Is Viewport -> switch_1.Switch
	    duplicate_hair_curves.links.new(is_viewport.outputs[0], switch_1.inputs[0])
	    #group_input_004_1.Amount -> math_1.Value
	    duplicate_hair_curves.links.new(group_input_004_1.outputs[1], math_1.inputs[0])
	    #math_1.Value -> switch_1.True
	    duplicate_hair_curves.links.new(math_1.outputs[0], switch_1.inputs[2])
	    #group_input_002_1.Viewport Amount -> math_1.Value
	    duplicate_hair_curves.links.new(group_input_002_1.outputs[2], math_1.inputs[1])
	    #id_1.ID -> capture_attribute_1.Value
	    duplicate_hair_curves.links.new(id_1.outputs[0], capture_attribute_1.inputs[1])
	    #vector_math_009.Vector -> set_position.Offset
	    duplicate_hair_curves.links.new(vector_math_009.outputs[0], set_position.inputs[3])
	    #group_input_005_1.Even Thickness -> switch_001_3.Switch
	    duplicate_hair_curves.links.new(group_input_005_1.outputs[6], switch_001_3.inputs[0])
	    #vector_math_007.Vector -> vector_math_005_1.Vector
	    duplicate_hair_curves.links.new(vector_math_007.outputs[0], vector_math_005_1.inputs[0])
	    #vector_math_006.Vector -> vector_math_005_1.Vector
	    duplicate_hair_curves.links.new(vector_math_006.outputs[0], vector_math_005_1.inputs[1])
	    #separate_xyz_001.X -> vector_math_007.Scale
	    duplicate_hair_curves.links.new(separate_xyz_001.outputs[0], vector_math_007.inputs[3])
	    #separate_xyz_001.Y -> vector_math_006.Scale
	    duplicate_hair_curves.links.new(separate_xyz_001.outputs[1], vector_math_006.inputs[3])
	    #evaluate_on_domain_002_1.Value -> set_position_001_1.Offset
	    duplicate_hair_curves.links.new(evaluate_on_domain_002_1.outputs[0], set_position_001_1.inputs[3])
	    #curve_tangent_001.Tangent -> vector_math_008.Vector
	    duplicate_hair_curves.links.new(curve_tangent_001.outputs[0], vector_math_008.inputs[0])
	    #normal_001_1.Normal -> vector_math_008.Vector
	    duplicate_hair_curves.links.new(normal_001_1.outputs[0], vector_math_008.inputs[1])
	    #evaluate_at_index_1.Value -> evaluate_on_domain_002_1.Value
	    duplicate_hair_curves.links.new(evaluate_at_index_1.outputs[0], evaluate_on_domain_002_1.inputs[0])
	    #vector_math_008.Vector -> vector_math_007.Vector
	    duplicate_hair_curves.links.new(vector_math_008.outputs[0], vector_math_007.inputs[0])
	    #normal_001_1.Normal -> vector_math_006.Vector
	    duplicate_hair_curves.links.new(normal_001_1.outputs[0], vector_math_006.inputs[0])
	    #evaluate_on_domain_001_1.Value -> separate_xyz_001.Vector
	    duplicate_hair_curves.links.new(evaluate_on_domain_001_1.outputs[0], separate_xyz_001.inputs[0])
	    #store_named_attribute_1.Geometry -> reroute_001_1.Input
	    duplicate_hair_curves.links.new(store_named_attribute_1.outputs[0], reroute_001_1.inputs[0])
	    #reroute_001_1.Output -> set_position_001_1.Geometry
	    duplicate_hair_curves.links.new(reroute_001_1.outputs[0], set_position_001_1.inputs[0])
	    #vector_math_011.Vector -> evaluate_at_index_1.Value
	    duplicate_hair_curves.links.new(vector_math_011.outputs[0], evaluate_at_index_1.inputs[1])
	    #capture_attribute_1.Geometry -> reroute_002_1.Input
	    duplicate_hair_curves.links.new(capture_attribute_1.outputs[0], reroute_002_1.inputs[0])
	    #math_055.Value -> math_054.Value
	    duplicate_hair_curves.links.new(math_055.outputs[0], math_054.inputs[0])
	    #math_053.Value -> math_055.Value
	    duplicate_hair_curves.links.new(math_053.outputs[0], math_055.inputs[0])
	    #math_056.Value -> math_054.Value
	    duplicate_hair_curves.links.new(math_056.outputs[0], math_054.inputs[1])
	    #group_input_006_1.Distribution Shape -> math_056.Value
	    duplicate_hair_curves.links.new(group_input_006_1.outputs[4], math_056.inputs[1])
	    #vector_math_003_1.Vector -> vector_math_009.Vector
	    duplicate_hair_curves.links.new(vector_math_003_1.outputs[0], vector_math_009.inputs[0])
	    #separate_xyz.Z -> vector_math_010.Scale
	    duplicate_hair_curves.links.new(separate_xyz.outputs[2], vector_math_010.inputs[3])
	    #curve_tangent_2.Tangent -> vector_math_010.Vector
	    duplicate_hair_curves.links.new(curve_tangent_2.outputs[0], vector_math_010.inputs[0])
	    #vector_math_010.Vector -> vector_math_009.Vector
	    duplicate_hair_curves.links.new(vector_math_010.outputs[0], vector_math_009.inputs[1])
	    #vector_math_005_1.Vector -> vector_math_011.Vector
	    duplicate_hair_curves.links.new(vector_math_005_1.outputs[0], vector_math_011.inputs[0])
	    #vector_math_012.Vector -> vector_math_011.Vector
	    duplicate_hair_curves.links.new(vector_math_012.outputs[0], vector_math_011.inputs[1])
	    #separate_xyz_001.Z -> vector_math_012.Scale
	    duplicate_hair_curves.links.new(separate_xyz_001.outputs[2], vector_math_012.inputs[3])
	    #curve_tangent_001.Tangent -> vector_math_012.Vector
	    duplicate_hair_curves.links.new(curve_tangent_001.outputs[0], vector_math_012.inputs[0])
	    #vector_rotate.Vector -> vector_math_013.Vector
	    duplicate_hair_curves.links.new(vector_rotate.outputs[0], vector_math_013.inputs[0])
	    #vector_math_014.Vector -> vector_math_013.Vector
	    duplicate_hair_curves.links.new(vector_math_014.outputs[0], vector_math_013.inputs[1])
	    #math_057.Value -> combine_xyz.Z
	    duplicate_hair_curves.links.new(math_057.outputs[0], combine_xyz.inputs[2])
	    #vector_math_013.Vector -> vector_math_004_1.Vector
	    duplicate_hair_curves.links.new(vector_math_013.outputs[0], vector_math_004_1.inputs[0])
	    #group_input_003_1.Radius -> vector_math_004_1.Scale
	    duplicate_hair_curves.links.new(group_input_003_1.outputs[3], vector_math_004_1.inputs[3])
	    #math_058.Value -> math_057.Value
	    duplicate_hair_curves.links.new(math_058.outputs[0], math_057.inputs[0])
	    #math_059.Value -> math_057.Value
	    duplicate_hair_curves.links.new(math_059.outputs[0], math_057.inputs[1])
	    #math_054.Value -> math_058.Value
	    duplicate_hair_curves.links.new(math_054.outputs[0], math_058.inputs[0])
	    #combine_xyz.Vector -> vector_math_014.Vector
	    duplicate_hair_curves.links.new(combine_xyz.outputs[0], vector_math_014.inputs[0])
	    #group_input_007_1.Tip Roundness -> vector_math_014.Scale
	    duplicate_hair_curves.links.new(group_input_007_1.outputs[5], vector_math_014.inputs[3])
	    #separate_xyz_002.Z -> math_059.Value
	    duplicate_hair_curves.links.new(separate_xyz_002.outputs[2], math_059.inputs[0])
	    #set_position_001_1.Geometry -> switch_001_3.False
	    duplicate_hair_curves.links.new(set_position_001_1.outputs[0], switch_001_3.inputs[1])
	    #set_position.Geometry -> switch_001_3.True
	    duplicate_hair_curves.links.new(set_position.outputs[0], switch_001_3.inputs[2])
	    #reroute_003_1.Output -> set_position.Selection
	    duplicate_hair_curves.links.new(reroute_003_1.outputs[0], set_position.inputs[1])
	    #reroute_003_1.Output -> set_position_001_1.Selection
	    duplicate_hair_curves.links.new(reroute_003_1.outputs[0], set_position_001_1.inputs[1])
	    #capture_attribute_002.Value -> reroute_003_1.Input
	    duplicate_hair_curves.links.new(capture_attribute_002.outputs[1], reroute_003_1.inputs[0])
	    #capture_attribute_001.Value -> reroute_004_1.Input
	    duplicate_hair_curves.links.new(capture_attribute_001.outputs[1], reroute_004_1.inputs[0])
	    #join_geometry.Geometry -> set_id.Geometry
	    duplicate_hair_curves.links.new(join_geometry.outputs[0], set_id.inputs[0])
	    #duplicate_elements.Geometry -> capture_attribute_002.Geometry
	    duplicate_hair_curves.links.new(duplicate_elements.outputs[0], capture_attribute_002.inputs[0])
	    #group_input_001_1.Seed -> random_value_004.ID
	    duplicate_hair_curves.links.new(group_input_001_1.outputs[7], random_value_004.inputs[7])
	    #random_value_004.Value -> random_value_001.Seed
	    duplicate_hair_curves.links.new(random_value_004.outputs[2], random_value_001.inputs[8])
	    #vector_math_004_1.Vector -> evaluate_on_domain_001_1.Value
	    duplicate_hair_curves.links.new(vector_math_004_1.outputs[0], evaluate_on_domain_001_1.inputs[0])
	    #reroute_018.Output -> join_geometry_001.Geometry
	    duplicate_hair_curves.links.new(reroute_018.outputs[0], join_geometry_001.inputs[0])
	    #separate_components.Mesh -> reroute_012_1.Input
	    duplicate_hair_curves.links.new(separate_components.outputs[0], reroute_012_1.inputs[0])
	    #separate_components.Instances -> reroute_013_1.Input
	    duplicate_hair_curves.links.new(separate_components.outputs[5], reroute_013_1.inputs[0])
	    #separate_components.Point Cloud -> reroute_014_1.Input
	    duplicate_hair_curves.links.new(separate_components.outputs[3], reroute_014_1.inputs[0])
	    #separate_components.Volume -> reroute_015_1.Input
	    duplicate_hair_curves.links.new(separate_components.outputs[4], reroute_015_1.inputs[0])
	    #reroute_012_1.Output -> reroute_016.Input
	    duplicate_hair_curves.links.new(reroute_012_1.outputs[0], reroute_016.inputs[0])
	    #reroute_014_1.Output -> reroute_017.Input
	    duplicate_hair_curves.links.new(reroute_014_1.outputs[0], reroute_017.inputs[0])
	    #reroute_013_1.Output -> reroute_018.Input
	    duplicate_hair_curves.links.new(reroute_013_1.outputs[0], reroute_018.inputs[0])
	    #reroute_015_1.Output -> reroute_019.Input
	    duplicate_hair_curves.links.new(reroute_015_1.outputs[0], reroute_019.inputs[0])
	    #switch_001_3.Output -> reroute_020.Input
	    duplicate_hair_curves.links.new(switch_001_3.outputs[0], reroute_020.inputs[0])
	    #group_input_3.Geometry -> separate_components.Geometry
	    duplicate_hair_curves.links.new(group_input_3.outputs[0], separate_components.inputs[0])
	    #separate_components.Curve -> capture_attribute_001.Geometry
	    duplicate_hair_curves.links.new(separate_components.outputs[1], capture_attribute_001.inputs[0])
	    #reroute_004_1.Output -> group_output_6.Guide Index
	    duplicate_hair_curves.links.new(reroute_004_1.outputs[0], group_output_6.inputs[1])
	    #group_002_2.Root Index -> evaluate_at_index_1.Index
	    duplicate_hair_curves.links.new(group_002_2.outputs[3], evaluate_at_index_1.inputs[0])
	    #reroute_002_1.Output -> join_geometry.Geometry
	    duplicate_hair_curves.links.new(reroute_002_1.outputs[0], join_geometry.inputs[0])
	    #reroute_019.Output -> join_geometry_001.Geometry
	    duplicate_hair_curves.links.new(reroute_019.outputs[0], join_geometry_001.inputs[0])
	    #reroute_020.Output -> join_geometry_001.Geometry
	    duplicate_hair_curves.links.new(reroute_020.outputs[0], join_geometry_001.inputs[0])
	    #reroute_017.Output -> join_geometry_001.Geometry
	    duplicate_hair_curves.links.new(reroute_017.outputs[0], join_geometry_001.inputs[0])
	    #reroute_016.Output -> join_geometry_001.Geometry
	    duplicate_hair_curves.links.new(reroute_016.outputs[0], join_geometry_001.inputs[0])
	    return duplicate_hair_curves
	
	duplicate_hair_curves = duplicate_hair_curves_node_group()
	
	#initialize shape_range node group
	def shape_range_node_group():
	    shape_range = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "shape_range")
	
	    shape_range.color_tag = 'NONE'
	    shape_range.description = ""
	    shape_range.default_group_node_width = 140
	    
	
	
	    #shape_range interface
	    #Socket Value
	    value_socket = shape_range.interface.new_socket(name = "Value", in_out='OUTPUT', socket_type = 'NodeSocketFloat')
	    value_socket.default_value = 0.0
	    value_socket.min_value = -3.4028234663852886e+38
	    value_socket.max_value = 3.4028234663852886e+38
	    value_socket.subtype = 'NONE'
	    value_socket.attribute_domain = 'POINT'
	
	    #Socket Value
	    value_socket_1 = shape_range.interface.new_socket(name = "Value", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    value_socket_1.default_value = 0.0
	    value_socket_1.min_value = 0.0
	    value_socket_1.max_value = 1.0
	    value_socket_1.subtype = 'NONE'
	    value_socket_1.attribute_domain = 'POINT'
	    value_socket_1.hide_value = True
	
	    #Socket Min
	    min_socket = shape_range.interface.new_socket(name = "Min", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    min_socket.default_value = 0.0
	    min_socket.min_value = -10000.0
	    min_socket.max_value = 10000.0
	    min_socket.subtype = 'NONE'
	    min_socket.attribute_domain = 'POINT'
	    min_socket.description = "rdghrhd"
	
	    #Socket Max
	    max_socket = shape_range.interface.new_socket(name = "Max", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    max_socket.default_value = 1.0
	    max_socket.min_value = -10000.0
	    max_socket.max_value = 10000.0
	    max_socket.subtype = 'NONE'
	    max_socket.attribute_domain = 'POINT'
	
	    #Socket Shape
	    shape_socket = shape_range.interface.new_socket(name = "Shape", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    shape_socket.default_value = 0.0
	    shape_socket.min_value = -1.0
	    shape_socket.max_value = 1.0
	    shape_socket.subtype = 'NONE'
	    shape_socket.attribute_domain = 'POINT'
	
	    #Socket Base
	    base_socket = shape_range.interface.new_socket(name = "Base", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    base_socket.default_value = 2.0
	    base_socket.min_value = 1.0
	    base_socket.max_value = 10000.0
	    base_socket.subtype = 'NONE'
	    base_socket.attribute_domain = 'POINT'
	
	
	    #initialize shape_range nodes
	    #node Switch.001
	    switch_001_4 = shape_range.nodes.new("GeometryNodeSwitch")
	    switch_001_4.name = "Switch.001"
	    switch_001_4.hide = True
	    switch_001_4.input_type = 'FLOAT'
	
	    #node Math.016
	    math_016 = shape_range.nodes.new("ShaderNodeMath")
	    math_016.name = "Math.016"
	    math_016.hide = True
	    math_016.operation = 'SUBTRACT'
	    math_016.use_clamp = False
	    #Value
	    math_016.inputs[0].default_value = 1.0
	
	    #node Math.004
	    math_004 = shape_range.nodes.new("ShaderNodeMath")
	    math_004.name = "Math.004"
	    math_004.hide = True
	    math_004.operation = 'SUBTRACT'
	    math_004.use_clamp = False
	    #Value
	    math_004.inputs[0].default_value = 1.0
	
	    #node Reroute
	    reroute_4 = shape_range.nodes.new("NodeReroute")
	    reroute_4.name = "Reroute"
	    reroute_4.socket_idname = "NodeSocketFloat"
	    #node Map Range
	    map_range = shape_range.nodes.new("ShaderNodeMapRange")
	    map_range.name = "Map Range"
	    map_range.hide = True
	    map_range.clamp = False
	    map_range.data_type = 'FLOAT'
	    map_range.interpolation_type = 'LINEAR'
	    map_range.inputs[3].hide = True
	    map_range.inputs[4].hide = True
	    map_range.inputs[5].hide = True
	    map_range.inputs[6].hide = True
	    map_range.inputs[7].hide = True
	    map_range.inputs[8].hide = True
	    map_range.inputs[9].hide = True
	    map_range.inputs[10].hide = True
	    map_range.inputs[11].hide = True
	    map_range.outputs[1].hide = True
	    #To Min
	    map_range.inputs[3].default_value = 0.0
	    #To Max
	    map_range.inputs[4].default_value = 1.0
	
	    #node Math.001
	    math_001 = shape_range.nodes.new("ShaderNodeMath")
	    math_001.name = "Math.001"
	    math_001.hide = True
	    math_001.operation = 'DIVIDE'
	    math_001.use_clamp = False
	    #Value
	    math_001.inputs[0].default_value = 1.0
	
	    #node Math.012
	    math_012 = shape_range.nodes.new("ShaderNodeMath")
	    math_012.name = "Math.012"
	    math_012.hide = True
	    math_012.operation = 'SUBTRACT'
	    math_012.use_clamp = False
	    #Value
	    math_012.inputs[0].default_value = 1.0
	
	    #node Math.013
	    math_013 = shape_range.nodes.new("ShaderNodeMath")
	    math_013.name = "Math.013"
	    math_013.hide = True
	    math_013.operation = 'MULTIPLY'
	    math_013.use_clamp = False
	    #Value_001
	    math_013.inputs[1].default_value = 2.0
	
	    #node Math
	    math_2 = shape_range.nodes.new("ShaderNodeMath")
	    math_2.name = "Math"
	    math_2.hide = True
	    math_2.operation = 'MULTIPLY'
	    math_2.use_clamp = False
	
	    #node Reroute.001
	    reroute_001_2 = shape_range.nodes.new("NodeReroute")
	    reroute_001_2.name = "Reroute.001"
	    reroute_001_2.socket_idname = "NodeSocketFloat"
	    #node Compare.004
	    compare_004 = shape_range.nodes.new("FunctionNodeCompare")
	    compare_004.name = "Compare.004"
	    compare_004.hide = True
	    compare_004.data_type = 'FLOAT'
	    compare_004.mode = 'ELEMENT'
	    compare_004.operation = 'LESS_THAN'
	    #B
	    compare_004.inputs[1].default_value = 0.0
	
	    #node Compare
	    compare_1 = shape_range.nodes.new("FunctionNodeCompare")
	    compare_1.name = "Compare"
	    compare_1.hide = True
	    compare_1.data_type = 'FLOAT'
	    compare_1.mode = 'ELEMENT'
	    compare_1.operation = 'GREATER_THAN'
	    #B
	    compare_1.inputs[1].default_value = 0.5
	
	    #node Boolean Math.002
	    boolean_math_002 = shape_range.nodes.new("FunctionNodeBooleanMath")
	    boolean_math_002.name = "Boolean Math.002"
	    boolean_math_002.hide = True
	    boolean_math_002.operation = 'NOT'
	
	    #node Switch
	    switch_2 = shape_range.nodes.new("GeometryNodeSwitch")
	    switch_2.name = "Switch"
	    switch_2.hide = True
	    switch_2.input_type = 'BOOLEAN'
	
	    #node Math.014
	    math_014 = shape_range.nodes.new("ShaderNodeMath")
	    math_014.name = "Math.014"
	    math_014.hide = True
	    math_014.operation = 'MAXIMUM'
	    math_014.use_clamp = False
	    #Value_001
	    math_014.inputs[1].default_value = 1.0000100135803223
	
	    #node Math.006
	    math_006 = shape_range.nodes.new("ShaderNodeMath")
	    math_006.name = "Math.006"
	    math_006.hide = True
	    math_006.operation = 'MULTIPLY'
	    math_006.use_clamp = False
	    #Value_001
	    math_006.inputs[1].default_value = -1.0
	
	    #node Math.007
	    math_007 = shape_range.nodes.new("ShaderNodeMath")
	    math_007.name = "Math.007"
	    math_007.hide = True
	    math_007.operation = 'SUBTRACT'
	    math_007.use_clamp = False
	    #Value
	    math_007.inputs[0].default_value = 1.0
	
	    #node Math.010
	    math_010 = shape_range.nodes.new("ShaderNodeMath")
	    math_010.name = "Math.010"
	    math_010.hide = True
	    math_010.operation = 'MAXIMUM'
	    math_010.use_clamp = False
	    #Value_001
	    math_010.inputs[1].default_value = 1.0000009536743164
	
	    #node Math.009
	    math_009 = shape_range.nodes.new("ShaderNodeMath")
	    math_009.name = "Math.009"
	    math_009.hide = True
	    math_009.operation = 'MAXIMUM'
	    math_009.use_clamp = False
	    #Value_001
	    math_009.inputs[1].default_value = 9.999999747378752e-06
	
	    #node Math.002
	    math_002 = shape_range.nodes.new("ShaderNodeMath")
	    math_002.name = "Math.002"
	    math_002.operation = 'POWER'
	    math_002.use_clamp = False
	
	    #node Math.005
	    math_005 = shape_range.nodes.new("ShaderNodeMath")
	    math_005.name = "Math.005"
	    math_005.hide = True
	    math_005.operation = 'LOGARITHM'
	    math_005.use_clamp = False
	
	    #node Math.015
	    math_015 = shape_range.nodes.new("ShaderNodeMath")
	    math_015.name = "Math.015"
	    math_015.hide = True
	    math_015.operation = 'PINGPONG'
	    math_015.use_clamp = False
	    #Value_001
	    math_015.inputs[1].default_value = 0.5
	
	    #node Math.017
	    math_017 = shape_range.nodes.new("ShaderNodeMath")
	    math_017.name = "Math.017"
	    math_017.operation = 'MINIMUM'
	    math_017.use_clamp = False
	    #Value_001
	    math_017.inputs[1].default_value = 0.9999989867210388
	
	    #node Math.003
	    math_003 = shape_range.nodes.new("ShaderNodeMath")
	    math_003.name = "Math.003"
	    math_003.operation = 'ABSOLUTE'
	    math_003.use_clamp = False
	
	    #node Map Range.001
	    map_range_001 = shape_range.nodes.new("ShaderNodeMapRange")
	    map_range_001.name = "Map Range.001"
	    map_range_001.clamp = True
	    map_range_001.data_type = 'FLOAT'
	    map_range_001.interpolation_type = 'LINEAR'
	    map_range_001.inputs[1].hide = True
	    map_range_001.inputs[2].hide = True
	    map_range_001.inputs[5].hide = True
	    map_range_001.inputs[6].hide = True
	    map_range_001.inputs[7].hide = True
	    map_range_001.inputs[8].hide = True
	    map_range_001.inputs[9].hide = True
	    map_range_001.inputs[10].hide = True
	    map_range_001.inputs[11].hide = True
	    map_range_001.outputs[1].hide = True
	    #From Min
	    map_range_001.inputs[1].default_value = 0.0
	    #From Max
	    map_range_001.inputs[2].default_value = 1.0
	
	    #node Group Input
	    group_input_4 = shape_range.nodes.new("NodeGroupInput")
	    group_input_4.name = "Group Input"
	
	    #node Group Output
	    group_output_7 = shape_range.nodes.new("NodeGroupOutput")
	    group_output_7.name = "Group Output"
	    group_output_7.is_active_output = True
	
	    #node Switch.002
	    switch_002 = shape_range.nodes.new("GeometryNodeSwitch")
	    switch_002.name = "Switch.002"
	    switch_002.hide = True
	    switch_002.input_type = 'FLOAT'
	
	    #node Switch.003
	    switch_003 = shape_range.nodes.new("GeometryNodeSwitch")
	    switch_003.name = "Switch.003"
	    switch_003.input_type = 'FLOAT'
	    #True
	    switch_003.inputs[2].default_value = 1.0
	
	    #node Compare.001
	    compare_001_1 = shape_range.nodes.new("FunctionNodeCompare")
	    compare_001_1.name = "Compare.001"
	    compare_001_1.data_type = 'FLOAT'
	    compare_001_1.mode = 'ELEMENT'
	    compare_001_1.operation = 'EQUAL'
	    #B
	    compare_001_1.inputs[1].default_value = 0.0
	    #Epsilon
	    compare_001_1.inputs[12].default_value = 9.999999747378752e-06
	
	
	
	
	
	    #Set locations
	    switch_001_4.location = (-1034.40283203125, 93.75666046142578)
	    math_016.location = (-632.5424194335938, 53.57061004638672)
	    math_004.location = (-1295.6121826171875, 133.94271850585938)
	    reroute_4.location = (-1315.7052001953125, 93.75666046142578)
	    map_range.location = (-1516.635498046875, 73.66363525390625)
	    math_001.location = (-1858.2169189453125, -147.359619140625)
	    math_012.location = (-1858.2169189453125, -107.17357635498047)
	    math_013.location = (-1858.2169189453125, -66.9875259399414)
	    math_2.location = (-1858.2169189453125, -26.801475524902344)
	    reroute_001_2.location = (-2119.42626953125, -147.359619140625)
	    compare_004.location = (-1637.193603515625, -66.9875259399414)
	    compare_1.location = (-1637.193603515625, -107.17357635498047)
	    boolean_math_002.location = (-1456.3564453125, -107.17357635498047)
	    switch_2.location = (-1456.3564453125, -66.9875259399414)
	    math_014.location = (-2059.14697265625, -107.17357635498047)
	    math_006.location = (-1034.40283203125, -87.0805435180664)
	    math_007.location = (-1034.40283203125, 33.47759246826172)
	    math_010.location = (-1195.1470947265625, -107.17357635498047)
	    math_009.location = (-1034.40283203125, -6.708457946777344)
	    math_002.location = (-833.47265625, 113.84968566894531)
	    math_005.location = (-1034.40283203125, -46.894508361816406)
	    math_015.location = (-2059.14697265625, -147.359619140625)
	    math_017.location = (-2280.17041015625, -127.26660919189453)
	    math_003.location = (-2461.007568359375, -127.26660919189453)
	    map_range_001.location = (-411.5191650390625, 53.57061004638672)
	    group_input_4.location = (-2682.03076171875, 13.384567260742188)
	    group_output_7.location = (75.0, 50.0)
	    switch_002.location = (-632.5424194335938, 93.75666046142578)
	    switch_003.location = (-164.938232421875, 110.71707153320312)
	    compare_001_1.location = (-828.0901489257812, 397.66241455078125)
	
	    #Set dimensions
	    switch_001_4.width, switch_001_4.height = 140.0, 100.0
	    math_016.width, math_016.height = 140.0, 100.0
	    math_004.width, math_004.height = 140.0, 100.0
	    reroute_4.width, reroute_4.height = 10.0, 100.0
	    map_range.width, map_range.height = 140.0, 100.0
	    math_001.width, math_001.height = 140.0, 100.0
	    math_012.width, math_012.height = 140.0, 100.0
	    math_013.width, math_013.height = 140.0, 100.0
	    math_2.width, math_2.height = 140.0, 100.0
	    reroute_001_2.width, reroute_001_2.height = 10.0, 100.0
	    compare_004.width, compare_004.height = 140.0, 100.0
	    compare_1.width, compare_1.height = 140.0, 100.0
	    boolean_math_002.width, boolean_math_002.height = 140.0, 100.0
	    switch_2.width, switch_2.height = 140.0, 100.0
	    math_014.width, math_014.height = 140.0, 100.0
	    math_006.width, math_006.height = 140.0, 100.0
	    math_007.width, math_007.height = 140.0, 100.0
	    math_010.width, math_010.height = 140.0, 100.0
	    math_009.width, math_009.height = 140.0, 100.0
	    math_002.width, math_002.height = 140.0, 100.0
	    math_005.width, math_005.height = 140.0, 100.0
	    math_015.width, math_015.height = 140.0, 100.0
	    math_017.width, math_017.height = 140.0, 100.0
	    math_003.width, math_003.height = 140.0, 100.0
	    map_range_001.width, map_range_001.height = 140.0, 100.0
	    group_input_4.width, group_input_4.height = 140.0, 100.0
	    group_output_7.width, group_output_7.height = 140.0, 100.0
	    switch_002.width, switch_002.height = 140.0, 100.0
	    switch_003.width, switch_003.height = 140.0, 100.0
	    compare_001_1.width, compare_001_1.height = 140.0, 100.0
	
	    #initialize shape_range links
	    #math_009.Value -> math_005.Value
	    shape_range.links.new(math_009.outputs[0], math_005.inputs[0])
	    #math_005.Value -> math_006.Value
	    shape_range.links.new(math_005.outputs[0], math_006.inputs[0])
	    #math_004.Value -> switch_001_4.True
	    shape_range.links.new(math_004.outputs[0], switch_001_4.inputs[2])
	    #math_2.Value -> math_007.Value
	    shape_range.links.new(math_2.outputs[0], math_007.inputs[1])
	    #switch_001_4.Output -> math_002.Value
	    shape_range.links.new(switch_001_4.outputs[0], math_002.inputs[0])
	    #reroute_4.Output -> math_004.Value
	    shape_range.links.new(reroute_4.outputs[0], math_004.inputs[1])
	    #math_006.Value -> math_002.Value
	    shape_range.links.new(math_006.outputs[0], math_002.inputs[1])
	    #reroute_4.Output -> switch_001_4.False
	    shape_range.links.new(reroute_4.outputs[0], switch_001_4.inputs[1])
	    #math_010.Value -> math_005.Value
	    shape_range.links.new(math_010.outputs[0], math_005.inputs[1])
	    #map_range.Result -> reroute_4.Input
	    shape_range.links.new(map_range.outputs[0], reroute_4.inputs[0])
	    #group_input_4.Value -> map_range.Value
	    shape_range.links.new(group_input_4.outputs[0], map_range.inputs[0])
	    #group_input_4.Min -> map_range.From Min
	    shape_range.links.new(group_input_4.outputs[1], map_range.inputs[1])
	    #group_input_4.Max -> map_range.From Max
	    shape_range.links.new(group_input_4.outputs[2], map_range.inputs[2])
	    #switch_002.Output -> map_range_001.Value
	    shape_range.links.new(switch_002.outputs[0], map_range_001.inputs[0])
	    #group_input_4.Min -> map_range_001.To Min
	    shape_range.links.new(group_input_4.outputs[1], map_range_001.inputs[3])
	    #group_input_4.Max -> map_range_001.To Max
	    shape_range.links.new(group_input_4.outputs[2], map_range_001.inputs[4])
	    #math_007.Value -> math_009.Value
	    shape_range.links.new(math_007.outputs[0], math_009.inputs[0])
	    #math_014.Value -> math_010.Value
	    shape_range.links.new(math_014.outputs[0], math_010.inputs[0])
	    #switch_003.Output -> group_output_7.Value
	    shape_range.links.new(switch_003.outputs[0], group_output_7.inputs[0])
	    #math_013.Value -> math_2.Value
	    shape_range.links.new(math_013.outputs[0], math_2.inputs[1])
	    #math_001.Value -> math_012.Value
	    shape_range.links.new(math_001.outputs[0], math_012.inputs[1])
	    #math_014.Value -> math_001.Value
	    shape_range.links.new(math_014.outputs[0], math_001.inputs[1])
	    #math_012.Value -> math_013.Value
	    shape_range.links.new(math_012.outputs[0], math_013.inputs[0])
	    #group_input_4.Base -> math_014.Value
	    shape_range.links.new(group_input_4.outputs[4], math_014.inputs[0])
	    #math_015.Value -> math_2.Value
	    shape_range.links.new(math_015.outputs[0], math_2.inputs[0])
	    #reroute_001_2.Output -> math_015.Value
	    shape_range.links.new(reroute_001_2.outputs[0], math_015.inputs[0])
	    #switch_2.Output -> switch_001_4.Switch
	    shape_range.links.new(switch_2.outputs[0], switch_001_4.inputs[0])
	    #reroute_001_2.Output -> compare_1.A
	    shape_range.links.new(reroute_001_2.outputs[0], compare_1.inputs[0])
	    #math_002.Value -> switch_002.False
	    shape_range.links.new(math_002.outputs[0], switch_002.inputs[1])
	    #math_016.Value -> switch_002.True
	    shape_range.links.new(math_016.outputs[0], switch_002.inputs[2])
	    #compare_1.Result -> switch_002.Switch
	    shape_range.links.new(compare_1.outputs[0], switch_002.inputs[0])
	    #math_002.Value -> math_016.Value
	    shape_range.links.new(math_002.outputs[0], math_016.inputs[1])
	    #group_input_4.Shape -> compare_004.A
	    shape_range.links.new(group_input_4.outputs[3], compare_004.inputs[0])
	    #math_017.Value -> reroute_001_2.Input
	    shape_range.links.new(math_017.outputs[0], reroute_001_2.inputs[0])
	    #group_input_4.Shape -> math_003.Value
	    shape_range.links.new(group_input_4.outputs[3], math_003.inputs[0])
	    #compare_004.Result -> boolean_math_002.Boolean
	    shape_range.links.new(compare_004.outputs[0], boolean_math_002.inputs[0])
	    #compare_1.Result -> switch_2.Switch
	    shape_range.links.new(compare_1.outputs[0], switch_2.inputs[0])
	    #compare_004.Result -> switch_2.False
	    shape_range.links.new(compare_004.outputs[0], switch_2.inputs[1])
	    #boolean_math_002.Boolean -> switch_2.True
	    shape_range.links.new(boolean_math_002.outputs[0], switch_2.inputs[2])
	    #math_003.Value -> math_017.Value
	    shape_range.links.new(math_003.outputs[0], math_017.inputs[0])
	    #group_input_4.Shape -> compare_001_1.A
	    shape_range.links.new(group_input_4.outputs[3], compare_001_1.inputs[0])
	    #map_range_001.Result -> switch_003.False
	    shape_range.links.new(map_range_001.outputs[0], switch_003.inputs[1])
	    #compare_001_1.Result -> switch_003.Switch
	    shape_range.links.new(compare_001_1.outputs[0], switch_003.inputs[0])
	    return shape_range
	
	shape_range = shape_range_node_group()
	
	#initialize curve_segment node group
	def curve_segment_node_group():
	    curve_segment = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Curve Segment")
	
	    curve_segment.color_tag = 'NONE'
	    curve_segment.description = "Reads information each point's previous curve segment"
	    curve_segment.default_group_node_width = 140
	    
	
	
	    #curve_segment interface
	    #Socket Segment Length
	    segment_length_socket = curve_segment.interface.new_socket(name = "Segment Length", in_out='OUTPUT', socket_type = 'NodeSocketFloat')
	    segment_length_socket.default_value = 0.0
	    segment_length_socket.min_value = -3.4028234663852886e+38
	    segment_length_socket.max_value = 3.4028234663852886e+38
	    segment_length_socket.subtype = 'NONE'
	    segment_length_socket.attribute_domain = 'POINT'
	    segment_length_socket.description = "Distance to previous point on curve"
	
	    #Socket Segment Direction
	    segment_direction_socket = curve_segment.interface.new_socket(name = "Segment Direction", in_out='OUTPUT', socket_type = 'NodeSocketVector')
	    segment_direction_socket.default_value = (0.0, 0.0, 0.0)
	    segment_direction_socket.min_value = -3.4028234663852886e+38
	    segment_direction_socket.max_value = 3.4028234663852886e+38
	    segment_direction_socket.subtype = 'NONE'
	    segment_direction_socket.attribute_domain = 'POINT'
	    segment_direction_socket.description = "Direction from previous neighboring point on segment"
	
	    #Socket Neighbor Index
	    neighbor_index_socket = curve_segment.interface.new_socket(name = "Neighbor Index", in_out='OUTPUT', socket_type = 'NodeSocketInt')
	    neighbor_index_socket.default_value = 0
	    neighbor_index_socket.min_value = -2147483648
	    neighbor_index_socket.max_value = 2147483647
	    neighbor_index_socket.subtype = 'NONE'
	    neighbor_index_socket.attribute_domain = 'POINT'
	    neighbor_index_socket.description = "Index of previous neighboring point on segment"
	
	
	    #initialize curve_segment nodes
	    #node Vector Math.009
	    vector_math_009_1 = curve_segment.nodes.new("ShaderNodeVectorMath")
	    vector_math_009_1.name = "Vector Math.009"
	    vector_math_009_1.operation = 'NORMALIZE'
	
	    #node Reroute.015
	    reroute_015_2 = curve_segment.nodes.new("NodeReroute")
	    reroute_015_2.name = "Reroute.015"
	    reroute_015_2.socket_idname = "NodeSocketVector"
	    #node Reroute.017
	    reroute_017_1 = curve_segment.nodes.new("NodeReroute")
	    reroute_017_1.name = "Reroute.017"
	    reroute_017_1.socket_idname = "NodeSocketVector"
	    #node Field at Index.001
	    field_at_index_001 = curve_segment.nodes.new("GeometryNodeFieldAtIndex")
	    field_at_index_001.name = "Field at Index.001"
	    field_at_index_001.data_type = 'FLOAT_VECTOR'
	    field_at_index_001.domain = 'POINT'
	
	    #node Vector Math.008
	    vector_math_008_1 = curve_segment.nodes.new("ShaderNodeVectorMath")
	    vector_math_008_1.name = "Vector Math.008"
	    vector_math_008_1.operation = 'SUBTRACT'
	
	    #node Reroute.018
	    reroute_018_1 = curve_segment.nodes.new("NodeReroute")
	    reroute_018_1.name = "Reroute.018"
	    reroute_018_1.socket_idname = "NodeSocketInt"
	    #node Interpolate Domain.002
	    interpolate_domain_002_2 = curve_segment.nodes.new("GeometryNodeFieldOnDomain")
	    interpolate_domain_002_2.name = "Interpolate Domain.002"
	    interpolate_domain_002_2.data_type = 'FLOAT_VECTOR'
	    interpolate_domain_002_2.domain = 'POINT'
	
	    #node Group Output
	    group_output_8 = curve_segment.nodes.new("NodeGroupOutput")
	    group_output_8.name = "Group Output"
	    group_output_8.is_active_output = True
	
	    #node Vector Math.007
	    vector_math_007_1 = curve_segment.nodes.new("ShaderNodeVectorMath")
	    vector_math_007_1.name = "Vector Math.007"
	    vector_math_007_1.operation = 'LENGTH'
	
	    #node Interpolate Domain.003
	    interpolate_domain_003 = curve_segment.nodes.new("GeometryNodeFieldOnDomain")
	    interpolate_domain_003.name = "Interpolate Domain.003"
	    interpolate_domain_003.data_type = 'INT'
	    interpolate_domain_003.domain = 'POINT'
	
	    #node Reroute
	    reroute_5 = curve_segment.nodes.new("NodeReroute")
	    reroute_5.name = "Reroute"
	    reroute_5.socket_idname = "NodeSocketBool"
	    #node Switch.004
	    switch_004 = curve_segment.nodes.new("GeometryNodeSwitch")
	    switch_004.name = "Switch.004"
	    switch_004.hide = True
	    switch_004.input_type = 'VECTOR'
	    #False
	    switch_004.inputs[1].default_value = (0.0, 0.0, 0.0)
	
	    #node Switch.003
	    switch_003_1 = curve_segment.nodes.new("GeometryNodeSwitch")
	    switch_003_1.name = "Switch.003"
	    switch_003_1.hide = True
	    switch_003_1.input_type = 'FLOAT'
	    #False
	    switch_003_1.inputs[1].default_value = 0.0
	
	    #node Boolean
	    boolean = curve_segment.nodes.new("FunctionNodeInputBool")
	    boolean.name = "Boolean"
	    boolean.boolean = True
	
	    #node Interpolate Domain
	    interpolate_domain_2 = curve_segment.nodes.new("GeometryNodeFieldOnDomain")
	    interpolate_domain_2.name = "Interpolate Domain"
	    interpolate_domain_2.data_type = 'BOOLEAN'
	    interpolate_domain_2.domain = 'CURVE'
	
	    #node Switch.005
	    switch_005 = curve_segment.nodes.new("GeometryNodeSwitch")
	    switch_005.name = "Switch.005"
	    switch_005.hide = True
	    switch_005.input_type = 'INT'
	    #False
	    switch_005.inputs[1].default_value = 0
	
	    #node Index.002
	    index_002 = curve_segment.nodes.new("GeometryNodeInputIndex")
	    index_002.name = "Index.002"
	
	    #node Switch.001
	    switch_001_5 = curve_segment.nodes.new("GeometryNodeSwitch")
	    switch_001_5.name = "Switch.001"
	    switch_001_5.input_type = 'INT'
	
	    #node Offset Point in Curve
	    offset_point_in_curve = curve_segment.nodes.new("GeometryNodeOffsetPointInCurve")
	    offset_point_in_curve.name = "Offset Point in Curve"
	    #Point Index
	    offset_point_in_curve.inputs[0].default_value = 0
	    #Offset
	    offset_point_in_curve.inputs[1].default_value = -1
	
	    #node Position.002
	    position_002_2 = curve_segment.nodes.new("GeometryNodeInputPosition")
	    position_002_2.name = "Position.002"
	
	
	
	
	
	    #Set locations
	    vector_math_009_1.location = (-389.8524169921875, 30.443286895751953)
	    reroute_015_2.location = (-456.8948974609375, 4.604297637939453)
	    reroute_017_1.location = (-1012.7362060546875, -9.742748260498047)
	    field_at_index_001.location = (-992.6431884765625, 70.62931823730469)
	    vector_math_008_1.location = (-811.805908203125, 70.62931823730469)
	    reroute_018_1.location = (-1032.8292236328125, 110.81541442871094)
	    interpolate_domain_002_2.location = (-630.9686279296875, 70.62931823730469)
	    group_output_8.location = (75.0, 50.0)
	    vector_math_007_1.location = (-389.8524169921875, 151.00144958496094)
	    interpolate_domain_003.location = (-390.85833740234375, -97.25408935546875)
	    reroute_5.location = (-342.979248046875, 193.345458984375)
	    switch_004.location = (-178.8756103515625, 10.35025405883789)
	    switch_003_1.location = (-178.8756103515625, 90.72234344482422)
	    boolean.location = (-781.6663208007812, 291.652587890625)
	    interpolate_domain_2.location = (-600.8291015625, 311.74560546875)
	    switch_005.location = (-178.8756103515625, -70.0218505859375)
	    index_002.location = (-1404.550048828125, 211.28048706054688)
	    switch_001_5.location = (-1223.712890625, 231.37350463867188)
	    offset_point_in_curve.location = (-1404.550048828125, 151.0014190673828)
	    position_002_2.location = (-1223.712890625, 30.44327163696289)
	
	    #Set dimensions
	    vector_math_009_1.width, vector_math_009_1.height = 140.0, 100.0
	    reroute_015_2.width, reroute_015_2.height = 100.0, 100.0
	    reroute_017_1.width, reroute_017_1.height = 100.0, 100.0
	    field_at_index_001.width, field_at_index_001.height = 140.0, 100.0
	    vector_math_008_1.width, vector_math_008_1.height = 140.0, 100.0
	    reroute_018_1.width, reroute_018_1.height = 100.0, 100.0
	    interpolate_domain_002_2.width, interpolate_domain_002_2.height = 140.0, 100.0
	    group_output_8.width, group_output_8.height = 140.0, 100.0
	    vector_math_007_1.width, vector_math_007_1.height = 140.0, 100.0
	    interpolate_domain_003.width, interpolate_domain_003.height = 140.0, 100.0
	    reroute_5.width, reroute_5.height = 100.0, 100.0
	    switch_004.width, switch_004.height = 140.0, 100.0
	    switch_003_1.width, switch_003_1.height = 140.0, 100.0
	    boolean.width, boolean.height = 140.0, 100.0
	    interpolate_domain_2.width, interpolate_domain_2.height = 140.0, 100.0
	    switch_005.width, switch_005.height = 140.0, 100.0
	    index_002.width, index_002.height = 140.0, 100.0
	    switch_001_5.width, switch_001_5.height = 140.0, 100.0
	    offset_point_in_curve.width, offset_point_in_curve.height = 140.0, 100.0
	    position_002_2.width, position_002_2.height = 140.0, 100.0
	
	    #initialize curve_segment links
	    #reroute_015_2.Output -> vector_math_007_1.Vector
	    curve_segment.links.new(reroute_015_2.outputs[0], vector_math_007_1.inputs[0])
	    #reroute_018_1.Output -> field_at_index_001.Index
	    curve_segment.links.new(reroute_018_1.outputs[0], field_at_index_001.inputs[0])
	    #vector_math_008_1.Vector -> interpolate_domain_002_2.Value
	    curve_segment.links.new(vector_math_008_1.outputs[0], interpolate_domain_002_2.inputs[0])
	    #reroute_017_1.Output -> vector_math_008_1.Vector
	    curve_segment.links.new(reroute_017_1.outputs[0], vector_math_008_1.inputs[0])
	    #reroute_015_2.Output -> vector_math_009_1.Vector
	    curve_segment.links.new(reroute_015_2.outputs[0], vector_math_009_1.inputs[0])
	    #reroute_017_1.Output -> field_at_index_001.Value
	    curve_segment.links.new(reroute_017_1.outputs[0], field_at_index_001.inputs[1])
	    #field_at_index_001.Value -> vector_math_008_1.Vector
	    curve_segment.links.new(field_at_index_001.outputs[0], vector_math_008_1.inputs[1])
	    #position_002_2.Position -> reroute_017_1.Input
	    curve_segment.links.new(position_002_2.outputs[0], reroute_017_1.inputs[0])
	    #interpolate_domain_002_2.Value -> reroute_015_2.Input
	    curve_segment.links.new(interpolate_domain_002_2.outputs[0], reroute_015_2.inputs[0])
	    #switch_004.Output -> group_output_8.Segment Direction
	    curve_segment.links.new(switch_004.outputs[0], group_output_8.inputs[1])
	    #switch_005.Output -> group_output_8.Neighbor Index
	    curve_segment.links.new(switch_005.outputs[0], group_output_8.inputs[2])
	    #boolean.Boolean -> interpolate_domain_2.Value
	    curve_segment.links.new(boolean.outputs[0], interpolate_domain_2.inputs[0])
	    #reroute_018_1.Output -> interpolate_domain_003.Value
	    curve_segment.links.new(reroute_018_1.outputs[0], interpolate_domain_003.inputs[0])
	    #vector_math_007_1.Value -> switch_003_1.True
	    curve_segment.links.new(vector_math_007_1.outputs[1], switch_003_1.inputs[2])
	    #reroute_5.Output -> switch_003_1.Switch
	    curve_segment.links.new(reroute_5.outputs[0], switch_003_1.inputs[0])
	    #switch_003_1.Output -> group_output_8.Segment Length
	    curve_segment.links.new(switch_003_1.outputs[0], group_output_8.inputs[0])
	    #vector_math_009_1.Vector -> switch_004.True
	    curve_segment.links.new(vector_math_009_1.outputs[0], switch_004.inputs[2])
	    #interpolate_domain_2.Value -> reroute_5.Input
	    curve_segment.links.new(interpolate_domain_2.outputs[0], reroute_5.inputs[0])
	    #reroute_5.Output -> switch_004.Switch
	    curve_segment.links.new(reroute_5.outputs[0], switch_004.inputs[0])
	    #interpolate_domain_003.Value -> switch_005.True
	    curve_segment.links.new(interpolate_domain_003.outputs[0], switch_005.inputs[2])
	    #reroute_5.Output -> switch_005.Switch
	    curve_segment.links.new(reroute_5.outputs[0], switch_005.inputs[0])
	    #offset_point_in_curve.Is Valid Offset -> switch_001_5.Switch
	    curve_segment.links.new(offset_point_in_curve.outputs[0], switch_001_5.inputs[0])
	    #offset_point_in_curve.Point Index -> switch_001_5.True
	    curve_segment.links.new(offset_point_in_curve.outputs[1], switch_001_5.inputs[2])
	    #index_002.Index -> switch_001_5.False
	    curve_segment.links.new(index_002.outputs[0], switch_001_5.inputs[1])
	    #switch_001_5.Output -> reroute_018_1.Input
	    curve_segment.links.new(switch_001_5.outputs[0], reroute_018_1.inputs[0])
	    return curve_segment
	
	curve_segment = curve_segment_node_group()
	
	#initialize restore_curve_segment_length node group
	def restore_curve_segment_length_node_group():
	    restore_curve_segment_length = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Restore Curve Segment Length")
	
	    restore_curve_segment_length.color_tag = 'NONE'
	    restore_curve_segment_length.description = "Restores the length of each curve segment using a previous state after deformation"
	    restore_curve_segment_length.default_group_node_width = 140
	    
	
	    restore_curve_segment_length.is_modifier = True
	
	    #restore_curve_segment_length interface
	    #Socket Curves
	    curves_socket = restore_curve_segment_length.interface.new_socket(name = "Curves", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    curves_socket.attribute_domain = 'POINT'
	
	    #Socket Curves
	    curves_socket_1 = restore_curve_segment_length.interface.new_socket(name = "Curves", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    curves_socket_1.attribute_domain = 'POINT'
	
	    #Socket Selection
	    selection_socket = restore_curve_segment_length.interface.new_socket(name = "Selection", in_out='INPUT', socket_type = 'NodeSocketBool')
	    selection_socket.default_value = True
	    selection_socket.attribute_domain = 'POINT'
	    selection_socket.hide_value = True
	    selection_socket.description = "Only affect selected elements"
	
	    #Socket Factor
	    factor_socket = restore_curve_segment_length.interface.new_socket(name = "Factor", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    factor_socket.default_value = 1.0
	    factor_socket.min_value = 0.0
	    factor_socket.max_value = 1.0
	    factor_socket.subtype = 'FACTOR'
	    factor_socket.attribute_domain = 'POINT'
	    factor_socket.description = "Factor to blend overall effect"
	
	    #Socket Reference Position
	    reference_position_socket = restore_curve_segment_length.interface.new_socket(name = "Reference Position", in_out='INPUT', socket_type = 'NodeSocketVector')
	    reference_position_socket.default_value = (8.146539688110352, 4.969870090484619, 9.874540328979492)
	    reference_position_socket.min_value = -3.4028234663852886e+38
	    reference_position_socket.max_value = 3.4028234663852886e+38
	    reference_position_socket.subtype = 'NONE'
	    reference_position_socket.default_attribute_name = "rest_position"
	    reference_position_socket.attribute_domain = 'POINT'
	    reference_position_socket.hide_value = True
	    reference_position_socket.description = "Reference position before deformation"
	
	    #Socket Pin at Parameter
	    pin_at_parameter_socket = restore_curve_segment_length.interface.new_socket(name = "Pin at Parameter", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    pin_at_parameter_socket.default_value = 0.0
	    pin_at_parameter_socket.min_value = 0.0
	    pin_at_parameter_socket.max_value = 1.0
	    pin_at_parameter_socket.subtype = 'FACTOR'
	    pin_at_parameter_socket.attribute_domain = 'POINT'
	    pin_at_parameter_socket.description = "Pin each curve at a certain point for the operation"
	
	
	    #initialize restore_curve_segment_length nodes
	    #node Frame.001
	    frame_001_2 = restore_curve_segment_length.nodes.new("NodeFrame")
	    frame_001_2.label = "Pin at Parameter"
	    frame_001_2.name = "Frame.001"
	    frame_001_2.label_size = 20
	    frame_001_2.shrink = True
	
	    #node Frame
	    frame_3 = restore_curve_segment_length.nodes.new("NodeFrame")
	    frame_3.label = "Restore Segment Lengths"
	    frame_3.name = "Frame"
	    frame_3.label_size = 20
	    frame_3.shrink = True
	
	    #node Frame.002
	    frame_002_2 = restore_curve_segment_length.nodes.new("NodeFrame")
	    frame_002_2.label = "Default Fallback"
	    frame_002_2.name = "Frame.002"
	    frame_002_2.label_size = 20
	    frame_002_2.shrink = True
	
	    #node Reroute.009
	    reroute_009_1 = restore_curve_segment_length.nodes.new("NodeReroute")
	    reroute_009_1.name = "Reroute.009"
	    reroute_009_1.socket_idname = "NodeSocketVector"
	    #node Group Input.006
	    group_input_006_2 = restore_curve_segment_length.nodes.new("NodeGroupInput")
	    group_input_006_2.name = "Group Input.006"
	    group_input_006_2.outputs[0].hide = True
	    group_input_006_2.outputs[1].hide = True
	    group_input_006_2.outputs[2].hide = True
	    group_input_006_2.outputs[3].hide = True
	    group_input_006_2.outputs[5].hide = True
	
	    #node Reroute.013
	    reroute_013_2 = restore_curve_segment_length.nodes.new("NodeReroute")
	    reroute_013_2.name = "Reroute.013"
	    reroute_013_2.socket_idname = "NodeSocketGeometry"
	    #node Index
	    index_2 = restore_curve_segment_length.nodes.new("GeometryNodeInputIndex")
	    index_2.name = "Index"
	
	    #node Sample Curve.001
	    sample_curve_001_1 = restore_curve_segment_length.nodes.new("GeometryNodeSampleCurve")
	    sample_curve_001_1.name = "Sample Curve.001"
	    sample_curve_001_1.data_type = 'FLOAT_VECTOR'
	    sample_curve_001_1.mode = 'FACTOR'
	    sample_curve_001_1.use_all_curves = False
	
	    #node Group Input.003
	    group_input_003_2 = restore_curve_segment_length.nodes.new("NodeGroupInput")
	    group_input_003_2.name = "Group Input.003"
	    group_input_003_2.outputs[0].hide = True
	    group_input_003_2.outputs[1].hide = True
	    group_input_003_2.outputs[2].hide = True
	    group_input_003_2.outputs[3].hide = True
	    group_input_003_2.outputs[5].hide = True
	
	    #node Vector Math.006
	    vector_math_006_1 = restore_curve_segment_length.nodes.new("ShaderNodeVectorMath")
	    vector_math_006_1.name = "Vector Math.006"
	    vector_math_006_1.hide = True
	    vector_math_006_1.operation = 'SUBTRACT'
	
	    #node Interpolate Domain
	    interpolate_domain_3 = restore_curve_segment_length.nodes.new("GeometryNodeFieldOnDomain")
	    interpolate_domain_3.name = "Interpolate Domain"
	    interpolate_domain_3.hide = True
	    interpolate_domain_3.data_type = 'FLOAT_VECTOR'
	    interpolate_domain_3.domain = 'CURVE'
	
	    #node Group Input.005
	    group_input_005_2 = restore_curve_segment_length.nodes.new("NodeGroupInput")
	    group_input_005_2.name = "Group Input.005"
	    group_input_005_2.outputs[0].hide = True
	    group_input_005_2.outputs[2].hide = True
	    group_input_005_2.outputs[3].hide = True
	    group_input_005_2.outputs[4].hide = True
	    group_input_005_2.outputs[5].hide = True
	
	    #node Boolean Math.002
	    boolean_math_002_1 = restore_curve_segment_length.nodes.new("FunctionNodeBooleanMath")
	    boolean_math_002_1.name = "Boolean Math.002"
	    boolean_math_002_1.hide = True
	    boolean_math_002_1.operation = 'AND'
	
	    #node Field at Index.002
	    field_at_index_002 = restore_curve_segment_length.nodes.new("GeometryNodeFieldAtIndex")
	    field_at_index_002.name = "Field at Index.002"
	    field_at_index_002.data_type = 'FLOAT_VECTOR'
	    field_at_index_002.domain = 'POINT'
	
	    #node Vector Math.004
	    vector_math_004_2 = restore_curve_segment_length.nodes.new("ShaderNodeVectorMath")
	    vector_math_004_2.name = "Vector Math.004"
	    vector_math_004_2.operation = 'DISTANCE'
	
	    #node Accumulate Field
	    accumulate_field = restore_curve_segment_length.nodes.new("GeometryNodeAccumulateField")
	    accumulate_field.name = "Accumulate Field"
	    accumulate_field.data_type = 'FLOAT_VECTOR'
	    accumulate_field.domain = 'POINT'
	    accumulate_field.outputs[1].hide = True
	    accumulate_field.outputs[2].hide = True
	
	    #node Curve of Point
	    curve_of_point = restore_curve_segment_length.nodes.new("GeometryNodeCurveOfPoint")
	    curve_of_point.name = "Curve of Point"
	    curve_of_point.inputs[0].hide = True
	    curve_of_point.outputs[1].hide = True
	    #Point Index
	    curve_of_point.inputs[0].default_value = 0
	
	    #node Vector Math
	    vector_math_3 = restore_curve_segment_length.nodes.new("ShaderNodeVectorMath")
	    vector_math_3.name = "Vector Math"
	    vector_math_3.operation = 'SCALE'
	
	    #node Index.001
	    index_001_1 = restore_curve_segment_length.nodes.new("GeometryNodeInputIndex")
	    index_001_1.name = "Index.001"
	
	    #node Curve of Point.001
	    curve_of_point_001 = restore_curve_segment_length.nodes.new("GeometryNodeCurveOfPoint")
	    curve_of_point_001.name = "Curve of Point.001"
	    curve_of_point_001.inputs[0].hide = True
	    curve_of_point_001.outputs[0].hide = True
	    #Point Index
	    curve_of_point_001.inputs[0].default_value = 0
	
	    #node Switch
	    switch_3 = restore_curve_segment_length.nodes.new("GeometryNodeSwitch")
	    switch_3.name = "Switch"
	    switch_3.input_type = 'INT'
	
	    #node Math
	    math_3 = restore_curve_segment_length.nodes.new("ShaderNodeMath")
	    math_3.name = "Math"
	    math_3.hide = True
	    math_3.operation = 'SUBTRACT'
	    math_3.use_clamp = False
	    #Value_001
	    math_3.inputs[1].default_value = 1.0
	
	    #node Compare
	    compare_2 = restore_curve_segment_length.nodes.new("FunctionNodeCompare")
	    compare_2.name = "Compare"
	    compare_2.hide = True
	    compare_2.data_type = 'INT'
	    compare_2.mode = 'ELEMENT'
	    compare_2.operation = 'EQUAL'
	    #B_INT
	    compare_2.inputs[3].default_value = 0
	
	    #node Reroute.001
	    reroute_001_3 = restore_curve_segment_length.nodes.new("NodeReroute")
	    reroute_001_3.name = "Reroute.001"
	    reroute_001_3.socket_idname = "NodeSocketVector"
	    #node Set Position.001
	    set_position_001_2 = restore_curve_segment_length.nodes.new("GeometryNodeSetPosition")
	    set_position_001_2.name = "Set Position.001"
	
	    #node Boolean Math
	    boolean_math = restore_curve_segment_length.nodes.new("FunctionNodeBooleanMath")
	    boolean_math.name = "Boolean Math"
	    boolean_math.operation = 'AND'
	
	    #node Compare.002
	    compare_002_3 = restore_curve_segment_length.nodes.new("FunctionNodeCompare")
	    compare_002_3.name = "Compare.002"
	    compare_002_3.data_type = 'FLOAT'
	    compare_002_3.mode = 'ELEMENT'
	    compare_002_3.operation = 'GREATER_THAN'
	    #B
	    compare_002_3.inputs[1].default_value = 0.0
	
	    #node Group Input.002
	    group_input_002_2 = restore_curve_segment_length.nodes.new("NodeGroupInput")
	    group_input_002_2.name = "Group Input.002"
	    group_input_002_2.outputs[0].hide = True
	    group_input_002_2.outputs[3].hide = True
	    group_input_002_2.outputs[4].hide = True
	    group_input_002_2.outputs[5].hide = True
	
	    #node Reroute.016
	    reroute_016_1 = restore_curve_segment_length.nodes.new("NodeReroute")
	    reroute_016_1.name = "Reroute.016"
	    reroute_016_1.socket_idname = "NodeSocketBool"
	    #node Reroute.014
	    reroute_014_2 = restore_curve_segment_length.nodes.new("NodeReroute")
	    reroute_014_2.name = "Reroute.014"
	    reroute_014_2.socket_idname = "NodeSocketGeometry"
	    #node Switch.001
	    switch_001_6 = restore_curve_segment_length.nodes.new("GeometryNodeSwitch")
	    switch_001_6.name = "Switch.001"
	    switch_001_6.input_type = 'GEOMETRY'
	
	    #node Group Output
	    group_output_9 = restore_curve_segment_length.nodes.new("NodeGroupOutput")
	    group_output_9.name = "Group Output"
	    group_output_9.is_active_output = True
	
	    #node Attribute Statistic
	    attribute_statistic = restore_curve_segment_length.nodes.new("GeometryNodeAttributeStatistic")
	    attribute_statistic.name = "Attribute Statistic"
	    attribute_statistic.hide = True
	    attribute_statistic.data_type = 'FLOAT'
	    attribute_statistic.domain = 'CURVE'
	    attribute_statistic.inputs[1].hide = True
	    attribute_statistic.outputs[0].hide = True
	    attribute_statistic.outputs[1].hide = True
	    attribute_statistic.outputs[2].hide = True
	    attribute_statistic.outputs[3].hide = True
	    attribute_statistic.outputs[5].hide = True
	    attribute_statistic.outputs[6].hide = True
	    attribute_statistic.outputs[7].hide = True
	    #Selection
	    attribute_statistic.inputs[1].default_value = True
	
	    #node Reroute.007
	    reroute_007_1 = restore_curve_segment_length.nodes.new("NodeReroute")
	    reroute_007_1.name = "Reroute.007"
	    reroute_007_1.socket_idname = "NodeSocketVector"
	    #node Reroute.004
	    reroute_004_2 = restore_curve_segment_length.nodes.new("NodeReroute")
	    reroute_004_2.name = "Reroute.004"
	    reroute_004_2.socket_idname = "NodeSocketGeometry"
	    #node Position.001
	    position_001_1 = restore_curve_segment_length.nodes.new("GeometryNodeInputPosition")
	    position_001_1.name = "Position.001"
	
	    #node Named Attribute
	    named_attribute_2 = restore_curve_segment_length.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute_2.name = "Named Attribute"
	    named_attribute_2.data_type = 'FLOAT_VECTOR'
	    #Name
	    named_attribute_2.inputs[0].default_value = "rest_position"
	
	    #node Switch.003
	    switch_003_2 = restore_curve_segment_length.nodes.new("GeometryNodeSwitch")
	    switch_003_2.name = "Switch.003"
	    switch_003_2.input_type = 'VECTOR'
	
	    #node Reroute.006
	    reroute_006_1 = restore_curve_segment_length.nodes.new("NodeReroute")
	    reroute_006_1.name = "Reroute.006"
	    reroute_006_1.socket_idname = "NodeSocketVector"
	    #node Switch.002
	    switch_002_1 = restore_curve_segment_length.nodes.new("GeometryNodeSwitch")
	    switch_002_1.name = "Switch.002"
	    switch_002_1.input_type = 'VECTOR'
	
	    #node Compare.004
	    compare_004_1 = restore_curve_segment_length.nodes.new("FunctionNodeCompare")
	    compare_004_1.name = "Compare.004"
	    compare_004_1.data_type = 'VECTOR'
	    compare_004_1.mode = 'ELEMENT'
	    compare_004_1.operation = 'EQUAL'
	    #B_VEC3
	    compare_004_1.inputs[5].default_value = (8.146539688110352, 4.969870090484619, 9.874540328979492)
	    #Epsilon
	    compare_004_1.inputs[12].default_value = 0.0
	
	    #node Group Input
	    group_input_5 = restore_curve_segment_length.nodes.new("NodeGroupInput")
	    group_input_5.name = "Group Input"
	    group_input_5.outputs[1].hide = True
	    group_input_5.outputs[2].hide = True
	    group_input_5.outputs[4].hide = True
	    group_input_5.outputs[5].hide = True
	
	    #node Reroute.011
	    reroute_011_1 = restore_curve_segment_length.nodes.new("NodeReroute")
	    reroute_011_1.name = "Reroute.011"
	    reroute_011_1.socket_idname = "NodeSocketGeometry"
	    #node Reroute.005
	    reroute_005_1 = restore_curve_segment_length.nodes.new("NodeReroute")
	    reroute_005_1.name = "Reroute.005"
	    reroute_005_1.socket_idname = "NodeSocketGeometry"
	    #node Reroute.008
	    reroute_008_1 = restore_curve_segment_length.nodes.new("NodeReroute")
	    reroute_008_1.name = "Reroute.008"
	    reroute_008_1.socket_idname = "NodeSocketVector"
	    #node Set Position.002
	    set_position_002_1 = restore_curve_segment_length.nodes.new("GeometryNodeSetPosition")
	    set_position_002_1.name = "Set Position.002"
	    set_position_002_1.inputs[2].hide = True
	    #Position
	    set_position_002_1.inputs[2].default_value = (0.0, 0.0, 0.0)
	
	    #node Reroute.012
	    reroute_012_2 = restore_curve_segment_length.nodes.new("NodeReroute")
	    reroute_012_2.name = "Reroute.012"
	    reroute_012_2.socket_idname = "NodeSocketGeometry"
	    #node Group Input.001
	    group_input_001_2 = restore_curve_segment_length.nodes.new("NodeGroupInput")
	    group_input_001_2.name = "Group Input.001"
	    group_input_001_2.outputs[0].hide = True
	    group_input_001_2.outputs[1].hide = True
	    group_input_001_2.outputs[3].hide = True
	    group_input_001_2.outputs[4].hide = True
	    group_input_001_2.outputs[5].hide = True
	
	    #node Mix
	    mix = restore_curve_segment_length.nodes.new("ShaderNodeMix")
	    mix.name = "Mix"
	    mix.blend_type = 'MIX'
	    mix.clamp_factor = True
	    mix.clamp_result = False
	    mix.data_type = 'FLOAT'
	    mix.factor_mode = 'UNIFORM'
	
	    #node Group.001
	    group_001_1 = restore_curve_segment_length.nodes.new("GeometryNodeGroup")
	    group_001_1.name = "Group.001"
	    group_001_1.node_tree = curve_segment
	    group_001_1.outputs[2].hide = True
	
	    #node Compare.003
	    compare_003_1 = restore_curve_segment_length.nodes.new("FunctionNodeCompare")
	    compare_003_1.name = "Compare.003"
	    compare_003_1.hide = True
	    compare_003_1.data_type = 'FLOAT'
	    compare_003_1.mode = 'ELEMENT'
	    compare_003_1.operation = 'NOT_EQUAL'
	    #B
	    compare_003_1.inputs[1].default_value = 0.0
	    #Epsilon
	    compare_003_1.inputs[12].default_value = 0.0
	
	    #node Compare.005
	    compare_005 = restore_curve_segment_length.nodes.new("FunctionNodeCompare")
	    compare_005.name = "Compare.005"
	    compare_005.hide = True
	    compare_005.data_type = 'FLOAT'
	    compare_005.mode = 'ELEMENT'
	    compare_005.operation = 'GREATER_THAN'
	    #B
	    compare_005.inputs[1].default_value = 0.0
	
	    #node Group.002
	    group_002_3 = restore_curve_segment_length.nodes.new("GeometryNodeGroup")
	    group_002_3.name = "Group.002"
	    group_002_3.node_tree = curve_root
	    group_002_3.outputs[0].hide = True
	    group_002_3.outputs[2].hide = True
	    group_002_3.outputs[3].hide = True
	
	
	
	
	    #Set parents
	    group_input_006_2.parent = frame_001_2
	    reroute_013_2.parent = frame_001_2
	    index_2.parent = frame_001_2
	    sample_curve_001_1.parent = frame_001_2
	    group_input_003_2.parent = frame_001_2
	    vector_math_006_1.parent = frame_001_2
	    interpolate_domain_3.parent = frame_001_2
	    group_input_005_2.parent = frame_001_2
	    boolean_math_002_1.parent = frame_001_2
	    field_at_index_002.parent = frame_3
	    vector_math_004_2.parent = frame_3
	    accumulate_field.parent = frame_3
	    curve_of_point.parent = frame_3
	    vector_math_3.parent = frame_3
	    index_001_1.parent = frame_3
	    curve_of_point_001.parent = frame_3
	    switch_3.parent = frame_3
	    math_3.parent = frame_3
	    compare_2.parent = frame_3
	    reroute_001_3.parent = frame_3
	    set_position_001_2.parent = frame_3
	    boolean_math.parent = frame_3
	    compare_002_3.parent = frame_3
	    group_input_002_2.parent = frame_3
	    reroute_016_1.parent = frame_001_2
	    reroute_014_2.parent = frame_001_2
	    switch_001_6.parent = frame_001_2
	    attribute_statistic.parent = frame_001_2
	    reroute_004_2.parent = frame_3
	    position_001_1.parent = frame_002_2
	    named_attribute_2.parent = frame_002_2
	    switch_003_2.parent = frame_002_2
	    reroute_006_1.parent = frame_002_2
	    switch_002_1.parent = frame_002_2
	    compare_004_1.parent = frame_002_2
	    reroute_005_1.parent = frame_3
	    set_position_002_1.parent = frame_001_2
	    reroute_012_2.parent = frame_001_2
	    group_input_001_2.parent = frame_3
	    mix.parent = frame_3
	    group_001_1.parent = frame_3
	    compare_003_1.parent = frame_001_2
	    compare_005.parent = frame_001_2
	    group_002_3.parent = frame_3
	
	    #Set locations
	    frame_001_2.location = (-1286.139892578125, 110.0)
	    frame_3.location = (-3491.0, 54.813934326171875)
	    frame_002_2.location = (-4464.1865234375, -101.0)
	    reroute_009_1.location = (-1431.9771728515625, -673.348876953125)
	    group_input_006_2.location = (215.837158203125, -140.37210083007812)
	    reroute_013_2.location = (175.651123046875, -120.2790756225586)
	    index_2.location = (35.0, -481.9534912109375)
	    sample_curve_001_1.location = (215.837158203125, -220.7441864013672)
	    group_input_003_2.location = (35.0, -421.6744384765625)
	    vector_math_006_1.location = (396.6744384765625, -260.93023681640625)
	    interpolate_domain_3.location = (577.5116577148438, -260.93023681640625)
	    group_input_005_2.location = (396.6744384765625, -180.5581512451172)
	    boolean_math_002_1.location = (577.5116577148438, -180.5581512451172)
	    field_at_index_002.location = (652.51123046875, -245.93023681640625)
	    vector_math_004_2.location = (833.348388671875, -225.83721923828125)
	    accumulate_field.location = (1556.697265625, -406.6744384765625)
	    curve_of_point.location = (1355.76708984375, -547.3255615234375)
	    vector_math_3.location = (1355.76708984375, -386.5813903808594)
	    index_001_1.location = (29.62744140625, -466.9534912109375)
	    curve_of_point_001.location = (29.62744140625, -386.5813903808594)
	    switch_3.location = (411.39501953125, -366.4883728027344)
	    math_3.location = (210.46484375, -466.9534912109375)
	    compare_2.location = (210.46484375, -426.7674560546875)
	    reroute_001_3.location = (612.3251953125, -306.20928955078125)
	    set_position_001_2.location = (1797.8135986328125, -145.46511840820312)
	    boolean_math.location = (1493.957763671875, -93.53775024414062)
	    compare_002_3.location = (1293.02783203125, -113.63077545166016)
	    group_input_002_2.location = (1112.19091796875, -133.7238006591797)
	    reroute_016_1.location = (798.534912109375, -160.46511840820312)
	    reroute_014_2.location = (798.534912109375, -120.2790756225586)
	    switch_001_6.location = (1079.837158203125, -39.906982421875)
	    group_output_9.location = (75.0, 50.0)
	    attribute_statistic.location = (858.81396484375, -60.0)
	    reroute_007_1.location = (-3762.76806640625, -251.3953857421875)
	    reroute_004_2.location = (1637.0693359375, -45.0)
	    position_001_1.location = (57.345703125, -240.45068359375)
	    named_attribute_2.location = (57.345703125, -300.729736328125)
	    switch_003_2.location = (238.1826171875, -220.357666015625)
	    reroute_006_1.location = (35.0, -71.92265319824219)
	    switch_002_1.location = (439.11279296875, -99.79951477050781)
	    compare_004_1.location = (57.34619140625, -39.52044677734375)
	    group_input_5.location = (-4707.1396484375, -30.37213134765625)
	    reroute_011_1.location = (-3581.9306640625, -70.55816650390625)
	    reroute_005_1.location = (49.720703125, -45.0)
	    reroute_008_1.location = (-3561.83740234375, -673.348876953125)
	    set_position_002_1.location = (858.81396484375, -140.37210083007812)
	    reroute_012_2.location = (35.0, -240.83721923828125)
	    group_input_001_2.location = (833.348388671875, -165.55813598632812)
	    mix.location = (1114.65087890625, -326.3023376464844)
	    group_001_1.location = (833.348388671875, -406.6744384765625)
	    compare_003_1.location = (396.6744384765625, -140.37210083007812)
	    compare_005.location = (858.81396484375, -100.18605041503906)
	    group_002_3.location = (1528.587158203125, -261.22265625)
	
	    #Set dimensions
	    frame_001_2.width, frame_001_2.height = 1250.139892578125, 562.0
	    frame_3.width, frame_3.height = 1968.0, 629.81396484375
	    frame_002_2.width, frame_002_2.height = 609.1865234375, 452.0
	    reroute_009_1.width, reroute_009_1.height = 10.0, 100.0
	    group_input_006_2.width, group_input_006_2.height = 140.0, 100.0
	    reroute_013_2.width, reroute_013_2.height = 10.0, 100.0
	    index_2.width, index_2.height = 140.0, 100.0
	    sample_curve_001_1.width, sample_curve_001_1.height = 140.0, 100.0
	    group_input_003_2.width, group_input_003_2.height = 140.0, 100.0
	    vector_math_006_1.width, vector_math_006_1.height = 140.0, 100.0
	    interpolate_domain_3.width, interpolate_domain_3.height = 140.0, 100.0
	    group_input_005_2.width, group_input_005_2.height = 140.0, 100.0
	    boolean_math_002_1.width, boolean_math_002_1.height = 140.0, 100.0
	    field_at_index_002.width, field_at_index_002.height = 140.0, 100.0
	    vector_math_004_2.width, vector_math_004_2.height = 140.0, 100.0
	    accumulate_field.width, accumulate_field.height = 140.0, 100.0
	    curve_of_point.width, curve_of_point.height = 140.0, 100.0
	    vector_math_3.width, vector_math_3.height = 140.0, 100.0
	    index_001_1.width, index_001_1.height = 140.0, 100.0
	    curve_of_point_001.width, curve_of_point_001.height = 140.0, 100.0
	    switch_3.width, switch_3.height = 140.0, 100.0
	    math_3.width, math_3.height = 140.0, 100.0
	    compare_2.width, compare_2.height = 140.0, 100.0
	    reroute_001_3.width, reroute_001_3.height = 10.0, 100.0
	    set_position_001_2.width, set_position_001_2.height = 140.0, 100.0
	    boolean_math.width, boolean_math.height = 140.0, 100.0
	    compare_002_3.width, compare_002_3.height = 140.0, 100.0
	    group_input_002_2.width, group_input_002_2.height = 140.0, 100.0
	    reroute_016_1.width, reroute_016_1.height = 10.0, 100.0
	    reroute_014_2.width, reroute_014_2.height = 10.0, 100.0
	    switch_001_6.width, switch_001_6.height = 140.0, 100.0
	    group_output_9.width, group_output_9.height = 140.0, 100.0
	    attribute_statistic.width, attribute_statistic.height = 140.0, 100.0
	    reroute_007_1.width, reroute_007_1.height = 10.0, 100.0
	    reroute_004_2.width, reroute_004_2.height = 10.0, 100.0
	    position_001_1.width, position_001_1.height = 140.0, 100.0
	    named_attribute_2.width, named_attribute_2.height = 140.0, 100.0
	    switch_003_2.width, switch_003_2.height = 140.0, 100.0
	    reroute_006_1.width, reroute_006_1.height = 10.0, 100.0
	    switch_002_1.width, switch_002_1.height = 140.0, 100.0
	    compare_004_1.width, compare_004_1.height = 140.0, 100.0
	    group_input_5.width, group_input_5.height = 140.0, 100.0
	    reroute_011_1.width, reroute_011_1.height = 10.0, 100.0
	    reroute_005_1.width, reroute_005_1.height = 10.0, 100.0
	    reroute_008_1.width, reroute_008_1.height = 10.0, 100.0
	    set_position_002_1.width, set_position_002_1.height = 140.0, 100.0
	    reroute_012_2.width, reroute_012_2.height = 10.0, 100.0
	    group_input_001_2.width, group_input_001_2.height = 140.0, 100.0
	    mix.width, mix.height = 140.0, 100.0
	    group_001_1.width, group_001_1.height = 140.0, 100.0
	    compare_003_1.width, compare_003_1.height = 140.0, 100.0
	    compare_005.width, compare_005.height = 140.0, 100.0
	    group_002_3.width, group_002_3.height = 140.0, 100.0
	
	    #initialize restore_curve_segment_length links
	    #reroute_004_2.Output -> set_position_001_2.Geometry
	    restore_curve_segment_length.links.new(reroute_004_2.outputs[0], set_position_001_2.inputs[0])
	    #curve_of_point.Curve Index -> accumulate_field.Group ID
	    restore_curve_segment_length.links.new(curve_of_point.outputs[0], accumulate_field.inputs[1])
	    #field_at_index_002.Value -> vector_math_004_2.Vector
	    restore_curve_segment_length.links.new(field_at_index_002.outputs[0], vector_math_004_2.inputs[0])
	    #reroute_001_3.Output -> vector_math_004_2.Vector
	    restore_curve_segment_length.links.new(reroute_001_3.outputs[0], vector_math_004_2.inputs[1])
	    #reroute_001_3.Output -> field_at_index_002.Value
	    restore_curve_segment_length.links.new(reroute_001_3.outputs[0], field_at_index_002.inputs[1])
	    #index_001_1.Index -> math_3.Value
	    restore_curve_segment_length.links.new(index_001_1.outputs[0], math_3.inputs[0])
	    #switch_3.Output -> field_at_index_002.Index
	    restore_curve_segment_length.links.new(switch_3.outputs[0], field_at_index_002.inputs[0])
	    #vector_math_3.Vector -> accumulate_field.Value
	    restore_curve_segment_length.links.new(vector_math_3.outputs[0], accumulate_field.inputs[0])
	    #curve_of_point_001.Index in Curve -> compare_2.A
	    restore_curve_segment_length.links.new(curve_of_point_001.outputs[1], compare_2.inputs[2])
	    #math_3.Value -> switch_3.False
	    restore_curve_segment_length.links.new(math_3.outputs[0], switch_3.inputs[1])
	    #compare_2.Result -> switch_3.Switch
	    restore_curve_segment_length.links.new(compare_2.outputs[0], switch_3.inputs[0])
	    #index_001_1.Index -> switch_3.True
	    restore_curve_segment_length.links.new(index_001_1.outputs[0], switch_3.inputs[2])
	    #reroute_006_1.Output -> switch_002_1.False
	    restore_curve_segment_length.links.new(reroute_006_1.outputs[0], switch_002_1.inputs[1])
	    #vector_math_004_2.Value -> mix.B
	    restore_curve_segment_length.links.new(vector_math_004_2.outputs[1], mix.inputs[3])
	    #mix.Result -> vector_math_3.Scale
	    restore_curve_segment_length.links.new(mix.outputs[0], vector_math_3.inputs[3])
	    #group_input_001_2.Factor -> mix.Factor
	    restore_curve_segment_length.links.new(group_input_001_2.outputs[2], mix.inputs[0])
	    #group_input_002_2.Factor -> compare_002_3.A
	    restore_curve_segment_length.links.new(group_input_002_2.outputs[2], compare_002_3.inputs[0])
	    #accumulate_field.Leading -> set_position_001_2.Offset
	    restore_curve_segment_length.links.new(accumulate_field.outputs[0], set_position_001_2.inputs[3])
	    #compare_002_3.Result -> boolean_math.Boolean
	    restore_curve_segment_length.links.new(compare_002_3.outputs[0], boolean_math.inputs[0])
	    #group_input_002_2.Selection -> boolean_math.Boolean
	    restore_curve_segment_length.links.new(group_input_002_2.outputs[1], boolean_math.inputs[1])
	    #reroute_005_1.Output -> reroute_004_2.Input
	    restore_curve_segment_length.links.new(reroute_005_1.outputs[0], reroute_004_2.inputs[0])
	    #reroute_012_2.Output -> sample_curve_001_1.Curves
	    restore_curve_segment_length.links.new(reroute_012_2.outputs[0], sample_curve_001_1.inputs[0])
	    #sample_curve_001_1.Position -> vector_math_006_1.Vector
	    restore_curve_segment_length.links.new(sample_curve_001_1.outputs[1], vector_math_006_1.inputs[1])
	    #sample_curve_001_1.Value -> vector_math_006_1.Vector
	    restore_curve_segment_length.links.new(sample_curve_001_1.outputs[0], vector_math_006_1.inputs[0])
	    #reroute_014_2.Output -> set_position_002_1.Geometry
	    restore_curve_segment_length.links.new(reroute_014_2.outputs[0], set_position_002_1.inputs[0])
	    #interpolate_domain_3.Value -> set_position_002_1.Offset
	    restore_curve_segment_length.links.new(interpolate_domain_3.outputs[0], set_position_002_1.inputs[3])
	    #index_2.Index -> sample_curve_001_1.Curve Index
	    restore_curve_segment_length.links.new(index_2.outputs[0], sample_curve_001_1.inputs[4])
	    #reroute_012_2.Output -> reroute_013_2.Input
	    restore_curve_segment_length.links.new(reroute_012_2.outputs[0], reroute_013_2.inputs[0])
	    #group_input_005_2.Selection -> boolean_math_002_1.Boolean
	    restore_curve_segment_length.links.new(group_input_005_2.outputs[1], boolean_math_002_1.inputs[1])
	    #compare_003_1.Result -> boolean_math_002_1.Boolean
	    restore_curve_segment_length.links.new(compare_003_1.outputs[0], boolean_math_002_1.inputs[0])
	    #reroute_011_1.Output -> reroute_005_1.Input
	    restore_curve_segment_length.links.new(reroute_011_1.outputs[0], reroute_005_1.inputs[0])
	    #group_input_003_2.Pin at Parameter -> sample_curve_001_1.Factor
	    restore_curve_segment_length.links.new(group_input_003_2.outputs[4], sample_curve_001_1.inputs[2])
	    #group_input_006_2.Pin at Parameter -> compare_003_1.A
	    restore_curve_segment_length.links.new(group_input_006_2.outputs[4], compare_003_1.inputs[0])
	    #reroute_006_1.Output -> compare_004_1.A
	    restore_curve_segment_length.links.new(reroute_006_1.outputs[0], compare_004_1.inputs[4])
	    #compare_004_1.Result -> switch_002_1.Switch
	    restore_curve_segment_length.links.new(compare_004_1.outputs[0], switch_002_1.inputs[0])
	    #named_attribute_2.Attribute -> switch_003_2.True
	    restore_curve_segment_length.links.new(named_attribute_2.outputs[0], switch_003_2.inputs[2])
	    #named_attribute_2.Exists -> switch_003_2.Switch
	    restore_curve_segment_length.links.new(named_attribute_2.outputs[1], switch_003_2.inputs[0])
	    #position_001_1.Position -> switch_003_2.False
	    restore_curve_segment_length.links.new(position_001_1.outputs[0], switch_003_2.inputs[1])
	    #switch_003_2.Output -> switch_002_1.True
	    restore_curve_segment_length.links.new(switch_003_2.outputs[0], switch_002_1.inputs[2])
	    #reroute_009_1.Output -> sample_curve_001_1.Value
	    restore_curve_segment_length.links.new(reroute_009_1.outputs[0], sample_curve_001_1.inputs[1])
	    #switch_002_1.Output -> reroute_007_1.Input
	    restore_curve_segment_length.links.new(switch_002_1.outputs[0], reroute_007_1.inputs[0])
	    #reroute_007_1.Output -> reroute_001_3.Input
	    restore_curve_segment_length.links.new(reroute_007_1.outputs[0], reroute_001_3.inputs[0])
	    #group_input_5.Reference Position -> reroute_006_1.Input
	    restore_curve_segment_length.links.new(group_input_5.outputs[3], reroute_006_1.inputs[0])
	    #reroute_007_1.Output -> reroute_008_1.Input
	    restore_curve_segment_length.links.new(reroute_007_1.outputs[0], reroute_008_1.inputs[0])
	    #reroute_008_1.Output -> reroute_009_1.Input
	    restore_curve_segment_length.links.new(reroute_008_1.outputs[0], reroute_009_1.inputs[0])
	    #group_input_5.Curves -> reroute_011_1.Input
	    restore_curve_segment_length.links.new(group_input_5.outputs[0], reroute_011_1.inputs[0])
	    #group_001_1.Segment Length -> mix.A
	    restore_curve_segment_length.links.new(group_001_1.outputs[0], mix.inputs[2])
	    #group_001_1.Segment Direction -> vector_math_3.Vector
	    restore_curve_segment_length.links.new(group_001_1.outputs[1], vector_math_3.inputs[0])
	    #vector_math_006_1.Vector -> interpolate_domain_3.Value
	    restore_curve_segment_length.links.new(vector_math_006_1.outputs[0], interpolate_domain_3.inputs[0])
	    #reroute_016_1.Output -> attribute_statistic.Attribute
	    restore_curve_segment_length.links.new(reroute_016_1.outputs[0], attribute_statistic.inputs[2])
	    #attribute_statistic.Max -> compare_005.A
	    restore_curve_segment_length.links.new(attribute_statistic.outputs[4], compare_005.inputs[0])
	    #set_position_002_1.Geometry -> switch_001_6.True
	    restore_curve_segment_length.links.new(set_position_002_1.outputs[0], switch_001_6.inputs[2])
	    #reroute_014_2.Output -> switch_001_6.False
	    restore_curve_segment_length.links.new(reroute_014_2.outputs[0], switch_001_6.inputs[1])
	    #reroute_016_1.Output -> set_position_002_1.Selection
	    restore_curve_segment_length.links.new(reroute_016_1.outputs[0], set_position_002_1.inputs[1])
	    #compare_005.Result -> switch_001_6.Switch
	    restore_curve_segment_length.links.new(compare_005.outputs[0], switch_001_6.inputs[0])
	    #reroute_014_2.Output -> attribute_statistic.Geometry
	    restore_curve_segment_length.links.new(reroute_014_2.outputs[0], attribute_statistic.inputs[0])
	    #boolean_math.Boolean -> set_position_001_2.Selection
	    restore_curve_segment_length.links.new(boolean_math.outputs[0], set_position_001_2.inputs[1])
	    #boolean_math_002_1.Boolean -> reroute_016_1.Input
	    restore_curve_segment_length.links.new(boolean_math_002_1.outputs[0], reroute_016_1.inputs[0])
	    #reroute_013_2.Output -> reroute_014_2.Input
	    restore_curve_segment_length.links.new(reroute_013_2.outputs[0], reroute_014_2.inputs[0])
	    #set_position_001_2.Geometry -> reroute_012_2.Input
	    restore_curve_segment_length.links.new(set_position_001_2.outputs[0], reroute_012_2.inputs[0])
	    #switch_001_6.Output -> group_output_9.Curves
	    restore_curve_segment_length.links.new(switch_001_6.outputs[0], group_output_9.inputs[0])
	    #group_002_3.Root Position -> set_position_001_2.Position
	    restore_curve_segment_length.links.new(group_002_3.outputs[1], set_position_001_2.inputs[2])
	    return restore_curve_segment_length
	
	restore_curve_segment_length = restore_curve_segment_length_node_group()
	
	#initialize frizz_hair_curves node group
	def frizz_hair_curves_node_group():
	    frizz_hair_curves = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Frizz Hair Curves")
	
	    frizz_hair_curves.color_tag = 'NONE'
	    frizz_hair_curves.description = "Deforms hair curves using a random vector per point to frizz them"
	    frizz_hair_curves.default_group_node_width = 140
	    
	
	    frizz_hair_curves.is_modifier = True
	
	    #frizz_hair_curves interface
	    #Socket Geometry
	    geometry_socket_8 = frizz_hair_curves.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_8.attribute_domain = 'POINT'
	
	    #Socket Offset Vector
	    offset_vector_socket = frizz_hair_curves.interface.new_socket(name = "Offset Vector", in_out='OUTPUT', socket_type = 'NodeSocketVector')
	    offset_vector_socket.default_value = (0.0, 0.0, 0.0)
	    offset_vector_socket.min_value = -3.4028234663852886e+38
	    offset_vector_socket.max_value = 3.4028234663852886e+38
	    offset_vector_socket.subtype = 'NONE'
	    offset_vector_socket.attribute_domain = 'POINT'
	    offset_vector_socket.description = "Vector by which each point was offset during deformation"
	
	    #Socket Geometry
	    geometry_socket_9 = frizz_hair_curves.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_9.attribute_domain = 'POINT'
	    geometry_socket_9.description = "Input Geometry (May include other than curves)"
	
	    #Socket Cumulative Offset
	    cumulative_offset_socket = frizz_hair_curves.interface.new_socket(name = "Cumulative Offset", in_out='INPUT', socket_type = 'NodeSocketBool')
	    cumulative_offset_socket.default_value = True
	    cumulative_offset_socket.attribute_domain = 'POINT'
	    cumulative_offset_socket.description = "Apply offset cumulatively (previous points affect points after)"
	
	    #Socket Factor
	    factor_socket_1 = frizz_hair_curves.interface.new_socket(name = "Factor", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    factor_socket_1.default_value = 1.0
	    factor_socket_1.min_value = 0.0
	    factor_socket_1.max_value = 1.0
	    factor_socket_1.subtype = 'FACTOR'
	    factor_socket_1.attribute_domain = 'POINT'
	    factor_socket_1.description = "Factor to blend overall effect"
	
	    #Socket Distance
	    distance_socket = frizz_hair_curves.interface.new_socket(name = "Distance", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    distance_socket.default_value = 0.009999999776482582
	    distance_socket.min_value = 0.0
	    distance_socket.max_value = 3.4028234663852886e+38
	    distance_socket.subtype = 'DISTANCE'
	    distance_socket.attribute_domain = 'POINT'
	    distance_socket.description = "Overall distance factor for the deformation"
	
	    #Socket Shape
	    shape_socket_1 = frizz_hair_curves.interface.new_socket(name = "Shape", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    shape_socket_1.default_value = 0.5
	    shape_socket_1.min_value = -1.0
	    shape_socket_1.max_value = 1.0
	    shape_socket_1.subtype = 'NONE'
	    shape_socket_1.attribute_domain = 'POINT'
	    shape_socket_1.description = "Shape of the influence along curves (0=constant, 0.5=linear)"
	
	    #Socket Seed
	    seed_socket_1 = frizz_hair_curves.interface.new_socket(name = "Seed", in_out='INPUT', socket_type = 'NodeSocketInt')
	    seed_socket_1.default_value = 0
	    seed_socket_1.min_value = -10000
	    seed_socket_1.max_value = 10000
	    seed_socket_1.subtype = 'NONE'
	    seed_socket_1.attribute_domain = 'POINT'
	    seed_socket_1.description = "Random Seed for the operation"
	
	    #Socket Preserve Length
	    preserve_length_socket = frizz_hair_curves.interface.new_socket(name = "Preserve Length", in_out='INPUT', socket_type = 'NodeSocketBool')
	    preserve_length_socket.default_value = False
	    preserve_length_socket.attribute_domain = 'POINT'
	    preserve_length_socket.description = "Preserve each curve's length during deformation"
	
	
	    #initialize frizz_hair_curves nodes
	    #node Frame
	    frame_4 = frizz_hair_curves.nodes.new("NodeFrame")
	    frame_4.label = "Optimization"
	    frame_4.name = "Frame"
	    frame_4.label_size = 20
	    frame_4.shrink = True
	
	    #node Frame.004
	    frame_004_2 = frizz_hair_curves.nodes.new("NodeFrame")
	    frame_004_2.label = "Offset Vector per Point"
	    frame_004_2.name = "Frame.004"
	    frame_004_2.label_size = 20
	    frame_004_2.shrink = True
	
	    #node Frame.001
	    frame_001_3 = frizz_hair_curves.nodes.new("NodeFrame")
	    frame_001_3.label = "Optimization"
	    frame_001_3.name = "Frame.001"
	    frame_001_3.label_size = 20
	    frame_001_3.shrink = True
	
	    #node Frame.002
	    frame_002_3 = frizz_hair_curves.nodes.new("NodeFrame")
	    frame_002_3.label = "Curve Tangent Space"
	    frame_002_3.name = "Frame.002"
	    frame_002_3.label_size = 20
	    frame_002_3.shrink = True
	
	    #node Frame.003
	    frame_003_2 = frizz_hair_curves.nodes.new("NodeFrame")
	    frame_003_2.label = "Random Vector per Point"
	    frame_003_2.name = "Frame.003"
	    frame_003_2.label_size = 20
	    frame_003_2.shrink = True
	
	    #node Frame.006
	    frame_006_1 = frizz_hair_curves.nodes.new("NodeFrame")
	    frame_006_1.label = "Length Preservation"
	    frame_006_1.name = "Frame.006"
	    frame_006_1.label_size = 20
	    frame_006_1.shrink = True
	
	    #node Frame.005
	    frame_005_1 = frizz_hair_curves.nodes.new("NodeFrame")
	    frame_005_1.label = "Optimization"
	    frame_005_1.name = "Frame.005"
	    frame_005_1.label_size = 20
	    frame_005_1.shrink = True
	
	    #node Math.001
	    math_001_1 = frizz_hair_curves.nodes.new("ShaderNodeMath")
	    math_001_1.name = "Math.001"
	    math_001_1.operation = 'MULTIPLY'
	    math_001_1.use_clamp = False
	
	    #node Group Input.001
	    group_input_001_3 = frizz_hair_curves.nodes.new("NodeGroupInput")
	    group_input_001_3.name = "Group Input.001"
	    group_input_001_3.outputs[0].hide = True
	    group_input_001_3.outputs[1].hide = True
	    group_input_001_3.outputs[3].hide = True
	    group_input_001_3.outputs[4].hide = True
	    group_input_001_3.outputs[5].hide = True
	    group_input_001_3.outputs[6].hide = True
	    group_input_001_3.outputs[7].hide = True
	
	    #node Group Input.006
	    group_input_006_3 = frizz_hair_curves.nodes.new("NodeGroupInput")
	    group_input_006_3.name = "Group Input.006"
	    group_input_006_3.outputs[0].hide = True
	    group_input_006_3.outputs[1].hide = True
	    group_input_006_3.outputs[2].hide = True
	    group_input_006_3.outputs[4].hide = True
	    group_input_006_3.outputs[5].hide = True
	    group_input_006_3.outputs[6].hide = True
	    group_input_006_3.outputs[7].hide = True
	
	    #node Capture Attribute.001
	    capture_attribute_001_1 = frizz_hair_curves.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_001_1.name = "Capture Attribute.001"
	    capture_attribute_001_1.active_index = 0
	    capture_attribute_001_1.capture_items.clear()
	    capture_attribute_001_1.capture_items.new('FLOAT', "Value")
	    capture_attribute_001_1.capture_items["Value"].data_type = 'FLOAT_VECTOR'
	    capture_attribute_001_1.domain = 'POINT'
	
	    #node Group Output
	    group_output_10 = frizz_hair_curves.nodes.new("NodeGroupOutput")
	    group_output_10.name = "Group Output"
	    group_output_10.is_active_output = True
	
	    #node Reroute.007
	    reroute_007_2 = frizz_hair_curves.nodes.new("NodeReroute")
	    reroute_007_2.name = "Reroute.007"
	    reroute_007_2.socket_idname = "NodeSocketGeometry"
	    #node Reroute.009
	    reroute_009_2 = frizz_hair_curves.nodes.new("NodeReroute")
	    reroute_009_2.name = "Reroute.009"
	    reroute_009_2.socket_idname = "NodeSocketGeometry"
	    #node Reroute.006
	    reroute_006_2 = frizz_hair_curves.nodes.new("NodeReroute")
	    reroute_006_2.name = "Reroute.006"
	    reroute_006_2.socket_idname = "NodeSocketGeometry"
	    #node Reroute.008
	    reroute_008_2 = frizz_hair_curves.nodes.new("NodeReroute")
	    reroute_008_2.name = "Reroute.008"
	    reroute_008_2.socket_idname = "NodeSocketGeometry"
	    #node Join Geometry
	    join_geometry_1 = frizz_hair_curves.nodes.new("GeometryNodeJoinGeometry")
	    join_geometry_1.name = "Join Geometry"
	
	    #node Set Spline Resolution.001
	    set_spline_resolution_001 = frizz_hair_curves.nodes.new("GeometryNodeSetSplineResolution")
	    set_spline_resolution_001.name = "Set Spline Resolution.001"
	    #Selection
	    set_spline_resolution_001.inputs[1].default_value = True
	
	    #node Set Spline Type.001
	    set_spline_type_001 = frizz_hair_curves.nodes.new("GeometryNodeCurveSplineType")
	    set_spline_type_001.name = "Set Spline Type.001"
	    set_spline_type_001.spline_type = 'CATMULL_ROM'
	    #Selection
	    set_spline_type_001.inputs[1].default_value = True
	
	    #node Reroute.002
	    reroute_002_2 = frizz_hair_curves.nodes.new("NodeReroute")
	    reroute_002_2.name = "Reroute.002"
	    reroute_002_2.socket_idname = "NodeSocketInt"
	    #node Switch.004
	    switch_004_1 = frizz_hair_curves.nodes.new("GeometryNodeSwitch")
	    switch_004_1.name = "Switch.004"
	    switch_004_1.input_type = 'INT'
	    #True
	    switch_004_1.inputs[2].default_value = 12
	
	    #node Compare.003
	    compare_003_2 = frizz_hair_curves.nodes.new("FunctionNodeCompare")
	    compare_003_2.name = "Compare.003"
	    compare_003_2.data_type = 'INT'
	    compare_003_2.mode = 'ELEMENT'
	    compare_003_2.operation = 'EQUAL'
	    #B_INT
	    compare_003_2.inputs[3].default_value = 0
	
	    #node Reroute.015
	    reroute_015_3 = frizz_hair_curves.nodes.new("NodeReroute")
	    reroute_015_3.name = "Reroute.015"
	    reroute_015_3.socket_idname = "NodeSocketVector"
	    #node Position.002
	    position_002_3 = frizz_hair_curves.nodes.new("GeometryNodeInputPosition")
	    position_002_3.name = "Position.002"
	
	    #node Vector Math.007
	    vector_math_007_2 = frizz_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_007_2.name = "Vector Math.007"
	    vector_math_007_2.operation = 'SUBTRACT'
	
	    #node Curve of Point
	    curve_of_point_1 = frizz_hair_curves.nodes.new("GeometryNodeCurveOfPoint")
	    curve_of_point_1.name = "Curve of Point"
	    curve_of_point_1.inputs[0].hide = True
	    curve_of_point_1.outputs[1].hide = True
	    #Point Index
	    curve_of_point_1.inputs[0].default_value = 0
	
	    #node Field at Index
	    field_at_index = frizz_hair_curves.nodes.new("GeometryNodeFieldAtIndex")
	    field_at_index.name = "Field at Index"
	    field_at_index.data_type = 'FLOAT_VECTOR'
	    field_at_index.domain = 'POINT'
	
	    #node Spline Parameter
	    spline_parameter_1 = frizz_hair_curves.nodes.new("GeometryNodeSplineParameter")
	    spline_parameter_1.name = "Spline Parameter"
	    spline_parameter_1.outputs[1].hide = True
	    spline_parameter_1.outputs[2].hide = True
	
	    #node Group
	    group_2 = frizz_hair_curves.nodes.new("GeometryNodeGroup")
	    group_2.name = "Group"
	    group_2.node_tree = shape_range
	    #Socket_2
	    group_2.inputs[1].default_value = 0.0
	    #Socket_3
	    group_2.inputs[2].default_value = 1.0
	    #Socket_5
	    group_2.inputs[4].default_value = 2.0
	
	    #node Group Input.007
	    group_input_007_2 = frizz_hair_curves.nodes.new("NodeGroupInput")
	    group_input_007_2.name = "Group Input.007"
	    group_input_007_2.outputs[0].hide = True
	    group_input_007_2.outputs[1].hide = True
	    group_input_007_2.outputs[2].hide = True
	    group_input_007_2.outputs[3].hide = True
	    group_input_007_2.outputs[5].hide = True
	    group_input_007_2.outputs[6].hide = True
	    group_input_007_2.outputs[7].hide = True
	
	    #node Vector Math.016
	    vector_math_016 = frizz_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_016.name = "Vector Math.016"
	    vector_math_016.operation = 'SUBTRACT'
	
	    #node Vector Math.014
	    vector_math_014_1 = frizz_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_014_1.name = "Vector Math.014"
	    vector_math_014_1.operation = 'ADD'
	
	    #node Vector Math.013
	    vector_math_013_1 = frizz_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_013_1.name = "Vector Math.013"
	    vector_math_013_1.operation = 'SUBTRACT'
	
	    #node Vector Math.015
	    vector_math_015 = frizz_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_015.name = "Vector Math.015"
	    vector_math_015.operation = 'SCALE'
	    #Scale
	    vector_math_015.inputs[3].default_value = 0.5
	
	    #node Group Input.005
	    group_input_005_3 = frizz_hair_curves.nodes.new("NodeGroupInput")
	    group_input_005_3.name = "Group Input.005"
	    group_input_005_3.outputs[0].hide = True
	    group_input_005_3.outputs[2].hide = True
	    group_input_005_3.outputs[3].hide = True
	    group_input_005_3.outputs[4].hide = True
	    group_input_005_3.outputs[5].hide = True
	    group_input_005_3.outputs[6].hide = True
	    group_input_005_3.outputs[7].hide = True
	
	    #node Switch
	    switch_4 = frizz_hair_curves.nodes.new("GeometryNodeSwitch")
	    switch_4.name = "Switch"
	    switch_4.input_type = 'VECTOR'
	
	    #node Vector Math.012
	    vector_math_012_1 = frizz_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_012_1.name = "Vector Math.012"
	    vector_math_012_1.operation = 'SCALE'
	
	    #node Vector Math.017
	    vector_math_017 = frizz_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_017.name = "Vector Math.017"
	    vector_math_017.operation = 'SCALE'
	
	    #node Position.001
	    position_001_2 = frizz_hair_curves.nodes.new("GeometryNodeInputPosition")
	    position_001_2.name = "Position.001"
	
	    #node Capture Attribute.003
	    capture_attribute_003_1 = frizz_hair_curves.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_003_1.name = "Capture Attribute.003"
	    capture_attribute_003_1.active_index = 0
	    capture_attribute_003_1.capture_items.clear()
	    capture_attribute_003_1.capture_items.new('FLOAT', "Value")
	    capture_attribute_003_1.capture_items["Value"].data_type = 'FLOAT_VECTOR'
	    capture_attribute_003_1.domain = 'POINT'
	
	    #node Group Input
	    group_input_6 = frizz_hair_curves.nodes.new("NodeGroupInput")
	    group_input_6.name = "Group Input"
	    group_input_6.outputs[1].hide = True
	    group_input_6.outputs[2].hide = True
	    group_input_6.outputs[3].hide = True
	    group_input_6.outputs[4].hide = True
	    group_input_6.outputs[5].hide = True
	    group_input_6.outputs[6].hide = True
	    group_input_6.outputs[7].hide = True
	
	    #node Reroute.012
	    reroute_012_3 = frizz_hair_curves.nodes.new("NodeReroute")
	    reroute_012_3.name = "Reroute.012"
	    reroute_012_3.socket_idname = "NodeSocketGeometry"
	    #node Reroute.010
	    reroute_010_1 = frizz_hair_curves.nodes.new("NodeReroute")
	    reroute_010_1.name = "Reroute.010"
	    reroute_010_1.socket_idname = "NodeSocketGeometry"
	    #node Reroute.011
	    reroute_011_2 = frizz_hair_curves.nodes.new("NodeReroute")
	    reroute_011_2.name = "Reroute.011"
	    reroute_011_2.socket_idname = "NodeSocketGeometry"
	    #node Reroute.013
	    reroute_013_3 = frizz_hair_curves.nodes.new("NodeReroute")
	    reroute_013_3.name = "Reroute.013"
	    reroute_013_3.socket_idname = "NodeSocketGeometry"
	    #node Separate Components
	    separate_components_1 = frizz_hair_curves.nodes.new("GeometryNodeSeparateComponents")
	    separate_components_1.name = "Separate Components"
	    separate_components_1.hide = True
	
	    #node Set Spline Type
	    set_spline_type = frizz_hair_curves.nodes.new("GeometryNodeCurveSplineType")
	    set_spline_type.name = "Set Spline Type"
	    set_spline_type.spline_type = 'POLY'
	    #Selection
	    set_spline_type.inputs[1].default_value = True
	
	    #node Spline Resolution
	    spline_resolution = frizz_hair_curves.nodes.new("GeometryNodeInputSplineResolution")
	    spline_resolution.name = "Spline Resolution"
	
	    #node Capture Attribute.002
	    capture_attribute_002_1 = frizz_hair_curves.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_002_1.name = "Capture Attribute.002"
	    capture_attribute_002_1.active_index = 0
	    capture_attribute_002_1.capture_items.clear()
	    capture_attribute_002_1.capture_items.new('FLOAT', "Value")
	    capture_attribute_002_1.capture_items["Value"].data_type = 'INT'
	    capture_attribute_002_1.domain = 'CURVE'
	
	    #node Reroute
	    reroute_6 = frizz_hair_curves.nodes.new("NodeReroute")
	    reroute_6.name = "Reroute"
	    reroute_6.socket_idname = "NodeSocketBool"
	    #node Set Position
	    set_position_1 = frizz_hair_curves.nodes.new("GeometryNodeSetPosition")
	    set_position_1.name = "Set Position"
	    set_position_1.inputs[2].hide = True
	    #Position
	    set_position_1.inputs[2].default_value = (0.0, 0.0, 0.0)
	
	    #node Group Input.002
	    group_input_002_3 = frizz_hair_curves.nodes.new("NodeGroupInput")
	    group_input_002_3.name = "Group Input.002"
	    group_input_002_3.outputs[0].hide = True
	    group_input_002_3.outputs[1].hide = True
	    group_input_002_3.outputs[3].hide = True
	    group_input_002_3.outputs[4].hide = True
	    group_input_002_3.outputs[5].hide = True
	    group_input_002_3.outputs[6].hide = True
	    group_input_002_3.outputs[7].hide = True
	
	    #node Compare
	    compare_3 = frizz_hair_curves.nodes.new("FunctionNodeCompare")
	    compare_3.name = "Compare"
	    compare_3.data_type = 'FLOAT'
	    compare_3.mode = 'ELEMENT'
	    compare_3.operation = 'NOT_EQUAL'
	    #B
	    compare_3.inputs[1].default_value = 0.0
	    #Epsilon
	    compare_3.inputs[12].default_value = 0.0
	
	    #node Reroute.003
	    reroute_003_2 = frizz_hair_curves.nodes.new("NodeReroute")
	    reroute_003_2.name = "Reroute.003"
	    reroute_003_2.socket_idname = "NodeSocketVector"
	    #node Accumulate Field
	    accumulate_field_1 = frizz_hair_curves.nodes.new("GeometryNodeAccumulateField")
	    accumulate_field_1.name = "Accumulate Field"
	    accumulate_field_1.data_type = 'FLOAT_VECTOR'
	    accumulate_field_1.domain = 'POINT'
	    accumulate_field_1.outputs[2].hide = True
	
	    #node Separate XYZ
	    separate_xyz_1 = frizz_hair_curves.nodes.new("ShaderNodeSeparateXYZ")
	    separate_xyz_1.name = "Separate XYZ"
	
	    #node Curve Tangent
	    curve_tangent_3 = frizz_hair_curves.nodes.new("GeometryNodeInputTangent")
	    curve_tangent_3.name = "Curve Tangent"
	
	    #node Normal
	    normal_2 = frizz_hair_curves.nodes.new("GeometryNodeInputNormal")
	    normal_2.name = "Normal"
	    normal_2.legacy_corner_normals = True
	
	    #node Vector Math.003
	    vector_math_003_2 = frizz_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_003_2.name = "Vector Math.003"
	    vector_math_003_2.hide = True
	    vector_math_003_2.operation = 'SCALE'
	
	    #node Vector Math.002
	    vector_math_002_2 = frizz_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_002_2.name = "Vector Math.002"
	    vector_math_002_2.hide = True
	    vector_math_002_2.operation = 'SCALE'
	
	    #node Vector Math.004
	    vector_math_004_3 = frizz_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_004_3.name = "Vector Math.004"
	    vector_math_004_3.hide = True
	    vector_math_004_3.operation = 'SCALE'
	
	    #node Vector Math.010
	    vector_math_010_1 = frizz_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_010_1.name = "Vector Math.010"
	    vector_math_010_1.hide = True
	    vector_math_010_1.operation = 'ADD'
	
	    #node Vector Math.011
	    vector_math_011_1 = frizz_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_011_1.name = "Vector Math.011"
	    vector_math_011_1.hide = True
	    vector_math_011_1.operation = 'ADD'
	
	    #node Vector Math
	    vector_math_4 = frizz_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_4.name = "Vector Math"
	    vector_math_4.hide = True
	    vector_math_4.operation = 'CROSS_PRODUCT'
	
	    #node Random Value
	    random_value_1 = frizz_hair_curves.nodes.new("FunctionNodeRandomValue")
	    random_value_1.name = "Random Value"
	    random_value_1.data_type = 'FLOAT_VECTOR'
	    #Min
	    random_value_1.inputs[0].default_value = (-1.0, -1.0, -1.0)
	    #Max
	    random_value_1.inputs[1].default_value = (1.0, 1.0, 1.0)
	    #ID
	    random_value_1.inputs[7].default_value = 0
	
	    #node Switch.001
	    switch_001_7 = frizz_hair_curves.nodes.new("GeometryNodeSwitch")
	    switch_001_7.name = "Switch.001"
	    switch_001_7.input_type = 'GEOMETRY'
	
	    #node Reroute.004
	    reroute_004_3 = frizz_hair_curves.nodes.new("NodeReroute")
	    reroute_004_3.name = "Reroute.004"
	    reroute_004_3.socket_idname = "NodeSocketGeometry"
	    #node Group.005
	    group_005_1 = frizz_hair_curves.nodes.new("GeometryNodeGroup")
	    group_005_1.name = "Group.005"
	    group_005_1.node_tree = restore_curve_segment_length
	    #Socket_5
	    group_005_1.inputs[4].default_value = 0.0
	
	    #node Sample Index
	    sample_index_1 = frizz_hair_curves.nodes.new("GeometryNodeSampleIndex")
	    sample_index_1.name = "Sample Index"
	    sample_index_1.hide = True
	    sample_index_1.clamp = False
	    sample_index_1.data_type = 'INT'
	    sample_index_1.domain = 'POINT'
	    #Index
	    sample_index_1.inputs[2].default_value = 0
	
	    #node Accumulate Field.001
	    accumulate_field_001 = frizz_hair_curves.nodes.new("GeometryNodeAccumulateField")
	    accumulate_field_001.name = "Accumulate Field.001"
	    accumulate_field_001.hide = True
	    accumulate_field_001.data_type = 'INT'
	    accumulate_field_001.domain = 'POINT'
	    #Group Index
	    accumulate_field_001.inputs[1].default_value = 0
	
	    #node Compare.002
	    compare_002_4 = frizz_hair_curves.nodes.new("FunctionNodeCompare")
	    compare_002_4.name = "Compare.002"
	    compare_002_4.data_type = 'FLOAT'
	    compare_002_4.mode = 'ELEMENT'
	    compare_002_4.operation = 'GREATER_THAN'
	    #B
	    compare_002_4.inputs[1].default_value = 0.0
	
	    #node Boolean Math
	    boolean_math_1 = frizz_hair_curves.nodes.new("FunctionNodeBooleanMath")
	    boolean_math_1.name = "Boolean Math"
	    boolean_math_1.hide = True
	    boolean_math_1.operation = 'AND'
	
	    #node Group Input.008
	    group_input_008_1 = frizz_hair_curves.nodes.new("NodeGroupInput")
	    group_input_008_1.name = "Group Input.008"
	    group_input_008_1.outputs[0].hide = True
	    group_input_008_1.outputs[1].hide = True
	    group_input_008_1.outputs[2].hide = True
	    group_input_008_1.outputs[3].hide = True
	    group_input_008_1.outputs[4].hide = True
	    group_input_008_1.outputs[5].hide = True
	    group_input_008_1.outputs[7].hide = True
	
	    #node Group Input.003
	    group_input_003_3 = frizz_hair_curves.nodes.new("NodeGroupInput")
	    group_input_003_3.name = "Group Input.003"
	    group_input_003_3.outputs[0].hide = True
	    group_input_003_3.outputs[1].hide = True
	    group_input_003_3.outputs[2].hide = True
	    group_input_003_3.outputs[3].hide = True
	    group_input_003_3.outputs[4].hide = True
	    group_input_003_3.outputs[6].hide = True
	    group_input_003_3.outputs[7].hide = True
	
	    #node Random Value.004
	    random_value_004_1 = frizz_hair_curves.nodes.new("FunctionNodeRandomValue")
	    random_value_004_1.label = "Hash Seed"
	    random_value_004_1.name = "Random Value.004"
	    random_value_004_1.data_type = 'INT'
	    #Min_002
	    random_value_004_1.inputs[4].default_value = -1073741823
	    #Max_002
	    random_value_004_1.inputs[5].default_value = 1073741823
	    #Seed
	    random_value_004_1.inputs[8].default_value = 64785
	
	    #node Group.001
	    group_001_2 = frizz_hair_curves.nodes.new("GeometryNodeGroup")
	    group_001_2.name = "Group.001"
	    group_001_2.node_tree = curve_root
	    group_001_2.outputs[0].hide = True
	    group_001_2.outputs[1].hide = True
	    group_001_2.outputs[2].hide = True
	
	
	
	
	    #Set parents
	    frame_005_1.parent = frame_006_1
	    set_spline_resolution_001.parent = frame_4
	    set_spline_type_001.parent = frame_4
	    reroute_002_2.parent = frame_4
	    switch_004_1.parent = frame_4
	    compare_003_2.parent = frame_4
	    curve_of_point_1.parent = frame_004_2
	    field_at_index.parent = frame_004_2
	    spline_parameter_1.parent = frame_004_2
	    group_2.parent = frame_004_2
	    group_input_007_2.parent = frame_004_2
	    vector_math_016.parent = frame_004_2
	    vector_math_014_1.parent = frame_004_2
	    vector_math_013_1.parent = frame_004_2
	    vector_math_015.parent = frame_004_2
	    group_input_005_3.parent = frame_004_2
	    switch_4.parent = frame_004_2
	    vector_math_012_1.parent = frame_004_2
	    vector_math_017.parent = frame_004_2
	    set_spline_type.parent = frame_001_3
	    spline_resolution.parent = frame_001_3
	    capture_attribute_002_1.parent = frame_001_3
	    reroute_003_2.parent = frame_004_2
	    accumulate_field_1.parent = frame_004_2
	    separate_xyz_1.parent = frame_002_3
	    curve_tangent_3.parent = frame_002_3
	    normal_2.parent = frame_002_3
	    vector_math_003_2.parent = frame_002_3
	    vector_math_002_2.parent = frame_002_3
	    vector_math_004_3.parent = frame_002_3
	    vector_math_010_1.parent = frame_002_3
	    vector_math_011_1.parent = frame_002_3
	    vector_math_4.parent = frame_002_3
	    random_value_1.parent = frame_003_2
	    switch_001_7.parent = frame_006_1
	    reroute_004_3.parent = frame_006_1
	    group_005_1.parent = frame_006_1
	    sample_index_1.parent = frame_005_1
	    accumulate_field_001.parent = frame_005_1
	    compare_002_4.parent = frame_005_1
	    boolean_math_1.parent = frame_006_1
	    group_input_008_1.parent = frame_006_1
	    group_input_003_3.parent = frame_003_2
	    random_value_004_1.parent = frame_003_2
	    group_001_2.parent = frame_004_2
	
	    #Set locations
	    frame_4.location = (-1246.265380859375, -71.0)
	    frame_004_2.location = (-4295.0, -652.0)
	    frame_001_3.location = (-3477.0, -46.0)
	    frame_002_3.location = (-4928.0, -623.0)
	    frame_003_2.location = (-5541.0, -623.0)
	    frame_006_1.location = (-2282.0, -9.0)
	    frame_005_1.location = (367.0, -40.0)
	    math_001_1.location = (-4486.1142578125, -1035.02294921875)
	    group_input_001_3.location = (-4666.9521484375, -1075.2091064453125)
	    group_input_006_3.location = (-4666.9521484375, -1155.5811767578125)
	    capture_attribute_001_1.location = (-523.780517578125, -124.394775390625)
	    group_output_10.location = (75.0, 50.0)
	    reroute_007_2.location = (-266.58154296875, 170.55810546875)
	    reroute_009_2.location = (-266.58154296875, 150.465087890625)
	    reroute_006_2.location = (-266.58154296875, 210.7442626953125)
	    reroute_008_2.location = (-266.58154296875, 190.651123046875)
	    join_geometry_1.location = (-125.930419921875, 50.0)
	    set_spline_resolution_001.location = (477.3583984375, -100.023193359375)
	    set_spline_type_001.location = (236.2421875, -39.74412536621094)
	    reroute_002_2.location = (35.0, -267.40777587890625)
	    switch_004_1.location = (256.0234375, -227.22171020507812)
	    compare_003_2.location = (75.186279296875, -227.22171020507812)
	    reroute_015_3.location = (-1914.2093505859375, -572.8834228515625)
	    position_002_3.location = (-969.83740234375, -512.6043701171875)
	    vector_math_007_2.location = (-789.000244140625, -492.5113525390625)
	    curve_of_point_1.location = (230.7509765625, -351.99322509765625)
	    field_at_index.location = (411.58837890625, -412.2723388671875)
	    spline_parameter_1.location = (1011.646484375, -321.7235107421875)
	    group_2.location = (1192.48388671875, -261.4444580078125)
	    group_input_007_2.location = (1011.646484375, -382.0025634765625)
	    vector_math_016.location = (629.879150390625, -40.42120361328125)
	    vector_math_014_1.location = (629.879150390625, -160.97930908203125)
	    vector_math_013_1.location = (629.879150390625, -281.5374755859375)
	    vector_math_015.location = (810.71630859375, -221.2584228515625)
	    group_input_005_3.location = (810.71630859375, -120.79327392578125)
	    switch_4.location = (1011.646484375, -120.79327392578125)
	    vector_math_012_1.location = (29.82080078125, -251.52813720703125)
	    vector_math_017.location = (1380.00390625, -144.06353759765625)
	    position_001_2.location = (-4003.882568359375, -211.2093505859375)
	    capture_attribute_003_1.location = (-3823.046630859375, -110.744140625)
	    group_input_6.location = (-4445.9287109375, 9.81396484375)
	    reroute_012_3.location = (-3863.232666015625, 190.651123046875)
	    reroute_010_1.location = (-3863.232666015625, 210.7442626953125)
	    reroute_011_2.location = (-3863.232666015625, 170.55810546875)
	    reroute_013_3.location = (-3863.232666015625, 150.465087890625)
	    separate_components_1.location = (-4224.9052734375, -50.465087890625)
	    set_spline_type.location = (468.02783203125, -40.377174377441406)
	    spline_resolution.location = (29.975341796875, -190.07485961914062)
	    capture_attribute_002_1.location = (230.905517578125, -49.42369842529297)
	    reroute_6.location = (-2577.279052734375, -512.6043701171875)
	    set_position_1.location = (-2496.906982421875, -351.8601989746094)
	    group_input_002_3.location = (-2979.1396484375, -492.5113525390625)
	    compare_3.location = (-2778.20947265625, -472.4183349609375)
	    reroute_003_2.location = (352.711669921875, -173.0606689453125)
	    accumulate_field_1.location = (411.58837890625, -151.0631103515625)
	    separate_xyz_1.location = (30.22705078125, -40.1751708984375)
	    curve_tangent_3.location = (30.22705078125, -180.82635498046875)
	    normal_2.location = (30.22705078125, -281.29150390625)
	    vector_math_003_2.location = (231.1572265625, -180.82635498046875)
	    vector_math_002_2.location = (231.1572265625, -140.64031982421875)
	    vector_math_004_3.location = (231.1572265625, -221.01239013671875)
	    vector_math_010_1.location = (391.9013671875, -160.73333740234375)
	    vector_math_011_1.location = (391.9013671875, -200.91937255859375)
	    vector_math_4.location = (30.22705078125, -241.10546875)
	    random_value_1.location = (401.955078125, -40.1171875)
	    switch_001_7.location = (793.6678466796875, -98.78160095214844)
	    reroute_004_3.location = (210.97021484375, -219.33973693847656)
	    group_005_1.location = (431.993408203125, -259.52581787109375)
	    sample_index_1.location = (29.9866943359375, -60.56507873535156)
	    accumulate_field_001.location = (29.9866943359375, -100.75112915039062)
	    compare_002_4.location = (210.8238525390625, -40.47205352783203)
	    boolean_math_1.location = (231.063232421875, -339.89788818359375)
	    group_input_008_1.location = (30.1328125, -380.08392333984375)
	    group_input_003_3.location = (30.140625, -244.14654541015625)
	    random_value_004_1.location = (210.97802734375, -163.7744140625)
	    group_001_2.location = (229.78955078125, -433.58740234375)
	
	    #Set dimensions
	    frame_4.width, frame_4.height = 647.265380859375, 405.0
	    frame_004_2.width, frame_004_2.height = 1550.0, 588.0
	    frame_001_3.width, frame_001_3.height = 638.0, 270.0
	    frame_002_3.width, frame_002_3.height = 562.0, 361.0
	    frame_003_2.width, frame_003_2.height = 572.0, 361.0
	    frame_006_1.width, frame_006_1.height = 964.0, 474.0
	    frame_005_1.width, frame_005_1.height = 381.0, 218.0
	    math_001_1.width, math_001_1.height = 140.0, 100.0
	    group_input_001_3.width, group_input_001_3.height = 140.0, 100.0
	    group_input_006_3.width, group_input_006_3.height = 140.0, 100.0
	    capture_attribute_001_1.width, capture_attribute_001_1.height = 140.0, 100.0
	    group_output_10.width, group_output_10.height = 140.0, 100.0
	    reroute_007_2.width, reroute_007_2.height = 10.0, 100.0
	    reroute_009_2.width, reroute_009_2.height = 10.0, 100.0
	    reroute_006_2.width, reroute_006_2.height = 10.0, 100.0
	    reroute_008_2.width, reroute_008_2.height = 10.0, 100.0
	    join_geometry_1.width, join_geometry_1.height = 140.0, 100.0
	    set_spline_resolution_001.width, set_spline_resolution_001.height = 140.0, 100.0
	    set_spline_type_001.width, set_spline_type_001.height = 140.0, 100.0
	    reroute_002_2.width, reroute_002_2.height = 10.0, 100.0
	    switch_004_1.width, switch_004_1.height = 140.0, 100.0
	    compare_003_2.width, compare_003_2.height = 140.0, 100.0
	    reroute_015_3.width, reroute_015_3.height = 10.0, 100.0
	    position_002_3.width, position_002_3.height = 140.0, 100.0
	    vector_math_007_2.width, vector_math_007_2.height = 140.0, 100.0
	    curve_of_point_1.width, curve_of_point_1.height = 140.0, 100.0
	    field_at_index.width, field_at_index.height = 140.0, 100.0
	    spline_parameter_1.width, spline_parameter_1.height = 140.0, 100.0
	    group_2.width, group_2.height = 140.0, 100.0
	    group_input_007_2.width, group_input_007_2.height = 140.0, 100.0
	    vector_math_016.width, vector_math_016.height = 140.0, 100.0
	    vector_math_014_1.width, vector_math_014_1.height = 140.0, 100.0
	    vector_math_013_1.width, vector_math_013_1.height = 140.0, 100.0
	    vector_math_015.width, vector_math_015.height = 140.0, 100.0
	    group_input_005_3.width, group_input_005_3.height = 140.0, 100.0
	    switch_4.width, switch_4.height = 140.0, 100.0
	    vector_math_012_1.width, vector_math_012_1.height = 140.0, 100.0
	    vector_math_017.width, vector_math_017.height = 140.0, 100.0
	    position_001_2.width, position_001_2.height = 140.0, 100.0
	    capture_attribute_003_1.width, capture_attribute_003_1.height = 140.0, 100.0
	    group_input_6.width, group_input_6.height = 140.0, 100.0
	    reroute_012_3.width, reroute_012_3.height = 10.0, 100.0
	    reroute_010_1.width, reroute_010_1.height = 10.0, 100.0
	    reroute_011_2.width, reroute_011_2.height = 10.0, 100.0
	    reroute_013_3.width, reroute_013_3.height = 10.0, 100.0
	    separate_components_1.width, separate_components_1.height = 140.0, 100.0
	    set_spline_type.width, set_spline_type.height = 140.0, 100.0
	    spline_resolution.width, spline_resolution.height = 140.0, 100.0
	    capture_attribute_002_1.width, capture_attribute_002_1.height = 140.0, 100.0
	    reroute_6.width, reroute_6.height = 10.0, 100.0
	    set_position_1.width, set_position_1.height = 140.0, 100.0
	    group_input_002_3.width, group_input_002_3.height = 140.0, 100.0
	    compare_3.width, compare_3.height = 140.0, 100.0
	    reroute_003_2.width, reroute_003_2.height = 10.0, 100.0
	    accumulate_field_1.width, accumulate_field_1.height = 140.0, 100.0
	    separate_xyz_1.width, separate_xyz_1.height = 140.0, 100.0
	    curve_tangent_3.width, curve_tangent_3.height = 140.0, 100.0
	    normal_2.width, normal_2.height = 140.0, 100.0
	    vector_math_003_2.width, vector_math_003_2.height = 140.0, 100.0
	    vector_math_002_2.width, vector_math_002_2.height = 140.0, 100.0
	    vector_math_004_3.width, vector_math_004_3.height = 140.0, 100.0
	    vector_math_010_1.width, vector_math_010_1.height = 140.0, 100.0
	    vector_math_011_1.width, vector_math_011_1.height = 140.0, 100.0
	    vector_math_4.width, vector_math_4.height = 140.0, 100.0
	    random_value_1.width, random_value_1.height = 140.0, 100.0
	    switch_001_7.width, switch_001_7.height = 140.0, 100.0
	    reroute_004_3.width, reroute_004_3.height = 10.0, 100.0
	    group_005_1.width, group_005_1.height = 251.53790283203125, 100.0
	    sample_index_1.width, sample_index_1.height = 140.0, 100.0
	    accumulate_field_001.width, accumulate_field_001.height = 140.0, 100.0
	    compare_002_4.width, compare_002_4.height = 140.0, 100.0
	    boolean_math_1.width, boolean_math_1.height = 140.0, 100.0
	    group_input_008_1.width, group_input_008_1.height = 140.0, 100.0
	    group_input_003_3.width, group_input_003_3.height = 140.0, 100.0
	    random_value_004_1.width, random_value_004_1.height = 140.0, 100.0
	    group_001_2.width, group_001_2.height = 140.0, 100.0
	
	    #initialize frizz_hair_curves links
	    #set_spline_type.Curve -> set_position_1.Geometry
	    frizz_hair_curves.links.new(set_spline_type.outputs[0], set_position_1.inputs[0])
	    #random_value_1.Value -> separate_xyz_1.Vector
	    frizz_hair_curves.links.new(random_value_1.outputs[0], separate_xyz_1.inputs[0])
	    #curve_tangent_3.Tangent -> vector_math_4.Vector
	    frizz_hair_curves.links.new(curve_tangent_3.outputs[0], vector_math_4.inputs[0])
	    #normal_2.Normal -> vector_math_4.Vector
	    frizz_hair_curves.links.new(normal_2.outputs[0], vector_math_4.inputs[1])
	    #curve_tangent_3.Tangent -> vector_math_002_2.Vector
	    frizz_hair_curves.links.new(curve_tangent_3.outputs[0], vector_math_002_2.inputs[0])
	    #vector_math_4.Vector -> vector_math_003_2.Vector
	    frizz_hair_curves.links.new(vector_math_4.outputs[0], vector_math_003_2.inputs[0])
	    #normal_2.Normal -> vector_math_004_3.Vector
	    frizz_hair_curves.links.new(normal_2.outputs[0], vector_math_004_3.inputs[0])
	    #separate_xyz_1.X -> vector_math_002_2.Scale
	    frizz_hair_curves.links.new(separate_xyz_1.outputs[0], vector_math_002_2.inputs[3])
	    #separate_xyz_1.Y -> vector_math_003_2.Scale
	    frizz_hair_curves.links.new(separate_xyz_1.outputs[1], vector_math_003_2.inputs[3])
	    #separate_xyz_1.Z -> vector_math_004_3.Scale
	    frizz_hair_curves.links.new(separate_xyz_1.outputs[2], vector_math_004_3.inputs[3])
	    #vector_math_002_2.Vector -> vector_math_010_1.Vector
	    frizz_hair_curves.links.new(vector_math_002_2.outputs[0], vector_math_010_1.inputs[0])
	    #vector_math_003_2.Vector -> vector_math_010_1.Vector
	    frizz_hair_curves.links.new(vector_math_003_2.outputs[0], vector_math_010_1.inputs[1])
	    #vector_math_010_1.Vector -> vector_math_011_1.Vector
	    frizz_hair_curves.links.new(vector_math_010_1.outputs[0], vector_math_011_1.inputs[0])
	    #vector_math_004_3.Vector -> vector_math_011_1.Vector
	    frizz_hair_curves.links.new(vector_math_004_3.outputs[0], vector_math_011_1.inputs[1])
	    #vector_math_011_1.Vector -> vector_math_012_1.Vector
	    frizz_hair_curves.links.new(vector_math_011_1.outputs[0], vector_math_012_1.inputs[0])
	    #math_001_1.Value -> vector_math_012_1.Scale
	    frizz_hair_curves.links.new(math_001_1.outputs[0], vector_math_012_1.inputs[3])
	    #spline_parameter_1.Factor -> group_2.Value
	    frizz_hair_curves.links.new(spline_parameter_1.outputs[0], group_2.inputs[0])
	    #curve_of_point_1.Curve Index -> accumulate_field_1.Group ID
	    frizz_hair_curves.links.new(curve_of_point_1.outputs[0], accumulate_field_1.inputs[1])
	    #reroute_003_2.Output -> accumulate_field_1.Value
	    frizz_hair_curves.links.new(reroute_003_2.outputs[0], accumulate_field_1.inputs[0])
	    #group_input_002_3.Factor -> compare_3.A
	    frizz_hair_curves.links.new(group_input_002_3.outputs[2], compare_3.inputs[0])
	    #reroute_6.Output -> set_position_1.Selection
	    frizz_hair_curves.links.new(reroute_6.outputs[0], set_position_1.inputs[1])
	    #compare_3.Result -> reroute_6.Input
	    frizz_hair_curves.links.new(compare_3.outputs[0], reroute_6.inputs[0])
	    #random_value_004_1.Value -> random_value_1.Seed
	    frizz_hair_curves.links.new(random_value_004_1.outputs[2], random_value_1.inputs[8])
	    #vector_math_012_1.Vector -> field_at_index.Value
	    frizz_hair_curves.links.new(vector_math_012_1.outputs[0], field_at_index.inputs[1])
	    #reroute_004_3.Output -> group_005_1.Curves
	    frizz_hair_curves.links.new(reroute_004_3.outputs[0], group_005_1.inputs[0])
	    #group_input_008_1.Preserve Length -> group_005_1.Factor
	    frizz_hair_curves.links.new(group_input_008_1.outputs[6], group_005_1.inputs[2])
	    #reroute_015_3.Output -> group_005_1.Reference Position
	    frizz_hair_curves.links.new(reroute_015_3.outputs[0], group_005_1.inputs[3])
	    #vector_math_017.Vector -> set_position_1.Offset
	    frizz_hair_curves.links.new(vector_math_017.outputs[0], set_position_1.inputs[3])
	    #field_at_index.Value -> vector_math_013_1.Vector
	    frizz_hair_curves.links.new(field_at_index.outputs[0], vector_math_013_1.inputs[1])
	    #accumulate_field_1.Leading -> vector_math_014_1.Vector
	    frizz_hair_curves.links.new(accumulate_field_1.outputs[0], vector_math_014_1.inputs[0])
	    #accumulate_field_1.Trailing -> vector_math_014_1.Vector
	    frizz_hair_curves.links.new(accumulate_field_1.outputs[1], vector_math_014_1.inputs[1])
	    #vector_math_014_1.Vector -> vector_math_013_1.Vector
	    frizz_hair_curves.links.new(vector_math_014_1.outputs[0], vector_math_013_1.inputs[0])
	    #vector_math_013_1.Vector -> vector_math_015.Vector
	    frizz_hair_curves.links.new(vector_math_013_1.outputs[0], vector_math_015.inputs[0])
	    #reroute_6.Output -> boolean_math_1.Boolean
	    frizz_hair_curves.links.new(reroute_6.outputs[0], boolean_math_1.inputs[0])
	    #group_input_008_1.Preserve Length -> boolean_math_1.Boolean
	    frizz_hair_curves.links.new(group_input_008_1.outputs[6], boolean_math_1.inputs[1])
	    #group_input_6.Geometry -> separate_components_1.Geometry
	    frizz_hair_curves.links.new(group_input_6.outputs[0], separate_components_1.inputs[0])
	    #reroute_009_2.Output -> join_geometry_1.Geometry
	    frizz_hair_curves.links.new(reroute_009_2.outputs[0], join_geometry_1.inputs[0])
	    #vector_math_015.Vector -> switch_4.True
	    frizz_hair_curves.links.new(vector_math_015.outputs[0], switch_4.inputs[2])
	    #group_input_005_3.Cumulative Offset -> switch_4.Switch
	    frizz_hair_curves.links.new(group_input_005_3.outputs[1], switch_4.inputs[0])
	    #boolean_math_1.Boolean -> group_005_1.Selection
	    frizz_hair_curves.links.new(boolean_math_1.outputs[0], group_005_1.inputs[1])
	    #reroute_004_3.Output -> switch_001_7.False
	    frizz_hair_curves.links.new(reroute_004_3.outputs[0], switch_001_7.inputs[1])
	    #reroute_010_1.Output -> reroute_006_2.Input
	    frizz_hair_curves.links.new(reroute_010_1.outputs[0], reroute_006_2.inputs[0])
	    #reroute_011_2.Output -> reroute_007_2.Input
	    frizz_hair_curves.links.new(reroute_011_2.outputs[0], reroute_007_2.inputs[0])
	    #reroute_012_3.Output -> reroute_008_2.Input
	    frizz_hair_curves.links.new(reroute_012_3.outputs[0], reroute_008_2.inputs[0])
	    #reroute_013_3.Output -> reroute_009_2.Input
	    frizz_hair_curves.links.new(reroute_013_3.outputs[0], reroute_009_2.inputs[0])
	    #separate_components_1.Mesh -> reroute_010_1.Input
	    frizz_hair_curves.links.new(separate_components_1.outputs[0], reroute_010_1.inputs[0])
	    #separate_components_1.Volume -> reroute_011_2.Input
	    frizz_hair_curves.links.new(separate_components_1.outputs[4], reroute_011_2.inputs[0])
	    #separate_components_1.Point Cloud -> reroute_012_3.Input
	    frizz_hair_curves.links.new(separate_components_1.outputs[3], reroute_012_3.inputs[0])
	    #separate_components_1.Instances -> reroute_013_3.Input
	    frizz_hair_curves.links.new(separate_components_1.outputs[5], reroute_013_3.inputs[0])
	    #boolean_math_1.Boolean -> accumulate_field_001.Value
	    frizz_hair_curves.links.new(boolean_math_1.outputs[0], accumulate_field_001.inputs[0])
	    #compare_002_4.Result -> switch_001_7.Switch
	    frizz_hair_curves.links.new(compare_002_4.outputs[0], switch_001_7.inputs[0])
	    #reroute_004_3.Output -> sample_index_1.Geometry
	    frizz_hair_curves.links.new(reroute_004_3.outputs[0], sample_index_1.inputs[0])
	    #sample_index_1.Value -> compare_002_4.A
	    frizz_hair_curves.links.new(sample_index_1.outputs[0], compare_002_4.inputs[0])
	    #accumulate_field_001.Total -> sample_index_1.Value
	    frizz_hair_curves.links.new(accumulate_field_001.outputs[2], sample_index_1.inputs[1])
	    #join_geometry_1.Geometry -> group_output_10.Geometry
	    frizz_hair_curves.links.new(join_geometry_1.outputs[0], group_output_10.inputs[0])
	    #reroute_003_2.Output -> vector_math_016.Vector
	    frizz_hair_curves.links.new(reroute_003_2.outputs[0], vector_math_016.inputs[0])
	    #field_at_index.Value -> vector_math_016.Vector
	    frizz_hair_curves.links.new(field_at_index.outputs[0], vector_math_016.inputs[1])
	    #vector_math_016.Vector -> switch_4.False
	    frizz_hair_curves.links.new(vector_math_016.outputs[0], switch_4.inputs[1])
	    #group_005_1.Curves -> switch_001_7.True
	    frizz_hair_curves.links.new(group_005_1.outputs[0], switch_001_7.inputs[2])
	    #group_input_001_3.Factor -> math_001_1.Value
	    frizz_hair_curves.links.new(group_input_001_3.outputs[2], math_001_1.inputs[0])
	    #group_input_006_3.Distance -> math_001_1.Value
	    frizz_hair_curves.links.new(group_input_006_3.outputs[3], math_001_1.inputs[1])
	    #switch_4.Output -> vector_math_017.Vector
	    frizz_hair_curves.links.new(switch_4.outputs[0], vector_math_017.inputs[0])
	    #group_2.Value -> vector_math_017.Scale
	    frizz_hair_curves.links.new(group_2.outputs[0], vector_math_017.inputs[3])
	    #group_input_007_2.Shape -> group_2.Shape
	    frizz_hair_curves.links.new(group_input_007_2.outputs[4], group_2.inputs[3])
	    #spline_resolution.Resolution -> capture_attribute_002_1.Value
	    frizz_hair_curves.links.new(spline_resolution.outputs[0], capture_attribute_002_1.inputs[1])
	    #set_spline_type_001.Curve -> set_spline_resolution_001.Geometry
	    frizz_hair_curves.links.new(set_spline_type_001.outputs[0], set_spline_resolution_001.inputs[0])
	    #capture_attribute_002_1.Geometry -> set_spline_type.Curve
	    frizz_hair_curves.links.new(capture_attribute_002_1.outputs[0], set_spline_type.inputs[0])
	    #switch_001_7.Output -> set_spline_type_001.Curve
	    frizz_hair_curves.links.new(switch_001_7.outputs[0], set_spline_type_001.inputs[0])
	    #capture_attribute_002_1.Value -> reroute_002_2.Input
	    frizz_hair_curves.links.new(capture_attribute_002_1.outputs[1], reroute_002_2.inputs[0])
	    #reroute_002_2.Output -> compare_003_2.A
	    frizz_hair_curves.links.new(reroute_002_2.outputs[0], compare_003_2.inputs[2])
	    #compare_003_2.Result -> switch_004_1.Switch
	    frizz_hair_curves.links.new(compare_003_2.outputs[0], switch_004_1.inputs[0])
	    #reroute_002_2.Output -> switch_004_1.False
	    frizz_hair_curves.links.new(reroute_002_2.outputs[0], switch_004_1.inputs[1])
	    #switch_004_1.Output -> set_spline_resolution_001.Resolution
	    frizz_hair_curves.links.new(switch_004_1.outputs[0], set_spline_resolution_001.inputs[2])
	    #position_001_2.Position -> capture_attribute_003_1.Value
	    frizz_hair_curves.links.new(position_001_2.outputs[0], capture_attribute_003_1.inputs[1])
	    #position_002_3.Position -> vector_math_007_2.Vector
	    frizz_hair_curves.links.new(position_002_3.outputs[0], vector_math_007_2.inputs[0])
	    #reroute_015_3.Output -> vector_math_007_2.Vector
	    frizz_hair_curves.links.new(reroute_015_3.outputs[0], vector_math_007_2.inputs[1])
	    #vector_math_007_2.Vector -> capture_attribute_001_1.Value
	    frizz_hair_curves.links.new(vector_math_007_2.outputs[0], capture_attribute_001_1.inputs[1])
	    #separate_components_1.Curve -> capture_attribute_003_1.Geometry
	    frizz_hair_curves.links.new(separate_components_1.outputs[1], capture_attribute_003_1.inputs[0])
	    #capture_attribute_003_1.Geometry -> capture_attribute_002_1.Geometry
	    frizz_hair_curves.links.new(capture_attribute_003_1.outputs[0], capture_attribute_002_1.inputs[0])
	    #set_spline_resolution_001.Geometry -> capture_attribute_001_1.Geometry
	    frizz_hair_curves.links.new(set_spline_resolution_001.outputs[0], capture_attribute_001_1.inputs[0])
	    #capture_attribute_001_1.Value -> group_output_10.Offset Vector
	    frizz_hair_curves.links.new(capture_attribute_001_1.outputs[1], group_output_10.inputs[1])
	    #set_position_1.Geometry -> reroute_004_3.Input
	    frizz_hair_curves.links.new(set_position_1.outputs[0], reroute_004_3.inputs[0])
	    #capture_attribute_003_1.Value -> reroute_015_3.Input
	    frizz_hair_curves.links.new(capture_attribute_003_1.outputs[1], reroute_015_3.inputs[0])
	    #vector_math_012_1.Vector -> reroute_003_2.Input
	    frizz_hair_curves.links.new(vector_math_012_1.outputs[0], reroute_003_2.inputs[0])
	    #group_input_003_3.Seed -> random_value_004_1.ID
	    frizz_hair_curves.links.new(group_input_003_3.outputs[5], random_value_004_1.inputs[7])
	    #group_001_2.Root Index -> field_at_index.Index
	    frizz_hair_curves.links.new(group_001_2.outputs[3], field_at_index.inputs[0])
	    #reroute_007_2.Output -> join_geometry_1.Geometry
	    frizz_hair_curves.links.new(reroute_007_2.outputs[0], join_geometry_1.inputs[0])
	    #capture_attribute_001_1.Geometry -> join_geometry_1.Geometry
	    frizz_hair_curves.links.new(capture_attribute_001_1.outputs[0], join_geometry_1.inputs[0])
	    #reroute_008_2.Output -> join_geometry_1.Geometry
	    frizz_hair_curves.links.new(reroute_008_2.outputs[0], join_geometry_1.inputs[0])
	    #reroute_006_2.Output -> join_geometry_1.Geometry
	    frizz_hair_curves.links.new(reroute_006_2.outputs[0], join_geometry_1.inputs[0])
	    return frizz_hair_curves
	
	frizz_hair_curves = frizz_hair_curves_node_group()
	
	#initialize hair_noise node group
	def hair_noise_node_group():
	    hair_noise = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "HAIR_NOISE")
	
	    hair_noise.color_tag = 'NONE'
	    hair_noise.description = ""
	    hair_noise.default_group_node_width = 140
	    
	
	
	    #hair_noise interface
	    #Socket Geometry
	    geometry_socket_10 = hair_noise.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_10.attribute_domain = 'POINT'
	
	    #Socket Geometry
	    geometry_socket_11 = hair_noise.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_11.attribute_domain = 'POINT'
	
	    #Socket Surface
	    surface_socket_2 = hair_noise.interface.new_socket(name = "Surface", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    surface_socket_2.attribute_domain = 'POINT'
	
	    #Socket Surface
	    surface_socket_3 = hair_noise.interface.new_socket(name = "Surface", in_out='INPUT', socket_type = 'NodeSocketObject')
	    surface_socket_3.attribute_domain = 'POINT'
	
	    #Socket Surface Offset
	    surface_offset_socket = hair_noise.interface.new_socket(name = "Surface Offset", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    surface_offset_socket.default_value = 1.0
	    surface_offset_socket.min_value = 0.0
	    surface_offset_socket.max_value = 1.0
	    surface_offset_socket.subtype = 'FACTOR'
	    surface_offset_socket.attribute_domain = 'POINT'
	
	    #Socket Scale
	    scale_socket = hair_noise.interface.new_socket(name = "Scale", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    scale_socket.default_value = 5.0
	    scale_socket.min_value = -1000.0
	    scale_socket.max_value = 1000.0
	    scale_socket.subtype = 'NONE'
	    scale_socket.attribute_domain = 'POINT'
	
	    #Socket Detail
	    detail_socket = hair_noise.interface.new_socket(name = "Detail", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    detail_socket.default_value = 0.5
	    detail_socket.min_value = 0.0
	    detail_socket.max_value = 15.0
	    detail_socket.subtype = 'NONE'
	    detail_socket.attribute_domain = 'POINT'
	
	    #Socket Roughness
	    roughness_socket = hair_noise.interface.new_socket(name = "Roughness", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    roughness_socket.default_value = 0.5
	    roughness_socket.min_value = 0.0
	    roughness_socket.max_value = 1.0
	    roughness_socket.subtype = 'FACTOR'
	    roughness_socket.attribute_domain = 'POINT'
	
	    #Socket Lacunarity
	    lacunarity_socket = hair_noise.interface.new_socket(name = "Lacunarity", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    lacunarity_socket.default_value = 2.0
	    lacunarity_socket.min_value = 0.0
	    lacunarity_socket.max_value = 1000.0
	    lacunarity_socket.subtype = 'NONE'
	    lacunarity_socket.attribute_domain = 'POINT'
	
	    #Socket Distortion
	    distortion_socket = hair_noise.interface.new_socket(name = "Distortion", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    distortion_socket.default_value = 5.0
	    distortion_socket.min_value = -1000.0
	    distortion_socket.max_value = 1000.0
	    distortion_socket.subtype = 'NONE'
	    distortion_socket.attribute_domain = 'POINT'
	
	
	    #initialize hair_noise nodes
	    #node Group Output
	    group_output_11 = hair_noise.nodes.new("NodeGroupOutput")
	    group_output_11.name = "Group Output"
	    group_output_11.is_active_output = True
	    group_output_11.inputs[1].hide = True
	
	    #node Group Input
	    group_input_7 = hair_noise.nodes.new("NodeGroupInput")
	    group_input_7.name = "Group Input"
	    group_input_7.outputs[3].hide = True
	    group_input_7.outputs[4].hide = True
	    group_input_7.outputs[5].hide = True
	    group_input_7.outputs[6].hide = True
	    group_input_7.outputs[7].hide = True
	    group_input_7.outputs[8].hide = True
	    group_input_7.outputs[9].hide = True
	
	    #node Set Position
	    set_position_2 = hair_noise.nodes.new("GeometryNodeSetPosition")
	    set_position_2.name = "Set Position"
	    set_position_2.inputs[2].hide = True
	    #Position
	    set_position_2.inputs[2].default_value = (0.0, 0.0, 0.0)
	
	    #node Endpoint Selection
	    endpoint_selection_2 = hair_noise.nodes.new("GeometryNodeCurveEndpointSelection")
	    endpoint_selection_2.name = "Endpoint Selection"
	    endpoint_selection_2.hide = True
	    #Start Size
	    endpoint_selection_2.inputs[0].default_value = 1
	    #End Size
	    endpoint_selection_2.inputs[1].default_value = 1
	
	    #node Boolean Math
	    boolean_math_2 = hair_noise.nodes.new("FunctionNodeBooleanMath")
	    boolean_math_2.name = "Boolean Math"
	    boolean_math_2.hide = True
	    boolean_math_2.operation = 'NOT'
	
	    #node Noise Texture
	    noise_texture = hair_noise.nodes.new("ShaderNodeTexNoise")
	    noise_texture.name = "Noise Texture"
	    noise_texture.noise_dimensions = '4D'
	    noise_texture.noise_type = 'FBM'
	    noise_texture.normalize = True
	    noise_texture.inputs[0].hide = True
	    noise_texture.inputs[6].hide = True
	    noise_texture.inputs[7].hide = True
	    noise_texture.outputs[1].hide = True
	    #Vector
	    noise_texture.inputs[0].default_value = (0.0, 0.0, 0.0)
	
	    #node Index
	    index_3 = hair_noise.nodes.new("GeometryNodeInputIndex")
	    index_3.name = "Index"
	
	    #node Group
	    group_3 = hair_noise.nodes.new("GeometryNodeGroup")
	    group_3.name = "Group"
	    group_3.hide = True
	    group_3.node_tree = mesh_geometry_priority
	
	    #node Sample Nearest
	    sample_nearest_1 = hair_noise.nodes.new("GeometryNodeSampleNearest")
	    sample_nearest_1.name = "Sample Nearest"
	    sample_nearest_1.hide = True
	    sample_nearest_1.domain = 'FACE'
	    #Sample Position
	    sample_nearest_1.inputs[1].default_value = (0.0, 0.0, 0.0)
	
	    #node Normal
	    normal_3 = hair_noise.nodes.new("GeometryNodeInputNormal")
	    normal_3.name = "Normal"
	    normal_3.hide = True
	    normal_3.legacy_corner_normals = True
	
	    #node Vector Math
	    vector_math_5 = hair_noise.nodes.new("ShaderNodeVectorMath")
	    vector_math_5.name = "Vector Math"
	    vector_math_5.hide = True
	    vector_math_5.operation = 'SCALE'
	
	    #node Map Range.001
	    map_range_001_1 = hair_noise.nodes.new("ShaderNodeMapRange")
	    map_range_001_1.name = "Map Range.001"
	    map_range_001_1.hide = True
	    map_range_001_1.clamp = True
	    map_range_001_1.data_type = 'FLOAT'
	    map_range_001_1.interpolation_type = 'LINEAR'
	    map_range_001_1.inputs[1].hide = True
	    map_range_001_1.inputs[2].hide = True
	    map_range_001_1.inputs[3].hide = True
	    map_range_001_1.inputs[5].hide = True
	    map_range_001_1.inputs[6].hide = True
	    map_range_001_1.inputs[7].hide = True
	    map_range_001_1.inputs[8].hide = True
	    map_range_001_1.inputs[9].hide = True
	    map_range_001_1.inputs[10].hide = True
	    map_range_001_1.inputs[11].hide = True
	    map_range_001_1.outputs[1].hide = True
	    #From Min
	    map_range_001_1.inputs[1].default_value = 0.0
	    #From Max
	    map_range_001_1.inputs[2].default_value = 1.0
	    #To Min
	    map_range_001_1.inputs[3].default_value = 0.0
	
	    #node Sample Index
	    sample_index_2 = hair_noise.nodes.new("GeometryNodeSampleIndex")
	    sample_index_2.name = "Sample Index"
	    sample_index_2.hide = True
	    sample_index_2.clamp = False
	    sample_index_2.data_type = 'FLOAT_VECTOR'
	    sample_index_2.domain = 'POINT'
	
	    #node Math
	    math_4 = hair_noise.nodes.new("ShaderNodeMath")
	    math_4.name = "Math"
	    math_4.hide = True
	    math_4.operation = 'MULTIPLY'
	    math_4.use_clamp = False
	    #Value_001
	    math_4.inputs[1].default_value = 0.10000000149011612
	
	    #node Group Input.001
	    group_input_001_4 = hair_noise.nodes.new("NodeGroupInput")
	    group_input_001_4.name = "Group Input.001"
	    group_input_001_4.outputs[0].hide = True
	    group_input_001_4.outputs[1].hide = True
	    group_input_001_4.outputs[2].hide = True
	    group_input_001_4.outputs[4].hide = True
	    group_input_001_4.outputs[5].hide = True
	    group_input_001_4.outputs[6].hide = True
	    group_input_001_4.outputs[7].hide = True
	    group_input_001_4.outputs[8].hide = True
	    group_input_001_4.outputs[9].hide = True
	
	    #node Group Input.002
	    group_input_002_4 = hair_noise.nodes.new("NodeGroupInput")
	    group_input_002_4.name = "Group Input.002"
	    group_input_002_4.outputs[0].hide = True
	    group_input_002_4.outputs[1].hide = True
	    group_input_002_4.outputs[2].hide = True
	    group_input_002_4.outputs[3].hide = True
	    group_input_002_4.outputs[9].hide = True
	
	
	
	
	
	    #Set locations
	    group_output_11.location = (769.8711547851562, 16.861846923828125)
	    group_input_7.location = (-200.0, 0.0)
	    set_position_2.location = (595.2684326171875, 16.861846923828125)
	    endpoint_selection_2.location = (435.3762512207031, -92.31562042236328)
	    boolean_math_2.location = (437.7815856933594, -53.75435256958008)
	    noise_texture.location = (243.0096893310547, -196.88522338867188)
	    index_3.location = (33.75593185424805, -262.185546875)
	    group_3.location = (16.22144317626953, -56.93858337402344)
	    sample_nearest_1.location = (241.2880859375, -163.95318603515625)
	    normal_3.location = (236.47703552246094, -55.49953842163086)
	    vector_math_5.location = (458.1733093261719, -192.3916778564453)
	    map_range_001_1.location = (458.8695983886719, -226.65318298339844)
	    sample_index_2.location = (243.6933135986328, -111.96574401855469)
	    math_4.location = (459.2305908203125, -263.2552795410156)
	    group_input_001_4.location = (457.17596435546875, -295.082275390625)
	    group_input_002_4.location = (34.22426986694336, -317.0027160644531)
	
	    #Set dimensions
	    group_output_11.width, group_output_11.height = 140.0, 100.0
	    group_input_7.width, group_input_7.height = 140.0, 100.0
	    set_position_2.width, set_position_2.height = 140.0, 100.0
	    endpoint_selection_2.width, endpoint_selection_2.height = 140.0, 100.0
	    boolean_math_2.width, boolean_math_2.height = 140.0, 100.0
	    noise_texture.width, noise_texture.height = 140.0, 100.0
	    index_3.width, index_3.height = 140.0, 100.0
	    group_3.width, group_3.height = 140.0, 100.0
	    sample_nearest_1.width, sample_nearest_1.height = 140.0, 100.0
	    normal_3.width, normal_3.height = 140.0, 100.0
	    vector_math_5.width, vector_math_5.height = 140.0, 100.0
	    map_range_001_1.width, map_range_001_1.height = 140.0, 100.0
	    sample_index_2.width, sample_index_2.height = 140.0, 100.0
	    math_4.width, math_4.height = 140.0, 100.0
	    group_input_001_4.width, group_input_001_4.height = 140.0, 100.0
	    group_input_002_4.width, group_input_002_4.height = 140.0, 100.0
	
	    #initialize hair_noise links
	    #group_input_7.Geometry -> set_position_2.Geometry
	    hair_noise.links.new(group_input_7.outputs[0], set_position_2.inputs[0])
	    #set_position_2.Geometry -> group_output_11.Geometry
	    hair_noise.links.new(set_position_2.outputs[0], group_output_11.inputs[0])
	    #endpoint_selection_2.Selection -> boolean_math_2.Boolean
	    hair_noise.links.new(endpoint_selection_2.outputs[0], boolean_math_2.inputs[0])
	    #boolean_math_2.Boolean -> set_position_2.Selection
	    hair_noise.links.new(boolean_math_2.outputs[0], set_position_2.inputs[1])
	    #index_3.Index -> noise_texture.W
	    hair_noise.links.new(index_3.outputs[0], noise_texture.inputs[1])
	    #group_3.Geometry -> sample_nearest_1.Geometry
	    hair_noise.links.new(group_3.outputs[0], sample_nearest_1.inputs[0])
	    #normal_3.Normal -> sample_index_2.Value
	    hair_noise.links.new(normal_3.outputs[0], sample_index_2.inputs[1])
	    #sample_nearest_1.Index -> sample_index_2.Index
	    hair_noise.links.new(sample_nearest_1.outputs[0], sample_index_2.inputs[2])
	    #group_3.Geometry -> sample_index_2.Geometry
	    hair_noise.links.new(group_3.outputs[0], sample_index_2.inputs[0])
	    #sample_index_2.Value -> vector_math_5.Vector
	    hair_noise.links.new(sample_index_2.outputs[0], vector_math_5.inputs[0])
	    #map_range_001_1.Result -> vector_math_5.Scale
	    hair_noise.links.new(map_range_001_1.outputs[0], vector_math_5.inputs[3])
	    #noise_texture.Fac -> map_range_001_1.Value
	    hair_noise.links.new(noise_texture.outputs[0], map_range_001_1.inputs[0])
	    #vector_math_5.Vector -> set_position_2.Offset
	    hair_noise.links.new(vector_math_5.outputs[0], set_position_2.inputs[3])
	    #group_input_7.Surface -> group_3.Geometry
	    hair_noise.links.new(group_input_7.outputs[1], group_3.inputs[0])
	    #group_input_7.Surface -> group_3.Object
	    hair_noise.links.new(group_input_7.outputs[2], group_3.inputs[1])
	    #math_4.Value -> map_range_001_1.To Max
	    hair_noise.links.new(math_4.outputs[0], map_range_001_1.inputs[4])
	    #group_input_001_4.Surface Offset -> math_4.Value
	    hair_noise.links.new(group_input_001_4.outputs[3], math_4.inputs[0])
	    #group_input_002_4.Scale -> noise_texture.Scale
	    hair_noise.links.new(group_input_002_4.outputs[4], noise_texture.inputs[2])
	    #group_input_002_4.Detail -> noise_texture.Detail
	    hair_noise.links.new(group_input_002_4.outputs[5], noise_texture.inputs[3])
	    #group_input_002_4.Roughness -> noise_texture.Roughness
	    hair_noise.links.new(group_input_002_4.outputs[6], noise_texture.inputs[4])
	    #group_input_002_4.Lacunarity -> noise_texture.Lacunarity
	    hair_noise.links.new(group_input_002_4.outputs[7], noise_texture.inputs[5])
	    #group_input_002_4.Distortion -> noise_texture.Distortion
	    hair_noise.links.new(group_input_002_4.outputs[8], noise_texture.inputs[8])
	    return hair_noise
	
	hair_noise = hair_noise_node_group()
	
	#initialize scalp_hair node group
	def scalp_hair_node_group():
	    scalp_hair = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "SCALP_HAIR")
	
	    scalp_hair.color_tag = 'NONE'
	    scalp_hair.description = ""
	    scalp_hair.default_group_node_width = 140
	    
	
	    scalp_hair.is_modifier = True
	
	    #scalp_hair interface
	    #Socket Geometry
	    geometry_socket_12 = scalp_hair.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_12.attribute_domain = 'POINT'
	
	    #Socket Geometry
	    geometry_socket_13 = scalp_hair.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_13.attribute_domain = 'POINT'
	
	    #Socket Surface
	    surface_socket_4 = scalp_hair.interface.new_socket(name = "Surface", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    surface_socket_4.attribute_domain = 'POINT'
	
	    #Socket Surface
	    surface_socket_5 = scalp_hair.interface.new_socket(name = "Surface", in_out='INPUT', socket_type = 'NodeSocketObject')
	    surface_socket_5.attribute_domain = 'POINT'
	
	    #Socket Guide Curve
	    guide_curve_socket_2 = scalp_hair.interface.new_socket(name = "Guide Curve", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    guide_curve_socket_2.attribute_domain = 'POINT'
	
	    #Socket Guide Curve
	    guide_curve_socket_3 = scalp_hair.interface.new_socket(name = "Guide Curve", in_out='INPUT', socket_type = 'NodeSocketObject')
	    guide_curve_socket_3.attribute_domain = 'POINT'
	
	    #Socket Control Points
	    control_points_socket_1 = scalp_hair.interface.new_socket(name = "Control Points", in_out='INPUT', socket_type = 'NodeSocketInt')
	    control_points_socket_1.default_value = 10
	    control_points_socket_1.min_value = 3
	    control_points_socket_1.max_value = 100000
	    control_points_socket_1.subtype = 'NONE'
	    control_points_socket_1.attribute_domain = 'POINT'
	
	    #Socket Hair Radius
	    hair_radius_socket = scalp_hair.interface.new_socket(name = "Hair Radius", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    hair_radius_socket.default_value = 0.003000000026077032
	    hair_radius_socket.min_value = 0.0
	    hair_radius_socket.max_value = 10000.0
	    hair_radius_socket.subtype = 'NONE'
	    hair_radius_socket.attribute_domain = 'POINT'
	
	    #Socket Hair Shape Curve
	    hair_shape_curve_socket = scalp_hair.interface.new_socket(name = "Hair Shape Curve", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    hair_shape_curve_socket.default_value = 0.0
	    hair_shape_curve_socket.min_value = 0.0
	    hair_shape_curve_socket.max_value = 0.0
	    hair_shape_curve_socket.subtype = 'NONE'
	    hair_shape_curve_socket.attribute_domain = 'POINT'
	    hair_shape_curve_socket.hide_value = True
	    hair_shape_curve_socket.hide_in_modifier = True
	
	    #Socket Hair Shape Offset
	    hair_shape_offset_socket_1 = scalp_hair.interface.new_socket(name = "Hair Shape Offset", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    hair_shape_offset_socket_1.default_value = 0.009999999776482582
	    hair_shape_offset_socket_1.min_value = 0.0
	    hair_shape_offset_socket_1.max_value = 10000.0
	    hair_shape_offset_socket_1.subtype = 'NONE'
	    hair_shape_offset_socket_1.attribute_domain = 'POINT'
	
	    #Socket Sample Surface Count
	    sample_surface_count_socket_1 = scalp_hair.interface.new_socket(name = "Sample Surface Count", in_out='INPUT', socket_type = 'NodeSocketInt')
	    sample_surface_count_socket_1.default_value = 10
	    sample_surface_count_socket_1.min_value = 1
	    sample_surface_count_socket_1.max_value = 100000
	    sample_surface_count_socket_1.subtype = 'NONE'
	    sample_surface_count_socket_1.attribute_domain = 'POINT'
	
	    #Socket Sample Surface Distance
	    sample_surface_distance_socket_1 = scalp_hair.interface.new_socket(name = "Sample Surface Distance", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    sample_surface_distance_socket_1.default_value = 0.10000000149011612
	    sample_surface_distance_socket_1.min_value = 0.0
	    sample_surface_distance_socket_1.max_value = 10000.0
	    sample_surface_distance_socket_1.subtype = 'NONE'
	    sample_surface_distance_socket_1.attribute_domain = 'POINT'
	
	    #Socket Max Influence Distance
	    max_influence_distance_socket_1 = scalp_hair.interface.new_socket(name = "Max Influence Distance", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    max_influence_distance_socket_1.default_value = 0.0
	    max_influence_distance_socket_1.min_value = 0.0
	    max_influence_distance_socket_1.max_value = 10000.0
	    max_influence_distance_socket_1.subtype = 'NONE'
	    max_influence_distance_socket_1.attribute_domain = 'POINT'
	
	    #Socket Offset from Surface
	    offset_from_surface_socket_1 = scalp_hair.interface.new_socket(name = "Offset from Surface", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    offset_from_surface_socket_1.default_value = 0.0
	    offset_from_surface_socket_1.min_value = 0.0
	    offset_from_surface_socket_1.max_value = 0.0
	    offset_from_surface_socket_1.subtype = 'NONE'
	    offset_from_surface_socket_1.attribute_domain = 'POINT'
	    offset_from_surface_socket_1.hide_value = True
	    offset_from_surface_socket_1.hide_in_modifier = True
	
	    #Socket Material
	    material_socket = scalp_hair.interface.new_socket(name = "Material", in_out='INPUT', socket_type = 'NodeSocketMaterial')
	    material_socket.attribute_domain = 'POINT'
	
	    #Socket Duplicate Amount
	    duplicate_amount_socket = scalp_hair.interface.new_socket(name = "Duplicate Amount", in_out='INPUT', socket_type = 'NodeSocketInt')
	    duplicate_amount_socket.default_value = 0
	    duplicate_amount_socket.min_value = 0
	    duplicate_amount_socket.max_value = 2147483647
	    duplicate_amount_socket.subtype = 'NONE'
	    duplicate_amount_socket.attribute_domain = 'POINT'
	
	    #Socket Duplicate Viewport Amount
	    duplicate_viewport_amount_socket = scalp_hair.interface.new_socket(name = "Duplicate Viewport Amount", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    duplicate_viewport_amount_socket.default_value = 1.0
	    duplicate_viewport_amount_socket.min_value = 0.0
	    duplicate_viewport_amount_socket.max_value = 1.0
	    duplicate_viewport_amount_socket.subtype = 'FACTOR'
	    duplicate_viewport_amount_socket.attribute_domain = 'POINT'
	
	    #Socket Duplicate Radius
	    duplicate_radius_socket = scalp_hair.interface.new_socket(name = "Duplicate Radius", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    duplicate_radius_socket.default_value = 0.10000000149011612
	    duplicate_radius_socket.min_value = 0.0
	    duplicate_radius_socket.max_value = 3.4028234663852886e+38
	    duplicate_radius_socket.subtype = 'DISTANCE'
	    duplicate_radius_socket.attribute_domain = 'POINT'
	
	    #Socket Duplicate Distribution Shape
	    duplicate_distribution_shape_socket = scalp_hair.interface.new_socket(name = "Duplicate Distribution Shape", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    duplicate_distribution_shape_socket.default_value = 0.0
	    duplicate_distribution_shape_socket.min_value = -10.0
	    duplicate_distribution_shape_socket.max_value = 10.0
	    duplicate_distribution_shape_socket.subtype = 'NONE'
	    duplicate_distribution_shape_socket.attribute_domain = 'POINT'
	
	    #Socket Duplicate Tip Roundness
	    duplicate_tip_roundness_socket = scalp_hair.interface.new_socket(name = "Duplicate Tip Roundness", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    duplicate_tip_roundness_socket.default_value = 0.0
	    duplicate_tip_roundness_socket.min_value = 0.0
	    duplicate_tip_roundness_socket.max_value = 1.0
	    duplicate_tip_roundness_socket.subtype = 'FACTOR'
	    duplicate_tip_roundness_socket.attribute_domain = 'POINT'
	
	    #Socket Duplicate Even Thickness
	    duplicate_even_thickness_socket = scalp_hair.interface.new_socket(name = "Duplicate Even Thickness", in_out='INPUT', socket_type = 'NodeSocketBool')
	    duplicate_even_thickness_socket.default_value = False
	    duplicate_even_thickness_socket.attribute_domain = 'POINT'
	
	    #Socket Duplicate Seed
	    duplicate_seed_socket = scalp_hair.interface.new_socket(name = "Duplicate Seed", in_out='INPUT', socket_type = 'NodeSocketInt')
	    duplicate_seed_socket.default_value = 0
	    duplicate_seed_socket.min_value = -10000
	    duplicate_seed_socket.max_value = 10000
	    duplicate_seed_socket.subtype = 'NONE'
	    duplicate_seed_socket.attribute_domain = 'POINT'
	
	    #Socket Frizz Factor
	    frizz_factor_socket = scalp_hair.interface.new_socket(name = "Frizz Factor", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    frizz_factor_socket.default_value = 0.0
	    frizz_factor_socket.min_value = 0.0
	    frizz_factor_socket.max_value = 1.0
	    frizz_factor_socket.subtype = 'FACTOR'
	    frizz_factor_socket.attribute_domain = 'POINT'
	
	    #Socket Frizz Distance
	    frizz_distance_socket = scalp_hair.interface.new_socket(name = "Frizz Distance", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    frizz_distance_socket.default_value = 0.009999999776482582
	    frizz_distance_socket.min_value = 0.0
	    frizz_distance_socket.max_value = 3.4028234663852886e+38
	    frizz_distance_socket.subtype = 'DISTANCE'
	    frizz_distance_socket.attribute_domain = 'POINT'
	
	    #Socket Frizz Shape
	    frizz_shape_socket = scalp_hair.interface.new_socket(name = "Frizz Shape", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    frizz_shape_socket.default_value = 0.5
	    frizz_shape_socket.min_value = -1.0
	    frizz_shape_socket.max_value = 1.0
	    frizz_shape_socket.subtype = 'NONE'
	    frizz_shape_socket.attribute_domain = 'POINT'
	
	    #Socket Frizz Seed
	    frizz_seed_socket = scalp_hair.interface.new_socket(name = "Frizz Seed", in_out='INPUT', socket_type = 'NodeSocketInt')
	    frizz_seed_socket.default_value = 0
	    frizz_seed_socket.min_value = -10000
	    frizz_seed_socket.max_value = 10000
	    frizz_seed_socket.subtype = 'NONE'
	    frizz_seed_socket.attribute_domain = 'POINT'
	
	    #Socket Noise Surface Offset
	    noise_surface_offset_socket = scalp_hair.interface.new_socket(name = "Noise Surface Offset", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    noise_surface_offset_socket.default_value = 0.0
	    noise_surface_offset_socket.min_value = 0.0
	    noise_surface_offset_socket.max_value = 1.0
	    noise_surface_offset_socket.subtype = 'FACTOR'
	    noise_surface_offset_socket.attribute_domain = 'POINT'
	
	    #Socket Noise Scale
	    noise_scale_socket = scalp_hair.interface.new_socket(name = "Noise Scale", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    noise_scale_socket.default_value = 5.0
	    noise_scale_socket.min_value = -1000.0
	    noise_scale_socket.max_value = 1000.0
	    noise_scale_socket.subtype = 'NONE'
	    noise_scale_socket.attribute_domain = 'POINT'
	
	    #Socket Noise Detail
	    noise_detail_socket = scalp_hair.interface.new_socket(name = "Noise Detail", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    noise_detail_socket.default_value = 1.0
	    noise_detail_socket.min_value = 0.0
	    noise_detail_socket.max_value = 15.0
	    noise_detail_socket.subtype = 'NONE'
	    noise_detail_socket.attribute_domain = 'POINT'
	
	    #Socket Noise Roughness
	    noise_roughness_socket = scalp_hair.interface.new_socket(name = "Noise Roughness", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    noise_roughness_socket.default_value = 0.5
	    noise_roughness_socket.min_value = 0.0
	    noise_roughness_socket.max_value = 1.0
	    noise_roughness_socket.subtype = 'FACTOR'
	    noise_roughness_socket.attribute_domain = 'POINT'
	
	    #Socket Noise Lacunarity
	    noise_lacunarity_socket = scalp_hair.interface.new_socket(name = "Noise Lacunarity", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    noise_lacunarity_socket.default_value = 2.0
	    noise_lacunarity_socket.min_value = 0.0
	    noise_lacunarity_socket.max_value = 1000.0
	    noise_lacunarity_socket.subtype = 'NONE'
	    noise_lacunarity_socket.attribute_domain = 'POINT'
	
	    #Socket Noise Distortion
	    noise_distortion_socket = scalp_hair.interface.new_socket(name = "Noise Distortion", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    noise_distortion_socket.default_value = 5.0
	    noise_distortion_socket.min_value = -1000.0
	    noise_distortion_socket.max_value = 1000.0
	    noise_distortion_socket.subtype = 'NONE'
	    noise_distortion_socket.attribute_domain = 'POINT'
	
	
	    #initialize scalp_hair nodes
	    #node Group Input
	    group_input_8 = scalp_hair.nodes.new("NodeGroupInput")
	    group_input_8.name = "Group Input"
	    group_input_8.outputs[1].hide = True
	    group_input_8.outputs[2].hide = True
	    group_input_8.outputs[3].hide = True
	    group_input_8.outputs[4].hide = True
	    group_input_8.outputs[5].hide = True
	    group_input_8.outputs[6].hide = True
	    group_input_8.outputs[7].hide = True
	    group_input_8.outputs[8].hide = True
	    group_input_8.outputs[9].hide = True
	    group_input_8.outputs[10].hide = True
	    group_input_8.outputs[11].hide = True
	    group_input_8.outputs[12].hide = True
	    group_input_8.outputs[13].hide = True
	    group_input_8.outputs[21].hide = True
	    group_input_8.outputs[22].hide = True
	    group_input_8.outputs[23].hide = True
	    group_input_8.outputs[24].hide = True
	    group_input_8.outputs[25].hide = True
	    group_input_8.outputs[26].hide = True
	    group_input_8.outputs[27].hide = True
	    group_input_8.outputs[28].hide = True
	    group_input_8.outputs[29].hide = True
	    group_input_8.outputs[30].hide = True
	    group_input_8.outputs[31].hide = True
	
	    #node Group Output
	    group_output_12 = scalp_hair.nodes.new("NodeGroupOutput")
	    group_output_12.name = "Group Output"
	    group_output_12.is_active_output = True
	
	    #node Group
	    group_4 = scalp_hair.nodes.new("GeometryNodeGroup")
	    group_4.name = "Group"
	    group_4.node_tree = shape_curve_to_closest_point
	
	    #node Group.001
	    group_001_3 = scalp_hair.nodes.new("GeometryNodeGroup")
	    group_001_3.name = "Group.001"
	    group_001_3.node_tree = duplicate_hair_curves
	
	    #node Group.002
	    group_002_4 = scalp_hair.nodes.new("GeometryNodeGroup")
	    group_002_4.name = "Group.002"
	    group_002_4.node_tree = frizz_hair_curves
	    #Socket_3
	    group_002_4.inputs[1].default_value = True
	    #Socket_8
	    group_002_4.inputs[6].default_value = True
	
	    #node Group.003
	    group_003_1 = scalp_hair.nodes.new("GeometryNodeGroup")
	    group_003_1.name = "Group.003"
	    group_003_1.node_tree = hair_noise
	
	    #node Group Input.001
	    group_input_001_5 = scalp_hair.nodes.new("NodeGroupInput")
	    group_input_001_5.name = "Group Input.001"
	    group_input_001_5.outputs[0].hide = True
	    group_input_001_5.outputs[6].hide = True
	    group_input_001_5.outputs[7].hide = True
	    group_input_001_5.outputs[12].hide = True
	    group_input_001_5.outputs[13].hide = True
	    group_input_001_5.outputs[14].hide = True
	    group_input_001_5.outputs[15].hide = True
	    group_input_001_5.outputs[16].hide = True
	    group_input_001_5.outputs[17].hide = True
	    group_input_001_5.outputs[18].hide = True
	    group_input_001_5.outputs[19].hide = True
	    group_input_001_5.outputs[20].hide = True
	    group_input_001_5.outputs[21].hide = True
	    group_input_001_5.outputs[22].hide = True
	    group_input_001_5.outputs[23].hide = True
	    group_input_001_5.outputs[24].hide = True
	    group_input_001_5.outputs[25].hide = True
	    group_input_001_5.outputs[26].hide = True
	    group_input_001_5.outputs[27].hide = True
	    group_input_001_5.outputs[28].hide = True
	    group_input_001_5.outputs[29].hide = True
	    group_input_001_5.outputs[30].hide = True
	    group_input_001_5.outputs[31].hide = True
	
	    #node Group Input.002
	    group_input_002_5 = scalp_hair.nodes.new("NodeGroupInput")
	    group_input_002_5.name = "Group Input.002"
	    group_input_002_5.outputs[0].hide = True
	    group_input_002_5.outputs[1].hide = True
	    group_input_002_5.outputs[2].hide = True
	    group_input_002_5.outputs[3].hide = True
	    group_input_002_5.outputs[4].hide = True
	    group_input_002_5.outputs[5].hide = True
	    group_input_002_5.outputs[6].hide = True
	    group_input_002_5.outputs[7].hide = True
	    group_input_002_5.outputs[8].hide = True
	    group_input_002_5.outputs[9].hide = True
	    group_input_002_5.outputs[10].hide = True
	    group_input_002_5.outputs[11].hide = True
	    group_input_002_5.outputs[12].hide = True
	    group_input_002_5.outputs[13].hide = True
	    group_input_002_5.outputs[14].hide = True
	    group_input_002_5.outputs[15].hide = True
	    group_input_002_5.outputs[16].hide = True
	    group_input_002_5.outputs[17].hide = True
	    group_input_002_5.outputs[18].hide = True
	    group_input_002_5.outputs[19].hide = True
	    group_input_002_5.outputs[20].hide = True
	    group_input_002_5.outputs[25].hide = True
	    group_input_002_5.outputs[26].hide = True
	    group_input_002_5.outputs[27].hide = True
	    group_input_002_5.outputs[28].hide = True
	    group_input_002_5.outputs[29].hide = True
	    group_input_002_5.outputs[30].hide = True
	    group_input_002_5.outputs[31].hide = True
	
	    #node Group Input.003
	    group_input_003_4 = scalp_hair.nodes.new("NodeGroupInput")
	    group_input_003_4.name = "Group Input.003"
	    group_input_003_4.outputs[0].hide = True
	    group_input_003_4.outputs[3].hide = True
	    group_input_003_4.outputs[4].hide = True
	    group_input_003_4.outputs[5].hide = True
	    group_input_003_4.outputs[6].hide = True
	    group_input_003_4.outputs[7].hide = True
	    group_input_003_4.outputs[8].hide = True
	    group_input_003_4.outputs[9].hide = True
	    group_input_003_4.outputs[10].hide = True
	    group_input_003_4.outputs[11].hide = True
	    group_input_003_4.outputs[12].hide = True
	    group_input_003_4.outputs[13].hide = True
	    group_input_003_4.outputs[14].hide = True
	    group_input_003_4.outputs[15].hide = True
	    group_input_003_4.outputs[16].hide = True
	    group_input_003_4.outputs[17].hide = True
	    group_input_003_4.outputs[18].hide = True
	    group_input_003_4.outputs[19].hide = True
	    group_input_003_4.outputs[20].hide = True
	    group_input_003_4.outputs[21].hide = True
	    group_input_003_4.outputs[22].hide = True
	    group_input_003_4.outputs[23].hide = True
	    group_input_003_4.outputs[24].hide = True
	    group_input_003_4.outputs[31].hide = True
	
	    #node Compare
	    compare_4 = scalp_hair.nodes.new("FunctionNodeCompare")
	    compare_4.name = "Compare"
	    compare_4.hide = True
	    compare_4.data_type = 'FLOAT'
	    compare_4.mode = 'ELEMENT'
	    compare_4.operation = 'NOT_EQUAL'
	    compare_4.inputs[1].hide = True
	    compare_4.inputs[2].hide = True
	    compare_4.inputs[3].hide = True
	    compare_4.inputs[4].hide = True
	    compare_4.inputs[5].hide = True
	    compare_4.inputs[6].hide = True
	    compare_4.inputs[7].hide = True
	    compare_4.inputs[8].hide = True
	    compare_4.inputs[9].hide = True
	    compare_4.inputs[10].hide = True
	    compare_4.inputs[11].hide = True
	    compare_4.inputs[12].hide = True
	    #B
	    compare_4.inputs[1].default_value = 0.0
	    #Epsilon
	    compare_4.inputs[12].default_value = 0.0
	
	    #node Switch
	    switch_5 = scalp_hair.nodes.new("GeometryNodeSwitch")
	    switch_5.name = "Switch"
	    switch_5.hide = True
	    switch_5.input_type = 'GEOMETRY'
	
	    #node Group Input.004
	    group_input_004_2 = scalp_hair.nodes.new("NodeGroupInput")
	    group_input_004_2.name = "Group Input.004"
	    group_input_004_2.outputs[0].hide = True
	    group_input_004_2.outputs[1].hide = True
	    group_input_004_2.outputs[2].hide = True
	    group_input_004_2.outputs[3].hide = True
	    group_input_004_2.outputs[4].hide = True
	    group_input_004_2.outputs[5].hide = True
	    group_input_004_2.outputs[6].hide = True
	    group_input_004_2.outputs[7].hide = True
	    group_input_004_2.outputs[8].hide = True
	    group_input_004_2.outputs[9].hide = True
	    group_input_004_2.outputs[10].hide = True
	    group_input_004_2.outputs[11].hide = True
	    group_input_004_2.outputs[12].hide = True
	    group_input_004_2.outputs[13].hide = True
	    group_input_004_2.outputs[15].hide = True
	    group_input_004_2.outputs[16].hide = True
	    group_input_004_2.outputs[17].hide = True
	    group_input_004_2.outputs[18].hide = True
	    group_input_004_2.outputs[19].hide = True
	    group_input_004_2.outputs[20].hide = True
	    group_input_004_2.outputs[21].hide = True
	    group_input_004_2.outputs[22].hide = True
	    group_input_004_2.outputs[23].hide = True
	    group_input_004_2.outputs[24].hide = True
	    group_input_004_2.outputs[25].hide = True
	    group_input_004_2.outputs[26].hide = True
	    group_input_004_2.outputs[27].hide = True
	    group_input_004_2.outputs[28].hide = True
	    group_input_004_2.outputs[29].hide = True
	    group_input_004_2.outputs[30].hide = True
	    group_input_004_2.outputs[31].hide = True
	
	    #node Reroute
	    reroute_7 = scalp_hair.nodes.new("NodeReroute")
	    reroute_7.name = "Reroute"
	    reroute_7.socket_idname = "NodeSocketGeometry"
	    #node Group Input.005
	    group_input_005_4 = scalp_hair.nodes.new("NodeGroupInput")
	    group_input_005_4.name = "Group Input.005"
	    group_input_005_4.outputs[0].hide = True
	    group_input_005_4.outputs[1].hide = True
	    group_input_005_4.outputs[2].hide = True
	    group_input_005_4.outputs[3].hide = True
	    group_input_005_4.outputs[4].hide = True
	    group_input_005_4.outputs[5].hide = True
	    group_input_005_4.outputs[6].hide = True
	    group_input_005_4.outputs[7].hide = True
	    group_input_005_4.outputs[8].hide = True
	    group_input_005_4.outputs[9].hide = True
	    group_input_005_4.outputs[10].hide = True
	    group_input_005_4.outputs[11].hide = True
	    group_input_005_4.outputs[12].hide = True
	    group_input_005_4.outputs[13].hide = True
	    group_input_005_4.outputs[14].hide = True
	    group_input_005_4.outputs[15].hide = True
	    group_input_005_4.outputs[16].hide = True
	    group_input_005_4.outputs[17].hide = True
	    group_input_005_4.outputs[18].hide = True
	    group_input_005_4.outputs[19].hide = True
	    group_input_005_4.outputs[20].hide = True
	    group_input_005_4.outputs[22].hide = True
	    group_input_005_4.outputs[23].hide = True
	    group_input_005_4.outputs[24].hide = True
	    group_input_005_4.outputs[25].hide = True
	    group_input_005_4.outputs[26].hide = True
	    group_input_005_4.outputs[27].hide = True
	    group_input_005_4.outputs[28].hide = True
	    group_input_005_4.outputs[29].hide = True
	    group_input_005_4.outputs[30].hide = True
	    group_input_005_4.outputs[31].hide = True
	
	    #node Compare.001
	    compare_001_2 = scalp_hair.nodes.new("FunctionNodeCompare")
	    compare_001_2.name = "Compare.001"
	    compare_001_2.hide = True
	    compare_001_2.data_type = 'FLOAT'
	    compare_001_2.mode = 'ELEMENT'
	    compare_001_2.operation = 'NOT_EQUAL'
	    compare_001_2.inputs[1].hide = True
	    compare_001_2.inputs[2].hide = True
	    compare_001_2.inputs[3].hide = True
	    compare_001_2.inputs[4].hide = True
	    compare_001_2.inputs[5].hide = True
	    compare_001_2.inputs[6].hide = True
	    compare_001_2.inputs[7].hide = True
	    compare_001_2.inputs[8].hide = True
	    compare_001_2.inputs[9].hide = True
	    compare_001_2.inputs[10].hide = True
	    compare_001_2.inputs[11].hide = True
	    compare_001_2.inputs[12].hide = True
	    #B
	    compare_001_2.inputs[1].default_value = 0.0
	    #Epsilon
	    compare_001_2.inputs[12].default_value = 0.0
	
	    #node Switch.001
	    switch_001_8 = scalp_hair.nodes.new("GeometryNodeSwitch")
	    switch_001_8.name = "Switch.001"
	    switch_001_8.hide = True
	    switch_001_8.input_type = 'GEOMETRY'
	
	    #node Reroute.001
	    reroute_001_4 = scalp_hair.nodes.new("NodeReroute")
	    reroute_001_4.name = "Reroute.001"
	    reroute_001_4.socket_idname = "NodeSocketGeometry"
	    #node Compare.002
	    compare_002_5 = scalp_hair.nodes.new("FunctionNodeCompare")
	    compare_002_5.name = "Compare.002"
	    compare_002_5.hide = True
	    compare_002_5.data_type = 'FLOAT'
	    compare_002_5.mode = 'ELEMENT'
	    compare_002_5.operation = 'NOT_EQUAL'
	    compare_002_5.inputs[1].hide = True
	    compare_002_5.inputs[2].hide = True
	    compare_002_5.inputs[3].hide = True
	    compare_002_5.inputs[4].hide = True
	    compare_002_5.inputs[5].hide = True
	    compare_002_5.inputs[6].hide = True
	    compare_002_5.inputs[7].hide = True
	    compare_002_5.inputs[8].hide = True
	    compare_002_5.inputs[9].hide = True
	    compare_002_5.inputs[10].hide = True
	    compare_002_5.inputs[11].hide = True
	    compare_002_5.inputs[12].hide = True
	    #B
	    compare_002_5.inputs[1].default_value = 0.0
	    #Epsilon
	    compare_002_5.inputs[12].default_value = 0.0
	
	    #node Switch.002
	    switch_002_2 = scalp_hair.nodes.new("GeometryNodeSwitch")
	    switch_002_2.name = "Switch.002"
	    switch_002_2.hide = True
	    switch_002_2.input_type = 'GEOMETRY'
	
	    #node Group Input.006
	    group_input_006_4 = scalp_hair.nodes.new("NodeGroupInput")
	    group_input_006_4.name = "Group Input.006"
	    group_input_006_4.outputs[0].hide = True
	    group_input_006_4.outputs[1].hide = True
	    group_input_006_4.outputs[2].hide = True
	    group_input_006_4.outputs[3].hide = True
	    group_input_006_4.outputs[4].hide = True
	    group_input_006_4.outputs[5].hide = True
	    group_input_006_4.outputs[6].hide = True
	    group_input_006_4.outputs[7].hide = True
	    group_input_006_4.outputs[8].hide = True
	    group_input_006_4.outputs[9].hide = True
	    group_input_006_4.outputs[10].hide = True
	    group_input_006_4.outputs[11].hide = True
	    group_input_006_4.outputs[12].hide = True
	    group_input_006_4.outputs[13].hide = True
	    group_input_006_4.outputs[14].hide = True
	    group_input_006_4.outputs[15].hide = True
	    group_input_006_4.outputs[16].hide = True
	    group_input_006_4.outputs[17].hide = True
	    group_input_006_4.outputs[18].hide = True
	    group_input_006_4.outputs[19].hide = True
	    group_input_006_4.outputs[20].hide = True
	    group_input_006_4.outputs[21].hide = True
	    group_input_006_4.outputs[22].hide = True
	    group_input_006_4.outputs[23].hide = True
	    group_input_006_4.outputs[24].hide = True
	    group_input_006_4.outputs[26].hide = True
	    group_input_006_4.outputs[27].hide = True
	    group_input_006_4.outputs[28].hide = True
	    group_input_006_4.outputs[29].hide = True
	    group_input_006_4.outputs[30].hide = True
	    group_input_006_4.outputs[31].hide = True
	
	    #node Set Material
	    set_material = scalp_hair.nodes.new("GeometryNodeSetMaterial")
	    set_material.name = "Set Material"
	    #Selection
	    set_material.inputs[1].default_value = True
	
	    #node Group Input.007
	    group_input_007_3 = scalp_hair.nodes.new("NodeGroupInput")
	    group_input_007_3.name = "Group Input.007"
	    group_input_007_3.outputs[0].hide = True
	    group_input_007_3.outputs[1].hide = True
	    group_input_007_3.outputs[2].hide = True
	    group_input_007_3.outputs[3].hide = True
	    group_input_007_3.outputs[4].hide = True
	    group_input_007_3.outputs[5].hide = True
	    group_input_007_3.outputs[6].hide = True
	    group_input_007_3.outputs[7].hide = True
	    group_input_007_3.outputs[8].hide = True
	    group_input_007_3.outputs[9].hide = True
	    group_input_007_3.outputs[10].hide = True
	    group_input_007_3.outputs[11].hide = True
	    group_input_007_3.outputs[12].hide = True
	    group_input_007_3.outputs[14].hide = True
	    group_input_007_3.outputs[15].hide = True
	    group_input_007_3.outputs[16].hide = True
	    group_input_007_3.outputs[17].hide = True
	    group_input_007_3.outputs[18].hide = True
	    group_input_007_3.outputs[19].hide = True
	    group_input_007_3.outputs[20].hide = True
	    group_input_007_3.outputs[21].hide = True
	    group_input_007_3.outputs[22].hide = True
	    group_input_007_3.outputs[23].hide = True
	    group_input_007_3.outputs[24].hide = True
	    group_input_007_3.outputs[25].hide = True
	    group_input_007_3.outputs[26].hide = True
	    group_input_007_3.outputs[27].hide = True
	    group_input_007_3.outputs[28].hide = True
	    group_input_007_3.outputs[29].hide = True
	    group_input_007_3.outputs[30].hide = True
	    group_input_007_3.outputs[31].hide = True
	
	    #node Hair to Surface Shape
	    hair_to_surface_shape_1 = scalp_hair.nodes.new("ShaderNodeFloatCurve")
	    hair_to_surface_shape_1.label = "Hair to Surface Shape"
	    hair_to_surface_shape_1.name = "Hair to Surface Shape"
	    #mapping settings
	    hair_to_surface_shape_1.mapping.extend = 'EXTRAPOLATED'
	    hair_to_surface_shape_1.mapping.tone = 'STANDARD'
	    hair_to_surface_shape_1.mapping.black_level = (0.0, 0.0, 0.0)
	    hair_to_surface_shape_1.mapping.white_level = (1.0, 1.0, 1.0)
	    hair_to_surface_shape_1.mapping.clip_min_x = 0.0
	    hair_to_surface_shape_1.mapping.clip_min_y = 0.0
	    hair_to_surface_shape_1.mapping.clip_max_x = 1.0
	    hair_to_surface_shape_1.mapping.clip_max_y = 1.0
	    hair_to_surface_shape_1.mapping.use_clip = True
	    #curve 0
	    hair_to_surface_shape_1_curve_0 = hair_to_surface_shape_1.mapping.curves[0]
	    hair_to_surface_shape_1_curve_0_point_0 = hair_to_surface_shape_1_curve_0.points[0]
	    hair_to_surface_shape_1_curve_0_point_0.location = (0.0, 0.0)
	    hair_to_surface_shape_1_curve_0_point_0.handle_type = 'AUTO'
	    hair_to_surface_shape_1_curve_0_point_1 = hair_to_surface_shape_1_curve_0.points[1]
	    hair_to_surface_shape_1_curve_0_point_1.location = (0.5, 1.0)
	    hair_to_surface_shape_1_curve_0_point_1.handle_type = 'AUTO'
	    hair_to_surface_shape_1_curve_0_point_2 = hair_to_surface_shape_1_curve_0.points.new(1.0, 0.013157878071069717)
	    hair_to_surface_shape_1_curve_0_point_2.handle_type = 'AUTO'
	    #update curve after changes
	    hair_to_surface_shape_1.mapping.update()
	    hair_to_surface_shape_1.inputs[0].hide = True
	    #Factor
	    hair_to_surface_shape_1.inputs[0].default_value = 1.0
	
	    #node Spline Parameter
	    spline_parameter_2 = scalp_hair.nodes.new("GeometryNodeSplineParameter")
	    spline_parameter_2.name = "Spline Parameter"
	    spline_parameter_2.outputs[1].hide = True
	    spline_parameter_2.outputs[2].hide = True
	
	    #node Frame.005
	    frame_005_2 = scalp_hair.nodes.new("NodeFrame")
	    frame_005_2.label = "Hair to Surface Shape"
	    frame_005_2.name = "Frame.005"
	    frame_005_2.label_size = 20
	    frame_005_2.shrink = True
	
	    #node Set Curve Radius
	    set_curve_radius = scalp_hair.nodes.new("GeometryNodeSetCurveRadius")
	    set_curve_radius.name = "Set Curve Radius"
	    set_curve_radius.inputs[1].hide = True
	    #Selection
	    set_curve_radius.inputs[1].default_value = True
	
	    #node Hair Shape
	    hair_shape = scalp_hair.nodes.new("ShaderNodeFloatCurve")
	    hair_shape.label = "Hair Shape"
	    hair_shape.name = "Hair Shape"
	    #mapping settings
	    hair_shape.mapping.extend = 'EXTRAPOLATED'
	    hair_shape.mapping.tone = 'STANDARD'
	    hair_shape.mapping.black_level = (0.0, 0.0, 0.0)
	    hair_shape.mapping.white_level = (1.0, 1.0, 1.0)
	    hair_shape.mapping.clip_min_x = 0.0
	    hair_shape.mapping.clip_min_y = 0.0
	    hair_shape.mapping.clip_max_x = 1.0
	    hair_shape.mapping.clip_max_y = 1.0
	    hair_shape.mapping.use_clip = True
	    #curve 0
	    hair_shape_curve_0 = hair_shape.mapping.curves[0]
	    hair_shape_curve_0_point_0 = hair_shape_curve_0.points[0]
	    hair_shape_curve_0_point_0.location = (0.0, 0.25)
	    hair_shape_curve_0_point_0.handle_type = 'AUTO'
	    hair_shape_curve_0_point_1 = hair_shape_curve_0.points[1]
	    hair_shape_curve_0_point_1.location = (0.024922097101807594, 1.0)
	    hair_shape_curve_0_point_1.handle_type = 'AUTO'
	    hair_shape_curve_0_point_2 = hair_shape_curve_0.points.new(0.5, 1.0)
	    hair_shape_curve_0_point_2.handle_type = 'AUTO'
	    hair_shape_curve_0_point_3 = hair_shape_curve_0.points.new(1.0, 0.0)
	    hair_shape_curve_0_point_3.handle_type = 'AUTO'
	    #update curve after changes
	    hair_shape.mapping.update()
	    #Factor
	    hair_shape.inputs[0].default_value = 1.0
	
	    #node Spline Parameter.001
	    spline_parameter_001_1 = scalp_hair.nodes.new("GeometryNodeSplineParameter")
	    spline_parameter_001_1.name = "Spline Parameter.001"
	    spline_parameter_001_1.outputs[1].hide = True
	    spline_parameter_001_1.outputs[2].hide = True
	
	    #node Frame
	    frame_5 = scalp_hair.nodes.new("NodeFrame")
	    frame_5.label = "Hair Shape"
	    frame_5.name = "Frame"
	    frame_5.label_size = 20
	    frame_5.shrink = True
	
	    #node Math
	    math_5 = scalp_hair.nodes.new("ShaderNodeMath")
	    math_5.name = "Math"
	    math_5.hide = True
	    math_5.operation = 'MULTIPLY'
	    math_5.use_clamp = False
	
	    #node Group Input.008
	    group_input_008_2 = scalp_hair.nodes.new("NodeGroupInput")
	    group_input_008_2.name = "Group Input.008"
	    group_input_008_2.outputs[0].hide = True
	    group_input_008_2.outputs[1].hide = True
	    group_input_008_2.outputs[2].hide = True
	    group_input_008_2.outputs[3].hide = True
	    group_input_008_2.outputs[4].hide = True
	    group_input_008_2.outputs[5].hide = True
	    group_input_008_2.outputs[7].hide = True
	    group_input_008_2.outputs[8].hide = True
	    group_input_008_2.outputs[9].hide = True
	    group_input_008_2.outputs[10].hide = True
	    group_input_008_2.outputs[11].hide = True
	    group_input_008_2.outputs[12].hide = True
	    group_input_008_2.outputs[13].hide = True
	    group_input_008_2.outputs[14].hide = True
	    group_input_008_2.outputs[15].hide = True
	    group_input_008_2.outputs[16].hide = True
	    group_input_008_2.outputs[17].hide = True
	    group_input_008_2.outputs[18].hide = True
	    group_input_008_2.outputs[19].hide = True
	    group_input_008_2.outputs[20].hide = True
	    group_input_008_2.outputs[21].hide = True
	    group_input_008_2.outputs[22].hide = True
	    group_input_008_2.outputs[23].hide = True
	    group_input_008_2.outputs[24].hide = True
	    group_input_008_2.outputs[25].hide = True
	    group_input_008_2.outputs[26].hide = True
	    group_input_008_2.outputs[27].hide = True
	    group_input_008_2.outputs[28].hide = True
	    group_input_008_2.outputs[29].hide = True
	    group_input_008_2.outputs[30].hide = True
	    group_input_008_2.outputs[31].hide = True
	
	    #node Group Input.009
	    group_input_009_1 = scalp_hair.nodes.new("NodeGroupInput")
	    group_input_009_1.name = "Group Input.009"
	    group_input_009_1.outputs[0].hide = True
	    group_input_009_1.outputs[1].hide = True
	    group_input_009_1.outputs[2].hide = True
	    group_input_009_1.outputs[3].hide = True
	    group_input_009_1.outputs[4].hide = True
	    group_input_009_1.outputs[5].hide = True
	    group_input_009_1.outputs[6].hide = True
	    group_input_009_1.outputs[7].hide = True
	    group_input_009_1.outputs[8].hide = True
	    group_input_009_1.outputs[9].hide = True
	    group_input_009_1.outputs[10].hide = True
	    group_input_009_1.outputs[11].hide = True
	    group_input_009_1.outputs[13].hide = True
	    group_input_009_1.outputs[14].hide = True
	    group_input_009_1.outputs[15].hide = True
	    group_input_009_1.outputs[16].hide = True
	    group_input_009_1.outputs[17].hide = True
	    group_input_009_1.outputs[18].hide = True
	    group_input_009_1.outputs[19].hide = True
	    group_input_009_1.outputs[20].hide = True
	    group_input_009_1.outputs[21].hide = True
	    group_input_009_1.outputs[22].hide = True
	    group_input_009_1.outputs[23].hide = True
	    group_input_009_1.outputs[24].hide = True
	    group_input_009_1.outputs[25].hide = True
	    group_input_009_1.outputs[26].hide = True
	    group_input_009_1.outputs[27].hide = True
	    group_input_009_1.outputs[28].hide = True
	    group_input_009_1.outputs[29].hide = True
	    group_input_009_1.outputs[30].hide = True
	    group_input_009_1.outputs[31].hide = True
	
	    #node Compare.003
	    compare_003_3 = scalp_hair.nodes.new("FunctionNodeCompare")
	    compare_003_3.name = "Compare.003"
	    compare_003_3.hide = True
	    compare_003_3.data_type = 'FLOAT'
	    compare_003_3.mode = 'ELEMENT'
	    compare_003_3.operation = 'EQUAL'
	    compare_003_3.inputs[1].hide = True
	    compare_003_3.inputs[2].hide = True
	    compare_003_3.inputs[3].hide = True
	    compare_003_3.inputs[4].hide = True
	    compare_003_3.inputs[5].hide = True
	    compare_003_3.inputs[6].hide = True
	    compare_003_3.inputs[7].hide = True
	    compare_003_3.inputs[8].hide = True
	    compare_003_3.inputs[9].hide = True
	    compare_003_3.inputs[10].hide = True
	    compare_003_3.inputs[11].hide = True
	    compare_003_3.inputs[12].hide = True
	    #B
	    compare_003_3.inputs[1].default_value = 0.0
	    #Epsilon
	    compare_003_3.inputs[12].default_value = 0.0
	
	    #node Group Input.010
	    group_input_010_1 = scalp_hair.nodes.new("NodeGroupInput")
	    group_input_010_1.name = "Group Input.010"
	    group_input_010_1.outputs[0].hide = True
	    group_input_010_1.outputs[1].hide = True
	    group_input_010_1.outputs[2].hide = True
	    group_input_010_1.outputs[3].hide = True
	    group_input_010_1.outputs[4].hide = True
	    group_input_010_1.outputs[5].hide = True
	    group_input_010_1.outputs[6].hide = True
	    group_input_010_1.outputs[8].hide = True
	    group_input_010_1.outputs[9].hide = True
	    group_input_010_1.outputs[10].hide = True
	    group_input_010_1.outputs[11].hide = True
	    group_input_010_1.outputs[12].hide = True
	    group_input_010_1.outputs[13].hide = True
	    group_input_010_1.outputs[14].hide = True
	    group_input_010_1.outputs[15].hide = True
	    group_input_010_1.outputs[16].hide = True
	    group_input_010_1.outputs[17].hide = True
	    group_input_010_1.outputs[18].hide = True
	    group_input_010_1.outputs[19].hide = True
	    group_input_010_1.outputs[20].hide = True
	    group_input_010_1.outputs[21].hide = True
	    group_input_010_1.outputs[22].hide = True
	    group_input_010_1.outputs[23].hide = True
	    group_input_010_1.outputs[24].hide = True
	    group_input_010_1.outputs[25].hide = True
	    group_input_010_1.outputs[26].hide = True
	    group_input_010_1.outputs[27].hide = True
	    group_input_010_1.outputs[28].hide = True
	    group_input_010_1.outputs[29].hide = True
	    group_input_010_1.outputs[30].hide = True
	    group_input_010_1.outputs[31].hide = True
	
	    #node Compare.004
	    compare_004_2 = scalp_hair.nodes.new("FunctionNodeCompare")
	    compare_004_2.name = "Compare.004"
	    compare_004_2.hide = True
	    compare_004_2.data_type = 'FLOAT'
	    compare_004_2.mode = 'ELEMENT'
	    compare_004_2.operation = 'EQUAL'
	    compare_004_2.inputs[1].hide = True
	    compare_004_2.inputs[2].hide = True
	    compare_004_2.inputs[3].hide = True
	    compare_004_2.inputs[4].hide = True
	    compare_004_2.inputs[5].hide = True
	    compare_004_2.inputs[6].hide = True
	    compare_004_2.inputs[7].hide = True
	    compare_004_2.inputs[8].hide = True
	    compare_004_2.inputs[9].hide = True
	    compare_004_2.inputs[10].hide = True
	    compare_004_2.inputs[11].hide = True
	    compare_004_2.inputs[12].hide = True
	    #B
	    compare_004_2.inputs[1].default_value = 0.0
	    #Epsilon
	    compare_004_2.inputs[12].default_value = 0.0
	
	    #node Switch.003
	    switch_003_3 = scalp_hair.nodes.new("GeometryNodeSwitch")
	    switch_003_3.name = "Switch.003"
	    switch_003_3.hide = True
	    switch_003_3.input_type = 'FLOAT'
	
	    #node Switch.004
	    switch_004_2 = scalp_hair.nodes.new("GeometryNodeSwitch")
	    switch_004_2.name = "Switch.004"
	    switch_004_2.hide = True
	    switch_004_2.input_type = 'FLOAT'
	
	
	
	
	    #Set parents
	    hair_to_surface_shape_1.parent = frame_005_2
	    spline_parameter_2.parent = frame_005_2
	    hair_shape.parent = frame_5
	    spline_parameter_001_1.parent = frame_5
	
	    #Set locations
	    group_input_8.location = (-340.0, 0.0)
	    group_output_12.location = (1616.8251953125, 234.0595245361328)
	    group_4.location = (228.75787353515625, 67.9648208618164)
	    group_001_3.location = (-128.67724609375, 42.553184509277344)
	    group_002_4.location = (585.469482421875, 110.74148559570312)
	    group_003_1.location = (917.6246337890625, 78.05233764648438)
	    group_input_001_5.location = (37.92403030395508, 0.0)
	    group_input_002_5.location = (414.29705810546875, 21.951507568359375)
	    group_input_003_4.location = (739.9785766601562, 11.820050239562988)
	    compare_4.location = (5.6065497398376465, 155.1045684814453)
	    switch_5.location = (8.98077392578125, 117.9559097290039)
	    group_input_004_2.location = (2.493638038635254, 214.44921875)
	    reroute_7.location = (-199.74411010742188, 106.61709594726562)
	    group_input_005_4.location = (717.9859619140625, 263.41796875)
	    compare_001_2.location = (717.58837890625, 200.69613647460938)
	    switch_001_8.location = (720.962646484375, 163.54747009277344)
	    reroute_001_4.location = (403.82379150390625, 155.0572052001953)
	    compare_002_5.location = (1051.646240234375, 200.69613647460938)
	    switch_002_2.location = (1055.0205078125, 163.54747009277344)
	    group_input_006_4.location = (1048.72900390625, 265.1065368652344)
	    set_material.location = (1234.58837890625, 210.2534637451172)
	    group_input_007_3.location = (1074.676513671875, 130.0436248779297)
	    hair_to_surface_shape_1.location = (30.038330078125, -39.822479248046875)
	    spline_parameter_2.location = (34.8480224609375, -332.90185546875)
	    frame_005_2.location = (-576.0, -291.0)
	    set_curve_radius.location = (1439.8720703125, 233.61318969726562)
	    hair_shape.location = (30.18115234375, -40.051971435546875)
	    spline_parameter_001_1.location = (32.83966064453125, -357.61944580078125)
	    frame_5.location = (520.0, -262.0)
	    math_5.location = (1306.6318359375, -276.3992919921875)
	    group_input_008_2.location = (1303.177001953125, -214.787841796875)
	    group_input_009_1.location = (231.09051513671875, -244.294677734375)
	    compare_003_3.location = (230.26451110839844, -307.5337829589844)
	    group_input_010_1.location = (1307.3897705078125, -383.3990478515625)
	    compare_004_2.location = (1310.77685546875, -351.794677734375)
	    switch_003_3.location = (230.26492309570312, -344.12200927734375)
	    switch_004_2.location = (1310.7784423828125, -314.61474609375)
	
	    #Set dimensions
	    group_input_8.width, group_input_8.height = 140.0, 100.0
	    group_output_12.width, group_output_12.height = 140.0, 100.0
	    group_4.width, group_4.height = 175.41641235351562, 100.0
	    group_001_3.width, group_001_3.height = 140.0, 100.0
	    group_002_4.width, group_002_4.height = 140.0, 100.0
	    group_003_1.width, group_003_1.height = 140.0, 100.0
	    group_input_001_5.width, group_input_001_5.height = 140.0, 100.0
	    group_input_002_5.width, group_input_002_5.height = 140.0, 100.0
	    group_input_003_4.width, group_input_003_4.height = 140.0, 100.0
	    compare_4.width, compare_4.height = 140.0, 100.0
	    switch_5.width, switch_5.height = 140.0, 100.0
	    group_input_004_2.width, group_input_004_2.height = 140.0, 100.0
	    reroute_7.width, reroute_7.height = 10.0, 100.0
	    group_input_005_4.width, group_input_005_4.height = 140.0, 100.0
	    compare_001_2.width, compare_001_2.height = 140.0, 100.0
	    switch_001_8.width, switch_001_8.height = 140.0, 100.0
	    reroute_001_4.width, reroute_001_4.height = 10.0, 100.0
	    compare_002_5.width, compare_002_5.height = 140.0, 100.0
	    switch_002_2.width, switch_002_2.height = 140.0, 100.0
	    group_input_006_4.width, group_input_006_4.height = 140.0, 100.0
	    set_material.width, set_material.height = 140.0, 100.0
	    group_input_007_3.width, group_input_007_3.height = 140.0, 100.0
	    hair_to_surface_shape_1.width, hair_to_surface_shape_1.height = 700.0, 100.0
	    spline_parameter_2.width, spline_parameter_2.height = 140.0, 100.0
	    frame_005_2.width, frame_005_2.height = 760.0, 415.0
	    set_curve_radius.width, set_curve_radius.height = 140.0, 100.0
	    hair_shape.width, hair_shape.height = 700.0, 100.0
	    spline_parameter_001_1.width, spline_parameter_001_1.height = 140.0, 100.0
	    frame_5.width, frame_5.height = 760.0, 440.0
	    math_5.width, math_5.height = 140.0, 100.0
	    group_input_008_2.width, group_input_008_2.height = 140.0, 100.0
	    group_input_009_1.width, group_input_009_1.height = 140.0, 100.0
	    compare_003_3.width, compare_003_3.height = 140.0, 100.0
	    group_input_010_1.width, group_input_010_1.height = 140.0, 100.0
	    compare_004_2.width, compare_004_2.height = 140.0, 100.0
	    switch_003_3.width, switch_003_3.height = 140.0, 100.0
	    switch_004_2.width, switch_004_2.height = 140.0, 100.0
	
	    #initialize scalp_hair links
	    #group_input_8.Geometry -> group_001_3.Geometry
	    scalp_hair.links.new(group_input_8.outputs[0], group_001_3.inputs[0])
	    #group_4.Geometry -> group_002_4.Geometry
	    scalp_hair.links.new(group_4.outputs[0], group_002_4.inputs[0])
	    #group_input_001_5.Surface -> group_4.Surface
	    scalp_hair.links.new(group_input_001_5.outputs[1], group_4.inputs[1])
	    #group_input_001_5.Surface -> group_4.Surface
	    scalp_hair.links.new(group_input_001_5.outputs[2], group_4.inputs[2])
	    #group_input_001_5.Guide Curve -> group_4.Guide Curve
	    scalp_hair.links.new(group_input_001_5.outputs[3], group_4.inputs[3])
	    #group_input_001_5.Guide Curve -> group_4.Guide Curve
	    scalp_hair.links.new(group_input_001_5.outputs[4], group_4.inputs[4])
	    #group_input_001_5.Control Points -> group_4.Control Points
	    scalp_hair.links.new(group_input_001_5.outputs[5], group_4.inputs[5])
	    #group_input_001_5.Sample Surface Count -> group_4.Sample Surface Count
	    scalp_hair.links.new(group_input_001_5.outputs[9], group_4.inputs[7])
	    #group_input_001_5.Sample Surface Distance -> group_4.Sample Surface Distance
	    scalp_hair.links.new(group_input_001_5.outputs[10], group_4.inputs[8])
	    #group_input_001_5.Max Influence Distance -> group_4.Max Influence Distance
	    scalp_hair.links.new(group_input_001_5.outputs[11], group_4.inputs[9])
	    #group_input_8.Duplicate Amount -> group_001_3.Amount
	    scalp_hair.links.new(group_input_8.outputs[14], group_001_3.inputs[1])
	    #group_input_8.Duplicate Viewport Amount -> group_001_3.Viewport Amount
	    scalp_hair.links.new(group_input_8.outputs[15], group_001_3.inputs[2])
	    #group_input_8.Duplicate Radius -> group_001_3.Radius
	    scalp_hair.links.new(group_input_8.outputs[16], group_001_3.inputs[3])
	    #group_input_8.Duplicate Distribution Shape -> group_001_3.Distribution Shape
	    scalp_hair.links.new(group_input_8.outputs[17], group_001_3.inputs[4])
	    #group_input_8.Duplicate Tip Roundness -> group_001_3.Tip Roundness
	    scalp_hair.links.new(group_input_8.outputs[18], group_001_3.inputs[5])
	    #group_input_8.Duplicate Even Thickness -> group_001_3.Even Thickness
	    scalp_hair.links.new(group_input_8.outputs[19], group_001_3.inputs[6])
	    #group_input_8.Duplicate Seed -> group_001_3.Seed
	    scalp_hair.links.new(group_input_8.outputs[20], group_001_3.inputs[7])
	    #group_input_002_5.Frizz Factor -> group_002_4.Factor
	    scalp_hair.links.new(group_input_002_5.outputs[21], group_002_4.inputs[2])
	    #group_input_002_5.Frizz Distance -> group_002_4.Distance
	    scalp_hair.links.new(group_input_002_5.outputs[22], group_002_4.inputs[3])
	    #group_input_002_5.Frizz Shape -> group_002_4.Shape
	    scalp_hair.links.new(group_input_002_5.outputs[23], group_002_4.inputs[4])
	    #group_input_002_5.Frizz Seed -> group_002_4.Seed
	    scalp_hair.links.new(group_input_002_5.outputs[24], group_002_4.inputs[5])
	    #group_input_003_4.Noise Surface Offset -> group_003_1.Surface Offset
	    scalp_hair.links.new(group_input_003_4.outputs[25], group_003_1.inputs[3])
	    #group_input_003_4.Noise Scale -> group_003_1.Scale
	    scalp_hair.links.new(group_input_003_4.outputs[26], group_003_1.inputs[4])
	    #group_input_003_4.Noise Detail -> group_003_1.Detail
	    scalp_hair.links.new(group_input_003_4.outputs[27], group_003_1.inputs[5])
	    #group_input_003_4.Noise Roughness -> group_003_1.Roughness
	    scalp_hair.links.new(group_input_003_4.outputs[28], group_003_1.inputs[6])
	    #group_input_003_4.Noise Lacunarity -> group_003_1.Lacunarity
	    scalp_hair.links.new(group_input_003_4.outputs[29], group_003_1.inputs[7])
	    #group_input_003_4.Noise Distortion -> group_003_1.Distortion
	    scalp_hair.links.new(group_input_003_4.outputs[30], group_003_1.inputs[8])
	    #group_input_003_4.Surface -> group_003_1.Surface
	    scalp_hair.links.new(group_input_003_4.outputs[2], group_003_1.inputs[2])
	    #group_input_003_4.Surface -> group_003_1.Surface
	    scalp_hair.links.new(group_input_003_4.outputs[1], group_003_1.inputs[1])
	    #group_input_004_2.Duplicate Amount -> compare_4.A
	    scalp_hair.links.new(group_input_004_2.outputs[14], compare_4.inputs[0])
	    #compare_4.Result -> switch_5.Switch
	    scalp_hair.links.new(compare_4.outputs[0], switch_5.inputs[0])
	    #reroute_7.Output -> switch_5.False
	    scalp_hair.links.new(reroute_7.outputs[0], switch_5.inputs[1])
	    #group_001_3.Geometry -> switch_5.True
	    scalp_hair.links.new(group_001_3.outputs[0], switch_5.inputs[2])
	    #group_input_8.Geometry -> reroute_7.Input
	    scalp_hair.links.new(group_input_8.outputs[0], reroute_7.inputs[0])
	    #switch_5.Output -> group_4.Geometry
	    scalp_hair.links.new(switch_5.outputs[0], group_4.inputs[0])
	    #compare_001_2.Result -> switch_001_8.Switch
	    scalp_hair.links.new(compare_001_2.outputs[0], switch_001_8.inputs[0])
	    #group_002_4.Geometry -> switch_001_8.True
	    scalp_hair.links.new(group_002_4.outputs[0], switch_001_8.inputs[2])
	    #group_input_005_4.Frizz Factor -> compare_001_2.A
	    scalp_hair.links.new(group_input_005_4.outputs[21], compare_001_2.inputs[0])
	    #reroute_001_4.Output -> switch_001_8.False
	    scalp_hair.links.new(reroute_001_4.outputs[0], switch_001_8.inputs[1])
	    #group_4.Geometry -> reroute_001_4.Input
	    scalp_hair.links.new(group_4.outputs[0], reroute_001_4.inputs[0])
	    #switch_001_8.Output -> group_003_1.Geometry
	    scalp_hair.links.new(switch_001_8.outputs[0], group_003_1.inputs[0])
	    #compare_002_5.Result -> switch_002_2.Switch
	    scalp_hair.links.new(compare_002_5.outputs[0], switch_002_2.inputs[0])
	    #switch_001_8.Output -> switch_002_2.False
	    scalp_hair.links.new(switch_001_8.outputs[0], switch_002_2.inputs[1])
	    #group_003_1.Geometry -> switch_002_2.True
	    scalp_hair.links.new(group_003_1.outputs[0], switch_002_2.inputs[2])
	    #group_input_006_4.Noise Surface Offset -> compare_002_5.A
	    scalp_hair.links.new(group_input_006_4.outputs[25], compare_002_5.inputs[0])
	    #set_curve_radius.Curve -> group_output_12.Geometry
	    scalp_hair.links.new(set_curve_radius.outputs[0], group_output_12.inputs[0])
	    #switch_002_2.Output -> set_material.Geometry
	    scalp_hair.links.new(switch_002_2.outputs[0], set_material.inputs[0])
	    #group_input_007_3.Material -> set_material.Material
	    scalp_hair.links.new(group_input_007_3.outputs[13], set_material.inputs[2])
	    #spline_parameter_2.Factor -> hair_to_surface_shape_1.Value
	    scalp_hair.links.new(spline_parameter_2.outputs[0], hair_to_surface_shape_1.inputs[1])
	    #set_material.Geometry -> set_curve_radius.Curve
	    scalp_hair.links.new(set_material.outputs[0], set_curve_radius.inputs[0])
	    #spline_parameter_001_1.Factor -> hair_shape.Value
	    scalp_hair.links.new(spline_parameter_001_1.outputs[0], hair_shape.inputs[1])
	    #math_5.Value -> set_curve_radius.Radius
	    scalp_hair.links.new(math_5.outputs[0], set_curve_radius.inputs[2])
	    #group_input_001_5.Hair Shape Offset -> group_4.Hair Shape Offset
	    scalp_hair.links.new(group_input_001_5.outputs[8], group_4.inputs[6])
	    #group_input_009_1.Offset from Surface -> compare_003_3.A
	    scalp_hair.links.new(group_input_009_1.outputs[12], compare_003_3.inputs[0])
	    #group_input_010_1.Hair Shape Curve -> compare_004_2.A
	    scalp_hair.links.new(group_input_010_1.outputs[7], compare_004_2.inputs[0])
	    #compare_003_3.Result -> switch_003_3.Switch
	    scalp_hair.links.new(compare_003_3.outputs[0], switch_003_3.inputs[0])
	    #group_input_009_1.Offset from Surface -> switch_003_3.False
	    scalp_hair.links.new(group_input_009_1.outputs[12], switch_003_3.inputs[1])
	    #hair_to_surface_shape_1.Value -> switch_003_3.True
	    scalp_hair.links.new(hair_to_surface_shape_1.outputs[0], switch_003_3.inputs[2])
	    #switch_003_3.Output -> group_4.Offset from Surface
	    scalp_hair.links.new(switch_003_3.outputs[0], group_4.inputs[10])
	    #compare_004_2.Result -> switch_004_2.Switch
	    scalp_hair.links.new(compare_004_2.outputs[0], switch_004_2.inputs[0])
	    #group_input_010_1.Hair Shape Curve -> switch_004_2.False
	    scalp_hair.links.new(group_input_010_1.outputs[7], switch_004_2.inputs[1])
	    #hair_shape.Value -> switch_004_2.True
	    scalp_hair.links.new(hair_shape.outputs[0], switch_004_2.inputs[2])
	    #switch_004_2.Output -> math_5.Value
	    scalp_hair.links.new(switch_004_2.outputs[0], math_5.inputs[1])
	    #group_input_008_2.Hair Radius -> math_5.Value
	    scalp_hair.links.new(group_input_008_2.outputs[6], math_5.inputs[0])
	    return scalp_hair
	
	scalp_hair = scalp_hair_node_group()
	
	#initialize hair_card node group
	def hair_card_node_group():
	    hair_card = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "HAIR_CARD")
	
	    hair_card.color_tag = 'NONE'
	    hair_card.description = ""
	    hair_card.default_group_node_width = 140
	    
	
	    hair_card.is_modifier = True
	
	    #hair_card interface
	    #Socket Geometry
	    geometry_socket_14 = hair_card.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_14.attribute_domain = 'POINT'
	
	    #Socket Geometry
	    geometry_socket_15 = hair_card.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_15.attribute_domain = 'POINT'
	
	    #Socket Material
	    material_socket_1 = hair_card.interface.new_socket(name = "Material", in_out='INPUT', socket_type = 'NodeSocketMaterial')
	    material_socket_1.attribute_domain = 'POINT'
	
	    #Socket Curve Radius
	    curve_radius_socket = hair_card.interface.new_socket(name = "Curve Radius", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    curve_radius_socket.default_value = 1.0
	    curve_radius_socket.min_value = 0.0
	    curve_radius_socket.max_value = 3.4028234663852886e+38
	    curve_radius_socket.subtype = 'DISTANCE'
	    curve_radius_socket.attribute_domain = 'POINT'
	    curve_radius_socket.hide_value = True
	    curve_radius_socket.hide_in_modifier = True
	
	    #Socket Resolution
	    resolution_socket = hair_card.interface.new_socket(name = "Resolution", in_out='INPUT', socket_type = 'NodeSocketInt')
	    resolution_socket.default_value = 0
	    resolution_socket.min_value = 2
	    resolution_socket.max_value = 512
	    resolution_socket.subtype = 'NONE'
	    resolution_socket.attribute_domain = 'POINT'
	
	    #Socket Width
	    width_socket = hair_card.interface.new_socket(name = "Width", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    width_socket.default_value = 0.10000000149011612
	    width_socket.min_value = 0.0
	    width_socket.max_value = 3.4028234663852886e+38
	    width_socket.subtype = 'DISTANCE'
	    width_socket.attribute_domain = 'POINT'
	
	    #Socket Angle
	    angle_socket = hair_card.interface.new_socket(name = "Angle", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    angle_socket.default_value = 0.0
	    angle_socket.min_value = -90.0
	    angle_socket.max_value = 90.0
	    angle_socket.subtype = 'ANGLE'
	    angle_socket.attribute_domain = 'POINT'
	
	
	    #initialize hair_card nodes
	    #node Group Input
	    group_input_9 = hair_card.nodes.new("NodeGroupInput")
	    group_input_9.name = "Group Input"
	    group_input_9.outputs[1].hide = True
	    group_input_9.outputs[2].hide = True
	    group_input_9.outputs[5].hide = True
	    group_input_9.outputs[6].hide = True
	
	    #node Group Output
	    group_output_13 = hair_card.nodes.new("NodeGroupOutput")
	    group_output_13.name = "Group Output"
	    group_output_13.is_active_output = True
	
	    #node Curve to Mesh
	    curve_to_mesh = hair_card.nodes.new("GeometryNodeCurveToMesh")
	    curve_to_mesh.name = "Curve to Mesh"
	    curve_to_mesh.hide = True
	    #Fill Caps
	    curve_to_mesh.inputs[2].default_value = False
	
	    #node Capture Attribute
	    capture_attribute_2 = hair_card.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_2.name = "Capture Attribute"
	    capture_attribute_2.hide = True
	    capture_attribute_2.active_index = 0
	    capture_attribute_2.capture_items.clear()
	    capture_attribute_2.capture_items.new('FLOAT', "Factor")
	    capture_attribute_2.capture_items["Factor"].data_type = 'FLOAT'
	    capture_attribute_2.domain = 'POINT'
	
	    #node Spline Parameter
	    spline_parameter_3 = hair_card.nodes.new("GeometryNodeSplineParameter")
	    spline_parameter_3.name = "Spline Parameter"
	    spline_parameter_3.hide = True
	
	    #node Combine XYZ
	    combine_xyz_1 = hair_card.nodes.new("ShaderNodeCombineXYZ")
	    combine_xyz_1.name = "Combine XYZ"
	    combine_xyz_1.hide = True
	    #Z
	    combine_xyz_1.inputs[2].default_value = 0.0
	
	    #node Store Named Attribute
	    store_named_attribute_2 = hair_card.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_2.name = "Store Named Attribute"
	    store_named_attribute_2.data_type = 'FLOAT2'
	    store_named_attribute_2.domain = 'CORNER'
	    #Selection
	    store_named_attribute_2.inputs[1].default_value = True
	    #Name
	    store_named_attribute_2.inputs[2].default_value = "hair_card_UV"
	
	    #node Set Material
	    set_material_1 = hair_card.nodes.new("GeometryNodeSetMaterial")
	    set_material_1.name = "Set Material"
	    set_material_1.hide = True
	    #Selection
	    set_material_1.inputs[1].default_value = True
	
	    #node Capture Attribute.002
	    capture_attribute_002_2 = hair_card.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_002_2.name = "Capture Attribute.002"
	    capture_attribute_002_2.hide = True
	    capture_attribute_002_2.active_index = 0
	    capture_attribute_002_2.capture_items.clear()
	    capture_attribute_002_2.capture_items.new('FLOAT', "Factor")
	    capture_attribute_002_2.capture_items["Factor"].data_type = 'FLOAT'
	    capture_attribute_002_2.domain = 'POINT'
	
	    #node Reroute
	    reroute_8 = hair_card.nodes.new("NodeReroute")
	    reroute_8.name = "Reroute"
	    reroute_8.socket_idname = "NodeSocketFloat"
	    #node Group Input.001
	    group_input_001_6 = hair_card.nodes.new("NodeGroupInput")
	    group_input_001_6.name = "Group Input.001"
	    group_input_001_6.outputs[0].hide = True
	    group_input_001_6.outputs[2].hide = True
	    group_input_001_6.outputs[3].hide = True
	    group_input_001_6.outputs[4].hide = True
	    group_input_001_6.outputs[5].hide = True
	    group_input_001_6.outputs[6].hide = True
	
	    #node Reroute.001
	    reroute_001_5 = hair_card.nodes.new("NodeReroute")
	    reroute_001_5.name = "Reroute.001"
	    reroute_001_5.socket_idname = "NodeSocketFloatDistance"
	    #node Resample Curve
	    resample_curve_1 = hair_card.nodes.new("GeometryNodeResampleCurve")
	    resample_curve_1.name = "Resample Curve"
	    resample_curve_1.hide = True
	    resample_curve_1.keep_last_segment = False
	    resample_curve_1.mode = 'COUNT'
	    #Selection
	    resample_curve_1.inputs[1].default_value = True
	
	    #node Switch
	    switch_6 = hair_card.nodes.new("GeometryNodeSwitch")
	    switch_6.name = "Switch"
	    switch_6.hide = True
	    switch_6.input_type = 'GEOMETRY'
	
	    #node Group Input.002
	    group_input_002_6 = hair_card.nodes.new("NodeGroupInput")
	    group_input_002_6.name = "Group Input.002"
	    group_input_002_6.outputs[0].hide = True
	    group_input_002_6.outputs[1].hide = True
	    group_input_002_6.outputs[2].hide = True
	    group_input_002_6.outputs[4].hide = True
	    group_input_002_6.outputs[5].hide = True
	    group_input_002_6.outputs[6].hide = True
	
	    #node Compare
	    compare_5 = hair_card.nodes.new("FunctionNodeCompare")
	    compare_5.name = "Compare"
	    compare_5.hide = True
	    compare_5.data_type = 'INT'
	    compare_5.mode = 'ELEMENT'
	    compare_5.operation = 'LESS_THAN'
	    #B_INT
	    compare_5.inputs[3].default_value = 2
	
	    #node Reroute.002
	    reroute_002_3 = hair_card.nodes.new("NodeReroute")
	    reroute_002_3.name = "Reroute.002"
	    reroute_002_3.socket_idname = "NodeSocketGeometry"
	    #node Group Input.003
	    group_input_003_5 = hair_card.nodes.new("NodeGroupInput")
	    group_input_003_5.name = "Group Input.003"
	    group_input_003_5.outputs[0].hide = True
	    group_input_003_5.outputs[1].hide = True
	    group_input_003_5.outputs[2].hide = True
	    group_input_003_5.outputs[3].hide = True
	    group_input_003_5.outputs[4].hide = True
	    group_input_003_5.outputs[6].hide = True
	
	    #node Points
	    points = hair_card.nodes.new("GeometryNodePoints")
	    points.name = "Points"
	    points.hide = True
	    #Count
	    points.inputs[0].default_value = 1
	    #Position
	    points.inputs[1].default_value = (0.0, 0.0, 0.0)
	    #Radius
	    points.inputs[2].default_value = 0.10000000149011612
	
	    #node Points.001
	    points_001 = hair_card.nodes.new("GeometryNodePoints")
	    points_001.name = "Points.001"
	    points_001.hide = True
	    #Count
	    points_001.inputs[0].default_value = 1
	    #Radius
	    points_001.inputs[2].default_value = 0.10000000149011612
	
	    #node Points.002
	    points_002 = hair_card.nodes.new("GeometryNodePoints")
	    points_002.name = "Points.002"
	    points_002.hide = True
	    #Count
	    points_002.inputs[0].default_value = 1
	    #Radius
	    points_002.inputs[2].default_value = 0.10000000149011612
	
	    #node Points to Curves
	    points_to_curves = hair_card.nodes.new("GeometryNodePointsToCurves")
	    points_to_curves.name = "Points to Curves"
	    points_to_curves.hide = True
	    #Curve Group ID
	    points_to_curves.inputs[1].default_value = 0
	    #Weight
	    points_to_curves.inputs[2].default_value = 0.0
	
	    #node Join Geometry
	    join_geometry_2 = hair_card.nodes.new("GeometryNodeJoinGeometry")
	    join_geometry_2.name = "Join Geometry"
	    join_geometry_2.hide = True
	
	    #node Vector Rotate
	    vector_rotate_1 = hair_card.nodes.new("ShaderNodeVectorRotate")
	    vector_rotate_1.name = "Vector Rotate"
	    vector_rotate_1.hide = True
	    vector_rotate_1.invert = False
	    vector_rotate_1.rotation_type = 'AXIS_ANGLE'
	    #Center
	    vector_rotate_1.inputs[1].default_value = (0.0, 0.0, 0.0)
	    #Axis
	    vector_rotate_1.inputs[2].default_value = (0.0, 0.0, 1.0)
	
	    #node Combine XYZ.003
	    combine_xyz_003 = hair_card.nodes.new("ShaderNodeCombineXYZ")
	    combine_xyz_003.name = "Combine XYZ.003"
	    combine_xyz_003.hide = True
	    #Y
	    combine_xyz_003.inputs[1].default_value = 0.0
	    #Z
	    combine_xyz_003.inputs[2].default_value = 0.0
	
	    #node Vector Math
	    vector_math_6 = hair_card.nodes.new("ShaderNodeVectorMath")
	    vector_math_6.name = "Vector Math"
	    vector_math_6.hide = True
	    vector_math_6.operation = 'MULTIPLY'
	    #Vector_001
	    vector_math_6.inputs[1].default_value = (-1.0, 1.0, 1.0)
	
	    #node Set Curve Radius
	    set_curve_radius_1 = hair_card.nodes.new("GeometryNodeSetCurveRadius")
	    set_curve_radius_1.name = "Set Curve Radius"
	    set_curve_radius_1.hide = True
	    #Selection
	    set_curve_radius_1.inputs[1].default_value = True
	
	    #node Group Input.004
	    group_input_004_3 = hair_card.nodes.new("NodeGroupInput")
	    group_input_004_3.name = "Group Input.004"
	    group_input_004_3.outputs[0].hide = True
	    group_input_004_3.outputs[1].hide = True
	    group_input_004_3.outputs[3].hide = True
	    group_input_004_3.outputs[4].hide = True
	    group_input_004_3.outputs[5].hide = True
	    group_input_004_3.outputs[6].hide = True
	
	    #node Reroute.003
	    reroute_003_3 = hair_card.nodes.new("NodeReroute")
	    reroute_003_3.name = "Reroute.003"
	    reroute_003_3.socket_idname = "NodeSocketFloatDistance"
	    #node Reroute.004
	    reroute_004_4 = hair_card.nodes.new("NodeReroute")
	    reroute_004_4.name = "Reroute.004"
	    reroute_004_4.socket_idname = "NodeSocketFloatDistance"
	
	
	
	
	    #Set locations
	    group_input_9.location = (-340.0, 0.0)
	    group_output_13.location = (1204.581787109375, 58.388336181640625)
	    curve_to_mesh.location = (717.3101196289062, -30.657630920410156)
	    capture_attribute_2.location = (532.3717651367188, -13.901289939880371)
	    spline_parameter_3.location = (329.8749084472656, -144.0863800048828)
	    combine_xyz_1.location = (717.11865234375, -93.34249114990234)
	    store_named_attribute_2.location = (883.1387329101562, 66.61811828613281)
	    set_material_1.location = (1044.3658447265625, 32.40200424194336)
	    capture_attribute_002_2.location = (534.5352783203125, -74.45401000976562)
	    reroute_8.location = (496.6486511230469, -141.76992797851562)
	    group_input_001_6.location = (1041.4315185546875, 1.5365350246429443)
	    reroute_001_5.location = (-187.22337341308594, -77.96863555908203)
	    resample_curve_1.location = (-5.360104560852051, -28.505603790283203)
	    switch_6.location = (-5.43592643737793, 6.486942291259766)
	    group_input_002_6.location = (-336.779052734375, 70.9764633178711)
	    compare_5.location = (-8.656487464904785, 41.045326232910156)
	    reroute_002_3.location = (-99.20211791992188, -32.54893493652344)
	    group_input_003_5.location = (-339.9999694824219, -103.2856674194336)
	    points.location = (156.70631408691406, -123.0439224243164)
	    points_001.location = (156.70632934570312, -81.72965240478516)
	    points_002.location = (158.99679565429688, -168.9486846923828)
	    points_to_curves.location = (321.6205749511719, -74.84392547607422)
	    join_geometry_2.location = (328.4919128417969, -106.97728729248047)
	    vector_rotate_1.location = (-8.371872901916504, -97.79617309570312)
	    combine_xyz_003.location = (-168.62094116210938, -79.79706573486328)
	    vector_math_6.location = (-6.081514358520508, -135.33193969726562)
	    set_curve_radius_1.location = (320.7674560546875, -1.0603179931640625)
	    group_input_004_3.location = (-334.8185729980469, 133.8203125)
	    reroute_003_3.location = (237.70924377441406, 97.4658203125)
	    reroute_004_4.location = (241.74778747558594, -21.909408569335938)
	
	    #Set dimensions
	    group_input_9.width, group_input_9.height = 140.0, 100.0
	    group_output_13.width, group_output_13.height = 140.0, 100.0
	    curve_to_mesh.width, curve_to_mesh.height = 140.0, 100.0
	    capture_attribute_2.width, capture_attribute_2.height = 140.0, 100.0
	    spline_parameter_3.width, spline_parameter_3.height = 140.0, 100.0
	    combine_xyz_1.width, combine_xyz_1.height = 140.0, 100.0
	    store_named_attribute_2.width, store_named_attribute_2.height = 140.0, 100.0
	    set_material_1.width, set_material_1.height = 140.0, 100.0
	    capture_attribute_002_2.width, capture_attribute_002_2.height = 140.0, 100.0
	    reroute_8.width, reroute_8.height = 100.0, 100.0
	    group_input_001_6.width, group_input_001_6.height = 140.0, 100.0
	    reroute_001_5.width, reroute_001_5.height = 100.0, 100.0
	    resample_curve_1.width, resample_curve_1.height = 140.0, 100.0
	    switch_6.width, switch_6.height = 140.0, 100.0
	    group_input_002_6.width, group_input_002_6.height = 140.0, 100.0
	    compare_5.width, compare_5.height = 140.0, 100.0
	    reroute_002_3.width, reroute_002_3.height = 100.0, 100.0
	    group_input_003_5.width, group_input_003_5.height = 140.0, 100.0
	    points.width, points.height = 140.0, 100.0
	    points_001.width, points_001.height = 140.0, 100.0
	    points_002.width, points_002.height = 140.0, 100.0
	    points_to_curves.width, points_to_curves.height = 140.0, 100.0
	    join_geometry_2.width, join_geometry_2.height = 140.0, 100.0
	    vector_rotate_1.width, vector_rotate_1.height = 140.0, 100.0
	    combine_xyz_003.width, combine_xyz_003.height = 140.0, 100.0
	    vector_math_6.width, vector_math_6.height = 140.0, 100.0
	    set_curve_radius_1.width, set_curve_radius_1.height = 140.0, 100.0
	    group_input_004_3.width, group_input_004_3.height = 140.0, 100.0
	    reroute_003_3.width, reroute_003_3.height = 100.0, 100.0
	    reroute_004_4.width, reroute_004_4.height = 100.0, 100.0
	
	    #initialize hair_card links
	    #set_material_1.Geometry -> group_output_13.Geometry
	    hair_card.links.new(set_material_1.outputs[0], group_output_13.inputs[0])
	    #capture_attribute_2.Geometry -> curve_to_mesh.Curve
	    hair_card.links.new(capture_attribute_2.outputs[0], curve_to_mesh.inputs[0])
	    #reroute_8.Output -> capture_attribute_2.Factor
	    hair_card.links.new(reroute_8.outputs[0], capture_attribute_2.inputs[1])
	    #capture_attribute_2.Factor -> combine_xyz_1.X
	    hair_card.links.new(capture_attribute_2.outputs[1], combine_xyz_1.inputs[0])
	    #curve_to_mesh.Mesh -> store_named_attribute_2.Geometry
	    hair_card.links.new(curve_to_mesh.outputs[0], store_named_attribute_2.inputs[0])
	    #combine_xyz_1.Vector -> store_named_attribute_2.Value
	    hair_card.links.new(combine_xyz_1.outputs[0], store_named_attribute_2.inputs[3])
	    #store_named_attribute_2.Geometry -> set_material_1.Geometry
	    hair_card.links.new(store_named_attribute_2.outputs[0], set_material_1.inputs[0])
	    #reroute_8.Output -> capture_attribute_002_2.Factor
	    hair_card.links.new(reroute_8.outputs[0], capture_attribute_002_2.inputs[1])
	    #capture_attribute_002_2.Factor -> combine_xyz_1.Y
	    hair_card.links.new(capture_attribute_002_2.outputs[1], combine_xyz_1.inputs[1])
	    #spline_parameter_3.Factor -> reroute_8.Input
	    hair_card.links.new(spline_parameter_3.outputs[0], reroute_8.inputs[0])
	    #group_input_001_6.Material -> set_material_1.Material
	    hair_card.links.new(group_input_001_6.outputs[1], set_material_1.inputs[2])
	    #group_input_9.Width -> reroute_001_5.Input
	    hair_card.links.new(group_input_9.outputs[4], reroute_001_5.inputs[0])
	    #reroute_002_3.Output -> resample_curve_1.Curve
	    hair_card.links.new(reroute_002_3.outputs[0], resample_curve_1.inputs[0])
	    #group_input_9.Resolution -> resample_curve_1.Count
	    hair_card.links.new(group_input_9.outputs[3], resample_curve_1.inputs[2])
	    #group_input_002_6.Resolution -> compare_5.A
	    hair_card.links.new(group_input_002_6.outputs[3], compare_5.inputs[2])
	    #compare_5.Result -> switch_6.Switch
	    hair_card.links.new(compare_5.outputs[0], switch_6.inputs[0])
	    #set_curve_radius_1.Curve -> capture_attribute_2.Geometry
	    hair_card.links.new(set_curve_radius_1.outputs[0], capture_attribute_2.inputs[0])
	    #group_input_9.Geometry -> reroute_002_3.Input
	    hair_card.links.new(group_input_9.outputs[0], reroute_002_3.inputs[0])
	    #reroute_002_3.Output -> switch_6.True
	    hair_card.links.new(reroute_002_3.outputs[0], switch_6.inputs[2])
	    #resample_curve_1.Curve -> switch_6.False
	    hair_card.links.new(resample_curve_1.outputs[0], switch_6.inputs[1])
	    #join_geometry_2.Geometry -> points_to_curves.Points
	    hair_card.links.new(join_geometry_2.outputs[0], points_to_curves.inputs[0])
	    #points_002.Points -> join_geometry_2.Geometry
	    hair_card.links.new(points_002.outputs[0], join_geometry_2.inputs[0])
	    #group_input_003_5.Angle -> vector_rotate_1.Angle
	    hair_card.links.new(group_input_003_5.outputs[5], vector_rotate_1.inputs[3])
	    #vector_rotate_1.Vector -> vector_math_6.Vector
	    hair_card.links.new(vector_rotate_1.outputs[0], vector_math_6.inputs[0])
	    #vector_rotate_1.Vector -> points_001.Position
	    hair_card.links.new(vector_rotate_1.outputs[0], points_001.inputs[1])
	    #vector_math_6.Vector -> points_002.Position
	    hair_card.links.new(vector_math_6.outputs[0], points_002.inputs[1])
	    #combine_xyz_003.Vector -> vector_rotate_1.Vector
	    hair_card.links.new(combine_xyz_003.outputs[0], vector_rotate_1.inputs[0])
	    #reroute_001_5.Output -> combine_xyz_003.X
	    hair_card.links.new(reroute_001_5.outputs[0], combine_xyz_003.inputs[0])
	    #points_to_curves.Curves -> capture_attribute_002_2.Geometry
	    hair_card.links.new(points_to_curves.outputs[0], capture_attribute_002_2.inputs[0])
	    #capture_attribute_002_2.Geometry -> curve_to_mesh.Profile Curve
	    hair_card.links.new(capture_attribute_002_2.outputs[0], curve_to_mesh.inputs[1])
	    #switch_6.Output -> set_curve_radius_1.Curve
	    hair_card.links.new(switch_6.outputs[0], set_curve_radius_1.inputs[0])
	    #reroute_004_4.Output -> set_curve_radius_1.Radius
	    hair_card.links.new(reroute_004_4.outputs[0], set_curve_radius_1.inputs[2])
	    #group_input_004_3.Curve Radius -> reroute_003_3.Input
	    hair_card.links.new(group_input_004_3.outputs[2], reroute_003_3.inputs[0])
	    #reroute_003_3.Output -> reroute_004_4.Input
	    hair_card.links.new(reroute_003_3.outputs[0], reroute_004_4.inputs[0])
	    #points.Points -> join_geometry_2.Geometry
	    hair_card.links.new(points.outputs[0], join_geometry_2.inputs[0])
	    #points_001.Points -> join_geometry_2.Geometry
	    hair_card.links.new(points_001.outputs[0], join_geometry_2.inputs[0])
	    return hair_card
	
	hair_card = hair_card_node_group()
	
	#initialize stylized_hair_mesh node group
	def stylized_hair_mesh_node_group():
	    stylized_hair_mesh = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "STYLIZED_HAIR_MESH")
	
	    stylized_hair_mesh.color_tag = 'NONE'
	    stylized_hair_mesh.description = ""
	    stylized_hair_mesh.default_group_node_width = 140
	    
	
	    stylized_hair_mesh.is_modifier = True
	
	    #stylized_hair_mesh interface
	    #Socket Geometry
	    geometry_socket_16 = stylized_hair_mesh.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_16.attribute_domain = 'POINT'
	
	    #Socket Geometry
	    geometry_socket_17 = stylized_hair_mesh.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_17.attribute_domain = 'POINT'
	
	    #Socket Profile
	    profile_socket = stylized_hair_mesh.interface.new_socket(name = "Profile", in_out='INPUT', socket_type = 'NodeSocketObject')
	    profile_socket.attribute_domain = 'POINT'
	
	    #Socket Material
	    material_socket_2 = stylized_hair_mesh.interface.new_socket(name = "Material", in_out='INPUT', socket_type = 'NodeSocketMaterial')
	    material_socket_2.attribute_domain = 'POINT'
	
	    #Socket Curve Radius
	    curve_radius_socket_1 = stylized_hair_mesh.interface.new_socket(name = "Curve Radius", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    curve_radius_socket_1.default_value = 1.0
	    curve_radius_socket_1.min_value = 0.0
	    curve_radius_socket_1.max_value = 3.4028234663852886e+38
	    curve_radius_socket_1.subtype = 'DISTANCE'
	    curve_radius_socket_1.attribute_domain = 'POINT'
	    curve_radius_socket_1.hide_value = True
	    curve_radius_socket_1.hide_in_modifier = True
	
	    #Socket Resolution
	    resolution_socket_1 = stylized_hair_mesh.interface.new_socket(name = "Resolution", in_out='INPUT', socket_type = 'NodeSocketInt')
	    resolution_socket_1.default_value = 10
	    resolution_socket_1.min_value = 1
	    resolution_socket_1.max_value = 100000
	    resolution_socket_1.subtype = 'NONE'
	    resolution_socket_1.attribute_domain = 'POINT'
	
	    #Socket Fill Caps
	    fill_caps_socket = stylized_hair_mesh.interface.new_socket(name = "Fill Caps", in_out='INPUT', socket_type = 'NodeSocketBool')
	    fill_caps_socket.default_value = True
	    fill_caps_socket.attribute_domain = 'POINT'
	
	    #Socket Translation
	    translation_socket = stylized_hair_mesh.interface.new_socket(name = "Translation", in_out='INPUT', socket_type = 'NodeSocketVector')
	    translation_socket.default_value = (0.0, 0.0, 0.0)
	    translation_socket.min_value = -3.4028234663852886e+38
	    translation_socket.max_value = 3.4028234663852886e+38
	    translation_socket.subtype = 'TRANSLATION'
	    translation_socket.attribute_domain = 'POINT'
	
	    #Socket Rotation
	    rotation_socket = stylized_hair_mesh.interface.new_socket(name = "Rotation", in_out='INPUT', socket_type = 'NodeSocketRotation')
	    rotation_socket.default_value = (0.0, 0.0, 0.0)
	    rotation_socket.attribute_domain = 'POINT'
	
	    #Socket Scale
	    scale_socket_1 = stylized_hair_mesh.interface.new_socket(name = "Scale", in_out='INPUT', socket_type = 'NodeSocketVector')
	    scale_socket_1.default_value = (1.0, 1.0, 1.0)
	    scale_socket_1.min_value = -3.4028234663852886e+38
	    scale_socket_1.max_value = 3.4028234663852886e+38
	    scale_socket_1.subtype = 'XYZ'
	    scale_socket_1.attribute_domain = 'POINT'
	
	
	    #initialize stylized_hair_mesh nodes
	    #node Group Input
	    group_input_10 = stylized_hair_mesh.nodes.new("NodeGroupInput")
	    group_input_10.name = "Group Input"
	    group_input_10.outputs[2].hide = True
	    group_input_10.outputs[3].hide = True
	    group_input_10.outputs[4].hide = True
	    group_input_10.outputs[5].hide = True
	    group_input_10.outputs[6].hide = True
	    group_input_10.outputs[7].hide = True
	    group_input_10.outputs[8].hide = True
	    group_input_10.outputs[9].hide = True
	
	    #node Group Output
	    group_output_14 = stylized_hair_mesh.nodes.new("NodeGroupOutput")
	    group_output_14.name = "Group Output"
	    group_output_14.is_active_output = True
	
	    #node Curve to Mesh
	    curve_to_mesh_1 = stylized_hair_mesh.nodes.new("GeometryNodeCurveToMesh")
	    curve_to_mesh_1.name = "Curve to Mesh"
	    curve_to_mesh_1.hide = True
	
	    #node Capture Attribute
	    capture_attribute_3 = stylized_hair_mesh.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_3.name = "Capture Attribute"
	    capture_attribute_3.hide = True
	    capture_attribute_3.active_index = 0
	    capture_attribute_3.capture_items.clear()
	    capture_attribute_3.capture_items.new('FLOAT', "Factor")
	    capture_attribute_3.capture_items["Factor"].data_type = 'FLOAT'
	    capture_attribute_3.domain = 'POINT'
	
	    #node Spline Parameter
	    spline_parameter_4 = stylized_hair_mesh.nodes.new("GeometryNodeSplineParameter")
	    spline_parameter_4.name = "Spline Parameter"
	    spline_parameter_4.hide = True
	
	    #node Combine XYZ
	    combine_xyz_2 = stylized_hair_mesh.nodes.new("ShaderNodeCombineXYZ")
	    combine_xyz_2.name = "Combine XYZ"
	    combine_xyz_2.hide = True
	    #Z
	    combine_xyz_2.inputs[2].default_value = 0.0
	
	    #node Store Named Attribute
	    store_named_attribute_3 = stylized_hair_mesh.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_3.name = "Store Named Attribute"
	    store_named_attribute_3.data_type = 'FLOAT2'
	    store_named_attribute_3.domain = 'CORNER'
	    #Selection
	    store_named_attribute_3.inputs[1].default_value = True
	    #Name
	    store_named_attribute_3.inputs[2].default_value = "stylized_hair_UV"
	
	    #node Set Material
	    set_material_2 = stylized_hair_mesh.nodes.new("GeometryNodeSetMaterial")
	    set_material_2.name = "Set Material"
	    set_material_2.hide = True
	    #Selection
	    set_material_2.inputs[1].default_value = True
	
	    #node Capture Attribute.002
	    capture_attribute_002_3 = stylized_hair_mesh.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_002_3.name = "Capture Attribute.002"
	    capture_attribute_002_3.hide = True
	    capture_attribute_002_3.active_index = 0
	    capture_attribute_002_3.capture_items.clear()
	    capture_attribute_002_3.capture_items.new('FLOAT', "Factor")
	    capture_attribute_002_3.capture_items["Factor"].data_type = 'FLOAT'
	    capture_attribute_002_3.domain = 'POINT'
	
	    #node Reroute
	    reroute_9 = stylized_hair_mesh.nodes.new("NodeReroute")
	    reroute_9.name = "Reroute"
	    reroute_9.socket_idname = "NodeSocketFloat"
	    #node Group Input.001
	    group_input_001_7 = stylized_hair_mesh.nodes.new("NodeGroupInput")
	    group_input_001_7.name = "Group Input.001"
	    group_input_001_7.outputs[0].hide = True
	    group_input_001_7.outputs[1].hide = True
	    group_input_001_7.outputs[3].hide = True
	    group_input_001_7.outputs[4].hide = True
	    group_input_001_7.outputs[5].hide = True
	    group_input_001_7.outputs[6].hide = True
	    group_input_001_7.outputs[7].hide = True
	    group_input_001_7.outputs[8].hide = True
	    group_input_001_7.outputs[9].hide = True
	
	    #node Group Input.002
	    group_input_002_7 = stylized_hair_mesh.nodes.new("NodeGroupInput")
	    group_input_002_7.name = "Group Input.002"
	    group_input_002_7.outputs[0].hide = True
	    group_input_002_7.outputs[1].hide = True
	    group_input_002_7.outputs[2].hide = True
	    group_input_002_7.outputs[3].hide = True
	    group_input_002_7.outputs[4].hide = True
	    group_input_002_7.outputs[6].hide = True
	    group_input_002_7.outputs[7].hide = True
	    group_input_002_7.outputs[8].hide = True
	    group_input_002_7.outputs[9].hide = True
	
	    #node Object Info
	    object_info_2 = stylized_hair_mesh.nodes.new("GeometryNodeObjectInfo")
	    object_info_2.name = "Object Info"
	    object_info_2.hide = True
	    object_info_2.transform_space = 'RELATIVE'
	    #As Instance
	    object_info_2.inputs[1].default_value = False
	
	    #node Transform Geometry
	    transform_geometry = stylized_hair_mesh.nodes.new("GeometryNodeTransform")
	    transform_geometry.name = "Transform Geometry"
	    transform_geometry.hide = True
	    transform_geometry.mode = 'COMPONENTS'
	
	    #node Group Input.003
	    group_input_003_6 = stylized_hair_mesh.nodes.new("NodeGroupInput")
	    group_input_003_6.name = "Group Input.003"
	    group_input_003_6.outputs[0].hide = True
	    group_input_003_6.outputs[1].hide = True
	    group_input_003_6.outputs[2].hide = True
	    group_input_003_6.outputs[4].hide = True
	    group_input_003_6.outputs[5].hide = True
	    group_input_003_6.outputs[6].hide = True
	    group_input_003_6.outputs[7].hide = True
	    group_input_003_6.outputs[8].hide = True
	    group_input_003_6.outputs[9].hide = True
	
	    #node Group Input.004
	    group_input_004_4 = stylized_hair_mesh.nodes.new("NodeGroupInput")
	    group_input_004_4.name = "Group Input.004"
	    group_input_004_4.outputs[0].hide = True
	    group_input_004_4.outputs[1].hide = True
	    group_input_004_4.outputs[2].hide = True
	    group_input_004_4.outputs[3].hide = True
	    group_input_004_4.outputs[4].hide = True
	    group_input_004_4.outputs[5].hide = True
	    group_input_004_4.outputs[9].hide = True
	
	    #node Set Curve Radius
	    set_curve_radius_2 = stylized_hair_mesh.nodes.new("GeometryNodeSetCurveRadius")
	    set_curve_radius_2.name = "Set Curve Radius"
	    set_curve_radius_2.hide = True
	    #Selection
	    set_curve_radius_2.inputs[1].default_value = True
	
	    #node Reroute.001
	    reroute_001_6 = stylized_hair_mesh.nodes.new("NodeReroute")
	    reroute_001_6.name = "Reroute.001"
	    reroute_001_6.socket_idname = "NodeSocketGeometry"
	    #node Reroute.002
	    reroute_002_4 = stylized_hair_mesh.nodes.new("NodeReroute")
	    reroute_002_4.name = "Reroute.002"
	    reroute_002_4.socket_idname = "NodeSocketGeometry"
	    #node Resample Curve
	    resample_curve_2 = stylized_hair_mesh.nodes.new("GeometryNodeResampleCurve")
	    resample_curve_2.name = "Resample Curve"
	    resample_curve_2.hide = True
	    resample_curve_2.keep_last_segment = False
	    resample_curve_2.mode = 'COUNT'
	    #Selection
	    resample_curve_2.inputs[1].default_value = True
	
	    #node Switch
	    switch_7 = stylized_hair_mesh.nodes.new("GeometryNodeSwitch")
	    switch_7.name = "Switch"
	    switch_7.hide = True
	    switch_7.input_type = 'GEOMETRY'
	
	    #node Compare
	    compare_6 = stylized_hair_mesh.nodes.new("FunctionNodeCompare")
	    compare_6.name = "Compare"
	    compare_6.hide = True
	    compare_6.data_type = 'INT'
	    compare_6.mode = 'ELEMENT'
	    compare_6.operation = 'LESS_THAN'
	    #B_INT
	    compare_6.inputs[3].default_value = 2
	
	    #node Reroute.005
	    reroute_005_2 = stylized_hair_mesh.nodes.new("NodeReroute")
	    reroute_005_2.name = "Reroute.005"
	    reroute_005_2.socket_idname = "NodeSocketGeometry"
	    #node Group Input.005
	    group_input_005_5 = stylized_hair_mesh.nodes.new("NodeGroupInput")
	    group_input_005_5.name = "Group Input.005"
	    group_input_005_5.outputs[0].hide = True
	    group_input_005_5.outputs[1].hide = True
	    group_input_005_5.outputs[2].hide = True
	    group_input_005_5.outputs[3].hide = True
	    group_input_005_5.outputs[5].hide = True
	    group_input_005_5.outputs[6].hide = True
	    group_input_005_5.outputs[7].hide = True
	    group_input_005_5.outputs[8].hide = True
	    group_input_005_5.outputs[9].hide = True
	
	
	
	
	
	    #Set locations
	    group_input_10.location = (-340.0, -125.68765258789062)
	    group_output_14.location = (1046.0562744140625, -35.87745666503906)
	    curve_to_mesh_1.location = (546.74853515625, -108.79241180419922)
	    capture_attribute_3.location = (361.8101501464844, -82.63687133789062)
	    spline_parameter_4.location = (156.93017578125, -142.56178283691406)
	    combine_xyz_2.location = (546.5570068359375, -195.67379760742188)
	    store_named_attribute_3.location = (712.5771484375, -27.647676467895508)
	    set_material_2.location = (873.80419921875, -61.86378860473633)
	    capture_attribute_002_3.location = (363.9737243652344, -168.7198028564453)
	    reroute_9.location = (319.04217529296875, -141.52703857421875)
	    group_input_001_7.location = (870.8699951171875, -92.72925567626953)
	    group_input_002_7.location = (542.2694702148438, -137.2887725830078)
	    object_info_2.location = (-173.28436279296875, -181.30752563476562)
	    transform_geometry.location = (156.43304443359375, -206.8249053955078)
	    group_input_003_6.location = (-339.0907897949219, -62.643611907958984)
	    group_input_004_4.location = (-338.4869689941406, -211.2111053466797)
	    set_curve_radius_2.location = (158.24813842773438, -76.21592712402344)
	    reroute_001_6.location = (-164.16294860839844, -159.83448791503906)
	    reroute_002_4.location = (-164.90399169921875, -71.62743377685547)
	    resample_curve_2.location = (-36.965057373046875, -67.16246032714844)
	    switch_7.location = (-37.0408821105957, -32.16990661621094)
	    compare_6.location = (-40.26144027709961, 2.388460159301758)
	    reroute_005_2.location = (-130.80706787109375, -71.2057876586914)
	    group_input_005_5.location = (-338.4869689941406, -2.108567237854004)
	
	    #Set dimensions
	    group_input_10.width, group_input_10.height = 140.0, 100.0
	    group_output_14.width, group_output_14.height = 140.0, 100.0
	    curve_to_mesh_1.width, curve_to_mesh_1.height = 140.0, 100.0
	    capture_attribute_3.width, capture_attribute_3.height = 140.0, 100.0
	    spline_parameter_4.width, spline_parameter_4.height = 140.0, 100.0
	    combine_xyz_2.width, combine_xyz_2.height = 140.0, 100.0
	    store_named_attribute_3.width, store_named_attribute_3.height = 140.0, 100.0
	    set_material_2.width, set_material_2.height = 140.0, 100.0
	    capture_attribute_002_3.width, capture_attribute_002_3.height = 140.0, 100.0
	    reroute_9.width, reroute_9.height = 100.0, 100.0
	    group_input_001_7.width, group_input_001_7.height = 140.0, 100.0
	    group_input_002_7.width, group_input_002_7.height = 140.0, 100.0
	    object_info_2.width, object_info_2.height = 140.0, 100.0
	    transform_geometry.width, transform_geometry.height = 140.0, 100.0
	    group_input_003_6.width, group_input_003_6.height = 140.0, 100.0
	    group_input_004_4.width, group_input_004_4.height = 140.0, 100.0
	    set_curve_radius_2.width, set_curve_radius_2.height = 140.0, 100.0
	    reroute_001_6.width, reroute_001_6.height = 100.0, 100.0
	    reroute_002_4.width, reroute_002_4.height = 100.0, 100.0
	    resample_curve_2.width, resample_curve_2.height = 140.0, 100.0
	    switch_7.width, switch_7.height = 140.0, 100.0
	    compare_6.width, compare_6.height = 140.0, 100.0
	    reroute_005_2.width, reroute_005_2.height = 100.0, 100.0
	    group_input_005_5.width, group_input_005_5.height = 140.0, 100.0
	
	    #initialize stylized_hair_mesh links
	    #set_material_2.Geometry -> group_output_14.Geometry
	    stylized_hair_mesh.links.new(set_material_2.outputs[0], group_output_14.inputs[0])
	    #capture_attribute_3.Geometry -> curve_to_mesh_1.Curve
	    stylized_hair_mesh.links.new(capture_attribute_3.outputs[0], curve_to_mesh_1.inputs[0])
	    #set_curve_radius_2.Curve -> capture_attribute_3.Geometry
	    stylized_hair_mesh.links.new(set_curve_radius_2.outputs[0], capture_attribute_3.inputs[0])
	    #reroute_9.Output -> capture_attribute_3.Factor
	    stylized_hair_mesh.links.new(reroute_9.outputs[0], capture_attribute_3.inputs[1])
	    #capture_attribute_3.Factor -> combine_xyz_2.X
	    stylized_hair_mesh.links.new(capture_attribute_3.outputs[1], combine_xyz_2.inputs[0])
	    #curve_to_mesh_1.Mesh -> store_named_attribute_3.Geometry
	    stylized_hair_mesh.links.new(curve_to_mesh_1.outputs[0], store_named_attribute_3.inputs[0])
	    #combine_xyz_2.Vector -> store_named_attribute_3.Value
	    stylized_hair_mesh.links.new(combine_xyz_2.outputs[0], store_named_attribute_3.inputs[3])
	    #store_named_attribute_3.Geometry -> set_material_2.Geometry
	    stylized_hair_mesh.links.new(store_named_attribute_3.outputs[0], set_material_2.inputs[0])
	    #reroute_9.Output -> capture_attribute_002_3.Factor
	    stylized_hair_mesh.links.new(reroute_9.outputs[0], capture_attribute_002_3.inputs[1])
	    #capture_attribute_002_3.Factor -> combine_xyz_2.Y
	    stylized_hair_mesh.links.new(capture_attribute_002_3.outputs[1], combine_xyz_2.inputs[1])
	    #capture_attribute_002_3.Geometry -> curve_to_mesh_1.Profile Curve
	    stylized_hair_mesh.links.new(capture_attribute_002_3.outputs[0], curve_to_mesh_1.inputs[1])
	    #spline_parameter_4.Factor -> reroute_9.Input
	    stylized_hair_mesh.links.new(spline_parameter_4.outputs[0], reroute_9.inputs[0])
	    #group_input_001_7.Material -> set_material_2.Material
	    stylized_hair_mesh.links.new(group_input_001_7.outputs[2], set_material_2.inputs[2])
	    #group_input_002_7.Fill Caps -> curve_to_mesh_1.Fill Caps
	    stylized_hair_mesh.links.new(group_input_002_7.outputs[5], curve_to_mesh_1.inputs[2])
	    #group_input_10.Profile -> object_info_2.Object
	    stylized_hair_mesh.links.new(group_input_10.outputs[1], object_info_2.inputs[0])
	    #object_info_2.Geometry -> transform_geometry.Geometry
	    stylized_hair_mesh.links.new(object_info_2.outputs[4], transform_geometry.inputs[0])
	    #transform_geometry.Geometry -> capture_attribute_002_3.Geometry
	    stylized_hair_mesh.links.new(transform_geometry.outputs[0], capture_attribute_002_3.inputs[0])
	    #group_input_003_6.Curve Radius -> set_curve_radius_2.Radius
	    stylized_hair_mesh.links.new(group_input_003_6.outputs[3], set_curve_radius_2.inputs[2])
	    #group_input_004_4.Translation -> transform_geometry.Translation
	    stylized_hair_mesh.links.new(group_input_004_4.outputs[6], transform_geometry.inputs[1])
	    #group_input_004_4.Rotation -> transform_geometry.Rotation
	    stylized_hair_mesh.links.new(group_input_004_4.outputs[7], transform_geometry.inputs[2])
	    #group_input_004_4.Scale -> transform_geometry.Scale
	    stylized_hair_mesh.links.new(group_input_004_4.outputs[8], transform_geometry.inputs[3])
	    #group_input_10.Geometry -> reroute_001_6.Input
	    stylized_hair_mesh.links.new(group_input_10.outputs[0], reroute_001_6.inputs[0])
	    #reroute_001_6.Output -> reroute_002_4.Input
	    stylized_hair_mesh.links.new(reroute_001_6.outputs[0], reroute_002_4.inputs[0])
	    #reroute_005_2.Output -> resample_curve_2.Curve
	    stylized_hair_mesh.links.new(reroute_005_2.outputs[0], resample_curve_2.inputs[0])
	    #compare_6.Result -> switch_7.Switch
	    stylized_hair_mesh.links.new(compare_6.outputs[0], switch_7.inputs[0])
	    #reroute_005_2.Output -> switch_7.True
	    stylized_hair_mesh.links.new(reroute_005_2.outputs[0], switch_7.inputs[2])
	    #resample_curve_2.Curve -> switch_7.False
	    stylized_hair_mesh.links.new(resample_curve_2.outputs[0], switch_7.inputs[1])
	    #group_input_005_5.Resolution -> resample_curve_2.Count
	    stylized_hair_mesh.links.new(group_input_005_5.outputs[4], resample_curve_2.inputs[2])
	    #group_input_005_5.Resolution -> compare_6.A
	    stylized_hair_mesh.links.new(group_input_005_5.outputs[4], compare_6.inputs[2])
	    #switch_7.Output -> set_curve_radius_2.Curve
	    stylized_hair_mesh.links.new(switch_7.outputs[0], set_curve_radius_2.inputs[0])
	    #reroute_002_4.Output -> reroute_005_2.Input
	    stylized_hair_mesh.links.new(reroute_002_4.outputs[0], reroute_005_2.inputs[0])
	    return stylized_hair_mesh
	
	stylized_hair_mesh = stylized_hair_mesh_node_group()
	
	#initialize tube_ribbon_mesh node group
	def tube_ribbon_mesh_node_group():
	    tube_ribbon_mesh = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "TUBE_RIBBON_MESH")
	
	    tube_ribbon_mesh.color_tag = 'NONE'
	    tube_ribbon_mesh.description = ""
	    tube_ribbon_mesh.default_group_node_width = 140
	    
	
	    tube_ribbon_mesh.is_modifier = True
	
	    #tube_ribbon_mesh interface
	    #Socket Geometry
	    geometry_socket_18 = tube_ribbon_mesh.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_18.attribute_domain = 'POINT'
	
	    #Socket Geometry
	    geometry_socket_19 = tube_ribbon_mesh.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_19.attribute_domain = 'POINT'
	
	    #Socket Material
	    material_socket_3 = tube_ribbon_mesh.interface.new_socket(name = "Material", in_out='INPUT', socket_type = 'NodeSocketMaterial')
	    material_socket_3.attribute_domain = 'POINT'
	
	    #Socket Curve Radius
	    curve_radius_socket_2 = tube_ribbon_mesh.interface.new_socket(name = "Curve Radius", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    curve_radius_socket_2.default_value = 1.0
	    curve_radius_socket_2.min_value = 0.0
	    curve_radius_socket_2.max_value = 3.4028234663852886e+38
	    curve_radius_socket_2.subtype = 'DISTANCE'
	    curve_radius_socket_2.attribute_domain = 'POINT'
	    curve_radius_socket_2.hide_value = True
	    curve_radius_socket_2.hide_in_modifier = True
	
	    #Socket Ribbon Count
	    ribbon_count_socket = tube_ribbon_mesh.interface.new_socket(name = "Ribbon Count", in_out='INPUT', socket_type = 'NodeSocketInt')
	    ribbon_count_socket.default_value = 8
	    ribbon_count_socket.min_value = 1
	    ribbon_count_socket.max_value = 180
	    ribbon_count_socket.subtype = 'NONE'
	    ribbon_count_socket.attribute_domain = 'POINT'
	
	    #Socket Resolution
	    resolution_socket_2 = tube_ribbon_mesh.interface.new_socket(name = "Resolution", in_out='INPUT', socket_type = 'NodeSocketInt')
	    resolution_socket_2.default_value = 0
	    resolution_socket_2.min_value = 2
	    resolution_socket_2.max_value = 512
	    resolution_socket_2.subtype = 'NONE'
	    resolution_socket_2.attribute_domain = 'POINT'
	
	    #Socket Width
	    width_socket_1 = tube_ribbon_mesh.interface.new_socket(name = "Width", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    width_socket_1.default_value = 0.10000000149011612
	    width_socket_1.min_value = 0.0
	    width_socket_1.max_value = 3.4028234663852886e+38
	    width_socket_1.subtype = 'DISTANCE'
	    width_socket_1.attribute_domain = 'POINT'
	
	
	    #initialize tube_ribbon_mesh nodes
	    #node Group Input
	    group_input_11 = tube_ribbon_mesh.nodes.new("NodeGroupInput")
	    group_input_11.name = "Group Input"
	    group_input_11.outputs[1].hide = True
	    group_input_11.outputs[2].hide = True
	    group_input_11.outputs[3].hide = True
	    group_input_11.outputs[6].hide = True
	
	    #node Group Output
	    group_output_15 = tube_ribbon_mesh.nodes.new("NodeGroupOutput")
	    group_output_15.name = "Group Output"
	    group_output_15.is_active_output = True
	
	    #node Curve to Mesh
	    curve_to_mesh_2 = tube_ribbon_mesh.nodes.new("GeometryNodeCurveToMesh")
	    curve_to_mesh_2.name = "Curve to Mesh"
	    curve_to_mesh_2.hide = True
	    #Fill Caps
	    curve_to_mesh_2.inputs[2].default_value = True
	
	    #node Capture Attribute
	    capture_attribute_4 = tube_ribbon_mesh.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_4.name = "Capture Attribute"
	    capture_attribute_4.hide = True
	    capture_attribute_4.active_index = 0
	    capture_attribute_4.capture_items.clear()
	    capture_attribute_4.capture_items.new('FLOAT', "Factor")
	    capture_attribute_4.capture_items["Factor"].data_type = 'FLOAT'
	    capture_attribute_4.domain = 'POINT'
	
	    #node Spline Parameter
	    spline_parameter_5 = tube_ribbon_mesh.nodes.new("GeometryNodeSplineParameter")
	    spline_parameter_5.name = "Spline Parameter"
	    spline_parameter_5.hide = True
	
	    #node Combine XYZ
	    combine_xyz_3 = tube_ribbon_mesh.nodes.new("ShaderNodeCombineXYZ")
	    combine_xyz_3.name = "Combine XYZ"
	    combine_xyz_3.hide = True
	    #Z
	    combine_xyz_3.inputs[2].default_value = 0.0
	
	    #node Store Named Attribute
	    store_named_attribute_4 = tube_ribbon_mesh.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_4.name = "Store Named Attribute"
	    store_named_attribute_4.data_type = 'FLOAT2'
	    store_named_attribute_4.domain = 'CORNER'
	    #Selection
	    store_named_attribute_4.inputs[1].default_value = True
	    #Name
	    store_named_attribute_4.inputs[2].default_value = "ribbon_mesh_UV"
	
	    #node Set Material
	    set_material_3 = tube_ribbon_mesh.nodes.new("GeometryNodeSetMaterial")
	    set_material_3.name = "Set Material"
	    set_material_3.hide = True
	    #Selection
	    set_material_3.inputs[1].default_value = True
	
	    #node Capture Attribute.002
	    capture_attribute_002_4 = tube_ribbon_mesh.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_002_4.name = "Capture Attribute.002"
	    capture_attribute_002_4.hide = True
	    capture_attribute_002_4.active_index = 0
	    capture_attribute_002_4.capture_items.clear()
	    capture_attribute_002_4.capture_items.new('FLOAT', "Factor")
	    capture_attribute_002_4.capture_items["Factor"].data_type = 'FLOAT'
	    capture_attribute_002_4.domain = 'POINT'
	
	    #node Reroute
	    reroute_10 = tube_ribbon_mesh.nodes.new("NodeReroute")
	    reroute_10.name = "Reroute"
	    reroute_10.socket_idname = "NodeSocketFloat"
	    #node Group Input.001
	    group_input_001_8 = tube_ribbon_mesh.nodes.new("NodeGroupInput")
	    group_input_001_8.name = "Group Input.001"
	    group_input_001_8.outputs[0].hide = True
	    group_input_001_8.outputs[2].hide = True
	    group_input_001_8.outputs[3].hide = True
	    group_input_001_8.outputs[4].hide = True
	    group_input_001_8.outputs[5].hide = True
	    group_input_001_8.outputs[6].hide = True
	
	    #node Curve Line
	    curve_line = tube_ribbon_mesh.nodes.new("GeometryNodeCurvePrimitiveLine")
	    curve_line.name = "Curve Line"
	    curve_line.hide = True
	    curve_line.mode = 'POINTS'
	
	    #node Combine XYZ.001
	    combine_xyz_001 = tube_ribbon_mesh.nodes.new("ShaderNodeCombineXYZ")
	    combine_xyz_001.name = "Combine XYZ.001"
	    combine_xyz_001.hide = True
	    #Y
	    combine_xyz_001.inputs[1].default_value = 0.0
	    #Z
	    combine_xyz_001.inputs[2].default_value = 0.0
	
	    #node Math.001
	    math_001_2 = tube_ribbon_mesh.nodes.new("ShaderNodeMath")
	    math_001_2.name = "Math.001"
	    math_001_2.hide = True
	    math_001_2.operation = 'MULTIPLY'
	    math_001_2.use_clamp = False
	    #Value_001
	    math_001_2.inputs[1].default_value = -1.0
	
	    #node Combine XYZ.002
	    combine_xyz_002_1 = tube_ribbon_mesh.nodes.new("ShaderNodeCombineXYZ")
	    combine_xyz_002_1.name = "Combine XYZ.002"
	    combine_xyz_002_1.hide = True
	    #Y
	    combine_xyz_002_1.inputs[1].default_value = 0.0
	    #Z
	    combine_xyz_002_1.inputs[2].default_value = 0.0
	
	    #node Reroute.001
	    reroute_001_7 = tube_ribbon_mesh.nodes.new("NodeReroute")
	    reroute_001_7.name = "Reroute.001"
	    reroute_001_7.socket_idname = "NodeSocketFloatDistance"
	    #node Resample Curve
	    resample_curve_3 = tube_ribbon_mesh.nodes.new("GeometryNodeResampleCurve")
	    resample_curve_3.name = "Resample Curve"
	    resample_curve_3.hide = True
	    resample_curve_3.keep_last_segment = False
	    resample_curve_3.mode = 'COUNT'
	    #Selection
	    resample_curve_3.inputs[1].default_value = True
	
	    #node Switch
	    switch_8 = tube_ribbon_mesh.nodes.new("GeometryNodeSwitch")
	    switch_8.name = "Switch"
	    switch_8.hide = True
	    switch_8.input_type = 'GEOMETRY'
	
	    #node Group Input.002
	    group_input_002_8 = tube_ribbon_mesh.nodes.new("NodeGroupInput")
	    group_input_002_8.name = "Group Input.002"
	    group_input_002_8.outputs[0].hide = True
	    group_input_002_8.outputs[1].hide = True
	    group_input_002_8.outputs[2].hide = True
	    group_input_002_8.outputs[3].hide = True
	    group_input_002_8.outputs[5].hide = True
	    group_input_002_8.outputs[6].hide = True
	
	    #node Compare
	    compare_7 = tube_ribbon_mesh.nodes.new("FunctionNodeCompare")
	    compare_7.name = "Compare"
	    compare_7.hide = True
	    compare_7.data_type = 'INT'
	    compare_7.mode = 'ELEMENT'
	    compare_7.operation = 'LESS_THAN'
	    #B_INT
	    compare_7.inputs[3].default_value = 2
	
	    #node Reroute.002
	    reroute_002_5 = tube_ribbon_mesh.nodes.new("NodeReroute")
	    reroute_002_5.name = "Reroute.002"
	    reroute_002_5.socket_idname = "NodeSocketGeometry"
	    #node Frame
	    frame_6 = tube_ribbon_mesh.nodes.new("NodeFrame")
	    frame_6.name = "Frame"
	    frame_6.label_size = 20
	    frame_6.shrink = True
	
	    #node Join Geometry
	    join_geometry_3 = tube_ribbon_mesh.nodes.new("GeometryNodeJoinGeometry")
	    join_geometry_3.name = "Join Geometry"
	
	    #node Set Curve Tilt
	    set_curve_tilt = tube_ribbon_mesh.nodes.new("GeometryNodeSetCurveTilt")
	    set_curve_tilt.name = "Set Curve Tilt"
	    #Selection
	    set_curve_tilt.inputs[1].default_value = True
	
	    #node Repeat Input
	    repeat_input = tube_ribbon_mesh.nodes.new("GeometryNodeRepeatInput")
	    repeat_input.name = "Repeat Input"
	    #node Repeat Output
	    repeat_output = tube_ribbon_mesh.nodes.new("GeometryNodeRepeatOutput")
	    repeat_output.name = "Repeat Output"
	    repeat_output.active_index = 1
	    repeat_output.inspection_index = 0
	    repeat_output.repeat_items.clear()
	    # Create item "Geometry"
	    repeat_output.repeat_items.new('GEOMETRY', "Geometry")
	    # Create item "Index"
	    repeat_output.repeat_items.new('INT', "Index")
	
	    #node Math.002
	    math_002_1 = tube_ribbon_mesh.nodes.new("ShaderNodeMath")
	    math_002_1.name = "Math.002"
	    math_002_1.hide = True
	    math_002_1.operation = 'DIVIDE'
	    math_002_1.use_clamp = False
	    #Value
	    math_002_1.inputs[0].default_value = 180.0
	
	    #node Group Input.003
	    group_input_003_7 = tube_ribbon_mesh.nodes.new("NodeGroupInput")
	    group_input_003_7.name = "Group Input.003"
	    group_input_003_7.outputs[0].hide = True
	    group_input_003_7.outputs[1].hide = True
	    group_input_003_7.outputs[2].hide = True
	    group_input_003_7.outputs[4].hide = True
	    group_input_003_7.outputs[5].hide = True
	    group_input_003_7.outputs[6].hide = True
	
	    #node Group Input.004
	    group_input_004_5 = tube_ribbon_mesh.nodes.new("NodeGroupInput")
	    group_input_004_5.name = "Group Input.004"
	    group_input_004_5.outputs[0].hide = True
	    group_input_004_5.outputs[1].hide = True
	    group_input_004_5.outputs[2].hide = True
	    group_input_004_5.outputs[4].hide = True
	    group_input_004_5.outputs[5].hide = True
	    group_input_004_5.outputs[6].hide = True
	
	    #node Math.003
	    math_003_1 = tube_ribbon_mesh.nodes.new("ShaderNodeMath")
	    math_003_1.name = "Math.003"
	    math_003_1.hide = True
	    math_003_1.operation = 'ADD'
	    math_003_1.use_clamp = False
	    #Value_001
	    math_003_1.inputs[1].default_value = 1.0
	
	    #node Math.004
	    math_004_1 = tube_ribbon_mesh.nodes.new("ShaderNodeMath")
	    math_004_1.name = "Math.004"
	    math_004_1.hide = True
	    math_004_1.operation = 'MULTIPLY'
	    math_004_1.use_clamp = False
	
	    #node Reroute.003
	    reroute_003_4 = tube_ribbon_mesh.nodes.new("NodeReroute")
	    reroute_003_4.name = "Reroute.003"
	    reroute_003_4.socket_idname = "NodeSocketInt"
	    #node Curve Tilt
	    curve_tilt = tube_ribbon_mesh.nodes.new("GeometryNodeInputCurveTilt")
	    curve_tilt.name = "Curve Tilt"
	    curve_tilt.hide = True
	
	    #node Math.005
	    math_005_1 = tube_ribbon_mesh.nodes.new("ShaderNodeMath")
	    math_005_1.name = "Math.005"
	    math_005_1.hide = True
	    math_005_1.operation = 'ADD'
	    math_005_1.use_clamp = False
	
	    #node Set Curve Radius
	    set_curve_radius_3 = tube_ribbon_mesh.nodes.new("GeometryNodeSetCurveRadius")
	    set_curve_radius_3.name = "Set Curve Radius"
	    set_curve_radius_3.hide = True
	    #Selection
	    set_curve_radius_3.inputs[1].default_value = True
	
	    #node Group Input.005
	    group_input_005_6 = tube_ribbon_mesh.nodes.new("NodeGroupInput")
	    group_input_005_6.name = "Group Input.005"
	    group_input_005_6.outputs[0].hide = True
	    group_input_005_6.outputs[1].hide = True
	    group_input_005_6.outputs[3].hide = True
	    group_input_005_6.outputs[4].hide = True
	    group_input_005_6.outputs[5].hide = True
	    group_input_005_6.outputs[6].hide = True
	
	    #node Reroute.004
	    reroute_004_5 = tube_ribbon_mesh.nodes.new("NodeReroute")
	    reroute_004_5.name = "Reroute.004"
	    reroute_004_5.socket_idname = "NodeSocketFloatDistance"
	    #node Reroute.005
	    reroute_005_3 = tube_ribbon_mesh.nodes.new("NodeReroute")
	    reroute_005_3.name = "Reroute.005"
	    reroute_005_3.socket_idname = "NodeSocketFloatDistance"
	
	    #Process zone input Repeat Input
	    repeat_input.pair_with_output(repeat_output)
	    #Item_2
	    repeat_input.inputs[2].default_value = 0
	
	
	
	
	    #Set parents
	    group_input_11.parent = frame_6
	    curve_to_mesh_2.parent = frame_6
	    capture_attribute_4.parent = frame_6
	    spline_parameter_5.parent = frame_6
	    combine_xyz_3.parent = frame_6
	    store_named_attribute_4.parent = frame_6
	    set_material_3.parent = frame_6
	    capture_attribute_002_4.parent = frame_6
	    reroute_10.parent = frame_6
	    group_input_001_8.parent = frame_6
	    curve_line.parent = frame_6
	    combine_xyz_001.parent = frame_6
	    math_001_2.parent = frame_6
	    combine_xyz_002_1.parent = frame_6
	    reroute_001_7.parent = frame_6
	    resample_curve_3.parent = frame_6
	    switch_8.parent = frame_6
	    group_input_002_8.parent = frame_6
	    compare_7.parent = frame_6
	    reroute_002_5.parent = frame_6
	    set_curve_tilt.parent = frame_6
	    math_004_1.parent = frame_6
	    math_005_1.parent = frame_6
	    set_curve_radius_3.parent = frame_6
	    group_input_005_6.parent = frame_6
	    reroute_004_5.parent = frame_6
	    reroute_005_3.parent = frame_6
	
	    #Set locations
	    group_input_11.location = (46.5567626953125, -187.68907165527344)
	    group_output_15.location = (1687.6083984375, 27.941242218017578)
	    curve_to_mesh_2.location = (937.7008666992188, -218.34669494628906)
	    capture_attribute_4.location = (764.834716796875, -223.1929168701172)
	    spline_parameter_5.location = (408.7358093261719, -288.16595458984375)
	    combine_xyz_3.location = (937.5093383789062, -281.03155517578125)
	    store_named_attribute_4.location = (1093.46923828125, -121.07095336914062)
	    set_material_3.location = (1254.6962890625, -155.2870635986328)
	    capture_attribute_002_4.location = (766.9982299804688, -262.14312744140625)
	    reroute_10.location = (566.0176391601562, -285.51812744140625)
	    group_input_001_8.location = (1251.76220703125, -186.1525421142578)
	    curve_line.location = (409.7470397949219, -252.2234649658203)
	    combine_xyz_001.location = (242.35899353027344, -260.64910888671875)
	    math_001_2.location = (247.1505889892578, -332.52447509765625)
	    combine_xyz_002_1.location = (245.62991333007812, -296.69708251953125)
	    reroute_001_7.location = (199.33338928222656, -265.65771484375)
	    resample_curve_3.location = (380.4243469238281, -216.19468688964844)
	    switch_8.location = (380.3485412597656, -181.20213317871094)
	    group_input_002_8.location = (375.72821044921875, -86.50663757324219)
	    compare_7.location = (377.1279602050781, -146.6437530517578)
	    reroute_002_5.location = (333.6315612792969, -213.35231018066406)
	    frame_6.location = (-58.76470947265625, -48.17646789550781)
	    join_geometry_3.location = (1331.0086669921875, 47.14059066772461)
	    set_curve_tilt.location = (192.23997497558594, -54.01100158691406)
	    repeat_input.location = (-184.79876708984375, 46.944000244140625)
	    repeat_output.location = (1511.4083251953125, 27.655336380004883)
	    math_002_1.location = (-195.4779510498047, -161.6897735595703)
	    group_input_003_7.location = (-346.3707580566406, 47.1754035949707)
	    group_input_004_5.location = (-353.25665283203125, -145.0489044189453)
	    math_003_1.location = (1134.1580810546875, -24.601409912109375)
	    math_004_1.location = (30.277496337890625, -106.62132263183594)
	    reroute_003_4.location = (-25.963211059570312, -31.35608673095703)
	    curve_tilt.location = (-197.5312957763672, -198.6190185546875)
	    math_005_1.location = (31.753875732421875, -145.03323364257812)
	    set_curve_radius_3.location = (591.83837890625, -194.33396911621094)
	    group_input_005_6.location = (377.0597229003906, -29.650436401367188)
	    reroute_004_5.location = (563.5545654296875, -215.4977264404297)
	    reroute_005_3.location = (561.7288208007812, -64.61457824707031)
	
	    #Set dimensions
	    group_input_11.width, group_input_11.height = 140.0, 100.0
	    group_output_15.width, group_output_15.height = 140.0, 100.0
	    curve_to_mesh_2.width, curve_to_mesh_2.height = 140.0, 100.0
	    capture_attribute_4.width, capture_attribute_4.height = 140.0, 100.0
	    spline_parameter_5.width, spline_parameter_5.height = 140.0, 100.0
	    combine_xyz_3.width, combine_xyz_3.height = 140.0, 100.0
	    store_named_attribute_4.width, store_named_attribute_4.height = 140.0, 100.0
	    set_material_3.width, set_material_3.height = 140.0, 100.0
	    capture_attribute_002_4.width, capture_attribute_002_4.height = 140.0, 100.0
	    reroute_10.width, reroute_10.height = 100.0, 100.0
	    group_input_001_8.width, group_input_001_8.height = 140.0, 100.0
	    curve_line.width, curve_line.height = 140.0, 100.0
	    combine_xyz_001.width, combine_xyz_001.height = 140.0, 100.0
	    math_001_2.width, math_001_2.height = 140.0, 100.0
	    combine_xyz_002_1.width, combine_xyz_002_1.height = 140.0, 100.0
	    reroute_001_7.width, reroute_001_7.height = 100.0, 100.0
	    resample_curve_3.width, resample_curve_3.height = 140.0, 100.0
	    switch_8.width, switch_8.height = 140.0, 100.0
	    group_input_002_8.width, group_input_002_8.height = 140.0, 100.0
	    compare_7.width, compare_7.height = 140.0, 100.0
	    reroute_002_5.width, reroute_002_5.height = 100.0, 100.0
	    frame_6.width, frame_6.height = 1424.3529052734375, 388.32354736328125
	    join_geometry_3.width, join_geometry_3.height = 140.0, 100.0
	    set_curve_tilt.width, set_curve_tilt.height = 140.0, 100.0
	    repeat_input.width, repeat_input.height = 140.0, 100.0
	    repeat_output.width, repeat_output.height = 140.0, 100.0
	    math_002_1.width, math_002_1.height = 140.0, 100.0
	    group_input_003_7.width, group_input_003_7.height = 140.0, 100.0
	    group_input_004_5.width, group_input_004_5.height = 140.0, 100.0
	    math_003_1.width, math_003_1.height = 140.0, 100.0
	    math_004_1.width, math_004_1.height = 140.0, 100.0
	    reroute_003_4.width, reroute_003_4.height = 100.0, 100.0
	    curve_tilt.width, curve_tilt.height = 140.0, 100.0
	    math_005_1.width, math_005_1.height = 140.0, 100.0
	    set_curve_radius_3.width, set_curve_radius_3.height = 140.0, 100.0
	    group_input_005_6.width, group_input_005_6.height = 140.0, 100.0
	    reroute_004_5.width, reroute_004_5.height = 100.0, 100.0
	    reroute_005_3.width, reroute_005_3.height = 100.0, 100.0
	
	    #initialize tube_ribbon_mesh links
	    #capture_attribute_4.Geometry -> curve_to_mesh_2.Curve
	    tube_ribbon_mesh.links.new(capture_attribute_4.outputs[0], curve_to_mesh_2.inputs[0])
	    #reroute_10.Output -> capture_attribute_4.Factor
	    tube_ribbon_mesh.links.new(reroute_10.outputs[0], capture_attribute_4.inputs[1])
	    #capture_attribute_4.Factor -> combine_xyz_3.X
	    tube_ribbon_mesh.links.new(capture_attribute_4.outputs[1], combine_xyz_3.inputs[0])
	    #curve_to_mesh_2.Mesh -> store_named_attribute_4.Geometry
	    tube_ribbon_mesh.links.new(curve_to_mesh_2.outputs[0], store_named_attribute_4.inputs[0])
	    #combine_xyz_3.Vector -> store_named_attribute_4.Value
	    tube_ribbon_mesh.links.new(combine_xyz_3.outputs[0], store_named_attribute_4.inputs[3])
	    #store_named_attribute_4.Geometry -> set_material_3.Geometry
	    tube_ribbon_mesh.links.new(store_named_attribute_4.outputs[0], set_material_3.inputs[0])
	    #reroute_10.Output -> capture_attribute_002_4.Factor
	    tube_ribbon_mesh.links.new(reroute_10.outputs[0], capture_attribute_002_4.inputs[1])
	    #capture_attribute_002_4.Factor -> combine_xyz_3.Y
	    tube_ribbon_mesh.links.new(capture_attribute_002_4.outputs[1], combine_xyz_3.inputs[1])
	    #capture_attribute_002_4.Geometry -> curve_to_mesh_2.Profile Curve
	    tube_ribbon_mesh.links.new(capture_attribute_002_4.outputs[0], curve_to_mesh_2.inputs[1])
	    #spline_parameter_5.Factor -> reroute_10.Input
	    tube_ribbon_mesh.links.new(spline_parameter_5.outputs[0], reroute_10.inputs[0])
	    #group_input_001_8.Material -> set_material_3.Material
	    tube_ribbon_mesh.links.new(group_input_001_8.outputs[1], set_material_3.inputs[2])
	    #combine_xyz_001.Vector -> curve_line.Start
	    tube_ribbon_mesh.links.new(combine_xyz_001.outputs[0], curve_line.inputs[0])
	    #math_001_2.Value -> combine_xyz_002_1.X
	    tube_ribbon_mesh.links.new(math_001_2.outputs[0], combine_xyz_002_1.inputs[0])
	    #combine_xyz_002_1.Vector -> curve_line.End
	    tube_ribbon_mesh.links.new(combine_xyz_002_1.outputs[0], curve_line.inputs[1])
	    #reroute_001_7.Output -> math_001_2.Value
	    tube_ribbon_mesh.links.new(reroute_001_7.outputs[0], math_001_2.inputs[0])
	    #curve_line.Curve -> capture_attribute_002_4.Geometry
	    tube_ribbon_mesh.links.new(curve_line.outputs[0], capture_attribute_002_4.inputs[0])
	    #group_input_11.Width -> reroute_001_7.Input
	    tube_ribbon_mesh.links.new(group_input_11.outputs[5], reroute_001_7.inputs[0])
	    #reroute_002_5.Output -> resample_curve_3.Curve
	    tube_ribbon_mesh.links.new(reroute_002_5.outputs[0], resample_curve_3.inputs[0])
	    #group_input_11.Resolution -> resample_curve_3.Count
	    tube_ribbon_mesh.links.new(group_input_11.outputs[4], resample_curve_3.inputs[2])
	    #group_input_002_8.Resolution -> compare_7.A
	    tube_ribbon_mesh.links.new(group_input_002_8.outputs[4], compare_7.inputs[2])
	    #compare_7.Result -> switch_8.Switch
	    tube_ribbon_mesh.links.new(compare_7.outputs[0], switch_8.inputs[0])
	    #set_curve_radius_3.Curve -> capture_attribute_4.Geometry
	    tube_ribbon_mesh.links.new(set_curve_radius_3.outputs[0], capture_attribute_4.inputs[0])
	    #reroute_002_5.Output -> switch_8.True
	    tube_ribbon_mesh.links.new(reroute_002_5.outputs[0], switch_8.inputs[2])
	    #resample_curve_3.Curve -> switch_8.False
	    tube_ribbon_mesh.links.new(resample_curve_3.outputs[0], switch_8.inputs[1])
	    #group_input_11.Geometry -> set_curve_tilt.Curve
	    tube_ribbon_mesh.links.new(group_input_11.outputs[0], set_curve_tilt.inputs[0])
	    #set_curve_tilt.Curve -> reroute_002_5.Input
	    tube_ribbon_mesh.links.new(set_curve_tilt.outputs[0], reroute_002_5.inputs[0])
	    #join_geometry_3.Geometry -> repeat_output.Geometry
	    tube_ribbon_mesh.links.new(join_geometry_3.outputs[0], repeat_output.inputs[0])
	    #group_input_003_7.Ribbon Count -> repeat_input.Iterations
	    tube_ribbon_mesh.links.new(group_input_003_7.outputs[3], repeat_input.inputs[0])
	    #math_003_1.Value -> repeat_output.Index
	    tube_ribbon_mesh.links.new(math_003_1.outputs[0], repeat_output.inputs[1])
	    #repeat_output.Geometry -> group_output_15.Geometry
	    tube_ribbon_mesh.links.new(repeat_output.outputs[0], group_output_15.inputs[0])
	    #reroute_003_4.Output -> math_003_1.Value
	    tube_ribbon_mesh.links.new(reroute_003_4.outputs[0], math_003_1.inputs[0])
	    #group_input_004_5.Ribbon Count -> math_002_1.Value
	    tube_ribbon_mesh.links.new(group_input_004_5.outputs[3], math_002_1.inputs[1])
	    #math_002_1.Value -> math_004_1.Value
	    tube_ribbon_mesh.links.new(math_002_1.outputs[0], math_004_1.inputs[1])
	    #reroute_003_4.Output -> math_004_1.Value
	    tube_ribbon_mesh.links.new(reroute_003_4.outputs[0], math_004_1.inputs[0])
	    #repeat_input.Index -> reroute_003_4.Input
	    tube_ribbon_mesh.links.new(repeat_input.outputs[2], reroute_003_4.inputs[0])
	    #set_material_3.Geometry -> join_geometry_3.Geometry
	    tube_ribbon_mesh.links.new(set_material_3.outputs[0], join_geometry_3.inputs[0])
	    #curve_tilt.Tilt -> math_005_1.Value
	    tube_ribbon_mesh.links.new(curve_tilt.outputs[0], math_005_1.inputs[1])
	    #math_004_1.Value -> math_005_1.Value
	    tube_ribbon_mesh.links.new(math_004_1.outputs[0], math_005_1.inputs[0])
	    #math_005_1.Value -> set_curve_tilt.Tilt
	    tube_ribbon_mesh.links.new(math_005_1.outputs[0], set_curve_tilt.inputs[2])
	    #switch_8.Output -> set_curve_radius_3.Curve
	    tube_ribbon_mesh.links.new(switch_8.outputs[0], set_curve_radius_3.inputs[0])
	    #reroute_004_5.Output -> set_curve_radius_3.Radius
	    tube_ribbon_mesh.links.new(reroute_004_5.outputs[0], set_curve_radius_3.inputs[2])
	    #reroute_005_3.Output -> reroute_004_5.Input
	    tube_ribbon_mesh.links.new(reroute_005_3.outputs[0], reroute_004_5.inputs[0])
	    #group_input_005_6.Curve Radius -> reroute_005_3.Input
	    tube_ribbon_mesh.links.new(group_input_005_6.outputs[2], reroute_005_3.inputs[0])
	    #reroute_001_7.Output -> combine_xyz_001.X
	    tube_ribbon_mesh.links.new(reroute_001_7.outputs[0], combine_xyz_001.inputs[0])
	    #repeat_input.Geometry -> join_geometry_3.Geometry
	    tube_ribbon_mesh.links.new(repeat_input.outputs[1], join_geometry_3.inputs[0])
	    return tube_ribbon_mesh
	
	tube_ribbon_mesh = tube_ribbon_mesh_node_group()
	
	#initialize root_edge_finder node group
	def root_edge_finder_node_group():
	    root_edge_finder = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Root_Edge_Finder")
	
	    root_edge_finder.color_tag = 'NONE'
	    root_edge_finder.description = ""
	    root_edge_finder.default_group_node_width = 140
	    
	
	
	    #root_edge_finder interface
	    #Socket Geometry
	    geometry_socket_20 = root_edge_finder.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_20.attribute_domain = 'POINT'
	
	    #Socket Geometry
	    geometry_socket_21 = root_edge_finder.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_21.attribute_domain = 'POINT'
	
	    #Socket Attribute
	    attribute_socket = root_edge_finder.interface.new_socket(name = "Attribute", in_out='INPUT', socket_type = 'NodeSocketVector')
	    attribute_socket.default_value = (0.0, 0.0, 0.0)
	    attribute_socket.min_value = -3.4028234663852886e+38
	    attribute_socket.max_value = 3.4028234663852886e+38
	    attribute_socket.subtype = 'NONE'
	    attribute_socket.attribute_domain = 'POINT'
	
	
	    #initialize root_edge_finder nodes
	    #node Group Output
	    group_output_16 = root_edge_finder.nodes.new("NodeGroupOutput")
	    group_output_16.name = "Group Output"
	    group_output_16.is_active_output = True
	
	    #node Group Input
	    group_input_12 = root_edge_finder.nodes.new("NodeGroupInput")
	    group_input_12.name = "Group Input"
	    group_input_12.outputs[1].hide = True
	    group_input_12.outputs[2].hide = True
	
	    #node Store Named Attribute.001
	    store_named_attribute_001_1 = root_edge_finder.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_001_1.name = "Store Named Attribute.001"
	    store_named_attribute_001_1.data_type = 'BOOLEAN'
	    store_named_attribute_001_1.domain = 'EDGE'
	    #Selection
	    store_named_attribute_001_1.inputs[1].default_value = True
	    #Name
	    store_named_attribute_001_1.inputs[2].default_value = "root_edge"
	
	    #node Separate XYZ
	    separate_xyz_2 = root_edge_finder.nodes.new("ShaderNodeSeparateXYZ")
	    separate_xyz_2.name = "Separate XYZ"
	    separate_xyz_2.hide = True
	
	    #node Edge Vertices
	    edge_vertices = root_edge_finder.nodes.new("GeometryNodeInputMeshEdgeVertices")
	    edge_vertices.name = "Edge Vertices"
	    edge_vertices.outputs[2].hide = True
	    edge_vertices.outputs[3].hide = True
	
	    #node Compare.004
	    compare_004_3 = root_edge_finder.nodes.new("FunctionNodeCompare")
	    compare_004_3.name = "Compare.004"
	    compare_004_3.hide = True
	    compare_004_3.data_type = 'FLOAT'
	    compare_004_3.mode = 'ELEMENT'
	    compare_004_3.operation = 'EQUAL'
	    #B
	    compare_004_3.inputs[1].default_value = 0.0
	    #Epsilon
	    compare_004_3.inputs[12].default_value = 0.0
	
	    #node Index
	    index_4 = root_edge_finder.nodes.new("GeometryNodeInputIndex")
	    index_4.name = "Index"
	    index_4.hide = True
	
	    #node Compare.005
	    compare_005_1 = root_edge_finder.nodes.new("FunctionNodeCompare")
	    compare_005_1.name = "Compare.005"
	    compare_005_1.hide = True
	    compare_005_1.data_type = 'INT'
	    compare_005_1.mode = 'ELEMENT'
	    compare_005_1.operation = 'EQUAL'
	
	    #node Compare.006
	    compare_006 = root_edge_finder.nodes.new("FunctionNodeCompare")
	    compare_006.name = "Compare.006"
	    compare_006.hide = True
	    compare_006.data_type = 'INT'
	    compare_006.mode = 'ELEMENT'
	    compare_006.operation = 'EQUAL'
	
	    #node Boolean Math
	    boolean_math_3 = root_edge_finder.nodes.new("FunctionNodeBooleanMath")
	    boolean_math_3.name = "Boolean Math"
	    boolean_math_3.hide = True
	    boolean_math_3.operation = 'OR'
	
	    #node Boolean Math.001
	    boolean_math_001_1 = root_edge_finder.nodes.new("FunctionNodeBooleanMath")
	    boolean_math_001_1.name = "Boolean Math.001"
	    boolean_math_001_1.hide = True
	    boolean_math_001_1.operation = 'AND'
	
	    #node Capture Attribute
	    capture_attribute_5 = root_edge_finder.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_5.name = "Capture Attribute"
	    capture_attribute_5.active_index = 1
	    capture_attribute_5.capture_items.clear()
	    capture_attribute_5.capture_items.new('FLOAT', "Index")
	    capture_attribute_5.capture_items["Index"].data_type = 'INT'
	    capture_attribute_5.capture_items.new('FLOAT', "Attribute")
	    capture_attribute_5.capture_items["Attribute"].data_type = 'FLOAT_VECTOR'
	    capture_attribute_5.domain = 'POINT'
	
	    #node Group Input.001
	    group_input_001_9 = root_edge_finder.nodes.new("NodeGroupInput")
	    group_input_001_9.name = "Group Input.001"
	    group_input_001_9.outputs[0].hide = True
	    group_input_001_9.outputs[2].hide = True
	
	
	
	
	
	    #Set locations
	    group_output_16.location = (718.633544921875, 0.0)
	    group_input_12.location = (-728.6337890625, 0.0)
	    store_named_attribute_001_1.location = (528.633544921875, 64.55459594726562)
	    separate_xyz_2.location = (11.952392578125, -93.82865905761719)
	    edge_vertices.location = (-175.849853515625, -119.31477355957031)
	    compare_004_3.location = (176.701171875, -106.4959716796875)
	    index_4.location = (-528.6337890625, -45.0521354675293)
	    compare_005_1.location = (6.56298828125, -132.4685821533203)
	    compare_006.location = (6.56298828125, -171.0046844482422)
	    boolean_math_3.location = (177.131591796875, -143.75625610351562)
	    boolean_math_001_1.location = (349.9113464355469, -121.9170913696289)
	    capture_attribute_5.location = (-339.7451171875, 25.617305755615234)
	    group_input_001_9.location = (-527.7212524414062, -80.99462127685547)
	
	    #Set dimensions
	    group_output_16.width, group_output_16.height = 140.0, 100.0
	    group_input_12.width, group_input_12.height = 140.0, 100.0
	    store_named_attribute_001_1.width, store_named_attribute_001_1.height = 140.0, 100.0
	    separate_xyz_2.width, separate_xyz_2.height = 140.0, 100.0
	    edge_vertices.width, edge_vertices.height = 140.0, 100.0
	    compare_004_3.width, compare_004_3.height = 140.0, 100.0
	    index_4.width, index_4.height = 140.0, 100.0
	    compare_005_1.width, compare_005_1.height = 140.0, 100.0
	    compare_006.width, compare_006.height = 140.0, 100.0
	    boolean_math_3.width, boolean_math_3.height = 140.0, 100.0
	    boolean_math_001_1.width, boolean_math_001_1.height = 140.0, 100.0
	    capture_attribute_5.width, capture_attribute_5.height = 140.0, 100.0
	    group_input_001_9.width, group_input_001_9.height = 140.0, 100.0
	
	    #initialize root_edge_finder links
	    #boolean_math_3.Boolean -> boolean_math_001_1.Boolean
	    root_edge_finder.links.new(boolean_math_3.outputs[0], boolean_math_001_1.inputs[1])
	    #edge_vertices.Vertex Index 2 -> compare_006.A
	    root_edge_finder.links.new(edge_vertices.outputs[1], compare_006.inputs[2])
	    #compare_006.Result -> boolean_math_3.Boolean
	    root_edge_finder.links.new(compare_006.outputs[0], boolean_math_3.inputs[1])
	    #capture_attribute_5.Attribute -> separate_xyz_2.Vector
	    root_edge_finder.links.new(capture_attribute_5.outputs[2], separate_xyz_2.inputs[0])
	    #capture_attribute_5.Index -> compare_005_1.A
	    root_edge_finder.links.new(capture_attribute_5.outputs[1], compare_005_1.inputs[2])
	    #capture_attribute_5.Index -> compare_006.B
	    root_edge_finder.links.new(capture_attribute_5.outputs[1], compare_006.inputs[3])
	    #edge_vertices.Vertex Index 1 -> compare_005_1.B
	    root_edge_finder.links.new(edge_vertices.outputs[0], compare_005_1.inputs[3])
	    #compare_005_1.Result -> boolean_math_3.Boolean
	    root_edge_finder.links.new(compare_005_1.outputs[0], boolean_math_3.inputs[0])
	    #capture_attribute_5.Geometry -> store_named_attribute_001_1.Geometry
	    root_edge_finder.links.new(capture_attribute_5.outputs[0], store_named_attribute_001_1.inputs[0])
	    #index_4.Index -> capture_attribute_5.Index
	    root_edge_finder.links.new(index_4.outputs[0], capture_attribute_5.inputs[1])
	    #compare_004_3.Result -> boolean_math_001_1.Boolean
	    root_edge_finder.links.new(compare_004_3.outputs[0], boolean_math_001_1.inputs[0])
	    #separate_xyz_2.X -> compare_004_3.A
	    root_edge_finder.links.new(separate_xyz_2.outputs[0], compare_004_3.inputs[0])
	    #boolean_math_001_1.Boolean -> store_named_attribute_001_1.Value
	    root_edge_finder.links.new(boolean_math_001_1.outputs[0], store_named_attribute_001_1.inputs[3])
	    #group_input_12.Geometry -> capture_attribute_5.Geometry
	    root_edge_finder.links.new(group_input_12.outputs[0], capture_attribute_5.inputs[0])
	    #store_named_attribute_001_1.Geometry -> group_output_16.Geometry
	    root_edge_finder.links.new(store_named_attribute_001_1.outputs[0], group_output_16.inputs[0])
	    #group_input_001_9.Attribute -> capture_attribute_5.Attribute
	    root_edge_finder.links.new(group_input_001_9.outputs[1], capture_attribute_5.inputs[2])
	    return root_edge_finder
	
	root_edge_finder = root_edge_finder_node_group()
	
	#initialize hair_shape_1 node group
	def hair_shape_1_node_group():
	    hair_shape_1 = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "HAIR_SHAPE")
	
	    hair_shape_1.color_tag = 'NONE'
	    hair_shape_1.description = ""
	    hair_shape_1.default_group_node_width = 140
	    
	
	    hair_shape_1.is_modifier = True
	
	    #hair_shape_1 interface
	    #Socket Geometry
	    geometry_socket_22 = hair_shape_1.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_22.attribute_domain = 'POINT'
	
	    #Socket Geometry
	    geometry_socket_23 = hair_shape_1.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_23.attribute_domain = 'POINT'
	
	    #Socket Style Select
	    style_select_socket = hair_shape_1.interface.new_socket(name = "Style Select", in_out='INPUT', socket_type = 'NodeSocketMenu')
	    style_select_socket.attribute_domain = 'POINT'
	
	    #Socket Curve Radius
	    curve_radius_socket_3 = hair_shape_1.interface.new_socket(name = "Curve Radius", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    curve_radius_socket_3.default_value = 1.0
	    curve_radius_socket_3.min_value = 0.0
	    curve_radius_socket_3.max_value = 3.4028234663852886e+38
	    curve_radius_socket_3.subtype = 'DISTANCE'
	    curve_radius_socket_3.attribute_domain = 'POINT'
	    curve_radius_socket_3.hide_value = True
	    curve_radius_socket_3.hide_in_modifier = True
	
	    #Socket Resolution
	    resolution_socket_3 = hair_shape_1.interface.new_socket(name = "Resolution", in_out='INPUT', socket_type = 'NodeSocketInt')
	    resolution_socket_3.default_value = 0
	    resolution_socket_3.min_value = 2
	    resolution_socket_3.max_value = 512
	    resolution_socket_3.subtype = 'NONE'
	    resolution_socket_3.attribute_domain = 'POINT'
	
	    #Socket Width
	    width_socket_2 = hair_shape_1.interface.new_socket(name = "Width", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    width_socket_2.default_value = 0.10000000149011612
	    width_socket_2.min_value = 0.0
	    width_socket_2.max_value = 3.4028234663852886e+38
	    width_socket_2.subtype = 'DISTANCE'
	    width_socket_2.attribute_domain = 'POINT'
	
	    #Socket Material
	    material_socket_4 = hair_shape_1.interface.new_socket(name = "Material", in_out='INPUT', socket_type = 'NodeSocketMaterial')
	    material_socket_4.attribute_domain = 'POINT'
	
	    #Socket Hair Card Angle
	    hair_card_angle_socket = hair_shape_1.interface.new_socket(name = "Hair Card Angle", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    hair_card_angle_socket.default_value = 45.0
	    hair_card_angle_socket.min_value = -90.0
	    hair_card_angle_socket.max_value = 90.0
	    hair_card_angle_socket.subtype = 'ANGLE'
	    hair_card_angle_socket.attribute_domain = 'POINT'
	
	    #Socket Tube Ribbon Count
	    tube_ribbon_count_socket = hair_shape_1.interface.new_socket(name = "Tube Ribbon Count", in_out='INPUT', socket_type = 'NodeSocketInt')
	    tube_ribbon_count_socket.default_value = 8
	    tube_ribbon_count_socket.min_value = 1
	    tube_ribbon_count_socket.max_value = 180
	    tube_ribbon_count_socket.subtype = 'NONE'
	    tube_ribbon_count_socket.attribute_domain = 'POINT'
	
	    #Socket Profile Curve
	    profile_curve_socket = hair_shape_1.interface.new_socket(name = "Profile Curve", in_out='INPUT', socket_type = 'NodeSocketObject')
	    profile_curve_socket.attribute_domain = 'POINT'
	
	    #Socket Profile Translation
	    profile_translation_socket = hair_shape_1.interface.new_socket(name = "Profile Translation", in_out='INPUT', socket_type = 'NodeSocketVector')
	    profile_translation_socket.default_value = (0.0, 0.0, 0.0)
	    profile_translation_socket.min_value = -3.4028234663852886e+38
	    profile_translation_socket.max_value = 3.4028234663852886e+38
	    profile_translation_socket.subtype = 'TRANSLATION'
	    profile_translation_socket.attribute_domain = 'POINT'
	
	    #Socket Profile Rotation
	    profile_rotation_socket = hair_shape_1.interface.new_socket(name = "Profile Rotation", in_out='INPUT', socket_type = 'NodeSocketRotation')
	    profile_rotation_socket.default_value = (0.0, 0.0, 0.0)
	    profile_rotation_socket.attribute_domain = 'POINT'
	
	    #Socket Profile Scale
	    profile_scale_socket = hair_shape_1.interface.new_socket(name = "Profile Scale", in_out='INPUT', socket_type = 'NodeSocketVector')
	    profile_scale_socket.default_value = (1.0, 1.0, 1.0)
	    profile_scale_socket.min_value = -3.4028234663852886e+38
	    profile_scale_socket.max_value = 3.4028234663852886e+38
	    profile_scale_socket.subtype = 'XYZ'
	    profile_scale_socket.attribute_domain = 'POINT'
	
	
	    #initialize hair_shape_1 nodes
	    #node Group Output
	    group_output_17 = hair_shape_1.nodes.new("NodeGroupOutput")
	    group_output_17.name = "Group Output"
	    group_output_17.is_active_output = True
	    group_output_17.inputs[1].hide = True
	
	    #node Group
	    group_5 = hair_shape_1.nodes.new("GeometryNodeGroup")
	    group_5.name = "Group"
	    group_5.node_tree = hair_card
	    group_5.inputs[1].hide = True
	
	    #node Group.001
	    group_001_4 = hair_shape_1.nodes.new("GeometryNodeGroup")
	    group_001_4.name = "Group.001"
	    group_001_4.node_tree = stylized_hair_mesh
	    group_001_4.inputs[2].hide = True
	    group_001_4.inputs[5].hide = True
	    #Socket_6
	    group_001_4.inputs[5].default_value = False
	
	    #node Group.003
	    group_003_2 = hair_shape_1.nodes.new("GeometryNodeGroup")
	    group_003_2.name = "Group.003"
	    group_003_2.node_tree = tube_ribbon_mesh
	    group_003_2.inputs[1].hide = True
	
	    #node Group Input.001
	    group_input_001_10 = hair_shape_1.nodes.new("NodeGroupInput")
	    group_input_001_10.name = "Group Input.001"
	    group_input_001_10.outputs[1].hide = True
	    group_input_001_10.outputs[5].hide = True
	    group_input_001_10.outputs[7].hide = True
	    group_input_001_10.outputs[8].hide = True
	    group_input_001_10.outputs[9].hide = True
	    group_input_001_10.outputs[10].hide = True
	    group_input_001_10.outputs[11].hide = True
	    group_input_001_10.outputs[12].hide = True
	
	    #node Group Input.003
	    group_input_003_8 = hair_shape_1.nodes.new("NodeGroupInput")
	    group_input_003_8.name = "Group Input.003"
	    group_input_003_8.outputs[1].hide = True
	    group_input_003_8.outputs[5].hide = True
	    group_input_003_8.outputs[6].hide = True
	    group_input_003_8.outputs[8].hide = True
	    group_input_003_8.outputs[9].hide = True
	    group_input_003_8.outputs[10].hide = True
	    group_input_003_8.outputs[11].hide = True
	    group_input_003_8.outputs[12].hide = True
	
	    #node Group Input.004
	    group_input_004_6 = hair_shape_1.nodes.new("NodeGroupInput")
	    group_input_004_6.name = "Group Input.004"
	    group_input_004_6.outputs[1].hide = True
	    group_input_004_6.outputs[4].hide = True
	    group_input_004_6.outputs[5].hide = True
	    group_input_004_6.outputs[6].hide = True
	    group_input_004_6.outputs[7].hide = True
	    group_input_004_6.outputs[8].hide = True
	    group_input_004_6.outputs[12].hide = True
	
	    #node Menu Switch.001
	    menu_switch_001 = hair_shape_1.nodes.new("GeometryNodeMenuSwitch")
	    menu_switch_001.name = "Menu Switch.001"
	    menu_switch_001.active_index = 2
	    menu_switch_001.data_type = 'STRING'
	    menu_switch_001.enum_items.clear()
	    menu_switch_001.enum_items.new("Hair Card")
	    menu_switch_001.enum_items[0].description = ""
	    menu_switch_001.enum_items.new("Tube Ribbon")
	    menu_switch_001.enum_items[1].description = ""
	    menu_switch_001.enum_items.new("Stylized")
	    menu_switch_001.enum_items[2].description = ""
	    menu_switch_001.inputs[4].hide = True
	
	    #node Store Named Attribute
	    store_named_attribute_5 = hair_shape_1.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_5.name = "Store Named Attribute"
	    store_named_attribute_5.data_type = 'FLOAT2'
	    store_named_attribute_5.domain = 'CORNER'
	    #Selection
	    store_named_attribute_5.inputs[1].default_value = True
	    #Name
	    store_named_attribute_5.inputs[2].default_value = "UVMap"
	
	    #node Named Attribute
	    named_attribute_3 = hair_shape_1.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute_3.name = "Named Attribute"
	    named_attribute_3.data_type = 'FLOAT_VECTOR'
	
	    #node Group Input.005
	    group_input_005_7 = hair_shape_1.nodes.new("NodeGroupInput")
	    group_input_005_7.name = "Group Input.005"
	    group_input_005_7.outputs[0].hide = True
	    group_input_005_7.outputs[2].hide = True
	    group_input_005_7.outputs[3].hide = True
	    group_input_005_7.outputs[4].hide = True
	    group_input_005_7.outputs[5].hide = True
	    group_input_005_7.outputs[6].hide = True
	    group_input_005_7.outputs[7].hide = True
	    group_input_005_7.outputs[8].hide = True
	    group_input_005_7.outputs[9].hide = True
	    group_input_005_7.outputs[10].hide = True
	    group_input_005_7.outputs[11].hide = True
	    group_input_005_7.outputs[12].hide = True
	
	    #node Group Input.006
	    group_input_006_5 = hair_shape_1.nodes.new("NodeGroupInput")
	    group_input_006_5.name = "Group Input.006"
	    group_input_006_5.outputs[0].hide = True
	    group_input_006_5.outputs[1].hide = True
	    group_input_006_5.outputs[2].hide = True
	    group_input_006_5.outputs[3].hide = True
	    group_input_006_5.outputs[4].hide = True
	    group_input_006_5.outputs[5].hide = True
	    group_input_006_5.outputs[6].hide = True
	    group_input_006_5.outputs[7].hide = True
	    group_input_006_5.outputs[9].hide = True
	    group_input_006_5.outputs[10].hide = True
	    group_input_006_5.outputs[11].hide = True
	    group_input_006_5.outputs[12].hide = True
	
	    #node Compare
	    compare_8 = hair_shape_1.nodes.new("FunctionNodeCompare")
	    compare_8.name = "Compare"
	    compare_8.hide = True
	    compare_8.data_type = 'STRING'
	    compare_8.mode = 'ELEMENT'
	    compare_8.operation = 'EQUAL'
	
	    #node Switch
	    switch_9 = hair_shape_1.nodes.new("GeometryNodeSwitch")
	    switch_9.name = "Switch"
	    switch_9.hide = True
	    switch_9.input_type = 'GEOMETRY'
	
	    #node Compare.002
	    compare_002_6 = hair_shape_1.nodes.new("FunctionNodeCompare")
	    compare_002_6.name = "Compare.002"
	    compare_002_6.hide = True
	    compare_002_6.data_type = 'STRING'
	    compare_002_6.mode = 'ELEMENT'
	    compare_002_6.operation = 'EQUAL'
	
	    #node Switch.002
	    switch_002_3 = hair_shape_1.nodes.new("GeometryNodeSwitch")
	    switch_002_3.name = "Switch.002"
	    switch_002_3.hide = True
	    switch_002_3.input_type = 'GEOMETRY'
	
	    #node Compare.003
	    compare_003_4 = hair_shape_1.nodes.new("FunctionNodeCompare")
	    compare_003_4.name = "Compare.003"
	    compare_003_4.hide = True
	    compare_003_4.data_type = 'STRING'
	    compare_003_4.mode = 'ELEMENT'
	    compare_003_4.operation = 'EQUAL'
	
	    #node Switch.003
	    switch_003_4 = hair_shape_1.nodes.new("GeometryNodeSwitch")
	    switch_003_4.name = "Switch.003"
	    switch_003_4.hide = True
	    switch_003_4.input_type = 'GEOMETRY'
	
	    #node String
	    string = hair_shape_1.nodes.new("FunctionNodeInputString")
	    string.name = "String"
	    string.string = "hair_card_UV"
	
	    #node String.002
	    string_002 = hair_shape_1.nodes.new("FunctionNodeInputString")
	    string_002.name = "String.002"
	    string_002.string = "ribbon_mesh_UV"
	
	    #node String.003
	    string_003 = hair_shape_1.nodes.new("FunctionNodeInputString")
	    string_003.name = "String.003"
	    string_003.string = "stylized_hair_UV"
	
	    #node Reroute
	    reroute_11 = hair_shape_1.nodes.new("NodeReroute")
	    reroute_11.name = "Reroute"
	    reroute_11.socket_idname = "NodeSocketString"
	    #node Reroute.002
	    reroute_002_6 = hair_shape_1.nodes.new("NodeReroute")
	    reroute_002_6.name = "Reroute.002"
	    reroute_002_6.socket_idname = "NodeSocketString"
	    #node Reroute.003
	    reroute_003_5 = hair_shape_1.nodes.new("NodeReroute")
	    reroute_003_5.name = "Reroute.003"
	    reroute_003_5.socket_idname = "NodeSocketString"
	    #node Reroute.004
	    reroute_004_6 = hair_shape_1.nodes.new("NodeReroute")
	    reroute_004_6.name = "Reroute.004"
	    reroute_004_6.socket_idname = "NodeSocketString"
	    #node Reroute.006
	    reroute_006_3 = hair_shape_1.nodes.new("NodeReroute")
	    reroute_006_3.name = "Reroute.006"
	    reroute_006_3.socket_idname = "NodeSocketString"
	    #node Reroute.007
	    reroute_007_3 = hair_shape_1.nodes.new("NodeReroute")
	    reroute_007_3.name = "Reroute.007"
	    reroute_007_3.socket_idname = "NodeSocketString"
	    #node Reroute.008
	    reroute_008_3 = hair_shape_1.nodes.new("NodeReroute")
	    reroute_008_3.name = "Reroute.008"
	    reroute_008_3.socket_idname = "NodeSocketString"
	    #node Reroute.009
	    reroute_009_3 = hair_shape_1.nodes.new("NodeReroute")
	    reroute_009_3.name = "Reroute.009"
	    reroute_009_3.socket_idname = "NodeSocketString"
	    #node Reroute.010
	    reroute_010_2 = hair_shape_1.nodes.new("NodeReroute")
	    reroute_010_2.name = "Reroute.010"
	    reroute_010_2.socket_idname = "NodeSocketString"
	    #node Reroute.012
	    reroute_012_4 = hair_shape_1.nodes.new("NodeReroute")
	    reroute_012_4.name = "Reroute.012"
	    reroute_012_4.socket_idname = "NodeSocketString"
	    #node Reroute.013
	    reroute_013_4 = hair_shape_1.nodes.new("NodeReroute")
	    reroute_013_4.name = "Reroute.013"
	    reroute_013_4.socket_idname = "NodeSocketString"
	    #node Reroute.014
	    reroute_014_3 = hair_shape_1.nodes.new("NodeReroute")
	    reroute_014_3.name = "Reroute.014"
	    reroute_014_3.socket_idname = "NodeSocketString"
	    #node Named Attribute.001
	    named_attribute_001_1 = hair_shape_1.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute_001_1.name = "Named Attribute.001"
	    named_attribute_001_1.hide = True
	    named_attribute_001_1.data_type = 'FLOAT_VECTOR'
	    #Name
	    named_attribute_001_1.inputs[0].default_value = "UVMap"
	
	    #node Group.004
	    group_004_2 = hair_shape_1.nodes.new("GeometryNodeGroup")
	    group_004_2.name = "Group.004"
	    group_004_2.node_tree = root_edge_finder
	
	    #node Set Material
	    set_material_4 = hair_shape_1.nodes.new("GeometryNodeSetMaterial")
	    set_material_4.name = "Set Material"
	    #Selection
	    set_material_4.inputs[1].default_value = True
	
	    #node Group Input.007
	    group_input_007_4 = hair_shape_1.nodes.new("NodeGroupInput")
	    group_input_007_4.name = "Group Input.007"
	    group_input_007_4.outputs[0].hide = True
	    group_input_007_4.outputs[1].hide = True
	    group_input_007_4.outputs[2].hide = True
	    group_input_007_4.outputs[3].hide = True
	    group_input_007_4.outputs[4].hide = True
	    group_input_007_4.outputs[6].hide = True
	    group_input_007_4.outputs[7].hide = True
	    group_input_007_4.outputs[8].hide = True
	    group_input_007_4.outputs[9].hide = True
	    group_input_007_4.outputs[10].hide = True
	    group_input_007_4.outputs[11].hide = True
	    group_input_007_4.outputs[12].hide = True
	
	    #node Remove Named Attribute
	    remove_named_attribute = hair_shape_1.nodes.new("GeometryNodeRemoveAttribute")
	    remove_named_attribute.name = "Remove Named Attribute"
	    remove_named_attribute.pattern_mode = 'EXACT'
	
	    #node Reroute.001
	    reroute_001_8 = hair_shape_1.nodes.new("NodeReroute")
	    reroute_001_8.name = "Reroute.001"
	    reroute_001_8.socket_idname = "NodeSocketString"
	    #node Reroute.005
	    reroute_005_4 = hair_shape_1.nodes.new("NodeReroute")
	    reroute_005_4.name = "Reroute.005"
	    reroute_005_4.socket_idname = "NodeSocketString"
	
	
	
	
	    #Set locations
	    group_output_17.location = (2279.355712890625, 100.73884582519531)
	    group_5.location = (-79.76215362548828, -110.40367889404297)
	    group_001_4.location = (-81.79773712158203, -586.5357055664062)
	    group_003_2.location = (-78.67485809326172, -363.6705627441406)
	    group_input_001_10.location = (-338.60595703125, -155.34437561035156)
	    group_input_003_8.location = (-338.60595703125, -407.43646240234375)
	    group_input_004_6.location = (-338.60595703125, -652.7152099609375)
	    menu_switch_001.location = (469.07684326171875, 163.7274627685547)
	    store_named_attribute_5.location = (1523.048583984375, -19.652393341064453)
	    named_attribute_3.location = (1351.15966796875, -157.7658233642578)
	    group_input_005_7.location = (265.0098571777344, 135.95323181152344)
	    group_input_006_5.location = (-338.60595703125, -594.0604858398438)
	    compare_8.location = (1114.0462646484375, -84.21184539794922)
	    switch_9.location = (1114.0589599609375, -117.19403076171875)
	    compare_002_6.location = (970.40234375, -337.4306335449219)
	    switch_002_3.location = (975.1282958984375, -372.77142333984375)
	    compare_003_4.location = (837.8390502929688, -561.7108764648438)
	    switch_003_4.location = (840.2083740234375, -597.887451171875)
	    string.location = (84.04959869384766, -54.475547790527344)
	    string_002.location = (79.31243896484375, -308.982421875)
	    string_003.location = (76.95584106445312, -534.5404052734375)
	    reroute_11.location = (266.1946716308594, -90.37294006347656)
	    reroute_002_6.location = (386.08740234375, -344.9817199707031)
	    reroute_003_5.location = (432.0370178222656, -572.8853759765625)
	    reroute_004_6.location = (267.64080810546875, 58.478363037109375)
	    reroute_006_3.location = (388.06353759765625, 34.71890640258789)
	    reroute_007_3.location = (434.48321533203125, 15.083160400390625)
	    reroute_008_3.location = (790.6254272460938, 129.04226684570312)
	    reroute_009_3.location = (800.4947509765625, -565.0940551757812)
	    reroute_010_2.location = (796.8050537109375, -336.4729309082031)
	    reroute_012_4.location = (790.7710571289062, -80.90033721923828)
	    reroute_013_4.location = (1290.490966796875, -261.59454345703125)
	    reroute_014_3.location = (1289.1600341796875, 129.6073760986328)
	    named_attribute_001_1.location = (1915.0404052734375, -57.07986068725586)
	    group_004_2.location = (1913.101806640625, 78.2515869140625)
	    set_material_4.location = (2105.3662109375, 102.2623291015625)
	    group_input_007_4.location = (1915.105712890625, -94.34074401855469)
	    remove_named_attribute.location = (1703.0, 28.8780517578125)
	    reroute_001_8.location = (1676.462890625, 128.53257751464844)
	    reroute_005_4.location = (1679.5771484375, -76.36426544189453)
	
	    #Set dimensions
	    group_output_17.width, group_output_17.height = 140.0, 100.0
	    group_5.width, group_5.height = 140.0, 100.0
	    group_001_4.width, group_001_4.height = 140.0, 100.0
	    group_003_2.width, group_003_2.height = 140.0, 100.0
	    group_input_001_10.width, group_input_001_10.height = 140.0, 100.0
	    group_input_003_8.width, group_input_003_8.height = 140.0, 100.0
	    group_input_004_6.width, group_input_004_6.height = 140.0, 100.0
	    menu_switch_001.width, menu_switch_001.height = 245.18148803710938, 100.0
	    store_named_attribute_5.width, store_named_attribute_5.height = 140.0, 100.0
	    named_attribute_3.width, named_attribute_3.height = 140.0, 100.0
	    group_input_005_7.width, group_input_005_7.height = 140.0, 100.0
	    group_input_006_5.width, group_input_006_5.height = 140.0, 100.0
	    compare_8.width, compare_8.height = 140.0, 100.0
	    switch_9.width, switch_9.height = 140.0, 100.0
	    compare_002_6.width, compare_002_6.height = 140.0, 100.0
	    switch_002_3.width, switch_002_3.height = 140.0, 100.0
	    compare_003_4.width, compare_003_4.height = 140.0, 100.0
	    switch_003_4.width, switch_003_4.height = 140.0, 100.0
	    string.width, string.height = 140.0, 100.0
	    string_002.width, string_002.height = 140.0, 100.0
	    string_003.width, string_003.height = 140.0, 100.0
	    reroute_11.width, reroute_11.height = 100.0, 100.0
	    reroute_002_6.width, reroute_002_6.height = 100.0, 100.0
	    reroute_003_5.width, reroute_003_5.height = 100.0, 100.0
	    reroute_004_6.width, reroute_004_6.height = 100.0, 100.0
	    reroute_006_3.width, reroute_006_3.height = 100.0, 100.0
	    reroute_007_3.width, reroute_007_3.height = 100.0, 100.0
	    reroute_008_3.width, reroute_008_3.height = 100.0, 100.0
	    reroute_009_3.width, reroute_009_3.height = 100.0, 100.0
	    reroute_010_2.width, reroute_010_2.height = 100.0, 100.0
	    reroute_012_4.width, reroute_012_4.height = 100.0, 100.0
	    reroute_013_4.width, reroute_013_4.height = 100.0, 100.0
	    reroute_014_3.width, reroute_014_3.height = 100.0, 100.0
	    named_attribute_001_1.width, named_attribute_001_1.height = 140.0, 100.0
	    group_004_2.width, group_004_2.height = 140.0, 100.0
	    set_material_4.width, set_material_4.height = 140.0, 100.0
	    group_input_007_4.width, group_input_007_4.height = 140.0, 100.0
	    remove_named_attribute.width, remove_named_attribute.height = 170.0, 100.0
	    reroute_001_8.width, reroute_001_8.height = 100.0, 100.0
	    reroute_005_4.width, reroute_005_4.height = 100.0, 100.0
	
	    #initialize hair_shape_1 links
	    #set_material_4.Geometry -> group_output_17.Geometry
	    hair_shape_1.links.new(set_material_4.outputs[0], group_output_17.inputs[0])
	    #group_input_001_10.Geometry -> group_5.Geometry
	    hair_shape_1.links.new(group_input_001_10.outputs[0], group_5.inputs[0])
	    #group_input_003_8.Geometry -> group_003_2.Geometry
	    hair_shape_1.links.new(group_input_003_8.outputs[0], group_003_2.inputs[0])
	    #group_input_004_6.Geometry -> group_001_4.Geometry
	    hair_shape_1.links.new(group_input_004_6.outputs[0], group_001_4.inputs[0])
	    #group_input_001_10.Curve Radius -> group_5.Curve Radius
	    hair_shape_1.links.new(group_input_001_10.outputs[2], group_5.inputs[2])
	    #named_attribute_3.Attribute -> store_named_attribute_5.Value
	    hair_shape_1.links.new(named_attribute_3.outputs[0], store_named_attribute_5.inputs[3])
	    #reroute_013_4.Output -> named_attribute_3.Name
	    hair_shape_1.links.new(reroute_013_4.outputs[0], named_attribute_3.inputs[0])
	    #group_input_005_7.Style Select -> menu_switch_001.Menu
	    hair_shape_1.links.new(group_input_005_7.outputs[1], menu_switch_001.inputs[0])
	    #group_input_001_10.Resolution -> group_5.Resolution
	    hair_shape_1.links.new(group_input_001_10.outputs[3], group_5.inputs[3])
	    #group_input_001_10.Width -> group_5.Width
	    hair_shape_1.links.new(group_input_001_10.outputs[4], group_5.inputs[4])
	    #group_input_001_10.Hair Card Angle -> group_5.Angle
	    hair_shape_1.links.new(group_input_001_10.outputs[6], group_5.inputs[5])
	    #group_input_003_8.Curve Radius -> group_003_2.Curve Radius
	    hair_shape_1.links.new(group_input_003_8.outputs[2], group_003_2.inputs[2])
	    #group_input_003_8.Resolution -> group_003_2.Resolution
	    hair_shape_1.links.new(group_input_003_8.outputs[3], group_003_2.inputs[4])
	    #group_input_003_8.Width -> group_003_2.Width
	    hair_shape_1.links.new(group_input_003_8.outputs[4], group_003_2.inputs[5])
	    #group_input_003_8.Tube Ribbon Count -> group_003_2.Ribbon Count
	    hair_shape_1.links.new(group_input_003_8.outputs[7], group_003_2.inputs[3])
	    #group_input_004_6.Curve Radius -> group_001_4.Curve Radius
	    hair_shape_1.links.new(group_input_004_6.outputs[2], group_001_4.inputs[3])
	    #group_input_004_6.Profile Translation -> group_001_4.Translation
	    hair_shape_1.links.new(group_input_004_6.outputs[9], group_001_4.inputs[6])
	    #group_input_004_6.Profile Rotation -> group_001_4.Rotation
	    hair_shape_1.links.new(group_input_004_6.outputs[10], group_001_4.inputs[7])
	    #group_input_004_6.Profile Scale -> group_001_4.Scale
	    hair_shape_1.links.new(group_input_004_6.outputs[11], group_001_4.inputs[8])
	    #group_input_006_5.Profile Curve -> group_001_4.Profile
	    hair_shape_1.links.new(group_input_006_5.outputs[8], group_001_4.inputs[1])
	    #group_input_004_6.Resolution -> group_001_4.Resolution
	    hair_shape_1.links.new(group_input_004_6.outputs[3], group_001_4.inputs[4])
	    #compare_8.Result -> switch_9.Switch
	    hair_shape_1.links.new(compare_8.outputs[0], switch_9.inputs[0])
	    #compare_002_6.Result -> switch_002_3.Switch
	    hair_shape_1.links.new(compare_002_6.outputs[0], switch_002_3.inputs[0])
	    #reroute_009_3.Output -> compare_003_4.A
	    hair_shape_1.links.new(reroute_009_3.outputs[0], compare_003_4.inputs[8])
	    #compare_003_4.Result -> switch_003_4.Switch
	    hair_shape_1.links.new(compare_003_4.outputs[0], switch_003_4.inputs[0])
	    #switch_003_4.Output -> switch_002_3.False
	    hair_shape_1.links.new(switch_003_4.outputs[0], switch_002_3.inputs[1])
	    #reroute_004_6.Output -> menu_switch_001.Hair Card
	    hair_shape_1.links.new(reroute_004_6.outputs[0], menu_switch_001.inputs[1])
	    #reroute_11.Output -> compare_8.B
	    hair_shape_1.links.new(reroute_11.outputs[0], compare_8.inputs[9])
	    #group_5.Geometry -> switch_9.True
	    hair_shape_1.links.new(group_5.outputs[0], switch_9.inputs[2])
	    #reroute_006_3.Output -> menu_switch_001.Tube Ribbon
	    hair_shape_1.links.new(reroute_006_3.outputs[0], menu_switch_001.inputs[2])
	    #reroute_002_6.Output -> compare_002_6.B
	    hair_shape_1.links.new(reroute_002_6.outputs[0], compare_002_6.inputs[9])
	    #group_003_2.Geometry -> switch_002_3.True
	    hair_shape_1.links.new(group_003_2.outputs[0], switch_002_3.inputs[2])
	    #reroute_007_3.Output -> menu_switch_001.Stylized
	    hair_shape_1.links.new(reroute_007_3.outputs[0], menu_switch_001.inputs[3])
	    #reroute_003_5.Output -> compare_003_4.B
	    hair_shape_1.links.new(reroute_003_5.outputs[0], compare_003_4.inputs[9])
	    #group_001_4.Geometry -> switch_003_4.True
	    hair_shape_1.links.new(group_001_4.outputs[0], switch_003_4.inputs[2])
	    #switch_9.Output -> store_named_attribute_5.Geometry
	    hair_shape_1.links.new(switch_9.outputs[0], store_named_attribute_5.inputs[0])
	    #string.String -> reroute_11.Input
	    hair_shape_1.links.new(string.outputs[0], reroute_11.inputs[0])
	    #string_002.String -> reroute_002_6.Input
	    hair_shape_1.links.new(string_002.outputs[0], reroute_002_6.inputs[0])
	    #string_003.String -> reroute_003_5.Input
	    hair_shape_1.links.new(string_003.outputs[0], reroute_003_5.inputs[0])
	    #reroute_11.Output -> reroute_004_6.Input
	    hair_shape_1.links.new(reroute_11.outputs[0], reroute_004_6.inputs[0])
	    #reroute_002_6.Output -> reroute_006_3.Input
	    hair_shape_1.links.new(reroute_002_6.outputs[0], reroute_006_3.inputs[0])
	    #reroute_003_5.Output -> reroute_007_3.Input
	    hair_shape_1.links.new(reroute_003_5.outputs[0], reroute_007_3.inputs[0])
	    #menu_switch_001.Output -> reroute_008_3.Input
	    hair_shape_1.links.new(menu_switch_001.outputs[0], reroute_008_3.inputs[0])
	    #reroute_010_2.Output -> reroute_009_3.Input
	    hair_shape_1.links.new(reroute_010_2.outputs[0], reroute_009_3.inputs[0])
	    #reroute_012_4.Output -> reroute_010_2.Input
	    hair_shape_1.links.new(reroute_012_4.outputs[0], reroute_010_2.inputs[0])
	    #reroute_010_2.Output -> compare_002_6.A
	    hair_shape_1.links.new(reroute_010_2.outputs[0], compare_002_6.inputs[8])
	    #reroute_008_3.Output -> reroute_012_4.Input
	    hair_shape_1.links.new(reroute_008_3.outputs[0], reroute_012_4.inputs[0])
	    #reroute_012_4.Output -> compare_8.A
	    hair_shape_1.links.new(reroute_012_4.outputs[0], compare_8.inputs[8])
	    #reroute_014_3.Output -> reroute_013_4.Input
	    hair_shape_1.links.new(reroute_014_3.outputs[0], reroute_013_4.inputs[0])
	    #reroute_008_3.Output -> reroute_014_3.Input
	    hair_shape_1.links.new(reroute_008_3.outputs[0], reroute_014_3.inputs[0])
	    #remove_named_attribute.Geometry -> group_004_2.Geometry
	    hair_shape_1.links.new(remove_named_attribute.outputs[0], group_004_2.inputs[0])
	    #named_attribute_001_1.Attribute -> group_004_2.Attribute
	    hair_shape_1.links.new(named_attribute_001_1.outputs[0], group_004_2.inputs[1])
	    #switch_002_3.Output -> switch_9.False
	    hair_shape_1.links.new(switch_002_3.outputs[0], switch_9.inputs[1])
	    #group_004_2.Geometry -> set_material_4.Geometry
	    hair_shape_1.links.new(group_004_2.outputs[0], set_material_4.inputs[0])
	    #group_input_007_4.Material -> set_material_4.Material
	    hair_shape_1.links.new(group_input_007_4.outputs[5], set_material_4.inputs[2])
	    #store_named_attribute_5.Geometry -> remove_named_attribute.Geometry
	    hair_shape_1.links.new(store_named_attribute_5.outputs[0], remove_named_attribute.inputs[0])
	    #reroute_005_4.Output -> remove_named_attribute.Name
	    hair_shape_1.links.new(reroute_005_4.outputs[0], remove_named_attribute.inputs[1])
	    #reroute_014_3.Output -> reroute_001_8.Input
	    hair_shape_1.links.new(reroute_014_3.outputs[0], reroute_001_8.inputs[0])
	    #reroute_001_8.Output -> reroute_005_4.Input
	    hair_shape_1.links.new(reroute_001_8.outputs[0], reroute_005_4.inputs[0])
	    return hair_shape_1
	
	hair_shape_1 = hair_shape_1_node_group()
	
	#initialize align_curve_to_surface node group
	def align_curve_to_surface_node_group():
	    align_curve_to_surface = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Align_Curve_to_Surface")
	
	    align_curve_to_surface.color_tag = 'NONE'
	    align_curve_to_surface.description = ""
	    align_curve_to_surface.default_group_node_width = 140
	    
	
	
	    #align_curve_to_surface interface
	    #Socket Geometry
	    geometry_socket_24 = align_curve_to_surface.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_24.attribute_domain = 'POINT'
	
	    #Socket Tilt
	    tilt_socket = align_curve_to_surface.interface.new_socket(name = "Tilt", in_out='OUTPUT', socket_type = 'NodeSocketFloat')
	    tilt_socket.default_value = 0.0
	    tilt_socket.min_value = -3.4028234663852886e+38
	    tilt_socket.max_value = 3.4028234663852886e+38
	    tilt_socket.subtype = 'NONE'
	    tilt_socket.attribute_domain = 'POINT'
	
	    #Socket Geometry
	    geometry_socket_25 = align_curve_to_surface.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_25.attribute_domain = 'POINT'
	
	    #Socket Surface
	    surface_socket_6 = align_curve_to_surface.interface.new_socket(name = "Surface", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    surface_socket_6.attribute_domain = 'POINT'
	
	    #Socket Surface
	    surface_socket_7 = align_curve_to_surface.interface.new_socket(name = "Surface", in_out='INPUT', socket_type = 'NodeSocketObject')
	    surface_socket_7.attribute_domain = 'POINT'
	
	    #Socket Surface Align Factor
	    surface_align_factor_socket = align_curve_to_surface.interface.new_socket(name = "Surface Align Factor", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    surface_align_factor_socket.default_value = 1.0
	    surface_align_factor_socket.min_value = 0.0
	    surface_align_factor_socket.max_value = 1.0
	    surface_align_factor_socket.subtype = 'FACTOR'
	    surface_align_factor_socket.attribute_domain = 'POINT'
	
	
	    #initialize align_curve_to_surface nodes
	    #node Group Output
	    group_output_18 = align_curve_to_surface.nodes.new("NodeGroupOutput")
	    group_output_18.name = "Group Output"
	    group_output_18.is_active_output = True
	    group_output_18.inputs[2].hide = True
	
	    #node Group Input
	    group_input_13 = align_curve_to_surface.nodes.new("NodeGroupInput")
	    group_input_13.name = "Group Input"
	    group_input_13.outputs[3].hide = True
	    group_input_13.outputs[4].hide = True
	
	    #node Capture Attribute.004
	    capture_attribute_004_1 = align_curve_to_surface.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_004_1.name = "Capture Attribute.004"
	    capture_attribute_004_1.active_index = 2
	    capture_attribute_004_1.capture_items.clear()
	    capture_attribute_004_1.capture_items.new('FLOAT', "Normal")
	    capture_attribute_004_1.capture_items["Normal"].data_type = 'FLOAT_VECTOR'
	    capture_attribute_004_1.capture_items.new('FLOAT', "Tangent")
	    capture_attribute_004_1.capture_items["Tangent"].data_type = 'FLOAT_VECTOR'
	    capture_attribute_004_1.capture_items.new('FLOAT', "Position")
	    capture_attribute_004_1.capture_items["Position"].data_type = 'FLOAT_VECTOR'
	    capture_attribute_004_1.domain = 'POINT'
	    capture_attribute_004_1.inputs[4].hide = True
	    capture_attribute_004_1.outputs[4].hide = True
	
	    #node Normal.005
	    normal_005 = align_curve_to_surface.nodes.new("GeometryNodeInputNormal")
	    normal_005.name = "Normal.005"
	    normal_005.hide = True
	    normal_005.legacy_corner_normals = True
	
	    #node Curve Tangent.002
	    curve_tangent_002 = align_curve_to_surface.nodes.new("GeometryNodeInputTangent")
	    curve_tangent_002.name = "Curve Tangent.002"
	    curve_tangent_002.hide = True
	
	    #node Vector Math.004
	    vector_math_004_4 = align_curve_to_surface.nodes.new("ShaderNodeVectorMath")
	    vector_math_004_4.name = "Vector Math.004"
	    vector_math_004_4.hide = True
	    vector_math_004_4.operation = 'CROSS_PRODUCT'
	
	    #node Vector Math.007
	    vector_math_007_3 = align_curve_to_surface.nodes.new("ShaderNodeVectorMath")
	    vector_math_007_3.name = "Vector Math.007"
	    vector_math_007_3.hide = True
	    vector_math_007_3.operation = 'DOT_PRODUCT'
	
	    #node Sample Nearest.003
	    sample_nearest_003 = align_curve_to_surface.nodes.new("GeometryNodeSampleNearest")
	    sample_nearest_003.name = "Sample Nearest.003"
	    sample_nearest_003.hide = True
	    sample_nearest_003.domain = 'POINT'
	
	    #node Sample Index.003
	    sample_index_003_1 = align_curve_to_surface.nodes.new("GeometryNodeSampleIndex")
	    sample_index_003_1.name = "Sample Index.003"
	    sample_index_003_1.hide = True
	    sample_index_003_1.clamp = False
	    sample_index_003_1.data_type = 'FLOAT_VECTOR'
	    sample_index_003_1.domain = 'POINT'
	
	    #node Normal.006
	    normal_006 = align_curve_to_surface.nodes.new("GeometryNodeInputNormal")
	    normal_006.name = "Normal.006"
	    normal_006.legacy_corner_normals = True
	
	    #node Position.004
	    position_004_1 = align_curve_to_surface.nodes.new("GeometryNodeInputPosition")
	    position_004_1.name = "Position.004"
	    position_004_1.hide = True
	
	    #node Frame.007
	    frame_007_1 = align_curve_to_surface.nodes.new("NodeFrame")
	    frame_007_1.name = "Frame.007"
	    frame_007_1.label_size = 20
	    frame_007_1.shrink = True
	
	    #node Math.008
	    math_008 = align_curve_to_surface.nodes.new("ShaderNodeMath")
	    math_008.name = "Math.008"
	    math_008.hide = True
	    math_008.operation = 'ARCTAN2'
	    math_008.use_clamp = False
	
	    #node Vector Math.008
	    vector_math_008_2 = align_curve_to_surface.nodes.new("ShaderNodeVectorMath")
	    vector_math_008_2.name = "Vector Math.008"
	    vector_math_008_2.hide = True
	    vector_math_008_2.operation = 'DOT_PRODUCT'
	
	    #node Math.009
	    math_009_1 = align_curve_to_surface.nodes.new("ShaderNodeMath")
	    math_009_1.name = "Math.009"
	    math_009_1.hide = True
	    math_009_1.operation = 'ADD'
	    math_009_1.use_clamp = False
	    #Value_001
	    math_009_1.inputs[1].default_value = 90.0
	
	    #node Frame.006
	    frame_006_2 = align_curve_to_surface.nodes.new("NodeFrame")
	    frame_006_2.name = "Frame.006"
	    frame_006_2.label_size = 20
	    frame_006_2.shrink = True
	
	    #node Reroute
	    reroute_12 = align_curve_to_surface.nodes.new("NodeReroute")
	    reroute_12.name = "Reroute"
	    reroute_12.socket_idname = "NodeSocketGeometry"
	    #node Group
	    group_6 = align_curve_to_surface.nodes.new("GeometryNodeGroup")
	    group_6.name = "Group"
	    group_6.hide = True
	    group_6.node_tree = mesh_geometry_priority
	
	    #node Map Range
	    map_range_1 = align_curve_to_surface.nodes.new("ShaderNodeMapRange")
	    map_range_1.name = "Map Range"
	    map_range_1.hide = True
	    map_range_1.clamp = False
	    map_range_1.data_type = 'FLOAT'
	    map_range_1.interpolation_type = 'LINEAR'
	    map_range_1.inputs[1].hide = True
	    map_range_1.inputs[2].hide = True
	    map_range_1.inputs[3].hide = True
	    map_range_1.inputs[5].hide = True
	    map_range_1.inputs[6].hide = True
	    map_range_1.inputs[7].hide = True
	    map_range_1.inputs[8].hide = True
	    map_range_1.inputs[9].hide = True
	    map_range_1.inputs[10].hide = True
	    map_range_1.inputs[11].hide = True
	    map_range_1.outputs[1].hide = True
	    #From Min
	    map_range_1.inputs[1].default_value = 0.0
	    #From Max
	    map_range_1.inputs[2].default_value = 1.0
	    #To Min
	    map_range_1.inputs[3].default_value = 0.0
	
	    #node Group Input.001
	    group_input_001_11 = align_curve_to_surface.nodes.new("NodeGroupInput")
	    group_input_001_11.name = "Group Input.001"
	    group_input_001_11.outputs[0].hide = True
	    group_input_001_11.outputs[1].hide = True
	    group_input_001_11.outputs[2].hide = True
	    group_input_001_11.outputs[4].hide = True
	
	
	
	
	    #Set parents
	    vector_math_004_4.parent = frame_007_1
	    vector_math_007_3.parent = frame_007_1
	    math_008.parent = frame_006_2
	    vector_math_008_2.parent = frame_006_2
	    math_009_1.parent = frame_006_2
	
	    #Set locations
	    group_output_18.location = (697.721435546875, 165.50466918945312)
	    group_input_13.location = (-531.6859130859375, 0.0)
	    capture_attribute_004_1.location = (-331.6859130859375, 193.2864990234375)
	    normal_005.location = (-331.6859130859375, 46.861083984375)
	    curve_tangent_002.location = (-331.6859130859375, 10.7730712890625)
	    vector_math_004_4.location = (29.613037109375, -35.04705810546875)
	    vector_math_007_3.location = (30.90576171875, -73.6961669921875)
	    sample_nearest_003.location = (-133.015869140625, -107.3826904296875)
	    sample_index_003_1.location = (-133.1280517578125, -156.7822265625)
	    normal_006.location = (-130.652099609375, -193.28662109375)
	    position_004_1.location = (-327.815673828125, -24.2001953125)
	    frame_007_1.location = (65.0, -72.0)
	    math_008.location = (32.670166015625, -69.58648681640625)
	    vector_math_008_2.location = (36.68603515625, -105.55633544921875)
	    math_009_1.location = (30.263671875, -34.89862060546875)
	    frame_006_2.location = (295.0, -77.0)
	    reroute_12.location = (-170.5524139404297, -136.1621856689453)
	    group_6.location = (-324.8177185058594, -125.7967529296875)
	    map_range_1.location = (559.6337280273438, -103.24618530273438)
	    group_input_001_11.location = (557.1717529296875, -43.553863525390625)
	
	    #Set dimensions
	    group_output_18.width, group_output_18.height = 140.0, 100.0
	    group_input_13.width, group_input_13.height = 140.0, 100.0
	    capture_attribute_004_1.width, capture_attribute_004_1.height = 140.0, 100.0
	    normal_005.width, normal_005.height = 140.0, 100.0
	    curve_tangent_002.width, curve_tangent_002.height = 140.0, 100.0
	    vector_math_004_4.width, vector_math_004_4.height = 140.0, 100.0
	    vector_math_007_3.width, vector_math_007_3.height = 140.0, 100.0
	    sample_nearest_003.width, sample_nearest_003.height = 140.0, 100.0
	    sample_index_003_1.width, sample_index_003_1.height = 140.0, 100.0
	    normal_006.width, normal_006.height = 140.0, 100.0
	    position_004_1.width, position_004_1.height = 140.0, 100.0
	    frame_007_1.width, frame_007_1.height = 201.0, 129.0
	    math_008.width, math_008.height = 140.0, 100.0
	    vector_math_008_2.width, vector_math_008_2.height = 140.0, 100.0
	    math_009_1.width, math_009_1.height = 140.0, 100.0
	    frame_006_2.width, frame_006_2.height = 207.0, 161.0
	    reroute_12.width, reroute_12.height = 100.0, 100.0
	    group_6.width, group_6.height = 140.0, 100.0
	    map_range_1.width, map_range_1.height = 140.0, 100.0
	    group_input_001_11.width, group_input_001_11.height = 140.0, 100.0
	
	    #initialize align_curve_to_surface links
	    #curve_tangent_002.Tangent -> capture_attribute_004_1.Tangent
	    align_curve_to_surface.links.new(curve_tangent_002.outputs[0], capture_attribute_004_1.inputs[2])
	    #position_004_1.Position -> capture_attribute_004_1.Position
	    align_curve_to_surface.links.new(position_004_1.outputs[0], capture_attribute_004_1.inputs[3])
	    #math_008.Value -> math_009_1.Value
	    align_curve_to_surface.links.new(math_008.outputs[0], math_009_1.inputs[0])
	    #normal_005.Normal -> capture_attribute_004_1.Normal
	    align_curve_to_surface.links.new(normal_005.outputs[0], capture_attribute_004_1.inputs[1])
	    #capture_attribute_004_1.Position -> sample_nearest_003.Sample Position
	    align_curve_to_surface.links.new(capture_attribute_004_1.outputs[3], sample_nearest_003.inputs[1])
	    #reroute_12.Output -> sample_nearest_003.Geometry
	    align_curve_to_surface.links.new(reroute_12.outputs[0], sample_nearest_003.inputs[0])
	    #sample_index_003_1.Value -> vector_math_007_3.Vector
	    align_curve_to_surface.links.new(sample_index_003_1.outputs[0], vector_math_007_3.inputs[1])
	    #vector_math_008_2.Value -> math_008.Value
	    align_curve_to_surface.links.new(vector_math_008_2.outputs[1], math_008.inputs[1])
	    #capture_attribute_004_1.Tangent -> vector_math_004_4.Vector
	    align_curve_to_surface.links.new(capture_attribute_004_1.outputs[2], vector_math_004_4.inputs[0])
	    #normal_006.Normal -> sample_index_003_1.Value
	    align_curve_to_surface.links.new(normal_006.outputs[0], sample_index_003_1.inputs[1])
	    #vector_math_004_4.Vector -> vector_math_007_3.Vector
	    align_curve_to_surface.links.new(vector_math_004_4.outputs[0], vector_math_007_3.inputs[0])
	    #vector_math_007_3.Value -> math_008.Value
	    align_curve_to_surface.links.new(vector_math_007_3.outputs[1], math_008.inputs[0])
	    #reroute_12.Output -> sample_index_003_1.Geometry
	    align_curve_to_surface.links.new(reroute_12.outputs[0], sample_index_003_1.inputs[0])
	    #sample_nearest_003.Index -> sample_index_003_1.Index
	    align_curve_to_surface.links.new(sample_nearest_003.outputs[0], sample_index_003_1.inputs[2])
	    #capture_attribute_004_1.Normal -> vector_math_004_4.Vector
	    align_curve_to_surface.links.new(capture_attribute_004_1.outputs[1], vector_math_004_4.inputs[1])
	    #capture_attribute_004_1.Normal -> vector_math_008_2.Vector
	    align_curve_to_surface.links.new(capture_attribute_004_1.outputs[1], vector_math_008_2.inputs[0])
	    #sample_index_003_1.Value -> vector_math_008_2.Vector
	    align_curve_to_surface.links.new(sample_index_003_1.outputs[0], vector_math_008_2.inputs[1])
	    #group_input_13.Geometry -> capture_attribute_004_1.Geometry
	    align_curve_to_surface.links.new(group_input_13.outputs[0], capture_attribute_004_1.inputs[0])
	    #capture_attribute_004_1.Geometry -> group_output_18.Geometry
	    align_curve_to_surface.links.new(capture_attribute_004_1.outputs[0], group_output_18.inputs[0])
	    #group_input_13.Surface -> group_6.Object
	    align_curve_to_surface.links.new(group_input_13.outputs[2], group_6.inputs[1])
	    #group_input_13.Surface -> group_6.Geometry
	    align_curve_to_surface.links.new(group_input_13.outputs[1], group_6.inputs[0])
	    #group_6.Geometry -> reroute_12.Input
	    align_curve_to_surface.links.new(group_6.outputs[0], reroute_12.inputs[0])
	    #group_input_001_11.Surface Align Factor -> map_range_1.Value
	    align_curve_to_surface.links.new(group_input_001_11.outputs[3], map_range_1.inputs[0])
	    #math_009_1.Value -> map_range_1.To Max
	    align_curve_to_surface.links.new(math_009_1.outputs[0], map_range_1.inputs[4])
	    #map_range_1.Result -> group_output_18.Tilt
	    align_curve_to_surface.links.new(map_range_1.outputs[0], group_output_18.inputs[1])
	    return align_curve_to_surface
	
	align_curve_to_surface = align_curve_to_surface_node_group()
	
	#initialize scalp_mesh_hair node group
	def scalp_mesh_hair_node_group():
	    scalp_mesh_hair = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "SCALP_MESH_HAIR")
	
	    scalp_mesh_hair.color_tag = 'NONE'
	    scalp_mesh_hair.description = ""
	    scalp_mesh_hair.default_group_node_width = 140
	    
	
	    scalp_mesh_hair.is_modifier = True
	
	    #scalp_mesh_hair interface
	    #Socket Geometry
	    geometry_socket_26 = scalp_mesh_hair.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_26.attribute_domain = 'POINT'
	
	    #Socket Geometry
	    geometry_socket_27 = scalp_mesh_hair.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_27.attribute_domain = 'POINT'
	
	    #Socket Surface
	    surface_socket_8 = scalp_mesh_hair.interface.new_socket(name = "Surface", in_out='INPUT', socket_type = 'NodeSocketObject')
	    surface_socket_8.attribute_domain = 'POINT'
	
	    #Socket Material
	    material_socket_5 = scalp_mesh_hair.interface.new_socket(name = "Material", in_out='INPUT', socket_type = 'NodeSocketMaterial')
	    material_socket_5.attribute_domain = 'POINT'
	
	    #Socket Control Points
	    control_points_socket_2 = scalp_mesh_hair.interface.new_socket(name = "Control Points", in_out='INPUT', socket_type = 'NodeSocketInt')
	    control_points_socket_2.default_value = 10
	    control_points_socket_2.min_value = 1
	    control_points_socket_2.max_value = 100000
	    control_points_socket_2.subtype = 'NONE'
	    control_points_socket_2.attribute_domain = 'POINT'
	
	    #Socket Width
	    width_socket_3 = scalp_mesh_hair.interface.new_socket(name = "Width", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    width_socket_3.default_value = 0.10000000149011612
	    width_socket_3.min_value = 0.0
	    width_socket_3.max_value = 3.4028234663852886e+38
	    width_socket_3.subtype = 'DISTANCE'
	    width_socket_3.attribute_domain = 'POINT'
	
	    #Socket Guide Merge Distance
	    guide_merge_distance_socket = scalp_mesh_hair.interface.new_socket(name = "Guide Merge Distance", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    guide_merge_distance_socket.default_value = 0.0010000000474974513
	    guide_merge_distance_socket.min_value = 0.0
	    guide_merge_distance_socket.max_value = 3.4028234663852886e+38
	    guide_merge_distance_socket.subtype = 'DISTANCE'
	    guide_merge_distance_socket.attribute_domain = 'POINT'
	
	    #Socket Mesh Merge Distance
	    mesh_merge_distance_socket = scalp_mesh_hair.interface.new_socket(name = "Mesh Merge Distance", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    mesh_merge_distance_socket.default_value = 0.0
	    mesh_merge_distance_socket.min_value = 0.0
	    mesh_merge_distance_socket.max_value = 0.10000000149011612
	    mesh_merge_distance_socket.subtype = 'DISTANCE'
	    mesh_merge_distance_socket.attribute_domain = 'POINT'
	
	    #Socket Subdivision Level
	    subdivision_level_socket = scalp_mesh_hair.interface.new_socket(name = "Subdivision Level", in_out='INPUT', socket_type = 'NodeSocketInt')
	    subdivision_level_socket.default_value = 1
	    subdivision_level_socket.min_value = 0
	    subdivision_level_socket.max_value = 6
	    subdivision_level_socket.subtype = 'NONE'
	    subdivision_level_socket.attribute_domain = 'POINT'
	
	    #Socket Surface Offset
	    surface_offset_socket_1 = scalp_mesh_hair.interface.new_socket(name = "Surface Offset", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    surface_offset_socket_1.default_value = 0.10000000149011612
	    surface_offset_socket_1.min_value = 0.0
	    surface_offset_socket_1.max_value = 10000.0
	    surface_offset_socket_1.subtype = 'NONE'
	    surface_offset_socket_1.attribute_domain = 'POINT'
	
	    #Socket Mesh Shape
	    mesh_shape_socket = scalp_mesh_hair.interface.new_socket(name = "Mesh Shape", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    mesh_shape_socket.default_value = 0.0
	    mesh_shape_socket.min_value = 0.0
	    mesh_shape_socket.max_value = 0.0
	    mesh_shape_socket.subtype = 'NONE'
	    mesh_shape_socket.attribute_domain = 'POINT'
	    mesh_shape_socket.hide_value = True
	    mesh_shape_socket.hide_in_modifier = True
	
	    #Socket Surface Offset Shape
	    surface_offset_shape_socket = scalp_mesh_hair.interface.new_socket(name = "Surface Offset Shape", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    surface_offset_shape_socket.default_value = 0.0
	    surface_offset_shape_socket.min_value = 0.0
	    surface_offset_shape_socket.max_value = 0.0
	    surface_offset_shape_socket.subtype = 'NONE'
	    surface_offset_shape_socket.attribute_domain = 'POINT'
	    surface_offset_shape_socket.hide_value = True
	    surface_offset_shape_socket.hide_in_modifier = True
	
	
	    #initialize scalp_mesh_hair nodes
	    #node Group Input
	    group_input_14 = scalp_mesh_hair.nodes.new("NodeGroupInput")
	    group_input_14.name = "Group Input"
	    group_input_14.outputs[1].hide = True
	    group_input_14.outputs[2].hide = True
	    group_input_14.outputs[3].hide = True
	    group_input_14.outputs[4].hide = True
	    group_input_14.outputs[5].hide = True
	    group_input_14.outputs[6].hide = True
	    group_input_14.outputs[7].hide = True
	    group_input_14.outputs[8].hide = True
	    group_input_14.outputs[9].hide = True
	    group_input_14.outputs[10].hide = True
	    group_input_14.outputs[11].hide = True
	
	    #node Group Output
	    group_output_19 = scalp_mesh_hair.nodes.new("NodeGroupOutput")
	    group_output_19.name = "Group Output"
	    group_output_19.is_active_output = True
	    group_output_19.inputs[1].hide = True
	
	    #node Named Attribute
	    named_attribute_4 = scalp_mesh_hair.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute_4.name = "Named Attribute"
	    named_attribute_4.data_type = 'INT'
	    #Name
	    named_attribute_4.inputs[0].default_value = "closest_idx"
	
	    #node Compare
	    compare_9 = scalp_mesh_hair.nodes.new("FunctionNodeCompare")
	    compare_9.name = "Compare"
	    compare_9.hide = True
	    compare_9.data_type = 'INT'
	    compare_9.mode = 'ELEMENT'
	    compare_9.operation = 'EQUAL'
	
	    #node Separate Geometry
	    separate_geometry = scalp_mesh_hair.nodes.new("GeometryNodeSeparateGeometry")
	    separate_geometry.name = "Separate Geometry"
	    separate_geometry.domain = 'CURVE'
	    separate_geometry.outputs[1].hide = True
	
	    #node Convex Hull
	    convex_hull = scalp_mesh_hair.nodes.new("GeometryNodeConvexHull")
	    convex_hull.name = "Convex Hull"
	
	    #node Object Info
	    object_info_3 = scalp_mesh_hair.nodes.new("GeometryNodeObjectInfo")
	    object_info_3.name = "Object Info"
	    object_info_3.hide = True
	    object_info_3.transform_space = 'RELATIVE'
	    object_info_3.inputs[1].hide = True
	    object_info_3.outputs[0].hide = True
	    object_info_3.outputs[1].hide = True
	    object_info_3.outputs[2].hide = True
	    object_info_3.outputs[3].hide = True
	    #As Instance
	    object_info_3.inputs[1].default_value = False
	
	    #node Mesh Boolean
	    mesh_boolean = scalp_mesh_hair.nodes.new("GeometryNodeMeshBoolean")
	    mesh_boolean.name = "Mesh Boolean"
	    mesh_boolean.operation = 'UNION'
	    mesh_boolean.solver = 'EXACT'
	    mesh_boolean.inputs[2].hide = True
	    mesh_boolean.inputs[3].hide = True
	    #Self Intersection
	    mesh_boolean.inputs[2].default_value = False
	    #Hole Tolerant
	    mesh_boolean.inputs[3].default_value = False
	
	    #node Delete Geometry
	    delete_geometry_1 = scalp_mesh_hair.nodes.new("GeometryNodeDeleteGeometry")
	    delete_geometry_1.name = "Delete Geometry"
	    delete_geometry_1.hide = True
	    delete_geometry_1.domain = 'EDGE'
	    delete_geometry_1.mode = 'ALL'
	
	    #node Boolean Math
	    boolean_math_4 = scalp_mesh_hair.nodes.new("FunctionNodeBooleanMath")
	    boolean_math_4.name = "Boolean Math"
	    boolean_math_4.hide = True
	    boolean_math_4.operation = 'NOT'
	
	    #node Named Attribute.002
	    named_attribute_002_1 = scalp_mesh_hair.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute_002_1.name = "Named Attribute.002"
	    named_attribute_002_1.data_type = 'FLOAT_VECTOR'
	    #Name
	    named_attribute_002_1.inputs[0].default_value = "closetst_pt"
	
	    #node Attribute Statistic
	    attribute_statistic_1 = scalp_mesh_hair.nodes.new("GeometryNodeAttributeStatistic")
	    attribute_statistic_1.name = "Attribute Statistic"
	    attribute_statistic_1.hide = True
	    attribute_statistic_1.data_type = 'FLOAT_VECTOR'
	    attribute_statistic_1.domain = 'CURVE'
	    attribute_statistic_1.inputs[1].hide = True
	    attribute_statistic_1.outputs[1].hide = True
	    attribute_statistic_1.outputs[2].hide = True
	    attribute_statistic_1.outputs[3].hide = True
	    attribute_statistic_1.outputs[4].hide = True
	    attribute_statistic_1.outputs[5].hide = True
	    attribute_statistic_1.outputs[6].hide = True
	    attribute_statistic_1.outputs[7].hide = True
	    #Selection
	    attribute_statistic_1.inputs[1].default_value = True
	
	    #node Mesh to Points
	    mesh_to_points = scalp_mesh_hair.nodes.new("GeometryNodeMeshToPoints")
	    mesh_to_points.name = "Mesh to Points"
	    mesh_to_points.hide = True
	    mesh_to_points.mode = 'VERTICES'
	    mesh_to_points.inputs[1].hide = True
	    mesh_to_points.inputs[2].hide = True
	    mesh_to_points.inputs[3].hide = True
	    #Selection
	    mesh_to_points.inputs[1].default_value = True
	    #Position
	    mesh_to_points.inputs[2].default_value = (0.0, 0.0, 0.0)
	    #Radius
	    mesh_to_points.inputs[3].default_value = 0.05000000074505806
	
	    #node Merge by Distance
	    merge_by_distance = scalp_mesh_hair.nodes.new("GeometryNodeMergeByDistance")
	    merge_by_distance.name = "Merge by Distance"
	    merge_by_distance.hide = True
	    merge_by_distance.mode = 'ALL'
	    merge_by_distance.inputs[1].hide = True
	    #Selection
	    merge_by_distance.inputs[1].default_value = True
	
	    #node Instance on Points
	    instance_on_points = scalp_mesh_hair.nodes.new("GeometryNodeInstanceOnPoints")
	    instance_on_points.name = "Instance on Points"
	    instance_on_points.hide = True
	    instance_on_points.inputs[1].hide = True
	    instance_on_points.inputs[3].hide = True
	    instance_on_points.inputs[4].hide = True
	    instance_on_points.inputs[5].hide = True
	    instance_on_points.inputs[6].hide = True
	    #Selection
	    instance_on_points.inputs[1].default_value = True
	    #Pick Instance
	    instance_on_points.inputs[3].default_value = False
	    #Instance Index
	    instance_on_points.inputs[4].default_value = 0
	    #Rotation
	    instance_on_points.inputs[5].default_value = (0.0, 0.0, 0.0)
	    #Scale
	    instance_on_points.inputs[6].default_value = (1.0, 1.0, 1.0)
	
	    #node Set Position
	    set_position_3 = scalp_mesh_hair.nodes.new("GeometryNodeSetPosition")
	    set_position_3.name = "Set Position"
	    set_position_3.inputs[3].hide = True
	    #Offset
	    set_position_3.inputs[3].default_value = (0.0, 0.0, 0.0)
	
	    #node Endpoint Selection
	    endpoint_selection_3 = scalp_mesh_hair.nodes.new("GeometryNodeCurveEndpointSelection")
	    endpoint_selection_3.name = "Endpoint Selection"
	    endpoint_selection_3.inputs[0].hide = True
	    endpoint_selection_3.inputs[1].hide = True
	    #Start Size
	    endpoint_selection_3.inputs[0].default_value = 0
	    #End Size
	    endpoint_selection_3.inputs[1].default_value = 1
	
	    #node Realize Instances
	    realize_instances = scalp_mesh_hair.nodes.new("GeometryNodeRealizeInstances")
	    realize_instances.name = "Realize Instances"
	    realize_instances.hide = True
	    realize_instances.inputs[1].hide = True
	    realize_instances.inputs[2].hide = True
	    realize_instances.inputs[3].hide = True
	    #Selection
	    realize_instances.inputs[1].default_value = True
	    #Realize All
	    realize_instances.inputs[2].default_value = True
	    #Depth
	    realize_instances.inputs[3].default_value = 0
	
	    #node Curve Line
	    curve_line_1 = scalp_mesh_hair.nodes.new("GeometryNodeCurvePrimitiveLine")
	    curve_line_1.name = "Curve Line"
	    curve_line_1.hide = True
	    curve_line_1.mode = 'DIRECTION'
	    #Start
	    curve_line_1.inputs[0].default_value = (0.0, 0.0, 0.0)
	    #Direction
	    curve_line_1.inputs[2].default_value = (0.0, 0.0, 1.0)
	    #Length
	    curve_line_1.inputs[3].default_value = 0.10000000149011612
	
	    #node Resample Curve
	    resample_curve_4 = scalp_mesh_hair.nodes.new("GeometryNodeResampleCurve")
	    resample_curve_4.name = "Resample Curve"
	    resample_curve_4.keep_last_segment = False
	    resample_curve_4.mode = 'COUNT'
	    resample_curve_4.inputs[1].hide = True
	    resample_curve_4.inputs[3].hide = True
	    #Selection
	    resample_curve_4.inputs[1].default_value = True
	
	    #node Set Position.001
	    set_position_001_3 = scalp_mesh_hair.nodes.new("GeometryNodeSetPosition")
	    set_position_001_3.name = "Set Position.001"
	    set_position_001_3.inputs[3].hide = True
	    #Offset
	    set_position_001_3.inputs[3].default_value = (0.0, 0.0, 0.0)
	
	    #node Geometry Proximity
	    geometry_proximity_1 = scalp_mesh_hair.nodes.new("GeometryNodeProximity")
	    geometry_proximity_1.name = "Geometry Proximity"
	    geometry_proximity_1.target_element = 'EDGES'
	    geometry_proximity_1.inputs[1].hide = True
	    geometry_proximity_1.inputs[3].hide = True
	    geometry_proximity_1.outputs[1].hide = True
	    geometry_proximity_1.outputs[2].hide = True
	    #Group ID
	    geometry_proximity_1.inputs[1].default_value = 0
	    #Sample Group ID
	    geometry_proximity_1.inputs[3].default_value = 0
	
	    #node Curve to Mesh.001
	    curve_to_mesh_001_1 = scalp_mesh_hair.nodes.new("GeometryNodeCurveToMesh")
	    curve_to_mesh_001_1.name = "Curve to Mesh.001"
	    curve_to_mesh_001_1.inputs[1].hide = True
	    curve_to_mesh_001_1.inputs[2].hide = True
	    #Fill Caps
	    curve_to_mesh_001_1.inputs[2].default_value = False
	
	    #node Capture Attribute
	    capture_attribute_6 = scalp_mesh_hair.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_6.name = "Capture Attribute"
	    capture_attribute_6.active_index = 0
	    capture_attribute_6.capture_items.clear()
	    capture_attribute_6.capture_items.new('FLOAT', "Position")
	    capture_attribute_6.capture_items["Position"].data_type = 'FLOAT_VECTOR'
	    capture_attribute_6.domain = 'POINT'
	    capture_attribute_6.inputs[2].hide = True
	    capture_attribute_6.outputs[2].hide = True
	
	    #node Position.001
	    position_001_3 = scalp_mesh_hair.nodes.new("GeometryNodeInputPosition")
	    position_001_3.name = "Position.001"
	
	    #node Attribute Statistic.001
	    attribute_statistic_001 = scalp_mesh_hair.nodes.new("GeometryNodeAttributeStatistic")
	    attribute_statistic_001.name = "Attribute Statistic.001"
	    attribute_statistic_001.hide = True
	    attribute_statistic_001.data_type = 'FLOAT'
	    attribute_statistic_001.domain = 'CURVE'
	    attribute_statistic_001.inputs[1].hide = True
	    attribute_statistic_001.outputs[0].hide = True
	    attribute_statistic_001.outputs[1].hide = True
	    attribute_statistic_001.outputs[2].hide = True
	    attribute_statistic_001.outputs[3].hide = True
	    attribute_statistic_001.outputs[5].hide = True
	    attribute_statistic_001.outputs[6].hide = True
	    attribute_statistic_001.outputs[7].hide = True
	    #Selection
	    attribute_statistic_001.inputs[1].default_value = True
	
	    #node Repeat Input
	    repeat_input_1 = scalp_mesh_hair.nodes.new("GeometryNodeRepeatInput")
	    repeat_input_1.name = "Repeat Input"
	    #node Repeat Output
	    repeat_output_1 = scalp_mesh_hair.nodes.new("GeometryNodeRepeatOutput")
	    repeat_output_1.name = "Repeat Output"
	    repeat_output_1.active_index = 1
	    repeat_output_1.inspection_index = 0
	    repeat_output_1.repeat_items.clear()
	    # Create item "Geometry"
	    repeat_output_1.repeat_items.new('GEOMETRY', "Geometry")
	    # Create item "Index"
	    repeat_output_1.repeat_items.new('INT', "Index")
	
	    #node Join Geometry.001
	    join_geometry_001_1 = scalp_mesh_hair.nodes.new("GeometryNodeJoinGeometry")
	    join_geometry_001_1.name = "Join Geometry.001"
	    join_geometry_001_1.hide = True
	
	    #node Math
	    math_6 = scalp_mesh_hair.nodes.new("ShaderNodeMath")
	    math_6.name = "Math"
	    math_6.hide = True
	    math_6.operation = 'ADD'
	    math_6.use_clamp = False
	    #Value_001
	    math_6.inputs[1].default_value = 1.0
	
	    #node Math.001
	    math_001_3 = scalp_mesh_hair.nodes.new("ShaderNodeMath")
	    math_001_3.name = "Math.001"
	    math_001_3.hide = True
	    math_001_3.operation = 'ADD'
	    math_001_3.use_clamp = False
	    #Value_001
	    math_001_3.inputs[1].default_value = 1.0
	
	    #node Named Attribute.003
	    named_attribute_003_1 = scalp_mesh_hair.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute_003_1.name = "Named Attribute.003"
	    named_attribute_003_1.data_type = 'INT'
	    #Name
	    named_attribute_003_1.inputs[0].default_value = "closest_idx"
	
	    #node Group.001
	    group_001_5 = scalp_mesh_hair.nodes.new("GeometryNodeGroup")
	    group_001_5.name = "Group.001"
	    group_001_5.node_tree = hair_shape_1
	    group_001_5.inputs[1].hide = True
	    group_001_5.inputs[3].hide = True
	    group_001_5.inputs[6].hide = True
	    group_001_5.inputs[7].hide = True
	    group_001_5.inputs[8].hide = True
	    group_001_5.inputs[9].hide = True
	    group_001_5.inputs[10].hide = True
	    group_001_5.inputs[11].hide = True
	    #Socket_2
	    group_001_5.inputs[1].default_value = 'Hair Card'
	    #Socket_4
	    group_001_5.inputs[3].default_value = 0
	    #Socket_7
	    group_001_5.inputs[6].default_value = 0.0
	    #Socket_8
	    group_001_5.inputs[7].default_value = 8
	    #Socket_10
	    group_001_5.inputs[9].default_value = (0.0, 0.0, 0.0)
	    #Socket_11
	    group_001_5.inputs[10].default_value = (0.0, 0.0, 0.0)
	    #Socket_12
	    group_001_5.inputs[11].default_value = (1.0, 1.0, 1.0)
	
	    #node Reroute.001
	    reroute_001_9 = scalp_mesh_hair.nodes.new("NodeReroute")
	    reroute_001_9.name = "Reroute.001"
	    reroute_001_9.socket_idname = "NodeSocketGeometry"
	    #node Reroute.002
	    reroute_002_7 = scalp_mesh_hair.nodes.new("NodeReroute")
	    reroute_002_7.name = "Reroute.002"
	    reroute_002_7.socket_idname = "NodeSocketGeometry"
	    #node Group Input.001
	    group_input_001_12 = scalp_mesh_hair.nodes.new("NodeGroupInput")
	    group_input_001_12.name = "Group Input.001"
	    group_input_001_12.outputs[0].hide = True
	    group_input_001_12.outputs[2].hide = True
	    group_input_001_12.outputs[3].hide = True
	    group_input_001_12.outputs[4].hide = True
	    group_input_001_12.outputs[5].hide = True
	    group_input_001_12.outputs[6].hide = True
	    group_input_001_12.outputs[7].hide = True
	    group_input_001_12.outputs[8].hide = True
	    group_input_001_12.outputs[9].hide = True
	    group_input_001_12.outputs[10].hide = True
	    group_input_001_12.outputs[11].hide = True
	
	    #node Reroute.003
	    reroute_003_6 = scalp_mesh_hair.nodes.new("NodeReroute")
	    reroute_003_6.name = "Reroute.003"
	    reroute_003_6.socket_idname = "NodeSocketGeometry"
	    #node Reroute.004
	    reroute_004_7 = scalp_mesh_hair.nodes.new("NodeReroute")
	    reroute_004_7.name = "Reroute.004"
	    reroute_004_7.socket_idname = "NodeSocketGeometry"
	    #node Reroute.005
	    reroute_005_5 = scalp_mesh_hair.nodes.new("NodeReroute")
	    reroute_005_5.name = "Reroute.005"
	    reroute_005_5.socket_idname = "NodeSocketGeometry"
	    #node Group Input.002
	    group_input_002_9 = scalp_mesh_hair.nodes.new("NodeGroupInput")
	    group_input_002_9.name = "Group Input.002"
	    group_input_002_9.outputs[0].hide = True
	    group_input_002_9.outputs[1].hide = True
	    group_input_002_9.outputs[2].hide = True
	    group_input_002_9.outputs[3].hide = True
	    group_input_002_9.outputs[4].hide = True
	    group_input_002_9.outputs[6].hide = True
	    group_input_002_9.outputs[7].hide = True
	    group_input_002_9.outputs[8].hide = True
	    group_input_002_9.outputs[9].hide = True
	    group_input_002_9.outputs[10].hide = True
	    group_input_002_9.outputs[11].hide = True
	
	    #node Group Input.003
	    group_input_003_9 = scalp_mesh_hair.nodes.new("NodeGroupInput")
	    group_input_003_9.name = "Group Input.003"
	    group_input_003_9.outputs[0].hide = True
	    group_input_003_9.outputs[1].hide = True
	    group_input_003_9.outputs[2].hide = True
	    group_input_003_9.outputs[4].hide = True
	    group_input_003_9.outputs[5].hide = True
	    group_input_003_9.outputs[6].hide = True
	    group_input_003_9.outputs[7].hide = True
	    group_input_003_9.outputs[8].hide = True
	    group_input_003_9.outputs[9].hide = True
	    group_input_003_9.outputs[10].hide = True
	    group_input_003_9.outputs[11].hide = True
	
	    #node Endpoint Selection.001
	    endpoint_selection_001 = scalp_mesh_hair.nodes.new("GeometryNodeCurveEndpointSelection")
	    endpoint_selection_001.name = "Endpoint Selection.001"
	    endpoint_selection_001.inputs[0].hide = True
	    endpoint_selection_001.inputs[1].hide = True
	    #Start Size
	    endpoint_selection_001.inputs[0].default_value = 0
	    #End Size
	    endpoint_selection_001.inputs[1].default_value = 1
	
	    #node Boolean Math.001
	    boolean_math_001_2 = scalp_mesh_hair.nodes.new("FunctionNodeBooleanMath")
	    boolean_math_001_2.name = "Boolean Math.001"
	    boolean_math_001_2.hide = True
	    boolean_math_001_2.operation = 'NOT'
	
	    #node Sample Nearest.001
	    sample_nearest_001_1 = scalp_mesh_hair.nodes.new("GeometryNodeSampleNearest")
	    sample_nearest_001_1.name = "Sample Nearest.001"
	    sample_nearest_001_1.hide = True
	    sample_nearest_001_1.domain = 'POINT'
	
	    #node Object Info.002
	    object_info_002 = scalp_mesh_hair.nodes.new("GeometryNodeObjectInfo")
	    object_info_002.name = "Object Info.002"
	    object_info_002.hide = True
	    object_info_002.transform_space = 'RELATIVE'
	    object_info_002.inputs[1].hide = True
	    object_info_002.outputs[0].hide = True
	    object_info_002.outputs[1].hide = True
	    object_info_002.outputs[2].hide = True
	    object_info_002.outputs[3].hide = True
	    #As Instance
	    object_info_002.inputs[1].default_value = False
	
	    #node Sample Index.001
	    sample_index_001_1 = scalp_mesh_hair.nodes.new("GeometryNodeSampleIndex")
	    sample_index_001_1.name = "Sample Index.001"
	    sample_index_001_1.hide = True
	    sample_index_001_1.clamp = False
	    sample_index_001_1.data_type = 'FLOAT_VECTOR'
	    sample_index_001_1.domain = 'POINT'
	
	    #node Normal.002
	    normal_002 = scalp_mesh_hair.nodes.new("GeometryNodeInputNormal")
	    normal_002.name = "Normal.002"
	    normal_002.legacy_corner_normals = True
	
	    #node Group Input.005
	    group_input_005_8 = scalp_mesh_hair.nodes.new("NodeGroupInput")
	    group_input_005_8.name = "Group Input.005"
	    group_input_005_8.outputs[0].hide = True
	    group_input_005_8.outputs[2].hide = True
	    group_input_005_8.outputs[3].hide = True
	    group_input_005_8.outputs[4].hide = True
	    group_input_005_8.outputs[5].hide = True
	    group_input_005_8.outputs[6].hide = True
	    group_input_005_8.outputs[7].hide = True
	    group_input_005_8.outputs[8].hide = True
	    group_input_005_8.outputs[9].hide = True
	    group_input_005_8.outputs[10].hide = True
	    group_input_005_8.outputs[11].hide = True
	
	    #node Capture Attribute.002
	    capture_attribute_002_5 = scalp_mesh_hair.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_002_5.name = "Capture Attribute.002"
	    capture_attribute_002_5.active_index = 0
	    capture_attribute_002_5.capture_items.clear()
	    capture_attribute_002_5.capture_items.new('FLOAT', "Position")
	    capture_attribute_002_5.capture_items["Position"].data_type = 'FLOAT_VECTOR'
	    capture_attribute_002_5.domain = 'POINT'
	    capture_attribute_002_5.inputs[2].hide = True
	    capture_attribute_002_5.outputs[2].hide = True
	
	    #node Position
	    position_1 = scalp_mesh_hair.nodes.new("GeometryNodeInputPosition")
	    position_1.name = "Position"
	
	    #node Set Position.002
	    set_position_002_2 = scalp_mesh_hair.nodes.new("GeometryNodeSetPosition")
	    set_position_002_2.name = "Set Position.002"
	
	    #node Vector Math.002
	    vector_math_002_3 = scalp_mesh_hair.nodes.new("ShaderNodeVectorMath")
	    vector_math_002_3.name = "Vector Math.002"
	    vector_math_002_3.hide = True
	    vector_math_002_3.operation = 'SCALE'
	
	    #node Named Attribute.001
	    named_attribute_001_2 = scalp_mesh_hair.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute_001_2.name = "Named Attribute.001"
	    named_attribute_001_2.hide = True
	    named_attribute_001_2.data_type = 'FLOAT_VECTOR'
	    #Name
	    named_attribute_001_2.inputs[0].default_value = "UVMap"
	
	    #node Compare.001
	    compare_001_3 = scalp_mesh_hair.nodes.new("FunctionNodeCompare")
	    compare_001_3.name = "Compare.001"
	    compare_001_3.hide = True
	    compare_001_3.data_type = 'VECTOR'
	    compare_001_3.mode = 'ELEMENT'
	    compare_001_3.operation = 'NOT_EQUAL'
	    compare_001_3.inputs[0].hide = True
	    compare_001_3.inputs[1].hide = True
	    compare_001_3.inputs[2].hide = True
	    compare_001_3.inputs[3].hide = True
	    compare_001_3.inputs[5].hide = True
	    compare_001_3.inputs[6].hide = True
	    compare_001_3.inputs[7].hide = True
	    compare_001_3.inputs[8].hide = True
	    compare_001_3.inputs[9].hide = True
	    compare_001_3.inputs[10].hide = True
	    compare_001_3.inputs[11].hide = True
	    compare_001_3.inputs[12].hide = True
	    #B_VEC3
	    compare_001_3.inputs[5].default_value = (0.0, 0.0, 0.0)
	    #Epsilon
	    compare_001_3.inputs[12].default_value = 0.0
	
	    #node Group Input.006
	    group_input_006_6 = scalp_mesh_hair.nodes.new("NodeGroupInput")
	    group_input_006_6.name = "Group Input.006"
	    group_input_006_6.outputs[0].hide = True
	    group_input_006_6.outputs[1].hide = True
	    group_input_006_6.outputs[3].hide = True
	    group_input_006_6.outputs[5].hide = True
	    group_input_006_6.outputs[6].hide = True
	    group_input_006_6.outputs[7].hide = True
	    group_input_006_6.outputs[8].hide = True
	    group_input_006_6.outputs[9].hide = True
	    group_input_006_6.outputs[10].hide = True
	    group_input_006_6.outputs[11].hide = True
	
	    #node Map Range
	    map_range_2 = scalp_mesh_hair.nodes.new("ShaderNodeMapRange")
	    map_range_2.name = "Map Range"
	    map_range_2.hide = True
	    map_range_2.clamp = False
	    map_range_2.data_type = 'FLOAT'
	    map_range_2.interpolation_type = 'LINEAR'
	    map_range_2.inputs[1].hide = True
	    map_range_2.inputs[2].hide = True
	    map_range_2.inputs[3].hide = True
	    map_range_2.inputs[5].hide = True
	    map_range_2.inputs[6].hide = True
	    map_range_2.inputs[7].hide = True
	    map_range_2.inputs[8].hide = True
	    map_range_2.inputs[9].hide = True
	    map_range_2.inputs[10].hide = True
	    map_range_2.inputs[11].hide = True
	    map_range_2.outputs[1].hide = True
	    #From Min
	    map_range_2.inputs[1].default_value = 0.0
	    #From Max
	    map_range_2.inputs[2].default_value = 1.0
	    #To Min
	    map_range_2.inputs[3].default_value = 0.0
	
	    #node Group Input.007
	    group_input_007_5 = scalp_mesh_hair.nodes.new("NodeGroupInput")
	    group_input_007_5.name = "Group Input.007"
	    group_input_007_5.outputs[0].hide = True
	    group_input_007_5.outputs[1].hide = True
	    group_input_007_5.outputs[2].hide = True
	    group_input_007_5.outputs[3].hide = True
	    group_input_007_5.outputs[4].hide = True
	    group_input_007_5.outputs[5].hide = True
	    group_input_007_5.outputs[6].hide = True
	    group_input_007_5.outputs[7].hide = True
	    group_input_007_5.outputs[9].hide = True
	    group_input_007_5.outputs[11].hide = True
	
	    #node Geometry Proximity.001
	    geometry_proximity_001_1 = scalp_mesh_hair.nodes.new("GeometryNodeProximity")
	    geometry_proximity_001_1.name = "Geometry Proximity.001"
	    geometry_proximity_001_1.target_element = 'FACES'
	    #Group ID
	    geometry_proximity_001_1.inputs[1].default_value = 0
	    #Sample Group ID
	    geometry_proximity_001_1.inputs[3].default_value = 0
	
	    #node Subdivide Mesh
	    subdivide_mesh = scalp_mesh_hair.nodes.new("GeometryNodeSubdivideMesh")
	    subdivide_mesh.name = "Subdivide Mesh"
	    subdivide_mesh.hide = True
	    #Level
	    subdivide_mesh.inputs[1].default_value = 3
	
	    #node Group Input.008
	    group_input_008_3 = scalp_mesh_hair.nodes.new("NodeGroupInput")
	    group_input_008_3.name = "Group Input.008"
	    group_input_008_3.outputs[0].hide = True
	    group_input_008_3.outputs[1].hide = True
	    group_input_008_3.outputs[2].hide = True
	    group_input_008_3.outputs[3].hide = True
	    group_input_008_3.outputs[4].hide = True
	    group_input_008_3.outputs[5].hide = True
	    group_input_008_3.outputs[6].hide = True
	    group_input_008_3.outputs[7].hide = True
	    group_input_008_3.outputs[8].hide = True
	    group_input_008_3.outputs[10].hide = True
	    group_input_008_3.outputs[11].hide = True
	
	    #node Set Curve Tilt.001
	    set_curve_tilt_001 = scalp_mesh_hair.nodes.new("GeometryNodeSetCurveTilt")
	    set_curve_tilt_001.name = "Set Curve Tilt.001"
	    set_curve_tilt_001.inputs[1].hide = True
	    #Selection
	    set_curve_tilt_001.inputs[1].default_value = True
	
	    #node Switch
	    switch_10 = scalp_mesh_hair.nodes.new("GeometryNodeSwitch")
	    switch_10.name = "Switch"
	    switch_10.hide = True
	    switch_10.input_type = 'GEOMETRY'
	
	    #node Group Input.010
	    group_input_010_2 = scalp_mesh_hair.nodes.new("NodeGroupInput")
	    group_input_010_2.name = "Group Input.010"
	    group_input_010_2.outputs[0].hide = True
	    group_input_010_2.outputs[1].hide = True
	    group_input_010_2.outputs[2].hide = True
	    group_input_010_2.outputs[3].hide = True
	    group_input_010_2.outputs[4].hide = True
	    group_input_010_2.outputs[5].hide = True
	    group_input_010_2.outputs[7].hide = True
	    group_input_010_2.outputs[8].hide = True
	    group_input_010_2.outputs[9].hide = True
	    group_input_010_2.outputs[10].hide = True
	    group_input_010_2.outputs[11].hide = True
	
	    #node Compare.002
	    compare_002_7 = scalp_mesh_hair.nodes.new("FunctionNodeCompare")
	    compare_002_7.name = "Compare.002"
	    compare_002_7.hide = True
	    compare_002_7.data_type = 'FLOAT'
	    compare_002_7.mode = 'ELEMENT'
	    compare_002_7.operation = 'EQUAL'
	    #B
	    compare_002_7.inputs[1].default_value = 0.0
	    #Epsilon
	    compare_002_7.inputs[12].default_value = 0.0
	
	    #node Merge by Distance.001
	    merge_by_distance_001 = scalp_mesh_hair.nodes.new("GeometryNodeMergeByDistance")
	    merge_by_distance_001.name = "Merge by Distance.001"
	    merge_by_distance_001.hide = True
	    merge_by_distance_001.mode = 'ALL'
	    merge_by_distance_001.inputs[1].hide = True
	    #Selection
	    merge_by_distance_001.inputs[1].default_value = True
	
	    #node Group Input.013
	    group_input_013_1 = scalp_mesh_hair.nodes.new("NodeGroupInput")
	    group_input_013_1.name = "Group Input.013"
	    group_input_013_1.outputs[0].hide = True
	    group_input_013_1.outputs[2].hide = True
	    group_input_013_1.outputs[3].hide = True
	    group_input_013_1.outputs[4].hide = True
	    group_input_013_1.outputs[5].hide = True
	    group_input_013_1.outputs[6].hide = True
	    group_input_013_1.outputs[7].hide = True
	    group_input_013_1.outputs[8].hide = True
	    group_input_013_1.outputs[9].hide = True
	    group_input_013_1.outputs[10].hide = True
	    group_input_013_1.outputs[11].hide = True
	
	    #node Group
	    group_7 = scalp_mesh_hair.nodes.new("GeometryNodeGroup")
	    group_7.name = "Group"
	    group_7.node_tree = align_curve_to_surface
	    group_7.inputs[1].hide = True
	    group_7.inputs[3].hide = True
	    #Socket_5
	    group_7.inputs[3].default_value = 1.0
	
	    #node Subdivision Surface
	    subdivision_surface = scalp_mesh_hair.nodes.new("GeometryNodeSubdivisionSurface")
	    subdivision_surface.name = "Subdivision Surface"
	    subdivision_surface.boundary_smooth = 'ALL'
	    subdivision_surface.uv_smooth = 'PRESERVE_BOUNDARIES'
	    subdivision_surface.inputs[2].hide = True
	    subdivision_surface.inputs[3].hide = True
	    subdivision_surface.inputs[4].hide = True
	    #Edge Crease
	    subdivision_surface.inputs[2].default_value = 0.0
	    #Vertex Crease
	    subdivision_surface.inputs[3].default_value = 0.0
	    #Limit Surface
	    subdivision_surface.inputs[4].default_value = True
	
	    #node Group Input.011
	    group_input_011_1 = scalp_mesh_hair.nodes.new("NodeGroupInput")
	    group_input_011_1.name = "Group Input.011"
	    group_input_011_1.outputs[0].hide = True
	    group_input_011_1.outputs[1].hide = True
	    group_input_011_1.outputs[2].hide = True
	    group_input_011_1.outputs[3].hide = True
	    group_input_011_1.outputs[4].hide = True
	    group_input_011_1.outputs[5].hide = True
	    group_input_011_1.outputs[6].hide = True
	    group_input_011_1.outputs[8].hide = True
	    group_input_011_1.outputs[9].hide = True
	    group_input_011_1.outputs[10].hide = True
	    group_input_011_1.outputs[11].hide = True
	
	
	    #Process zone input Repeat Input
	    repeat_input_1.pair_with_output(repeat_output_1)
	    #Item_2
	    repeat_input_1.inputs[2].default_value = 0
	
	
	
	
	
	    #Set locations
	    group_input_14.location = (-340.0, 0.0)
	    group_output_19.location = (4867.056640625, 198.1728973388672)
	    named_attribute_4.location = (237.794921875, -204.86949157714844)
	    compare_9.location = (237.99490356445312, -171.7650146484375)
	    separate_geometry.location = (434.56829833984375, -287.77130126953125)
	    convex_hull.location = (646.521240234375, -263.57049560546875)
	    object_info_3.location = (831.0836791992188, -326.6778259277344)
	    mesh_boolean.location = (829.2451171875, -171.54408264160156)
	    delete_geometry_1.location = (1030.076171875, -201.4806671142578)
	    boolean_math_4.location = (1040.427734375, -237.08360290527344)
	    named_attribute_002_1.location = (1445.0579833984375, -375.33697509765625)
	    attribute_statistic_1.location = (1446.5335693359375, -523.4667358398438)
	    mesh_to_points.location = (1443.890869140625, -217.95069885253906)
	    merge_by_distance.location = (1283.8487548828125, -214.57022094726562)
	    instance_on_points.location = (1444.212890625, -270.5458068847656)
	    set_position_3.location = (1786.1016845703125, -222.05580139160156)
	    endpoint_selection_3.location = (1785.614990234375, -346.51092529296875)
	    realize_instances.location = (1621.86328125, -270.0395202636719)
	    curve_line_1.location = (1446.1905517578125, -329.26934814453125)
	    resample_curve_4.location = (1967.627685546875, -174.60067749023438)
	    set_position_001_3.location = (2432.850341796875, -254.134033203125)
	    geometry_proximity_1.location = (2293.907958984375, -508.3775939941406)
	    curve_to_mesh_001_1.location = (1981.537841796875, -557.6326293945312)
	    capture_attribute_6.location = (2150.01220703125, -256.2615966796875)
	    position_001_3.location = (2143.646484375, -180.65032958984375)
	    attribute_statistic_001.location = (-71.79378509521484, -31.660974502563477)
	    repeat_input_1.location = (99.01121520996094, -41.19667053222656)
	    repeat_output_1.location = (2753.04541015625, -41.19667053222656)
	    join_geometry_001_1.location = (2573.40576171875, -71.7889404296875)
	    math_6.location = (2593.523681640625, -110.43626403808594)
	    math_001_3.location = (-73.19247436523438, -64.9359130859375)
	    named_attribute_003_1.location = (-73.26921081542969, 117.17273712158203)
	    group_001_5.location = (3537.784912109375, 97.02477264404297)
	    reroute_001_9.location = (-154.91433715820312, -33.560951232910156)
	    reroute_002_7.location = (-149.08628845214844, -369.71771240234375)
	    group_input_001_12.location = (828.1835327148438, -358.9533996582031)
	    reroute_003_6.location = (608.2127075195312, -322.5533447265625)
	    reroute_004_7.location = (627.9598999023438, -626.784912109375)
	    reroute_005_5.location = (1449.2567138671875, -621.3866577148438)
	    group_input_002_9.location = (1284.916015625, -135.2099609375)
	    group_input_003_9.location = (1968.3475341796875, -301.2956237792969)
	    endpoint_selection_001.location = (2433.987548828125, -412.75189208984375)
	    boolean_math_001_2.location = (2435.628662109375, -381.3258972167969)
	    sample_nearest_001_1.location = (3907.443359375, 21.718294143676758)
	    object_info_002.location = (3720.416259765625, -0.6742697358131409)
	    sample_index_001_1.location = (3914.627685546875, -27.68128204345703)
	    normal_002.location = (3917.103515625, -64.18562316894531)
	    group_input_005_8.location = (3714.7275390625, -30.789379119873047)
	    capture_attribute_002_5.location = (3722.0205078125, 121.66604614257812)
	    position_1.location = (3724.080810546875, 196.8589630126953)
	    set_position_002_2.location = (4260.25439453125, 125.46896362304688)
	    vector_math_002_3.location = (4258.66015625, -23.053760528564453)
	    named_attribute_001_2.location = (4082.3212890625, 17.682523727416992)
	    compare_001_3.location = (4082.32080078125, 54.87092971801758)
	    group_input_006_6.location = (3340.542236328125, 7.2145562171936035)
	    map_range_2.location = (4258.73388671875, -59.20608139038086)
	    group_input_007_5.location = (4257.83544921875, -91.74464416503906)
	    geometry_proximity_001_1.location = (3916.275390625, -124.71709442138672)
	    subdivide_mesh.location = (1284.614990234375, -265.76397705078125)
	    group_input_008_3.location = (3338.422119140625, 77.18179321289062)
	    set_curve_tilt_001.location = (3154.777099609375, 51.47222900390625)
	    switch_10.location = (4493.99365234375, 99.69527435302734)
	    group_input_010_2.location = (4490.82470703125, 196.77166748046875)
	    compare_002_7.location = (4493.9931640625, 135.6820068359375)
	    merge_by_distance_001.location = (4491.7109375, 47.16737747192383)
	    group_input_013_1.location = (2948.58349609375, -118.76447296142578)
	    group_7.location = (2950.806640625, 24.009780883789062)
	    subdivision_surface.location = (4674.0, 197.7174530029297)
	    group_input_011_1.location = (4491.658203125, 14.612602233886719)
	
	    #Set dimensions
	    group_input_14.width, group_input_14.height = 140.0, 100.0
	    group_output_19.width, group_output_19.height = 140.0, 100.0
	    named_attribute_4.width, named_attribute_4.height = 140.0, 100.0
	    compare_9.width, compare_9.height = 140.0, 100.0
	    separate_geometry.width, separate_geometry.height = 140.0, 100.0
	    convex_hull.width, convex_hull.height = 140.0, 100.0
	    object_info_3.width, object_info_3.height = 140.0, 100.0
	    mesh_boolean.width, mesh_boolean.height = 140.0, 100.0
	    delete_geometry_1.width, delete_geometry_1.height = 140.0, 100.0
	    boolean_math_4.width, boolean_math_4.height = 140.0, 100.0
	    named_attribute_002_1.width, named_attribute_002_1.height = 140.0, 100.0
	    attribute_statistic_1.width, attribute_statistic_1.height = 140.0, 100.0
	    mesh_to_points.width, mesh_to_points.height = 140.0, 100.0
	    merge_by_distance.width, merge_by_distance.height = 140.0, 100.0
	    instance_on_points.width, instance_on_points.height = 140.0, 100.0
	    set_position_3.width, set_position_3.height = 140.0, 100.0
	    endpoint_selection_3.width, endpoint_selection_3.height = 140.0, 100.0
	    realize_instances.width, realize_instances.height = 140.0, 100.0
	    curve_line_1.width, curve_line_1.height = 140.0, 100.0
	    resample_curve_4.width, resample_curve_4.height = 140.0, 100.0
	    set_position_001_3.width, set_position_001_3.height = 140.0, 100.0
	    geometry_proximity_1.width, geometry_proximity_1.height = 140.0, 100.0
	    curve_to_mesh_001_1.width, curve_to_mesh_001_1.height = 140.0, 100.0
	    capture_attribute_6.width, capture_attribute_6.height = 140.0, 100.0
	    position_001_3.width, position_001_3.height = 140.0, 100.0
	    attribute_statistic_001.width, attribute_statistic_001.height = 140.0, 100.0
	    repeat_input_1.width, repeat_input_1.height = 140.0, 100.0
	    repeat_output_1.width, repeat_output_1.height = 140.0, 100.0
	    join_geometry_001_1.width, join_geometry_001_1.height = 140.0, 100.0
	    math_6.width, math_6.height = 140.0, 100.0
	    math_001_3.width, math_001_3.height = 140.0, 100.0
	    named_attribute_003_1.width, named_attribute_003_1.height = 140.0, 100.0
	    group_001_5.width, group_001_5.height = 140.0, 100.0
	    reroute_001_9.width, reroute_001_9.height = 100.0, 100.0
	    reroute_002_7.width, reroute_002_7.height = 100.0, 100.0
	    group_input_001_12.width, group_input_001_12.height = 140.0, 100.0
	    reroute_003_6.width, reroute_003_6.height = 100.0, 100.0
	    reroute_004_7.width, reroute_004_7.height = 100.0, 100.0
	    reroute_005_5.width, reroute_005_5.height = 100.0, 100.0
	    group_input_002_9.width, group_input_002_9.height = 140.0, 100.0
	    group_input_003_9.width, group_input_003_9.height = 140.0, 100.0
	    endpoint_selection_001.width, endpoint_selection_001.height = 140.0, 100.0
	    boolean_math_001_2.width, boolean_math_001_2.height = 140.0, 100.0
	    sample_nearest_001_1.width, sample_nearest_001_1.height = 140.0, 100.0
	    object_info_002.width, object_info_002.height = 140.0, 100.0
	    sample_index_001_1.width, sample_index_001_1.height = 140.0, 100.0
	    normal_002.width, normal_002.height = 140.0, 100.0
	    group_input_005_8.width, group_input_005_8.height = 140.0, 100.0
	    capture_attribute_002_5.width, capture_attribute_002_5.height = 140.0, 100.0
	    position_1.width, position_1.height = 140.0, 100.0
	    set_position_002_2.width, set_position_002_2.height = 140.0, 100.0
	    vector_math_002_3.width, vector_math_002_3.height = 140.0, 100.0
	    named_attribute_001_2.width, named_attribute_001_2.height = 140.0, 100.0
	    compare_001_3.width, compare_001_3.height = 140.0, 100.0
	    group_input_006_6.width, group_input_006_6.height = 140.0, 100.0
	    map_range_2.width, map_range_2.height = 140.0, 100.0
	    group_input_007_5.width, group_input_007_5.height = 140.0, 100.0
	    geometry_proximity_001_1.width, geometry_proximity_001_1.height = 140.0, 100.0
	    subdivide_mesh.width, subdivide_mesh.height = 140.0, 100.0
	    group_input_008_3.width, group_input_008_3.height = 140.0, 100.0
	    set_curve_tilt_001.width, set_curve_tilt_001.height = 140.0, 100.0
	    switch_10.width, switch_10.height = 140.0, 100.0
	    group_input_010_2.width, group_input_010_2.height = 140.0, 100.0
	    compare_002_7.width, compare_002_7.height = 140.0, 100.0
	    merge_by_distance_001.width, merge_by_distance_001.height = 140.0, 100.0
	    group_input_013_1.width, group_input_013_1.height = 140.0, 100.0
	    group_7.width, group_7.height = 140.0, 100.0
	    subdivision_surface.width, subdivision_surface.height = 150.0, 100.0
	    group_input_011_1.width, group_input_011_1.height = 140.0, 100.0
	
	    #initialize scalp_mesh_hair links
	    #named_attribute_4.Attribute -> compare_9.A
	    scalp_mesh_hair.links.new(named_attribute_4.outputs[0], compare_9.inputs[2])
	    #reroute_002_7.Output -> separate_geometry.Geometry
	    scalp_mesh_hair.links.new(reroute_002_7.outputs[0], separate_geometry.inputs[0])
	    #compare_9.Result -> separate_geometry.Selection
	    scalp_mesh_hair.links.new(compare_9.outputs[0], separate_geometry.inputs[1])
	    #reroute_003_6.Output -> convex_hull.Geometry
	    scalp_mesh_hair.links.new(reroute_003_6.outputs[0], convex_hull.inputs[0])
	    #convex_hull.Convex Hull -> mesh_boolean.Mesh 1
	    scalp_mesh_hair.links.new(convex_hull.outputs[0], mesh_boolean.inputs[0])
	    #object_info_3.Geometry -> mesh_boolean.Mesh
	    scalp_mesh_hair.links.new(object_info_3.outputs[4], mesh_boolean.inputs[1])
	    #mesh_boolean.Intersecting Edges -> boolean_math_4.Boolean
	    scalp_mesh_hair.links.new(mesh_boolean.outputs[1], boolean_math_4.inputs[0])
	    #mesh_boolean.Mesh -> delete_geometry_1.Geometry
	    scalp_mesh_hair.links.new(mesh_boolean.outputs[0], delete_geometry_1.inputs[0])
	    #boolean_math_4.Boolean -> delete_geometry_1.Selection
	    scalp_mesh_hair.links.new(boolean_math_4.outputs[0], delete_geometry_1.inputs[1])
	    #named_attribute_002_1.Attribute -> attribute_statistic_1.Attribute
	    scalp_mesh_hair.links.new(named_attribute_002_1.outputs[0], attribute_statistic_1.inputs[2])
	    #merge_by_distance.Geometry -> mesh_to_points.Mesh
	    scalp_mesh_hair.links.new(merge_by_distance.outputs[0], mesh_to_points.inputs[0])
	    #mesh_to_points.Points -> instance_on_points.Points
	    scalp_mesh_hair.links.new(mesh_to_points.outputs[0], instance_on_points.inputs[0])
	    #realize_instances.Geometry -> set_position_3.Geometry
	    scalp_mesh_hair.links.new(realize_instances.outputs[0], set_position_3.inputs[0])
	    #instance_on_points.Instances -> realize_instances.Geometry
	    scalp_mesh_hair.links.new(instance_on_points.outputs[0], realize_instances.inputs[0])
	    #endpoint_selection_3.Selection -> set_position_3.Selection
	    scalp_mesh_hair.links.new(endpoint_selection_3.outputs[0], set_position_3.inputs[1])
	    #curve_line_1.Curve -> instance_on_points.Instance
	    scalp_mesh_hair.links.new(curve_line_1.outputs[0], instance_on_points.inputs[2])
	    #attribute_statistic_1.Mean -> set_position_3.Position
	    scalp_mesh_hair.links.new(attribute_statistic_1.outputs[0], set_position_3.inputs[2])
	    #set_position_3.Geometry -> resample_curve_4.Curve
	    scalp_mesh_hair.links.new(set_position_3.outputs[0], resample_curve_4.inputs[0])
	    #capture_attribute_6.Geometry -> set_position_001_3.Geometry
	    scalp_mesh_hair.links.new(capture_attribute_6.outputs[0], set_position_001_3.inputs[0])
	    #curve_to_mesh_001_1.Mesh -> geometry_proximity_1.Geometry
	    scalp_mesh_hair.links.new(curve_to_mesh_001_1.outputs[0], geometry_proximity_1.inputs[0])
	    #reroute_005_5.Output -> curve_to_mesh_001_1.Curve
	    scalp_mesh_hair.links.new(reroute_005_5.outputs[0], curve_to_mesh_001_1.inputs[0])
	    #resample_curve_4.Curve -> capture_attribute_6.Geometry
	    scalp_mesh_hair.links.new(resample_curve_4.outputs[0], capture_attribute_6.inputs[0])
	    #position_001_3.Position -> capture_attribute_6.Position
	    scalp_mesh_hair.links.new(position_001_3.outputs[0], capture_attribute_6.inputs[1])
	    #capture_attribute_6.Position -> geometry_proximity_1.Sample Position
	    scalp_mesh_hair.links.new(capture_attribute_6.outputs[1], geometry_proximity_1.inputs[2])
	    #geometry_proximity_1.Position -> set_position_001_3.Position
	    scalp_mesh_hair.links.new(geometry_proximity_1.outputs[0], set_position_001_3.inputs[2])
	    #join_geometry_001_1.Geometry -> repeat_output_1.Geometry
	    scalp_mesh_hair.links.new(join_geometry_001_1.outputs[0], repeat_output_1.inputs[0])
	    #math_6.Value -> repeat_output_1.Index
	    scalp_mesh_hair.links.new(math_6.outputs[0], repeat_output_1.inputs[1])
	    #repeat_input_1.Index -> math_6.Value
	    scalp_mesh_hair.links.new(repeat_input_1.outputs[2], math_6.inputs[0])
	    #reroute_001_9.Output -> attribute_statistic_001.Geometry
	    scalp_mesh_hair.links.new(reroute_001_9.outputs[0], attribute_statistic_001.inputs[0])
	    #math_001_3.Value -> repeat_input_1.Iterations
	    scalp_mesh_hair.links.new(math_001_3.outputs[0], repeat_input_1.inputs[0])
	    #attribute_statistic_001.Max -> math_001_3.Value
	    scalp_mesh_hair.links.new(attribute_statistic_001.outputs[4], math_001_3.inputs[0])
	    #named_attribute_003_1.Attribute -> attribute_statistic_001.Attribute
	    scalp_mesh_hair.links.new(named_attribute_003_1.outputs[0], attribute_statistic_001.inputs[2])
	    #set_position_001_3.Geometry -> join_geometry_001_1.Geometry
	    scalp_mesh_hair.links.new(set_position_001_3.outputs[0], join_geometry_001_1.inputs[0])
	    #repeat_input_1.Index -> compare_9.B
	    scalp_mesh_hair.links.new(repeat_input_1.outputs[2], compare_9.inputs[3])
	    #group_input_14.Geometry -> reroute_001_9.Input
	    scalp_mesh_hair.links.new(group_input_14.outputs[0], reroute_001_9.inputs[0])
	    #reroute_001_9.Output -> reroute_002_7.Input
	    scalp_mesh_hair.links.new(reroute_001_9.outputs[0], reroute_002_7.inputs[0])
	    #group_input_001_12.Surface -> object_info_3.Object
	    scalp_mesh_hair.links.new(group_input_001_12.outputs[1], object_info_3.inputs[0])
	    #separate_geometry.Selection -> reroute_003_6.Input
	    scalp_mesh_hair.links.new(separate_geometry.outputs[0], reroute_003_6.inputs[0])
	    #reroute_003_6.Output -> reroute_004_7.Input
	    scalp_mesh_hair.links.new(reroute_003_6.outputs[0], reroute_004_7.inputs[0])
	    #reroute_004_7.Output -> reroute_005_5.Input
	    scalp_mesh_hair.links.new(reroute_004_7.outputs[0], reroute_005_5.inputs[0])
	    #reroute_005_5.Output -> attribute_statistic_1.Geometry
	    scalp_mesh_hair.links.new(reroute_005_5.outputs[0], attribute_statistic_1.inputs[0])
	    #group_input_002_9.Guide Merge Distance -> merge_by_distance.Distance
	    scalp_mesh_hair.links.new(group_input_002_9.outputs[5], merge_by_distance.inputs[2])
	    #group_input_003_9.Control Points -> resample_curve_4.Count
	    scalp_mesh_hair.links.new(group_input_003_9.outputs[3], resample_curve_4.inputs[2])
	    #endpoint_selection_001.Selection -> boolean_math_001_2.Boolean
	    scalp_mesh_hair.links.new(endpoint_selection_001.outputs[0], boolean_math_001_2.inputs[0])
	    #boolean_math_001_2.Boolean -> set_position_001_3.Selection
	    scalp_mesh_hair.links.new(boolean_math_001_2.outputs[0], set_position_001_3.inputs[1])
	    #object_info_002.Geometry -> sample_nearest_001_1.Geometry
	    scalp_mesh_hair.links.new(object_info_002.outputs[4], sample_nearest_001_1.inputs[0])
	    #object_info_002.Geometry -> sample_index_001_1.Geometry
	    scalp_mesh_hair.links.new(object_info_002.outputs[4], sample_index_001_1.inputs[0])
	    #sample_nearest_001_1.Index -> sample_index_001_1.Index
	    scalp_mesh_hair.links.new(sample_nearest_001_1.outputs[0], sample_index_001_1.inputs[2])
	    #normal_002.Normal -> sample_index_001_1.Value
	    scalp_mesh_hair.links.new(normal_002.outputs[0], sample_index_001_1.inputs[1])
	    #group_input_005_8.Surface -> object_info_002.Object
	    scalp_mesh_hair.links.new(group_input_005_8.outputs[1], object_info_002.inputs[0])
	    #group_001_5.Geometry -> capture_attribute_002_5.Geometry
	    scalp_mesh_hair.links.new(group_001_5.outputs[0], capture_attribute_002_5.inputs[0])
	    #position_1.Position -> capture_attribute_002_5.Position
	    scalp_mesh_hair.links.new(position_1.outputs[0], capture_attribute_002_5.inputs[1])
	    #capture_attribute_002_5.Position -> sample_nearest_001_1.Sample Position
	    scalp_mesh_hair.links.new(capture_attribute_002_5.outputs[1], sample_nearest_001_1.inputs[1])
	    #capture_attribute_002_5.Geometry -> set_position_002_2.Geometry
	    scalp_mesh_hair.links.new(capture_attribute_002_5.outputs[0], set_position_002_2.inputs[0])
	    #sample_index_001_1.Value -> vector_math_002_3.Vector
	    scalp_mesh_hair.links.new(sample_index_001_1.outputs[0], vector_math_002_3.inputs[0])
	    #vector_math_002_3.Vector -> set_position_002_2.Offset
	    scalp_mesh_hair.links.new(vector_math_002_3.outputs[0], set_position_002_2.inputs[3])
	    #named_attribute_001_2.Attribute -> compare_001_3.A
	    scalp_mesh_hair.links.new(named_attribute_001_2.outputs[0], compare_001_3.inputs[4])
	    #compare_001_3.Result -> set_position_002_2.Selection
	    scalp_mesh_hair.links.new(compare_001_3.outputs[0], set_position_002_2.inputs[1])
	    #group_input_006_6.Width -> group_001_5.Width
	    scalp_mesh_hair.links.new(group_input_006_6.outputs[4], group_001_5.inputs[4])
	    #group_input_006_6.Material -> group_001_5.Material
	    scalp_mesh_hair.links.new(group_input_006_6.outputs[2], group_001_5.inputs[5])
	    #map_range_2.Result -> vector_math_002_3.Scale
	    scalp_mesh_hair.links.new(map_range_2.outputs[0], vector_math_002_3.inputs[3])
	    #group_input_007_5.Surface Offset -> map_range_2.To Max
	    scalp_mesh_hair.links.new(group_input_007_5.outputs[8], map_range_2.inputs[4])
	    #object_info_002.Geometry -> geometry_proximity_001_1.Geometry
	    scalp_mesh_hair.links.new(object_info_002.outputs[4], geometry_proximity_001_1.inputs[0])
	    #capture_attribute_002_5.Position -> geometry_proximity_001_1.Sample Position
	    scalp_mesh_hair.links.new(capture_attribute_002_5.outputs[1], geometry_proximity_001_1.inputs[2])
	    #geometry_proximity_001_1.Position -> set_position_002_2.Position
	    scalp_mesh_hair.links.new(geometry_proximity_001_1.outputs[0], set_position_002_2.inputs[2])
	    #delete_geometry_1.Geometry -> subdivide_mesh.Mesh
	    scalp_mesh_hair.links.new(delete_geometry_1.outputs[0], subdivide_mesh.inputs[0])
	    #subdivide_mesh.Mesh -> merge_by_distance.Geometry
	    scalp_mesh_hair.links.new(subdivide_mesh.outputs[0], merge_by_distance.inputs[0])
	    #set_curve_tilt_001.Curve -> group_001_5.Geometry
	    scalp_mesh_hair.links.new(set_curve_tilt_001.outputs[0], group_001_5.inputs[0])
	    #group_input_010_2.Mesh Merge Distance -> compare_002_7.A
	    scalp_mesh_hair.links.new(group_input_010_2.outputs[6], compare_002_7.inputs[0])
	    #group_input_010_2.Mesh Merge Distance -> merge_by_distance_001.Distance
	    scalp_mesh_hair.links.new(group_input_010_2.outputs[6], merge_by_distance_001.inputs[2])
	    #set_position_002_2.Geometry -> merge_by_distance_001.Geometry
	    scalp_mesh_hair.links.new(set_position_002_2.outputs[0], merge_by_distance_001.inputs[0])
	    #merge_by_distance_001.Geometry -> switch_10.True
	    scalp_mesh_hair.links.new(merge_by_distance_001.outputs[0], switch_10.inputs[2])
	    #compare_002_7.Result -> switch_10.Switch
	    scalp_mesh_hair.links.new(compare_002_7.outputs[0], switch_10.inputs[0])
	    #set_position_002_2.Geometry -> switch_10.False
	    scalp_mesh_hair.links.new(set_position_002_2.outputs[0], switch_10.inputs[1])
	    #subdivision_surface.Mesh -> group_output_19.Geometry
	    scalp_mesh_hair.links.new(subdivision_surface.outputs[0], group_output_19.inputs[0])
	    #group_input_013_1.Surface -> group_7.Surface
	    scalp_mesh_hair.links.new(group_input_013_1.outputs[1], group_7.inputs[2])
	    #repeat_output_1.Geometry -> group_7.Geometry
	    scalp_mesh_hair.links.new(repeat_output_1.outputs[0], group_7.inputs[0])
	    #group_7.Geometry -> set_curve_tilt_001.Curve
	    scalp_mesh_hair.links.new(group_7.outputs[0], set_curve_tilt_001.inputs[0])
	    #group_7.Tilt -> set_curve_tilt_001.Tilt
	    scalp_mesh_hair.links.new(group_7.outputs[1], set_curve_tilt_001.inputs[2])
	    #switch_10.Output -> subdivision_surface.Mesh
	    scalp_mesh_hair.links.new(switch_10.outputs[0], subdivision_surface.inputs[0])
	    #group_input_011_1.Subdivision Level -> subdivision_surface.Level
	    scalp_mesh_hair.links.new(group_input_011_1.outputs[7], subdivision_surface.inputs[1])
	    #group_input_008_3.Mesh Shape -> group_001_5.Curve Radius
	    scalp_mesh_hair.links.new(group_input_008_3.outputs[9], group_001_5.inputs[2])
	    #group_input_007_5.Surface Offset Shape -> map_range_2.Value
	    scalp_mesh_hair.links.new(group_input_007_5.outputs[10], map_range_2.inputs[0])
	    #convex_hull.Convex Hull -> mesh_boolean.Mesh
	    scalp_mesh_hair.links.new(convex_hull.outputs[0], mesh_boolean.inputs[1])
	    #repeat_input_1.Geometry -> join_geometry_001_1.Geometry
	    scalp_mesh_hair.links.new(repeat_input_1.outputs[1], join_geometry_001_1.inputs[0])
	    return scalp_mesh_hair
	
	scalp_mesh_hair = scalp_mesh_hair_node_group()
	
	#initialize shape_fill node group
	def shape_fill_node_group():
	    shape_fill = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Shape_Fill")
	
	    shape_fill.color_tag = 'NONE'
	    shape_fill.description = ""
	    shape_fill.default_group_node_width = 140
	    
	
	
	    #shape_fill interface
	    #Socket Geometry
	    geometry_socket_28 = shape_fill.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_28.attribute_domain = 'POINT'
	
	    #Socket Target
	    target_socket = shape_fill.interface.new_socket(name = "Target", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    target_socket.attribute_domain = 'POINT'
	
	    #Socket Count
	    count_socket = shape_fill.interface.new_socket(name = "Count", in_out='INPUT', socket_type = 'NodeSocketInt')
	    count_socket.default_value = 10
	    count_socket.min_value = 0
	    count_socket.max_value = 2147483647
	    count_socket.subtype = 'NONE'
	    count_socket.attribute_domain = 'POINT'
	
	    #Socket Closest_Pt
	    closest_pt_socket = shape_fill.interface.new_socket(name = "Closest_Pt", in_out='INPUT', socket_type = 'NodeSocketVector')
	    closest_pt_socket.default_value = (0.0, 0.0, 0.0)
	    closest_pt_socket.min_value = -3.4028234663852886e+38
	    closest_pt_socket.max_value = 3.4028234663852886e+38
	    closest_pt_socket.subtype = 'NONE'
	    closest_pt_socket.attribute_domain = 'POINT'
	
	    #Socket Index
	    index_socket = shape_fill.interface.new_socket(name = "Index", in_out='INPUT', socket_type = 'NodeSocketInt')
	    index_socket.default_value = 0
	    index_socket.min_value = 0
	    index_socket.max_value = 2147483647
	    index_socket.subtype = 'NONE'
	    index_socket.attribute_domain = 'POINT'
	
	
	    #initialize shape_fill nodes
	    #node Group Output
	    group_output_20 = shape_fill.nodes.new("NodeGroupOutput")
	    group_output_20.name = "Group Output"
	    group_output_20.is_active_output = True
	
	    #node Group Input
	    group_input_15 = shape_fill.nodes.new("NodeGroupInput")
	    group_input_15.name = "Group Input"
	    group_input_15.outputs[1].hide = True
	    group_input_15.outputs[2].hide = True
	    group_input_15.outputs[4].hide = True
	
	    #node Grid
	    grid = shape_fill.nodes.new("GeometryNodeMeshGrid")
	    grid.name = "Grid"
	    grid.inputs[0].hide = True
	    grid.inputs[1].hide = True
	    grid.inputs[3].hide = True
	    #Size X
	    grid.inputs[0].default_value = 1.0
	    #Size Y
	    grid.inputs[1].default_value = 1.0
	    #Vertices Y
	    grid.inputs[3].default_value = 2
	
	    #node Store Named Attribute
	    store_named_attribute_6 = shape_fill.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_6.name = "Store Named Attribute"
	    store_named_attribute_6.data_type = 'FLOAT2'
	    store_named_attribute_6.domain = 'CORNER'
	    #Selection
	    store_named_attribute_6.inputs[1].default_value = True
	    #Name
	    store_named_attribute_6.inputs[2].default_value = "UVMap"
	
	    #node Index
	    index_5 = shape_fill.nodes.new("GeometryNodeInputIndex")
	    index_5.name = "Index"
	
	    #node Math.002
	    math_002_2 = shape_fill.nodes.new("ShaderNodeMath")
	    math_002_2.name = "Math.002"
	    math_002_2.hide = True
	    math_002_2.operation = 'DIVIDE'
	    math_002_2.use_clamp = False
	    math_002_2.inputs[1].hide = True
	    math_002_2.inputs[2].hide = True
	    #Value_001
	    math_002_2.inputs[1].default_value = 2.0
	
	    #node Vector Math
	    vector_math_7 = shape_fill.nodes.new("ShaderNodeVectorMath")
	    vector_math_7.name = "Vector Math"
	    vector_math_7.hide = True
	    vector_math_7.operation = 'SCALE'
	
	    #node Math.003
	    math_003_2 = shape_fill.nodes.new("ShaderNodeMath")
	    math_003_2.name = "Math.003"
	    math_003_2.hide = True
	    math_003_2.operation = 'FLOOR'
	    math_003_2.use_clamp = False
	
	    #node Map Range.002
	    map_range_002 = shape_fill.nodes.new("ShaderNodeMapRange")
	    map_range_002.name = "Map Range.002"
	    map_range_002.hide = True
	    map_range_002.clamp = True
	    map_range_002.data_type = 'FLOAT'
	    map_range_002.interpolation_type = 'LINEAR'
	    map_range_002.inputs[1].hide = True
	    map_range_002.inputs[3].hide = True
	    map_range_002.inputs[4].hide = True
	    map_range_002.inputs[5].hide = True
	    map_range_002.inputs[6].hide = True
	    map_range_002.inputs[7].hide = True
	    map_range_002.inputs[8].hide = True
	    map_range_002.inputs[9].hide = True
	    map_range_002.inputs[10].hide = True
	    map_range_002.inputs[11].hide = True
	    map_range_002.outputs[1].hide = True
	    #From Min
	    map_range_002.inputs[1].default_value = 0.0
	    #To Min
	    map_range_002.inputs[3].default_value = 0.0
	    #To Max
	    map_range_002.inputs[4].default_value = 1.0
	
	    #node Math.004
	    math_004_2 = shape_fill.nodes.new("ShaderNodeMath")
	    math_004_2.name = "Math.004"
	    math_004_2.hide = True
	    math_004_2.operation = 'FLOORED_MODULO'
	    math_004_2.use_clamp = False
	    math_004_2.inputs[1].hide = True
	    math_004_2.inputs[2].hide = True
	    #Value_001
	    math_004_2.inputs[1].default_value = 2.0
	
	    #node Compare.005
	    compare_005_2 = shape_fill.nodes.new("FunctionNodeCompare")
	    compare_005_2.name = "Compare.005"
	    compare_005_2.hide = True
	    compare_005_2.data_type = 'FLOAT'
	    compare_005_2.mode = 'ELEMENT'
	    compare_005_2.operation = 'EQUAL'
	    #B
	    compare_005_2.inputs[1].default_value = 0.0
	    #Epsilon
	    compare_005_2.inputs[12].default_value = 0.0
	
	    #node Compare.006
	    compare_006_1 = shape_fill.nodes.new("FunctionNodeCompare")
	    compare_006_1.name = "Compare.006"
	    compare_006_1.hide = True
	    compare_006_1.data_type = 'FLOAT'
	    compare_006_1.mode = 'ELEMENT'
	    compare_006_1.operation = 'EQUAL'
	    #B
	    compare_006_1.inputs[1].default_value = 1.0
	    #Epsilon
	    compare_006_1.inputs[12].default_value = 0.0
	
	    #node Math.005
	    math_005_2 = shape_fill.nodes.new("ShaderNodeMath")
	    math_005_2.name = "Math.005"
	    math_005_2.hide = True
	    math_005_2.operation = 'SUBTRACT'
	    math_005_2.use_clamp = False
	    math_005_2.inputs[1].hide = True
	    math_005_2.inputs[2].hide = True
	    #Value_001
	    math_005_2.inputs[1].default_value = 1.0
	
	    #node Vector Math.001
	    vector_math_001_3 = shape_fill.nodes.new("ShaderNodeVectorMath")
	    vector_math_001_3.name = "Vector Math.001"
	    vector_math_001_3.hide = True
	    vector_math_001_3.operation = 'ADD'
	
	    #node Vector Math.003
	    vector_math_003_3 = shape_fill.nodes.new("ShaderNodeVectorMath")
	    vector_math_003_3.name = "Vector Math.003"
	    vector_math_003_3.hide = True
	    vector_math_003_3.operation = 'SUBTRACT'
	
	    #node Vector Math.004
	    vector_math_004_5 = shape_fill.nodes.new("ShaderNodeVectorMath")
	    vector_math_004_5.name = "Vector Math.004"
	    vector_math_004_5.hide = True
	    vector_math_004_5.operation = 'SCALE'
	
	    #node Vector Math.005
	    vector_math_005_2 = shape_fill.nodes.new("ShaderNodeVectorMath")
	    vector_math_005_2.name = "Vector Math.005"
	    vector_math_005_2.hide = True
	    vector_math_005_2.operation = 'ADD'
	
	    #node Vector Math.006
	    vector_math_006_2 = shape_fill.nodes.new("ShaderNodeVectorMath")
	    vector_math_006_2.name = "Vector Math.006"
	    vector_math_006_2.hide = True
	    vector_math_006_2.operation = 'SUBTRACT'
	
	    #node Frame.002
	    frame_002_4 = shape_fill.nodes.new("NodeFrame")
	    frame_002_4.name = "Frame.002"
	    frame_002_4.label_size = 20
	    frame_002_4.shrink = True
	
	    #node Frame.003
	    frame_003_3 = shape_fill.nodes.new("NodeFrame")
	    frame_003_3.name = "Frame.003"
	    frame_003_3.label_size = 20
	    frame_003_3.shrink = True
	
	    #node Frame.004
	    frame_004_3 = shape_fill.nodes.new("NodeFrame")
	    frame_004_3.name = "Frame.004"
	    frame_004_3.label_size = 20
	    frame_004_3.shrink = True
	
	    #node Frame.005
	    frame_005_3 = shape_fill.nodes.new("NodeFrame")
	    frame_005_3.name = "Frame.005"
	    frame_005_3.label_size = 20
	    frame_005_3.shrink = True
	
	    #node Set Position.003
	    set_position_003_1 = shape_fill.nodes.new("GeometryNodeSetPosition")
	    set_position_003_1.name = "Set Position.003"
	    set_position_003_1.inputs[3].hide = True
	    #Offset
	    set_position_003_1.inputs[3].default_value = (0.0, 0.0, 0.0)
	
	    #node Set Position.004
	    set_position_004_1 = shape_fill.nodes.new("GeometryNodeSetPosition")
	    set_position_004_1.name = "Set Position.004"
	    set_position_004_1.inputs[3].hide = True
	    #Offset
	    set_position_004_1.inputs[3].default_value = (0.0, 0.0, 0.0)
	
	    #node Edge Vertices
	    edge_vertices_1 = shape_fill.nodes.new("GeometryNodeInputMeshEdgeVertices")
	    edge_vertices_1.name = "Edge Vertices"
	    edge_vertices_1.outputs[0].hide = True
	    edge_vertices_1.outputs[1].hide = True
	
	    #node Sample Index
	    sample_index_3 = shape_fill.nodes.new("GeometryNodeSampleIndex")
	    sample_index_3.name = "Sample Index"
	    sample_index_3.hide = True
	    sample_index_3.clamp = False
	    sample_index_3.data_type = 'FLOAT_VECTOR'
	    sample_index_3.domain = 'EDGE'
	
	    #node Sample Index.001
	    sample_index_001_2 = shape_fill.nodes.new("GeometryNodeSampleIndex")
	    sample_index_001_2.name = "Sample Index.001"
	    sample_index_001_2.hide = True
	    sample_index_001_2.clamp = False
	    sample_index_001_2.data_type = 'FLOAT_VECTOR'
	    sample_index_001_2.domain = 'EDGE'
	
	    #node Frame
	    frame_7 = shape_fill.nodes.new("NodeFrame")
	    frame_7.name = "Frame"
	    frame_7.label_size = 20
	    frame_7.shrink = True
	
	    #node Group Input.001
	    group_input_001_13 = shape_fill.nodes.new("NodeGroupInput")
	    group_input_001_13.name = "Group Input.001"
	    group_input_001_13.outputs[0].hide = True
	    group_input_001_13.outputs[1].hide = True
	    group_input_001_13.outputs[3].hide = True
	    group_input_001_13.outputs[4].hide = True
	
	    #node Group Input.002
	    group_input_002_10 = shape_fill.nodes.new("NodeGroupInput")
	    group_input_002_10.name = "Group Input.002"
	    group_input_002_10.outputs[0].hide = True
	    group_input_002_10.outputs[2].hide = True
	    group_input_002_10.outputs[3].hide = True
	    group_input_002_10.outputs[4].hide = True
	
	    #node Group Input.003
	    group_input_003_10 = shape_fill.nodes.new("NodeGroupInput")
	    group_input_003_10.name = "Group Input.003"
	    group_input_003_10.outputs[0].hide = True
	    group_input_003_10.outputs[2].hide = True
	    group_input_003_10.outputs[3].hide = True
	    group_input_003_10.outputs[4].hide = True
	
	    #node Frame.001
	    frame_001_4 = shape_fill.nodes.new("NodeFrame")
	    frame_001_4.name = "Frame.001"
	    frame_001_4.label_size = 20
	    frame_001_4.shrink = True
	
	    #node Frame.006
	    frame_006_3 = shape_fill.nodes.new("NodeFrame")
	    frame_006_3.name = "Frame.006"
	    frame_006_3.label_size = 20
	    frame_006_3.shrink = True
	
	
	
	
	    #Set parents
	    index_5.parent = frame_001_4
	    math_002_2.parent = frame_004_3
	    vector_math_7.parent = frame_003_3
	    math_003_2.parent = frame_004_3
	    map_range_002.parent = frame_004_3
	    math_004_2.parent = frame_005_3
	    compare_005_2.parent = frame_005_3
	    compare_006_1.parent = frame_005_3
	    math_005_2.parent = frame_004_3
	    vector_math_001_3.parent = frame_003_3
	    vector_math_003_3.parent = frame_003_3
	    vector_math_004_5.parent = frame_002_4
	    vector_math_005_2.parent = frame_002_4
	    vector_math_006_2.parent = frame_002_4
	    frame_002_4.parent = frame_006_3
	    frame_003_3.parent = frame_006_3
	    frame_004_3.parent = frame_001_4
	    frame_005_3.parent = frame_001_4
	    edge_vertices_1.parent = frame_7
	    sample_index_3.parent = frame_7
	    sample_index_001_2.parent = frame_7
	
	    #Set locations
	    group_output_20.location = (815.5284423828125, 0.0)
	    group_input_15.location = (-736.8353271484375, -327.8897705078125)
	    grid.location = (-410.6092529296875, -127.79910278320312)
	    store_named_attribute_6.location = (-230.305908203125, -55.2906379699707)
	    index_5.location = (58.663330078125, -207.4080810546875)
	    math_002_2.location = (32.300140380859375, -142.4964599609375)
	    vector_math_7.location = (29.8404541015625, -70.91549682617188)
	    math_003_2.location = (32.300140380859375, -106.70068359375)
	    map_range_002.location = (34.534881591796875, -70.0452880859375)
	    math_004_2.location = (30.421600341796875, -34.69482421875)
	    compare_005_2.location = (32.271820068359375, -70.87353515625)
	    compare_006_1.location = (32.271942138671875, -106.6689453125)
	    math_005_2.location = (30.419403076171875, -35.109161376953125)
	    vector_math_001_3.location = (29.840576171875, -35.119781494140625)
	    vector_math_003_3.location = (29.84033203125, -108.5947265625)
	    vector_math_004_5.location = (29.9598388671875, -71.2415771484375)
	    vector_math_005_2.location = (29.9600830078125, -35.4459228515625)
	    vector_math_006_2.location = (29.9598388671875, -108.9208984375)
	    frame_002_4.location = (30.0, -202.0)
	    frame_003_3.location = (30.0, -30.0)
	    frame_004_3.location = (32.0, -30.0)
	    frame_005_3.location = (30.0, -233.0)
	    set_position_003_1.location = (430.7568664550781, -26.263755798339844)
	    set_position_004_1.location = (611.1026000976562, -2.331735134124756)
	    edge_vertices_1.location = (29.92950439453125, -41.535552978515625)
	    sample_index_3.location = (212.2432861328125, -34.9100341796875)
	    sample_index_001_2.location = (209.78094482421875, -96.54345703125)
	    frame_7.location = (-478.0, -272.0)
	    group_input_001_13.location = (-49.46245574951172, -692.7595825195312)
	    group_input_002_10.location = (-736.8353271484375, -177.50424194335938)
	    group_input_003_10.location = (-736.8353271484375, -488.13665771484375)
	    frame_001_4.location = (-439.0, -446.0)
	    frame_006_3.location = (232.0, -405.0)
	
	    #Set dimensions
	    group_output_20.width, group_output_20.height = 140.0, 100.0
	    group_input_15.width, group_input_15.height = 140.0, 100.0
	    grid.width, grid.height = 140.0, 100.0
	    store_named_attribute_6.width, store_named_attribute_6.height = 140.0, 100.0
	    index_5.width, index_5.height = 140.0, 100.0
	    math_002_2.width, math_002_2.height = 140.0, 100.0
	    vector_math_7.width, vector_math_7.height = 140.0, 100.0
	    math_003_2.width, math_003_2.height = 140.0, 100.0
	    map_range_002.width, map_range_002.height = 140.0, 100.0
	    math_004_2.width, math_004_2.height = 140.0, 100.0
	    compare_005_2.width, compare_005_2.height = 140.0, 100.0
	    compare_006_1.width, compare_006_1.height = 140.0, 100.0
	    math_005_2.width, math_005_2.height = 140.0, 100.0
	    vector_math_001_3.width, vector_math_001_3.height = 140.0, 100.0
	    vector_math_003_3.width, vector_math_003_3.height = 140.0, 100.0
	    vector_math_004_5.width, vector_math_004_5.height = 140.0, 100.0
	    vector_math_005_2.width, vector_math_005_2.height = 140.0, 100.0
	    vector_math_006_2.width, vector_math_006_2.height = 140.0, 100.0
	    frame_002_4.width, frame_002_4.height = 200.0, 164.0
	    frame_003_3.width, frame_003_3.height = 200.0, 164.0
	    frame_004_3.width, frame_004_3.height = 205.0, 197.0
	    frame_005_3.width, frame_005_3.height = 202.0, 162.0
	    set_position_003_1.width, set_position_003_1.height = 140.0, 100.0
	    set_position_004_1.width, set_position_004_1.height = 140.0, 100.0
	    edge_vertices_1.width, edge_vertices_1.height = 140.0, 100.0
	    sample_index_3.width, sample_index_3.height = 140.0, 100.0
	    sample_index_001_2.width, sample_index_001_2.height = 140.0, 100.0
	    frame_7.width, frame_7.height = 382.0, 152.0
	    group_input_001_13.width, group_input_001_13.height = 140.0, 100.0
	    group_input_002_10.width, group_input_002_10.height = 140.0, 100.0
	    group_input_003_10.width, group_input_003_10.height = 140.0, 100.0
	    frame_001_4.width, frame_001_4.height = 267.0, 425.0
	    frame_006_3.width, frame_006_3.height = 260.0, 396.0
	
	    #initialize shape_fill links
	    #math_005_2.Value -> map_range_002.From Max
	    shape_fill.links.new(math_005_2.outputs[0], map_range_002.inputs[2])
	    #vector_math_006_2.Vector -> vector_math_004_5.Vector
	    shape_fill.links.new(vector_math_006_2.outputs[0], vector_math_004_5.inputs[0])
	    #grid.UV Map -> store_named_attribute_6.Value
	    shape_fill.links.new(grid.outputs[1], store_named_attribute_6.inputs[3])
	    #sample_index_001_2.Value -> vector_math_006_2.Vector
	    shape_fill.links.new(sample_index_001_2.outputs[0], vector_math_006_2.inputs[1])
	    #set_position_003_1.Geometry -> set_position_004_1.Geometry
	    shape_fill.links.new(set_position_003_1.outputs[0], set_position_004_1.inputs[0])
	    #group_input_001_13.Closest_Pt -> vector_math_006_2.Vector
	    shape_fill.links.new(group_input_001_13.outputs[2], vector_math_006_2.inputs[0])
	    #math_004_2.Value -> compare_006_1.A
	    shape_fill.links.new(math_004_2.outputs[0], compare_006_1.inputs[0])
	    #sample_index_001_2.Value -> vector_math_005_2.Vector
	    shape_fill.links.new(sample_index_001_2.outputs[0], vector_math_005_2.inputs[1])
	    #math_004_2.Value -> compare_005_2.A
	    shape_fill.links.new(math_004_2.outputs[0], compare_005_2.inputs[0])
	    #compare_005_2.Result -> set_position_003_1.Selection
	    shape_fill.links.new(compare_005_2.outputs[0], set_position_003_1.inputs[1])
	    #map_range_002.Result -> vector_math_004_5.Scale
	    shape_fill.links.new(map_range_002.outputs[0], vector_math_004_5.inputs[3])
	    #vector_math_005_2.Vector -> set_position_004_1.Position
	    shape_fill.links.new(vector_math_005_2.outputs[0], set_position_004_1.inputs[2])
	    #compare_006_1.Result -> set_position_004_1.Selection
	    shape_fill.links.new(compare_006_1.outputs[0], set_position_004_1.inputs[1])
	    #vector_math_001_3.Vector -> set_position_003_1.Position
	    shape_fill.links.new(vector_math_001_3.outputs[0], set_position_003_1.inputs[2])
	    #vector_math_7.Vector -> vector_math_001_3.Vector
	    shape_fill.links.new(vector_math_7.outputs[0], vector_math_001_3.inputs[0])
	    #math_003_2.Value -> map_range_002.Value
	    shape_fill.links.new(math_003_2.outputs[0], map_range_002.inputs[0])
	    #vector_math_004_5.Vector -> vector_math_005_2.Vector
	    shape_fill.links.new(vector_math_004_5.outputs[0], vector_math_005_2.inputs[0])
	    #sample_index_3.Value -> vector_math_001_3.Vector
	    shape_fill.links.new(sample_index_3.outputs[0], vector_math_001_3.inputs[1])
	    #index_5.Index -> math_004_2.Value
	    shape_fill.links.new(index_5.outputs[0], math_004_2.inputs[0])
	    #map_range_002.Result -> vector_math_7.Scale
	    shape_fill.links.new(map_range_002.outputs[0], vector_math_7.inputs[3])
	    #vector_math_003_3.Vector -> vector_math_7.Vector
	    shape_fill.links.new(vector_math_003_3.outputs[0], vector_math_7.inputs[0])
	    #math_002_2.Value -> math_003_2.Value
	    shape_fill.links.new(math_002_2.outputs[0], math_003_2.inputs[0])
	    #sample_index_3.Value -> vector_math_003_3.Vector
	    shape_fill.links.new(sample_index_3.outputs[0], vector_math_003_3.inputs[1])
	    #index_5.Index -> math_002_2.Value
	    shape_fill.links.new(index_5.outputs[0], math_002_2.inputs[0])
	    #group_input_001_13.Closest_Pt -> vector_math_003_3.Vector
	    shape_fill.links.new(group_input_001_13.outputs[2], vector_math_003_3.inputs[0])
	    #grid.Mesh -> store_named_attribute_6.Geometry
	    shape_fill.links.new(grid.outputs[0], store_named_attribute_6.inputs[0])
	    #store_named_attribute_6.Geometry -> set_position_003_1.Geometry
	    shape_fill.links.new(store_named_attribute_6.outputs[0], set_position_003_1.inputs[0])
	    #set_position_004_1.Geometry -> group_output_20.Geometry
	    shape_fill.links.new(set_position_004_1.outputs[0], group_output_20.inputs[0])
	    #group_input_15.Target -> sample_index_3.Geometry
	    shape_fill.links.new(group_input_15.outputs[0], sample_index_3.inputs[0])
	    #group_input_15.Index -> sample_index_3.Index
	    shape_fill.links.new(group_input_15.outputs[3], sample_index_3.inputs[2])
	    #group_input_15.Target -> sample_index_001_2.Geometry
	    shape_fill.links.new(group_input_15.outputs[0], sample_index_001_2.inputs[0])
	    #group_input_15.Index -> sample_index_001_2.Index
	    shape_fill.links.new(group_input_15.outputs[3], sample_index_001_2.inputs[2])
	    #edge_vertices_1.Position 1 -> sample_index_3.Value
	    shape_fill.links.new(edge_vertices_1.outputs[2], sample_index_3.inputs[1])
	    #edge_vertices_1.Position 2 -> sample_index_001_2.Value
	    shape_fill.links.new(edge_vertices_1.outputs[3], sample_index_001_2.inputs[1])
	    #group_input_002_10.Count -> grid.Vertices X
	    shape_fill.links.new(group_input_002_10.outputs[1], grid.inputs[2])
	    #group_input_003_10.Count -> math_005_2.Value
	    shape_fill.links.new(group_input_003_10.outputs[1], math_005_2.inputs[0])
	    return shape_fill
	
	shape_fill = shape_fill_node_group()
	
	#initialize nearest_surface_data node group
	def nearest_surface_data_node_group():
	    nearest_surface_data = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Nearest_Surface_Data")
	
	    nearest_surface_data.color_tag = 'NONE'
	    nearest_surface_data.description = ""
	    nearest_surface_data.default_group_node_width = 140
	    
	
	
	    #nearest_surface_data interface
	    #Socket Position
	    position_socket = nearest_surface_data.interface.new_socket(name = "Position", in_out='OUTPUT', socket_type = 'NodeSocketVector')
	    position_socket.default_value = (0.0, 0.0, 0.0)
	    position_socket.min_value = -3.4028234663852886e+38
	    position_socket.max_value = 3.4028234663852886e+38
	    position_socket.subtype = 'NONE'
	    position_socket.attribute_domain = 'POINT'
	
	    #Socket Distance
	    distance_socket_1 = nearest_surface_data.interface.new_socket(name = "Distance", in_out='OUTPUT', socket_type = 'NodeSocketFloat')
	    distance_socket_1.default_value = 0.0
	    distance_socket_1.min_value = -3.4028234663852886e+38
	    distance_socket_1.max_value = 3.4028234663852886e+38
	    distance_socket_1.subtype = 'NONE'
	    distance_socket_1.attribute_domain = 'POINT'
	
	    #Socket Is Valid
	    is_valid_socket = nearest_surface_data.interface.new_socket(name = "Is Valid", in_out='OUTPUT', socket_type = 'NodeSocketBool')
	    is_valid_socket.default_value = False
	    is_valid_socket.attribute_domain = 'POINT'
	
	    #Socket Vector
	    vector_socket = nearest_surface_data.interface.new_socket(name = "Vector", in_out='OUTPUT', socket_type = 'NodeSocketVector')
	    vector_socket.default_value = (0.0, 0.0, 0.0)
	    vector_socket.min_value = -3.4028234663852886e+38
	    vector_socket.max_value = 3.4028234663852886e+38
	    vector_socket.subtype = 'NONE'
	    vector_socket.attribute_domain = 'POINT'
	
	    #Socket Dot Product
	    dot_product_socket = nearest_surface_data.interface.new_socket(name = "Dot Product", in_out='OUTPUT', socket_type = 'NodeSocketFloat')
	    dot_product_socket.default_value = 0.0
	    dot_product_socket.min_value = -3.4028234663852886e+38
	    dot_product_socket.max_value = 3.4028234663852886e+38
	    dot_product_socket.subtype = 'NONE'
	    dot_product_socket.attribute_domain = 'POINT'
	
	    #Socket Face Index
	    face_index_socket = nearest_surface_data.interface.new_socket(name = "Face Index", in_out='OUTPUT', socket_type = 'NodeSocketInt')
	    face_index_socket.default_value = 0
	    face_index_socket.min_value = -2147483648
	    face_index_socket.max_value = 2147483647
	    face_index_socket.subtype = 'NONE'
	    face_index_socket.attribute_domain = 'POINT'
	
	    #Socket Face Normal
	    face_normal_socket = nearest_surface_data.interface.new_socket(name = "Face Normal", in_out='OUTPUT', socket_type = 'NodeSocketVector')
	    face_normal_socket.default_value = (0.0, 0.0, 0.0)
	    face_normal_socket.min_value = -3.4028234663852886e+38
	    face_normal_socket.max_value = 3.4028234663852886e+38
	    face_normal_socket.subtype = 'NONE'
	    face_normal_socket.attribute_domain = 'POINT'
	
	    #Socket Geometry
	    geometry_socket_29 = nearest_surface_data.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_29.attribute_domain = 'POINT'
	
	    #Socket Sample Position
	    sample_position_socket = nearest_surface_data.interface.new_socket(name = "Sample Position", in_out='INPUT', socket_type = 'NodeSocketVector')
	    sample_position_socket.default_value = (0.0, 0.0, 0.0)
	    sample_position_socket.min_value = -3.4028234663852886e+38
	    sample_position_socket.max_value = 3.4028234663852886e+38
	    sample_position_socket.subtype = 'NONE'
	    sample_position_socket.attribute_domain = 'POINT'
	    sample_position_socket.hide_value = True
	
	
	    #initialize nearest_surface_data nodes
	    #node Group Output
	    group_output_21 = nearest_surface_data.nodes.new("NodeGroupOutput")
	    group_output_21.name = "Group Output"
	    group_output_21.is_active_output = True
	
	    #node Group Input
	    group_input_16 = nearest_surface_data.nodes.new("NodeGroupInput")
	    group_input_16.name = "Group Input"
	    group_input_16.outputs[2].hide = True
	
	    #node Geometry Proximity
	    geometry_proximity_2 = nearest_surface_data.nodes.new("GeometryNodeProximity")
	    geometry_proximity_2.name = "Geometry Proximity"
	    geometry_proximity_2.hide = True
	    geometry_proximity_2.target_element = 'FACES'
	    geometry_proximity_2.inputs[1].hide = True
	    geometry_proximity_2.inputs[3].hide = True
	    #Group ID
	    geometry_proximity_2.inputs[1].default_value = 0
	    #Sample Group ID
	    geometry_proximity_2.inputs[3].default_value = 0
	
	    #node Sample Nearest
	    sample_nearest_2 = nearest_surface_data.nodes.new("GeometryNodeSampleNearest")
	    sample_nearest_2.name = "Sample Nearest"
	    sample_nearest_2.hide = True
	    sample_nearest_2.domain = 'FACE'
	
	    #node Sample Index
	    sample_index_4 = nearest_surface_data.nodes.new("GeometryNodeSampleIndex")
	    sample_index_4.name = "Sample Index"
	    sample_index_4.hide = True
	    sample_index_4.clamp = False
	    sample_index_4.data_type = 'FLOAT_VECTOR'
	    sample_index_4.domain = 'FACE'
	
	    #node Vector Math
	    vector_math_8 = nearest_surface_data.nodes.new("ShaderNodeVectorMath")
	    vector_math_8.name = "Vector Math"
	    vector_math_8.hide = True
	    vector_math_8.operation = 'SUBTRACT'
	
	    #node Group Input.001
	    group_input_001_14 = nearest_surface_data.nodes.new("NodeGroupInput")
	    group_input_001_14.name = "Group Input.001"
	    group_input_001_14.outputs[2].hide = True
	
	    #node Normal
	    normal_4 = nearest_surface_data.nodes.new("GeometryNodeInputNormal")
	    normal_4.name = "Normal"
	    normal_4.hide = True
	    normal_4.legacy_corner_normals = True
	
	    #node Vector Math.001
	    vector_math_001_4 = nearest_surface_data.nodes.new("ShaderNodeVectorMath")
	    vector_math_001_4.name = "Vector Math.001"
	    vector_math_001_4.hide = True
	    vector_math_001_4.operation = 'NORMALIZE'
	
	    #node Vector Math.002
	    vector_math_002_4 = nearest_surface_data.nodes.new("ShaderNodeVectorMath")
	    vector_math_002_4.name = "Vector Math.002"
	    vector_math_002_4.hide = True
	    vector_math_002_4.operation = 'DOT_PRODUCT'
	
	
	
	
	
	    #Set locations
	    group_output_21.location = (379.0383605957031, 0.0)
	    group_input_16.location = (-200.0, -4.406444072723389)
	    geometry_proximity_2.location = (112.07869720458984, -39.657997131347656)
	    sample_nearest_2.location = (111.041748046875, -196.0867919921875)
	    sample_index_4.location = (113.24059295654297, -231.3383026123047)
	    vector_math_8.location = (113.24064636230469, -77.11277770996094)
	    group_input_001_14.location = (-200.0, -165.24166870117188)
	    normal_4.location = (113.24056243896484, -266.0278015136719)
	    vector_math_001_4.location = (113.24064636230469, -116.7707748413086)
	    vector_math_002_4.location = (113.24064636230469, -156.42877197265625)
	
	    #Set dimensions
	    group_output_21.width, group_output_21.height = 140.0, 100.0
	    group_input_16.width, group_input_16.height = 140.0, 100.0
	    geometry_proximity_2.width, geometry_proximity_2.height = 140.0, 100.0
	    sample_nearest_2.width, sample_nearest_2.height = 140.0, 100.0
	    sample_index_4.width, sample_index_4.height = 140.0, 100.0
	    vector_math_8.width, vector_math_8.height = 140.0, 100.0
	    group_input_001_14.width, group_input_001_14.height = 140.0, 100.0
	    normal_4.width, normal_4.height = 140.0, 100.0
	    vector_math_001_4.width, vector_math_001_4.height = 140.0, 100.0
	    vector_math_002_4.width, vector_math_002_4.height = 140.0, 100.0
	
	    #initialize nearest_surface_data links
	    #geometry_proximity_2.Position -> group_output_21.Position
	    nearest_surface_data.links.new(geometry_proximity_2.outputs[0], group_output_21.inputs[0])
	    #geometry_proximity_2.Distance -> group_output_21.Distance
	    nearest_surface_data.links.new(geometry_proximity_2.outputs[1], group_output_21.inputs[1])
	    #geometry_proximity_2.Is Valid -> group_output_21.Is Valid
	    nearest_surface_data.links.new(geometry_proximity_2.outputs[2], group_output_21.inputs[2])
	    #group_input_16.Geometry -> geometry_proximity_2.Geometry
	    nearest_surface_data.links.new(group_input_16.outputs[0], geometry_proximity_2.inputs[0])
	    #group_input_16.Sample Position -> geometry_proximity_2.Sample Position
	    nearest_surface_data.links.new(group_input_16.outputs[1], geometry_proximity_2.inputs[2])
	    #group_input_001_14.Geometry -> sample_nearest_2.Geometry
	    nearest_surface_data.links.new(group_input_001_14.outputs[0], sample_nearest_2.inputs[0])
	    #group_input_001_14.Sample Position -> sample_nearest_2.Sample Position
	    nearest_surface_data.links.new(group_input_001_14.outputs[1], sample_nearest_2.inputs[1])
	    #group_input_001_14.Geometry -> sample_index_4.Geometry
	    nearest_surface_data.links.new(group_input_001_14.outputs[0], sample_index_4.inputs[0])
	    #sample_nearest_2.Index -> sample_index_4.Index
	    nearest_surface_data.links.new(sample_nearest_2.outputs[0], sample_index_4.inputs[2])
	    #normal_4.Normal -> sample_index_4.Value
	    nearest_surface_data.links.new(normal_4.outputs[0], sample_index_4.inputs[1])
	    #geometry_proximity_2.Position -> vector_math_8.Vector
	    nearest_surface_data.links.new(geometry_proximity_2.outputs[0], vector_math_8.inputs[0])
	    #group_input_16.Sample Position -> vector_math_8.Vector
	    nearest_surface_data.links.new(group_input_16.outputs[1], vector_math_8.inputs[1])
	    #vector_math_8.Vector -> vector_math_001_4.Vector
	    nearest_surface_data.links.new(vector_math_8.outputs[0], vector_math_001_4.inputs[0])
	    #vector_math_001_4.Vector -> group_output_21.Vector
	    nearest_surface_data.links.new(vector_math_001_4.outputs[0], group_output_21.inputs[3])
	    #sample_index_4.Value -> vector_math_002_4.Vector
	    nearest_surface_data.links.new(sample_index_4.outputs[0], vector_math_002_4.inputs[1])
	    #vector_math_001_4.Vector -> vector_math_002_4.Vector
	    nearest_surface_data.links.new(vector_math_001_4.outputs[0], vector_math_002_4.inputs[0])
	    #vector_math_002_4.Value -> group_output_21.Dot Product
	    nearest_surface_data.links.new(vector_math_002_4.outputs[1], group_output_21.inputs[4])
	    #sample_nearest_2.Index -> group_output_21.Face Index
	    nearest_surface_data.links.new(sample_nearest_2.outputs[0], group_output_21.inputs[5])
	    #sample_index_4.Value -> group_output_21.Face Normal
	    nearest_surface_data.links.new(sample_index_4.outputs[0], group_output_21.inputs[6])
	    return nearest_surface_data
	
	nearest_surface_data = nearest_surface_data_node_group()
	
	#initialize scalp_stylized_mesh node group
	def scalp_stylized_mesh_node_group():
	    scalp_stylized_mesh = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "SCALP_STYLIZED_MESH")
	
	    scalp_stylized_mesh.color_tag = 'NONE'
	    scalp_stylized_mesh.description = ""
	    scalp_stylized_mesh.default_group_node_width = 140
	    
	
	    scalp_stylized_mesh.is_modifier = True
	
	    #scalp_stylized_mesh interface
	    #Socket Geometry
	    geometry_socket_30 = scalp_stylized_mesh.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_30.attribute_domain = 'POINT'
	
	    #Socket Geometry
	    geometry_socket_31 = scalp_stylized_mesh.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_31.attribute_domain = 'POINT'
	
	    #Socket Surface
	    surface_socket_9 = scalp_stylized_mesh.interface.new_socket(name = "Surface", in_out='INPUT', socket_type = 'NodeSocketObject')
	    surface_socket_9.attribute_domain = 'POINT'
	
	    #Socket Material
	    material_socket_6 = scalp_stylized_mesh.interface.new_socket(name = "Material", in_out='INPUT', socket_type = 'NodeSocketMaterial')
	    material_socket_6.attribute_domain = 'POINT'
	
	    #Socket Control Points
	    control_points_socket_3 = scalp_stylized_mesh.interface.new_socket(name = "Control Points", in_out='INPUT', socket_type = 'NodeSocketInt')
	    control_points_socket_3.default_value = 10
	    control_points_socket_3.min_value = 1
	    control_points_socket_3.max_value = 100000
	    control_points_socket_3.subtype = 'NONE'
	    control_points_socket_3.attribute_domain = 'POINT'
	
	    #Socket Subdivison Level
	    subdivison_level_socket = scalp_stylized_mesh.interface.new_socket(name = "Subdivison Level", in_out='INPUT', socket_type = 'NodeSocketInt')
	    subdivison_level_socket.default_value = 1
	    subdivison_level_socket.min_value = 0
	    subdivison_level_socket.max_value = 6
	    subdivison_level_socket.subtype = 'NONE'
	    subdivison_level_socket.attribute_domain = 'POINT'
	
	    #Socket Surface Offset
	    surface_offset_socket_2 = scalp_stylized_mesh.interface.new_socket(name = "Surface Offset", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    surface_offset_socket_2.default_value = 0.10000000149011612
	    surface_offset_socket_2.min_value = 0.0
	    surface_offset_socket_2.max_value = 10000.0
	    surface_offset_socket_2.subtype = 'NONE'
	    surface_offset_socket_2.attribute_domain = 'POINT'
	
	    #Socket Surface Offset Shape
	    surface_offset_shape_socket_1 = scalp_stylized_mesh.interface.new_socket(name = "Surface Offset Shape", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    surface_offset_shape_socket_1.default_value = 0.0
	    surface_offset_shape_socket_1.min_value = 0.0
	    surface_offset_shape_socket_1.max_value = 0.0
	    surface_offset_shape_socket_1.subtype = 'NONE'
	    surface_offset_shape_socket_1.attribute_domain = 'POINT'
	    surface_offset_shape_socket_1.hide_value = True
	    surface_offset_shape_socket_1.hide_in_modifier = True
	
	
	    #initialize scalp_stylized_mesh nodes
	    #node Group Input
	    group_input_17 = scalp_stylized_mesh.nodes.new("NodeGroupInput")
	    group_input_17.name = "Group Input"
	    group_input_17.outputs[1].hide = True
	    group_input_17.outputs[2].hide = True
	    group_input_17.outputs[3].hide = True
	    group_input_17.outputs[4].hide = True
	    group_input_17.outputs[5].hide = True
	    group_input_17.outputs[6].hide = True
	    group_input_17.outputs[7].hide = True
	
	    #node Group Output
	    group_output_22 = scalp_stylized_mesh.nodes.new("NodeGroupOutput")
	    group_output_22.name = "Group Output"
	    group_output_22.is_active_output = True
	
	    #node Named Attribute
	    named_attribute_5 = scalp_stylized_mesh.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute_5.name = "Named Attribute"
	    named_attribute_5.data_type = 'INT'
	    #Name
	    named_attribute_5.inputs[0].default_value = "closest_idx"
	
	    #node Compare
	    compare_10 = scalp_stylized_mesh.nodes.new("FunctionNodeCompare")
	    compare_10.name = "Compare"
	    compare_10.hide = True
	    compare_10.data_type = 'INT'
	    compare_10.mode = 'ELEMENT'
	    compare_10.operation = 'EQUAL'
	
	    #node Separate Geometry
	    separate_geometry_1 = scalp_stylized_mesh.nodes.new("GeometryNodeSeparateGeometry")
	    separate_geometry_1.name = "Separate Geometry"
	    separate_geometry_1.domain = 'CURVE'
	    separate_geometry_1.outputs[1].hide = True
	
	    #node Convex Hull
	    convex_hull_1 = scalp_stylized_mesh.nodes.new("GeometryNodeConvexHull")
	    convex_hull_1.name = "Convex Hull"
	
	    #node Object Info
	    object_info_4 = scalp_stylized_mesh.nodes.new("GeometryNodeObjectInfo")
	    object_info_4.name = "Object Info"
	    object_info_4.hide = True
	    object_info_4.transform_space = 'RELATIVE'
	    object_info_4.inputs[1].hide = True
	    object_info_4.outputs[0].hide = True
	    object_info_4.outputs[1].hide = True
	    object_info_4.outputs[2].hide = True
	    object_info_4.outputs[3].hide = True
	    #As Instance
	    object_info_4.inputs[1].default_value = False
	
	    #node Mesh Boolean
	    mesh_boolean_1 = scalp_stylized_mesh.nodes.new("GeometryNodeMeshBoolean")
	    mesh_boolean_1.name = "Mesh Boolean"
	    mesh_boolean_1.operation = 'UNION'
	    mesh_boolean_1.solver = 'EXACT'
	    mesh_boolean_1.inputs[2].hide = True
	    mesh_boolean_1.inputs[3].hide = True
	    #Self Intersection
	    mesh_boolean_1.inputs[2].default_value = False
	    #Hole Tolerant
	    mesh_boolean_1.inputs[3].default_value = False
	
	    #node Delete Geometry
	    delete_geometry_2 = scalp_stylized_mesh.nodes.new("GeometryNodeDeleteGeometry")
	    delete_geometry_2.name = "Delete Geometry"
	    delete_geometry_2.hide = True
	    delete_geometry_2.domain = 'EDGE'
	    delete_geometry_2.mode = 'ALL'
	
	    #node Boolean Math
	    boolean_math_5 = scalp_stylized_mesh.nodes.new("FunctionNodeBooleanMath")
	    boolean_math_5.name = "Boolean Math"
	    boolean_math_5.hide = True
	    boolean_math_5.operation = 'NOT'
	
	    #node Named Attribute.002
	    named_attribute_002_2 = scalp_stylized_mesh.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute_002_2.name = "Named Attribute.002"
	    named_attribute_002_2.data_type = 'FLOAT_VECTOR'
	    #Name
	    named_attribute_002_2.inputs[0].default_value = "closetst_pt"
	
	    #node Attribute Statistic
	    attribute_statistic_2 = scalp_stylized_mesh.nodes.new("GeometryNodeAttributeStatistic")
	    attribute_statistic_2.name = "Attribute Statistic"
	    attribute_statistic_2.hide = True
	    attribute_statistic_2.data_type = 'FLOAT_VECTOR'
	    attribute_statistic_2.domain = 'CURVE'
	    attribute_statistic_2.inputs[1].hide = True
	    attribute_statistic_2.outputs[1].hide = True
	    attribute_statistic_2.outputs[2].hide = True
	    attribute_statistic_2.outputs[3].hide = True
	    attribute_statistic_2.outputs[4].hide = True
	    attribute_statistic_2.outputs[5].hide = True
	    attribute_statistic_2.outputs[6].hide = True
	    attribute_statistic_2.outputs[7].hide = True
	    #Selection
	    attribute_statistic_2.inputs[1].default_value = True
	
	    #node Merge by Distance
	    merge_by_distance_1 = scalp_stylized_mesh.nodes.new("GeometryNodeMergeByDistance")
	    merge_by_distance_1.name = "Merge by Distance"
	    merge_by_distance_1.hide = True
	    merge_by_distance_1.mode = 'ALL'
	    merge_by_distance_1.inputs[1].hide = True
	    #Selection
	    merge_by_distance_1.inputs[1].default_value = True
	    #Distance
	    merge_by_distance_1.inputs[2].default_value = 0.0010000000474974513
	
	    #node Attribute Statistic.001
	    attribute_statistic_001_1 = scalp_stylized_mesh.nodes.new("GeometryNodeAttributeStatistic")
	    attribute_statistic_001_1.name = "Attribute Statistic.001"
	    attribute_statistic_001_1.hide = True
	    attribute_statistic_001_1.data_type = 'FLOAT'
	    attribute_statistic_001_1.domain = 'CURVE'
	    attribute_statistic_001_1.inputs[1].hide = True
	    attribute_statistic_001_1.outputs[0].hide = True
	    attribute_statistic_001_1.outputs[1].hide = True
	    attribute_statistic_001_1.outputs[2].hide = True
	    attribute_statistic_001_1.outputs[3].hide = True
	    attribute_statistic_001_1.outputs[5].hide = True
	    attribute_statistic_001_1.outputs[6].hide = True
	    attribute_statistic_001_1.outputs[7].hide = True
	    #Selection
	    attribute_statistic_001_1.inputs[1].default_value = True
	
	    #node Repeat Input
	    repeat_input_2 = scalp_stylized_mesh.nodes.new("GeometryNodeRepeatInput")
	    repeat_input_2.name = "Repeat Input"
	    #node Repeat Output
	    repeat_output_2 = scalp_stylized_mesh.nodes.new("GeometryNodeRepeatOutput")
	    repeat_output_2.name = "Repeat Output"
	    repeat_output_2.active_index = 1
	    repeat_output_2.inspection_index = 0
	    repeat_output_2.repeat_items.clear()
	    # Create item "Geometry"
	    repeat_output_2.repeat_items.new('GEOMETRY', "Geometry")
	    # Create item "Index"
	    repeat_output_2.repeat_items.new('INT', "Index")
	
	    #node Join Geometry.001
	    join_geometry_001_2 = scalp_stylized_mesh.nodes.new("GeometryNodeJoinGeometry")
	    join_geometry_001_2.name = "Join Geometry.001"
	    join_geometry_001_2.hide = True
	
	    #node Math
	    math_7 = scalp_stylized_mesh.nodes.new("ShaderNodeMath")
	    math_7.name = "Math"
	    math_7.hide = True
	    math_7.operation = 'ADD'
	    math_7.use_clamp = False
	    #Value_001
	    math_7.inputs[1].default_value = 1.0
	
	    #node Math.001
	    math_001_4 = scalp_stylized_mesh.nodes.new("ShaderNodeMath")
	    math_001_4.name = "Math.001"
	    math_001_4.hide = True
	    math_001_4.operation = 'ADD'
	    math_001_4.use_clamp = False
	    #Value_001
	    math_001_4.inputs[1].default_value = 1.0
	
	    #node Named Attribute.003
	    named_attribute_003_2 = scalp_stylized_mesh.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute_003_2.name = "Named Attribute.003"
	    named_attribute_003_2.data_type = 'INT'
	    #Name
	    named_attribute_003_2.inputs[0].default_value = "closest_idx"
	
	    #node Reroute.001
	    reroute_001_10 = scalp_stylized_mesh.nodes.new("NodeReroute")
	    reroute_001_10.name = "Reroute.001"
	    reroute_001_10.socket_idname = "NodeSocketGeometry"
	    #node Reroute.002
	    reroute_002_8 = scalp_stylized_mesh.nodes.new("NodeReroute")
	    reroute_002_8.name = "Reroute.002"
	    reroute_002_8.socket_idname = "NodeSocketGeometry"
	    #node Group Input.001
	    group_input_001_15 = scalp_stylized_mesh.nodes.new("NodeGroupInput")
	    group_input_001_15.name = "Group Input.001"
	    group_input_001_15.outputs[0].hide = True
	    group_input_001_15.outputs[2].hide = True
	    group_input_001_15.outputs[3].hide = True
	    group_input_001_15.outputs[4].hide = True
	    group_input_001_15.outputs[5].hide = True
	    group_input_001_15.outputs[6].hide = True
	    group_input_001_15.outputs[7].hide = True
	
	    #node Reroute.003
	    reroute_003_7 = scalp_stylized_mesh.nodes.new("NodeReroute")
	    reroute_003_7.name = "Reroute.003"
	    reroute_003_7.socket_idname = "NodeSocketGeometry"
	    #node Reroute.004
	    reroute_004_8 = scalp_stylized_mesh.nodes.new("NodeReroute")
	    reroute_004_8.name = "Reroute.004"
	    reroute_004_8.socket_idname = "NodeSocketGeometry"
	    #node Reroute.005
	    reroute_005_6 = scalp_stylized_mesh.nodes.new("NodeReroute")
	    reroute_005_6.name = "Reroute.005"
	    reroute_005_6.socket_idname = "NodeSocketGeometry"
	    #node Group Input.002
	    group_input_002_11 = scalp_stylized_mesh.nodes.new("NodeGroupInput")
	    group_input_002_11.name = "Group Input.002"
	    group_input_002_11.outputs[0].hide = True
	    group_input_002_11.outputs[1].hide = True
	    group_input_002_11.outputs[2].hide = True
	    group_input_002_11.outputs[3].hide = True
	    group_input_002_11.outputs[4].hide = True
	    group_input_002_11.outputs[5].hide = True
	    group_input_002_11.outputs[6].hide = True
	    group_input_002_11.outputs[7].hide = True
	
	    #node Capture Attribute.002
	    capture_attribute_002_6 = scalp_stylized_mesh.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_002_6.name = "Capture Attribute.002"
	    capture_attribute_002_6.active_index = 0
	    capture_attribute_002_6.capture_items.clear()
	    capture_attribute_002_6.capture_items.new('FLOAT', "Position")
	    capture_attribute_002_6.capture_items["Position"].data_type = 'FLOAT_VECTOR'
	    capture_attribute_002_6.domain = 'POINT'
	    capture_attribute_002_6.inputs[2].hide = True
	    capture_attribute_002_6.outputs[2].hide = True
	
	    #node Position
	    position_2 = scalp_stylized_mesh.nodes.new("GeometryNodeInputPosition")
	    position_2.name = "Position"
	
	    #node Set Position.002
	    set_position_002_3 = scalp_stylized_mesh.nodes.new("GeometryNodeSetPosition")
	    set_position_002_3.name = "Set Position.002"
	    set_position_002_3.inputs[1].hide = True
	    #Selection
	    set_position_002_3.inputs[1].default_value = True
	
	    #node Vector Math.002
	    vector_math_002_5 = scalp_stylized_mesh.nodes.new("ShaderNodeVectorMath")
	    vector_math_002_5.name = "Vector Math.002"
	    vector_math_002_5.hide = True
	    vector_math_002_5.operation = 'SCALE'
	
	    #node Map Range
	    map_range_3 = scalp_stylized_mesh.nodes.new("ShaderNodeMapRange")
	    map_range_3.name = "Map Range"
	    map_range_3.hide = True
	    map_range_3.clamp = False
	    map_range_3.data_type = 'FLOAT'
	    map_range_3.interpolation_type = 'LINEAR'
	    map_range_3.inputs[1].hide = True
	    map_range_3.inputs[2].hide = True
	    map_range_3.inputs[3].hide = True
	    map_range_3.inputs[5].hide = True
	    map_range_3.inputs[6].hide = True
	    map_range_3.inputs[7].hide = True
	    map_range_3.inputs[8].hide = True
	    map_range_3.inputs[9].hide = True
	    map_range_3.inputs[10].hide = True
	    map_range_3.inputs[11].hide = True
	    map_range_3.outputs[1].hide = True
	    #From Min
	    map_range_3.inputs[1].default_value = 0.0
	    #From Max
	    map_range_3.inputs[2].default_value = 1.0
	    #To Min
	    map_range_3.inputs[3].default_value = 0.0
	
	    #node Group Input.009
	    group_input_009_2 = scalp_stylized_mesh.nodes.new("NodeGroupInput")
	    group_input_009_2.name = "Group Input.009"
	    group_input_009_2.outputs[0].hide = True
	    group_input_009_2.outputs[1].hide = True
	    group_input_009_2.outputs[2].hide = True
	    group_input_009_2.outputs[3].hide = True
	    group_input_009_2.outputs[4].hide = True
	    group_input_009_2.outputs[7].hide = True
	
	    #node Domain Size
	    domain_size_2 = scalp_stylized_mesh.nodes.new("GeometryNodeAttributeDomainSize")
	    domain_size_2.name = "Domain Size"
	    domain_size_2.hide = True
	    domain_size_2.component = 'MESH'
	    domain_size_2.outputs[0].hide = True
	    domain_size_2.outputs[2].hide = True
	    domain_size_2.outputs[3].hide = True
	    domain_size_2.outputs[4].hide = True
	    domain_size_2.outputs[5].hide = True
	    domain_size_2.outputs[6].hide = True
	
	    #node Group.002
	    group_002_5 = scalp_stylized_mesh.nodes.new("GeometryNodeGroup")
	    group_002_5.name = "Group.002"
	    group_002_5.node_tree = shape_fill
	
	    #node Repeat Input.001
	    repeat_input_001 = scalp_stylized_mesh.nodes.new("GeometryNodeRepeatInput")
	    repeat_input_001.name = "Repeat Input.001"
	    #node Repeat Output.001
	    repeat_output_001 = scalp_stylized_mesh.nodes.new("GeometryNodeRepeatOutput")
	    repeat_output_001.name = "Repeat Output.001"
	    repeat_output_001.active_index = 1
	    repeat_output_001.inspection_index = 0
	    repeat_output_001.repeat_items.clear()
	    # Create item "Geometry"
	    repeat_output_001.repeat_items.new('GEOMETRY', "Geometry")
	    # Create item "Index"
	    repeat_output_001.repeat_items.new('INT', "Index")
	
	    #node Join Geometry.002
	    join_geometry_002 = scalp_stylized_mesh.nodes.new("GeometryNodeJoinGeometry")
	    join_geometry_002.name = "Join Geometry.002"
	    join_geometry_002.hide = True
	
	    #node Math.002
	    math_002_3 = scalp_stylized_mesh.nodes.new("ShaderNodeMath")
	    math_002_3.name = "Math.002"
	    math_002_3.hide = True
	    math_002_3.operation = 'ADD'
	    math_002_3.use_clamp = False
	    #Value_001
	    math_002_3.inputs[1].default_value = 1.0
	
	    #node Reroute
	    reroute_13 = scalp_stylized_mesh.nodes.new("NodeReroute")
	    reroute_13.name = "Reroute"
	    reroute_13.socket_idname = "NodeSocketGeometry"
	    #node Reroute.006
	    reroute_006_4 = scalp_stylized_mesh.nodes.new("NodeReroute")
	    reroute_006_4.name = "Reroute.006"
	    reroute_006_4.socket_idname = "NodeSocketGeometry"
	    #node Reroute.007
	    reroute_007_4 = scalp_stylized_mesh.nodes.new("NodeReroute")
	    reroute_007_4.name = "Reroute.007"
	    reroute_007_4.socket_idname = "NodeSocketInt"
	    #node Group Input.003
	    group_input_003_11 = scalp_stylized_mesh.nodes.new("NodeGroupInput")
	    group_input_003_11.name = "Group Input.003"
	    group_input_003_11.outputs[0].hide = True
	    group_input_003_11.outputs[1].hide = True
	    group_input_003_11.outputs[2].hide = True
	    group_input_003_11.outputs[4].hide = True
	    group_input_003_11.outputs[5].hide = True
	    group_input_003_11.outputs[6].hide = True
	    group_input_003_11.outputs[7].hide = True
	
	    #node Object Info.003
	    object_info_003 = scalp_stylized_mesh.nodes.new("GeometryNodeObjectInfo")
	    object_info_003.name = "Object Info.003"
	    object_info_003.hide = True
	    object_info_003.transform_space = 'RELATIVE'
	    object_info_003.inputs[1].hide = True
	    object_info_003.outputs[0].hide = True
	    object_info_003.outputs[1].hide = True
	    object_info_003.outputs[2].hide = True
	    object_info_003.outputs[3].hide = True
	    #As Instance
	    object_info_003.inputs[1].default_value = False
	
	    #node Group Input.006
	    group_input_006_7 = scalp_stylized_mesh.nodes.new("NodeGroupInput")
	    group_input_006_7.name = "Group Input.006"
	    group_input_006_7.outputs[0].hide = True
	    group_input_006_7.outputs[2].hide = True
	    group_input_006_7.outputs[3].hide = True
	    group_input_006_7.outputs[4].hide = True
	    group_input_006_7.outputs[5].hide = True
	    group_input_006_7.outputs[6].hide = True
	    group_input_006_7.outputs[7].hide = True
	
	    #node Group.001
	    group_001_6 = scalp_stylized_mesh.nodes.new("GeometryNodeGroup")
	    group_001_6.name = "Group.001"
	    group_001_6.node_tree = nearest_surface_data
	    group_001_6.outputs[1].hide = True
	    group_001_6.outputs[2].hide = True
	    group_001_6.outputs[3].hide = True
	    group_001_6.outputs[4].hide = True
	    group_001_6.outputs[5].hide = True
	
	    #node Set Material
	    set_material_5 = scalp_stylized_mesh.nodes.new("GeometryNodeSetMaterial")
	    set_material_5.name = "Set Material"
	    set_material_5.inputs[1].hide = True
	    #Selection
	    set_material_5.inputs[1].default_value = True
	
	    #node Group Input.008
	    group_input_008_4 = scalp_stylized_mesh.nodes.new("NodeGroupInput")
	    group_input_008_4.name = "Group Input.008"
	    group_input_008_4.outputs[0].hide = True
	    group_input_008_4.outputs[1].hide = True
	    group_input_008_4.outputs[3].hide = True
	    group_input_008_4.outputs[4].hide = True
	    group_input_008_4.outputs[5].hide = True
	    group_input_008_4.outputs[6].hide = True
	    group_input_008_4.outputs[7].hide = True
	
	    #node Subdivision Surface
	    subdivision_surface_1 = scalp_stylized_mesh.nodes.new("GeometryNodeSubdivisionSurface")
	    subdivision_surface_1.name = "Subdivision Surface"
	    subdivision_surface_1.boundary_smooth = 'ALL'
	    subdivision_surface_1.uv_smooth = 'PRESERVE_BOUNDARIES'
	    subdivision_surface_1.inputs[2].hide = True
	    subdivision_surface_1.inputs[3].hide = True
	    subdivision_surface_1.inputs[4].hide = True
	    #Edge Crease
	    subdivision_surface_1.inputs[2].default_value = 0.0
	    #Vertex Crease
	    subdivision_surface_1.inputs[3].default_value = 0.0
	    #Limit Surface
	    subdivision_surface_1.inputs[4].default_value = True
	
	    #node Group Input.010
	    group_input_010_3 = scalp_stylized_mesh.nodes.new("NodeGroupInput")
	    group_input_010_3.name = "Group Input.010"
	    group_input_010_3.outputs[0].hide = True
	    group_input_010_3.outputs[1].hide = True
	    group_input_010_3.outputs[2].hide = True
	    group_input_010_3.outputs[3].hide = True
	    group_input_010_3.outputs[5].hide = True
	    group_input_010_3.outputs[6].hide = True
	    group_input_010_3.outputs[7].hide = True
	
	    #node Set Position.003
	    set_position_003_2 = scalp_stylized_mesh.nodes.new("GeometryNodeSetPosition")
	    set_position_003_2.name = "Set Position.003"
	    set_position_003_2.inputs[1].hide = True
	    set_position_003_2.inputs[2].hide = True
	    #Selection
	    set_position_003_2.inputs[1].default_value = True
	    #Position
	    set_position_003_2.inputs[2].default_value = (0.0, 0.0, 0.0)
	
	
	    #Process zone input Repeat Input
	    repeat_input_2.pair_with_output(repeat_output_2)
	    #Item_2
	    repeat_input_2.inputs[2].default_value = 0
	
	
	    #Process zone input Repeat Input.001
	    repeat_input_001.pair_with_output(repeat_output_001)
	    #Item_2
	    repeat_input_001.inputs[2].default_value = 0
	
	
	
	
	
	    #Set locations
	    group_input_17.location = (-340.0, 0.0)
	    group_output_22.location = (3886.58349609375, 71.8291244506836)
	    named_attribute_5.location = (237.794921875, -204.86949157714844)
	    compare_10.location = (237.99490356445312, -171.7650146484375)
	    separate_geometry_1.location = (434.56829833984375, -287.77130126953125)
	    convex_hull_1.location = (646.521240234375, -263.57049560546875)
	    object_info_4.location = (831.0836791992188, -326.6778259277344)
	    mesh_boolean_1.location = (829.2451171875, -171.54408264160156)
	    delete_geometry_2.location = (1030.076171875, -203.94602966308594)
	    boolean_math_5.location = (1030.5745849609375, -239.54898071289062)
	    named_attribute_002_2.location = (1215.771484375, -289.0494384765625)
	    attribute_statistic_2.location = (1217.2470703125, -437.1791687011719)
	    merge_by_distance_1.location = (1209.949951171875, -212.1048583984375)
	    attribute_statistic_001_1.location = (-71.79378509521484, -31.660974502563477)
	    repeat_input_2.location = (99.01121520996094, -41.19667053222656)
	    repeat_output_2.location = (2492.572509765625, -48.5927619934082)
	    join_geometry_001_2.location = (2312.93310546875, -71.7889404296875)
	    math_7.location = (2333.051025390625, -110.43626403808594)
	    math_001_4.location = (-73.19247436523438, -64.9359130859375)
	    named_attribute_003_2.location = (-73.26921081542969, 117.17273712158203)
	    reroute_001_10.location = (-154.91433715820312, -33.560951232910156)
	    reroute_002_8.location = (-149.08628845214844, -369.71771240234375)
	    group_input_001_15.location = (828.1835327148438, -358.9533996582031)
	    reroute_003_7.location = (608.2127075195312, -322.5533447265625)
	    reroute_004_8.location = (613.1801147460938, -508.4476623535156)
	    reroute_005_6.location = (1219.9703369140625, -503.0494384765625)
	    group_input_002_11.location = (1211.0172119140625, -132.74459838867188)
	    capture_attribute_002_6.location = (2860.900146484375, -21.246612548828125)
	    position_2.location = (2862.9609375, 53.94630432128906)
	    set_position_002_3.location = (3059.556396484375, -22.87578773498535)
	    vector_math_002_5.location = (3059.706787109375, -150.4325408935547)
	    map_range_3.location = (3059.780517578125, -186.5848846435547)
	    group_input_009_2.location = (3057.319091796875, -218.39364624023438)
	    domain_size_2.location = (1426.6778564453125, -211.9302520751953)
	    group_002_5.location = (1853.4088134765625, -326.876220703125)
	    repeat_input_001.location = (1605.2392578125, -186.91415405273438)
	    repeat_output_001.location = (2169.86962890625, -201.7063446044922)
	    join_geometry_002.location = (1990.2298583984375, -224.9025421142578)
	    math_002_3.location = (2010.3480224609375, -263.5498352050781)
	    reroute_13.location = (1387.522216796875, -222.22802734375)
	    reroute_006_4.location = (1391.2220458984375, -406.2130432128906)
	    reroute_007_4.location = (1751.8936767578125, -471.0537414550781)
	    group_input_003_11.location = (1444.3856201171875, -394.56329345703125)
	    object_info_003.location = (2859.529296875, -288.309814453125)
	    group_input_006_7.location = (2857.45849609375, -320.235595703125)
	    group_001_6.location = (2856.904052734375, -141.48858642578125)
	    set_material_5.location = (3420.342041015625, 0.7178115844726562)
	    group_input_008_4.location = (3417.281005859375, -101.73077392578125)
	    subdivision_surface_1.location = (3606.68505859375, 73.78602600097656)
	    group_input_010_3.location = (3611.27685546875, -81.86913299560547)
	    set_position_003_2.location = (3240.0, -22.87578773498535)
	
	    #Set dimensions
	    group_input_17.width, group_input_17.height = 140.0, 100.0
	    group_output_22.width, group_output_22.height = 140.0, 100.0
	    named_attribute_5.width, named_attribute_5.height = 140.0, 100.0
	    compare_10.width, compare_10.height = 140.0, 100.0
	    separate_geometry_1.width, separate_geometry_1.height = 140.0, 100.0
	    convex_hull_1.width, convex_hull_1.height = 140.0, 100.0
	    object_info_4.width, object_info_4.height = 140.0, 100.0
	    mesh_boolean_1.width, mesh_boolean_1.height = 140.0, 100.0
	    delete_geometry_2.width, delete_geometry_2.height = 140.0, 100.0
	    boolean_math_5.width, boolean_math_5.height = 140.0, 100.0
	    named_attribute_002_2.width, named_attribute_002_2.height = 140.0, 100.0
	    attribute_statistic_2.width, attribute_statistic_2.height = 140.0, 100.0
	    merge_by_distance_1.width, merge_by_distance_1.height = 140.0, 100.0
	    attribute_statistic_001_1.width, attribute_statistic_001_1.height = 140.0, 100.0
	    repeat_input_2.width, repeat_input_2.height = 140.0, 100.0
	    repeat_output_2.width, repeat_output_2.height = 140.0, 100.0
	    join_geometry_001_2.width, join_geometry_001_2.height = 140.0, 100.0
	    math_7.width, math_7.height = 140.0, 100.0
	    math_001_4.width, math_001_4.height = 140.0, 100.0
	    named_attribute_003_2.width, named_attribute_003_2.height = 140.0, 100.0
	    reroute_001_10.width, reroute_001_10.height = 100.0, 100.0
	    reroute_002_8.width, reroute_002_8.height = 100.0, 100.0
	    group_input_001_15.width, group_input_001_15.height = 140.0, 100.0
	    reroute_003_7.width, reroute_003_7.height = 100.0, 100.0
	    reroute_004_8.width, reroute_004_8.height = 100.0, 100.0
	    reroute_005_6.width, reroute_005_6.height = 100.0, 100.0
	    group_input_002_11.width, group_input_002_11.height = 140.0, 100.0
	    capture_attribute_002_6.width, capture_attribute_002_6.height = 140.0, 100.0
	    position_2.width, position_2.height = 140.0, 100.0
	    set_position_002_3.width, set_position_002_3.height = 140.0, 100.0
	    vector_math_002_5.width, vector_math_002_5.height = 140.0, 100.0
	    map_range_3.width, map_range_3.height = 140.0, 100.0
	    group_input_009_2.width, group_input_009_2.height = 140.0, 100.0
	    domain_size_2.width, domain_size_2.height = 140.0, 100.0
	    group_002_5.width, group_002_5.height = 140.0, 100.0
	    repeat_input_001.width, repeat_input_001.height = 140.0, 100.0
	    repeat_output_001.width, repeat_output_001.height = 140.0, 100.0
	    join_geometry_002.width, join_geometry_002.height = 140.0, 100.0
	    math_002_3.width, math_002_3.height = 140.0, 100.0
	    reroute_13.width, reroute_13.height = 100.0, 100.0
	    reroute_006_4.width, reroute_006_4.height = 100.0, 100.0
	    reroute_007_4.width, reroute_007_4.height = 100.0, 100.0
	    group_input_003_11.width, group_input_003_11.height = 140.0, 100.0
	    object_info_003.width, object_info_003.height = 140.0, 100.0
	    group_input_006_7.width, group_input_006_7.height = 140.0, 100.0
	    group_001_6.width, group_001_6.height = 140.0, 100.0
	    set_material_5.width, set_material_5.height = 140.0, 100.0
	    group_input_008_4.width, group_input_008_4.height = 140.0, 100.0
	    subdivision_surface_1.width, subdivision_surface_1.height = 150.0, 100.0
	    group_input_010_3.width, group_input_010_3.height = 140.0, 100.0
	    set_position_003_2.width, set_position_003_2.height = 140.0, 100.0
	
	    #initialize scalp_stylized_mesh links
	    #named_attribute_5.Attribute -> compare_10.A
	    scalp_stylized_mesh.links.new(named_attribute_5.outputs[0], compare_10.inputs[2])
	    #reroute_002_8.Output -> separate_geometry_1.Geometry
	    scalp_stylized_mesh.links.new(reroute_002_8.outputs[0], separate_geometry_1.inputs[0])
	    #compare_10.Result -> separate_geometry_1.Selection
	    scalp_stylized_mesh.links.new(compare_10.outputs[0], separate_geometry_1.inputs[1])
	    #reroute_003_7.Output -> convex_hull_1.Geometry
	    scalp_stylized_mesh.links.new(reroute_003_7.outputs[0], convex_hull_1.inputs[0])
	    #convex_hull_1.Convex Hull -> mesh_boolean_1.Mesh 1
	    scalp_stylized_mesh.links.new(convex_hull_1.outputs[0], mesh_boolean_1.inputs[0])
	    #object_info_4.Geometry -> mesh_boolean_1.Mesh
	    scalp_stylized_mesh.links.new(object_info_4.outputs[4], mesh_boolean_1.inputs[1])
	    #mesh_boolean_1.Intersecting Edges -> boolean_math_5.Boolean
	    scalp_stylized_mesh.links.new(mesh_boolean_1.outputs[1], boolean_math_5.inputs[0])
	    #mesh_boolean_1.Mesh -> delete_geometry_2.Geometry
	    scalp_stylized_mesh.links.new(mesh_boolean_1.outputs[0], delete_geometry_2.inputs[0])
	    #boolean_math_5.Boolean -> delete_geometry_2.Selection
	    scalp_stylized_mesh.links.new(boolean_math_5.outputs[0], delete_geometry_2.inputs[1])
	    #named_attribute_002_2.Attribute -> attribute_statistic_2.Attribute
	    scalp_stylized_mesh.links.new(named_attribute_002_2.outputs[0], attribute_statistic_2.inputs[2])
	    #join_geometry_001_2.Geometry -> repeat_output_2.Geometry
	    scalp_stylized_mesh.links.new(join_geometry_001_2.outputs[0], repeat_output_2.inputs[0])
	    #math_7.Value -> repeat_output_2.Index
	    scalp_stylized_mesh.links.new(math_7.outputs[0], repeat_output_2.inputs[1])
	    #repeat_input_2.Index -> math_7.Value
	    scalp_stylized_mesh.links.new(repeat_input_2.outputs[2], math_7.inputs[0])
	    #reroute_001_10.Output -> attribute_statistic_001_1.Geometry
	    scalp_stylized_mesh.links.new(reroute_001_10.outputs[0], attribute_statistic_001_1.inputs[0])
	    #math_001_4.Value -> repeat_input_2.Iterations
	    scalp_stylized_mesh.links.new(math_001_4.outputs[0], repeat_input_2.inputs[0])
	    #attribute_statistic_001_1.Max -> math_001_4.Value
	    scalp_stylized_mesh.links.new(attribute_statistic_001_1.outputs[4], math_001_4.inputs[0])
	    #named_attribute_003_2.Attribute -> attribute_statistic_001_1.Attribute
	    scalp_stylized_mesh.links.new(named_attribute_003_2.outputs[0], attribute_statistic_001_1.inputs[2])
	    #repeat_input_2.Index -> compare_10.B
	    scalp_stylized_mesh.links.new(repeat_input_2.outputs[2], compare_10.inputs[3])
	    #group_input_17.Geometry -> reroute_001_10.Input
	    scalp_stylized_mesh.links.new(group_input_17.outputs[0], reroute_001_10.inputs[0])
	    #reroute_001_10.Output -> reroute_002_8.Input
	    scalp_stylized_mesh.links.new(reroute_001_10.outputs[0], reroute_002_8.inputs[0])
	    #group_input_001_15.Surface -> object_info_4.Object
	    scalp_stylized_mesh.links.new(group_input_001_15.outputs[1], object_info_4.inputs[0])
	    #separate_geometry_1.Selection -> reroute_003_7.Input
	    scalp_stylized_mesh.links.new(separate_geometry_1.outputs[0], reroute_003_7.inputs[0])
	    #reroute_003_7.Output -> reroute_004_8.Input
	    scalp_stylized_mesh.links.new(reroute_003_7.outputs[0], reroute_004_8.inputs[0])
	    #reroute_004_8.Output -> reroute_005_6.Input
	    scalp_stylized_mesh.links.new(reroute_004_8.outputs[0], reroute_005_6.inputs[0])
	    #reroute_005_6.Output -> attribute_statistic_2.Geometry
	    scalp_stylized_mesh.links.new(reroute_005_6.outputs[0], attribute_statistic_2.inputs[0])
	    #repeat_output_2.Geometry -> capture_attribute_002_6.Geometry
	    scalp_stylized_mesh.links.new(repeat_output_2.outputs[0], capture_attribute_002_6.inputs[0])
	    #position_2.Position -> capture_attribute_002_6.Position
	    scalp_stylized_mesh.links.new(position_2.outputs[0], capture_attribute_002_6.inputs[1])
	    #capture_attribute_002_6.Geometry -> set_position_002_3.Geometry
	    scalp_stylized_mesh.links.new(capture_attribute_002_6.outputs[0], set_position_002_3.inputs[0])
	    #vector_math_002_5.Vector -> set_position_002_3.Offset
	    scalp_stylized_mesh.links.new(vector_math_002_5.outputs[0], set_position_002_3.inputs[3])
	    #map_range_3.Result -> vector_math_002_5.Scale
	    scalp_stylized_mesh.links.new(map_range_3.outputs[0], vector_math_002_5.inputs[3])
	    #delete_geometry_2.Geometry -> merge_by_distance_1.Geometry
	    scalp_stylized_mesh.links.new(delete_geometry_2.outputs[0], merge_by_distance_1.inputs[0])
	    #subdivision_surface_1.Mesh -> group_output_22.Geometry
	    scalp_stylized_mesh.links.new(subdivision_surface_1.outputs[0], group_output_22.inputs[0])
	    #attribute_statistic_2.Mean -> group_002_5.Closest_Pt
	    scalp_stylized_mesh.links.new(attribute_statistic_2.outputs[0], group_002_5.inputs[2])
	    #join_geometry_002.Geometry -> repeat_output_001.Geometry
	    scalp_stylized_mesh.links.new(join_geometry_002.outputs[0], repeat_output_001.inputs[0])
	    #math_002_3.Value -> repeat_output_001.Index
	    scalp_stylized_mesh.links.new(math_002_3.outputs[0], repeat_output_001.inputs[1])
	    #repeat_input_001.Index -> math_002_3.Value
	    scalp_stylized_mesh.links.new(repeat_input_001.outputs[2], math_002_3.inputs[0])
	    #repeat_input_001.Geometry -> join_geometry_002.Geometry
	    scalp_stylized_mesh.links.new(repeat_input_001.outputs[1], join_geometry_002.inputs[0])
	    #reroute_13.Output -> domain_size_2.Geometry
	    scalp_stylized_mesh.links.new(reroute_13.outputs[0], domain_size_2.inputs[0])
	    #domain_size_2.Edge Count -> repeat_input_001.Iterations
	    scalp_stylized_mesh.links.new(domain_size_2.outputs[1], repeat_input_001.inputs[0])
	    #reroute_006_4.Output -> group_002_5.Target
	    scalp_stylized_mesh.links.new(reroute_006_4.outputs[0], group_002_5.inputs[0])
	    #reroute_007_4.Output -> group_002_5.Index
	    scalp_stylized_mesh.links.new(reroute_007_4.outputs[0], group_002_5.inputs[3])
	    #repeat_output_001.Geometry -> join_geometry_001_2.Geometry
	    scalp_stylized_mesh.links.new(repeat_output_001.outputs[0], join_geometry_001_2.inputs[0])
	    #merge_by_distance_1.Geometry -> reroute_13.Input
	    scalp_stylized_mesh.links.new(merge_by_distance_1.outputs[0], reroute_13.inputs[0])
	    #reroute_13.Output -> reroute_006_4.Input
	    scalp_stylized_mesh.links.new(reroute_13.outputs[0], reroute_006_4.inputs[0])
	    #repeat_input_001.Index -> reroute_007_4.Input
	    scalp_stylized_mesh.links.new(repeat_input_001.outputs[2], reroute_007_4.inputs[0])
	    #group_input_003_11.Control Points -> group_002_5.Count
	    scalp_stylized_mesh.links.new(group_input_003_11.outputs[3], group_002_5.inputs[1])
	    #group_input_006_7.Surface -> object_info_003.Object
	    scalp_stylized_mesh.links.new(group_input_006_7.outputs[1], object_info_003.inputs[0])
	    #object_info_003.Geometry -> group_001_6.Geometry
	    scalp_stylized_mesh.links.new(object_info_003.outputs[4], group_001_6.inputs[0])
	    #group_001_6.Face Normal -> vector_math_002_5.Vector
	    scalp_stylized_mesh.links.new(group_001_6.outputs[6], vector_math_002_5.inputs[0])
	    #capture_attribute_002_6.Position -> group_001_6.Sample Position
	    scalp_stylized_mesh.links.new(capture_attribute_002_6.outputs[1], group_001_6.inputs[1])
	    #set_position_003_2.Geometry -> set_material_5.Geometry
	    scalp_stylized_mesh.links.new(set_position_003_2.outputs[0], set_material_5.inputs[0])
	    #group_input_008_4.Material -> set_material_5.Material
	    scalp_stylized_mesh.links.new(group_input_008_4.outputs[2], set_material_5.inputs[2])
	    #set_material_5.Geometry -> subdivision_surface_1.Mesh
	    scalp_stylized_mesh.links.new(set_material_5.outputs[0], subdivision_surface_1.inputs[0])
	    #group_input_010_3.Subdivison Level -> subdivision_surface_1.Level
	    scalp_stylized_mesh.links.new(group_input_010_3.outputs[4], subdivision_surface_1.inputs[1])
	    #group_001_6.Position -> set_position_002_3.Position
	    scalp_stylized_mesh.links.new(group_001_6.outputs[0], set_position_002_3.inputs[2])
	    #group_input_009_2.Surface Offset Shape -> map_range_3.Value
	    scalp_stylized_mesh.links.new(group_input_009_2.outputs[6], map_range_3.inputs[0])
	    #group_input_009_2.Surface Offset -> map_range_3.To Max
	    scalp_stylized_mesh.links.new(group_input_009_2.outputs[5], map_range_3.inputs[4])
	    #set_position_002_3.Geometry -> set_position_003_2.Geometry
	    scalp_stylized_mesh.links.new(set_position_002_3.outputs[0], set_position_003_2.inputs[0])
	    #vector_math_002_5.Vector -> set_position_003_2.Offset
	    scalp_stylized_mesh.links.new(vector_math_002_5.outputs[0], set_position_003_2.inputs[3])
	    #convex_hull_1.Convex Hull -> mesh_boolean_1.Mesh
	    scalp_stylized_mesh.links.new(convex_hull_1.outputs[0], mesh_boolean_1.inputs[1])
	    #repeat_input_2.Geometry -> join_geometry_001_2.Geometry
	    scalp_stylized_mesh.links.new(repeat_input_2.outputs[1], join_geometry_001_2.inputs[0])
	    #group_002_5.Geometry -> join_geometry_002.Geometry
	    scalp_stylized_mesh.links.new(group_002_5.outputs[0], join_geometry_002.inputs[0])
	    return scalp_stylized_mesh
	
	scalp_stylized_mesh = scalp_stylized_mesh_node_group()
	
	#initialize scalp_hairz node group
	def scalp_hairz_node_group():
	    scalp_hairz = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "SCALP_HAIRZ")
	
	    scalp_hairz.color_tag = 'NONE'
	    scalp_hairz.description = "Pull hair towards points of interest, such as, braids, buns, ponytails, etc..."
	    scalp_hairz.default_group_node_width = 140
	    
	
	    scalp_hairz.is_modifier = True
	
	    #scalp_hairz interface
	    #Socket Geometry
	    geometry_socket_32 = scalp_hairz.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_32.attribute_domain = 'POINT'
	
	    #Socket Geometry
	    geometry_socket_33 = scalp_hairz.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_33.attribute_domain = 'POINT'
	    geometry_socket_33.description = "Surface Hairs"
	
	    #Socket Surface
	    surface_socket_10 = scalp_hairz.interface.new_socket(name = "Surface", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    surface_socket_10.attribute_domain = 'POINT'
	    surface_socket_10.description = "Surface mesh for hair."
	
	    #Socket Surface
	    surface_socket_11 = scalp_hairz.interface.new_socket(name = "Surface", in_out='INPUT', socket_type = 'NodeSocketObject')
	    surface_socket_11.attribute_domain = 'POINT'
	    surface_socket_11.description = "Surface mesh for hair."
	
	    #Socket Guide Curve
	    guide_curve_socket_4 = scalp_hairz.interface.new_socket(name = "Guide Curve", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    guide_curve_socket_4.attribute_domain = 'POINT'
	    guide_curve_socket_4.description = "Curve to sample points of interest."
	
	    #Socket Guide Curve
	    guide_curve_socket_5 = scalp_hairz.interface.new_socket(name = "Guide Curve", in_out='INPUT', socket_type = 'NodeSocketObject')
	    guide_curve_socket_5.attribute_domain = 'POINT'
	    guide_curve_socket_5.description = "Curve to sample points of interest."
	
	    #Socket Hair Style
	    hair_style_socket = scalp_hairz.interface.new_socket(name = "Hair Style", in_out='INPUT', socket_type = 'NodeSocketMenu')
	    hair_style_socket.attribute_domain = 'POINT'
	    hair_style_socket.description = "Select hair curve or mesh style for hair."
	
	    #Socket Control Points
	    control_points_socket_4 = scalp_hairz.interface.new_socket(name = "Control Points", in_out='INPUT', socket_type = 'NodeSocketInt')
	    control_points_socket_4.default_value = 10
	    control_points_socket_4.min_value = 3
	    control_points_socket_4.max_value = 100000
	    control_points_socket_4.subtype = 'NONE'
	    control_points_socket_4.attribute_domain = 'POINT'
	    control_points_socket_4.description = "Amount of points per curve."
	
	    #Socket Hair Radius
	    hair_radius_socket_1 = scalp_hairz.interface.new_socket(name = "Hair Radius", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    hair_radius_socket_1.default_value = 0.003000000026077032
	    hair_radius_socket_1.min_value = 0.0
	    hair_radius_socket_1.max_value = 10000.0
	    hair_radius_socket_1.subtype = 'NONE'
	    hair_radius_socket_1.attribute_domain = 'POINT'
	    hair_radius_socket_1.description = "Hair strand radius."
	
	    #Socket Hair Shape Offset
	    hair_shape_offset_socket_2 = scalp_hairz.interface.new_socket(name = "Hair Shape Offset", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    hair_shape_offset_socket_2.default_value = 0.009999999776482582
	    hair_shape_offset_socket_2.min_value = 0.0
	    hair_shape_offset_socket_2.max_value = 10000.0
	    hair_shape_offset_socket_2.subtype = 'NONE'
	    hair_shape_offset_socket_2.attribute_domain = 'POINT'
	    hair_shape_offset_socket_2.description = "Overall shape of hair strands."
	
	    #Socket Sample Surface Count
	    sample_surface_count_socket_2 = scalp_hairz.interface.new_socket(name = "Sample Surface Count", in_out='INPUT', socket_type = 'NodeSocketInt')
	    sample_surface_count_socket_2.default_value = 10
	    sample_surface_count_socket_2.min_value = 1
	    sample_surface_count_socket_2.max_value = 100000
	    sample_surface_count_socket_2.subtype = 'NONE'
	    sample_surface_count_socket_2.attribute_domain = 'POINT'
	    sample_surface_count_socket_2.description = "Amount of points of interest to sample from each curve."
	
	    #Socket Sample Surface Distance
	    sample_surface_distance_socket_2 = scalp_hairz.interface.new_socket(name = "Sample Surface Distance", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    sample_surface_distance_socket_2.default_value = 0.10000000149011612
	    sample_surface_distance_socket_2.min_value = 0.0
	    sample_surface_distance_socket_2.max_value = 10000.0
	    sample_surface_distance_socket_2.subtype = 'NONE'
	    sample_surface_distance_socket_2.attribute_domain = 'POINT'
	    sample_surface_distance_socket_2.description = "Treshold for distance from point of interest to surface to sample point."
	
	    #Socket Max Influence Distance
	    max_influence_distance_socket_2 = scalp_hairz.interface.new_socket(name = "Max Influence Distance", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    max_influence_distance_socket_2.default_value = 0.0
	    max_influence_distance_socket_2.min_value = 0.0
	    max_influence_distance_socket_2.max_value = 10000.0
	    max_influence_distance_socket_2.subtype = 'NONE'
	    max_influence_distance_socket_2.attribute_domain = 'POINT'
	    max_influence_distance_socket_2.description = "Max distance for point of interest to have influence on scalp hair."
	
	    #Socket Curve Material
	    curve_material_socket = scalp_hairz.interface.new_socket(name = "Curve Material", in_out='INPUT', socket_type = 'NodeSocketMaterial')
	    curve_material_socket.attribute_domain = 'POINT'
	    curve_material_socket.description = "Material for hair curve."
	
	    #Panel Children Settings
	    children_settings_panel = scalp_hairz.interface.new_panel("Children Settings", default_closed=True)
	    children_settings_panel.description = "Setting for duplicate hair parameters."
	    #Socket Duplicate Amount
	    duplicate_amount_socket_1 = scalp_hairz.interface.new_socket(name = "Duplicate Amount", in_out='INPUT', socket_type = 'NodeSocketInt', parent = children_settings_panel)
	    duplicate_amount_socket_1.default_value = 0
	    duplicate_amount_socket_1.min_value = 0
	    duplicate_amount_socket_1.max_value = 2147483647
	    duplicate_amount_socket_1.subtype = 'NONE'
	    duplicate_amount_socket_1.attribute_domain = 'POINT'
	    duplicate_amount_socket_1.description = "Amount of duplicate hairs."
	
	    #Socket Duplicate Viewport Amount
	    duplicate_viewport_amount_socket_1 = scalp_hairz.interface.new_socket(name = "Duplicate Viewport Amount", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = children_settings_panel)
	    duplicate_viewport_amount_socket_1.default_value = 1.0
	    duplicate_viewport_amount_socket_1.min_value = 0.0
	    duplicate_viewport_amount_socket_1.max_value = 1.0
	    duplicate_viewport_amount_socket_1.subtype = 'FACTOR'
	    duplicate_viewport_amount_socket_1.attribute_domain = 'POINT'
	    duplicate_viewport_amount_socket_1.description = "Percentage of duplicate hairs to display in viewport."
	
	    #Socket Duplicate Radius
	    duplicate_radius_socket_1 = scalp_hairz.interface.new_socket(name = "Duplicate Radius", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = children_settings_panel)
	    duplicate_radius_socket_1.default_value = 0.10000000149011612
	    duplicate_radius_socket_1.min_value = 0.0
	    duplicate_radius_socket_1.max_value = 3.4028234663852886e+38
	    duplicate_radius_socket_1.subtype = 'DISTANCE'
	    duplicate_radius_socket_1.attribute_domain = 'POINT'
	    duplicate_radius_socket_1.description = "Radius in which the duplicate hairs are placed around the guide."
	
	    #Socket Duplicate Distribution Shape
	    duplicate_distribution_shape_socket_1 = scalp_hairz.interface.new_socket(name = "Duplicate Distribution Shape", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = children_settings_panel)
	    duplicate_distribution_shape_socket_1.default_value = 0.0
	    duplicate_distribution_shape_socket_1.min_value = -10.0
	    duplicate_distribution_shape_socket_1.max_value = 10.0
	    duplicate_distribution_shape_socket_1.subtype = 'NONE'
	    duplicate_distribution_shape_socket_1.attribute_domain = 'POINT'
	    duplicate_distribution_shape_socket_1.description = "Shape of the distribution from the center to the edge of the duplicate radius."
	
	    #Socket Duplicate Tip Roundness
	    duplicate_tip_roundness_socket_1 = scalp_hairz.interface.new_socket(name = "Duplicate Tip Roundness", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = children_settings_panel)
	    duplicate_tip_roundness_socket_1.default_value = 0.0
	    duplicate_tip_roundness_socket_1.min_value = 0.0
	    duplicate_tip_roundness_socket_1.max_value = 1.0
	    duplicate_tip_roundness_socket_1.subtype = 'FACTOR'
	    duplicate_tip_roundness_socket_1.attribute_domain = 'POINT'
	    duplicate_tip_roundness_socket_1.description = "Offset of the curves to round the tip."
	
	    #Socket Duplicate Even Thickness
	    duplicate_even_thickness_socket_1 = scalp_hairz.interface.new_socket(name = "Duplicate Even Thickness", in_out='INPUT', socket_type = 'NodeSocketBool', parent = children_settings_panel)
	    duplicate_even_thickness_socket_1.default_value = False
	    duplicate_even_thickness_socket_1.attribute_domain = 'POINT'
	    duplicate_even_thickness_socket_1.description = "Keep an even thickness of the distribution of duplicates."
	
	    #Socket Duplicate Seed
	    duplicate_seed_socket_1 = scalp_hairz.interface.new_socket(name = "Duplicate Seed", in_out='INPUT', socket_type = 'NodeSocketInt', parent = children_settings_panel)
	    duplicate_seed_socket_1.default_value = 0
	    duplicate_seed_socket_1.min_value = -10000
	    duplicate_seed_socket_1.max_value = 10000
	    duplicate_seed_socket_1.subtype = 'NONE'
	    duplicate_seed_socket_1.attribute_domain = 'POINT'
	    duplicate_seed_socket_1.description = "Random seed for duplication."
	
	
	    #Panel Frizz Settings
	    frizz_settings_panel = scalp_hairz.interface.new_panel("Frizz Settings", default_closed=True)
	    frizz_settings_panel.description = "Settings for hair frizz parameters."
	    #Socket Frizz Factor
	    frizz_factor_socket_1 = scalp_hairz.interface.new_socket(name = "Frizz Factor", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = frizz_settings_panel)
	    frizz_factor_socket_1.default_value = 0.0
	    frizz_factor_socket_1.min_value = 0.0
	    frizz_factor_socket_1.max_value = 1.0
	    frizz_factor_socket_1.subtype = 'FACTOR'
	    frizz_factor_socket_1.attribute_domain = 'POINT'
	    frizz_factor_socket_1.description = "Factor to blend overall hair frizz."
	
	    #Socket Frizz Distance
	    frizz_distance_socket_1 = scalp_hairz.interface.new_socket(name = "Frizz Distance", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = frizz_settings_panel)
	    frizz_distance_socket_1.default_value = 0.009999999776482582
	    frizz_distance_socket_1.min_value = 0.0
	    frizz_distance_socket_1.max_value = 3.4028234663852886e+38
	    frizz_distance_socket_1.subtype = 'DISTANCE'
	    frizz_distance_socket_1.attribute_domain = 'POINT'
	    frizz_distance_socket_1.description = "Overall distance factor for the deformation."
	
	    #Socket Frizz Shape
	    frizz_shape_socket_1 = scalp_hairz.interface.new_socket(name = "Frizz Shape", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = frizz_settings_panel)
	    frizz_shape_socket_1.default_value = 0.5
	    frizz_shape_socket_1.min_value = -1.0
	    frizz_shape_socket_1.max_value = 1.0
	    frizz_shape_socket_1.subtype = 'NONE'
	    frizz_shape_socket_1.attribute_domain = 'POINT'
	    frizz_shape_socket_1.description = "Shape of the influence along curves. (0=constant, 0.5=linear)"
	
	    #Socket Frizz Seed
	    frizz_seed_socket_1 = scalp_hairz.interface.new_socket(name = "Frizz Seed", in_out='INPUT', socket_type = 'NodeSocketInt', parent = frizz_settings_panel)
	    frizz_seed_socket_1.default_value = 0
	    frizz_seed_socket_1.min_value = -10000
	    frizz_seed_socket_1.max_value = 10000
	    frizz_seed_socket_1.subtype = 'NONE'
	    frizz_seed_socket_1.attribute_domain = 'POINT'
	    frizz_seed_socket_1.description = "Random seed for hair frizz."
	
	
	    #Panel Noise Settings
	    noise_settings_panel = scalp_hairz.interface.new_panel("Noise Settings", default_closed=True)
	    noise_settings_panel.description = "Settings for hair noise parameter."
	    #Socket Noise Surface Offset
	    noise_surface_offset_socket_1 = scalp_hairz.interface.new_socket(name = "Noise Surface Offset", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = noise_settings_panel)
	    noise_surface_offset_socket_1.default_value = 0.0
	    noise_surface_offset_socket_1.min_value = 0.0
	    noise_surface_offset_socket_1.max_value = 1.0
	    noise_surface_offset_socket_1.subtype = 'FACTOR'
	    noise_surface_offset_socket_1.attribute_domain = 'POINT'
	    noise_surface_offset_socket_1.description = "Offset of noise from surface."
	
	    #Socket Noise Scale
	    noise_scale_socket_1 = scalp_hairz.interface.new_socket(name = "Noise Scale", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = noise_settings_panel)
	    noise_scale_socket_1.default_value = 5.0
	    noise_scale_socket_1.min_value = -1000.0
	    noise_scale_socket_1.max_value = 1000.0
	    noise_scale_socket_1.subtype = 'NONE'
	    noise_scale_socket_1.attribute_domain = 'POINT'
	    noise_scale_socket_1.description = "Scale of noise texture."
	
	    #Socket Noise Detail
	    noise_detail_socket_1 = scalp_hairz.interface.new_socket(name = "Noise Detail", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = noise_settings_panel)
	    noise_detail_socket_1.default_value = 1.0
	    noise_detail_socket_1.min_value = 0.0
	    noise_detail_socket_1.max_value = 15.0
	    noise_detail_socket_1.subtype = 'NONE'
	    noise_detail_socket_1.attribute_domain = 'POINT'
	    noise_detail_socket_1.description = "Detail of noise texture."
	
	    #Socket Noise Roughness
	    noise_roughness_socket_1 = scalp_hairz.interface.new_socket(name = "Noise Roughness", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = noise_settings_panel)
	    noise_roughness_socket_1.default_value = 0.5
	    noise_roughness_socket_1.min_value = 0.0
	    noise_roughness_socket_1.max_value = 1.0
	    noise_roughness_socket_1.subtype = 'FACTOR'
	    noise_roughness_socket_1.attribute_domain = 'POINT'
	    noise_roughness_socket_1.description = "Roughness for noise texture."
	
	    #Socket Noise Lacunarity
	    noise_lacunarity_socket_1 = scalp_hairz.interface.new_socket(name = "Noise Lacunarity", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = noise_settings_panel)
	    noise_lacunarity_socket_1.default_value = 2.0
	    noise_lacunarity_socket_1.min_value = 0.0
	    noise_lacunarity_socket_1.max_value = 1000.0
	    noise_lacunarity_socket_1.subtype = 'NONE'
	    noise_lacunarity_socket_1.attribute_domain = 'POINT'
	    noise_lacunarity_socket_1.description = "Noise texture Lacunarity."
	
	    #Socket Noise Distortion
	    noise_distortion_socket_1 = scalp_hairz.interface.new_socket(name = "Noise Distortion", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = noise_settings_panel)
	    noise_distortion_socket_1.default_value = 5.0
	    noise_distortion_socket_1.min_value = -1000.0
	    noise_distortion_socket_1.max_value = 1000.0
	    noise_distortion_socket_1.subtype = 'NONE'
	    noise_distortion_socket_1.attribute_domain = 'POINT'
	    noise_distortion_socket_1.description = "Noise texture distortion."
	
	
	    #Panel Mesh Settings
	    mesh_settings_panel = scalp_hairz.interface.new_panel("Mesh Settings", default_closed=True)
	    mesh_settings_panel.description = "Settings for mesh parameters."
	    #Socket Mesh Material
	    mesh_material_socket = scalp_hairz.interface.new_socket(name = "Mesh Material", in_out='INPUT', socket_type = 'NodeSocketMaterial', parent = mesh_settings_panel)
	    mesh_material_socket.attribute_domain = 'POINT'
	    mesh_material_socket.description = "Material for mesh hair."
	
	    #Socket Mesh Control Points
	    mesh_control_points_socket = scalp_hairz.interface.new_socket(name = "Mesh Control Points", in_out='INPUT', socket_type = 'NodeSocketInt', parent = mesh_settings_panel)
	    mesh_control_points_socket.default_value = 10
	    mesh_control_points_socket.min_value = 2
	    mesh_control_points_socket.max_value = 100000
	    mesh_control_points_socket.subtype = 'NONE'
	    mesh_control_points_socket.attribute_domain = 'POINT'
	    mesh_control_points_socket.description = "Amounnt of points to use for each mesh strip from root to tip."
	
	    #Socket Mesh Width
	    mesh_width_socket = scalp_hairz.interface.new_socket(name = "Mesh Width", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = mesh_settings_panel)
	    mesh_width_socket.default_value = 0.009999999776482582
	    mesh_width_socket.min_value = 0.0
	    mesh_width_socket.max_value = 3.4028234663852886e+38
	    mesh_width_socket.subtype = 'DISTANCE'
	    mesh_width_socket.attribute_domain = 'POINT'
	    mesh_width_socket.description = "Width of mesh hair strip. (Mesh Strip only)"
	
	    #Socket Mesh Guide Merge Distance
	    mesh_guide_merge_distance_socket = scalp_hairz.interface.new_socket(name = "Mesh Guide Merge Distance", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = mesh_settings_panel)
	    mesh_guide_merge_distance_socket.default_value = 0.0010000000474974513
	    mesh_guide_merge_distance_socket.min_value = 0.0
	    mesh_guide_merge_distance_socket.max_value = 3.4028234663852886e+38
	    mesh_guide_merge_distance_socket.subtype = 'DISTANCE'
	    mesh_guide_merge_distance_socket.attribute_domain = 'POINT'
	    mesh_guide_merge_distance_socket.description = "Distance at wich to merge hair guides into single mesh strips. (Mesh Strip only)"
	
	    #Socket Mesh Merge Distance
	    mesh_merge_distance_socket_1 = scalp_hairz.interface.new_socket(name = "Mesh Merge Distance", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = mesh_settings_panel)
	    mesh_merge_distance_socket_1.default_value = 0.0010000000474974513
	    mesh_merge_distance_socket_1.min_value = 0.0
	    mesh_merge_distance_socket_1.max_value = 0.10000000149011612
	    mesh_merge_distance_socket_1.subtype = 'DISTANCE'
	    mesh_merge_distance_socket_1.attribute_domain = 'POINT'
	    mesh_merge_distance_socket_1.description = "Distance at wich to merge vertices."
	
	    #Socket Mesh Subdivison Level
	    mesh_subdivison_level_socket = scalp_hairz.interface.new_socket(name = "Mesh Subdivison Level", in_out='INPUT', socket_type = 'NodeSocketInt', parent = mesh_settings_panel)
	    mesh_subdivison_level_socket.default_value = 1
	    mesh_subdivison_level_socket.min_value = 0
	    mesh_subdivison_level_socket.max_value = 6
	    mesh_subdivison_level_socket.subtype = 'NONE'
	    mesh_subdivison_level_socket.attribute_domain = 'POINT'
	    mesh_subdivison_level_socket.description = "Level used for mesh hair subdivision."
	
	    #Socket Mesh Surface Offset
	    mesh_surface_offset_socket = scalp_hairz.interface.new_socket(name = "Mesh Surface Offset", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = mesh_settings_panel)
	    mesh_surface_offset_socket.default_value = 0.019999999552965164
	    mesh_surface_offset_socket.min_value = 0.0
	    mesh_surface_offset_socket.max_value = 10000.0
	    mesh_surface_offset_socket.subtype = 'NONE'
	    mesh_surface_offset_socket.attribute_domain = 'POINT'
	    mesh_surface_offset_socket.description = "Offset distance for mesh hair from surface."
	
	    #Socket Mesh Noise Surface Offset
	    mesh_noise_surface_offset_socket = scalp_hairz.interface.new_socket(name = "Mesh Noise Surface Offset", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = mesh_settings_panel)
	    mesh_noise_surface_offset_socket.default_value = 0.0
	    mesh_noise_surface_offset_socket.min_value = 0.0
	    mesh_noise_surface_offset_socket.max_value = 1.0
	    mesh_noise_surface_offset_socket.subtype = 'FACTOR'
	    mesh_noise_surface_offset_socket.attribute_domain = 'POINT'
	    mesh_noise_surface_offset_socket.description = "Offset of noise from surface."
	
	    #Socket Mesh Noise Scale
	    mesh_noise_scale_socket = scalp_hairz.interface.new_socket(name = "Mesh Noise Scale", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = mesh_settings_panel)
	    mesh_noise_scale_socket.default_value = 5.0
	    mesh_noise_scale_socket.min_value = -1000.0
	    mesh_noise_scale_socket.max_value = 1000.0
	    mesh_noise_scale_socket.subtype = 'NONE'
	    mesh_noise_scale_socket.attribute_domain = 'POINT'
	    mesh_noise_scale_socket.description = "Scale of noise texture."
	
	    #Socket Mesh Noise Detail
	    mesh_noise_detail_socket = scalp_hairz.interface.new_socket(name = "Mesh Noise Detail", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = mesh_settings_panel)
	    mesh_noise_detail_socket.default_value = 1.0
	    mesh_noise_detail_socket.min_value = 0.0
	    mesh_noise_detail_socket.max_value = 15.0
	    mesh_noise_detail_socket.subtype = 'NONE'
	    mesh_noise_detail_socket.attribute_domain = 'POINT'
	    mesh_noise_detail_socket.description = "Detail of noise texture."
	
	    #Socket Mesh Noise Roughness
	    mesh_noise_roughness_socket = scalp_hairz.interface.new_socket(name = "Mesh Noise Roughness", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = mesh_settings_panel)
	    mesh_noise_roughness_socket.default_value = 0.5
	    mesh_noise_roughness_socket.min_value = 0.0
	    mesh_noise_roughness_socket.max_value = 1.0
	    mesh_noise_roughness_socket.subtype = 'FACTOR'
	    mesh_noise_roughness_socket.attribute_domain = 'POINT'
	    mesh_noise_roughness_socket.description = "Roughness for noise texture."
	
	    #Socket Mesh Noise Lacunarity
	    mesh_noise_lacunarity_socket = scalp_hairz.interface.new_socket(name = "Mesh Noise Lacunarity", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = mesh_settings_panel)
	    mesh_noise_lacunarity_socket.default_value = 2.0
	    mesh_noise_lacunarity_socket.min_value = 0.0
	    mesh_noise_lacunarity_socket.max_value = 1000.0
	    mesh_noise_lacunarity_socket.subtype = 'NONE'
	    mesh_noise_lacunarity_socket.attribute_domain = 'POINT'
	    mesh_noise_lacunarity_socket.description = "Noise texture Lacunarity."
	
	    #Socket Mesh Noise Distortion
	    mesh_noise_distortion_socket = scalp_hairz.interface.new_socket(name = "Mesh Noise Distortion", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = mesh_settings_panel)
	    mesh_noise_distortion_socket.default_value = 5.0
	    mesh_noise_distortion_socket.min_value = -1000.0
	    mesh_noise_distortion_socket.max_value = 1000.0
	    mesh_noise_distortion_socket.subtype = 'NONE'
	    mesh_noise_distortion_socket.attribute_domain = 'POINT'
	    mesh_noise_distortion_socket.description = "Noise texture distortion."
	
	
	
	    #initialize scalp_hairz nodes
	    #node Group Input
	    group_input_18 = scalp_hairz.nodes.new("NodeGroupInput")
	    group_input_18.name = "Group Input"
	    group_input_18.outputs[5].hide = True
	    group_input_18.outputs[30].hide = True
	    group_input_18.outputs[31].hide = True
	    group_input_18.outputs[32].hide = True
	    group_input_18.outputs[33].hide = True
	    group_input_18.outputs[34].hide = True
	    group_input_18.outputs[35].hide = True
	    group_input_18.outputs[36].hide = True
	    group_input_18.outputs[37].hide = True
	    group_input_18.outputs[38].hide = True
	    group_input_18.outputs[39].hide = True
	    group_input_18.outputs[40].hide = True
	    group_input_18.outputs[41].hide = True
	    group_input_18.outputs[42].hide = True
	    group_input_18.outputs[43].hide = True
	
	    #node Group Output
	    group_output_23 = scalp_hairz.nodes.new("NodeGroupOutput")
	    group_output_23.name = "Group Output"
	    group_output_23.is_active_output = True
	    group_output_23.inputs[1].hide = True
	
	    #node Group
	    group_8 = scalp_hairz.nodes.new("GeometryNodeGroup")
	    group_8.name = "Group"
	    group_8.node_tree = scalp_hair
	
	    #node Group.001
	    group_001_7 = scalp_hairz.nodes.new("GeometryNodeGroup")
	    group_001_7.name = "Group.001"
	    group_001_7.node_tree = scalp_mesh_hair
	
	    #node Hair Shape
	    hair_shape_2 = scalp_hairz.nodes.new("ShaderNodeFloatCurve")
	    hair_shape_2.label = "Hair Shape"
	    hair_shape_2.name = "Hair Shape"
	    #mapping settings
	    hair_shape_2.mapping.extend = 'EXTRAPOLATED'
	    hair_shape_2.mapping.tone = 'STANDARD'
	    hair_shape_2.mapping.black_level = (0.0, 0.0, 0.0)
	    hair_shape_2.mapping.white_level = (1.0, 1.0, 1.0)
	    hair_shape_2.mapping.clip_min_x = 0.0
	    hair_shape_2.mapping.clip_min_y = 0.0
	    hair_shape_2.mapping.clip_max_x = 1.0
	    hair_shape_2.mapping.clip_max_y = 1.0
	    hair_shape_2.mapping.use_clip = True
	    #curve 0
	    hair_shape_2_curve_0 = hair_shape_2.mapping.curves[0]
	    hair_shape_2_curve_0_point_0 = hair_shape_2_curve_0.points[0]
	    hair_shape_2_curve_0_point_0.location = (0.0, 0.25)
	    hair_shape_2_curve_0_point_0.handle_type = 'AUTO'
	    hair_shape_2_curve_0_point_1 = hair_shape_2_curve_0.points[1]
	    hair_shape_2_curve_0_point_1.location = (0.024922097101807594, 1.0)
	    hair_shape_2_curve_0_point_1.handle_type = 'AUTO'
	    hair_shape_2_curve_0_point_2 = hair_shape_2_curve_0.points.new(0.5, 1.0)
	    hair_shape_2_curve_0_point_2.handle_type = 'AUTO'
	    hair_shape_2_curve_0_point_3 = hair_shape_2_curve_0.points.new(1.0, 0.0)
	    hair_shape_2_curve_0_point_3.handle_type = 'AUTO'
	    #update curve after changes
	    hair_shape_2.mapping.update()
	    #Factor
	    hair_shape_2.inputs[0].default_value = 1.0
	
	    #node Spline Parameter.001
	    spline_parameter_001_2 = scalp_hairz.nodes.new("GeometryNodeSplineParameter")
	    spline_parameter_001_2.name = "Spline Parameter.001"
	    spline_parameter_001_2.hide = True
	    spline_parameter_001_2.outputs[1].hide = True
	    spline_parameter_001_2.outputs[2].hide = True
	
	    #node Frame
	    frame_8 = scalp_hairz.nodes.new("NodeFrame")
	    frame_8.label = "Hair Shape"
	    frame_8.name = "Frame"
	    frame_8.label_size = 20
	    frame_8.shrink = True
	
	    #node Hair to Surface Shape
	    hair_to_surface_shape_2 = scalp_hairz.nodes.new("ShaderNodeFloatCurve")
	    hair_to_surface_shape_2.label = "Hair to Surface Shape"
	    hair_to_surface_shape_2.name = "Hair to Surface Shape"
	    #mapping settings
	    hair_to_surface_shape_2.mapping.extend = 'EXTRAPOLATED'
	    hair_to_surface_shape_2.mapping.tone = 'STANDARD'
	    hair_to_surface_shape_2.mapping.black_level = (0.0, 0.0, 0.0)
	    hair_to_surface_shape_2.mapping.white_level = (1.0, 1.0, 1.0)
	    hair_to_surface_shape_2.mapping.clip_min_x = 0.0
	    hair_to_surface_shape_2.mapping.clip_min_y = 0.0
	    hair_to_surface_shape_2.mapping.clip_max_x = 1.0
	    hair_to_surface_shape_2.mapping.clip_max_y = 1.0
	    hair_to_surface_shape_2.mapping.use_clip = True
	    #curve 0
	    hair_to_surface_shape_2_curve_0 = hair_to_surface_shape_2.mapping.curves[0]
	    hair_to_surface_shape_2_curve_0_point_0 = hair_to_surface_shape_2_curve_0.points[0]
	    hair_to_surface_shape_2_curve_0_point_0.location = (0.0, 0.0)
	    hair_to_surface_shape_2_curve_0_point_0.handle_type = 'AUTO'
	    hair_to_surface_shape_2_curve_0_point_1 = hair_to_surface_shape_2_curve_0.points[1]
	    hair_to_surface_shape_2_curve_0_point_1.location = (0.5, 1.0)
	    hair_to_surface_shape_2_curve_0_point_1.handle_type = 'AUTO'
	    hair_to_surface_shape_2_curve_0_point_2 = hair_to_surface_shape_2_curve_0.points.new(1.0, 0.013157878071069717)
	    hair_to_surface_shape_2_curve_0_point_2.handle_type = 'AUTO'
	    #update curve after changes
	    hair_to_surface_shape_2.mapping.update()
	    hair_to_surface_shape_2.inputs[0].hide = True
	    #Factor
	    hair_to_surface_shape_2.inputs[0].default_value = 1.0
	
	    #node Spline Parameter
	    spline_parameter_6 = scalp_hairz.nodes.new("GeometryNodeSplineParameter")
	    spline_parameter_6.name = "Spline Parameter"
	    spline_parameter_6.hide = True
	    spline_parameter_6.outputs[1].hide = True
	    spline_parameter_6.outputs[2].hide = True
	
	    #node Frame.005
	    frame_005_4 = scalp_hairz.nodes.new("NodeFrame")
	    frame_005_4.label = "Hair to Surface Shape"
	    frame_005_4.name = "Frame.005"
	    frame_005_4.label_size = 20
	    frame_005_4.shrink = True
	
	    #node Group Input.002
	    group_input_002_12 = scalp_hairz.nodes.new("NodeGroupInput")
	    group_input_002_12.name = "Group Input.002"
	    group_input_002_12.outputs[0].hide = True
	    group_input_002_12.outputs[1].hide = True
	    group_input_002_12.outputs[3].hide = True
	    group_input_002_12.outputs[4].hide = True
	    group_input_002_12.outputs[5].hide = True
	    group_input_002_12.outputs[6].hide = True
	    group_input_002_12.outputs[7].hide = True
	    group_input_002_12.outputs[8].hide = True
	    group_input_002_12.outputs[9].hide = True
	    group_input_002_12.outputs[10].hide = True
	    group_input_002_12.outputs[11].hide = True
	    group_input_002_12.outputs[12].hide = True
	    group_input_002_12.outputs[13].hide = True
	    group_input_002_12.outputs[14].hide = True
	    group_input_002_12.outputs[15].hide = True
	    group_input_002_12.outputs[16].hide = True
	    group_input_002_12.outputs[17].hide = True
	    group_input_002_12.outputs[18].hide = True
	    group_input_002_12.outputs[19].hide = True
	    group_input_002_12.outputs[20].hide = True
	    group_input_002_12.outputs[21].hide = True
	    group_input_002_12.outputs[22].hide = True
	    group_input_002_12.outputs[23].hide = True
	    group_input_002_12.outputs[24].hide = True
	    group_input_002_12.outputs[25].hide = True
	    group_input_002_12.outputs[26].hide = True
	    group_input_002_12.outputs[27].hide = True
	    group_input_002_12.outputs[28].hide = True
	    group_input_002_12.outputs[29].hide = True
	    group_input_002_12.outputs[35].hide = True
	    group_input_002_12.outputs[37].hide = True
	    group_input_002_12.outputs[38].hide = True
	    group_input_002_12.outputs[39].hide = True
	    group_input_002_12.outputs[40].hide = True
	    group_input_002_12.outputs[41].hide = True
	    group_input_002_12.outputs[42].hide = True
	    group_input_002_12.outputs[43].hide = True
	
	    #node Mesh Shape
	    mesh_shape = scalp_hairz.nodes.new("ShaderNodeFloatCurve")
	    mesh_shape.label = "Mesh Shape"
	    mesh_shape.name = "Mesh Shape"
	    #mapping settings
	    mesh_shape.mapping.extend = 'EXTRAPOLATED'
	    mesh_shape.mapping.tone = 'STANDARD'
	    mesh_shape.mapping.black_level = (0.0, 0.0, 0.0)
	    mesh_shape.mapping.white_level = (1.0, 1.0, 1.0)
	    mesh_shape.mapping.clip_min_x = 0.0
	    mesh_shape.mapping.clip_min_y = 0.0
	    mesh_shape.mapping.clip_max_x = 1.0
	    mesh_shape.mapping.clip_max_y = 1.0
	    mesh_shape.mapping.use_clip = True
	    #curve 0
	    mesh_shape_curve_0 = mesh_shape.mapping.curves[0]
	    mesh_shape_curve_0_point_0 = mesh_shape_curve_0.points[0]
	    mesh_shape_curve_0_point_0.location = (0.0, 0.0)
	    mesh_shape_curve_0_point_0.handle_type = 'AUTO'
	    mesh_shape_curve_0_point_1 = mesh_shape_curve_0.points[1]
	    mesh_shape_curve_0_point_1.location = (0.16908212006092072, 0.8684210777282715)
	    mesh_shape_curve_0_point_1.handle_type = 'AUTO'
	    mesh_shape_curve_0_point_2 = mesh_shape_curve_0.points.new(1.0, 0.0)
	    mesh_shape_curve_0_point_2.handle_type = 'AUTO'
	    #update curve after changes
	    mesh_shape.mapping.update()
	    #Factor
	    mesh_shape.inputs[0].default_value = 1.0
	
	    #node Spline Parameter.002
	    spline_parameter_002 = scalp_hairz.nodes.new("GeometryNodeSplineParameter")
	    spline_parameter_002.name = "Spline Parameter.002"
	    spline_parameter_002.hide = True
	
	    #node Frame.001
	    frame_001_5 = scalp_hairz.nodes.new("NodeFrame")
	    frame_001_5.label = "Mesh Shape"
	    frame_001_5.name = "Frame.001"
	    frame_001_5.label_size = 20
	    frame_001_5.shrink = True
	
	    #node Mesh Surface Offset Shape
	    mesh_surface_offset_shape = scalp_hairz.nodes.new("ShaderNodeFloatCurve")
	    mesh_surface_offset_shape.label = "Mesh Surface Offset Shape"
	    mesh_surface_offset_shape.name = "Mesh Surface Offset Shape"
	    #mapping settings
	    mesh_surface_offset_shape.mapping.extend = 'EXTRAPOLATED'
	    mesh_surface_offset_shape.mapping.tone = 'STANDARD'
	    mesh_surface_offset_shape.mapping.black_level = (0.0, 0.0, 0.0)
	    mesh_surface_offset_shape.mapping.white_level = (1.0, 1.0, 1.0)
	    mesh_surface_offset_shape.mapping.clip_min_x = 0.0
	    mesh_surface_offset_shape.mapping.clip_min_y = 0.0
	    mesh_surface_offset_shape.mapping.clip_max_x = 1.0
	    mesh_surface_offset_shape.mapping.clip_max_y = 1.0
	    mesh_surface_offset_shape.mapping.use_clip = True
	    #curve 0
	    mesh_surface_offset_shape_curve_0 = mesh_surface_offset_shape.mapping.curves[0]
	    mesh_surface_offset_shape_curve_0_point_0 = mesh_surface_offset_shape_curve_0.points[0]
	    mesh_surface_offset_shape_curve_0_point_0.location = (0.0, 0.0)
	    mesh_surface_offset_shape_curve_0_point_0.handle_type = 'AUTO'
	    mesh_surface_offset_shape_curve_0_point_1 = mesh_surface_offset_shape_curve_0.points[1]
	    mesh_surface_offset_shape_curve_0_point_1.location = (0.17941175401210785, 0.24375000596046448)
	    mesh_surface_offset_shape_curve_0_point_1.handle_type = 'AUTO'
	    mesh_surface_offset_shape_curve_0_point_2 = mesh_surface_offset_shape_curve_0.points.new(0.5429043173789978, 0.43223676085472107)
	    mesh_surface_offset_shape_curve_0_point_2.handle_type = 'AUTO'
	    mesh_surface_offset_shape_curve_0_point_3 = mesh_surface_offset_shape_curve_0.points.new(0.7757606506347656, 0.8296050429344177)
	    mesh_surface_offset_shape_curve_0_point_3.handle_type = 'AUTO'
	    mesh_surface_offset_shape_curve_0_point_4 = mesh_surface_offset_shape_curve_0.points.new(1.0, 1.0)
	    mesh_surface_offset_shape_curve_0_point_4.handle_type = 'AUTO'
	    #update curve after changes
	    mesh_surface_offset_shape.mapping.update()
	    #Factor
	    mesh_surface_offset_shape.inputs[0].default_value = 1.0
	
	    #node Named Attribute.004
	    named_attribute_004 = scalp_hairz.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute_004.name = "Named Attribute.004"
	    named_attribute_004.hide = True
	    named_attribute_004.data_type = 'FLOAT_VECTOR'
	    #Name
	    named_attribute_004.inputs[0].default_value = "UVMap"
	
	    #node Frame.002
	    frame_002_5 = scalp_hairz.nodes.new("NodeFrame")
	    frame_002_5.label = "Surface Offset Shape"
	    frame_002_5.name = "Frame.002"
	    frame_002_5.label_size = 20
	    frame_002_5.shrink = True
	
	    #node Reroute
	    reroute_14 = scalp_hairz.nodes.new("NodeReroute")
	    reroute_14.name = "Reroute"
	    reroute_14.socket_idname = "NodeSocketGeometry"
	    #node Frame.003
	    frame_003_4 = scalp_hairz.nodes.new("NodeFrame")
	    frame_003_4.label = "Curve Hair"
	    frame_003_4.name = "Frame.003"
	    frame_003_4.label_size = 20
	    frame_003_4.shrink = True
	
	    #node Frame.004
	    frame_004_4 = scalp_hairz.nodes.new("NodeFrame")
	    frame_004_4.label = "Mesh Hair"
	    frame_004_4.name = "Frame.004"
	    frame_004_4.label_size = 20
	    frame_004_4.shrink = True
	
	    #node Group.004
	    group_004_3 = scalp_hairz.nodes.new("GeometryNodeGroup")
	    group_004_3.name = "Group.004"
	    group_004_3.node_tree = scalp_stylized_mesh
	
	    #node Menu Switch
	    menu_switch = scalp_hairz.nodes.new("GeometryNodeMenuSwitch")
	    menu_switch.name = "Menu Switch"
	    menu_switch.active_index = 2
	    menu_switch.data_type = 'GEOMETRY'
	    menu_switch.enum_items.clear()
	    menu_switch.enum_items.new("Curve Hair")
	    menu_switch.enum_items[0].description = ""
	    menu_switch.enum_items.new("Mesh Strip")
	    menu_switch.enum_items[1].description = ""
	    menu_switch.enum_items.new("Mesh Polygon")
	    menu_switch.enum_items[2].description = ""
	    menu_switch.inputs[4].hide = True
	
	    #node Group Input.003
	    group_input_003_12 = scalp_hairz.nodes.new("NodeGroupInput")
	    group_input_003_12.name = "Group Input.003"
	    group_input_003_12.outputs[0].hide = True
	    group_input_003_12.outputs[1].hide = True
	    group_input_003_12.outputs[3].hide = True
	    group_input_003_12.outputs[4].hide = True
	    group_input_003_12.outputs[5].hide = True
	    group_input_003_12.outputs[6].hide = True
	    group_input_003_12.outputs[7].hide = True
	    group_input_003_12.outputs[8].hide = True
	    group_input_003_12.outputs[9].hide = True
	    group_input_003_12.outputs[10].hide = True
	    group_input_003_12.outputs[11].hide = True
	    group_input_003_12.outputs[12].hide = True
	    group_input_003_12.outputs[13].hide = True
	    group_input_003_12.outputs[14].hide = True
	    group_input_003_12.outputs[15].hide = True
	    group_input_003_12.outputs[16].hide = True
	    group_input_003_12.outputs[17].hide = True
	    group_input_003_12.outputs[18].hide = True
	    group_input_003_12.outputs[19].hide = True
	    group_input_003_12.outputs[20].hide = True
	    group_input_003_12.outputs[21].hide = True
	    group_input_003_12.outputs[22].hide = True
	    group_input_003_12.outputs[23].hide = True
	    group_input_003_12.outputs[24].hide = True
	    group_input_003_12.outputs[25].hide = True
	    group_input_003_12.outputs[26].hide = True
	    group_input_003_12.outputs[27].hide = True
	    group_input_003_12.outputs[28].hide = True
	    group_input_003_12.outputs[29].hide = True
	    group_input_003_12.outputs[32].hide = True
	    group_input_003_12.outputs[33].hide = True
	    group_input_003_12.outputs[34].hide = True
	    group_input_003_12.outputs[35].hide = True
	    group_input_003_12.outputs[37].hide = True
	    group_input_003_12.outputs[38].hide = True
	    group_input_003_12.outputs[39].hide = True
	    group_input_003_12.outputs[40].hide = True
	    group_input_003_12.outputs[41].hide = True
	    group_input_003_12.outputs[42].hide = True
	    group_input_003_12.outputs[43].hide = True
	
	    #node Group Input.004
	    group_input_004_7 = scalp_hairz.nodes.new("NodeGroupInput")
	    group_input_004_7.name = "Group Input.004"
	    group_input_004_7.outputs[0].hide = True
	    group_input_004_7.outputs[1].hide = True
	    group_input_004_7.outputs[2].hide = True
	    group_input_004_7.outputs[3].hide = True
	    group_input_004_7.outputs[4].hide = True
	    group_input_004_7.outputs[6].hide = True
	    group_input_004_7.outputs[7].hide = True
	    group_input_004_7.outputs[8].hide = True
	    group_input_004_7.outputs[9].hide = True
	    group_input_004_7.outputs[10].hide = True
	    group_input_004_7.outputs[11].hide = True
	    group_input_004_7.outputs[12].hide = True
	    group_input_004_7.outputs[13].hide = True
	    group_input_004_7.outputs[14].hide = True
	    group_input_004_7.outputs[15].hide = True
	    group_input_004_7.outputs[16].hide = True
	    group_input_004_7.outputs[17].hide = True
	    group_input_004_7.outputs[18].hide = True
	    group_input_004_7.outputs[19].hide = True
	    group_input_004_7.outputs[20].hide = True
	    group_input_004_7.outputs[21].hide = True
	    group_input_004_7.outputs[22].hide = True
	    group_input_004_7.outputs[23].hide = True
	    group_input_004_7.outputs[24].hide = True
	    group_input_004_7.outputs[25].hide = True
	    group_input_004_7.outputs[26].hide = True
	    group_input_004_7.outputs[27].hide = True
	    group_input_004_7.outputs[28].hide = True
	    group_input_004_7.outputs[29].hide = True
	    group_input_004_7.outputs[30].hide = True
	    group_input_004_7.outputs[31].hide = True
	    group_input_004_7.outputs[32].hide = True
	    group_input_004_7.outputs[33].hide = True
	    group_input_004_7.outputs[34].hide = True
	    group_input_004_7.outputs[35].hide = True
	    group_input_004_7.outputs[36].hide = True
	    group_input_004_7.outputs[37].hide = True
	    group_input_004_7.outputs[38].hide = True
	    group_input_004_7.outputs[39].hide = True
	    group_input_004_7.outputs[40].hide = True
	    group_input_004_7.outputs[41].hide = True
	    group_input_004_7.outputs[42].hide = True
	    group_input_004_7.outputs[43].hide = True
	
	    #node Group Input.005
	    group_input_005_9 = scalp_hairz.nodes.new("NodeGroupInput")
	    group_input_005_9.name = "Group Input.005"
	    group_input_005_9.outputs[0].hide = True
	    group_input_005_9.outputs[1].hide = True
	    group_input_005_9.outputs[2].hide = True
	    group_input_005_9.outputs[3].hide = True
	    group_input_005_9.outputs[4].hide = True
	    group_input_005_9.outputs[5].hide = True
	    group_input_005_9.outputs[6].hide = True
	    group_input_005_9.outputs[7].hide = True
	    group_input_005_9.outputs[8].hide = True
	    group_input_005_9.outputs[9].hide = True
	    group_input_005_9.outputs[10].hide = True
	    group_input_005_9.outputs[11].hide = True
	    group_input_005_9.outputs[12].hide = True
	    group_input_005_9.outputs[13].hide = True
	    group_input_005_9.outputs[14].hide = True
	    group_input_005_9.outputs[15].hide = True
	    group_input_005_9.outputs[16].hide = True
	    group_input_005_9.outputs[17].hide = True
	    group_input_005_9.outputs[18].hide = True
	    group_input_005_9.outputs[19].hide = True
	    group_input_005_9.outputs[20].hide = True
	    group_input_005_9.outputs[21].hide = True
	    group_input_005_9.outputs[22].hide = True
	    group_input_005_9.outputs[23].hide = True
	    group_input_005_9.outputs[24].hide = True
	    group_input_005_9.outputs[25].hide = True
	    group_input_005_9.outputs[26].hide = True
	    group_input_005_9.outputs[27].hide = True
	    group_input_005_9.outputs[28].hide = True
	    group_input_005_9.outputs[29].hide = True
	    group_input_005_9.outputs[30].hide = True
	    group_input_005_9.outputs[31].hide = True
	    group_input_005_9.outputs[32].hide = True
	    group_input_005_9.outputs[33].hide = True
	    group_input_005_9.outputs[34].hide = True
	    group_input_005_9.outputs[36].hide = True
	    group_input_005_9.outputs[37].hide = True
	    group_input_005_9.outputs[38].hide = True
	    group_input_005_9.outputs[39].hide = True
	    group_input_005_9.outputs[40].hide = True
	    group_input_005_9.outputs[41].hide = True
	    group_input_005_9.outputs[42].hide = True
	    group_input_005_9.outputs[43].hide = True
	
	    #node Final Bake
	    final_bake = scalp_hairz.nodes.new("GeometryNodeBake")
	    final_bake.label = "Final Bake"
	    final_bake.name = "Final Bake"
	    final_bake.active_index = 0
	    final_bake.bake_items.clear()
	    final_bake.bake_items.new('GEOMETRY', "Geometry")
	    final_bake.bake_items[0].attribute_domain = 'POINT'
	    final_bake.inputs[1].hide = True
	    final_bake.outputs[1].hide = True
	
	    #node Hair Bake
	    hair_bake = scalp_hairz.nodes.new("GeometryNodeBake")
	    hair_bake.label = "Hair Bake"
	    hair_bake.name = "Hair Bake"
	    hair_bake.active_index = 0
	    hair_bake.bake_items.clear()
	    hair_bake.bake_items.new('GEOMETRY', "Geometry")
	    hair_bake.bake_items[0].attribute_domain = 'POINT'
	    hair_bake.inputs[1].hide = True
	    hair_bake.outputs[1].hide = True
	
	    #node Group Input.006
	    group_input_006_8 = scalp_hairz.nodes.new("NodeGroupInput")
	    group_input_006_8.name = "Group Input.006"
	    group_input_006_8.outputs[0].hide = True
	    group_input_006_8.outputs[1].hide = True
	    group_input_006_8.outputs[2].hide = True
	    group_input_006_8.outputs[3].hide = True
	    group_input_006_8.outputs[4].hide = True
	    group_input_006_8.outputs[5].hide = True
	    group_input_006_8.outputs[6].hide = True
	    group_input_006_8.outputs[7].hide = True
	    group_input_006_8.outputs[8].hide = True
	    group_input_006_8.outputs[9].hide = True
	    group_input_006_8.outputs[10].hide = True
	    group_input_006_8.outputs[11].hide = True
	    group_input_006_8.outputs[12].hide = True
	    group_input_006_8.outputs[13].hide = True
	    group_input_006_8.outputs[14].hide = True
	    group_input_006_8.outputs[15].hide = True
	    group_input_006_8.outputs[16].hide = True
	    group_input_006_8.outputs[17].hide = True
	    group_input_006_8.outputs[18].hide = True
	    group_input_006_8.outputs[19].hide = True
	    group_input_006_8.outputs[20].hide = True
	    group_input_006_8.outputs[21].hide = True
	    group_input_006_8.outputs[22].hide = True
	    group_input_006_8.outputs[23].hide = True
	    group_input_006_8.outputs[24].hide = True
	    group_input_006_8.outputs[25].hide = True
	    group_input_006_8.outputs[26].hide = True
	    group_input_006_8.outputs[27].hide = True
	    group_input_006_8.outputs[28].hide = True
	    group_input_006_8.outputs[29].hide = True
	    group_input_006_8.outputs[30].hide = True
	    group_input_006_8.outputs[31].hide = True
	    group_input_006_8.outputs[32].hide = True
	    group_input_006_8.outputs[33].hide = True
	    group_input_006_8.outputs[34].hide = True
	    group_input_006_8.outputs[36].hide = True
	    group_input_006_8.outputs[37].hide = True
	    group_input_006_8.outputs[38].hide = True
	    group_input_006_8.outputs[39].hide = True
	    group_input_006_8.outputs[40].hide = True
	    group_input_006_8.outputs[41].hide = True
	    group_input_006_8.outputs[42].hide = True
	    group_input_006_8.outputs[43].hide = True
	
	    #node Merge by Distance
	    merge_by_distance_2 = scalp_hairz.nodes.new("GeometryNodeMergeByDistance")
	    merge_by_distance_2.name = "Merge by Distance"
	    merge_by_distance_2.mode = 'ALL'
	    merge_by_distance_2.inputs[1].hide = True
	    #Selection
	    merge_by_distance_2.inputs[1].default_value = True
	
	    #node Separate XYZ
	    separate_xyz_3 = scalp_hairz.nodes.new("ShaderNodeSeparateXYZ")
	    separate_xyz_3.name = "Separate XYZ"
	    separate_xyz_3.hide = True
	    separate_xyz_3.outputs[1].hide = True
	    separate_xyz_3.outputs[2].hide = True
	
	    #node Group Input.007
	    group_input_007_6 = scalp_hairz.nodes.new("NodeGroupInput")
	    group_input_007_6.name = "Group Input.007"
	    group_input_007_6.outputs[0].hide = True
	    group_input_007_6.outputs[1].hide = True
	    group_input_007_6.outputs[3].hide = True
	    group_input_007_6.outputs[4].hide = True
	    group_input_007_6.outputs[5].hide = True
	    group_input_007_6.outputs[6].hide = True
	    group_input_007_6.outputs[7].hide = True
	    group_input_007_6.outputs[8].hide = True
	    group_input_007_6.outputs[9].hide = True
	    group_input_007_6.outputs[10].hide = True
	    group_input_007_6.outputs[11].hide = True
	    group_input_007_6.outputs[12].hide = True
	    group_input_007_6.outputs[13].hide = True
	    group_input_007_6.outputs[14].hide = True
	    group_input_007_6.outputs[15].hide = True
	    group_input_007_6.outputs[16].hide = True
	    group_input_007_6.outputs[17].hide = True
	    group_input_007_6.outputs[18].hide = True
	    group_input_007_6.outputs[19].hide = True
	    group_input_007_6.outputs[20].hide = True
	    group_input_007_6.outputs[21].hide = True
	    group_input_007_6.outputs[22].hide = True
	    group_input_007_6.outputs[23].hide = True
	    group_input_007_6.outputs[24].hide = True
	    group_input_007_6.outputs[25].hide = True
	    group_input_007_6.outputs[26].hide = True
	    group_input_007_6.outputs[27].hide = True
	    group_input_007_6.outputs[28].hide = True
	    group_input_007_6.outputs[29].hide = True
	    group_input_007_6.outputs[30].hide = True
	    group_input_007_6.outputs[31].hide = True
	    group_input_007_6.outputs[32].hide = True
	    group_input_007_6.outputs[33].hide = True
	    group_input_007_6.outputs[34].hide = True
	    group_input_007_6.outputs[35].hide = True
	    group_input_007_6.outputs[36].hide = True
	    group_input_007_6.outputs[37].hide = True
	    group_input_007_6.outputs[38].hide = True
	    group_input_007_6.outputs[39].hide = True
	    group_input_007_6.outputs[40].hide = True
	    group_input_007_6.outputs[41].hide = True
	    group_input_007_6.outputs[42].hide = True
	    group_input_007_6.outputs[43].hide = True
	
	    #node Group Input.008
	    group_input_008_5 = scalp_hairz.nodes.new("NodeGroupInput")
	    group_input_008_5.name = "Group Input.008"
	    group_input_008_5.outputs[0].hide = True
	    group_input_008_5.outputs[1].hide = True
	    group_input_008_5.outputs[2].hide = True
	    group_input_008_5.outputs[3].hide = True
	    group_input_008_5.outputs[4].hide = True
	    group_input_008_5.outputs[5].hide = True
	    group_input_008_5.outputs[6].hide = True
	    group_input_008_5.outputs[7].hide = True
	    group_input_008_5.outputs[8].hide = True
	    group_input_008_5.outputs[9].hide = True
	    group_input_008_5.outputs[10].hide = True
	    group_input_008_5.outputs[11].hide = True
	    group_input_008_5.outputs[12].hide = True
	    group_input_008_5.outputs[13].hide = True
	    group_input_008_5.outputs[14].hide = True
	    group_input_008_5.outputs[15].hide = True
	    group_input_008_5.outputs[16].hide = True
	    group_input_008_5.outputs[17].hide = True
	    group_input_008_5.outputs[18].hide = True
	    group_input_008_5.outputs[19].hide = True
	    group_input_008_5.outputs[20].hide = True
	    group_input_008_5.outputs[21].hide = True
	    group_input_008_5.outputs[22].hide = True
	    group_input_008_5.outputs[23].hide = True
	    group_input_008_5.outputs[24].hide = True
	    group_input_008_5.outputs[25].hide = True
	    group_input_008_5.outputs[26].hide = True
	    group_input_008_5.outputs[27].hide = True
	    group_input_008_5.outputs[28].hide = True
	    group_input_008_5.outputs[29].hide = True
	    group_input_008_5.outputs[30].hide = True
	    group_input_008_5.outputs[31].hide = True
	    group_input_008_5.outputs[32].hide = True
	    group_input_008_5.outputs[33].hide = True
	    group_input_008_5.outputs[34].hide = True
	    group_input_008_5.outputs[35].hide = True
	    group_input_008_5.outputs[36].hide = True
	    group_input_008_5.outputs[37].hide = True
	    group_input_008_5.outputs[43].hide = True
	
	    #node Group Input.009
	    group_input_009_3 = scalp_hairz.nodes.new("NodeGroupInput")
	    group_input_009_3.name = "Group Input.009"
	    group_input_009_3.outputs[0].hide = True
	    group_input_009_3.outputs[1].hide = True
	    group_input_009_3.outputs[2].hide = True
	    group_input_009_3.outputs[3].hide = True
	    group_input_009_3.outputs[4].hide = True
	    group_input_009_3.outputs[5].hide = True
	    group_input_009_3.outputs[6].hide = True
	    group_input_009_3.outputs[7].hide = True
	    group_input_009_3.outputs[8].hide = True
	    group_input_009_3.outputs[9].hide = True
	    group_input_009_3.outputs[10].hide = True
	    group_input_009_3.outputs[11].hide = True
	    group_input_009_3.outputs[12].hide = True
	    group_input_009_3.outputs[13].hide = True
	    group_input_009_3.outputs[14].hide = True
	    group_input_009_3.outputs[15].hide = True
	    group_input_009_3.outputs[16].hide = True
	    group_input_009_3.outputs[17].hide = True
	    group_input_009_3.outputs[18].hide = True
	    group_input_009_3.outputs[19].hide = True
	    group_input_009_3.outputs[20].hide = True
	    group_input_009_3.outputs[21].hide = True
	    group_input_009_3.outputs[22].hide = True
	    group_input_009_3.outputs[23].hide = True
	    group_input_009_3.outputs[24].hide = True
	    group_input_009_3.outputs[25].hide = True
	    group_input_009_3.outputs[26].hide = True
	    group_input_009_3.outputs[27].hide = True
	    group_input_009_3.outputs[28].hide = True
	    group_input_009_3.outputs[29].hide = True
	    group_input_009_3.outputs[30].hide = True
	    group_input_009_3.outputs[31].hide = True
	    group_input_009_3.outputs[32].hide = True
	    group_input_009_3.outputs[34].hide = True
	    group_input_009_3.outputs[35].hide = True
	    group_input_009_3.outputs[36].hide = True
	    group_input_009_3.outputs[37].hide = True
	    group_input_009_3.outputs[38].hide = True
	    group_input_009_3.outputs[39].hide = True
	    group_input_009_3.outputs[40].hide = True
	    group_input_009_3.outputs[41].hide = True
	    group_input_009_3.outputs[42].hide = True
	    group_input_009_3.outputs[43].hide = True
	
	    #node Compare
	    compare_11 = scalp_hairz.nodes.new("FunctionNodeCompare")
	    compare_11.name = "Compare"
	    compare_11.hide = True
	    compare_11.data_type = 'FLOAT'
	    compare_11.mode = 'ELEMENT'
	    compare_11.operation = 'EQUAL'
	    compare_11.inputs[1].hide = True
	    compare_11.inputs[2].hide = True
	    compare_11.inputs[3].hide = True
	    compare_11.inputs[4].hide = True
	    compare_11.inputs[5].hide = True
	    compare_11.inputs[6].hide = True
	    compare_11.inputs[7].hide = True
	    compare_11.inputs[8].hide = True
	    compare_11.inputs[9].hide = True
	    compare_11.inputs[10].hide = True
	    compare_11.inputs[11].hide = True
	    compare_11.inputs[12].hide = True
	    #B
	    compare_11.inputs[1].default_value = 0.0
	    #Epsilon
	    compare_11.inputs[12].default_value = 0.0
	
	    #node Switch
	    switch_11 = scalp_hairz.nodes.new("GeometryNodeSwitch")
	    switch_11.name = "Switch"
	    switch_11.hide = True
	    switch_11.input_type = 'GEOMETRY'
	
	    #node Group Input.010
	    group_input_010_4 = scalp_hairz.nodes.new("NodeGroupInput")
	    group_input_010_4.name = "Group Input.010"
	    group_input_010_4.outputs[0].hide = True
	    group_input_010_4.outputs[1].hide = True
	    group_input_010_4.outputs[2].hide = True
	    group_input_010_4.outputs[3].hide = True
	    group_input_010_4.outputs[4].hide = True
	    group_input_010_4.outputs[5].hide = True
	    group_input_010_4.outputs[6].hide = True
	    group_input_010_4.outputs[7].hide = True
	    group_input_010_4.outputs[8].hide = True
	    group_input_010_4.outputs[9].hide = True
	    group_input_010_4.outputs[10].hide = True
	    group_input_010_4.outputs[11].hide = True
	    group_input_010_4.outputs[12].hide = True
	    group_input_010_4.outputs[13].hide = True
	    group_input_010_4.outputs[14].hide = True
	    group_input_010_4.outputs[15].hide = True
	    group_input_010_4.outputs[16].hide = True
	    group_input_010_4.outputs[17].hide = True
	    group_input_010_4.outputs[18].hide = True
	    group_input_010_4.outputs[19].hide = True
	    group_input_010_4.outputs[20].hide = True
	    group_input_010_4.outputs[21].hide = True
	    group_input_010_4.outputs[22].hide = True
	    group_input_010_4.outputs[23].hide = True
	    group_input_010_4.outputs[24].hide = True
	    group_input_010_4.outputs[25].hide = True
	    group_input_010_4.outputs[26].hide = True
	    group_input_010_4.outputs[27].hide = True
	    group_input_010_4.outputs[28].hide = True
	    group_input_010_4.outputs[29].hide = True
	    group_input_010_4.outputs[30].hide = True
	    group_input_010_4.outputs[31].hide = True
	    group_input_010_4.outputs[32].hide = True
	    group_input_010_4.outputs[33].hide = True
	    group_input_010_4.outputs[34].hide = True
	    group_input_010_4.outputs[35].hide = True
	    group_input_010_4.outputs[36].hide = True
	    group_input_010_4.outputs[38].hide = True
	    group_input_010_4.outputs[39].hide = True
	    group_input_010_4.outputs[40].hide = True
	    group_input_010_4.outputs[41].hide = True
	    group_input_010_4.outputs[42].hide = True
	    group_input_010_4.outputs[43].hide = True
	
	    #node Reroute.001
	    reroute_001_11 = scalp_hairz.nodes.new("NodeReroute")
	    reroute_001_11.name = "Reroute.001"
	    reroute_001_11.socket_idname = "NodeSocketGeometry"
	    #node Reroute.002
	    reroute_002_9 = scalp_hairz.nodes.new("NodeReroute")
	    reroute_002_9.name = "Reroute.002"
	    reroute_002_9.socket_idname = "NodeSocketGeometry"
	    #node Reroute.003
	    reroute_003_8 = scalp_hairz.nodes.new("NodeReroute")
	    reroute_003_8.name = "Reroute.003"
	    reroute_003_8.socket_idname = "NodeSocketGeometry"
	    #node Reroute.004
	    reroute_004_9 = scalp_hairz.nodes.new("NodeReroute")
	    reroute_004_9.name = "Reroute.004"
	    reroute_004_9.socket_idname = "NodeSocketGeometry"
	    #node Group.003
	    group_003_3 = scalp_hairz.nodes.new("GeometryNodeGroup")
	    group_003_3.name = "Group.003"
	    group_003_3.node_tree = hair_noise
	    group_003_3.inputs[1].hide = True
	
	    #node Group Input.011
	    group_input_011_2 = scalp_hairz.nodes.new("NodeGroupInput")
	    group_input_011_2.name = "Group Input.011"
	    group_input_011_2.outputs[0].hide = True
	    group_input_011_2.outputs[1].hide = True
	    group_input_011_2.outputs[3].hide = True
	    group_input_011_2.outputs[4].hide = True
	    group_input_011_2.outputs[5].hide = True
	    group_input_011_2.outputs[6].hide = True
	    group_input_011_2.outputs[7].hide = True
	    group_input_011_2.outputs[8].hide = True
	    group_input_011_2.outputs[9].hide = True
	    group_input_011_2.outputs[10].hide = True
	    group_input_011_2.outputs[11].hide = True
	    group_input_011_2.outputs[12].hide = True
	    group_input_011_2.outputs[13].hide = True
	    group_input_011_2.outputs[14].hide = True
	    group_input_011_2.outputs[15].hide = True
	    group_input_011_2.outputs[16].hide = True
	    group_input_011_2.outputs[17].hide = True
	    group_input_011_2.outputs[18].hide = True
	    group_input_011_2.outputs[19].hide = True
	    group_input_011_2.outputs[20].hide = True
	    group_input_011_2.outputs[21].hide = True
	    group_input_011_2.outputs[22].hide = True
	    group_input_011_2.outputs[23].hide = True
	    group_input_011_2.outputs[24].hide = True
	    group_input_011_2.outputs[25].hide = True
	    group_input_011_2.outputs[26].hide = True
	    group_input_011_2.outputs[27].hide = True
	    group_input_011_2.outputs[28].hide = True
	    group_input_011_2.outputs[29].hide = True
	    group_input_011_2.outputs[30].hide = True
	    group_input_011_2.outputs[31].hide = True
	    group_input_011_2.outputs[32].hide = True
	    group_input_011_2.outputs[33].hide = True
	    group_input_011_2.outputs[34].hide = True
	    group_input_011_2.outputs[35].hide = True
	    group_input_011_2.outputs[36].hide = True
	    group_input_011_2.outputs[37].hide = True
	    group_input_011_2.outputs[38].hide = True
	    group_input_011_2.outputs[39].hide = True
	    group_input_011_2.outputs[40].hide = True
	    group_input_011_2.outputs[41].hide = True
	    group_input_011_2.outputs[42].hide = True
	    group_input_011_2.outputs[43].hide = True
	
	    #node Group Input.012
	    group_input_012_1 = scalp_hairz.nodes.new("NodeGroupInput")
	    group_input_012_1.name = "Group Input.012"
	    group_input_012_1.outputs[0].hide = True
	    group_input_012_1.outputs[1].hide = True
	    group_input_012_1.outputs[2].hide = True
	    group_input_012_1.outputs[3].hide = True
	    group_input_012_1.outputs[4].hide = True
	    group_input_012_1.outputs[5].hide = True
	    group_input_012_1.outputs[6].hide = True
	    group_input_012_1.outputs[7].hide = True
	    group_input_012_1.outputs[8].hide = True
	    group_input_012_1.outputs[9].hide = True
	    group_input_012_1.outputs[10].hide = True
	    group_input_012_1.outputs[11].hide = True
	    group_input_012_1.outputs[12].hide = True
	    group_input_012_1.outputs[13].hide = True
	    group_input_012_1.outputs[14].hide = True
	    group_input_012_1.outputs[15].hide = True
	    group_input_012_1.outputs[16].hide = True
	    group_input_012_1.outputs[17].hide = True
	    group_input_012_1.outputs[18].hide = True
	    group_input_012_1.outputs[19].hide = True
	    group_input_012_1.outputs[20].hide = True
	    group_input_012_1.outputs[21].hide = True
	    group_input_012_1.outputs[22].hide = True
	    group_input_012_1.outputs[23].hide = True
	    group_input_012_1.outputs[24].hide = True
	    group_input_012_1.outputs[25].hide = True
	    group_input_012_1.outputs[26].hide = True
	    group_input_012_1.outputs[27].hide = True
	    group_input_012_1.outputs[28].hide = True
	    group_input_012_1.outputs[29].hide = True
	    group_input_012_1.outputs[30].hide = True
	    group_input_012_1.outputs[31].hide = True
	    group_input_012_1.outputs[32].hide = True
	    group_input_012_1.outputs[33].hide = True
	    group_input_012_1.outputs[34].hide = True
	    group_input_012_1.outputs[35].hide = True
	    group_input_012_1.outputs[36].hide = True
	    group_input_012_1.outputs[37].hide = True
	    group_input_012_1.outputs[43].hide = True
	
	    #node Compare.001
	    compare_001_4 = scalp_hairz.nodes.new("FunctionNodeCompare")
	    compare_001_4.name = "Compare.001"
	    compare_001_4.hide = True
	    compare_001_4.data_type = 'FLOAT'
	    compare_001_4.mode = 'ELEMENT'
	    compare_001_4.operation = 'EQUAL'
	    compare_001_4.inputs[1].hide = True
	    compare_001_4.inputs[2].hide = True
	    compare_001_4.inputs[3].hide = True
	    compare_001_4.inputs[4].hide = True
	    compare_001_4.inputs[5].hide = True
	    compare_001_4.inputs[6].hide = True
	    compare_001_4.inputs[7].hide = True
	    compare_001_4.inputs[8].hide = True
	    compare_001_4.inputs[9].hide = True
	    compare_001_4.inputs[10].hide = True
	    compare_001_4.inputs[11].hide = True
	    compare_001_4.inputs[12].hide = True
	    #B
	    compare_001_4.inputs[1].default_value = 0.0
	    #Epsilon
	    compare_001_4.inputs[12].default_value = 0.0
	
	    #node Switch.001
	    switch_001_9 = scalp_hairz.nodes.new("GeometryNodeSwitch")
	    switch_001_9.name = "Switch.001"
	    switch_001_9.hide = True
	    switch_001_9.input_type = 'GEOMETRY'
	
	    #node Group Input.013
	    group_input_013_2 = scalp_hairz.nodes.new("NodeGroupInput")
	    group_input_013_2.name = "Group Input.013"
	    group_input_013_2.outputs[0].hide = True
	    group_input_013_2.outputs[1].hide = True
	    group_input_013_2.outputs[2].hide = True
	    group_input_013_2.outputs[3].hide = True
	    group_input_013_2.outputs[4].hide = True
	    group_input_013_2.outputs[5].hide = True
	    group_input_013_2.outputs[6].hide = True
	    group_input_013_2.outputs[7].hide = True
	    group_input_013_2.outputs[8].hide = True
	    group_input_013_2.outputs[9].hide = True
	    group_input_013_2.outputs[10].hide = True
	    group_input_013_2.outputs[11].hide = True
	    group_input_013_2.outputs[12].hide = True
	    group_input_013_2.outputs[13].hide = True
	    group_input_013_2.outputs[14].hide = True
	    group_input_013_2.outputs[15].hide = True
	    group_input_013_2.outputs[16].hide = True
	    group_input_013_2.outputs[17].hide = True
	    group_input_013_2.outputs[18].hide = True
	    group_input_013_2.outputs[19].hide = True
	    group_input_013_2.outputs[20].hide = True
	    group_input_013_2.outputs[21].hide = True
	    group_input_013_2.outputs[22].hide = True
	    group_input_013_2.outputs[23].hide = True
	    group_input_013_2.outputs[24].hide = True
	    group_input_013_2.outputs[25].hide = True
	    group_input_013_2.outputs[26].hide = True
	    group_input_013_2.outputs[27].hide = True
	    group_input_013_2.outputs[28].hide = True
	    group_input_013_2.outputs[29].hide = True
	    group_input_013_2.outputs[30].hide = True
	    group_input_013_2.outputs[31].hide = True
	    group_input_013_2.outputs[32].hide = True
	    group_input_013_2.outputs[33].hide = True
	    group_input_013_2.outputs[34].hide = True
	    group_input_013_2.outputs[35].hide = True
	    group_input_013_2.outputs[36].hide = True
	    group_input_013_2.outputs[38].hide = True
	    group_input_013_2.outputs[39].hide = True
	    group_input_013_2.outputs[40].hide = True
	    group_input_013_2.outputs[41].hide = True
	    group_input_013_2.outputs[42].hide = True
	    group_input_013_2.outputs[43].hide = True
	
	    #node Group.005
	    group_005_2 = scalp_hairz.nodes.new("GeometryNodeGroup")
	    group_005_2.name = "Group.005"
	    group_005_2.node_tree = hair_noise
	    group_005_2.inputs[1].hide = True
	
	    #node Mesh Strip Bake
	    mesh_strip_bake = scalp_hairz.nodes.new("GeometryNodeBake")
	    mesh_strip_bake.label = "Mesh Strip Bake"
	    mesh_strip_bake.name = "Mesh Strip Bake"
	    mesh_strip_bake.active_index = 0
	    mesh_strip_bake.bake_items.clear()
	    mesh_strip_bake.bake_items.new('GEOMETRY', "Geometry")
	    mesh_strip_bake.bake_items[0].attribute_domain = 'POINT'
	    mesh_strip_bake.inputs[1].hide = True
	    mesh_strip_bake.outputs[1].hide = True
	
	    #node Reroute.005
	    reroute_005_7 = scalp_hairz.nodes.new("NodeReroute")
	    reroute_005_7.name = "Reroute.005"
	    reroute_005_7.socket_idname = "NodeSocketGeometry"
	    #node Mesh Polygon Bake
	    mesh_polygon_bake = scalp_hairz.nodes.new("GeometryNodeBake")
	    mesh_polygon_bake.label = "Mesh Polygon Bake"
	    mesh_polygon_bake.name = "Mesh Polygon Bake"
	    mesh_polygon_bake.active_index = 0
	    mesh_polygon_bake.bake_items.clear()
	    mesh_polygon_bake.bake_items.new('GEOMETRY', "Geometry")
	    mesh_polygon_bake.bake_items[0].attribute_domain = 'POINT'
	    mesh_polygon_bake.inputs[1].hide = True
	    mesh_polygon_bake.outputs[1].hide = True
	
	    #node Reroute.006
	    reroute_006_5 = scalp_hairz.nodes.new("NodeReroute")
	    reroute_006_5.name = "Reroute.006"
	    reroute_006_5.socket_idname = "NodeSocketGeometry"
	    #node Mesh Noise Factor Curve
	    mesh_noise_factor_curve = scalp_hairz.nodes.new("ShaderNodeFloatCurve")
	    mesh_noise_factor_curve.label = "Mesh Noise Factor Curve"
	    mesh_noise_factor_curve.name = "Mesh Noise Factor Curve"
	    #mapping settings
	    mesh_noise_factor_curve.mapping.extend = 'EXTRAPOLATED'
	    mesh_noise_factor_curve.mapping.tone = 'STANDARD'
	    mesh_noise_factor_curve.mapping.black_level = (0.0, 0.0, 0.0)
	    mesh_noise_factor_curve.mapping.white_level = (1.0, 1.0, 1.0)
	    mesh_noise_factor_curve.mapping.clip_min_x = 0.0
	    mesh_noise_factor_curve.mapping.clip_min_y = 0.0
	    mesh_noise_factor_curve.mapping.clip_max_x = 1.0
	    mesh_noise_factor_curve.mapping.clip_max_y = 1.0
	    mesh_noise_factor_curve.mapping.use_clip = True
	    #curve 0
	    mesh_noise_factor_curve_curve_0 = mesh_noise_factor_curve.mapping.curves[0]
	    mesh_noise_factor_curve_curve_0_point_0 = mesh_noise_factor_curve_curve_0.points[0]
	    mesh_noise_factor_curve_curve_0_point_0.location = (0.0, 1.0)
	    mesh_noise_factor_curve_curve_0_point_0.handle_type = 'AUTO'
	    mesh_noise_factor_curve_curve_0_point_1 = mesh_noise_factor_curve_curve_0.points[1]
	    mesh_noise_factor_curve_curve_0_point_1.location = (1.0, 1.0)
	    mesh_noise_factor_curve_curve_0_point_1.handle_type = 'AUTO'
	    #update curve after changes
	    mesh_noise_factor_curve.mapping.update()
	    #Factor
	    mesh_noise_factor_curve.inputs[0].default_value = 1.0
	
	    #node Named Attribute.005
	    named_attribute_005_1 = scalp_hairz.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute_005_1.name = "Named Attribute.005"
	    named_attribute_005_1.hide = True
	    named_attribute_005_1.data_type = 'FLOAT_VECTOR'
	    #Name
	    named_attribute_005_1.inputs[0].default_value = "UVMap"
	
	    #node Frame.006
	    frame_006_4 = scalp_hairz.nodes.new("NodeFrame")
	    frame_006_4.label = "Mesh Noise Factor Curve"
	    frame_006_4.name = "Frame.006"
	    frame_006_4.label_size = 20
	    frame_006_4.shrink = True
	
	    #node Separate XYZ.001
	    separate_xyz_001_1 = scalp_hairz.nodes.new("ShaderNodeSeparateXYZ")
	    separate_xyz_001_1.name = "Separate XYZ.001"
	    separate_xyz_001_1.hide = True
	    separate_xyz_001_1.outputs[1].hide = True
	    separate_xyz_001_1.outputs[2].hide = True
	
	    #node Map Range
	    map_range_4 = scalp_hairz.nodes.new("ShaderNodeMapRange")
	    map_range_4.name = "Map Range"
	    map_range_4.hide = True
	    map_range_4.clamp = True
	    map_range_4.data_type = 'FLOAT'
	    map_range_4.interpolation_type = 'LINEAR'
	    map_range_4.inputs[1].hide = True
	    map_range_4.inputs[2].hide = True
	    map_range_4.inputs[3].hide = True
	    map_range_4.inputs[5].hide = True
	    map_range_4.inputs[6].hide = True
	    map_range_4.inputs[7].hide = True
	    map_range_4.inputs[8].hide = True
	    map_range_4.inputs[9].hide = True
	    map_range_4.inputs[10].hide = True
	    map_range_4.inputs[11].hide = True
	    map_range_4.outputs[1].hide = True
	    #From Min
	    map_range_4.inputs[1].default_value = 0.0
	    #From Max
	    map_range_4.inputs[2].default_value = 1.0
	    #To Min
	    map_range_4.inputs[3].default_value = 0.0
	
	    #node Group Input.014
	    group_input_014_1 = scalp_hairz.nodes.new("NodeGroupInput")
	    group_input_014_1.name = "Group Input.014"
	    group_input_014_1.outputs[0].hide = True
	    group_input_014_1.outputs[1].hide = True
	    group_input_014_1.outputs[2].hide = True
	    group_input_014_1.outputs[3].hide = True
	    group_input_014_1.outputs[4].hide = True
	    group_input_014_1.outputs[5].hide = True
	    group_input_014_1.outputs[6].hide = True
	    group_input_014_1.outputs[7].hide = True
	    group_input_014_1.outputs[8].hide = True
	    group_input_014_1.outputs[9].hide = True
	    group_input_014_1.outputs[10].hide = True
	    group_input_014_1.outputs[11].hide = True
	    group_input_014_1.outputs[12].hide = True
	    group_input_014_1.outputs[13].hide = True
	    group_input_014_1.outputs[14].hide = True
	    group_input_014_1.outputs[15].hide = True
	    group_input_014_1.outputs[16].hide = True
	    group_input_014_1.outputs[17].hide = True
	    group_input_014_1.outputs[18].hide = True
	    group_input_014_1.outputs[19].hide = True
	    group_input_014_1.outputs[20].hide = True
	    group_input_014_1.outputs[21].hide = True
	    group_input_014_1.outputs[22].hide = True
	    group_input_014_1.outputs[23].hide = True
	    group_input_014_1.outputs[24].hide = True
	    group_input_014_1.outputs[25].hide = True
	    group_input_014_1.outputs[26].hide = True
	    group_input_014_1.outputs[27].hide = True
	    group_input_014_1.outputs[28].hide = True
	    group_input_014_1.outputs[29].hide = True
	    group_input_014_1.outputs[30].hide = True
	    group_input_014_1.outputs[31].hide = True
	    group_input_014_1.outputs[32].hide = True
	    group_input_014_1.outputs[33].hide = True
	    group_input_014_1.outputs[34].hide = True
	    group_input_014_1.outputs[35].hide = True
	    group_input_014_1.outputs[36].hide = True
	    group_input_014_1.outputs[38].hide = True
	    group_input_014_1.outputs[39].hide = True
	    group_input_014_1.outputs[40].hide = True
	    group_input_014_1.outputs[41].hide = True
	    group_input_014_1.outputs[42].hide = True
	    group_input_014_1.outputs[43].hide = True
	
	    #node Reroute.007
	    reroute_007_5 = scalp_hairz.nodes.new("NodeReroute")
	    reroute_007_5.name = "Reroute.007"
	    reroute_007_5.socket_idname = "NodeSocketGeometry"
	    #node Reroute.008
	    reroute_008_4 = scalp_hairz.nodes.new("NodeReroute")
	    reroute_008_4.name = "Reroute.008"
	    reroute_008_4.socket_idname = "NodeSocketGeometry"
	    #node Separate Components
	    separate_components_2 = scalp_hairz.nodes.new("GeometryNodeSeparateComponents")
	    separate_components_2.name = "Separate Components"
	    separate_components_2.hide = True
	
	    #node Join Geometry
	    join_geometry_4 = scalp_hairz.nodes.new("GeometryNodeJoinGeometry")
	    join_geometry_4.name = "Join Geometry"
	
	    #node Reroute.009
	    reroute_009_4 = scalp_hairz.nodes.new("NodeReroute")
	    reroute_009_4.name = "Reroute.009"
	    reroute_009_4.socket_idname = "NodeSocketGeometry"
	    #node Reroute.010
	    reroute_010_3 = scalp_hairz.nodes.new("NodeReroute")
	    reroute_010_3.name = "Reroute.010"
	    reroute_010_3.socket_idname = "NodeSocketGeometry"
	    #node Reroute.011
	    reroute_011_3 = scalp_hairz.nodes.new("NodeReroute")
	    reroute_011_3.name = "Reroute.011"
	    reroute_011_3.socket_idname = "NodeSocketGeometry"
	    #node Reroute.012
	    reroute_012_5 = scalp_hairz.nodes.new("NodeReroute")
	    reroute_012_5.name = "Reroute.012"
	    reroute_012_5.socket_idname = "NodeSocketGeometry"
	    #node Reroute.013
	    reroute_013_5 = scalp_hairz.nodes.new("NodeReroute")
	    reroute_013_5.name = "Reroute.013"
	    reroute_013_5.socket_idname = "NodeSocketGeometry"
	    #node Reroute.014
	    reroute_014_4 = scalp_hairz.nodes.new("NodeReroute")
	    reroute_014_4.name = "Reroute.014"
	    reroute_014_4.socket_idname = "NodeSocketGeometry"
	    #node Reroute.015
	    reroute_015_4 = scalp_hairz.nodes.new("NodeReroute")
	    reroute_015_4.name = "Reroute.015"
	    reroute_015_4.socket_idname = "NodeSocketGeometry"
	    #node Reroute.016
	    reroute_016_2 = scalp_hairz.nodes.new("NodeReroute")
	    reroute_016_2.name = "Reroute.016"
	    reroute_016_2.socket_idname = "NodeSocketGeometry"
	    #node Reroute.017
	    reroute_017_2 = scalp_hairz.nodes.new("NodeReroute")
	    reroute_017_2.name = "Reroute.017"
	    reroute_017_2.socket_idname = "NodeSocketGeometry"
	    #node Reroute.018
	    reroute_018_2 = scalp_hairz.nodes.new("NodeReroute")
	    reroute_018_2.name = "Reroute.018"
	    reroute_018_2.socket_idname = "NodeSocketGeometry"
	
	
	
	    #Set parents
	    hair_shape_2.parent = frame_8
	    spline_parameter_001_2.parent = frame_8
	    frame_8.parent = frame_003_4
	    hair_to_surface_shape_2.parent = frame_005_4
	    spline_parameter_6.parent = frame_005_4
	    frame_005_4.parent = frame_003_4
	    mesh_shape.parent = frame_001_5
	    spline_parameter_002.parent = frame_001_5
	    frame_001_5.parent = frame_004_4
	    mesh_surface_offset_shape.parent = frame_002_5
	    named_attribute_004.parent = frame_002_5
	    frame_002_5.parent = frame_004_4
	    separate_xyz_3.parent = frame_002_5
	    mesh_noise_factor_curve.parent = frame_006_4
	    named_attribute_005_1.parent = frame_006_4
	    separate_xyz_001_1.parent = frame_006_4
	
	    #Set locations
	    group_input_18.location = (-340.0, 0.0)
	    group_output_23.location = (2498.748291015625, 138.07150268554688)
	    group_8.location = (6.512582302093506, 44.20233917236328)
	    group_001_7.location = (1301.7005615234375, -14.335044860839844)
	    hair_shape_2.location = (30.1650390625, -40.409637451171875)
	    spline_parameter_001_2.location = (32.8236083984375, -357.97711181640625)
	    frame_8.location = (32.0, -40.0)
	    hair_to_surface_shape_2.location = (29.9520263671875, -40.24993896484375)
	    spline_parameter_6.location = (34.76171875, -333.32928466796875)
	    frame_005_4.location = (30.0, -494.0)
	    group_input_002_12.location = (1089.756103515625, -81.95970916748047)
	    mesh_shape.location = (29.7364501953125, -40.29109191894531)
	    spline_parameter_002.location = (33.8048095703125, -358.07086181640625)
	    frame_001_5.location = (31.0, -40.0)
	    mesh_surface_offset_shape.location = (33.0364990234375, -40.1190185546875)
	    named_attribute_004.location = (30.3880615234375, -400.962158203125)
	    frame_002_5.location = (30.0, -475.0)
	    reroute_14.location = (1211.82470703125, 7.036154747009277)
	    frame_003_4.location = (-1172.0, -60.0)
	    frame_004_4.location = (224.0, -157.0)
	    group_004_3.location = (1296.4984130859375, -519.2134399414062)
	    menu_switch.location = (1907.0181884765625, 116.88939666748047)
	    group_input_003_12.location = (1104.3203125, -586.4176025390625)
	    group_input_004_7.location = (1304.43896484375, 71.29739379882812)
	    group_input_005_9.location = (1106.1248779296875, -713.7122192382812)
	    final_bake.location = (2316.99169921875, 185.9367218017578)
	    hair_bake.location = (561.419921875, 91.96378326416016)
	    group_input_006_8.location = (1092.5899658203125, -280.3586120605469)
	    merge_by_distance_2.location = (1549.7828369140625, -469.328369140625)
	    separate_xyz_3.location = (31.2996826171875, -361.85699462890625)
	    group_input_007_6.location = (1717.983642578125, -525.2825927734375)
	    group_input_008_5.location = (1720.86474609375, -584.37646484375)
	    group_input_009_3.location = (1545.924072265625, -596.5067749023438)
	    compare_11.location = (1947.3621826171875, -340.4393615722656)
	    switch_11.location = (1950.2431640625, -375.0309143066406)
	    group_input_010_4.location = (1942.3316650390625, -276.8927917480469)
	    reroute_001_11.location = (1890.0230712890625, -33.24720764160156)
	    reroute_002_9.location = (1890.3812255859375, -76.82134246826172)
	    reroute_003_8.location = (2128.272705078125, -78.14014434814453)
	    reroute_004_9.location = (2131.846435546875, -385.7110595703125)
	    group_003_3.location = (1925.3233642578125, -421.8853759765625)
	    group_input_011_2.location = (1459.549560546875, -191.23692321777344)
	    group_input_012_1.location = (1462.4306640625, -250.33079528808594)
	    compare_001_4.location = (1693.615234375, -61.87758255004883)
	    switch_001_9.location = (1696.4962158203125, -96.46913146972656)
	    group_input_013_2.location = (1691.8631591796875, 3.208242416381836)
	    group_005_2.location = (1666.8892822265625, -152.70301818847656)
	    mesh_strip_bake.location = (1472.089599609375, -31.375274658203125)
	    reroute_005_7.location = (1649.260986328125, -114.33887481689453)
	    mesh_polygon_bake.location = (1718.15869140625, -422.3330383300781)
	    reroute_006_5.location = (1882.041748046875, -503.85968017578125)
	    mesh_noise_factor_curve.location = (32.2041015625, -39.75799560546875)
	    named_attribute_005_1.location = (29.5556640625, -400.601318359375)
	    frame_006_4.location = (1069.0, -805.0)
	    separate_xyz_001_1.location = (30.46728515625, -361.49609375)
	    map_range_4.location = (1661.8564453125, -755.481201171875)
	    group_input_014_1.location = (1658.739501953125, -787.8583984375)
	    reroute_007_5.location = (1864.0465087890625, -11.732559204101562)
	    reroute_008_4.location = (1881.179931640625, -398.97265625)
	    separate_components_2.location = (-336.15185546875, 41.10321044921875)
	    join_geometry_4.location = (2132.42431640625, 139.64212036132812)
	    reroute_009_4.location = (30.82415771484375, 250.1999053955078)
	    reroute_010_3.location = (30.82415771484375, 240.24090576171875)
	    reroute_011_3.location = (30.82415771484375, 260.43634033203125)
	    reroute_012_5.location = (30.82415771484375, 255.25543212890625)
	    reroute_013_5.location = (30.82415771484375, 245.1908416748047)
	    reroute_014_4.location = (2054.1962890625, 251.99314880371094)
	    reroute_015_4.location = (2054.1962890625, 241.9932861328125)
	    reroute_016_2.location = (2054.1962890625, 261.9940490722656)
	    reroute_017_2.location = (2054.1962890625, 246.9931182861328)
	    reroute_018_2.location = (2054.1962890625, 256.9934387207031)
	
	    #Set dimensions
	    group_input_18.width, group_input_18.height = 140.0, 100.0
	    group_output_23.width, group_output_23.height = 140.0, 100.0
	    group_8.width, group_8.height = 173.69985961914062, 100.0
	    group_001_7.width, group_001_7.height = 140.0, 100.0
	    hair_shape_2.width, hair_shape_2.height = 700.0, 100.0
	    spline_parameter_001_2.width, spline_parameter_001_2.height = 140.0, 100.0
	    frame_8.width, frame_8.height = 760.0, 413.0
	    hair_to_surface_shape_2.width, hair_to_surface_shape_2.height = 700.0, 100.0
	    spline_parameter_6.width, spline_parameter_6.height = 140.0, 100.0
	    frame_005_4.width, frame_005_4.height = 760.0, 388.0
	    group_input_002_12.width, group_input_002_12.height = 140.0, 100.0
	    mesh_shape.width, mesh_shape.height = 700.0, 100.0
	    spline_parameter_002.width, spline_parameter_002.height = 140.0, 100.0
	    frame_001_5.width, frame_001_5.height = 760.0, 413.0
	    mesh_surface_offset_shape.width, mesh_surface_offset_shape.height = 700.0, 100.0
	    named_attribute_004.width, named_attribute_004.height = 140.0, 100.0
	    frame_002_5.width, frame_002_5.height = 763.0, 456.0
	    reroute_14.width, reroute_14.height = 10.0, 100.0
	    frame_003_4.width, frame_003_4.height = 822.0, 912.0
	    frame_004_4.width, frame_004_4.height = 823.0, 961.0
	    group_004_3.width, group_004_3.height = 220.9304656982422, 100.0
	    menu_switch.width, menu_switch.height = 140.0, 100.0
	    group_input_003_12.width, group_input_003_12.height = 140.0, 100.0
	    group_input_004_7.width, group_input_004_7.height = 140.0, 100.0
	    group_input_005_9.width, group_input_005_9.height = 140.0, 100.0
	    final_bake.width, final_bake.height = 140.0, 100.0
	    hair_bake.width, hair_bake.height = 140.0, 100.0
	    group_input_006_8.width, group_input_006_8.height = 140.0, 100.0
	    merge_by_distance_2.width, merge_by_distance_2.height = 140.0, 100.0
	    separate_xyz_3.width, separate_xyz_3.height = 140.0, 100.0
	    group_input_007_6.width, group_input_007_6.height = 140.0, 100.0
	    group_input_008_5.width, group_input_008_5.height = 140.0, 100.0
	    group_input_009_3.width, group_input_009_3.height = 140.0, 100.0
	    compare_11.width, compare_11.height = 140.0, 100.0
	    switch_11.width, switch_11.height = 140.0, 100.0
	    group_input_010_4.width, group_input_010_4.height = 140.0, 100.0
	    reroute_001_11.width, reroute_001_11.height = 10.0, 100.0
	    reroute_002_9.width, reroute_002_9.height = 10.0, 100.0
	    reroute_003_8.width, reroute_003_8.height = 10.0, 100.0
	    reroute_004_9.width, reroute_004_9.height = 10.0, 100.0
	    group_003_3.width, group_003_3.height = 183.602783203125, 100.0
	    group_input_011_2.width, group_input_011_2.height = 140.0, 100.0
	    group_input_012_1.width, group_input_012_1.height = 140.0, 100.0
	    compare_001_4.width, compare_001_4.height = 140.0, 100.0
	    switch_001_9.width, switch_001_9.height = 140.0, 100.0
	    group_input_013_2.width, group_input_013_2.height = 140.0, 100.0
	    group_005_2.width, group_005_2.height = 183.602783203125, 100.0
	    mesh_strip_bake.width, mesh_strip_bake.height = 140.0, 100.0
	    reroute_005_7.width, reroute_005_7.height = 10.0, 100.0
	    mesh_polygon_bake.width, mesh_polygon_bake.height = 140.0, 100.0
	    reroute_006_5.width, reroute_006_5.height = 10.0, 100.0
	    mesh_noise_factor_curve.width, mesh_noise_factor_curve.height = 700.0, 100.0
	    named_attribute_005_1.width, named_attribute_005_1.height = 140.0, 100.0
	    frame_006_4.width, frame_006_4.height = 762.0, 456.0
	    separate_xyz_001_1.width, separate_xyz_001_1.height = 140.0, 100.0
	    map_range_4.width, map_range_4.height = 140.0, 100.0
	    group_input_014_1.width, group_input_014_1.height = 140.0, 100.0
	    reroute_007_5.width, reroute_007_5.height = 10.0, 100.0
	    reroute_008_4.width, reroute_008_4.height = 10.0, 100.0
	    separate_components_2.width, separate_components_2.height = 140.0, 100.0
	    join_geometry_4.width, join_geometry_4.height = 140.0, 100.0
	    reroute_009_4.width, reroute_009_4.height = 10.0, 100.0
	    reroute_010_3.width, reroute_010_3.height = 10.0, 100.0
	    reroute_011_3.width, reroute_011_3.height = 10.0, 100.0
	    reroute_012_5.width, reroute_012_5.height = 10.0, 100.0
	    reroute_013_5.width, reroute_013_5.height = 10.0, 100.0
	    reroute_014_4.width, reroute_014_4.height = 10.0, 100.0
	    reroute_015_4.width, reroute_015_4.height = 10.0, 100.0
	    reroute_016_2.width, reroute_016_2.height = 10.0, 100.0
	    reroute_017_2.width, reroute_017_2.height = 10.0, 100.0
	    reroute_018_2.width, reroute_018_2.height = 10.0, 100.0
	
	    #initialize scalp_hairz links
	    #reroute_14.Output -> group_001_7.Geometry
	    scalp_hairz.links.new(reroute_14.outputs[0], group_001_7.inputs[0])
	    #group_input_18.Surface -> group_8.Surface
	    scalp_hairz.links.new(group_input_18.outputs[1], group_8.inputs[1])
	    #group_input_18.Surface -> group_8.Surface
	    scalp_hairz.links.new(group_input_18.outputs[2], group_8.inputs[2])
	    #group_input_18.Guide Curve -> group_8.Guide Curve
	    scalp_hairz.links.new(group_input_18.outputs[3], group_8.inputs[3])
	    #group_input_18.Guide Curve -> group_8.Guide Curve
	    scalp_hairz.links.new(group_input_18.outputs[4], group_8.inputs[4])
	    #group_input_18.Control Points -> group_8.Control Points
	    scalp_hairz.links.new(group_input_18.outputs[6], group_8.inputs[5])
	    #spline_parameter_001_2.Factor -> hair_shape_2.Value
	    scalp_hairz.links.new(spline_parameter_001_2.outputs[0], hair_shape_2.inputs[1])
	    #spline_parameter_6.Factor -> hair_to_surface_shape_2.Value
	    scalp_hairz.links.new(spline_parameter_6.outputs[0], hair_to_surface_shape_2.inputs[1])
	    #group_input_18.Hair Radius -> group_8.Hair Radius
	    scalp_hairz.links.new(group_input_18.outputs[7], group_8.inputs[6])
	    #hair_shape_2.Value -> group_8.Hair Shape Curve
	    scalp_hairz.links.new(hair_shape_2.outputs[0], group_8.inputs[7])
	    #hair_to_surface_shape_2.Value -> group_8.Offset from Surface
	    scalp_hairz.links.new(hair_to_surface_shape_2.outputs[0], group_8.inputs[12])
	    #group_input_18.Hair Shape Offset -> group_8.Hair Shape Offset
	    scalp_hairz.links.new(group_input_18.outputs[8], group_8.inputs[8])
	    #group_input_18.Sample Surface Count -> group_8.Sample Surface Count
	    scalp_hairz.links.new(group_input_18.outputs[9], group_8.inputs[9])
	    #group_input_18.Sample Surface Distance -> group_8.Sample Surface Distance
	    scalp_hairz.links.new(group_input_18.outputs[10], group_8.inputs[10])
	    #group_input_18.Max Influence Distance -> group_8.Max Influence Distance
	    scalp_hairz.links.new(group_input_18.outputs[11], group_8.inputs[11])
	    #group_input_18.Curve Material -> group_8.Material
	    scalp_hairz.links.new(group_input_18.outputs[12], group_8.inputs[13])
	    #group_input_18.Duplicate Amount -> group_8.Duplicate Amount
	    scalp_hairz.links.new(group_input_18.outputs[13], group_8.inputs[14])
	    #group_input_18.Duplicate Viewport Amount -> group_8.Duplicate Viewport Amount
	    scalp_hairz.links.new(group_input_18.outputs[14], group_8.inputs[15])
	    #group_input_18.Duplicate Radius -> group_8.Duplicate Radius
	    scalp_hairz.links.new(group_input_18.outputs[15], group_8.inputs[16])
	    #group_input_18.Duplicate Distribution Shape -> group_8.Duplicate Distribution Shape
	    scalp_hairz.links.new(group_input_18.outputs[16], group_8.inputs[17])
	    #group_input_18.Duplicate Tip Roundness -> group_8.Duplicate Tip Roundness
	    scalp_hairz.links.new(group_input_18.outputs[17], group_8.inputs[18])
	    #group_input_18.Duplicate Even Thickness -> group_8.Duplicate Even Thickness
	    scalp_hairz.links.new(group_input_18.outputs[18], group_8.inputs[19])
	    #group_input_18.Duplicate Seed -> group_8.Duplicate Seed
	    scalp_hairz.links.new(group_input_18.outputs[19], group_8.inputs[20])
	    #group_input_18.Frizz Factor -> group_8.Frizz Factor
	    scalp_hairz.links.new(group_input_18.outputs[20], group_8.inputs[21])
	    #group_input_18.Frizz Distance -> group_8.Frizz Distance
	    scalp_hairz.links.new(group_input_18.outputs[21], group_8.inputs[22])
	    #group_input_18.Frizz Shape -> group_8.Frizz Shape
	    scalp_hairz.links.new(group_input_18.outputs[22], group_8.inputs[23])
	    #group_input_18.Frizz Seed -> group_8.Frizz Seed
	    scalp_hairz.links.new(group_input_18.outputs[23], group_8.inputs[24])
	    #group_input_18.Noise Surface Offset -> group_8.Noise Surface Offset
	    scalp_hairz.links.new(group_input_18.outputs[24], group_8.inputs[25])
	    #group_input_18.Noise Scale -> group_8.Noise Scale
	    scalp_hairz.links.new(group_input_18.outputs[25], group_8.inputs[26])
	    #group_input_18.Noise Detail -> group_8.Noise Detail
	    scalp_hairz.links.new(group_input_18.outputs[26], group_8.inputs[27])
	    #group_input_18.Noise Roughness -> group_8.Noise Roughness
	    scalp_hairz.links.new(group_input_18.outputs[27], group_8.inputs[28])
	    #group_input_18.Noise Lacunarity -> group_8.Noise Lacunarity
	    scalp_hairz.links.new(group_input_18.outputs[28], group_8.inputs[29])
	    #group_input_18.Noise Distortion -> group_8.Noise Distortion
	    scalp_hairz.links.new(group_input_18.outputs[29], group_8.inputs[30])
	    #group_input_002_12.Surface -> group_001_7.Surface
	    scalp_hairz.links.new(group_input_002_12.outputs[2], group_001_7.inputs[1])
	    #group_input_002_12.Mesh Material -> group_001_7.Material
	    scalp_hairz.links.new(group_input_002_12.outputs[30], group_001_7.inputs[2])
	    #group_input_002_12.Mesh Control Points -> group_001_7.Control Points
	    scalp_hairz.links.new(group_input_002_12.outputs[31], group_001_7.inputs[3])
	    #group_input_002_12.Mesh Width -> group_001_7.Width
	    scalp_hairz.links.new(group_input_002_12.outputs[32], group_001_7.inputs[4])
	    #group_input_002_12.Mesh Guide Merge Distance -> group_001_7.Guide Merge Distance
	    scalp_hairz.links.new(group_input_002_12.outputs[33], group_001_7.inputs[5])
	    #group_input_002_12.Mesh Merge Distance -> group_001_7.Mesh Merge Distance
	    scalp_hairz.links.new(group_input_002_12.outputs[34], group_001_7.inputs[6])
	    #spline_parameter_002.Factor -> mesh_shape.Value
	    scalp_hairz.links.new(spline_parameter_002.outputs[0], mesh_shape.inputs[1])
	    #group_input_002_12.Mesh Surface Offset -> group_001_7.Surface Offset
	    scalp_hairz.links.new(group_input_002_12.outputs[36], group_001_7.inputs[8])
	    #mesh_shape.Value -> group_001_7.Mesh Shape
	    scalp_hairz.links.new(mesh_shape.outputs[0], group_001_7.inputs[9])
	    #mesh_surface_offset_shape.Value -> group_001_7.Surface Offset Shape
	    scalp_hairz.links.new(mesh_surface_offset_shape.outputs[0], group_001_7.inputs[10])
	    #hair_bake.Geometry -> reroute_14.Input
	    scalp_hairz.links.new(hair_bake.outputs[0], reroute_14.inputs[0])
	    #reroute_14.Output -> group_004_3.Geometry
	    scalp_hairz.links.new(reroute_14.outputs[0], group_004_3.inputs[0])
	    #mesh_surface_offset_shape.Value -> group_004_3.Surface Offset Shape
	    scalp_hairz.links.new(mesh_surface_offset_shape.outputs[0], group_004_3.inputs[6])
	    #group_input_003_12.Surface -> group_004_3.Surface
	    scalp_hairz.links.new(group_input_003_12.outputs[2], group_004_3.inputs[1])
	    #group_input_003_12.Mesh Material -> group_004_3.Material
	    scalp_hairz.links.new(group_input_003_12.outputs[30], group_004_3.inputs[2])
	    #group_input_003_12.Mesh Control Points -> group_004_3.Control Points
	    scalp_hairz.links.new(group_input_003_12.outputs[31], group_004_3.inputs[3])
	    #group_input_003_12.Mesh Surface Offset -> group_004_3.Surface Offset
	    scalp_hairz.links.new(group_input_003_12.outputs[36], group_004_3.inputs[5])
	    #final_bake.Geometry -> group_output_23.Geometry
	    scalp_hairz.links.new(final_bake.outputs[0], group_output_23.inputs[0])
	    #group_input_004_7.Hair Style -> menu_switch.Menu
	    scalp_hairz.links.new(group_input_004_7.outputs[5], menu_switch.inputs[0])
	    #group_input_005_9.Mesh Subdivison Level -> group_004_3.Subdivison Level
	    scalp_hairz.links.new(group_input_005_9.outputs[35], group_004_3.inputs[4])
	    #group_8.Geometry -> hair_bake.Geometry
	    scalp_hairz.links.new(group_8.outputs[0], hair_bake.inputs[0])
	    #group_input_006_8.Mesh Subdivison Level -> group_001_7.Subdivision Level
	    scalp_hairz.links.new(group_input_006_8.outputs[35], group_001_7.inputs[7])
	    #group_004_3.Geometry -> merge_by_distance_2.Geometry
	    scalp_hairz.links.new(group_004_3.outputs[0], merge_by_distance_2.inputs[0])
	    #named_attribute_004.Attribute -> separate_xyz_3.Vector
	    scalp_hairz.links.new(named_attribute_004.outputs[0], separate_xyz_3.inputs[0])
	    #separate_xyz_3.X -> mesh_surface_offset_shape.Value
	    scalp_hairz.links.new(separate_xyz_3.outputs[0], mesh_surface_offset_shape.inputs[1])
	    #group_input_009_3.Mesh Guide Merge Distance -> merge_by_distance_2.Distance
	    scalp_hairz.links.new(group_input_009_3.outputs[33], merge_by_distance_2.inputs[2])
	    #compare_11.Result -> switch_11.Switch
	    scalp_hairz.links.new(compare_11.outputs[0], switch_11.inputs[0])
	    #group_input_010_4.Mesh Noise Surface Offset -> compare_11.A
	    scalp_hairz.links.new(group_input_010_4.outputs[37], compare_11.inputs[0])
	    #reroute_008_4.Output -> switch_11.True
	    scalp_hairz.links.new(reroute_008_4.outputs[0], switch_11.inputs[2])
	    #reroute_001_11.Output -> menu_switch.Mesh Polygon
	    scalp_hairz.links.new(reroute_001_11.outputs[0], menu_switch.inputs[3])
	    #reroute_002_9.Output -> reroute_001_11.Input
	    scalp_hairz.links.new(reroute_002_9.outputs[0], reroute_001_11.inputs[0])
	    #reroute_003_8.Output -> reroute_002_9.Input
	    scalp_hairz.links.new(reroute_003_8.outputs[0], reroute_002_9.inputs[0])
	    #reroute_004_9.Output -> reroute_003_8.Input
	    scalp_hairz.links.new(reroute_004_9.outputs[0], reroute_003_8.inputs[0])
	    #switch_11.Output -> reroute_004_9.Input
	    scalp_hairz.links.new(switch_11.outputs[0], reroute_004_9.inputs[0])
	    #reroute_006_5.Output -> group_003_3.Geometry
	    scalp_hairz.links.new(reroute_006_5.outputs[0], group_003_3.inputs[0])
	    #group_input_007_6.Surface -> group_003_3.Surface
	    scalp_hairz.links.new(group_input_007_6.outputs[2], group_003_3.inputs[2])
	    #group_input_008_5.Mesh Noise Scale -> group_003_3.Scale
	    scalp_hairz.links.new(group_input_008_5.outputs[38], group_003_3.inputs[4])
	    #group_input_008_5.Mesh Noise Detail -> group_003_3.Detail
	    scalp_hairz.links.new(group_input_008_5.outputs[39], group_003_3.inputs[5])
	    #group_input_008_5.Mesh Noise Roughness -> group_003_3.Roughness
	    scalp_hairz.links.new(group_input_008_5.outputs[40], group_003_3.inputs[6])
	    #group_input_008_5.Mesh Noise Lacunarity -> group_003_3.Lacunarity
	    scalp_hairz.links.new(group_input_008_5.outputs[41], group_003_3.inputs[7])
	    #group_input_008_5.Mesh Noise Distortion -> group_003_3.Distortion
	    scalp_hairz.links.new(group_input_008_5.outputs[42], group_003_3.inputs[8])
	    #group_003_3.Geometry -> switch_11.False
	    scalp_hairz.links.new(group_003_3.outputs[0], switch_11.inputs[1])
	    #compare_001_4.Result -> switch_001_9.Switch
	    scalp_hairz.links.new(compare_001_4.outputs[0], switch_001_9.inputs[0])
	    #group_input_013_2.Mesh Noise Surface Offset -> compare_001_4.A
	    scalp_hairz.links.new(group_input_013_2.outputs[37], compare_001_4.inputs[0])
	    #group_input_011_2.Surface -> group_005_2.Surface
	    scalp_hairz.links.new(group_input_011_2.outputs[2], group_005_2.inputs[2])
	    #group_input_012_1.Mesh Noise Scale -> group_005_2.Scale
	    scalp_hairz.links.new(group_input_012_1.outputs[38], group_005_2.inputs[4])
	    #group_input_012_1.Mesh Noise Detail -> group_005_2.Detail
	    scalp_hairz.links.new(group_input_012_1.outputs[39], group_005_2.inputs[5])
	    #group_input_012_1.Mesh Noise Roughness -> group_005_2.Roughness
	    scalp_hairz.links.new(group_input_012_1.outputs[40], group_005_2.inputs[6])
	    #group_input_012_1.Mesh Noise Lacunarity -> group_005_2.Lacunarity
	    scalp_hairz.links.new(group_input_012_1.outputs[41], group_005_2.inputs[7])
	    #group_input_012_1.Mesh Noise Distortion -> group_005_2.Distortion
	    scalp_hairz.links.new(group_input_012_1.outputs[42], group_005_2.inputs[8])
	    #group_005_2.Geometry -> switch_001_9.False
	    scalp_hairz.links.new(group_005_2.outputs[0], switch_001_9.inputs[1])
	    #reroute_005_7.Output -> switch_001_9.True
	    scalp_hairz.links.new(reroute_005_7.outputs[0], switch_001_9.inputs[2])
	    #reroute_007_5.Output -> menu_switch.Mesh Strip
	    scalp_hairz.links.new(reroute_007_5.outputs[0], menu_switch.inputs[2])
	    #reroute_14.Output -> menu_switch.Curve Hair
	    scalp_hairz.links.new(reroute_14.outputs[0], menu_switch.inputs[1])
	    #reroute_005_7.Output -> group_005_2.Geometry
	    scalp_hairz.links.new(reroute_005_7.outputs[0], group_005_2.inputs[0])
	    #group_001_7.Geometry -> mesh_strip_bake.Geometry
	    scalp_hairz.links.new(group_001_7.outputs[0], mesh_strip_bake.inputs[0])
	    #mesh_strip_bake.Geometry -> reroute_005_7.Input
	    scalp_hairz.links.new(mesh_strip_bake.outputs[0], reroute_005_7.inputs[0])
	    #merge_by_distance_2.Geometry -> mesh_polygon_bake.Geometry
	    scalp_hairz.links.new(merge_by_distance_2.outputs[0], mesh_polygon_bake.inputs[0])
	    #mesh_polygon_bake.Geometry -> reroute_006_5.Input
	    scalp_hairz.links.new(mesh_polygon_bake.outputs[0], reroute_006_5.inputs[0])
	    #named_attribute_005_1.Attribute -> separate_xyz_001_1.Vector
	    scalp_hairz.links.new(named_attribute_005_1.outputs[0], separate_xyz_001_1.inputs[0])
	    #separate_xyz_001_1.X -> mesh_noise_factor_curve.Value
	    scalp_hairz.links.new(separate_xyz_001_1.outputs[0], mesh_noise_factor_curve.inputs[1])
	    #mesh_noise_factor_curve.Value -> map_range_4.Value
	    scalp_hairz.links.new(mesh_noise_factor_curve.outputs[0], map_range_4.inputs[0])
	    #group_input_014_1.Mesh Noise Surface Offset -> map_range_4.To Max
	    scalp_hairz.links.new(group_input_014_1.outputs[37], map_range_4.inputs[4])
	    #map_range_4.Result -> group_003_3.Surface Offset
	    scalp_hairz.links.new(map_range_4.outputs[0], group_003_3.inputs[3])
	    #map_range_4.Result -> group_005_2.Surface Offset
	    scalp_hairz.links.new(map_range_4.outputs[0], group_005_2.inputs[3])
	    #switch_001_9.Output -> reroute_007_5.Input
	    scalp_hairz.links.new(switch_001_9.outputs[0], reroute_007_5.inputs[0])
	    #reroute_006_5.Output -> reroute_008_4.Input
	    scalp_hairz.links.new(reroute_006_5.outputs[0], reroute_008_4.inputs[0])
	    #group_input_18.Geometry -> separate_components_2.Geometry
	    scalp_hairz.links.new(group_input_18.outputs[0], separate_components_2.inputs[0])
	    #separate_components_2.Curve -> group_8.Geometry
	    scalp_hairz.links.new(separate_components_2.outputs[1], group_8.inputs[0])
	    #reroute_015_4.Output -> join_geometry_4.Geometry
	    scalp_hairz.links.new(reroute_015_4.outputs[0], join_geometry_4.inputs[0])
	    #separate_components_2.Point Cloud -> reroute_009_4.Input
	    scalp_hairz.links.new(separate_components_2.outputs[3], reroute_009_4.inputs[0])
	    #separate_components_2.Instances -> reroute_010_3.Input
	    scalp_hairz.links.new(separate_components_2.outputs[5], reroute_010_3.inputs[0])
	    #separate_components_2.Mesh -> reroute_011_3.Input
	    scalp_hairz.links.new(separate_components_2.outputs[0], reroute_011_3.inputs[0])
	    #separate_components_2.Grease Pencil -> reroute_012_5.Input
	    scalp_hairz.links.new(separate_components_2.outputs[2], reroute_012_5.inputs[0])
	    #separate_components_2.Volume -> reroute_013_5.Input
	    scalp_hairz.links.new(separate_components_2.outputs[4], reroute_013_5.inputs[0])
	    #reroute_009_4.Output -> reroute_014_4.Input
	    scalp_hairz.links.new(reroute_009_4.outputs[0], reroute_014_4.inputs[0])
	    #reroute_010_3.Output -> reroute_015_4.Input
	    scalp_hairz.links.new(reroute_010_3.outputs[0], reroute_015_4.inputs[0])
	    #reroute_011_3.Output -> reroute_016_2.Input
	    scalp_hairz.links.new(reroute_011_3.outputs[0], reroute_016_2.inputs[0])
	    #reroute_013_5.Output -> reroute_017_2.Input
	    scalp_hairz.links.new(reroute_013_5.outputs[0], reroute_017_2.inputs[0])
	    #reroute_012_5.Output -> reroute_018_2.Input
	    scalp_hairz.links.new(reroute_012_5.outputs[0], reroute_018_2.inputs[0])
	    #join_geometry_4.Geometry -> final_bake.Geometry
	    scalp_hairz.links.new(join_geometry_4.outputs[0], final_bake.inputs[0])
	    #reroute_017_2.Output -> join_geometry_4.Geometry
	    scalp_hairz.links.new(reroute_017_2.outputs[0], join_geometry_4.inputs[0])
	    #reroute_014_4.Output -> join_geometry_4.Geometry
	    scalp_hairz.links.new(reroute_014_4.outputs[0], join_geometry_4.inputs[0])
	    #reroute_018_2.Output -> join_geometry_4.Geometry
	    scalp_hairz.links.new(reroute_018_2.outputs[0], join_geometry_4.inputs[0])
	    #reroute_016_2.Output -> join_geometry_4.Geometry
	    scalp_hairz.links.new(reroute_016_2.outputs[0], join_geometry_4.inputs[0])
	    #menu_switch.Output -> join_geometry_4.Geometry
	    scalp_hairz.links.new(menu_switch.outputs[0], join_geometry_4.inputs[0])
	    hair_style_socket.default_value = 'Curve Hair'
	    return scalp_hairz
	return scalp_hairz_node_group()

	

	
