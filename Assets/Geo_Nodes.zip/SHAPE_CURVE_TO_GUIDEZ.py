import bpy, mathutils

def node():
	#initialize curve_attractor node group
	def curve_attractor_node_group():
	    curve_attractor = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Curve_Attractor")
	
	    curve_attractor.color_tag = 'NONE'
	    curve_attractor.description = ""
	    curve_attractor.default_group_node_width = 140
	    
	
	
	    #curve_attractor interface
	    #Socket Geometry
	    geometry_socket = curve_attractor.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket.attribute_domain = 'POINT'
	
	    #Socket Curve
	    curve_socket = curve_attractor.interface.new_socket(name = "Curve", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    curve_socket.attribute_domain = 'POINT'
	
	    #Socket Target Curve
	    target_curve_socket = curve_attractor.interface.new_socket(name = "Target Curve", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    target_curve_socket.attribute_domain = 'POINT'
	
	    #Socket Offset Factor
	    offset_factor_socket = curve_attractor.interface.new_socket(name = "Offset Factor", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    offset_factor_socket.default_value = 0.0
	    offset_factor_socket.min_value = 0.0
	    offset_factor_socket.max_value = 1.0
	    offset_factor_socket.subtype = 'NONE'
	    offset_factor_socket.attribute_domain = 'POINT'
	    offset_factor_socket.hide_value = True
	    offset_factor_socket.hide_in_modifier = True
	
	    #Socket Offset Point
	    offset_point_socket = curve_attractor.interface.new_socket(name = "Offset Point", in_out='INPUT', socket_type = 'NodeSocketInt')
	    offset_point_socket.default_value = 1
	    offset_point_socket.min_value = 0
	    offset_point_socket.max_value = 2147483647
	    offset_point_socket.subtype = 'NONE'
	    offset_point_socket.attribute_domain = 'POINT'
	
	    #Socket Closest Curve Index
	    closest_curve_index_socket = curve_attractor.interface.new_socket(name = "Closest Curve Index", in_out='INPUT', socket_type = 'NodeSocketInt')
	    closest_curve_index_socket.default_value = 0
	    closest_curve_index_socket.min_value = 0
	    closest_curve_index_socket.max_value = 2147483647
	    closest_curve_index_socket.subtype = 'NONE'
	    closest_curve_index_socket.attribute_domain = 'POINT'
	
	
	    #initialize curve_attractor nodes
	    #node Group Output
	    group_output = curve_attractor.nodes.new("NodeGroupOutput")
	    group_output.name = "Group Output"
	    group_output.is_active_output = True
	
	    #node Group Input
	    group_input = curve_attractor.nodes.new("NodeGroupInput")
	    group_input.name = "Group Input"
	    group_input.outputs[0].hide = True
	    group_input.outputs[1].hide = True
	    group_input.outputs[2].hide = True
	    group_input.outputs[3].hide = True
	    group_input.outputs[5].hide = True
	
	    #node Sample Curve
	    sample_curve = curve_attractor.nodes.new("GeometryNodeSampleCurve")
	    sample_curve.name = "Sample Curve"
	    sample_curve.hide = True
	    sample_curve.data_type = 'FLOAT'
	    sample_curve.mode = 'FACTOR'
	    sample_curve.use_all_curves = False
	    #Value
	    sample_curve.inputs[1].default_value = 0.0
	
	    #node Spline Parameter
	    spline_parameter = curve_attractor.nodes.new("GeometryNodeSplineParameter")
	    spline_parameter.name = "Spline Parameter"
	    spline_parameter.outputs[1].hide = True
	    spline_parameter.outputs[2].hide = True
	
	    #node Group Input.002
	    group_input_002 = curve_attractor.nodes.new("NodeGroupInput")
	    group_input_002.name = "Group Input.002"
	    group_input_002.outputs[1].hide = True
	    group_input_002.outputs[2].hide = True
	    group_input_002.outputs[3].hide = True
	    group_input_002.outputs[4].hide = True
	    group_input_002.outputs[5].hide = True
	
	    #node Group Input.003
	    group_input_003 = curve_attractor.nodes.new("NodeGroupInput")
	    group_input_003.name = "Group Input.003"
	    group_input_003.outputs[0].hide = True
	    group_input_003.outputs[2].hide = True
	    group_input_003.outputs[3].hide = True
	    group_input_003.outputs[4].hide = True
	    group_input_003.outputs[5].hide = True
	
	    #node Resample Curve
	    resample_curve = curve_attractor.nodes.new("GeometryNodeResampleCurve")
	    resample_curve.name = "Resample Curve"
	    resample_curve.hide = True
	    resample_curve.keep_last_segment = False
	    resample_curve.mode = 'COUNT'
	    #Selection
	    resample_curve.inputs[1].default_value = True
	
	    #node Group Input.005
	    group_input_005 = curve_attractor.nodes.new("NodeGroupInput")
	    group_input_005.name = "Group Input.005"
	    group_input_005.outputs[0].hide = True
	    group_input_005.outputs[2].hide = True
	    group_input_005.outputs[3].hide = True
	    group_input_005.outputs[4].hide = True
	    group_input_005.outputs[5].hide = True
	
	    #node Domain Size.005
	    domain_size_005 = curve_attractor.nodes.new("GeometryNodeAttributeDomainSize")
	    domain_size_005.name = "Domain Size.005"
	    domain_size_005.hide = True
	    domain_size_005.component = 'CURVE'
	
	    #node Math.005
	    math_005 = curve_attractor.nodes.new("ShaderNodeMath")
	    math_005.name = "Math.005"
	    math_005.hide = True
	    math_005.operation = 'DIVIDE'
	    math_005.use_clamp = False
	
	    #node Frame
	    frame = curve_attractor.nodes.new("NodeFrame")
	    frame.label = "Geometry"
	    frame.name = "Frame"
	    frame.label_size = 20
	    frame.shrink = True
	
	    #node Frame.002
	    frame_002 = curve_attractor.nodes.new("NodeFrame")
	    frame_002.label = "Position"
	    frame_002.name = "Frame.002"
	    frame_002.label_size = 20
	    frame_002.shrink = True
	
	    #node Vector Math
	    vector_math = curve_attractor.nodes.new("ShaderNodeVectorMath")
	    vector_math.name = "Vector Math"
	    vector_math.hide = True
	    vector_math.operation = 'SCALE'
	
	    #node Vector Math.001
	    vector_math_001 = curve_attractor.nodes.new("ShaderNodeVectorMath")
	    vector_math_001.name = "Vector Math.001"
	    vector_math_001.hide = True
	    vector_math_001.operation = 'SUBTRACT'
	
	    #node Set Position.001
	    set_position_001 = curve_attractor.nodes.new("GeometryNodeSetPosition")
	    set_position_001.name = "Set Position.001"
	    set_position_001.hide = True
	    set_position_001.inputs[3].hide = True
	    #Offset
	    set_position_001.inputs[3].default_value = (0.0, 0.0, 0.0)
	
	    #node Capture Attribute.001
	    capture_attribute_001 = curve_attractor.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_001.name = "Capture Attribute.001"
	    capture_attribute_001.hide = True
	    capture_attribute_001.active_index = 0
	    capture_attribute_001.capture_items.clear()
	    capture_attribute_001.capture_items.new('FLOAT', "Position")
	    capture_attribute_001.capture_items["Position"].data_type = 'FLOAT_VECTOR'
	    capture_attribute_001.domain = 'POINT'
	
	    #node Position.001
	    position_001 = curve_attractor.nodes.new("GeometryNodeInputPosition")
	    position_001.name = "Position.001"
	
	    #node Set Position.002
	    set_position_002 = curve_attractor.nodes.new("GeometryNodeSetPosition")
	    set_position_002.name = "Set Position.002"
	    set_position_002.inputs[1].hide = True
	    set_position_002.inputs[2].hide = True
	    #Selection
	    set_position_002.inputs[1].default_value = True
	    #Position
	    set_position_002.inputs[2].default_value = (0.0, 0.0, 0.0)
	
	    #node Reroute
	    reroute = curve_attractor.nodes.new("NodeReroute")
	    reroute.name = "Reroute"
	    reroute.socket_idname = "NodeSocketVector"
	    #node Reroute.001
	    reroute_001 = curve_attractor.nodes.new("NodeReroute")
	    reroute_001.name = "Reroute.001"
	    reroute_001.socket_idname = "NodeSocketVector"
	    #node Reroute.002
	    reroute_002 = curve_attractor.nodes.new("NodeReroute")
	    reroute_002.name = "Reroute.002"
	    reroute_002.socket_idname = "NodeSocketVector"
	    #node Group Input.004
	    group_input_004 = curve_attractor.nodes.new("NodeGroupInput")
	    group_input_004.name = "Group Input.004"
	    group_input_004.outputs[0].hide = True
	    group_input_004.outputs[1].hide = True
	    group_input_004.outputs[3].hide = True
	    group_input_004.outputs[4].hide = True
	    group_input_004.outputs[5].hide = True
	
	    #node Endpoint Selection
	    endpoint_selection = curve_attractor.nodes.new("GeometryNodeCurveEndpointSelection")
	    endpoint_selection.name = "Endpoint Selection"
	    endpoint_selection.inputs[1].hide = True
	    #End Size
	    endpoint_selection.inputs[1].default_value = 0
	
	    #node Boolean Math
	    boolean_math = curve_attractor.nodes.new("FunctionNodeBooleanMath")
	    boolean_math.name = "Boolean Math"
	    boolean_math.hide = True
	    boolean_math.operation = 'NOT'
	
	    #node Set Position.003
	    set_position_003 = curve_attractor.nodes.new("GeometryNodeSetPosition")
	    set_position_003.name = "Set Position.003"
	    set_position_003.inputs[3].hide = True
	    #Offset
	    set_position_003.inputs[3].default_value = (0.0, 0.0, 0.0)
	
	    #node Reroute.004
	    reroute_004 = curve_attractor.nodes.new("NodeReroute")
	    reroute_004.name = "Reroute.004"
	    reroute_004.socket_idname = "NodeSocketVector"
	    #node Reroute.005
	    reroute_005 = curve_attractor.nodes.new("NodeReroute")
	    reroute_005.name = "Reroute.005"
	    reroute_005.socket_idname = "NodeSocketVector"
	    #node Reroute.006
	    reroute_006 = curve_attractor.nodes.new("NodeReroute")
	    reroute_006.name = "Reroute.006"
	    reroute_006.socket_idname = "NodeSocketVector"
	    #node Reroute.007
	    reroute_007 = curve_attractor.nodes.new("NodeReroute")
	    reroute_007.name = "Reroute.007"
	    reroute_007.socket_idname = "NodeSocketBool"
	    #node Reroute.008
	    reroute_008 = curve_attractor.nodes.new("NodeReroute")
	    reroute_008.name = "Reroute.008"
	    reroute_008.socket_idname = "NodeSocketBool"
	    #node Group Input.001
	    group_input_001 = curve_attractor.nodes.new("NodeGroupInput")
	    group_input_001.name = "Group Input.001"
	    group_input_001.outputs[0].hide = True
	    group_input_001.outputs[1].hide = True
	    group_input_001.outputs[2].hide = True
	    group_input_001.outputs[4].hide = True
	    group_input_001.outputs[5].hide = True
	
	    #node Math
	    math = curve_attractor.nodes.new("ShaderNodeMath")
	    math.name = "Math"
	    math.hide = True
	    math.operation = 'ADD'
	    math.use_clamp = False
	    math.inputs[1].hide = True
	    math.inputs[2].hide = True
	    #Value_001
	    math.inputs[1].default_value = 1.0
	
	
	
	
	    #Set parents
	    group_input.parent = frame_002
	    sample_curve.parent = frame_002
	    spline_parameter.parent = frame_002
	    group_input_002.parent = frame
	    group_input_003.parent = frame_002
	    resample_curve.parent = frame
	    group_input_005.parent = frame
	    domain_size_005.parent = frame
	    math_005.parent = frame
	
	    #Set locations
	    group_output.location = (1252.7728271484375, 169.1415252685547)
	    group_input.location = (30.187042236328125, -123.64524841308594)
	    sample_curve.location = (200.72720336914062, -103.29527282714844)
	    spline_parameter.location = (197.67129516601562, -39.73517608642578)
	    group_input_002.location = (360.2132873535156, -39.865325927734375)
	    group_input_003.location = (33.06707763671875, -66.12847137451172)
	    resample_curve.location = (540.4117431640625, -78.47219848632812)
	    group_input_005.location = (30.086090087890625, -81.01583862304688)
	    domain_size_005.location = (195.9091796875, -104.75875854492188)
	    math_005.location = (358.9772644042969, -104.2315673828125)
	    frame.location = (-407.0, 184.0)
	    frame_002.location = (101.0, 1.0)
	    vector_math.location = (711.2145385742188, 19.329330444335938)
	    vector_math_001.location = (709.9968872070312, -14.269463539123535)
	    set_position_001.location = (545.6182861328125, 95.52835845947266)
	    capture_attribute_001.location = (330.7835998535156, 96.59638977050781)
	    position_001.location = (330.7835388183594, 63.05186462402344)
	    set_position_002.location = (853.4332885742188, 145.01251220703125)
	    reroute.location = (549.6845092773438, -108.51962280273438)
	    reroute_001.location = (498.0160827636719, -19.71049690246582)
	    reroute_002.location = (495.68212890625, 86.8971939086914)
	    group_input_004.location = (705.1908569335938, 78.49667358398438)
	    endpoint_selection.location = (401.55755615234375, -246.674072265625)
	    boolean_math.location = (402.7728576660156, -215.4364471435547)
	    set_position_003.location = (1072.35498046875, 170.05712890625)
	    reroute_004.location = (1049.6480712890625, 67.91584777832031)
	    reroute_005.location = (1052.0789794921875, -51.60334777832031)
	    reroute_006.location = (498.9603576660156, -56.537498474121094)
	    reroute_007.location = (1019.3714599609375, 88.4566650390625)
	    reroute_008.location = (1027.7366943359375, -276.3819885253906)
	    group_input_001.location = (68.6279296875, -271.6609191894531)
	    math.location = (239.40084838867188, -293.97125244140625)
	
	    #Set dimensions
	    group_output.width, group_output.height = 140.0, 100.0
	    group_input.width, group_input.height = 140.0, 100.0
	    sample_curve.width, sample_curve.height = 140.0, 100.0
	    spline_parameter.width, spline_parameter.height = 140.0, 100.0
	    group_input_002.width, group_input_002.height = 140.0, 100.0
	    group_input_003.width, group_input_003.height = 140.0, 100.0
	    resample_curve.width, resample_curve.height = 140.0, 100.0
	    group_input_005.width, group_input_005.height = 140.0, 100.0
	    domain_size_005.width, domain_size_005.height = 140.0, 100.0
	    math_005.width, math_005.height = 140.0, 100.0
	    frame.width, frame.height = 710.0, 163.0
	    frame_002.width, frame_002.height = 371.0, 206.0
	    vector_math.width, vector_math.height = 140.0, 100.0
	    vector_math_001.width, vector_math_001.height = 140.0, 100.0
	    set_position_001.width, set_position_001.height = 140.0, 100.0
	    capture_attribute_001.width, capture_attribute_001.height = 140.0, 100.0
	    position_001.width, position_001.height = 140.0, 100.0
	    set_position_002.width, set_position_002.height = 140.0, 100.0
	    reroute.width, reroute.height = 10.0, 100.0
	    reroute_001.width, reroute_001.height = 10.0, 100.0
	    reroute_002.width, reroute_002.height = 10.0, 100.0
	    group_input_004.width, group_input_004.height = 140.0, 100.0
	    endpoint_selection.width, endpoint_selection.height = 140.0, 100.0
	    boolean_math.width, boolean_math.height = 140.0, 100.0
	    set_position_003.width, set_position_003.height = 140.0, 100.0
	    reroute_004.width, reroute_004.height = 10.0, 100.0
	    reroute_005.width, reroute_005.height = 10.0, 100.0
	    reroute_006.width, reroute_006.height = 10.0, 100.0
	    reroute_007.width, reroute_007.height = 10.0, 100.0
	    reroute_008.width, reroute_008.height = 10.0, 100.0
	    group_input_001.width, group_input_001.height = 140.0, 100.0
	    math.width, math.height = 140.0, 100.0
	
	    #initialize curve_attractor links
	    #spline_parameter.Factor -> sample_curve.Factor
	    curve_attractor.links.new(spline_parameter.outputs[0], sample_curve.inputs[2])
	    #set_position_003.Geometry -> group_output.Geometry
	    curve_attractor.links.new(set_position_003.outputs[0], group_output.inputs[0])
	    #group_input_003.Target Curve -> sample_curve.Curves
	    curve_attractor.links.new(group_input_003.outputs[1], sample_curve.inputs[0])
	    #group_input_005.Target Curve -> domain_size_005.Geometry
	    curve_attractor.links.new(group_input_005.outputs[1], domain_size_005.inputs[0])
	    #domain_size_005.Point Count -> math_005.Value
	    curve_attractor.links.new(domain_size_005.outputs[0], math_005.inputs[0])
	    #domain_size_005.Spline Count -> math_005.Value
	    curve_attractor.links.new(domain_size_005.outputs[4], math_005.inputs[1])
	    #group_input_002.Curve -> resample_curve.Curve
	    curve_attractor.links.new(group_input_002.outputs[0], resample_curve.inputs[0])
	    #math_005.Value -> resample_curve.Count
	    curve_attractor.links.new(math_005.outputs[0], resample_curve.inputs[2])
	    #vector_math_001.Vector -> vector_math.Vector
	    curve_attractor.links.new(vector_math_001.outputs[0], vector_math.inputs[0])
	    #reroute.Output -> set_position_001.Position
	    curve_attractor.links.new(reroute.outputs[0], set_position_001.inputs[2])
	    #capture_attribute_001.Geometry -> set_position_001.Geometry
	    curve_attractor.links.new(capture_attribute_001.outputs[0], set_position_001.inputs[0])
	    #resample_curve.Curve -> capture_attribute_001.Geometry
	    curve_attractor.links.new(resample_curve.outputs[0], capture_attribute_001.inputs[0])
	    #position_001.Position -> capture_attribute_001.Position
	    curve_attractor.links.new(position_001.outputs[0], capture_attribute_001.inputs[1])
	    #vector_math.Vector -> set_position_002.Offset
	    curve_attractor.links.new(vector_math.outputs[0], set_position_002.inputs[3])
	    #set_position_001.Geometry -> set_position_002.Geometry
	    curve_attractor.links.new(set_position_001.outputs[0], set_position_002.inputs[0])
	    #sample_curve.Position -> reroute.Input
	    curve_attractor.links.new(sample_curve.outputs[1], reroute.inputs[0])
	    #reroute_002.Output -> reroute_001.Input
	    curve_attractor.links.new(reroute_002.outputs[0], reroute_001.inputs[0])
	    #capture_attribute_001.Position -> reroute_002.Input
	    curve_attractor.links.new(capture_attribute_001.outputs[1], reroute_002.inputs[0])
	    #group_input.Closest Curve Index -> sample_curve.Curve Index
	    curve_attractor.links.new(group_input.outputs[4], sample_curve.inputs[4])
	    #group_input_004.Offset Factor -> vector_math.Scale
	    curve_attractor.links.new(group_input_004.outputs[2], vector_math.inputs[3])
	    #endpoint_selection.Selection -> boolean_math.Boolean
	    curve_attractor.links.new(endpoint_selection.outputs[0], boolean_math.inputs[0])
	    #boolean_math.Boolean -> set_position_001.Selection
	    curve_attractor.links.new(boolean_math.outputs[0], set_position_001.inputs[1])
	    #set_position_002.Geometry -> set_position_003.Geometry
	    curve_attractor.links.new(set_position_002.outputs[0], set_position_003.inputs[0])
	    #reroute_004.Output -> set_position_003.Position
	    curve_attractor.links.new(reroute_004.outputs[0], set_position_003.inputs[2])
	    #reroute_005.Output -> reroute_004.Input
	    curve_attractor.links.new(reroute_005.outputs[0], reroute_004.inputs[0])
	    #reroute_006.Output -> reroute_005.Input
	    curve_attractor.links.new(reroute_006.outputs[0], reroute_005.inputs[0])
	    #reroute_001.Output -> reroute_006.Input
	    curve_attractor.links.new(reroute_001.outputs[0], reroute_006.inputs[0])
	    #reroute_007.Output -> set_position_003.Selection
	    curve_attractor.links.new(reroute_007.outputs[0], set_position_003.inputs[1])
	    #reroute_008.Output -> reroute_007.Input
	    curve_attractor.links.new(reroute_008.outputs[0], reroute_007.inputs[0])
	    #endpoint_selection.Selection -> reroute_008.Input
	    curve_attractor.links.new(endpoint_selection.outputs[0], reroute_008.inputs[0])
	    #math.Value -> endpoint_selection.Start Size
	    curve_attractor.links.new(math.outputs[0], endpoint_selection.inputs[0])
	    #group_input_001.Offset Point -> math.Value
	    curve_attractor.links.new(group_input_001.outputs[3], math.inputs[0])
	    #reroute.Output -> vector_math_001.Vector
	    curve_attractor.links.new(reroute.outputs[0], vector_math_001.inputs[1])
	    #reroute_001.Output -> vector_math_001.Vector
	    curve_attractor.links.new(reroute_001.outputs[0], vector_math_001.inputs[0])
	    return curve_attractor
	
	curve_attractor = curve_attractor_node_group()
	
	#initialize curve_geometry_priority node group
	def curve_geometry_priority_node_group():
	    curve_geometry_priority = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Curve Geometry Priority")
	
	    curve_geometry_priority.color_tag = 'NONE'
	    curve_geometry_priority.description = ""
	    curve_geometry_priority.default_group_node_width = 140
	    
	
	
	    #curve_geometry_priority interface
	    #Socket Geometry
	    geometry_socket_1 = curve_geometry_priority.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_1.attribute_domain = 'POINT'
	
	    #Socket Geometry
	    geometry_socket_2 = curve_geometry_priority.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_2.attribute_domain = 'POINT'
	
	    #Socket Object
	    object_socket = curve_geometry_priority.interface.new_socket(name = "Object", in_out='INPUT', socket_type = 'NodeSocketObject')
	    object_socket.attribute_domain = 'POINT'
	
	
	    #initialize curve_geometry_priority nodes
	    #node Group Output
	    group_output_1 = curve_geometry_priority.nodes.new("NodeGroupOutput")
	    group_output_1.name = "Group Output"
	    group_output_1.is_active_output = True
	
	    #node Group Input
	    group_input_1 = curve_geometry_priority.nodes.new("NodeGroupInput")
	    group_input_1.name = "Group Input"
	
	    #node Object Info
	    object_info = curve_geometry_priority.nodes.new("GeometryNodeObjectInfo")
	    object_info.name = "Object Info"
	    object_info.hide = True
	    object_info.transform_space = 'RELATIVE'
	    object_info.inputs[1].hide = True
	    object_info.outputs[0].hide = True
	    object_info.outputs[1].hide = True
	    object_info.outputs[2].hide = True
	    object_info.outputs[3].hide = True
	    #As Instance
	    object_info.inputs[1].default_value = False
	
	    #node Switch.001
	    switch_001 = curve_geometry_priority.nodes.new("GeometryNodeSwitch")
	    switch_001.name = "Switch.001"
	    switch_001.hide = True
	    switch_001.input_type = 'GEOMETRY'
	
	    #node Domain Size
	    domain_size = curve_geometry_priority.nodes.new("GeometryNodeAttributeDomainSize")
	    domain_size.name = "Domain Size"
	    domain_size.hide = True
	    domain_size.component = 'CURVE'
	    domain_size.outputs[1].hide = True
	    domain_size.outputs[2].hide = True
	    domain_size.outputs[3].hide = True
	    domain_size.outputs[4].hide = True
	    domain_size.outputs[5].hide = True
	    domain_size.outputs[6].hide = True
	
	    #node Compare.002
	    compare_002 = curve_geometry_priority.nodes.new("FunctionNodeCompare")
	    compare_002.name = "Compare.002"
	    compare_002.hide = True
	    compare_002.data_type = 'FLOAT'
	    compare_002.mode = 'ELEMENT'
	    compare_002.operation = 'EQUAL'
	    #B
	    compare_002.inputs[1].default_value = 0.0
	    #Epsilon
	    compare_002.inputs[12].default_value = 0.0
	
	    #node Reroute
	    reroute_1 = curve_geometry_priority.nodes.new("NodeReroute")
	    reroute_1.name = "Reroute"
	    reroute_1.socket_idname = "NodeSocketGeometry"
	
	
	
	
	    #Set locations
	    group_output_1.location = (331.4979553222656, 0.0)
	    group_input_1.location = (-341.49798583984375, 0.0)
	    object_info.location = (-141.49798583984375, -48.543128967285156)
	    switch_001.location = (141.49795532226562, -25.427536010742188)
	    domain_size.location = (-37.58526611328125, 25.427532196044922)
	    compare_002.location = (138.00750732421875, 13.003349304199219)
	    reroute_1.location = (-98.26019287109375, -34.39356231689453)
	
	    #Set dimensions
	    group_output_1.width, group_output_1.height = 140.0, 100.0
	    group_input_1.width, group_input_1.height = 140.0, 100.0
	    object_info.width, object_info.height = 140.0, 100.0
	    switch_001.width, switch_001.height = 140.0, 100.0
	    domain_size.width, domain_size.height = 140.0, 100.0
	    compare_002.width, compare_002.height = 140.0, 100.0
	    reroute_1.width, reroute_1.height = 10.0, 100.0
	
	    #initialize curve_geometry_priority links
	    #reroute_1.Output -> domain_size.Geometry
	    curve_geometry_priority.links.new(reroute_1.outputs[0], domain_size.inputs[0])
	    #domain_size.Point Count -> compare_002.A
	    curve_geometry_priority.links.new(domain_size.outputs[0], compare_002.inputs[0])
	    #compare_002.Result -> switch_001.Switch
	    curve_geometry_priority.links.new(compare_002.outputs[0], switch_001.inputs[0])
	    #object_info.Geometry -> switch_001.True
	    curve_geometry_priority.links.new(object_info.outputs[4], switch_001.inputs[2])
	    #reroute_1.Output -> switch_001.False
	    curve_geometry_priority.links.new(reroute_1.outputs[0], switch_001.inputs[1])
	    #group_input_1.Object -> object_info.Object
	    curve_geometry_priority.links.new(group_input_1.outputs[1], object_info.inputs[0])
	    #group_input_1.Geometry -> reroute_1.Input
	    curve_geometry_priority.links.new(group_input_1.outputs[0], reroute_1.inputs[0])
	    #switch_001.Output -> group_output_1.Geometry
	    curve_geometry_priority.links.new(switch_001.outputs[0], group_output_1.inputs[0])
	    return curve_geometry_priority
	
	curve_geometry_priority = curve_geometry_priority_node_group()
	
	#initialize curve_root node group
	def curve_root_node_group():
	    curve_root = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Curve Root")
	
	    curve_root.color_tag = 'INPUT'
	    curve_root.description = ""
	    curve_root.default_group_node_width = 140
	    
	
	
	    #curve_root interface
	    #Socket Root Selection
	    root_selection_socket = curve_root.interface.new_socket(name = "Root Selection", in_out='OUTPUT', socket_type = 'NodeSocketBool')
	    root_selection_socket.default_value = False
	    root_selection_socket.attribute_domain = 'POINT'
	    root_selection_socket.description = "Boolean selection of curve root points"
	
	    #Socket Root Position
	    root_position_socket = curve_root.interface.new_socket(name = "Root Position", in_out='OUTPUT', socket_type = 'NodeSocketVector')
	    root_position_socket.default_value = (0.0, 0.0, 0.0)
	    root_position_socket.min_value = -3.4028234663852886e+38
	    root_position_socket.max_value = 3.4028234663852886e+38
	    root_position_socket.subtype = 'NONE'
	    root_position_socket.attribute_domain = 'CURVE'
	    root_position_socket.description = "Position of the root point of a curve"
	
	    #Socket Root Direction
	    root_direction_socket = curve_root.interface.new_socket(name = "Root Direction", in_out='OUTPUT', socket_type = 'NodeSocketVector')
	    root_direction_socket.default_value = (0.0, 0.0, 0.0)
	    root_direction_socket.min_value = -3.4028234663852886e+38
	    root_direction_socket.max_value = 3.4028234663852886e+38
	    root_direction_socket.subtype = 'NONE'
	    root_direction_socket.attribute_domain = 'CURVE'
	    root_direction_socket.description = "Direction of the root segment of a curve"
	
	    #Socket Root Index
	    root_index_socket = curve_root.interface.new_socket(name = "Root Index", in_out='OUTPUT', socket_type = 'NodeSocketInt')
	    root_index_socket.default_value = 0
	    root_index_socket.min_value = -2147483648
	    root_index_socket.max_value = 2147483647
	    root_index_socket.subtype = 'NONE'
	    root_index_socket.attribute_domain = 'CURVE'
	    root_index_socket.description = "Index of the root point of a curve"
	
	
	    #initialize curve_root nodes
	    #node Position.002
	    position_002 = curve_root.nodes.new("GeometryNodeInputPosition")
	    position_002.name = "Position.002"
	
	    #node Interpolate Domain
	    interpolate_domain = curve_root.nodes.new("GeometryNodeFieldOnDomain")
	    interpolate_domain.name = "Interpolate Domain"
	    interpolate_domain.data_type = 'INT'
	    interpolate_domain.domain = 'CURVE'
	
	    #node Field at Index.003
	    field_at_index_003 = curve_root.nodes.new("GeometryNodeFieldAtIndex")
	    field_at_index_003.name = "Field at Index.003"
	    field_at_index_003.data_type = 'FLOAT_VECTOR'
	    field_at_index_003.domain = 'POINT'
	
	    #node Interpolate Domain.001
	    interpolate_domain_001 = curve_root.nodes.new("GeometryNodeFieldOnDomain")
	    interpolate_domain_001.name = "Interpolate Domain.001"
	    interpolate_domain_001.data_type = 'FLOAT_VECTOR'
	    interpolate_domain_001.domain = 'CURVE'
	
	    #node Curve Tangent
	    curve_tangent = curve_root.nodes.new("GeometryNodeInputTangent")
	    curve_tangent.name = "Curve Tangent"
	
	    #node Endpoint Selection
	    endpoint_selection_1 = curve_root.nodes.new("GeometryNodeCurveEndpointSelection")
	    endpoint_selection_1.name = "Endpoint Selection"
	    #Start Size
	    endpoint_selection_1.inputs[0].default_value = 1
	    #End Size
	    endpoint_selection_1.inputs[1].default_value = 0
	
	    #node Field at Index.004
	    field_at_index_004 = curve_root.nodes.new("GeometryNodeFieldAtIndex")
	    field_at_index_004.name = "Field at Index.004"
	    field_at_index_004.data_type = 'FLOAT_VECTOR'
	    field_at_index_004.domain = 'POINT'
	
	    #node Interpolate Domain.002
	    interpolate_domain_002 = curve_root.nodes.new("GeometryNodeFieldOnDomain")
	    interpolate_domain_002.name = "Interpolate Domain.002"
	    interpolate_domain_002.data_type = 'FLOAT_VECTOR'
	    interpolate_domain_002.domain = 'CURVE'
	
	    #node Group Output
	    group_output_2 = curve_root.nodes.new("NodeGroupOutput")
	    group_output_2.name = "Group Output"
	    group_output_2.is_active_output = True
	
	    #node Points of Curve
	    points_of_curve = curve_root.nodes.new("GeometryNodePointsOfCurve")
	    points_of_curve.name = "Points of Curve"
	    points_of_curve.inputs[0].hide = True
	    points_of_curve.inputs[1].hide = True
	    points_of_curve.outputs[1].hide = True
	    #Curve Index
	    points_of_curve.inputs[0].default_value = 0
	    #Weights
	    points_of_curve.inputs[1].default_value = 0.0
	    #Sort Index
	    points_of_curve.inputs[2].default_value = 0
	
	
	
	
	
	    #Set locations
	    position_002.location = (-608.1627807617188, -70.55814361572266)
	    interpolate_domain.location = (-608.1627807617188, 90.18604278564453)
	    field_at_index_003.location = (-407.2325439453125, 70.09302520751953)
	    interpolate_domain_001.location = (-206.30230712890625, 70.09302520751953)
	    curve_tangent.location = (-608.1627807617188, -271.4883728027344)
	    endpoint_selection_1.location = (-206.30230712890625, 190.65118408203125)
	    field_at_index_004.location = (-407.2325439453125, -130.83721923828125)
	    interpolate_domain_002.location = (-206.30230712890625, -130.83721923828125)
	    group_output_2.location = (75.0, 50.0)
	    points_of_curve.location = (-789.0, 50.0)
	
	    #Set dimensions
	    position_002.width, position_002.height = 140.0, 100.0
	    interpolate_domain.width, interpolate_domain.height = 140.0, 100.0
	    field_at_index_003.width, field_at_index_003.height = 140.0, 100.0
	    interpolate_domain_001.width, interpolate_domain_001.height = 140.0, 100.0
	    curve_tangent.width, curve_tangent.height = 140.0, 100.0
	    endpoint_selection_1.width, endpoint_selection_1.height = 140.0, 100.0
	    field_at_index_004.width, field_at_index_004.height = 140.0, 100.0
	    interpolate_domain_002.width, interpolate_domain_002.height = 140.0, 100.0
	    group_output_2.width, group_output_2.height = 140.0, 100.0
	    points_of_curve.width, points_of_curve.height = 140.0, 100.0
	
	    #initialize curve_root links
	    #position_002.Position -> field_at_index_003.Value
	    curve_root.links.new(position_002.outputs[0], field_at_index_003.inputs[1])
	    #interpolate_domain_001.Value -> group_output_2.Root Position
	    curve_root.links.new(interpolate_domain_001.outputs[0], group_output_2.inputs[1])
	    #interpolate_domain.Value -> field_at_index_003.Index
	    curve_root.links.new(interpolate_domain.outputs[0], field_at_index_003.inputs[0])
	    #points_of_curve.Point Index -> interpolate_domain.Value
	    curve_root.links.new(points_of_curve.outputs[0], interpolate_domain.inputs[0])
	    #interpolate_domain.Value -> group_output_2.Root Index
	    curve_root.links.new(interpolate_domain.outputs[0], group_output_2.inputs[3])
	    #endpoint_selection_1.Selection -> group_output_2.Root Selection
	    curve_root.links.new(endpoint_selection_1.outputs[0], group_output_2.inputs[0])
	    #field_at_index_003.Value -> interpolate_domain_001.Value
	    curve_root.links.new(field_at_index_003.outputs[0], interpolate_domain_001.inputs[0])
	    #interpolate_domain_002.Value -> group_output_2.Root Direction
	    curve_root.links.new(interpolate_domain_002.outputs[0], group_output_2.inputs[2])
	    #interpolate_domain.Value -> field_at_index_004.Index
	    curve_root.links.new(interpolate_domain.outputs[0], field_at_index_004.inputs[0])
	    #curve_tangent.Tangent -> field_at_index_004.Value
	    curve_root.links.new(curve_tangent.outputs[0], field_at_index_004.inputs[1])
	    #field_at_index_004.Value -> interpolate_domain_002.Value
	    curve_root.links.new(field_at_index_004.outputs[0], interpolate_domain_002.inputs[0])
	    return curve_root
	
	curve_root = curve_root_node_group()
	
	#initialize curve_segment node group
	def curve_segment_node_group():
	    curve_segment = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Curve Segment")
	
	    curve_segment.color_tag = 'INPUT'
	    curve_segment.description = ""
	    curve_segment.default_group_node_width = 140
	    
	
	
	    #curve_segment interface
	    #Socket Segment Length
	    segment_length_socket = curve_segment.interface.new_socket(name = "Segment Length", in_out='OUTPUT', socket_type = 'NodeSocketFloat')
	    segment_length_socket.default_value = 0.0
	    segment_length_socket.min_value = -3.4028234663852886e+38
	    segment_length_socket.max_value = 3.4028234663852886e+38
	    segment_length_socket.subtype = 'NONE'
	    segment_length_socket.attribute_domain = 'POINT'
	    segment_length_socket.description = "Distance to previous point on curve"
	
	    #Socket Segment Direction
	    segment_direction_socket = curve_segment.interface.new_socket(name = "Segment Direction", in_out='OUTPUT', socket_type = 'NodeSocketVector')
	    segment_direction_socket.default_value = (0.0, 0.0, 0.0)
	    segment_direction_socket.min_value = -3.4028234663852886e+38
	    segment_direction_socket.max_value = 3.4028234663852886e+38
	    segment_direction_socket.subtype = 'NONE'
	    segment_direction_socket.attribute_domain = 'POINT'
	    segment_direction_socket.description = "Direction from previous neighboring point on segment"
	
	    #Socket Neighbor Index
	    neighbor_index_socket = curve_segment.interface.new_socket(name = "Neighbor Index", in_out='OUTPUT', socket_type = 'NodeSocketInt')
	    neighbor_index_socket.default_value = 0
	    neighbor_index_socket.min_value = -2147483648
	    neighbor_index_socket.max_value = 2147483647
	    neighbor_index_socket.subtype = 'NONE'
	    neighbor_index_socket.attribute_domain = 'POINT'
	    neighbor_index_socket.description = "Index of previous neighboring point on segment"
	
	
	    #initialize curve_segment nodes
	    #node Vector Math.009
	    vector_math_009 = curve_segment.nodes.new("ShaderNodeVectorMath")
	    vector_math_009.name = "Vector Math.009"
	    vector_math_009.operation = 'NORMALIZE'
	
	    #node Reroute.015
	    reroute_015 = curve_segment.nodes.new("NodeReroute")
	    reroute_015.name = "Reroute.015"
	    reroute_015.socket_idname = "NodeSocketVector"
	    #node Reroute.017
	    reroute_017 = curve_segment.nodes.new("NodeReroute")
	    reroute_017.name = "Reroute.017"
	    reroute_017.socket_idname = "NodeSocketVector"
	    #node Field at Index.001
	    field_at_index_001 = curve_segment.nodes.new("GeometryNodeFieldAtIndex")
	    field_at_index_001.name = "Field at Index.001"
	    field_at_index_001.data_type = 'FLOAT_VECTOR'
	    field_at_index_001.domain = 'POINT'
	
	    #node Vector Math.008
	    vector_math_008 = curve_segment.nodes.new("ShaderNodeVectorMath")
	    vector_math_008.name = "Vector Math.008"
	    vector_math_008.operation = 'SUBTRACT'
	
	    #node Reroute.018
	    reroute_018 = curve_segment.nodes.new("NodeReroute")
	    reroute_018.name = "Reroute.018"
	    reroute_018.socket_idname = "NodeSocketInt"
	    #node Interpolate Domain.002
	    interpolate_domain_002_1 = curve_segment.nodes.new("GeometryNodeFieldOnDomain")
	    interpolate_domain_002_1.name = "Interpolate Domain.002"
	    interpolate_domain_002_1.data_type = 'FLOAT_VECTOR'
	    interpolate_domain_002_1.domain = 'POINT'
	
	    #node Group Output
	    group_output_3 = curve_segment.nodes.new("NodeGroupOutput")
	    group_output_3.name = "Group Output"
	    group_output_3.is_active_output = True
	
	    #node Vector Math.007
	    vector_math_007 = curve_segment.nodes.new("ShaderNodeVectorMath")
	    vector_math_007.name = "Vector Math.007"
	    vector_math_007.operation = 'LENGTH'
	
	    #node Interpolate Domain.003
	    interpolate_domain_003 = curve_segment.nodes.new("GeometryNodeFieldOnDomain")
	    interpolate_domain_003.name = "Interpolate Domain.003"
	    interpolate_domain_003.data_type = 'INT'
	    interpolate_domain_003.domain = 'POINT'
	
	    #node Reroute
	    reroute_2 = curve_segment.nodes.new("NodeReroute")
	    reroute_2.name = "Reroute"
	    reroute_2.socket_idname = "NodeSocketBool"
	    #node Switch.004
	    switch_004 = curve_segment.nodes.new("GeometryNodeSwitch")
	    switch_004.name = "Switch.004"
	    switch_004.hide = True
	    switch_004.input_type = 'VECTOR'
	    #False
	    switch_004.inputs[1].default_value = (0.0, 0.0, 0.0)
	
	    #node Switch.003
	    switch_003 = curve_segment.nodes.new("GeometryNodeSwitch")
	    switch_003.name = "Switch.003"
	    switch_003.hide = True
	    switch_003.input_type = 'FLOAT'
	    #False
	    switch_003.inputs[1].default_value = 0.0
	
	    #node Boolean
	    boolean = curve_segment.nodes.new("FunctionNodeInputBool")
	    boolean.name = "Boolean"
	    boolean.boolean = True
	
	    #node Interpolate Domain
	    interpolate_domain_1 = curve_segment.nodes.new("GeometryNodeFieldOnDomain")
	    interpolate_domain_1.name = "Interpolate Domain"
	    interpolate_domain_1.data_type = 'BOOLEAN'
	    interpolate_domain_1.domain = 'CURVE'
	
	    #node Switch.005
	    switch_005 = curve_segment.nodes.new("GeometryNodeSwitch")
	    switch_005.name = "Switch.005"
	    switch_005.hide = True
	    switch_005.input_type = 'INT'
	    #False
	    switch_005.inputs[1].default_value = 0
	
	    #node Index.002
	    index_002 = curve_segment.nodes.new("GeometryNodeInputIndex")
	    index_002.name = "Index.002"
	
	    #node Switch.001
	    switch_001_1 = curve_segment.nodes.new("GeometryNodeSwitch")
	    switch_001_1.name = "Switch.001"
	    switch_001_1.input_type = 'INT'
	
	    #node Offset Point in Curve
	    offset_point_in_curve = curve_segment.nodes.new("GeometryNodeOffsetPointInCurve")
	    offset_point_in_curve.name = "Offset Point in Curve"
	    #Point Index
	    offset_point_in_curve.inputs[0].default_value = 0
	    #Offset
	    offset_point_in_curve.inputs[1].default_value = -1
	
	    #node Position.002
	    position_002_1 = curve_segment.nodes.new("GeometryNodeInputPosition")
	    position_002_1.name = "Position.002"
	
	
	
	
	
	    #Set locations
	    vector_math_009.location = (-389.8524169921875, 30.443286895751953)
	    reroute_015.location = (-456.8948974609375, 4.604297637939453)
	    reroute_017.location = (-1012.7362060546875, -9.742748260498047)
	    field_at_index_001.location = (-992.6431884765625, 70.62931823730469)
	    vector_math_008.location = (-811.805908203125, 70.62931823730469)
	    reroute_018.location = (-1032.8292236328125, 110.81541442871094)
	    interpolate_domain_002_1.location = (-630.9686279296875, 70.62931823730469)
	    group_output_3.location = (75.0, 50.0)
	    vector_math_007.location = (-389.8524169921875, 151.00144958496094)
	    interpolate_domain_003.location = (-390.85833740234375, -97.25408935546875)
	    reroute_2.location = (-342.979248046875, 193.345458984375)
	    switch_004.location = (-178.8756103515625, 10.35025405883789)
	    switch_003.location = (-178.8756103515625, 90.72234344482422)
	    boolean.location = (-781.6663208007812, 291.652587890625)
	    interpolate_domain_1.location = (-600.8291015625, 311.74560546875)
	    switch_005.location = (-178.8756103515625, -70.0218505859375)
	    index_002.location = (-1404.550048828125, 211.28048706054688)
	    switch_001_1.location = (-1223.712890625, 231.37350463867188)
	    offset_point_in_curve.location = (-1404.550048828125, 151.0014190673828)
	    position_002_1.location = (-1223.712890625, 30.44327163696289)
	
	    #Set dimensions
	    vector_math_009.width, vector_math_009.height = 140.0, 100.0
	    reroute_015.width, reroute_015.height = 100.0, 100.0
	    reroute_017.width, reroute_017.height = 100.0, 100.0
	    field_at_index_001.width, field_at_index_001.height = 140.0, 100.0
	    vector_math_008.width, vector_math_008.height = 140.0, 100.0
	    reroute_018.width, reroute_018.height = 100.0, 100.0
	    interpolate_domain_002_1.width, interpolate_domain_002_1.height = 140.0, 100.0
	    group_output_3.width, group_output_3.height = 140.0, 100.0
	    vector_math_007.width, vector_math_007.height = 140.0, 100.0
	    interpolate_domain_003.width, interpolate_domain_003.height = 140.0, 100.0
	    reroute_2.width, reroute_2.height = 100.0, 100.0
	    switch_004.width, switch_004.height = 140.0, 100.0
	    switch_003.width, switch_003.height = 140.0, 100.0
	    boolean.width, boolean.height = 140.0, 100.0
	    interpolate_domain_1.width, interpolate_domain_1.height = 140.0, 100.0
	    switch_005.width, switch_005.height = 140.0, 100.0
	    index_002.width, index_002.height = 140.0, 100.0
	    switch_001_1.width, switch_001_1.height = 140.0, 100.0
	    offset_point_in_curve.width, offset_point_in_curve.height = 140.0, 100.0
	    position_002_1.width, position_002_1.height = 140.0, 100.0
	
	    #initialize curve_segment links
	    #reroute_015.Output -> vector_math_007.Vector
	    curve_segment.links.new(reroute_015.outputs[0], vector_math_007.inputs[0])
	    #reroute_018.Output -> field_at_index_001.Index
	    curve_segment.links.new(reroute_018.outputs[0], field_at_index_001.inputs[0])
	    #vector_math_008.Vector -> interpolate_domain_002_1.Value
	    curve_segment.links.new(vector_math_008.outputs[0], interpolate_domain_002_1.inputs[0])
	    #reroute_017.Output -> vector_math_008.Vector
	    curve_segment.links.new(reroute_017.outputs[0], vector_math_008.inputs[0])
	    #reroute_015.Output -> vector_math_009.Vector
	    curve_segment.links.new(reroute_015.outputs[0], vector_math_009.inputs[0])
	    #reroute_017.Output -> field_at_index_001.Value
	    curve_segment.links.new(reroute_017.outputs[0], field_at_index_001.inputs[1])
	    #field_at_index_001.Value -> vector_math_008.Vector
	    curve_segment.links.new(field_at_index_001.outputs[0], vector_math_008.inputs[1])
	    #position_002_1.Position -> reroute_017.Input
	    curve_segment.links.new(position_002_1.outputs[0], reroute_017.inputs[0])
	    #interpolate_domain_002_1.Value -> reroute_015.Input
	    curve_segment.links.new(interpolate_domain_002_1.outputs[0], reroute_015.inputs[0])
	    #switch_004.Output -> group_output_3.Segment Direction
	    curve_segment.links.new(switch_004.outputs[0], group_output_3.inputs[1])
	    #switch_005.Output -> group_output_3.Neighbor Index
	    curve_segment.links.new(switch_005.outputs[0], group_output_3.inputs[2])
	    #boolean.Boolean -> interpolate_domain_1.Value
	    curve_segment.links.new(boolean.outputs[0], interpolate_domain_1.inputs[0])
	    #reroute_018.Output -> interpolate_domain_003.Value
	    curve_segment.links.new(reroute_018.outputs[0], interpolate_domain_003.inputs[0])
	    #vector_math_007.Value -> switch_003.True
	    curve_segment.links.new(vector_math_007.outputs[1], switch_003.inputs[2])
	    #reroute_2.Output -> switch_003.Switch
	    curve_segment.links.new(reroute_2.outputs[0], switch_003.inputs[0])
	    #switch_003.Output -> group_output_3.Segment Length
	    curve_segment.links.new(switch_003.outputs[0], group_output_3.inputs[0])
	    #vector_math_009.Vector -> switch_004.True
	    curve_segment.links.new(vector_math_009.outputs[0], switch_004.inputs[2])
	    #interpolate_domain_1.Value -> reroute_2.Input
	    curve_segment.links.new(interpolate_domain_1.outputs[0], reroute_2.inputs[0])
	    #reroute_2.Output -> switch_004.Switch
	    curve_segment.links.new(reroute_2.outputs[0], switch_004.inputs[0])
	    #interpolate_domain_003.Value -> switch_005.True
	    curve_segment.links.new(interpolate_domain_003.outputs[0], switch_005.inputs[2])
	    #reroute_2.Output -> switch_005.Switch
	    curve_segment.links.new(reroute_2.outputs[0], switch_005.inputs[0])
	    #offset_point_in_curve.Is Valid Offset -> switch_001_1.Switch
	    curve_segment.links.new(offset_point_in_curve.outputs[0], switch_001_1.inputs[0])
	    #offset_point_in_curve.Point Index -> switch_001_1.True
	    curve_segment.links.new(offset_point_in_curve.outputs[1], switch_001_1.inputs[2])
	    #index_002.Index -> switch_001_1.False
	    curve_segment.links.new(index_002.outputs[0], switch_001_1.inputs[1])
	    #switch_001_1.Output -> reroute_018.Input
	    curve_segment.links.new(switch_001_1.outputs[0], reroute_018.inputs[0])
	    return curve_segment
	
	curve_segment = curve_segment_node_group()
	
	#initialize restore_curve_segment_length node group
	def restore_curve_segment_length_node_group():
	    restore_curve_segment_length = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Restore Curve Segment Length")
	
	    restore_curve_segment_length.color_tag = 'GEOMETRY'
	    restore_curve_segment_length.description = "Restores the length of each curve segment using a previous state after deformation"
	    restore_curve_segment_length.default_group_node_width = 140
	    
	
	    restore_curve_segment_length.is_modifier = True
	
	    #restore_curve_segment_length interface
	    #Socket Curves
	    curves_socket = restore_curve_segment_length.interface.new_socket(name = "Curves", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    curves_socket.attribute_domain = 'POINT'
	
	    #Socket Curves
	    curves_socket_1 = restore_curve_segment_length.interface.new_socket(name = "Curves", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    curves_socket_1.attribute_domain = 'POINT'
	
	    #Socket Selection
	    selection_socket = restore_curve_segment_length.interface.new_socket(name = "Selection", in_out='INPUT', socket_type = 'NodeSocketBool')
	    selection_socket.default_value = True
	    selection_socket.attribute_domain = 'POINT'
	    selection_socket.hide_value = True
	    selection_socket.description = "Only affect selected elements"
	
	    #Socket Factor
	    factor_socket = restore_curve_segment_length.interface.new_socket(name = "Factor", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    factor_socket.default_value = 1.0
	    factor_socket.min_value = 0.0
	    factor_socket.max_value = 1.0
	    factor_socket.subtype = 'FACTOR'
	    factor_socket.attribute_domain = 'POINT'
	    factor_socket.description = "Factor to blend overall effect"
	
	    #Socket Reference Position
	    reference_position_socket = restore_curve_segment_length.interface.new_socket(name = "Reference Position", in_out='INPUT', socket_type = 'NodeSocketVector')
	    reference_position_socket.default_value = (8.146539688110352, 4.969870090484619, 9.874540328979492)
	    reference_position_socket.min_value = -3.4028234663852886e+38
	    reference_position_socket.max_value = 3.4028234663852886e+38
	    reference_position_socket.subtype = 'NONE'
	    reference_position_socket.default_attribute_name = "rest_position"
	    reference_position_socket.attribute_domain = 'POINT'
	    reference_position_socket.hide_value = True
	    reference_position_socket.description = "Reference position before deformation"
	
	    #Socket Pin at Parameter
	    pin_at_parameter_socket = restore_curve_segment_length.interface.new_socket(name = "Pin at Parameter", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    pin_at_parameter_socket.default_value = 0.0
	    pin_at_parameter_socket.min_value = 0.0
	    pin_at_parameter_socket.max_value = 1.0
	    pin_at_parameter_socket.subtype = 'FACTOR'
	    pin_at_parameter_socket.attribute_domain = 'POINT'
	    pin_at_parameter_socket.description = "Pin each curve at a certain point for the operation"
	
	
	    #initialize restore_curve_segment_length nodes
	    #node Frame.001
	    frame_001 = restore_curve_segment_length.nodes.new("NodeFrame")
	    frame_001.label = "Pin at Parameter"
	    frame_001.name = "Frame.001"
	    frame_001.label_size = 20
	    frame_001.shrink = True
	
	    #node Frame
	    frame_1 = restore_curve_segment_length.nodes.new("NodeFrame")
	    frame_1.label = "Restore Segment Lengths"
	    frame_1.name = "Frame"
	    frame_1.label_size = 20
	    frame_1.shrink = True
	
	    #node Frame.002
	    frame_002_1 = restore_curve_segment_length.nodes.new("NodeFrame")
	    frame_002_1.label = "Default Fallback"
	    frame_002_1.name = "Frame.002"
	    frame_002_1.label_size = 20
	    frame_002_1.shrink = True
	
	    #node Reroute.009
	    reroute_009 = restore_curve_segment_length.nodes.new("NodeReroute")
	    reroute_009.name = "Reroute.009"
	    reroute_009.socket_idname = "NodeSocketVector"
	    #node Group Input.006
	    group_input_006 = restore_curve_segment_length.nodes.new("NodeGroupInput")
	    group_input_006.name = "Group Input.006"
	    group_input_006.outputs[0].hide = True
	    group_input_006.outputs[1].hide = True
	    group_input_006.outputs[2].hide = True
	    group_input_006.outputs[3].hide = True
	    group_input_006.outputs[5].hide = True
	
	    #node Reroute.013
	    reroute_013 = restore_curve_segment_length.nodes.new("NodeReroute")
	    reroute_013.name = "Reroute.013"
	    reroute_013.socket_idname = "NodeSocketGeometry"
	    #node Index
	    index = restore_curve_segment_length.nodes.new("GeometryNodeInputIndex")
	    index.name = "Index"
	
	    #node Sample Curve.001
	    sample_curve_001 = restore_curve_segment_length.nodes.new("GeometryNodeSampleCurve")
	    sample_curve_001.name = "Sample Curve.001"
	    sample_curve_001.data_type = 'FLOAT_VECTOR'
	    sample_curve_001.mode = 'FACTOR'
	    sample_curve_001.use_all_curves = False
	
	    #node Group Input.003
	    group_input_003_1 = restore_curve_segment_length.nodes.new("NodeGroupInput")
	    group_input_003_1.name = "Group Input.003"
	    group_input_003_1.outputs[0].hide = True
	    group_input_003_1.outputs[1].hide = True
	    group_input_003_1.outputs[2].hide = True
	    group_input_003_1.outputs[3].hide = True
	    group_input_003_1.outputs[5].hide = True
	
	    #node Vector Math.006
	    vector_math_006 = restore_curve_segment_length.nodes.new("ShaderNodeVectorMath")
	    vector_math_006.name = "Vector Math.006"
	    vector_math_006.hide = True
	    vector_math_006.operation = 'SUBTRACT'
	
	    #node Interpolate Domain
	    interpolate_domain_2 = restore_curve_segment_length.nodes.new("GeometryNodeFieldOnDomain")
	    interpolate_domain_2.name = "Interpolate Domain"
	    interpolate_domain_2.hide = True
	    interpolate_domain_2.data_type = 'FLOAT_VECTOR'
	    interpolate_domain_2.domain = 'CURVE'
	
	    #node Group Input.005
	    group_input_005_1 = restore_curve_segment_length.nodes.new("NodeGroupInput")
	    group_input_005_1.name = "Group Input.005"
	    group_input_005_1.outputs[0].hide = True
	    group_input_005_1.outputs[2].hide = True
	    group_input_005_1.outputs[3].hide = True
	    group_input_005_1.outputs[4].hide = True
	    group_input_005_1.outputs[5].hide = True
	
	    #node Boolean Math.002
	    boolean_math_002 = restore_curve_segment_length.nodes.new("FunctionNodeBooleanMath")
	    boolean_math_002.name = "Boolean Math.002"
	    boolean_math_002.hide = True
	    boolean_math_002.operation = 'AND'
	
	    #node Field at Index.002
	    field_at_index_002 = restore_curve_segment_length.nodes.new("GeometryNodeFieldAtIndex")
	    field_at_index_002.name = "Field at Index.002"
	    field_at_index_002.data_type = 'FLOAT_VECTOR'
	    field_at_index_002.domain = 'POINT'
	
	    #node Vector Math.004
	    vector_math_004 = restore_curve_segment_length.nodes.new("ShaderNodeVectorMath")
	    vector_math_004.name = "Vector Math.004"
	    vector_math_004.operation = 'DISTANCE'
	
	    #node Accumulate Field
	    accumulate_field = restore_curve_segment_length.nodes.new("GeometryNodeAccumulateField")
	    accumulate_field.name = "Accumulate Field"
	    accumulate_field.data_type = 'FLOAT_VECTOR'
	    accumulate_field.domain = 'POINT'
	    accumulate_field.outputs[1].hide = True
	    accumulate_field.outputs[2].hide = True
	
	    #node Curve of Point
	    curve_of_point = restore_curve_segment_length.nodes.new("GeometryNodeCurveOfPoint")
	    curve_of_point.name = "Curve of Point"
	    curve_of_point.inputs[0].hide = True
	    curve_of_point.outputs[1].hide = True
	    #Point Index
	    curve_of_point.inputs[0].default_value = 0
	
	    #node Vector Math
	    vector_math_1 = restore_curve_segment_length.nodes.new("ShaderNodeVectorMath")
	    vector_math_1.name = "Vector Math"
	    vector_math_1.operation = 'SCALE'
	
	    #node Index.001
	    index_001 = restore_curve_segment_length.nodes.new("GeometryNodeInputIndex")
	    index_001.name = "Index.001"
	
	    #node Curve of Point.001
	    curve_of_point_001 = restore_curve_segment_length.nodes.new("GeometryNodeCurveOfPoint")
	    curve_of_point_001.name = "Curve of Point.001"
	    curve_of_point_001.inputs[0].hide = True
	    curve_of_point_001.outputs[0].hide = True
	    #Point Index
	    curve_of_point_001.inputs[0].default_value = 0
	
	    #node Switch
	    switch = restore_curve_segment_length.nodes.new("GeometryNodeSwitch")
	    switch.name = "Switch"
	    switch.input_type = 'INT'
	
	    #node Math
	    math_1 = restore_curve_segment_length.nodes.new("ShaderNodeMath")
	    math_1.name = "Math"
	    math_1.hide = True
	    math_1.operation = 'SUBTRACT'
	    math_1.use_clamp = False
	    #Value_001
	    math_1.inputs[1].default_value = 1.0
	
	    #node Compare
	    compare = restore_curve_segment_length.nodes.new("FunctionNodeCompare")
	    compare.name = "Compare"
	    compare.hide = True
	    compare.data_type = 'INT'
	    compare.mode = 'ELEMENT'
	    compare.operation = 'EQUAL'
	    #B_INT
	    compare.inputs[3].default_value = 0
	
	    #node Reroute.001
	    reroute_001_1 = restore_curve_segment_length.nodes.new("NodeReroute")
	    reroute_001_1.name = "Reroute.001"
	    reroute_001_1.socket_idname = "NodeSocketVector"
	    #node Set Position.001
	    set_position_001_1 = restore_curve_segment_length.nodes.new("GeometryNodeSetPosition")
	    set_position_001_1.name = "Set Position.001"
	
	    #node Boolean Math
	    boolean_math_1 = restore_curve_segment_length.nodes.new("FunctionNodeBooleanMath")
	    boolean_math_1.name = "Boolean Math"
	    boolean_math_1.operation = 'AND'
	
	    #node Compare.002
	    compare_002_1 = restore_curve_segment_length.nodes.new("FunctionNodeCompare")
	    compare_002_1.name = "Compare.002"
	    compare_002_1.data_type = 'FLOAT'
	    compare_002_1.mode = 'ELEMENT'
	    compare_002_1.operation = 'GREATER_THAN'
	    #B
	    compare_002_1.inputs[1].default_value = 0.0
	
	    #node Group Input.002
	    group_input_002_1 = restore_curve_segment_length.nodes.new("NodeGroupInput")
	    group_input_002_1.name = "Group Input.002"
	    group_input_002_1.outputs[0].hide = True
	    group_input_002_1.outputs[3].hide = True
	    group_input_002_1.outputs[4].hide = True
	    group_input_002_1.outputs[5].hide = True
	
	    #node Reroute.016
	    reroute_016 = restore_curve_segment_length.nodes.new("NodeReroute")
	    reroute_016.name = "Reroute.016"
	    reroute_016.socket_idname = "NodeSocketBool"
	    #node Reroute.014
	    reroute_014 = restore_curve_segment_length.nodes.new("NodeReroute")
	    reroute_014.name = "Reroute.014"
	    reroute_014.socket_idname = "NodeSocketGeometry"
	    #node Switch.001
	    switch_001_2 = restore_curve_segment_length.nodes.new("GeometryNodeSwitch")
	    switch_001_2.name = "Switch.001"
	    switch_001_2.input_type = 'GEOMETRY'
	
	    #node Group Output
	    group_output_4 = restore_curve_segment_length.nodes.new("NodeGroupOutput")
	    group_output_4.name = "Group Output"
	    group_output_4.is_active_output = True
	
	    #node Attribute Statistic
	    attribute_statistic = restore_curve_segment_length.nodes.new("GeometryNodeAttributeStatistic")
	    attribute_statistic.name = "Attribute Statistic"
	    attribute_statistic.hide = True
	    attribute_statistic.data_type = 'FLOAT'
	    attribute_statistic.domain = 'CURVE'
	    attribute_statistic.inputs[1].hide = True
	    attribute_statistic.outputs[0].hide = True
	    attribute_statistic.outputs[1].hide = True
	    attribute_statistic.outputs[2].hide = True
	    attribute_statistic.outputs[3].hide = True
	    attribute_statistic.outputs[5].hide = True
	    attribute_statistic.outputs[6].hide = True
	    attribute_statistic.outputs[7].hide = True
	    #Selection
	    attribute_statistic.inputs[1].default_value = True
	
	    #node Group
	    group = restore_curve_segment_length.nodes.new("GeometryNodeGroup")
	    group.name = "Group"
	    group.node_tree = curve_root
	    group.outputs[0].hide = True
	    group.outputs[2].hide = True
	    group.outputs[3].hide = True
	
	    #node Reroute.007
	    reroute_007_1 = restore_curve_segment_length.nodes.new("NodeReroute")
	    reroute_007_1.name = "Reroute.007"
	    reroute_007_1.socket_idname = "NodeSocketVector"
	    #node Reroute.004
	    reroute_004_1 = restore_curve_segment_length.nodes.new("NodeReroute")
	    reroute_004_1.name = "Reroute.004"
	    reroute_004_1.socket_idname = "NodeSocketGeometry"
	    #node Position.001
	    position_001_1 = restore_curve_segment_length.nodes.new("GeometryNodeInputPosition")
	    position_001_1.name = "Position.001"
	
	    #node Named Attribute
	    named_attribute = restore_curve_segment_length.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute.name = "Named Attribute"
	    named_attribute.data_type = 'FLOAT_VECTOR'
	    #Name
	    named_attribute.inputs[0].default_value = "rest_position"
	
	    #node Switch.003
	    switch_003_1 = restore_curve_segment_length.nodes.new("GeometryNodeSwitch")
	    switch_003_1.name = "Switch.003"
	    switch_003_1.input_type = 'VECTOR'
	
	    #node Reroute.006
	    reroute_006_1 = restore_curve_segment_length.nodes.new("NodeReroute")
	    reroute_006_1.name = "Reroute.006"
	    reroute_006_1.socket_idname = "NodeSocketVector"
	    #node Switch.002
	    switch_002 = restore_curve_segment_length.nodes.new("GeometryNodeSwitch")
	    switch_002.name = "Switch.002"
	    switch_002.input_type = 'VECTOR'
	
	    #node Compare.004
	    compare_004 = restore_curve_segment_length.nodes.new("FunctionNodeCompare")
	    compare_004.name = "Compare.004"
	    compare_004.data_type = 'VECTOR'
	    compare_004.mode = 'ELEMENT'
	    compare_004.operation = 'EQUAL'
	    #B_VEC3
	    compare_004.inputs[5].default_value = (8.146539688110352, 4.969870090484619, 9.874540328979492)
	    #Epsilon
	    compare_004.inputs[12].default_value = 0.0
	
	    #node Group Input
	    group_input_2 = restore_curve_segment_length.nodes.new("NodeGroupInput")
	    group_input_2.name = "Group Input"
	    group_input_2.outputs[1].hide = True
	    group_input_2.outputs[2].hide = True
	    group_input_2.outputs[4].hide = True
	    group_input_2.outputs[5].hide = True
	
	    #node Reroute.011
	    reroute_011 = restore_curve_segment_length.nodes.new("NodeReroute")
	    reroute_011.name = "Reroute.011"
	    reroute_011.socket_idname = "NodeSocketGeometry"
	    #node Reroute.005
	    reroute_005_1 = restore_curve_segment_length.nodes.new("NodeReroute")
	    reroute_005_1.name = "Reroute.005"
	    reroute_005_1.socket_idname = "NodeSocketGeometry"
	    #node Reroute.008
	    reroute_008_1 = restore_curve_segment_length.nodes.new("NodeReroute")
	    reroute_008_1.name = "Reroute.008"
	    reroute_008_1.socket_idname = "NodeSocketVector"
	    #node Set Position.002
	    set_position_002_1 = restore_curve_segment_length.nodes.new("GeometryNodeSetPosition")
	    set_position_002_1.name = "Set Position.002"
	    set_position_002_1.inputs[2].hide = True
	    #Position
	    set_position_002_1.inputs[2].default_value = (0.0, 0.0, 0.0)
	
	    #node Reroute.012
	    reroute_012 = restore_curve_segment_length.nodes.new("NodeReroute")
	    reroute_012.name = "Reroute.012"
	    reroute_012.socket_idname = "NodeSocketGeometry"
	    #node Group Input.001
	    group_input_001_1 = restore_curve_segment_length.nodes.new("NodeGroupInput")
	    group_input_001_1.name = "Group Input.001"
	    group_input_001_1.outputs[0].hide = True
	    group_input_001_1.outputs[1].hide = True
	    group_input_001_1.outputs[3].hide = True
	    group_input_001_1.outputs[4].hide = True
	    group_input_001_1.outputs[5].hide = True
	
	    #node Mix
	    mix = restore_curve_segment_length.nodes.new("ShaderNodeMix")
	    mix.name = "Mix"
	    mix.blend_type = 'MIX'
	    mix.clamp_factor = True
	    mix.clamp_result = False
	    mix.data_type = 'FLOAT'
	    mix.factor_mode = 'UNIFORM'
	
	    #node Group.001
	    group_001 = restore_curve_segment_length.nodes.new("GeometryNodeGroup")
	    group_001.name = "Group.001"
	    group_001.node_tree = curve_segment
	    group_001.outputs[2].hide = True
	
	    #node Compare.003
	    compare_003 = restore_curve_segment_length.nodes.new("FunctionNodeCompare")
	    compare_003.name = "Compare.003"
	    compare_003.hide = True
	    compare_003.data_type = 'FLOAT'
	    compare_003.mode = 'ELEMENT'
	    compare_003.operation = 'NOT_EQUAL'
	    #B
	    compare_003.inputs[1].default_value = 0.0
	    #Epsilon
	    compare_003.inputs[12].default_value = 0.0
	
	    #node Compare.005
	    compare_005 = restore_curve_segment_length.nodes.new("FunctionNodeCompare")
	    compare_005.name = "Compare.005"
	    compare_005.hide = True
	    compare_005.data_type = 'FLOAT'
	    compare_005.mode = 'ELEMENT'
	    compare_005.operation = 'GREATER_THAN'
	    #B
	    compare_005.inputs[1].default_value = 0.0
	
	
	
	
	    #Set parents
	    group_input_006.parent = frame_001
	    reroute_013.parent = frame_001
	    index.parent = frame_001
	    sample_curve_001.parent = frame_001
	    group_input_003_1.parent = frame_001
	    vector_math_006.parent = frame_001
	    interpolate_domain_2.parent = frame_001
	    group_input_005_1.parent = frame_001
	    boolean_math_002.parent = frame_001
	    field_at_index_002.parent = frame_1
	    vector_math_004.parent = frame_1
	    accumulate_field.parent = frame_1
	    curve_of_point.parent = frame_1
	    vector_math_1.parent = frame_1
	    index_001.parent = frame_1
	    curve_of_point_001.parent = frame_1
	    switch.parent = frame_1
	    math_1.parent = frame_1
	    compare.parent = frame_1
	    reroute_001_1.parent = frame_1
	    set_position_001_1.parent = frame_1
	    boolean_math_1.parent = frame_1
	    compare_002_1.parent = frame_1
	    group_input_002_1.parent = frame_1
	    reroute_016.parent = frame_001
	    reroute_014.parent = frame_001
	    switch_001_2.parent = frame_001
	    attribute_statistic.parent = frame_001
	    group.parent = frame_1
	    reroute_004_1.parent = frame_1
	    position_001_1.parent = frame_002_1
	    named_attribute.parent = frame_002_1
	    switch_003_1.parent = frame_002_1
	    reroute_006_1.parent = frame_002_1
	    switch_002.parent = frame_002_1
	    compare_004.parent = frame_002_1
	    reroute_005_1.parent = frame_1
	    set_position_002_1.parent = frame_001
	    reroute_012.parent = frame_001
	    group_input_001_1.parent = frame_1
	    mix.parent = frame_1
	    group_001.parent = frame_1
	    compare_003.parent = frame_001
	    compare_005.parent = frame_001
	
	    #Set locations
	    frame_001.location = (-1286.139892578125, 110.0)
	    frame_1.location = (-3491.0, 54.813934326171875)
	    frame_002_1.location = (-4464.1865234375, -101.0)
	    reroute_009.location = (-1431.9771728515625, -673.348876953125)
	    group_input_006.location = (215.837158203125, -140.37210083007812)
	    reroute_013.location = (175.651123046875, -120.2790756225586)
	    index.location = (35.0, -481.9534912109375)
	    sample_curve_001.location = (215.837158203125, -220.7441864013672)
	    group_input_003_1.location = (35.0, -421.6744384765625)
	    vector_math_006.location = (396.6744384765625, -260.93023681640625)
	    interpolate_domain_2.location = (577.5116577148438, -260.93023681640625)
	    group_input_005_1.location = (396.6744384765625, -180.5581512451172)
	    boolean_math_002.location = (577.5116577148438, -180.5581512451172)
	    field_at_index_002.location = (652.51123046875, -245.93023681640625)
	    vector_math_004.location = (833.348388671875, -225.83721923828125)
	    accumulate_field.location = (1556.697265625, -406.6744384765625)
	    curve_of_point.location = (1355.76708984375, -547.3255615234375)
	    vector_math_1.location = (1355.76708984375, -386.5813903808594)
	    index_001.location = (29.62744140625, -466.9534912109375)
	    curve_of_point_001.location = (29.62744140625, -386.5813903808594)
	    switch.location = (411.39501953125, -366.4883728027344)
	    math_1.location = (210.46484375, -466.9534912109375)
	    compare.location = (210.46484375, -426.7674560546875)
	    reroute_001_1.location = (612.3251953125, -306.20928955078125)
	    set_position_001_1.location = (1797.8135986328125, -145.46511840820312)
	    boolean_math_1.location = (1493.957763671875, -93.53775024414062)
	    compare_002_1.location = (1293.02783203125, -113.63077545166016)
	    group_input_002_1.location = (1112.19091796875, -133.7238006591797)
	    reroute_016.location = (798.534912109375, -160.46511840820312)
	    reroute_014.location = (798.534912109375, -120.2790756225586)
	    switch_001_2.location = (1079.837158203125, -39.906982421875)
	    group_output_4.location = (75.0, 50.0)
	    attribute_statistic.location = (858.81396484375, -60.0)
	    group.location = (1556.697265625, -266.02325439453125)
	    reroute_007_1.location = (-3762.76806640625, -251.3953857421875)
	    reroute_004_1.location = (1637.0693359375, -45.0)
	    position_001_1.location = (57.345703125, -240.45068359375)
	    named_attribute.location = (57.345703125, -300.729736328125)
	    switch_003_1.location = (238.1826171875, -220.357666015625)
	    reroute_006_1.location = (35.0, -71.92265319824219)
	    switch_002.location = (439.11279296875, -99.79951477050781)
	    compare_004.location = (57.34619140625, -39.52044677734375)
	    group_input_2.location = (-4707.1396484375, -30.37213134765625)
	    reroute_011.location = (-3581.9306640625, -70.55816650390625)
	    reroute_005_1.location = (49.720703125, -45.0)
	    reroute_008_1.location = (-3561.83740234375, -673.348876953125)
	    set_position_002_1.location = (858.81396484375, -140.37210083007812)
	    reroute_012.location = (35.0, -240.83721923828125)
	    group_input_001_1.location = (833.348388671875, -165.55813598632812)
	    mix.location = (1114.65087890625, -326.3023376464844)
	    group_001.location = (833.348388671875, -406.6744384765625)
	    compare_003.location = (396.6744384765625, -140.37210083007812)
	    compare_005.location = (858.81396484375, -100.18605041503906)
	
	    #Set dimensions
	    frame_001.width, frame_001.height = 1250.139892578125, 562.0
	    frame_1.width, frame_1.height = 1968.0, 629.81396484375
	    frame_002_1.width, frame_002_1.height = 609.1865234375, 452.0
	    reroute_009.width, reroute_009.height = 100.0, 100.0
	    group_input_006.width, group_input_006.height = 140.0, 100.0
	    reroute_013.width, reroute_013.height = 100.0, 100.0
	    index.width, index.height = 140.0, 100.0
	    sample_curve_001.width, sample_curve_001.height = 140.0, 100.0
	    group_input_003_1.width, group_input_003_1.height = 140.0, 100.0
	    vector_math_006.width, vector_math_006.height = 140.0, 100.0
	    interpolate_domain_2.width, interpolate_domain_2.height = 140.0, 100.0
	    group_input_005_1.width, group_input_005_1.height = 140.0, 100.0
	    boolean_math_002.width, boolean_math_002.height = 140.0, 100.0
	    field_at_index_002.width, field_at_index_002.height = 140.0, 100.0
	    vector_math_004.width, vector_math_004.height = 140.0, 100.0
	    accumulate_field.width, accumulate_field.height = 140.0, 100.0
	    curve_of_point.width, curve_of_point.height = 140.0, 100.0
	    vector_math_1.width, vector_math_1.height = 140.0, 100.0
	    index_001.width, index_001.height = 140.0, 100.0
	    curve_of_point_001.width, curve_of_point_001.height = 140.0, 100.0
	    switch.width, switch.height = 140.0, 100.0
	    math_1.width, math_1.height = 140.0, 100.0
	    compare.width, compare.height = 140.0, 100.0
	    reroute_001_1.width, reroute_001_1.height = 100.0, 100.0
	    set_position_001_1.width, set_position_001_1.height = 140.0, 100.0
	    boolean_math_1.width, boolean_math_1.height = 140.0, 100.0
	    compare_002_1.width, compare_002_1.height = 140.0, 100.0
	    group_input_002_1.width, group_input_002_1.height = 140.0, 100.0
	    reroute_016.width, reroute_016.height = 100.0, 100.0
	    reroute_014.width, reroute_014.height = 100.0, 100.0
	    switch_001_2.width, switch_001_2.height = 140.0, 100.0
	    group_output_4.width, group_output_4.height = 140.0, 100.0
	    attribute_statistic.width, attribute_statistic.height = 140.0, 100.0
	    group.width, group.height = 140.0, 100.0
	    reroute_007_1.width, reroute_007_1.height = 100.0, 100.0
	    reroute_004_1.width, reroute_004_1.height = 100.0, 100.0
	    position_001_1.width, position_001_1.height = 140.0, 100.0
	    named_attribute.width, named_attribute.height = 140.0, 100.0
	    switch_003_1.width, switch_003_1.height = 140.0, 100.0
	    reroute_006_1.width, reroute_006_1.height = 100.0, 100.0
	    switch_002.width, switch_002.height = 140.0, 100.0
	    compare_004.width, compare_004.height = 140.0, 100.0
	    group_input_2.width, group_input_2.height = 140.0, 100.0
	    reroute_011.width, reroute_011.height = 100.0, 100.0
	    reroute_005_1.width, reroute_005_1.height = 100.0, 100.0
	    reroute_008_1.width, reroute_008_1.height = 100.0, 100.0
	    set_position_002_1.width, set_position_002_1.height = 140.0, 100.0
	    reroute_012.width, reroute_012.height = 100.0, 100.0
	    group_input_001_1.width, group_input_001_1.height = 140.0, 100.0
	    mix.width, mix.height = 140.0, 100.0
	    group_001.width, group_001.height = 140.0, 100.0
	    compare_003.width, compare_003.height = 140.0, 100.0
	    compare_005.width, compare_005.height = 140.0, 100.0
	
	    #initialize restore_curve_segment_length links
	    #reroute_004_1.Output -> set_position_001_1.Geometry
	    restore_curve_segment_length.links.new(reroute_004_1.outputs[0], set_position_001_1.inputs[0])
	    #curve_of_point.Curve Index -> accumulate_field.Group ID
	    restore_curve_segment_length.links.new(curve_of_point.outputs[0], accumulate_field.inputs[1])
	    #field_at_index_002.Value -> vector_math_004.Vector
	    restore_curve_segment_length.links.new(field_at_index_002.outputs[0], vector_math_004.inputs[0])
	    #reroute_001_1.Output -> vector_math_004.Vector
	    restore_curve_segment_length.links.new(reroute_001_1.outputs[0], vector_math_004.inputs[1])
	    #reroute_001_1.Output -> field_at_index_002.Value
	    restore_curve_segment_length.links.new(reroute_001_1.outputs[0], field_at_index_002.inputs[1])
	    #index_001.Index -> math_1.Value
	    restore_curve_segment_length.links.new(index_001.outputs[0], math_1.inputs[0])
	    #switch.Output -> field_at_index_002.Index
	    restore_curve_segment_length.links.new(switch.outputs[0], field_at_index_002.inputs[0])
	    #vector_math_1.Vector -> accumulate_field.Value
	    restore_curve_segment_length.links.new(vector_math_1.outputs[0], accumulate_field.inputs[0])
	    #curve_of_point_001.Index in Curve -> compare.A
	    restore_curve_segment_length.links.new(curve_of_point_001.outputs[1], compare.inputs[2])
	    #math_1.Value -> switch.False
	    restore_curve_segment_length.links.new(math_1.outputs[0], switch.inputs[1])
	    #compare.Result -> switch.Switch
	    restore_curve_segment_length.links.new(compare.outputs[0], switch.inputs[0])
	    #index_001.Index -> switch.True
	    restore_curve_segment_length.links.new(index_001.outputs[0], switch.inputs[2])
	    #reroute_006_1.Output -> switch_002.False
	    restore_curve_segment_length.links.new(reroute_006_1.outputs[0], switch_002.inputs[1])
	    #group.Root Position -> set_position_001_1.Position
	    restore_curve_segment_length.links.new(group.outputs[1], set_position_001_1.inputs[2])
	    #vector_math_004.Value -> mix.B
	    restore_curve_segment_length.links.new(vector_math_004.outputs[1], mix.inputs[3])
	    #mix.Result -> vector_math_1.Scale
	    restore_curve_segment_length.links.new(mix.outputs[0], vector_math_1.inputs[3])
	    #group_input_001_1.Factor -> mix.Factor
	    restore_curve_segment_length.links.new(group_input_001_1.outputs[2], mix.inputs[0])
	    #group_input_002_1.Factor -> compare_002_1.A
	    restore_curve_segment_length.links.new(group_input_002_1.outputs[2], compare_002_1.inputs[0])
	    #accumulate_field.Leading -> set_position_001_1.Offset
	    restore_curve_segment_length.links.new(accumulate_field.outputs[0], set_position_001_1.inputs[3])
	    #compare_002_1.Result -> boolean_math_1.Boolean
	    restore_curve_segment_length.links.new(compare_002_1.outputs[0], boolean_math_1.inputs[0])
	    #group_input_002_1.Selection -> boolean_math_1.Boolean
	    restore_curve_segment_length.links.new(group_input_002_1.outputs[1], boolean_math_1.inputs[1])
	    #reroute_005_1.Output -> reroute_004_1.Input
	    restore_curve_segment_length.links.new(reroute_005_1.outputs[0], reroute_004_1.inputs[0])
	    #reroute_012.Output -> sample_curve_001.Curves
	    restore_curve_segment_length.links.new(reroute_012.outputs[0], sample_curve_001.inputs[0])
	    #sample_curve_001.Position -> vector_math_006.Vector
	    restore_curve_segment_length.links.new(sample_curve_001.outputs[1], vector_math_006.inputs[1])
	    #sample_curve_001.Value -> vector_math_006.Vector
	    restore_curve_segment_length.links.new(sample_curve_001.outputs[0], vector_math_006.inputs[0])
	    #reroute_014.Output -> set_position_002_1.Geometry
	    restore_curve_segment_length.links.new(reroute_014.outputs[0], set_position_002_1.inputs[0])
	    #interpolate_domain_2.Value -> set_position_002_1.Offset
	    restore_curve_segment_length.links.new(interpolate_domain_2.outputs[0], set_position_002_1.inputs[3])
	    #index.Index -> sample_curve_001.Curve Index
	    restore_curve_segment_length.links.new(index.outputs[0], sample_curve_001.inputs[4])
	    #reroute_012.Output -> reroute_013.Input
	    restore_curve_segment_length.links.new(reroute_012.outputs[0], reroute_013.inputs[0])
	    #group_input_005_1.Selection -> boolean_math_002.Boolean
	    restore_curve_segment_length.links.new(group_input_005_1.outputs[1], boolean_math_002.inputs[1])
	    #compare_003.Result -> boolean_math_002.Boolean
	    restore_curve_segment_length.links.new(compare_003.outputs[0], boolean_math_002.inputs[0])
	    #reroute_011.Output -> reroute_005_1.Input
	    restore_curve_segment_length.links.new(reroute_011.outputs[0], reroute_005_1.inputs[0])
	    #group_input_003_1.Pin at Parameter -> sample_curve_001.Factor
	    restore_curve_segment_length.links.new(group_input_003_1.outputs[4], sample_curve_001.inputs[2])
	    #group_input_006.Pin at Parameter -> compare_003.A
	    restore_curve_segment_length.links.new(group_input_006.outputs[4], compare_003.inputs[0])
	    #reroute_006_1.Output -> compare_004.A
	    restore_curve_segment_length.links.new(reroute_006_1.outputs[0], compare_004.inputs[4])
	    #compare_004.Result -> switch_002.Switch
	    restore_curve_segment_length.links.new(compare_004.outputs[0], switch_002.inputs[0])
	    #named_attribute.Attribute -> switch_003_1.True
	    restore_curve_segment_length.links.new(named_attribute.outputs[0], switch_003_1.inputs[2])
	    #named_attribute.Exists -> switch_003_1.Switch
	    restore_curve_segment_length.links.new(named_attribute.outputs[1], switch_003_1.inputs[0])
	    #position_001_1.Position -> switch_003_1.False
	    restore_curve_segment_length.links.new(position_001_1.outputs[0], switch_003_1.inputs[1])
	    #switch_003_1.Output -> switch_002.True
	    restore_curve_segment_length.links.new(switch_003_1.outputs[0], switch_002.inputs[2])
	    #reroute_009.Output -> sample_curve_001.Value
	    restore_curve_segment_length.links.new(reroute_009.outputs[0], sample_curve_001.inputs[1])
	    #switch_002.Output -> reroute_007_1.Input
	    restore_curve_segment_length.links.new(switch_002.outputs[0], reroute_007_1.inputs[0])
	    #reroute_007_1.Output -> reroute_001_1.Input
	    restore_curve_segment_length.links.new(reroute_007_1.outputs[0], reroute_001_1.inputs[0])
	    #group_input_2.Reference Position -> reroute_006_1.Input
	    restore_curve_segment_length.links.new(group_input_2.outputs[3], reroute_006_1.inputs[0])
	    #reroute_007_1.Output -> reroute_008_1.Input
	    restore_curve_segment_length.links.new(reroute_007_1.outputs[0], reroute_008_1.inputs[0])
	    #reroute_008_1.Output -> reroute_009.Input
	    restore_curve_segment_length.links.new(reroute_008_1.outputs[0], reroute_009.inputs[0])
	    #group_input_2.Curves -> reroute_011.Input
	    restore_curve_segment_length.links.new(group_input_2.outputs[0], reroute_011.inputs[0])
	    #group_001.Segment Length -> mix.A
	    restore_curve_segment_length.links.new(group_001.outputs[0], mix.inputs[2])
	    #group_001.Segment Direction -> vector_math_1.Vector
	    restore_curve_segment_length.links.new(group_001.outputs[1], vector_math_1.inputs[0])
	    #vector_math_006.Vector -> interpolate_domain_2.Value
	    restore_curve_segment_length.links.new(vector_math_006.outputs[0], interpolate_domain_2.inputs[0])
	    #reroute_016.Output -> attribute_statistic.Attribute
	    restore_curve_segment_length.links.new(reroute_016.outputs[0], attribute_statistic.inputs[2])
	    #attribute_statistic.Max -> compare_005.A
	    restore_curve_segment_length.links.new(attribute_statistic.outputs[4], compare_005.inputs[0])
	    #set_position_002_1.Geometry -> switch_001_2.True
	    restore_curve_segment_length.links.new(set_position_002_1.outputs[0], switch_001_2.inputs[2])
	    #reroute_014.Output -> switch_001_2.False
	    restore_curve_segment_length.links.new(reroute_014.outputs[0], switch_001_2.inputs[1])
	    #reroute_016.Output -> set_position_002_1.Selection
	    restore_curve_segment_length.links.new(reroute_016.outputs[0], set_position_002_1.inputs[1])
	    #compare_005.Result -> switch_001_2.Switch
	    restore_curve_segment_length.links.new(compare_005.outputs[0], switch_001_2.inputs[0])
	    #reroute_014.Output -> attribute_statistic.Geometry
	    restore_curve_segment_length.links.new(reroute_014.outputs[0], attribute_statistic.inputs[0])
	    #boolean_math_1.Boolean -> set_position_001_1.Selection
	    restore_curve_segment_length.links.new(boolean_math_1.outputs[0], set_position_001_1.inputs[1])
	    #boolean_math_002.Boolean -> reroute_016.Input
	    restore_curve_segment_length.links.new(boolean_math_002.outputs[0], reroute_016.inputs[0])
	    #reroute_013.Output -> reroute_014.Input
	    restore_curve_segment_length.links.new(reroute_013.outputs[0], reroute_014.inputs[0])
	    #set_position_001_1.Geometry -> reroute_012.Input
	    restore_curve_segment_length.links.new(set_position_001_1.outputs[0], reroute_012.inputs[0])
	    #switch_001_2.Output -> group_output_4.Curves
	    restore_curve_segment_length.links.new(switch_001_2.outputs[0], group_output_4.inputs[0])
	    return restore_curve_segment_length
	
	restore_curve_segment_length = restore_curve_segment_length_node_group()
	
	#initialize attach_hair_curves_to_surface node group
	def attach_hair_curves_to_surface_node_group():
	    attach_hair_curves_to_surface = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Attach Hair Curves to Surface")
	
	    attach_hair_curves_to_surface.color_tag = 'GEOMETRY'
	    attach_hair_curves_to_surface.description = "Attaches hair curves to a surface mesh"
	    attach_hair_curves_to_surface.default_group_node_width = 140
	    
	
	    attach_hair_curves_to_surface.is_modifier = True
	
	    #attach_hair_curves_to_surface interface
	    #Socket Geometry
	    geometry_socket_3 = attach_hair_curves_to_surface.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_3.attribute_domain = 'POINT'
	
	    #Socket Surface UV Coordinate
	    surface_uv_coordinate_socket = attach_hair_curves_to_surface.interface.new_socket(name = "Surface UV Coordinate", in_out='OUTPUT', socket_type = 'NodeSocketVector')
	    surface_uv_coordinate_socket.default_value = (0.0, 0.0, 0.0)
	    surface_uv_coordinate_socket.min_value = -3.4028234663852886e+38
	    surface_uv_coordinate_socket.max_value = 3.4028234663852886e+38
	    surface_uv_coordinate_socket.subtype = 'NONE'
	    surface_uv_coordinate_socket.attribute_domain = 'CURVE'
	    surface_uv_coordinate_socket.description = "Surface UV coordinates at the attachment point"
	
	    #Socket Surface Normal
	    surface_normal_socket = attach_hair_curves_to_surface.interface.new_socket(name = "Surface Normal", in_out='OUTPUT', socket_type = 'NodeSocketVector')
	    surface_normal_socket.default_value = (0.0, 0.0, 0.0)
	    surface_normal_socket.min_value = -3.4028234663852886e+38
	    surface_normal_socket.max_value = 3.4028234663852886e+38
	    surface_normal_socket.subtype = 'NONE'
	    surface_normal_socket.attribute_domain = 'CURVE'
	    surface_normal_socket.description = "Surface normal at the attachment point"
	
	    #Socket Geometry
	    geometry_socket_4 = attach_hair_curves_to_surface.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_4.attribute_domain = 'POINT'
	    geometry_socket_4.description = "Input Geometry (may include other than curves)"
	
	    #Socket Surface
	    surface_socket = attach_hair_curves_to_surface.interface.new_socket(name = "Surface", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    surface_socket.attribute_domain = 'POINT'
	    surface_socket.description = "Surface geometry to attach hair curves to"
	
	    #Socket Surface
	    surface_socket_1 = attach_hair_curves_to_surface.interface.new_socket(name = "Surface", in_out='INPUT', socket_type = 'NodeSocketObject')
	    surface_socket_1.attribute_domain = 'POINT'
	    surface_socket_1.description = "Surface Object to attach to (needs to have matching transforms)"
	
	    #Socket Surface UV Map
	    surface_uv_map_socket = attach_hair_curves_to_surface.interface.new_socket(name = "Surface UV Map", in_out='INPUT', socket_type = 'NodeSocketVector')
	    surface_uv_map_socket.default_value = (0.0, 0.0, 0.0)
	    surface_uv_map_socket.min_value = -3.4028234663852886e+38
	    surface_uv_map_socket.max_value = 3.4028234663852886e+38
	    surface_uv_map_socket.subtype = 'NONE'
	    surface_uv_map_socket.default_attribute_name = "UVMap"
	    surface_uv_map_socket.attribute_domain = 'POINT'
	    surface_uv_map_socket.hide_value = True
	    surface_uv_map_socket.description = "Surface UV map used for attachment"
	
	    #Socket Surface Rest Position
	    surface_rest_position_socket = attach_hair_curves_to_surface.interface.new_socket(name = "Surface Rest Position", in_out='INPUT', socket_type = 'NodeSocketBool')
	    surface_rest_position_socket.default_value = False
	    surface_rest_position_socket.attribute_domain = 'POINT'
	    surface_rest_position_socket.description = "Set the surface mesh into its rest position before attachment"
	
	    #Socket Sample Attachment UV
	    sample_attachment_uv_socket = attach_hair_curves_to_surface.interface.new_socket(name = "Sample Attachment UV", in_out='INPUT', socket_type = 'NodeSocketBool')
	    sample_attachment_uv_socket.default_value = True
	    sample_attachment_uv_socket.attribute_domain = 'POINT'
	    sample_attachment_uv_socket.description = "Sample the surface UV map at the attachment point"
	
	    #Socket Snap to Surface
	    snap_to_surface_socket = attach_hair_curves_to_surface.interface.new_socket(name = "Snap to Surface", in_out='INPUT', socket_type = 'NodeSocketBool')
	    snap_to_surface_socket.default_value = True
	    snap_to_surface_socket.attribute_domain = 'POINT'
	    snap_to_surface_socket.description = "Snap the root of each curve to the closest surface point"
	
	    #Socket Align to Surface Normal
	    align_to_surface_normal_socket = attach_hair_curves_to_surface.interface.new_socket(name = "Align to Surface Normal", in_out='INPUT', socket_type = 'NodeSocketBool')
	    align_to_surface_normal_socket.default_value = True
	    align_to_surface_normal_socket.attribute_domain = 'POINT'
	    align_to_surface_normal_socket.description = "Align the curve to the surface normal (needs a guide as reference)"
	
	    #Socket Blend along Curve
	    blend_along_curve_socket = attach_hair_curves_to_surface.interface.new_socket(name = "Blend along Curve", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    blend_along_curve_socket.default_value = 0.0
	    blend_along_curve_socket.min_value = 0.0
	    blend_along_curve_socket.max_value = 1.0
	    blend_along_curve_socket.subtype = 'FACTOR'
	    blend_along_curve_socket.attribute_domain = 'POINT'
	    blend_along_curve_socket.description = "Blend deformation along each curve from the root"
	
	
	    #initialize attach_hair_curves_to_surface nodes
	    #node Frame.004
	    frame_004 = attach_hair_curves_to_surface.nodes.new("NodeFrame")
	    frame_004.label = "Write Data"
	    frame_004.name = "Frame.004"
	    frame_004.label_size = 20
	    frame_004.shrink = True
	
	    #node Frame.005
	    frame_005 = attach_hair_curves_to_surface.nodes.new("NodeFrame")
	    frame_005.label = "Sample Surface"
	    frame_005.name = "Frame.005"
	    frame_005.label_size = 20
	    frame_005.shrink = True
	
	    #node Frame
	    frame_2 = attach_hair_curves_to_surface.nodes.new("NodeFrame")
	    frame_2.label = "Surface Geometry Input"
	    frame_2.name = "Frame"
	    frame_2.label_size = 20
	    frame_2.shrink = True
	
	    #node Frame.006
	    frame_006 = attach_hair_curves_to_surface.nodes.new("NodeFrame")
	    frame_006.label = "Geometry Socket with Priority"
	    frame_006.name = "Frame.006"
	    frame_006.label_size = 20
	    frame_006.shrink = True
	
	    #node Frame.007
	    frame_007 = attach_hair_curves_to_surface.nodes.new("NodeFrame")
	    frame_007.label = "Object in Local Space"
	    frame_007.name = "Frame.007"
	    frame_007.label_size = 20
	    frame_007.shrink = True
	
	    #node Frame.011
	    frame_011 = attach_hair_curves_to_surface.nodes.new("NodeFrame")
	    frame_011.label = "Sample Attachment UV"
	    frame_011.name = "Frame.011"
	    frame_011.label_size = 20
	    frame_011.shrink = True
	
	    #node Frame.001
	    frame_001_1 = attach_hair_curves_to_surface.nodes.new("NodeFrame")
	    frame_001_1.label = "Smooth Normals"
	    frame_001_1.name = "Frame.001"
	    frame_001_1.label_size = 20
	    frame_001_1.shrink = True
	
	    #node Frame.010
	    frame_010 = attach_hair_curves_to_surface.nodes.new("NodeFrame")
	    frame_010.label = "Calculate New Position"
	    frame_010.name = "Frame.010"
	    frame_010.use_custom_color = True
	    frame_010.color = (0.13328450918197632, 0.13328450918197632, 0.13328450918197632)
	    frame_010.label_size = 20
	    frame_010.shrink = True
	
	    #node Frame.003
	    frame_003 = attach_hair_curves_to_surface.nodes.new("NodeFrame")
	    frame_003.label = "Blend Deformation"
	    frame_003.name = "Frame.003"
	    frame_003.label_size = 20
	    frame_003.shrink = True
	
	    #node Frame.002
	    frame_002_2 = attach_hair_curves_to_surface.nodes.new("NodeFrame")
	    frame_002_2.label = "Align to Normal"
	    frame_002_2.name = "Frame.002"
	    frame_002_2.use_custom_color = True
	    frame_002_2.color = (0.08883915841579437, 0.08883915841579437, 0.08883915841579437)
	    frame_002_2.label_size = 20
	    frame_002_2.shrink = True
	
	    #node Frame.008
	    frame_008 = attach_hair_curves_to_surface.nodes.new("NodeFrame")
	    frame_008.label = "Optimize"
	    frame_008.name = "Frame.008"
	    frame_008.label_size = 20
	    frame_008.shrink = True
	
	    #node Frame.009
	    frame_009 = attach_hair_curves_to_surface.nodes.new("NodeFrame")
	    frame_009.label = "Sample from Guide"
	    frame_009.name = "Frame.009"
	    frame_009.label_size = 20
	    frame_009.shrink = True
	
	    #node Reroute.010
	    reroute_010 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_010.name = "Reroute.010"
	    reroute_010.socket_idname = "NodeSocketGeometry"
	    #node Reroute.013
	    reroute_013_1 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_013_1.name = "Reroute.013"
	    reroute_013_1.socket_idname = "NodeSocketBool"
	    #node Group Output
	    group_output_5 = attach_hair_curves_to_surface.nodes.new("NodeGroupOutput")
	    group_output_5.name = "Group Output"
	    group_output_5.is_active_output = True
	
	    #node Reroute.003
	    reroute_003 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_003.name = "Reroute.003"
	    reroute_003.socket_idname = "NodeSocketVector"
	    #node Switch
	    switch_1 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSwitch")
	    switch_1.name = "Switch"
	    switch_1.input_type = 'GEOMETRY'
	
	    #node Store Named Attribute
	    store_named_attribute = attach_hair_curves_to_surface.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute.name = "Store Named Attribute"
	    store_named_attribute.data_type = 'FLOAT2'
	    store_named_attribute.domain = 'CURVE'
	    #Selection
	    store_named_attribute.inputs[1].default_value = True
	    #Name
	    store_named_attribute.inputs[2].default_value = "surface_uv_coordinate"
	
	    #node Group Input.007
	    group_input_007 = attach_hair_curves_to_surface.nodes.new("NodeGroupInput")
	    group_input_007.name = "Group Input.007"
	    group_input_007.outputs[0].hide = True
	    group_input_007.outputs[1].hide = True
	    group_input_007.outputs[2].hide = True
	    group_input_007.outputs[3].hide = True
	    group_input_007.outputs[4].hide = True
	    group_input_007.outputs[6].hide = True
	    group_input_007.outputs[7].hide = True
	    group_input_007.outputs[8].hide = True
	    group_input_007.outputs[9].hide = True
	
	    #node Reroute.016
	    reroute_016_1 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_016_1.name = "Reroute.016"
	    reroute_016_1.socket_idname = "NodeSocketGeometry"
	    #node Reroute.005
	    reroute_005_2 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_005_2.name = "Reroute.005"
	    reroute_005_2.socket_idname = "NodeSocketVector"
	    #node Store Named Attribute.001
	    store_named_attribute_001 = attach_hair_curves_to_surface.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_001.name = "Store Named Attribute.001"
	    store_named_attribute_001.data_type = 'FLOAT_VECTOR'
	    store_named_attribute_001.domain = 'CURVE'
	    #Selection
	    store_named_attribute_001.inputs[1].default_value = True
	    #Name
	    store_named_attribute_001.inputs[2].default_value = "surface_normal"
	
	    #node Named Attribute.004
	    named_attribute_004 = attach_hair_curves_to_surface.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute_004.name = "Named Attribute.004"
	    named_attribute_004.data_type = 'FLOAT_VECTOR'
	    #Name
	    named_attribute_004.inputs[0].default_value = "surface_normal"
	
	    #node Reroute.012
	    reroute_012_1 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_012_1.name = "Reroute.012"
	    reroute_012_1.socket_idname = "NodeSocketBool"
	    #node Reroute.014
	    reroute_014_1 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_014_1.name = "Reroute.014"
	    reroute_014_1.socket_idname = "NodeSocketBool"
	    #node Reroute.006
	    reroute_006_2 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_006_2.name = "Reroute.006"
	    reroute_006_2.socket_idname = "NodeSocketGeometry"
	    #node Named Attribute.003
	    named_attribute_003 = attach_hair_curves_to_surface.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute_003.name = "Named Attribute.003"
	    named_attribute_003.data_type = 'FLOAT_VECTOR'
	    #Name
	    named_attribute_003.inputs[0].default_value = "surface_uv_coordinate"
	
	    #node Switch.008
	    switch_008 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSwitch")
	    switch_008.name = "Switch.008"
	    switch_008.input_type = 'GEOMETRY'
	
	    #node Switch.009
	    switch_009 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSwitch")
	    switch_009.name = "Switch.009"
	    switch_009.input_type = 'VECTOR'
	
	    #node Switch.010
	    switch_010 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSwitch")
	    switch_010.name = "Switch.010"
	    switch_010.input_type = 'VECTOR'
	
	    #node Set Position.001
	    set_position_001_2 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSetPosition")
	    set_position_001_2.name = "Set Position.001"
	    set_position_001_2.inputs[2].hide = True
	    #Position
	    set_position_001_2.inputs[2].default_value = (0.0, 0.0, 0.0)
	
	    #node Reroute.002
	    reroute_002_1 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_002_1.name = "Reroute.002"
	    reroute_002_1.socket_idname = "NodeSocketVector"
	    #node Reroute.018
	    reroute_018_1 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_018_1.name = "Reroute.018"
	    reroute_018_1.socket_idname = "NodeSocketVector"
	    #node Reroute.017
	    reroute_017_1 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_017_1.name = "Reroute.017"
	    reroute_017_1.socket_idname = "NodeSocketGeometry"
	    #node Group Input.009
	    group_input_009 = attach_hair_curves_to_surface.nodes.new("NodeGroupInput")
	    group_input_009.name = "Group Input.009"
	    group_input_009.outputs[0].hide = True
	    group_input_009.outputs[1].hide = True
	    group_input_009.outputs[2].hide = True
	    group_input_009.outputs[4].hide = True
	    group_input_009.outputs[5].hide = True
	    group_input_009.outputs[6].hide = True
	    group_input_009.outputs[7].hide = True
	    group_input_009.outputs[8].hide = True
	    group_input_009.outputs[9].hide = True
	
	    #node Position
	    position = attach_hair_curves_to_surface.nodes.new("GeometryNodeInputPosition")
	    position.name = "Position"
	
	    #node Named Attribute.001
	    named_attribute_001 = attach_hair_curves_to_surface.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute_001.name = "Named Attribute.001"
	    named_attribute_001.data_type = 'FLOAT_VECTOR'
	    #Name
	    named_attribute_001.inputs[0].default_value = "surface_uv_coordinate"
	
	    #node Capture Attribute.001
	    capture_attribute_001_1 = attach_hair_curves_to_surface.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_001_1.name = "Capture Attribute.001"
	    capture_attribute_001_1.active_index = 0
	    capture_attribute_001_1.capture_items.clear()
	    capture_attribute_001_1.capture_items.new('FLOAT', "Value")
	    capture_attribute_001_1.capture_items["Value"].data_type = 'FLOAT_VECTOR'
	    capture_attribute_001_1.domain = 'CURVE'
	
	    #node Group Input.004
	    group_input_004_1 = attach_hair_curves_to_surface.nodes.new("NodeGroupInput")
	    group_input_004_1.name = "Group Input.004"
	    group_input_004_1.outputs[0].hide = True
	    group_input_004_1.outputs[2].hide = True
	    group_input_004_1.outputs[3].hide = True
	    group_input_004_1.outputs[4].hide = True
	    group_input_004_1.outputs[5].hide = True
	    group_input_004_1.outputs[6].hide = True
	    group_input_004_1.outputs[7].hide = True
	    group_input_004_1.outputs[8].hide = True
	    group_input_004_1.outputs[9].hide = True
	
	    #node Domain Size.002
	    domain_size_002 = attach_hair_curves_to_surface.nodes.new("GeometryNodeAttributeDomainSize")
	    domain_size_002.name = "Domain Size.002"
	    domain_size_002.component = 'MESH'
	    domain_size_002.outputs[0].hide = True
	    domain_size_002.outputs[1].hide = True
	    domain_size_002.outputs[3].hide = True
	    domain_size_002.outputs[4].hide = True
	    domain_size_002.outputs[5].hide = True
	
	    #node Compare.001
	    compare_001 = attach_hair_curves_to_surface.nodes.new("FunctionNodeCompare")
	    compare_001.name = "Compare.001"
	    compare_001.data_type = 'INT'
	    compare_001.mode = 'ELEMENT'
	    compare_001.operation = 'NOT_EQUAL'
	    #B_INT
	    compare_001.inputs[3].default_value = 0
	
	    #node Object Info.001
	    object_info_001 = attach_hair_curves_to_surface.nodes.new("GeometryNodeObjectInfo")
	    object_info_001.name = "Object Info.001"
	    object_info_001.transform_space = 'ORIGINAL'
	    object_info_001.inputs[1].hide = True
	    object_info_001.outputs[1].hide = True
	    object_info_001.outputs[3].hide = True
	    #As Instance
	    object_info_001.inputs[1].default_value = False
	
	    #node Group Input.002
	    group_input_002_2 = attach_hair_curves_to_surface.nodes.new("NodeGroupInput")
	    group_input_002_2.name = "Group Input.002"
	    group_input_002_2.outputs[0].hide = True
	    group_input_002_2.outputs[1].hide = True
	    group_input_002_2.outputs[3].hide = True
	    group_input_002_2.outputs[4].hide = True
	    group_input_002_2.outputs[5].hide = True
	    group_input_002_2.outputs[6].hide = True
	    group_input_002_2.outputs[7].hide = True
	    group_input_002_2.outputs[8].hide = True
	    group_input_002_2.outputs[9].hide = True
	
	    #node Switch.005
	    switch_005_1 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSwitch")
	    switch_005_1.name = "Switch.005"
	    switch_005_1.input_type = 'GEOMETRY'
	
	    #node Domain Size.003
	    domain_size_003 = attach_hair_curves_to_surface.nodes.new("GeometryNodeAttributeDomainSize")
	    domain_size_003.name = "Domain Size.003"
	    domain_size_003.component = 'MESH'
	    domain_size_003.outputs[0].hide = True
	    domain_size_003.outputs[1].hide = True
	    domain_size_003.outputs[3].hide = True
	    domain_size_003.outputs[4].hide = True
	    domain_size_003.outputs[5].hide = True
	
	    #node Compare.002
	    compare_002_2 = attach_hair_curves_to_surface.nodes.new("FunctionNodeCompare")
	    compare_002_2.name = "Compare.002"
	    compare_002_2.data_type = 'INT'
	    compare_002_2.mode = 'ELEMENT'
	    compare_002_2.operation = 'EQUAL'
	    #B_INT
	    compare_002_2.inputs[3].default_value = 0
	
	    #node Named Attribute
	    named_attribute_1 = attach_hair_curves_to_surface.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute_1.name = "Named Attribute"
	    named_attribute_1.data_type = 'FLOAT_VECTOR'
	    #Name
	    named_attribute_1.inputs[0].default_value = "rest_position"
	
	    #node Reroute
	    reroute_3 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_3.name = "Reroute"
	    reroute_3.socket_idname = "NodeSocketGeometry"
	    #node Group Input.005
	    group_input_005_2 = attach_hair_curves_to_surface.nodes.new("NodeGroupInput")
	    group_input_005_2.name = "Group Input.005"
	    group_input_005_2.outputs[0].hide = True
	    group_input_005_2.outputs[1].hide = True
	    group_input_005_2.outputs[2].hide = True
	    group_input_005_2.outputs[3].hide = True
	    group_input_005_2.outputs[5].hide = True
	    group_input_005_2.outputs[6].hide = True
	    group_input_005_2.outputs[7].hide = True
	    group_input_005_2.outputs[8].hide = True
	    group_input_005_2.outputs[9].hide = True
	
	    #node Set Position
	    set_position = attach_hair_curves_to_surface.nodes.new("GeometryNodeSetPosition")
	    set_position.name = "Set Position"
	    set_position.inputs[3].hide = True
	    #Offset
	    set_position.inputs[3].default_value = (0.0, 0.0, 0.0)
	
	    #node Switch.007
	    switch_007 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSwitch")
	    switch_007.name = "Switch.007"
	    switch_007.input_type = 'GEOMETRY'
	
	    #node Reroute.015
	    reroute_015_1 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_015_1.name = "Reroute.015"
	    reroute_015_1.socket_idname = "NodeSocketBool"
	    #node Reroute.011
	    reroute_011_1 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_011_1.name = "Reroute.011"
	    reroute_011_1.socket_idname = "NodeSocketGeometry"
	    #node Group Input
	    group_input_3 = attach_hair_curves_to_surface.nodes.new("NodeGroupInput")
	    group_input_3.name = "Group Input"
	    group_input_3.outputs[1].hide = True
	    group_input_3.outputs[2].hide = True
	    group_input_3.outputs[3].hide = True
	    group_input_3.outputs[4].hide = True
	    group_input_3.outputs[5].hide = True
	    group_input_3.outputs[6].hide = True
	    group_input_3.outputs[7].hide = True
	    group_input_3.outputs[8].hide = True
	    group_input_3.outputs[9].hide = True
	
	    #node Capture Attribute.002
	    capture_attribute_002 = attach_hair_curves_to_surface.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_002.name = "Capture Attribute.002"
	    capture_attribute_002.active_index = 0
	    capture_attribute_002.capture_items.clear()
	    capture_attribute_002.capture_items.new('FLOAT', "Value")
	    capture_attribute_002.capture_items["Value"].data_type = 'FLOAT_VECTOR'
	    capture_attribute_002.domain = 'CURVE'
	
	    #node Reroute.001
	    reroute_001_2 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_001_2.name = "Reroute.001"
	    reroute_001_2.socket_idname = "NodeSocketGeometry"
	    #node Sample Nearest Surface
	    sample_nearest_surface = attach_hair_curves_to_surface.nodes.new("GeometryNodeSampleNearestSurface")
	    sample_nearest_surface.name = "Sample Nearest Surface"
	    sample_nearest_surface.data_type = 'FLOAT_VECTOR'
	    #Group ID
	    sample_nearest_surface.inputs[2].default_value = 0
	    #Sample Group ID
	    sample_nearest_surface.inputs[4].default_value = 0
	
	    #node Group Input.001
	    group_input_001_2 = attach_hair_curves_to_surface.nodes.new("NodeGroupInput")
	    group_input_001_2.name = "Group Input.001"
	    group_input_001_2.outputs[0].hide = True
	    group_input_001_2.outputs[1].hide = True
	    group_input_001_2.outputs[2].hide = True
	    group_input_001_2.outputs[4].hide = True
	    group_input_001_2.outputs[5].hide = True
	    group_input_001_2.outputs[6].hide = True
	    group_input_001_2.outputs[7].hide = True
	    group_input_001_2.outputs[8].hide = True
	    group_input_001_2.outputs[9].hide = True
	
	    #node Reroute.020
	    reroute_020 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_020.name = "Reroute.020"
	    reroute_020.socket_idname = "NodeSocketGeometry"
	    #node Normal
	    normal = attach_hair_curves_to_surface.nodes.new("GeometryNodeInputNormal")
	    normal.name = "Normal"
	    normal.legacy_corner_normals = True
	
	    #node Capture Attribute
	    capture_attribute = attach_hair_curves_to_surface.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute.name = "Capture Attribute"
	    capture_attribute.hide = True
	    capture_attribute.active_index = 0
	    capture_attribute.capture_items.clear()
	    capture_attribute.capture_items.new('FLOAT', "Value")
	    capture_attribute.capture_items["Value"].data_type = 'FLOAT_VECTOR'
	    capture_attribute.domain = 'POINT'
	
	    #node Sample UV Surface
	    sample_uv_surface = attach_hair_curves_to_surface.nodes.new("GeometryNodeSampleUVSurface")
	    sample_uv_surface.name = "Sample UV Surface"
	    sample_uv_surface.hide = True
	    sample_uv_surface.data_type = 'FLOAT_VECTOR'
	    sample_uv_surface.outputs[1].hide = True
	
	    #node Sample UV Surface.003
	    sample_uv_surface_003 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSampleUVSurface")
	    sample_uv_surface_003.name = "Sample UV Surface.003"
	    sample_uv_surface_003.hide = True
	    sample_uv_surface_003.data_type = 'FLOAT_VECTOR'
	    sample_uv_surface_003.outputs[1].hide = True
	
	    #node Reroute.004
	    reroute_004_2 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_004_2.name = "Reroute.004"
	    reroute_004_2.socket_idname = "NodeSocketVector"
	    #node Sample UV Surface.001
	    sample_uv_surface_001 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSampleUVSurface")
	    sample_uv_surface_001.name = "Sample UV Surface.001"
	    sample_uv_surface_001.hide = True
	    sample_uv_surface_001.data_type = 'FLOAT_VECTOR'
	    sample_uv_surface_001.outputs[1].hide = True
	
	    #node Position.001
	    position_001_2 = attach_hair_curves_to_surface.nodes.new("GeometryNodeInputPosition")
	    position_001_2.name = "Position.001"
	
	    #node Vector Math
	    vector_math_2 = attach_hair_curves_to_surface.nodes.new("ShaderNodeVectorMath")
	    vector_math_2.name = "Vector Math"
	    vector_math_2.operation = 'SUBTRACT'
	
	    #node Vector Math.001
	    vector_math_001_1 = attach_hair_curves_to_surface.nodes.new("ShaderNodeVectorMath")
	    vector_math_001_1.name = "Vector Math.001"
	    vector_math_001_1.operation = 'SUBTRACT'
	
	    #node Vector Math.004
	    vector_math_004_1 = attach_hair_curves_to_surface.nodes.new("ShaderNodeVectorMath")
	    vector_math_004_1.name = "Vector Math.004"
	    vector_math_004_1.operation = 'SUBTRACT'
	
	    #node Vector Math.003
	    vector_math_003 = attach_hair_curves_to_surface.nodes.new("ShaderNodeVectorMath")
	    vector_math_003.name = "Vector Math.003"
	    vector_math_003.operation = 'SUBTRACT'
	
	    #node Group Input.003
	    group_input_003_2 = attach_hair_curves_to_surface.nodes.new("NodeGroupInput")
	    group_input_003_2.name = "Group Input.003"
	    group_input_003_2.outputs[0].hide = True
	    group_input_003_2.outputs[1].hide = True
	    group_input_003_2.outputs[2].hide = True
	    group_input_003_2.outputs[3].hide = True
	    group_input_003_2.outputs[4].hide = True
	    group_input_003_2.outputs[5].hide = True
	    group_input_003_2.outputs[6].hide = True
	    group_input_003_2.outputs[8].hide = True
	    group_input_003_2.outputs[9].hide = True
	
	    #node Group Input.006
	    group_input_006_1 = attach_hair_curves_to_surface.nodes.new("NodeGroupInput")
	    group_input_006_1.name = "Group Input.006"
	    group_input_006_1.outputs[0].hide = True
	    group_input_006_1.outputs[1].hide = True
	    group_input_006_1.outputs[2].hide = True
	    group_input_006_1.outputs[3].hide = True
	    group_input_006_1.outputs[4].hide = True
	    group_input_006_1.outputs[5].hide = True
	    group_input_006_1.outputs[7].hide = True
	    group_input_006_1.outputs[8].hide = True
	    group_input_006_1.outputs[9].hide = True
	
	    #node Switch.003
	    switch_003_2 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSwitch")
	    switch_003_2.name = "Switch.003"
	    switch_003_2.hide = True
	    switch_003_2.input_type = 'VECTOR'
	    #False
	    switch_003_2.inputs[1].default_value = (0.0, 0.0, 0.0)
	
	    #node Switch.002
	    switch_002_1 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSwitch")
	    switch_002_1.name = "Switch.002"
	    switch_002_1.input_type = 'VECTOR'
	
	    #node Vector Math.002
	    vector_math_002 = attach_hair_curves_to_surface.nodes.new("ShaderNodeVectorMath")
	    vector_math_002.name = "Vector Math.002"
	    vector_math_002.operation = 'ADD'
	
	    #node Vector Math.005
	    vector_math_005 = attach_hair_curves_to_surface.nodes.new("ShaderNodeVectorMath")
	    vector_math_005.name = "Vector Math.005"
	    vector_math_005.operation = 'SCALE'
	
	    #node Boolean Math
	    boolean_math_2 = attach_hair_curves_to_surface.nodes.new("FunctionNodeBooleanMath")
	    boolean_math_2.name = "Boolean Math"
	    boolean_math_2.operation = 'OR'
	
	    #node Spline Parameter
	    spline_parameter_1 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSplineParameter")
	    spline_parameter_1.name = "Spline Parameter"
	    spline_parameter_1.outputs[1].hide = True
	    spline_parameter_1.outputs[2].hide = True
	
	    #node Group Input.008
	    group_input_008 = attach_hair_curves_to_surface.nodes.new("NodeGroupInput")
	    group_input_008.name = "Group Input.008"
	    group_input_008.outputs[0].hide = True
	    group_input_008.outputs[1].hide = True
	    group_input_008.outputs[2].hide = True
	    group_input_008.outputs[3].hide = True
	    group_input_008.outputs[4].hide = True
	    group_input_008.outputs[5].hide = True
	    group_input_008.outputs[6].hide = True
	    group_input_008.outputs[7].hide = True
	    group_input_008.outputs[9].hide = True
	
	    #node Map Range
	    map_range = attach_hair_curves_to_surface.nodes.new("ShaderNodeMapRange")
	    map_range.name = "Map Range"
	    map_range.hide = True
	    map_range.clamp = True
	    map_range.data_type = 'FLOAT'
	    map_range.interpolation_type = 'SMOOTHSTEP'
	    #From Min
	    map_range.inputs[1].default_value = 0.0
	    #To Min
	    map_range.inputs[3].default_value = 1.0
	    #To Max
	    map_range.inputs[4].default_value = 0.0
	
	    #node Compare
	    compare_1 = attach_hair_curves_to_surface.nodes.new("FunctionNodeCompare")
	    compare_1.name = "Compare"
	    compare_1.data_type = 'FLOAT'
	    compare_1.mode = 'ELEMENT'
	    compare_1.operation = 'EQUAL'
	    #B
	    compare_1.inputs[1].default_value = 0.0
	    #Epsilon
	    compare_1.inputs[12].default_value = 0.0
	
	    #node Switch.004
	    switch_004_1 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSwitch")
	    switch_004_1.name = "Switch.004"
	    switch_004_1.input_type = 'FLOAT'
	    #True
	    switch_004_1.inputs[2].default_value = 1.0
	
	    #node Position.002
	    position_002_2 = attach_hair_curves_to_surface.nodes.new("GeometryNodeInputPosition")
	    position_002_2.name = "Position.002"
	
	    #node Evaluate on Domain
	    evaluate_on_domain = attach_hair_curves_to_surface.nodes.new("GeometryNodeFieldOnDomain")
	    evaluate_on_domain.name = "Evaluate on Domain"
	    evaluate_on_domain.data_type = 'FLOAT_VECTOR'
	    evaluate_on_domain.domain = 'CURVE'
	
	    #node Reroute.009
	    reroute_009_1 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_009_1.name = "Reroute.009"
	    reroute_009_1.socket_idname = "NodeSocketVector"
	    #node Evaluate on Domain.002
	    evaluate_on_domain_002 = attach_hair_curves_to_surface.nodes.new("GeometryNodeFieldOnDomain")
	    evaluate_on_domain_002.name = "Evaluate on Domain.002"
	    evaluate_on_domain_002.hide = True
	    evaluate_on_domain_002.data_type = 'FLOAT_VECTOR'
	    evaluate_on_domain_002.domain = 'CURVE'
	
	    #node Switch.006
	    switch_006 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSwitch")
	    switch_006.name = "Switch.006"
	    switch_006.input_type = 'VECTOR'
	
	    #node Vector Rotate
	    vector_rotate = attach_hair_curves_to_surface.nodes.new("ShaderNodeVectorRotate")
	    vector_rotate.name = "Vector Rotate"
	    vector_rotate.invert = False
	    vector_rotate.rotation_type = 'EULER_XYZ'
	    vector_rotate.inputs[1].hide = True
	    vector_rotate.inputs[2].hide = True
	    vector_rotate.inputs[3].hide = True
	    #Center
	    vector_rotate.inputs[1].default_value = (0.0, 0.0, 0.0)
	
	    #node Vector Rotate.003
	    vector_rotate_003 = attach_hair_curves_to_surface.nodes.new("ShaderNodeVectorRotate")
	    vector_rotate_003.name = "Vector Rotate.003"
	    vector_rotate_003.invert = True
	    vector_rotate_003.rotation_type = 'EULER_XYZ'
	    vector_rotate_003.inputs[1].hide = True
	    vector_rotate_003.inputs[2].hide = True
	    vector_rotate_003.inputs[3].hide = True
	    #Center
	    vector_rotate_003.inputs[1].default_value = (0.0, 0.0, 0.0)
	
	    #node Align Euler to Vector.003
	    align_euler_to_vector_003 = attach_hair_curves_to_surface.nodes.new("FunctionNodeAlignEulerToVector")
	    align_euler_to_vector_003.name = "Align Euler to Vector.003"
	    align_euler_to_vector_003.axis = 'Z'
	    align_euler_to_vector_003.pivot_axis = 'AUTO'
	    align_euler_to_vector_003.inputs[0].hide = True
	    align_euler_to_vector_003.inputs[1].hide = True
	    #Rotation
	    align_euler_to_vector_003.inputs[0].default_value = (0.0, 0.0, 0.0)
	    #Factor
	    align_euler_to_vector_003.inputs[1].default_value = 1.0
	
	    #node Align Euler to Vector.002
	    align_euler_to_vector_002 = attach_hair_curves_to_surface.nodes.new("FunctionNodeAlignEulerToVector")
	    align_euler_to_vector_002.name = "Align Euler to Vector.002"
	    align_euler_to_vector_002.axis = 'Z'
	    align_euler_to_vector_002.pivot_axis = 'AUTO'
	    align_euler_to_vector_002.inputs[0].hide = True
	    align_euler_to_vector_002.inputs[1].hide = True
	    #Rotation
	    align_euler_to_vector_002.inputs[0].default_value = (0.0, 0.0, 0.0)
	    #Factor
	    align_euler_to_vector_002.inputs[1].default_value = 1.0
	
	    #node Evaluate on Domain.003
	    evaluate_on_domain_003 = attach_hair_curves_to_surface.nodes.new("GeometryNodeFieldOnDomain")
	    evaluate_on_domain_003.name = "Evaluate on Domain.003"
	    evaluate_on_domain_003.hide = True
	    evaluate_on_domain_003.data_type = 'FLOAT_VECTOR'
	    evaluate_on_domain_003.domain = 'CURVE'
	
	    #node Switch.001
	    switch_001_3 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSwitch")
	    switch_001_3.name = "Switch.001"
	    switch_001_3.hide = True
	    switch_001_3.input_type = 'VECTOR'
	
	    #node Accumulate Field
	    accumulate_field_1 = attach_hair_curves_to_surface.nodes.new("GeometryNodeAccumulateField")
	    accumulate_field_1.name = "Accumulate Field"
	    accumulate_field_1.hide = True
	    accumulate_field_1.data_type = 'FLOAT'
	    accumulate_field_1.domain = 'POINT'
	    #Group Index
	    accumulate_field_1.inputs[1].default_value = 0
	
	    #node Sample Index.001
	    sample_index_001 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSampleIndex")
	    sample_index_001.name = "Sample Index.001"
	    sample_index_001.hide = True
	    sample_index_001.clamp = False
	    sample_index_001.data_type = 'BOOLEAN'
	    sample_index_001.domain = 'CURVE'
	    #Index
	    sample_index_001.inputs[2].default_value = 0
	
	    #node Reroute.019
	    reroute_019 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_019.name = "Reroute.019"
	    reroute_019.socket_idname = "NodeSocketVector"
	    #node Named Attribute.002
	    named_attribute_002 = attach_hair_curves_to_surface.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute_002.name = "Named Attribute.002"
	    named_attribute_002.data_type = 'INT'
	    #Name
	    named_attribute_002.inputs[0].default_value = "guide_curve_index"
	
	    #node Reroute.007
	    reroute_007_2 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_007_2.name = "Reroute.007"
	    reroute_007_2.socket_idname = "NodeSocketGeometry"
	    #node Reroute.008
	    reroute_008_2 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_008_2.name = "Reroute.008"
	    reroute_008_2.socket_idname = "NodeSocketVector"
	    #node Sample Index
	    sample_index = attach_hair_curves_to_surface.nodes.new("GeometryNodeSampleIndex")
	    sample_index.name = "Sample Index"
	    sample_index.hide = True
	    sample_index.clamp = False
	    sample_index.data_type = 'FLOAT_VECTOR'
	    sample_index.domain = 'CURVE'
	
	    #node Group.002
	    group_002 = attach_hair_curves_to_surface.nodes.new("GeometryNodeGroup")
	    group_002.name = "Group.002"
	    group_002.node_tree = curve_root
	    group_002.outputs[0].hide = True
	    group_002.outputs[2].hide = True
	    group_002.outputs[3].hide = True
	
	    #node Group.003
	    group_003 = attach_hair_curves_to_surface.nodes.new("GeometryNodeGroup")
	    group_003.name = "Group.003"
	    group_003.node_tree = curve_root
	    group_003.outputs[0].hide = True
	    group_003.outputs[2].hide = True
	    group_003.outputs[3].hide = True
	
	
	
	
	    #Set parents
	    frame_006.parent = frame_2
	    frame_007.parent = frame_2
	    frame_003.parent = frame_010
	    frame_002_2.parent = frame_010
	    frame_008.parent = frame_002_2
	    frame_009.parent = frame_002_2
	    reroute_003.parent = frame_004
	    switch_1.parent = frame_004
	    store_named_attribute.parent = frame_004
	    group_input_007.parent = frame_004
	    reroute_016_1.parent = frame_004
	    reroute_005_2.parent = frame_004
	    store_named_attribute_001.parent = frame_004
	    named_attribute_004.parent = frame_004
	    reroute_012_1.parent = frame_004
	    named_attribute_003.parent = frame_004
	    switch_008.parent = frame_004
	    switch_009.parent = frame_004
	    switch_010.parent = frame_004
	    reroute_002_1.parent = frame_005
	    reroute_018_1.parent = frame_005
	    reroute_017_1.parent = frame_005
	    group_input_009.parent = frame_005
	    position.parent = frame_005
	    named_attribute_001.parent = frame_005
	    group_input_004_1.parent = frame_006
	    domain_size_002.parent = frame_006
	    compare_001.parent = frame_006
	    object_info_001.parent = frame_007
	    group_input_002_2.parent = frame_007
	    switch_005_1.parent = frame_2
	    domain_size_003.parent = frame_2
	    compare_002_2.parent = frame_2
	    named_attribute_1.parent = frame_2
	    reroute_3.parent = frame_2
	    group_input_005_2.parent = frame_2
	    set_position.parent = frame_2
	    switch_007.parent = frame_2
	    sample_nearest_surface.parent = frame_011
	    group_input_001_2.parent = frame_011
	    normal.parent = frame_001_1
	    capture_attribute.parent = frame_001_1
	    sample_uv_surface.parent = frame_005
	    sample_uv_surface_003.parent = frame_005
	    reroute_004_2.parent = frame_005
	    sample_uv_surface_001.parent = frame_005
	    position_001_2.parent = frame_010
	    vector_math_2.parent = frame_010
	    vector_math_001_1.parent = frame_010
	    vector_math_004_1.parent = frame_010
	    vector_math_003.parent = frame_010
	    group_input_003_2.parent = frame_010
	    group_input_006_1.parent = frame_010
	    switch_003_2.parent = frame_010
	    switch_002_1.parent = frame_010
	    vector_math_002.parent = frame_010
	    vector_math_005.parent = frame_010
	    boolean_math_2.parent = frame_010
	    spline_parameter_1.parent = frame_003
	    group_input_008.parent = frame_003
	    map_range.parent = frame_003
	    compare_1.parent = frame_003
	    switch_004_1.parent = frame_003
	    position_002_2.parent = frame_010
	    evaluate_on_domain.parent = frame_010
	    reroute_009_1.parent = frame_002_2
	    evaluate_on_domain_002.parent = frame_002_2
	    switch_006.parent = frame_002_2
	    vector_rotate.parent = frame_002_2
	    vector_rotate_003.parent = frame_002_2
	    align_euler_to_vector_003.parent = frame_002_2
	    align_euler_to_vector_002.parent = frame_002_2
	    evaluate_on_domain_003.parent = frame_002_2
	    switch_001_3.parent = frame_008
	    accumulate_field_1.parent = frame_008
	    sample_index_001.parent = frame_008
	    reroute_019.parent = frame_002_2
	    named_attribute_002.parent = frame_009
	    reroute_007_2.parent = frame_009
	    reroute_008_2.parent = frame_009
	    sample_index.parent = frame_009
	    group_002.parent = frame_010
	    group_003.parent = frame_011
	
	    #Set locations
	    frame_004.location = (-1215.903076171875, 262.0)
	    frame_005.location = (-4968.0, -121.0)
	    frame_2.location = (-7319.0, 140.0)
	    frame_006.location = (30.0, -355.0)
	    frame_007.location = (207.0, -181.0)
	    frame_011.location = (-5753.0, 120.0)
	    frame_001_1.location = (-5510.0, -382.0)
	    frame_010.location = (-4110.3515625, 32.0)
	    frame_003.location = (1565.3515625, -503.0)
	    frame_002_2.location = (29.999755859375, -437.0)
	    frame_008.location = (219.351806640625, -40.0)
	    frame_009.location = (30.0, -217.5032958984375)
	    reroute_010.location = (-798.60986328125, 472.99615478515625)
	    reroute_013_1.location = (-789.0, 512.1389770507812)
	    group_output_5.location = (75.0, 50.0)
	    reroute_003.location = (35.0, -292.3721618652344)
	    switch_1.location = (320.95263671875, -40.143096923828125)
	    store_named_attribute.location = (115.3720703125, -151.72100830078125)
	    group_input_007.location = (122.9049072265625, -39.53450012207031)
	    reroute_016_1.location = (45.1358642578125, -151.72100830078125)
	    reroute_005_2.location = (406.810302734375, -272.2791442871094)
	    store_named_attribute_001.location = (527.368408203125, -51.255889892578125)
	    named_attribute_004.location = (607.740478515625, -513.3954467773438)
	    reroute_012_1.location = (768.484619140625, -252.18612670898438)
	    reroute_014_1.location = (-507.69775390625, 311.209228515625)
	    reroute_006_2.location = (-547.8837890625, 291.1162109375)
	    named_attribute_003.location = (607.740478515625, -352.6512451171875)
	    switch_008.location = (808.670654296875, -71.34890747070312)
	    switch_009.location = (808.670654296875, -212.00006103515625)
	    switch_010.location = (808.670654296875, -392.8372802734375)
	    set_position_001_2.location = (-1472.16259765625, 230.837158203125)
	    reroute_002_1.location = (220.65625, -190.25262451171875)
	    reroute_018_1.location = (220.65625, -150.06658935546875)
	    reroute_017_1.location = (220.65625, -109.88055419921875)
	    group_input_009.location = (29.99072265625, -180.322021484375)
	    position.location = (29.99072265625, -39.67083740234375)
	    named_attribute_001.location = (29.99072265625, -260.694091796875)
	    capture_attribute_001_1.location = (-4365.55810546875, 210.744140625)
	    group_input_004_1.location = (29.669921875, -178.9044189453125)
	    domain_size_002.location = (207.6806640625, -80.07354736328125)
	    compare_001.location = (388.517578125, -39.88751220703125)
	    object_info_001.location = (210.88330078125, -39.64691162109375)
	    group_input_002_2.location = (30.0458984375, -79.83294677734375)
	    switch_005_1.location = (640.525390625, -283.5823974609375)
	    domain_size_003.location = (938.8193359375, -79.91128540039062)
	    compare_002_2.location = (1119.65625, -39.725250244140625)
	    named_attribute_1.location = (820.7041015625, -432.90301513671875)
	    reroute_3.location = (961.35546875, -332.43792724609375)
	    group_input_005_2.location = (1021.63427734375, -252.0657958984375)
	    set_position.location = (1021.63427734375, -352.53094482421875)
	    switch_007.location = (1222.564453125, -231.9727783203125)
	    reroute_015_1.location = (-5129.0927734375, 532.2319946289062)
	    reroute_011_1.location = (-5109.0, 492.04595947265625)
	    group_input_3.location = (-5510.8603515625, 351.395263671875)
	    capture_attribute_002.location = (-5209.46484375, 230.837158203125)
	    reroute_001_2.location = (-4887.9765625, -653.2559814453125)
	    sample_nearest_surface.location = (211.7509765625, -40.199798583984375)
	    group_input_001_2.location = (30.9140625, -100.4788818359375)
	    reroute_020.location = (-4526.30224609375, -10.2791748046875)
	    normal.location = (29.5712890625, -45.01953125)
	    capture_attribute.location = (230.50146484375, -45.01953125)
	    sample_uv_surface.location = (321.1396484375, -50.02386474609375)
	    sample_uv_surface_003.location = (321.1396484375, -130.39593505859375)
	    reroute_004_2.location = (220.6748046875, -230.86102294921875)
	    sample_uv_surface_001.location = (321.1396484375, -210.76800537109375)
	    position_001_2.location = (339.46484375, -321.08465576171875)
	    vector_math_2.location = (339.46484375, -140.2474365234375)
	    vector_math_001_1.location = (540.39501953125, -321.08465576171875)
	    vector_math_004_1.location = (1826.3486328125, -341.17767333984375)
	    vector_math_003.location = (2027.27880859375, -200.52651977539062)
	    group_input_003_2.location = (1424.48828125, -220.79666137695312)
	    group_input_006_1.location = (1424.48828125, -100.238525390625)
	    switch_003_2.location = (1625.41845703125, -180.61062622070312)
	    switch_002_1.location = (1625.41845703125, -220.79666137695312)
	    vector_math_002.location = (1826.3486328125, -140.424560546875)
	    vector_math_005.location = (2248.30224609375, -200.70364379882812)
	    boolean_math_2.location = (1625.41845703125, -39.959442138671875)
	    spline_parameter_1.location = (32.72265625, -81.9400634765625)
	    group_input_008.location = (30.322265625, -161.4296875)
	    map_range.location = (205.259765625, -190.3057861328125)
	    compare_1.location = (205.20068359375, -39.6795654296875)
	    switch_004_1.location = (386.037841796875, -59.772705078125)
	    position_002_2.location = (1625.41845703125, -371.6761474609375)
	    evaluate_on_domain.location = (531.248291015625, -115.30325317382812)
	    reroute_009_1.location = (731.747802734375, -64.921875)
	    evaluate_on_domain_002.location = (630.95361328125, -265.85211181640625)
	    switch_006.location = (992.6279296875, -64.921875)
	    vector_rotate.location = (1173.465087890625, -64.921875)
	    vector_rotate_003.location = (811.790771484375, -165.386962890625)
	    align_euler_to_vector_003.location = (630.95361328125, -165.386962890625)
	    align_euler_to_vector_002.location = (630.95361328125, -306.0382080078125)
	    evaluate_on_domain_003.location = (630.95361328125, -406.5032958984375)
	    switch_001_3.location = (210.67138671875, -105.2939453125)
	    accumulate_field_1.location = (29.834228515625, -45.014892578125)
	    sample_index_001.location = (29.834228515625, -85.200927734375)
	    reroute_019.location = (48.255859375, -185.48004150390625)
	    named_attribute_002.location = (35.0, -105.279052734375)
	    reroute_007_2.location = (35.0, -45.0)
	    reroute_008_2.location = (35.0, -85.18603515625)
	    sample_index.location = (215.837158203125, -65.093017578125)
	    group_002.location = (151.73974609375, -255.81243896484375)
	    group_003.location = (30.05615234375, -185.4729461669922)
	
	    #Set dimensions
	    frame_004.width, frame_004.height = 978.903076171875, 664.0
	    frame_005.width, frame_005.height = 491.0, 412.0
	    frame_2.width, frame_2.height = 1393.0, 646.0
	    frame_006.width, frame_006.height = 559.0, 261.0
	    frame_007.width, frame_007.height = 381.0, 215.0
	    frame_011.width, frame_011.height = 391.33642578125, 293.0
	    frame_001_1.width, frame_001_1.height = 401.0, 125.0
	    frame_010.width, frame_010.height = 2418.3515625, 971.0
	    frame_003.width, frame_003.height = 556.0, 250.0
	    frame_002_2.width, frame_002_2.height = 1343.351806640625, 504.0
	    frame_008.width, frame_008.height = 381.0, 160.0
	    frame_009.width, frame_009.height = 385.351806640625, 256.4967041015625
	    reroute_010.width, reroute_010.height = 10.0, 100.0
	    reroute_013_1.width, reroute_013_1.height = 10.0, 100.0
	    group_output_5.width, group_output_5.height = 140.0, 100.0
	    reroute_003.width, reroute_003.height = 10.0, 100.0
	    switch_1.width, switch_1.height = 140.0, 100.0
	    store_named_attribute.width, store_named_attribute.height = 140.0, 100.0
	    group_input_007.width, group_input_007.height = 140.0, 100.0
	    reroute_016_1.width, reroute_016_1.height = 10.0, 100.0
	    reroute_005_2.width, reroute_005_2.height = 10.0, 100.0
	    store_named_attribute_001.width, store_named_attribute_001.height = 140.0, 100.0
	    named_attribute_004.width, named_attribute_004.height = 140.0, 100.0
	    reroute_012_1.width, reroute_012_1.height = 10.0, 100.0
	    reroute_014_1.width, reroute_014_1.height = 10.0, 100.0
	    reroute_006_2.width, reroute_006_2.height = 10.0, 100.0
	    named_attribute_003.width, named_attribute_003.height = 140.0, 100.0
	    switch_008.width, switch_008.height = 140.0, 100.0
	    switch_009.width, switch_009.height = 140.0, 100.0
	    switch_010.width, switch_010.height = 140.0, 100.0
	    set_position_001_2.width, set_position_001_2.height = 140.0, 100.0
	    reroute_002_1.width, reroute_002_1.height = 10.0, 100.0
	    reroute_018_1.width, reroute_018_1.height = 10.0, 100.0
	    reroute_017_1.width, reroute_017_1.height = 10.0, 100.0
	    group_input_009.width, group_input_009.height = 140.0, 100.0
	    position.width, position.height = 140.0, 100.0
	    named_attribute_001.width, named_attribute_001.height = 140.0, 100.0
	    capture_attribute_001_1.width, capture_attribute_001_1.height = 140.0, 100.0
	    group_input_004_1.width, group_input_004_1.height = 140.0, 100.0
	    domain_size_002.width, domain_size_002.height = 140.0, 100.0
	    compare_001.width, compare_001.height = 140.0, 100.0
	    object_info_001.width, object_info_001.height = 140.0, 100.0
	    group_input_002_2.width, group_input_002_2.height = 140.0, 100.0
	    switch_005_1.width, switch_005_1.height = 140.0, 100.0
	    domain_size_003.width, domain_size_003.height = 140.0, 100.0
	    compare_002_2.width, compare_002_2.height = 140.0, 100.0
	    named_attribute_1.width, named_attribute_1.height = 140.0, 100.0
	    reroute_3.width, reroute_3.height = 10.0, 100.0
	    group_input_005_2.width, group_input_005_2.height = 140.0, 100.0
	    set_position.width, set_position.height = 140.0, 100.0
	    switch_007.width, switch_007.height = 140.0, 100.0
	    reroute_015_1.width, reroute_015_1.height = 10.0, 100.0
	    reroute_011_1.width, reroute_011_1.height = 10.0, 100.0
	    group_input_3.width, group_input_3.height = 140.0, 100.0
	    capture_attribute_002.width, capture_attribute_002.height = 140.0, 100.0
	    reroute_001_2.width, reroute_001_2.height = 10.0, 100.0
	    sample_nearest_surface.width, sample_nearest_surface.height = 149.33627319335938, 100.0
	    group_input_001_2.width, group_input_001_2.height = 140.0, 100.0
	    reroute_020.width, reroute_020.height = 10.0, 100.0
	    normal.width, normal.height = 140.0, 100.0
	    capture_attribute.width, capture_attribute.height = 140.0, 100.0
	    sample_uv_surface.width, sample_uv_surface.height = 140.0, 100.0
	    sample_uv_surface_003.width, sample_uv_surface_003.height = 140.0, 100.0
	    reroute_004_2.width, reroute_004_2.height = 10.0, 100.0
	    sample_uv_surface_001.width, sample_uv_surface_001.height = 140.0, 100.0
	    position_001_2.width, position_001_2.height = 140.0, 100.0
	    vector_math_2.width, vector_math_2.height = 140.0, 100.0
	    vector_math_001_1.width, vector_math_001_1.height = 140.0, 100.0
	    vector_math_004_1.width, vector_math_004_1.height = 140.0, 100.0
	    vector_math_003.width, vector_math_003.height = 140.0, 100.0
	    group_input_003_2.width, group_input_003_2.height = 140.0, 100.0
	    group_input_006_1.width, group_input_006_1.height = 140.0, 100.0
	    switch_003_2.width, switch_003_2.height = 140.0, 100.0
	    switch_002_1.width, switch_002_1.height = 140.0, 100.0
	    vector_math_002.width, vector_math_002.height = 140.0, 100.0
	    vector_math_005.width, vector_math_005.height = 140.0, 100.0
	    boolean_math_2.width, boolean_math_2.height = 140.0, 100.0
	    spline_parameter_1.width, spline_parameter_1.height = 140.0, 100.0
	    group_input_008.width, group_input_008.height = 140.0, 100.0
	    map_range.width, map_range.height = 140.0, 100.0
	    compare_1.width, compare_1.height = 140.0, 100.0
	    switch_004_1.width, switch_004_1.height = 140.0, 100.0
	    position_002_2.width, position_002_2.height = 140.0, 100.0
	    evaluate_on_domain.width, evaluate_on_domain.height = 140.0, 100.0
	    reroute_009_1.width, reroute_009_1.height = 10.0, 100.0
	    evaluate_on_domain_002.width, evaluate_on_domain_002.height = 140.0, 100.0
	    switch_006.width, switch_006.height = 140.0, 100.0
	    vector_rotate.width, vector_rotate.height = 140.0, 100.0
	    vector_rotate_003.width, vector_rotate_003.height = 140.0, 100.0
	    align_euler_to_vector_003.width, align_euler_to_vector_003.height = 140.0, 100.0
	    align_euler_to_vector_002.width, align_euler_to_vector_002.height = 140.0, 100.0
	    evaluate_on_domain_003.width, evaluate_on_domain_003.height = 140.0, 100.0
	    switch_001_3.width, switch_001_3.height = 140.0, 100.0
	    accumulate_field_1.width, accumulate_field_1.height = 140.0, 100.0
	    sample_index_001.width, sample_index_001.height = 140.0, 100.0
	    reroute_019.width, reroute_019.height = 10.0, 100.0
	    named_attribute_002.width, named_attribute_002.height = 140.0, 100.0
	    reroute_007_2.width, reroute_007_2.height = 10.0, 100.0
	    reroute_008_2.width, reroute_008_2.height = 10.0, 100.0
	    sample_index.width, sample_index.height = 140.0, 100.0
	    group_002.width, group_002.height = 140.0, 100.0
	    group_003.width, group_003.height = 140.0, 100.0
	
	    #initialize attach_hair_curves_to_surface links
	    #domain_size_002.Face Count -> compare_001.A
	    attach_hair_curves_to_surface.links.new(domain_size_002.outputs[2], compare_001.inputs[2])
	    #compare_001.Result -> switch_005_1.Switch
	    attach_hair_curves_to_surface.links.new(compare_001.outputs[0], switch_005_1.inputs[0])
	    #group_input_002_2.Surface -> object_info_001.Object
	    attach_hair_curves_to_surface.links.new(group_input_002_2.outputs[2], object_info_001.inputs[0])
	    #group_input_004_1.Surface -> domain_size_002.Geometry
	    attach_hair_curves_to_surface.links.new(group_input_004_1.outputs[1], domain_size_002.inputs[0])
	    #group_input_004_1.Surface -> switch_005_1.True
	    attach_hair_curves_to_surface.links.new(group_input_004_1.outputs[1], switch_005_1.inputs[2])
	    #group_input_001_2.Surface UV Map -> sample_nearest_surface.Value
	    attach_hair_curves_to_surface.links.new(group_input_001_2.outputs[3], sample_nearest_surface.inputs[1])
	    #reroute_3.Output -> set_position.Geometry
	    attach_hair_curves_to_surface.links.new(reroute_3.outputs[0], set_position.inputs[0])
	    #reroute_3.Output -> switch_007.False
	    attach_hair_curves_to_surface.links.new(reroute_3.outputs[0], switch_007.inputs[1])
	    #set_position.Geometry -> switch_007.True
	    attach_hair_curves_to_surface.links.new(set_position.outputs[0], switch_007.inputs[2])
	    #switch_005_1.Output -> reroute_3.Input
	    attach_hair_curves_to_surface.links.new(switch_005_1.outputs[0], reroute_3.inputs[0])
	    #group_input_005_2.Surface Rest Position -> switch_007.Switch
	    attach_hair_curves_to_surface.links.new(group_input_005_2.outputs[4], switch_007.inputs[0])
	    #named_attribute_1.Attribute -> set_position.Position
	    attach_hair_curves_to_surface.links.new(named_attribute_1.outputs[0], set_position.inputs[2])
	    #named_attribute_1.Exists -> set_position.Selection
	    attach_hair_curves_to_surface.links.new(named_attribute_1.outputs[1], set_position.inputs[1])
	    #switch_007.Output -> sample_nearest_surface.Mesh
	    attach_hair_curves_to_surface.links.new(switch_007.outputs[0], sample_nearest_surface.inputs[0])
	    #object_info_001.Geometry -> switch_005_1.False
	    attach_hair_curves_to_surface.links.new(object_info_001.outputs[4], switch_005_1.inputs[1])
	    #reroute_002_1.Output -> sample_uv_surface.UV Map
	    attach_hair_curves_to_surface.links.new(reroute_002_1.outputs[0], sample_uv_surface.inputs[2])
	    #position.Position -> sample_uv_surface.Value
	    attach_hair_curves_to_surface.links.new(position.outputs[0], sample_uv_surface.inputs[1])
	    #reroute_004_2.Output -> sample_uv_surface.Sample UV
	    attach_hair_curves_to_surface.links.new(reroute_004_2.outputs[0], sample_uv_surface.inputs[3])
	    #capture_attribute_001_1.Geometry -> set_position_001_2.Geometry
	    attach_hair_curves_to_surface.links.new(capture_attribute_001_1.outputs[0], set_position_001_2.inputs[0])
	    #reroute_017_1.Output -> sample_uv_surface_001.Mesh
	    attach_hair_curves_to_surface.links.new(reroute_017_1.outputs[0], sample_uv_surface_001.inputs[0])
	    #reroute_004_2.Output -> sample_uv_surface_001.Sample UV
	    attach_hair_curves_to_surface.links.new(reroute_004_2.outputs[0], sample_uv_surface_001.inputs[3])
	    #reroute_002_1.Output -> sample_uv_surface_001.UV Map
	    attach_hair_curves_to_surface.links.new(reroute_002_1.outputs[0], sample_uv_surface_001.inputs[2])
	    #normal.Normal -> capture_attribute.Value
	    attach_hair_curves_to_surface.links.new(normal.outputs[0], capture_attribute.inputs[1])
	    #reroute_018_1.Output -> sample_uv_surface_001.Value
	    attach_hair_curves_to_surface.links.new(reroute_018_1.outputs[0], sample_uv_surface_001.inputs[1])
	    #sample_uv_surface.Value -> vector_math_2.Vector
	    attach_hair_curves_to_surface.links.new(sample_uv_surface.outputs[0], vector_math_2.inputs[0])
	    #vector_math_2.Vector -> evaluate_on_domain.Value
	    attach_hair_curves_to_surface.links.new(vector_math_2.outputs[0], evaluate_on_domain.inputs[0])
	    #position_001_2.Position -> vector_math_001_1.Vector
	    attach_hair_curves_to_surface.links.new(position_001_2.outputs[0], vector_math_001_1.inputs[0])
	    #switch_006.Output -> vector_rotate.Vector
	    attach_hair_curves_to_surface.links.new(switch_006.outputs[0], vector_rotate.inputs[0])
	    #reroute_007_2.Output -> sample_index.Geometry
	    attach_hair_curves_to_surface.links.new(reroute_007_2.outputs[0], sample_index.inputs[0])
	    #named_attribute_002.Attribute -> sample_index.Index
	    attach_hair_curves_to_surface.links.new(named_attribute_002.outputs[0], sample_index.inputs[2])
	    #position_002_2.Position -> vector_math_004_1.Vector
	    attach_hair_curves_to_surface.links.new(position_002_2.outputs[0], vector_math_004_1.inputs[0])
	    #vector_math_002.Vector -> vector_math_003.Vector
	    attach_hair_curves_to_surface.links.new(vector_math_002.outputs[0], vector_math_003.inputs[0])
	    #switch_003_2.Output -> vector_math_002.Vector
	    attach_hair_curves_to_surface.links.new(switch_003_2.outputs[0], vector_math_002.inputs[0])
	    #switch_002_1.Output -> vector_math_002.Vector
	    attach_hair_curves_to_surface.links.new(switch_002_1.outputs[0], vector_math_002.inputs[1])
	    #reroute_009_1.Output -> vector_rotate_003.Vector
	    attach_hair_curves_to_surface.links.new(reroute_009_1.outputs[0], vector_rotate_003.inputs[0])
	    #evaluate_on_domain_002.Value -> vector_rotate_003.Rotation
	    attach_hair_curves_to_surface.links.new(evaluate_on_domain_002.outputs[0], vector_rotate_003.inputs[4])
	    #evaluate_on_domain_003.Value -> vector_rotate.Rotation
	    attach_hair_curves_to_surface.links.new(evaluate_on_domain_003.outputs[0], vector_rotate.inputs[4])
	    #vector_math_004_1.Vector -> vector_math_003.Vector
	    attach_hair_curves_to_surface.links.new(vector_math_004_1.outputs[0], vector_math_003.inputs[1])
	    #reroute_016_1.Output -> store_named_attribute.Geometry
	    attach_hair_curves_to_surface.links.new(reroute_016_1.outputs[0], store_named_attribute.inputs[0])
	    #group_input_3.Geometry -> capture_attribute_002.Geometry
	    attach_hair_curves_to_surface.links.new(group_input_3.outputs[0], capture_attribute_002.inputs[0])
	    #reroute_003.Output -> store_named_attribute.Value
	    attach_hair_curves_to_surface.links.new(reroute_003.outputs[0], store_named_attribute.inputs[3])
	    #sample_nearest_surface.Value -> capture_attribute_002.Value
	    attach_hair_curves_to_surface.links.new(sample_nearest_surface.outputs[0], capture_attribute_002.inputs[1])
	    #capture_attribute_002.Value -> reroute_004_2.Input
	    attach_hair_curves_to_surface.links.new(capture_attribute_002.outputs[1], reroute_004_2.inputs[0])
	    #switch_007.Output -> capture_attribute.Geometry
	    attach_hair_curves_to_surface.links.new(switch_007.outputs[0], capture_attribute.inputs[0])
	    #align_euler_to_vector_003.Rotation -> evaluate_on_domain_002.Value
	    attach_hair_curves_to_surface.links.new(align_euler_to_vector_003.outputs[0], evaluate_on_domain_002.inputs[0])
	    #align_euler_to_vector_002.Rotation -> evaluate_on_domain_003.Value
	    attach_hair_curves_to_surface.links.new(align_euler_to_vector_002.outputs[0], evaluate_on_domain_003.inputs[0])
	    #capture_attribute.Geometry -> reroute_001_2.Input
	    attach_hair_curves_to_surface.links.new(capture_attribute.outputs[0], reroute_001_2.inputs[0])
	    #reroute_018_1.Output -> sample_uv_surface_003.Value
	    attach_hair_curves_to_surface.links.new(reroute_018_1.outputs[0], sample_uv_surface_003.inputs[1])
	    #reroute_002_1.Output -> sample_uv_surface_003.UV Map
	    attach_hair_curves_to_surface.links.new(reroute_002_1.outputs[0], sample_uv_surface_003.inputs[2])
	    #reroute_017_1.Output -> sample_uv_surface_003.Mesh
	    attach_hair_curves_to_surface.links.new(reroute_017_1.outputs[0], sample_uv_surface_003.inputs[0])
	    #named_attribute_001.Attribute -> sample_uv_surface_003.Sample UV
	    attach_hair_curves_to_surface.links.new(named_attribute_001.outputs[0], sample_uv_surface_003.inputs[3])
	    #reroute_019.Output -> switch_001_3.True
	    attach_hair_curves_to_surface.links.new(reroute_019.outputs[0], switch_001_3.inputs[2])
	    #reroute_020.Output -> sample_index_001.Geometry
	    attach_hair_curves_to_surface.links.new(reroute_020.outputs[0], sample_index_001.inputs[0])
	    #named_attribute_001.Exists -> accumulate_field_1.Value
	    attach_hair_curves_to_surface.links.new(named_attribute_001.outputs[1], accumulate_field_1.inputs[0])
	    #accumulate_field_1.Total -> sample_index_001.Value
	    attach_hair_curves_to_surface.links.new(accumulate_field_1.outputs[2], sample_index_001.inputs[1])
	    #sample_index_001.Value -> switch_001_3.Switch
	    attach_hair_curves_to_surface.links.new(sample_index_001.outputs[0], switch_001_3.inputs[0])
	    #reroute_008_2.Output -> sample_index.Value
	    attach_hair_curves_to_surface.links.new(reroute_008_2.outputs[0], sample_index.inputs[1])
	    #vector_rotate.Vector -> switch_002_1.True
	    attach_hair_curves_to_surface.links.new(vector_rotate.outputs[0], switch_002_1.inputs[2])
	    #vector_math_001_1.Vector -> switch_002_1.False
	    attach_hair_curves_to_surface.links.new(vector_math_001_1.outputs[0], switch_002_1.inputs[1])
	    #group_input_003_2.Align to Surface Normal -> switch_002_1.Switch
	    attach_hair_curves_to_surface.links.new(group_input_003_2.outputs[7], switch_002_1.inputs[0])
	    #vector_math_005.Vector -> set_position_001_2.Offset
	    attach_hair_curves_to_surface.links.new(vector_math_005.outputs[0], set_position_001_2.inputs[3])
	    #evaluate_on_domain.Value -> switch_003_2.True
	    attach_hair_curves_to_surface.links.new(evaluate_on_domain.outputs[0], switch_003_2.inputs[2])
	    #group_input_006_1.Snap to Surface -> switch_003_2.Switch
	    attach_hair_curves_to_surface.links.new(group_input_006_1.outputs[6], switch_003_2.inputs[0])
	    #group_input_006_1.Snap to Surface -> boolean_math_2.Boolean
	    attach_hair_curves_to_surface.links.new(group_input_006_1.outputs[6], boolean_math_2.inputs[0])
	    #group_input_003_2.Align to Surface Normal -> boolean_math_2.Boolean
	    attach_hair_curves_to_surface.links.new(group_input_003_2.outputs[7], boolean_math_2.inputs[1])
	    #boolean_math_2.Boolean -> set_position_001_2.Selection
	    attach_hair_curves_to_surface.links.new(boolean_math_2.outputs[0], set_position_001_2.inputs[1])
	    #capture_attribute_002.Value -> reroute_003.Input
	    attach_hair_curves_to_surface.links.new(capture_attribute_002.outputs[1], reroute_003.inputs[0])
	    #switch_009.Output -> group_output_5.Surface UV Coordinate
	    attach_hair_curves_to_surface.links.new(switch_009.outputs[0], group_output_5.inputs[1])
	    #store_named_attribute.Geometry -> switch_1.True
	    attach_hair_curves_to_surface.links.new(store_named_attribute.outputs[0], switch_1.inputs[2])
	    #group_input_007.Sample Attachment UV -> switch_1.Switch
	    attach_hair_curves_to_surface.links.new(group_input_007.outputs[5], switch_1.inputs[0])
	    #reroute_016_1.Output -> switch_1.False
	    attach_hair_curves_to_surface.links.new(reroute_016_1.outputs[0], switch_1.inputs[1])
	    #switch_1.Output -> store_named_attribute_001.Geometry
	    attach_hair_curves_to_surface.links.new(switch_1.outputs[0], store_named_attribute_001.inputs[0])
	    #reroute_020.Output -> capture_attribute_001_1.Geometry
	    attach_hair_curves_to_surface.links.new(reroute_020.outputs[0], capture_attribute_001_1.inputs[0])
	    #reroute_005_2.Output -> store_named_attribute_001.Value
	    attach_hair_curves_to_surface.links.new(reroute_005_2.outputs[0], store_named_attribute_001.inputs[3])
	    #capture_attribute_001_1.Value -> reroute_005_2.Input
	    attach_hair_curves_to_surface.links.new(capture_attribute_001_1.outputs[1], reroute_005_2.inputs[0])
	    #switch_010.Output -> group_output_5.Surface Normal
	    attach_hair_curves_to_surface.links.new(switch_010.outputs[0], group_output_5.inputs[2])
	    #sample_uv_surface_001.Value -> capture_attribute_001_1.Value
	    attach_hair_curves_to_surface.links.new(sample_uv_surface_001.outputs[0], capture_attribute_001_1.inputs[1])
	    #vector_math_003.Vector -> vector_math_005.Vector
	    attach_hair_curves_to_surface.links.new(vector_math_003.outputs[0], vector_math_005.inputs[0])
	    #spline_parameter_1.Factor -> map_range.Value
	    attach_hair_curves_to_surface.links.new(spline_parameter_1.outputs[0], map_range.inputs[0])
	    #group_input_008.Blend along Curve -> map_range.From Max
	    attach_hair_curves_to_surface.links.new(group_input_008.outputs[8], map_range.inputs[2])
	    #group_input_008.Blend along Curve -> compare_1.A
	    attach_hair_curves_to_surface.links.new(group_input_008.outputs[8], compare_1.inputs[0])
	    #compare_1.Result -> switch_004_1.Switch
	    attach_hair_curves_to_surface.links.new(compare_1.outputs[0], switch_004_1.inputs[0])
	    #map_range.Result -> switch_004_1.False
	    attach_hair_curves_to_surface.links.new(map_range.outputs[0], switch_004_1.inputs[1])
	    #switch_004_1.Output -> vector_math_005.Scale
	    attach_hair_curves_to_surface.links.new(switch_004_1.outputs[0], vector_math_005.inputs[3])
	    #switch_001_3.Output -> align_euler_to_vector_003.Vector
	    attach_hair_curves_to_surface.links.new(switch_001_3.outputs[0], align_euler_to_vector_003.inputs[2])
	    #sample_index.Value -> switch_001_3.False
	    attach_hair_curves_to_surface.links.new(sample_index.outputs[0], switch_001_3.inputs[1])
	    #named_attribute_002.Exists -> switch_006.Switch
	    attach_hair_curves_to_surface.links.new(named_attribute_002.outputs[1], switch_006.inputs[0])
	    #reroute_009_1.Output -> switch_006.False
	    attach_hair_curves_to_surface.links.new(reroute_009_1.outputs[0], switch_006.inputs[1])
	    #vector_rotate_003.Vector -> switch_006.True
	    attach_hair_curves_to_surface.links.new(vector_rotate_003.outputs[0], switch_006.inputs[2])
	    #vector_math_001_1.Vector -> reroute_009_1.Input
	    attach_hair_curves_to_surface.links.new(vector_math_001_1.outputs[0], reroute_009_1.inputs[0])
	    #reroute_011_1.Output -> reroute_010.Input
	    attach_hair_curves_to_surface.links.new(reroute_011_1.outputs[0], reroute_010.inputs[0])
	    #group_input_3.Geometry -> reroute_011_1.Input
	    attach_hair_curves_to_surface.links.new(group_input_3.outputs[0], reroute_011_1.inputs[0])
	    #store_named_attribute_001.Geometry -> switch_008.False
	    attach_hair_curves_to_surface.links.new(store_named_attribute_001.outputs[0], switch_008.inputs[1])
	    #reroute_006_2.Output -> switch_008.True
	    attach_hair_curves_to_surface.links.new(reroute_006_2.outputs[0], switch_008.inputs[2])
	    #switch_008.Output -> group_output_5.Geometry
	    attach_hair_curves_to_surface.links.new(switch_008.outputs[0], group_output_5.inputs[0])
	    #reroute_003.Output -> switch_009.False
	    attach_hair_curves_to_surface.links.new(reroute_003.outputs[0], switch_009.inputs[1])
	    #reroute_005_2.Output -> switch_010.False
	    attach_hair_curves_to_surface.links.new(reroute_005_2.outputs[0], switch_010.inputs[1])
	    #domain_size_003.Face Count -> compare_002_2.A
	    attach_hair_curves_to_surface.links.new(domain_size_003.outputs[2], compare_002_2.inputs[2])
	    #switch_005_1.Output -> domain_size_003.Geometry
	    attach_hair_curves_to_surface.links.new(switch_005_1.outputs[0], domain_size_003.inputs[0])
	    #reroute_012_1.Output -> switch_008.Switch
	    attach_hair_curves_to_surface.links.new(reroute_012_1.outputs[0], switch_008.inputs[0])
	    #reroute_014_1.Output -> reroute_012_1.Input
	    attach_hair_curves_to_surface.links.new(reroute_014_1.outputs[0], reroute_012_1.inputs[0])
	    #reroute_012_1.Output -> switch_009.Switch
	    attach_hair_curves_to_surface.links.new(reroute_012_1.outputs[0], switch_009.inputs[0])
	    #reroute_012_1.Output -> switch_010.Switch
	    attach_hair_curves_to_surface.links.new(reroute_012_1.outputs[0], switch_010.inputs[0])
	    #named_attribute_003.Attribute -> switch_009.True
	    attach_hair_curves_to_surface.links.new(named_attribute_003.outputs[0], switch_009.inputs[2])
	    #named_attribute_004.Attribute -> switch_010.True
	    attach_hair_curves_to_surface.links.new(named_attribute_004.outputs[0], switch_010.inputs[2])
	    #reroute_015_1.Output -> reroute_013_1.Input
	    attach_hair_curves_to_surface.links.new(reroute_015_1.outputs[0], reroute_013_1.inputs[0])
	    #reroute_013_1.Output -> reroute_014_1.Input
	    attach_hair_curves_to_surface.links.new(reroute_013_1.outputs[0], reroute_014_1.inputs[0])
	    #compare_002_2.Result -> reroute_015_1.Input
	    attach_hair_curves_to_surface.links.new(compare_002_2.outputs[0], reroute_015_1.inputs[0])
	    #set_position_001_2.Geometry -> reroute_016_1.Input
	    attach_hair_curves_to_surface.links.new(set_position_001_2.outputs[0], reroute_016_1.inputs[0])
	    #capture_attribute.Geometry -> reroute_017_1.Input
	    attach_hair_curves_to_surface.links.new(capture_attribute.outputs[0], reroute_017_1.inputs[0])
	    #capture_attribute.Value -> reroute_018_1.Input
	    attach_hair_curves_to_surface.links.new(capture_attribute.outputs[1], reroute_018_1.inputs[0])
	    #reroute_010.Output -> reroute_006_2.Input
	    attach_hair_curves_to_surface.links.new(reroute_010.outputs[0], reroute_006_2.inputs[0])
	    #reroute_001_2.Output -> reroute_007_2.Input
	    attach_hair_curves_to_surface.links.new(reroute_001_2.outputs[0], reroute_007_2.inputs[0])
	    #sample_uv_surface_001.Value -> reroute_008_2.Input
	    attach_hair_curves_to_surface.links.new(sample_uv_surface_001.outputs[0], reroute_008_2.inputs[0])
	    #reroute_008_2.Output -> align_euler_to_vector_002.Vector
	    attach_hair_curves_to_surface.links.new(reroute_008_2.outputs[0], align_euler_to_vector_002.inputs[2])
	    #sample_uv_surface_003.Value -> reroute_019.Input
	    attach_hair_curves_to_surface.links.new(sample_uv_surface_003.outputs[0], reroute_019.inputs[0])
	    #reroute_017_1.Output -> sample_uv_surface.Mesh
	    attach_hair_curves_to_surface.links.new(reroute_017_1.outputs[0], sample_uv_surface.inputs[0])
	    #group_input_009.Surface UV Map -> reroute_002_1.Input
	    attach_hair_curves_to_surface.links.new(group_input_009.outputs[3], reroute_002_1.inputs[0])
	    #capture_attribute_002.Geometry -> reroute_020.Input
	    attach_hair_curves_to_surface.links.new(capture_attribute_002.outputs[0], reroute_020.inputs[0])
	    #group_002.Root Position -> vector_math_2.Vector
	    attach_hair_curves_to_surface.links.new(group_002.outputs[1], vector_math_2.inputs[1])
	    #group_002.Root Position -> vector_math_001_1.Vector
	    attach_hair_curves_to_surface.links.new(group_002.outputs[1], vector_math_001_1.inputs[1])
	    #group_002.Root Position -> vector_math_004_1.Vector
	    attach_hair_curves_to_surface.links.new(group_002.outputs[1], vector_math_004_1.inputs[1])
	    #group_003.Root Position -> sample_nearest_surface.Sample Position
	    attach_hair_curves_to_surface.links.new(group_003.outputs[1], sample_nearest_surface.inputs[3])
	    return attach_hair_curves_to_surface
	
	attach_hair_curves_to_surface = attach_hair_curves_to_surface_node_group()
	
	#initialize attach_hair node group
	def attach_hair_node_group():
	    attach_hair = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "ATTACH_HAIR")
	
	    attach_hair.color_tag = 'NONE'
	    attach_hair.description = ""
	    attach_hair.default_group_node_width = 140
	    
	
	    attach_hair.is_modifier = True
	
	    #attach_hair interface
	    #Socket Geometry
	    geometry_socket_5 = attach_hair.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_5.attribute_domain = 'POINT'
	
	    #Socket Geometry
	    geometry_socket_6 = attach_hair.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_6.attribute_domain = 'POINT'
	
	    #Socket Surface
	    surface_socket_2 = attach_hair.interface.new_socket(name = "Surface", in_out='INPUT', socket_type = 'NodeSocketObject')
	    surface_socket_2.attribute_domain = 'POINT'
	    surface_socket_2.description = "Surface Object to attach to (needs to have matching transforms)"
	
	    #Socket UV Map
	    uv_map_socket = attach_hair.interface.new_socket(name = "UV Map", in_out='INPUT', socket_type = 'NodeSocketString')
	    uv_map_socket.default_value = "UVMap"
	    uv_map_socket.subtype = 'NONE'
	    uv_map_socket.attribute_domain = 'POINT'
	    uv_map_socket.description = "Surface UV Map used to attach hair."
	
	    #Socket Blend along Curve
	    blend_along_curve_socket_1 = attach_hair.interface.new_socket(name = "Blend along Curve", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    blend_along_curve_socket_1.default_value = 0.05000000074505806
	    blend_along_curve_socket_1.min_value = 0.0
	    blend_along_curve_socket_1.max_value = 1.0
	    blend_along_curve_socket_1.subtype = 'FACTOR'
	    blend_along_curve_socket_1.attribute_domain = 'POINT'
	    blend_along_curve_socket_1.description = "Blend deformation along each curve from the root"
	
	
	    #initialize attach_hair nodes
	    #node Group Input
	    group_input_4 = attach_hair.nodes.new("NodeGroupInput")
	    group_input_4.name = "Group Input"
	    group_input_4.outputs[4].hide = True
	
	    #node Group Output
	    group_output_6 = attach_hair.nodes.new("NodeGroupOutput")
	    group_output_6.name = "Group Output"
	    group_output_6.is_active_output = True
	    group_output_6.inputs[1].hide = True
	
	    #node Group
	    group_1 = attach_hair.nodes.new("GeometryNodeGroup")
	    group_1.name = "Group"
	    group_1.node_tree = attach_hair_curves_to_surface
	    group_1.inputs[1].hide = True
	    group_1.inputs[4].hide = True
	    group_1.inputs[5].hide = True
	    group_1.inputs[6].hide = True
	    group_1.inputs[7].hide = True
	    group_1.outputs[1].hide = True
	    group_1.outputs[2].hide = True
	    #Socket_7
	    group_1.inputs[4].default_value = False
	    #Socket_8
	    group_1.inputs[5].default_value = True
	    #Socket_9
	    group_1.inputs[6].default_value = True
	    #Socket_10
	    group_1.inputs[7].default_value = False
	
	    #node Named Attribute
	    named_attribute_2 = attach_hair.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute_2.name = "Named Attribute"
	    named_attribute_2.hide = True
	    named_attribute_2.data_type = 'FLOAT_VECTOR'
	
	
	
	
	
	    #Set locations
	    group_input_4.location = (-340.0, 0.0)
	    group_output_6.location = (82.01471710205078, 24.076622009277344)
	    group_1.location = (-156.17784118652344, 22.037841796875)
	    named_attribute_2.location = (-333.9075622558594, -146.13522338867188)
	
	    #Set dimensions
	    group_input_4.width, group_input_4.height = 140.0, 100.0
	    group_output_6.width, group_output_6.height = 140.0, 100.0
	    group_1.width, group_1.height = 197.8995361328125, 100.0
	    named_attribute_2.width, named_attribute_2.height = 140.0, 100.0
	
	    #initialize attach_hair links
	    #group_1.Geometry -> group_output_6.Geometry
	    attach_hair.links.new(group_1.outputs[0], group_output_6.inputs[0])
	    #group_input_4.Geometry -> group_1.Geometry
	    attach_hair.links.new(group_input_4.outputs[0], group_1.inputs[0])
	    #named_attribute_2.Attribute -> group_1.Surface UV Map
	    attach_hair.links.new(named_attribute_2.outputs[0], group_1.inputs[3])
	    #group_input_4.Surface -> group_1.Surface
	    attach_hair.links.new(group_input_4.outputs[1], group_1.inputs[2])
	    #group_input_4.UV Map -> named_attribute_2.Name
	    attach_hair.links.new(group_input_4.outputs[2], named_attribute_2.inputs[0])
	    #group_input_4.Blend along Curve -> group_1.Blend along Curve
	    attach_hair.links.new(group_input_4.outputs[3], group_1.inputs[8])
	    return attach_hair
	
	attach_hair = attach_hair_node_group()
	
	#initialize face_centers node group
	def face_centers_node_group():
	    face_centers = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "FACE_CENTERS")
	
	    face_centers.color_tag = 'NONE'
	    face_centers.description = ""
	    face_centers.default_group_node_width = 140
	    
	
	    face_centers.is_modifier = True
	
	    #face_centers interface
	    #Socket Geometry
	    geometry_socket_7 = face_centers.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_7.attribute_domain = 'POINT'
	
	    #Socket Geometry
	    geometry_socket_8 = face_centers.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_8.attribute_domain = 'POINT'
	
	
	    #initialize face_centers nodes
	    #node Group Output
	    group_output_7 = face_centers.nodes.new("NodeGroupOutput")
	    group_output_7.name = "Group Output"
	    group_output_7.is_active_output = True
	
	    #node Group Input
	    group_input_5 = face_centers.nodes.new("NodeGroupInput")
	    group_input_5.name = "Group Input"
	
	    #node For Each Geometry Element Input
	    for_each_geometry_element_input = face_centers.nodes.new("GeometryNodeForeachGeometryElementInput")
	    for_each_geometry_element_input.name = "For Each Geometry Element Input"
	    #node For Each Geometry Element Output
	    for_each_geometry_element_output = face_centers.nodes.new("GeometryNodeForeachGeometryElementOutput")
	    for_each_geometry_element_output.name = "For Each Geometry Element Output"
	    for_each_geometry_element_output.active_generation_index = 0
	    for_each_geometry_element_output.active_input_index = 0
	    for_each_geometry_element_output.active_main_index = 0
	    for_each_geometry_element_output.domain = 'FACE'
	    for_each_geometry_element_output.generation_items.clear()
	    for_each_geometry_element_output.generation_items.new('GEOMETRY', "Geometry")
	    for_each_geometry_element_output.generation_items[0].domain = 'POINT'
	    for_each_geometry_element_output.input_items.clear()
	    for_each_geometry_element_output.inspection_index = 0
	    for_each_geometry_element_output.main_items.clear()
	
	    #node Store Named Attribute
	    store_named_attribute_1 = face_centers.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_1.name = "Store Named Attribute"
	    store_named_attribute_1.data_type = 'FLOAT_VECTOR'
	    store_named_attribute_1.domain = 'FACE'
	    #Selection
	    store_named_attribute_1.inputs[1].default_value = True
	    #Name
	    store_named_attribute_1.inputs[2].default_value = "centers"
	
	    #node Named Attribute.001
	    named_attribute_001_1 = face_centers.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute_001_1.name = "Named Attribute.001"
	    named_attribute_001_1.data_type = 'INT'
	    #Name
	    named_attribute_001_1.inputs[0].default_value = "fidx"
	
	    #node Named Attribute.004
	    named_attribute_004_1 = face_centers.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute_004_1.name = "Named Attribute.004"
	    named_attribute_004_1.data_type = 'FLOAT_VECTOR'
	    #Name
	    named_attribute_004_1.inputs[0].default_value = "fco"
	
	    #node Compare.001
	    compare_001_1 = face_centers.nodes.new("FunctionNodeCompare")
	    compare_001_1.name = "Compare.001"
	    compare_001_1.hide = True
	    compare_001_1.data_type = 'INT'
	    compare_001_1.mode = 'ELEMENT'
	    compare_001_1.operation = 'EQUAL'
	
	    #node Attribute Statistic.002
	    attribute_statistic_002 = face_centers.nodes.new("GeometryNodeAttributeStatistic")
	    attribute_statistic_002.name = "Attribute Statistic.002"
	    attribute_statistic_002.data_type = 'FLOAT_VECTOR'
	    attribute_statistic_002.domain = 'CORNER'
	    attribute_statistic_002.outputs[1].hide = True
	    attribute_statistic_002.outputs[2].hide = True
	    attribute_statistic_002.outputs[3].hide = True
	    attribute_statistic_002.outputs[4].hide = True
	    attribute_statistic_002.outputs[5].hide = True
	    attribute_statistic_002.outputs[6].hide = True
	    attribute_statistic_002.outputs[7].hide = True
	
	    #node Reroute.010
	    reroute_010_1 = face_centers.nodes.new("NodeReroute")
	    reroute_010_1.name = "Reroute.010"
	    reroute_010_1.socket_idname = "NodeSocketGeometry"
	
	
	    #Process zone input For Each Geometry Element Input
	    for_each_geometry_element_input.pair_with_output(for_each_geometry_element_output)
	    #Selection
	    for_each_geometry_element_input.inputs[1].default_value = True
	
	
	
	
	    #Set locations
	    group_output_7.location = (659.57373046875, 0.0)
	    group_input_5.location = (-669.57373046875, 0.0)
	    for_each_geometry_element_input.location = (-369.873779296875, 251.74090576171875)
	    for_each_geometry_element_output.location = (469.57373046875, 251.74090576171875)
	    store_named_attribute_1.location = (250.197998046875, 248.50677490234375)
	    named_attribute_001_1.location = (-405.4127197265625, 37.06463623046875)
	    named_attribute_004_1.location = (-403.79931640625, -97.15411376953125)
	    compare_001_1.location = (-188.1004638671875, 84.72480773925781)
	    attribute_statistic_002.location = (-11.463111877441406, 110.92959594726562)
	    reroute_010_1.location = (-485.5649719238281, -34.71746826171875)
	
	    #Set dimensions
	    group_output_7.width, group_output_7.height = 140.0, 100.0
	    group_input_5.width, group_input_5.height = 140.0, 100.0
	    for_each_geometry_element_input.width, for_each_geometry_element_input.height = 140.0, 100.0
	    for_each_geometry_element_output.width, for_each_geometry_element_output.height = 140.0, 100.0
	    store_named_attribute_1.width, store_named_attribute_1.height = 140.0, 100.0
	    named_attribute_001_1.width, named_attribute_001_1.height = 140.0, 100.0
	    named_attribute_004_1.width, named_attribute_004_1.height = 140.0, 100.0
	    compare_001_1.width, compare_001_1.height = 140.0, 100.0
	    attribute_statistic_002.width, attribute_statistic_002.height = 140.0, 100.0
	    reroute_010_1.width, reroute_010_1.height = 10.0, 100.0
	
	    #initialize face_centers links
	    #reroute_010_1.Output -> attribute_statistic_002.Geometry
	    face_centers.links.new(reroute_010_1.outputs[0], attribute_statistic_002.inputs[0])
	    #compare_001_1.Result -> attribute_statistic_002.Selection
	    face_centers.links.new(compare_001_1.outputs[0], attribute_statistic_002.inputs[1])
	    #named_attribute_004_1.Attribute -> attribute_statistic_002.Attribute
	    face_centers.links.new(named_attribute_004_1.outputs[0], attribute_statistic_002.inputs[2])
	    #named_attribute_001_1.Attribute -> compare_001_1.B
	    face_centers.links.new(named_attribute_001_1.outputs[0], compare_001_1.inputs[3])
	    #store_named_attribute_1.Geometry -> for_each_geometry_element_output.Geometry
	    face_centers.links.new(store_named_attribute_1.outputs[0], for_each_geometry_element_output.inputs[1])
	    #attribute_statistic_002.Mean -> store_named_attribute_1.Value
	    face_centers.links.new(attribute_statistic_002.outputs[0], store_named_attribute_1.inputs[3])
	    #for_each_geometry_element_input.Element -> store_named_attribute_1.Geometry
	    face_centers.links.new(for_each_geometry_element_input.outputs[1], store_named_attribute_1.inputs[0])
	    #reroute_010_1.Output -> for_each_geometry_element_input.Geometry
	    face_centers.links.new(reroute_010_1.outputs[0], for_each_geometry_element_input.inputs[0])
	    #for_each_geometry_element_input.Index -> compare_001_1.A
	    face_centers.links.new(for_each_geometry_element_input.outputs[0], compare_001_1.inputs[2])
	    #group_input_5.Geometry -> reroute_010_1.Input
	    face_centers.links.new(group_input_5.outputs[0], reroute_010_1.inputs[0])
	    #for_each_geometry_element_output.Geometry -> group_output_7.Geometry
	    face_centers.links.new(for_each_geometry_element_output.outputs[2], group_output_7.inputs[0])
	    return face_centers
	
	face_centers = face_centers_node_group()
	
	#initialize ob_data node group
	def ob_data_node_group():
	    ob_data = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "OB_DATA")
	
	    ob_data.color_tag = 'NONE'
	    ob_data.description = "Extra data for mesh object."
	    ob_data.default_group_node_width = 140
	    
	
	    ob_data.is_modifier = True
	    ob_data.is_tool = True
	    ob_data.is_mode_object = False
	    ob_data.is_mode_edit = False
	    ob_data.is_mode_sculpt = False
	    ob_data.is_type_curve = False
	    ob_data.is_type_mesh = False
	    ob_data.is_type_point_cloud = False
	
	    #ob_data interface
	    #Socket Geometry
	    geometry_socket_9 = ob_data.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_9.attribute_domain = 'POINT'
	
	    #Socket Geometry
	    geometry_socket_10 = ob_data.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_10.attribute_domain = 'POINT'
	
	
	    #initialize ob_data nodes
	    #node Group Output
	    group_output_8 = ob_data.nodes.new("NodeGroupOutput")
	    group_output_8.name = "Group Output"
	    group_output_8.is_active_output = True
	    group_output_8.inputs[1].hide = True
	
	    #node Group Input
	    group_input_6 = ob_data.nodes.new("NodeGroupInput")
	    group_input_6.name = "Group Input"
	    group_input_6.outputs[1].hide = True
	
	    #node Store Named Attribute
	    store_named_attribute_2 = ob_data.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_2.name = "Store Named Attribute"
	    store_named_attribute_2.data_type = 'FLOAT'
	    store_named_attribute_2.domain = 'FACE'
	    #Selection
	    store_named_attribute_2.inputs[1].default_value = True
	    #Name
	    store_named_attribute_2.inputs[2].default_value = "area"
	
	    #node Face Area
	    face_area = ob_data.nodes.new("GeometryNodeInputMeshFaceArea")
	    face_area.name = "Face Area"
	
	    #node Corners of Face
	    corners_of_face = ob_data.nodes.new("GeometryNodeCornersOfFace")
	    corners_of_face.name = "Corners of Face"
	    corners_of_face.inputs[0].hide = True
	    corners_of_face.inputs[1].hide = True
	    corners_of_face.inputs[2].hide = True
	    corners_of_face.outputs[0].hide = True
	    #Face Index
	    corners_of_face.inputs[0].default_value = 0
	    #Weights
	    corners_of_face.inputs[1].default_value = 0.0
	    #Sort Index
	    corners_of_face.inputs[2].default_value = 0
	
	    #node Store Named Attribute.004
	    store_named_attribute_004 = ob_data.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_004.name = "Store Named Attribute.004"
	    store_named_attribute_004.data_type = 'INT'
	    store_named_attribute_004.domain = 'FACE'
	    #Selection
	    store_named_attribute_004.inputs[1].default_value = True
	    #Name
	    store_named_attribute_004.inputs[2].default_value = "fvct"
	
	    #node Edge Vertices.001
	    edge_vertices_001 = ob_data.nodes.new("GeometryNodeInputMeshEdgeVertices")
	    edge_vertices_001.name = "Edge Vertices.001"
	
	    #node Store Named Attribute.010
	    store_named_attribute_010 = ob_data.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_010.name = "Store Named Attribute.010"
	    store_named_attribute_010.data_type = 'FLOAT_VECTOR'
	    store_named_attribute_010.domain = 'EDGE'
	    #Selection
	    store_named_attribute_010.inputs[1].default_value = True
	    #Name
	    store_named_attribute_010.inputs[2].default_value = "evec"
	
	    #node Store Named Attribute.011
	    store_named_attribute_011 = ob_data.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_011.name = "Store Named Attribute.011"
	    store_named_attribute_011.data_type = 'FLOAT'
	    store_named_attribute_011.domain = 'EDGE'
	    #Selection
	    store_named_attribute_011.inputs[1].default_value = True
	    #Name
	    store_named_attribute_011.inputs[2].default_value = "elen"
	
	    #node Vector Math
	    vector_math_3 = ob_data.nodes.new("ShaderNodeVectorMath")
	    vector_math_3.name = "Vector Math"
	    vector_math_3.hide = True
	    vector_math_3.operation = 'SUBTRACT'
	
	    #node Vector Math.001
	    vector_math_001_2 = ob_data.nodes.new("ShaderNodeVectorMath")
	    vector_math_001_2.name = "Vector Math.001"
	    vector_math_001_2.hide = True
	    vector_math_001_2.operation = 'LENGTH'
	
	    #node Vertex Neighbors
	    vertex_neighbors = ob_data.nodes.new("GeometryNodeInputMeshVertexNeighbors")
	    vertex_neighbors.name = "Vertex Neighbors"
	
	    #node Store Named Attribute.002
	    store_named_attribute_002 = ob_data.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_002.name = "Store Named Attribute.002"
	    store_named_attribute_002.data_type = 'INT'
	    store_named_attribute_002.domain = 'POINT'
	    #Selection
	    store_named_attribute_002.inputs[1].default_value = True
	    #Name
	    store_named_attribute_002.inputs[2].default_value = "vct"
	
	    #node Store Named Attribute.003
	    store_named_attribute_003 = ob_data.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_003.name = "Store Named Attribute.003"
	    store_named_attribute_003.data_type = 'INT'
	    store_named_attribute_003.domain = 'POINT'
	    #Selection
	    store_named_attribute_003.inputs[1].default_value = True
	    #Name
	    store_named_attribute_003.inputs[2].default_value = "fct"
	
	    #node Corners of Vertex
	    corners_of_vertex = ob_data.nodes.new("GeometryNodeCornersOfVertex")
	    corners_of_vertex.name = "Corners of Vertex"
	    #Vertex Index
	    corners_of_vertex.inputs[0].default_value = 0
	    #Weights
	    corners_of_vertex.inputs[1].default_value = 0.0
	    #Sort Index
	    corners_of_vertex.inputs[2].default_value = 0
	
	    #node Store Named Attribute.006
	    store_named_attribute_006 = ob_data.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_006.name = "Store Named Attribute.006"
	    store_named_attribute_006.data_type = 'INT'
	    store_named_attribute_006.domain = 'POINT'
	    #Selection
	    store_named_attribute_006.inputs[1].default_value = True
	    #Name
	    store_named_attribute_006.inputs[2].default_value = "vi"
	
	    #node Face of Corner
	    face_of_corner = ob_data.nodes.new("GeometryNodeFaceOfCorner")
	    face_of_corner.name = "Face of Corner"
	    face_of_corner.inputs[0].hide = True
	    face_of_corner.outputs[1].hide = True
	    #Corner Index
	    face_of_corner.inputs[0].default_value = 0
	
	    #node Store Named Attribute.007
	    store_named_attribute_007 = ob_data.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_007.name = "Store Named Attribute.007"
	    store_named_attribute_007.data_type = 'INT'
	    store_named_attribute_007.domain = 'POINT'
	    #Selection
	    store_named_attribute_007.inputs[1].default_value = True
	    #Name
	    store_named_attribute_007.inputs[2].default_value = "iif"
	
	    #node Store Named Attribute.005
	    store_named_attribute_005 = ob_data.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_005.name = "Store Named Attribute.005"
	    store_named_attribute_005.data_type = 'INT'
	    store_named_attribute_005.domain = 'POINT'
	    #Selection
	    store_named_attribute_005.inputs[1].default_value = True
	    #Name
	    store_named_attribute_005.inputs[2].default_value = "vidx"
	
	    #node Index
	    index_1 = ob_data.nodes.new("GeometryNodeInputIndex")
	    index_1.name = "Index"
	
	    #node Store Named Attribute.012
	    store_named_attribute_012 = ob_data.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_012.name = "Store Named Attribute.012"
	    store_named_attribute_012.data_type = 'INT'
	    store_named_attribute_012.domain = 'EDGE'
	    #Selection
	    store_named_attribute_012.inputs[1].default_value = True
	    #Name
	    store_named_attribute_012.inputs[2].default_value = "e1"
	
	    #node Store Named Attribute.013
	    store_named_attribute_013 = ob_data.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_013.name = "Store Named Attribute.013"
	    store_named_attribute_013.data_type = 'INT'
	    store_named_attribute_013.domain = 'EDGE'
	    #Selection
	    store_named_attribute_013.inputs[1].default_value = True
	    #Name
	    store_named_attribute_013.inputs[2].default_value = "e2"
	
	    #node Frame
	    frame_3 = ob_data.nodes.new("NodeFrame")
	    frame_3.label = "Point"
	    frame_3.name = "Frame"
	    frame_3.label_size = 20
	    frame_3.shrink = True
	
	    #node Frame.001
	    frame_001_2 = ob_data.nodes.new("NodeFrame")
	    frame_001_2.label = "Edge"
	    frame_001_2.name = "Frame.001"
	    frame_001_2.label_size = 20
	    frame_001_2.shrink = True
	
	    #node Frame.002
	    frame_002_3 = ob_data.nodes.new("NodeFrame")
	    frame_002_3.label = "Face"
	    frame_002_3.name = "Frame.002"
	    frame_002_3.label_size = 20
	    frame_002_3.shrink = True
	
	    #node Store Named Attribute.008
	    store_named_attribute_008 = ob_data.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_008.name = "Store Named Attribute.008"
	    store_named_attribute_008.data_type = 'INT'
	    store_named_attribute_008.domain = 'CORNER'
	    #Selection
	    store_named_attribute_008.inputs[1].default_value = True
	    #Name
	    store_named_attribute_008.inputs[2].default_value = "fidx"
	
	    #node Index.001
	    index_001_1 = ob_data.nodes.new("GeometryNodeInputIndex")
	    index_001_1.name = "Index.001"
	
	    #node Face of Corner.001
	    face_of_corner_001 = ob_data.nodes.new("GeometryNodeFaceOfCorner")
	    face_of_corner_001.name = "Face of Corner.001"
	    face_of_corner_001.hide = True
	    #Corner Index
	    face_of_corner_001.inputs[0].default_value = 0
	
	    #node Store Named Attribute.009
	    store_named_attribute_009 = ob_data.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_009.name = "Store Named Attribute.009"
	    store_named_attribute_009.data_type = 'INT'
	    store_named_attribute_009.domain = 'CORNER'
	    #Selection
	    store_named_attribute_009.inputs[1].default_value = True
	    #Name
	    store_named_attribute_009.inputs[2].default_value = "iface"
	
	    #node Evaluate at Index.002
	    evaluate_at_index_002 = ob_data.nodes.new("GeometryNodeFieldAtIndex")
	    evaluate_at_index_002.name = "Evaluate at Index.002"
	    evaluate_at_index_002.hide = True
	    evaluate_at_index_002.data_type = 'FLOAT_VECTOR'
	    evaluate_at_index_002.domain = 'POINT'
	
	    #node Position
	    position_1 = ob_data.nodes.new("GeometryNodeInputPosition")
	    position_1.name = "Position"
	
	    #node Store Named Attribute.014
	    store_named_attribute_014 = ob_data.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_014.name = "Store Named Attribute.014"
	    store_named_attribute_014.data_type = 'FLOAT_VECTOR'
	    store_named_attribute_014.domain = 'CORNER'
	    #Selection
	    store_named_attribute_014.inputs[1].default_value = True
	    #Name
	    store_named_attribute_014.inputs[2].default_value = "fco"
	
	    #node Store Named Attribute.015
	    store_named_attribute_015 = ob_data.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_015.name = "Store Named Attribute.015"
	    store_named_attribute_015.data_type = 'INT'
	    store_named_attribute_015.domain = 'CORNER'
	    #Selection
	    store_named_attribute_015.inputs[1].default_value = True
	    #Name
	    store_named_attribute_015.inputs[2].default_value = "fvert"
	
	    #node Named Attribute.001
	    named_attribute_001_2 = ob_data.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute_001_2.name = "Named Attribute.001"
	    named_attribute_001_2.data_type = 'INT'
	    #Name
	    named_attribute_001_2.inputs[0].default_value = "vidx"
	
	    #node Frame.003
	    frame_003_1 = ob_data.nodes.new("NodeFrame")
	    frame_003_1.label = "UV"
	    frame_003_1.name = "Frame.003"
	    frame_003_1.label_size = 20
	    frame_003_1.shrink = True
	
	    #node Group
	    group_2 = ob_data.nodes.new("GeometryNodeGroup")
	    group_2.name = "Group"
	    group_2.node_tree = face_centers
	
	
	
	
	    #Set parents
	    store_named_attribute_2.parent = frame_002_3
	    face_area.parent = frame_002_3
	    corners_of_face.parent = frame_002_3
	    store_named_attribute_004.parent = frame_002_3
	    edge_vertices_001.parent = frame_001_2
	    store_named_attribute_010.parent = frame_001_2
	    store_named_attribute_011.parent = frame_001_2
	    vector_math_3.parent = frame_001_2
	    vector_math_001_2.parent = frame_001_2
	    vertex_neighbors.parent = frame_3
	    store_named_attribute_002.parent = frame_3
	    store_named_attribute_003.parent = frame_3
	    corners_of_vertex.parent = frame_3
	    store_named_attribute_006.parent = frame_3
	    face_of_corner.parent = frame_3
	    store_named_attribute_007.parent = frame_3
	    store_named_attribute_005.parent = frame_3
	    index_1.parent = frame_3
	    store_named_attribute_012.parent = frame_001_2
	    store_named_attribute_013.parent = frame_001_2
	    store_named_attribute_008.parent = frame_003_1
	    index_001_1.parent = frame_003_1
	    face_of_corner_001.parent = frame_003_1
	    store_named_attribute_009.parent = frame_003_1
	    evaluate_at_index_002.parent = frame_003_1
	    position_1.parent = frame_003_1
	    store_named_attribute_014.parent = frame_003_1
	    store_named_attribute_015.parent = frame_003_1
	    named_attribute_001_2.parent = frame_003_1
	
	    #Set locations
	    group_output_8.location = (2084.419677734375, 0.0)
	    group_input_6.location = (-1175.17578125, 0.0)
	    store_named_attribute_2.location = (31.557861328125, -39.91112518310547)
	    face_area.location = (30.0308837890625, -241.5736541748047)
	    corners_of_face.location = (207.884521484375, -240.56661987304688)
	    store_named_attribute_004.location = (211.1871337890625, -43.55321502685547)
	    edge_vertices_001.location = (30.059101104736328, -235.656494140625)
	    store_named_attribute_010.location = (379.56103515625, -39.92475128173828)
	    store_named_attribute_011.location = (559.666259765625, -39.92475128173828)
	    vector_math_3.location = (377.9259338378906, -247.12554931640625)
	    vector_math_001_2.location = (559.92236328125, -245.30450439453125)
	    vertex_neighbors.location = (225.6195068359375, -241.48486328125)
	    store_named_attribute_002.location = (230.421875, -42.65917205810547)
	    store_named_attribute_003.location = (424.875732421875, -42.65917205810547)
	    corners_of_vertex.location = (791.2051391601562, -243.86764526367188)
	    store_named_attribute_006.location = (614.2387084960938, -44.48021697998047)
	    face_of_corner.location = (609.9549560546875, -242.69467163085938)
	    store_named_attribute_007.location = (794.2388305664062, -44.48021697998047)
	    store_named_attribute_005.location = (32.19744873046875, -39.81938171386719)
	    index_1.location = (29.61065673828125, -237.67437744140625)
	    store_named_attribute_012.location = (30.58085823059082, -39.92475128173828)
	    store_named_attribute_013.location = (205.30517578125, -39.92475128173828)
	    frame_3.location = (-1011.0, 114.0)
	    frame_001_2.location = (-24.0, 111.0)
	    frame_002_3.location = (723.0, 113.0)
	    store_named_attribute_008.location = (30.084228515625, -39.91887664794922)
	    index_001_1.location = (399.0113525390625, -272.89666748046875)
	    face_of_corner_001.location = (31.023681640625, -240.24319458007812)
	    store_named_attribute_009.location = (210.18896484375, -39.91887664794922)
	    evaluate_at_index_002.location = (399.3846435546875, -241.97543334960938)
	    position_1.location = (395.73388671875, -329.0435791015625)
	    store_named_attribute_014.location = (396.99755859375, -39.91887664794922)
	    store_named_attribute_015.location = (589.268798828125, -39.91887664794922)
	    named_attribute_001_2.location = (590.27685546875, -237.64990234375)
	    frame_003_1.location = (1121.0, 117.0)
	    group_2.location = (1895.553466796875, -3.2612171173095703)
	
	    #Set dimensions
	    group_output_8.width, group_output_8.height = 140.0, 100.0
	    group_input_6.width, group_input_6.height = 140.0, 100.0
	    store_named_attribute_2.width, store_named_attribute_2.height = 140.0, 100.0
	    face_area.width, face_area.height = 140.0, 100.0
	    corners_of_face.width, corners_of_face.height = 140.0, 100.0
	    store_named_attribute_004.width, store_named_attribute_004.height = 140.0, 100.0
	    edge_vertices_001.width, edge_vertices_001.height = 140.0, 100.0
	    store_named_attribute_010.width, store_named_attribute_010.height = 140.0, 100.0
	    store_named_attribute_011.width, store_named_attribute_011.height = 140.0, 100.0
	    vector_math_3.width, vector_math_3.height = 140.0, 100.0
	    vector_math_001_2.width, vector_math_001_2.height = 140.0, 100.0
	    vertex_neighbors.width, vertex_neighbors.height = 140.0, 100.0
	    store_named_attribute_002.width, store_named_attribute_002.height = 140.0, 100.0
	    store_named_attribute_003.width, store_named_attribute_003.height = 140.0, 100.0
	    corners_of_vertex.width, corners_of_vertex.height = 140.0, 100.0
	    store_named_attribute_006.width, store_named_attribute_006.height = 140.0, 100.0
	    face_of_corner.width, face_of_corner.height = 140.0, 100.0
	    store_named_attribute_007.width, store_named_attribute_007.height = 140.0, 100.0
	    store_named_attribute_005.width, store_named_attribute_005.height = 140.0, 100.0
	    index_1.width, index_1.height = 140.0, 100.0
	    store_named_attribute_012.width, store_named_attribute_012.height = 140.0, 100.0
	    store_named_attribute_013.width, store_named_attribute_013.height = 140.0, 100.0
	    frame_3.width, frame_3.height = 964.0, 415.0
	    frame_001_2.width, frame_001_2.height = 730.0, 382.0
	    frame_002_3.width, frame_002_3.height = 381.0, 322.0
	    store_named_attribute_008.width, store_named_attribute_008.height = 140.0, 100.0
	    index_001_1.width, index_001_1.height = 140.0, 100.0
	    face_of_corner_001.width, face_of_corner_001.height = 140.0, 100.0
	    store_named_attribute_009.width, store_named_attribute_009.height = 140.0, 100.0
	    evaluate_at_index_002.width, evaluate_at_index_002.height = 140.0, 100.0
	    position_1.width, position_1.height = 140.0, 100.0
	    store_named_attribute_014.width, store_named_attribute_014.height = 140.0, 100.0
	    store_named_attribute_015.width, store_named_attribute_015.height = 140.0, 100.0
	    named_attribute_001_2.width, named_attribute_001_2.height = 140.0, 100.0
	    frame_003_1.width, frame_003_1.height = 760.0, 409.0
	    group_2.width, group_2.height = 140.0, 100.0
	
	    #initialize ob_data links
	    #store_named_attribute_010.Geometry -> store_named_attribute_011.Geometry
	    ob_data.links.new(store_named_attribute_010.outputs[0], store_named_attribute_011.inputs[0])
	    #edge_vertices_001.Position 2 -> vector_math_3.Vector
	    ob_data.links.new(edge_vertices_001.outputs[3], vector_math_3.inputs[0])
	    #edge_vertices_001.Position 1 -> vector_math_3.Vector
	    ob_data.links.new(edge_vertices_001.outputs[2], vector_math_3.inputs[1])
	    #vector_math_3.Vector -> store_named_attribute_010.Value
	    ob_data.links.new(vector_math_3.outputs[0], store_named_attribute_010.inputs[3])
	    #vector_math_3.Vector -> vector_math_001_2.Vector
	    ob_data.links.new(vector_math_3.outputs[0], vector_math_001_2.inputs[0])
	    #vector_math_001_2.Value -> store_named_attribute_011.Value
	    ob_data.links.new(vector_math_001_2.outputs[1], store_named_attribute_011.inputs[3])
	    #store_named_attribute_011.Geometry -> store_named_attribute_2.Geometry
	    ob_data.links.new(store_named_attribute_011.outputs[0], store_named_attribute_2.inputs[0])
	    #face_area.Area -> store_named_attribute_2.Value
	    ob_data.links.new(face_area.outputs[0], store_named_attribute_2.inputs[3])
	    #store_named_attribute_2.Geometry -> store_named_attribute_004.Geometry
	    ob_data.links.new(store_named_attribute_2.outputs[0], store_named_attribute_004.inputs[0])
	    #corners_of_face.Total -> store_named_attribute_004.Value
	    ob_data.links.new(corners_of_face.outputs[1], store_named_attribute_004.inputs[3])
	    #index_1.Index -> store_named_attribute_005.Value
	    ob_data.links.new(index_1.outputs[0], store_named_attribute_005.inputs[3])
	    #vertex_neighbors.Vertex Count -> store_named_attribute_002.Value
	    ob_data.links.new(vertex_neighbors.outputs[0], store_named_attribute_002.inputs[3])
	    #store_named_attribute_005.Geometry -> store_named_attribute_002.Geometry
	    ob_data.links.new(store_named_attribute_005.outputs[0], store_named_attribute_002.inputs[0])
	    #vertex_neighbors.Face Count -> store_named_attribute_003.Value
	    ob_data.links.new(vertex_neighbors.outputs[1], store_named_attribute_003.inputs[3])
	    #store_named_attribute_002.Geometry -> store_named_attribute_003.Geometry
	    ob_data.links.new(store_named_attribute_002.outputs[0], store_named_attribute_003.inputs[0])
	    #store_named_attribute_006.Geometry -> store_named_attribute_007.Geometry
	    ob_data.links.new(store_named_attribute_006.outputs[0], store_named_attribute_007.inputs[0])
	    #store_named_attribute_003.Geometry -> store_named_attribute_006.Geometry
	    ob_data.links.new(store_named_attribute_003.outputs[0], store_named_attribute_006.inputs[0])
	    #corners_of_vertex.Corner Index -> store_named_attribute_007.Value
	    ob_data.links.new(corners_of_vertex.outputs[0], store_named_attribute_007.inputs[3])
	    #face_of_corner.Face Index -> store_named_attribute_006.Value
	    ob_data.links.new(face_of_corner.outputs[0], store_named_attribute_006.inputs[3])
	    #group_input_6.Geometry -> store_named_attribute_005.Geometry
	    ob_data.links.new(group_input_6.outputs[0], store_named_attribute_005.inputs[0])
	    #store_named_attribute_013.Geometry -> store_named_attribute_010.Geometry
	    ob_data.links.new(store_named_attribute_013.outputs[0], store_named_attribute_010.inputs[0])
	    #store_named_attribute_007.Geometry -> store_named_attribute_012.Geometry
	    ob_data.links.new(store_named_attribute_007.outputs[0], store_named_attribute_012.inputs[0])
	    #store_named_attribute_012.Geometry -> store_named_attribute_013.Geometry
	    ob_data.links.new(store_named_attribute_012.outputs[0], store_named_attribute_013.inputs[0])
	    #edge_vertices_001.Vertex Index 1 -> store_named_attribute_012.Value
	    ob_data.links.new(edge_vertices_001.outputs[0], store_named_attribute_012.inputs[3])
	    #edge_vertices_001.Vertex Index 2 -> store_named_attribute_013.Value
	    ob_data.links.new(edge_vertices_001.outputs[1], store_named_attribute_013.inputs[3])
	    #face_of_corner_001.Index in Face -> store_named_attribute_009.Value
	    ob_data.links.new(face_of_corner_001.outputs[1], store_named_attribute_009.inputs[3])
	    #evaluate_at_index_002.Value -> store_named_attribute_014.Value
	    ob_data.links.new(evaluate_at_index_002.outputs[0], store_named_attribute_014.inputs[3])
	    #position_1.Position -> evaluate_at_index_002.Value
	    ob_data.links.new(position_1.outputs[0], evaluate_at_index_002.inputs[1])
	    #store_named_attribute_009.Geometry -> store_named_attribute_014.Geometry
	    ob_data.links.new(store_named_attribute_009.outputs[0], store_named_attribute_014.inputs[0])
	    #index_001_1.Index -> evaluate_at_index_002.Index
	    ob_data.links.new(index_001_1.outputs[0], evaluate_at_index_002.inputs[0])
	    #store_named_attribute_008.Geometry -> store_named_attribute_009.Geometry
	    ob_data.links.new(store_named_attribute_008.outputs[0], store_named_attribute_009.inputs[0])
	    #face_of_corner_001.Face Index -> store_named_attribute_008.Value
	    ob_data.links.new(face_of_corner_001.outputs[0], store_named_attribute_008.inputs[3])
	    #store_named_attribute_014.Geometry -> store_named_attribute_015.Geometry
	    ob_data.links.new(store_named_attribute_014.outputs[0], store_named_attribute_015.inputs[0])
	    #named_attribute_001_2.Attribute -> store_named_attribute_015.Value
	    ob_data.links.new(named_attribute_001_2.outputs[0], store_named_attribute_015.inputs[3])
	    #store_named_attribute_004.Geometry -> store_named_attribute_008.Geometry
	    ob_data.links.new(store_named_attribute_004.outputs[0], store_named_attribute_008.inputs[0])
	    #group_2.Geometry -> group_output_8.Geometry
	    ob_data.links.new(group_2.outputs[0], group_output_8.inputs[0])
	    #store_named_attribute_015.Geometry -> group_2.Geometry
	    ob_data.links.new(store_named_attribute_015.outputs[0], group_2.inputs[0])
	    return ob_data
	
	ob_data = ob_data_node_group()
	
	#initialize convex_curve_profile node group
	def convex_curve_profile_node_group():
	    convex_curve_profile = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "CONVEX_CURVE_PROFILE")
	
	    convex_curve_profile.color_tag = 'NONE'
	    convex_curve_profile.description = ""
	    convex_curve_profile.default_group_node_width = 140
	    
	
	
	    #convex_curve_profile interface
	    #Socket Geometry
	    geometry_socket_11 = convex_curve_profile.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_11.attribute_domain = 'POINT'
	
	    #Socket Geometry
	    geometry_socket_12 = convex_curve_profile.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_12.attribute_domain = 'POINT'
	
	    #Socket Surface
	    surface_socket_3 = convex_curve_profile.interface.new_socket(name = "Surface", in_out='INPUT', socket_type = 'NodeSocketObject')
	    surface_socket_3.attribute_domain = 'POINT'
	
	
	    #initialize convex_curve_profile nodes
	    #node Group Output
	    group_output_9 = convex_curve_profile.nodes.new("NodeGroupOutput")
	    group_output_9.name = "Group Output"
	    group_output_9.is_active_output = True
	
	    #node Group Input
	    group_input_7 = convex_curve_profile.nodes.new("NodeGroupInput")
	    group_input_7.name = "Group Input"
	    group_input_7.outputs[0].hide = True
	    group_input_7.outputs[2].hide = True
	
	    #node Delete Geometry.001
	    delete_geometry_001 = convex_curve_profile.nodes.new("GeometryNodeDeleteGeometry")
	    delete_geometry_001.name = "Delete Geometry.001"
	    delete_geometry_001.hide = True
	    delete_geometry_001.domain = 'FACE'
	    delete_geometry_001.mode = 'ALL'
	
	    #node Sample Nearest
	    sample_nearest = convex_curve_profile.nodes.new("GeometryNodeSampleNearest")
	    sample_nearest.name = "Sample Nearest"
	    sample_nearest.hide = True
	    sample_nearest.domain = 'FACE'
	
	    #node Named Attribute.004
	    named_attribute_004_2 = convex_curve_profile.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute_004_2.name = "Named Attribute.004"
	    named_attribute_004_2.data_type = 'FLOAT_VECTOR'
	    #Name
	    named_attribute_004_2.inputs[0].default_value = "centers"
	
	    #node Sample Index
	    sample_index_1 = convex_curve_profile.nodes.new("GeometryNodeSampleIndex")
	    sample_index_1.name = "Sample Index"
	    sample_index_1.hide = True
	    sample_index_1.clamp = False
	    sample_index_1.data_type = 'FLOAT_VECTOR'
	    sample_index_1.domain = 'POINT'
	
	    #node Normal
	    normal_1 = convex_curve_profile.nodes.new("GeometryNodeInputNormal")
	    normal_1.name = "Normal"
	    normal_1.legacy_corner_normals = False
	
	    #node Compare.001
	    compare_001_2 = convex_curve_profile.nodes.new("FunctionNodeCompare")
	    compare_001_2.name = "Compare.001"
	    compare_001_2.hide = True
	    compare_001_2.data_type = 'VECTOR'
	    compare_001_2.mode = 'DOT_PRODUCT'
	    compare_001_2.operation = 'LESS_THAN'
	    compare_001_2.inputs[0].hide = True
	    compare_001_2.inputs[1].hide = True
	    compare_001_2.inputs[2].hide = True
	    compare_001_2.inputs[3].hide = True
	    compare_001_2.inputs[6].hide = True
	    compare_001_2.inputs[7].hide = True
	    compare_001_2.inputs[8].hide = True
	    compare_001_2.inputs[9].hide = True
	    compare_001_2.inputs[10].hide = True
	    compare_001_2.inputs[11].hide = True
	    compare_001_2.inputs[12].hide = True
	    #C
	    compare_001_2.inputs[10].default_value = 0.0
	
	    #node Sample Index.001
	    sample_index_001_1 = convex_curve_profile.nodes.new("GeometryNodeSampleIndex")
	    sample_index_001_1.name = "Sample Index.001"
	    sample_index_001_1.hide = True
	    sample_index_001_1.clamp = False
	    sample_index_001_1.data_type = 'FLOAT_VECTOR'
	    sample_index_001_1.domain = 'FACE'
	
	    #node Normal.001
	    normal_001 = convex_curve_profile.nodes.new("GeometryNodeInputNormal")
	    normal_001.name = "Normal.001"
	    normal_001.legacy_corner_normals = False
	
	    #node Index
	    index_2 = convex_curve_profile.nodes.new("GeometryNodeInputIndex")
	    index_2.name = "Index"
	
	    #node Delete Geometry.002
	    delete_geometry_002 = convex_curve_profile.nodes.new("GeometryNodeDeleteGeometry")
	    delete_geometry_002.name = "Delete Geometry.002"
	    delete_geometry_002.hide = True
	    delete_geometry_002.domain = 'EDGE'
	    delete_geometry_002.mode = 'EDGE_FACE'
	
	    #node Compare.002
	    compare_002_3 = convex_curve_profile.nodes.new("FunctionNodeCompare")
	    compare_002_3.name = "Compare.002"
	    compare_002_3.hide = True
	    compare_002_3.data_type = 'INT'
	    compare_002_3.mode = 'ELEMENT'
	    compare_002_3.operation = 'GREATER_THAN'
	    compare_002_3.inputs[0].hide = True
	    compare_002_3.inputs[1].hide = True
	    compare_002_3.inputs[3].hide = True
	    compare_002_3.inputs[4].hide = True
	    compare_002_3.inputs[5].hide = True
	    compare_002_3.inputs[6].hide = True
	    compare_002_3.inputs[7].hide = True
	    compare_002_3.inputs[8].hide = True
	    compare_002_3.inputs[9].hide = True
	    compare_002_3.inputs[10].hide = True
	    compare_002_3.inputs[11].hide = True
	    compare_002_3.inputs[12].hide = True
	    #B_INT
	    compare_002_3.inputs[3].default_value = 1
	
	    #node Edge Neighbors
	    edge_neighbors = convex_curve_profile.nodes.new("GeometryNodeInputMeshEdgeNeighbors")
	    edge_neighbors.name = "Edge Neighbors"
	
	    #node Merge by Distance.001
	    merge_by_distance_001 = convex_curve_profile.nodes.new("GeometryNodeMergeByDistance")
	    merge_by_distance_001.name = "Merge by Distance.001"
	    merge_by_distance_001.hide = True
	    merge_by_distance_001.mode = 'ALL'
	    #Selection
	    merge_by_distance_001.inputs[1].default_value = True
	    #Distance
	    merge_by_distance_001.inputs[2].default_value = 0.0010000000474974513
	
	    #node Object Info.001
	    object_info_001_1 = convex_curve_profile.nodes.new("GeometryNodeObjectInfo")
	    object_info_001_1.name = "Object Info.001"
	    object_info_001_1.hide = True
	    object_info_001_1.transform_space = 'RELATIVE'
	    object_info_001_1.inputs[1].hide = True
	    object_info_001_1.outputs[0].hide = True
	    object_info_001_1.outputs[1].hide = True
	    object_info_001_1.outputs[2].hide = True
	    object_info_001_1.outputs[3].hide = True
	    #As Instance
	    object_info_001_1.inputs[1].default_value = False
	
	    #node Mesh to Curve
	    mesh_to_curve = convex_curve_profile.nodes.new("GeometryNodeMeshToCurve")
	    mesh_to_curve.name = "Mesh to Curve"
	    mesh_to_curve.hide = True
	    mesh_to_curve.inputs[1].hide = True
	    #Selection
	    mesh_to_curve.inputs[1].default_value = True
	
	    #node Group Input.001
	    group_input_001_3 = convex_curve_profile.nodes.new("NodeGroupInput")
	    group_input_001_3.name = "Group Input.001"
	    group_input_001_3.outputs[1].hide = True
	    group_input_001_3.outputs[2].hide = True
	
	    #node Group Input.002
	    group_input_002_3 = convex_curve_profile.nodes.new("NodeGroupInput")
	    group_input_002_3.name = "Group Input.002"
	    group_input_002_3.outputs[1].hide = True
	    group_input_002_3.outputs[2].hide = True
	
	
	
	
	
	    #Set locations
	    group_output_9.location = (-131.0277099609375, -136.95811462402344)
	    group_input_7.location = (-1372.7032470703125, 0.0)
	    delete_geometry_001.location = (-493.7367858886719, -158.619873046875)
	    sample_nearest.location = (-1047.2716064453125, -74.38338470458984)
	    named_attribute_004_2.location = (-1049.729248046875, -104.1408462524414)
	    sample_index_1.location = (-867.6522827148438, -34.97990036010742)
	    normal_1.location = (-871.3107299804688, -66.765625)
	    compare_001_2.location = (-673.4129638671875, -168.19537353515625)
	    sample_index_001_1.location = (-858.5, -306.8774108886719)
	    normal_001.location = (-1051.0888671875, -297.31158447265625)
	    index_2.location = (-1051.08349609375, -356.73614501953125)
	    delete_geometry_002.location = (-313.3856201171875, -217.2752685546875)
	    compare_002_3.location = (-312.8627624511719, -254.32992553710938)
	    edge_neighbors.location = (-312.9332580566406, -286.8948669433594)
	    merge_by_distance_001.location = (-493.1096496582031, -211.0828094482422)
	    object_info_001_1.location = (-1184.5113525390625, -24.985580444335938)
	    mesh_to_curve.location = (-310.79290771484375, -162.5512237548828)
	    group_input_001_3.location = (-1051.9151611328125, -236.2948760986328)
	    group_input_002_3.location = (-496.93218994140625, -82.70318603515625)
	
	    #Set dimensions
	    group_output_9.width, group_output_9.height = 140.0, 100.0
	    group_input_7.width, group_input_7.height = 140.0, 100.0
	    delete_geometry_001.width, delete_geometry_001.height = 140.0, 100.0
	    sample_nearest.width, sample_nearest.height = 140.0, 100.0
	    named_attribute_004_2.width, named_attribute_004_2.height = 140.0, 100.0
	    sample_index_1.width, sample_index_1.height = 140.0, 100.0
	    normal_1.width, normal_1.height = 140.0, 100.0
	    compare_001_2.width, compare_001_2.height = 140.0, 100.0
	    sample_index_001_1.width, sample_index_001_1.height = 140.0, 100.0
	    normal_001.width, normal_001.height = 140.0, 100.0
	    index_2.width, index_2.height = 140.0, 100.0
	    delete_geometry_002.width, delete_geometry_002.height = 140.0, 100.0
	    compare_002_3.width, compare_002_3.height = 140.0, 100.0
	    edge_neighbors.width, edge_neighbors.height = 140.0, 100.0
	    merge_by_distance_001.width, merge_by_distance_001.height = 140.0, 100.0
	    object_info_001_1.width, object_info_001_1.height = 140.0, 100.0
	    mesh_to_curve.width, mesh_to_curve.height = 140.0, 100.0
	    group_input_001_3.width, group_input_001_3.height = 140.0, 100.0
	    group_input_002_3.width, group_input_002_3.height = 140.0, 100.0
	
	    #initialize convex_curve_profile links
	    #sample_index_1.Value -> compare_001_2.A
	    convex_curve_profile.links.new(sample_index_1.outputs[0], compare_001_2.inputs[4])
	    #compare_001_2.Result -> delete_geometry_001.Selection
	    convex_curve_profile.links.new(compare_001_2.outputs[0], delete_geometry_001.inputs[1])
	    #named_attribute_004_2.Attribute -> sample_nearest.Sample Position
	    convex_curve_profile.links.new(named_attribute_004_2.outputs[0], sample_nearest.inputs[1])
	    #sample_nearest.Index -> sample_index_1.Index
	    convex_curve_profile.links.new(sample_nearest.outputs[0], sample_index_1.inputs[2])
	    #object_info_001_1.Geometry -> sample_index_1.Geometry
	    convex_curve_profile.links.new(object_info_001_1.outputs[4], sample_index_1.inputs[0])
	    #normal_001.Normal -> sample_index_001_1.Value
	    convex_curve_profile.links.new(normal_001.outputs[0], sample_index_001_1.inputs[1])
	    #edge_neighbors.Face Count -> compare_002_3.A
	    convex_curve_profile.links.new(edge_neighbors.outputs[0], compare_002_3.inputs[2])
	    #index_2.Index -> sample_index_001_1.Index
	    convex_curve_profile.links.new(index_2.outputs[0], sample_index_001_1.inputs[2])
	    #compare_002_3.Result -> delete_geometry_002.Selection
	    convex_curve_profile.links.new(compare_002_3.outputs[0], delete_geometry_002.inputs[1])
	    #sample_index_001_1.Value -> compare_001_2.B
	    convex_curve_profile.links.new(sample_index_001_1.outputs[0], compare_001_2.inputs[5])
	    #merge_by_distance_001.Geometry -> delete_geometry_002.Geometry
	    convex_curve_profile.links.new(merge_by_distance_001.outputs[0], delete_geometry_002.inputs[0])
	    #object_info_001_1.Geometry -> sample_nearest.Geometry
	    convex_curve_profile.links.new(object_info_001_1.outputs[4], sample_nearest.inputs[0])
	    #normal_1.Normal -> sample_index_1.Value
	    convex_curve_profile.links.new(normal_1.outputs[0], sample_index_1.inputs[1])
	    #delete_geometry_001.Geometry -> merge_by_distance_001.Geometry
	    convex_curve_profile.links.new(delete_geometry_001.outputs[0], merge_by_distance_001.inputs[0])
	    #group_input_7.Surface -> object_info_001_1.Object
	    convex_curve_profile.links.new(group_input_7.outputs[1], object_info_001_1.inputs[0])
	    #delete_geometry_002.Geometry -> mesh_to_curve.Mesh
	    convex_curve_profile.links.new(delete_geometry_002.outputs[0], mesh_to_curve.inputs[0])
	    #mesh_to_curve.Curve -> group_output_9.Geometry
	    convex_curve_profile.links.new(mesh_to_curve.outputs[0], group_output_9.inputs[0])
	    #group_input_001_3.Geometry -> sample_index_001_1.Geometry
	    convex_curve_profile.links.new(group_input_001_3.outputs[0], sample_index_001_1.inputs[0])
	    #group_input_002_3.Geometry -> delete_geometry_001.Geometry
	    convex_curve_profile.links.new(group_input_002_3.outputs[0], delete_geometry_001.inputs[0])
	    return convex_curve_profile
	
	convex_curve_profile = convex_curve_profile_node_group()
	
	#initialize curve_from_centroids node group
	def curve_from_centroids_node_group():
	    curve_from_centroids = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "CURVE_FROM_CENTROIDS")
	
	    curve_from_centroids.color_tag = 'NONE'
	    curve_from_centroids.description = "Create new curve from centroids of multiple curves."
	    curve_from_centroids.default_group_node_width = 140
	    
	
	    curve_from_centroids.is_modifier = True
	
	    #curve_from_centroids interface
	    #Socket Geometry
	    geometry_socket_13 = curve_from_centroids.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_13.attribute_domain = 'POINT'
	    geometry_socket_13.description = "New curve along centroid."
	
	    #Socket Geometry
	    geometry_socket_14 = curve_from_centroids.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_14.attribute_domain = 'POINT'
	    geometry_socket_14.description = "Curve with multiple splines."
	
	
	    #initialize curve_from_centroids nodes
	    #node Group Output
	    group_output_10 = curve_from_centroids.nodes.new("NodeGroupOutput")
	    group_output_10.name = "Group Output"
	    group_output_10.is_active_output = True
	    group_output_10.inputs[1].hide = True
	
	    #node Group Input
	    group_input_8 = curve_from_centroids.nodes.new("NodeGroupInput")
	    group_input_8.name = "Group Input"
	    group_input_8.outputs[1].hide = True
	
	    #node Repeat Input
	    repeat_input = curve_from_centroids.nodes.new("GeometryNodeRepeatInput")
	    repeat_input.name = "Repeat Input"
	    #node Repeat Output
	    repeat_output = curve_from_centroids.nodes.new("GeometryNodeRepeatOutput")
	    repeat_output.name = "Repeat Output"
	    repeat_output.active_index = 0
	    repeat_output.inspection_index = 0
	    repeat_output.repeat_items.clear()
	    # Create item "Geometry"
	    repeat_output.repeat_items.new('GEOMETRY', "Geometry")
	
	    #node Domain Size
	    domain_size_1 = curve_from_centroids.nodes.new("GeometryNodeAttributeDomainSize")
	    domain_size_1.name = "Domain Size"
	    domain_size_1.hide = True
	    domain_size_1.component = 'CURVE'
	
	    #node Math
	    math_2 = curve_from_centroids.nodes.new("ShaderNodeMath")
	    math_2.name = "Math"
	    math_2.hide = True
	    math_2.operation = 'DIVIDE'
	    math_2.use_clamp = False
	
	    #node Attribute Statistic
	    attribute_statistic_1 = curve_from_centroids.nodes.new("GeometryNodeAttributeStatistic")
	    attribute_statistic_1.name = "Attribute Statistic"
	    attribute_statistic_1.hide = True
	    attribute_statistic_1.data_type = 'FLOAT_VECTOR'
	    attribute_statistic_1.domain = 'POINT'
	    attribute_statistic_1.outputs[1].hide = True
	    attribute_statistic_1.outputs[2].hide = True
	    attribute_statistic_1.outputs[3].hide = True
	    attribute_statistic_1.outputs[4].hide = True
	    attribute_statistic_1.outputs[5].hide = True
	    attribute_statistic_1.outputs[6].hide = True
	    attribute_statistic_1.outputs[7].hide = True
	
	    #node Position
	    position_2 = curve_from_centroids.nodes.new("GeometryNodeInputPosition")
	    position_2.name = "Position"
	
	    #node Compare
	    compare_2 = curve_from_centroids.nodes.new("FunctionNodeCompare")
	    compare_2.name = "Compare"
	    compare_2.hide = True
	    compare_2.data_type = 'INT'
	    compare_2.mode = 'ELEMENT'
	    compare_2.operation = 'EQUAL'
	    compare_2.inputs[0].hide = True
	    compare_2.inputs[1].hide = True
	    compare_2.inputs[4].hide = True
	    compare_2.inputs[5].hide = True
	    compare_2.inputs[6].hide = True
	    compare_2.inputs[7].hide = True
	    compare_2.inputs[8].hide = True
	    compare_2.inputs[9].hide = True
	    compare_2.inputs[10].hide = True
	    compare_2.inputs[11].hide = True
	    compare_2.inputs[12].hide = True
	
	    #node Index
	    index_3 = curve_from_centroids.nodes.new("GeometryNodeInputIndex")
	    index_3.name = "Index"
	
	    #node Math.001
	    math_001 = curve_from_centroids.nodes.new("ShaderNodeMath")
	    math_001.name = "Math.001"
	    math_001.hide = True
	    math_001.operation = 'FLOORED_MODULO'
	    math_001.use_clamp = False
	
	    #node Join Geometry
	    join_geometry = curve_from_centroids.nodes.new("GeometryNodeJoinGeometry")
	    join_geometry.name = "Join Geometry"
	    join_geometry.hide = True
	
	    #node Points
	    points = curve_from_centroids.nodes.new("GeometryNodePoints")
	    points.name = "Points"
	    points.hide = True
	    points.inputs[0].hide = True
	    points.inputs[2].hide = True
	    #Count
	    points.inputs[0].default_value = 1
	    #Radius
	    points.inputs[2].default_value = 0.10000000149011612
	
	    #node Points to Curves
	    points_to_curves = curve_from_centroids.nodes.new("GeometryNodePointsToCurves")
	    points_to_curves.name = "Points to Curves"
	    points_to_curves.inputs[1].hide = True
	    points_to_curves.inputs[2].hide = True
	    #Curve Group ID
	    points_to_curves.inputs[1].default_value = 0
	    #Weight
	    points_to_curves.inputs[2].default_value = 0.0
	
	    #node Group Input.001
	    group_input_001_4 = curve_from_centroids.nodes.new("NodeGroupInput")
	    group_input_001_4.name = "Group Input.001"
	    group_input_001_4.outputs[1].hide = True
	
	    #node Reroute
	    reroute_4 = curve_from_centroids.nodes.new("NodeReroute")
	    reroute_4.name = "Reroute"
	    reroute_4.socket_idname = "NodeSocketFloat"
	    #node Reroute.001
	    reroute_001_3 = curve_from_centroids.nodes.new("NodeReroute")
	    reroute_001_3.name = "Reroute.001"
	    reroute_001_3.socket_idname = "NodeSocketFloat"
	
	    #Process zone input Repeat Input
	    repeat_input.pair_with_output(repeat_output)
	
	
	
	
	
	    #Set locations
	    group_output_10.location = (1302.4775390625, -33.473915100097656)
	    group_input_8.location = (-200.0, 0.0)
	    repeat_input.location = (190.50888061523438, -15.57342529296875)
	    repeat_output.location = (960.9061279296875, -56.923553466796875)
	    domain_size_1.location = (-17.454999923706055, -24.502897262573242)
	    math_2.location = (-15.655715942382812, -60.950531005859375)
	    attribute_statistic_1.location = (601.8110961914062, -193.2510528564453)
	    position_2.location = (603.0748901367188, -224.40174865722656)
	    compare_2.location = (421.454833984375, -243.2841339111328)
	    index_3.location = (420.0198974609375, -145.9272918701172)
	    math_001.location = (419.6551513671875, -207.2341766357422)
	    join_geometry.location = (780.789794921875, -82.40153503417969)
	    points.location = (778.607666015625, -120.22016906738281)
	    points_to_curves.location = (1130.0872802734375, -31.979248046875)
	    group_input_001_4.location = (600.9574584960938, -131.9265899658203)
	    reroute_4.location = (162.4088134765625, -72.65477752685547)
	    reroute_001_3.location = (165.49166870117188, -227.18580627441406)
	
	    #Set dimensions
	    group_output_10.width, group_output_10.height = 140.0, 100.0
	    group_input_8.width, group_input_8.height = 140.0, 100.0
	    repeat_input.width, repeat_input.height = 140.0, 100.0
	    repeat_output.width, repeat_output.height = 140.0, 100.0
	    domain_size_1.width, domain_size_1.height = 140.0, 100.0
	    math_2.width, math_2.height = 140.0, 100.0
	    attribute_statistic_1.width, attribute_statistic_1.height = 140.0, 100.0
	    position_2.width, position_2.height = 140.0, 100.0
	    compare_2.width, compare_2.height = 140.0, 100.0
	    index_3.width, index_3.height = 140.0, 100.0
	    math_001.width, math_001.height = 140.0, 100.0
	    join_geometry.width, join_geometry.height = 140.0, 100.0
	    points.width, points.height = 140.0, 100.0
	    points_to_curves.width, points_to_curves.height = 140.0, 100.0
	    group_input_001_4.width, group_input_001_4.height = 140.0, 100.0
	    reroute_4.width, reroute_4.height = 10.0, 100.0
	    reroute_001_3.width, reroute_001_3.height = 10.0, 100.0
	
	    #initialize curve_from_centroids links
	    #group_input_8.Geometry -> domain_size_1.Geometry
	    curve_from_centroids.links.new(group_input_8.outputs[0], domain_size_1.inputs[0])
	    #domain_size_1.Point Count -> math_2.Value
	    curve_from_centroids.links.new(domain_size_1.outputs[0], math_2.inputs[0])
	    #domain_size_1.Spline Count -> math_2.Value
	    curve_from_centroids.links.new(domain_size_1.outputs[4], math_2.inputs[1])
	    #reroute_4.Output -> repeat_input.Iterations
	    curve_from_centroids.links.new(reroute_4.outputs[0], repeat_input.inputs[0])
	    #position_2.Position -> attribute_statistic_1.Attribute
	    curve_from_centroids.links.new(position_2.outputs[0], attribute_statistic_1.inputs[2])
	    #index_3.Index -> math_001.Value
	    curve_from_centroids.links.new(index_3.outputs[0], math_001.inputs[0])
	    #reroute_001_3.Output -> math_001.Value
	    curve_from_centroids.links.new(reroute_001_3.outputs[0], math_001.inputs[1])
	    #compare_2.Result -> attribute_statistic_1.Selection
	    curve_from_centroids.links.new(compare_2.outputs[0], attribute_statistic_1.inputs[1])
	    #repeat_input.Iteration -> compare_2.B
	    curve_from_centroids.links.new(repeat_input.outputs[0], compare_2.inputs[3])
	    #math_001.Value -> compare_2.A
	    curve_from_centroids.links.new(math_001.outputs[0], compare_2.inputs[2])
	    #join_geometry.Geometry -> repeat_output.Geometry
	    curve_from_centroids.links.new(join_geometry.outputs[0], repeat_output.inputs[0])
	    #attribute_statistic_1.Mean -> points.Position
	    curve_from_centroids.links.new(attribute_statistic_1.outputs[0], points.inputs[1])
	    #points.Points -> join_geometry.Geometry
	    curve_from_centroids.links.new(points.outputs[0], join_geometry.inputs[0])
	    #repeat_output.Geometry -> points_to_curves.Points
	    curve_from_centroids.links.new(repeat_output.outputs[0], points_to_curves.inputs[0])
	    #group_input_001_4.Geometry -> attribute_statistic_1.Geometry
	    curve_from_centroids.links.new(group_input_001_4.outputs[0], attribute_statistic_1.inputs[0])
	    #points_to_curves.Curves -> group_output_10.Geometry
	    curve_from_centroids.links.new(points_to_curves.outputs[0], group_output_10.inputs[0])
	    #math_2.Value -> reroute_4.Input
	    curve_from_centroids.links.new(math_2.outputs[0], reroute_4.inputs[0])
	    #reroute_4.Output -> reroute_001_3.Input
	    curve_from_centroids.links.new(reroute_4.outputs[0], reroute_001_3.inputs[0])
	    #repeat_input.Geometry -> join_geometry.Geometry
	    curve_from_centroids.links.new(repeat_input.outputs[1], join_geometry.inputs[0])
	    return curve_from_centroids
	
	curve_from_centroids = curve_from_centroids_node_group()
	
	#initialize mesh_magic node group
	def mesh_magic_node_group():
	    mesh_magic = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "MESH_MAGIC")
	
	    mesh_magic.color_tag = 'NONE'
	    mesh_magic.description = "Convert a set of curves to a stylized mesh."
	    mesh_magic.default_group_node_width = 140
	    
	
	    mesh_magic.is_modifier = True
	
	    #mesh_magic interface
	    #Socket Geometry
	    geometry_socket_15 = mesh_magic.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_15.attribute_domain = 'POINT'
	    geometry_socket_15.description = "Curves converted to a stylized mesh."
	
	    #Socket Geometry
	    geometry_socket_16 = mesh_magic.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_16.attribute_domain = 'POINT'
	    geometry_socket_16.description = "Set of curves."
	
	    #Socket Surface
	    surface_socket_4 = mesh_magic.interface.new_socket(name = "Surface", in_out='INPUT', socket_type = 'NodeSocketObject')
	    surface_socket_4.attribute_domain = 'POINT'
	    surface_socket_4.description = "Surface mesh."
	
	    #Socket Radius
	    radius_socket = mesh_magic.interface.new_socket(name = "Radius", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    radius_socket.default_value = 0.09999999403953552
	    radius_socket.min_value = 0.0
	    radius_socket.max_value = 3.4028234663852886e+38
	    radius_socket.subtype = 'DISTANCE'
	    radius_socket.attribute_domain = 'POINT'
	    radius_socket.description = "Mesh Radius."
	
	    #Panel Enhancement Settings
	    enhancement_settings_panel = mesh_magic.interface.new_panel("Enhancement Settings", default_closed=True)
	    enhancement_settings_panel.description = "Settings for mesh enhancements."
	    #Socket Use Enhancements
	    use_enhancements_socket = mesh_magic.interface.new_socket(name = "Use Enhancements", in_out='INPUT', socket_type = 'NodeSocketBool', parent = enhancement_settings_panel)
	    use_enhancements_socket.default_value = True
	    use_enhancements_socket.attribute_domain = 'POINT'
	    use_enhancements_socket.description = "Use Enhancement settings."
	
	    #Socket Maintain Shape Factor
	    maintain_shape_factor_socket = mesh_magic.interface.new_socket(name = "Maintain Shape Factor", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = enhancement_settings_panel)
	    maintain_shape_factor_socket.default_value = 1.0
	    maintain_shape_factor_socket.min_value = 0.0
	    maintain_shape_factor_socket.max_value = 1.0
	    maintain_shape_factor_socket.subtype = 'FACTOR'
	    maintain_shape_factor_socket.attribute_domain = 'POINT'
	    maintain_shape_factor_socket.description = "Factor to blend overall effect"
	
	    #Socket Pin at Parameter
	    pin_at_parameter_socket_1 = mesh_magic.interface.new_socket(name = "Pin at Parameter", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = enhancement_settings_panel)
	    pin_at_parameter_socket_1.default_value = 0.0
	    pin_at_parameter_socket_1.min_value = 0.0
	    pin_at_parameter_socket_1.max_value = 1.0
	    pin_at_parameter_socket_1.subtype = 'FACTOR'
	    pin_at_parameter_socket_1.attribute_domain = 'POINT'
	    pin_at_parameter_socket_1.description = "Pin each curve at a certain point for the operation"
	
	    #Socket Snap to surface
	    snap_to_surface_socket_1 = mesh_magic.interface.new_socket(name = "Snap to surface", in_out='INPUT', socket_type = 'NodeSocketBool', parent = enhancement_settings_panel)
	    snap_to_surface_socket_1.default_value = False
	    snap_to_surface_socket_1.attribute_domain = 'POINT'
	    snap_to_surface_socket_1.description = "Snap mesh roots to the nearest surface point."
	
	    #Panel Subdivision Settings
	    subdivision_settings_panel = mesh_magic.interface.new_panel("Subdivision Settings")
	    subdivision_settings_panel.description = "Settings for mesh subdivision."
	    #Socket Level
	    level_socket = mesh_magic.interface.new_socket(name = "Level", in_out='INPUT', socket_type = 'NodeSocketInt', parent = subdivision_settings_panel)
	    level_socket.default_value = 1
	    level_socket.min_value = 0
	    level_socket.max_value = 6
	    level_socket.subtype = 'NONE'
	    level_socket.attribute_domain = 'POINT'
	    level_socket.description = "Subdivision level."
	
	    #Socket Edge Crease
	    edge_crease_socket = mesh_magic.interface.new_socket(name = "Edge Crease", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = subdivision_settings_panel)
	    edge_crease_socket.default_value = 0.0
	    edge_crease_socket.min_value = 0.0
	    edge_crease_socket.max_value = 1.0
	    edge_crease_socket.subtype = 'FACTOR'
	    edge_crease_socket.attribute_domain = 'POINT'
	    edge_crease_socket.description = "Edge crease factor for subdivision."
	
	    #Socket Vertex Crease
	    vertex_crease_socket = mesh_magic.interface.new_socket(name = "Vertex Crease", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = subdivision_settings_panel)
	    vertex_crease_socket.default_value = 0.0
	    vertex_crease_socket.min_value = 0.0
	    vertex_crease_socket.max_value = 1.0
	    vertex_crease_socket.subtype = 'FACTOR'
	    vertex_crease_socket.attribute_domain = 'POINT'
	    vertex_crease_socket.description = "Vertex crease factor for subdivision."
	
	    #Socket Limit Surface
	    limit_surface_socket = mesh_magic.interface.new_socket(name = "Limit Surface", in_out='INPUT', socket_type = 'NodeSocketBool', parent = subdivision_settings_panel)
	    limit_surface_socket.default_value = True
	    limit_surface_socket.attribute_domain = 'POINT'
	    limit_surface_socket.description = "Limit subdivision on surface."
	
	
	    mesh_magic.interface.move_to_parent(subdivision_settings_panel, enhancement_settings_panel, 9)
	    #Panel Merge Settings
	    merge_settings_panel = mesh_magic.interface.new_panel("Merge Settings", default_closed=True)
	    merge_settings_panel.description = "Settings for merging points."
	    #Socket Distance
	    distance_socket = mesh_magic.interface.new_socket(name = "Distance", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = merge_settings_panel)
	    distance_socket.default_value = 0.0010000000474974513
	    distance_socket.min_value = 0.0
	    distance_socket.max_value = 3.4028234663852886e+38
	    distance_socket.subtype = 'DISTANCE'
	    distance_socket.attribute_domain = 'POINT'
	    distance_socket.description = "Distance threshold to merge points."
	
	
	    mesh_magic.interface.move_to_parent(merge_settings_panel, enhancement_settings_panel, 14)
	
	
	    #initialize mesh_magic nodes
	    #node Group Output
	    group_output_11 = mesh_magic.nodes.new("NodeGroupOutput")
	    group_output_11.name = "Group Output"
	    group_output_11.is_active_output = True
	    group_output_11.inputs[1].hide = True
	
	    #node Group Input
	    group_input_9 = mesh_magic.nodes.new("NodeGroupInput")
	    group_input_9.name = "Group Input"
	    group_input_9.outputs[1].hide = True
	    group_input_9.outputs[2].hide = True
	    group_input_9.outputs[3].hide = True
	    group_input_9.outputs[4].hide = True
	    group_input_9.outputs[5].hide = True
	    group_input_9.outputs[6].hide = True
	    group_input_9.outputs[7].hide = True
	    group_input_9.outputs[8].hide = True
	    group_input_9.outputs[9].hide = True
	    group_input_9.outputs[10].hide = True
	    group_input_9.outputs[11].hide = True
	    group_input_9.outputs[12].hide = True
	
	    #node Group
	    group_3 = mesh_magic.nodes.new("GeometryNodeGroup")
	    group_3.name = "Group"
	    group_3.node_tree = ob_data
	
	    #node Group.004
	    group_004 = mesh_magic.nodes.new("GeometryNodeGroup")
	    group_004.name = "Group.004"
	    group_004.node_tree = convex_curve_profile
	
	    #node Group.005
	    group_005 = mesh_magic.nodes.new("GeometryNodeGroup")
	    group_005.name = "Group.005"
	    group_005.node_tree = curve_from_centroids
	
	    #node Curve to Mesh
	    curve_to_mesh = mesh_magic.nodes.new("GeometryNodeCurveToMesh")
	    curve_to_mesh.name = "Curve to Mesh"
	    #Fill Caps
	    curve_to_mesh.inputs[2].default_value = True
	
	    #node Set Position.001
	    set_position_001_3 = mesh_magic.nodes.new("GeometryNodeSetPosition")
	    set_position_001_3.name = "Set Position.001"
	    set_position_001_3.inputs[1].hide = True
	    set_position_001_3.inputs[3].hide = True
	    #Selection
	    set_position_001_3.inputs[1].default_value = True
	    #Offset
	    set_position_001_3.inputs[3].default_value = (0.0, 0.0, 0.0)
	
	    #node Position.002
	    position_002_3 = mesh_magic.nodes.new("GeometryNodeInputPosition")
	    position_002_3.name = "Position.002"
	
	    #node Separate XYZ
	    separate_xyz = mesh_magic.nodes.new("ShaderNodeSeparateXYZ")
	    separate_xyz.name = "Separate XYZ"
	    separate_xyz.hide = True
	    separate_xyz.outputs[2].hide = True
	
	    #node Combine XYZ
	    combine_xyz = mesh_magic.nodes.new("ShaderNodeCombineXYZ")
	    combine_xyz.name = "Combine XYZ"
	    combine_xyz.hide = True
	    combine_xyz.inputs[2].hide = True
	    #Z
	    combine_xyz.inputs[2].default_value = 0.0
	
	    #node Set Curve Radius
	    set_curve_radius = mesh_magic.nodes.new("GeometryNodeSetCurveRadius")
	    set_curve_radius.name = "Set Curve Radius"
	    set_curve_radius.inputs[1].hide = True
	    #Selection
	    set_curve_radius.inputs[1].default_value = True
	
	    #node Capture Attribute.001
	    capture_attribute_001_2 = mesh_magic.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_001_2.name = "Capture Attribute.001"
	    capture_attribute_001_2.hide = True
	    capture_attribute_001_2.active_index = 0
	    capture_attribute_001_2.capture_items.clear()
	    capture_attribute_001_2.capture_items.new('FLOAT', "Factor")
	    capture_attribute_001_2.capture_items["Factor"].data_type = 'FLOAT'
	    capture_attribute_001_2.domain = 'POINT'
	    capture_attribute_001_2.inputs[2].hide = True
	    capture_attribute_001_2.outputs[2].hide = True
	
	    #node Capture Attribute.002
	    capture_attribute_002_1 = mesh_magic.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_002_1.name = "Capture Attribute.002"
	    capture_attribute_002_1.hide = True
	    capture_attribute_002_1.active_index = 0
	    capture_attribute_002_1.capture_items.clear()
	    capture_attribute_002_1.capture_items.new('FLOAT', "Factor")
	    capture_attribute_002_1.capture_items["Factor"].data_type = 'FLOAT'
	    capture_attribute_002_1.domain = 'POINT'
	    capture_attribute_002_1.inputs[2].hide = True
	    capture_attribute_002_1.outputs[2].hide = True
	
	    #node Spline Parameter
	    spline_parameter_2 = mesh_magic.nodes.new("GeometryNodeSplineParameter")
	    spline_parameter_2.name = "Spline Parameter"
	    spline_parameter_2.outputs[1].hide = True
	    spline_parameter_2.outputs[2].hide = True
	
	    #node Store Named Attribute
	    store_named_attribute_3 = mesh_magic.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_3.name = "Store Named Attribute"
	    store_named_attribute_3.data_type = 'FLOAT2'
	    store_named_attribute_3.domain = 'CORNER'
	    #Selection
	    store_named_attribute_3.inputs[1].default_value = True
	    #Name
	    store_named_attribute_3.inputs[2].default_value = "UVMap"
	
	    #node Combine XYZ.001
	    combine_xyz_001 = mesh_magic.nodes.new("ShaderNodeCombineXYZ")
	    combine_xyz_001.name = "Combine XYZ.001"
	    combine_xyz_001.hide = True
	    combine_xyz_001.inputs[2].hide = True
	    #Z
	    combine_xyz_001.inputs[2].default_value = 0.0
	
	    #node Stylized Mesh Shape
	    stylized_mesh_shape = mesh_magic.nodes.new("ShaderNodeFloatCurve")
	    stylized_mesh_shape.label = "Stylized Mesh Shape"
	    stylized_mesh_shape.name = "Stylized Mesh Shape"
	    #mapping settings
	    stylized_mesh_shape.mapping.extend = 'EXTRAPOLATED'
	    stylized_mesh_shape.mapping.tone = 'STANDARD'
	    stylized_mesh_shape.mapping.black_level = (0.0, 0.0, 0.0)
	    stylized_mesh_shape.mapping.white_level = (1.0, 1.0, 1.0)
	    stylized_mesh_shape.mapping.clip_min_x = 0.0
	    stylized_mesh_shape.mapping.clip_min_y = 0.0
	    stylized_mesh_shape.mapping.clip_max_x = 1.0
	    stylized_mesh_shape.mapping.clip_max_y = 1.0
	    stylized_mesh_shape.mapping.use_clip = True
	    #curve 0
	    stylized_mesh_shape_curve_0 = stylized_mesh_shape.mapping.curves[0]
	    stylized_mesh_shape_curve_0_point_0 = stylized_mesh_shape_curve_0.points[0]
	    stylized_mesh_shape_curve_0_point_0.location = (0.00909090880304575, 1.0)
	    stylized_mesh_shape_curve_0_point_0.handle_type = 'AUTO'
	    stylized_mesh_shape_curve_0_point_1 = stylized_mesh_shape_curve_0.points[1]
	    stylized_mesh_shape_curve_0_point_1.location = (0.27272725105285645, 0.3750000596046448)
	    stylized_mesh_shape_curve_0_point_1.handle_type = 'AUTO'
	    stylized_mesh_shape_curve_0_point_2 = stylized_mesh_shape_curve_0.points.new(0.459090918302536, 0.3562501072883606)
	    stylized_mesh_shape_curve_0_point_2.handle_type = 'AUTO'
	    stylized_mesh_shape_curve_0_point_3 = stylized_mesh_shape_curve_0.points.new(1.0, 0.0)
	    stylized_mesh_shape_curve_0_point_3.handle_type = 'AUTO'
	    #update curve after changes
	    stylized_mesh_shape.mapping.update()
	    #Factor
	    stylized_mesh_shape.inputs[0].default_value = 1.0
	
	    #node Spline Parameter.001
	    spline_parameter_001 = mesh_magic.nodes.new("GeometryNodeSplineParameter")
	    spline_parameter_001.name = "Spline Parameter.001"
	    spline_parameter_001.outputs[1].hide = True
	    spline_parameter_001.outputs[2].hide = True
	
	    #node Map Range
	    map_range_1 = mesh_magic.nodes.new("ShaderNodeMapRange")
	    map_range_1.name = "Map Range"
	    map_range_1.hide = True
	    map_range_1.clamp = True
	    map_range_1.data_type = 'FLOAT'
	    map_range_1.interpolation_type = 'LINEAR'
	    map_range_1.inputs[1].hide = True
	    map_range_1.inputs[2].hide = True
	    map_range_1.inputs[3].hide = True
	    map_range_1.inputs[5].hide = True
	    map_range_1.inputs[6].hide = True
	    map_range_1.inputs[7].hide = True
	    map_range_1.inputs[8].hide = True
	    map_range_1.inputs[9].hide = True
	    map_range_1.inputs[10].hide = True
	    map_range_1.inputs[11].hide = True
	    map_range_1.outputs[1].hide = True
	    #From Min
	    map_range_1.inputs[1].default_value = 0.0
	    #From Max
	    map_range_1.inputs[2].default_value = 1.0
	    #To Min
	    map_range_1.inputs[3].default_value = 0.0
	
	    #node Group Input.001
	    group_input_001_5 = mesh_magic.nodes.new("NodeGroupInput")
	    group_input_001_5.name = "Group Input.001"
	    group_input_001_5.outputs[0].hide = True
	    group_input_001_5.outputs[1].hide = True
	    group_input_001_5.outputs[3].hide = True
	    group_input_001_5.outputs[4].hide = True
	    group_input_001_5.outputs[5].hide = True
	    group_input_001_5.outputs[6].hide = True
	    group_input_001_5.outputs[7].hide = True
	    group_input_001_5.outputs[8].hide = True
	    group_input_001_5.outputs[9].hide = True
	    group_input_001_5.outputs[10].hide = True
	    group_input_001_5.outputs[11].hide = True
	    group_input_001_5.outputs[12].hide = True
	
	    #node Group Input.002
	    group_input_002_4 = mesh_magic.nodes.new("NodeGroupInput")
	    group_input_002_4.name = "Group Input.002"
	    group_input_002_4.outputs[0].hide = True
	    group_input_002_4.outputs[2].hide = True
	    group_input_002_4.outputs[3].hide = True
	    group_input_002_4.outputs[4].hide = True
	    group_input_002_4.outputs[5].hide = True
	    group_input_002_4.outputs[6].hide = True
	    group_input_002_4.outputs[7].hide = True
	    group_input_002_4.outputs[8].hide = True
	    group_input_002_4.outputs[9].hide = True
	    group_input_002_4.outputs[10].hide = True
	    group_input_002_4.outputs[11].hide = True
	    group_input_002_4.outputs[12].hide = True
	
	    #node Group Input.003
	    group_input_003_3 = mesh_magic.nodes.new("NodeGroupInput")
	    group_input_003_3.name = "Group Input.003"
	    group_input_003_3.outputs[0].hide = True
	    group_input_003_3.outputs[2].hide = True
	    group_input_003_3.outputs[3].hide = True
	    group_input_003_3.outputs[4].hide = True
	    group_input_003_3.outputs[5].hide = True
	    group_input_003_3.outputs[6].hide = True
	    group_input_003_3.outputs[7].hide = True
	    group_input_003_3.outputs[8].hide = True
	    group_input_003_3.outputs[9].hide = True
	    group_input_003_3.outputs[10].hide = True
	    group_input_003_3.outputs[11].hide = True
	    group_input_003_3.outputs[12].hide = True
	
	    #node Set Position.002
	    set_position_002_2 = mesh_magic.nodes.new("GeometryNodeSetPosition")
	    set_position_002_2.name = "Set Position.002"
	    set_position_002_2.inputs[3].hide = True
	    #Offset
	    set_position_002_2.inputs[3].default_value = (0.0, 0.0, 0.0)
	
	    #node Geometry Proximity
	    geometry_proximity = mesh_magic.nodes.new("GeometryNodeProximity")
	    geometry_proximity.name = "Geometry Proximity"
	    geometry_proximity.hide = True
	    geometry_proximity.target_element = 'FACES'
	    geometry_proximity.inputs[1].hide = True
	    geometry_proximity.inputs[2].hide = True
	    geometry_proximity.inputs[3].hide = True
	    geometry_proximity.outputs[1].hide = True
	    geometry_proximity.outputs[2].hide = True
	    #Group ID
	    geometry_proximity.inputs[1].default_value = 0
	    #Source Position
	    geometry_proximity.inputs[2].default_value = (0.0, 0.0, 0.0)
	    #Sample Group ID
	    geometry_proximity.inputs[3].default_value = 0
	
	    #node Object Info
	    object_info_1 = mesh_magic.nodes.new("GeometryNodeObjectInfo")
	    object_info_1.name = "Object Info"
	    object_info_1.hide = True
	    object_info_1.transform_space = 'RELATIVE'
	    object_info_1.inputs[1].hide = True
	    object_info_1.outputs[0].hide = True
	    object_info_1.outputs[1].hide = True
	    object_info_1.outputs[2].hide = True
	    object_info_1.outputs[3].hide = True
	    #As Instance
	    object_info_1.inputs[1].default_value = False
	
	    #node Named Attribute
	    named_attribute_3 = mesh_magic.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute_3.name = "Named Attribute"
	    named_attribute_3.data_type = 'FLOAT_VECTOR'
	    #Name
	    named_attribute_3.inputs[0].default_value = "UVMap"
	
	    #node Separate XYZ.001
	    separate_xyz_001 = mesh_magic.nodes.new("ShaderNodeSeparateXYZ")
	    separate_xyz_001.name = "Separate XYZ.001"
	    separate_xyz_001.hide = True
	    separate_xyz_001.outputs[1].hide = True
	    separate_xyz_001.outputs[2].hide = True
	
	    #node Compare
	    compare_3 = mesh_magic.nodes.new("FunctionNodeCompare")
	    compare_3.name = "Compare"
	    compare_3.hide = True
	    compare_3.data_type = 'FLOAT'
	    compare_3.mode = 'ELEMENT'
	    compare_3.operation = 'EQUAL'
	    compare_3.inputs[1].hide = True
	    compare_3.inputs[2].hide = True
	    compare_3.inputs[3].hide = True
	    compare_3.inputs[4].hide = True
	    compare_3.inputs[5].hide = True
	    compare_3.inputs[6].hide = True
	    compare_3.inputs[7].hide = True
	    compare_3.inputs[8].hide = True
	    compare_3.inputs[9].hide = True
	    compare_3.inputs[10].hide = True
	    compare_3.inputs[11].hide = True
	    compare_3.inputs[12].hide = True
	    #B
	    compare_3.inputs[1].default_value = 0.0
	    #Epsilon
	    compare_3.inputs[12].default_value = 0.0
	
	    #node Delete Geometry.001
	    delete_geometry_001_1 = mesh_magic.nodes.new("GeometryNodeDeleteGeometry")
	    delete_geometry_001_1.name = "Delete Geometry.001"
	    delete_geometry_001_1.domain = 'POINT'
	    delete_geometry_001_1.mode = 'ALL'
	
	    #node Vertex Neighbors
	    vertex_neighbors_1 = mesh_magic.nodes.new("GeometryNodeInputMeshVertexNeighbors")
	    vertex_neighbors_1.name = "Vertex Neighbors"
	    vertex_neighbors_1.outputs[0].hide = True
	
	    #node Compare.001
	    compare_001_3 = mesh_magic.nodes.new("FunctionNodeCompare")
	    compare_001_3.name = "Compare.001"
	    compare_001_3.hide = True
	    compare_001_3.data_type = 'INT'
	    compare_001_3.mode = 'ELEMENT'
	    compare_001_3.operation = 'EQUAL'
	    compare_001_3.inputs[0].hide = True
	    compare_001_3.inputs[1].hide = True
	    compare_001_3.inputs[3].hide = True
	    compare_001_3.inputs[4].hide = True
	    compare_001_3.inputs[5].hide = True
	    compare_001_3.inputs[6].hide = True
	    compare_001_3.inputs[7].hide = True
	    compare_001_3.inputs[8].hide = True
	    compare_001_3.inputs[9].hide = True
	    compare_001_3.inputs[10].hide = True
	    compare_001_3.inputs[11].hide = True
	    compare_001_3.inputs[12].hide = True
	    #B_INT
	    compare_001_3.inputs[3].default_value = 0
	
	    #node Raycast
	    raycast = mesh_magic.nodes.new("GeometryNodeRaycast")
	    raycast.name = "Raycast"
	    raycast.hide = True
	    raycast.data_type = 'FLOAT'
	    raycast.mapping = 'INTERPOLATED'
	    raycast.inputs[1].hide = True
	    raycast.inputs[2].hide = True
	    raycast.inputs[4].hide = True
	    raycast.outputs[0].hide = True
	    raycast.outputs[3].hide = True
	    raycast.outputs[4].hide = True
	    #Attribute
	    raycast.inputs[1].default_value = 0.0
	    #Source Position
	    raycast.inputs[2].default_value = (0.0, 0.0, 0.0)
	    #Ray Length
	    raycast.inputs[4].default_value = 100.0
	
	    #node Vector Math.001
	    vector_math_001_3 = mesh_magic.nodes.new("ShaderNodeVectorMath")
	    vector_math_001_3.name = "Vector Math.001"
	    vector_math_001_3.hide = True
	    vector_math_001_3.operation = 'SUBTRACT'
	
	    #node Position
	    position_3 = mesh_magic.nodes.new("GeometryNodeInputPosition")
	    position_3.name = "Position"
	
	    #node Vector Math.002
	    vector_math_002_1 = mesh_magic.nodes.new("ShaderNodeVectorMath")
	    vector_math_002_1.name = "Vector Math.002"
	    vector_math_002_1.hide = True
	    vector_math_002_1.operation = 'NORMALIZE'
	
	    #node Compare.003
	    compare_003_1 = mesh_magic.nodes.new("FunctionNodeCompare")
	    compare_003_1.name = "Compare.003"
	    compare_003_1.hide = True
	    compare_003_1.data_type = 'VECTOR'
	    compare_003_1.mode = 'DOT_PRODUCT'
	    compare_003_1.operation = 'GREATER_THAN'
	    compare_003_1.inputs[0].hide = True
	    compare_003_1.inputs[1].hide = True
	    compare_003_1.inputs[2].hide = True
	    compare_003_1.inputs[3].hide = True
	    compare_003_1.inputs[6].hide = True
	    compare_003_1.inputs[7].hide = True
	    compare_003_1.inputs[8].hide = True
	    compare_003_1.inputs[9].hide = True
	    compare_003_1.inputs[10].hide = True
	    compare_003_1.inputs[11].hide = True
	    compare_003_1.inputs[12].hide = True
	    #C
	    compare_003_1.inputs[10].default_value = 0.0
	
	    #node Merge by Distance
	    merge_by_distance = mesh_magic.nodes.new("GeometryNodeMergeByDistance")
	    merge_by_distance.name = "Merge by Distance"
	    merge_by_distance.mode = 'ALL'
	
	    #node Subdivision Surface
	    subdivision_surface = mesh_magic.nodes.new("GeometryNodeSubdivisionSurface")
	    subdivision_surface.name = "Subdivision Surface"
	    subdivision_surface.boundary_smooth = 'ALL'
	    subdivision_surface.uv_smooth = 'PRESERVE_BOUNDARIES'
	
	    #node Frame
	    frame_4 = mesh_magic.nodes.new("NodeFrame")
	    frame_4.name = "Frame"
	    frame_4.label_size = 20
	    frame_4.shrink = True
	
	    #node Geometry Proximity.001
	    geometry_proximity_001 = mesh_magic.nodes.new("GeometryNodeProximity")
	    geometry_proximity_001.name = "Geometry Proximity.001"
	    geometry_proximity_001.target_element = 'POINTS'
	    geometry_proximity_001.inputs[1].hide = True
	    geometry_proximity_001.inputs[2].hide = True
	    geometry_proximity_001.inputs[3].hide = True
	    geometry_proximity_001.outputs[1].hide = True
	    geometry_proximity_001.outputs[2].hide = True
	    #Group ID
	    geometry_proximity_001.inputs[1].default_value = 0
	    #Source Position
	    geometry_proximity_001.inputs[2].default_value = (0.0, 0.0, 0.0)
	    #Sample Group ID
	    geometry_proximity_001.inputs[3].default_value = 0
	
	    #node Reroute
	    reroute_5 = mesh_magic.nodes.new("NodeReroute")
	    reroute_5.name = "Reroute"
	    reroute_5.socket_idname = "NodeSocketVector"
	    #node Curve to Mesh.001
	    curve_to_mesh_001 = mesh_magic.nodes.new("GeometryNodeCurveToMesh")
	    curve_to_mesh_001.name = "Curve to Mesh.001"
	    curve_to_mesh_001.hide = True
	    curve_to_mesh_001.inputs[1].hide = True
	    curve_to_mesh_001.inputs[2].hide = True
	    #Fill Caps
	    curve_to_mesh_001.inputs[2].default_value = False
	
	    #node Reroute.002
	    reroute_002_2 = mesh_magic.nodes.new("NodeReroute")
	    reroute_002_2.name = "Reroute.002"
	    reroute_002_2.socket_idname = "NodeSocketVector"
	    #node Attribute Statistic
	    attribute_statistic_2 = mesh_magic.nodes.new("GeometryNodeAttributeStatistic")
	    attribute_statistic_2.name = "Attribute Statistic"
	    attribute_statistic_2.hide = True
	    attribute_statistic_2.data_type = 'FLOAT_VECTOR'
	    attribute_statistic_2.domain = 'POINT'
	    attribute_statistic_2.inputs[1].hide = True
	    attribute_statistic_2.outputs[1].hide = True
	    attribute_statistic_2.outputs[2].hide = True
	    attribute_statistic_2.outputs[3].hide = True
	    attribute_statistic_2.outputs[4].hide = True
	    attribute_statistic_2.outputs[5].hide = True
	    attribute_statistic_2.outputs[6].hide = True
	    attribute_statistic_2.outputs[7].hide = True
	    #Selection
	    attribute_statistic_2.inputs[1].default_value = True
	
	    #node Position.003
	    position_003 = mesh_magic.nodes.new("GeometryNodeInputPosition")
	    position_003.name = "Position.003"
	
	    #node Vector Math.003
	    vector_math_003_1 = mesh_magic.nodes.new("ShaderNodeVectorMath")
	    vector_math_003_1.name = "Vector Math.003"
	    vector_math_003_1.hide = True
	    vector_math_003_1.operation = 'SCALE'
	    vector_math_003_1.inputs[1].hide = True
	    vector_math_003_1.inputs[2].hide = True
	    vector_math_003_1.inputs[3].hide = True
	    vector_math_003_1.outputs[1].hide = True
	    #Scale
	    vector_math_003_1.inputs[3].default_value = -1.0
	
	    #node Sample Index
	    sample_index_2 = mesh_magic.nodes.new("GeometryNodeSampleIndex")
	    sample_index_2.name = "Sample Index"
	    sample_index_2.hide = True
	    sample_index_2.clamp = True
	    sample_index_2.data_type = 'FLOAT_VECTOR'
	    sample_index_2.domain = 'POINT'
	
	    #node Reroute.003
	    reroute_003_1 = mesh_magic.nodes.new("NodeReroute")
	    reroute_003_1.name = "Reroute.003"
	    reroute_003_1.socket_idname = "NodeSocketGeometry"
	    #node Index
	    index_4 = mesh_magic.nodes.new("GeometryNodeInputIndex")
	    index_4.name = "Index"
	
	    #node Transform Geometry
	    transform_geometry = mesh_magic.nodes.new("GeometryNodeTransform")
	    transform_geometry.name = "Transform Geometry"
	    transform_geometry.mode = 'COMPONENTS'
	    transform_geometry.inputs[2].hide = True
	    transform_geometry.inputs[3].hide = True
	    transform_geometry.inputs[4].hide = True
	    #Rotation
	    transform_geometry.inputs[2].default_value = (0.0, 0.0, 0.0)
	    #Scale
	    transform_geometry.inputs[3].default_value = (1.0, 1.0, 1.0)
	
	    #node Set Position.003
	    set_position_003_1 = mesh_magic.nodes.new("GeometryNodeSetPosition")
	    set_position_003_1.name = "Set Position.003"
	    set_position_003_1.inputs[3].hide = True
	    #Offset
	    set_position_003_1.inputs[3].default_value = (0.0, 0.0, 0.0)
	
	    #node Boolean Math.002
	    boolean_math_002_1 = mesh_magic.nodes.new("FunctionNodeBooleanMath")
	    boolean_math_002_1.name = "Boolean Math.002"
	    boolean_math_002_1.hide = True
	    boolean_math_002_1.operation = 'AND'
	
	    #node Reroute.001
	    reroute_001_4 = mesh_magic.nodes.new("NodeReroute")
	    reroute_001_4.name = "Reroute.001"
	    reroute_001_4.socket_idname = "NodeSocketVector"
	    #node Reroute.004
	    reroute_004_3 = mesh_magic.nodes.new("NodeReroute")
	    reroute_004_3.name = "Reroute.004"
	    reroute_004_3.socket_idname = "NodeSocketVector"
	    #node Switch
	    switch_2 = mesh_magic.nodes.new("GeometryNodeSwitch")
	    switch_2.name = "Switch"
	    switch_2.input_type = 'GEOMETRY'
	
	    #node Reroute.005
	    reroute_005_3 = mesh_magic.nodes.new("NodeReroute")
	    reroute_005_3.name = "Reroute.005"
	    reroute_005_3.socket_idname = "NodeSocketGeometry"
	    #node Reroute.006
	    reroute_006_3 = mesh_magic.nodes.new("NodeReroute")
	    reroute_006_3.name = "Reroute.006"
	    reroute_006_3.socket_idname = "NodeSocketGeometry"
	    #node Reroute.007
	    reroute_007_3 = mesh_magic.nodes.new("NodeReroute")
	    reroute_007_3.name = "Reroute.007"
	    reroute_007_3.socket_idname = "NodeSocketGeometry"
	    #node Switch.001
	    switch_001_4 = mesh_magic.nodes.new("GeometryNodeSwitch")
	    switch_001_4.name = "Switch.001"
	    switch_001_4.input_type = 'GEOMETRY'
	
	    #node Curve to Mesh.002
	    curve_to_mesh_002 = mesh_magic.nodes.new("GeometryNodeCurveToMesh")
	    curve_to_mesh_002.name = "Curve to Mesh.002"
	    curve_to_mesh_002.hide = True
	    curve_to_mesh_002.inputs[1].hide = True
	    curve_to_mesh_002.inputs[2].hide = True
	    #Fill Caps
	    curve_to_mesh_002.inputs[2].default_value = False
	
	    #node Geometry Proximity.002
	    geometry_proximity_002 = mesh_magic.nodes.new("GeometryNodeProximity")
	    geometry_proximity_002.name = "Geometry Proximity.002"
	    geometry_proximity_002.hide = True
	    geometry_proximity_002.target_element = 'EDGES'
	    geometry_proximity_002.inputs[1].hide = True
	    geometry_proximity_002.inputs[2].hide = True
	    geometry_proximity_002.inputs[3].hide = True
	    geometry_proximity_002.outputs[1].hide = True
	    geometry_proximity_002.outputs[2].hide = True
	    #Group ID
	    geometry_proximity_002.inputs[1].default_value = 0
	    #Source Position
	    geometry_proximity_002.inputs[2].default_value = (0.0, 0.0, 0.0)
	    #Sample Group ID
	    geometry_proximity_002.inputs[3].default_value = 0
	
	    #node Position.004
	    position_004 = mesh_magic.nodes.new("GeometryNodeInputPosition")
	    position_004.name = "Position.004"
	
	    #node Vector Math.004
	    vector_math_004_2 = mesh_magic.nodes.new("ShaderNodeVectorMath")
	    vector_math_004_2.name = "Vector Math.004"
	    vector_math_004_2.hide = True
	    vector_math_004_2.operation = 'SUBTRACT'
	
	    #node Compare.002
	    compare_002_4 = mesh_magic.nodes.new("FunctionNodeCompare")
	    compare_002_4.name = "Compare.002"
	    compare_002_4.hide = True
	    compare_002_4.data_type = 'VECTOR'
	    compare_002_4.mode = 'DOT_PRODUCT'
	    compare_002_4.operation = 'GREATER_THAN'
	    compare_002_4.inputs[0].hide = True
	    compare_002_4.inputs[1].hide = True
	    compare_002_4.inputs[2].hide = True
	    compare_002_4.inputs[3].hide = True
	    compare_002_4.inputs[6].hide = True
	    compare_002_4.inputs[7].hide = True
	    compare_002_4.inputs[8].hide = True
	    compare_002_4.inputs[9].hide = True
	    compare_002_4.inputs[10].hide = True
	    compare_002_4.inputs[11].hide = True
	    compare_002_4.inputs[12].hide = True
	    #C
	    compare_002_4.inputs[10].default_value = 0.0
	
	    #node Vector Math.005
	    vector_math_005_1 = mesh_magic.nodes.new("ShaderNodeVectorMath")
	    vector_math_005_1.name = "Vector Math.005"
	    vector_math_005_1.hide = True
	    vector_math_005_1.operation = 'NORMALIZE'
	
	    #node Normal
	    normal_2 = mesh_magic.nodes.new("GeometryNodeInputNormal")
	    normal_2.name = "Normal"
	    normal_2.legacy_corner_normals = False
	
	    #node Reroute.008
	    reroute_008_3 = mesh_magic.nodes.new("NodeReroute")
	    reroute_008_3.name = "Reroute.008"
	    reroute_008_3.socket_idname = "NodeSocketGeometry"
	    #node Reroute.009
	    reroute_009_2 = mesh_magic.nodes.new("NodeReroute")
	    reroute_009_2.name = "Reroute.009"
	    reroute_009_2.socket_idname = "NodeSocketGeometry"
	    #node Reroute.010
	    reroute_010_2 = mesh_magic.nodes.new("NodeReroute")
	    reroute_010_2.name = "Reroute.010"
	    reroute_010_2.socket_idname = "NodeSocketGeometry"
	    #node Group Input.005
	    group_input_005_3 = mesh_magic.nodes.new("NodeGroupInput")
	    group_input_005_3.name = "Group Input.005"
	    group_input_005_3.outputs[0].hide = True
	    group_input_005_3.outputs[1].hide = True
	    group_input_005_3.outputs[2].hide = True
	    group_input_005_3.outputs[3].hide = True
	    group_input_005_3.outputs[4].hide = True
	    group_input_005_3.outputs[5].hide = True
	    group_input_005_3.outputs[6].hide = True
	    group_input_005_3.outputs[11].hide = True
	    group_input_005_3.outputs[12].hide = True
	
	    #node Group Input.006
	    group_input_006_2 = mesh_magic.nodes.new("NodeGroupInput")
	    group_input_006_2.name = "Group Input.006"
	    group_input_006_2.outputs[0].hide = True
	    group_input_006_2.outputs[1].hide = True
	    group_input_006_2.outputs[2].hide = True
	    group_input_006_2.outputs[3].hide = True
	    group_input_006_2.outputs[4].hide = True
	    group_input_006_2.outputs[5].hide = True
	    group_input_006_2.outputs[7].hide = True
	    group_input_006_2.outputs[8].hide = True
	    group_input_006_2.outputs[9].hide = True
	    group_input_006_2.outputs[10].hide = True
	    group_input_006_2.outputs[11].hide = True
	    group_input_006_2.outputs[12].hide = True
	
	    #node Group Input.007
	    group_input_007_1 = mesh_magic.nodes.new("NodeGroupInput")
	    group_input_007_1.name = "Group Input.007"
	    group_input_007_1.outputs[0].hide = True
	    group_input_007_1.outputs[1].hide = True
	    group_input_007_1.outputs[2].hide = True
	    group_input_007_1.outputs[4].hide = True
	    group_input_007_1.outputs[5].hide = True
	    group_input_007_1.outputs[6].hide = True
	    group_input_007_1.outputs[7].hide = True
	    group_input_007_1.outputs[8].hide = True
	    group_input_007_1.outputs[9].hide = True
	    group_input_007_1.outputs[10].hide = True
	    group_input_007_1.outputs[11].hide = True
	    group_input_007_1.outputs[12].hide = True
	
	    #node Group Input.008
	    group_input_008_1 = mesh_magic.nodes.new("NodeGroupInput")
	    group_input_008_1.name = "Group Input.008"
	    group_input_008_1.outputs[0].hide = True
	    group_input_008_1.outputs[1].hide = True
	    group_input_008_1.outputs[2].hide = True
	    group_input_008_1.outputs[3].hide = True
	    group_input_008_1.outputs[4].hide = True
	    group_input_008_1.outputs[5].hide = True
	    group_input_008_1.outputs[6].hide = True
	    group_input_008_1.outputs[7].hide = True
	    group_input_008_1.outputs[8].hide = True
	    group_input_008_1.outputs[9].hide = True
	    group_input_008_1.outputs[10].hide = True
	    group_input_008_1.outputs[12].hide = True
	
	    #node Convex Hull
	    convex_hull = mesh_magic.nodes.new("GeometryNodeConvexHull")
	    convex_hull.name = "Convex Hull"
	    convex_hull.hide = True
	
	    #node Resample Curve
	    resample_curve_1 = mesh_magic.nodes.new("GeometryNodeResampleCurve")
	    resample_curve_1.name = "Resample Curve"
	    resample_curve_1.hide = True
	    resample_curve_1.keep_last_segment = True
	    resample_curve_1.mode = 'COUNT'
	    resample_curve_1.inputs[1].hide = True
	    resample_curve_1.inputs[2].hide = True
	    resample_curve_1.inputs[3].hide = True
	    #Selection
	    resample_curve_1.inputs[1].default_value = True
	    #Count
	    resample_curve_1.inputs[2].default_value = 1
	
	    #node Group Input.009
	    group_input_009_1 = mesh_magic.nodes.new("NodeGroupInput")
	    group_input_009_1.name = "Group Input.009"
	    group_input_009_1.outputs[1].hide = True
	    group_input_009_1.outputs[2].hide = True
	    group_input_009_1.outputs[3].hide = True
	    group_input_009_1.outputs[4].hide = True
	    group_input_009_1.outputs[5].hide = True
	    group_input_009_1.outputs[6].hide = True
	    group_input_009_1.outputs[7].hide = True
	    group_input_009_1.outputs[8].hide = True
	    group_input_009_1.outputs[9].hide = True
	    group_input_009_1.outputs[10].hide = True
	    group_input_009_1.outputs[11].hide = True
	    group_input_009_1.outputs[12].hide = True
	
	    #node Reroute.011
	    reroute_011_2 = mesh_magic.nodes.new("NodeReroute")
	    reroute_011_2.name = "Reroute.011"
	    reroute_011_2.socket_idname = "NodeSocketGeometry"
	    #node Reroute.012
	    reroute_012_2 = mesh_magic.nodes.new("NodeReroute")
	    reroute_012_2.name = "Reroute.012"
	    reroute_012_2.socket_idname = "NodeSocketGeometry"
	    #node Reroute.013
	    reroute_013_2 = mesh_magic.nodes.new("NodeReroute")
	    reroute_013_2.name = "Reroute.013"
	    reroute_013_2.socket_idname = "NodeSocketGeometry"
	    #node Sample Index.003
	    sample_index_003 = mesh_magic.nodes.new("GeometryNodeSampleIndex")
	    sample_index_003.name = "Sample Index.003"
	    sample_index_003.hide = True
	    sample_index_003.clamp = False
	    sample_index_003.data_type = 'FLOAT_VECTOR'
	    sample_index_003.domain = 'POINT'
	
	    #node Index.001
	    index_001_2 = mesh_magic.nodes.new("GeometryNodeInputIndex")
	    index_001_2.name = "Index.001"
	
	    #node Position.006
	    position_006 = mesh_magic.nodes.new("GeometryNodeInputPosition")
	    position_006.name = "Position.006"
	
	    #node Group Input.004
	    group_input_004_2 = mesh_magic.nodes.new("NodeGroupInput")
	    group_input_004_2.name = "Group Input.004"
	    group_input_004_2.outputs[0].hide = True
	    group_input_004_2.outputs[1].hide = True
	    group_input_004_2.outputs[2].hide = True
	    group_input_004_2.outputs[3].hide = True
	    group_input_004_2.outputs[6].hide = True
	    group_input_004_2.outputs[7].hide = True
	    group_input_004_2.outputs[8].hide = True
	    group_input_004_2.outputs[9].hide = True
	    group_input_004_2.outputs[10].hide = True
	    group_input_004_2.outputs[11].hide = True
	    group_input_004_2.outputs[12].hide = True
	
	    #node Group.001
	    group_001_1 = mesh_magic.nodes.new("GeometryNodeGroup")
	    group_001_1.name = "Group.001"
	    group_001_1.hide = True
	    group_001_1.node_tree = restore_curve_segment_length
	    group_001_1.inputs[1].hide = True
	    #Socket_2
	    group_001_1.inputs[1].default_value = True
	
	
	
	
	    #Set parents
	    merge_by_distance.parent = frame_4
	    subdivision_surface.parent = frame_4
	    curve_to_mesh_002.parent = frame_4
	    geometry_proximity_002.parent = frame_4
	    position_004.parent = frame_4
	    vector_math_004_2.parent = frame_4
	    compare_002_4.parent = frame_4
	    vector_math_005_1.parent = frame_4
	    normal_2.parent = frame_4
	    group_input_008_1.parent = frame_4
	
	    #Set locations
	    group_output_11.location = (1031.5587158203125, 81.62284851074219)
	    group_input_9.location = (-1337.7576904296875, 0.0)
	    group_3.location = (-1561.1627197265625, -444.97662353515625)
	    group_004.location = (-1387.1285400390625, -444.80096435546875)
	    group_005.location = (-1159.2635498046875, 48.164581298828125)
	    curve_to_mesh.location = (-312.4471435546875, -60.54876708984375)
	    set_position_001_3.location = (-788.6621704101562, -228.47361755371094)
	    position_002_3.location = (-792.6373901367188, -405.48309326171875)
	    separate_xyz.location = (-791.5325317382812, -374.3955078125)
	    combine_xyz.location = (-790.7725219726562, -337.9853515625)
	    set_curve_radius.location = (-975.1597900390625, 75.02672576904297)
	    capture_attribute_001_2.location = (-531.400146484375, -121.226318359375)
	    capture_attribute_002_1.location = (-533.6032104492188, -185.83802795410156)
	    spline_parameter_2.location = (-533.6025390625, -35.50511169433594)
	    store_named_attribute_3.location = (-132.1085205078125, -31.856613159179688)
	    combine_xyz_001.location = (-307.5316162109375, -196.94834899902344)
	    stylized_mesh_shape.location = (-1338.9588623046875, 386.1346435546875)
	    spline_parameter_001.location = (-1335.0230712890625, 69.11566925048828)
	    map_range_1.location = (-974.5907592773438, 125.018310546875)
	    group_input_001_5.location = (-977.0860595703125, 187.7188720703125)
	    group_input_002_4.location = (-1562.2896728515625, -548.21484375)
	    group_input_003_3.location = (-323.04083251953125, -284.2138671875)
	    set_position_002_2.location = (59.1375732421875, -6.6789703369140625)
	    geometry_proximity.location = (-124.21686553955078, -345.39385986328125)
	    object_info_1.location = (-317.07330322265625, -345.391845703125)
	    named_attribute_3.location = (63.2789306640625, -209.4910430908203)
	    separate_xyz_001.location = (63.2738037109375, -177.6759490966797)
	    compare_3.location = (63.2681884765625, -140.26284790039062)
	    delete_geometry_001_1.location = (410.6286315917969, 7.821929931640625)
	    vertex_neighbors_1.location = (412.1759948730469, -176.40525817871094)
	    compare_001_3.location = (412.1015319824219, -146.34869384765625)
	    raycast.location = (56.59661865234375, -342.426513671875)
	    vector_math_001_3.location = (-122.12775421142578, -379.99432373046875)
	    position_3.location = (-317.44903564453125, -374.13055419921875)
	    vector_math_002_1.location = (-120.57453155517578, -415.8165283203125)
	    compare_003_1.location = (63.36517333984375, -378.056884765625)
	    merge_by_distance.location = (344.03363037109375, -30.38555908203125)
	    subdivision_surface.location = (30.454833984375, -36.522369384765625)
	    frame_4.location = (621.0, -142.0)
	    geometry_proximity_001.location = (-983.087158203125, -543.2496948242188)
	    reroute_5.location = (28.21014404296875, -110.69659423828125)
	    curve_to_mesh_001.location = (-1194.0711669921875, -621.5685424804688)
	    reroute_002_2.location = (31.23211669921875, -243.04759216308594)
	    attribute_statistic_2.location = (-983.5204467773438, -440.9342041015625)
	    position_003.location = (-1198.7054443359375, -486.99920654296875)
	    vector_math_003_1.location = (-981.1094360351562, -384.22332763671875)
	    sample_index_2.location = (-982.5184936523438, -494.052734375)
	    reroute_003_1.location = (-1015.1716918945312, -474.0562744140625)
	    index_4.location = (-1197.283447265625, -541.866455078125)
	    transform_geometry.location = (-981.6549682617188, -253.2978057861328)
	    set_position_003_1.location = (244.274658203125, -105.82246398925781)
	    boolean_math_002_1.location = (244.3353271484375, -239.52256774902344)
	    reroute_001_4.location = (-389.7041015625, -577.631103515625)
	    reroute_004_3.location = (-390.2657775878906, -249.13380432128906)
	    switch_2.location = (833.3876953125, 80.71955871582031)
	    reroute_005_3.location = (601.5782470703125, -26.6990966796875)
	    reroute_006_3.location = (1102.367431640625, -101.81690979003906)
	    reroute_007_3.location = (833.978759765625, -102.31964111328125)
	    switch_001_4.location = (249.525634765625, 64.32618713378906)
	    curve_to_mesh_002.location = (36.904541015625, -387.6512451171875)
	    geometry_proximity_002.location = (347.34417724609375, -302.5712890625)
	    position_004.location = (36.405517578125, -311.45703125)
	    vector_math_004_2.location = (343.53411865234375, -249.55474853515625)
	    compare_002_4.location = (346.50726318359375, -180.98382568359375)
	    vector_math_005_1.location = (344.39007568359375, -215.7021484375)
	    normal_2.location = (35.951416015625, -253.07757568359375)
	    reroute_008_3.location = (606.60009765625, -287.90728759765625)
	    reroute_009_2.location = (-699.68603515625, 40.084739685058594)
	    reroute_010_2.location = (-571.5803833007812, -123.06626892089844)
	    group_input_005_3.location = (420.6587219238281, -276.055908203125)
	    group_input_006_2.location = (249.810546875, 120.62094116210938)
	    group_input_007_1.location = (834.636962890625, 135.9620361328125)
	    group_input_008_1.location = (188.27728271484375, -123.00439453125)
	    convex_hull.location = (-1747.9849853515625, -517.2109375)
	    resample_curve_1.location = (-1751.5504150390625, -566.2632446289062)
	    group_input_009_1.location = (-1751.3270263671875, -597.8270874023438)
	    reroute_011_2.location = (-571.0870361328125, 164.75799560546875)
	    reroute_012_2.location = (568.4801025390625, 178.11517333984375)
	    reroute_013_2.location = (589.6373291015625, -539.890625)
	    sample_index_003.location = (-781.8150634765625, -108.58781433105469)
	    index_001_2.location = (-979.1199951171875, -89.25547790527344)
	    position_006.location = (-976.2593994140625, -34.26322937011719)
	    group_input_004_2.location = (-982.133056640625, -150.17100524902344)
	    group_001_1.location = (-785.2252197265625, -180.23828125)
	
	    #Set dimensions
	    group_output_11.width, group_output_11.height = 140.0, 100.0
	    group_input_9.width, group_input_9.height = 140.0, 100.0
	    group_3.width, group_3.height = 140.0, 100.0
	    group_004.width, group_004.height = 140.0, 100.0
	    group_005.width, group_005.height = 140.0, 100.0
	    curve_to_mesh.width, curve_to_mesh.height = 140.0, 100.0
	    set_position_001_3.width, set_position_001_3.height = 140.0, 100.0
	    position_002_3.width, position_002_3.height = 140.0, 100.0
	    separate_xyz.width, separate_xyz.height = 140.0, 100.0
	    combine_xyz.width, combine_xyz.height = 140.0, 100.0
	    set_curve_radius.width, set_curve_radius.height = 140.0, 100.0
	    capture_attribute_001_2.width, capture_attribute_001_2.height = 140.0, 100.0
	    capture_attribute_002_1.width, capture_attribute_002_1.height = 140.0, 100.0
	    spline_parameter_2.width, spline_parameter_2.height = 140.0, 100.0
	    store_named_attribute_3.width, store_named_attribute_3.height = 140.0, 100.0
	    combine_xyz_001.width, combine_xyz_001.height = 140.0, 100.0
	    stylized_mesh_shape.width, stylized_mesh_shape.height = 240.0, 100.0
	    spline_parameter_001.width, spline_parameter_001.height = 140.0, 100.0
	    map_range_1.width, map_range_1.height = 140.0, 100.0
	    group_input_001_5.width, group_input_001_5.height = 140.0, 100.0
	    group_input_002_4.width, group_input_002_4.height = 140.0, 100.0
	    group_input_003_3.width, group_input_003_3.height = 140.0, 100.0
	    set_position_002_2.width, set_position_002_2.height = 140.0, 100.0
	    geometry_proximity.width, geometry_proximity.height = 140.0, 100.0
	    object_info_1.width, object_info_1.height = 140.0, 100.0
	    named_attribute_3.width, named_attribute_3.height = 140.0, 100.0
	    separate_xyz_001.width, separate_xyz_001.height = 140.0, 100.0
	    compare_3.width, compare_3.height = 140.0, 100.0
	    delete_geometry_001_1.width, delete_geometry_001_1.height = 140.0, 100.0
	    vertex_neighbors_1.width, vertex_neighbors_1.height = 140.0, 100.0
	    compare_001_3.width, compare_001_3.height = 140.0, 100.0
	    raycast.width, raycast.height = 150.0, 100.0
	    vector_math_001_3.width, vector_math_001_3.height = 140.0, 100.0
	    position_3.width, position_3.height = 140.0, 100.0
	    vector_math_002_1.width, vector_math_002_1.height = 140.0, 100.0
	    compare_003_1.width, compare_003_1.height = 140.0, 100.0
	    merge_by_distance.width, merge_by_distance.height = 140.0, 100.0
	    subdivision_surface.width, subdivision_surface.height = 150.0, 100.0
	    frame_4.width, frame_4.height = 517.0, 443.0
	    geometry_proximity_001.width, geometry_proximity_001.height = 140.0, 100.0
	    reroute_5.width, reroute_5.height = 10.0, 100.0
	    curve_to_mesh_001.width, curve_to_mesh_001.height = 140.0, 100.0
	    reroute_002_2.width, reroute_002_2.height = 10.0, 100.0
	    attribute_statistic_2.width, attribute_statistic_2.height = 140.0, 100.0
	    position_003.width, position_003.height = 140.0, 100.0
	    vector_math_003_1.width, vector_math_003_1.height = 140.0, 100.0
	    sample_index_2.width, sample_index_2.height = 140.0, 100.0
	    reroute_003_1.width, reroute_003_1.height = 10.0, 100.0
	    index_4.width, index_4.height = 140.0, 100.0
	    transform_geometry.width, transform_geometry.height = 140.0, 100.0
	    set_position_003_1.width, set_position_003_1.height = 140.0, 100.0
	    boolean_math_002_1.width, boolean_math_002_1.height = 140.0, 100.0
	    reroute_001_4.width, reroute_001_4.height = 10.0, 100.0
	    reroute_004_3.width, reroute_004_3.height = 10.0, 100.0
	    switch_2.width, switch_2.height = 140.0, 100.0
	    reroute_005_3.width, reroute_005_3.height = 10.0, 100.0
	    reroute_006_3.width, reroute_006_3.height = 10.0, 100.0
	    reroute_007_3.width, reroute_007_3.height = 10.0, 100.0
	    switch_001_4.width, switch_001_4.height = 140.0, 100.0
	    curve_to_mesh_002.width, curve_to_mesh_002.height = 140.0, 100.0
	    geometry_proximity_002.width, geometry_proximity_002.height = 140.0, 100.0
	    position_004.width, position_004.height = 140.0, 100.0
	    vector_math_004_2.width, vector_math_004_2.height = 140.0, 100.0
	    compare_002_4.width, compare_002_4.height = 140.0, 100.0
	    vector_math_005_1.width, vector_math_005_1.height = 140.0, 100.0
	    normal_2.width, normal_2.height = 140.0, 100.0
	    reroute_008_3.width, reroute_008_3.height = 10.0, 100.0
	    reroute_009_2.width, reroute_009_2.height = 10.0, 100.0
	    reroute_010_2.width, reroute_010_2.height = 10.0, 100.0
	    group_input_005_3.width, group_input_005_3.height = 140.0, 100.0
	    group_input_006_2.width, group_input_006_2.height = 140.0, 100.0
	    group_input_007_1.width, group_input_007_1.height = 140.0, 100.0
	    group_input_008_1.width, group_input_008_1.height = 140.0, 100.0
	    convex_hull.width, convex_hull.height = 140.0, 100.0
	    resample_curve_1.width, resample_curve_1.height = 140.0, 100.0
	    group_input_009_1.width, group_input_009_1.height = 140.0, 100.0
	    reroute_011_2.width, reroute_011_2.height = 10.0, 100.0
	    reroute_012_2.width, reroute_012_2.height = 10.0, 100.0
	    reroute_013_2.width, reroute_013_2.height = 10.0, 100.0
	    sample_index_003.width, sample_index_003.height = 140.0, 100.0
	    index_001_2.width, index_001_2.height = 140.0, 100.0
	    position_006.width, position_006.height = 140.0, 100.0
	    group_input_004_2.width, group_input_004_2.height = 140.0, 100.0
	    group_001_1.width, group_001_1.height = 140.0, 100.0
	
	    #initialize mesh_magic links
	    #combine_xyz.Vector -> set_position_001_3.Position
	    mesh_magic.links.new(combine_xyz.outputs[0], set_position_001_3.inputs[2])
	    #position_002_3.Position -> separate_xyz.Vector
	    mesh_magic.links.new(position_002_3.outputs[0], separate_xyz.inputs[0])
	    #capture_attribute_001_2.Geometry -> curve_to_mesh.Curve
	    mesh_magic.links.new(capture_attribute_001_2.outputs[0], curve_to_mesh.inputs[0])
	    #separate_xyz.X -> combine_xyz.X
	    mesh_magic.links.new(separate_xyz.outputs[0], combine_xyz.inputs[0])
	    #group_005.Geometry -> set_curve_radius.Curve
	    mesh_magic.links.new(group_005.outputs[0], set_curve_radius.inputs[0])
	    #separate_xyz.Y -> combine_xyz.Y
	    mesh_magic.links.new(separate_xyz.outputs[1], combine_xyz.inputs[1])
	    #capture_attribute_002_1.Geometry -> curve_to_mesh.Profile Curve
	    mesh_magic.links.new(capture_attribute_002_1.outputs[0], curve_to_mesh.inputs[1])
	    #group_3.Geometry -> group_004.Geometry
	    mesh_magic.links.new(group_3.outputs[0], group_004.inputs[0])
	    #transform_geometry.Geometry -> set_position_001_3.Geometry
	    mesh_magic.links.new(transform_geometry.outputs[0], set_position_001_3.inputs[0])
	    #group_input_9.Geometry -> group_005.Geometry
	    mesh_magic.links.new(group_input_9.outputs[0], group_005.inputs[0])
	    #reroute_010_2.Output -> capture_attribute_001_2.Geometry
	    mesh_magic.links.new(reroute_010_2.outputs[0], capture_attribute_001_2.inputs[0])
	    #spline_parameter_2.Factor -> capture_attribute_001_2.Factor
	    mesh_magic.links.new(spline_parameter_2.outputs[0], capture_attribute_001_2.inputs[1])
	    #spline_parameter_2.Factor -> capture_attribute_002_1.Factor
	    mesh_magic.links.new(spline_parameter_2.outputs[0], capture_attribute_002_1.inputs[1])
	    #curve_to_mesh.Mesh -> store_named_attribute_3.Geometry
	    mesh_magic.links.new(curve_to_mesh.outputs[0], store_named_attribute_3.inputs[0])
	    #combine_xyz_001.Vector -> store_named_attribute_3.Value
	    mesh_magic.links.new(combine_xyz_001.outputs[0], store_named_attribute_3.inputs[3])
	    #capture_attribute_001_2.Factor -> combine_xyz_001.X
	    mesh_magic.links.new(capture_attribute_001_2.outputs[1], combine_xyz_001.inputs[0])
	    #capture_attribute_002_1.Factor -> combine_xyz_001.Y
	    mesh_magic.links.new(capture_attribute_002_1.outputs[1], combine_xyz_001.inputs[1])
	    #spline_parameter_001.Factor -> stylized_mesh_shape.Value
	    mesh_magic.links.new(spline_parameter_001.outputs[0], stylized_mesh_shape.inputs[1])
	    #stylized_mesh_shape.Value -> map_range_1.Value
	    mesh_magic.links.new(stylized_mesh_shape.outputs[0], map_range_1.inputs[0])
	    #map_range_1.Result -> set_curve_radius.Radius
	    mesh_magic.links.new(map_range_1.outputs[0], set_curve_radius.inputs[2])
	    #group_input_001_5.Radius -> map_range_1.To Max
	    mesh_magic.links.new(group_input_001_5.outputs[2], map_range_1.inputs[4])
	    #group_input_002_4.Surface -> group_004.Surface
	    mesh_magic.links.new(group_input_002_4.outputs[1], group_004.inputs[1])
	    #store_named_attribute_3.Geometry -> set_position_002_2.Geometry
	    mesh_magic.links.new(store_named_attribute_3.outputs[0], set_position_002_2.inputs[0])
	    #group_input_003_3.Surface -> object_info_1.Object
	    mesh_magic.links.new(group_input_003_3.outputs[1], object_info_1.inputs[0])
	    #object_info_1.Geometry -> geometry_proximity.Geometry
	    mesh_magic.links.new(object_info_1.outputs[4], geometry_proximity.inputs[0])
	    #named_attribute_3.Attribute -> separate_xyz_001.Vector
	    mesh_magic.links.new(named_attribute_3.outputs[0], separate_xyz_001.inputs[0])
	    #separate_xyz_001.X -> compare_3.A
	    mesh_magic.links.new(separate_xyz_001.outputs[0], compare_3.inputs[0])
	    #vertex_neighbors_1.Face Count -> compare_001_3.A
	    mesh_magic.links.new(vertex_neighbors_1.outputs[1], compare_001_3.inputs[2])
	    #compare_001_3.Result -> delete_geometry_001_1.Selection
	    mesh_magic.links.new(compare_001_3.outputs[0], delete_geometry_001_1.inputs[1])
	    #object_info_1.Geometry -> raycast.Target Geometry
	    mesh_magic.links.new(object_info_1.outputs[4], raycast.inputs[0])
	    #geometry_proximity.Position -> vector_math_001_3.Vector
	    mesh_magic.links.new(geometry_proximity.outputs[0], vector_math_001_3.inputs[0])
	    #position_3.Position -> vector_math_001_3.Vector
	    mesh_magic.links.new(position_3.outputs[0], vector_math_001_3.inputs[1])
	    #vector_math_001_3.Vector -> vector_math_002_1.Vector
	    mesh_magic.links.new(vector_math_001_3.outputs[0], vector_math_002_1.inputs[0])
	    #vector_math_002_1.Vector -> raycast.Ray Direction
	    mesh_magic.links.new(vector_math_002_1.outputs[0], raycast.inputs[3])
	    #vector_math_002_1.Vector -> compare_003_1.A
	    mesh_magic.links.new(vector_math_002_1.outputs[0], compare_003_1.inputs[4])
	    #raycast.Hit Normal -> compare_003_1.B
	    mesh_magic.links.new(raycast.outputs[2], compare_003_1.inputs[5])
	    #reroute_5.Output -> set_position_002_2.Position
	    mesh_magic.links.new(reroute_5.outputs[0], set_position_002_2.inputs[2])
	    #curve_to_mesh_001.Mesh -> geometry_proximity_001.Geometry
	    mesh_magic.links.new(curve_to_mesh_001.outputs[0], geometry_proximity_001.inputs[0])
	    #group_004.Geometry -> curve_to_mesh_001.Curve
	    mesh_magic.links.new(group_004.outputs[0], curve_to_mesh_001.inputs[0])
	    #reroute_004_3.Output -> reroute_002_2.Input
	    mesh_magic.links.new(reroute_004_3.outputs[0], reroute_002_2.inputs[0])
	    #reroute_002_2.Output -> reroute_5.Input
	    mesh_magic.links.new(reroute_002_2.outputs[0], reroute_5.inputs[0])
	    #reroute_003_1.Output -> attribute_statistic_2.Geometry
	    mesh_magic.links.new(reroute_003_1.outputs[0], attribute_statistic_2.inputs[0])
	    #attribute_statistic_2.Mean -> vector_math_003_1.Vector
	    mesh_magic.links.new(attribute_statistic_2.outputs[0], vector_math_003_1.inputs[0])
	    #group_004.Geometry -> reroute_003_1.Input
	    mesh_magic.links.new(group_004.outputs[0], reroute_003_1.inputs[0])
	    #reroute_003_1.Output -> sample_index_2.Geometry
	    mesh_magic.links.new(reroute_003_1.outputs[0], sample_index_2.inputs[0])
	    #index_4.Index -> sample_index_2.Index
	    mesh_magic.links.new(index_4.outputs[0], sample_index_2.inputs[2])
	    #position_003.Position -> sample_index_2.Value
	    mesh_magic.links.new(position_003.outputs[0], sample_index_2.inputs[1])
	    #sample_index_2.Value -> attribute_statistic_2.Attribute
	    mesh_magic.links.new(sample_index_2.outputs[0], attribute_statistic_2.inputs[2])
	    #group_004.Geometry -> transform_geometry.Geometry
	    mesh_magic.links.new(group_004.outputs[0], transform_geometry.inputs[0])
	    #vector_math_003_1.Vector -> transform_geometry.Translation
	    mesh_magic.links.new(vector_math_003_1.outputs[0], transform_geometry.inputs[1])
	    #compare_3.Result -> set_position_002_2.Selection
	    mesh_magic.links.new(compare_3.outputs[0], set_position_002_2.inputs[1])
	    #set_position_002_2.Geometry -> set_position_003_1.Geometry
	    mesh_magic.links.new(set_position_002_2.outputs[0], set_position_003_1.inputs[0])
	    #raycast.Hit Position -> set_position_003_1.Position
	    mesh_magic.links.new(raycast.outputs[1], set_position_003_1.inputs[2])
	    #compare_003_1.Result -> boolean_math_002_1.Boolean
	    mesh_magic.links.new(compare_003_1.outputs[0], boolean_math_002_1.inputs[1])
	    #compare_3.Result -> boolean_math_002_1.Boolean
	    mesh_magic.links.new(compare_3.outputs[0], boolean_math_002_1.inputs[0])
	    #boolean_math_002_1.Boolean -> set_position_003_1.Selection
	    mesh_magic.links.new(boolean_math_002_1.outputs[0], set_position_003_1.inputs[1])
	    #geometry_proximity_001.Position -> reroute_001_4.Input
	    mesh_magic.links.new(geometry_proximity_001.outputs[0], reroute_001_4.inputs[0])
	    #reroute_001_4.Output -> reroute_004_3.Input
	    mesh_magic.links.new(reroute_001_4.outputs[0], reroute_004_3.inputs[0])
	    #reroute_007_3.Output -> switch_2.True
	    mesh_magic.links.new(reroute_007_3.outputs[0], switch_2.inputs[2])
	    #reroute_005_3.Output -> switch_2.False
	    mesh_magic.links.new(reroute_005_3.outputs[0], switch_2.inputs[1])
	    #switch_2.Output -> group_output_11.Geometry
	    mesh_magic.links.new(switch_2.outputs[0], group_output_11.inputs[0])
	    #delete_geometry_001_1.Geometry -> reroute_005_3.Input
	    mesh_magic.links.new(delete_geometry_001_1.outputs[0], reroute_005_3.inputs[0])
	    #reroute_006_3.Output -> reroute_007_3.Input
	    mesh_magic.links.new(reroute_006_3.outputs[0], reroute_007_3.inputs[0])
	    #set_position_003_1.Geometry -> switch_001_4.True
	    mesh_magic.links.new(set_position_003_1.outputs[0], switch_001_4.inputs[2])
	    #set_position_002_2.Geometry -> switch_001_4.False
	    mesh_magic.links.new(set_position_002_2.outputs[0], switch_001_4.inputs[1])
	    #switch_001_4.Output -> delete_geometry_001_1.Geometry
	    mesh_magic.links.new(switch_001_4.outputs[0], delete_geometry_001_1.inputs[0])
	    #curve_to_mesh_002.Mesh -> geometry_proximity_002.Geometry
	    mesh_magic.links.new(curve_to_mesh_002.outputs[0], geometry_proximity_002.inputs[0])
	    #geometry_proximity_002.Position -> vector_math_004_2.Vector
	    mesh_magic.links.new(geometry_proximity_002.outputs[0], vector_math_004_2.inputs[0])
	    #vector_math_005_1.Vector -> compare_002_4.A
	    mesh_magic.links.new(vector_math_005_1.outputs[0], compare_002_4.inputs[4])
	    #subdivision_surface.Mesh -> merge_by_distance.Geometry
	    mesh_magic.links.new(subdivision_surface.outputs[0], merge_by_distance.inputs[0])
	    #merge_by_distance.Geometry -> reroute_006_3.Input
	    mesh_magic.links.new(merge_by_distance.outputs[0], reroute_006_3.inputs[0])
	    #reroute_008_3.Output -> subdivision_surface.Mesh
	    mesh_magic.links.new(reroute_008_3.outputs[0], subdivision_surface.inputs[0])
	    #position_004.Position -> vector_math_004_2.Vector
	    mesh_magic.links.new(position_004.outputs[0], vector_math_004_2.inputs[1])
	    #vector_math_004_2.Vector -> vector_math_005_1.Vector
	    mesh_magic.links.new(vector_math_004_2.outputs[0], vector_math_005_1.inputs[0])
	    #normal_2.Normal -> compare_002_4.B
	    mesh_magic.links.new(normal_2.outputs[0], compare_002_4.inputs[5])
	    #compare_002_4.Result -> merge_by_distance.Selection
	    mesh_magic.links.new(compare_002_4.outputs[0], merge_by_distance.inputs[1])
	    #reroute_005_3.Output -> reroute_008_3.Input
	    mesh_magic.links.new(reroute_005_3.outputs[0], reroute_008_3.inputs[0])
	    #set_curve_radius.Curve -> reroute_009_2.Input
	    mesh_magic.links.new(set_curve_radius.outputs[0], reroute_009_2.inputs[0])
	    #reroute_009_2.Output -> reroute_010_2.Input
	    mesh_magic.links.new(reroute_009_2.outputs[0], reroute_010_2.inputs[0])
	    #group_input_006_2.Snap to surface -> switch_001_4.Switch
	    mesh_magic.links.new(group_input_006_2.outputs[6], switch_001_4.inputs[0])
	    #group_input_007_1.Use Enhancements -> switch_2.Switch
	    mesh_magic.links.new(group_input_007_1.outputs[3], switch_2.inputs[0])
	    #group_input_005_3.Level -> subdivision_surface.Level
	    mesh_magic.links.new(group_input_005_3.outputs[7], subdivision_surface.inputs[1])
	    #group_input_005_3.Edge Crease -> subdivision_surface.Edge Crease
	    mesh_magic.links.new(group_input_005_3.outputs[8], subdivision_surface.inputs[2])
	    #group_input_005_3.Vertex Crease -> subdivision_surface.Vertex Crease
	    mesh_magic.links.new(group_input_005_3.outputs[9], subdivision_surface.inputs[3])
	    #group_input_005_3.Limit Surface -> subdivision_surface.Limit Surface
	    mesh_magic.links.new(group_input_005_3.outputs[10], subdivision_surface.inputs[4])
	    #group_input_008_1.Distance -> merge_by_distance.Distance
	    mesh_magic.links.new(group_input_008_1.outputs[11], merge_by_distance.inputs[2])
	    #resample_curve_1.Curve -> convex_hull.Geometry
	    mesh_magic.links.new(resample_curve_1.outputs[0], convex_hull.inputs[0])
	    #group_input_009_1.Geometry -> resample_curve_1.Curve
	    mesh_magic.links.new(group_input_009_1.outputs[0], resample_curve_1.inputs[0])
	    #convex_hull.Convex Hull -> group_3.Geometry
	    mesh_magic.links.new(convex_hull.outputs[0], group_3.inputs[0])
	    #reroute_011_2.Output -> reroute_012_2.Input
	    mesh_magic.links.new(reroute_011_2.outputs[0], reroute_012_2.inputs[0])
	    #reroute_013_2.Output -> curve_to_mesh_002.Curve
	    mesh_magic.links.new(reroute_013_2.outputs[0], curve_to_mesh_002.inputs[0])
	    #reroute_012_2.Output -> reroute_013_2.Input
	    mesh_magic.links.new(reroute_012_2.outputs[0], reroute_013_2.inputs[0])
	    #transform_geometry.Geometry -> sample_index_003.Geometry
	    mesh_magic.links.new(transform_geometry.outputs[0], sample_index_003.inputs[0])
	    #index_001_2.Index -> sample_index_003.Index
	    mesh_magic.links.new(index_001_2.outputs[0], sample_index_003.inputs[2])
	    #position_006.Position -> sample_index_003.Value
	    mesh_magic.links.new(position_006.outputs[0], sample_index_003.inputs[1])
	    #reroute_009_2.Output -> reroute_011_2.Input
	    mesh_magic.links.new(reroute_009_2.outputs[0], reroute_011_2.inputs[0])
	    #sample_index_003.Value -> group_001_1.Reference Position
	    mesh_magic.links.new(sample_index_003.outputs[0], group_001_1.inputs[3])
	    #group_input_004_2.Maintain Shape Factor -> group_001_1.Factor
	    mesh_magic.links.new(group_input_004_2.outputs[4], group_001_1.inputs[2])
	    #group_input_004_2.Pin at Parameter -> group_001_1.Pin at Parameter
	    mesh_magic.links.new(group_input_004_2.outputs[5], group_001_1.inputs[4])
	    #set_position_001_3.Geometry -> group_001_1.Curves
	    mesh_magic.links.new(set_position_001_3.outputs[0], group_001_1.inputs[0])
	    #group_001_1.Curves -> capture_attribute_002_1.Geometry
	    mesh_magic.links.new(group_001_1.outputs[0], capture_attribute_002_1.inputs[0])
	    return mesh_magic
	
	mesh_magic = mesh_magic_node_group()
	
	#initialize stylized_meshify_hair node group
	def stylized_meshify_hair_node_group():
	    stylized_meshify_hair = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "STYLIZED_MESHIFY_HAIR")
	
	    stylized_meshify_hair.color_tag = 'NONE'
	    stylized_meshify_hair.description = "Convert muiltiguided curves to stylized mesh."
	    stylized_meshify_hair.default_group_node_width = 140
	    
	
	    stylized_meshify_hair.is_modifier = True
	
	    #stylized_meshify_hair interface
	    #Socket Geometry
	    geometry_socket_17 = stylized_meshify_hair.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_17.attribute_domain = 'POINT'
	    geometry_socket_17.description = "Stylized mesh hair."
	
	    #Socket Geometry
	    geometry_socket_18 = stylized_meshify_hair.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_18.attribute_domain = 'POINT'
	    geometry_socket_18.description = "Multiguided curves."
	
	    #Socket Surface
	    surface_socket_5 = stylized_meshify_hair.interface.new_socket(name = "Surface", in_out='INPUT', socket_type = 'NodeSocketObject')
	    surface_socket_5.attribute_domain = 'POINT'
	    surface_socket_5.description = "Surface attached to hair."
	
	    #Socket Material
	    material_socket = stylized_meshify_hair.interface.new_socket(name = "Material", in_out='INPUT', socket_type = 'NodeSocketMaterial')
	    material_socket.attribute_domain = 'POINT'
	    material_socket.description = "Mesh Material."
	
	    #Socket Control Points
	    control_points_socket = stylized_meshify_hair.interface.new_socket(name = "Control Points", in_out='INPUT', socket_type = 'NodeSocketInt')
	    control_points_socket.default_value = 10
	    control_points_socket.min_value = 2
	    control_points_socket.max_value = 100000
	    control_points_socket.subtype = 'NONE'
	    control_points_socket.attribute_domain = 'POINT'
	    control_points_socket.description = "Amount of points to resample the curves. (Amount < 2  means no resampling)"
	
	    #Socket Radius
	    radius_socket_1 = stylized_meshify_hair.interface.new_socket(name = "Radius", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    radius_socket_1.default_value = 1.0
	    radius_socket_1.min_value = 0.0
	    radius_socket_1.max_value = 3.4028234663852886e+38
	    radius_socket_1.subtype = 'DISTANCE'
	    radius_socket_1.attribute_domain = 'POINT'
	    radius_socket_1.description = "Mesh Radius."
	
	    #Panel Enhancement Settings
	    enhancement_settings_panel_1 = stylized_meshify_hair.interface.new_panel("Enhancement Settings", default_closed=True)
	    enhancement_settings_panel_1.description = "Settings for mesh enhancements."
	    #Socket Use Enhancements
	    use_enhancements_socket_1 = stylized_meshify_hair.interface.new_socket(name = "Use Enhancements", in_out='INPUT', socket_type = 'NodeSocketBool', parent = enhancement_settings_panel_1)
	    use_enhancements_socket_1.default_value = True
	    use_enhancements_socket_1.attribute_domain = 'POINT'
	    use_enhancements_socket_1.description = "Use Enhancement settings."
	
	    #Socket Maintain Shape Factor
	    maintain_shape_factor_socket_1 = stylized_meshify_hair.interface.new_socket(name = "Maintain Shape Factor", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = enhancement_settings_panel_1)
	    maintain_shape_factor_socket_1.default_value = 1.0
	    maintain_shape_factor_socket_1.min_value = 0.0
	    maintain_shape_factor_socket_1.max_value = 1.0
	    maintain_shape_factor_socket_1.subtype = 'FACTOR'
	    maintain_shape_factor_socket_1.attribute_domain = 'POINT'
	    maintain_shape_factor_socket_1.description = "Factor to blend overall effect"
	
	    #Socket Pin at Parameter
	    pin_at_parameter_socket_2 = stylized_meshify_hair.interface.new_socket(name = "Pin at Parameter", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = enhancement_settings_panel_1)
	    pin_at_parameter_socket_2.default_value = 0.0
	    pin_at_parameter_socket_2.min_value = 0.0
	    pin_at_parameter_socket_2.max_value = 1.0
	    pin_at_parameter_socket_2.subtype = 'FACTOR'
	    pin_at_parameter_socket_2.attribute_domain = 'POINT'
	    pin_at_parameter_socket_2.description = "Pin each curve at a certain point for the operation"
	
	    #Socket Snap to surface
	    snap_to_surface_socket_2 = stylized_meshify_hair.interface.new_socket(name = "Snap to surface", in_out='INPUT', socket_type = 'NodeSocketBool', parent = enhancement_settings_panel_1)
	    snap_to_surface_socket_2.default_value = False
	    snap_to_surface_socket_2.attribute_domain = 'POINT'
	    snap_to_surface_socket_2.description = "Snap mesh roots to the nearest surface point."
	
	    #Panel Subdivision Settings
	    subdivision_settings_panel_1 = stylized_meshify_hair.interface.new_panel("Subdivision Settings", default_closed=True)
	    subdivision_settings_panel_1.description = "Settings for mesh subdivision."
	    #Socket Subdivison Level
	    subdivison_level_socket = stylized_meshify_hair.interface.new_socket(name = "Subdivison Level", in_out='INPUT', socket_type = 'NodeSocketInt', parent = subdivision_settings_panel_1)
	    subdivison_level_socket.default_value = 1
	    subdivison_level_socket.min_value = 0
	    subdivison_level_socket.max_value = 6
	    subdivison_level_socket.subtype = 'NONE'
	    subdivison_level_socket.attribute_domain = 'POINT'
	    subdivison_level_socket.description = "Subdivision level."
	
	    #Socket Edge Crease
	    edge_crease_socket_1 = stylized_meshify_hair.interface.new_socket(name = "Edge Crease", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = subdivision_settings_panel_1)
	    edge_crease_socket_1.default_value = 0.0
	    edge_crease_socket_1.min_value = 0.0
	    edge_crease_socket_1.max_value = 1.0
	    edge_crease_socket_1.subtype = 'FACTOR'
	    edge_crease_socket_1.attribute_domain = 'POINT'
	    edge_crease_socket_1.description = "Edge crease factor for subdivision."
	
	    #Socket Vertex Crease
	    vertex_crease_socket_1 = stylized_meshify_hair.interface.new_socket(name = "Vertex Crease", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = subdivision_settings_panel_1)
	    vertex_crease_socket_1.default_value = 0.0
	    vertex_crease_socket_1.min_value = 0.0
	    vertex_crease_socket_1.max_value = 1.0
	    vertex_crease_socket_1.subtype = 'FACTOR'
	    vertex_crease_socket_1.attribute_domain = 'POINT'
	    vertex_crease_socket_1.description = "Vertex crease factor for subdivision."
	
	    #Socket Limit Surface
	    limit_surface_socket_1 = stylized_meshify_hair.interface.new_socket(name = "Limit Surface", in_out='INPUT', socket_type = 'NodeSocketBool', parent = subdivision_settings_panel_1)
	    limit_surface_socket_1.default_value = True
	    limit_surface_socket_1.attribute_domain = 'POINT'
	    limit_surface_socket_1.description = "Limit subdivision on surface."
	
	
	    stylized_meshify_hair.interface.move_to_parent(subdivision_settings_panel_1, enhancement_settings_panel_1, 11)
	    #Panel Merge Settings
	    merge_settings_panel_1 = stylized_meshify_hair.interface.new_panel("Merge Settings", default_closed=True)
	    merge_settings_panel_1.description = "Settings for merging points."
	    #Socket Distance
	    distance_socket_1 = stylized_meshify_hair.interface.new_socket(name = "Distance", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = merge_settings_panel_1)
	    distance_socket_1.default_value = 0.0010000000474974513
	    distance_socket_1.min_value = 0.0
	    distance_socket_1.max_value = 3.4028234663852886e+38
	    distance_socket_1.subtype = 'DISTANCE'
	    distance_socket_1.attribute_domain = 'POINT'
	    distance_socket_1.description = "Distance threshold to merge points."
	
	
	    stylized_meshify_hair.interface.move_to_parent(merge_settings_panel_1, enhancement_settings_panel_1, 16)
	
	
	    #initialize stylized_meshify_hair nodes
	    #node Group Input
	    group_input_10 = stylized_meshify_hair.nodes.new("NodeGroupInput")
	    group_input_10.name = "Group Input"
	    group_input_10.outputs[1].hide = True
	    group_input_10.outputs[2].hide = True
	    group_input_10.outputs[3].hide = True
	    group_input_10.outputs[4].hide = True
	    group_input_10.outputs[5].hide = True
	    group_input_10.outputs[6].hide = True
	    group_input_10.outputs[7].hide = True
	    group_input_10.outputs[8].hide = True
	    group_input_10.outputs[9].hide = True
	    group_input_10.outputs[10].hide = True
	    group_input_10.outputs[11].hide = True
	    group_input_10.outputs[12].hide = True
	    group_input_10.outputs[13].hide = True
	    group_input_10.outputs[14].hide = True
	
	    #node Group Output
	    group_output_12 = stylized_meshify_hair.nodes.new("NodeGroupOutput")
	    group_output_12.name = "Group Output"
	    group_output_12.is_active_output = True
	    group_output_12.inputs[1].hide = True
	
	    #node Named Attribute
	    named_attribute_4 = stylized_meshify_hair.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute_4.name = "Named Attribute"
	    named_attribute_4.data_type = 'INT'
	    #Name
	    named_attribute_4.inputs[0].default_value = "closest_idx"
	
	    #node Compare
	    compare_4 = stylized_meshify_hair.nodes.new("FunctionNodeCompare")
	    compare_4.name = "Compare"
	    compare_4.hide = True
	    compare_4.data_type = 'INT'
	    compare_4.mode = 'ELEMENT'
	    compare_4.operation = 'EQUAL'
	
	    #node Separate Geometry
	    separate_geometry = stylized_meshify_hair.nodes.new("GeometryNodeSeparateGeometry")
	    separate_geometry.name = "Separate Geometry"
	    separate_geometry.domain = 'CURVE'
	    separate_geometry.outputs[1].hide = True
	
	    #node Attribute Statistic.001
	    attribute_statistic_001 = stylized_meshify_hair.nodes.new("GeometryNodeAttributeStatistic")
	    attribute_statistic_001.name = "Attribute Statistic.001"
	    attribute_statistic_001.hide = True
	    attribute_statistic_001.data_type = 'FLOAT'
	    attribute_statistic_001.domain = 'CURVE'
	    attribute_statistic_001.inputs[1].hide = True
	    attribute_statistic_001.outputs[0].hide = True
	    attribute_statistic_001.outputs[1].hide = True
	    attribute_statistic_001.outputs[2].hide = True
	    attribute_statistic_001.outputs[3].hide = True
	    attribute_statistic_001.outputs[5].hide = True
	    attribute_statistic_001.outputs[6].hide = True
	    attribute_statistic_001.outputs[7].hide = True
	    #Selection
	    attribute_statistic_001.inputs[1].default_value = True
	
	    #node Repeat Input
	    repeat_input_1 = stylized_meshify_hair.nodes.new("GeometryNodeRepeatInput")
	    repeat_input_1.name = "Repeat Input"
	    #node Repeat Output
	    repeat_output_1 = stylized_meshify_hair.nodes.new("GeometryNodeRepeatOutput")
	    repeat_output_1.name = "Repeat Output"
	    repeat_output_1.active_index = 1
	    repeat_output_1.inspection_index = 0
	    repeat_output_1.repeat_items.clear()
	    # Create item "Geometry"
	    repeat_output_1.repeat_items.new('GEOMETRY', "Geometry")
	    # Create item "Index"
	    repeat_output_1.repeat_items.new('INT', "Index")
	
	    #node Join Geometry.001
	    join_geometry_001 = stylized_meshify_hair.nodes.new("GeometryNodeJoinGeometry")
	    join_geometry_001.name = "Join Geometry.001"
	    join_geometry_001.hide = True
	
	    #node Math
	    math_3 = stylized_meshify_hair.nodes.new("ShaderNodeMath")
	    math_3.name = "Math"
	    math_3.hide = True
	    math_3.operation = 'ADD'
	    math_3.use_clamp = False
	    #Value_001
	    math_3.inputs[1].default_value = 1.0
	
	    #node Math.001
	    math_001_1 = stylized_meshify_hair.nodes.new("ShaderNodeMath")
	    math_001_1.name = "Math.001"
	    math_001_1.hide = True
	    math_001_1.operation = 'ADD'
	    math_001_1.use_clamp = False
	    #Value_001
	    math_001_1.inputs[1].default_value = 1.0
	
	    #node Named Attribute.003
	    named_attribute_003_1 = stylized_meshify_hair.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute_003_1.name = "Named Attribute.003"
	    named_attribute_003_1.data_type = 'INT'
	    #Name
	    named_attribute_003_1.inputs[0].default_value = "closest_idx"
	
	    #node Reroute.001
	    reroute_001_5 = stylized_meshify_hair.nodes.new("NodeReroute")
	    reroute_001_5.name = "Reroute.001"
	    reroute_001_5.socket_idname = "NodeSocketGeometry"
	    #node Reroute.002
	    reroute_002_3 = stylized_meshify_hair.nodes.new("NodeReroute")
	    reroute_002_3.name = "Reroute.002"
	    reroute_002_3.socket_idname = "NodeSocketGeometry"
	    #node Set Material
	    set_material = stylized_meshify_hair.nodes.new("GeometryNodeSetMaterial")
	    set_material.name = "Set Material"
	    set_material.inputs[1].hide = True
	    #Selection
	    set_material.inputs[1].default_value = True
	
	    #node Group Input.008
	    group_input_008_2 = stylized_meshify_hair.nodes.new("NodeGroupInput")
	    group_input_008_2.name = "Group Input.008"
	    group_input_008_2.outputs[0].hide = True
	    group_input_008_2.outputs[1].hide = True
	    group_input_008_2.outputs[3].hide = True
	    group_input_008_2.outputs[4].hide = True
	    group_input_008_2.outputs[5].hide = True
	    group_input_008_2.outputs[6].hide = True
	    group_input_008_2.outputs[7].hide = True
	    group_input_008_2.outputs[8].hide = True
	    group_input_008_2.outputs[9].hide = True
	    group_input_008_2.outputs[10].hide = True
	    group_input_008_2.outputs[11].hide = True
	    group_input_008_2.outputs[12].hide = True
	    group_input_008_2.outputs[13].hide = True
	    group_input_008_2.outputs[14].hide = True
	
	    #node Group Input.010
	    group_input_010 = stylized_meshify_hair.nodes.new("NodeGroupInput")
	    group_input_010.name = "Group Input.010"
	    group_input_010.outputs[0].hide = True
	    group_input_010.outputs[1].hide = True
	    group_input_010.outputs[2].hide = True
	    group_input_010.outputs[3].hide = True
	    group_input_010.outputs[14].hide = True
	
	    #node Group Input.005
	    group_input_005_4 = stylized_meshify_hair.nodes.new("NodeGroupInput")
	    group_input_005_4.name = "Group Input.005"
	    group_input_005_4.outputs[0].hide = True
	    group_input_005_4.outputs[2].hide = True
	    group_input_005_4.outputs[3].hide = True
	    group_input_005_4.outputs[4].hide = True
	    group_input_005_4.outputs[5].hide = True
	    group_input_005_4.outputs[6].hide = True
	    group_input_005_4.outputs[7].hide = True
	    group_input_005_4.outputs[8].hide = True
	    group_input_005_4.outputs[9].hide = True
	    group_input_005_4.outputs[10].hide = True
	    group_input_005_4.outputs[11].hide = True
	    group_input_005_4.outputs[12].hide = True
	    group_input_005_4.outputs[13].hide = True
	    group_input_005_4.outputs[14].hide = True
	
	    #node Reroute.010
	    reroute_010_3 = stylized_meshify_hair.nodes.new("NodeReroute")
	    reroute_010_3.name = "Reroute.010"
	    reroute_010_3.socket_idname = "NodeSocketGeometry"
	    #node Group.007
	    group_007 = stylized_meshify_hair.nodes.new("GeometryNodeGroup")
	    group_007.name = "Group.007"
	    group_007.node_tree = mesh_magic
	
	    #node Stylized Mesh Bake
	    stylized_mesh_bake = stylized_meshify_hair.nodes.new("GeometryNodeBake")
	    stylized_mesh_bake.label = "Stylized Mesh Bake"
	    stylized_mesh_bake.name = "Stylized Mesh Bake"
	    stylized_mesh_bake.active_index = 0
	    stylized_mesh_bake.bake_items.clear()
	    stylized_mesh_bake.bake_items.new('GEOMETRY', "Geometry")
	    stylized_mesh_bake.bake_items[0].attribute_domain = 'POINT'
	    stylized_mesh_bake.inputs[1].hide = True
	    stylized_mesh_bake.outputs[1].hide = True
	
	    #node Resample Curve.001
	    resample_curve_001 = stylized_meshify_hair.nodes.new("GeometryNodeResampleCurve")
	    resample_curve_001.name = "Resample Curve.001"
	    resample_curve_001.hide = True
	    resample_curve_001.keep_last_segment = True
	    resample_curve_001.mode = 'COUNT'
	    resample_curve_001.inputs[1].hide = True
	    resample_curve_001.inputs[3].hide = True
	    #Selection
	    resample_curve_001.inputs[1].default_value = True
	
	    #node Group Input.001
	    group_input_001_6 = stylized_meshify_hair.nodes.new("NodeGroupInput")
	    group_input_001_6.name = "Group Input.001"
	    group_input_001_6.outputs[0].hide = True
	    group_input_001_6.outputs[1].hide = True
	    group_input_001_6.outputs[2].hide = True
	    group_input_001_6.outputs[4].hide = True
	    group_input_001_6.outputs[5].hide = True
	    group_input_001_6.outputs[6].hide = True
	    group_input_001_6.outputs[7].hide = True
	    group_input_001_6.outputs[8].hide = True
	    group_input_001_6.outputs[9].hide = True
	    group_input_001_6.outputs[10].hide = True
	    group_input_001_6.outputs[11].hide = True
	    group_input_001_6.outputs[12].hide = True
	    group_input_001_6.outputs[13].hide = True
	    group_input_001_6.outputs[14].hide = True
	
	    #node Switch
	    switch_3 = stylized_meshify_hair.nodes.new("GeometryNodeSwitch")
	    switch_3.name = "Switch"
	    switch_3.hide = True
	    switch_3.input_type = 'GEOMETRY'
	
	    #node Compare.001
	    compare_001_4 = stylized_meshify_hair.nodes.new("FunctionNodeCompare")
	    compare_001_4.name = "Compare.001"
	    compare_001_4.hide = True
	    compare_001_4.data_type = 'INT'
	    compare_001_4.mode = 'ELEMENT'
	    compare_001_4.operation = 'GREATER_EQUAL'
	    compare_001_4.inputs[0].hide = True
	    compare_001_4.inputs[1].hide = True
	    compare_001_4.inputs[3].hide = True
	    compare_001_4.inputs[4].hide = True
	    compare_001_4.inputs[5].hide = True
	    compare_001_4.inputs[6].hide = True
	    compare_001_4.inputs[7].hide = True
	    compare_001_4.inputs[8].hide = True
	    compare_001_4.inputs[9].hide = True
	    compare_001_4.inputs[10].hide = True
	    compare_001_4.inputs[11].hide = True
	    compare_001_4.inputs[12].hide = True
	    #B_INT
	    compare_001_4.inputs[3].default_value = 2
	
	
	    #Process zone input Repeat Input
	    repeat_input_1.pair_with_output(repeat_output_1)
	    #Item_2
	    repeat_input_1.inputs[2].default_value = 0
	
	
	
	
	
	    #Set locations
	    group_input_10.location = (-340.0, 0.0)
	    group_output_12.location = (1549.6400146484375, -34.82880401611328)
	    named_attribute_4.location = (237.794921875, -204.86949157714844)
	    compare_4.location = (237.99490356445312, -171.7650146484375)
	    separate_geometry.location = (434.56829833984375, -276.72552490234375)
	    attribute_statistic_001.location = (-71.79378509521484, -31.660974502563477)
	    repeat_input_1.location = (99.01121520996094, -41.19667053222656)
	    repeat_output_1.location = (1002.779296875, -61.759864807128906)
	    join_geometry_001.location = (823.139892578125, -84.95603942871094)
	    math_3.location = (834.5255126953125, -123.60336303710938)
	    math_001_1.location = (-73.19247436523438, -64.9359130859375)
	    named_attribute_003_1.location = (-71.07884216308594, 117.17273712158203)
	    reroute_001_5.location = (-154.91433715820312, -33.560951232910156)
	    reroute_002_3.location = (-149.08628845214844, -411.6916198730469)
	    set_material.location = (1374.4747314453125, -35.82680130004883)
	    group_input_008_2.location = (1367.4078369140625, -138.275390625)
	    group_input_010.location = (433.3647766113281, -466.8764953613281)
	    group_input_005_4.location = (431.66448974609375, -405.8486022949219)
	    reroute_010_3.location = (823.3209228515625, -266.45831298828125)
	    group_007.location = (646.2728881835938, -232.4287109375)
	    stylized_mesh_bake.location = (1187.839111328125, -13.576586723327637)
	    resample_curve_001.location = (-90.34358215332031, -409.5655517578125)
	    group_input_001_6.location = (-86.76141357421875, -258.945556640625)
	    switch_3.location = (-86.4659423828125, -359.3800048828125)
	    compare_001_4.location = (-88.06952667236328, -323.3353271484375)
	
	    #Set dimensions
	    group_input_10.width, group_input_10.height = 140.0, 100.0
	    group_output_12.width, group_output_12.height = 140.0, 100.0
	    named_attribute_4.width, named_attribute_4.height = 140.0, 100.0
	    compare_4.width, compare_4.height = 140.0, 100.0
	    separate_geometry.width, separate_geometry.height = 140.0, 100.0
	    attribute_statistic_001.width, attribute_statistic_001.height = 140.0, 100.0
	    repeat_input_1.width, repeat_input_1.height = 140.0, 100.0
	    repeat_output_1.width, repeat_output_1.height = 140.0, 100.0
	    join_geometry_001.width, join_geometry_001.height = 140.0, 100.0
	    math_3.width, math_3.height = 140.0, 100.0
	    math_001_1.width, math_001_1.height = 140.0, 100.0
	    named_attribute_003_1.width, named_attribute_003_1.height = 140.0, 100.0
	    reroute_001_5.width, reroute_001_5.height = 10.0, 100.0
	    reroute_002_3.width, reroute_002_3.height = 10.0, 100.0
	    set_material.width, set_material.height = 140.0, 100.0
	    group_input_008_2.width, group_input_008_2.height = 140.0, 100.0
	    group_input_010.width, group_input_010.height = 140.0, 100.0
	    group_input_005_4.width, group_input_005_4.height = 140.0, 100.0
	    reroute_010_3.width, reroute_010_3.height = 10.0, 100.0
	    group_007.width, group_007.height = 140.0, 100.0
	    stylized_mesh_bake.width, stylized_mesh_bake.height = 140.0, 100.0
	    resample_curve_001.width, resample_curve_001.height = 140.0, 100.0
	    group_input_001_6.width, group_input_001_6.height = 140.0, 100.0
	    switch_3.width, switch_3.height = 140.0, 100.0
	    compare_001_4.width, compare_001_4.height = 140.0, 100.0
	
	    #initialize stylized_meshify_hair links
	    #named_attribute_4.Attribute -> compare_4.A
	    stylized_meshify_hair.links.new(named_attribute_4.outputs[0], compare_4.inputs[2])
	    #compare_4.Result -> separate_geometry.Selection
	    stylized_meshify_hair.links.new(compare_4.outputs[0], separate_geometry.inputs[1])
	    #join_geometry_001.Geometry -> repeat_output_1.Geometry
	    stylized_meshify_hair.links.new(join_geometry_001.outputs[0], repeat_output_1.inputs[0])
	    #math_3.Value -> repeat_output_1.Index
	    stylized_meshify_hair.links.new(math_3.outputs[0], repeat_output_1.inputs[1])
	    #repeat_input_1.Index -> math_3.Value
	    stylized_meshify_hair.links.new(repeat_input_1.outputs[2], math_3.inputs[0])
	    #reroute_001_5.Output -> attribute_statistic_001.Geometry
	    stylized_meshify_hair.links.new(reroute_001_5.outputs[0], attribute_statistic_001.inputs[0])
	    #math_001_1.Value -> repeat_input_1.Iterations
	    stylized_meshify_hair.links.new(math_001_1.outputs[0], repeat_input_1.inputs[0])
	    #attribute_statistic_001.Max -> math_001_1.Value
	    stylized_meshify_hair.links.new(attribute_statistic_001.outputs[4], math_001_1.inputs[0])
	    #named_attribute_003_1.Attribute -> attribute_statistic_001.Attribute
	    stylized_meshify_hair.links.new(named_attribute_003_1.outputs[0], attribute_statistic_001.inputs[2])
	    #repeat_input_1.Index -> compare_4.B
	    stylized_meshify_hair.links.new(repeat_input_1.outputs[2], compare_4.inputs[3])
	    #group_input_10.Geometry -> reroute_001_5.Input
	    stylized_meshify_hair.links.new(group_input_10.outputs[0], reroute_001_5.inputs[0])
	    #reroute_001_5.Output -> reroute_002_3.Input
	    stylized_meshify_hair.links.new(reroute_001_5.outputs[0], reroute_002_3.inputs[0])
	    #set_material.Geometry -> group_output_12.Geometry
	    stylized_meshify_hair.links.new(set_material.outputs[0], group_output_12.inputs[0])
	    #stylized_mesh_bake.Geometry -> set_material.Geometry
	    stylized_meshify_hair.links.new(stylized_mesh_bake.outputs[0], set_material.inputs[0])
	    #group_input_008_2.Material -> set_material.Material
	    stylized_meshify_hair.links.new(group_input_008_2.outputs[2], set_material.inputs[2])
	    #reroute_010_3.Output -> join_geometry_001.Geometry
	    stylized_meshify_hair.links.new(reroute_010_3.outputs[0], join_geometry_001.inputs[0])
	    #group_007.Geometry -> reroute_010_3.Input
	    stylized_meshify_hair.links.new(group_007.outputs[0], reroute_010_3.inputs[0])
	    #group_input_005_4.Surface -> group_007.Surface
	    stylized_meshify_hair.links.new(group_input_005_4.outputs[1], group_007.inputs[1])
	    #separate_geometry.Selection -> group_007.Geometry
	    stylized_meshify_hair.links.new(separate_geometry.outputs[0], group_007.inputs[0])
	    #repeat_output_1.Geometry -> stylized_mesh_bake.Geometry
	    stylized_meshify_hair.links.new(repeat_output_1.outputs[0], stylized_mesh_bake.inputs[0])
	    #reroute_002_3.Output -> resample_curve_001.Curve
	    stylized_meshify_hair.links.new(reroute_002_3.outputs[0], resample_curve_001.inputs[0])
	    #group_input_001_6.Control Points -> resample_curve_001.Count
	    stylized_meshify_hair.links.new(group_input_001_6.outputs[3], resample_curve_001.inputs[2])
	    #group_input_010.Subdivison Level -> group_007.Level
	    stylized_meshify_hair.links.new(group_input_010.outputs[9], group_007.inputs[7])
	    #group_input_010.Radius -> group_007.Radius
	    stylized_meshify_hair.links.new(group_input_010.outputs[4], group_007.inputs[2])
	    #group_input_010.Use Enhancements -> group_007.Use Enhancements
	    stylized_meshify_hair.links.new(group_input_010.outputs[5], group_007.inputs[3])
	    #group_input_010.Maintain Shape Factor -> group_007.Maintain Shape Factor
	    stylized_meshify_hair.links.new(group_input_010.outputs[6], group_007.inputs[4])
	    #group_input_010.Pin at Parameter -> group_007.Pin at Parameter
	    stylized_meshify_hair.links.new(group_input_010.outputs[7], group_007.inputs[5])
	    #group_input_010.Snap to surface -> group_007.Snap to surface
	    stylized_meshify_hair.links.new(group_input_010.outputs[8], group_007.inputs[6])
	    #group_input_010.Edge Crease -> group_007.Edge Crease
	    stylized_meshify_hair.links.new(group_input_010.outputs[10], group_007.inputs[8])
	    #group_input_010.Vertex Crease -> group_007.Vertex Crease
	    stylized_meshify_hair.links.new(group_input_010.outputs[11], group_007.inputs[9])
	    #group_input_010.Limit Surface -> group_007.Limit Surface
	    stylized_meshify_hair.links.new(group_input_010.outputs[12], group_007.inputs[10])
	    #group_input_010.Distance -> group_007.Distance
	    stylized_meshify_hair.links.new(group_input_010.outputs[13], group_007.inputs[11])
	    #group_input_001_6.Control Points -> compare_001_4.A
	    stylized_meshify_hair.links.new(group_input_001_6.outputs[3], compare_001_4.inputs[2])
	    #compare_001_4.Result -> switch_3.Switch
	    stylized_meshify_hair.links.new(compare_001_4.outputs[0], switch_3.inputs[0])
	    #reroute_002_3.Output -> switch_3.False
	    stylized_meshify_hair.links.new(reroute_002_3.outputs[0], switch_3.inputs[1])
	    #resample_curve_001.Curve -> switch_3.True
	    stylized_meshify_hair.links.new(resample_curve_001.outputs[0], switch_3.inputs[2])
	    #switch_3.Output -> separate_geometry.Geometry
	    stylized_meshify_hair.links.new(switch_3.outputs[0], separate_geometry.inputs[0])
	    #repeat_input_1.Geometry -> join_geometry_001.Geometry
	    stylized_meshify_hair.links.new(repeat_input_1.outputs[1], join_geometry_001.inputs[0])
	    return stylized_meshify_hair
	
	stylized_meshify_hair = stylized_meshify_hair_node_group()
	
	#initialize hair_card node group
	def hair_card_node_group():
	    hair_card = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Hair_Card")
	
	    hair_card.color_tag = 'NONE'
	    hair_card.description = ""
	    hair_card.default_group_node_width = 140
	    
	
	    hair_card.is_modifier = True
	
	    #hair_card interface
	    #Socket Geometry
	    geometry_socket_19 = hair_card.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_19.attribute_domain = 'POINT'
	
	    #Socket Geometry
	    geometry_socket_20 = hair_card.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_20.attribute_domain = 'POINT'
	
	    #Socket Material
	    material_socket_1 = hair_card.interface.new_socket(name = "Material", in_out='INPUT', socket_type = 'NodeSocketMaterial')
	    material_socket_1.attribute_domain = 'POINT'
	
	    #Socket Curve Radius
	    curve_radius_socket = hair_card.interface.new_socket(name = "Curve Radius", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    curve_radius_socket.default_value = 1.0
	    curve_radius_socket.min_value = 0.0
	    curve_radius_socket.max_value = 3.4028234663852886e+38
	    curve_radius_socket.subtype = 'DISTANCE'
	    curve_radius_socket.attribute_domain = 'POINT'
	    curve_radius_socket.hide_value = True
	    curve_radius_socket.hide_in_modifier = True
	
	    #Socket Resolution
	    resolution_socket = hair_card.interface.new_socket(name = "Resolution", in_out='INPUT', socket_type = 'NodeSocketInt')
	    resolution_socket.default_value = 0
	    resolution_socket.min_value = 2
	    resolution_socket.max_value = 512
	    resolution_socket.subtype = 'NONE'
	    resolution_socket.attribute_domain = 'POINT'
	
	    #Socket Width
	    width_socket = hair_card.interface.new_socket(name = "Width", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    width_socket.default_value = 0.10000000149011612
	    width_socket.min_value = 0.0
	    width_socket.max_value = 3.4028234663852886e+38
	    width_socket.subtype = 'DISTANCE'
	    width_socket.attribute_domain = 'POINT'
	
	    #Socket Angle
	    angle_socket = hair_card.interface.new_socket(name = "Angle", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    angle_socket.default_value = 45.0
	    angle_socket.min_value = -90.0
	    angle_socket.max_value = 90.0
	    angle_socket.subtype = 'ANGLE'
	    angle_socket.attribute_domain = 'POINT'
	
	
	    #initialize hair_card nodes
	    #node Group Input
	    group_input_11 = hair_card.nodes.new("NodeGroupInput")
	    group_input_11.name = "Group Input"
	    group_input_11.outputs[1].hide = True
	    group_input_11.outputs[2].hide = True
	    group_input_11.outputs[5].hide = True
	    group_input_11.outputs[6].hide = True
	
	    #node Group Output
	    group_output_13 = hair_card.nodes.new("NodeGroupOutput")
	    group_output_13.name = "Group Output"
	    group_output_13.is_active_output = True
	
	    #node Curve to Mesh
	    curve_to_mesh_1 = hair_card.nodes.new("GeometryNodeCurveToMesh")
	    curve_to_mesh_1.name = "Curve to Mesh"
	    curve_to_mesh_1.hide = True
	    #Fill Caps
	    curve_to_mesh_1.inputs[2].default_value = False
	
	    #node Capture Attribute
	    capture_attribute_1 = hair_card.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_1.name = "Capture Attribute"
	    capture_attribute_1.hide = True
	    capture_attribute_1.active_index = 0
	    capture_attribute_1.capture_items.clear()
	    capture_attribute_1.capture_items.new('FLOAT', "Factor")
	    capture_attribute_1.capture_items["Factor"].data_type = 'FLOAT'
	    capture_attribute_1.domain = 'POINT'
	
	    #node Spline Parameter
	    spline_parameter_3 = hair_card.nodes.new("GeometryNodeSplineParameter")
	    spline_parameter_3.name = "Spline Parameter"
	    spline_parameter_3.hide = True
	
	    #node Combine XYZ
	    combine_xyz_1 = hair_card.nodes.new("ShaderNodeCombineXYZ")
	    combine_xyz_1.name = "Combine XYZ"
	    combine_xyz_1.hide = True
	    #Z
	    combine_xyz_1.inputs[2].default_value = 0.0
	
	    #node Store Named Attribute
	    store_named_attribute_4 = hair_card.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_4.name = "Store Named Attribute"
	    store_named_attribute_4.data_type = 'FLOAT2'
	    store_named_attribute_4.domain = 'CORNER'
	    #Selection
	    store_named_attribute_4.inputs[1].default_value = True
	    #Name
	    store_named_attribute_4.inputs[2].default_value = "hair_card_UV"
	
	    #node Set Material
	    set_material_1 = hair_card.nodes.new("GeometryNodeSetMaterial")
	    set_material_1.name = "Set Material"
	    set_material_1.hide = True
	    #Selection
	    set_material_1.inputs[1].default_value = True
	
	    #node Capture Attribute.002
	    capture_attribute_002_2 = hair_card.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_002_2.name = "Capture Attribute.002"
	    capture_attribute_002_2.hide = True
	    capture_attribute_002_2.active_index = 0
	    capture_attribute_002_2.capture_items.clear()
	    capture_attribute_002_2.capture_items.new('FLOAT', "Factor")
	    capture_attribute_002_2.capture_items["Factor"].data_type = 'FLOAT'
	    capture_attribute_002_2.domain = 'POINT'
	
	    #node Reroute
	    reroute_6 = hair_card.nodes.new("NodeReroute")
	    reroute_6.name = "Reroute"
	    reroute_6.socket_idname = "NodeSocketFloat"
	    #node Group Input.001
	    group_input_001_7 = hair_card.nodes.new("NodeGroupInput")
	    group_input_001_7.name = "Group Input.001"
	    group_input_001_7.outputs[0].hide = True
	    group_input_001_7.outputs[2].hide = True
	    group_input_001_7.outputs[3].hide = True
	    group_input_001_7.outputs[4].hide = True
	    group_input_001_7.outputs[5].hide = True
	    group_input_001_7.outputs[6].hide = True
	
	    #node Reroute.001
	    reroute_001_6 = hair_card.nodes.new("NodeReroute")
	    reroute_001_6.name = "Reroute.001"
	    reroute_001_6.socket_idname = "NodeSocketFloatDistance"
	    #node Resample Curve
	    resample_curve_2 = hair_card.nodes.new("GeometryNodeResampleCurve")
	    resample_curve_2.name = "Resample Curve"
	    resample_curve_2.hide = True
	    resample_curve_2.keep_last_segment = False
	    resample_curve_2.mode = 'COUNT'
	    #Selection
	    resample_curve_2.inputs[1].default_value = True
	
	    #node Switch
	    switch_4 = hair_card.nodes.new("GeometryNodeSwitch")
	    switch_4.name = "Switch"
	    switch_4.hide = True
	    switch_4.input_type = 'GEOMETRY'
	
	    #node Group Input.002
	    group_input_002_5 = hair_card.nodes.new("NodeGroupInput")
	    group_input_002_5.name = "Group Input.002"
	    group_input_002_5.outputs[0].hide = True
	    group_input_002_5.outputs[1].hide = True
	    group_input_002_5.outputs[2].hide = True
	    group_input_002_5.outputs[4].hide = True
	    group_input_002_5.outputs[5].hide = True
	    group_input_002_5.outputs[6].hide = True
	
	    #node Compare
	    compare_5 = hair_card.nodes.new("FunctionNodeCompare")
	    compare_5.name = "Compare"
	    compare_5.hide = True
	    compare_5.data_type = 'INT'
	    compare_5.mode = 'ELEMENT'
	    compare_5.operation = 'LESS_THAN'
	    #B_INT
	    compare_5.inputs[3].default_value = 2
	
	    #node Reroute.002
	    reroute_002_4 = hair_card.nodes.new("NodeReroute")
	    reroute_002_4.name = "Reroute.002"
	    reroute_002_4.socket_idname = "NodeSocketGeometry"
	    #node Group Input.003
	    group_input_003_4 = hair_card.nodes.new("NodeGroupInput")
	    group_input_003_4.name = "Group Input.003"
	    group_input_003_4.outputs[0].hide = True
	    group_input_003_4.outputs[1].hide = True
	    group_input_003_4.outputs[2].hide = True
	    group_input_003_4.outputs[3].hide = True
	    group_input_003_4.outputs[4].hide = True
	    group_input_003_4.outputs[6].hide = True
	
	    #node Points
	    points_1 = hair_card.nodes.new("GeometryNodePoints")
	    points_1.name = "Points"
	    points_1.hide = True
	    #Count
	    points_1.inputs[0].default_value = 1
	    #Position
	    points_1.inputs[1].default_value = (0.0, 0.0, 0.0)
	    #Radius
	    points_1.inputs[2].default_value = 0.10000000149011612
	
	    #node Points.001
	    points_001 = hair_card.nodes.new("GeometryNodePoints")
	    points_001.name = "Points.001"
	    points_001.hide = True
	    #Count
	    points_001.inputs[0].default_value = 1
	    #Radius
	    points_001.inputs[2].default_value = 0.10000000149011612
	
	    #node Points.002
	    points_002 = hair_card.nodes.new("GeometryNodePoints")
	    points_002.name = "Points.002"
	    points_002.hide = True
	    #Count
	    points_002.inputs[0].default_value = 1
	    #Radius
	    points_002.inputs[2].default_value = 0.10000000149011612
	
	    #node Points to Curves
	    points_to_curves_1 = hair_card.nodes.new("GeometryNodePointsToCurves")
	    points_to_curves_1.name = "Points to Curves"
	    points_to_curves_1.hide = True
	    #Curve Group ID
	    points_to_curves_1.inputs[1].default_value = 0
	    #Weight
	    points_to_curves_1.inputs[2].default_value = 0.0
	
	    #node Join Geometry
	    join_geometry_1 = hair_card.nodes.new("GeometryNodeJoinGeometry")
	    join_geometry_1.name = "Join Geometry"
	    join_geometry_1.hide = True
	
	    #node Vector Rotate
	    vector_rotate_1 = hair_card.nodes.new("ShaderNodeVectorRotate")
	    vector_rotate_1.name = "Vector Rotate"
	    vector_rotate_1.hide = True
	    vector_rotate_1.invert = False
	    vector_rotate_1.rotation_type = 'AXIS_ANGLE'
	    #Center
	    vector_rotate_1.inputs[1].default_value = (0.0, 0.0, 0.0)
	    #Axis
	    vector_rotate_1.inputs[2].default_value = (0.0, 0.0, 1.0)
	
	    #node Combine XYZ.003
	    combine_xyz_003 = hair_card.nodes.new("ShaderNodeCombineXYZ")
	    combine_xyz_003.name = "Combine XYZ.003"
	    combine_xyz_003.hide = True
	    #Y
	    combine_xyz_003.inputs[1].default_value = 0.0
	    #Z
	    combine_xyz_003.inputs[2].default_value = 0.0
	
	    #node Vector Math
	    vector_math_4 = hair_card.nodes.new("ShaderNodeVectorMath")
	    vector_math_4.name = "Vector Math"
	    vector_math_4.hide = True
	    vector_math_4.operation = 'MULTIPLY'
	    #Vector_001
	    vector_math_4.inputs[1].default_value = (-1.0, 1.0, 1.0)
	
	    #node Set Curve Radius
	    set_curve_radius_1 = hair_card.nodes.new("GeometryNodeSetCurveRadius")
	    set_curve_radius_1.name = "Set Curve Radius"
	    set_curve_radius_1.hide = True
	    #Selection
	    set_curve_radius_1.inputs[1].default_value = True
	
	    #node Group Input.004
	    group_input_004_3 = hair_card.nodes.new("NodeGroupInput")
	    group_input_004_3.name = "Group Input.004"
	    group_input_004_3.outputs[0].hide = True
	    group_input_004_3.outputs[1].hide = True
	    group_input_004_3.outputs[3].hide = True
	    group_input_004_3.outputs[4].hide = True
	    group_input_004_3.outputs[5].hide = True
	    group_input_004_3.outputs[6].hide = True
	
	    #node Reroute.003
	    reroute_003_2 = hair_card.nodes.new("NodeReroute")
	    reroute_003_2.name = "Reroute.003"
	    reroute_003_2.socket_idname = "NodeSocketFloatDistance"
	    #node Reroute.004
	    reroute_004_4 = hair_card.nodes.new("NodeReroute")
	    reroute_004_4.name = "Reroute.004"
	    reroute_004_4.socket_idname = "NodeSocketFloatDistance"
	
	
	
	
	    #Set locations
	    group_input_11.location = (-340.0, 0.0)
	    group_output_13.location = (1204.581787109375, 58.388336181640625)
	    curve_to_mesh_1.location = (717.3101196289062, -30.657630920410156)
	    capture_attribute_1.location = (532.3717651367188, -13.901289939880371)
	    spline_parameter_3.location = (329.8749084472656, -144.0863800048828)
	    combine_xyz_1.location = (717.11865234375, -93.34249114990234)
	    store_named_attribute_4.location = (883.1387329101562, 66.61811828613281)
	    set_material_1.location = (1044.3658447265625, 32.40200424194336)
	    capture_attribute_002_2.location = (534.5352783203125, -74.45401000976562)
	    reroute_6.location = (496.6486511230469, -141.76992797851562)
	    group_input_001_7.location = (1041.4315185546875, 1.5365350246429443)
	    reroute_001_6.location = (-187.22337341308594, -77.96863555908203)
	    resample_curve_2.location = (-5.360104560852051, -28.505603790283203)
	    switch_4.location = (-5.43592643737793, 6.486942291259766)
	    group_input_002_5.location = (-336.779052734375, 70.9764633178711)
	    compare_5.location = (-8.656487464904785, 41.045326232910156)
	    reroute_002_4.location = (-99.20211791992188, -32.54893493652344)
	    group_input_003_4.location = (-339.9999694824219, -103.2856674194336)
	    points_1.location = (156.70631408691406, -123.0439224243164)
	    points_001.location = (156.70632934570312, -81.72965240478516)
	    points_002.location = (158.99679565429688, -168.9486846923828)
	    points_to_curves_1.location = (321.6205749511719, -74.84392547607422)
	    join_geometry_1.location = (328.4919128417969, -106.97728729248047)
	    vector_rotate_1.location = (-8.371872901916504, -97.79617309570312)
	    combine_xyz_003.location = (-168.62094116210938, -79.79706573486328)
	    vector_math_4.location = (-6.081514358520508, -135.33193969726562)
	    set_curve_radius_1.location = (320.7674560546875, -1.0603179931640625)
	    group_input_004_3.location = (-334.8185729980469, 133.8203125)
	    reroute_003_2.location = (237.70924377441406, 97.4658203125)
	    reroute_004_4.location = (241.74778747558594, -21.909408569335938)
	
	    #Set dimensions
	    group_input_11.width, group_input_11.height = 140.0, 100.0
	    group_output_13.width, group_output_13.height = 140.0, 100.0
	    curve_to_mesh_1.width, curve_to_mesh_1.height = 140.0, 100.0
	    capture_attribute_1.width, capture_attribute_1.height = 140.0, 100.0
	    spline_parameter_3.width, spline_parameter_3.height = 140.0, 100.0
	    combine_xyz_1.width, combine_xyz_1.height = 140.0, 100.0
	    store_named_attribute_4.width, store_named_attribute_4.height = 140.0, 100.0
	    set_material_1.width, set_material_1.height = 140.0, 100.0
	    capture_attribute_002_2.width, capture_attribute_002_2.height = 140.0, 100.0
	    reroute_6.width, reroute_6.height = 100.0, 100.0
	    group_input_001_7.width, group_input_001_7.height = 140.0, 100.0
	    reroute_001_6.width, reroute_001_6.height = 100.0, 100.0
	    resample_curve_2.width, resample_curve_2.height = 140.0, 100.0
	    switch_4.width, switch_4.height = 140.0, 100.0
	    group_input_002_5.width, group_input_002_5.height = 140.0, 100.0
	    compare_5.width, compare_5.height = 140.0, 100.0
	    reroute_002_4.width, reroute_002_4.height = 100.0, 100.0
	    group_input_003_4.width, group_input_003_4.height = 140.0, 100.0
	    points_1.width, points_1.height = 140.0, 100.0
	    points_001.width, points_001.height = 140.0, 100.0
	    points_002.width, points_002.height = 140.0, 100.0
	    points_to_curves_1.width, points_to_curves_1.height = 140.0, 100.0
	    join_geometry_1.width, join_geometry_1.height = 140.0, 100.0
	    vector_rotate_1.width, vector_rotate_1.height = 140.0, 100.0
	    combine_xyz_003.width, combine_xyz_003.height = 140.0, 100.0
	    vector_math_4.width, vector_math_4.height = 140.0, 100.0
	    set_curve_radius_1.width, set_curve_radius_1.height = 140.0, 100.0
	    group_input_004_3.width, group_input_004_3.height = 140.0, 100.0
	    reroute_003_2.width, reroute_003_2.height = 100.0, 100.0
	    reroute_004_4.width, reroute_004_4.height = 100.0, 100.0
	
	    #initialize hair_card links
	    #set_material_1.Geometry -> group_output_13.Geometry
	    hair_card.links.new(set_material_1.outputs[0], group_output_13.inputs[0])
	    #capture_attribute_1.Geometry -> curve_to_mesh_1.Curve
	    hair_card.links.new(capture_attribute_1.outputs[0], curve_to_mesh_1.inputs[0])
	    #reroute_6.Output -> capture_attribute_1.Factor
	    hair_card.links.new(reroute_6.outputs[0], capture_attribute_1.inputs[1])
	    #capture_attribute_1.Factor -> combine_xyz_1.X
	    hair_card.links.new(capture_attribute_1.outputs[1], combine_xyz_1.inputs[0])
	    #curve_to_mesh_1.Mesh -> store_named_attribute_4.Geometry
	    hair_card.links.new(curve_to_mesh_1.outputs[0], store_named_attribute_4.inputs[0])
	    #combine_xyz_1.Vector -> store_named_attribute_4.Value
	    hair_card.links.new(combine_xyz_1.outputs[0], store_named_attribute_4.inputs[3])
	    #store_named_attribute_4.Geometry -> set_material_1.Geometry
	    hair_card.links.new(store_named_attribute_4.outputs[0], set_material_1.inputs[0])
	    #reroute_6.Output -> capture_attribute_002_2.Factor
	    hair_card.links.new(reroute_6.outputs[0], capture_attribute_002_2.inputs[1])
	    #capture_attribute_002_2.Factor -> combine_xyz_1.Y
	    hair_card.links.new(capture_attribute_002_2.outputs[1], combine_xyz_1.inputs[1])
	    #spline_parameter_3.Factor -> reroute_6.Input
	    hair_card.links.new(spline_parameter_3.outputs[0], reroute_6.inputs[0])
	    #group_input_001_7.Material -> set_material_1.Material
	    hair_card.links.new(group_input_001_7.outputs[1], set_material_1.inputs[2])
	    #group_input_11.Width -> reroute_001_6.Input
	    hair_card.links.new(group_input_11.outputs[4], reroute_001_6.inputs[0])
	    #reroute_002_4.Output -> resample_curve_2.Curve
	    hair_card.links.new(reroute_002_4.outputs[0], resample_curve_2.inputs[0])
	    #group_input_11.Resolution -> resample_curve_2.Count
	    hair_card.links.new(group_input_11.outputs[3], resample_curve_2.inputs[2])
	    #group_input_002_5.Resolution -> compare_5.A
	    hair_card.links.new(group_input_002_5.outputs[3], compare_5.inputs[2])
	    #compare_5.Result -> switch_4.Switch
	    hair_card.links.new(compare_5.outputs[0], switch_4.inputs[0])
	    #set_curve_radius_1.Curve -> capture_attribute_1.Geometry
	    hair_card.links.new(set_curve_radius_1.outputs[0], capture_attribute_1.inputs[0])
	    #group_input_11.Geometry -> reroute_002_4.Input
	    hair_card.links.new(group_input_11.outputs[0], reroute_002_4.inputs[0])
	    #reroute_002_4.Output -> switch_4.True
	    hair_card.links.new(reroute_002_4.outputs[0], switch_4.inputs[2])
	    #resample_curve_2.Curve -> switch_4.False
	    hair_card.links.new(resample_curve_2.outputs[0], switch_4.inputs[1])
	    #join_geometry_1.Geometry -> points_to_curves_1.Points
	    hair_card.links.new(join_geometry_1.outputs[0], points_to_curves_1.inputs[0])
	    #points_002.Points -> join_geometry_1.Geometry
	    hair_card.links.new(points_002.outputs[0], join_geometry_1.inputs[0])
	    #group_input_003_4.Angle -> vector_rotate_1.Angle
	    hair_card.links.new(group_input_003_4.outputs[5], vector_rotate_1.inputs[3])
	    #vector_rotate_1.Vector -> vector_math_4.Vector
	    hair_card.links.new(vector_rotate_1.outputs[0], vector_math_4.inputs[0])
	    #vector_rotate_1.Vector -> points_001.Position
	    hair_card.links.new(vector_rotate_1.outputs[0], points_001.inputs[1])
	    #vector_math_4.Vector -> points_002.Position
	    hair_card.links.new(vector_math_4.outputs[0], points_002.inputs[1])
	    #combine_xyz_003.Vector -> vector_rotate_1.Vector
	    hair_card.links.new(combine_xyz_003.outputs[0], vector_rotate_1.inputs[0])
	    #reroute_001_6.Output -> combine_xyz_003.X
	    hair_card.links.new(reroute_001_6.outputs[0], combine_xyz_003.inputs[0])
	    #points_to_curves_1.Curves -> capture_attribute_002_2.Geometry
	    hair_card.links.new(points_to_curves_1.outputs[0], capture_attribute_002_2.inputs[0])
	    #capture_attribute_002_2.Geometry -> curve_to_mesh_1.Profile Curve
	    hair_card.links.new(capture_attribute_002_2.outputs[0], curve_to_mesh_1.inputs[1])
	    #switch_4.Output -> set_curve_radius_1.Curve
	    hair_card.links.new(switch_4.outputs[0], set_curve_radius_1.inputs[0])
	    #reroute_004_4.Output -> set_curve_radius_1.Radius
	    hair_card.links.new(reroute_004_4.outputs[0], set_curve_radius_1.inputs[2])
	    #group_input_004_3.Curve Radius -> reroute_003_2.Input
	    hair_card.links.new(group_input_004_3.outputs[2], reroute_003_2.inputs[0])
	    #reroute_003_2.Output -> reroute_004_4.Input
	    hair_card.links.new(reroute_003_2.outputs[0], reroute_004_4.inputs[0])
	    #points_1.Points -> join_geometry_1.Geometry
	    hair_card.links.new(points_1.outputs[0], join_geometry_1.inputs[0])
	    #points_001.Points -> join_geometry_1.Geometry
	    hair_card.links.new(points_001.outputs[0], join_geometry_1.inputs[0])
	    return hair_card
	
	hair_card = hair_card_node_group()
	
	#initialize stylized_hair node group
	def stylized_hair_node_group():
	    stylized_hair = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Stylized_Hair")
	
	    stylized_hair.color_tag = 'NONE'
	    stylized_hair.description = ""
	    stylized_hair.default_group_node_width = 140
	    
	
	    stylized_hair.is_modifier = True
	
	    #stylized_hair interface
	    #Socket Geometry
	    geometry_socket_21 = stylized_hair.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_21.attribute_domain = 'POINT'
	
	    #Socket Geometry
	    geometry_socket_22 = stylized_hair.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_22.attribute_domain = 'POINT'
	
	    #Socket Profile
	    profile_socket = stylized_hair.interface.new_socket(name = "Profile", in_out='INPUT', socket_type = 'NodeSocketObject')
	    profile_socket.attribute_domain = 'POINT'
	
	    #Socket Material
	    material_socket_2 = stylized_hair.interface.new_socket(name = "Material", in_out='INPUT', socket_type = 'NodeSocketMaterial')
	    material_socket_2.attribute_domain = 'POINT'
	
	    #Socket Curve Radius
	    curve_radius_socket_1 = stylized_hair.interface.new_socket(name = "Curve Radius", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    curve_radius_socket_1.default_value = 1.0
	    curve_radius_socket_1.min_value = 0.0
	    curve_radius_socket_1.max_value = 3.4028234663852886e+38
	    curve_radius_socket_1.subtype = 'DISTANCE'
	    curve_radius_socket_1.attribute_domain = 'POINT'
	    curve_radius_socket_1.hide_value = True
	    curve_radius_socket_1.hide_in_modifier = True
	
	    #Socket Resolution
	    resolution_socket_1 = stylized_hair.interface.new_socket(name = "Resolution", in_out='INPUT', socket_type = 'NodeSocketInt')
	    resolution_socket_1.default_value = 10
	    resolution_socket_1.min_value = 1
	    resolution_socket_1.max_value = 100000
	    resolution_socket_1.subtype = 'NONE'
	    resolution_socket_1.attribute_domain = 'POINT'
	
	    #Socket Fill Caps
	    fill_caps_socket = stylized_hair.interface.new_socket(name = "Fill Caps", in_out='INPUT', socket_type = 'NodeSocketBool')
	    fill_caps_socket.default_value = True
	    fill_caps_socket.attribute_domain = 'POINT'
	
	    #Socket Translation
	    translation_socket = stylized_hair.interface.new_socket(name = "Translation", in_out='INPUT', socket_type = 'NodeSocketVector')
	    translation_socket.default_value = (0.0, 0.0, 0.0)
	    translation_socket.min_value = -3.4028234663852886e+38
	    translation_socket.max_value = 3.4028234663852886e+38
	    translation_socket.subtype = 'TRANSLATION'
	    translation_socket.attribute_domain = 'POINT'
	
	    #Socket Rotation
	    rotation_socket = stylized_hair.interface.new_socket(name = "Rotation", in_out='INPUT', socket_type = 'NodeSocketRotation')
	    rotation_socket.default_value = (0.0, 0.0, 0.0)
	    rotation_socket.attribute_domain = 'POINT'
	
	    #Socket Scale
	    scale_socket = stylized_hair.interface.new_socket(name = "Scale", in_out='INPUT', socket_type = 'NodeSocketVector')
	    scale_socket.default_value = (1.0, 1.0, 1.0)
	    scale_socket.min_value = -3.4028234663852886e+38
	    scale_socket.max_value = 3.4028234663852886e+38
	    scale_socket.subtype = 'XYZ'
	    scale_socket.attribute_domain = 'POINT'
	
	
	    #initialize stylized_hair nodes
	    #node Group Input
	    group_input_12 = stylized_hair.nodes.new("NodeGroupInput")
	    group_input_12.name = "Group Input"
	    group_input_12.outputs[2].hide = True
	    group_input_12.outputs[3].hide = True
	    group_input_12.outputs[4].hide = True
	    group_input_12.outputs[5].hide = True
	    group_input_12.outputs[6].hide = True
	    group_input_12.outputs[7].hide = True
	    group_input_12.outputs[8].hide = True
	    group_input_12.outputs[9].hide = True
	
	    #node Group Output
	    group_output_14 = stylized_hair.nodes.new("NodeGroupOutput")
	    group_output_14.name = "Group Output"
	    group_output_14.is_active_output = True
	
	    #node Curve to Mesh
	    curve_to_mesh_2 = stylized_hair.nodes.new("GeometryNodeCurveToMesh")
	    curve_to_mesh_2.name = "Curve to Mesh"
	    curve_to_mesh_2.hide = True
	
	    #node Capture Attribute
	    capture_attribute_2 = stylized_hair.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_2.name = "Capture Attribute"
	    capture_attribute_2.hide = True
	    capture_attribute_2.active_index = 0
	    capture_attribute_2.capture_items.clear()
	    capture_attribute_2.capture_items.new('FLOAT', "Factor")
	    capture_attribute_2.capture_items["Factor"].data_type = 'FLOAT'
	    capture_attribute_2.domain = 'POINT'
	
	    #node Spline Parameter
	    spline_parameter_4 = stylized_hair.nodes.new("GeometryNodeSplineParameter")
	    spline_parameter_4.name = "Spline Parameter"
	    spline_parameter_4.hide = True
	
	    #node Combine XYZ
	    combine_xyz_2 = stylized_hair.nodes.new("ShaderNodeCombineXYZ")
	    combine_xyz_2.name = "Combine XYZ"
	    combine_xyz_2.hide = True
	    #Z
	    combine_xyz_2.inputs[2].default_value = 0.0
	
	    #node Store Named Attribute
	    store_named_attribute_5 = stylized_hair.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_5.name = "Store Named Attribute"
	    store_named_attribute_5.data_type = 'FLOAT2'
	    store_named_attribute_5.domain = 'CORNER'
	    #Selection
	    store_named_attribute_5.inputs[1].default_value = True
	    #Name
	    store_named_attribute_5.inputs[2].default_value = "stylized_hair_UV"
	
	    #node Set Material
	    set_material_2 = stylized_hair.nodes.new("GeometryNodeSetMaterial")
	    set_material_2.name = "Set Material"
	    set_material_2.hide = True
	    #Selection
	    set_material_2.inputs[1].default_value = True
	
	    #node Capture Attribute.002
	    capture_attribute_002_3 = stylized_hair.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_002_3.name = "Capture Attribute.002"
	    capture_attribute_002_3.hide = True
	    capture_attribute_002_3.active_index = 0
	    capture_attribute_002_3.capture_items.clear()
	    capture_attribute_002_3.capture_items.new('FLOAT', "Factor")
	    capture_attribute_002_3.capture_items["Factor"].data_type = 'FLOAT'
	    capture_attribute_002_3.domain = 'POINT'
	
	    #node Reroute
	    reroute_7 = stylized_hair.nodes.new("NodeReroute")
	    reroute_7.name = "Reroute"
	    reroute_7.socket_idname = "NodeSocketFloat"
	    #node Group Input.001
	    group_input_001_8 = stylized_hair.nodes.new("NodeGroupInput")
	    group_input_001_8.name = "Group Input.001"
	    group_input_001_8.outputs[0].hide = True
	    group_input_001_8.outputs[1].hide = True
	    group_input_001_8.outputs[3].hide = True
	    group_input_001_8.outputs[4].hide = True
	    group_input_001_8.outputs[5].hide = True
	    group_input_001_8.outputs[6].hide = True
	    group_input_001_8.outputs[7].hide = True
	    group_input_001_8.outputs[8].hide = True
	    group_input_001_8.outputs[9].hide = True
	
	    #node Group Input.002
	    group_input_002_6 = stylized_hair.nodes.new("NodeGroupInput")
	    group_input_002_6.name = "Group Input.002"
	    group_input_002_6.outputs[0].hide = True
	    group_input_002_6.outputs[1].hide = True
	    group_input_002_6.outputs[2].hide = True
	    group_input_002_6.outputs[3].hide = True
	    group_input_002_6.outputs[4].hide = True
	    group_input_002_6.outputs[6].hide = True
	    group_input_002_6.outputs[7].hide = True
	    group_input_002_6.outputs[8].hide = True
	    group_input_002_6.outputs[9].hide = True
	
	    #node Object Info
	    object_info_2 = stylized_hair.nodes.new("GeometryNodeObjectInfo")
	    object_info_2.name = "Object Info"
	    object_info_2.hide = True
	    object_info_2.transform_space = 'RELATIVE'
	    #As Instance
	    object_info_2.inputs[1].default_value = False
	
	    #node Transform Geometry
	    transform_geometry_1 = stylized_hair.nodes.new("GeometryNodeTransform")
	    transform_geometry_1.name = "Transform Geometry"
	    transform_geometry_1.hide = True
	    transform_geometry_1.mode = 'COMPONENTS'
	
	    #node Group Input.003
	    group_input_003_5 = stylized_hair.nodes.new("NodeGroupInput")
	    group_input_003_5.name = "Group Input.003"
	    group_input_003_5.outputs[0].hide = True
	    group_input_003_5.outputs[1].hide = True
	    group_input_003_5.outputs[2].hide = True
	    group_input_003_5.outputs[4].hide = True
	    group_input_003_5.outputs[5].hide = True
	    group_input_003_5.outputs[6].hide = True
	    group_input_003_5.outputs[7].hide = True
	    group_input_003_5.outputs[8].hide = True
	    group_input_003_5.outputs[9].hide = True
	
	    #node Group Input.004
	    group_input_004_4 = stylized_hair.nodes.new("NodeGroupInput")
	    group_input_004_4.name = "Group Input.004"
	    group_input_004_4.outputs[0].hide = True
	    group_input_004_4.outputs[1].hide = True
	    group_input_004_4.outputs[2].hide = True
	    group_input_004_4.outputs[3].hide = True
	    group_input_004_4.outputs[4].hide = True
	    group_input_004_4.outputs[5].hide = True
	    group_input_004_4.outputs[9].hide = True
	
	    #node Set Curve Radius
	    set_curve_radius_2 = stylized_hair.nodes.new("GeometryNodeSetCurveRadius")
	    set_curve_radius_2.name = "Set Curve Radius"
	    set_curve_radius_2.hide = True
	    #Selection
	    set_curve_radius_2.inputs[1].default_value = True
	
	    #node Reroute.001
	    reroute_001_7 = stylized_hair.nodes.new("NodeReroute")
	    reroute_001_7.name = "Reroute.001"
	    reroute_001_7.socket_idname = "NodeSocketGeometry"
	    #node Reroute.002
	    reroute_002_5 = stylized_hair.nodes.new("NodeReroute")
	    reroute_002_5.name = "Reroute.002"
	    reroute_002_5.socket_idname = "NodeSocketGeometry"
	    #node Resample Curve
	    resample_curve_3 = stylized_hair.nodes.new("GeometryNodeResampleCurve")
	    resample_curve_3.name = "Resample Curve"
	    resample_curve_3.hide = True
	    resample_curve_3.keep_last_segment = False
	    resample_curve_3.mode = 'COUNT'
	    #Selection
	    resample_curve_3.inputs[1].default_value = True
	
	    #node Switch
	    switch_5 = stylized_hair.nodes.new("GeometryNodeSwitch")
	    switch_5.name = "Switch"
	    switch_5.hide = True
	    switch_5.input_type = 'GEOMETRY'
	
	    #node Compare
	    compare_6 = stylized_hair.nodes.new("FunctionNodeCompare")
	    compare_6.name = "Compare"
	    compare_6.hide = True
	    compare_6.data_type = 'INT'
	    compare_6.mode = 'ELEMENT'
	    compare_6.operation = 'LESS_THAN'
	    #B_INT
	    compare_6.inputs[3].default_value = 2
	
	    #node Reroute.005
	    reroute_005_4 = stylized_hair.nodes.new("NodeReroute")
	    reroute_005_4.name = "Reroute.005"
	    reroute_005_4.socket_idname = "NodeSocketGeometry"
	    #node Group Input.005
	    group_input_005_5 = stylized_hair.nodes.new("NodeGroupInput")
	    group_input_005_5.name = "Group Input.005"
	    group_input_005_5.outputs[0].hide = True
	    group_input_005_5.outputs[1].hide = True
	    group_input_005_5.outputs[2].hide = True
	    group_input_005_5.outputs[3].hide = True
	    group_input_005_5.outputs[5].hide = True
	    group_input_005_5.outputs[6].hide = True
	    group_input_005_5.outputs[7].hide = True
	    group_input_005_5.outputs[8].hide = True
	    group_input_005_5.outputs[9].hide = True
	
	
	
	
	
	    #Set locations
	    group_input_12.location = (-340.0, -125.68765258789062)
	    group_output_14.location = (1046.0562744140625, -35.87745666503906)
	    curve_to_mesh_2.location = (546.74853515625, -108.79241180419922)
	    capture_attribute_2.location = (361.8101501464844, -82.63687133789062)
	    spline_parameter_4.location = (156.93017578125, -142.56178283691406)
	    combine_xyz_2.location = (546.5570068359375, -195.67379760742188)
	    store_named_attribute_5.location = (712.5771484375, -27.647676467895508)
	    set_material_2.location = (873.80419921875, -61.86378860473633)
	    capture_attribute_002_3.location = (363.9737243652344, -168.7198028564453)
	    reroute_7.location = (319.04217529296875, -141.52703857421875)
	    group_input_001_8.location = (870.8699951171875, -92.72925567626953)
	    group_input_002_6.location = (542.2694702148438, -137.2887725830078)
	    object_info_2.location = (-173.28436279296875, -181.30752563476562)
	    transform_geometry_1.location = (156.43304443359375, -206.8249053955078)
	    group_input_003_5.location = (-339.0907897949219, -62.643611907958984)
	    group_input_004_4.location = (-338.4869689941406, -211.2111053466797)
	    set_curve_radius_2.location = (158.24813842773438, -76.21592712402344)
	    reroute_001_7.location = (-164.16294860839844, -159.83448791503906)
	    reroute_002_5.location = (-164.90399169921875, -71.62743377685547)
	    resample_curve_3.location = (-36.965057373046875, -67.16246032714844)
	    switch_5.location = (-37.0408821105957, -32.16990661621094)
	    compare_6.location = (-40.26144027709961, 2.388460159301758)
	    reroute_005_4.location = (-130.80706787109375, -71.2057876586914)
	    group_input_005_5.location = (-338.4869689941406, -2.108567237854004)
	
	    #Set dimensions
	    group_input_12.width, group_input_12.height = 140.0, 100.0
	    group_output_14.width, group_output_14.height = 140.0, 100.0
	    curve_to_mesh_2.width, curve_to_mesh_2.height = 140.0, 100.0
	    capture_attribute_2.width, capture_attribute_2.height = 140.0, 100.0
	    spline_parameter_4.width, spline_parameter_4.height = 140.0, 100.0
	    combine_xyz_2.width, combine_xyz_2.height = 140.0, 100.0
	    store_named_attribute_5.width, store_named_attribute_5.height = 140.0, 100.0
	    set_material_2.width, set_material_2.height = 140.0, 100.0
	    capture_attribute_002_3.width, capture_attribute_002_3.height = 140.0, 100.0
	    reroute_7.width, reroute_7.height = 100.0, 100.0
	    group_input_001_8.width, group_input_001_8.height = 140.0, 100.0
	    group_input_002_6.width, group_input_002_6.height = 140.0, 100.0
	    object_info_2.width, object_info_2.height = 140.0, 100.0
	    transform_geometry_1.width, transform_geometry_1.height = 140.0, 100.0
	    group_input_003_5.width, group_input_003_5.height = 140.0, 100.0
	    group_input_004_4.width, group_input_004_4.height = 140.0, 100.0
	    set_curve_radius_2.width, set_curve_radius_2.height = 140.0, 100.0
	    reroute_001_7.width, reroute_001_7.height = 100.0, 100.0
	    reroute_002_5.width, reroute_002_5.height = 100.0, 100.0
	    resample_curve_3.width, resample_curve_3.height = 140.0, 100.0
	    switch_5.width, switch_5.height = 140.0, 100.0
	    compare_6.width, compare_6.height = 140.0, 100.0
	    reroute_005_4.width, reroute_005_4.height = 100.0, 100.0
	    group_input_005_5.width, group_input_005_5.height = 140.0, 100.0
	
	    #initialize stylized_hair links
	    #set_material_2.Geometry -> group_output_14.Geometry
	    stylized_hair.links.new(set_material_2.outputs[0], group_output_14.inputs[0])
	    #capture_attribute_2.Geometry -> curve_to_mesh_2.Curve
	    stylized_hair.links.new(capture_attribute_2.outputs[0], curve_to_mesh_2.inputs[0])
	    #set_curve_radius_2.Curve -> capture_attribute_2.Geometry
	    stylized_hair.links.new(set_curve_radius_2.outputs[0], capture_attribute_2.inputs[0])
	    #reroute_7.Output -> capture_attribute_2.Factor
	    stylized_hair.links.new(reroute_7.outputs[0], capture_attribute_2.inputs[1])
	    #capture_attribute_2.Factor -> combine_xyz_2.X
	    stylized_hair.links.new(capture_attribute_2.outputs[1], combine_xyz_2.inputs[0])
	    #curve_to_mesh_2.Mesh -> store_named_attribute_5.Geometry
	    stylized_hair.links.new(curve_to_mesh_2.outputs[0], store_named_attribute_5.inputs[0])
	    #combine_xyz_2.Vector -> store_named_attribute_5.Value
	    stylized_hair.links.new(combine_xyz_2.outputs[0], store_named_attribute_5.inputs[3])
	    #store_named_attribute_5.Geometry -> set_material_2.Geometry
	    stylized_hair.links.new(store_named_attribute_5.outputs[0], set_material_2.inputs[0])
	    #reroute_7.Output -> capture_attribute_002_3.Factor
	    stylized_hair.links.new(reroute_7.outputs[0], capture_attribute_002_3.inputs[1])
	    #capture_attribute_002_3.Factor -> combine_xyz_2.Y
	    stylized_hair.links.new(capture_attribute_002_3.outputs[1], combine_xyz_2.inputs[1])
	    #capture_attribute_002_3.Geometry -> curve_to_mesh_2.Profile Curve
	    stylized_hair.links.new(capture_attribute_002_3.outputs[0], curve_to_mesh_2.inputs[1])
	    #spline_parameter_4.Factor -> reroute_7.Input
	    stylized_hair.links.new(spline_parameter_4.outputs[0], reroute_7.inputs[0])
	    #group_input_001_8.Material -> set_material_2.Material
	    stylized_hair.links.new(group_input_001_8.outputs[2], set_material_2.inputs[2])
	    #group_input_002_6.Fill Caps -> curve_to_mesh_2.Fill Caps
	    stylized_hair.links.new(group_input_002_6.outputs[5], curve_to_mesh_2.inputs[2])
	    #group_input_12.Profile -> object_info_2.Object
	    stylized_hair.links.new(group_input_12.outputs[1], object_info_2.inputs[0])
	    #object_info_2.Geometry -> transform_geometry_1.Geometry
	    stylized_hair.links.new(object_info_2.outputs[4], transform_geometry_1.inputs[0])
	    #transform_geometry_1.Geometry -> capture_attribute_002_3.Geometry
	    stylized_hair.links.new(transform_geometry_1.outputs[0], capture_attribute_002_3.inputs[0])
	    #group_input_003_5.Curve Radius -> set_curve_radius_2.Radius
	    stylized_hair.links.new(group_input_003_5.outputs[3], set_curve_radius_2.inputs[2])
	    #group_input_004_4.Translation -> transform_geometry_1.Translation
	    stylized_hair.links.new(group_input_004_4.outputs[6], transform_geometry_1.inputs[1])
	    #group_input_004_4.Rotation -> transform_geometry_1.Rotation
	    stylized_hair.links.new(group_input_004_4.outputs[7], transform_geometry_1.inputs[2])
	    #group_input_004_4.Scale -> transform_geometry_1.Scale
	    stylized_hair.links.new(group_input_004_4.outputs[8], transform_geometry_1.inputs[3])
	    #group_input_12.Geometry -> reroute_001_7.Input
	    stylized_hair.links.new(group_input_12.outputs[0], reroute_001_7.inputs[0])
	    #reroute_001_7.Output -> reroute_002_5.Input
	    stylized_hair.links.new(reroute_001_7.outputs[0], reroute_002_5.inputs[0])
	    #reroute_005_4.Output -> resample_curve_3.Curve
	    stylized_hair.links.new(reroute_005_4.outputs[0], resample_curve_3.inputs[0])
	    #compare_6.Result -> switch_5.Switch
	    stylized_hair.links.new(compare_6.outputs[0], switch_5.inputs[0])
	    #reroute_005_4.Output -> switch_5.True
	    stylized_hair.links.new(reroute_005_4.outputs[0], switch_5.inputs[2])
	    #resample_curve_3.Curve -> switch_5.False
	    stylized_hair.links.new(resample_curve_3.outputs[0], switch_5.inputs[1])
	    #group_input_005_5.Resolution -> resample_curve_3.Count
	    stylized_hair.links.new(group_input_005_5.outputs[4], resample_curve_3.inputs[2])
	    #group_input_005_5.Resolution -> compare_6.A
	    stylized_hair.links.new(group_input_005_5.outputs[4], compare_6.inputs[2])
	    #switch_5.Output -> set_curve_radius_2.Curve
	    stylized_hair.links.new(switch_5.outputs[0], set_curve_radius_2.inputs[0])
	    #reroute_002_5.Output -> reroute_005_4.Input
	    stylized_hair.links.new(reroute_002_5.outputs[0], reroute_005_4.inputs[0])
	    return stylized_hair
	
	stylized_hair = stylized_hair_node_group()
	
	#initialize tube_mesh node group
	def tube_mesh_node_group():
	    tube_mesh = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Tube_Mesh")
	
	    tube_mesh.color_tag = 'NONE'
	    tube_mesh.description = ""
	    tube_mesh.default_group_node_width = 140
	    
	
	    tube_mesh.is_modifier = True
	
	    #tube_mesh interface
	    #Socket Geometry
	    geometry_socket_23 = tube_mesh.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_23.attribute_domain = 'POINT'
	
	    #Socket Geometry
	    geometry_socket_24 = tube_mesh.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_24.attribute_domain = 'POINT'
	
	    #Socket Material
	    material_socket_3 = tube_mesh.interface.new_socket(name = "Material", in_out='INPUT', socket_type = 'NodeSocketMaterial')
	    material_socket_3.attribute_domain = 'POINT'
	
	    #Socket Curve Radius
	    curve_radius_socket_2 = tube_mesh.interface.new_socket(name = "Curve Radius", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    curve_radius_socket_2.default_value = 1.0
	    curve_radius_socket_2.min_value = 0.0
	    curve_radius_socket_2.max_value = 3.4028234663852886e+38
	    curve_radius_socket_2.subtype = 'DISTANCE'
	    curve_radius_socket_2.attribute_domain = 'POINT'
	    curve_radius_socket_2.hide_value = True
	    curve_radius_socket_2.hide_in_modifier = True
	
	    #Socket Resolution
	    resolution_socket_2 = tube_mesh.interface.new_socket(name = "Resolution", in_out='INPUT', socket_type = 'NodeSocketInt')
	    resolution_socket_2.default_value = 32
	    resolution_socket_2.min_value = 3
	    resolution_socket_2.max_value = 512
	    resolution_socket_2.subtype = 'NONE'
	    resolution_socket_2.attribute_domain = 'POINT'
	
	    #Socket Width
	    width_socket_1 = tube_mesh.interface.new_socket(name = "Width", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    width_socket_1.default_value = 0.10000000149011612
	    width_socket_1.min_value = 0.0
	    width_socket_1.max_value = 3.4028234663852886e+38
	    width_socket_1.subtype = 'DISTANCE'
	    width_socket_1.attribute_domain = 'POINT'
	
	    #Socket Fill Caps
	    fill_caps_socket_1 = tube_mesh.interface.new_socket(name = "Fill Caps", in_out='INPUT', socket_type = 'NodeSocketBool')
	    fill_caps_socket_1.default_value = True
	    fill_caps_socket_1.attribute_domain = 'POINT'
	
	
	    #initialize tube_mesh nodes
	    #node Group Input
	    group_input_13 = tube_mesh.nodes.new("NodeGroupInput")
	    group_input_13.name = "Group Input"
	    group_input_13.outputs[1].hide = True
	    group_input_13.outputs[2].hide = True
	    group_input_13.outputs[5].hide = True
	    group_input_13.outputs[6].hide = True
	
	    #node Group Output
	    group_output_15 = tube_mesh.nodes.new("NodeGroupOutput")
	    group_output_15.name = "Group Output"
	    group_output_15.is_active_output = True
	
	    #node Curve to Mesh
	    curve_to_mesh_3 = tube_mesh.nodes.new("GeometryNodeCurveToMesh")
	    curve_to_mesh_3.name = "Curve to Mesh"
	    curve_to_mesh_3.hide = True
	
	    #node Capture Attribute
	    capture_attribute_3 = tube_mesh.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_3.name = "Capture Attribute"
	    capture_attribute_3.hide = True
	    capture_attribute_3.active_index = 0
	    capture_attribute_3.capture_items.clear()
	    capture_attribute_3.capture_items.new('FLOAT', "Factor")
	    capture_attribute_3.capture_items["Factor"].data_type = 'FLOAT'
	    capture_attribute_3.domain = 'POINT'
	
	    #node Spline Parameter
	    spline_parameter_5 = tube_mesh.nodes.new("GeometryNodeSplineParameter")
	    spline_parameter_5.name = "Spline Parameter"
	    spline_parameter_5.hide = True
	
	    #node Combine XYZ
	    combine_xyz_3 = tube_mesh.nodes.new("ShaderNodeCombineXYZ")
	    combine_xyz_3.name = "Combine XYZ"
	    combine_xyz_3.hide = True
	    #Z
	    combine_xyz_3.inputs[2].default_value = 0.0
	
	    #node Store Named Attribute
	    store_named_attribute_6 = tube_mesh.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_6.name = "Store Named Attribute"
	    store_named_attribute_6.data_type = 'FLOAT2'
	    store_named_attribute_6.domain = 'CORNER'
	    #Selection
	    store_named_attribute_6.inputs[1].default_value = True
	    #Name
	    store_named_attribute_6.inputs[2].default_value = "tube_mesh_UV"
	
	    #node Set Material
	    set_material_3 = tube_mesh.nodes.new("GeometryNodeSetMaterial")
	    set_material_3.name = "Set Material"
	    set_material_3.hide = True
	    #Selection
	    set_material_3.inputs[1].default_value = True
	
	    #node Curve Circle
	    curve_circle = tube_mesh.nodes.new("GeometryNodeCurvePrimitiveCircle")
	    curve_circle.name = "Curve Circle"
	    curve_circle.hide = True
	    curve_circle.mode = 'RADIUS'
	    #Resolution
	    curve_circle.inputs[0].default_value = 16
	
	    #node Capture Attribute.002
	    capture_attribute_002_4 = tube_mesh.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_002_4.name = "Capture Attribute.002"
	    capture_attribute_002_4.hide = True
	    capture_attribute_002_4.active_index = 0
	    capture_attribute_002_4.capture_items.clear()
	    capture_attribute_002_4.capture_items.new('FLOAT', "Factor")
	    capture_attribute_002_4.capture_items["Factor"].data_type = 'FLOAT'
	    capture_attribute_002_4.domain = 'POINT'
	
	    #node Reroute
	    reroute_8 = tube_mesh.nodes.new("NodeReroute")
	    reroute_8.name = "Reroute"
	    reroute_8.socket_idname = "NodeSocketFloat"
	    #node Group Input.001
	    group_input_001_9 = tube_mesh.nodes.new("NodeGroupInput")
	    group_input_001_9.name = "Group Input.001"
	    group_input_001_9.outputs[0].hide = True
	    group_input_001_9.outputs[2].hide = True
	    group_input_001_9.outputs[3].hide = True
	    group_input_001_9.outputs[4].hide = True
	    group_input_001_9.outputs[5].hide = True
	    group_input_001_9.outputs[6].hide = True
	
	    #node Group Input.002
	    group_input_002_7 = tube_mesh.nodes.new("NodeGroupInput")
	    group_input_002_7.name = "Group Input.002"
	    group_input_002_7.outputs[0].hide = True
	    group_input_002_7.outputs[1].hide = True
	    group_input_002_7.outputs[2].hide = True
	    group_input_002_7.outputs[3].hide = True
	    group_input_002_7.outputs[4].hide = True
	    group_input_002_7.outputs[6].hide = True
	
	    #node Set Curve Radius
	    set_curve_radius_3 = tube_mesh.nodes.new("GeometryNodeSetCurveRadius")
	    set_curve_radius_3.name = "Set Curve Radius"
	    set_curve_radius_3.hide = True
	    #Selection
	    set_curve_radius_3.inputs[1].default_value = True
	
	    #node Group Input.003
	    group_input_003_6 = tube_mesh.nodes.new("NodeGroupInput")
	    group_input_003_6.name = "Group Input.003"
	    group_input_003_6.outputs[0].hide = True
	    group_input_003_6.outputs[1].hide = True
	    group_input_003_6.outputs[3].hide = True
	    group_input_003_6.outputs[4].hide = True
	    group_input_003_6.outputs[5].hide = True
	    group_input_003_6.outputs[6].hide = True
	
	    #node Resample Curve
	    resample_curve_4 = tube_mesh.nodes.new("GeometryNodeResampleCurve")
	    resample_curve_4.name = "Resample Curve"
	    resample_curve_4.hide = True
	    resample_curve_4.keep_last_segment = False
	    resample_curve_4.mode = 'COUNT'
	    #Selection
	    resample_curve_4.inputs[1].default_value = True
	
	    #node Switch
	    switch_6 = tube_mesh.nodes.new("GeometryNodeSwitch")
	    switch_6.name = "Switch"
	    switch_6.hide = True
	    switch_6.input_type = 'GEOMETRY'
	
	    #node Compare
	    compare_7 = tube_mesh.nodes.new("FunctionNodeCompare")
	    compare_7.name = "Compare"
	    compare_7.hide = True
	    compare_7.data_type = 'INT'
	    compare_7.mode = 'ELEMENT'
	    compare_7.operation = 'LESS_THAN'
	    #B_INT
	    compare_7.inputs[3].default_value = 2
	
	    #node Reroute.003
	    reroute_003_3 = tube_mesh.nodes.new("NodeReroute")
	    reroute_003_3.name = "Reroute.003"
	    reroute_003_3.socket_idname = "NodeSocketGeometry"
	    #node Group Input.004
	    group_input_004_5 = tube_mesh.nodes.new("NodeGroupInput")
	    group_input_004_5.name = "Group Input.004"
	    group_input_004_5.outputs[0].hide = True
	    group_input_004_5.outputs[1].hide = True
	    group_input_004_5.outputs[2].hide = True
	    group_input_004_5.outputs[4].hide = True
	    group_input_004_5.outputs[5].hide = True
	    group_input_004_5.outputs[6].hide = True
	
	    #node Reroute.006
	    reroute_006_4 = tube_mesh.nodes.new("NodeReroute")
	    reroute_006_4.name = "Reroute.006"
	    reroute_006_4.socket_idname = "NodeSocketFloatDistance"
	    #node Reroute.007
	    reroute_007_4 = tube_mesh.nodes.new("NodeReroute")
	    reroute_007_4.name = "Reroute.007"
	    reroute_007_4.socket_idname = "NodeSocketFloatDistance"
	    #node Reroute.008
	    reroute_008_4 = tube_mesh.nodes.new("NodeReroute")
	    reroute_008_4.name = "Reroute.008"
	    reroute_008_4.socket_idname = "NodeSocketInt"
	    #node Reroute.009
	    reroute_009_3 = tube_mesh.nodes.new("NodeReroute")
	    reroute_009_3.name = "Reroute.009"
	    reroute_009_3.socket_idname = "NodeSocketInt"
	
	
	
	
	    #Set locations
	    group_input_13.location = (-340.0, 0.0)
	    group_output_15.location = (953.9598388671875, 58.388336181640625)
	    curve_to_mesh_3.location = (466.6881408691406, -14.526612281799316)
	    capture_attribute_3.location = (281.749755859375, -33.53998565673828)
	    spline_parameter_5.location = (84.9455795288086, -92.41136169433594)
	    combine_xyz_3.location = (466.4966735839844, -101.40799713134766)
	    store_named_attribute_6.location = (632.5167846679688, 66.61811828613281)
	    set_material_3.location = (793.743896484375, 32.40200424194336)
	    curve_circle.location = (87.1727523803711, -56.81591033935547)
	    capture_attribute_002_4.location = (283.9133605957031, -74.45401000976562)
	    reroute_8.location = (247.05758666992188, -91.37664031982422)
	    group_input_001_9.location = (790.8096313476562, 1.5365350246429443)
	    group_input_002_7.location = (462.2091369628906, -43.022979736328125)
	    set_curve_radius_3.location = (93.72252655029297, -22.188615798950195)
	    group_input_003_6.location = (-339.80987548828125, 120.61366271972656)
	    resample_curve_4.location = (-105.32349395751953, -15.050445556640625)
	    switch_6.location = (-105.3993148803711, 19.942108154296875)
	    compare_7.location = (-108.61988830566406, 54.5004768371582)
	    reroute_003_3.location = (-169.31845092773438, -19.093738555908203)
	    group_input_004_5.location = (-340.0, 59.733726501464844)
	    reroute_006_4.location = (58.51203918457031, -44.47895431518555)
	    reroute_007_4.location = (51.51875686645508, 91.57743072509766)
	    reroute_008_4.location = (-135.7594451904297, -35.677268981933594)
	    reroute_009_3.location = (-140.79913330078125, 26.496713638305664)
	
	    #Set dimensions
	    group_input_13.width, group_input_13.height = 140.0, 100.0
	    group_output_15.width, group_output_15.height = 140.0, 100.0
	    curve_to_mesh_3.width, curve_to_mesh_3.height = 140.0, 100.0
	    capture_attribute_3.width, capture_attribute_3.height = 140.0, 100.0
	    spline_parameter_5.width, spline_parameter_5.height = 140.0, 100.0
	    combine_xyz_3.width, combine_xyz_3.height = 140.0, 100.0
	    store_named_attribute_6.width, store_named_attribute_6.height = 140.0, 100.0
	    set_material_3.width, set_material_3.height = 140.0, 100.0
	    curve_circle.width, curve_circle.height = 140.0, 100.0
	    capture_attribute_002_4.width, capture_attribute_002_4.height = 140.0, 100.0
	    reroute_8.width, reroute_8.height = 100.0, 100.0
	    group_input_001_9.width, group_input_001_9.height = 140.0, 100.0
	    group_input_002_7.width, group_input_002_7.height = 140.0, 100.0
	    set_curve_radius_3.width, set_curve_radius_3.height = 140.0, 100.0
	    group_input_003_6.width, group_input_003_6.height = 140.0, 100.0
	    resample_curve_4.width, resample_curve_4.height = 140.0, 100.0
	    switch_6.width, switch_6.height = 140.0, 100.0
	    compare_7.width, compare_7.height = 140.0, 100.0
	    reroute_003_3.width, reroute_003_3.height = 100.0, 100.0
	    group_input_004_5.width, group_input_004_5.height = 140.0, 100.0
	    reroute_006_4.width, reroute_006_4.height = 100.0, 100.0
	    reroute_007_4.width, reroute_007_4.height = 100.0, 100.0
	    reroute_008_4.width, reroute_008_4.height = 100.0, 100.0
	    reroute_009_3.width, reroute_009_3.height = 100.0, 100.0
	
	    #initialize tube_mesh links
	    #set_material_3.Geometry -> group_output_15.Geometry
	    tube_mesh.links.new(set_material_3.outputs[0], group_output_15.inputs[0])
	    #capture_attribute_3.Geometry -> curve_to_mesh_3.Curve
	    tube_mesh.links.new(capture_attribute_3.outputs[0], curve_to_mesh_3.inputs[0])
	    #set_curve_radius_3.Curve -> capture_attribute_3.Geometry
	    tube_mesh.links.new(set_curve_radius_3.outputs[0], capture_attribute_3.inputs[0])
	    #reroute_8.Output -> capture_attribute_3.Factor
	    tube_mesh.links.new(reroute_8.outputs[0], capture_attribute_3.inputs[1])
	    #capture_attribute_3.Factor -> combine_xyz_3.X
	    tube_mesh.links.new(capture_attribute_3.outputs[1], combine_xyz_3.inputs[0])
	    #curve_to_mesh_3.Mesh -> store_named_attribute_6.Geometry
	    tube_mesh.links.new(curve_to_mesh_3.outputs[0], store_named_attribute_6.inputs[0])
	    #combine_xyz_3.Vector -> store_named_attribute_6.Value
	    tube_mesh.links.new(combine_xyz_3.outputs[0], store_named_attribute_6.inputs[3])
	    #store_named_attribute_6.Geometry -> set_material_3.Geometry
	    tube_mesh.links.new(store_named_attribute_6.outputs[0], set_material_3.inputs[0])
	    #curve_circle.Curve -> capture_attribute_002_4.Geometry
	    tube_mesh.links.new(curve_circle.outputs[0], capture_attribute_002_4.inputs[0])
	    #reroute_8.Output -> capture_attribute_002_4.Factor
	    tube_mesh.links.new(reroute_8.outputs[0], capture_attribute_002_4.inputs[1])
	    #capture_attribute_002_4.Factor -> combine_xyz_3.Y
	    tube_mesh.links.new(capture_attribute_002_4.outputs[1], combine_xyz_3.inputs[1])
	    #capture_attribute_002_4.Geometry -> curve_to_mesh_3.Profile Curve
	    tube_mesh.links.new(capture_attribute_002_4.outputs[0], curve_to_mesh_3.inputs[1])
	    #group_input_13.Width -> curve_circle.Radius
	    tube_mesh.links.new(group_input_13.outputs[4], curve_circle.inputs[4])
	    #spline_parameter_5.Factor -> reroute_8.Input
	    tube_mesh.links.new(spline_parameter_5.outputs[0], reroute_8.inputs[0])
	    #group_input_001_9.Material -> set_material_3.Material
	    tube_mesh.links.new(group_input_001_9.outputs[1], set_material_3.inputs[2])
	    #group_input_002_7.Fill Caps -> curve_to_mesh_3.Fill Caps
	    tube_mesh.links.new(group_input_002_7.outputs[5], curve_to_mesh_3.inputs[2])
	    #reroute_006_4.Output -> set_curve_radius_3.Radius
	    tube_mesh.links.new(reroute_006_4.outputs[0], set_curve_radius_3.inputs[2])
	    #reroute_003_3.Output -> resample_curve_4.Curve
	    tube_mesh.links.new(reroute_003_3.outputs[0], resample_curve_4.inputs[0])
	    #compare_7.Result -> switch_6.Switch
	    tube_mesh.links.new(compare_7.outputs[0], switch_6.inputs[0])
	    #reroute_003_3.Output -> switch_6.True
	    tube_mesh.links.new(reroute_003_3.outputs[0], switch_6.inputs[2])
	    #resample_curve_4.Curve -> switch_6.False
	    tube_mesh.links.new(resample_curve_4.outputs[0], switch_6.inputs[1])
	    #reroute_008_4.Output -> resample_curve_4.Count
	    tube_mesh.links.new(reroute_008_4.outputs[0], resample_curve_4.inputs[2])
	    #group_input_13.Geometry -> reroute_003_3.Input
	    tube_mesh.links.new(group_input_13.outputs[0], reroute_003_3.inputs[0])
	    #reroute_007_4.Output -> reroute_006_4.Input
	    tube_mesh.links.new(reroute_007_4.outputs[0], reroute_006_4.inputs[0])
	    #group_input_003_6.Curve Radius -> reroute_007_4.Input
	    tube_mesh.links.new(group_input_003_6.outputs[2], reroute_007_4.inputs[0])
	    #reroute_009_3.Output -> reroute_008_4.Input
	    tube_mesh.links.new(reroute_009_3.outputs[0], reroute_008_4.inputs[0])
	    #group_input_004_5.Resolution -> reroute_009_3.Input
	    tube_mesh.links.new(group_input_004_5.outputs[3], reroute_009_3.inputs[0])
	    #reroute_009_3.Output -> compare_7.A
	    tube_mesh.links.new(reroute_009_3.outputs[0], compare_7.inputs[2])
	    #switch_6.Output -> set_curve_radius_3.Curve
	    tube_mesh.links.new(switch_6.outputs[0], set_curve_radius_3.inputs[0])
	    return tube_mesh
	
	tube_mesh = tube_mesh_node_group()
	
	#initialize tube_ribbon node group
	def tube_ribbon_node_group():
	    tube_ribbon = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Tube_Ribbon")
	
	    tube_ribbon.color_tag = 'NONE'
	    tube_ribbon.description = ""
	    tube_ribbon.default_group_node_width = 140
	    
	
	    tube_ribbon.is_modifier = True
	
	    #tube_ribbon interface
	    #Socket Geometry
	    geometry_socket_25 = tube_ribbon.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_25.attribute_domain = 'POINT'
	
	    #Socket Geometry
	    geometry_socket_26 = tube_ribbon.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_26.attribute_domain = 'POINT'
	
	    #Socket Material
	    material_socket_4 = tube_ribbon.interface.new_socket(name = "Material", in_out='INPUT', socket_type = 'NodeSocketMaterial')
	    material_socket_4.attribute_domain = 'POINT'
	
	    #Socket Curve Radius
	    curve_radius_socket_3 = tube_ribbon.interface.new_socket(name = "Curve Radius", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    curve_radius_socket_3.default_value = 1.0
	    curve_radius_socket_3.min_value = 0.0
	    curve_radius_socket_3.max_value = 3.4028234663852886e+38
	    curve_radius_socket_3.subtype = 'DISTANCE'
	    curve_radius_socket_3.attribute_domain = 'POINT'
	    curve_radius_socket_3.hide_value = True
	    curve_radius_socket_3.hide_in_modifier = True
	
	    #Socket Ribbon Count
	    ribbon_count_socket = tube_ribbon.interface.new_socket(name = "Ribbon Count", in_out='INPUT', socket_type = 'NodeSocketInt')
	    ribbon_count_socket.default_value = 8
	    ribbon_count_socket.min_value = 1
	    ribbon_count_socket.max_value = 180
	    ribbon_count_socket.subtype = 'NONE'
	    ribbon_count_socket.attribute_domain = 'POINT'
	
	    #Socket Resolution
	    resolution_socket_3 = tube_ribbon.interface.new_socket(name = "Resolution", in_out='INPUT', socket_type = 'NodeSocketInt')
	    resolution_socket_3.default_value = 0
	    resolution_socket_3.min_value = 2
	    resolution_socket_3.max_value = 512
	    resolution_socket_3.subtype = 'NONE'
	    resolution_socket_3.attribute_domain = 'POINT'
	
	    #Socket Width
	    width_socket_2 = tube_ribbon.interface.new_socket(name = "Width", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    width_socket_2.default_value = 0.10000000149011612
	    width_socket_2.min_value = 0.0
	    width_socket_2.max_value = 3.4028234663852886e+38
	    width_socket_2.subtype = 'DISTANCE'
	    width_socket_2.attribute_domain = 'POINT'
	
	
	    #initialize tube_ribbon nodes
	    #node Group Input
	    group_input_14 = tube_ribbon.nodes.new("NodeGroupInput")
	    group_input_14.name = "Group Input"
	    group_input_14.outputs[1].hide = True
	    group_input_14.outputs[2].hide = True
	    group_input_14.outputs[3].hide = True
	    group_input_14.outputs[6].hide = True
	
	    #node Group Output
	    group_output_16 = tube_ribbon.nodes.new("NodeGroupOutput")
	    group_output_16.name = "Group Output"
	    group_output_16.is_active_output = True
	
	    #node Curve to Mesh
	    curve_to_mesh_4 = tube_ribbon.nodes.new("GeometryNodeCurveToMesh")
	    curve_to_mesh_4.name = "Curve to Mesh"
	    curve_to_mesh_4.hide = True
	    #Fill Caps
	    curve_to_mesh_4.inputs[2].default_value = True
	
	    #node Capture Attribute
	    capture_attribute_4 = tube_ribbon.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_4.name = "Capture Attribute"
	    capture_attribute_4.hide = True
	    capture_attribute_4.active_index = 0
	    capture_attribute_4.capture_items.clear()
	    capture_attribute_4.capture_items.new('FLOAT', "Factor")
	    capture_attribute_4.capture_items["Factor"].data_type = 'FLOAT'
	    capture_attribute_4.domain = 'POINT'
	
	    #node Spline Parameter
	    spline_parameter_6 = tube_ribbon.nodes.new("GeometryNodeSplineParameter")
	    spline_parameter_6.name = "Spline Parameter"
	    spline_parameter_6.hide = True
	
	    #node Combine XYZ
	    combine_xyz_4 = tube_ribbon.nodes.new("ShaderNodeCombineXYZ")
	    combine_xyz_4.name = "Combine XYZ"
	    combine_xyz_4.hide = True
	    #Z
	    combine_xyz_4.inputs[2].default_value = 0.0
	
	    #node Store Named Attribute
	    store_named_attribute_7 = tube_ribbon.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_7.name = "Store Named Attribute"
	    store_named_attribute_7.data_type = 'FLOAT2'
	    store_named_attribute_7.domain = 'CORNER'
	    #Selection
	    store_named_attribute_7.inputs[1].default_value = True
	    #Name
	    store_named_attribute_7.inputs[2].default_value = "ribbon_mesh_UV"
	
	    #node Set Material
	    set_material_4 = tube_ribbon.nodes.new("GeometryNodeSetMaterial")
	    set_material_4.name = "Set Material"
	    set_material_4.hide = True
	    #Selection
	    set_material_4.inputs[1].default_value = True
	
	    #node Capture Attribute.002
	    capture_attribute_002_5 = tube_ribbon.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_002_5.name = "Capture Attribute.002"
	    capture_attribute_002_5.hide = True
	    capture_attribute_002_5.active_index = 0
	    capture_attribute_002_5.capture_items.clear()
	    capture_attribute_002_5.capture_items.new('FLOAT', "Factor")
	    capture_attribute_002_5.capture_items["Factor"].data_type = 'FLOAT'
	    capture_attribute_002_5.domain = 'POINT'
	
	    #node Reroute
	    reroute_9 = tube_ribbon.nodes.new("NodeReroute")
	    reroute_9.name = "Reroute"
	    reroute_9.socket_idname = "NodeSocketFloat"
	    #node Group Input.001
	    group_input_001_10 = tube_ribbon.nodes.new("NodeGroupInput")
	    group_input_001_10.name = "Group Input.001"
	    group_input_001_10.outputs[0].hide = True
	    group_input_001_10.outputs[2].hide = True
	    group_input_001_10.outputs[3].hide = True
	    group_input_001_10.outputs[4].hide = True
	    group_input_001_10.outputs[5].hide = True
	    group_input_001_10.outputs[6].hide = True
	
	    #node Curve Line
	    curve_line = tube_ribbon.nodes.new("GeometryNodeCurvePrimitiveLine")
	    curve_line.name = "Curve Line"
	    curve_line.hide = True
	    curve_line.mode = 'POINTS'
	
	    #node Combine XYZ.001
	    combine_xyz_001_1 = tube_ribbon.nodes.new("ShaderNodeCombineXYZ")
	    combine_xyz_001_1.name = "Combine XYZ.001"
	    combine_xyz_001_1.hide = True
	    #Y
	    combine_xyz_001_1.inputs[1].default_value = 0.0
	    #Z
	    combine_xyz_001_1.inputs[2].default_value = 0.0
	
	    #node Math.001
	    math_001_2 = tube_ribbon.nodes.new("ShaderNodeMath")
	    math_001_2.name = "Math.001"
	    math_001_2.hide = True
	    math_001_2.operation = 'MULTIPLY'
	    math_001_2.use_clamp = False
	    #Value_001
	    math_001_2.inputs[1].default_value = -1.0
	
	    #node Combine XYZ.002
	    combine_xyz_002 = tube_ribbon.nodes.new("ShaderNodeCombineXYZ")
	    combine_xyz_002.name = "Combine XYZ.002"
	    combine_xyz_002.hide = True
	    #Y
	    combine_xyz_002.inputs[1].default_value = 0.0
	    #Z
	    combine_xyz_002.inputs[2].default_value = 0.0
	
	    #node Reroute.001
	    reroute_001_8 = tube_ribbon.nodes.new("NodeReroute")
	    reroute_001_8.name = "Reroute.001"
	    reroute_001_8.socket_idname = "NodeSocketFloatDistance"
	    #node Resample Curve
	    resample_curve_5 = tube_ribbon.nodes.new("GeometryNodeResampleCurve")
	    resample_curve_5.name = "Resample Curve"
	    resample_curve_5.hide = True
	    resample_curve_5.keep_last_segment = False
	    resample_curve_5.mode = 'COUNT'
	    #Selection
	    resample_curve_5.inputs[1].default_value = True
	
	    #node Switch
	    switch_7 = tube_ribbon.nodes.new("GeometryNodeSwitch")
	    switch_7.name = "Switch"
	    switch_7.hide = True
	    switch_7.input_type = 'GEOMETRY'
	
	    #node Group Input.002
	    group_input_002_8 = tube_ribbon.nodes.new("NodeGroupInput")
	    group_input_002_8.name = "Group Input.002"
	    group_input_002_8.outputs[0].hide = True
	    group_input_002_8.outputs[1].hide = True
	    group_input_002_8.outputs[2].hide = True
	    group_input_002_8.outputs[3].hide = True
	    group_input_002_8.outputs[5].hide = True
	    group_input_002_8.outputs[6].hide = True
	
	    #node Compare
	    compare_8 = tube_ribbon.nodes.new("FunctionNodeCompare")
	    compare_8.name = "Compare"
	    compare_8.hide = True
	    compare_8.data_type = 'INT'
	    compare_8.mode = 'ELEMENT'
	    compare_8.operation = 'LESS_THAN'
	    #B_INT
	    compare_8.inputs[3].default_value = 2
	
	    #node Reroute.002
	    reroute_002_6 = tube_ribbon.nodes.new("NodeReroute")
	    reroute_002_6.name = "Reroute.002"
	    reroute_002_6.socket_idname = "NodeSocketGeometry"
	    #node Frame
	    frame_5 = tube_ribbon.nodes.new("NodeFrame")
	    frame_5.name = "Frame"
	    frame_5.label_size = 20
	    frame_5.shrink = True
	
	    #node Join Geometry
	    join_geometry_2 = tube_ribbon.nodes.new("GeometryNodeJoinGeometry")
	    join_geometry_2.name = "Join Geometry"
	
	    #node Set Curve Tilt
	    set_curve_tilt = tube_ribbon.nodes.new("GeometryNodeSetCurveTilt")
	    set_curve_tilt.name = "Set Curve Tilt"
	    #Selection
	    set_curve_tilt.inputs[1].default_value = True
	
	    #node Repeat Input
	    repeat_input_2 = tube_ribbon.nodes.new("GeometryNodeRepeatInput")
	    repeat_input_2.name = "Repeat Input"
	    #node Repeat Output
	    repeat_output_2 = tube_ribbon.nodes.new("GeometryNodeRepeatOutput")
	    repeat_output_2.name = "Repeat Output"
	    repeat_output_2.active_index = 1
	    repeat_output_2.inspection_index = 0
	    repeat_output_2.repeat_items.clear()
	    # Create item "Geometry"
	    repeat_output_2.repeat_items.new('GEOMETRY', "Geometry")
	    # Create item "Index"
	    repeat_output_2.repeat_items.new('INT', "Index")
	
	    #node Math.002
	    math_002 = tube_ribbon.nodes.new("ShaderNodeMath")
	    math_002.name = "Math.002"
	    math_002.hide = True
	    math_002.operation = 'DIVIDE'
	    math_002.use_clamp = False
	    #Value
	    math_002.inputs[0].default_value = 180.0
	
	    #node Group Input.003
	    group_input_003_7 = tube_ribbon.nodes.new("NodeGroupInput")
	    group_input_003_7.name = "Group Input.003"
	    group_input_003_7.outputs[0].hide = True
	    group_input_003_7.outputs[1].hide = True
	    group_input_003_7.outputs[2].hide = True
	    group_input_003_7.outputs[4].hide = True
	    group_input_003_7.outputs[5].hide = True
	    group_input_003_7.outputs[6].hide = True
	
	    #node Group Input.004
	    group_input_004_6 = tube_ribbon.nodes.new("NodeGroupInput")
	    group_input_004_6.name = "Group Input.004"
	    group_input_004_6.outputs[0].hide = True
	    group_input_004_6.outputs[1].hide = True
	    group_input_004_6.outputs[2].hide = True
	    group_input_004_6.outputs[4].hide = True
	    group_input_004_6.outputs[5].hide = True
	    group_input_004_6.outputs[6].hide = True
	
	    #node Math.003
	    math_003 = tube_ribbon.nodes.new("ShaderNodeMath")
	    math_003.name = "Math.003"
	    math_003.hide = True
	    math_003.operation = 'ADD'
	    math_003.use_clamp = False
	    #Value_001
	    math_003.inputs[1].default_value = 1.0
	
	    #node Math.004
	    math_004 = tube_ribbon.nodes.new("ShaderNodeMath")
	    math_004.name = "Math.004"
	    math_004.hide = True
	    math_004.operation = 'MULTIPLY'
	    math_004.use_clamp = False
	
	    #node Reroute.003
	    reroute_003_4 = tube_ribbon.nodes.new("NodeReroute")
	    reroute_003_4.name = "Reroute.003"
	    reroute_003_4.socket_idname = "NodeSocketInt"
	    #node Curve Tilt
	    curve_tilt = tube_ribbon.nodes.new("GeometryNodeInputCurveTilt")
	    curve_tilt.name = "Curve Tilt"
	    curve_tilt.hide = True
	
	    #node Math.005
	    math_005_1 = tube_ribbon.nodes.new("ShaderNodeMath")
	    math_005_1.name = "Math.005"
	    math_005_1.hide = True
	    math_005_1.operation = 'ADD'
	    math_005_1.use_clamp = False
	
	    #node Set Curve Radius
	    set_curve_radius_4 = tube_ribbon.nodes.new("GeometryNodeSetCurveRadius")
	    set_curve_radius_4.name = "Set Curve Radius"
	    set_curve_radius_4.hide = True
	    #Selection
	    set_curve_radius_4.inputs[1].default_value = True
	
	    #node Group Input.005
	    group_input_005_6 = tube_ribbon.nodes.new("NodeGroupInput")
	    group_input_005_6.name = "Group Input.005"
	    group_input_005_6.outputs[0].hide = True
	    group_input_005_6.outputs[1].hide = True
	    group_input_005_6.outputs[3].hide = True
	    group_input_005_6.outputs[4].hide = True
	    group_input_005_6.outputs[5].hide = True
	    group_input_005_6.outputs[6].hide = True
	
	    #node Reroute.004
	    reroute_004_5 = tube_ribbon.nodes.new("NodeReroute")
	    reroute_004_5.name = "Reroute.004"
	    reroute_004_5.socket_idname = "NodeSocketFloatDistance"
	    #node Reroute.005
	    reroute_005_5 = tube_ribbon.nodes.new("NodeReroute")
	    reroute_005_5.name = "Reroute.005"
	    reroute_005_5.socket_idname = "NodeSocketFloatDistance"
	
	    #Process zone input Repeat Input
	    repeat_input_2.pair_with_output(repeat_output_2)
	    #Item_2
	    repeat_input_2.inputs[2].default_value = 0
	
	
	
	
	    #Set parents
	    group_input_14.parent = frame_5
	    curve_to_mesh_4.parent = frame_5
	    capture_attribute_4.parent = frame_5
	    spline_parameter_6.parent = frame_5
	    combine_xyz_4.parent = frame_5
	    store_named_attribute_7.parent = frame_5
	    set_material_4.parent = frame_5
	    capture_attribute_002_5.parent = frame_5
	    reroute_9.parent = frame_5
	    group_input_001_10.parent = frame_5
	    curve_line.parent = frame_5
	    combine_xyz_001_1.parent = frame_5
	    math_001_2.parent = frame_5
	    combine_xyz_002.parent = frame_5
	    reroute_001_8.parent = frame_5
	    resample_curve_5.parent = frame_5
	    switch_7.parent = frame_5
	    group_input_002_8.parent = frame_5
	    compare_8.parent = frame_5
	    reroute_002_6.parent = frame_5
	    set_curve_tilt.parent = frame_5
	    math_004.parent = frame_5
	    math_005_1.parent = frame_5
	    set_curve_radius_4.parent = frame_5
	    group_input_005_6.parent = frame_5
	    reroute_004_5.parent = frame_5
	    reroute_005_5.parent = frame_5
	
	    #Set locations
	    group_input_14.location = (46.5567626953125, -187.68907165527344)
	    group_output_16.location = (1687.6083984375, 27.941242218017578)
	    curve_to_mesh_4.location = (937.7008666992188, -218.34669494628906)
	    capture_attribute_4.location = (764.834716796875, -223.1929168701172)
	    spline_parameter_6.location = (408.7358093261719, -288.16595458984375)
	    combine_xyz_4.location = (937.5093383789062, -281.03155517578125)
	    store_named_attribute_7.location = (1093.46923828125, -121.07095336914062)
	    set_material_4.location = (1254.6962890625, -155.2870635986328)
	    capture_attribute_002_5.location = (766.9982299804688, -262.14312744140625)
	    reroute_9.location = (566.0176391601562, -285.51812744140625)
	    group_input_001_10.location = (1251.76220703125, -186.1525421142578)
	    curve_line.location = (409.7470397949219, -252.2234649658203)
	    combine_xyz_001_1.location = (242.35899353027344, -260.64910888671875)
	    math_001_2.location = (247.1505889892578, -332.52447509765625)
	    combine_xyz_002.location = (245.62991333007812, -296.69708251953125)
	    reroute_001_8.location = (199.33338928222656, -265.65771484375)
	    resample_curve_5.location = (380.4243469238281, -216.19468688964844)
	    switch_7.location = (380.3485412597656, -181.20213317871094)
	    group_input_002_8.location = (375.72821044921875, -86.50663757324219)
	    compare_8.location = (377.1279602050781, -146.6437530517578)
	    reroute_002_6.location = (333.6315612792969, -213.35231018066406)
	    frame_5.location = (-58.76470947265625, -48.17646789550781)
	    join_geometry_2.location = (1331.0086669921875, 47.14059066772461)
	    set_curve_tilt.location = (192.23997497558594, -54.01100158691406)
	    repeat_input_2.location = (-184.79876708984375, 46.944000244140625)
	    repeat_output_2.location = (1511.4083251953125, 27.655336380004883)
	    math_002.location = (-195.4779510498047, -161.6897735595703)
	    group_input_003_7.location = (-346.3707580566406, 47.1754035949707)
	    group_input_004_6.location = (-353.25665283203125, -145.0489044189453)
	    math_003.location = (1134.1580810546875, -24.601409912109375)
	    math_004.location = (30.277496337890625, -106.62132263183594)
	    reroute_003_4.location = (-25.963211059570312, -31.35608673095703)
	    curve_tilt.location = (-197.5312957763672, -198.6190185546875)
	    math_005_1.location = (31.753875732421875, -145.03323364257812)
	    set_curve_radius_4.location = (591.83837890625, -194.33396911621094)
	    group_input_005_6.location = (377.0597229003906, -29.650436401367188)
	    reroute_004_5.location = (563.5545654296875, -215.4977264404297)
	    reroute_005_5.location = (561.7288208007812, -64.61457824707031)
	
	    #Set dimensions
	    group_input_14.width, group_input_14.height = 140.0, 100.0
	    group_output_16.width, group_output_16.height = 140.0, 100.0
	    curve_to_mesh_4.width, curve_to_mesh_4.height = 140.0, 100.0
	    capture_attribute_4.width, capture_attribute_4.height = 140.0, 100.0
	    spline_parameter_6.width, spline_parameter_6.height = 140.0, 100.0
	    combine_xyz_4.width, combine_xyz_4.height = 140.0, 100.0
	    store_named_attribute_7.width, store_named_attribute_7.height = 140.0, 100.0
	    set_material_4.width, set_material_4.height = 140.0, 100.0
	    capture_attribute_002_5.width, capture_attribute_002_5.height = 140.0, 100.0
	    reroute_9.width, reroute_9.height = 100.0, 100.0
	    group_input_001_10.width, group_input_001_10.height = 140.0, 100.0
	    curve_line.width, curve_line.height = 140.0, 100.0
	    combine_xyz_001_1.width, combine_xyz_001_1.height = 140.0, 100.0
	    math_001_2.width, math_001_2.height = 140.0, 100.0
	    combine_xyz_002.width, combine_xyz_002.height = 140.0, 100.0
	    reroute_001_8.width, reroute_001_8.height = 100.0, 100.0
	    resample_curve_5.width, resample_curve_5.height = 140.0, 100.0
	    switch_7.width, switch_7.height = 140.0, 100.0
	    group_input_002_8.width, group_input_002_8.height = 140.0, 100.0
	    compare_8.width, compare_8.height = 140.0, 100.0
	    reroute_002_6.width, reroute_002_6.height = 100.0, 100.0
	    frame_5.width, frame_5.height = 1424.3529052734375, 388.32354736328125
	    join_geometry_2.width, join_geometry_2.height = 140.0, 100.0
	    set_curve_tilt.width, set_curve_tilt.height = 140.0, 100.0
	    repeat_input_2.width, repeat_input_2.height = 140.0, 100.0
	    repeat_output_2.width, repeat_output_2.height = 140.0, 100.0
	    math_002.width, math_002.height = 140.0, 100.0
	    group_input_003_7.width, group_input_003_7.height = 140.0, 100.0
	    group_input_004_6.width, group_input_004_6.height = 140.0, 100.0
	    math_003.width, math_003.height = 140.0, 100.0
	    math_004.width, math_004.height = 140.0, 100.0
	    reroute_003_4.width, reroute_003_4.height = 100.0, 100.0
	    curve_tilt.width, curve_tilt.height = 140.0, 100.0
	    math_005_1.width, math_005_1.height = 140.0, 100.0
	    set_curve_radius_4.width, set_curve_radius_4.height = 140.0, 100.0
	    group_input_005_6.width, group_input_005_6.height = 140.0, 100.0
	    reroute_004_5.width, reroute_004_5.height = 100.0, 100.0
	    reroute_005_5.width, reroute_005_5.height = 100.0, 100.0
	
	    #initialize tube_ribbon links
	    #capture_attribute_4.Geometry -> curve_to_mesh_4.Curve
	    tube_ribbon.links.new(capture_attribute_4.outputs[0], curve_to_mesh_4.inputs[0])
	    #reroute_9.Output -> capture_attribute_4.Factor
	    tube_ribbon.links.new(reroute_9.outputs[0], capture_attribute_4.inputs[1])
	    #capture_attribute_4.Factor -> combine_xyz_4.X
	    tube_ribbon.links.new(capture_attribute_4.outputs[1], combine_xyz_4.inputs[0])
	    #curve_to_mesh_4.Mesh -> store_named_attribute_7.Geometry
	    tube_ribbon.links.new(curve_to_mesh_4.outputs[0], store_named_attribute_7.inputs[0])
	    #combine_xyz_4.Vector -> store_named_attribute_7.Value
	    tube_ribbon.links.new(combine_xyz_4.outputs[0], store_named_attribute_7.inputs[3])
	    #store_named_attribute_7.Geometry -> set_material_4.Geometry
	    tube_ribbon.links.new(store_named_attribute_7.outputs[0], set_material_4.inputs[0])
	    #reroute_9.Output -> capture_attribute_002_5.Factor
	    tube_ribbon.links.new(reroute_9.outputs[0], capture_attribute_002_5.inputs[1])
	    #capture_attribute_002_5.Factor -> combine_xyz_4.Y
	    tube_ribbon.links.new(capture_attribute_002_5.outputs[1], combine_xyz_4.inputs[1])
	    #capture_attribute_002_5.Geometry -> curve_to_mesh_4.Profile Curve
	    tube_ribbon.links.new(capture_attribute_002_5.outputs[0], curve_to_mesh_4.inputs[1])
	    #spline_parameter_6.Factor -> reroute_9.Input
	    tube_ribbon.links.new(spline_parameter_6.outputs[0], reroute_9.inputs[0])
	    #group_input_001_10.Material -> set_material_4.Material
	    tube_ribbon.links.new(group_input_001_10.outputs[1], set_material_4.inputs[2])
	    #combine_xyz_001_1.Vector -> curve_line.Start
	    tube_ribbon.links.new(combine_xyz_001_1.outputs[0], curve_line.inputs[0])
	    #math_001_2.Value -> combine_xyz_002.X
	    tube_ribbon.links.new(math_001_2.outputs[0], combine_xyz_002.inputs[0])
	    #combine_xyz_002.Vector -> curve_line.End
	    tube_ribbon.links.new(combine_xyz_002.outputs[0], curve_line.inputs[1])
	    #reroute_001_8.Output -> math_001_2.Value
	    tube_ribbon.links.new(reroute_001_8.outputs[0], math_001_2.inputs[0])
	    #curve_line.Curve -> capture_attribute_002_5.Geometry
	    tube_ribbon.links.new(curve_line.outputs[0], capture_attribute_002_5.inputs[0])
	    #group_input_14.Width -> reroute_001_8.Input
	    tube_ribbon.links.new(group_input_14.outputs[5], reroute_001_8.inputs[0])
	    #reroute_002_6.Output -> resample_curve_5.Curve
	    tube_ribbon.links.new(reroute_002_6.outputs[0], resample_curve_5.inputs[0])
	    #group_input_14.Resolution -> resample_curve_5.Count
	    tube_ribbon.links.new(group_input_14.outputs[4], resample_curve_5.inputs[2])
	    #group_input_002_8.Resolution -> compare_8.A
	    tube_ribbon.links.new(group_input_002_8.outputs[4], compare_8.inputs[2])
	    #compare_8.Result -> switch_7.Switch
	    tube_ribbon.links.new(compare_8.outputs[0], switch_7.inputs[0])
	    #set_curve_radius_4.Curve -> capture_attribute_4.Geometry
	    tube_ribbon.links.new(set_curve_radius_4.outputs[0], capture_attribute_4.inputs[0])
	    #reroute_002_6.Output -> switch_7.True
	    tube_ribbon.links.new(reroute_002_6.outputs[0], switch_7.inputs[2])
	    #resample_curve_5.Curve -> switch_7.False
	    tube_ribbon.links.new(resample_curve_5.outputs[0], switch_7.inputs[1])
	    #group_input_14.Geometry -> set_curve_tilt.Curve
	    tube_ribbon.links.new(group_input_14.outputs[0], set_curve_tilt.inputs[0])
	    #set_curve_tilt.Curve -> reroute_002_6.Input
	    tube_ribbon.links.new(set_curve_tilt.outputs[0], reroute_002_6.inputs[0])
	    #join_geometry_2.Geometry -> repeat_output_2.Geometry
	    tube_ribbon.links.new(join_geometry_2.outputs[0], repeat_output_2.inputs[0])
	    #group_input_003_7.Ribbon Count -> repeat_input_2.Iterations
	    tube_ribbon.links.new(group_input_003_7.outputs[3], repeat_input_2.inputs[0])
	    #math_003.Value -> repeat_output_2.Index
	    tube_ribbon.links.new(math_003.outputs[0], repeat_output_2.inputs[1])
	    #repeat_output_2.Geometry -> group_output_16.Geometry
	    tube_ribbon.links.new(repeat_output_2.outputs[0], group_output_16.inputs[0])
	    #reroute_003_4.Output -> math_003.Value
	    tube_ribbon.links.new(reroute_003_4.outputs[0], math_003.inputs[0])
	    #group_input_004_6.Ribbon Count -> math_002.Value
	    tube_ribbon.links.new(group_input_004_6.outputs[3], math_002.inputs[1])
	    #math_002.Value -> math_004.Value
	    tube_ribbon.links.new(math_002.outputs[0], math_004.inputs[1])
	    #reroute_003_4.Output -> math_004.Value
	    tube_ribbon.links.new(reroute_003_4.outputs[0], math_004.inputs[0])
	    #repeat_input_2.Index -> reroute_003_4.Input
	    tube_ribbon.links.new(repeat_input_2.outputs[2], reroute_003_4.inputs[0])
	    #set_material_4.Geometry -> join_geometry_2.Geometry
	    tube_ribbon.links.new(set_material_4.outputs[0], join_geometry_2.inputs[0])
	    #curve_tilt.Tilt -> math_005_1.Value
	    tube_ribbon.links.new(curve_tilt.outputs[0], math_005_1.inputs[1])
	    #math_004.Value -> math_005_1.Value
	    tube_ribbon.links.new(math_004.outputs[0], math_005_1.inputs[0])
	    #math_005_1.Value -> set_curve_tilt.Tilt
	    tube_ribbon.links.new(math_005_1.outputs[0], set_curve_tilt.inputs[2])
	    #switch_7.Output -> set_curve_radius_4.Curve
	    tube_ribbon.links.new(switch_7.outputs[0], set_curve_radius_4.inputs[0])
	    #reroute_004_5.Output -> set_curve_radius_4.Radius
	    tube_ribbon.links.new(reroute_004_5.outputs[0], set_curve_radius_4.inputs[2])
	    #reroute_005_5.Output -> reroute_004_5.Input
	    tube_ribbon.links.new(reroute_005_5.outputs[0], reroute_004_5.inputs[0])
	    #group_input_005_6.Curve Radius -> reroute_005_5.Input
	    tube_ribbon.links.new(group_input_005_6.outputs[2], reroute_005_5.inputs[0])
	    #reroute_001_8.Output -> combine_xyz_001_1.X
	    tube_ribbon.links.new(reroute_001_8.outputs[0], combine_xyz_001_1.inputs[0])
	    #repeat_input_2.Geometry -> join_geometry_2.Geometry
	    tube_ribbon.links.new(repeat_input_2.outputs[1], join_geometry_2.inputs[0])
	    return tube_ribbon
	
	tube_ribbon = tube_ribbon_node_group()
	
	#initialize mesh_hair_selector node group
	def mesh_hair_selector_node_group():
	    mesh_hair_selector = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "MESH_HAIR_SELECTOR")
	
	    mesh_hair_selector.color_tag = 'NONE'
	    mesh_hair_selector.description = "Convert hair to mesh object."
	    mesh_hair_selector.default_group_node_width = 140
	    
	
	    mesh_hair_selector.is_modifier = True
	
	    #mesh_hair_selector interface
	    #Socket Geometry
	    geometry_socket_27 = mesh_hair_selector.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_27.attribute_domain = 'POINT'
	    geometry_socket_27.description = "Mesh object."
	
	    #Socket Geometry
	    geometry_socket_28 = mesh_hair_selector.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_28.attribute_domain = 'POINT'
	    geometry_socket_28.description = "Curve object"
	
	    #Socket Style Select
	    style_select_socket = mesh_hair_selector.interface.new_socket(name = "Style Select", in_out='INPUT', socket_type = 'NodeSocketMenu')
	    style_select_socket.attribute_domain = 'POINT'
	    style_select_socket.description = "Mesh style to convert curve."
	
	    #Socket Material
	    material_socket_5 = mesh_hair_selector.interface.new_socket(name = "Material", in_out='INPUT', socket_type = 'NodeSocketMaterial')
	    material_socket_5.attribute_domain = 'POINT'
	    material_socket_5.description = "Material used for mesh."
	
	    #Socket Resolution
	    resolution_socket_4 = mesh_hair_selector.interface.new_socket(name = "Resolution", in_out='INPUT', socket_type = 'NodeSocketInt')
	    resolution_socket_4.default_value = 0
	    resolution_socket_4.min_value = 2
	    resolution_socket_4.max_value = 512
	    resolution_socket_4.subtype = 'NONE'
	    resolution_socket_4.attribute_domain = 'POINT'
	    resolution_socket_4.description = "Control mesh smoothness by add and removing points along curve."
	
	    #Socket Width
	    width_socket_3 = mesh_hair_selector.interface.new_socket(name = "Width", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    width_socket_3.default_value = 0.10000000149011612
	    width_socket_3.min_value = 0.0
	    width_socket_3.max_value = 3.4028234663852886e+38
	    width_socket_3.subtype = 'DISTANCE'
	    width_socket_3.attribute_domain = 'POINT'
	    width_socket_3.description = "Width of mesh object."
	
	    #Socket Curve Radius
	    curve_radius_socket_4 = mesh_hair_selector.interface.new_socket(name = "Curve Radius", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    curve_radius_socket_4.default_value = 0.0
	    curve_radius_socket_4.min_value = 0.0
	    curve_radius_socket_4.max_value = 0.0
	    curve_radius_socket_4.subtype = 'DISTANCE'
	    curve_radius_socket_4.attribute_domain = 'POINT'
	    curve_radius_socket_4.hide_value = True
	    curve_radius_socket_4.hide_in_modifier = True
	    curve_radius_socket_4.description = "Overall mesh shape float curve."
	
	    #Socket Fill Caps
	    fill_caps_socket_2 = mesh_hair_selector.interface.new_socket(name = "Fill Caps", in_out='INPUT', socket_type = 'NodeSocketBool')
	    fill_caps_socket_2.default_value = False
	    fill_caps_socket_2.attribute_domain = 'POINT'
	    fill_caps_socket_2.description = "Fill openings with mesh surface. (Used only for [Tube Mesh | Stylized] mesh styles)"
	
	    #Socket Shade Smooth
	    shade_smooth_socket = mesh_hair_selector.interface.new_socket(name = "Shade Smooth", in_out='INPUT', socket_type = 'NodeSocketBool')
	    shade_smooth_socket.default_value = False
	    shade_smooth_socket.attribute_domain = 'POINT'
	    shade_smooth_socket.description = "Use Smooth Shade for mesh."
	
	    #Socket Hair Card Angle
	    hair_card_angle_socket = mesh_hair_selector.interface.new_socket(name = "Hair Card Angle", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    hair_card_angle_socket.default_value = 0.0
	    hair_card_angle_socket.min_value = -90.0
	    hair_card_angle_socket.max_value = 90.0
	    hair_card_angle_socket.subtype = 'ANGLE'
	    hair_card_angle_socket.attribute_domain = 'POINT'
	    hair_card_angle_socket.description = "Angle used to bend hair card. (Mesh Style=Hair Card)"
	
	    #Socket Tube Ribbon Count
	    tube_ribbon_count_socket = mesh_hair_selector.interface.new_socket(name = "Tube Ribbon Count", in_out='INPUT', socket_type = 'NodeSocketInt')
	    tube_ribbon_count_socket.default_value = 8
	    tube_ribbon_count_socket.min_value = 1
	    tube_ribbon_count_socket.max_value = 180
	    tube_ribbon_count_socket.subtype = 'NONE'
	    tube_ribbon_count_socket.attribute_domain = 'POINT'
	    tube_ribbon_count_socket.description = "Amount of billboard like hair cards used to shape hair. (Mesh Style=Tube Ribbon)"
	
	    #Socket Profile Curve
	    profile_curve_socket = mesh_hair_selector.interface.new_socket(name = "Profile Curve", in_out='INPUT', socket_type = 'NodeSocketObject')
	    profile_curve_socket.attribute_domain = 'POINT'
	    profile_curve_socket.description = "Curve object used as the profile for stylized hair. (Mesh Style=Stylized)"
	
	    #Socket Profile Translation
	    profile_translation_socket = mesh_hair_selector.interface.new_socket(name = "Profile Translation", in_out='INPUT', socket_type = 'NodeSocketVector')
	    profile_translation_socket.default_value = (0.0, 0.0, 0.0)
	    profile_translation_socket.min_value = -3.4028234663852886e+38
	    profile_translation_socket.max_value = 3.4028234663852886e+38
	    profile_translation_socket.subtype = 'TRANSLATION'
	    profile_translation_socket.attribute_domain = 'POINT'
	    profile_translation_socket.description = "Move position of stylized profile from origin. (Mesh Style=Stylized)"
	
	    #Socket Profile Rotation
	    profile_rotation_socket = mesh_hair_selector.interface.new_socket(name = "Profile Rotation", in_out='INPUT', socket_type = 'NodeSocketRotation')
	    profile_rotation_socket.default_value = (0.0, 0.0, 0.0)
	    profile_rotation_socket.attribute_domain = 'POINT'
	    profile_rotation_socket.description = "Rotate the stylized profile from origin. (Mesh Style=Stylized)"
	
	    #Socket Profile Scale
	    profile_scale_socket = mesh_hair_selector.interface.new_socket(name = "Profile Scale", in_out='INPUT', socket_type = 'NodeSocketVector')
	    profile_scale_socket.default_value = (1.0, 1.0, 1.0)
	    profile_scale_socket.min_value = -3.4028234663852886e+38
	    profile_scale_socket.max_value = 3.4028234663852886e+38
	    profile_scale_socket.subtype = 'XYZ'
	    profile_scale_socket.attribute_domain = 'POINT'
	    profile_scale_socket.description = "Scale the stylized profile from origin. (Mesh Style=Stylized)"
	
	    #Socket Mesh Index
	    mesh_index_socket = mesh_hair_selector.interface.new_socket(name = "Mesh Index", in_out='INPUT', socket_type = 'NodeSocketInt')
	    mesh_index_socket.default_value = 0
	    mesh_index_socket.min_value = 0
	    mesh_index_socket.max_value = 2147483647
	    mesh_index_socket.subtype = 'NONE'
	    mesh_index_socket.attribute_domain = 'POINT'
	    mesh_index_socket.description = "Index used to offset uv coords."
	
	
	    #initialize mesh_hair_selector nodes
	    #node Group Output
	    group_output_17 = mesh_hair_selector.nodes.new("NodeGroupOutput")
	    group_output_17.name = "Group Output"
	    group_output_17.is_active_output = True
	    group_output_17.inputs[1].hide = True
	
	    #node Group
	    group_4 = mesh_hair_selector.nodes.new("GeometryNodeGroup")
	    group_4.name = "Group"
	    group_4.node_tree = hair_card
	
	    #node Group.001
	    group_001_2 = mesh_hair_selector.nodes.new("GeometryNodeGroup")
	    group_001_2.name = "Group.001"
	    group_001_2.node_tree = stylized_hair
	
	    #node Group.002
	    group_002_1 = mesh_hair_selector.nodes.new("GeometryNodeGroup")
	    group_002_1.name = "Group.002"
	    group_002_1.node_tree = tube_mesh
	
	    #node Group.003
	    group_003_1 = mesh_hair_selector.nodes.new("GeometryNodeGroup")
	    group_003_1.name = "Group.003"
	    group_003_1.node_tree = tube_ribbon
	
	    #node Group Input.001
	    group_input_001_11 = mesh_hair_selector.nodes.new("NodeGroupInput")
	    group_input_001_11.name = "Group Input.001"
	    group_input_001_11.outputs[1].hide = True
	    group_input_001_11.outputs[5].hide = True
	    group_input_001_11.outputs[6].hide = True
	    group_input_001_11.outputs[7].hide = True
	    group_input_001_11.outputs[9].hide = True
	    group_input_001_11.outputs[10].hide = True
	    group_input_001_11.outputs[11].hide = True
	    group_input_001_11.outputs[12].hide = True
	    group_input_001_11.outputs[13].hide = True
	    group_input_001_11.outputs[14].hide = True
	    group_input_001_11.outputs[15].hide = True
	
	    #node Group Input.002
	    group_input_002_9 = mesh_hair_selector.nodes.new("NodeGroupInput")
	    group_input_002_9.name = "Group Input.002"
	    group_input_002_9.outputs[1].hide = True
	    group_input_002_9.outputs[5].hide = True
	    group_input_002_9.outputs[7].hide = True
	    group_input_002_9.outputs[8].hide = True
	    group_input_002_9.outputs[9].hide = True
	    group_input_002_9.outputs[10].hide = True
	    group_input_002_9.outputs[11].hide = True
	    group_input_002_9.outputs[12].hide = True
	    group_input_002_9.outputs[13].hide = True
	    group_input_002_9.outputs[14].hide = True
	    group_input_002_9.outputs[15].hide = True
	
	    #node Group Input.003
	    group_input_003_8 = mesh_hair_selector.nodes.new("NodeGroupInput")
	    group_input_003_8.name = "Group Input.003"
	    group_input_003_8.outputs[1].hide = True
	    group_input_003_8.outputs[5].hide = True
	    group_input_003_8.outputs[6].hide = True
	    group_input_003_8.outputs[7].hide = True
	    group_input_003_8.outputs[8].hide = True
	    group_input_003_8.outputs[10].hide = True
	    group_input_003_8.outputs[11].hide = True
	    group_input_003_8.outputs[12].hide = True
	    group_input_003_8.outputs[13].hide = True
	    group_input_003_8.outputs[14].hide = True
	    group_input_003_8.outputs[15].hide = True
	
	    #node Group Input.004
	    group_input_004_7 = mesh_hair_selector.nodes.new("NodeGroupInput")
	    group_input_004_7.name = "Group Input.004"
	    group_input_004_7.outputs[1].hide = True
	    group_input_004_7.outputs[4].hide = True
	    group_input_004_7.outputs[5].hide = True
	    group_input_004_7.outputs[7].hide = True
	    group_input_004_7.outputs[8].hide = True
	    group_input_004_7.outputs[9].hide = True
	    group_input_004_7.outputs[10].hide = True
	    group_input_004_7.outputs[14].hide = True
	    group_input_004_7.outputs[15].hide = True
	
	    #node Menu Switch.001
	    menu_switch_001 = mesh_hair_selector.nodes.new("GeometryNodeMenuSwitch")
	    menu_switch_001.name = "Menu Switch.001"
	    menu_switch_001.active_index = 3
	    menu_switch_001.data_type = 'STRING'
	    menu_switch_001.enum_items.clear()
	    menu_switch_001.enum_items.new("Hair Card")
	    menu_switch_001.enum_items[0].description = ""
	    menu_switch_001.enum_items.new("Tube Mesh")
	    menu_switch_001.enum_items[1].description = ""
	    menu_switch_001.enum_items.new("Tube Ribbon")
	    menu_switch_001.enum_items[2].description = ""
	    menu_switch_001.enum_items.new("Stylized")
	    menu_switch_001.enum_items[3].description = ""
	    menu_switch_001.inputs[5].hide = True
	
	    #node Store Named Attribute
	    store_named_attribute_8 = mesh_hair_selector.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_8.name = "Store Named Attribute"
	    store_named_attribute_8.data_type = 'FLOAT2'
	    store_named_attribute_8.domain = 'CORNER'
	    #Selection
	    store_named_attribute_8.inputs[1].default_value = True
	    #Name
	    store_named_attribute_8.inputs[2].default_value = "UVMap"
	
	    #node Named Attribute
	    named_attribute_5 = mesh_hair_selector.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute_5.name = "Named Attribute"
	    named_attribute_5.data_type = 'FLOAT_VECTOR'
	
	    #node Group Input.005
	    group_input_005_7 = mesh_hair_selector.nodes.new("NodeGroupInput")
	    group_input_005_7.name = "Group Input.005"
	    group_input_005_7.outputs[0].hide = True
	    group_input_005_7.outputs[2].hide = True
	    group_input_005_7.outputs[3].hide = True
	    group_input_005_7.outputs[4].hide = True
	    group_input_005_7.outputs[5].hide = True
	    group_input_005_7.outputs[6].hide = True
	    group_input_005_7.outputs[7].hide = True
	    group_input_005_7.outputs[8].hide = True
	    group_input_005_7.outputs[9].hide = True
	    group_input_005_7.outputs[10].hide = True
	    group_input_005_7.outputs[11].hide = True
	    group_input_005_7.outputs[12].hide = True
	    group_input_005_7.outputs[13].hide = True
	    group_input_005_7.outputs[14].hide = True
	    group_input_005_7.outputs[15].hide = True
	
	    #node Group Input.006
	    group_input_006_3 = mesh_hair_selector.nodes.new("NodeGroupInput")
	    group_input_006_3.name = "Group Input.006"
	    group_input_006_3.outputs[0].hide = True
	    group_input_006_3.outputs[1].hide = True
	    group_input_006_3.outputs[2].hide = True
	    group_input_006_3.outputs[3].hide = True
	    group_input_006_3.outputs[4].hide = True
	    group_input_006_3.outputs[5].hide = True
	    group_input_006_3.outputs[6].hide = True
	    group_input_006_3.outputs[7].hide = True
	    group_input_006_3.outputs[8].hide = True
	    group_input_006_3.outputs[9].hide = True
	    group_input_006_3.outputs[11].hide = True
	    group_input_006_3.outputs[12].hide = True
	    group_input_006_3.outputs[13].hide = True
	    group_input_006_3.outputs[14].hide = True
	    group_input_006_3.outputs[15].hide = True
	
	    #node Compare
	    compare_9 = mesh_hair_selector.nodes.new("FunctionNodeCompare")
	    compare_9.name = "Compare"
	    compare_9.hide = True
	    compare_9.data_type = 'STRING'
	    compare_9.mode = 'ELEMENT'
	    compare_9.operation = 'EQUAL'
	
	    #node Switch
	    switch_8 = mesh_hair_selector.nodes.new("GeometryNodeSwitch")
	    switch_8.name = "Switch"
	    switch_8.hide = True
	    switch_8.input_type = 'GEOMETRY'
	
	    #node Compare.001
	    compare_001_5 = mesh_hair_selector.nodes.new("FunctionNodeCompare")
	    compare_001_5.name = "Compare.001"
	    compare_001_5.hide = True
	    compare_001_5.data_type = 'STRING'
	    compare_001_5.mode = 'ELEMENT'
	    compare_001_5.operation = 'EQUAL'
	
	    #node Switch.001
	    switch_001_5 = mesh_hair_selector.nodes.new("GeometryNodeSwitch")
	    switch_001_5.name = "Switch.001"
	    switch_001_5.hide = True
	    switch_001_5.input_type = 'GEOMETRY'
	
	    #node Compare.002
	    compare_002_5 = mesh_hair_selector.nodes.new("FunctionNodeCompare")
	    compare_002_5.name = "Compare.002"
	    compare_002_5.hide = True
	    compare_002_5.data_type = 'STRING'
	    compare_002_5.mode = 'ELEMENT'
	    compare_002_5.operation = 'EQUAL'
	
	    #node Switch.002
	    switch_002_2 = mesh_hair_selector.nodes.new("GeometryNodeSwitch")
	    switch_002_2.name = "Switch.002"
	    switch_002_2.hide = True
	    switch_002_2.input_type = 'GEOMETRY'
	
	    #node Compare.003
	    compare_003_2 = mesh_hair_selector.nodes.new("FunctionNodeCompare")
	    compare_003_2.name = "Compare.003"
	    compare_003_2.hide = True
	    compare_003_2.data_type = 'STRING'
	    compare_003_2.mode = 'ELEMENT'
	    compare_003_2.operation = 'EQUAL'
	
	    #node Switch.003
	    switch_003_3 = mesh_hair_selector.nodes.new("GeometryNodeSwitch")
	    switch_003_3.name = "Switch.003"
	    switch_003_3.hide = True
	    switch_003_3.input_type = 'GEOMETRY'
	
	    #node String
	    string = mesh_hair_selector.nodes.new("FunctionNodeInputString")
	    string.name = "String"
	    string.string = "hair_card_UV"
	
	    #node String.001
	    string_001 = mesh_hair_selector.nodes.new("FunctionNodeInputString")
	    string_001.name = "String.001"
	    string_001.string = "tube_mesh_UV"
	
	    #node String.002
	    string_002 = mesh_hair_selector.nodes.new("FunctionNodeInputString")
	    string_002.name = "String.002"
	    string_002.string = "ribbon_mesh_UV"
	
	    #node String.003
	    string_003 = mesh_hair_selector.nodes.new("FunctionNodeInputString")
	    string_003.name = "String.003"
	    string_003.string = "stylized_hair_UV"
	
	    #node Reroute
	    reroute_10 = mesh_hair_selector.nodes.new("NodeReroute")
	    reroute_10.name = "Reroute"
	    reroute_10.socket_idname = "NodeSocketString"
	    #node Reroute.001
	    reroute_001_9 = mesh_hair_selector.nodes.new("NodeReroute")
	    reroute_001_9.name = "Reroute.001"
	    reroute_001_9.socket_idname = "NodeSocketString"
	    #node Reroute.002
	    reroute_002_7 = mesh_hair_selector.nodes.new("NodeReroute")
	    reroute_002_7.name = "Reroute.002"
	    reroute_002_7.socket_idname = "NodeSocketString"
	    #node Reroute.003
	    reroute_003_5 = mesh_hair_selector.nodes.new("NodeReroute")
	    reroute_003_5.name = "Reroute.003"
	    reroute_003_5.socket_idname = "NodeSocketString"
	    #node Reroute.004
	    reroute_004_6 = mesh_hair_selector.nodes.new("NodeReroute")
	    reroute_004_6.name = "Reroute.004"
	    reroute_004_6.socket_idname = "NodeSocketString"
	    #node Reroute.005
	    reroute_005_6 = mesh_hair_selector.nodes.new("NodeReroute")
	    reroute_005_6.name = "Reroute.005"
	    reroute_005_6.socket_idname = "NodeSocketString"
	    #node Reroute.006
	    reroute_006_5 = mesh_hair_selector.nodes.new("NodeReroute")
	    reroute_006_5.name = "Reroute.006"
	    reroute_006_5.socket_idname = "NodeSocketString"
	    #node Reroute.007
	    reroute_007_5 = mesh_hair_selector.nodes.new("NodeReroute")
	    reroute_007_5.name = "Reroute.007"
	    reroute_007_5.socket_idname = "NodeSocketString"
	    #node Reroute.008
	    reroute_008_5 = mesh_hair_selector.nodes.new("NodeReroute")
	    reroute_008_5.name = "Reroute.008"
	    reroute_008_5.socket_idname = "NodeSocketString"
	    #node Reroute.009
	    reroute_009_4 = mesh_hair_selector.nodes.new("NodeReroute")
	    reroute_009_4.name = "Reroute.009"
	    reroute_009_4.socket_idname = "NodeSocketString"
	    #node Reroute.010
	    reroute_010_4 = mesh_hair_selector.nodes.new("NodeReroute")
	    reroute_010_4.name = "Reroute.010"
	    reroute_010_4.socket_idname = "NodeSocketString"
	    #node Reroute.011
	    reroute_011_3 = mesh_hair_selector.nodes.new("NodeReroute")
	    reroute_011_3.name = "Reroute.011"
	    reroute_011_3.socket_idname = "NodeSocketString"
	    #node Reroute.012
	    reroute_012_3 = mesh_hair_selector.nodes.new("NodeReroute")
	    reroute_012_3.name = "Reroute.012"
	    reroute_012_3.socket_idname = "NodeSocketString"
	    #node Reroute.013
	    reroute_013_3 = mesh_hair_selector.nodes.new("NodeReroute")
	    reroute_013_3.name = "Reroute.013"
	    reroute_013_3.socket_idname = "NodeSocketString"
	    #node Reroute.014
	    reroute_014_2 = mesh_hair_selector.nodes.new("NodeReroute")
	    reroute_014_2.name = "Reroute.014"
	    reroute_014_2.socket_idname = "NodeSocketString"
	    #node Group Input.007
	    group_input_007_2 = mesh_hair_selector.nodes.new("NodeGroupInput")
	    group_input_007_2.name = "Group Input.007"
	    group_input_007_2.outputs[0].hide = True
	    group_input_007_2.outputs[1].hide = True
	    group_input_007_2.outputs[2].hide = True
	    group_input_007_2.outputs[3].hide = True
	    group_input_007_2.outputs[4].hide = True
	    group_input_007_2.outputs[5].hide = True
	    group_input_007_2.outputs[6].hide = True
	    group_input_007_2.outputs[7].hide = True
	    group_input_007_2.outputs[8].hide = True
	    group_input_007_2.outputs[9].hide = True
	    group_input_007_2.outputs[10].hide = True
	    group_input_007_2.outputs[11].hide = True
	    group_input_007_2.outputs[12].hide = True
	    group_input_007_2.outputs[13].hide = True
	    group_input_007_2.outputs[15].hide = True
	
	    #node Store Named Attribute.001
	    store_named_attribute_001_1 = mesh_hair_selector.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_001_1.name = "Store Named Attribute.001"
	    store_named_attribute_001_1.data_type = 'INT'
	    store_named_attribute_001_1.domain = 'CORNER'
	    #Selection
	    store_named_attribute_001_1.inputs[1].default_value = True
	    #Name
	    store_named_attribute_001_1.inputs[2].default_value = "mesh_idx"
	
	    #node Remove Named Attribute
	    remove_named_attribute = mesh_hair_selector.nodes.new("GeometryNodeRemoveAttribute")
	    remove_named_attribute.name = "Remove Named Attribute"
	    remove_named_attribute.pattern_mode = 'EXACT'
	
	    #node Reroute.015
	    reroute_015_2 = mesh_hair_selector.nodes.new("NodeReroute")
	    reroute_015_2.name = "Reroute.015"
	    reroute_015_2.socket_idname = "NodeSocketString"
	    #node Reroute.016
	    reroute_016_2 = mesh_hair_selector.nodes.new("NodeReroute")
	    reroute_016_2.name = "Reroute.016"
	    reroute_016_2.socket_idname = "NodeSocketString"
	    #node Set Shade Smooth
	    set_shade_smooth = mesh_hair_selector.nodes.new("GeometryNodeSetShadeSmooth")
	    set_shade_smooth.name = "Set Shade Smooth"
	    set_shade_smooth.domain = 'FACE'
	    set_shade_smooth.inputs[1].hide = True
	    #Selection
	    set_shade_smooth.inputs[1].default_value = True
	
	    #node Use Mesh Bake
	    use_mesh_bake = mesh_hair_selector.nodes.new("GeometryNodeBake")
	    use_mesh_bake.label = "Use Mesh Bake"
	    use_mesh_bake.name = "Use Mesh Bake"
	    use_mesh_bake.active_index = 0
	    use_mesh_bake.bake_items.clear()
	    use_mesh_bake.bake_items.new('GEOMETRY', "Geometry")
	    use_mesh_bake.bake_items[0].attribute_domain = 'POINT'
	    use_mesh_bake.inputs[1].hide = True
	    use_mesh_bake.outputs[1].hide = True
	
	    #node Group Input.008
	    group_input_008_3 = mesh_hair_selector.nodes.new("NodeGroupInput")
	    group_input_008_3.name = "Group Input.008"
	    group_input_008_3.outputs[0].hide = True
	    group_input_008_3.outputs[1].hide = True
	    group_input_008_3.outputs[2].hide = True
	    group_input_008_3.outputs[3].hide = True
	    group_input_008_3.outputs[4].hide = True
	    group_input_008_3.outputs[5].hide = True
	    group_input_008_3.outputs[6].hide = True
	    group_input_008_3.outputs[8].hide = True
	    group_input_008_3.outputs[9].hide = True
	    group_input_008_3.outputs[10].hide = True
	    group_input_008_3.outputs[11].hide = True
	    group_input_008_3.outputs[12].hide = True
	    group_input_008_3.outputs[13].hide = True
	    group_input_008_3.outputs[14].hide = True
	    group_input_008_3.outputs[15].hide = True
	
	    #node Mesh Overall Shape
	    mesh_overall_shape = mesh_hair_selector.nodes.new("ShaderNodeFloatCurve")
	    mesh_overall_shape.label = "Mesh Overall Shape"
	    mesh_overall_shape.name = "Mesh Overall Shape"
	    #mapping settings
	    mesh_overall_shape.mapping.extend = 'EXTRAPOLATED'
	    mesh_overall_shape.mapping.tone = 'STANDARD'
	    mesh_overall_shape.mapping.black_level = (0.0, 0.0, 0.0)
	    mesh_overall_shape.mapping.white_level = (1.0, 1.0, 1.0)
	    mesh_overall_shape.mapping.clip_min_x = 0.0
	    mesh_overall_shape.mapping.clip_min_y = 0.0
	    mesh_overall_shape.mapping.clip_max_x = 1.0
	    mesh_overall_shape.mapping.clip_max_y = 1.0
	    mesh_overall_shape.mapping.use_clip = True
	    #curve 0
	    mesh_overall_shape_curve_0 = mesh_overall_shape.mapping.curves[0]
	    mesh_overall_shape_curve_0_point_0 = mesh_overall_shape_curve_0.points[0]
	    mesh_overall_shape_curve_0_point_0.location = (0.0, 1.0)
	    mesh_overall_shape_curve_0_point_0.handle_type = 'AUTO'
	    mesh_overall_shape_curve_0_point_1 = mesh_overall_shape_curve_0.points[1]
	    mesh_overall_shape_curve_0_point_1.location = (1.0, 1.0)
	    mesh_overall_shape_curve_0_point_1.handle_type = 'AUTO'
	    #update curve after changes
	    mesh_overall_shape.mapping.update()
	    #Factor
	    mesh_overall_shape.inputs[0].default_value = 1.0
	
	    #node Spline Parameter
	    spline_parameter_7 = mesh_hair_selector.nodes.new("GeometryNodeSplineParameter")
	    spline_parameter_7.name = "Spline Parameter"
	    spline_parameter_7.outputs[1].hide = True
	    spline_parameter_7.outputs[2].hide = True
	
	    #node Switch.004
	    switch_004_2 = mesh_hair_selector.nodes.new("GeometryNodeSwitch")
	    switch_004_2.name = "Switch.004"
	    switch_004_2.hide = True
	    switch_004_2.input_type = 'FLOAT'
	
	    #node Group Input.009
	    group_input_009_2 = mesh_hair_selector.nodes.new("NodeGroupInput")
	    group_input_009_2.name = "Group Input.009"
	    group_input_009_2.outputs[0].hide = True
	    group_input_009_2.outputs[1].hide = True
	    group_input_009_2.outputs[2].hide = True
	    group_input_009_2.outputs[3].hide = True
	    group_input_009_2.outputs[4].hide = True
	    group_input_009_2.outputs[6].hide = True
	    group_input_009_2.outputs[7].hide = True
	    group_input_009_2.outputs[8].hide = True
	    group_input_009_2.outputs[9].hide = True
	    group_input_009_2.outputs[10].hide = True
	    group_input_009_2.outputs[11].hide = True
	    group_input_009_2.outputs[12].hide = True
	    group_input_009_2.outputs[13].hide = True
	    group_input_009_2.outputs[14].hide = True
	    group_input_009_2.outputs[15].hide = True
	
	    #node Attribute Statistic
	    attribute_statistic_3 = mesh_hair_selector.nodes.new("GeometryNodeAttributeStatistic")
	    attribute_statistic_3.name = "Attribute Statistic"
	    attribute_statistic_3.hide = True
	    attribute_statistic_3.data_type = 'FLOAT'
	    attribute_statistic_3.domain = 'POINT'
	    attribute_statistic_3.inputs[1].hide = True
	    attribute_statistic_3.outputs[0].hide = True
	    attribute_statistic_3.outputs[1].hide = True
	    attribute_statistic_3.outputs[3].hide = True
	    attribute_statistic_3.outputs[4].hide = True
	    attribute_statistic_3.outputs[5].hide = True
	    attribute_statistic_3.outputs[6].hide = True
	    attribute_statistic_3.outputs[7].hide = True
	    #Selection
	    attribute_statistic_3.inputs[1].default_value = True
	
	    #node Store Named Attribute.002
	    store_named_attribute_002_1 = mesh_hair_selector.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_002_1.name = "Store Named Attribute.002"
	    store_named_attribute_002_1.hide = True
	    store_named_attribute_002_1.data_type = 'FLOAT'
	    store_named_attribute_002_1.domain = 'POINT'
	    store_named_attribute_002_1.inputs[1].hide = True
	    store_named_attribute_002_1.inputs[2].hide = True
	    #Selection
	    store_named_attribute_002_1.inputs[1].default_value = True
	    #Name
	    store_named_attribute_002_1.inputs[2].default_value = "mcr"
	
	    #node Compare.005
	    compare_005_1 = mesh_hair_selector.nodes.new("FunctionNodeCompare")
	    compare_005_1.name = "Compare.005"
	    compare_005_1.hide = True
	    compare_005_1.data_type = 'FLOAT'
	    compare_005_1.mode = 'ELEMENT'
	    compare_005_1.operation = 'EQUAL'
	    compare_005_1.inputs[1].hide = True
	    compare_005_1.inputs[2].hide = True
	    compare_005_1.inputs[3].hide = True
	    compare_005_1.inputs[4].hide = True
	    compare_005_1.inputs[5].hide = True
	    compare_005_1.inputs[6].hide = True
	    compare_005_1.inputs[7].hide = True
	    compare_005_1.inputs[8].hide = True
	    compare_005_1.inputs[9].hide = True
	    compare_005_1.inputs[10].hide = True
	    compare_005_1.inputs[11].hide = True
	    compare_005_1.inputs[12].hide = True
	    #B
	    compare_005_1.inputs[1].default_value = 0.0
	    #Epsilon
	    compare_005_1.inputs[12].default_value = 0.0
	
	    #node Named Attribute.001
	    named_attribute_001_3 = mesh_hair_selector.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute_001_3.name = "Named Attribute.001"
	    named_attribute_001_3.hide = True
	    named_attribute_001_3.data_type = 'FLOAT'
	    #Name
	    named_attribute_001_3.inputs[0].default_value = "mcr"
	
	    #node Group Input.010
	    group_input_010_1 = mesh_hair_selector.nodes.new("NodeGroupInput")
	    group_input_010_1.name = "Group Input.010"
	    group_input_010_1.outputs[1].hide = True
	    group_input_010_1.outputs[2].hide = True
	    group_input_010_1.outputs[3].hide = True
	    group_input_010_1.outputs[4].hide = True
	    group_input_010_1.outputs[5].hide = True
	    group_input_010_1.outputs[6].hide = True
	    group_input_010_1.outputs[7].hide = True
	    group_input_010_1.outputs[8].hide = True
	    group_input_010_1.outputs[9].hide = True
	    group_input_010_1.outputs[10].hide = True
	    group_input_010_1.outputs[11].hide = True
	    group_input_010_1.outputs[12].hide = True
	    group_input_010_1.outputs[13].hide = True
	    group_input_010_1.outputs[14].hide = True
	    group_input_010_1.outputs[15].hide = True
	
	
	
	
	
	    #Set locations
	    group_output_17.location = (2610.42724609375, -19.416736602783203)
	    group_4.location = (-79.76215362548828, -110.40367889404297)
	    group_001_2.location = (-81.79773712158203, -748.9313354492188)
	    group_002_1.location = (-78.79950714111328, -318.1512451171875)
	    group_003_1.location = (-78.67485809326172, -526.0662231445312)
	    group_input_001_11.location = (-338.60595703125, -155.34437561035156)
	    group_input_002_9.location = (-338.60595703125, -362.43890380859375)
	    group_input_003_8.location = (-338.60595703125, -569.8320922851562)
	    group_input_004_7.location = (-338.60595703125, -815.11083984375)
	    menu_switch_001.location = (469.07684326171875, 163.7274627685547)
	    store_named_attribute_8.location = (1647.7332763671875, -19.652393341064453)
	    named_attribute_5.location = (1475.844482421875, -157.7658233642578)
	    group_input_005_7.location = (265.0098571777344, 135.95323181152344)
	    group_input_006_3.location = (-338.60595703125, -756.4561767578125)
	    compare_9.location = (1238.7310791015625, -84.21184539794922)
	    switch_8.location = (1238.74365234375, -117.19403076171875)
	    compare_001_5.location = (1099.1707763671875, -299.4894104003906)
	    switch_001_5.location = (1106.2532958984375, -334.8301696777344)
	    compare_002_5.location = (970.40234375, -499.8262634277344)
	    switch_002_2.location = (975.1282958984375, -535.1670532226562)
	    compare_003_2.location = (837.8390502929688, -724.1065063476562)
	    switch_003_3.location = (840.2083740234375, -760.2830810546875)
	    string.location = (84.04959869384766, -54.475547790527344)
	    string_001.location = (82.85930633544922, -258.00762939453125)
	    string_002.location = (79.31243896484375, -471.3780517578125)
	    string_003.location = (76.95584106445312, -696.93603515625)
	    reroute_10.location = (266.1946716308594, -90.37294006347656)
	    reroute_001_9.location = (330.2995910644531, -295.4872741699219)
	    reroute_002_7.location = (386.08740234375, -507.37738037109375)
	    reroute_003_5.location = (432.0370178222656, -735.281005859375)
	    reroute_004_6.location = (267.64080810546875, 58.478363037109375)
	    reroute_005_6.location = (328.94110107421875, 33.61994552612305)
	    reroute_006_5.location = (388.06353759765625, 12.934127807617188)
	    reroute_007_5.location = (434.48321533203125, -6.701620101928711)
	    reroute_008_5.location = (790.6254272460938, 129.04226684570312)
	    reroute_009_4.location = (800.4947509765625, -727.48974609375)
	    reroute_010_4.location = (796.8050537109375, -498.8685607910156)
	    reroute_011_3.location = (792.9110107421875, -293.6495361328125)
	    reroute_012_3.location = (790.7710571289062, -80.90033721923828)
	    reroute_013_3.location = (1415.17578125, -264.01324462890625)
	    reroute_014_2.location = (1401.7613525390625, 129.6073760986328)
	    group_input_007_2.location = (1837.3367919921875, -221.13070678710938)
	    store_named_attribute_001_1.location = (1841.328125, -19.652393341064453)
	    remove_named_attribute.location = (2020.999755859375, -18.566680908203125)
	    reroute_015_2.location = (1997.9866943359375, 132.55369567871094)
	    reroute_016_2.location = (2003.16845703125, -126.52413940429688)
	    set_shade_smooth.location = (2246.024658203125, -17.58367919921875)
	    use_mesh_bake.location = (2430.91064453125, 27.558258056640625)
	    group_input_008_3.location = (2049.84326171875, -148.66607666015625)
	    mesh_overall_shape.location = (-873.3704223632812, -650.7651977539062)
	    spline_parameter_7.location = (-876.84423828125, -968.0524291992188)
	    switch_004_2.location = (-631.904296875, -473.04425048828125)
	    group_input_009_2.location = (-872.6063232421875, -591.0381469726562)
	    attribute_statistic_3.location = (-870.9525146484375, -511.33477783203125)
	    store_named_attribute_002_1.location = (-879.0206909179688, -565.9711303710938)
	    compare_005_1.location = (-632.6890869140625, -511.18927001953125)
	    named_attribute_001_3.location = (-874.1126708984375, -454.52947998046875)
	    group_input_010_1.location = (-1047.1160888671875, -533.9951782226562)
	
	    #Set dimensions
	    group_output_17.width, group_output_17.height = 140.0, 100.0
	    group_4.width, group_4.height = 140.0, 100.0
	    group_001_2.width, group_001_2.height = 140.0, 100.0
	    group_002_1.width, group_002_1.height = 140.0, 100.0
	    group_003_1.width, group_003_1.height = 140.0, 100.0
	    group_input_001_11.width, group_input_001_11.height = 140.0, 100.0
	    group_input_002_9.width, group_input_002_9.height = 140.0, 100.0
	    group_input_003_8.width, group_input_003_8.height = 140.0, 100.0
	    group_input_004_7.width, group_input_004_7.height = 140.0, 100.0
	    menu_switch_001.width, menu_switch_001.height = 245.18148803710938, 100.0
	    store_named_attribute_8.width, store_named_attribute_8.height = 140.0, 100.0
	    named_attribute_5.width, named_attribute_5.height = 140.0, 100.0
	    group_input_005_7.width, group_input_005_7.height = 140.0, 100.0
	    group_input_006_3.width, group_input_006_3.height = 140.0, 100.0
	    compare_9.width, compare_9.height = 140.0, 100.0
	    switch_8.width, switch_8.height = 140.0, 100.0
	    compare_001_5.width, compare_001_5.height = 140.0, 100.0
	    switch_001_5.width, switch_001_5.height = 140.0, 100.0
	    compare_002_5.width, compare_002_5.height = 140.0, 100.0
	    switch_002_2.width, switch_002_2.height = 140.0, 100.0
	    compare_003_2.width, compare_003_2.height = 140.0, 100.0
	    switch_003_3.width, switch_003_3.height = 140.0, 100.0
	    string.width, string.height = 140.0, 100.0
	    string_001.width, string_001.height = 140.0, 100.0
	    string_002.width, string_002.height = 140.0, 100.0
	    string_003.width, string_003.height = 140.0, 100.0
	    reroute_10.width, reroute_10.height = 10.0, 100.0
	    reroute_001_9.width, reroute_001_9.height = 10.0, 100.0
	    reroute_002_7.width, reroute_002_7.height = 10.0, 100.0
	    reroute_003_5.width, reroute_003_5.height = 10.0, 100.0
	    reroute_004_6.width, reroute_004_6.height = 10.0, 100.0
	    reroute_005_6.width, reroute_005_6.height = 10.0, 100.0
	    reroute_006_5.width, reroute_006_5.height = 10.0, 100.0
	    reroute_007_5.width, reroute_007_5.height = 10.0, 100.0
	    reroute_008_5.width, reroute_008_5.height = 10.0, 100.0
	    reroute_009_4.width, reroute_009_4.height = 10.0, 100.0
	    reroute_010_4.width, reroute_010_4.height = 10.0, 100.0
	    reroute_011_3.width, reroute_011_3.height = 10.0, 100.0
	    reroute_012_3.width, reroute_012_3.height = 10.0, 100.0
	    reroute_013_3.width, reroute_013_3.height = 10.0, 100.0
	    reroute_014_2.width, reroute_014_2.height = 10.0, 100.0
	    group_input_007_2.width, group_input_007_2.height = 140.0, 100.0
	    store_named_attribute_001_1.width, store_named_attribute_001_1.height = 140.0, 100.0
	    remove_named_attribute.width, remove_named_attribute.height = 170.0, 100.0
	    reroute_015_2.width, reroute_015_2.height = 10.0, 100.0
	    reroute_016_2.width, reroute_016_2.height = 10.0, 100.0
	    set_shade_smooth.width, set_shade_smooth.height = 140.0, 100.0
	    use_mesh_bake.width, use_mesh_bake.height = 140.0, 100.0
	    group_input_008_3.width, group_input_008_3.height = 140.0, 100.0
	    mesh_overall_shape.width, mesh_overall_shape.height = 240.0, 100.0
	    spline_parameter_7.width, spline_parameter_7.height = 140.0, 100.0
	    switch_004_2.width, switch_004_2.height = 140.0, 100.0
	    group_input_009_2.width, group_input_009_2.height = 140.0, 100.0
	    attribute_statistic_3.width, attribute_statistic_3.height = 140.0, 100.0
	    store_named_attribute_002_1.width, store_named_attribute_002_1.height = 140.0, 100.0
	    compare_005_1.width, compare_005_1.height = 140.0, 100.0
	    named_attribute_001_3.width, named_attribute_001_3.height = 140.0, 100.0
	    group_input_010_1.width, group_input_010_1.height = 140.0, 100.0
	
	    #initialize mesh_hair_selector links
	    #use_mesh_bake.Geometry -> group_output_17.Geometry
	    mesh_hair_selector.links.new(use_mesh_bake.outputs[0], group_output_17.inputs[0])
	    #group_input_001_11.Geometry -> group_4.Geometry
	    mesh_hair_selector.links.new(group_input_001_11.outputs[0], group_4.inputs[0])
	    #group_input_002_9.Geometry -> group_002_1.Geometry
	    mesh_hair_selector.links.new(group_input_002_9.outputs[0], group_002_1.inputs[0])
	    #group_input_003_8.Geometry -> group_003_1.Geometry
	    mesh_hair_selector.links.new(group_input_003_8.outputs[0], group_003_1.inputs[0])
	    #group_input_001_11.Material -> group_4.Material
	    mesh_hair_selector.links.new(group_input_001_11.outputs[2], group_4.inputs[1])
	    #named_attribute_5.Attribute -> store_named_attribute_8.Value
	    mesh_hair_selector.links.new(named_attribute_5.outputs[0], store_named_attribute_8.inputs[3])
	    #reroute_013_3.Output -> named_attribute_5.Name
	    mesh_hair_selector.links.new(reroute_013_3.outputs[0], named_attribute_5.inputs[0])
	    #group_input_005_7.Style Select -> menu_switch_001.Menu
	    mesh_hair_selector.links.new(group_input_005_7.outputs[1], menu_switch_001.inputs[0])
	    #group_input_001_11.Resolution -> group_4.Resolution
	    mesh_hair_selector.links.new(group_input_001_11.outputs[3], group_4.inputs[3])
	    #group_input_001_11.Width -> group_4.Width
	    mesh_hair_selector.links.new(group_input_001_11.outputs[4], group_4.inputs[4])
	    #group_input_001_11.Hair Card Angle -> group_4.Angle
	    mesh_hair_selector.links.new(group_input_001_11.outputs[8], group_4.inputs[5])
	    #group_input_002_9.Material -> group_002_1.Material
	    mesh_hair_selector.links.new(group_input_002_9.outputs[2], group_002_1.inputs[1])
	    #group_input_002_9.Resolution -> group_002_1.Resolution
	    mesh_hair_selector.links.new(group_input_002_9.outputs[3], group_002_1.inputs[3])
	    #group_input_002_9.Width -> group_002_1.Width
	    mesh_hair_selector.links.new(group_input_002_9.outputs[4], group_002_1.inputs[4])
	    #group_input_002_9.Fill Caps -> group_002_1.Fill Caps
	    mesh_hair_selector.links.new(group_input_002_9.outputs[6], group_002_1.inputs[5])
	    #group_input_003_8.Material -> group_003_1.Material
	    mesh_hair_selector.links.new(group_input_003_8.outputs[2], group_003_1.inputs[1])
	    #group_input_003_8.Resolution -> group_003_1.Resolution
	    mesh_hair_selector.links.new(group_input_003_8.outputs[3], group_003_1.inputs[4])
	    #group_input_003_8.Width -> group_003_1.Width
	    mesh_hair_selector.links.new(group_input_003_8.outputs[4], group_003_1.inputs[5])
	    #group_input_003_8.Tube Ribbon Count -> group_003_1.Ribbon Count
	    mesh_hair_selector.links.new(group_input_003_8.outputs[9], group_003_1.inputs[3])
	    #group_input_004_7.Material -> group_001_2.Material
	    mesh_hair_selector.links.new(group_input_004_7.outputs[2], group_001_2.inputs[2])
	    #group_input_004_7.Fill Caps -> group_001_2.Fill Caps
	    mesh_hair_selector.links.new(group_input_004_7.outputs[6], group_001_2.inputs[5])
	    #group_input_004_7.Profile Translation -> group_001_2.Translation
	    mesh_hair_selector.links.new(group_input_004_7.outputs[11], group_001_2.inputs[6])
	    #group_input_004_7.Profile Rotation -> group_001_2.Rotation
	    mesh_hair_selector.links.new(group_input_004_7.outputs[12], group_001_2.inputs[7])
	    #group_input_004_7.Profile Scale -> group_001_2.Scale
	    mesh_hair_selector.links.new(group_input_004_7.outputs[13], group_001_2.inputs[8])
	    #group_input_006_3.Profile Curve -> group_001_2.Profile
	    mesh_hair_selector.links.new(group_input_006_3.outputs[10], group_001_2.inputs[1])
	    #group_input_004_7.Resolution -> group_001_2.Resolution
	    mesh_hair_selector.links.new(group_input_004_7.outputs[3], group_001_2.inputs[4])
	    #compare_9.Result -> switch_8.Switch
	    mesh_hair_selector.links.new(compare_9.outputs[0], switch_8.inputs[0])
	    #compare_001_5.Result -> switch_001_5.Switch
	    mesh_hair_selector.links.new(compare_001_5.outputs[0], switch_001_5.inputs[0])
	    #compare_002_5.Result -> switch_002_2.Switch
	    mesh_hair_selector.links.new(compare_002_5.outputs[0], switch_002_2.inputs[0])
	    #reroute_009_4.Output -> compare_003_2.A
	    mesh_hair_selector.links.new(reroute_009_4.outputs[0], compare_003_2.inputs[8])
	    #compare_003_2.Result -> switch_003_3.Switch
	    mesh_hair_selector.links.new(compare_003_2.outputs[0], switch_003_3.inputs[0])
	    #switch_001_5.Output -> switch_8.False
	    mesh_hair_selector.links.new(switch_001_5.outputs[0], switch_8.inputs[1])
	    #switch_002_2.Output -> switch_001_5.False
	    mesh_hair_selector.links.new(switch_002_2.outputs[0], switch_001_5.inputs[1])
	    #switch_003_3.Output -> switch_002_2.False
	    mesh_hair_selector.links.new(switch_003_3.outputs[0], switch_002_2.inputs[1])
	    #reroute_004_6.Output -> menu_switch_001.Hair Card
	    mesh_hair_selector.links.new(reroute_004_6.outputs[0], menu_switch_001.inputs[1])
	    #reroute_10.Output -> compare_9.B
	    mesh_hair_selector.links.new(reroute_10.outputs[0], compare_9.inputs[9])
	    #group_4.Geometry -> switch_8.True
	    mesh_hair_selector.links.new(group_4.outputs[0], switch_8.inputs[2])
	    #reroute_005_6.Output -> menu_switch_001.Tube Mesh
	    mesh_hair_selector.links.new(reroute_005_6.outputs[0], menu_switch_001.inputs[2])
	    #reroute_001_9.Output -> compare_001_5.B
	    mesh_hair_selector.links.new(reroute_001_9.outputs[0], compare_001_5.inputs[9])
	    #group_002_1.Geometry -> switch_001_5.True
	    mesh_hair_selector.links.new(group_002_1.outputs[0], switch_001_5.inputs[2])
	    #reroute_006_5.Output -> menu_switch_001.Tube Ribbon
	    mesh_hair_selector.links.new(reroute_006_5.outputs[0], menu_switch_001.inputs[3])
	    #reroute_002_7.Output -> compare_002_5.B
	    mesh_hair_selector.links.new(reroute_002_7.outputs[0], compare_002_5.inputs[9])
	    #group_003_1.Geometry -> switch_002_2.True
	    mesh_hair_selector.links.new(group_003_1.outputs[0], switch_002_2.inputs[2])
	    #reroute_007_5.Output -> menu_switch_001.Stylized
	    mesh_hair_selector.links.new(reroute_007_5.outputs[0], menu_switch_001.inputs[4])
	    #reroute_003_5.Output -> compare_003_2.B
	    mesh_hair_selector.links.new(reroute_003_5.outputs[0], compare_003_2.inputs[9])
	    #group_001_2.Geometry -> switch_003_3.True
	    mesh_hair_selector.links.new(group_001_2.outputs[0], switch_003_3.inputs[2])
	    #switch_8.Output -> store_named_attribute_8.Geometry
	    mesh_hair_selector.links.new(switch_8.outputs[0], store_named_attribute_8.inputs[0])
	    #string.String -> reroute_10.Input
	    mesh_hair_selector.links.new(string.outputs[0], reroute_10.inputs[0])
	    #string_001.String -> reroute_001_9.Input
	    mesh_hair_selector.links.new(string_001.outputs[0], reroute_001_9.inputs[0])
	    #string_002.String -> reroute_002_7.Input
	    mesh_hair_selector.links.new(string_002.outputs[0], reroute_002_7.inputs[0])
	    #string_003.String -> reroute_003_5.Input
	    mesh_hair_selector.links.new(string_003.outputs[0], reroute_003_5.inputs[0])
	    #reroute_10.Output -> reroute_004_6.Input
	    mesh_hair_selector.links.new(reroute_10.outputs[0], reroute_004_6.inputs[0])
	    #reroute_001_9.Output -> reroute_005_6.Input
	    mesh_hair_selector.links.new(reroute_001_9.outputs[0], reroute_005_6.inputs[0])
	    #reroute_002_7.Output -> reroute_006_5.Input
	    mesh_hair_selector.links.new(reroute_002_7.outputs[0], reroute_006_5.inputs[0])
	    #reroute_003_5.Output -> reroute_007_5.Input
	    mesh_hair_selector.links.new(reroute_003_5.outputs[0], reroute_007_5.inputs[0])
	    #menu_switch_001.Output -> reroute_008_5.Input
	    mesh_hair_selector.links.new(menu_switch_001.outputs[0], reroute_008_5.inputs[0])
	    #reroute_010_4.Output -> reroute_009_4.Input
	    mesh_hair_selector.links.new(reroute_010_4.outputs[0], reroute_009_4.inputs[0])
	    #reroute_011_3.Output -> reroute_010_4.Input
	    mesh_hair_selector.links.new(reroute_011_3.outputs[0], reroute_010_4.inputs[0])
	    #reroute_010_4.Output -> compare_002_5.A
	    mesh_hair_selector.links.new(reroute_010_4.outputs[0], compare_002_5.inputs[8])
	    #reroute_012_3.Output -> reroute_011_3.Input
	    mesh_hair_selector.links.new(reroute_012_3.outputs[0], reroute_011_3.inputs[0])
	    #reroute_008_5.Output -> reroute_012_3.Input
	    mesh_hair_selector.links.new(reroute_008_5.outputs[0], reroute_012_3.inputs[0])
	    #reroute_011_3.Output -> compare_001_5.A
	    mesh_hair_selector.links.new(reroute_011_3.outputs[0], compare_001_5.inputs[8])
	    #reroute_012_3.Output -> compare_9.A
	    mesh_hair_selector.links.new(reroute_012_3.outputs[0], compare_9.inputs[8])
	    #reroute_014_2.Output -> reroute_013_3.Input
	    mesh_hair_selector.links.new(reroute_014_2.outputs[0], reroute_013_3.inputs[0])
	    #reroute_008_5.Output -> reroute_014_2.Input
	    mesh_hair_selector.links.new(reroute_008_5.outputs[0], reroute_014_2.inputs[0])
	    #store_named_attribute_8.Geometry -> store_named_attribute_001_1.Geometry
	    mesh_hair_selector.links.new(store_named_attribute_8.outputs[0], store_named_attribute_001_1.inputs[0])
	    #group_input_007_2.Mesh Index -> store_named_attribute_001_1.Value
	    mesh_hair_selector.links.new(group_input_007_2.outputs[14], store_named_attribute_001_1.inputs[3])
	    #store_named_attribute_001_1.Geometry -> remove_named_attribute.Geometry
	    mesh_hair_selector.links.new(store_named_attribute_001_1.outputs[0], remove_named_attribute.inputs[0])
	    #reroute_016_2.Output -> remove_named_attribute.Name
	    mesh_hair_selector.links.new(reroute_016_2.outputs[0], remove_named_attribute.inputs[1])
	    #reroute_014_2.Output -> reroute_015_2.Input
	    mesh_hair_selector.links.new(reroute_014_2.outputs[0], reroute_015_2.inputs[0])
	    #reroute_015_2.Output -> reroute_016_2.Input
	    mesh_hair_selector.links.new(reroute_015_2.outputs[0], reroute_016_2.inputs[0])
	    #set_shade_smooth.Geometry -> use_mesh_bake.Geometry
	    mesh_hair_selector.links.new(set_shade_smooth.outputs[0], use_mesh_bake.inputs[0])
	    #remove_named_attribute.Geometry -> set_shade_smooth.Geometry
	    mesh_hair_selector.links.new(remove_named_attribute.outputs[0], set_shade_smooth.inputs[0])
	    #group_input_008_3.Shade Smooth -> set_shade_smooth.Shade Smooth
	    mesh_hair_selector.links.new(group_input_008_3.outputs[7], set_shade_smooth.inputs[2])
	    #switch_004_2.Output -> group_001_2.Curve Radius
	    mesh_hair_selector.links.new(switch_004_2.outputs[0], group_001_2.inputs[3])
	    #switch_004_2.Output -> group_003_1.Curve Radius
	    mesh_hair_selector.links.new(switch_004_2.outputs[0], group_003_1.inputs[2])
	    #switch_004_2.Output -> group_002_1.Curve Radius
	    mesh_hair_selector.links.new(switch_004_2.outputs[0], group_002_1.inputs[2])
	    #switch_004_2.Output -> group_4.Curve Radius
	    mesh_hair_selector.links.new(switch_004_2.outputs[0], group_4.inputs[2])
	    #spline_parameter_7.Factor -> mesh_overall_shape.Value
	    mesh_hair_selector.links.new(spline_parameter_7.outputs[0], mesh_overall_shape.inputs[1])
	    #group_input_009_2.Curve Radius -> store_named_attribute_002_1.Value
	    mesh_hair_selector.links.new(group_input_009_2.outputs[5], store_named_attribute_002_1.inputs[3])
	    #store_named_attribute_002_1.Geometry -> attribute_statistic_3.Geometry
	    mesh_hair_selector.links.new(store_named_attribute_002_1.outputs[0], attribute_statistic_3.inputs[0])
	    #attribute_statistic_3.Sum -> compare_005_1.A
	    mesh_hair_selector.links.new(attribute_statistic_3.outputs[2], compare_005_1.inputs[0])
	    #compare_005_1.Result -> switch_004_2.Switch
	    mesh_hair_selector.links.new(compare_005_1.outputs[0], switch_004_2.inputs[0])
	    #named_attribute_001_3.Attribute -> attribute_statistic_3.Attribute
	    mesh_hair_selector.links.new(named_attribute_001_3.outputs[0], attribute_statistic_3.inputs[2])
	    #mesh_overall_shape.Value -> switch_004_2.True
	    mesh_hair_selector.links.new(mesh_overall_shape.outputs[0], switch_004_2.inputs[2])
	    #group_input_009_2.Curve Radius -> switch_004_2.False
	    mesh_hair_selector.links.new(group_input_009_2.outputs[5], switch_004_2.inputs[1])
	    #group_input_010_1.Geometry -> store_named_attribute_002_1.Geometry
	    mesh_hair_selector.links.new(group_input_010_1.outputs[0], store_named_attribute_002_1.inputs[0])
	    #group_input_004_7.Geometry -> group_001_2.Geometry
	    mesh_hair_selector.links.new(group_input_004_7.outputs[0], group_001_2.inputs[0])
	    style_select_socket.default_value = 'Hair Card'
	    return mesh_hair_selector
	
	mesh_hair_selector = mesh_hair_selector_node_group()
	
	#initialize shape_curve_to_guidez node group
	def shape_curve_to_guidez_node_group():
	    shape_curve_to_guidez = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "SHAPE_CURVE_TO_GUIDEZ")
	
	    shape_curve_to_guidez.color_tag = 'NONE'
	    shape_curve_to_guidez.description = "Shape curve towards matching a guide curve."
	    shape_curve_to_guidez.default_group_node_width = 140
	    
	
	    shape_curve_to_guidez.is_modifier = True
	
	    #shape_curve_to_guidez interface
	    #Socket Geometry
	    geometry_socket_29 = shape_curve_to_guidez.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_29.attribute_domain = 'POINT'
	    geometry_socket_29.description = "Modified shaped curve."
	
	    #Socket Geometry
	    geometry_socket_30 = shape_curve_to_guidez.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_30.attribute_domain = 'POINT'
	    geometry_socket_30.description = "Hair Curve."
	
	    #Socket Surface
	    surface_socket_6 = shape_curve_to_guidez.interface.new_socket(name = "Surface", in_out='INPUT', socket_type = 'NodeSocketObject')
	    surface_socket_6.attribute_domain = 'POINT'
	    surface_socket_6.description = "Surface Object to attach to (needs to have matching transforms)"
	
	    #Socket Curve Guide
	    curve_guide_socket = shape_curve_to_guidez.interface.new_socket(name = "Curve Guide", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    curve_guide_socket.attribute_domain = 'POINT'
	    curve_guide_socket.description = "Curve to guide new shape."
	
	    #Socket Curve Guide
	    curve_guide_socket_1 = shape_curve_to_guidez.interface.new_socket(name = "Curve Guide", in_out='INPUT', socket_type = 'NodeSocketObject')
	    curve_guide_socket_1.attribute_domain = 'POINT'
	    curve_guide_socket_1.description = "Curve to guide new shape."
	
	    #Socket Hair Style
	    hair_style_socket = shape_curve_to_guidez.interface.new_socket(name = "Hair Style", in_out='INPUT', socket_type = 'NodeSocketMenu')
	    hair_style_socket.attribute_domain = 'POINT'
	    hair_style_socket.description = "Style of hair to use fromcurve to mesh types."
	
	    #Socket Control Points
	    control_points_socket_1 = shape_curve_to_guidez.interface.new_socket(name = "Control Points", in_out='INPUT', socket_type = 'NodeSocketInt')
	    control_points_socket_1.default_value = 10
	    control_points_socket_1.min_value = 2
	    control_points_socket_1.max_value = 2147483647
	    control_points_socket_1.subtype = 'NONE'
	    control_points_socket_1.attribute_domain = 'POINT'
	    control_points_socket_1.description = "Amount of points for each curve."
	
	    #Socket Sample Count
	    sample_count_socket = shape_curve_to_guidez.interface.new_socket(name = "Sample Count", in_out='INPUT', socket_type = 'NodeSocketInt')
	    sample_count_socket.default_value = 1
	    sample_count_socket.min_value = 1
	    sample_count_socket.max_value = 100000
	    sample_count_socket.subtype = 'NONE'
	    sample_count_socket.attribute_domain = 'POINT'
	    sample_count_socket.description = "Index of points to start sampling from each curve guide."
	
	    #Socket Hair Strand Radius
	    hair_strand_radius_socket = shape_curve_to_guidez.interface.new_socket(name = "Hair Strand Radius", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    hair_strand_radius_socket.default_value = 0.004999999888241291
	    hair_strand_radius_socket.min_value = 0.0
	    hair_strand_radius_socket.max_value = 3.4028234663852886e+38
	    hair_strand_radius_socket.subtype = 'DISTANCE'
	    hair_strand_radius_socket.attribute_domain = 'POINT'
	    hair_strand_radius_socket.description = "Radius of each hair strand."
	
	    #Socket UV Map
	    uv_map_socket_1 = shape_curve_to_guidez.interface.new_socket(name = "UV Map", in_out='INPUT', socket_type = 'NodeSocketString')
	    uv_map_socket_1.default_value = "UVMap"
	    uv_map_socket_1.subtype = 'NONE'
	    uv_map_socket_1.attribute_domain = 'POINT'
	    uv_map_socket_1.description = "Surface UV Map used to attach hair."
	
	    #Socket Blend along Curve
	    blend_along_curve_socket_2 = shape_curve_to_guidez.interface.new_socket(name = "Blend along Curve", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    blend_along_curve_socket_2.default_value = 0.05000000074505806
	    blend_along_curve_socket_2.min_value = 0.0
	    blend_along_curve_socket_2.max_value = 1.0
	    blend_along_curve_socket_2.subtype = 'FACTOR'
	    blend_along_curve_socket_2.attribute_domain = 'POINT'
	    blend_along_curve_socket_2.description = "Blend deformation along each curve from the root"
	
	    #Socket Preserve Length Factor
	    preserve_length_factor_socket = shape_curve_to_guidez.interface.new_socket(name = "Preserve Length Factor", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    preserve_length_factor_socket.default_value = 0.0
	    preserve_length_factor_socket.min_value = 0.0
	    preserve_length_factor_socket.max_value = 1.0
	    preserve_length_factor_socket.subtype = 'FACTOR'
	    preserve_length_factor_socket.attribute_domain = 'POINT'
	    preserve_length_factor_socket.description = "Factor to blend overall effect"
	
	    #Socket Offset index
	    offset_index_socket = shape_curve_to_guidez.interface.new_socket(name = "Offset index", in_out='INPUT', socket_type = 'NodeSocketBool')
	    offset_index_socket.default_value = False
	    offset_index_socket.attribute_domain = 'POINT'
	    offset_index_socket.description = "Use previous target point index to influence new shape."
	
	    #Socket Material
	    material_socket_6 = shape_curve_to_guidez.interface.new_socket(name = "Material", in_out='INPUT', socket_type = 'NodeSocketMaterial')
	    material_socket_6.attribute_domain = 'POINT'
	    material_socket_6.description = "Curve material."
	
	    #Socket Mesh Material
	    mesh_material_socket = shape_curve_to_guidez.interface.new_socket(name = "Mesh Material", in_out='INPUT', socket_type = 'NodeSocketMaterial')
	    mesh_material_socket.attribute_domain = 'POINT'
	    mesh_material_socket.description = "Mesh Material."
	
	    #Panel Stylized Settings
	    stylized_settings_panel = shape_curve_to_guidez.interface.new_panel("Stylized Settings", default_closed=True)
	    stylized_settings_panel.description = "Settings for stylized Hair Style."
	    #Socket Control Points
	    control_points_socket_2 = shape_curve_to_guidez.interface.new_socket(name = "Control Points", in_out='INPUT', socket_type = 'NodeSocketInt', parent = stylized_settings_panel)
	    control_points_socket_2.default_value = 10
	    control_points_socket_2.min_value = 2
	    control_points_socket_2.max_value = 100000
	    control_points_socket_2.subtype = 'NONE'
	    control_points_socket_2.attribute_domain = 'POINT'
	    control_points_socket_2.description = "Amount of points to resample the curves. (Amount < 2  means no resampling)"
	
	    #Socket Radius
	    radius_socket_2 = shape_curve_to_guidez.interface.new_socket(name = "Radius", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = stylized_settings_panel)
	    radius_socket_2.default_value = 1.0
	    radius_socket_2.min_value = 0.0
	    radius_socket_2.max_value = 3.4028234663852886e+38
	    radius_socket_2.subtype = 'DISTANCE'
	    radius_socket_2.attribute_domain = 'POINT'
	    radius_socket_2.description = "Mesh Radius."
	
	    #Panel Enhancement Settings
	    enhancement_settings_panel_2 = shape_curve_to_guidez.interface.new_panel("Enhancement Settings", default_closed=True)
	    #Socket Use Enhancements
	    use_enhancements_socket_2 = shape_curve_to_guidez.interface.new_socket(name = "Use Enhancements", in_out='INPUT', socket_type = 'NodeSocketBool', parent = enhancement_settings_panel_2)
	    use_enhancements_socket_2.default_value = True
	    use_enhancements_socket_2.attribute_domain = 'POINT'
	    use_enhancements_socket_2.description = "Use Enhancement settings."
	
	    #Socket Maintain Shape Factor
	    maintain_shape_factor_socket_2 = shape_curve_to_guidez.interface.new_socket(name = "Maintain Shape Factor", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = enhancement_settings_panel_2)
	    maintain_shape_factor_socket_2.default_value = 1.0
	    maintain_shape_factor_socket_2.min_value = 0.0
	    maintain_shape_factor_socket_2.max_value = 1.0
	    maintain_shape_factor_socket_2.subtype = 'FACTOR'
	    maintain_shape_factor_socket_2.attribute_domain = 'POINT'
	    maintain_shape_factor_socket_2.description = "Factor to blend overall effect"
	
	    #Socket Pin at Parameter
	    pin_at_parameter_socket_3 = shape_curve_to_guidez.interface.new_socket(name = "Pin at Parameter", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = enhancement_settings_panel_2)
	    pin_at_parameter_socket_3.default_value = 0.0
	    pin_at_parameter_socket_3.min_value = 0.0
	    pin_at_parameter_socket_3.max_value = 1.0
	    pin_at_parameter_socket_3.subtype = 'FACTOR'
	    pin_at_parameter_socket_3.attribute_domain = 'POINT'
	    pin_at_parameter_socket_3.description = "Pin each curve at a certain point for the operation"
	
	    #Socket Snap to surface
	    snap_to_surface_socket_3 = shape_curve_to_guidez.interface.new_socket(name = "Snap to surface", in_out='INPUT', socket_type = 'NodeSocketBool', parent = enhancement_settings_panel_2)
	    snap_to_surface_socket_3.default_value = False
	    snap_to_surface_socket_3.attribute_domain = 'POINT'
	    snap_to_surface_socket_3.description = "Snap mesh roots to the nearest surface point."
	
	    #Panel Subdivision Settings
	    subdivision_settings_panel_2 = shape_curve_to_guidez.interface.new_panel("Subdivision Settings", default_closed=True)
	    #Socket Subdivison Level
	    subdivison_level_socket_1 = shape_curve_to_guidez.interface.new_socket(name = "Subdivison Level", in_out='INPUT', socket_type = 'NodeSocketInt', parent = subdivision_settings_panel_2)
	    subdivison_level_socket_1.default_value = 1
	    subdivison_level_socket_1.min_value = 0
	    subdivison_level_socket_1.max_value = 6
	    subdivison_level_socket_1.subtype = 'NONE'
	    subdivison_level_socket_1.attribute_domain = 'POINT'
	    subdivison_level_socket_1.description = "Subdivision level."
	
	    #Socket Edge Crease
	    edge_crease_socket_2 = shape_curve_to_guidez.interface.new_socket(name = "Edge Crease", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = subdivision_settings_panel_2)
	    edge_crease_socket_2.default_value = 0.0
	    edge_crease_socket_2.min_value = 0.0
	    edge_crease_socket_2.max_value = 1.0
	    edge_crease_socket_2.subtype = 'FACTOR'
	    edge_crease_socket_2.attribute_domain = 'POINT'
	    edge_crease_socket_2.description = "Edge crease factor for subdivision."
	
	    #Socket Vertex Crease
	    vertex_crease_socket_2 = shape_curve_to_guidez.interface.new_socket(name = "Vertex Crease", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = subdivision_settings_panel_2)
	    vertex_crease_socket_2.default_value = 0.0
	    vertex_crease_socket_2.min_value = 0.0
	    vertex_crease_socket_2.max_value = 1.0
	    vertex_crease_socket_2.subtype = 'FACTOR'
	    vertex_crease_socket_2.attribute_domain = 'POINT'
	    vertex_crease_socket_2.description = "Vertex crease factor for subdivision."
	
	    #Socket Limit Surface
	    limit_surface_socket_2 = shape_curve_to_guidez.interface.new_socket(name = "Limit Surface", in_out='INPUT', socket_type = 'NodeSocketBool', parent = subdivision_settings_panel_2)
	    limit_surface_socket_2.default_value = True
	    limit_surface_socket_2.attribute_domain = 'POINT'
	    limit_surface_socket_2.description = "Limit subdivision on surface."
	
	
	    shape_curve_to_guidez.interface.move_to_parent(subdivision_settings_panel_2, enhancement_settings_panel_2, 23)
	    #Panel Merge Settings
	    merge_settings_panel_2 = shape_curve_to_guidez.interface.new_panel("Merge Settings", default_closed=True)
	    #Socket Distance
	    distance_socket_2 = shape_curve_to_guidez.interface.new_socket(name = "Distance", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = merge_settings_panel_2)
	    distance_socket_2.default_value = 0.0010000000474974513
	    distance_socket_2.min_value = 0.0
	    distance_socket_2.max_value = 3.4028234663852886e+38
	    distance_socket_2.subtype = 'DISTANCE'
	    distance_socket_2.attribute_domain = 'POINT'
	    distance_socket_2.description = "Distance threshold to merge points."
	
	
	    shape_curve_to_guidez.interface.move_to_parent(merge_settings_panel_2, enhancement_settings_panel_2, 28)
	
	    shape_curve_to_guidez.interface.move_to_parent(enhancement_settings_panel_2, stylized_settings_panel, 18)
	
	    #Panel Mesh Hair Settings
	    mesh_hair_settings_panel = shape_curve_to_guidez.interface.new_panel("Mesh Hair Settings", default_closed=True)
	    mesh_hair_settings_panel.description = "Settings for Mesh Hair Style."
	    #Socket Style Select
	    style_select_socket_1 = shape_curve_to_guidez.interface.new_socket(name = "Style Select", in_out='INPUT', socket_type = 'NodeSocketMenu', parent = mesh_hair_settings_panel)
	    style_select_socket_1.attribute_domain = 'POINT'
	    style_select_socket_1.description = "Mesh style to convert curve."
	
	    #Socket Resolution
	    resolution_socket_5 = shape_curve_to_guidez.interface.new_socket(name = "Resolution", in_out='INPUT', socket_type = 'NodeSocketInt', parent = mesh_hair_settings_panel)
	    resolution_socket_5.default_value = 0
	    resolution_socket_5.min_value = 2
	    resolution_socket_5.max_value = 512
	    resolution_socket_5.subtype = 'NONE'
	    resolution_socket_5.attribute_domain = 'POINT'
	    resolution_socket_5.description = "Control mesh smoothness by add and removing points along curve."
	
	    #Socket Width
	    width_socket_4 = shape_curve_to_guidez.interface.new_socket(name = "Width", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = mesh_hair_settings_panel)
	    width_socket_4.default_value = 0.10000000149011612
	    width_socket_4.min_value = 0.0
	    width_socket_4.max_value = 3.4028234663852886e+38
	    width_socket_4.subtype = 'DISTANCE'
	    width_socket_4.attribute_domain = 'POINT'
	    width_socket_4.description = "Width of mesh object."
	
	    #Socket Fill Caps
	    fill_caps_socket_3 = shape_curve_to_guidez.interface.new_socket(name = "Fill Caps", in_out='INPUT', socket_type = 'NodeSocketBool', parent = mesh_hair_settings_panel)
	    fill_caps_socket_3.default_value = False
	    fill_caps_socket_3.attribute_domain = 'POINT'
	    fill_caps_socket_3.description = "Fill openings with mesh surface. (Used only for [Tube Mesh | Stylized] mesh styles)"
	
	    #Socket Shade Smooth
	    shade_smooth_socket_1 = shape_curve_to_guidez.interface.new_socket(name = "Shade Smooth", in_out='INPUT', socket_type = 'NodeSocketBool', parent = mesh_hair_settings_panel)
	    shade_smooth_socket_1.default_value = False
	    shade_smooth_socket_1.attribute_domain = 'POINT'
	    shade_smooth_socket_1.description = "Use Smooth Shade for mesh."
	
	    #Socket Hair Card Angle
	    hair_card_angle_socket_1 = shape_curve_to_guidez.interface.new_socket(name = "Hair Card Angle", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = mesh_hair_settings_panel)
	    hair_card_angle_socket_1.default_value = 0.0
	    hair_card_angle_socket_1.min_value = -90.0
	    hair_card_angle_socket_1.max_value = 90.0
	    hair_card_angle_socket_1.subtype = 'ANGLE'
	    hair_card_angle_socket_1.attribute_domain = 'POINT'
	    hair_card_angle_socket_1.description = "Angle used to bend hair card. (Mesh Style=Hair Card)"
	
	    #Socket Tube Ribbon Count
	    tube_ribbon_count_socket_1 = shape_curve_to_guidez.interface.new_socket(name = "Tube Ribbon Count", in_out='INPUT', socket_type = 'NodeSocketInt', parent = mesh_hair_settings_panel)
	    tube_ribbon_count_socket_1.default_value = 8
	    tube_ribbon_count_socket_1.min_value = 1
	    tube_ribbon_count_socket_1.max_value = 180
	    tube_ribbon_count_socket_1.subtype = 'NONE'
	    tube_ribbon_count_socket_1.attribute_domain = 'POINT'
	    tube_ribbon_count_socket_1.description = "Amount of billboard like hair cards used to shape hair. (Mesh Style=Tube Ribbon)"
	
	    #Socket Profile Curve
	    profile_curve_socket_1 = shape_curve_to_guidez.interface.new_socket(name = "Profile Curve", in_out='INPUT', socket_type = 'NodeSocketObject', parent = mesh_hair_settings_panel)
	    profile_curve_socket_1.attribute_domain = 'POINT'
	    profile_curve_socket_1.description = "Curve object used as the profile for stylized hair. (Mesh Style=Stylized)"
	
	    #Socket Profile Translation
	    profile_translation_socket_1 = shape_curve_to_guidez.interface.new_socket(name = "Profile Translation", in_out='INPUT', socket_type = 'NodeSocketVector', parent = mesh_hair_settings_panel)
	    profile_translation_socket_1.default_value = (0.0, 0.0, 0.0)
	    profile_translation_socket_1.min_value = -3.4028234663852886e+38
	    profile_translation_socket_1.max_value = 3.4028234663852886e+38
	    profile_translation_socket_1.subtype = 'TRANSLATION'
	    profile_translation_socket_1.attribute_domain = 'POINT'
	    profile_translation_socket_1.description = "Move position of stylized profile from origin. (Mesh Style=Stylized)"
	
	    #Socket Profile Rotation
	    profile_rotation_socket_1 = shape_curve_to_guidez.interface.new_socket(name = "Profile Rotation", in_out='INPUT', socket_type = 'NodeSocketRotation', parent = mesh_hair_settings_panel)
	    profile_rotation_socket_1.default_value = (0.0, 0.0, 0.0)
	    profile_rotation_socket_1.attribute_domain = 'POINT'
	    profile_rotation_socket_1.description = "Rotate the stylized profile from origin. (Mesh Style=Stylized)"
	
	    #Socket Profile Scale
	    profile_scale_socket_1 = shape_curve_to_guidez.interface.new_socket(name = "Profile Scale", in_out='INPUT', socket_type = 'NodeSocketVector', parent = mesh_hair_settings_panel)
	    profile_scale_socket_1.default_value = (1.0, 1.0, 1.0)
	    profile_scale_socket_1.min_value = -3.4028234663852886e+38
	    profile_scale_socket_1.max_value = 3.4028234663852886e+38
	    profile_scale_socket_1.subtype = 'XYZ'
	    profile_scale_socket_1.attribute_domain = 'POINT'
	    profile_scale_socket_1.description = "Scale the stylized profile from origin. (Mesh Style=Stylized)"
	
	
	
	    #initialize shape_curve_to_guidez nodes
	    #node Group Input
	    group_input_15 = shape_curve_to_guidez.nodes.new("NodeGroupInput")
	    group_input_15.name = "Group Input"
	    group_input_15.outputs[2].hide = True
	    group_input_15.outputs[3].hide = True
	    group_input_15.outputs[4].hide = True
	    group_input_15.outputs[5].hide = True
	    group_input_15.outputs[6].hide = True
	    group_input_15.outputs[7].hide = True
	    group_input_15.outputs[10].hide = True
	    group_input_15.outputs[11].hide = True
	    group_input_15.outputs[12].hide = True
	    group_input_15.outputs[13].hide = True
	    group_input_15.outputs[14].hide = True
	    group_input_15.outputs[15].hide = True
	    group_input_15.outputs[16].hide = True
	    group_input_15.outputs[17].hide = True
	    group_input_15.outputs[18].hide = True
	    group_input_15.outputs[19].hide = True
	    group_input_15.outputs[20].hide = True
	    group_input_15.outputs[21].hide = True
	    group_input_15.outputs[22].hide = True
	    group_input_15.outputs[23].hide = True
	    group_input_15.outputs[24].hide = True
	    group_input_15.outputs[25].hide = True
	    group_input_15.outputs[26].hide = True
	    group_input_15.outputs[27].hide = True
	    group_input_15.outputs[28].hide = True
	    group_input_15.outputs[29].hide = True
	    group_input_15.outputs[30].hide = True
	    group_input_15.outputs[31].hide = True
	    group_input_15.outputs[32].hide = True
	    group_input_15.outputs[33].hide = True
	    group_input_15.outputs[34].hide = True
	    group_input_15.outputs[35].hide = True
	    group_input_15.outputs[36].hide = True
	
	    #node Group Output
	    group_output_18 = shape_curve_to_guidez.nodes.new("NodeGroupOutput")
	    group_output_18.name = "Group Output"
	    group_output_18.is_active_output = True
	    group_output_18.inputs[1].hide = True
	
	    #node Store Named Attribute
	    store_named_attribute_9 = shape_curve_to_guidez.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_9.name = "Store Named Attribute"
	    store_named_attribute_9.data_type = 'INT'
	    store_named_attribute_9.domain = 'CURVE'
	    #Selection
	    store_named_attribute_9.inputs[1].default_value = True
	    #Name
	    store_named_attribute_9.inputs[2].default_value = "closest_idx"
	
	    #node Sample Nearest
	    sample_nearest_1 = shape_curve_to_guidez.nodes.new("GeometryNodeSampleNearest")
	    sample_nearest_1.name = "Sample Nearest"
	    sample_nearest_1.hide = True
	    sample_nearest_1.domain = 'POINT'
	
	    #node Curve to Points
	    curve_to_points = shape_curve_to_guidez.nodes.new("GeometryNodeCurveToPoints")
	    curve_to_points.name = "Curve to Points"
	    curve_to_points.hide = True
	    curve_to_points.mode = 'COUNT'
	
	    #node Group Input.001
	    group_input_001_12 = shape_curve_to_guidez.nodes.new("NodeGroupInput")
	    group_input_001_12.name = "Group Input.001"
	    group_input_001_12.outputs[0].hide = True
	    group_input_001_12.outputs[1].hide = True
	    group_input_001_12.outputs[2].hide = True
	    group_input_001_12.outputs[4].hide = True
	    group_input_001_12.outputs[5].hide = True
	    group_input_001_12.outputs[6].hide = True
	    group_input_001_12.outputs[7].hide = True
	    group_input_001_12.outputs[8].hide = True
	    group_input_001_12.outputs[9].hide = True
	    group_input_001_12.outputs[10].hide = True
	    group_input_001_12.outputs[11].hide = True
	    group_input_001_12.outputs[12].hide = True
	    group_input_001_12.outputs[13].hide = True
	    group_input_001_12.outputs[14].hide = True
	    group_input_001_12.outputs[15].hide = True
	    group_input_001_12.outputs[16].hide = True
	    group_input_001_12.outputs[17].hide = True
	    group_input_001_12.outputs[18].hide = True
	    group_input_001_12.outputs[19].hide = True
	    group_input_001_12.outputs[20].hide = True
	    group_input_001_12.outputs[21].hide = True
	    group_input_001_12.outputs[22].hide = True
	    group_input_001_12.outputs[23].hide = True
	    group_input_001_12.outputs[24].hide = True
	    group_input_001_12.outputs[25].hide = True
	    group_input_001_12.outputs[26].hide = True
	    group_input_001_12.outputs[27].hide = True
	    group_input_001_12.outputs[28].hide = True
	    group_input_001_12.outputs[29].hide = True
	    group_input_001_12.outputs[30].hide = True
	    group_input_001_12.outputs[31].hide = True
	    group_input_001_12.outputs[32].hide = True
	    group_input_001_12.outputs[33].hide = True
	    group_input_001_12.outputs[34].hide = True
	    group_input_001_12.outputs[35].hide = True
	    group_input_001_12.outputs[36].hide = True
	
	    #node Sample Curve
	    sample_curve_1 = shape_curve_to_guidez.nodes.new("GeometryNodeSampleCurve")
	    sample_curve_1.name = "Sample Curve"
	    sample_curve_1.hide = True
	    sample_curve_1.data_type = 'FLOAT'
	    sample_curve_1.mode = 'FACTOR'
	    sample_curve_1.use_all_curves = False
	    sample_curve_1.inputs[1].hide = True
	    sample_curve_1.inputs[2].hide = True
	    sample_curve_1.inputs[3].hide = True
	    sample_curve_1.outputs[0].hide = True
	    sample_curve_1.outputs[2].hide = True
	    sample_curve_1.outputs[3].hide = True
	    #Value
	    sample_curve_1.inputs[1].default_value = 0.0
	    #Factor
	    sample_curve_1.inputs[2].default_value = 0.0
	
	    #node Index
	    index_5 = shape_curve_to_guidez.nodes.new("GeometryNodeInputIndex")
	    index_5.name = "Index"
	
	    #node Named Attribute.013
	    named_attribute_013 = shape_curve_to_guidez.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute_013.name = "Named Attribute.013"
	    named_attribute_013.hide = True
	    named_attribute_013.data_type = 'INT'
	    #Name
	    named_attribute_013.inputs[0].default_value = "closest_spline_idx"
	
	    #node Group.006
	    group_006 = shape_curve_to_guidez.nodes.new("GeometryNodeGroup")
	    group_006.name = "Group.006"
	    group_006.node_tree = curve_attractor
	
	    #node Spline Parameter.001
	    spline_parameter_001_1 = shape_curve_to_guidez.nodes.new("GeometryNodeSplineParameter")
	    spline_parameter_001_1.name = "Spline Parameter.001"
	    spline_parameter_001_1.outputs[1].hide = True
	    spline_parameter_001_1.outputs[2].hide = True
	
	    #node Offset Shape Curve
	    offset_shape_curve = shape_curve_to_guidez.nodes.new("ShaderNodeFloatCurve")
	    offset_shape_curve.label = "Offset Shape Curve"
	    offset_shape_curve.name = "Offset Shape Curve"
	    offset_shape_curve.use_custom_color = True
	    offset_shape_curve.color = (0.08484221249818802, 0.08484221249818802, 0.08484221249818802)
	    #mapping settings
	    offset_shape_curve.mapping.extend = 'EXTRAPOLATED'
	    offset_shape_curve.mapping.tone = 'STANDARD'
	    offset_shape_curve.mapping.black_level = (0.0, 0.0, 0.0)
	    offset_shape_curve.mapping.white_level = (1.0, 1.0, 1.0)
	    offset_shape_curve.mapping.clip_min_x = 0.0
	    offset_shape_curve.mapping.clip_min_y = 0.0
	    offset_shape_curve.mapping.clip_max_x = 1.0
	    offset_shape_curve.mapping.clip_max_y = 1.0
	    offset_shape_curve.mapping.use_clip = True
	    #curve 0
	    offset_shape_curve_curve_0 = offset_shape_curve.mapping.curves[0]
	    offset_shape_curve_curve_0_point_0 = offset_shape_curve_curve_0.points[0]
	    offset_shape_curve_curve_0_point_0.location = (0.0, 1.0)
	    offset_shape_curve_curve_0_point_0.handle_type = 'AUTO'
	    offset_shape_curve_curve_0_point_1 = offset_shape_curve_curve_0.points[1]
	    offset_shape_curve_curve_0_point_1.location = (0.059189632534980774, 0.07894738763570786)
	    offset_shape_curve_curve_0_point_1.handle_type = 'AUTO'
	    offset_shape_curve_curve_0_point_2 = offset_shape_curve_curve_0.points.new(0.10000000149011612, 0.0)
	    offset_shape_curve_curve_0_point_2.handle_type = 'VECTOR'
	    offset_shape_curve_curve_0_point_3 = offset_shape_curve_curve_0.points.new(0.5, 0.0)
	    offset_shape_curve_curve_0_point_3.handle_type = 'VECTOR'
	    offset_shape_curve_curve_0_point_4 = offset_shape_curve_curve_0.points.new(1.0, 0.0)
	    offset_shape_curve_curve_0_point_4.handle_type = 'AUTO'
	    #update curve after changes
	    offset_shape_curve.mapping.update()
	    #Factor
	    offset_shape_curve.inputs[0].default_value = 1.0
	
	    #node Frame
	    frame_6 = shape_curve_to_guidez.nodes.new("NodeFrame")
	    frame_6.label = "Offset Shape Curve"
	    frame_6.name = "Frame"
	    frame_6.label_size = 20
	    frame_6.shrink = True
	
	    #node Group Input.002
	    group_input_002_10 = shape_curve_to_guidez.nodes.new("NodeGroupInput")
	    group_input_002_10.name = "Group Input.002"
	    group_input_002_10.outputs[1].hide = True
	    group_input_002_10.outputs[2].hide = True
	    group_input_002_10.outputs[3].hide = True
	    group_input_002_10.outputs[4].hide = True
	    group_input_002_10.outputs[5].hide = True
	    group_input_002_10.outputs[6].hide = True
	    group_input_002_10.outputs[7].hide = True
	    group_input_002_10.outputs[8].hide = True
	    group_input_002_10.outputs[9].hide = True
	    group_input_002_10.outputs[10].hide = True
	    group_input_002_10.outputs[11].hide = True
	    group_input_002_10.outputs[12].hide = True
	    group_input_002_10.outputs[13].hide = True
	    group_input_002_10.outputs[14].hide = True
	    group_input_002_10.outputs[15].hide = True
	    group_input_002_10.outputs[16].hide = True
	    group_input_002_10.outputs[17].hide = True
	    group_input_002_10.outputs[18].hide = True
	    group_input_002_10.outputs[19].hide = True
	    group_input_002_10.outputs[20].hide = True
	    group_input_002_10.outputs[21].hide = True
	    group_input_002_10.outputs[22].hide = True
	    group_input_002_10.outputs[23].hide = True
	    group_input_002_10.outputs[24].hide = True
	    group_input_002_10.outputs[25].hide = True
	    group_input_002_10.outputs[26].hide = True
	    group_input_002_10.outputs[27].hide = True
	    group_input_002_10.outputs[28].hide = True
	    group_input_002_10.outputs[29].hide = True
	    group_input_002_10.outputs[30].hide = True
	    group_input_002_10.outputs[31].hide = True
	    group_input_002_10.outputs[32].hide = True
	    group_input_002_10.outputs[33].hide = True
	    group_input_002_10.outputs[34].hide = True
	    group_input_002_10.outputs[35].hide = True
	    group_input_002_10.outputs[36].hide = True
	
	    #node Group Input.003
	    group_input_003_9 = shape_curve_to_guidez.nodes.new("NodeGroupInput")
	    group_input_003_9.name = "Group Input.003"
	    group_input_003_9.outputs[0].hide = True
	    group_input_003_9.outputs[1].hide = True
	    group_input_003_9.outputs[3].hide = True
	    group_input_003_9.outputs[4].hide = True
	    group_input_003_9.outputs[5].hide = True
	    group_input_003_9.outputs[6].hide = True
	    group_input_003_9.outputs[7].hide = True
	    group_input_003_9.outputs[8].hide = True
	    group_input_003_9.outputs[9].hide = True
	    group_input_003_9.outputs[10].hide = True
	    group_input_003_9.outputs[11].hide = True
	    group_input_003_9.outputs[12].hide = True
	    group_input_003_9.outputs[13].hide = True
	    group_input_003_9.outputs[14].hide = True
	    group_input_003_9.outputs[15].hide = True
	    group_input_003_9.outputs[16].hide = True
	    group_input_003_9.outputs[17].hide = True
	    group_input_003_9.outputs[18].hide = True
	    group_input_003_9.outputs[19].hide = True
	    group_input_003_9.outputs[20].hide = True
	    group_input_003_9.outputs[21].hide = True
	    group_input_003_9.outputs[22].hide = True
	    group_input_003_9.outputs[23].hide = True
	    group_input_003_9.outputs[24].hide = True
	    group_input_003_9.outputs[25].hide = True
	    group_input_003_9.outputs[26].hide = True
	    group_input_003_9.outputs[27].hide = True
	    group_input_003_9.outputs[28].hide = True
	    group_input_003_9.outputs[29].hide = True
	    group_input_003_9.outputs[30].hide = True
	    group_input_003_9.outputs[31].hide = True
	    group_input_003_9.outputs[32].hide = True
	    group_input_003_9.outputs[33].hide = True
	    group_input_003_9.outputs[34].hide = True
	    group_input_003_9.outputs[35].hide = True
	    group_input_003_9.outputs[36].hide = True
	
	    #node Switch.001
	    switch_001_6 = shape_curve_to_guidez.nodes.new("GeometryNodeSwitch")
	    switch_001_6.name = "Switch.001"
	    switch_001_6.hide = True
	    switch_001_6.input_type = 'INT'
	
	    #node Reroute
	    reroute_11 = shape_curve_to_guidez.nodes.new("NodeReroute")
	    reroute_11.name = "Reroute"
	    reroute_11.socket_idname = "NodeSocketFloat"
	    #node Group.001
	    group_001_3 = shape_curve_to_guidez.nodes.new("GeometryNodeGroup")
	    group_001_3.name = "Group.001"
	    group_001_3.hide = True
	    group_001_3.node_tree = curve_geometry_priority
	
	    #node Group Input.007
	    group_input_007_3 = shape_curve_to_guidez.nodes.new("NodeGroupInput")
	    group_input_007_3.name = "Group Input.007"
	    group_input_007_3.outputs[0].hide = True
	    group_input_007_3.outputs[1].hide = True
	    group_input_007_3.outputs[2].hide = True
	    group_input_007_3.outputs[4].hide = True
	    group_input_007_3.outputs[5].hide = True
	    group_input_007_3.outputs[6].hide = True
	    group_input_007_3.outputs[7].hide = True
	    group_input_007_3.outputs[8].hide = True
	    group_input_007_3.outputs[9].hide = True
	    group_input_007_3.outputs[10].hide = True
	    group_input_007_3.outputs[11].hide = True
	    group_input_007_3.outputs[12].hide = True
	    group_input_007_3.outputs[13].hide = True
	    group_input_007_3.outputs[14].hide = True
	    group_input_007_3.outputs[15].hide = True
	    group_input_007_3.outputs[16].hide = True
	    group_input_007_3.outputs[17].hide = True
	    group_input_007_3.outputs[18].hide = True
	    group_input_007_3.outputs[19].hide = True
	    group_input_007_3.outputs[20].hide = True
	    group_input_007_3.outputs[21].hide = True
	    group_input_007_3.outputs[22].hide = True
	    group_input_007_3.outputs[23].hide = True
	    group_input_007_3.outputs[24].hide = True
	    group_input_007_3.outputs[25].hide = True
	    group_input_007_3.outputs[26].hide = True
	    group_input_007_3.outputs[27].hide = True
	    group_input_007_3.outputs[28].hide = True
	    group_input_007_3.outputs[29].hide = True
	    group_input_007_3.outputs[30].hide = True
	    group_input_007_3.outputs[31].hide = True
	    group_input_007_3.outputs[32].hide = True
	    group_input_007_3.outputs[33].hide = True
	    group_input_007_3.outputs[34].hide = True
	    group_input_007_3.outputs[35].hide = True
	    group_input_007_3.outputs[36].hide = True
	
	    #node Group Input.009
	    group_input_009_3 = shape_curve_to_guidez.nodes.new("NodeGroupInput")
	    group_input_009_3.name = "Group Input.009"
	    group_input_009_3.outputs[0].hide = True
	    group_input_009_3.outputs[1].hide = True
	    group_input_009_3.outputs[3].hide = True
	    group_input_009_3.outputs[4].hide = True
	    group_input_009_3.outputs[5].hide = True
	    group_input_009_3.outputs[6].hide = True
	    group_input_009_3.outputs[7].hide = True
	    group_input_009_3.outputs[8].hide = True
	    group_input_009_3.outputs[9].hide = True
	    group_input_009_3.outputs[10].hide = True
	    group_input_009_3.outputs[11].hide = True
	    group_input_009_3.outputs[12].hide = True
	    group_input_009_3.outputs[13].hide = True
	    group_input_009_3.outputs[14].hide = True
	    group_input_009_3.outputs[15].hide = True
	    group_input_009_3.outputs[16].hide = True
	    group_input_009_3.outputs[17].hide = True
	    group_input_009_3.outputs[18].hide = True
	    group_input_009_3.outputs[19].hide = True
	    group_input_009_3.outputs[20].hide = True
	    group_input_009_3.outputs[21].hide = True
	    group_input_009_3.outputs[22].hide = True
	    group_input_009_3.outputs[23].hide = True
	    group_input_009_3.outputs[24].hide = True
	    group_input_009_3.outputs[25].hide = True
	    group_input_009_3.outputs[26].hide = True
	    group_input_009_3.outputs[27].hide = True
	    group_input_009_3.outputs[28].hide = True
	    group_input_009_3.outputs[29].hide = True
	    group_input_009_3.outputs[30].hide = True
	    group_input_009_3.outputs[31].hide = True
	    group_input_009_3.outputs[32].hide = True
	    group_input_009_3.outputs[33].hide = True
	    group_input_009_3.outputs[34].hide = True
	    group_input_009_3.outputs[35].hide = True
	    group_input_009_3.outputs[36].hide = True
	
	    #node Group.002
	    group_002_2 = shape_curve_to_guidez.nodes.new("GeometryNodeGroup")
	    group_002_2.name = "Group.002"
	    group_002_2.hide = True
	    group_002_2.node_tree = curve_geometry_priority
	
	    #node Group Input.012
	    group_input_012 = shape_curve_to_guidez.nodes.new("NodeGroupInput")
	    group_input_012.name = "Group Input.012"
	    group_input_012.outputs[0].hide = True
	    group_input_012.outputs[1].hide = True
	    group_input_012.outputs[2].hide = True
	    group_input_012.outputs[3].hide = True
	    group_input_012.outputs[4].hide = True
	    group_input_012.outputs[6].hide = True
	    group_input_012.outputs[7].hide = True
	    group_input_012.outputs[8].hide = True
	    group_input_012.outputs[9].hide = True
	    group_input_012.outputs[10].hide = True
	    group_input_012.outputs[11].hide = True
	    group_input_012.outputs[12].hide = True
	    group_input_012.outputs[13].hide = True
	    group_input_012.outputs[14].hide = True
	    group_input_012.outputs[15].hide = True
	    group_input_012.outputs[16].hide = True
	    group_input_012.outputs[17].hide = True
	    group_input_012.outputs[18].hide = True
	    group_input_012.outputs[19].hide = True
	    group_input_012.outputs[20].hide = True
	    group_input_012.outputs[21].hide = True
	    group_input_012.outputs[22].hide = True
	    group_input_012.outputs[23].hide = True
	    group_input_012.outputs[24].hide = True
	    group_input_012.outputs[25].hide = True
	    group_input_012.outputs[26].hide = True
	    group_input_012.outputs[27].hide = True
	    group_input_012.outputs[28].hide = True
	    group_input_012.outputs[29].hide = True
	    group_input_012.outputs[30].hide = True
	    group_input_012.outputs[31].hide = True
	    group_input_012.outputs[32].hide = True
	    group_input_012.outputs[33].hide = True
	    group_input_012.outputs[34].hide = True
	    group_input_012.outputs[35].hide = True
	    group_input_012.outputs[36].hide = True
	
	    #node Store Named Attribute.001
	    store_named_attribute_001_2 = shape_curve_to_guidez.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_001_2.name = "Store Named Attribute.001"
	    store_named_attribute_001_2.data_type = 'INT'
	    store_named_attribute_001_2.domain = 'CURVE'
	    #Selection
	    store_named_attribute_001_2.inputs[1].default_value = True
	    #Name
	    store_named_attribute_001_2.inputs[2].default_value = "closest_spline_idx"
	
	    #node Named Attribute
	    named_attribute_6 = shape_curve_to_guidez.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute_6.name = "Named Attribute"
	    named_attribute_6.hide = True
	    named_attribute_6.data_type = 'INT'
	    #Name
	    named_attribute_6.inputs[0].default_value = "closest_idx"
	
	    #node Math
	    math_4 = shape_curve_to_guidez.nodes.new("ShaderNodeMath")
	    math_4.name = "Math"
	    math_4.hide = True
	    math_4.operation = 'DIVIDE'
	    math_4.use_clamp = False
	
	    #node Group Input.004
	    group_input_004_8 = shape_curve_to_guidez.nodes.new("NodeGroupInput")
	    group_input_004_8.name = "Group Input.004"
	    group_input_004_8.outputs[0].hide = True
	    group_input_004_8.outputs[1].hide = True
	    group_input_004_8.outputs[2].hide = True
	    group_input_004_8.outputs[3].hide = True
	    group_input_004_8.outputs[4].hide = True
	    group_input_004_8.outputs[5].hide = True
	    group_input_004_8.outputs[7].hide = True
	    group_input_004_8.outputs[8].hide = True
	    group_input_004_8.outputs[9].hide = True
	    group_input_004_8.outputs[10].hide = True
	    group_input_004_8.outputs[11].hide = True
	    group_input_004_8.outputs[12].hide = True
	    group_input_004_8.outputs[13].hide = True
	    group_input_004_8.outputs[14].hide = True
	    group_input_004_8.outputs[15].hide = True
	    group_input_004_8.outputs[16].hide = True
	    group_input_004_8.outputs[17].hide = True
	    group_input_004_8.outputs[18].hide = True
	    group_input_004_8.outputs[19].hide = True
	    group_input_004_8.outputs[20].hide = True
	    group_input_004_8.outputs[21].hide = True
	    group_input_004_8.outputs[22].hide = True
	    group_input_004_8.outputs[23].hide = True
	    group_input_004_8.outputs[24].hide = True
	    group_input_004_8.outputs[25].hide = True
	    group_input_004_8.outputs[26].hide = True
	    group_input_004_8.outputs[27].hide = True
	    group_input_004_8.outputs[28].hide = True
	    group_input_004_8.outputs[29].hide = True
	    group_input_004_8.outputs[30].hide = True
	    group_input_004_8.outputs[31].hide = True
	    group_input_004_8.outputs[32].hide = True
	    group_input_004_8.outputs[33].hide = True
	    group_input_004_8.outputs[34].hide = True
	    group_input_004_8.outputs[35].hide = True
	    group_input_004_8.outputs[36].hide = True
	
	    #node Group Input.005
	    group_input_005_8 = shape_curve_to_guidez.nodes.new("NodeGroupInput")
	    group_input_005_8.name = "Group Input.005"
	    group_input_005_8.outputs[0].hide = True
	    group_input_005_8.outputs[1].hide = True
	    group_input_005_8.outputs[2].hide = True
	    group_input_005_8.outputs[3].hide = True
	    group_input_005_8.outputs[4].hide = True
	    group_input_005_8.outputs[5].hide = True
	    group_input_005_8.outputs[7].hide = True
	    group_input_005_8.outputs[8].hide = True
	    group_input_005_8.outputs[9].hide = True
	    group_input_005_8.outputs[10].hide = True
	    group_input_005_8.outputs[11].hide = True
	    group_input_005_8.outputs[12].hide = True
	    group_input_005_8.outputs[13].hide = True
	    group_input_005_8.outputs[14].hide = True
	    group_input_005_8.outputs[15].hide = True
	    group_input_005_8.outputs[16].hide = True
	    group_input_005_8.outputs[17].hide = True
	    group_input_005_8.outputs[18].hide = True
	    group_input_005_8.outputs[19].hide = True
	    group_input_005_8.outputs[20].hide = True
	    group_input_005_8.outputs[21].hide = True
	    group_input_005_8.outputs[22].hide = True
	    group_input_005_8.outputs[23].hide = True
	    group_input_005_8.outputs[24].hide = True
	    group_input_005_8.outputs[25].hide = True
	    group_input_005_8.outputs[26].hide = True
	    group_input_005_8.outputs[27].hide = True
	    group_input_005_8.outputs[28].hide = True
	    group_input_005_8.outputs[29].hide = True
	    group_input_005_8.outputs[30].hide = True
	    group_input_005_8.outputs[31].hide = True
	    group_input_005_8.outputs[32].hide = True
	    group_input_005_8.outputs[33].hide = True
	    group_input_005_8.outputs[34].hide = True
	    group_input_005_8.outputs[35].hide = True
	    group_input_005_8.outputs[36].hide = True
	
	    #node Math.001
	    math_001_3 = shape_curve_to_guidez.nodes.new("ShaderNodeMath")
	    math_001_3.name = "Math.001"
	    math_001_3.hide = True
	    math_001_3.operation = 'FLOOR'
	    math_001_3.use_clamp = False
	
	    #node Store Named Attribute.002
	    store_named_attribute_002_2 = shape_curve_to_guidez.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_002_2.name = "Store Named Attribute.002"
	    store_named_attribute_002_2.data_type = 'INT'
	    store_named_attribute_002_2.domain = 'CURVE'
	    #Selection
	    store_named_attribute_002_2.inputs[1].default_value = True
	    #Name
	    store_named_attribute_002_2.inputs[2].default_value = "sample_idx"
	
	    #node Math.002
	    math_002_1 = shape_curve_to_guidez.nodes.new("ShaderNodeMath")
	    math_002_1.name = "Math.002"
	    math_002_1.hide = True
	    math_002_1.operation = 'FLOORED_MODULO'
	    math_002_1.use_clamp = False
	
	    #node Group Input.013
	    group_input_013 = shape_curve_to_guidez.nodes.new("NodeGroupInput")
	    group_input_013.name = "Group Input.013"
	    group_input_013.outputs[0].hide = True
	    group_input_013.outputs[1].hide = True
	    group_input_013.outputs[2].hide = True
	    group_input_013.outputs[3].hide = True
	    group_input_013.outputs[4].hide = True
	    group_input_013.outputs[5].hide = True
	    group_input_013.outputs[7].hide = True
	    group_input_013.outputs[8].hide = True
	    group_input_013.outputs[9].hide = True
	    group_input_013.outputs[10].hide = True
	    group_input_013.outputs[11].hide = True
	    group_input_013.outputs[12].hide = True
	    group_input_013.outputs[13].hide = True
	    group_input_013.outputs[14].hide = True
	    group_input_013.outputs[15].hide = True
	    group_input_013.outputs[16].hide = True
	    group_input_013.outputs[17].hide = True
	    group_input_013.outputs[18].hide = True
	    group_input_013.outputs[19].hide = True
	    group_input_013.outputs[20].hide = True
	    group_input_013.outputs[21].hide = True
	    group_input_013.outputs[22].hide = True
	    group_input_013.outputs[23].hide = True
	    group_input_013.outputs[24].hide = True
	    group_input_013.outputs[25].hide = True
	    group_input_013.outputs[26].hide = True
	    group_input_013.outputs[27].hide = True
	    group_input_013.outputs[28].hide = True
	    group_input_013.outputs[29].hide = True
	    group_input_013.outputs[30].hide = True
	    group_input_013.outputs[31].hide = True
	    group_input_013.outputs[32].hide = True
	    group_input_013.outputs[33].hide = True
	    group_input_013.outputs[34].hide = True
	    group_input_013.outputs[35].hide = True
	    group_input_013.outputs[36].hide = True
	
	    #node Named Attribute.016
	    named_attribute_016 = shape_curve_to_guidez.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute_016.name = "Named Attribute.016"
	    named_attribute_016.hide = True
	    named_attribute_016.data_type = 'INT'
	    #Name
	    named_attribute_016.inputs[0].default_value = "sample_idx"
	
	    #node Math.003
	    math_003_1 = shape_curve_to_guidez.nodes.new("ShaderNodeMath")
	    math_003_1.name = "Math.003"
	    math_003_1.hide = True
	    math_003_1.operation = 'SUBTRACT'
	    math_003_1.use_clamp = False
	    #Value_001
	    math_003_1.inputs[1].default_value = 1.0
	
	    #node Frame.001
	    frame_001_3 = shape_curve_to_guidez.nodes.new("NodeFrame")
	    frame_001_3.label = "Attributes"
	    frame_001_3.name = "Frame.001"
	    frame_001_3.label_size = 20
	    frame_001_3.shrink = True
	
	    #node Resample Curve.001
	    resample_curve_001_1 = shape_curve_to_guidez.nodes.new("GeometryNodeResampleCurve")
	    resample_curve_001_1.name = "Resample Curve.001"
	    resample_curve_001_1.keep_last_segment = False
	    resample_curve_001_1.mode = 'COUNT'
	    resample_curve_001_1.inputs[1].hide = True
	    resample_curve_001_1.inputs[3].hide = True
	    #Selection
	    resample_curve_001_1.inputs[1].default_value = True
	
	    #node Store Named Attribute.003
	    store_named_attribute_003_1 = shape_curve_to_guidez.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_003_1.name = "Store Named Attribute.003"
	    store_named_attribute_003_1.data_type = 'FLOAT_VECTOR'
	    store_named_attribute_003_1.domain = 'CURVE'
	    #Selection
	    store_named_attribute_003_1.inputs[1].default_value = True
	    #Name
	    store_named_attribute_003_1.inputs[2].default_value = "closest_pt"
	
	    #node Sample Index
	    sample_index_3 = shape_curve_to_guidez.nodes.new("GeometryNodeSampleIndex")
	    sample_index_3.name = "Sample Index"
	    sample_index_3.hide = True
	    sample_index_3.clamp = False
	    sample_index_3.data_type = 'FLOAT_VECTOR'
	    sample_index_3.domain = 'POINT'
	
	    #node Position.001
	    position_001_3 = shape_curve_to_guidez.nodes.new("GeometryNodeInputPosition")
	    position_001_3.name = "Position.001"
	
	    #node Group.007
	    group_007_1 = shape_curve_to_guidez.nodes.new("GeometryNodeGroup")
	    group_007_1.name = "Group.007"
	    group_007_1.node_tree = restore_curve_segment_length
	    group_007_1.inputs[1].hide = True
	    group_007_1.inputs[4].hide = True
	    #Socket_2
	    group_007_1.inputs[1].default_value = True
	    #Socket_5
	    group_007_1.inputs[4].default_value = 0.0
	
	    #node Named Attribute.001
	    named_attribute_001_4 = shape_curve_to_guidez.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute_001_4.name = "Named Attribute.001"
	    named_attribute_001_4.hide = True
	    named_attribute_001_4.data_type = 'FLOAT_VECTOR'
	    #Name
	    named_attribute_001_4.inputs[0].default_value = "pos"
	
	    #node Store Named Attribute.005
	    store_named_attribute_005_1 = shape_curve_to_guidez.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_005_1.name = "Store Named Attribute.005"
	    store_named_attribute_005_1.data_type = 'FLOAT_VECTOR'
	    store_named_attribute_005_1.domain = 'POINT'
	    #Selection
	    store_named_attribute_005_1.inputs[1].default_value = True
	    #Name
	    store_named_attribute_005_1.inputs[2].default_value = "pos"
	
	    #node Group.008
	    group_008 = shape_curve_to_guidez.nodes.new("GeometryNodeGroup")
	    group_008.name = "Group.008"
	    group_008.node_tree = attach_hair
	
	    #node Group Input.017
	    group_input_017 = shape_curve_to_guidez.nodes.new("NodeGroupInput")
	    group_input_017.name = "Group Input.017"
	    group_input_017.outputs[0].hide = True
	    group_input_017.outputs[1].hide = True
	    group_input_017.outputs[2].hide = True
	    group_input_017.outputs[3].hide = True
	    group_input_017.outputs[4].hide = True
	    group_input_017.outputs[5].hide = True
	    group_input_017.outputs[6].hide = True
	    group_input_017.outputs[7].hide = True
	    group_input_017.outputs[8].hide = True
	    group_input_017.outputs[9].hide = True
	    group_input_017.outputs[11].hide = True
	    group_input_017.outputs[12].hide = True
	    group_input_017.outputs[13].hide = True
	    group_input_017.outputs[14].hide = True
	    group_input_017.outputs[15].hide = True
	    group_input_017.outputs[16].hide = True
	    group_input_017.outputs[17].hide = True
	    group_input_017.outputs[18].hide = True
	    group_input_017.outputs[19].hide = True
	    group_input_017.outputs[20].hide = True
	    group_input_017.outputs[21].hide = True
	    group_input_017.outputs[22].hide = True
	    group_input_017.outputs[23].hide = True
	    group_input_017.outputs[24].hide = True
	    group_input_017.outputs[25].hide = True
	    group_input_017.outputs[26].hide = True
	    group_input_017.outputs[27].hide = True
	    group_input_017.outputs[28].hide = True
	    group_input_017.outputs[29].hide = True
	    group_input_017.outputs[30].hide = True
	    group_input_017.outputs[31].hide = True
	    group_input_017.outputs[32].hide = True
	    group_input_017.outputs[33].hide = True
	    group_input_017.outputs[34].hide = True
	    group_input_017.outputs[35].hide = True
	    group_input_017.outputs[36].hide = True
	
	    #node Reroute.001
	    reroute_001_10 = shape_curve_to_guidez.nodes.new("NodeReroute")
	    reroute_001_10.name = "Reroute.001"
	    reroute_001_10.socket_idname = "NodeSocketFloat"
	    #node Group Input.014
	    group_input_014 = shape_curve_to_guidez.nodes.new("NodeGroupInput")
	    group_input_014.name = "Group Input.014"
	    group_input_014.outputs[0].hide = True
	    group_input_014.outputs[1].hide = True
	    group_input_014.outputs[2].hide = True
	    group_input_014.outputs[3].hide = True
	    group_input_014.outputs[4].hide = True
	    group_input_014.outputs[5].hide = True
	    group_input_014.outputs[6].hide = True
	    group_input_014.outputs[7].hide = True
	    group_input_014.outputs[8].hide = True
	    group_input_014.outputs[9].hide = True
	    group_input_014.outputs[10].hide = True
	    group_input_014.outputs[12].hide = True
	    group_input_014.outputs[13].hide = True
	    group_input_014.outputs[14].hide = True
	    group_input_014.outputs[15].hide = True
	    group_input_014.outputs[16].hide = True
	    group_input_014.outputs[17].hide = True
	    group_input_014.outputs[18].hide = True
	    group_input_014.outputs[19].hide = True
	    group_input_014.outputs[20].hide = True
	    group_input_014.outputs[21].hide = True
	    group_input_014.outputs[22].hide = True
	    group_input_014.outputs[23].hide = True
	    group_input_014.outputs[24].hide = True
	    group_input_014.outputs[25].hide = True
	    group_input_014.outputs[26].hide = True
	    group_input_014.outputs[27].hide = True
	    group_input_014.outputs[28].hide = True
	    group_input_014.outputs[29].hide = True
	    group_input_014.outputs[30].hide = True
	    group_input_014.outputs[31].hide = True
	    group_input_014.outputs[32].hide = True
	    group_input_014.outputs[33].hide = True
	    group_input_014.outputs[34].hide = True
	    group_input_014.outputs[35].hide = True
	    group_input_014.outputs[36].hide = True
	
	    #node Final Bake
	    final_bake = shape_curve_to_guidez.nodes.new("GeometryNodeBake")
	    final_bake.label = "Final Bake"
	    final_bake.name = "Final Bake"
	    final_bake.active_index = 0
	    final_bake.bake_items.clear()
	    final_bake.bake_items.new('GEOMETRY', "Geometry")
	    final_bake.bake_items[0].attribute_domain = 'POINT'
	    final_bake.inputs[1].hide = True
	    final_bake.outputs[1].hide = True
	
	    #node Separate Components
	    separate_components = shape_curve_to_guidez.nodes.new("GeometryNodeSeparateComponents")
	    separate_components.name = "Separate Components"
	    separate_components.hide = True
	
	    #node Join Geometry.001
	    join_geometry_001_1 = shape_curve_to_guidez.nodes.new("GeometryNodeJoinGeometry")
	    join_geometry_001_1.name = "Join Geometry.001"
	
	    #node Reroute.002
	    reroute_002_8 = shape_curve_to_guidez.nodes.new("NodeReroute")
	    reroute_002_8.name = "Reroute.002"
	    reroute_002_8.socket_idname = "NodeSocketGeometry"
	    #node Reroute.003
	    reroute_003_6 = shape_curve_to_guidez.nodes.new("NodeReroute")
	    reroute_003_6.name = "Reroute.003"
	    reroute_003_6.socket_idname = "NodeSocketGeometry"
	    #node Reroute.004
	    reroute_004_7 = shape_curve_to_guidez.nodes.new("NodeReroute")
	    reroute_004_7.name = "Reroute.004"
	    reroute_004_7.socket_idname = "NodeSocketGeometry"
	    #node Reroute.005
	    reroute_005_7 = shape_curve_to_guidez.nodes.new("NodeReroute")
	    reroute_005_7.name = "Reroute.005"
	    reroute_005_7.socket_idname = "NodeSocketGeometry"
	    #node Reroute.006
	    reroute_006_6 = shape_curve_to_guidez.nodes.new("NodeReroute")
	    reroute_006_6.name = "Reroute.006"
	    reroute_006_6.socket_idname = "NodeSocketGeometry"
	    #node Reroute.007
	    reroute_007_6 = shape_curve_to_guidez.nodes.new("NodeReroute")
	    reroute_007_6.name = "Reroute.007"
	    reroute_007_6.socket_idname = "NodeSocketGeometry"
	    #node Reroute.008
	    reroute_008_6 = shape_curve_to_guidez.nodes.new("NodeReroute")
	    reroute_008_6.name = "Reroute.008"
	    reroute_008_6.socket_idname = "NodeSocketGeometry"
	    #node Reroute.009
	    reroute_009_5 = shape_curve_to_guidez.nodes.new("NodeReroute")
	    reroute_009_5.name = "Reroute.009"
	    reroute_009_5.socket_idname = "NodeSocketGeometry"
	    #node Reroute.010
	    reroute_010_5 = shape_curve_to_guidez.nodes.new("NodeReroute")
	    reroute_010_5.name = "Reroute.010"
	    reroute_010_5.socket_idname = "NodeSocketGeometry"
	    #node Reroute.011
	    reroute_011_4 = shape_curve_to_guidez.nodes.new("NodeReroute")
	    reroute_011_4.name = "Reroute.011"
	    reroute_011_4.socket_idname = "NodeSocketGeometry"
	    #node Hair Style
	    hair_style = shape_curve_to_guidez.nodes.new("GeometryNodeMenuSwitch")
	    hair_style.label = "Hair Style"
	    hair_style.name = "Hair Style"
	    hair_style.active_index = 2
	    hair_style.data_type = 'GEOMETRY'
	    hair_style.enum_items.clear()
	    hair_style.enum_items.new("Curve Hair")
	    hair_style.enum_items[0].description = "Hair Curves."
	    hair_style.enum_items.new("Stylized")
	    hair_style.enum_items[1].description = "Stylized mesh hair."
	    hair_style.enum_items.new("Mesh Hair")
	    hair_style.enum_items[2].description = "Mesh hair with multiple options."
	    hair_style.inputs[4].hide = True
	
	    #node Shaped Hair Bake
	    shaped_hair_bake = shape_curve_to_guidez.nodes.new("GeometryNodeBake")
	    shaped_hair_bake.label = "Shaped Hair Bake"
	    shaped_hair_bake.name = "Shaped Hair Bake"
	    shaped_hair_bake.active_index = 0
	    shaped_hair_bake.bake_items.clear()
	    shaped_hair_bake.bake_items.new('GEOMETRY', "Geometry")
	    shaped_hair_bake.bake_items[0].attribute_domain = 'POINT'
	    shaped_hair_bake.inputs[1].hide = True
	    shaped_hair_bake.outputs[1].hide = True
	
	    #node Group
	    group_5 = shape_curve_to_guidez.nodes.new("GeometryNodeGroup")
	    group_5.name = "Group"
	    group_5.node_tree = stylized_meshify_hair
	
	    #node Group.003
	    group_003_2 = shape_curve_to_guidez.nodes.new("GeometryNodeGroup")
	    group_003_2.name = "Group.003"
	    group_003_2.node_tree = mesh_hair_selector
	    group_003_2.inputs[5].hide = True
	    group_003_2.inputs[14].hide = True
	    #Socket_6
	    group_003_2.inputs[5].default_value = 0.0
	    #Socket_15
	    group_003_2.inputs[14].default_value = 0
	
	    #node Group Input.018
	    group_input_018 = shape_curve_to_guidez.nodes.new("NodeGroupInput")
	    group_input_018.name = "Group Input.018"
	    group_input_018.outputs[0].hide = True
	    group_input_018.outputs[1].hide = True
	    group_input_018.outputs[2].hide = True
	    group_input_018.outputs[3].hide = True
	    group_input_018.outputs[5].hide = True
	    group_input_018.outputs[6].hide = True
	    group_input_018.outputs[7].hide = True
	    group_input_018.outputs[8].hide = True
	    group_input_018.outputs[9].hide = True
	    group_input_018.outputs[10].hide = True
	    group_input_018.outputs[11].hide = True
	    group_input_018.outputs[12].hide = True
	    group_input_018.outputs[13].hide = True
	    group_input_018.outputs[14].hide = True
	    group_input_018.outputs[15].hide = True
	    group_input_018.outputs[16].hide = True
	    group_input_018.outputs[17].hide = True
	    group_input_018.outputs[18].hide = True
	    group_input_018.outputs[19].hide = True
	    group_input_018.outputs[20].hide = True
	    group_input_018.outputs[21].hide = True
	    group_input_018.outputs[22].hide = True
	    group_input_018.outputs[23].hide = True
	    group_input_018.outputs[24].hide = True
	    group_input_018.outputs[25].hide = True
	    group_input_018.outputs[26].hide = True
	    group_input_018.outputs[27].hide = True
	    group_input_018.outputs[28].hide = True
	    group_input_018.outputs[29].hide = True
	    group_input_018.outputs[30].hide = True
	    group_input_018.outputs[31].hide = True
	    group_input_018.outputs[32].hide = True
	    group_input_018.outputs[33].hide = True
	    group_input_018.outputs[34].hide = True
	    group_input_018.outputs[35].hide = True
	    group_input_018.outputs[36].hide = True
	
	    #node Group Input.019
	    group_input_019 = shape_curve_to_guidez.nodes.new("NodeGroupInput")
	    group_input_019.name = "Group Input.019"
	    group_input_019.outputs[0].hide = True
	    group_input_019.outputs[2].hide = True
	    group_input_019.outputs[3].hide = True
	    group_input_019.outputs[4].hide = True
	    group_input_019.outputs[5].hide = True
	    group_input_019.outputs[6].hide = True
	    group_input_019.outputs[7].hide = True
	    group_input_019.outputs[8].hide = True
	    group_input_019.outputs[9].hide = True
	    group_input_019.outputs[10].hide = True
	    group_input_019.outputs[11].hide = True
	    group_input_019.outputs[12].hide = True
	    group_input_019.outputs[25].hide = True
	    group_input_019.outputs[26].hide = True
	    group_input_019.outputs[27].hide = True
	    group_input_019.outputs[28].hide = True
	    group_input_019.outputs[29].hide = True
	    group_input_019.outputs[30].hide = True
	    group_input_019.outputs[31].hide = True
	    group_input_019.outputs[32].hide = True
	    group_input_019.outputs[33].hide = True
	    group_input_019.outputs[34].hide = True
	    group_input_019.outputs[35].hide = True
	    group_input_019.outputs[36].hide = True
	
	    #node Group Input.020
	    group_input_020 = shape_curve_to_guidez.nodes.new("NodeGroupInput")
	    group_input_020.name = "Group Input.020"
	    group_input_020.outputs[0].hide = True
	    group_input_020.outputs[1].hide = True
	    group_input_020.outputs[2].hide = True
	    group_input_020.outputs[3].hide = True
	    group_input_020.outputs[4].hide = True
	    group_input_020.outputs[5].hide = True
	    group_input_020.outputs[6].hide = True
	    group_input_020.outputs[7].hide = True
	    group_input_020.outputs[8].hide = True
	    group_input_020.outputs[9].hide = True
	    group_input_020.outputs[10].hide = True
	    group_input_020.outputs[11].hide = True
	    group_input_020.outputs[12].hide = True
	    group_input_020.outputs[14].hide = True
	    group_input_020.outputs[15].hide = True
	    group_input_020.outputs[16].hide = True
	    group_input_020.outputs[17].hide = True
	    group_input_020.outputs[18].hide = True
	    group_input_020.outputs[19].hide = True
	    group_input_020.outputs[20].hide = True
	    group_input_020.outputs[21].hide = True
	    group_input_020.outputs[22].hide = True
	    group_input_020.outputs[23].hide = True
	    group_input_020.outputs[24].hide = True
	    group_input_020.outputs[36].hide = True
	
	    #node Set Material
	    set_material_5 = shape_curve_to_guidez.nodes.new("GeometryNodeSetMaterial")
	    set_material_5.name = "Set Material"
	    set_material_5.inputs[1].hide = True
	    #Selection
	    set_material_5.inputs[1].default_value = True
	
	    #node Group Input.021
	    group_input_021 = shape_curve_to_guidez.nodes.new("NodeGroupInput")
	    group_input_021.name = "Group Input.021"
	    group_input_021.outputs[0].hide = True
	    group_input_021.outputs[1].hide = True
	    group_input_021.outputs[2].hide = True
	    group_input_021.outputs[3].hide = True
	    group_input_021.outputs[4].hide = True
	    group_input_021.outputs[5].hide = True
	    group_input_021.outputs[6].hide = True
	    group_input_021.outputs[7].hide = True
	    group_input_021.outputs[8].hide = True
	    group_input_021.outputs[9].hide = True
	    group_input_021.outputs[10].hide = True
	    group_input_021.outputs[11].hide = True
	    group_input_021.outputs[13].hide = True
	    group_input_021.outputs[14].hide = True
	    group_input_021.outputs[15].hide = True
	    group_input_021.outputs[16].hide = True
	    group_input_021.outputs[17].hide = True
	    group_input_021.outputs[18].hide = True
	    group_input_021.outputs[19].hide = True
	    group_input_021.outputs[20].hide = True
	    group_input_021.outputs[21].hide = True
	    group_input_021.outputs[22].hide = True
	    group_input_021.outputs[23].hide = True
	    group_input_021.outputs[24].hide = True
	    group_input_021.outputs[25].hide = True
	    group_input_021.outputs[26].hide = True
	    group_input_021.outputs[27].hide = True
	    group_input_021.outputs[28].hide = True
	    group_input_021.outputs[29].hide = True
	    group_input_021.outputs[30].hide = True
	    group_input_021.outputs[31].hide = True
	    group_input_021.outputs[32].hide = True
	    group_input_021.outputs[33].hide = True
	    group_input_021.outputs[34].hide = True
	    group_input_021.outputs[35].hide = True
	    group_input_021.outputs[36].hide = True
	
	    #node Spline Parameter
	    spline_parameter_8 = shape_curve_to_guidez.nodes.new("GeometryNodeSplineParameter")
	    spline_parameter_8.name = "Spline Parameter"
	    spline_parameter_8.outputs[1].hide = True
	    spline_parameter_8.outputs[2].hide = True
	
	    #node Map Range
	    map_range_2 = shape_curve_to_guidez.nodes.new("ShaderNodeMapRange")
	    map_range_2.name = "Map Range"
	    map_range_2.hide = True
	    map_range_2.clamp = True
	    map_range_2.data_type = 'FLOAT'
	    map_range_2.interpolation_type = 'LINEAR'
	    map_range_2.inputs[1].hide = True
	    map_range_2.inputs[2].hide = True
	    map_range_2.inputs[3].hide = True
	    map_range_2.inputs[5].hide = True
	    map_range_2.inputs[6].hide = True
	    map_range_2.inputs[7].hide = True
	    map_range_2.inputs[8].hide = True
	    map_range_2.inputs[9].hide = True
	    map_range_2.inputs[10].hide = True
	    map_range_2.inputs[11].hide = True
	    map_range_2.outputs[1].hide = True
	    #From Min
	    map_range_2.inputs[1].default_value = 0.0
	    #From Max
	    map_range_2.inputs[2].default_value = 1.0
	    #To Min
	    map_range_2.inputs[3].default_value = 0.0
	
	    #node Set Curve Radius
	    set_curve_radius_5 = shape_curve_to_guidez.nodes.new("GeometryNodeSetCurveRadius")
	    set_curve_radius_5.name = "Set Curve Radius"
	    set_curve_radius_5.hide = True
	    set_curve_radius_5.inputs[1].hide = True
	    #Selection
	    set_curve_radius_5.inputs[1].default_value = True
	
	    #node Group Input.006
	    group_input_006_4 = shape_curve_to_guidez.nodes.new("NodeGroupInput")
	    group_input_006_4.name = "Group Input.006"
	    group_input_006_4.outputs[0].hide = True
	    group_input_006_4.outputs[1].hide = True
	    group_input_006_4.outputs[2].hide = True
	    group_input_006_4.outputs[3].hide = True
	    group_input_006_4.outputs[4].hide = True
	    group_input_006_4.outputs[5].hide = True
	    group_input_006_4.outputs[6].hide = True
	    group_input_006_4.outputs[8].hide = True
	    group_input_006_4.outputs[9].hide = True
	    group_input_006_4.outputs[10].hide = True
	    group_input_006_4.outputs[11].hide = True
	    group_input_006_4.outputs[12].hide = True
	    group_input_006_4.outputs[13].hide = True
	    group_input_006_4.outputs[14].hide = True
	    group_input_006_4.outputs[15].hide = True
	    group_input_006_4.outputs[16].hide = True
	    group_input_006_4.outputs[17].hide = True
	    group_input_006_4.outputs[18].hide = True
	    group_input_006_4.outputs[19].hide = True
	    group_input_006_4.outputs[20].hide = True
	    group_input_006_4.outputs[21].hide = True
	    group_input_006_4.outputs[22].hide = True
	    group_input_006_4.outputs[23].hide = True
	    group_input_006_4.outputs[24].hide = True
	    group_input_006_4.outputs[25].hide = True
	    group_input_006_4.outputs[26].hide = True
	    group_input_006_4.outputs[27].hide = True
	    group_input_006_4.outputs[28].hide = True
	    group_input_006_4.outputs[29].hide = True
	    group_input_006_4.outputs[30].hide = True
	    group_input_006_4.outputs[31].hide = True
	    group_input_006_4.outputs[32].hide = True
	    group_input_006_4.outputs[33].hide = True
	    group_input_006_4.outputs[34].hide = True
	    group_input_006_4.outputs[35].hide = True
	    group_input_006_4.outputs[36].hide = True
	
	    #node Hair Shape
	    hair_shape = shape_curve_to_guidez.nodes.new("ShaderNodeFloatCurve")
	    hair_shape.label = "Hair Shape"
	    hair_shape.name = "Hair Shape"
	    #mapping settings
	    hair_shape.mapping.extend = 'EXTRAPOLATED'
	    hair_shape.mapping.tone = 'STANDARD'
	    hair_shape.mapping.black_level = (0.0, 0.0, 0.0)
	    hair_shape.mapping.white_level = (1.0, 1.0, 1.0)
	    hair_shape.mapping.clip_min_x = 0.0
	    hair_shape.mapping.clip_min_y = 0.0
	    hair_shape.mapping.clip_max_x = 1.0
	    hair_shape.mapping.clip_max_y = 1.0
	    hair_shape.mapping.use_clip = True
	    #curve 0
	    hair_shape_curve_0 = hair_shape.mapping.curves[0]
	    hair_shape_curve_0_point_0 = hair_shape_curve_0.points[0]
	    hair_shape_curve_0_point_0.location = (0.00909090880304575, 0.0)
	    hair_shape_curve_0_point_0.handle_type = 'AUTO'
	    hair_shape_curve_0_point_1 = hair_shape_curve_0.points[1]
	    hair_shape_curve_0_point_1.location = (0.044510386884212494, 1.0)
	    hair_shape_curve_0_point_1.handle_type = 'VECTOR'
	    hair_shape_curve_0_point_2 = hair_shape_curve_0.points.new(0.925815999507904, 0.96875)
	    hair_shape_curve_0_point_2.handle_type = 'VECTOR'
	    hair_shape_curve_0_point_3 = hair_shape_curve_0.points.new(1.0, 0.0)
	    hair_shape_curve_0_point_3.handle_type = 'AUTO'
	    #update curve after changes
	    hair_shape.mapping.update()
	    hair_shape.inputs[0].hide = True
	    #Factor
	    hair_shape.inputs[0].default_value = 1.0
	
	    #node Reroute.012
	    reroute_012_4 = shape_curve_to_guidez.nodes.new("NodeReroute")
	    reroute_012_4.name = "Reroute.012"
	    reroute_012_4.socket_idname = "NodeSocketGeometry"
	    #node Reroute.013
	    reroute_013_4 = shape_curve_to_guidez.nodes.new("NodeReroute")
	    reroute_013_4.name = "Reroute.013"
	    reroute_013_4.socket_idname = "NodeSocketGeometry"
	    #node Reroute.014
	    reroute_014_3 = shape_curve_to_guidez.nodes.new("NodeReroute")
	    reroute_014_3.name = "Reroute.014"
	    reroute_014_3.socket_idname = "NodeSocketGeometry"
	    #node Reroute.015
	    reroute_015_3 = shape_curve_to_guidez.nodes.new("NodeReroute")
	    reroute_015_3.name = "Reroute.015"
	    reroute_015_3.socket_idname = "NodeSocketGeometry"
	
	
	
	    #Set parents
	    store_named_attribute_9.parent = frame_001_3
	    spline_parameter_001_1.parent = frame_6
	    offset_shape_curve.parent = frame_6
	    store_named_attribute_001_2.parent = frame_001_3
	    named_attribute_6.parent = frame_001_3
	    math_4.parent = frame_001_3
	    group_input_005_8.parent = frame_001_3
	    math_001_3.parent = frame_001_3
	    store_named_attribute_002_2.parent = frame_001_3
	    math_002_1.parent = frame_001_3
	    group_input_013.parent = frame_001_3
	    store_named_attribute_003_1.parent = frame_001_3
	    store_named_attribute_005_1.parent = frame_001_3
	
	    #Set locations
	    group_input_15.location = (-340.0, 76.4854736328125)
	    group_output_18.location = (3074.840576171875, 302.15350341796875)
	    store_named_attribute_9.location = (210.4107666015625, -39.887725830078125)
	    sample_nearest_1.location = (50.98876190185547, -118.06270599365234)
	    curve_to_points.location = (49.45391082763672, -73.36334991455078)
	    group_input_001_12.location = (-339.9401550292969, -115.41028594970703)
	    sample_curve_1.location = (-153.27989196777344, -149.58399963378906)
	    index_5.location = (-156.36334228515625, -183.8214111328125)
	    named_attribute_013.location = (1187.1776123046875, -8.223509788513184)
	    group_006.location = (1186.8851318359375, 181.92123413085938)
	    spline_parameter_001_1.location = (33.302154541015625, -356.39654541015625)
	    offset_shape_curve.location = (30.15692138671875, -40.439849853515625)
	    frame_6.location = (195.0, -236.0)
	    group_input_002_10.location = (-340.0, -175.7472686767578)
	    group_input_003_9.location = (-340.0, -51.37912368774414)
	    switch_001_6.location = (1001.8509521484375, -20.132909774780273)
	    reroute_11.location = (991.2462158203125, -310.4882507324219)
	    group_001_3.location = (-158.7305450439453, -59.20834732055664)
	    group_input_007_3.location = (1001.8561401367188, 216.1919708251953)
	    group_input_009_3.location = (1001.7962036132812, 280.22314453125)
	    group_002_2.location = (1183.065673828125, 230.4647674560547)
	    group_input_012.location = (1376.7615966796875, 105.74304962158203)
	    store_named_attribute_001_2.location = (395.1071472167969, -39.887725830078125)
	    named_attribute_6.location = (210.68707275390625, -237.4015655517578)
	    math_4.location = (392.692626953125, -276.99835205078125)
	    group_input_004_8.location = (-153.76177978515625, -87.15043640136719)
	    group_input_005_8.location = (390.0076599121094, -309.68548583984375)
	    math_001_3.location = (392.692626953125, -238.81570434570312)
	    store_named_attribute_002_2.location = (578.5244750976562, -39.887725830078125)
	    math_002_1.location = (577.52099609375, -241.64389038085938)
	    group_input_013.location = (574.8359985351562, -274.3310546875)
	    named_attribute_016.location = (1002.1512451171875, -57.762611389160156)
	    math_003_1.location = (1005.1016845703125, -94.66605377197266)
	    frame_001_3.location = (22.0, 182.0)
	    resample_curve_001_1.location = (1376.4798583984375, 231.8351287841797)
	    store_named_attribute_003_1.location = (755.7221069335938, -39.887725830078125)
	    sample_index_3.location = (50.550537109375, -159.9559326171875)
	    position_001_3.location = (48.307533264160156, -192.2386474609375)
	    group_007_1.location = (1593.790283203125, 277.61614990234375)
	    named_attribute_001_4.location = (1592.198974609375, 125.16507720947266)
	    store_named_attribute_005_1.location = (30.000003814697266, -44.37464904785156)
	    group_008.location = (-155.3152618408203, 115.36802673339844)
	    group_input_017.location = (1380.2117919921875, 44.967498779296875)
	    reroute_001_10.location = (988.071044921875, 53.528297424316406)
	    group_input_014.location = (1004.8717041015625, 44.711753845214844)
	    final_bake.location = (2894.465576171875, 349.68060302734375)
	    separate_components.location = (-336.09576416015625, 121.25868225097656)
	    join_geometry_001_1.location = (1823.6162109375, 301.7110290527344)
	    reroute_002_8.location = (-97.7074966430664, 357.1273498535156)
	    reroute_003_6.location = (-97.24090576171875, 352.3932189941406)
	    reroute_004_7.location = (-98.9859619140625, 361.5510559082031)
	    reroute_005_7.location = (-95.83991241455078, 348.1520080566406)
	    reroute_006_6.location = (-98.9859619140625, 366.9311828613281)
	    reroute_007_6.location = (1724.6318359375, 368.99072265625)
	    reroute_008_6.location = (1724.6318359375, 358.99151611328125)
	    reroute_009_5.location = (1724.6318359375, 353.9927673339844)
	    reroute_010_5.location = (1724.6318359375, 363.9889831542969)
	    reroute_011_4.location = (1724.6851806640625, 348.9961242675781)
	    hair_style.location = (2705.113525390625, 303.2171325683594)
	    shaped_hair_bake.location = (2183.159423828125, 375.27410888671875)
	    group_5.location = (2411.29150390625, 207.8965301513672)
	    group_003_2.location = (2414.560546875, -266.1255187988281)
	    group_input_018.location = (2703.026123046875, 359.4300537109375)
	    group_input_019.location = (2217.525390625, 109.87641143798828)
	    group_input_020.location = (2207.118896484375, -336.2450256347656)
	    set_material_5.location = (2004.0001220703125, 327.0755615234375)
	    group_input_021.location = (2003.0850830078125, 224.0734100341797)
	    spline_parameter_8.location = (759.1943359375, 438.0902099609375)
	    map_range_2.location = (861.21533203125, 818.3792114257812)
	    set_curve_radius_5.location = (1004.412353515625, 109.7810287475586)
	    group_input_006_4.location = (859.82373046875, 787.6554565429688)
	    hair_shape.location = (762.0992431640625, 730.6365966796875)
	    reroute_012_4.location = (2382.697509765625, 293.692138671875)
	    reroute_013_4.location = (2166.886962890625, -346.7854919433594)
	    reroute_014_3.location = (2385.212158203125, 125.4520492553711)
	    reroute_015_3.location = (2162.68994140625, 122.93897247314453)
	
	    #Set dimensions
	    group_input_15.width, group_input_15.height = 140.0, 100.0
	    group_output_18.width, group_output_18.height = 140.0, 100.0
	    store_named_attribute_9.width, store_named_attribute_9.height = 140.0, 100.0
	    sample_nearest_1.width, sample_nearest_1.height = 140.0, 100.0
	    curve_to_points.width, curve_to_points.height = 140.0, 100.0
	    group_input_001_12.width, group_input_001_12.height = 140.0, 100.0
	    sample_curve_1.width, sample_curve_1.height = 140.0, 100.0
	    index_5.width, index_5.height = 140.0, 100.0
	    named_attribute_013.width, named_attribute_013.height = 140.0, 100.0
	    group_006.width, group_006.height = 140.0, 100.0
	    spline_parameter_001_1.width, spline_parameter_001_1.height = 140.0, 100.0
	    offset_shape_curve.width, offset_shape_curve.height = 700.0, 100.0
	    frame_6.width, frame_6.height = 760.0, 438.0
	    group_input_002_10.width, group_input_002_10.height = 140.0, 100.0
	    group_input_003_9.width, group_input_003_9.height = 140.0, 100.0
	    switch_001_6.width, switch_001_6.height = 140.0, 100.0
	    reroute_11.width, reroute_11.height = 10.0, 100.0
	    group_001_3.width, group_001_3.height = 140.0, 100.0
	    group_input_007_3.width, group_input_007_3.height = 140.0, 100.0
	    group_input_009_3.width, group_input_009_3.height = 140.0, 100.0
	    group_002_2.width, group_002_2.height = 140.0, 100.0
	    group_input_012.width, group_input_012.height = 140.0, 100.0
	    store_named_attribute_001_2.width, store_named_attribute_001_2.height = 140.0, 100.0
	    named_attribute_6.width, named_attribute_6.height = 140.0, 100.0
	    math_4.width, math_4.height = 140.0, 100.0
	    group_input_004_8.width, group_input_004_8.height = 140.0, 100.0
	    group_input_005_8.width, group_input_005_8.height = 140.0, 100.0
	    math_001_3.width, math_001_3.height = 140.0, 100.0
	    store_named_attribute_002_2.width, store_named_attribute_002_2.height = 140.0, 100.0
	    math_002_1.width, math_002_1.height = 140.0, 100.0
	    group_input_013.width, group_input_013.height = 140.0, 100.0
	    named_attribute_016.width, named_attribute_016.height = 140.0, 100.0
	    math_003_1.width, math_003_1.height = 140.0, 100.0
	    frame_001_3.width, frame_001_3.height = 926.0, 392.0
	    resample_curve_001_1.width, resample_curve_001_1.height = 140.0, 100.0
	    store_named_attribute_003_1.width, store_named_attribute_003_1.height = 140.0, 100.0
	    sample_index_3.width, sample_index_3.height = 140.0, 100.0
	    position_001_3.width, position_001_3.height = 140.0, 100.0
	    group_007_1.width, group_007_1.height = 140.0, 100.0
	    named_attribute_001_4.width, named_attribute_001_4.height = 140.0, 100.0
	    store_named_attribute_005_1.width, store_named_attribute_005_1.height = 140.0, 100.0
	    group_008.width, group_008.height = 140.0, 100.0
	    group_input_017.width, group_input_017.height = 140.0, 100.0
	    reroute_001_10.width, reroute_001_10.height = 10.0, 100.0
	    group_input_014.width, group_input_014.height = 140.0, 100.0
	    final_bake.width, final_bake.height = 140.0, 100.0
	    separate_components.width, separate_components.height = 140.0, 100.0
	    join_geometry_001_1.width, join_geometry_001_1.height = 140.0, 100.0
	    reroute_002_8.width, reroute_002_8.height = 10.0, 100.0
	    reroute_003_6.width, reroute_003_6.height = 10.0, 100.0
	    reroute_004_7.width, reroute_004_7.height = 10.0, 100.0
	    reroute_005_7.width, reroute_005_7.height = 10.0, 100.0
	    reroute_006_6.width, reroute_006_6.height = 10.0, 100.0
	    reroute_007_6.width, reroute_007_6.height = 10.0, 100.0
	    reroute_008_6.width, reroute_008_6.height = 10.0, 100.0
	    reroute_009_5.width, reroute_009_5.height = 10.0, 100.0
	    reroute_010_5.width, reroute_010_5.height = 10.0, 100.0
	    reroute_011_4.width, reroute_011_4.height = 10.0, 100.0
	    hair_style.width, hair_style.height = 140.0, 100.0
	    shaped_hair_bake.width, shaped_hair_bake.height = 140.0, 100.0
	    group_5.width, group_5.height = 140.0, 100.0
	    group_003_2.width, group_003_2.height = 140.0, 100.0
	    group_input_018.width, group_input_018.height = 140.0, 100.0
	    group_input_019.width, group_input_019.height = 140.0, 100.0
	    group_input_020.width, group_input_020.height = 140.0, 100.0
	    set_material_5.width, set_material_5.height = 140.0, 100.0
	    group_input_021.width, group_input_021.height = 140.0, 100.0
	    spline_parameter_8.width, spline_parameter_8.height = 140.0, 100.0
	    map_range_2.width, map_range_2.height = 140.0, 100.0
	    set_curve_radius_5.width, set_curve_radius_5.height = 140.0, 100.0
	    group_input_006_4.width, group_input_006_4.height = 140.0, 100.0
	    hair_shape.width, hair_shape.height = 240.0, 100.0
	    reroute_012_4.width, reroute_012_4.height = 10.0, 100.0
	    reroute_013_4.width, reroute_013_4.height = 10.0, 100.0
	    reroute_014_3.width, reroute_014_3.height = 10.0, 100.0
	    reroute_015_3.width, reroute_015_3.height = 10.0, 100.0
	
	    #initialize shape_curve_to_guidez links
	    #store_named_attribute_005_1.Geometry -> store_named_attribute_9.Geometry
	    shape_curve_to_guidez.links.new(store_named_attribute_005_1.outputs[0], store_named_attribute_9.inputs[0])
	    #curve_to_points.Points -> sample_nearest_1.Geometry
	    shape_curve_to_guidez.links.new(curve_to_points.outputs[0], sample_nearest_1.inputs[0])
	    #sample_nearest_1.Index -> store_named_attribute_9.Value
	    shape_curve_to_guidez.links.new(sample_nearest_1.outputs[0], store_named_attribute_9.inputs[3])
	    #index_5.Index -> sample_curve_1.Curve Index
	    shape_curve_to_guidez.links.new(index_5.outputs[0], sample_curve_1.inputs[4])
	    #named_attribute_013.Attribute -> group_006.Closest Curve Index
	    shape_curve_to_guidez.links.new(named_attribute_013.outputs[0], group_006.inputs[4])
	    #set_curve_radius_5.Curve -> group_006.Curve
	    shape_curve_to_guidez.links.new(set_curve_radius_5.outputs[0], group_006.inputs[0])
	    #spline_parameter_001_1.Factor -> offset_shape_curve.Value
	    shape_curve_to_guidez.links.new(spline_parameter_001_1.outputs[0], offset_shape_curve.inputs[1])
	    #sample_curve_1.Position -> sample_nearest_1.Sample Position
	    shape_curve_to_guidez.links.new(sample_curve_1.outputs[1], sample_nearest_1.inputs[1])
	    #group_input_002_10.Geometry -> sample_curve_1.Curves
	    shape_curve_to_guidez.links.new(group_input_002_10.outputs[0], sample_curve_1.inputs[0])
	    #reroute_001_10.Output -> group_006.Offset Factor
	    shape_curve_to_guidez.links.new(reroute_001_10.outputs[0], group_006.inputs[2])
	    #offset_shape_curve.Value -> reroute_11.Input
	    shape_curve_to_guidez.links.new(offset_shape_curve.outputs[0], reroute_11.inputs[0])
	    #group_input_003_9.Curve Guide -> group_001_3.Geometry
	    shape_curve_to_guidez.links.new(group_input_003_9.outputs[2], group_001_3.inputs[0])
	    #group_input_001_12.Curve Guide -> group_001_3.Object
	    shape_curve_to_guidez.links.new(group_input_001_12.outputs[3], group_001_3.inputs[1])
	    #group_001_3.Geometry -> curve_to_points.Curve
	    shape_curve_to_guidez.links.new(group_001_3.outputs[0], curve_to_points.inputs[0])
	    #group_input_009_3.Curve Guide -> group_002_2.Geometry
	    shape_curve_to_guidez.links.new(group_input_009_3.outputs[2], group_002_2.inputs[0])
	    #group_input_007_3.Curve Guide -> group_002_2.Object
	    shape_curve_to_guidez.links.new(group_input_007_3.outputs[3], group_002_2.inputs[1])
	    #group_002_2.Geometry -> group_006.Target Curve
	    shape_curve_to_guidez.links.new(group_002_2.outputs[0], group_006.inputs[1])
	    #store_named_attribute_9.Geometry -> store_named_attribute_001_2.Geometry
	    shape_curve_to_guidez.links.new(store_named_attribute_9.outputs[0], store_named_attribute_001_2.inputs[0])
	    #named_attribute_6.Attribute -> math_4.Value
	    shape_curve_to_guidez.links.new(named_attribute_6.outputs[0], math_4.inputs[0])
	    #group_input_004_8.Sample Count -> curve_to_points.Count
	    shape_curve_to_guidez.links.new(group_input_004_8.outputs[6], curve_to_points.inputs[1])
	    #group_input_005_8.Sample Count -> math_4.Value
	    shape_curve_to_guidez.links.new(group_input_005_8.outputs[6], math_4.inputs[1])
	    #math_4.Value -> math_001_3.Value
	    shape_curve_to_guidez.links.new(math_4.outputs[0], math_001_3.inputs[0])
	    #math_001_3.Value -> store_named_attribute_001_2.Value
	    shape_curve_to_guidez.links.new(math_001_3.outputs[0], store_named_attribute_001_2.inputs[3])
	    #store_named_attribute_001_2.Geometry -> store_named_attribute_002_2.Geometry
	    shape_curve_to_guidez.links.new(store_named_attribute_001_2.outputs[0], store_named_attribute_002_2.inputs[0])
	    #named_attribute_6.Attribute -> math_002_1.Value
	    shape_curve_to_guidez.links.new(named_attribute_6.outputs[0], math_002_1.inputs[0])
	    #group_input_013.Sample Count -> math_002_1.Value
	    shape_curve_to_guidez.links.new(group_input_013.outputs[6], math_002_1.inputs[1])
	    #math_002_1.Value -> store_named_attribute_002_2.Value
	    shape_curve_to_guidez.links.new(math_002_1.outputs[0], store_named_attribute_002_2.inputs[3])
	    #named_attribute_016.Attribute -> math_003_1.Value
	    shape_curve_to_guidez.links.new(named_attribute_016.outputs[0], math_003_1.inputs[0])
	    #group_006.Geometry -> resample_curve_001_1.Curve
	    shape_curve_to_guidez.links.new(group_006.outputs[0], resample_curve_001_1.inputs[0])
	    #store_named_attribute_002_2.Geometry -> store_named_attribute_003_1.Geometry
	    shape_curve_to_guidez.links.new(store_named_attribute_002_2.outputs[0], store_named_attribute_003_1.inputs[0])
	    #curve_to_points.Points -> sample_index_3.Geometry
	    shape_curve_to_guidez.links.new(curve_to_points.outputs[0], sample_index_3.inputs[0])
	    #sample_nearest_1.Index -> sample_index_3.Index
	    shape_curve_to_guidez.links.new(sample_nearest_1.outputs[0], sample_index_3.inputs[2])
	    #position_001_3.Position -> sample_index_3.Value
	    shape_curve_to_guidez.links.new(position_001_3.outputs[0], sample_index_3.inputs[1])
	    #sample_index_3.Value -> store_named_attribute_003_1.Value
	    shape_curve_to_guidez.links.new(sample_index_3.outputs[0], store_named_attribute_003_1.inputs[3])
	    #group_input_012.Control Points -> resample_curve_001_1.Count
	    shape_curve_to_guidez.links.new(group_input_012.outputs[5], resample_curve_001_1.inputs[2])
	    #group_008.Geometry -> store_named_attribute_005_1.Geometry
	    shape_curve_to_guidez.links.new(group_008.outputs[0], store_named_attribute_005_1.inputs[0])
	    #resample_curve_001_1.Curve -> group_007_1.Curves
	    shape_curve_to_guidez.links.new(resample_curve_001_1.outputs[0], group_007_1.inputs[0])
	    #final_bake.Geometry -> group_output_18.Geometry
	    shape_curve_to_guidez.links.new(final_bake.outputs[0], group_output_18.inputs[0])
	    #named_attribute_001_4.Attribute -> group_007_1.Reference Position
	    shape_curve_to_guidez.links.new(named_attribute_001_4.outputs[0], group_007_1.inputs[3])
	    #position_001_3.Position -> store_named_attribute_005_1.Value
	    shape_curve_to_guidez.links.new(position_001_3.outputs[0], store_named_attribute_005_1.inputs[3])
	    #group_input_15.Surface -> group_008.Surface
	    shape_curve_to_guidez.links.new(group_input_15.outputs[1], group_008.inputs[1])
	    #group_input_15.UV Map -> group_008.UV Map
	    shape_curve_to_guidez.links.new(group_input_15.outputs[8], group_008.inputs[2])
	    #group_input_15.Blend along Curve -> group_008.Blend along Curve
	    shape_curve_to_guidez.links.new(group_input_15.outputs[9], group_008.inputs[3])
	    #group_input_017.Preserve Length Factor -> group_007_1.Factor
	    shape_curve_to_guidez.links.new(group_input_017.outputs[10], group_007_1.inputs[2])
	    #reroute_11.Output -> reroute_001_10.Input
	    shape_curve_to_guidez.links.new(reroute_11.outputs[0], reroute_001_10.inputs[0])
	    #named_attribute_016.Attribute -> switch_001_6.False
	    shape_curve_to_guidez.links.new(named_attribute_016.outputs[0], switch_001_6.inputs[1])
	    #math_003_1.Value -> switch_001_6.True
	    shape_curve_to_guidez.links.new(math_003_1.outputs[0], switch_001_6.inputs[2])
	    #switch_001_6.Output -> group_006.Offset Point
	    shape_curve_to_guidez.links.new(switch_001_6.outputs[0], group_006.inputs[3])
	    #group_input_014.Offset index -> switch_001_6.Switch
	    shape_curve_to_guidez.links.new(group_input_014.outputs[11], switch_001_6.inputs[0])
	    #group_input_15.Geometry -> separate_components.Geometry
	    shape_curve_to_guidez.links.new(group_input_15.outputs[0], separate_components.inputs[0])
	    #separate_components.Curve -> group_008.Geometry
	    shape_curve_to_guidez.links.new(separate_components.outputs[1], group_008.inputs[0])
	    #reroute_011_4.Output -> join_geometry_001_1.Geometry
	    shape_curve_to_guidez.links.new(reroute_011_4.outputs[0], join_geometry_001_1.inputs[0])
	    #separate_components.Point Cloud -> reroute_002_8.Input
	    shape_curve_to_guidez.links.new(separate_components.outputs[3], reroute_002_8.inputs[0])
	    #separate_components.Volume -> reroute_003_6.Input
	    shape_curve_to_guidez.links.new(separate_components.outputs[4], reroute_003_6.inputs[0])
	    #separate_components.Grease Pencil -> reroute_004_7.Input
	    shape_curve_to_guidez.links.new(separate_components.outputs[2], reroute_004_7.inputs[0])
	    #separate_components.Instances -> reroute_005_7.Input
	    shape_curve_to_guidez.links.new(separate_components.outputs[5], reroute_005_7.inputs[0])
	    #separate_components.Mesh -> reroute_006_6.Input
	    shape_curve_to_guidez.links.new(separate_components.outputs[0], reroute_006_6.inputs[0])
	    #reroute_006_6.Output -> reroute_007_6.Input
	    shape_curve_to_guidez.links.new(reroute_006_6.outputs[0], reroute_007_6.inputs[0])
	    #reroute_002_8.Output -> reroute_008_6.Input
	    shape_curve_to_guidez.links.new(reroute_002_8.outputs[0], reroute_008_6.inputs[0])
	    #reroute_003_6.Output -> reroute_009_5.Input
	    shape_curve_to_guidez.links.new(reroute_003_6.outputs[0], reroute_009_5.inputs[0])
	    #reroute_004_7.Output -> reroute_010_5.Input
	    shape_curve_to_guidez.links.new(reroute_004_7.outputs[0], reroute_010_5.inputs[0])
	    #reroute_005_7.Output -> reroute_011_4.Input
	    shape_curve_to_guidez.links.new(reroute_005_7.outputs[0], reroute_011_4.inputs[0])
	    #set_material_5.Geometry -> shaped_hair_bake.Geometry
	    shape_curve_to_guidez.links.new(set_material_5.outputs[0], shaped_hair_bake.inputs[0])
	    #reroute_012_4.Output -> hair_style.Curve Hair
	    shape_curve_to_guidez.links.new(reroute_012_4.outputs[0], hair_style.inputs[1])
	    #reroute_014_3.Output -> group_5.Geometry
	    shape_curve_to_guidez.links.new(reroute_014_3.outputs[0], group_5.inputs[0])
	    #group_5.Geometry -> hair_style.Stylized
	    shape_curve_to_guidez.links.new(group_5.outputs[0], hair_style.inputs[2])
	    #reroute_013_4.Output -> group_003_2.Geometry
	    shape_curve_to_guidez.links.new(reroute_013_4.outputs[0], group_003_2.inputs[0])
	    #group_003_2.Geometry -> hair_style.Mesh Hair
	    shape_curve_to_guidez.links.new(group_003_2.outputs[0], hair_style.inputs[3])
	    #hair_style.Output -> final_bake.Geometry
	    shape_curve_to_guidez.links.new(hair_style.outputs[0], final_bake.inputs[0])
	    #group_input_018.Hair Style -> hair_style.Menu
	    shape_curve_to_guidez.links.new(group_input_018.outputs[4], hair_style.inputs[0])
	    #group_input_019.Surface -> group_5.Surface
	    shape_curve_to_guidez.links.new(group_input_019.outputs[1], group_5.inputs[1])
	    #join_geometry_001_1.Geometry -> set_material_5.Geometry
	    shape_curve_to_guidez.links.new(join_geometry_001_1.outputs[0], set_material_5.inputs[0])
	    #group_input_021.Material -> set_material_5.Material
	    shape_curve_to_guidez.links.new(group_input_021.outputs[12], set_material_5.inputs[2])
	    #group_input_019.Mesh Material -> group_5.Material
	    shape_curve_to_guidez.links.new(group_input_019.outputs[13], group_5.inputs[2])
	    #group_input_019.Control Points -> group_5.Control Points
	    shape_curve_to_guidez.links.new(group_input_019.outputs[14], group_5.inputs[3])
	    #group_input_019.Radius -> group_5.Radius
	    shape_curve_to_guidez.links.new(group_input_019.outputs[15], group_5.inputs[4])
	    #group_input_019.Use Enhancements -> group_5.Use Enhancements
	    shape_curve_to_guidez.links.new(group_input_019.outputs[16], group_5.inputs[5])
	    #group_input_019.Maintain Shape Factor -> group_5.Maintain Shape Factor
	    shape_curve_to_guidez.links.new(group_input_019.outputs[17], group_5.inputs[6])
	    #group_input_019.Pin at Parameter -> group_5.Pin at Parameter
	    shape_curve_to_guidez.links.new(group_input_019.outputs[18], group_5.inputs[7])
	    #group_input_019.Snap to surface -> group_5.Snap to surface
	    shape_curve_to_guidez.links.new(group_input_019.outputs[19], group_5.inputs[8])
	    #group_input_019.Subdivison Level -> group_5.Subdivison Level
	    shape_curve_to_guidez.links.new(group_input_019.outputs[20], group_5.inputs[9])
	    #group_input_019.Edge Crease -> group_5.Edge Crease
	    shape_curve_to_guidez.links.new(group_input_019.outputs[21], group_5.inputs[10])
	    #group_input_019.Vertex Crease -> group_5.Vertex Crease
	    shape_curve_to_guidez.links.new(group_input_019.outputs[22], group_5.inputs[11])
	    #group_input_019.Limit Surface -> group_5.Limit Surface
	    shape_curve_to_guidez.links.new(group_input_019.outputs[23], group_5.inputs[12])
	    #group_input_019.Distance -> group_5.Distance
	    shape_curve_to_guidez.links.new(group_input_019.outputs[24], group_5.inputs[13])
	    #group_input_020.Mesh Material -> group_003_2.Material
	    shape_curve_to_guidez.links.new(group_input_020.outputs[13], group_003_2.inputs[2])
	    #group_input_020.Style Select -> group_003_2.Style Select
	    shape_curve_to_guidez.links.new(group_input_020.outputs[25], group_003_2.inputs[1])
	    #group_input_020.Resolution -> group_003_2.Resolution
	    shape_curve_to_guidez.links.new(group_input_020.outputs[26], group_003_2.inputs[3])
	    #group_input_020.Width -> group_003_2.Width
	    shape_curve_to_guidez.links.new(group_input_020.outputs[27], group_003_2.inputs[4])
	    #group_input_020.Fill Caps -> group_003_2.Fill Caps
	    shape_curve_to_guidez.links.new(group_input_020.outputs[28], group_003_2.inputs[6])
	    #group_input_020.Shade Smooth -> group_003_2.Shade Smooth
	    shape_curve_to_guidez.links.new(group_input_020.outputs[29], group_003_2.inputs[7])
	    #group_input_020.Hair Card Angle -> group_003_2.Hair Card Angle
	    shape_curve_to_guidez.links.new(group_input_020.outputs[30], group_003_2.inputs[8])
	    #group_input_020.Tube Ribbon Count -> group_003_2.Tube Ribbon Count
	    shape_curve_to_guidez.links.new(group_input_020.outputs[31], group_003_2.inputs[9])
	    #group_input_020.Profile Curve -> group_003_2.Profile Curve
	    shape_curve_to_guidez.links.new(group_input_020.outputs[32], group_003_2.inputs[10])
	    #group_input_020.Profile Translation -> group_003_2.Profile Translation
	    shape_curve_to_guidez.links.new(group_input_020.outputs[33], group_003_2.inputs[11])
	    #group_input_020.Profile Rotation -> group_003_2.Profile Rotation
	    shape_curve_to_guidez.links.new(group_input_020.outputs[34], group_003_2.inputs[12])
	    #group_input_020.Profile Scale -> group_003_2.Profile Scale
	    shape_curve_to_guidez.links.new(group_input_020.outputs[35], group_003_2.inputs[13])
	    #group_input_006_4.Hair Strand Radius -> map_range_2.To Max
	    shape_curve_to_guidez.links.new(group_input_006_4.outputs[7], map_range_2.inputs[4])
	    #spline_parameter_8.Factor -> hair_shape.Value
	    shape_curve_to_guidez.links.new(spline_parameter_8.outputs[0], hair_shape.inputs[1])
	    #hair_shape.Value -> map_range_2.Value
	    shape_curve_to_guidez.links.new(hair_shape.outputs[0], map_range_2.inputs[0])
	    #store_named_attribute_003_1.Geometry -> set_curve_radius_5.Curve
	    shape_curve_to_guidez.links.new(store_named_attribute_003_1.outputs[0], set_curve_radius_5.inputs[0])
	    #map_range_2.Result -> set_curve_radius_5.Radius
	    shape_curve_to_guidez.links.new(map_range_2.outputs[0], set_curve_radius_5.inputs[2])
	    #shaped_hair_bake.Geometry -> reroute_012_4.Input
	    shape_curve_to_guidez.links.new(shaped_hair_bake.outputs[0], reroute_012_4.inputs[0])
	    #reroute_012_4.Output -> reroute_014_3.Input
	    shape_curve_to_guidez.links.new(reroute_012_4.outputs[0], reroute_014_3.inputs[0])
	    #reroute_014_3.Output -> reroute_015_3.Input
	    shape_curve_to_guidez.links.new(reroute_014_3.outputs[0], reroute_015_3.inputs[0])
	    #reroute_015_3.Output -> reroute_013_4.Input
	    shape_curve_to_guidez.links.new(reroute_015_3.outputs[0], reroute_013_4.inputs[0])
	    #reroute_009_5.Output -> join_geometry_001_1.Geometry
	    shape_curve_to_guidez.links.new(reroute_009_5.outputs[0], join_geometry_001_1.inputs[0])
	    #reroute_008_6.Output -> join_geometry_001_1.Geometry
	    shape_curve_to_guidez.links.new(reroute_008_6.outputs[0], join_geometry_001_1.inputs[0])
	    #reroute_010_5.Output -> join_geometry_001_1.Geometry
	    shape_curve_to_guidez.links.new(reroute_010_5.outputs[0], join_geometry_001_1.inputs[0])
	    #reroute_007_6.Output -> join_geometry_001_1.Geometry
	    shape_curve_to_guidez.links.new(reroute_007_6.outputs[0], join_geometry_001_1.inputs[0])
	    #group_007_1.Curves -> join_geometry_001_1.Geometry
	    shape_curve_to_guidez.links.new(group_007_1.outputs[0], join_geometry_001_1.inputs[0])
	    hair_style_socket.default_value = 'Curve Hair'
	    style_select_socket_1.default_value = 'Hair Card'
	    return shape_curve_to_guidez
	return shape_curve_to_guidez_node_group()

	

	
