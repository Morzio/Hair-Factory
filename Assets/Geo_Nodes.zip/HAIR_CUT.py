import bpy, mathutils

def node():
	#initialize curve_root node group
	def curve_root_node_group():
	    curve_root = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Curve Root")
	
	    curve_root.color_tag = 'INPUT'
	    curve_root.description = "Reads information about each curve's root point"
	    curve_root.default_group_node_width = 140
	    
	
	
	    #curve_root interface
	    #Socket Root Selection
	    root_selection_socket = curve_root.interface.new_socket(name = "Root Selection", in_out='OUTPUT', socket_type = 'NodeSocketBool')
	    root_selection_socket.default_value = False
	    root_selection_socket.attribute_domain = 'POINT'
	    root_selection_socket.description = "Boolean selection of curve root points"
	
	    #Socket Root Position
	    root_position_socket = curve_root.interface.new_socket(name = "Root Position", in_out='OUTPUT', socket_type = 'NodeSocketVector')
	    root_position_socket.default_value = (0.0, 0.0, 0.0)
	    root_position_socket.min_value = -3.4028234663852886e+38
	    root_position_socket.max_value = 3.4028234663852886e+38
	    root_position_socket.subtype = 'NONE'
	    root_position_socket.attribute_domain = 'CURVE'
	    root_position_socket.description = "Position of the root point of a curve"
	
	    #Socket Root Direction
	    root_direction_socket = curve_root.interface.new_socket(name = "Root Direction", in_out='OUTPUT', socket_type = 'NodeSocketVector')
	    root_direction_socket.default_value = (0.0, 0.0, 0.0)
	    root_direction_socket.min_value = -3.4028234663852886e+38
	    root_direction_socket.max_value = 3.4028234663852886e+38
	    root_direction_socket.subtype = 'NONE'
	    root_direction_socket.attribute_domain = 'CURVE'
	    root_direction_socket.description = "Direction of the root segment of a curve"
	
	    #Socket Root Index
	    root_index_socket = curve_root.interface.new_socket(name = "Root Index", in_out='OUTPUT', socket_type = 'NodeSocketInt')
	    root_index_socket.default_value = 0
	    root_index_socket.min_value = -2147483648
	    root_index_socket.max_value = 2147483647
	    root_index_socket.subtype = 'NONE'
	    root_index_socket.attribute_domain = 'CURVE'
	    root_index_socket.description = "Index of the root point of a curve"
	
	
	    #initialize curve_root nodes
	    #node Position.002
	    position_002 = curve_root.nodes.new("GeometryNodeInputPosition")
	    position_002.name = "Position.002"
	
	    #node Interpolate Domain
	    interpolate_domain = curve_root.nodes.new("GeometryNodeFieldOnDomain")
	    interpolate_domain.name = "Interpolate Domain"
	    interpolate_domain.data_type = 'INT'
	    interpolate_domain.domain = 'CURVE'
	
	    #node Field at Index.003
	    field_at_index_003 = curve_root.nodes.new("GeometryNodeFieldAtIndex")
	    field_at_index_003.name = "Field at Index.003"
	    field_at_index_003.data_type = 'FLOAT_VECTOR'
	    field_at_index_003.domain = 'POINT'
	
	    #node Interpolate Domain.001
	    interpolate_domain_001 = curve_root.nodes.new("GeometryNodeFieldOnDomain")
	    interpolate_domain_001.name = "Interpolate Domain.001"
	    interpolate_domain_001.data_type = 'FLOAT_VECTOR'
	    interpolate_domain_001.domain = 'CURVE'
	
	    #node Curve Tangent
	    curve_tangent = curve_root.nodes.new("GeometryNodeInputTangent")
	    curve_tangent.name = "Curve Tangent"
	
	    #node Endpoint Selection
	    endpoint_selection = curve_root.nodes.new("GeometryNodeCurveEndpointSelection")
	    endpoint_selection.name = "Endpoint Selection"
	    #Start Size
	    endpoint_selection.inputs[0].default_value = 1
	    #End Size
	    endpoint_selection.inputs[1].default_value = 0
	
	    #node Field at Index.004
	    field_at_index_004 = curve_root.nodes.new("GeometryNodeFieldAtIndex")
	    field_at_index_004.name = "Field at Index.004"
	    field_at_index_004.data_type = 'FLOAT_VECTOR'
	    field_at_index_004.domain = 'POINT'
	
	    #node Interpolate Domain.002
	    interpolate_domain_002 = curve_root.nodes.new("GeometryNodeFieldOnDomain")
	    interpolate_domain_002.name = "Interpolate Domain.002"
	    interpolate_domain_002.data_type = 'FLOAT_VECTOR'
	    interpolate_domain_002.domain = 'CURVE'
	
	    #node Group Output
	    group_output = curve_root.nodes.new("NodeGroupOutput")
	    group_output.name = "Group Output"
	    group_output.is_active_output = True
	
	    #node Points of Curve
	    points_of_curve = curve_root.nodes.new("GeometryNodePointsOfCurve")
	    points_of_curve.name = "Points of Curve"
	    points_of_curve.inputs[0].hide = True
	    points_of_curve.inputs[1].hide = True
	    points_of_curve.outputs[1].hide = True
	    #Curve Index
	    points_of_curve.inputs[0].default_value = 0
	    #Weights
	    points_of_curve.inputs[1].default_value = 0.0
	    #Sort Index
	    points_of_curve.inputs[2].default_value = 0
	
	
	
	
	
	    #Set locations
	    position_002.location = (-608.1627807617188, -70.55814361572266)
	    interpolate_domain.location = (-608.1627807617188, 90.18604278564453)
	    field_at_index_003.location = (-407.2325439453125, 70.09302520751953)
	    interpolate_domain_001.location = (-206.30230712890625, 70.09302520751953)
	    curve_tangent.location = (-608.1627807617188, -271.4883728027344)
	    endpoint_selection.location = (-206.30230712890625, 190.65118408203125)
	    field_at_index_004.location = (-407.2325439453125, -130.83721923828125)
	    interpolate_domain_002.location = (-206.30230712890625, -130.83721923828125)
	    group_output.location = (75.0, 50.0)
	    points_of_curve.location = (-789.0, 50.0)
	
	    #Set dimensions
	    position_002.width, position_002.height = 140.0, 100.0
	    interpolate_domain.width, interpolate_domain.height = 140.0, 100.0
	    field_at_index_003.width, field_at_index_003.height = 140.0, 100.0
	    interpolate_domain_001.width, interpolate_domain_001.height = 140.0, 100.0
	    curve_tangent.width, curve_tangent.height = 140.0, 100.0
	    endpoint_selection.width, endpoint_selection.height = 140.0, 100.0
	    field_at_index_004.width, field_at_index_004.height = 140.0, 100.0
	    interpolate_domain_002.width, interpolate_domain_002.height = 140.0, 100.0
	    group_output.width, group_output.height = 140.0, 100.0
	    points_of_curve.width, points_of_curve.height = 140.0, 100.0
	
	    #initialize curve_root links
	    #position_002.Position -> field_at_index_003.Value
	    curve_root.links.new(position_002.outputs[0], field_at_index_003.inputs[1])
	    #interpolate_domain_001.Value -> group_output.Root Position
	    curve_root.links.new(interpolate_domain_001.outputs[0], group_output.inputs[1])
	    #interpolate_domain.Value -> field_at_index_003.Index
	    curve_root.links.new(interpolate_domain.outputs[0], field_at_index_003.inputs[0])
	    #points_of_curve.Point Index -> interpolate_domain.Value
	    curve_root.links.new(points_of_curve.outputs[0], interpolate_domain.inputs[0])
	    #interpolate_domain.Value -> group_output.Root Index
	    curve_root.links.new(interpolate_domain.outputs[0], group_output.inputs[3])
	    #endpoint_selection.Selection -> group_output.Root Selection
	    curve_root.links.new(endpoint_selection.outputs[0], group_output.inputs[0])
	    #field_at_index_003.Value -> interpolate_domain_001.Value
	    curve_root.links.new(field_at_index_003.outputs[0], interpolate_domain_001.inputs[0])
	    #interpolate_domain_002.Value -> group_output.Root Direction
	    curve_root.links.new(interpolate_domain_002.outputs[0], group_output.inputs[2])
	    #interpolate_domain.Value -> field_at_index_004.Index
	    curve_root.links.new(interpolate_domain.outputs[0], field_at_index_004.inputs[0])
	    #curve_tangent.Tangent -> field_at_index_004.Value
	    curve_root.links.new(curve_tangent.outputs[0], field_at_index_004.inputs[1])
	    #field_at_index_004.Value -> interpolate_domain_002.Value
	    curve_root.links.new(field_at_index_004.outputs[0], interpolate_domain_002.inputs[0])
	    return curve_root
	
	curve_root = curve_root_node_group()
	
	#initialize hair_cut node group
	def hair_cut_node_group():
	    hair_cut = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "HAIR_CUT")
	
	    hair_cut.color_tag = 'NONE'
	    hair_cut.description = "Cut hair with a surrounding object."
	    hair_cut.default_group_node_width = 140
	    
	
	    hair_cut.is_modifier = True
	
	    #hair_cut interface
	    #Socket Geometry
	    geometry_socket = hair_cut.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket.attribute_domain = 'POINT'
	    geometry_socket.description = "Modified curve."
	
	    #Socket Geometry
	    geometry_socket_1 = hair_cut.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_1.attribute_domain = 'POINT'
	    geometry_socket_1.description = "Hair curve."
	
	    #Socket Cut Shape
	    cut_shape_socket = hair_cut.interface.new_socket(name = "Cut Shape", in_out='INPUT', socket_type = 'NodeSocketObject')
	    cut_shape_socket.attribute_domain = 'POINT'
	    cut_shape_socket.description = "Object used to shape hair cut."
	
	
	    #initialize hair_cut nodes
	    #node Group Input
	    group_input = hair_cut.nodes.new("NodeGroupInput")
	    group_input.name = "Group Input"
	    group_input.outputs[1].hide = True
	    group_input.outputs[2].hide = True
	
	    #node Group Output
	    group_output_1 = hair_cut.nodes.new("NodeGroupOutput")
	    group_output_1.name = "Group Output"
	    group_output_1.is_active_output = True
	    group_output_1.inputs[1].hide = True
	
	    #node Object Info
	    object_info = hair_cut.nodes.new("GeometryNodeObjectInfo")
	    object_info.name = "Object Info"
	    object_info.hide = True
	    object_info.transform_space = 'RELATIVE'
	    object_info.inputs[1].hide = True
	    object_info.outputs[0].hide = True
	    object_info.outputs[1].hide = True
	    object_info.outputs[2].hide = True
	    object_info.outputs[3].hide = True
	    #As Instance
	    object_info.inputs[1].default_value = False
	
	    #node Capture Attribute
	    capture_attribute = hair_cut.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute.name = "Capture Attribute"
	    capture_attribute.hide = True
	    capture_attribute.active_index = 0
	    capture_attribute.capture_items.clear()
	    capture_attribute.capture_items.new('FLOAT', "Position")
	    capture_attribute.capture_items["Position"].data_type = 'FLOAT_VECTOR'
	    capture_attribute.domain = 'POINT'
	
	    #node Position
	    position = hair_cut.nodes.new("GeometryNodeInputPosition")
	    position.name = "Position"
	    position.hide = True
	
	    #node Resample Curve
	    resample_curve = hair_cut.nodes.new("GeometryNodeResampleCurve")
	    resample_curve.name = "Resample Curve"
	    resample_curve.hide = True
	    resample_curve.keep_last_segment = False
	    resample_curve.mode = 'COUNT'
	    resample_curve.inputs[1].hide = True
	    resample_curve.inputs[3].hide = True
	    #Selection
	    resample_curve.inputs[1].default_value = True
	
	    #node Resample Curve.001
	    resample_curve_001 = hair_cut.nodes.new("GeometryNodeResampleCurve")
	    resample_curve_001.name = "Resample Curve.001"
	    resample_curve_001.hide = True
	    resample_curve_001.keep_last_segment = False
	    resample_curve_001.mode = 'COUNT'
	    resample_curve_001.inputs[1].hide = True
	    resample_curve_001.inputs[3].hide = True
	    #Selection
	    resample_curve_001.inputs[1].default_value = True
	
	    #node Math.001
	    math_001 = hair_cut.nodes.new("ShaderNodeMath")
	    math_001.name = "Math.001"
	    math_001.hide = True
	    math_001.operation = 'MULTIPLY'
	    math_001.use_clamp = False
	    math_001.inputs[1].hide = True
	    math_001.inputs[2].hide = True
	    #Value_001
	    math_001.inputs[1].default_value = 10.0
	
	    #node Vector Math
	    vector_math = hair_cut.nodes.new("ShaderNodeVectorMath")
	    vector_math.name = "Vector Math"
	    vector_math.hide = True
	    vector_math.operation = 'SUBTRACT'
	
	    #node Vector Math.001
	    vector_math_001 = hair_cut.nodes.new("ShaderNodeVectorMath")
	    vector_math_001.name = "Vector Math.001"
	    vector_math_001.hide = True
	    vector_math_001.operation = 'SUBTRACT'
	
	    #node Reroute
	    reroute = hair_cut.nodes.new("NodeReroute")
	    reroute.name = "Reroute"
	    reroute.socket_idname = "NodeSocketGeometry"
	    #node Reroute.002
	    reroute_002 = hair_cut.nodes.new("NodeReroute")
	    reroute_002.name = "Reroute.002"
	    reroute_002.socket_idname = "NodeSocketVector"
	    #node Reroute.003
	    reroute_003 = hair_cut.nodes.new("NodeReroute")
	    reroute_003.name = "Reroute.003"
	    reroute_003.socket_idname = "NodeSocketVector"
	    #node Group Input.001
	    group_input_001 = hair_cut.nodes.new("NodeGroupInput")
	    group_input_001.name = "Group Input.001"
	    group_input_001.outputs[0].hide = True
	    group_input_001.outputs[2].hide = True
	
	    #node Geometry Proximity
	    geometry_proximity = hair_cut.nodes.new("GeometryNodeProximity")
	    geometry_proximity.name = "Geometry Proximity"
	    geometry_proximity.target_element = 'FACES'
	    geometry_proximity.inputs[1].hide = True
	    geometry_proximity.inputs[3].hide = True
	    geometry_proximity.outputs[1].hide = True
	    geometry_proximity.outputs[2].hide = True
	    #Group ID
	    geometry_proximity.inputs[1].default_value = 0
	    #Sample Group ID
	    geometry_proximity.inputs[3].default_value = 0
	
	    #node Vector Math.002
	    vector_math_002 = hair_cut.nodes.new("ShaderNodeVectorMath")
	    vector_math_002.name = "Vector Math.002"
	    vector_math_002.hide = True
	    vector_math_002.operation = 'NORMALIZE'
	
	    #node Vector Math.003
	    vector_math_003 = hair_cut.nodes.new("ShaderNodeVectorMath")
	    vector_math_003.name = "Vector Math.003"
	    vector_math_003.hide = True
	    vector_math_003.operation = 'NORMALIZE'
	
	    #node Vector Math.004
	    vector_math_004 = hair_cut.nodes.new("ShaderNodeVectorMath")
	    vector_math_004.name = "Vector Math.004"
	    vector_math_004.hide = True
	    vector_math_004.operation = 'DOT_PRODUCT'
	
	    #node Reroute.001
	    reroute_001 = hair_cut.nodes.new("NodeReroute")
	    reroute_001.name = "Reroute.001"
	    reroute_001.socket_idname = "NodeSocketVector"
	    #node Reroute.004
	    reroute_004 = hair_cut.nodes.new("NodeReroute")
	    reroute_004.name = "Reroute.004"
	    reroute_004.socket_idname = "NodeSocketVector"
	    #node Reroute.005
	    reroute_005 = hair_cut.nodes.new("NodeReroute")
	    reroute_005.name = "Reroute.005"
	    reroute_005.socket_idname = "NodeSocketVector"
	    #node Compare
	    compare = hair_cut.nodes.new("FunctionNodeCompare")
	    compare.name = "Compare"
	    compare.hide = True
	    compare.data_type = 'FLOAT'
	    compare.mode = 'ELEMENT'
	    compare.operation = 'LESS_THAN'
	    #B
	    compare.inputs[1].default_value = 0.0
	
	    #node Delete Geometry
	    delete_geometry = hair_cut.nodes.new("GeometryNodeDeleteGeometry")
	    delete_geometry.name = "Delete Geometry"
	    delete_geometry.hide = True
	    delete_geometry.domain = 'POINT'
	    delete_geometry.mode = 'ALL'
	
	    #node Group.001
	    group_001 = hair_cut.nodes.new("GeometryNodeGroup")
	    group_001.name = "Group.001"
	    group_001.node_tree = curve_root
	    group_001.outputs[0].hide = True
	    group_001.outputs[2].hide = True
	    group_001.outputs[3].hide = True
	
	    #node Hair Cut Bake
	    hair_cut_bake = hair_cut.nodes.new("GeometryNodeBake")
	    hair_cut_bake.label = "Hair Cut Bake"
	    hair_cut_bake.name = "Hair Cut Bake"
	    hair_cut_bake.active_index = 0
	    hair_cut_bake.bake_items.clear()
	    hair_cut_bake.bake_items.new('GEOMETRY', "Geometry")
	    hair_cut_bake.bake_items[0].attribute_domain = 'POINT'
	    hair_cut_bake.inputs[1].hide = True
	    hair_cut_bake.outputs[1].hide = True
	
	    #node Separate Components
	    separate_components = hair_cut.nodes.new("GeometryNodeSeparateComponents")
	    separate_components.name = "Separate Components"
	    separate_components.hide = True
	
	    #node Join Geometry
	    join_geometry = hair_cut.nodes.new("GeometryNodeJoinGeometry")
	    join_geometry.name = "Join Geometry"
	
	    #node Reroute.006
	    reroute_006 = hair_cut.nodes.new("NodeReroute")
	    reroute_006.name = "Reroute.006"
	    reroute_006.socket_idname = "NodeSocketGeometry"
	    #node Reroute.007
	    reroute_007 = hair_cut.nodes.new("NodeReroute")
	    reroute_007.name = "Reroute.007"
	    reroute_007.socket_idname = "NodeSocketGeometry"
	    #node Reroute.008
	    reroute_008 = hair_cut.nodes.new("NodeReroute")
	    reroute_008.name = "Reroute.008"
	    reroute_008.socket_idname = "NodeSocketGeometry"
	    #node Reroute.009
	    reroute_009 = hair_cut.nodes.new("NodeReroute")
	    reroute_009.name = "Reroute.009"
	    reroute_009.socket_idname = "NodeSocketGeometry"
	    #node Reroute.010
	    reroute_010 = hair_cut.nodes.new("NodeReroute")
	    reroute_010.name = "Reroute.010"
	    reroute_010.socket_idname = "NodeSocketGeometry"
	    #node Reroute.011
	    reroute_011 = hair_cut.nodes.new("NodeReroute")
	    reroute_011.name = "Reroute.011"
	    reroute_011.socket_idname = "NodeSocketGeometry"
	    #node Reroute.012
	    reroute_012 = hair_cut.nodes.new("NodeReroute")
	    reroute_012.name = "Reroute.012"
	    reroute_012.socket_idname = "NodeSocketGeometry"
	    #node Reroute.013
	    reroute_013 = hair_cut.nodes.new("NodeReroute")
	    reroute_013.name = "Reroute.013"
	    reroute_013.socket_idname = "NodeSocketGeometry"
	    #node Reroute.014
	    reroute_014 = hair_cut.nodes.new("NodeReroute")
	    reroute_014.name = "Reroute.014"
	    reroute_014.socket_idname = "NodeSocketGeometry"
	    #node Reroute.015
	    reroute_015 = hair_cut.nodes.new("NodeReroute")
	    reroute_015.name = "Reroute.015"
	    reroute_015.socket_idname = "NodeSocketGeometry"
	    #node Attribute Statistic
	    attribute_statistic = hair_cut.nodes.new("GeometryNodeAttributeStatistic")
	    attribute_statistic.name = "Attribute Statistic"
	    attribute_statistic.hide = True
	    attribute_statistic.data_type = 'FLOAT'
	    attribute_statistic.domain = 'POINT'
	    attribute_statistic.inputs[1].hide = True
	    attribute_statistic.outputs[0].hide = True
	    attribute_statistic.outputs[1].hide = True
	    attribute_statistic.outputs[2].hide = True
	    attribute_statistic.outputs[3].hide = True
	    attribute_statistic.outputs[5].hide = True
	    attribute_statistic.outputs[6].hide = True
	    attribute_statistic.outputs[7].hide = True
	    #Selection
	    attribute_statistic.inputs[1].default_value = True
	
	    #node Spline Length
	    spline_length = hair_cut.nodes.new("GeometryNodeSplineLength")
	    spline_length.name = "Spline Length"
	    spline_length.outputs[0].hide = True
	
	
	
	
	
	    #Set locations
	    group_input.location = (-356.57452392578125, 0.0)
	    group_output_1.location = (1844.275146484375, -0.5694694519042969)
	    object_info.location = (297.9954528808594, 72.37544250488281)
	    capture_attribute.location = (300.677978515625, -44.632572174072266)
	    position.location = (297.6986083984375, 10.80154800415039)
	    resample_curve.location = (138.88661193847656, -33.20964050292969)
	    resample_curve_001.location = (1271.0633544921875, -50.36743927001953)
	    math_001.location = (-24.935009002685547, -44.439422607421875)
	    vector_math.location = (659.5955200195312, -107.05665588378906)
	    vector_math_001.location = (662.5382690429688, -155.33766174316406)
	    reroute.location = (-180.54879760742188, -33.81312942504883)
	    reroute_002.location = (454.28350830078125, -55.67739486694336)
	    reroute_003.location = (452.7006530761719, 18.836143493652344)
	    group_input_001.location = (111.0817642211914, 106.88307189941406)
	    geometry_proximity.location = (484.9754943847656, 126.0665512084961)
	    vector_math_002.location = (817.7742919921875, -107.95645141601562)
	    vector_math_003.location = (821.0771484375, -154.23573303222656)
	    vector_math_004.location = (973.0100708007812, -128.89230346679688)
	    reroute_001.location = (455.0517272949219, -127.69132995605469)
	    reroute_004.location = (637.0446166992188, 92.1860122680664)
	    reroute_005.location = (641.6331787109375, -143.6271209716797)
	    compare.location = (971.4041137695312, -92.09779357910156)
	    delete_geometry.location = (1106.82275390625, -41.41089630126953)
	    group_001.location = (664.374267578125, -201.1261444091797)
	    hair_cut_bake.location = (1664.0001220703125, 46.986976623535156)
	    separate_components.location = (-354.02056884765625, 39.34757995605469)
	    join_geometry.location = (1494.0396728515625, -0.7295894622802734)
	    reroute_006.location = (-46.01055908203125, 203.55471801757812)
	    reroute_007.location = (-46.01055908203125, 198.2002410888672)
	    reroute_008.location = (-46.01055908203125, 187.89125061035156)
	    reroute_009.location = (-44.62933349609375, 182.9856414794922)
	    reroute_010.location = (-46.01055908203125, 193.04579162597656)
	    reroute_011.location = (1297.90771484375, 203.99765014648438)
	    reroute_012.location = (1297.90771484375, 198.99581909179688)
	    reroute_013.location = (1297.90771484375, 188.9942626953125)
	    reroute_014.location = (1297.90771484375, 193.99502563476562)
	    reroute_015.location = (1297.90771484375, 183.99473571777344)
	    attribute_statistic.location = (-184.2984619140625, -65.3093032836914)
	    spline_length.location = (-187.78643798828125, -97.4619140625)
	
	    #Set dimensions
	    group_input.width, group_input.height = 140.0, 100.0
	    group_output_1.width, group_output_1.height = 140.0, 100.0
	    object_info.width, object_info.height = 140.0, 100.0
	    capture_attribute.width, capture_attribute.height = 140.0, 100.0
	    position.width, position.height = 140.0, 100.0
	    resample_curve.width, resample_curve.height = 140.0, 100.0
	    resample_curve_001.width, resample_curve_001.height = 140.0, 100.0
	    math_001.width, math_001.height = 140.0, 100.0
	    vector_math.width, vector_math.height = 140.0, 100.0
	    vector_math_001.width, vector_math_001.height = 140.0, 100.0
	    reroute.width, reroute.height = 10.0, 100.0
	    reroute_002.width, reroute_002.height = 10.0, 100.0
	    reroute_003.width, reroute_003.height = 10.0, 100.0
	    group_input_001.width, group_input_001.height = 140.0, 100.0
	    geometry_proximity.width, geometry_proximity.height = 140.0, 100.0
	    vector_math_002.width, vector_math_002.height = 140.0, 100.0
	    vector_math_003.width, vector_math_003.height = 140.0, 100.0
	    vector_math_004.width, vector_math_004.height = 140.0, 100.0
	    reroute_001.width, reroute_001.height = 10.0, 100.0
	    reroute_004.width, reroute_004.height = 10.0, 100.0
	    reroute_005.width, reroute_005.height = 10.0, 100.0
	    compare.width, compare.height = 140.0, 100.0
	    delete_geometry.width, delete_geometry.height = 140.0, 100.0
	    group_001.width, group_001.height = 140.0, 100.0
	    hair_cut_bake.width, hair_cut_bake.height = 140.0, 100.0
	    separate_components.width, separate_components.height = 140.0, 100.0
	    join_geometry.width, join_geometry.height = 140.0, 100.0
	    reroute_006.width, reroute_006.height = 10.0, 100.0
	    reroute_007.width, reroute_007.height = 10.0, 100.0
	    reroute_008.width, reroute_008.height = 10.0, 100.0
	    reroute_009.width, reroute_009.height = 10.0, 100.0
	    reroute_010.width, reroute_010.height = 10.0, 100.0
	    reroute_011.width, reroute_011.height = 10.0, 100.0
	    reroute_012.width, reroute_012.height = 10.0, 100.0
	    reroute_013.width, reroute_013.height = 10.0, 100.0
	    reroute_014.width, reroute_014.height = 10.0, 100.0
	    reroute_015.width, reroute_015.height = 10.0, 100.0
	    attribute_statistic.width, attribute_statistic.height = 140.0, 100.0
	    spline_length.width, spline_length.height = 140.0, 100.0
	
	    #initialize hair_cut links
	    #hair_cut_bake.Geometry -> group_output_1.Geometry
	    hair_cut.links.new(hair_cut_bake.outputs[0], group_output_1.inputs[0])
	    #resample_curve.Curve -> capture_attribute.Geometry
	    hair_cut.links.new(resample_curve.outputs[0], capture_attribute.inputs[0])
	    #position.Position -> capture_attribute.Position
	    hair_cut.links.new(position.outputs[0], capture_attribute.inputs[1])
	    #reroute.Output -> resample_curve.Curve
	    hair_cut.links.new(reroute.outputs[0], resample_curve.inputs[0])
	    #math_001.Value -> resample_curve.Count
	    hair_cut.links.new(math_001.outputs[0], resample_curve.inputs[2])
	    #delete_geometry.Geometry -> resample_curve_001.Curve
	    hair_cut.links.new(delete_geometry.outputs[0], resample_curve_001.inputs[0])
	    #capture_attribute.Position -> reroute_002.Input
	    hair_cut.links.new(capture_attribute.outputs[1], reroute_002.inputs[0])
	    #reroute_002.Output -> reroute_003.Input
	    hair_cut.links.new(reroute_002.outputs[0], reroute_003.inputs[0])
	    #group_input_001.Cut Shape -> object_info.Object
	    hair_cut.links.new(group_input_001.outputs[1], object_info.inputs[0])
	    #reroute_001.Output -> vector_math.Vector
	    hair_cut.links.new(reroute_001.outputs[0], vector_math.inputs[1])
	    #object_info.Geometry -> geometry_proximity.Geometry
	    hair_cut.links.new(object_info.outputs[4], geometry_proximity.inputs[0])
	    #reroute_003.Output -> geometry_proximity.Sample Position
	    hair_cut.links.new(reroute_003.outputs[0], geometry_proximity.inputs[2])
	    #reroute_005.Output -> vector_math.Vector
	    hair_cut.links.new(reroute_005.outputs[0], vector_math.inputs[0])
	    #reroute_005.Output -> vector_math_001.Vector
	    hair_cut.links.new(reroute_005.outputs[0], vector_math_001.inputs[0])
	    #vector_math.Vector -> vector_math_002.Vector
	    hair_cut.links.new(vector_math.outputs[0], vector_math_002.inputs[0])
	    #vector_math_001.Vector -> vector_math_003.Vector
	    hair_cut.links.new(vector_math_001.outputs[0], vector_math_003.inputs[0])
	    #vector_math_002.Vector -> vector_math_004.Vector
	    hair_cut.links.new(vector_math_002.outputs[0], vector_math_004.inputs[0])
	    #vector_math_003.Vector -> vector_math_004.Vector
	    hair_cut.links.new(vector_math_003.outputs[0], vector_math_004.inputs[1])
	    #reroute_002.Output -> reroute_001.Input
	    hair_cut.links.new(reroute_002.outputs[0], reroute_001.inputs[0])
	    #geometry_proximity.Position -> reroute_004.Input
	    hair_cut.links.new(geometry_proximity.outputs[0], reroute_004.inputs[0])
	    #reroute_004.Output -> reroute_005.Input
	    hair_cut.links.new(reroute_004.outputs[0], reroute_005.inputs[0])
	    #vector_math_004.Value -> compare.A
	    hair_cut.links.new(vector_math_004.outputs[1], compare.inputs[0])
	    #capture_attribute.Geometry -> delete_geometry.Geometry
	    hair_cut.links.new(capture_attribute.outputs[0], delete_geometry.inputs[0])
	    #compare.Result -> delete_geometry.Selection
	    hair_cut.links.new(compare.outputs[0], delete_geometry.inputs[1])
	    #group_001.Root Position -> vector_math_001.Vector
	    hair_cut.links.new(group_001.outputs[1], vector_math_001.inputs[1])
	    #group_input.Geometry -> separate_components.Geometry
	    hair_cut.links.new(group_input.outputs[0], separate_components.inputs[0])
	    #separate_components.Curve -> reroute.Input
	    hair_cut.links.new(separate_components.outputs[1], reroute.inputs[0])
	    #reroute_015.Output -> join_geometry.Geometry
	    hair_cut.links.new(reroute_015.outputs[0], join_geometry.inputs[0])
	    #separate_components.Mesh -> reroute_006.Input
	    hair_cut.links.new(separate_components.outputs[0], reroute_006.inputs[0])
	    #separate_components.Grease Pencil -> reroute_007.Input
	    hair_cut.links.new(separate_components.outputs[2], reroute_007.inputs[0])
	    #separate_components.Volume -> reroute_008.Input
	    hair_cut.links.new(separate_components.outputs[4], reroute_008.inputs[0])
	    #separate_components.Instances -> reroute_009.Input
	    hair_cut.links.new(separate_components.outputs[5], reroute_009.inputs[0])
	    #separate_components.Point Cloud -> reroute_010.Input
	    hair_cut.links.new(separate_components.outputs[3], reroute_010.inputs[0])
	    #reroute_006.Output -> reroute_011.Input
	    hair_cut.links.new(reroute_006.outputs[0], reroute_011.inputs[0])
	    #reroute_007.Output -> reroute_012.Input
	    hair_cut.links.new(reroute_007.outputs[0], reroute_012.inputs[0])
	    #reroute_008.Output -> reroute_013.Input
	    hair_cut.links.new(reroute_008.outputs[0], reroute_013.inputs[0])
	    #reroute_010.Output -> reroute_014.Input
	    hair_cut.links.new(reroute_010.outputs[0], reroute_014.inputs[0])
	    #reroute_009.Output -> reroute_015.Input
	    hair_cut.links.new(reroute_009.outputs[0], reroute_015.inputs[0])
	    #join_geometry.Geometry -> hair_cut_bake.Geometry
	    hair_cut.links.new(join_geometry.outputs[0], hair_cut_bake.inputs[0])
	    #reroute.Output -> attribute_statistic.Geometry
	    hair_cut.links.new(reroute.outputs[0], attribute_statistic.inputs[0])
	    #spline_length.Point Count -> attribute_statistic.Attribute
	    hair_cut.links.new(spline_length.outputs[1], attribute_statistic.inputs[2])
	    #attribute_statistic.Max -> resample_curve_001.Count
	    hair_cut.links.new(attribute_statistic.outputs[4], resample_curve_001.inputs[2])
	    #attribute_statistic.Max -> math_001.Value
	    hair_cut.links.new(attribute_statistic.outputs[4], math_001.inputs[0])
	    #reroute_013.Output -> join_geometry.Geometry
	    hair_cut.links.new(reroute_013.outputs[0], join_geometry.inputs[0])
	    #reroute_014.Output -> join_geometry.Geometry
	    hair_cut.links.new(reroute_014.outputs[0], join_geometry.inputs[0])
	    #reroute_012.Output -> join_geometry.Geometry
	    hair_cut.links.new(reroute_012.outputs[0], join_geometry.inputs[0])
	    #reroute_011.Output -> join_geometry.Geometry
	    hair_cut.links.new(reroute_011.outputs[0], join_geometry.inputs[0])
	    #resample_curve_001.Curve -> join_geometry.Geometry
	    hair_cut.links.new(resample_curve_001.outputs[0], join_geometry.inputs[0])
	    return hair_cut
	return hair_cut_node_group()

	

	
