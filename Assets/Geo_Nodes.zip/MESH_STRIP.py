import bpy, mathutils

def node():
	#initialize mesh_strip node group
	def mesh_strip_node_group():
	    mesh_strip = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "MESH_STRIP")
	
	    mesh_strip.color_tag = 'NONE'
	    mesh_strip.description = "Convert curve into a mesh strip."
	    mesh_strip.default_group_node_width = 140
	    
	
	    mesh_strip.is_modifier = True
	
	    #mesh_strip interface
	    #Socket Geometry
	    geometry_socket = mesh_strip.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket.attribute_domain = 'POINT'
	    geometry_socket.description = "Mesh strip."
	
	    #Socket Geometry
	    geometry_socket_1 = mesh_strip.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_1.attribute_domain = 'POINT'
	    geometry_socket_1.description = "Hair Curve."
	
	    #Socket Width
	    width_socket = mesh_strip.interface.new_socket(name = "Width", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    width_socket.default_value = 0.10000000149011612
	    width_socket.min_value = 0.0
	    width_socket.max_value = 3.4028234663852886e+38
	    width_socket.subtype = 'DISTANCE'
	    width_socket.attribute_domain = 'POINT'
	    width_socket.description = "Width of mesh strip."
	
	    #Socket Shade Smooth
	    shade_smooth_socket = mesh_strip.interface.new_socket(name = "Shade Smooth", in_out='INPUT', socket_type = 'NodeSocketBool')
	    shade_smooth_socket.default_value = True
	    shade_smooth_socket.attribute_domain = 'POINT'
	    shade_smooth_socket.description = "Mesh smooth shading."
	
	    #Socket Material
	    material_socket = mesh_strip.interface.new_socket(name = "Material", in_out='INPUT', socket_type = 'NodeSocketMaterial')
	    material_socket.attribute_domain = 'POINT'
	    material_socket.description = "Mesh material."
	
	
	    #initialize mesh_strip nodes
	    #node Group Output
	    group_output = mesh_strip.nodes.new("NodeGroupOutput")
	    group_output.name = "Group Output"
	    group_output.is_active_output = True
	    group_output.inputs[1].hide = True
	
	    #node Group Input
	    group_input = mesh_strip.nodes.new("NodeGroupInput")
	    group_input.name = "Group Input"
	    group_input.outputs[0].hide = True
	    group_input.outputs[2].hide = True
	    group_input.outputs[3].hide = True
	    group_input.outputs[4].hide = True
	
	    #node Curve to Mesh
	    curve_to_mesh = mesh_strip.nodes.new("GeometryNodeCurveToMesh")
	    curve_to_mesh.name = "Curve to Mesh"
	    curve_to_mesh.hide = True
	    curve_to_mesh.inputs[2].hide = True
	    #Fill Caps
	    curve_to_mesh.inputs[2].default_value = False
	
	    #node Curve Line
	    curve_line = mesh_strip.nodes.new("GeometryNodeCurvePrimitiveLine")
	    curve_line.name = "Curve Line"
	    curve_line.hide = True
	    curve_line.mode = 'DIRECTION'
	    curve_line.inputs[1].hide = True
	    curve_line.inputs[2].hide = True
	    #Direction
	    curve_line.inputs[2].default_value = (0.0, 1.0, 0.0)
	
	    #node Combine XYZ.001
	    combine_xyz_001 = mesh_strip.nodes.new("ShaderNodeCombineXYZ")
	    combine_xyz_001.name = "Combine XYZ.001"
	    combine_xyz_001.hide = True
	    combine_xyz_001.inputs[0].hide = True
	    combine_xyz_001.inputs[2].hide = True
	    #X
	    combine_xyz_001.inputs[0].default_value = 0.0
	    #Z
	    combine_xyz_001.inputs[2].default_value = 0.0
	
	    #node Math.001
	    math_001 = mesh_strip.nodes.new("ShaderNodeMath")
	    math_001.name = "Math.001"
	    math_001.hide = True
	    math_001.operation = 'MULTIPLY'
	    math_001.use_clamp = False
	    math_001.inputs[1].hide = True
	    math_001.inputs[2].hide = True
	    #Value_001
	    math_001.inputs[1].default_value = -0.5
	
	    #node Set Shade Smooth
	    set_shade_smooth = mesh_strip.nodes.new("GeometryNodeSetShadeSmooth")
	    set_shade_smooth.name = "Set Shade Smooth"
	    set_shade_smooth.hide = True
	    set_shade_smooth.domain = 'FACE'
	    set_shade_smooth.inputs[1].hide = True
	    #Selection
	    set_shade_smooth.inputs[1].default_value = True
	
	    #node Capture Attribute
	    capture_attribute = mesh_strip.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute.name = "Capture Attribute"
	    capture_attribute.hide = True
	    capture_attribute.active_index = 0
	    capture_attribute.capture_items.clear()
	    capture_attribute.capture_items.new('FLOAT', "Factor")
	    capture_attribute.capture_items["Factor"].data_type = 'FLOAT'
	    capture_attribute.domain = 'POINT'
	    capture_attribute.inputs[2].hide = True
	    capture_attribute.outputs[2].hide = True
	
	    #node Store Named Attribute
	    store_named_attribute = mesh_strip.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute.name = "Store Named Attribute"
	    store_named_attribute.data_type = 'FLOAT2'
	    store_named_attribute.domain = 'CORNER'
	    #Selection
	    store_named_attribute.inputs[1].default_value = True
	    #Name
	    store_named_attribute.inputs[2].default_value = "UVMap"
	
	    #node Set Material
	    set_material = mesh_strip.nodes.new("GeometryNodeSetMaterial")
	    set_material.name = "Set Material"
	    set_material.hide = True
	    #Selection
	    set_material.inputs[1].default_value = True
	
	    #node Capture Attribute.002
	    capture_attribute_002 = mesh_strip.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_002.name = "Capture Attribute.002"
	    capture_attribute_002.hide = True
	    capture_attribute_002.active_index = 0
	    capture_attribute_002.capture_items.clear()
	    capture_attribute_002.capture_items.new('FLOAT', "Factor")
	    capture_attribute_002.capture_items["Factor"].data_type = 'FLOAT'
	    capture_attribute_002.domain = 'POINT'
	    capture_attribute_002.inputs[2].hide = True
	    capture_attribute_002.outputs[2].hide = True
	
	    #node Spline Parameter.001
	    spline_parameter_001 = mesh_strip.nodes.new("GeometryNodeSplineParameter")
	    spline_parameter_001.name = "Spline Parameter.001"
	    spline_parameter_001.outputs[1].hide = True
	    spline_parameter_001.outputs[2].hide = True
	
	    #node Combine XYZ.003
	    combine_xyz_003 = mesh_strip.nodes.new("ShaderNodeCombineXYZ")
	    combine_xyz_003.name = "Combine XYZ.003"
	    combine_xyz_003.hide = True
	    combine_xyz_003.inputs[2].hide = True
	    #Z
	    combine_xyz_003.inputs[2].default_value = 0.0
	
	    #node Group Input.001
	    group_input_001 = mesh_strip.nodes.new("NodeGroupInput")
	    group_input_001.name = "Group Input.001"
	    group_input_001.outputs[0].hide = True
	    group_input_001.outputs[1].hide = True
	    group_input_001.outputs[2].hide = True
	    group_input_001.outputs[4].hide = True
	
	    #node Group Input.002
	    group_input_002 = mesh_strip.nodes.new("NodeGroupInput")
	    group_input_002.name = "Group Input.002"
	    group_input_002.outputs[0].hide = True
	    group_input_002.outputs[1].hide = True
	    group_input_002.outputs[3].hide = True
	    group_input_002.outputs[4].hide = True
	
	    #node Group Input.003
	    group_input_003 = mesh_strip.nodes.new("NodeGroupInput")
	    group_input_003.name = "Group Input.003"
	    group_input_003.outputs[1].hide = True
	    group_input_003.outputs[2].hide = True
	    group_input_003.outputs[3].hide = True
	    group_input_003.outputs[4].hide = True
	
	    #node Set Curve Radius
	    set_curve_radius = mesh_strip.nodes.new("GeometryNodeSetCurveRadius")
	    set_curve_radius.name = "Set Curve Radius"
	    set_curve_radius.hide = True
	    set_curve_radius.inputs[1].hide = True
	    #Selection
	    set_curve_radius.inputs[1].default_value = True
	
	    #node Mesh Shape
	    mesh_shape = mesh_strip.nodes.new("ShaderNodeFloatCurve")
	    mesh_shape.label = "Mesh Shape"
	    mesh_shape.name = "Mesh Shape"
	    #mapping settings
	    mesh_shape.mapping.extend = 'EXTRAPOLATED'
	    mesh_shape.mapping.tone = 'STANDARD'
	    mesh_shape.mapping.black_level = (0.0, 0.0, 0.0)
	    mesh_shape.mapping.white_level = (1.0, 1.0, 1.0)
	    mesh_shape.mapping.clip_min_x = 0.0
	    mesh_shape.mapping.clip_min_y = 0.0
	    mesh_shape.mapping.clip_max_x = 1.0
	    mesh_shape.mapping.clip_max_y = 1.0
	    mesh_shape.mapping.use_clip = True
	    #curve 0
	    mesh_shape_curve_0 = mesh_shape.mapping.curves[0]
	    mesh_shape_curve_0_point_0 = mesh_shape_curve_0.points[0]
	    mesh_shape_curve_0_point_0.location = (0.0, 1.0)
	    mesh_shape_curve_0_point_0.handle_type = 'AUTO'
	    mesh_shape_curve_0_point_1 = mesh_shape_curve_0.points[1]
	    mesh_shape_curve_0_point_1.location = (1.0, 1.0)
	    mesh_shape_curve_0_point_1.handle_type = 'AUTO'
	    #update curve after changes
	    mesh_shape.mapping.update()
	    mesh_shape.inputs[0].hide = True
	    #Factor
	    mesh_shape.inputs[0].default_value = 1.0
	
	    #node Spline Parameter.002
	    spline_parameter_002 = mesh_strip.nodes.new("GeometryNodeSplineParameter")
	    spline_parameter_002.name = "Spline Parameter.002"
	    spline_parameter_002.outputs[1].hide = True
	    spline_parameter_002.outputs[2].hide = True
	
	    #node Mesh Bake
	    mesh_bake = mesh_strip.nodes.new("GeometryNodeBake")
	    mesh_bake.label = "Mesh Bake"
	    mesh_bake.name = "Mesh Bake"
	    mesh_bake.active_index = 0
	    mesh_bake.bake_items.clear()
	    mesh_bake.bake_items.new('GEOMETRY', "Geometry")
	    mesh_bake.bake_items[0].attribute_domain = 'POINT'
	    mesh_bake.inputs[1].hide = True
	    mesh_bake.outputs[1].hide = True
	
	    #node Separate Components
	    separate_components = mesh_strip.nodes.new("GeometryNodeSeparateComponents")
	    separate_components.name = "Separate Components"
	    separate_components.hide = True
	
	    #node Join Geometry
	    join_geometry = mesh_strip.nodes.new("GeometryNodeJoinGeometry")
	    join_geometry.name = "Join Geometry"
	
	    #node Reroute
	    reroute = mesh_strip.nodes.new("NodeReroute")
	    reroute.name = "Reroute"
	    reroute.socket_idname = "NodeSocketGeometry"
	    #node Reroute.001
	    reroute_001 = mesh_strip.nodes.new("NodeReroute")
	    reroute_001.name = "Reroute.001"
	    reroute_001.socket_idname = "NodeSocketGeometry"
	    #node Reroute.002
	    reroute_002 = mesh_strip.nodes.new("NodeReroute")
	    reroute_002.name = "Reroute.002"
	    reroute_002.socket_idname = "NodeSocketGeometry"
	    #node Reroute.003
	    reroute_003 = mesh_strip.nodes.new("NodeReroute")
	    reroute_003.name = "Reroute.003"
	    reroute_003.socket_idname = "NodeSocketGeometry"
	    #node Reroute.004
	    reroute_004 = mesh_strip.nodes.new("NodeReroute")
	    reroute_004.name = "Reroute.004"
	    reroute_004.socket_idname = "NodeSocketGeometry"
	    #node Reroute.005
	    reroute_005 = mesh_strip.nodes.new("NodeReroute")
	    reroute_005.name = "Reroute.005"
	    reroute_005.socket_idname = "NodeSocketGeometry"
	    #node Reroute.006
	    reroute_006 = mesh_strip.nodes.new("NodeReroute")
	    reroute_006.name = "Reroute.006"
	    reroute_006.socket_idname = "NodeSocketGeometry"
	    #node Reroute.007
	    reroute_007 = mesh_strip.nodes.new("NodeReroute")
	    reroute_007.name = "Reroute.007"
	    reroute_007.socket_idname = "NodeSocketGeometry"
	    #node Reroute.008
	    reroute_008 = mesh_strip.nodes.new("NodeReroute")
	    reroute_008.name = "Reroute.008"
	    reroute_008.socket_idname = "NodeSocketGeometry"
	    #node Reroute.009
	    reroute_009 = mesh_strip.nodes.new("NodeReroute")
	    reroute_009.name = "Reroute.009"
	    reroute_009.socket_idname = "NodeSocketGeometry"
	
	
	
	
	    #Set locations
	    group_output.location = (944.61669921875, 92.7010498046875)
	    group_input.location = (-562.1895141601562, 29.572296142578125)
	    curve_to_mesh.location = (32.7371826171875, 50.001190185546875)
	    curve_line.location = (-361.7039794921875, -25.414398193359375)
	    combine_xyz_001.location = (-361.2547607421875, 9.869476318359375)
	    math_001.location = (-362.18951416015625, 46.61334228515625)
	    set_shade_smooth.location = (33.899169921875, 12.753509521484375)
	    capture_attribute.location = (-177.2156982421875, 9.4949951171875)
	    store_named_attribute.location = (200.96240234375, 83.67747497558594)
	    set_material.location = (362.189453125, 47.34906005859375)
	    capture_attribute_002.location = (-180.4632568359375, -36.271575927734375)
	    spline_parameter_001.location = (-359.17535400390625, -57.465911865234375)
	    combine_xyz_003.location = (36.32861328125, -83.677490234375)
	    group_input_001.location = (361.3492736816406, 10.561531066894531)
	    group_input_002.location = (32.41766357421875, -16.898452758789062)
	    group_input_003.location = (-359.77008056640625, 162.04959106445312)
	    set_curve_radius.location = (-361.65057373046875, 84.4383544921875)
	    mesh_shape.location = (-814.0376586914062, 102.21343994140625)
	    spline_parameter_002.location = (-813.3016357421875, -192.83901977539062)
	    mesh_bake.location = (764.4188232421875, 139.30262756347656)
	    separate_components.location = (-358.1722106933594, 200.15603637695312)
	    join_geometry.location = (568.9017333984375, 92.25613403320312)
	    reroute.location = (-137.274658203125, 197.8334197998047)
	    reroute_001.location = (-137.274658203125, 187.42483520507812)
	    reroute_002.location = (-137.6398468017578, 203.5111083984375)
	    reroute_003.location = (-137.274658203125, 182.45799255371094)
	    reroute_004.location = (-137.274658203125, 192.48793029785156)
	    reroute_005.location = (452.4445495605469, 197.99574279785156)
	    reroute_006.location = (453.35614013671875, 203.01223754882812)
	    reroute_007.location = (452.365234375, 182.98611450195312)
	    reroute_008.location = (452.365234375, 192.98690795898438)
	    reroute_009.location = (452.365234375, 187.98529052734375)
	
	    #Set dimensions
	    group_output.width, group_output.height = 140.0, 100.0
	    group_input.width, group_input.height = 140.0, 100.0
	    curve_to_mesh.width, curve_to_mesh.height = 140.0, 100.0
	    curve_line.width, curve_line.height = 140.0, 100.0
	    combine_xyz_001.width, combine_xyz_001.height = 140.0, 100.0
	    math_001.width, math_001.height = 140.0, 100.0
	    set_shade_smooth.width, set_shade_smooth.height = 140.0, 100.0
	    capture_attribute.width, capture_attribute.height = 140.0, 100.0
	    store_named_attribute.width, store_named_attribute.height = 140.0, 100.0
	    set_material.width, set_material.height = 140.0, 100.0
	    capture_attribute_002.width, capture_attribute_002.height = 140.0, 100.0
	    spline_parameter_001.width, spline_parameter_001.height = 140.0, 100.0
	    combine_xyz_003.width, combine_xyz_003.height = 140.0, 100.0
	    group_input_001.width, group_input_001.height = 140.0, 100.0
	    group_input_002.width, group_input_002.height = 140.0, 100.0
	    group_input_003.width, group_input_003.height = 140.0, 100.0
	    set_curve_radius.width, set_curve_radius.height = 140.0, 100.0
	    mesh_shape.width, mesh_shape.height = 240.0, 100.0
	    spline_parameter_002.width, spline_parameter_002.height = 140.0, 100.0
	    mesh_bake.width, mesh_bake.height = 140.0, 100.0
	    separate_components.width, separate_components.height = 140.0, 100.0
	    join_geometry.width, join_geometry.height = 140.0, 100.0
	    reroute.width, reroute.height = 10.0, 100.0
	    reroute_001.width, reroute_001.height = 10.0, 100.0
	    reroute_002.width, reroute_002.height = 10.0, 100.0
	    reroute_003.width, reroute_003.height = 10.0, 100.0
	    reroute_004.width, reroute_004.height = 10.0, 100.0
	    reroute_005.width, reroute_005.height = 10.0, 100.0
	    reroute_006.width, reroute_006.height = 10.0, 100.0
	    reroute_007.width, reroute_007.height = 10.0, 100.0
	    reroute_008.width, reroute_008.height = 10.0, 100.0
	    reroute_009.width, reroute_009.height = 10.0, 100.0
	
	    #initialize mesh_strip links
	    #math_001.Value -> combine_xyz_001.Y
	    mesh_strip.links.new(math_001.outputs[0], combine_xyz_001.inputs[1])
	    #curve_line.Curve -> capture_attribute_002.Geometry
	    mesh_strip.links.new(curve_line.outputs[0], capture_attribute_002.inputs[0])
	    #set_shade_smooth.Geometry -> store_named_attribute.Geometry
	    mesh_strip.links.new(set_shade_smooth.outputs[0], store_named_attribute.inputs[0])
	    #capture_attribute_002.Geometry -> curve_to_mesh.Profile Curve
	    mesh_strip.links.new(capture_attribute_002.outputs[0], curve_to_mesh.inputs[1])
	    #spline_parameter_001.Factor -> capture_attribute_002.Factor
	    mesh_strip.links.new(spline_parameter_001.outputs[0], capture_attribute_002.inputs[1])
	    #capture_attribute_002.Factor -> combine_xyz_003.Y
	    mesh_strip.links.new(capture_attribute_002.outputs[1], combine_xyz_003.inputs[1])
	    #store_named_attribute.Geometry -> set_material.Geometry
	    mesh_strip.links.new(store_named_attribute.outputs[0], set_material.inputs[0])
	    #spline_parameter_001.Factor -> capture_attribute.Factor
	    mesh_strip.links.new(spline_parameter_001.outputs[0], capture_attribute.inputs[1])
	    #capture_attribute.Factor -> combine_xyz_003.X
	    mesh_strip.links.new(capture_attribute.outputs[1], combine_xyz_003.inputs[0])
	    #capture_attribute.Geometry -> curve_to_mesh.Curve
	    mesh_strip.links.new(capture_attribute.outputs[0], curve_to_mesh.inputs[0])
	    #combine_xyz_003.Vector -> store_named_attribute.Value
	    mesh_strip.links.new(combine_xyz_003.outputs[0], store_named_attribute.inputs[3])
	    #curve_to_mesh.Mesh -> set_shade_smooth.Geometry
	    mesh_strip.links.new(curve_to_mesh.outputs[0], set_shade_smooth.inputs[0])
	    #combine_xyz_001.Vector -> curve_line.Start
	    mesh_strip.links.new(combine_xyz_001.outputs[0], curve_line.inputs[0])
	    #group_input.Width -> curve_line.Length
	    mesh_strip.links.new(group_input.outputs[1], curve_line.inputs[3])
	    #group_input.Width -> math_001.Value
	    mesh_strip.links.new(group_input.outputs[1], math_001.inputs[0])
	    #mesh_bake.Geometry -> group_output.Geometry
	    mesh_strip.links.new(mesh_bake.outputs[0], group_output.inputs[0])
	    #group_input_001.Material -> set_material.Material
	    mesh_strip.links.new(group_input_001.outputs[3], set_material.inputs[2])
	    #group_input_002.Shade Smooth -> set_shade_smooth.Shade Smooth
	    mesh_strip.links.new(group_input_002.outputs[2], set_shade_smooth.inputs[2])
	    #spline_parameter_002.Factor -> mesh_shape.Value
	    mesh_strip.links.new(spline_parameter_002.outputs[0], mesh_shape.inputs[1])
	    #mesh_shape.Value -> set_curve_radius.Radius
	    mesh_strip.links.new(mesh_shape.outputs[0], set_curve_radius.inputs[2])
	    #set_curve_radius.Curve -> capture_attribute.Geometry
	    mesh_strip.links.new(set_curve_radius.outputs[0], capture_attribute.inputs[0])
	    #group_input_003.Geometry -> separate_components.Geometry
	    mesh_strip.links.new(group_input_003.outputs[0], separate_components.inputs[0])
	    #separate_components.Curve -> set_curve_radius.Curve
	    mesh_strip.links.new(separate_components.outputs[1], set_curve_radius.inputs[0])
	    #reroute_007.Output -> join_geometry.Geometry
	    mesh_strip.links.new(reroute_007.outputs[0], join_geometry.inputs[0])
	    #separate_components.Grease Pencil -> reroute.Input
	    mesh_strip.links.new(separate_components.outputs[2], reroute.inputs[0])
	    #separate_components.Volume -> reroute_001.Input
	    mesh_strip.links.new(separate_components.outputs[4], reroute_001.inputs[0])
	    #separate_components.Mesh -> reroute_002.Input
	    mesh_strip.links.new(separate_components.outputs[0], reroute_002.inputs[0])
	    #separate_components.Instances -> reroute_003.Input
	    mesh_strip.links.new(separate_components.outputs[5], reroute_003.inputs[0])
	    #separate_components.Point Cloud -> reroute_004.Input
	    mesh_strip.links.new(separate_components.outputs[3], reroute_004.inputs[0])
	    #reroute.Output -> reroute_005.Input
	    mesh_strip.links.new(reroute.outputs[0], reroute_005.inputs[0])
	    #reroute_002.Output -> reroute_006.Input
	    mesh_strip.links.new(reroute_002.outputs[0], reroute_006.inputs[0])
	    #reroute_003.Output -> reroute_007.Input
	    mesh_strip.links.new(reroute_003.outputs[0], reroute_007.inputs[0])
	    #reroute_004.Output -> reroute_008.Input
	    mesh_strip.links.new(reroute_004.outputs[0], reroute_008.inputs[0])
	    #reroute_001.Output -> reroute_009.Input
	    mesh_strip.links.new(reroute_001.outputs[0], reroute_009.inputs[0])
	    #join_geometry.Geometry -> mesh_bake.Geometry
	    mesh_strip.links.new(join_geometry.outputs[0], mesh_bake.inputs[0])
	    #reroute_009.Output -> join_geometry.Geometry
	    mesh_strip.links.new(reroute_009.outputs[0], join_geometry.inputs[0])
	    #reroute_008.Output -> join_geometry.Geometry
	    mesh_strip.links.new(reroute_008.outputs[0], join_geometry.inputs[0])
	    #reroute_005.Output -> join_geometry.Geometry
	    mesh_strip.links.new(reroute_005.outputs[0], join_geometry.inputs[0])
	    #reroute_006.Output -> join_geometry.Geometry
	    mesh_strip.links.new(reroute_006.outputs[0], join_geometry.inputs[0])
	    #set_material.Geometry -> join_geometry.Geometry
	    mesh_strip.links.new(set_material.outputs[0], join_geometry.inputs[0])
	    return mesh_strip
	return mesh_strip_node_group()

	

	
