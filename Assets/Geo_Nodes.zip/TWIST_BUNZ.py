import bpy, mathutils

def node():
	#initialize twist node group
	def twist_node_group():
	    twist = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "TWIST")
	
	    twist.color_tag = 'NONE'
	    twist.description = ""
	    twist.default_group_node_width = 140
	    
	
	
	    #twist interface
	    #Socket Geometry
	    geometry_socket = twist.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket.attribute_domain = 'POINT'
	
	    #Socket Control Points
	    control_points_socket = twist.interface.new_socket(name = "Control Points", in_out='INPUT', socket_type = 'NodeSocketInt')
	    control_points_socket.default_value = 20
	    control_points_socket.min_value = 1
	    control_points_socket.max_value = 100000
	    control_points_socket.subtype = 'NONE'
	    control_points_socket.attribute_domain = 'POINT'
	
	    #Socket Offset Scale
	    offset_scale_socket = twist.interface.new_socket(name = "Offset Scale", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    offset_scale_socket.default_value = 0.0
	    offset_scale_socket.min_value = -3.4028234663852886e+38
	    offset_scale_socket.max_value = 3.4028234663852886e+38
	    offset_scale_socket.subtype = 'NONE'
	    offset_scale_socket.attribute_domain = 'POINT'
	
	    #Socket Rotate
	    rotate_socket = twist.interface.new_socket(name = "Rotate", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    rotate_socket.default_value = 0.0
	    rotate_socket.min_value = -3.1415927410125732
	    rotate_socket.max_value = 3.1415927410125732
	    rotate_socket.subtype = 'ANGLE'
	    rotate_socket.attribute_domain = 'POINT'
	
	    #Socket Scale
	    scale_socket = twist.interface.new_socket(name = "Scale", in_out='INPUT', socket_type = 'NodeSocketVector')
	    scale_socket.default_value = (1.0, 1.0, 1.0)
	    scale_socket.min_value = -3.4028234663852886e+38
	    scale_socket.max_value = 3.4028234663852886e+38
	    scale_socket.subtype = 'XYZ'
	    scale_socket.attribute_domain = 'POINT'
	
	
	    #initialize twist nodes
	    #node Group Output
	    group_output = twist.nodes.new("NodeGroupOutput")
	    group_output.name = "Group Output"
	    group_output.is_active_output = True
	    group_output.inputs[1].hide = True
	
	    #node Group Input
	    group_input = twist.nodes.new("NodeGroupInput")
	    group_input.name = "Group Input"
	    group_input.outputs[0].hide = True
	    group_input.outputs[3].hide = True
	    group_input.outputs[4].hide = True
	
	    #node Spiral
	    spiral = twist.nodes.new("GeometryNodeCurveSpiral")
	    spiral.name = "Spiral"
	    spiral.inputs[0].hide = True
	    spiral.inputs[1].hide = True
	    spiral.inputs[2].hide = True
	    spiral.inputs[3].hide = True
	    spiral.inputs[4].hide = True
	    spiral.inputs[5].hide = True
	    #Resolution
	    spiral.inputs[0].default_value = 32
	    #Rotations
	    spiral.inputs[1].default_value = 0.25
	    #Start Radius
	    spiral.inputs[2].default_value = 0.0
	    #End Radius
	    spiral.inputs[3].default_value = 1.0
	    #Height
	    spiral.inputs[4].default_value = 0.0
	    #Reverse
	    spiral.inputs[5].default_value = False
	
	    #node Reverse Curve
	    reverse_curve = twist.nodes.new("GeometryNodeReverseCurve")
	    reverse_curve.name = "Reverse Curve"
	    reverse_curve.inputs[1].hide = True
	    #Selection
	    reverse_curve.inputs[1].default_value = True
	
	    #node Set Position
	    set_position = twist.nodes.new("GeometryNodeSetPosition")
	    set_position.name = "Set Position"
	    set_position.inputs[1].hide = True
	    set_position.inputs[3].hide = True
	    #Selection
	    set_position.inputs[1].default_value = True
	    #Offset
	    set_position.inputs[3].default_value = (1.0, 0.0, 0.0)
	
	    #node Position
	    position = twist.nodes.new("GeometryNodeInputPosition")
	    position.name = "Position"
	
	    #node Combine XYZ
	    combine_xyz = twist.nodes.new("ShaderNodeCombineXYZ")
	    combine_xyz.name = "Combine XYZ"
	    combine_xyz.hide = True
	
	    #node Separate XYZ
	    separate_xyz = twist.nodes.new("ShaderNodeSeparateXYZ")
	    separate_xyz.name = "Separate XYZ"
	    separate_xyz.hide = True
	
	    #node Set Position.001
	    set_position_001 = twist.nodes.new("GeometryNodeSetPosition")
	    set_position_001.name = "Set Position.001"
	    set_position_001.inputs[2].hide = True
	    #Position
	    set_position_001.inputs[2].default_value = (0.0, 0.0, 0.0)
	
	    #node Twist Stem Offset Shape
	    twist_stem_offset_shape = twist.nodes.new("ShaderNodeFloatCurve")
	    twist_stem_offset_shape.label = "Twist Stem Offset Shape"
	    twist_stem_offset_shape.name = "Twist Stem Offset Shape"
	    #mapping settings
	    twist_stem_offset_shape.mapping.extend = 'EXTRAPOLATED'
	    twist_stem_offset_shape.mapping.tone = 'STANDARD'
	    twist_stem_offset_shape.mapping.black_level = (0.0, 0.0, 0.0)
	    twist_stem_offset_shape.mapping.white_level = (1.0, 1.0, 1.0)
	    twist_stem_offset_shape.mapping.clip_min_x = 0.0
	    twist_stem_offset_shape.mapping.clip_min_y = 0.0
	    twist_stem_offset_shape.mapping.clip_max_x = 1.0
	    twist_stem_offset_shape.mapping.clip_max_y = 1.0
	    twist_stem_offset_shape.mapping.use_clip = True
	    #curve 0
	    twist_stem_offset_shape_curve_0 = twist_stem_offset_shape.mapping.curves[0]
	    twist_stem_offset_shape_curve_0_point_0 = twist_stem_offset_shape_curve_0.points[0]
	    twist_stem_offset_shape_curve_0_point_0.location = (0.0, 0.0)
	    twist_stem_offset_shape_curve_0_point_0.handle_type = 'AUTO'
	    twist_stem_offset_shape_curve_0_point_1 = twist_stem_offset_shape_curve_0.points[1]
	    twist_stem_offset_shape_curve_0_point_1.location = (0.22727283835411072, 0.8125003576278687)
	    twist_stem_offset_shape_curve_0_point_1.handle_type = 'AUTO'
	    twist_stem_offset_shape_curve_0_point_2 = twist_stem_offset_shape_curve_0.points.new(0.695454478263855, 0.9749999046325684)
	    twist_stem_offset_shape_curve_0_point_2.handle_type = 'AUTO'
	    twist_stem_offset_shape_curve_0_point_3 = twist_stem_offset_shape_curve_0.points.new(1.0, 1.0)
	    twist_stem_offset_shape_curve_0_point_3.handle_type = 'AUTO'
	    #update curve after changes
	    twist_stem_offset_shape.mapping.update()
	    twist_stem_offset_shape.inputs[0].hide = True
	    #Factor
	    twist_stem_offset_shape.inputs[0].default_value = 1.0
	
	    #node Spline Parameter
	    spline_parameter = twist.nodes.new("GeometryNodeSplineParameter")
	    spline_parameter.name = "Spline Parameter"
	    spline_parameter.outputs[1].hide = True
	    spline_parameter.outputs[2].hide = True
	
	    #node Combine XYZ.001
	    combine_xyz_001 = twist.nodes.new("ShaderNodeCombineXYZ")
	    combine_xyz_001.name = "Combine XYZ.001"
	    combine_xyz_001.hide = True
	    combine_xyz_001.inputs[1].hide = True
	    combine_xyz_001.inputs[2].hide = True
	    #Y
	    combine_xyz_001.inputs[1].default_value = 0.0
	    #Z
	    combine_xyz_001.inputs[2].default_value = 0.0
	
	    #node Math
	    math = twist.nodes.new("ShaderNodeMath")
	    math.name = "Math"
	    math.hide = True
	    math.operation = 'SUBTRACT'
	    math.use_clamp = False
	    math.inputs[0].hide = True
	    math.inputs[2].hide = True
	    #Value
	    math.inputs[0].default_value = 1.0
	
	    #node Duplicate Elements
	    duplicate_elements = twist.nodes.new("GeometryNodeDuplicateElements")
	    duplicate_elements.name = "Duplicate Elements"
	    duplicate_elements.domain = 'SPLINE'
	    duplicate_elements.inputs[1].hide = True
	    duplicate_elements.inputs[2].hide = True
	    duplicate_elements.outputs[1].hide = True
	    #Selection
	    duplicate_elements.inputs[1].default_value = True
	    #Amount
	    duplicate_elements.inputs[2].default_value = 1
	
	    #node Twist Overhang Offset Shape
	    twist_overhang_offset_shape = twist.nodes.new("ShaderNodeFloatCurve")
	    twist_overhang_offset_shape.label = "Twist Overhang Offset Shape"
	    twist_overhang_offset_shape.name = "Twist Overhang Offset Shape"
	    #mapping settings
	    twist_overhang_offset_shape.mapping.extend = 'EXTRAPOLATED'
	    twist_overhang_offset_shape.mapping.tone = 'STANDARD'
	    twist_overhang_offset_shape.mapping.black_level = (0.0, 0.0, 0.0)
	    twist_overhang_offset_shape.mapping.white_level = (1.0, 1.0, 1.0)
	    twist_overhang_offset_shape.mapping.clip_min_x = 0.0
	    twist_overhang_offset_shape.mapping.clip_min_y = 0.0
	    twist_overhang_offset_shape.mapping.clip_max_x = 1.0
	    twist_overhang_offset_shape.mapping.clip_max_y = 1.0
	    twist_overhang_offset_shape.mapping.use_clip = True
	    #curve 0
	    twist_overhang_offset_shape_curve_0 = twist_overhang_offset_shape.mapping.curves[0]
	    twist_overhang_offset_shape_curve_0_point_0 = twist_overhang_offset_shape_curve_0.points[0]
	    twist_overhang_offset_shape_curve_0_point_0.location = (0.0, 0.49999991059303284)
	    twist_overhang_offset_shape_curve_0_point_0.handle_type = 'AUTO'
	    twist_overhang_offset_shape_curve_0_point_1 = twist_overhang_offset_shape_curve_0.points[1]
	    twist_overhang_offset_shape_curve_0_point_1.location = (0.2681819200515747, 0.8750004172325134)
	    twist_overhang_offset_shape_curve_0_point_1.handle_type = 'AUTO'
	    twist_overhang_offset_shape_curve_0_point_2 = twist_overhang_offset_shape_curve_0.points.new(0.695454478263855, 0.9749999046325684)
	    twist_overhang_offset_shape_curve_0_point_2.handle_type = 'AUTO'
	    twist_overhang_offset_shape_curve_0_point_3 = twist_overhang_offset_shape_curve_0.points.new(1.0, 1.0)
	    twist_overhang_offset_shape_curve_0_point_3.handle_type = 'AUTO'
	    #update curve after changes
	    twist_overhang_offset_shape.mapping.update()
	    twist_overhang_offset_shape.inputs[0].hide = True
	    #Factor
	    twist_overhang_offset_shape.inputs[0].default_value = 1.0
	
	    #node Spline Parameter.001
	    spline_parameter_001 = twist.nodes.new("GeometryNodeSplineParameter")
	    spline_parameter_001.name = "Spline Parameter.001"
	    spline_parameter_001.outputs[1].hide = True
	    spline_parameter_001.outputs[2].hide = True
	
	    #node Math.001
	    math_001 = twist.nodes.new("ShaderNodeMath")
	    math_001.name = "Math.001"
	    math_001.hide = True
	    math_001.operation = 'SUBTRACT'
	    math_001.use_clamp = False
	    math_001.inputs[0].hide = True
	    math_001.inputs[2].hide = True
	    #Value
	    math_001.inputs[0].default_value = 1.0
	
	    #node Set Position.002
	    set_position_002 = twist.nodes.new("GeometryNodeSetPosition")
	    set_position_002.name = "Set Position.002"
	    set_position_002.inputs[1].hide = True
	    set_position_002.inputs[2].hide = True
	    #Selection
	    set_position_002.inputs[1].default_value = True
	    #Position
	    set_position_002.inputs[2].default_value = (0.0, 0.0, 0.0)
	
	    #node Combine XYZ.002
	    combine_xyz_002 = twist.nodes.new("ShaderNodeCombineXYZ")
	    combine_xyz_002.name = "Combine XYZ.002"
	    combine_xyz_002.hide = True
	    combine_xyz_002.inputs[1].hide = True
	    combine_xyz_002.inputs[2].hide = True
	    #Y
	    combine_xyz_002.inputs[1].default_value = 0.0
	    #Z
	    combine_xyz_002.inputs[2].default_value = 0.0
	
	    #node Position.001
	    position_001 = twist.nodes.new("GeometryNodeInputPosition")
	    position_001.name = "Position.001"
	
	    #node Combine XYZ.003
	    combine_xyz_003 = twist.nodes.new("ShaderNodeCombineXYZ")
	    combine_xyz_003.name = "Combine XYZ.003"
	    combine_xyz_003.hide = True
	
	    #node Separate XYZ.001
	    separate_xyz_001 = twist.nodes.new("ShaderNodeSeparateXYZ")
	    separate_xyz_001.name = "Separate XYZ.001"
	    separate_xyz_001.hide = True
	
	    #node Math.002
	    math_002 = twist.nodes.new("ShaderNodeMath")
	    math_002.name = "Math.002"
	    math_002.hide = True
	    math_002.operation = 'MULTIPLY'
	    math_002.use_clamp = False
	    math_002.inputs[1].hide = True
	    math_002.inputs[2].hide = True
	    #Value_001
	    math_002.inputs[1].default_value = -1.0
	
	    #node Set Position.003
	    set_position_003 = twist.nodes.new("GeometryNodeSetPosition")
	    set_position_003.name = "Set Position.003"
	    set_position_003.hide = True
	    set_position_003.inputs[1].hide = True
	    set_position_003.inputs[3].hide = True
	    #Selection
	    set_position_003.inputs[1].default_value = True
	    #Offset
	    set_position_003.inputs[3].default_value = (0.0, 0.0, 0.0)
	
	    #node Endpoint Selection
	    endpoint_selection = twist.nodes.new("GeometryNodeCurveEndpointSelection")
	    endpoint_selection.name = "Endpoint Selection"
	    endpoint_selection.inputs[0].hide = True
	    endpoint_selection.inputs[1].hide = True
	    #Start Size
	    endpoint_selection.inputs[0].default_value = 1
	    #End Size
	    endpoint_selection.inputs[1].default_value = 0
	
	    #node Boolean Math
	    boolean_math = twist.nodes.new("FunctionNodeBooleanMath")
	    boolean_math.name = "Boolean Math"
	    boolean_math.hide = True
	    boolean_math.operation = 'NOT'
	    boolean_math.inputs[1].hide = True
	
	    #node Join Geometry
	    join_geometry = twist.nodes.new("GeometryNodeJoinGeometry")
	    join_geometry.name = "Join Geometry"
	    join_geometry.hide = True
	
	    #node Curve to Mesh
	    curve_to_mesh = twist.nodes.new("GeometryNodeCurveToMesh")
	    curve_to_mesh.name = "Curve to Mesh"
	    curve_to_mesh.hide = True
	    curve_to_mesh.inputs[1].hide = True
	    curve_to_mesh.inputs[2].hide = True
	    #Fill Caps
	    curve_to_mesh.inputs[2].default_value = False
	
	    #node Merge by Distance
	    merge_by_distance = twist.nodes.new("GeometryNodeMergeByDistance")
	    merge_by_distance.name = "Merge by Distance"
	    merge_by_distance.hide = True
	    merge_by_distance.mode = 'ALL'
	    merge_by_distance.inputs[1].hide = True
	    merge_by_distance.inputs[2].hide = True
	    #Selection
	    merge_by_distance.inputs[1].default_value = True
	    #Distance
	    merge_by_distance.inputs[2].default_value = 0.0010000000474974513
	
	    #node Mesh to Curve
	    mesh_to_curve = twist.nodes.new("GeometryNodeMeshToCurve")
	    mesh_to_curve.name = "Mesh to Curve"
	    mesh_to_curve.hide = True
	    mesh_to_curve.inputs[1].hide = True
	    #Selection
	    mesh_to_curve.inputs[1].default_value = True
	
	    #node Resample Curve
	    resample_curve = twist.nodes.new("GeometryNodeResampleCurve")
	    resample_curve.name = "Resample Curve"
	    resample_curve.keep_last_segment = True
	    resample_curve.mode = 'COUNT'
	    resample_curve.inputs[1].hide = True
	    resample_curve.inputs[3].hide = True
	    #Selection
	    resample_curve.inputs[1].default_value = True
	
	    #node Set Position.004
	    set_position_004 = twist.nodes.new("GeometryNodeSetPosition")
	    set_position_004.name = "Set Position.004"
	    set_position_004.inputs[2].hide = True
	    #Position
	    set_position_004.inputs[2].default_value = (0.0, 0.0, 0.0)
	
	    #node Twist Separation Offset Shape
	    twist_separation_offset_shape = twist.nodes.new("ShaderNodeFloatCurve")
	    twist_separation_offset_shape.label = "Twist Separation Offset Shape"
	    twist_separation_offset_shape.name = "Twist Separation Offset Shape"
	    #mapping settings
	    twist_separation_offset_shape.mapping.extend = 'EXTRAPOLATED'
	    twist_separation_offset_shape.mapping.tone = 'STANDARD'
	    twist_separation_offset_shape.mapping.black_level = (0.0, 0.0, 0.0)
	    twist_separation_offset_shape.mapping.white_level = (1.0, 1.0, 1.0)
	    twist_separation_offset_shape.mapping.clip_min_x = 0.0
	    twist_separation_offset_shape.mapping.clip_min_y = 0.0
	    twist_separation_offset_shape.mapping.clip_max_x = 1.0
	    twist_separation_offset_shape.mapping.clip_max_y = 1.0
	    twist_separation_offset_shape.mapping.use_clip = True
	    #curve 0
	    twist_separation_offset_shape_curve_0 = twist_separation_offset_shape.mapping.curves[0]
	    twist_separation_offset_shape_curve_0_point_0 = twist_separation_offset_shape_curve_0.points[0]
	    twist_separation_offset_shape_curve_0_point_0.location = (0.0, 0.5)
	    twist_separation_offset_shape_curve_0_point_0.handle_type = 'AUTO'
	    twist_separation_offset_shape_curve_0_point_1 = twist_separation_offset_shape_curve_0.points[1]
	    twist_separation_offset_shape_curve_0_point_1.location = (0.3590909242630005, 0.5625003576278687)
	    twist_separation_offset_shape_curve_0_point_1.handle_type = 'AUTO'
	    twist_separation_offset_shape_curve_0_point_2 = twist_separation_offset_shape_curve_0.points.new(0.8090907335281372, 0.537499725818634)
	    twist_separation_offset_shape_curve_0_point_2.handle_type = 'AUTO'
	    twist_separation_offset_shape_curve_0_point_3 = twist_separation_offset_shape_curve_0.points.new(1.0, 0.3937495946884155)
	    twist_separation_offset_shape_curve_0_point_3.handle_type = 'AUTO'
	    #update curve after changes
	    twist_separation_offset_shape.mapping.update()
	    twist_separation_offset_shape.inputs[0].hide = True
	    #Factor
	    twist_separation_offset_shape.inputs[0].default_value = 1.0
	
	    #node Spline Parameter.002
	    spline_parameter_002 = twist.nodes.new("GeometryNodeSplineParameter")
	    spline_parameter_002.name = "Spline Parameter.002"
	    spline_parameter_002.outputs[1].hide = True
	    spline_parameter_002.outputs[2].hide = True
	
	    #node Combine XYZ.004
	    combine_xyz_004 = twist.nodes.new("ShaderNodeCombineXYZ")
	    combine_xyz_004.name = "Combine XYZ.004"
	    combine_xyz_004.hide = True
	    combine_xyz_004.inputs[0].hide = True
	    combine_xyz_004.inputs[1].hide = True
	    #X
	    combine_xyz_004.inputs[0].default_value = 0.0
	    #Y
	    combine_xyz_004.inputs[1].default_value = 0.0
	
	    #node Map Range
	    map_range = twist.nodes.new("ShaderNodeMapRange")
	    map_range.name = "Map Range"
	    map_range.hide = True
	    map_range.clamp = True
	    map_range.data_type = 'FLOAT'
	    map_range.interpolation_type = 'LINEAR'
	    map_range.inputs[1].hide = True
	    map_range.inputs[2].hide = True
	    map_range.inputs[5].hide = True
	    map_range.inputs[6].hide = True
	    map_range.inputs[7].hide = True
	    map_range.inputs[8].hide = True
	    map_range.inputs[9].hide = True
	    map_range.inputs[10].hide = True
	    map_range.inputs[11].hide = True
	    map_range.outputs[1].hide = True
	    #From Min
	    map_range.inputs[1].default_value = 0.0
	    #From Max
	    map_range.inputs[2].default_value = 1.0
	
	    #node Math.003
	    math_003 = twist.nodes.new("ShaderNodeMath")
	    math_003.name = "Math.003"
	    math_003.hide = True
	    math_003.operation = 'MULTIPLY'
	    math_003.use_clamp = False
	    math_003.inputs[1].hide = True
	    math_003.inputs[2].hide = True
	    #Value_001
	    math_003.inputs[1].default_value = -1.0
	
	    #node Group Input.001
	    group_input_001 = twist.nodes.new("NodeGroupInput")
	    group_input_001.name = "Group Input.001"
	    group_input_001.outputs[1].hide = True
	    group_input_001.outputs[2].hide = True
	    group_input_001.outputs[3].hide = True
	    group_input_001.outputs[4].hide = True
	
	    #node Transform Geometry
	    transform_geometry = twist.nodes.new("GeometryNodeTransform")
	    transform_geometry.name = "Transform Geometry"
	    transform_geometry.mode = 'COMPONENTS'
	    transform_geometry.inputs[1].hide = True
	    transform_geometry.inputs[3].hide = True
	    transform_geometry.inputs[4].hide = True
	    #Translation
	    transform_geometry.inputs[1].default_value = (0.0, 0.0, 0.0)
	    #Scale
	    transform_geometry.inputs[3].default_value = (0.5, 0.5, 0.5)
	
	    #node Combine XYZ.005
	    combine_xyz_005 = twist.nodes.new("ShaderNodeCombineXYZ")
	    combine_xyz_005.name = "Combine XYZ.005"
	    combine_xyz_005.hide = True
	    combine_xyz_005.inputs[1].hide = True
	    combine_xyz_005.inputs[2].hide = True
	    #Y
	    combine_xyz_005.inputs[1].default_value = 0.0
	    #Z
	    combine_xyz_005.inputs[2].default_value = 0.0
	
	    #node Endpoint Selection.001
	    endpoint_selection_001 = twist.nodes.new("GeometryNodeCurveEndpointSelection")
	    endpoint_selection_001.name = "Endpoint Selection.001"
	    endpoint_selection_001.inputs[0].hide = True
	    endpoint_selection_001.inputs[1].hide = True
	    #Start Size
	    endpoint_selection_001.inputs[0].default_value = 0
	    #End Size
	    endpoint_selection_001.inputs[1].default_value = 0
	
	    #node Boolean Math.001
	    boolean_math_001 = twist.nodes.new("FunctionNodeBooleanMath")
	    boolean_math_001.name = "Boolean Math.001"
	    boolean_math_001.hide = True
	    boolean_math_001.operation = 'NOT'
	    boolean_math_001.inputs[1].hide = True
	
	    #node Transform Geometry.001
	    transform_geometry_001 = twist.nodes.new("GeometryNodeTransform")
	    transform_geometry_001.name = "Transform Geometry.001"
	    transform_geometry_001.mode = 'COMPONENTS'
	    transform_geometry_001.inputs[1].hide = True
	    transform_geometry_001.inputs[2].hide = True
	    transform_geometry_001.inputs[4].hide = True
	    #Translation
	    transform_geometry_001.inputs[1].default_value = (0.0, 0.0, 0.0)
	    #Rotation
	    transform_geometry_001.inputs[2].default_value = (0.0, 0.0, 0.0)
	
	    #node Group Input.002
	    group_input_002 = twist.nodes.new("NodeGroupInput")
	    group_input_002.name = "Group Input.002"
	    group_input_002.outputs[0].hide = True
	    group_input_002.outputs[1].hide = True
	    group_input_002.outputs[2].hide = True
	    group_input_002.outputs[4].hide = True
	
	    #node Twist Bake
	    twist_bake = twist.nodes.new("GeometryNodeBake")
	    twist_bake.label = "Twist Bake"
	    twist_bake.name = "Twist Bake"
	    twist_bake.active_index = 0
	    twist_bake.bake_items.clear()
	    twist_bake.bake_items.new('GEOMETRY', "Geometry")
	    twist_bake.bake_items[0].attribute_domain = 'POINT'
	    twist_bake.inputs[1].hide = True
	    twist_bake.outputs[1].hide = True
	
	    #node Sample Index
	    sample_index = twist.nodes.new("GeometryNodeSampleIndex")
	    sample_index.name = "Sample Index"
	    sample_index.hide = True
	    sample_index.clamp = False
	    sample_index.data_type = 'FLOAT_VECTOR'
	    sample_index.domain = 'POINT'
	    sample_index.inputs[2].hide = True
	    #Index
	    sample_index.inputs[2].default_value = 9
	
	    #node Position.002
	    position_002 = twist.nodes.new("GeometryNodeInputPosition")
	    position_002.name = "Position.002"
	
	    #node Sample Index.001
	    sample_index_001 = twist.nodes.new("GeometryNodeSampleIndex")
	    sample_index_001.name = "Sample Index.001"
	    sample_index_001.hide = True
	    sample_index_001.clamp = False
	    sample_index_001.data_type = 'FLOAT_VECTOR'
	    sample_index_001.domain = 'POINT'
	    sample_index_001.inputs[2].hide = True
	    #Index
	    sample_index_001.inputs[2].default_value = 9
	
	    #node Position.003
	    position_003 = twist.nodes.new("GeometryNodeInputPosition")
	    position_003.name = "Position.003"
	
	    #node Vector Math
	    vector_math = twist.nodes.new("ShaderNodeVectorMath")
	    vector_math.name = "Vector Math"
	    vector_math.hide = True
	    vector_math.operation = 'ADD'
	
	    #node Set Position.005
	    set_position_005 = twist.nodes.new("GeometryNodeSetPosition")
	    set_position_005.name = "Set Position.005"
	    set_position_005.hide = True
	    set_position_005.inputs[1].hide = True
	    set_position_005.inputs[2].hide = True
	    #Selection
	    set_position_005.inputs[1].default_value = True
	    #Position
	    set_position_005.inputs[2].default_value = (0.0, 0.0, 0.0)
	
	    #node Reroute
	    reroute = twist.nodes.new("NodeReroute")
	    reroute.name = "Reroute"
	    reroute.socket_idname = "NodeSocketGeometry"
	
	
	
	
	    #Set locations
	    group_output.location = (633.7520751953125, 39.2705192565918)
	    group_input.location = (-120.92694091796875, -285.1476745605469)
	    spiral.location = (-1585.30126953125, -79.4180908203125)
	    reverse_curve.location = (-1051.619384765625, -62.907798767089844)
	    set_position.location = (-1413.0087890625, -54.379241943359375)
	    position.location = (-1417.357421875, -227.35400390625)
	    combine_xyz.location = (-1414.626953125, -163.56655883789062)
	    separate_xyz.location = (-1415.8521728515625, -197.9095458984375)
	    set_position_001.location = (-1231.619384765625, -55.74694061279297)
	    twist_stem_offset_shape.location = (-1233.237548828125, -217.30233764648438)
	    spline_parameter.location = (-1239.115478515625, -545.1759033203125)
	    combine_xyz_001.location = (-1233.082763671875, -184.82571411132812)
	    math.location = (-1236.084716796875, -515.4725952148438)
	    duplicate_elements.location = (-1231.55029296875, 71.37326049804688)
	    twist_overhang_offset_shape.location = (-1150.8916015625, 386.68695068359375)
	    spline_parameter_001.location = (-1321.7974853515625, 183.46002197265625)
	    math_001.location = (-1317.0582275390625, 122.35502624511719)
	    set_position_002.location = (-1050.8184814453125, 56.58488464355469)
	    combine_xyz_002.location = (-1052.5067138671875, 86.72793579101562)
	    position_001.location = (-877.2251586914062, 233.80291748046875)
	    combine_xyz_003.location = (-875.9872436523438, 104.97087860107422)
	    separate_xyz_001.location = (-877.1243896484375, 174.66375732421875)
	    math_002.location = (-875.6507568359375, 139.516357421875)
	    set_position_003.location = (-877.1929931640625, 58.355712890625)
	    endpoint_selection.location = (-120.63607788085938, 49.06641387939453)
	    boolean_math.location = (-121.60287475585938, -9.902364730834961)
	    join_geometry.location = (-497.8161926269531, -6.703788757324219)
	    curve_to_mesh.location = (-499.3544006347656, -57.15467834472656)
	    merge_by_distance.location = (-500.7768859863281, -108.33099365234375)
	    mesh_to_curve.location = (-502.1993713378906, -158.49134826660156)
	    resample_curve.location = (-318.0685119628906, -84.28378295898438)
	    set_position_004.location = (-121.37966918945312, -58.98444366455078)
	    twist_separation_offset_shape.location = (-414.7201232910156, -274.26837158203125)
	    spline_parameter_002.location = (-417.6324157714844, -567.2902221679688)
	    combine_xyz_004.location = (-121.08096313476562, -186.7659912109375)
	    map_range.location = (-122.23611450195312, -220.75576782226562)
	    math_003.location = (-121.743408203125, -255.94485473632812)
	    group_input_001.location = (-316.6186218261719, -214.15740966796875)
	    transform_geometry.location = (79.06991577148438, -10.815780639648438)
	    combine_xyz_005.location = (78.6533203125, -142.8201141357422)
	    endpoint_selection_001.location = (-1417.5849609375, -317.205810546875)
	    boolean_math_001.location = (-1415.890869140625, -286.98394775390625)
	    transform_geometry_001.location = (275.2121276855469, 38.27008056640625)
	    group_input_002.location = (79.96328735351562, -177.15878295898438)
	    twist_bake.location = (459.6880187988281, 85.2494888305664)
	    sample_index.location = (-687.2417602539062, 10.000402450561523)
	    position_002.location = (-688.7094116210938, -19.448816299438477)
	    sample_index_001.location = (-689.9703979492188, -126.93573760986328)
	    position_003.location = (-691.4380493164062, -156.38497924804688)
	    vector_math.location = (-687.39501953125, -76.69742584228516)
	    set_position_005.location = (-685.635498046875, 58.355712890625)
	    reroute.location = (-810.03662109375, -98.93850708007812)
	
	    #Set dimensions
	    group_output.width, group_output.height = 140.0, 100.0
	    group_input.width, group_input.height = 140.0, 100.0
	    spiral.width, spiral.height = 140.0, 100.0
	    reverse_curve.width, reverse_curve.height = 140.0, 100.0
	    set_position.width, set_position.height = 140.0, 100.0
	    position.width, position.height = 140.0, 100.0
	    combine_xyz.width, combine_xyz.height = 140.0, 100.0
	    separate_xyz.width, separate_xyz.height = 140.0, 100.0
	    set_position_001.width, set_position_001.height = 140.0, 100.0
	    twist_stem_offset_shape.width, twist_stem_offset_shape.height = 240.0, 100.0
	    spline_parameter.width, spline_parameter.height = 140.0, 100.0
	    combine_xyz_001.width, combine_xyz_001.height = 140.0, 100.0
	    math.width, math.height = 140.0, 100.0
	    duplicate_elements.width, duplicate_elements.height = 140.0, 100.0
	    twist_overhang_offset_shape.width, twist_overhang_offset_shape.height = 240.0, 100.0
	    spline_parameter_001.width, spline_parameter_001.height = 140.0, 100.0
	    math_001.width, math_001.height = 140.0, 100.0
	    set_position_002.width, set_position_002.height = 140.0, 100.0
	    combine_xyz_002.width, combine_xyz_002.height = 140.0, 100.0
	    position_001.width, position_001.height = 140.0, 100.0
	    combine_xyz_003.width, combine_xyz_003.height = 140.0, 100.0
	    separate_xyz_001.width, separate_xyz_001.height = 140.0, 100.0
	    math_002.width, math_002.height = 140.0, 100.0
	    set_position_003.width, set_position_003.height = 140.0, 100.0
	    endpoint_selection.width, endpoint_selection.height = 140.0, 100.0
	    boolean_math.width, boolean_math.height = 140.0, 100.0
	    join_geometry.width, join_geometry.height = 140.0, 100.0
	    curve_to_mesh.width, curve_to_mesh.height = 140.0, 100.0
	    merge_by_distance.width, merge_by_distance.height = 140.0, 100.0
	    mesh_to_curve.width, mesh_to_curve.height = 140.0, 100.0
	    resample_curve.width, resample_curve.height = 140.0, 100.0
	    set_position_004.width, set_position_004.height = 140.0, 100.0
	    twist_separation_offset_shape.width, twist_separation_offset_shape.height = 240.0, 100.0
	    spline_parameter_002.width, spline_parameter_002.height = 140.0, 100.0
	    combine_xyz_004.width, combine_xyz_004.height = 140.0, 100.0
	    map_range.width, map_range.height = 140.0, 100.0
	    math_003.width, math_003.height = 140.0, 100.0
	    group_input_001.width, group_input_001.height = 140.0, 100.0
	    transform_geometry.width, transform_geometry.height = 140.0, 100.0
	    combine_xyz_005.width, combine_xyz_005.height = 140.0, 100.0
	    endpoint_selection_001.width, endpoint_selection_001.height = 140.0, 100.0
	    boolean_math_001.width, boolean_math_001.height = 140.0, 100.0
	    transform_geometry_001.width, transform_geometry_001.height = 140.0, 100.0
	    group_input_002.width, group_input_002.height = 140.0, 100.0
	    twist_bake.width, twist_bake.height = 140.0, 100.0
	    sample_index.width, sample_index.height = 140.0, 100.0
	    position_002.width, position_002.height = 140.0, 100.0
	    sample_index_001.width, sample_index_001.height = 140.0, 100.0
	    position_003.width, position_003.height = 140.0, 100.0
	    vector_math.width, vector_math.height = 140.0, 100.0
	    set_position_005.width, set_position_005.height = 140.0, 100.0
	    reroute.width, reroute.height = 10.0, 100.0
	
	    #initialize twist links
	    #set_position_001.Geometry -> reverse_curve.Curve
	    twist.links.new(set_position_001.outputs[0], reverse_curve.inputs[0])
	    #math_003.Value -> map_range.To Min
	    twist.links.new(math_003.outputs[0], map_range.inputs[3])
	    #group_input.Offset Scale -> math_003.Value
	    twist.links.new(group_input.outputs[1], math_003.inputs[0])
	    #endpoint_selection.Selection -> boolean_math.Boolean
	    twist.links.new(endpoint_selection.outputs[0], boolean_math.inputs[0])
	    #mesh_to_curve.Curve -> resample_curve.Curve
	    twist.links.new(mesh_to_curve.outputs[0], resample_curve.inputs[0])
	    #separate_xyz.X -> combine_xyz.Y
	    twist.links.new(separate_xyz.outputs[0], combine_xyz.inputs[1])
	    #separate_xyz.Z -> combine_xyz.Z
	    twist.links.new(separate_xyz.outputs[2], combine_xyz.inputs[2])
	    #set_position.Geometry -> set_position_001.Geometry
	    twist.links.new(set_position.outputs[0], set_position_001.inputs[0])
	    #boolean_math.Boolean -> set_position_004.Selection
	    twist.links.new(boolean_math.outputs[0], set_position_004.inputs[1])
	    #combine_xyz_002.Vector -> set_position_002.Offset
	    twist.links.new(combine_xyz_002.outputs[0], set_position_002.inputs[3])
	    #resample_curve.Curve -> set_position_004.Geometry
	    twist.links.new(resample_curve.outputs[0], set_position_004.inputs[0])
	    #combine_xyz_003.Vector -> set_position_003.Position
	    twist.links.new(combine_xyz_003.outputs[0], set_position_003.inputs[2])
	    #position.Position -> separate_xyz.Vector
	    twist.links.new(position.outputs[0], separate_xyz.inputs[0])
	    #map_range.Result -> combine_xyz_004.Z
	    twist.links.new(map_range.outputs[0], combine_xyz_004.inputs[2])
	    #separate_xyz.Y -> combine_xyz.X
	    twist.links.new(separate_xyz.outputs[1], combine_xyz.inputs[0])
	    #twist_separation_offset_shape.Value -> map_range.Value
	    twist.links.new(twist_separation_offset_shape.outputs[0], map_range.inputs[0])
	    #math.Value -> twist_stem_offset_shape.Value
	    twist.links.new(math.outputs[0], twist_stem_offset_shape.inputs[1])
	    #math_001.Value -> twist_overhang_offset_shape.Value
	    twist.links.new(math_001.outputs[0], twist_overhang_offset_shape.inputs[1])
	    #spline_parameter.Factor -> math.Value
	    twist.links.new(spline_parameter.outputs[0], math.inputs[1])
	    #set_position_002.Geometry -> set_position_003.Geometry
	    twist.links.new(set_position_002.outputs[0], set_position_003.inputs[0])
	    #set_position.Geometry -> duplicate_elements.Geometry
	    twist.links.new(set_position.outputs[0], duplicate_elements.inputs[0])
	    #group_input.Offset Scale -> map_range.To Max
	    twist.links.new(group_input.outputs[1], map_range.inputs[4])
	    #spline_parameter_001.Factor -> math_001.Value
	    twist.links.new(spline_parameter_001.outputs[0], math_001.inputs[1])
	    #twist_overhang_offset_shape.Value -> combine_xyz_002.X
	    twist.links.new(twist_overhang_offset_shape.outputs[0], combine_xyz_002.inputs[0])
	    #set_position_005.Geometry -> join_geometry.Geometry
	    twist.links.new(set_position_005.outputs[0], join_geometry.inputs[0])
	    #merge_by_distance.Geometry -> mesh_to_curve.Mesh
	    twist.links.new(merge_by_distance.outputs[0], mesh_to_curve.inputs[0])
	    #twist_stem_offset_shape.Value -> combine_xyz_001.X
	    twist.links.new(twist_stem_offset_shape.outputs[0], combine_xyz_001.inputs[0])
	    #curve_to_mesh.Mesh -> merge_by_distance.Geometry
	    twist.links.new(curve_to_mesh.outputs[0], merge_by_distance.inputs[0])
	    #spline_parameter_002.Factor -> twist_separation_offset_shape.Value
	    twist.links.new(spline_parameter_002.outputs[0], twist_separation_offset_shape.inputs[1])
	    #separate_xyz_001.X -> combine_xyz_003.X
	    twist.links.new(separate_xyz_001.outputs[0], combine_xyz_003.inputs[0])
	    #combine_xyz_004.Vector -> set_position_004.Offset
	    twist.links.new(combine_xyz_004.outputs[0], set_position_004.inputs[3])
	    #spiral.Curve -> set_position.Geometry
	    twist.links.new(spiral.outputs[0], set_position.inputs[0])
	    #duplicate_elements.Geometry -> set_position_002.Geometry
	    twist.links.new(duplicate_elements.outputs[0], set_position_002.inputs[0])
	    #combine_xyz_001.Vector -> set_position_001.Offset
	    twist.links.new(combine_xyz_001.outputs[0], set_position_001.inputs[3])
	    #math_002.Value -> combine_xyz_003.Y
	    twist.links.new(math_002.outputs[0], combine_xyz_003.inputs[1])
	    #combine_xyz.Vector -> set_position.Position
	    twist.links.new(combine_xyz.outputs[0], set_position.inputs[2])
	    #separate_xyz_001.Y -> math_002.Value
	    twist.links.new(separate_xyz_001.outputs[1], math_002.inputs[0])
	    #separate_xyz_001.Z -> combine_xyz_003.Z
	    twist.links.new(separate_xyz_001.outputs[2], combine_xyz_003.inputs[2])
	    #join_geometry.Geometry -> curve_to_mesh.Curve
	    twist.links.new(join_geometry.outputs[0], curve_to_mesh.inputs[0])
	    #position_001.Position -> separate_xyz_001.Vector
	    twist.links.new(position_001.outputs[0], separate_xyz_001.inputs[0])
	    #twist_bake.Geometry -> group_output.Geometry
	    twist.links.new(twist_bake.outputs[0], group_output.inputs[0])
	    #group_input_001.Control Points -> resample_curve.Count
	    twist.links.new(group_input_001.outputs[0], resample_curve.inputs[2])
	    #set_position_004.Geometry -> transform_geometry.Geometry
	    twist.links.new(set_position_004.outputs[0], transform_geometry.inputs[0])
	    #combine_xyz_005.Vector -> transform_geometry.Rotation
	    twist.links.new(combine_xyz_005.outputs[0], transform_geometry.inputs[2])
	    #group_input.Rotate -> combine_xyz_005.X
	    twist.links.new(group_input.outputs[2], combine_xyz_005.inputs[0])
	    #endpoint_selection_001.Selection -> boolean_math_001.Boolean
	    twist.links.new(endpoint_selection_001.outputs[0], boolean_math_001.inputs[0])
	    #boolean_math_001.Boolean -> set_position_001.Selection
	    twist.links.new(boolean_math_001.outputs[0], set_position_001.inputs[1])
	    #transform_geometry.Geometry -> transform_geometry_001.Geometry
	    twist.links.new(transform_geometry.outputs[0], transform_geometry_001.inputs[0])
	    #group_input_002.Scale -> transform_geometry_001.Scale
	    twist.links.new(group_input_002.outputs[3], transform_geometry_001.inputs[3])
	    #transform_geometry_001.Geometry -> twist_bake.Geometry
	    twist.links.new(transform_geometry_001.outputs[0], twist_bake.inputs[0])
	    #reroute.Output -> sample_index.Geometry
	    twist.links.new(reroute.outputs[0], sample_index.inputs[0])
	    #position_002.Position -> sample_index.Value
	    twist.links.new(position_002.outputs[0], sample_index.inputs[1])
	    #position_003.Position -> sample_index_001.Value
	    twist.links.new(position_003.outputs[0], sample_index_001.inputs[1])
	    #set_position_003.Geometry -> sample_index_001.Geometry
	    twist.links.new(set_position_003.outputs[0], sample_index_001.inputs[0])
	    #sample_index.Value -> vector_math.Vector
	    twist.links.new(sample_index.outputs[0], vector_math.inputs[0])
	    #sample_index_001.Value -> vector_math.Vector
	    twist.links.new(sample_index_001.outputs[0], vector_math.inputs[1])
	    #set_position_003.Geometry -> set_position_005.Geometry
	    twist.links.new(set_position_003.outputs[0], set_position_005.inputs[0])
	    #vector_math.Vector -> set_position_005.Offset
	    twist.links.new(vector_math.outputs[0], set_position_005.inputs[3])
	    #reverse_curve.Curve -> reroute.Input
	    twist.links.new(reverse_curve.outputs[0], reroute.inputs[0])
	    #reroute.Output -> join_geometry.Geometry
	    twist.links.new(reroute.outputs[0], join_geometry.inputs[0])
	    return twist
	
	twist = twist_node_group()
	
	#initialize curve_root node group
	def curve_root_node_group():
	    curve_root = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Curve Root")
	
	    curve_root.color_tag = 'INPUT'
	    curve_root.description = "Reads information about each curve's root point"
	    curve_root.default_group_node_width = 140
	    
	
	
	    #curve_root interface
	    #Socket Root Selection
	    root_selection_socket = curve_root.interface.new_socket(name = "Root Selection", in_out='OUTPUT', socket_type = 'NodeSocketBool')
	    root_selection_socket.default_value = False
	    root_selection_socket.attribute_domain = 'POINT'
	    root_selection_socket.description = "Boolean selection of curve root points"
	
	    #Socket Root Position
	    root_position_socket = curve_root.interface.new_socket(name = "Root Position", in_out='OUTPUT', socket_type = 'NodeSocketVector')
	    root_position_socket.default_value = (0.0, 0.0, 0.0)
	    root_position_socket.min_value = -3.4028234663852886e+38
	    root_position_socket.max_value = 3.4028234663852886e+38
	    root_position_socket.subtype = 'NONE'
	    root_position_socket.attribute_domain = 'CURVE'
	    root_position_socket.description = "Position of the root point of a curve"
	
	    #Socket Root Direction
	    root_direction_socket = curve_root.interface.new_socket(name = "Root Direction", in_out='OUTPUT', socket_type = 'NodeSocketVector')
	    root_direction_socket.default_value = (0.0, 0.0, 0.0)
	    root_direction_socket.min_value = -3.4028234663852886e+38
	    root_direction_socket.max_value = 3.4028234663852886e+38
	    root_direction_socket.subtype = 'NONE'
	    root_direction_socket.attribute_domain = 'CURVE'
	    root_direction_socket.description = "Direction of the root segment of a curve"
	
	    #Socket Root Index
	    root_index_socket = curve_root.interface.new_socket(name = "Root Index", in_out='OUTPUT', socket_type = 'NodeSocketInt')
	    root_index_socket.default_value = 0
	    root_index_socket.min_value = -2147483648
	    root_index_socket.max_value = 2147483647
	    root_index_socket.subtype = 'NONE'
	    root_index_socket.attribute_domain = 'CURVE'
	    root_index_socket.description = "Index of the root point of a curve"
	
	
	    #initialize curve_root nodes
	    #node Position.002
	    position_002_1 = curve_root.nodes.new("GeometryNodeInputPosition")
	    position_002_1.name = "Position.002"
	
	    #node Interpolate Domain
	    interpolate_domain = curve_root.nodes.new("GeometryNodeFieldOnDomain")
	    interpolate_domain.name = "Interpolate Domain"
	    interpolate_domain.data_type = 'INT'
	    interpolate_domain.domain = 'CURVE'
	
	    #node Field at Index.003
	    field_at_index_003 = curve_root.nodes.new("GeometryNodeFieldAtIndex")
	    field_at_index_003.name = "Field at Index.003"
	    field_at_index_003.data_type = 'FLOAT_VECTOR'
	    field_at_index_003.domain = 'POINT'
	
	    #node Interpolate Domain.001
	    interpolate_domain_001 = curve_root.nodes.new("GeometryNodeFieldOnDomain")
	    interpolate_domain_001.name = "Interpolate Domain.001"
	    interpolate_domain_001.data_type = 'FLOAT_VECTOR'
	    interpolate_domain_001.domain = 'CURVE'
	
	    #node Curve Tangent
	    curve_tangent = curve_root.nodes.new("GeometryNodeInputTangent")
	    curve_tangent.name = "Curve Tangent"
	
	    #node Endpoint Selection
	    endpoint_selection_1 = curve_root.nodes.new("GeometryNodeCurveEndpointSelection")
	    endpoint_selection_1.name = "Endpoint Selection"
	    #Start Size
	    endpoint_selection_1.inputs[0].default_value = 1
	    #End Size
	    endpoint_selection_1.inputs[1].default_value = 0
	
	    #node Field at Index.004
	    field_at_index_004 = curve_root.nodes.new("GeometryNodeFieldAtIndex")
	    field_at_index_004.name = "Field at Index.004"
	    field_at_index_004.data_type = 'FLOAT_VECTOR'
	    field_at_index_004.domain = 'POINT'
	
	    #node Interpolate Domain.002
	    interpolate_domain_002 = curve_root.nodes.new("GeometryNodeFieldOnDomain")
	    interpolate_domain_002.name = "Interpolate Domain.002"
	    interpolate_domain_002.data_type = 'FLOAT_VECTOR'
	    interpolate_domain_002.domain = 'CURVE'
	
	    #node Group Output
	    group_output_1 = curve_root.nodes.new("NodeGroupOutput")
	    group_output_1.name = "Group Output"
	    group_output_1.is_active_output = True
	
	    #node Points of Curve
	    points_of_curve = curve_root.nodes.new("GeometryNodePointsOfCurve")
	    points_of_curve.name = "Points of Curve"
	    points_of_curve.inputs[0].hide = True
	    points_of_curve.inputs[1].hide = True
	    points_of_curve.outputs[1].hide = True
	    #Curve Index
	    points_of_curve.inputs[0].default_value = 0
	    #Weights
	    points_of_curve.inputs[1].default_value = 0.0
	    #Sort Index
	    points_of_curve.inputs[2].default_value = 0
	
	
	
	
	
	    #Set locations
	    position_002_1.location = (-608.1627807617188, -70.55814361572266)
	    interpolate_domain.location = (-608.1627807617188, 90.18604278564453)
	    field_at_index_003.location = (-407.2325439453125, 70.09302520751953)
	    interpolate_domain_001.location = (-206.30230712890625, 70.09302520751953)
	    curve_tangent.location = (-608.1627807617188, -271.4883728027344)
	    endpoint_selection_1.location = (-206.30230712890625, 190.65118408203125)
	    field_at_index_004.location = (-407.2325439453125, -130.83721923828125)
	    interpolate_domain_002.location = (-206.30230712890625, -130.83721923828125)
	    group_output_1.location = (75.0, 50.0)
	    points_of_curve.location = (-789.0, 50.0)
	
	    #Set dimensions
	    position_002_1.width, position_002_1.height = 140.0, 100.0
	    interpolate_domain.width, interpolate_domain.height = 140.0, 100.0
	    field_at_index_003.width, field_at_index_003.height = 140.0, 100.0
	    interpolate_domain_001.width, interpolate_domain_001.height = 140.0, 100.0
	    curve_tangent.width, curve_tangent.height = 140.0, 100.0
	    endpoint_selection_1.width, endpoint_selection_1.height = 140.0, 100.0
	    field_at_index_004.width, field_at_index_004.height = 140.0, 100.0
	    interpolate_domain_002.width, interpolate_domain_002.height = 140.0, 100.0
	    group_output_1.width, group_output_1.height = 140.0, 100.0
	    points_of_curve.width, points_of_curve.height = 140.0, 100.0
	
	    #initialize curve_root links
	    #position_002_1.Position -> field_at_index_003.Value
	    curve_root.links.new(position_002_1.outputs[0], field_at_index_003.inputs[1])
	    #interpolate_domain_001.Value -> group_output_1.Root Position
	    curve_root.links.new(interpolate_domain_001.outputs[0], group_output_1.inputs[1])
	    #interpolate_domain.Value -> field_at_index_003.Index
	    curve_root.links.new(interpolate_domain.outputs[0], field_at_index_003.inputs[0])
	    #points_of_curve.Point Index -> interpolate_domain.Value
	    curve_root.links.new(points_of_curve.outputs[0], interpolate_domain.inputs[0])
	    #interpolate_domain.Value -> group_output_1.Root Index
	    curve_root.links.new(interpolate_domain.outputs[0], group_output_1.inputs[3])
	    #endpoint_selection_1.Selection -> group_output_1.Root Selection
	    curve_root.links.new(endpoint_selection_1.outputs[0], group_output_1.inputs[0])
	    #field_at_index_003.Value -> interpolate_domain_001.Value
	    curve_root.links.new(field_at_index_003.outputs[0], interpolate_domain_001.inputs[0])
	    #interpolate_domain_002.Value -> group_output_1.Root Direction
	    curve_root.links.new(interpolate_domain_002.outputs[0], group_output_1.inputs[2])
	    #interpolate_domain.Value -> field_at_index_004.Index
	    curve_root.links.new(interpolate_domain.outputs[0], field_at_index_004.inputs[0])
	    #curve_tangent.Tangent -> field_at_index_004.Value
	    curve_root.links.new(curve_tangent.outputs[0], field_at_index_004.inputs[1])
	    #field_at_index_004.Value -> interpolate_domain_002.Value
	    curve_root.links.new(field_at_index_004.outputs[0], interpolate_domain_002.inputs[0])
	    return curve_root
	
	curve_root = curve_root_node_group()
	
	#initialize curve_segment node group
	def curve_segment_node_group():
	    curve_segment = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Curve Segment")
	
	    curve_segment.color_tag = 'INPUT'
	    curve_segment.description = "Reads information each point's previous curve segment"
	    curve_segment.default_group_node_width = 140
	    
	
	
	    #curve_segment interface
	    #Socket Segment Length
	    segment_length_socket = curve_segment.interface.new_socket(name = "Segment Length", in_out='OUTPUT', socket_type = 'NodeSocketFloat')
	    segment_length_socket.default_value = 0.0
	    segment_length_socket.min_value = -3.4028234663852886e+38
	    segment_length_socket.max_value = 3.4028234663852886e+38
	    segment_length_socket.subtype = 'NONE'
	    segment_length_socket.attribute_domain = 'POINT'
	    segment_length_socket.description = "Distance to previous point on curve"
	
	    #Socket Segment Direction
	    segment_direction_socket = curve_segment.interface.new_socket(name = "Segment Direction", in_out='OUTPUT', socket_type = 'NodeSocketVector')
	    segment_direction_socket.default_value = (0.0, 0.0, 0.0)
	    segment_direction_socket.min_value = -3.4028234663852886e+38
	    segment_direction_socket.max_value = 3.4028234663852886e+38
	    segment_direction_socket.subtype = 'NONE'
	    segment_direction_socket.attribute_domain = 'POINT'
	    segment_direction_socket.description = "Direction from previous neighboring point on segment"
	
	    #Socket Neighbor Index
	    neighbor_index_socket = curve_segment.interface.new_socket(name = "Neighbor Index", in_out='OUTPUT', socket_type = 'NodeSocketInt')
	    neighbor_index_socket.default_value = 0
	    neighbor_index_socket.min_value = -2147483648
	    neighbor_index_socket.max_value = 2147483647
	    neighbor_index_socket.subtype = 'NONE'
	    neighbor_index_socket.attribute_domain = 'POINT'
	    neighbor_index_socket.description = "Index of previous neighboring point on segment"
	
	
	    #initialize curve_segment nodes
	    #node Vector Math.009
	    vector_math_009 = curve_segment.nodes.new("ShaderNodeVectorMath")
	    vector_math_009.name = "Vector Math.009"
	    vector_math_009.operation = 'NORMALIZE'
	
	    #node Reroute.015
	    reroute_015 = curve_segment.nodes.new("NodeReroute")
	    reroute_015.name = "Reroute.015"
	    reroute_015.socket_idname = "NodeSocketVector"
	    #node Reroute.017
	    reroute_017 = curve_segment.nodes.new("NodeReroute")
	    reroute_017.name = "Reroute.017"
	    reroute_017.socket_idname = "NodeSocketVector"
	    #node Field at Index.001
	    field_at_index_001 = curve_segment.nodes.new("GeometryNodeFieldAtIndex")
	    field_at_index_001.name = "Field at Index.001"
	    field_at_index_001.data_type = 'FLOAT_VECTOR'
	    field_at_index_001.domain = 'POINT'
	
	    #node Vector Math.008
	    vector_math_008 = curve_segment.nodes.new("ShaderNodeVectorMath")
	    vector_math_008.name = "Vector Math.008"
	    vector_math_008.operation = 'SUBTRACT'
	
	    #node Reroute.018
	    reroute_018 = curve_segment.nodes.new("NodeReroute")
	    reroute_018.name = "Reroute.018"
	    reroute_018.socket_idname = "NodeSocketInt"
	    #node Interpolate Domain.002
	    interpolate_domain_002_1 = curve_segment.nodes.new("GeometryNodeFieldOnDomain")
	    interpolate_domain_002_1.name = "Interpolate Domain.002"
	    interpolate_domain_002_1.data_type = 'FLOAT_VECTOR'
	    interpolate_domain_002_1.domain = 'POINT'
	
	    #node Group Output
	    group_output_2 = curve_segment.nodes.new("NodeGroupOutput")
	    group_output_2.name = "Group Output"
	    group_output_2.is_active_output = True
	
	    #node Vector Math.007
	    vector_math_007 = curve_segment.nodes.new("ShaderNodeVectorMath")
	    vector_math_007.name = "Vector Math.007"
	    vector_math_007.operation = 'LENGTH'
	
	    #node Interpolate Domain.003
	    interpolate_domain_003 = curve_segment.nodes.new("GeometryNodeFieldOnDomain")
	    interpolate_domain_003.name = "Interpolate Domain.003"
	    interpolate_domain_003.data_type = 'INT'
	    interpolate_domain_003.domain = 'POINT'
	
	    #node Reroute
	    reroute_1 = curve_segment.nodes.new("NodeReroute")
	    reroute_1.name = "Reroute"
	    reroute_1.socket_idname = "NodeSocketBool"
	    #node Switch.004
	    switch_004 = curve_segment.nodes.new("GeometryNodeSwitch")
	    switch_004.name = "Switch.004"
	    switch_004.hide = True
	    switch_004.input_type = 'VECTOR'
	    #False
	    switch_004.inputs[1].default_value = (0.0, 0.0, 0.0)
	
	    #node Switch.003
	    switch_003 = curve_segment.nodes.new("GeometryNodeSwitch")
	    switch_003.name = "Switch.003"
	    switch_003.hide = True
	    switch_003.input_type = 'FLOAT'
	    #False
	    switch_003.inputs[1].default_value = 0.0
	
	    #node Boolean
	    boolean = curve_segment.nodes.new("FunctionNodeInputBool")
	    boolean.name = "Boolean"
	    boolean.boolean = True
	
	    #node Interpolate Domain
	    interpolate_domain_1 = curve_segment.nodes.new("GeometryNodeFieldOnDomain")
	    interpolate_domain_1.name = "Interpolate Domain"
	    interpolate_domain_1.data_type = 'BOOLEAN'
	    interpolate_domain_1.domain = 'CURVE'
	
	    #node Switch.005
	    switch_005 = curve_segment.nodes.new("GeometryNodeSwitch")
	    switch_005.name = "Switch.005"
	    switch_005.hide = True
	    switch_005.input_type = 'INT'
	    #False
	    switch_005.inputs[1].default_value = 0
	
	    #node Index.002
	    index_002 = curve_segment.nodes.new("GeometryNodeInputIndex")
	    index_002.name = "Index.002"
	
	    #node Switch.001
	    switch_001 = curve_segment.nodes.new("GeometryNodeSwitch")
	    switch_001.name = "Switch.001"
	    switch_001.input_type = 'INT'
	
	    #node Offset Point in Curve
	    offset_point_in_curve = curve_segment.nodes.new("GeometryNodeOffsetPointInCurve")
	    offset_point_in_curve.name = "Offset Point in Curve"
	    #Point Index
	    offset_point_in_curve.inputs[0].default_value = 0
	    #Offset
	    offset_point_in_curve.inputs[1].default_value = -1
	
	    #node Position.002
	    position_002_2 = curve_segment.nodes.new("GeometryNodeInputPosition")
	    position_002_2.name = "Position.002"
	
	
	
	
	
	    #Set locations
	    vector_math_009.location = (-389.8524169921875, 30.443286895751953)
	    reroute_015.location = (-456.8948974609375, 4.604297637939453)
	    reroute_017.location = (-1012.7362060546875, -9.742748260498047)
	    field_at_index_001.location = (-992.6431884765625, 70.62931823730469)
	    vector_math_008.location = (-811.805908203125, 70.62931823730469)
	    reroute_018.location = (-1032.8292236328125, 110.81541442871094)
	    interpolate_domain_002_1.location = (-630.9686279296875, 70.62931823730469)
	    group_output_2.location = (75.0, 50.0)
	    vector_math_007.location = (-389.8524169921875, 151.00144958496094)
	    interpolate_domain_003.location = (-390.85833740234375, -97.25408935546875)
	    reroute_1.location = (-342.979248046875, 193.345458984375)
	    switch_004.location = (-178.8756103515625, 10.35025405883789)
	    switch_003.location = (-178.8756103515625, 90.72234344482422)
	    boolean.location = (-781.6663208007812, 291.652587890625)
	    interpolate_domain_1.location = (-600.8291015625, 311.74560546875)
	    switch_005.location = (-178.8756103515625, -70.0218505859375)
	    index_002.location = (-1404.550048828125, 211.28048706054688)
	    switch_001.location = (-1223.712890625, 231.37350463867188)
	    offset_point_in_curve.location = (-1404.550048828125, 151.0014190673828)
	    position_002_2.location = (-1223.712890625, 30.44327163696289)
	
	    #Set dimensions
	    vector_math_009.width, vector_math_009.height = 140.0, 100.0
	    reroute_015.width, reroute_015.height = 16.0, 100.0
	    reroute_017.width, reroute_017.height = 16.0, 100.0
	    field_at_index_001.width, field_at_index_001.height = 140.0, 100.0
	    vector_math_008.width, vector_math_008.height = 140.0, 100.0
	    reroute_018.width, reroute_018.height = 16.0, 100.0
	    interpolate_domain_002_1.width, interpolate_domain_002_1.height = 140.0, 100.0
	    group_output_2.width, group_output_2.height = 140.0, 100.0
	    vector_math_007.width, vector_math_007.height = 140.0, 100.0
	    interpolate_domain_003.width, interpolate_domain_003.height = 140.0, 100.0
	    reroute_1.width, reroute_1.height = 16.0, 100.0
	    switch_004.width, switch_004.height = 140.0, 100.0
	    switch_003.width, switch_003.height = 140.0, 100.0
	    boolean.width, boolean.height = 140.0, 100.0
	    interpolate_domain_1.width, interpolate_domain_1.height = 140.0, 100.0
	    switch_005.width, switch_005.height = 140.0, 100.0
	    index_002.width, index_002.height = 140.0, 100.0
	    switch_001.width, switch_001.height = 140.0, 100.0
	    offset_point_in_curve.width, offset_point_in_curve.height = 140.0, 100.0
	    position_002_2.width, position_002_2.height = 140.0, 100.0
	
	    #initialize curve_segment links
	    #reroute_015.Output -> vector_math_007.Vector
	    curve_segment.links.new(reroute_015.outputs[0], vector_math_007.inputs[0])
	    #reroute_018.Output -> field_at_index_001.Index
	    curve_segment.links.new(reroute_018.outputs[0], field_at_index_001.inputs[0])
	    #vector_math_008.Vector -> interpolate_domain_002_1.Value
	    curve_segment.links.new(vector_math_008.outputs[0], interpolate_domain_002_1.inputs[0])
	    #reroute_017.Output -> vector_math_008.Vector
	    curve_segment.links.new(reroute_017.outputs[0], vector_math_008.inputs[0])
	    #reroute_015.Output -> vector_math_009.Vector
	    curve_segment.links.new(reroute_015.outputs[0], vector_math_009.inputs[0])
	    #reroute_017.Output -> field_at_index_001.Value
	    curve_segment.links.new(reroute_017.outputs[0], field_at_index_001.inputs[1])
	    #field_at_index_001.Value -> vector_math_008.Vector
	    curve_segment.links.new(field_at_index_001.outputs[0], vector_math_008.inputs[1])
	    #position_002_2.Position -> reroute_017.Input
	    curve_segment.links.new(position_002_2.outputs[0], reroute_017.inputs[0])
	    #interpolate_domain_002_1.Value -> reroute_015.Input
	    curve_segment.links.new(interpolate_domain_002_1.outputs[0], reroute_015.inputs[0])
	    #switch_004.Output -> group_output_2.Segment Direction
	    curve_segment.links.new(switch_004.outputs[0], group_output_2.inputs[1])
	    #switch_005.Output -> group_output_2.Neighbor Index
	    curve_segment.links.new(switch_005.outputs[0], group_output_2.inputs[2])
	    #boolean.Boolean -> interpolate_domain_1.Value
	    curve_segment.links.new(boolean.outputs[0], interpolate_domain_1.inputs[0])
	    #reroute_018.Output -> interpolate_domain_003.Value
	    curve_segment.links.new(reroute_018.outputs[0], interpolate_domain_003.inputs[0])
	    #vector_math_007.Value -> switch_003.True
	    curve_segment.links.new(vector_math_007.outputs[1], switch_003.inputs[2])
	    #reroute_1.Output -> switch_003.Switch
	    curve_segment.links.new(reroute_1.outputs[0], switch_003.inputs[0])
	    #switch_003.Output -> group_output_2.Segment Length
	    curve_segment.links.new(switch_003.outputs[0], group_output_2.inputs[0])
	    #vector_math_009.Vector -> switch_004.True
	    curve_segment.links.new(vector_math_009.outputs[0], switch_004.inputs[2])
	    #interpolate_domain_1.Value -> reroute_1.Input
	    curve_segment.links.new(interpolate_domain_1.outputs[0], reroute_1.inputs[0])
	    #reroute_1.Output -> switch_004.Switch
	    curve_segment.links.new(reroute_1.outputs[0], switch_004.inputs[0])
	    #interpolate_domain_003.Value -> switch_005.True
	    curve_segment.links.new(interpolate_domain_003.outputs[0], switch_005.inputs[2])
	    #reroute_1.Output -> switch_005.Switch
	    curve_segment.links.new(reroute_1.outputs[0], switch_005.inputs[0])
	    #offset_point_in_curve.Is Valid Offset -> switch_001.Switch
	    curve_segment.links.new(offset_point_in_curve.outputs[0], switch_001.inputs[0])
	    #offset_point_in_curve.Point Index -> switch_001.True
	    curve_segment.links.new(offset_point_in_curve.outputs[1], switch_001.inputs[2])
	    #index_002.Index -> switch_001.False
	    curve_segment.links.new(index_002.outputs[0], switch_001.inputs[1])
	    #switch_001.Output -> reroute_018.Input
	    curve_segment.links.new(switch_001.outputs[0], reroute_018.inputs[0])
	    return curve_segment
	
	curve_segment = curve_segment_node_group()
	
	#initialize restore_curve_segment_length node group
	def restore_curve_segment_length_node_group():
	    restore_curve_segment_length = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Restore Curve Segment Length")
	
	    restore_curve_segment_length.color_tag = 'GEOMETRY'
	    restore_curve_segment_length.description = "Restores the length of each curve segment using a previous state after deformation"
	    restore_curve_segment_length.default_group_node_width = 140
	    
	
	    restore_curve_segment_length.is_modifier = True
	
	    #restore_curve_segment_length interface
	    #Socket Curves
	    curves_socket = restore_curve_segment_length.interface.new_socket(name = "Curves", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    curves_socket.attribute_domain = 'POINT'
	
	    #Socket Curves
	    curves_socket_1 = restore_curve_segment_length.interface.new_socket(name = "Curves", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    curves_socket_1.attribute_domain = 'POINT'
	
	    #Socket Selection
	    selection_socket = restore_curve_segment_length.interface.new_socket(name = "Selection", in_out='INPUT', socket_type = 'NodeSocketBool')
	    selection_socket.default_value = True
	    selection_socket.attribute_domain = 'POINT'
	    selection_socket.hide_value = True
	    selection_socket.description = "Only affect selected elements"
	
	    #Socket Factor
	    factor_socket = restore_curve_segment_length.interface.new_socket(name = "Factor", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    factor_socket.default_value = 1.0
	    factor_socket.min_value = 0.0
	    factor_socket.max_value = 1.0
	    factor_socket.subtype = 'FACTOR'
	    factor_socket.attribute_domain = 'POINT'
	    factor_socket.description = "Factor to blend overall effect"
	
	    #Socket Reference Position
	    reference_position_socket = restore_curve_segment_length.interface.new_socket(name = "Reference Position", in_out='INPUT', socket_type = 'NodeSocketVector')
	    reference_position_socket.default_value = (8.146539688110352, 4.969870090484619, 9.874540328979492)
	    reference_position_socket.min_value = -3.4028234663852886e+38
	    reference_position_socket.max_value = 3.4028234663852886e+38
	    reference_position_socket.subtype = 'NONE'
	    reference_position_socket.default_attribute_name = "rest_position"
	    reference_position_socket.attribute_domain = 'POINT'
	    reference_position_socket.hide_value = True
	    reference_position_socket.description = "Reference position before deformation"
	
	    #Socket Pin at Parameter
	    pin_at_parameter_socket = restore_curve_segment_length.interface.new_socket(name = "Pin at Parameter", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    pin_at_parameter_socket.default_value = 0.0
	    pin_at_parameter_socket.min_value = 0.0
	    pin_at_parameter_socket.max_value = 1.0
	    pin_at_parameter_socket.subtype = 'FACTOR'
	    pin_at_parameter_socket.attribute_domain = 'POINT'
	    pin_at_parameter_socket.description = "Pin each curve at a certain point for the operation"
	
	
	    #initialize restore_curve_segment_length nodes
	    #node Frame.001
	    frame_001 = restore_curve_segment_length.nodes.new("NodeFrame")
	    frame_001.label = "Pin at Parameter"
	    frame_001.name = "Frame.001"
	    frame_001.label_size = 20
	    frame_001.shrink = True
	
	    #node Frame
	    frame = restore_curve_segment_length.nodes.new("NodeFrame")
	    frame.label = "Restore Segment Lengths"
	    frame.name = "Frame"
	    frame.label_size = 20
	    frame.shrink = True
	
	    #node Frame.002
	    frame_002 = restore_curve_segment_length.nodes.new("NodeFrame")
	    frame_002.label = "Default Fallback"
	    frame_002.name = "Frame.002"
	    frame_002.label_size = 20
	    frame_002.shrink = True
	
	    #node Reroute.009
	    reroute_009 = restore_curve_segment_length.nodes.new("NodeReroute")
	    reroute_009.name = "Reroute.009"
	    reroute_009.socket_idname = "NodeSocketVector"
	    #node Group Input.006
	    group_input_006 = restore_curve_segment_length.nodes.new("NodeGroupInput")
	    group_input_006.name = "Group Input.006"
	    group_input_006.outputs[0].hide = True
	    group_input_006.outputs[1].hide = True
	    group_input_006.outputs[2].hide = True
	    group_input_006.outputs[3].hide = True
	    group_input_006.outputs[5].hide = True
	
	    #node Reroute.013
	    reroute_013 = restore_curve_segment_length.nodes.new("NodeReroute")
	    reroute_013.name = "Reroute.013"
	    reroute_013.socket_idname = "NodeSocketGeometry"
	    #node Index
	    index = restore_curve_segment_length.nodes.new("GeometryNodeInputIndex")
	    index.name = "Index"
	
	    #node Sample Curve.001
	    sample_curve_001 = restore_curve_segment_length.nodes.new("GeometryNodeSampleCurve")
	    sample_curve_001.name = "Sample Curve.001"
	    sample_curve_001.data_type = 'FLOAT_VECTOR'
	    sample_curve_001.mode = 'FACTOR'
	    sample_curve_001.use_all_curves = False
	
	    #node Group Input.003
	    group_input_003 = restore_curve_segment_length.nodes.new("NodeGroupInput")
	    group_input_003.name = "Group Input.003"
	    group_input_003.outputs[0].hide = True
	    group_input_003.outputs[1].hide = True
	    group_input_003.outputs[2].hide = True
	    group_input_003.outputs[3].hide = True
	    group_input_003.outputs[5].hide = True
	
	    #node Vector Math.006
	    vector_math_006 = restore_curve_segment_length.nodes.new("ShaderNodeVectorMath")
	    vector_math_006.name = "Vector Math.006"
	    vector_math_006.hide = True
	    vector_math_006.operation = 'SUBTRACT'
	
	    #node Interpolate Domain
	    interpolate_domain_2 = restore_curve_segment_length.nodes.new("GeometryNodeFieldOnDomain")
	    interpolate_domain_2.name = "Interpolate Domain"
	    interpolate_domain_2.hide = True
	    interpolate_domain_2.data_type = 'FLOAT_VECTOR'
	    interpolate_domain_2.domain = 'CURVE'
	
	    #node Group Input.005
	    group_input_005 = restore_curve_segment_length.nodes.new("NodeGroupInput")
	    group_input_005.name = "Group Input.005"
	    group_input_005.outputs[0].hide = True
	    group_input_005.outputs[2].hide = True
	    group_input_005.outputs[3].hide = True
	    group_input_005.outputs[4].hide = True
	    group_input_005.outputs[5].hide = True
	
	    #node Boolean Math.002
	    boolean_math_002 = restore_curve_segment_length.nodes.new("FunctionNodeBooleanMath")
	    boolean_math_002.name = "Boolean Math.002"
	    boolean_math_002.hide = True
	    boolean_math_002.operation = 'AND'
	
	    #node Field at Index.002
	    field_at_index_002 = restore_curve_segment_length.nodes.new("GeometryNodeFieldAtIndex")
	    field_at_index_002.name = "Field at Index.002"
	    field_at_index_002.data_type = 'FLOAT_VECTOR'
	    field_at_index_002.domain = 'POINT'
	
	    #node Vector Math.004
	    vector_math_004 = restore_curve_segment_length.nodes.new("ShaderNodeVectorMath")
	    vector_math_004.name = "Vector Math.004"
	    vector_math_004.operation = 'DISTANCE'
	
	    #node Accumulate Field
	    accumulate_field = restore_curve_segment_length.nodes.new("GeometryNodeAccumulateField")
	    accumulate_field.name = "Accumulate Field"
	    accumulate_field.data_type = 'FLOAT_VECTOR'
	    accumulate_field.domain = 'POINT'
	    accumulate_field.outputs[1].hide = True
	    accumulate_field.outputs[2].hide = True
	
	    #node Curve of Point
	    curve_of_point = restore_curve_segment_length.nodes.new("GeometryNodeCurveOfPoint")
	    curve_of_point.name = "Curve of Point"
	    curve_of_point.inputs[0].hide = True
	    curve_of_point.outputs[1].hide = True
	    #Point Index
	    curve_of_point.inputs[0].default_value = 0
	
	    #node Vector Math
	    vector_math_1 = restore_curve_segment_length.nodes.new("ShaderNodeVectorMath")
	    vector_math_1.name = "Vector Math"
	    vector_math_1.operation = 'SCALE'
	
	    #node Index.001
	    index_001 = restore_curve_segment_length.nodes.new("GeometryNodeInputIndex")
	    index_001.name = "Index.001"
	
	    #node Curve of Point.001
	    curve_of_point_001 = restore_curve_segment_length.nodes.new("GeometryNodeCurveOfPoint")
	    curve_of_point_001.name = "Curve of Point.001"
	    curve_of_point_001.inputs[0].hide = True
	    curve_of_point_001.outputs[0].hide = True
	    #Point Index
	    curve_of_point_001.inputs[0].default_value = 0
	
	    #node Switch
	    switch = restore_curve_segment_length.nodes.new("GeometryNodeSwitch")
	    switch.name = "Switch"
	    switch.input_type = 'INT'
	
	    #node Math
	    math_1 = restore_curve_segment_length.nodes.new("ShaderNodeMath")
	    math_1.name = "Math"
	    math_1.hide = True
	    math_1.operation = 'SUBTRACT'
	    math_1.use_clamp = False
	    #Value_001
	    math_1.inputs[1].default_value = 1.0
	
	    #node Compare
	    compare = restore_curve_segment_length.nodes.new("FunctionNodeCompare")
	    compare.name = "Compare"
	    compare.hide = True
	    compare.data_type = 'INT'
	    compare.mode = 'ELEMENT'
	    compare.operation = 'EQUAL'
	    #B_INT
	    compare.inputs[3].default_value = 0
	
	    #node Reroute.001
	    reroute_001 = restore_curve_segment_length.nodes.new("NodeReroute")
	    reroute_001.name = "Reroute.001"
	    reroute_001.socket_idname = "NodeSocketVector"
	    #node Set Position.001
	    set_position_001_1 = restore_curve_segment_length.nodes.new("GeometryNodeSetPosition")
	    set_position_001_1.name = "Set Position.001"
	
	    #node Boolean Math
	    boolean_math_1 = restore_curve_segment_length.nodes.new("FunctionNodeBooleanMath")
	    boolean_math_1.name = "Boolean Math"
	    boolean_math_1.operation = 'AND'
	
	    #node Compare.002
	    compare_002 = restore_curve_segment_length.nodes.new("FunctionNodeCompare")
	    compare_002.name = "Compare.002"
	    compare_002.data_type = 'FLOAT'
	    compare_002.mode = 'ELEMENT'
	    compare_002.operation = 'GREATER_THAN'
	    #B
	    compare_002.inputs[1].default_value = 0.0
	
	    #node Group Input.002
	    group_input_002_1 = restore_curve_segment_length.nodes.new("NodeGroupInput")
	    group_input_002_1.name = "Group Input.002"
	    group_input_002_1.outputs[0].hide = True
	    group_input_002_1.outputs[3].hide = True
	    group_input_002_1.outputs[4].hide = True
	    group_input_002_1.outputs[5].hide = True
	
	    #node Reroute.016
	    reroute_016 = restore_curve_segment_length.nodes.new("NodeReroute")
	    reroute_016.name = "Reroute.016"
	    reroute_016.socket_idname = "NodeSocketBool"
	    #node Reroute.014
	    reroute_014 = restore_curve_segment_length.nodes.new("NodeReroute")
	    reroute_014.name = "Reroute.014"
	    reroute_014.socket_idname = "NodeSocketGeometry"
	    #node Switch.001
	    switch_001_1 = restore_curve_segment_length.nodes.new("GeometryNodeSwitch")
	    switch_001_1.name = "Switch.001"
	    switch_001_1.input_type = 'GEOMETRY'
	
	    #node Group Output
	    group_output_3 = restore_curve_segment_length.nodes.new("NodeGroupOutput")
	    group_output_3.name = "Group Output"
	    group_output_3.is_active_output = True
	
	    #node Attribute Statistic
	    attribute_statistic = restore_curve_segment_length.nodes.new("GeometryNodeAttributeStatistic")
	    attribute_statistic.name = "Attribute Statistic"
	    attribute_statistic.hide = True
	    attribute_statistic.data_type = 'FLOAT'
	    attribute_statistic.domain = 'CURVE'
	    attribute_statistic.inputs[1].hide = True
	    attribute_statistic.outputs[0].hide = True
	    attribute_statistic.outputs[1].hide = True
	    attribute_statistic.outputs[2].hide = True
	    attribute_statistic.outputs[3].hide = True
	    attribute_statistic.outputs[5].hide = True
	    attribute_statistic.outputs[6].hide = True
	    attribute_statistic.outputs[7].hide = True
	    #Selection
	    attribute_statistic.inputs[1].default_value = True
	
	    #node Group
	    group = restore_curve_segment_length.nodes.new("GeometryNodeGroup")
	    group.name = "Group"
	    group.node_tree = curve_root
	    group.outputs[0].hide = True
	    group.outputs[2].hide = True
	    group.outputs[3].hide = True
	
	    #node Reroute.007
	    reroute_007 = restore_curve_segment_length.nodes.new("NodeReroute")
	    reroute_007.name = "Reroute.007"
	    reroute_007.socket_idname = "NodeSocketVector"
	    #node Reroute.004
	    reroute_004 = restore_curve_segment_length.nodes.new("NodeReroute")
	    reroute_004.name = "Reroute.004"
	    reroute_004.socket_idname = "NodeSocketGeometry"
	    #node Position.001
	    position_001_1 = restore_curve_segment_length.nodes.new("GeometryNodeInputPosition")
	    position_001_1.name = "Position.001"
	
	    #node Named Attribute
	    named_attribute = restore_curve_segment_length.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute.name = "Named Attribute"
	    named_attribute.data_type = 'FLOAT_VECTOR'
	    #Name
	    named_attribute.inputs[0].default_value = "rest_position"
	
	    #node Switch.003
	    switch_003_1 = restore_curve_segment_length.nodes.new("GeometryNodeSwitch")
	    switch_003_1.name = "Switch.003"
	    switch_003_1.input_type = 'VECTOR'
	
	    #node Reroute.006
	    reroute_006 = restore_curve_segment_length.nodes.new("NodeReroute")
	    reroute_006.name = "Reroute.006"
	    reroute_006.socket_idname = "NodeSocketVector"
	    #node Switch.002
	    switch_002 = restore_curve_segment_length.nodes.new("GeometryNodeSwitch")
	    switch_002.name = "Switch.002"
	    switch_002.input_type = 'VECTOR'
	
	    #node Compare.004
	    compare_004 = restore_curve_segment_length.nodes.new("FunctionNodeCompare")
	    compare_004.name = "Compare.004"
	    compare_004.data_type = 'VECTOR'
	    compare_004.mode = 'ELEMENT'
	    compare_004.operation = 'EQUAL'
	    #B_VEC3
	    compare_004.inputs[5].default_value = (8.146539688110352, 4.969870090484619, 9.874540328979492)
	    #Epsilon
	    compare_004.inputs[12].default_value = 0.0
	
	    #node Group Input
	    group_input_1 = restore_curve_segment_length.nodes.new("NodeGroupInput")
	    group_input_1.name = "Group Input"
	    group_input_1.outputs[1].hide = True
	    group_input_1.outputs[2].hide = True
	    group_input_1.outputs[4].hide = True
	    group_input_1.outputs[5].hide = True
	
	    #node Reroute.011
	    reroute_011 = restore_curve_segment_length.nodes.new("NodeReroute")
	    reroute_011.name = "Reroute.011"
	    reroute_011.socket_idname = "NodeSocketGeometry"
	    #node Reroute.005
	    reroute_005 = restore_curve_segment_length.nodes.new("NodeReroute")
	    reroute_005.name = "Reroute.005"
	    reroute_005.socket_idname = "NodeSocketGeometry"
	    #node Reroute.008
	    reroute_008 = restore_curve_segment_length.nodes.new("NodeReroute")
	    reroute_008.name = "Reroute.008"
	    reroute_008.socket_idname = "NodeSocketVector"
	    #node Set Position.002
	    set_position_002_1 = restore_curve_segment_length.nodes.new("GeometryNodeSetPosition")
	    set_position_002_1.name = "Set Position.002"
	    set_position_002_1.inputs[2].hide = True
	    #Position
	    set_position_002_1.inputs[2].default_value = (0.0, 0.0, 0.0)
	
	    #node Reroute.012
	    reroute_012 = restore_curve_segment_length.nodes.new("NodeReroute")
	    reroute_012.name = "Reroute.012"
	    reroute_012.socket_idname = "NodeSocketGeometry"
	    #node Group Input.001
	    group_input_001_1 = restore_curve_segment_length.nodes.new("NodeGroupInput")
	    group_input_001_1.name = "Group Input.001"
	    group_input_001_1.outputs[0].hide = True
	    group_input_001_1.outputs[1].hide = True
	    group_input_001_1.outputs[3].hide = True
	    group_input_001_1.outputs[4].hide = True
	    group_input_001_1.outputs[5].hide = True
	
	    #node Mix
	    mix = restore_curve_segment_length.nodes.new("ShaderNodeMix")
	    mix.name = "Mix"
	    mix.blend_type = 'MIX'
	    mix.clamp_factor = True
	    mix.clamp_result = False
	    mix.data_type = 'FLOAT'
	    mix.factor_mode = 'UNIFORM'
	
	    #node Group.001
	    group_001 = restore_curve_segment_length.nodes.new("GeometryNodeGroup")
	    group_001.name = "Group.001"
	    group_001.node_tree = curve_segment
	    group_001.outputs[2].hide = True
	
	    #node Compare.003
	    compare_003 = restore_curve_segment_length.nodes.new("FunctionNodeCompare")
	    compare_003.name = "Compare.003"
	    compare_003.hide = True
	    compare_003.data_type = 'FLOAT'
	    compare_003.mode = 'ELEMENT'
	    compare_003.operation = 'NOT_EQUAL'
	    #B
	    compare_003.inputs[1].default_value = 0.0
	    #Epsilon
	    compare_003.inputs[12].default_value = 0.0
	
	    #node Compare.005
	    compare_005 = restore_curve_segment_length.nodes.new("FunctionNodeCompare")
	    compare_005.name = "Compare.005"
	    compare_005.hide = True
	    compare_005.data_type = 'FLOAT'
	    compare_005.mode = 'ELEMENT'
	    compare_005.operation = 'GREATER_THAN'
	    #B
	    compare_005.inputs[1].default_value = 0.0
	
	
	
	
	    #Set parents
	    group_input_006.parent = frame_001
	    reroute_013.parent = frame_001
	    index.parent = frame_001
	    sample_curve_001.parent = frame_001
	    group_input_003.parent = frame_001
	    vector_math_006.parent = frame_001
	    interpolate_domain_2.parent = frame_001
	    group_input_005.parent = frame_001
	    boolean_math_002.parent = frame_001
	    field_at_index_002.parent = frame
	    vector_math_004.parent = frame
	    accumulate_field.parent = frame
	    curve_of_point.parent = frame
	    vector_math_1.parent = frame
	    index_001.parent = frame
	    curve_of_point_001.parent = frame
	    switch.parent = frame
	    math_1.parent = frame
	    compare.parent = frame
	    reroute_001.parent = frame
	    set_position_001_1.parent = frame
	    boolean_math_1.parent = frame
	    compare_002.parent = frame
	    group_input_002_1.parent = frame
	    reroute_016.parent = frame_001
	    reroute_014.parent = frame_001
	    switch_001_1.parent = frame_001
	    attribute_statistic.parent = frame_001
	    group.parent = frame
	    reroute_004.parent = frame
	    position_001_1.parent = frame_002
	    named_attribute.parent = frame_002
	    switch_003_1.parent = frame_002
	    reroute_006.parent = frame_002
	    switch_002.parent = frame_002
	    compare_004.parent = frame_002
	    reroute_005.parent = frame
	    set_position_002_1.parent = frame_001
	    reroute_012.parent = frame_001
	    group_input_001_1.parent = frame
	    mix.parent = frame
	    group_001.parent = frame
	    compare_003.parent = frame_001
	    compare_005.parent = frame_001
	
	    #Set locations
	    frame_001.location = (-1289.059814453125, 110.20000457763672)
	    frame.location = (-3492.00048828125, 57.61393737792969)
	    frame_002.location = (-4467.1064453125, -100.04000854492188)
	    reroute_009.location = (-1431.9771728515625, -673.348876953125)
	    group_input_006.location = (218.757080078125, -140.57211303710938)
	    reroute_013.location = (178.571044921875, -120.47908020019531)
	    index.location = (37.919921875, -482.15350341796875)
	    sample_curve_001.location = (218.757080078125, -220.94418334960938)
	    group_input_003.location = (37.919921875, -421.87445068359375)
	    vector_math_006.location = (399.5943603515625, -261.1302490234375)
	    interpolate_domain_2.location = (580.4315795898438, -261.1302490234375)
	    group_input_005.location = (399.5943603515625, -180.75814819335938)
	    boolean_math_002.location = (580.4315795898438, -180.75814819335938)
	    field_at_index_002.location = (653.51171875, -248.73023986816406)
	    vector_math_004.location = (834.348876953125, -228.63722229003906)
	    accumulate_field.location = (1557.69775390625, -409.47442626953125)
	    curve_of_point.location = (1356.767578125, -550.1256103515625)
	    vector_math_1.location = (1356.767578125, -389.38140869140625)
	    index_001.location = (30.6279296875, -469.75347900390625)
	    curve_of_point_001.location = (30.6279296875, -389.38140869140625)
	    switch.location = (412.3955078125, -369.28839111328125)
	    math_1.location = (211.46533203125, -469.75347900390625)
	    compare.location = (211.46533203125, -429.56744384765625)
	    reroute_001.location = (613.32568359375, -309.0093078613281)
	    set_position_001_1.location = (1798.8140869140625, -148.26512145996094)
	    boolean_math_1.location = (1494.958251953125, -96.33775329589844)
	    compare_002.location = (1294.0283203125, -116.43077850341797)
	    group_input_002_1.location = (1113.19140625, -136.5238037109375)
	    reroute_016.location = (801.454833984375, -160.66513061523438)
	    reroute_014.location = (801.454833984375, -120.47908020019531)
	    switch_001_1.location = (1082.757080078125, -40.10698699951172)
	    group_output_3.location = (75.0, 50.0)
	    attribute_statistic.location = (861.73388671875, -60.20000457763672)
	    group.location = (1557.69775390625, -268.8232421875)
	    reroute_007.location = (-3762.76806640625, -251.3953857421875)
	    reroute_004.location = (1638.06982421875, -47.80000305175781)
	    position_001_1.location = (60.265625, -241.41067504882812)
	    named_attribute.location = (60.265625, -301.6897277832031)
	    switch_003_1.location = (241.1025390625, -221.31765747070312)
	    reroute_006.location = (37.919921875, -72.88264465332031)
	    switch_002.location = (442.03271484375, -100.75950622558594)
	    compare_004.location = (60.26611328125, -40.480438232421875)
	    group_input_1.location = (-4707.1396484375, -30.37213134765625)
	    reroute_011.location = (-3581.9306640625, -70.55816650390625)
	    reroute_005.location = (50.72119140625, -47.80000305175781)
	    reroute_008.location = (-3561.83740234375, -673.348876953125)
	    set_position_002_1.location = (861.73388671875, -140.57211303710938)
	    reroute_012.location = (37.919921875, -241.0372314453125)
	    group_input_001_1.location = (834.348876953125, -168.358154296875)
	    mix.location = (1115.6513671875, -329.10235595703125)
	    group_001.location = (834.348876953125, -409.47442626953125)
	    compare_003.location = (399.5943603515625, -140.57211303710938)
	    compare_005.location = (861.73388671875, -100.38605499267578)
	
	    #Set dimensions
	    frame_001.width, frame_001.height = 1252.8997802734375, 561.8800659179688
	    frame.width, frame.height = 1968.80029296875, 632.1739501953125
	    frame_002.width, frame_002.height = 612.06640625, 452.4400329589844
	    reroute_009.width, reroute_009.height = 16.0, 100.0
	    group_input_006.width, group_input_006.height = 140.0, 100.0
	    reroute_013.width, reroute_013.height = 16.0, 100.0
	    index.width, index.height = 140.0, 100.0
	    sample_curve_001.width, sample_curve_001.height = 140.0, 100.0
	    group_input_003.width, group_input_003.height = 140.0, 100.0
	    vector_math_006.width, vector_math_006.height = 140.0, 100.0
	    interpolate_domain_2.width, interpolate_domain_2.height = 140.0, 100.0
	    group_input_005.width, group_input_005.height = 140.0, 100.0
	    boolean_math_002.width, boolean_math_002.height = 140.0, 100.0
	    field_at_index_002.width, field_at_index_002.height = 140.0, 100.0
	    vector_math_004.width, vector_math_004.height = 140.0, 100.0
	    accumulate_field.width, accumulate_field.height = 140.0, 100.0
	    curve_of_point.width, curve_of_point.height = 140.0, 100.0
	    vector_math_1.width, vector_math_1.height = 140.0, 100.0
	    index_001.width, index_001.height = 140.0, 100.0
	    curve_of_point_001.width, curve_of_point_001.height = 140.0, 100.0
	    switch.width, switch.height = 140.0, 100.0
	    math_1.width, math_1.height = 140.0, 100.0
	    compare.width, compare.height = 140.0, 100.0
	    reroute_001.width, reroute_001.height = 16.0, 100.0
	    set_position_001_1.width, set_position_001_1.height = 140.0, 100.0
	    boolean_math_1.width, boolean_math_1.height = 140.0, 100.0
	    compare_002.width, compare_002.height = 140.0, 100.0
	    group_input_002_1.width, group_input_002_1.height = 140.0, 100.0
	    reroute_016.width, reroute_016.height = 16.0, 100.0
	    reroute_014.width, reroute_014.height = 16.0, 100.0
	    switch_001_1.width, switch_001_1.height = 140.0, 100.0
	    group_output_3.width, group_output_3.height = 140.0, 100.0
	    attribute_statistic.width, attribute_statistic.height = 140.0, 100.0
	    group.width, group.height = 140.0, 100.0
	    reroute_007.width, reroute_007.height = 16.0, 100.0
	    reroute_004.width, reroute_004.height = 16.0, 100.0
	    position_001_1.width, position_001_1.height = 140.0, 100.0
	    named_attribute.width, named_attribute.height = 140.0, 100.0
	    switch_003_1.width, switch_003_1.height = 140.0, 100.0
	    reroute_006.width, reroute_006.height = 16.0, 100.0
	    switch_002.width, switch_002.height = 140.0, 100.0
	    compare_004.width, compare_004.height = 140.0, 100.0
	    group_input_1.width, group_input_1.height = 140.0, 100.0
	    reroute_011.width, reroute_011.height = 16.0, 100.0
	    reroute_005.width, reroute_005.height = 16.0, 100.0
	    reroute_008.width, reroute_008.height = 16.0, 100.0
	    set_position_002_1.width, set_position_002_1.height = 140.0, 100.0
	    reroute_012.width, reroute_012.height = 16.0, 100.0
	    group_input_001_1.width, group_input_001_1.height = 140.0, 100.0
	    mix.width, mix.height = 140.0, 100.0
	    group_001.width, group_001.height = 140.0, 100.0
	    compare_003.width, compare_003.height = 140.0, 100.0
	    compare_005.width, compare_005.height = 140.0, 100.0
	
	    #initialize restore_curve_segment_length links
	    #reroute_004.Output -> set_position_001_1.Geometry
	    restore_curve_segment_length.links.new(reroute_004.outputs[0], set_position_001_1.inputs[0])
	    #curve_of_point.Curve Index -> accumulate_field.Group ID
	    restore_curve_segment_length.links.new(curve_of_point.outputs[0], accumulate_field.inputs[1])
	    #field_at_index_002.Value -> vector_math_004.Vector
	    restore_curve_segment_length.links.new(field_at_index_002.outputs[0], vector_math_004.inputs[0])
	    #reroute_001.Output -> vector_math_004.Vector
	    restore_curve_segment_length.links.new(reroute_001.outputs[0], vector_math_004.inputs[1])
	    #reroute_001.Output -> field_at_index_002.Value
	    restore_curve_segment_length.links.new(reroute_001.outputs[0], field_at_index_002.inputs[1])
	    #index_001.Index -> math_1.Value
	    restore_curve_segment_length.links.new(index_001.outputs[0], math_1.inputs[0])
	    #switch.Output -> field_at_index_002.Index
	    restore_curve_segment_length.links.new(switch.outputs[0], field_at_index_002.inputs[0])
	    #vector_math_1.Vector -> accumulate_field.Value
	    restore_curve_segment_length.links.new(vector_math_1.outputs[0], accumulate_field.inputs[0])
	    #curve_of_point_001.Index in Curve -> compare.A
	    restore_curve_segment_length.links.new(curve_of_point_001.outputs[1], compare.inputs[2])
	    #math_1.Value -> switch.False
	    restore_curve_segment_length.links.new(math_1.outputs[0], switch.inputs[1])
	    #compare.Result -> switch.Switch
	    restore_curve_segment_length.links.new(compare.outputs[0], switch.inputs[0])
	    #index_001.Index -> switch.True
	    restore_curve_segment_length.links.new(index_001.outputs[0], switch.inputs[2])
	    #reroute_006.Output -> switch_002.False
	    restore_curve_segment_length.links.new(reroute_006.outputs[0], switch_002.inputs[1])
	    #group.Root Position -> set_position_001_1.Position
	    restore_curve_segment_length.links.new(group.outputs[1], set_position_001_1.inputs[2])
	    #vector_math_004.Value -> mix.B
	    restore_curve_segment_length.links.new(vector_math_004.outputs[1], mix.inputs[3])
	    #mix.Result -> vector_math_1.Scale
	    restore_curve_segment_length.links.new(mix.outputs[0], vector_math_1.inputs[3])
	    #group_input_001_1.Factor -> mix.Factor
	    restore_curve_segment_length.links.new(group_input_001_1.outputs[2], mix.inputs[0])
	    #group_input_002_1.Factor -> compare_002.A
	    restore_curve_segment_length.links.new(group_input_002_1.outputs[2], compare_002.inputs[0])
	    #accumulate_field.Leading -> set_position_001_1.Offset
	    restore_curve_segment_length.links.new(accumulate_field.outputs[0], set_position_001_1.inputs[3])
	    #compare_002.Result -> boolean_math_1.Boolean
	    restore_curve_segment_length.links.new(compare_002.outputs[0], boolean_math_1.inputs[0])
	    #group_input_002_1.Selection -> boolean_math_1.Boolean
	    restore_curve_segment_length.links.new(group_input_002_1.outputs[1], boolean_math_1.inputs[1])
	    #reroute_005.Output -> reroute_004.Input
	    restore_curve_segment_length.links.new(reroute_005.outputs[0], reroute_004.inputs[0])
	    #reroute_012.Output -> sample_curve_001.Curves
	    restore_curve_segment_length.links.new(reroute_012.outputs[0], sample_curve_001.inputs[0])
	    #sample_curve_001.Position -> vector_math_006.Vector
	    restore_curve_segment_length.links.new(sample_curve_001.outputs[1], vector_math_006.inputs[1])
	    #sample_curve_001.Value -> vector_math_006.Vector
	    restore_curve_segment_length.links.new(sample_curve_001.outputs[0], vector_math_006.inputs[0])
	    #reroute_014.Output -> set_position_002_1.Geometry
	    restore_curve_segment_length.links.new(reroute_014.outputs[0], set_position_002_1.inputs[0])
	    #interpolate_domain_2.Value -> set_position_002_1.Offset
	    restore_curve_segment_length.links.new(interpolate_domain_2.outputs[0], set_position_002_1.inputs[3])
	    #index.Index -> sample_curve_001.Curve Index
	    restore_curve_segment_length.links.new(index.outputs[0], sample_curve_001.inputs[4])
	    #reroute_012.Output -> reroute_013.Input
	    restore_curve_segment_length.links.new(reroute_012.outputs[0], reroute_013.inputs[0])
	    #group_input_005.Selection -> boolean_math_002.Boolean
	    restore_curve_segment_length.links.new(group_input_005.outputs[1], boolean_math_002.inputs[1])
	    #compare_003.Result -> boolean_math_002.Boolean
	    restore_curve_segment_length.links.new(compare_003.outputs[0], boolean_math_002.inputs[0])
	    #reroute_011.Output -> reroute_005.Input
	    restore_curve_segment_length.links.new(reroute_011.outputs[0], reroute_005.inputs[0])
	    #group_input_003.Pin at Parameter -> sample_curve_001.Factor
	    restore_curve_segment_length.links.new(group_input_003.outputs[4], sample_curve_001.inputs[2])
	    #group_input_006.Pin at Parameter -> compare_003.A
	    restore_curve_segment_length.links.new(group_input_006.outputs[4], compare_003.inputs[0])
	    #reroute_006.Output -> compare_004.A
	    restore_curve_segment_length.links.new(reroute_006.outputs[0], compare_004.inputs[4])
	    #compare_004.Result -> switch_002.Switch
	    restore_curve_segment_length.links.new(compare_004.outputs[0], switch_002.inputs[0])
	    #named_attribute.Attribute -> switch_003_1.True
	    restore_curve_segment_length.links.new(named_attribute.outputs[0], switch_003_1.inputs[2])
	    #named_attribute.Exists -> switch_003_1.Switch
	    restore_curve_segment_length.links.new(named_attribute.outputs[1], switch_003_1.inputs[0])
	    #position_001_1.Position -> switch_003_1.False
	    restore_curve_segment_length.links.new(position_001_1.outputs[0], switch_003_1.inputs[1])
	    #switch_003_1.Output -> switch_002.True
	    restore_curve_segment_length.links.new(switch_003_1.outputs[0], switch_002.inputs[2])
	    #reroute_009.Output -> sample_curve_001.Value
	    restore_curve_segment_length.links.new(reroute_009.outputs[0], sample_curve_001.inputs[1])
	    #switch_002.Output -> reroute_007.Input
	    restore_curve_segment_length.links.new(switch_002.outputs[0], reroute_007.inputs[0])
	    #reroute_007.Output -> reroute_001.Input
	    restore_curve_segment_length.links.new(reroute_007.outputs[0], reroute_001.inputs[0])
	    #group_input_1.Reference Position -> reroute_006.Input
	    restore_curve_segment_length.links.new(group_input_1.outputs[3], reroute_006.inputs[0])
	    #reroute_007.Output -> reroute_008.Input
	    restore_curve_segment_length.links.new(reroute_007.outputs[0], reroute_008.inputs[0])
	    #reroute_008.Output -> reroute_009.Input
	    restore_curve_segment_length.links.new(reroute_008.outputs[0], reroute_009.inputs[0])
	    #group_input_1.Curves -> reroute_011.Input
	    restore_curve_segment_length.links.new(group_input_1.outputs[0], reroute_011.inputs[0])
	    #group_001.Segment Length -> mix.A
	    restore_curve_segment_length.links.new(group_001.outputs[0], mix.inputs[2])
	    #group_001.Segment Direction -> vector_math_1.Vector
	    restore_curve_segment_length.links.new(group_001.outputs[1], vector_math_1.inputs[0])
	    #vector_math_006.Vector -> interpolate_domain_2.Value
	    restore_curve_segment_length.links.new(vector_math_006.outputs[0], interpolate_domain_2.inputs[0])
	    #reroute_016.Output -> attribute_statistic.Attribute
	    restore_curve_segment_length.links.new(reroute_016.outputs[0], attribute_statistic.inputs[2])
	    #attribute_statistic.Max -> compare_005.A
	    restore_curve_segment_length.links.new(attribute_statistic.outputs[4], compare_005.inputs[0])
	    #set_position_002_1.Geometry -> switch_001_1.True
	    restore_curve_segment_length.links.new(set_position_002_1.outputs[0], switch_001_1.inputs[2])
	    #reroute_014.Output -> switch_001_1.False
	    restore_curve_segment_length.links.new(reroute_014.outputs[0], switch_001_1.inputs[1])
	    #reroute_016.Output -> set_position_002_1.Selection
	    restore_curve_segment_length.links.new(reroute_016.outputs[0], set_position_002_1.inputs[1])
	    #compare_005.Result -> switch_001_1.Switch
	    restore_curve_segment_length.links.new(compare_005.outputs[0], switch_001_1.inputs[0])
	    #reroute_014.Output -> attribute_statistic.Geometry
	    restore_curve_segment_length.links.new(reroute_014.outputs[0], attribute_statistic.inputs[0])
	    #boolean_math_1.Boolean -> set_position_001_1.Selection
	    restore_curve_segment_length.links.new(boolean_math_1.outputs[0], set_position_001_1.inputs[1])
	    #boolean_math_002.Boolean -> reroute_016.Input
	    restore_curve_segment_length.links.new(boolean_math_002.outputs[0], reroute_016.inputs[0])
	    #reroute_013.Output -> reroute_014.Input
	    restore_curve_segment_length.links.new(reroute_013.outputs[0], reroute_014.inputs[0])
	    #set_position_001_1.Geometry -> reroute_012.Input
	    restore_curve_segment_length.links.new(set_position_001_1.outputs[0], reroute_012.inputs[0])
	    #switch_001_1.Output -> group_output_3.Curves
	    restore_curve_segment_length.links.new(switch_001_1.outputs[0], group_output_3.inputs[0])
	    return restore_curve_segment_length
	
	restore_curve_segment_length = restore_curve_segment_length_node_group()
	
	#initialize twist_bun node group
	def twist_bun_node_group():
	    twist_bun = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "TWIST_BUN")
	
	    twist_bun.color_tag = 'NONE'
	    twist_bun.description = "Deform hair curve to a twist bun guide."
	    twist_bun.default_group_node_width = 140
	    
	
	    twist_bun.is_modifier = True
	
	    #twist_bun interface
	    #Socket Geometry
	    geometry_socket_1 = twist_bun.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_1.attribute_domain = 'POINT'
	    geometry_socket_1.description = "Deformed hair curve."
	
	    #Socket Geometry
	    geometry_socket_2 = twist_bun.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_2.attribute_domain = 'POINT'
	    geometry_socket_2.description = "Hair Curve."
	
	    #Socket Control Points
	    control_points_socket_1 = twist_bun.interface.new_socket(name = "Control Points", in_out='INPUT', socket_type = 'NodeSocketInt')
	    control_points_socket_1.default_value = 20
	    control_points_socket_1.min_value = 1
	    control_points_socket_1.max_value = 100000
	    control_points_socket_1.subtype = 'NONE'
	    control_points_socket_1.attribute_domain = 'POINT'
	    control_points_socket_1.description = "Amount of points for each curve."
	
	    #Socket Offset Scale
	    offset_scale_socket_1 = twist_bun.interface.new_socket(name = "Offset Scale", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    offset_scale_socket_1.default_value = 1.0
	    offset_scale_socket_1.min_value = 0.0
	    offset_scale_socket_1.max_value = 3.4028234663852886e+38
	    offset_scale_socket_1.subtype = 'NONE'
	    offset_scale_socket_1.attribute_domain = 'POINT'
	    offset_scale_socket_1.description = "Overhang offset scale."
	
	    #Socket Rotate
	    rotate_socket_1 = twist_bun.interface.new_socket(name = "Rotate", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    rotate_socket_1.default_value = 0.0
	    rotate_socket_1.min_value = -3.1415927410125732
	    rotate_socket_1.max_value = 3.1415927410125732
	    rotate_socket_1.subtype = 'ANGLE'
	    rotate_socket_1.attribute_domain = 'POINT'
	    rotate_socket_1.description = "Rotate twist along guide curve tangent."
	
	    #Socket Scale
	    scale_socket_1 = twist_bun.interface.new_socket(name = "Scale", in_out='INPUT', socket_type = 'NodeSocketVector')
	    scale_socket_1.default_value = (1.0, 1.0, 1.0)
	    scale_socket_1.min_value = -3.4028234663852886e+38
	    scale_socket_1.max_value = 3.4028234663852886e+38
	    scale_socket_1.subtype = 'XYZ'
	    scale_socket_1.attribute_domain = 'POINT'
	    scale_socket_1.description = "Scale of twist."
	
	    #Socket Flip X
	    flip_x_socket = twist_bun.interface.new_socket(name = "Flip X", in_out='INPUT', socket_type = 'NodeSocketBool')
	    flip_x_socket.default_value = False
	    flip_x_socket.attribute_domain = 'POINT'
	    flip_x_socket.description = "Flip directection of twist based on root position."
	
	    #Socket Flip Overhang
	    flip_overhang_socket = twist_bun.interface.new_socket(name = "Flip Overhang", in_out='INPUT', socket_type = 'NodeSocketBool')
	    flip_overhang_socket.default_value = False
	    flip_overhang_socket.attribute_domain = 'POINT'
	    flip_overhang_socket.description = "Flip overhang direction of twist that has Flip X."
	
	
	    #initialize twist_bun nodes
	    #node Group Input
	    group_input_2 = twist_bun.nodes.new("NodeGroupInput")
	    group_input_2.name = "Group Input"
	    group_input_2.outputs[2].hide = True
	    group_input_2.outputs[3].hide = True
	    group_input_2.outputs[4].hide = True
	    group_input_2.outputs[5].hide = True
	    group_input_2.outputs[6].hide = True
	    group_input_2.outputs[7].hide = True
	
	    #node Group Output
	    group_output_4 = twist_bun.nodes.new("NodeGroupOutput")
	    group_output_4.name = "Group Output"
	    group_output_4.is_active_output = True
	    group_output_4.inputs[1].hide = True
	
	    #node Group
	    group_1 = twist_bun.nodes.new("GeometryNodeGroup")
	    group_1.name = "Group"
	    group_1.node_tree = twist
	
	    #node Curve Tangent
	    curve_tangent_1 = twist_bun.nodes.new("GeometryNodeInputTangent")
	    curve_tangent_1.name = "Curve Tangent"
	
	    #node Align Rotation to Vector
	    align_rotation_to_vector = twist_bun.nodes.new("FunctionNodeAlignRotationToVector")
	    align_rotation_to_vector.name = "Align Rotation to Vector"
	    align_rotation_to_vector.hide = True
	    align_rotation_to_vector.axis = 'X'
	    align_rotation_to_vector.pivot_axis = 'AUTO'
	    align_rotation_to_vector.inputs[0].hide = True
	    align_rotation_to_vector.inputs[1].hide = True
	    #Rotation
	    align_rotation_to_vector.inputs[0].default_value = (0.0, 0.0, 0.0)
	    #Factor
	    align_rotation_to_vector.inputs[1].default_value = 1.0
	
	    #node Resample Curve
	    resample_curve_1 = twist_bun.nodes.new("GeometryNodeResampleCurve")
	    resample_curve_1.name = "Resample Curve"
	    resample_curve_1.hide = True
	    resample_curve_1.keep_last_segment = True
	    resample_curve_1.mode = 'COUNT'
	    resample_curve_1.inputs[1].hide = True
	    resample_curve_1.inputs[3].hide = True
	    #Selection
	    resample_curve_1.inputs[1].default_value = True
	
	    #node Sample Index
	    sample_index_1 = twist_bun.nodes.new("GeometryNodeSampleIndex")
	    sample_index_1.name = "Sample Index"
	    sample_index_1.hide = True
	    sample_index_1.clamp = False
	    sample_index_1.data_type = 'FLOAT_VECTOR'
	    sample_index_1.domain = 'POINT'
	
	    #node Index
	    index_1 = twist_bun.nodes.new("GeometryNodeInputIndex")
	    index_1.name = "Index"
	
	    #node Math
	    math_2 = twist_bun.nodes.new("ShaderNodeMath")
	    math_2.name = "Math"
	    math_2.hide = True
	    math_2.operation = 'FLOORED_MODULO'
	    math_2.use_clamp = False
	
	    #node Position
	    position_1 = twist_bun.nodes.new("GeometryNodeInputPosition")
	    position_1.name = "Position"
	
	    #node Rotate Vector
	    rotate_vector = twist_bun.nodes.new("FunctionNodeRotateVector")
	    rotate_vector.name = "Rotate Vector"
	
	    #node Set Position.001
	    set_position_001_2 = twist_bun.nodes.new("GeometryNodeSetPosition")
	    set_position_001_2.name = "Set Position.001"
	    set_position_001_2.inputs[1].hide = True
	    #Selection
	    set_position_001_2.inputs[1].default_value = True
	
	    #node Group.001
	    group_001_1 = twist_bun.nodes.new("GeometryNodeGroup")
	    group_001_1.name = "Group.001"
	    group_001_1.node_tree = curve_root
	    group_001_1.outputs[0].hide = True
	    group_001_1.outputs[2].hide = True
	    group_001_1.outputs[3].hide = True
	
	    #node Group.002
	    group_002 = twist_bun.nodes.new("GeometryNodeGroup")
	    group_002.name = "Group.002"
	    group_002.node_tree = restore_curve_segment_length
	    group_002.inputs[1].hide = True
	    group_002.inputs[2].hide = True
	    group_002.inputs[4].hide = True
	    #Input_4
	    group_002.inputs[1].default_value = True
	    #Input_3
	    group_002.inputs[2].default_value = 1.0
	    #Input_6
	    group_002.inputs[4].default_value = 0.0
	
	    #node Sample Index.001
	    sample_index_001_1 = twist_bun.nodes.new("GeometryNodeSampleIndex")
	    sample_index_001_1.name = "Sample Index.001"
	    sample_index_001_1.hide = True
	    sample_index_001_1.clamp = False
	    sample_index_001_1.data_type = 'FLOAT_VECTOR'
	    sample_index_001_1.domain = 'POINT'
	
	    #node Index.001
	    index_001_1 = twist_bun.nodes.new("GeometryNodeInputIndex")
	    index_001_1.name = "Index.001"
	
	    #node Position.002
	    position_002_3 = twist_bun.nodes.new("GeometryNodeInputPosition")
	    position_002_3.name = "Position.002"
	
	    #node Group Input.001
	    group_input_001_2 = twist_bun.nodes.new("NodeGroupInput")
	    group_input_001_2.name = "Group Input.001"
	    group_input_001_2.outputs[0].hide = True
	    group_input_001_2.outputs[5].hide = True
	    group_input_001_2.outputs[6].hide = True
	    group_input_001_2.outputs[7].hide = True
	
	    #node Group Input.003
	    group_input_003_1 = twist_bun.nodes.new("NodeGroupInput")
	    group_input_003_1.name = "Group Input.003"
	    group_input_003_1.outputs[0].hide = True
	    group_input_003_1.outputs[2].hide = True
	    group_input_003_1.outputs[3].hide = True
	    group_input_003_1.outputs[4].hide = True
	    group_input_003_1.outputs[5].hide = True
	    group_input_003_1.outputs[6].hide = True
	    group_input_003_1.outputs[7].hide = True
	
	    #node Combine XYZ.001
	    combine_xyz_001_1 = twist_bun.nodes.new("ShaderNodeCombineXYZ")
	    combine_xyz_001_1.name = "Combine XYZ.001"
	    combine_xyz_001_1.hide = True
	
	    #node Separate XYZ.001
	    separate_xyz_001_1 = twist_bun.nodes.new("ShaderNodeSeparateXYZ")
	    separate_xyz_001_1.name = "Separate XYZ.001"
	    separate_xyz_001_1.hide = True
	
	    #node Math.001
	    math_001_1 = twist_bun.nodes.new("ShaderNodeMath")
	    math_001_1.name = "Math.001"
	    math_001_1.hide = True
	    math_001_1.operation = 'MULTIPLY'
	    math_001_1.use_clamp = False
	    math_001_1.inputs[1].hide = True
	    math_001_1.inputs[2].hide = True
	    #Value_001
	    math_001_1.inputs[1].default_value = -1.0
	
	    #node Math.002
	    math_002_1 = twist_bun.nodes.new("ShaderNodeMath")
	    math_002_1.name = "Math.002"
	    math_002_1.hide = True
	    math_002_1.operation = 'MULTIPLY'
	    math_002_1.use_clamp = False
	    math_002_1.inputs[1].hide = True
	    math_002_1.inputs[2].hide = True
	    #Value_001
	    math_002_1.inputs[1].default_value = -1.0
	
	    #node Set Position.004
	    set_position_004_1 = twist_bun.nodes.new("GeometryNodeSetPosition")
	    set_position_004_1.name = "Set Position.004"
	    set_position_004_1.hide = True
	
	    #node Group.004
	    group_004 = twist_bun.nodes.new("GeometryNodeGroup")
	    group_004.name = "Group.004"
	    group_004.node_tree = curve_root
	    group_004.outputs[0].hide = True
	    group_004.outputs[2].hide = True
	    group_004.outputs[3].hide = True
	
	    #node Separate XYZ.002
	    separate_xyz_002 = twist_bun.nodes.new("ShaderNodeSeparateXYZ")
	    separate_xyz_002.name = "Separate XYZ.002"
	    separate_xyz_002.hide = True
	    separate_xyz_002.outputs[1].hide = True
	    separate_xyz_002.outputs[2].hide = True
	
	    #node Compare
	    compare_1 = twist_bun.nodes.new("FunctionNodeCompare")
	    compare_1.name = "Compare"
	    compare_1.hide = True
	    compare_1.data_type = 'FLOAT'
	    compare_1.mode = 'ELEMENT'
	    compare_1.operation = 'GREATER_THAN'
	    compare_1.inputs[1].hide = True
	    compare_1.inputs[2].hide = True
	    compare_1.inputs[3].hide = True
	    compare_1.inputs[4].hide = True
	    compare_1.inputs[5].hide = True
	    compare_1.inputs[6].hide = True
	    compare_1.inputs[7].hide = True
	    compare_1.inputs[8].hide = True
	    compare_1.inputs[9].hide = True
	    compare_1.inputs[10].hide = True
	    compare_1.inputs[11].hide = True
	    compare_1.inputs[12].hide = True
	    #B
	    compare_1.inputs[1].default_value = 0.0
	
	    #node Boolean Math
	    boolean_math_2 = twist_bun.nodes.new("FunctionNodeBooleanMath")
	    boolean_math_2.name = "Boolean Math"
	    boolean_math_2.hide = True
	    boolean_math_2.operation = 'NOT'
	
	    #node Curve Tangent.002
	    curve_tangent_002 = twist_bun.nodes.new("GeometryNodeInputTangent")
	    curve_tangent_002.name = "Curve Tangent.002"
	
	    #node Align Rotation to Vector.002
	    align_rotation_to_vector_002 = twist_bun.nodes.new("FunctionNodeAlignRotationToVector")
	    align_rotation_to_vector_002.name = "Align Rotation to Vector.002"
	    align_rotation_to_vector_002.hide = True
	    align_rotation_to_vector_002.axis = 'X'
	    align_rotation_to_vector_002.pivot_axis = 'AUTO'
	    align_rotation_to_vector_002.inputs[0].hide = True
	    align_rotation_to_vector_002.inputs[1].hide = True
	    #Rotation
	    align_rotation_to_vector_002.inputs[0].default_value = (0.0, 0.0, 0.0)
	    #Factor
	    align_rotation_to_vector_002.inputs[1].default_value = 1.0
	
	    #node Rotate Vector.002
	    rotate_vector_002 = twist_bun.nodes.new("FunctionNodeRotateVector")
	    rotate_vector_002.name = "Rotate Vector.002"
	
	    #node Set Position.005
	    set_position_005_1 = twist_bun.nodes.new("GeometryNodeSetPosition")
	    set_position_005_1.name = "Set Position.005"
	    set_position_005_1.hide = True
	
	    #node Group.005
	    group_005 = twist_bun.nodes.new("GeometryNodeGroup")
	    group_005.name = "Group.005"
	    group_005.node_tree = curve_root
	    group_005.outputs[0].hide = True
	    group_005.outputs[2].hide = True
	    group_005.outputs[3].hide = True
	
	    #node Switch
	    switch_1 = twist_bun.nodes.new("GeometryNodeSwitch")
	    switch_1.name = "Switch"
	    switch_1.hide = True
	    switch_1.input_type = 'GEOMETRY'
	
	    #node Switch.001
	    switch_001_2 = twist_bun.nodes.new("GeometryNodeSwitch")
	    switch_001_2.name = "Switch.001"
	    switch_001_2.hide = True
	    switch_001_2.input_type = 'FLOAT'
	
	    #node Frame
	    frame_1 = twist_bun.nodes.new("NodeFrame")
	    frame_1.label = "Flip X"
	    frame_1.name = "Frame"
	    frame_1.label_size = 20
	    frame_1.shrink = True
	
	    #node Group Input.002
	    group_input_002_2 = twist_bun.nodes.new("NodeGroupInput")
	    group_input_002_2.name = "Group Input.002"
	    group_input_002_2.outputs[0].hide = True
	    group_input_002_2.outputs[1].hide = True
	    group_input_002_2.outputs[2].hide = True
	    group_input_002_2.outputs[3].hide = True
	    group_input_002_2.outputs[4].hide = True
	    group_input_002_2.outputs[6].hide = True
	    group_input_002_2.outputs[7].hide = True
	
	    #node Group Input.004
	    group_input_004 = twist_bun.nodes.new("NodeGroupInput")
	    group_input_004.name = "Group Input.004"
	    group_input_004.outputs[0].hide = True
	    group_input_004.outputs[1].hide = True
	    group_input_004.outputs[2].hide = True
	    group_input_004.outputs[3].hide = True
	    group_input_004.outputs[4].hide = True
	    group_input_004.outputs[5].hide = True
	    group_input_004.outputs[7].hide = True
	
	    #node Twist Bun Bake
	    twist_bun_bake = twist_bun.nodes.new("GeometryNodeBake")
	    twist_bun_bake.label = "Twist Bun Bake"
	    twist_bun_bake.name = "Twist Bun Bake"
	    twist_bun_bake.active_index = 0
	    twist_bun_bake.bake_items.clear()
	    twist_bun_bake.bake_items.new('GEOMETRY', "Geometry")
	    twist_bun_bake.bake_items[0].attribute_domain = 'POINT'
	    twist_bun_bake.inputs[1].hide = True
	    twist_bun_bake.outputs[1].hide = True
	
	
	
	
	    #Set parents
	    combine_xyz_001_1.parent = frame_1
	    separate_xyz_001_1.parent = frame_1
	    math_001_1.parent = frame_1
	    math_002_1.parent = frame_1
	    set_position_004_1.parent = frame_1
	    group_004.parent = frame_1
	    separate_xyz_002.parent = frame_1
	    compare_1.parent = frame_1
	    boolean_math_2.parent = frame_1
	    curve_tangent_002.parent = frame_1
	    align_rotation_to_vector_002.parent = frame_1
	    rotate_vector_002.parent = frame_1
	    set_position_005_1.parent = frame_1
	    group_005.parent = frame_1
	    switch_001_2.parent = frame_1
	
	    #Set locations
	    group_input_2.location = (-340.0, 0.0)
	    group_output_4.location = (751.70703125, -6.748708724975586)
	    group_1.location = (-521.43701171875, -18.797523498535156)
	    curve_tangent_1.location = (-168.17709350585938, -301.6763916015625)
	    align_rotation_to_vector.location = (-170.00460815429688, -270.28857421875)
	    resample_curve_1.location = (-169.4429168701172, -32.20364761352539)
	    sample_index_1.location = (-341.0291442871094, -205.567626953125)
	    index_1.location = (-519.739501953125, -240.63514709472656)
	    math_2.location = (-341.1871032714844, -241.31204223632812)
	    position_1.location = (-520.1217651367188, -185.08969116210938)
	    rotate_vector.location = (-168.30642700195312, -163.6996307373047)
	    set_position_001_2.location = (8.631647109985352, 18.025375366210938)
	    group_001_1.location = (10.530008316040039, -121.42079162597656)
	    group_002.location = (364.1277160644531, -8.031657218933105)
	    sample_index_001_1.location = (-169.97933959960938, -83.72132873535156)
	    index_001_1.location = (-340.09619140625, -132.7902374267578)
	    position_002_3.location = (-339.2433776855469, -77.85386657714844)
	    group_input_001_2.location = (-697.4818725585938, -66.13355255126953)
	    group_input_003_1.location = (-519.4154052734375, -297.27923583984375)
	    combine_xyz_001_1.location = (33.33610534667969, -176.2052001953125)
	    separate_xyz_001_1.location = (32.56260681152344, -73.7750244140625)
	    math_001_1.location = (32.06541442871094, -107.67337036132812)
	    math_002_1.location = (32.06541442871094, -140.80111694335938)
	    set_position_004_1.location = (210.15066528320312, -44.59283447265625)
	    group_004.location = (210.472412109375, -90.96636962890625)
	    separate_xyz_002.location = (212.29762268066406, -179.4678955078125)
	    compare_1.location = (211.8003692626953, -213.3663330078125)
	    boolean_math_2.location = (213.37696838378906, -246.493896484375)
	    curve_tangent_002.location = (31.765304565429688, -381.6473388671875)
	    align_rotation_to_vector_002.location = (29.937789916992188, -350.259521484375)
	    rotate_vector_002.location = (31.635971069335938, -243.6705322265625)
	    set_position_005_1.location = (213.3039093017578, -298.5711669921875)
	    group_005.location = (210.472412109375, -344.944580078125)
	    switch_1.location = (196.3229522705078, -6.687553405761719)
	    switch_001_2.location = (30.669906616210938, -212.421875)
	    frame_1.location = (-181.0, -364.0)
	    group_input_002_2.location = (194.88661193847656, 53.75669860839844)
	    group_input_004.location = (-326.97552490234375, -537.80712890625)
	    twist_bun_bake.location = (559.734130859375, 40.35017395019531)
	
	    #Set dimensions
	    group_input_2.width, group_input_2.height = 140.0, 100.0
	    group_output_4.width, group_output_4.height = 140.0, 100.0
	    group_1.width, group_1.height = 140.0, 100.0
	    curve_tangent_1.width, curve_tangent_1.height = 140.0, 100.0
	    align_rotation_to_vector.width, align_rotation_to_vector.height = 140.0, 100.0
	    resample_curve_1.width, resample_curve_1.height = 140.0, 100.0
	    sample_index_1.width, sample_index_1.height = 140.0, 100.0
	    index_1.width, index_1.height = 140.0, 100.0
	    math_2.width, math_2.height = 140.0, 100.0
	    position_1.width, position_1.height = 140.0, 100.0
	    rotate_vector.width, rotate_vector.height = 140.0, 100.0
	    set_position_001_2.width, set_position_001_2.height = 140.0, 100.0
	    group_001_1.width, group_001_1.height = 140.0, 100.0
	    group_002.width, group_002.height = 140.0, 100.0
	    sample_index_001_1.width, sample_index_001_1.height = 140.0, 100.0
	    index_001_1.width, index_001_1.height = 140.0, 100.0
	    position_002_3.width, position_002_3.height = 140.0, 100.0
	    group_input_001_2.width, group_input_001_2.height = 140.0, 100.0
	    group_input_003_1.width, group_input_003_1.height = 140.0, 100.0
	    combine_xyz_001_1.width, combine_xyz_001_1.height = 140.0, 100.0
	    separate_xyz_001_1.width, separate_xyz_001_1.height = 140.0, 100.0
	    math_001_1.width, math_001_1.height = 140.0, 100.0
	    math_002_1.width, math_002_1.height = 140.0, 100.0
	    set_position_004_1.width, set_position_004_1.height = 140.0, 100.0
	    group_004.width, group_004.height = 140.0, 100.0
	    separate_xyz_002.width, separate_xyz_002.height = 140.0, 100.0
	    compare_1.width, compare_1.height = 140.0, 100.0
	    boolean_math_2.width, boolean_math_2.height = 140.0, 100.0
	    curve_tangent_002.width, curve_tangent_002.height = 140.0, 100.0
	    align_rotation_to_vector_002.width, align_rotation_to_vector_002.height = 140.0, 100.0
	    rotate_vector_002.width, rotate_vector_002.height = 140.0, 100.0
	    set_position_005_1.width, set_position_005_1.height = 140.0, 100.0
	    group_005.width, group_005.height = 140.0, 100.0
	    switch_1.width, switch_1.height = 140.0, 100.0
	    switch_001_2.width, switch_001_2.height = 140.0, 100.0
	    frame_1.width, frame_1.height = 383.0, 462.0
	    group_input_002_2.width, group_input_002_2.height = 140.0, 100.0
	    group_input_004.width, group_input_004.height = 140.0, 100.0
	    twist_bun_bake.width, twist_bun_bake.height = 140.0, 100.0
	
	    #initialize twist_bun links
	    #curve_tangent_1.Tangent -> align_rotation_to_vector.Vector
	    twist_bun.links.new(curve_tangent_1.outputs[0], align_rotation_to_vector.inputs[2])
	    #group_input_2.Geometry -> resample_curve_1.Curve
	    twist_bun.links.new(group_input_2.outputs[0], resample_curve_1.inputs[0])
	    #group_1.Geometry -> sample_index_1.Geometry
	    twist_bun.links.new(group_1.outputs[0], sample_index_1.inputs[0])
	    #math_2.Value -> sample_index_1.Index
	    twist_bun.links.new(math_2.outputs[0], sample_index_1.inputs[2])
	    #index_1.Index -> math_2.Value
	    twist_bun.links.new(index_1.outputs[0], math_2.inputs[0])
	    #position_1.Position -> sample_index_1.Value
	    twist_bun.links.new(position_1.outputs[0], sample_index_1.inputs[1])
	    #sample_index_1.Value -> rotate_vector.Vector
	    twist_bun.links.new(sample_index_1.outputs[0], rotate_vector.inputs[0])
	    #align_rotation_to_vector.Rotation -> rotate_vector.Rotation
	    twist_bun.links.new(align_rotation_to_vector.outputs[0], rotate_vector.inputs[1])
	    #resample_curve_1.Curve -> set_position_001_2.Geometry
	    twist_bun.links.new(resample_curve_1.outputs[0], set_position_001_2.inputs[0])
	    #rotate_vector.Vector -> set_position_001_2.Position
	    twist_bun.links.new(rotate_vector.outputs[0], set_position_001_2.inputs[2])
	    #group_001_1.Root Position -> set_position_001_2.Offset
	    twist_bun.links.new(group_001_1.outputs[1], set_position_001_2.inputs[3])
	    #resample_curve_1.Curve -> sample_index_001_1.Geometry
	    twist_bun.links.new(resample_curve_1.outputs[0], sample_index_001_1.inputs[0])
	    #index_001_1.Index -> sample_index_001_1.Index
	    twist_bun.links.new(index_001_1.outputs[0], sample_index_001_1.inputs[2])
	    #position_002_3.Position -> sample_index_001_1.Value
	    twist_bun.links.new(position_002_3.outputs[0], sample_index_001_1.inputs[1])
	    #sample_index_001_1.Value -> group_002.Reference Position
	    twist_bun.links.new(sample_index_001_1.outputs[0], group_002.inputs[3])
	    #twist_bun_bake.Geometry -> group_output_4.Geometry
	    twist_bun.links.new(twist_bun_bake.outputs[0], group_output_4.inputs[0])
	    #group_input_001_2.Control Points -> group_1.Control Points
	    twist_bun.links.new(group_input_001_2.outputs[1], group_1.inputs[0])
	    #group_input_003_1.Control Points -> math_2.Value
	    twist_bun.links.new(group_input_003_1.outputs[1], math_2.inputs[1])
	    #group_input_2.Control Points -> resample_curve_1.Count
	    twist_bun.links.new(group_input_2.outputs[1], resample_curve_1.inputs[2])
	    #group_input_001_2.Offset Scale -> group_1.Offset Scale
	    twist_bun.links.new(group_input_001_2.outputs[2], group_1.inputs[1])
	    #group_input_001_2.Rotate -> group_1.Rotate
	    twist_bun.links.new(group_input_001_2.outputs[3], group_1.inputs[2])
	    #group_input_001_2.Scale -> group_1.Scale
	    twist_bun.links.new(group_input_001_2.outputs[4], group_1.inputs[3])
	    #separate_xyz_001_1.X -> combine_xyz_001_1.X
	    twist_bun.links.new(separate_xyz_001_1.outputs[0], combine_xyz_001_1.inputs[0])
	    #sample_index_1.Value -> separate_xyz_001_1.Vector
	    twist_bun.links.new(sample_index_1.outputs[0], separate_xyz_001_1.inputs[0])
	    #separate_xyz_001_1.Y -> math_001_1.Value
	    twist_bun.links.new(separate_xyz_001_1.outputs[1], math_001_1.inputs[0])
	    #math_001_1.Value -> combine_xyz_001_1.Y
	    twist_bun.links.new(math_001_1.outputs[0], combine_xyz_001_1.inputs[1])
	    #separate_xyz_001_1.Z -> math_002_1.Value
	    twist_bun.links.new(separate_xyz_001_1.outputs[2], math_002_1.inputs[0])
	    #resample_curve_1.Curve -> set_position_004_1.Geometry
	    twist_bun.links.new(resample_curve_1.outputs[0], set_position_004_1.inputs[0])
	    #group_004.Root Position -> set_position_004_1.Offset
	    twist_bun.links.new(group_004.outputs[1], set_position_004_1.inputs[3])
	    #group_004.Root Position -> separate_xyz_002.Vector
	    twist_bun.links.new(group_004.outputs[1], separate_xyz_002.inputs[0])
	    #separate_xyz_002.X -> compare_1.A
	    twist_bun.links.new(separate_xyz_002.outputs[0], compare_1.inputs[0])
	    #compare_1.Result -> boolean_math_2.Boolean
	    twist_bun.links.new(compare_1.outputs[0], boolean_math_2.inputs[0])
	    #curve_tangent_002.Tangent -> align_rotation_to_vector_002.Vector
	    twist_bun.links.new(curve_tangent_002.outputs[0], align_rotation_to_vector_002.inputs[2])
	    #align_rotation_to_vector_002.Rotation -> rotate_vector_002.Rotation
	    twist_bun.links.new(align_rotation_to_vector_002.outputs[0], rotate_vector_002.inputs[1])
	    #combine_xyz_001_1.Vector -> rotate_vector_002.Vector
	    twist_bun.links.new(combine_xyz_001_1.outputs[0], rotate_vector_002.inputs[0])
	    #group_005.Root Position -> set_position_005_1.Offset
	    twist_bun.links.new(group_005.outputs[1], set_position_005_1.inputs[3])
	    #rotate_vector_002.Vector -> set_position_005_1.Position
	    twist_bun.links.new(rotate_vector_002.outputs[0], set_position_005_1.inputs[2])
	    #rotate_vector.Vector -> set_position_004_1.Position
	    twist_bun.links.new(rotate_vector.outputs[0], set_position_004_1.inputs[2])
	    #compare_1.Result -> set_position_004_1.Selection
	    twist_bun.links.new(compare_1.outputs[0], set_position_004_1.inputs[1])
	    #boolean_math_2.Boolean -> set_position_005_1.Selection
	    twist_bun.links.new(boolean_math_2.outputs[0], set_position_005_1.inputs[1])
	    #set_position_004_1.Geometry -> set_position_005_1.Geometry
	    twist_bun.links.new(set_position_004_1.outputs[0], set_position_005_1.inputs[0])
	    #set_position_005_1.Geometry -> switch_1.True
	    twist_bun.links.new(set_position_005_1.outputs[0], switch_1.inputs[2])
	    #separate_xyz_001_1.Z -> switch_001_2.False
	    twist_bun.links.new(separate_xyz_001_1.outputs[2], switch_001_2.inputs[1])
	    #math_002_1.Value -> switch_001_2.True
	    twist_bun.links.new(math_002_1.outputs[0], switch_001_2.inputs[2])
	    #switch_001_2.Output -> combine_xyz_001_1.Z
	    twist_bun.links.new(switch_001_2.outputs[0], combine_xyz_001_1.inputs[2])
	    #set_position_001_2.Geometry -> switch_1.False
	    twist_bun.links.new(set_position_001_2.outputs[0], switch_1.inputs[1])
	    #switch_1.Output -> group_002.Curves
	    twist_bun.links.new(switch_1.outputs[0], group_002.inputs[0])
	    #group_input_002_2.Flip X -> switch_1.Switch
	    twist_bun.links.new(group_input_002_2.outputs[5], switch_1.inputs[0])
	    #group_input_004.Flip Overhang -> switch_001_2.Switch
	    twist_bun.links.new(group_input_004.outputs[6], switch_001_2.inputs[0])
	    #group_002.Curves -> twist_bun_bake.Geometry
	    twist_bun.links.new(group_002.outputs[0], twist_bun_bake.inputs[0])
	    return twist_bun
	
	twist_bun = twist_bun_node_group()
	
	#initialize mesh_strip node group
	def mesh_strip_node_group():
	    mesh_strip = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "MESH_STRIP")
	
	    mesh_strip.color_tag = 'NONE'
	    mesh_strip.description = "Convert curve into a mesh strip."
	    mesh_strip.default_group_node_width = 140
	    
	
	    mesh_strip.is_modifier = True
	
	    #mesh_strip interface
	    #Socket Geometry
	    geometry_socket_3 = mesh_strip.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_3.attribute_domain = 'POINT'
	    geometry_socket_3.description = "Mesh strip."
	
	    #Socket Geometry
	    geometry_socket_4 = mesh_strip.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_4.attribute_domain = 'POINT'
	    geometry_socket_4.description = "Hair Curve."
	
	    #Socket Width
	    width_socket = mesh_strip.interface.new_socket(name = "Width", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    width_socket.default_value = 0.10000000149011612
	    width_socket.min_value = 0.0
	    width_socket.max_value = 3.4028234663852886e+38
	    width_socket.subtype = 'DISTANCE'
	    width_socket.attribute_domain = 'POINT'
	    width_socket.description = "Width of mesh strip."
	
	    #Socket Shade Smooth
	    shade_smooth_socket = mesh_strip.interface.new_socket(name = "Shade Smooth", in_out='INPUT', socket_type = 'NodeSocketBool')
	    shade_smooth_socket.default_value = True
	    shade_smooth_socket.attribute_domain = 'POINT'
	    shade_smooth_socket.description = "Mesh smooth shading."
	
	    #Socket Material
	    material_socket = mesh_strip.interface.new_socket(name = "Material", in_out='INPUT', socket_type = 'NodeSocketMaterial')
	    material_socket.attribute_domain = 'POINT'
	    material_socket.description = "Mesh material."
	
	
	    #initialize mesh_strip nodes
	    #node Group Output
	    group_output_5 = mesh_strip.nodes.new("NodeGroupOutput")
	    group_output_5.name = "Group Output"
	    group_output_5.is_active_output = True
	    group_output_5.inputs[1].hide = True
	
	    #node Group Input
	    group_input_3 = mesh_strip.nodes.new("NodeGroupInput")
	    group_input_3.name = "Group Input"
	    group_input_3.outputs[0].hide = True
	    group_input_3.outputs[2].hide = True
	    group_input_3.outputs[3].hide = True
	    group_input_3.outputs[4].hide = True
	
	    #node Curve to Mesh
	    curve_to_mesh_1 = mesh_strip.nodes.new("GeometryNodeCurveToMesh")
	    curve_to_mesh_1.name = "Curve to Mesh"
	    curve_to_mesh_1.hide = True
	    curve_to_mesh_1.inputs[2].hide = True
	    #Fill Caps
	    curve_to_mesh_1.inputs[2].default_value = False
	
	    #node Curve Line
	    curve_line = mesh_strip.nodes.new("GeometryNodeCurvePrimitiveLine")
	    curve_line.name = "Curve Line"
	    curve_line.hide = True
	    curve_line.mode = 'DIRECTION'
	    curve_line.inputs[1].hide = True
	    curve_line.inputs[2].hide = True
	    #Direction
	    curve_line.inputs[2].default_value = (0.0, 1.0, 0.0)
	
	    #node Combine XYZ.001
	    combine_xyz_001_2 = mesh_strip.nodes.new("ShaderNodeCombineXYZ")
	    combine_xyz_001_2.name = "Combine XYZ.001"
	    combine_xyz_001_2.hide = True
	    combine_xyz_001_2.inputs[0].hide = True
	    combine_xyz_001_2.inputs[2].hide = True
	    #X
	    combine_xyz_001_2.inputs[0].default_value = 0.0
	    #Z
	    combine_xyz_001_2.inputs[2].default_value = 0.0
	
	    #node Math.001
	    math_001_2 = mesh_strip.nodes.new("ShaderNodeMath")
	    math_001_2.name = "Math.001"
	    math_001_2.hide = True
	    math_001_2.operation = 'MULTIPLY'
	    math_001_2.use_clamp = False
	    math_001_2.inputs[1].hide = True
	    math_001_2.inputs[2].hide = True
	    #Value_001
	    math_001_2.inputs[1].default_value = -0.5
	
	    #node Set Shade Smooth
	    set_shade_smooth = mesh_strip.nodes.new("GeometryNodeSetShadeSmooth")
	    set_shade_smooth.name = "Set Shade Smooth"
	    set_shade_smooth.hide = True
	    set_shade_smooth.domain = 'FACE'
	    set_shade_smooth.inputs[1].hide = True
	    #Selection
	    set_shade_smooth.inputs[1].default_value = True
	
	    #node Capture Attribute
	    capture_attribute = mesh_strip.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute.name = "Capture Attribute"
	    capture_attribute.hide = True
	    capture_attribute.active_index = 0
	    capture_attribute.capture_items.clear()
	    capture_attribute.capture_items.new('FLOAT', "Factor")
	    capture_attribute.capture_items["Factor"].data_type = 'FLOAT'
	    capture_attribute.domain = 'POINT'
	    capture_attribute.inputs[2].hide = True
	    capture_attribute.outputs[2].hide = True
	
	    #node Store Named Attribute
	    store_named_attribute = mesh_strip.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute.name = "Store Named Attribute"
	    store_named_attribute.data_type = 'FLOAT2'
	    store_named_attribute.domain = 'CORNER'
	    #Selection
	    store_named_attribute.inputs[1].default_value = True
	    #Name
	    store_named_attribute.inputs[2].default_value = "UVMap"
	
	    #node Set Material
	    set_material = mesh_strip.nodes.new("GeometryNodeSetMaterial")
	    set_material.name = "Set Material"
	    set_material.hide = True
	    #Selection
	    set_material.inputs[1].default_value = True
	
	    #node Capture Attribute.002
	    capture_attribute_002 = mesh_strip.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_002.name = "Capture Attribute.002"
	    capture_attribute_002.hide = True
	    capture_attribute_002.active_index = 0
	    capture_attribute_002.capture_items.clear()
	    capture_attribute_002.capture_items.new('FLOAT', "Factor")
	    capture_attribute_002.capture_items["Factor"].data_type = 'FLOAT'
	    capture_attribute_002.domain = 'POINT'
	    capture_attribute_002.inputs[2].hide = True
	    capture_attribute_002.outputs[2].hide = True
	
	    #node Spline Parameter.001
	    spline_parameter_001_1 = mesh_strip.nodes.new("GeometryNodeSplineParameter")
	    spline_parameter_001_1.name = "Spline Parameter.001"
	    spline_parameter_001_1.outputs[1].hide = True
	    spline_parameter_001_1.outputs[2].hide = True
	
	    #node Combine XYZ.003
	    combine_xyz_003_1 = mesh_strip.nodes.new("ShaderNodeCombineXYZ")
	    combine_xyz_003_1.name = "Combine XYZ.003"
	    combine_xyz_003_1.hide = True
	    combine_xyz_003_1.inputs[2].hide = True
	    #Z
	    combine_xyz_003_1.inputs[2].default_value = 0.0
	
	    #node Group Input.001
	    group_input_001_3 = mesh_strip.nodes.new("NodeGroupInput")
	    group_input_001_3.name = "Group Input.001"
	    group_input_001_3.outputs[0].hide = True
	    group_input_001_3.outputs[1].hide = True
	    group_input_001_3.outputs[2].hide = True
	    group_input_001_3.outputs[4].hide = True
	
	    #node Group Input.002
	    group_input_002_3 = mesh_strip.nodes.new("NodeGroupInput")
	    group_input_002_3.name = "Group Input.002"
	    group_input_002_3.outputs[0].hide = True
	    group_input_002_3.outputs[1].hide = True
	    group_input_002_3.outputs[3].hide = True
	    group_input_002_3.outputs[4].hide = True
	
	    #node Group Input.003
	    group_input_003_2 = mesh_strip.nodes.new("NodeGroupInput")
	    group_input_003_2.name = "Group Input.003"
	    group_input_003_2.outputs[1].hide = True
	    group_input_003_2.outputs[2].hide = True
	    group_input_003_2.outputs[3].hide = True
	    group_input_003_2.outputs[4].hide = True
	
	    #node Set Curve Radius
	    set_curve_radius = mesh_strip.nodes.new("GeometryNodeSetCurveRadius")
	    set_curve_radius.name = "Set Curve Radius"
	    set_curve_radius.hide = True
	    set_curve_radius.inputs[1].hide = True
	    #Selection
	    set_curve_radius.inputs[1].default_value = True
	
	    #node Mesh Shape
	    mesh_shape = mesh_strip.nodes.new("ShaderNodeFloatCurve")
	    mesh_shape.label = "Mesh Shape"
	    mesh_shape.name = "Mesh Shape"
	    #mapping settings
	    mesh_shape.mapping.extend = 'EXTRAPOLATED'
	    mesh_shape.mapping.tone = 'STANDARD'
	    mesh_shape.mapping.black_level = (0.0, 0.0, 0.0)
	    mesh_shape.mapping.white_level = (1.0, 1.0, 1.0)
	    mesh_shape.mapping.clip_min_x = 0.0
	    mesh_shape.mapping.clip_min_y = 0.0
	    mesh_shape.mapping.clip_max_x = 1.0
	    mesh_shape.mapping.clip_max_y = 1.0
	    mesh_shape.mapping.use_clip = True
	    #curve 0
	    mesh_shape_curve_0 = mesh_shape.mapping.curves[0]
	    mesh_shape_curve_0_point_0 = mesh_shape_curve_0.points[0]
	    mesh_shape_curve_0_point_0.location = (0.0, 1.0)
	    mesh_shape_curve_0_point_0.handle_type = 'AUTO'
	    mesh_shape_curve_0_point_1 = mesh_shape_curve_0.points[1]
	    mesh_shape_curve_0_point_1.location = (1.0, 1.0)
	    mesh_shape_curve_0_point_1.handle_type = 'AUTO'
	    #update curve after changes
	    mesh_shape.mapping.update()
	    mesh_shape.inputs[0].hide = True
	    #Factor
	    mesh_shape.inputs[0].default_value = 1.0
	
	    #node Spline Parameter.002
	    spline_parameter_002_1 = mesh_strip.nodes.new("GeometryNodeSplineParameter")
	    spline_parameter_002_1.name = "Spline Parameter.002"
	    spline_parameter_002_1.outputs[1].hide = True
	    spline_parameter_002_1.outputs[2].hide = True
	
	    #node Mesh Bake
	    mesh_bake = mesh_strip.nodes.new("GeometryNodeBake")
	    mesh_bake.label = "Mesh Bake"
	    mesh_bake.name = "Mesh Bake"
	    mesh_bake.active_index = 0
	    mesh_bake.bake_items.clear()
	    mesh_bake.bake_items.new('GEOMETRY', "Geometry")
	    mesh_bake.bake_items[0].attribute_domain = 'POINT'
	    mesh_bake.inputs[1].hide = True
	    mesh_bake.outputs[1].hide = True
	
	    #node Separate Components
	    separate_components = mesh_strip.nodes.new("GeometryNodeSeparateComponents")
	    separate_components.name = "Separate Components"
	    separate_components.hide = True
	
	    #node Join Geometry
	    join_geometry_1 = mesh_strip.nodes.new("GeometryNodeJoinGeometry")
	    join_geometry_1.name = "Join Geometry"
	
	    #node Reroute
	    reroute_2 = mesh_strip.nodes.new("NodeReroute")
	    reroute_2.name = "Reroute"
	    reroute_2.socket_idname = "NodeSocketGeometry"
	    #node Reroute.001
	    reroute_001_1 = mesh_strip.nodes.new("NodeReroute")
	    reroute_001_1.name = "Reroute.001"
	    reroute_001_1.socket_idname = "NodeSocketGeometry"
	    #node Reroute.002
	    reroute_002 = mesh_strip.nodes.new("NodeReroute")
	    reroute_002.name = "Reroute.002"
	    reroute_002.socket_idname = "NodeSocketGeometry"
	    #node Reroute.003
	    reroute_003 = mesh_strip.nodes.new("NodeReroute")
	    reroute_003.name = "Reroute.003"
	    reroute_003.socket_idname = "NodeSocketGeometry"
	    #node Reroute.004
	    reroute_004_1 = mesh_strip.nodes.new("NodeReroute")
	    reroute_004_1.name = "Reroute.004"
	    reroute_004_1.socket_idname = "NodeSocketGeometry"
	    #node Reroute.005
	    reroute_005_1 = mesh_strip.nodes.new("NodeReroute")
	    reroute_005_1.name = "Reroute.005"
	    reroute_005_1.socket_idname = "NodeSocketGeometry"
	    #node Reroute.006
	    reroute_006_1 = mesh_strip.nodes.new("NodeReroute")
	    reroute_006_1.name = "Reroute.006"
	    reroute_006_1.socket_idname = "NodeSocketGeometry"
	    #node Reroute.007
	    reroute_007_1 = mesh_strip.nodes.new("NodeReroute")
	    reroute_007_1.name = "Reroute.007"
	    reroute_007_1.socket_idname = "NodeSocketGeometry"
	    #node Reroute.008
	    reroute_008_1 = mesh_strip.nodes.new("NodeReroute")
	    reroute_008_1.name = "Reroute.008"
	    reroute_008_1.socket_idname = "NodeSocketGeometry"
	    #node Reroute.009
	    reroute_009_1 = mesh_strip.nodes.new("NodeReroute")
	    reroute_009_1.name = "Reroute.009"
	    reroute_009_1.socket_idname = "NodeSocketGeometry"
	
	
	
	
	    #Set locations
	    group_output_5.location = (944.61669921875, 92.7010498046875)
	    group_input_3.location = (-562.1895141601562, 29.572296142578125)
	    curve_to_mesh_1.location = (32.7371826171875, 50.001190185546875)
	    curve_line.location = (-361.7039794921875, -25.414398193359375)
	    combine_xyz_001_2.location = (-361.2547607421875, 9.869476318359375)
	    math_001_2.location = (-362.18951416015625, 46.61334228515625)
	    set_shade_smooth.location = (33.899169921875, 12.753509521484375)
	    capture_attribute.location = (-177.2156982421875, 9.4949951171875)
	    store_named_attribute.location = (200.96240234375, 83.67747497558594)
	    set_material.location = (362.189453125, 47.34906005859375)
	    capture_attribute_002.location = (-180.4632568359375, -36.271575927734375)
	    spline_parameter_001_1.location = (-359.17535400390625, -57.465911865234375)
	    combine_xyz_003_1.location = (36.32861328125, -83.677490234375)
	    group_input_001_3.location = (361.3492736816406, 10.561531066894531)
	    group_input_002_3.location = (32.41766357421875, -16.898452758789062)
	    group_input_003_2.location = (-359.77008056640625, 162.04959106445312)
	    set_curve_radius.location = (-361.65057373046875, 84.4383544921875)
	    mesh_shape.location = (-814.0376586914062, 102.21343994140625)
	    spline_parameter_002_1.location = (-813.3016357421875, -192.83901977539062)
	    mesh_bake.location = (764.4188232421875, 139.30262756347656)
	    separate_components.location = (-358.1722106933594, 200.15603637695312)
	    join_geometry_1.location = (568.9017333984375, 92.25613403320312)
	    reroute_2.location = (-137.274658203125, 197.8334197998047)
	    reroute_001_1.location = (-137.274658203125, 187.42483520507812)
	    reroute_002.location = (-137.6398468017578, 203.5111083984375)
	    reroute_003.location = (-137.274658203125, 182.45799255371094)
	    reroute_004_1.location = (-137.274658203125, 192.48793029785156)
	    reroute_005_1.location = (452.4445495605469, 197.99574279785156)
	    reroute_006_1.location = (453.35614013671875, 203.01223754882812)
	    reroute_007_1.location = (452.365234375, 182.98611450195312)
	    reroute_008_1.location = (452.365234375, 192.98690795898438)
	    reroute_009_1.location = (452.365234375, 187.98529052734375)
	
	    #Set dimensions
	    group_output_5.width, group_output_5.height = 140.0, 100.0
	    group_input_3.width, group_input_3.height = 140.0, 100.0
	    curve_to_mesh_1.width, curve_to_mesh_1.height = 140.0, 100.0
	    curve_line.width, curve_line.height = 140.0, 100.0
	    combine_xyz_001_2.width, combine_xyz_001_2.height = 140.0, 100.0
	    math_001_2.width, math_001_2.height = 140.0, 100.0
	    set_shade_smooth.width, set_shade_smooth.height = 140.0, 100.0
	    capture_attribute.width, capture_attribute.height = 140.0, 100.0
	    store_named_attribute.width, store_named_attribute.height = 140.0, 100.0
	    set_material.width, set_material.height = 140.0, 100.0
	    capture_attribute_002.width, capture_attribute_002.height = 140.0, 100.0
	    spline_parameter_001_1.width, spline_parameter_001_1.height = 140.0, 100.0
	    combine_xyz_003_1.width, combine_xyz_003_1.height = 140.0, 100.0
	    group_input_001_3.width, group_input_001_3.height = 140.0, 100.0
	    group_input_002_3.width, group_input_002_3.height = 140.0, 100.0
	    group_input_003_2.width, group_input_003_2.height = 140.0, 100.0
	    set_curve_radius.width, set_curve_radius.height = 140.0, 100.0
	    mesh_shape.width, mesh_shape.height = 240.0, 100.0
	    spline_parameter_002_1.width, spline_parameter_002_1.height = 140.0, 100.0
	    mesh_bake.width, mesh_bake.height = 140.0, 100.0
	    separate_components.width, separate_components.height = 140.0, 100.0
	    join_geometry_1.width, join_geometry_1.height = 140.0, 100.0
	    reroute_2.width, reroute_2.height = 10.0, 100.0
	    reroute_001_1.width, reroute_001_1.height = 10.0, 100.0
	    reroute_002.width, reroute_002.height = 10.0, 100.0
	    reroute_003.width, reroute_003.height = 10.0, 100.0
	    reroute_004_1.width, reroute_004_1.height = 10.0, 100.0
	    reroute_005_1.width, reroute_005_1.height = 10.0, 100.0
	    reroute_006_1.width, reroute_006_1.height = 10.0, 100.0
	    reroute_007_1.width, reroute_007_1.height = 10.0, 100.0
	    reroute_008_1.width, reroute_008_1.height = 10.0, 100.0
	    reroute_009_1.width, reroute_009_1.height = 10.0, 100.0
	
	    #initialize mesh_strip links
	    #math_001_2.Value -> combine_xyz_001_2.Y
	    mesh_strip.links.new(math_001_2.outputs[0], combine_xyz_001_2.inputs[1])
	    #curve_line.Curve -> capture_attribute_002.Geometry
	    mesh_strip.links.new(curve_line.outputs[0], capture_attribute_002.inputs[0])
	    #set_shade_smooth.Geometry -> store_named_attribute.Geometry
	    mesh_strip.links.new(set_shade_smooth.outputs[0], store_named_attribute.inputs[0])
	    #capture_attribute_002.Geometry -> curve_to_mesh_1.Profile Curve
	    mesh_strip.links.new(capture_attribute_002.outputs[0], curve_to_mesh_1.inputs[1])
	    #spline_parameter_001_1.Factor -> capture_attribute_002.Factor
	    mesh_strip.links.new(spline_parameter_001_1.outputs[0], capture_attribute_002.inputs[1])
	    #capture_attribute_002.Factor -> combine_xyz_003_1.Y
	    mesh_strip.links.new(capture_attribute_002.outputs[1], combine_xyz_003_1.inputs[1])
	    #store_named_attribute.Geometry -> set_material.Geometry
	    mesh_strip.links.new(store_named_attribute.outputs[0], set_material.inputs[0])
	    #spline_parameter_001_1.Factor -> capture_attribute.Factor
	    mesh_strip.links.new(spline_parameter_001_1.outputs[0], capture_attribute.inputs[1])
	    #capture_attribute.Factor -> combine_xyz_003_1.X
	    mesh_strip.links.new(capture_attribute.outputs[1], combine_xyz_003_1.inputs[0])
	    #capture_attribute.Geometry -> curve_to_mesh_1.Curve
	    mesh_strip.links.new(capture_attribute.outputs[0], curve_to_mesh_1.inputs[0])
	    #combine_xyz_003_1.Vector -> store_named_attribute.Value
	    mesh_strip.links.new(combine_xyz_003_1.outputs[0], store_named_attribute.inputs[3])
	    #curve_to_mesh_1.Mesh -> set_shade_smooth.Geometry
	    mesh_strip.links.new(curve_to_mesh_1.outputs[0], set_shade_smooth.inputs[0])
	    #combine_xyz_001_2.Vector -> curve_line.Start
	    mesh_strip.links.new(combine_xyz_001_2.outputs[0], curve_line.inputs[0])
	    #group_input_3.Width -> curve_line.Length
	    mesh_strip.links.new(group_input_3.outputs[1], curve_line.inputs[3])
	    #group_input_3.Width -> math_001_2.Value
	    mesh_strip.links.new(group_input_3.outputs[1], math_001_2.inputs[0])
	    #mesh_bake.Geometry -> group_output_5.Geometry
	    mesh_strip.links.new(mesh_bake.outputs[0], group_output_5.inputs[0])
	    #group_input_001_3.Material -> set_material.Material
	    mesh_strip.links.new(group_input_001_3.outputs[3], set_material.inputs[2])
	    #group_input_002_3.Shade Smooth -> set_shade_smooth.Shade Smooth
	    mesh_strip.links.new(group_input_002_3.outputs[2], set_shade_smooth.inputs[2])
	    #spline_parameter_002_1.Factor -> mesh_shape.Value
	    mesh_strip.links.new(spline_parameter_002_1.outputs[0], mesh_shape.inputs[1])
	    #mesh_shape.Value -> set_curve_radius.Radius
	    mesh_strip.links.new(mesh_shape.outputs[0], set_curve_radius.inputs[2])
	    #set_curve_radius.Curve -> capture_attribute.Geometry
	    mesh_strip.links.new(set_curve_radius.outputs[0], capture_attribute.inputs[0])
	    #group_input_003_2.Geometry -> separate_components.Geometry
	    mesh_strip.links.new(group_input_003_2.outputs[0], separate_components.inputs[0])
	    #separate_components.Curve -> set_curve_radius.Curve
	    mesh_strip.links.new(separate_components.outputs[1], set_curve_radius.inputs[0])
	    #reroute_007_1.Output -> join_geometry_1.Geometry
	    mesh_strip.links.new(reroute_007_1.outputs[0], join_geometry_1.inputs[0])
	    #separate_components.Grease Pencil -> reroute_2.Input
	    mesh_strip.links.new(separate_components.outputs[2], reroute_2.inputs[0])
	    #separate_components.Volume -> reroute_001_1.Input
	    mesh_strip.links.new(separate_components.outputs[4], reroute_001_1.inputs[0])
	    #separate_components.Mesh -> reroute_002.Input
	    mesh_strip.links.new(separate_components.outputs[0], reroute_002.inputs[0])
	    #separate_components.Instances -> reroute_003.Input
	    mesh_strip.links.new(separate_components.outputs[5], reroute_003.inputs[0])
	    #separate_components.Point Cloud -> reroute_004_1.Input
	    mesh_strip.links.new(separate_components.outputs[3], reroute_004_1.inputs[0])
	    #reroute_2.Output -> reroute_005_1.Input
	    mesh_strip.links.new(reroute_2.outputs[0], reroute_005_1.inputs[0])
	    #reroute_002.Output -> reroute_006_1.Input
	    mesh_strip.links.new(reroute_002.outputs[0], reroute_006_1.inputs[0])
	    #reroute_003.Output -> reroute_007_1.Input
	    mesh_strip.links.new(reroute_003.outputs[0], reroute_007_1.inputs[0])
	    #reroute_004_1.Output -> reroute_008_1.Input
	    mesh_strip.links.new(reroute_004_1.outputs[0], reroute_008_1.inputs[0])
	    #reroute_001_1.Output -> reroute_009_1.Input
	    mesh_strip.links.new(reroute_001_1.outputs[0], reroute_009_1.inputs[0])
	    #join_geometry_1.Geometry -> mesh_bake.Geometry
	    mesh_strip.links.new(join_geometry_1.outputs[0], mesh_bake.inputs[0])
	    #reroute_009_1.Output -> join_geometry_1.Geometry
	    mesh_strip.links.new(reroute_009_1.outputs[0], join_geometry_1.inputs[0])
	    #reroute_008_1.Output -> join_geometry_1.Geometry
	    mesh_strip.links.new(reroute_008_1.outputs[0], join_geometry_1.inputs[0])
	    #reroute_005_1.Output -> join_geometry_1.Geometry
	    mesh_strip.links.new(reroute_005_1.outputs[0], join_geometry_1.inputs[0])
	    #reroute_006_1.Output -> join_geometry_1.Geometry
	    mesh_strip.links.new(reroute_006_1.outputs[0], join_geometry_1.inputs[0])
	    #set_material.Geometry -> join_geometry_1.Geometry
	    mesh_strip.links.new(set_material.outputs[0], join_geometry_1.inputs[0])
	    return mesh_strip
	
	mesh_strip = mesh_strip_node_group()
	
	#initialize mesh_to_strands node group
	def mesh_to_strands_node_group():
	    mesh_to_strands = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "MESH_TO_STRANDS")
	
	    mesh_to_strands.color_tag = 'NONE'
	    mesh_to_strands.description = "Convert mesh with UV Map to hair curve strands."
	    mesh_to_strands.default_group_node_width = 140
	    
	
	
	    #mesh_to_strands interface
	    #Socket Geometry
	    geometry_socket_5 = mesh_to_strands.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_5.attribute_domain = 'POINT'
	    geometry_socket_5.description = "Hair Curve Strands made mesh."
	
	    #Socket Geometry
	    geometry_socket_6 = mesh_to_strands.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_6.attribute_domain = 'POINT'
	    geometry_socket_6.description = "Mesh object with UV Map."
	
	    #Socket Level
	    level_socket = mesh_to_strands.interface.new_socket(name = "Level", in_out='INPUT', socket_type = 'NodeSocketInt')
	    level_socket.default_value = 0
	    level_socket.min_value = 0
	    level_socket.max_value = 6
	    level_socket.subtype = 'NONE'
	    level_socket.attribute_domain = 'POINT'
	    level_socket.description = "Mesh subdivision level."
	
	    #Socket Material
	    material_socket_1 = mesh_to_strands.interface.new_socket(name = "Material", in_out='INPUT', socket_type = 'NodeSocketMaterial')
	    material_socket_1.attribute_domain = 'POINT'
	    material_socket_1.description = "Curve material."
	
	    #Socket Strand Radius
	    strand_radius_socket = mesh_to_strands.interface.new_socket(name = "Strand Radius", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    strand_radius_socket.default_value = 0.003000000026077032
	    strand_radius_socket.min_value = 0.0
	    strand_radius_socket.max_value = 10000.0
	    strand_radius_socket.subtype = 'NONE'
	    strand_radius_socket.attribute_domain = 'POINT'
	    strand_radius_socket.description = "Radius for hair strands."
	
	    #Socket Trim Seed
	    trim_seed_socket = mesh_to_strands.interface.new_socket(name = "Trim Seed", in_out='INPUT', socket_type = 'NodeSocketInt')
	    trim_seed_socket.default_value = 0
	    trim_seed_socket.min_value = -10000
	    trim_seed_socket.max_value = 10000
	    trim_seed_socket.subtype = 'NONE'
	    trim_seed_socket.attribute_domain = 'POINT'
	    trim_seed_socket.description = "Random seed for hair tip trimming."
	
	    #Socket Trim Factor
	    trim_factor_socket = mesh_to_strands.interface.new_socket(name = "Trim Factor", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    trim_factor_socket.default_value = 1.0
	    trim_factor_socket.min_value = 0.0
	    trim_factor_socket.max_value = 1.0
	    trim_factor_socket.subtype = 'FACTOR'
	    trim_factor_socket.attribute_domain = 'POINT'
	    trim_factor_socket.description = "Minumal percentage of hair strand length to remain after random trim. (1=no trim, 0=potential full trim)"
	
	    #Socket UV Map
	    uv_map_socket = mesh_to_strands.interface.new_socket(name = "UV Map", in_out='INPUT', socket_type = 'NodeSocketString')
	    uv_map_socket.default_value = "UVMap"
	    uv_map_socket.subtype = 'NONE'
	    uv_map_socket.attribute_domain = 'POINT'
	    uv_map_socket.description = "UV Map used to detrmine strand direction."
	
	
	    #initialize mesh_to_strands nodes
	    #node Group Output
	    group_output_6 = mesh_to_strands.nodes.new("NodeGroupOutput")
	    group_output_6.name = "Group Output"
	    group_output_6.is_active_output = True
	    group_output_6.inputs[1].hide = True
	
	    #node Group Input
	    group_input_4 = mesh_to_strands.nodes.new("NodeGroupInput")
	    group_input_4.name = "Group Input"
	    group_input_4.outputs[2].hide = True
	    group_input_4.outputs[3].hide = True
	    group_input_4.outputs[4].hide = True
	    group_input_4.outputs[5].hide = True
	    group_input_4.outputs[6].hide = True
	    group_input_4.outputs[7].hide = True
	
	    #node Shortest Edge Paths
	    shortest_edge_paths = mesh_to_strands.nodes.new("GeometryNodeInputShortestEdgePaths")
	    shortest_edge_paths.name = "Shortest Edge Paths"
	    shortest_edge_paths.inputs[1].hide = True
	    shortest_edge_paths.outputs[0].hide = True
	    #Edge Cost
	    shortest_edge_paths.inputs[1].default_value = 1.0
	
	    #node Edge Vertices
	    edge_vertices = mesh_to_strands.nodes.new("GeometryNodeInputMeshEdgeVertices")
	    edge_vertices.name = "Edge Vertices"
	    edge_vertices.outputs[2].hide = True
	    edge_vertices.outputs[3].hide = True
	
	    #node Evaluate at Index
	    evaluate_at_index = mesh_to_strands.nodes.new("GeometryNodeFieldAtIndex")
	    evaluate_at_index.name = "Evaluate at Index"
	    evaluate_at_index.data_type = 'INT'
	    evaluate_at_index.domain = 'POINT'
	
	    #node Evaluate at Index.001
	    evaluate_at_index_001 = mesh_to_strands.nodes.new("GeometryNodeFieldAtIndex")
	    evaluate_at_index_001.name = "Evaluate at Index.001"
	    evaluate_at_index_001.data_type = 'INT'
	    evaluate_at_index_001.domain = 'POINT'
	
	    #node Compare.002
	    compare_002_1 = mesh_to_strands.nodes.new("FunctionNodeCompare")
	    compare_002_1.name = "Compare.002"
	    compare_002_1.data_type = 'INT'
	    compare_002_1.mode = 'ELEMENT'
	    compare_002_1.operation = 'EQUAL'
	
	    #node Named Attribute
	    named_attribute_1 = mesh_to_strands.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute_1.name = "Named Attribute"
	    named_attribute_1.data_type = 'FLOAT_VECTOR'
	
	    #node Separate XYZ
	    separate_xyz_1 = mesh_to_strands.nodes.new("ShaderNodeSeparateXYZ")
	    separate_xyz_1.name = "Separate XYZ"
	    separate_xyz_1.outputs[1].hide = True
	    separate_xyz_1.outputs[2].hide = True
	
	    #node Compare.005
	    compare_005_1 = mesh_to_strands.nodes.new("FunctionNodeCompare")
	    compare_005_1.name = "Compare.005"
	    compare_005_1.data_type = 'FLOAT'
	    compare_005_1.mode = 'ELEMENT'
	    compare_005_1.operation = 'EQUAL'
	    compare_005_1.inputs[1].hide = True
	    compare_005_1.inputs[2].hide = True
	    compare_005_1.inputs[3].hide = True
	    compare_005_1.inputs[4].hide = True
	    compare_005_1.inputs[5].hide = True
	    compare_005_1.inputs[6].hide = True
	    compare_005_1.inputs[7].hide = True
	    compare_005_1.inputs[8].hide = True
	    compare_005_1.inputs[9].hide = True
	    compare_005_1.inputs[10].hide = True
	    compare_005_1.inputs[11].hide = True
	    compare_005_1.inputs[12].hide = True
	    #B
	    compare_005_1.inputs[1].default_value = 0.0
	    #Epsilon
	    compare_005_1.inputs[12].default_value = 0.0
	
	    #node Delete Geometry
	    delete_geometry = mesh_to_strands.nodes.new("GeometryNodeDeleteGeometry")
	    delete_geometry.name = "Delete Geometry"
	    delete_geometry.hide = True
	    delete_geometry.domain = 'EDGE'
	    delete_geometry.mode = 'ALL'
	
	    #node Mesh to Curve
	    mesh_to_curve_1 = mesh_to_strands.nodes.new("GeometryNodeMeshToCurve")
	    mesh_to_curve_1.name = "Mesh to Curve"
	    mesh_to_curve_1.hide = True
	    mesh_to_curve_1.inputs[1].hide = True
	    #Selection
	    mesh_to_curve_1.inputs[1].default_value = True
	
	    #node Subdivide Mesh
	    subdivide_mesh = mesh_to_strands.nodes.new("GeometryNodeSubdivideMesh")
	    subdivide_mesh.name = "Subdivide Mesh"
	
	    #node Set Material.002
	    set_material_002 = mesh_to_strands.nodes.new("GeometryNodeSetMaterial")
	    set_material_002.name = "Set Material.002"
	    set_material_002.inputs[1].hide = True
	    #Selection
	    set_material_002.inputs[1].default_value = True
	
	    #node Set Curve Radius
	    set_curve_radius_1 = mesh_to_strands.nodes.new("GeometryNodeSetCurveRadius")
	    set_curve_radius_1.name = "Set Curve Radius"
	    set_curve_radius_1.inputs[1].hide = True
	    #Selection
	    set_curve_radius_1.inputs[1].default_value = True
	
	    #node Map Range
	    map_range_1 = mesh_to_strands.nodes.new("ShaderNodeMapRange")
	    map_range_1.name = "Map Range"
	    map_range_1.hide = True
	    map_range_1.clamp = True
	    map_range_1.data_type = 'FLOAT'
	    map_range_1.interpolation_type = 'LINEAR'
	    map_range_1.inputs[1].hide = True
	    map_range_1.inputs[2].hide = True
	    map_range_1.inputs[3].hide = True
	    map_range_1.inputs[5].hide = True
	    map_range_1.inputs[6].hide = True
	    map_range_1.inputs[7].hide = True
	    map_range_1.inputs[8].hide = True
	    map_range_1.inputs[9].hide = True
	    map_range_1.inputs[10].hide = True
	    map_range_1.inputs[11].hide = True
	    map_range_1.outputs[1].hide = True
	    #From Min
	    map_range_1.inputs[1].default_value = 0.0
	    #From Max
	    map_range_1.inputs[2].default_value = 1.0
	    #To Min
	    map_range_1.inputs[3].default_value = 0.0
	
	    #node Map Range.001
	    map_range_001 = mesh_to_strands.nodes.new("ShaderNodeMapRange")
	    map_range_001.name = "Map Range.001"
	    map_range_001.hide = True
	    map_range_001.clamp = True
	    map_range_001.data_type = 'FLOAT'
	    map_range_001.interpolation_type = 'LINEAR'
	    map_range_001.inputs[1].hide = True
	    map_range_001.inputs[2].hide = True
	    map_range_001.inputs[4].hide = True
	    map_range_001.inputs[5].hide = True
	    map_range_001.inputs[6].hide = True
	    map_range_001.inputs[7].hide = True
	    map_range_001.inputs[8].hide = True
	    map_range_001.inputs[9].hide = True
	    map_range_001.inputs[10].hide = True
	    map_range_001.inputs[11].hide = True
	    map_range_001.outputs[1].hide = True
	    #From Min
	    map_range_001.inputs[1].default_value = 0.0
	    #From Max
	    map_range_001.inputs[2].default_value = 1.0
	    #To Max
	    map_range_001.inputs[4].default_value = 1.0
	
	    #node Trim Shape
	    trim_shape = mesh_to_strands.nodes.new("ShaderNodeFloatCurve")
	    trim_shape.label = "Trim Shape"
	    trim_shape.name = "Trim Shape"
	    #mapping settings
	    trim_shape.mapping.extend = 'EXTRAPOLATED'
	    trim_shape.mapping.tone = 'STANDARD'
	    trim_shape.mapping.black_level = (0.0, 0.0, 0.0)
	    trim_shape.mapping.white_level = (1.0, 1.0, 1.0)
	    trim_shape.mapping.clip_min_x = 0.0
	    trim_shape.mapping.clip_min_y = 0.0
	    trim_shape.mapping.clip_max_x = 1.0
	    trim_shape.mapping.clip_max_y = 1.0
	    trim_shape.mapping.use_clip = True
	    #curve 0
	    trim_shape_curve_0 = trim_shape.mapping.curves[0]
	    trim_shape_curve_0_point_0 = trim_shape_curve_0.points[0]
	    trim_shape_curve_0_point_0.location = (0.0, 0.0)
	    trim_shape_curve_0_point_0.handle_type = 'AUTO'
	    trim_shape_curve_0_point_1 = trim_shape_curve_0.points[1]
	    trim_shape_curve_0_point_1.location = (0.281818151473999, 0.16875001788139343)
	    trim_shape_curve_0_point_1.handle_type = 'AUTO'
	    trim_shape_curve_0_point_2 = trim_shape_curve_0.points.new(0.7136364579200745, 0.8625001907348633)
	    trim_shape_curve_0_point_2.handle_type = 'AUTO'
	    trim_shape_curve_0_point_3 = trim_shape_curve_0.points.new(1.0, 1.0)
	    trim_shape_curve_0_point_3.handle_type = 'AUTO'
	    #update curve after changes
	    trim_shape.mapping.update()
	    trim_shape.inputs[0].hide = True
	    #Factor
	    trim_shape.inputs[0].default_value = 1.0
	
	    #node Random Value
	    random_value = mesh_to_strands.nodes.new("FunctionNodeRandomValue")
	    random_value.name = "Random Value"
	    random_value.hide = True
	    random_value.data_type = 'FLOAT'
	    random_value.inputs[0].hide = True
	    random_value.inputs[1].hide = True
	    random_value.inputs[2].hide = True
	    random_value.inputs[3].hide = True
	    random_value.inputs[4].hide = True
	    random_value.inputs[5].hide = True
	    random_value.inputs[6].hide = True
	    random_value.inputs[7].hide = True
	    random_value.outputs[0].hide = True
	    random_value.outputs[2].hide = True
	    random_value.outputs[3].hide = True
	    #Min_001
	    random_value.inputs[2].default_value = 0.0
	    #Max_001
	    random_value.inputs[3].default_value = 1.0
	    #ID
	    random_value.inputs[7].default_value = 0
	
	    #node Strand Shape
	    strand_shape = mesh_to_strands.nodes.new("ShaderNodeFloatCurve")
	    strand_shape.label = "Strand Shape"
	    strand_shape.name = "Strand Shape"
	    #mapping settings
	    strand_shape.mapping.extend = 'EXTRAPOLATED'
	    strand_shape.mapping.tone = 'STANDARD'
	    strand_shape.mapping.black_level = (0.0, 0.0, 0.0)
	    strand_shape.mapping.white_level = (1.0, 1.0, 1.0)
	    strand_shape.mapping.clip_min_x = 0.0
	    strand_shape.mapping.clip_min_y = 0.0
	    strand_shape.mapping.clip_max_x = 1.0
	    strand_shape.mapping.clip_max_y = 1.0
	    strand_shape.mapping.use_clip = True
	    #curve 0
	    strand_shape_curve_0 = strand_shape.mapping.curves[0]
	    strand_shape_curve_0_point_0 = strand_shape_curve_0.points[0]
	    strand_shape_curve_0_point_0.location = (0.0, 1.0)
	    strand_shape_curve_0_point_0.handle_type = 'AUTO'
	    strand_shape_curve_0_point_1 = strand_shape_curve_0.points[1]
	    strand_shape_curve_0_point_1.location = (0.3227272033691406, 0.9187501072883606)
	    strand_shape_curve_0_point_1.handle_type = 'AUTO'
	    strand_shape_curve_0_point_2 = strand_shape_curve_0.points.new(0.6772727966308594, 0.15000002086162567)
	    strand_shape_curve_0_point_2.handle_type = 'AUTO'
	    strand_shape_curve_0_point_3 = strand_shape_curve_0.points.new(1.0, 0.0)
	    strand_shape_curve_0_point_3.handle_type = 'AUTO'
	    #update curve after changes
	    strand_shape.mapping.update()
	    strand_shape.inputs[0].hide = True
	    #Factor
	    strand_shape.inputs[0].default_value = 1.0
	
	    #node Hair Fadeout
	    hair_fadeout = mesh_to_strands.nodes.new("ShaderNodeValToRGB")
	    hair_fadeout.label = "Hair Fadeout"
	    hair_fadeout.name = "Hair Fadeout"
	    hair_fadeout.color_ramp.color_mode = 'RGB'
	    hair_fadeout.color_ramp.hue_interpolation = 'NEAR'
	    hair_fadeout.color_ramp.interpolation = 'LINEAR'
	
	    #initialize color ramp elements
	    hair_fadeout.color_ramp.elements.remove(hair_fadeout.color_ramp.elements[0])
	    hair_fadeout_cre_0 = hair_fadeout.color_ramp.elements[0]
	    hair_fadeout_cre_0.position = 0.0
	    hair_fadeout_cre_0.alpha = 1.0
	    hair_fadeout_cre_0.color = (0.0, 0.0, 0.0, 1.0)
	
	    hair_fadeout_cre_1 = hair_fadeout.color_ramp.elements.new(0.009999999776482582)
	    hair_fadeout_cre_1.alpha = 1.0
	    hair_fadeout_cre_1.color = (1.0, 1.0, 1.0, 1.0)
	
	    hair_fadeout_cre_2 = hair_fadeout.color_ramp.elements.new(0.949999988079071)
	    hair_fadeout_cre_2.alpha = 1.0
	    hair_fadeout_cre_2.color = (1.0, 1.0, 1.0, 1.0)
	
	    hair_fadeout_cre_3 = hair_fadeout.color_ramp.elements.new(1.0)
	    hair_fadeout_cre_3.alpha = 1.0
	    hair_fadeout_cre_3.color = (0.0, 0.0, 0.0, 1.0)
	
	    hair_fadeout.outputs[1].hide = True
	
	    #node Spline Parameter.002
	    spline_parameter_002_2 = mesh_to_strands.nodes.new("GeometryNodeSplineParameter")
	    spline_parameter_002_2.name = "Spline Parameter.002"
	    spline_parameter_002_2.outputs[1].hide = True
	    spline_parameter_002_2.outputs[2].hide = True
	
	    #node Frame.003
	    frame_003 = mesh_to_strands.nodes.new("NodeFrame")
	    frame_003.label = "Random Length | Strand Shape"
	    frame_003.name = "Frame.003"
	    frame_003.label_size = 20
	    frame_003.shrink = True
	
	    #node Map Range.002
	    map_range_002 = mesh_to_strands.nodes.new("ShaderNodeMapRange")
	    map_range_002.name = "Map Range.002"
	    map_range_002.hide = True
	    map_range_002.clamp = True
	    map_range_002.data_type = 'FLOAT'
	    map_range_002.interpolation_type = 'LINEAR'
	    map_range_002.inputs[1].hide = True
	    map_range_002.inputs[2].hide = True
	    map_range_002.inputs[3].hide = True
	    map_range_002.inputs[4].hide = True
	    map_range_002.inputs[5].hide = True
	    map_range_002.inputs[6].hide = True
	    map_range_002.inputs[7].hide = True
	    map_range_002.inputs[8].hide = True
	    map_range_002.inputs[9].hide = True
	    map_range_002.inputs[10].hide = True
	    map_range_002.inputs[11].hide = True
	    map_range_002.outputs[1].hide = True
	    #From Min
	    map_range_002.inputs[1].default_value = 0.0
	    #From Max
	    map_range_002.inputs[2].default_value = 1.0
	    #To Min
	    map_range_002.inputs[3].default_value = 1.0
	    #To Max
	    map_range_002.inputs[4].default_value = 0.0
	
	    #node Trim Curve
	    trim_curve = mesh_to_strands.nodes.new("GeometryNodeTrimCurve")
	    trim_curve.name = "Trim Curve"
	    trim_curve.mode = 'FACTOR'
	    trim_curve.inputs[1].hide = True
	    trim_curve.inputs[2].hide = True
	    trim_curve.inputs[4].hide = True
	    trim_curve.inputs[5].hide = True
	    #Selection
	    trim_curve.inputs[1].default_value = True
	    #Start
	    trim_curve.inputs[2].default_value = 0.0
	
	    #node Subdivide Bake
	    subdivide_bake = mesh_to_strands.nodes.new("GeometryNodeBake")
	    subdivide_bake.label = "Subdivide Bake"
	    subdivide_bake.name = "Subdivide Bake"
	    subdivide_bake.active_index = 0
	    subdivide_bake.bake_items.clear()
	    subdivide_bake.bake_items.new('GEOMETRY', "Geometry")
	    subdivide_bake.bake_items[0].attribute_domain = 'POINT'
	    subdivide_bake.inputs[1].hide = True
	    subdivide_bake.outputs[1].hide = True
	
	    #node Mesh to Strands Bake
	    mesh_to_strands_bake = mesh_to_strands.nodes.new("GeometryNodeBake")
	    mesh_to_strands_bake.label = "Mesh to Strands Bake"
	    mesh_to_strands_bake.name = "Mesh to Strands Bake"
	    mesh_to_strands_bake.active_index = 0
	    mesh_to_strands_bake.bake_items.clear()
	    mesh_to_strands_bake.bake_items.new('GEOMETRY', "Geometry")
	    mesh_to_strands_bake.bake_items[0].attribute_domain = 'POINT'
	    mesh_to_strands_bake.inputs[1].hide = True
	    mesh_to_strands_bake.outputs[1].hide = True
	
	    #node Group Input.001
	    group_input_001_4 = mesh_to_strands.nodes.new("NodeGroupInput")
	    group_input_001_4.name = "Group Input.001"
	    group_input_001_4.outputs[0].hide = True
	    group_input_001_4.outputs[1].hide = True
	    group_input_001_4.outputs[2].hide = True
	    group_input_001_4.outputs[4].hide = True
	    group_input_001_4.outputs[5].hide = True
	    group_input_001_4.outputs[6].hide = True
	    group_input_001_4.outputs[7].hide = True
	
	    #node Group Input.002
	    group_input_002_4 = mesh_to_strands.nodes.new("NodeGroupInput")
	    group_input_002_4.name = "Group Input.002"
	    group_input_002_4.outputs[0].hide = True
	    group_input_002_4.outputs[1].hide = True
	    group_input_002_4.outputs[3].hide = True
	    group_input_002_4.outputs[4].hide = True
	    group_input_002_4.outputs[5].hide = True
	    group_input_002_4.outputs[6].hide = True
	    group_input_002_4.outputs[7].hide = True
	
	    #node Group Input.003
	    group_input_003_3 = mesh_to_strands.nodes.new("NodeGroupInput")
	    group_input_003_3.name = "Group Input.003"
	    group_input_003_3.outputs[0].hide = True
	    group_input_003_3.outputs[1].hide = True
	    group_input_003_3.outputs[2].hide = True
	    group_input_003_3.outputs[3].hide = True
	    group_input_003_3.outputs[4].hide = True
	    group_input_003_3.outputs[6].hide = True
	    group_input_003_3.outputs[7].hide = True
	
	    #node Group Input.004
	    group_input_004_1 = mesh_to_strands.nodes.new("NodeGroupInput")
	    group_input_004_1.name = "Group Input.004"
	    group_input_004_1.outputs[0].hide = True
	    group_input_004_1.outputs[1].hide = True
	    group_input_004_1.outputs[2].hide = True
	    group_input_004_1.outputs[3].hide = True
	    group_input_004_1.outputs[5].hide = True
	    group_input_004_1.outputs[6].hide = True
	    group_input_004_1.outputs[7].hide = True
	
	    #node Group Input.005
	    group_input_005_1 = mesh_to_strands.nodes.new("NodeGroupInput")
	    group_input_005_1.name = "Group Input.005"
	    group_input_005_1.outputs[0].hide = True
	    group_input_005_1.outputs[1].hide = True
	    group_input_005_1.outputs[2].hide = True
	    group_input_005_1.outputs[3].hide = True
	    group_input_005_1.outputs[4].hide = True
	    group_input_005_1.outputs[5].hide = True
	    group_input_005_1.outputs[7].hide = True
	
	
	
	
	    #Set parents
	    map_range_001.parent = frame_003
	    trim_shape.parent = frame_003
	    random_value.parent = frame_003
	    strand_shape.parent = frame_003
	    hair_fadeout.parent = frame_003
	    spline_parameter_002_2.parent = frame_003
	    map_range_002.parent = frame_003
	    group_input_003_3.parent = frame_003
	    group_input_004_1.parent = frame_003
	
	    #Set locations
	    group_output_6.location = (-311.6728515625, 182.35992431640625)
	    group_input_4.location = (-1495.008056640625, -70.43521118164062)
	    shortest_edge_paths.location = (-1879.842041015625, -309.317626953125)
	    edge_vertices.location = (-1878.0546875, -216.49757385253906)
	    evaluate_at_index.location = (-1684.451904296875, -141.1178741455078)
	    evaluate_at_index_001.location = (-1684.282958984375, -305.86328125)
	    compare_002_1.location = (-1490.848876953125, -163.2925567626953)
	    named_attribute_1.location = (-2385.718017578125, -331.6299133300781)
	    separate_xyz_1.location = (-2211.636962890625, -353.7036437988281)
	    compare_005_1.location = (-2046.370361328125, -333.7033996582031)
	    delete_geometry.location = (-1312.639404296875, 103.10943603515625)
	    mesh_to_curve_1.location = (-1311.537109375, 139.97247314453125)
	    subdivide_mesh.location = (-1312.422119140625, -46.22938537597656)
	    set_material_002.location = (-1104.4716796875, 190.73081970214844)
	    set_curve_radius_1.location = (-675.178955078125, 182.86843872070312)
	    map_range_1.location = (-676.05224609375, 73.86978149414062)
	    map_range_001.location = (675.9549560546875, -73.31365966796875)
	    trim_shape.location = (412.5455322265625, -40.33319091796875)
	    random_value.location = (250.141845703125, -305.07757568359375)
	    strand_shape.location = (707.562744140625, -340.84307861328125)
	    hair_fadeout.location = (192.409423828125, -414.34478759765625)
	    spline_parameter_002_2.location = (30.21435546875, -553.3194580078125)
	    frame_003.location = (-2441.0, -479.0)
	    map_range_002.location = (528.3743896484375, -604.0279541015625)
	    trim_curve.location = (-887.9752197265625, 157.05897521972656)
	    subdivide_bake.location = (-1313.263916015625, 72.80914306640625)
	    mesh_to_strands_bake.location = (-488.5013122558594, 230.3529815673828)
	    group_input_001_4.location = (-677.0774536132812, 41.92536926269531)
	    group_input_002_4.location = (-1106.1558837890625, 88.88201904296875)
	    group_input_003_3.location = (674.4658203125, -102.9271240234375)
	    group_input_004_1.location = (71.07421875, -279.01458740234375)
	    group_input_005_1.location = (-2557.647705078125, -402.4859924316406)
	
	    #Set dimensions
	    group_output_6.width, group_output_6.height = 140.0, 100.0
	    group_input_4.width, group_input_4.height = 140.0, 100.0
	    shortest_edge_paths.width, shortest_edge_paths.height = 140.0, 100.0
	    edge_vertices.width, edge_vertices.height = 140.0, 100.0
	    evaluate_at_index.width, evaluate_at_index.height = 140.0, 100.0
	    evaluate_at_index_001.width, evaluate_at_index_001.height = 140.0, 100.0
	    compare_002_1.width, compare_002_1.height = 140.0, 100.0
	    named_attribute_1.width, named_attribute_1.height = 140.0, 100.0
	    separate_xyz_1.width, separate_xyz_1.height = 140.0, 100.0
	    compare_005_1.width, compare_005_1.height = 140.0, 100.0
	    delete_geometry.width, delete_geometry.height = 140.0, 100.0
	    mesh_to_curve_1.width, mesh_to_curve_1.height = 140.0, 100.0
	    subdivide_mesh.width, subdivide_mesh.height = 140.0, 100.0
	    set_material_002.width, set_material_002.height = 140.0, 100.0
	    set_curve_radius_1.width, set_curve_radius_1.height = 140.0, 100.0
	    map_range_1.width, map_range_1.height = 140.0, 100.0
	    map_range_001.width, map_range_001.height = 140.0, 100.0
	    trim_shape.width, trim_shape.height = 240.0, 100.0
	    random_value.width, random_value.height = 140.0, 100.0
	    strand_shape.width, strand_shape.height = 240.0, 100.0
	    hair_fadeout.width, hair_fadeout.height = 240.0, 100.0
	    spline_parameter_002_2.width, spline_parameter_002_2.height = 140.0, 100.0
	    frame_003.width, frame_003.height = 978.0, 660.0
	    map_range_002.width, map_range_002.height = 140.0, 100.0
	    trim_curve.width, trim_curve.height = 140.0, 100.0
	    subdivide_bake.width, subdivide_bake.height = 140.0, 100.0
	    mesh_to_strands_bake.width, mesh_to_strands_bake.height = 140.0, 100.0
	    group_input_001_4.width, group_input_001_4.height = 140.0, 100.0
	    group_input_002_4.width, group_input_002_4.height = 140.0, 100.0
	    group_input_003_3.width, group_input_003_3.height = 140.0, 100.0
	    group_input_004_1.width, group_input_004_1.height = 140.0, 100.0
	    group_input_005_1.width, group_input_005_1.height = 140.0, 100.0
	
	    #initialize mesh_to_strands links
	    #map_range_001.Result -> trim_curve.End
	    mesh_to_strands.links.new(map_range_001.outputs[0], trim_curve.inputs[3])
	    #compare_002_1.Result -> delete_geometry.Selection
	    mesh_to_strands.links.new(compare_002_1.outputs[0], delete_geometry.inputs[1])
	    #set_material_002.Geometry -> trim_curve.Curve
	    mesh_to_strands.links.new(set_material_002.outputs[0], trim_curve.inputs[0])
	    #shortest_edge_paths.Total Cost -> evaluate_at_index.Value
	    mesh_to_strands.links.new(shortest_edge_paths.outputs[1], evaluate_at_index.inputs[1])
	    #map_range_002.Result -> strand_shape.Value
	    mesh_to_strands.links.new(map_range_002.outputs[0], strand_shape.inputs[1])
	    #compare_005_1.Result -> shortest_edge_paths.End Vertex
	    mesh_to_strands.links.new(compare_005_1.outputs[0], shortest_edge_paths.inputs[0])
	    #hair_fadeout.Color -> map_range_002.Value
	    mesh_to_strands.links.new(hair_fadeout.outputs[0], map_range_002.inputs[0])
	    #shortest_edge_paths.Total Cost -> evaluate_at_index_001.Value
	    mesh_to_strands.links.new(shortest_edge_paths.outputs[1], evaluate_at_index_001.inputs[1])
	    #spline_parameter_002_2.Factor -> hair_fadeout.Fac
	    mesh_to_strands.links.new(spline_parameter_002_2.outputs[0], hair_fadeout.inputs[0])
	    #evaluate_at_index.Value -> compare_002_1.A
	    mesh_to_strands.links.new(evaluate_at_index.outputs[0], compare_002_1.inputs[2])
	    #random_value.Value -> trim_shape.Value
	    mesh_to_strands.links.new(random_value.outputs[1], trim_shape.inputs[1])
	    #evaluate_at_index_001.Value -> compare_002_1.B
	    mesh_to_strands.links.new(evaluate_at_index_001.outputs[0], compare_002_1.inputs[3])
	    #trim_shape.Value -> map_range_001.Value
	    mesh_to_strands.links.new(trim_shape.outputs[0], map_range_001.inputs[0])
	    #edge_vertices.Vertex Index 1 -> evaluate_at_index.Index
	    mesh_to_strands.links.new(edge_vertices.outputs[0], evaluate_at_index.inputs[0])
	    #map_range_1.Result -> set_curve_radius_1.Radius
	    mesh_to_strands.links.new(map_range_1.outputs[0], set_curve_radius_1.inputs[2])
	    #named_attribute_1.Attribute -> separate_xyz_1.Vector
	    mesh_to_strands.links.new(named_attribute_1.outputs[0], separate_xyz_1.inputs[0])
	    #subdivide_bake.Geometry -> delete_geometry.Geometry
	    mesh_to_strands.links.new(subdivide_bake.outputs[0], delete_geometry.inputs[0])
	    #mesh_to_curve_1.Curve -> set_material_002.Geometry
	    mesh_to_strands.links.new(mesh_to_curve_1.outputs[0], set_material_002.inputs[0])
	    #edge_vertices.Vertex Index 2 -> evaluate_at_index_001.Index
	    mesh_to_strands.links.new(edge_vertices.outputs[1], evaluate_at_index_001.inputs[0])
	    #subdivide_mesh.Mesh -> subdivide_bake.Geometry
	    mesh_to_strands.links.new(subdivide_mesh.outputs[0], subdivide_bake.inputs[0])
	    #delete_geometry.Geometry -> mesh_to_curve_1.Mesh
	    mesh_to_strands.links.new(delete_geometry.outputs[0], mesh_to_curve_1.inputs[0])
	    #strand_shape.Value -> map_range_1.Value
	    mesh_to_strands.links.new(strand_shape.outputs[0], map_range_1.inputs[0])
	    #separate_xyz_1.X -> compare_005_1.A
	    mesh_to_strands.links.new(separate_xyz_1.outputs[0], compare_005_1.inputs[0])
	    #group_input_4.Geometry -> subdivide_mesh.Mesh
	    mesh_to_strands.links.new(group_input_4.outputs[0], subdivide_mesh.inputs[0])
	    #group_input_4.Level -> subdivide_mesh.Level
	    mesh_to_strands.links.new(group_input_4.outputs[1], subdivide_mesh.inputs[1])
	    #trim_curve.Curve -> set_curve_radius_1.Curve
	    mesh_to_strands.links.new(trim_curve.outputs[0], set_curve_radius_1.inputs[0])
	    #mesh_to_strands_bake.Geometry -> group_output_6.Geometry
	    mesh_to_strands.links.new(mesh_to_strands_bake.outputs[0], group_output_6.inputs[0])
	    #group_input_002_4.Material -> set_material_002.Material
	    mesh_to_strands.links.new(group_input_002_4.outputs[2], set_material_002.inputs[2])
	    #group_input_001_4.Strand Radius -> map_range_1.To Max
	    mesh_to_strands.links.new(group_input_001_4.outputs[3], map_range_1.inputs[4])
	    #group_input_004_1.Trim Seed -> random_value.Seed
	    mesh_to_strands.links.new(group_input_004_1.outputs[4], random_value.inputs[8])
	    #group_input_003_3.Trim Factor -> map_range_001.To Min
	    mesh_to_strands.links.new(group_input_003_3.outputs[5], map_range_001.inputs[3])
	    #group_input_005_1.UV Map -> named_attribute_1.Name
	    mesh_to_strands.links.new(group_input_005_1.outputs[6], named_attribute_1.inputs[0])
	    #set_curve_radius_1.Curve -> mesh_to_strands_bake.Geometry
	    mesh_to_strands.links.new(set_curve_radius_1.outputs[0], mesh_to_strands_bake.inputs[0])
	    return mesh_to_strands
	
	mesh_to_strands = mesh_to_strands_node_group()
	
	#initialize curve_extrude_profile node group
	def curve_extrude_profile_node_group():
	    curve_extrude_profile = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "CURVE_EXTRUDE_PROFILE")
	
	    curve_extrude_profile.color_tag = 'NONE'
	    curve_extrude_profile.description = "Create a curve profile for Convert to Mesh Profile."
	    curve_extrude_profile.default_group_node_width = 140
	    
	
	    curve_extrude_profile.is_modifier = True
	
	    #curve_extrude_profile interface
	    #Socket Geometry
	    geometry_socket_7 = curve_extrude_profile.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_7.attribute_domain = 'POINT'
	    geometry_socket_7.description = "Curve profile."
	
	    #Socket Resolution
	    resolution_socket = curve_extrude_profile.interface.new_socket(name = "Resolution", in_out='INPUT', socket_type = 'NodeSocketInt')
	    resolution_socket.default_value = 32
	    resolution_socket.min_value = 3
	    resolution_socket.max_value = 512
	    resolution_socket.subtype = 'NONE'
	    resolution_socket.attribute_domain = 'POINT'
	    resolution_socket.description = "Curve resolution."
	
	    #Socket Translation
	    translation_socket = curve_extrude_profile.interface.new_socket(name = "Translation", in_out='INPUT', socket_type = 'NodeSocketVector')
	    translation_socket.default_value = (0.0, 0.0, 0.0)
	    translation_socket.min_value = -3.4028234663852886e+38
	    translation_socket.max_value = 3.4028234663852886e+38
	    translation_socket.subtype = 'TRANSLATION'
	    translation_socket.attribute_domain = 'POINT'
	    translation_socket.description = "Translate curve profile from origin."
	
	    #Socket Rotation
	    rotation_socket = curve_extrude_profile.interface.new_socket(name = "Rotation", in_out='INPUT', socket_type = 'NodeSocketRotation')
	    rotation_socket.default_value = (0.0, 0.0, 0.0)
	    rotation_socket.attribute_domain = 'POINT'
	    rotation_socket.description = "Rotate curve profile from origin."
	
	    #Socket Scale
	    scale_socket_2 = curve_extrude_profile.interface.new_socket(name = "Scale", in_out='INPUT', socket_type = 'NodeSocketVector')
	    scale_socket_2.default_value = (1.0, 1.0, 1.0)
	    scale_socket_2.min_value = -3.4028234663852886e+38
	    scale_socket_2.max_value = 3.4028234663852886e+38
	    scale_socket_2.subtype = 'XYZ'
	    scale_socket_2.attribute_domain = 'POINT'
	    scale_socket_2.description = "Scale curve profile from origin."
	
	
	    #initialize curve_extrude_profile nodes
	    #node Group Input
	    group_input_5 = curve_extrude_profile.nodes.new("NodeGroupInput")
	    group_input_5.name = "Group Input"
	    group_input_5.outputs[1].hide = True
	    group_input_5.outputs[2].hide = True
	    group_input_5.outputs[3].hide = True
	    group_input_5.outputs[4].hide = True
	
	    #node Group Output
	    group_output_7 = curve_extrude_profile.nodes.new("NodeGroupOutput")
	    group_output_7.name = "Group Output"
	    group_output_7.is_active_output = True
	    group_output_7.inputs[1].hide = True
	
	    #node Curve Circle
	    curve_circle = curve_extrude_profile.nodes.new("GeometryNodeCurvePrimitiveCircle")
	    curve_circle.name = "Curve Circle"
	    curve_circle.hide = True
	    curve_circle.mode = 'RADIUS'
	    curve_circle.inputs[1].hide = True
	    curve_circle.inputs[2].hide = True
	    curve_circle.inputs[3].hide = True
	    curve_circle.inputs[4].hide = True
	    curve_circle.outputs[1].hide = True
	    #Radius
	    curve_circle.inputs[4].default_value = 1.0
	
	    #node Radial Offset
	    radial_offset = curve_extrude_profile.nodes.new("ShaderNodeFloatCurve")
	    radial_offset.label = "Radial Offset"
	    radial_offset.name = "Radial Offset"
	    #mapping settings
	    radial_offset.mapping.extend = 'EXTRAPOLATED'
	    radial_offset.mapping.tone = 'STANDARD'
	    radial_offset.mapping.black_level = (0.0, 0.0, 0.0)
	    radial_offset.mapping.white_level = (1.0, 1.0, 1.0)
	    radial_offset.mapping.clip_min_x = 0.0
	    radial_offset.mapping.clip_min_y = 0.0
	    radial_offset.mapping.clip_max_x = 1.0
	    radial_offset.mapping.clip_max_y = 1.0
	    radial_offset.mapping.use_clip = True
	    #curve 0
	    radial_offset_curve_0 = radial_offset.mapping.curves[0]
	    radial_offset_curve_0_point_0 = radial_offset_curve_0.points[0]
	    radial_offset_curve_0_point_0.location = (0.001054852269589901, 0.4187498390674591)
	    radial_offset_curve_0_point_0.handle_type = 'AUTO'
	    radial_offset_curve_0_point_1 = radial_offset_curve_0.points[1]
	    radial_offset_curve_0_point_1.location = (0.047468364238739014, 0.46874988079071045)
	    radial_offset_curve_0_point_1.handle_type = 'AUTO'
	    radial_offset_curve_0_point_2 = radial_offset_curve_0.points.new(0.08649790287017822, 0.5812492370605469)
	    radial_offset_curve_0_point_2.handle_type = 'AUTO'
	    radial_offset_curve_0_point_3 = radial_offset_curve_0.points.new(0.10337552428245544, 0.7875000238418579)
	    radial_offset_curve_0_point_3.handle_type = 'AUTO'
	    radial_offset_curve_0_point_4 = radial_offset_curve_0.points.new(0.13396626710891724, 0.7749997973442078)
	    radial_offset_curve_0_point_4.handle_type = 'AUTO'
	    radial_offset_curve_0_point_5 = radial_offset_curve_0.points.new(0.16772152483463287, 0.8312500715255737)
	    radial_offset_curve_0_point_5.handle_type = 'AUTO'
	    radial_offset_curve_0_point_6 = radial_offset_curve_0.points.new(0.19677962362766266, 0.787499725818634)
	    radial_offset_curve_0_point_6.handle_type = 'AUTO_CLAMPED'
	    radial_offset_curve_0_point_7 = radial_offset_curve_0.points.new(0.20991560816764832, 0.8937498927116394)
	    radial_offset_curve_0_point_7.handle_type = 'AUTO'
	    radial_offset_curve_0_point_8 = radial_offset_curve_0.points.new(0.2320675104856491, 0.9124997854232788)
	    radial_offset_curve_0_point_8.handle_type = 'AUTO'
	    radial_offset_curve_0_point_9 = radial_offset_curve_0.points.new(0.25210970640182495, 0.9124999046325684)
	    radial_offset_curve_0_point_9.handle_type = 'AUTO'
	    radial_offset_curve_0_point_10 = radial_offset_curve_0.points.new(0.26160338521003723, 0.8437498211860657)
	    radial_offset_curve_0_point_10.handle_type = 'AUTO_CLAMPED'
	    radial_offset_curve_0_point_11 = radial_offset_curve_0.points.new(0.2890295386314392, 0.7687493562698364)
	    radial_offset_curve_0_point_11.handle_type = 'AUTO_CLAMPED'
	    radial_offset_curve_0_point_12 = radial_offset_curve_0.points.new(0.3238396644592285, 0.8562501668930054)
	    radial_offset_curve_0_point_12.handle_type = 'AUTO'
	    radial_offset_curve_0_point_13 = radial_offset_curve_0.points.new(0.324894517660141, 0.5749994516372681)
	    radial_offset_curve_0_point_13.handle_type = 'AUTO_CLAMPED'
	    radial_offset_curve_0_point_14 = radial_offset_curve_0.points.new(0.35232067108154297, 0.6937500238418579)
	    radial_offset_curve_0_point_14.handle_type = 'AUTO'
	    radial_offset_curve_0_point_15 = radial_offset_curve_0.points.new(0.35232067108154297, 0.524999737739563)
	    radial_offset_curve_0_point_15.handle_type = 'AUTO_CLAMPED'
	    radial_offset_curve_0_point_16 = radial_offset_curve_0.points.new(0.3818565309047699, 0.5062499642372131)
	    radial_offset_curve_0_point_16.handle_type = 'AUTO'
	    radial_offset_curve_0_point_17 = radial_offset_curve_0.points.new(0.3913502097129822, 0.36875006556510925)
	    radial_offset_curve_0_point_17.handle_type = 'AUTO'
	    radial_offset_curve_0_point_18 = radial_offset_curve_0.points.new(0.4166666567325592, 0.35624998807907104)
	    radial_offset_curve_0_point_18.handle_type = 'AUTO'
	    radial_offset_curve_0_point_19 = radial_offset_curve_0.points.new(0.4388185739517212, 0.2812500298023224)
	    radial_offset_curve_0_point_19.handle_type = 'AUTO'
	    radial_offset_curve_0_point_20 = radial_offset_curve_0.points.new(0.4609704613685608, 0.3125)
	    radial_offset_curve_0_point_20.handle_type = 'AUTO'
	    radial_offset_curve_0_point_21 = radial_offset_curve_0.points.new(0.4820675253868103, 0.27500006556510925)
	    radial_offset_curve_0_point_21.handle_type = 'AUTO'
	    radial_offset_curve_0_point_22 = radial_offset_curve_0.points.new(0.4989451467990875, 0.3312499225139618)
	    radial_offset_curve_0_point_22.handle_type = 'AUTO'
	    radial_offset_curve_0_point_23 = radial_offset_curve_0.points.new(0.5179324746131897, 0.30000004172325134)
	    radial_offset_curve_0_point_23.handle_type = 'AUTO'
	    radial_offset_curve_0_point_24 = radial_offset_curve_0.points.new(0.5348103046417236, 0.3374999463558197)
	    radial_offset_curve_0_point_24.handle_type = 'AUTO'
	    radial_offset_curve_0_point_25 = radial_offset_curve_0.points.new(0.5537979006767273, 0.47499993443489075)
	    radial_offset_curve_0_point_25.handle_type = 'AUTO_CLAMPED'
	    radial_offset_curve_0_point_26 = radial_offset_curve_0.points.new(0.590717077255249, 0.4125000536441803)
	    radial_offset_curve_0_point_26.handle_type = 'AUTO'
	    radial_offset_curve_0_point_27 = radial_offset_curve_0.points.new(0.6097047328948975, 0.5375000238418579)
	    radial_offset_curve_0_point_27.handle_type = 'AUTO'
	    radial_offset_curve_0_point_28 = radial_offset_curve_0.points.new(0.6255272030830383, 0.631250262260437)
	    radial_offset_curve_0_point_28.handle_type = 'AUTO_CLAMPED'
	    radial_offset_curve_0_point_29 = radial_offset_curve_0.points.new(0.6540082693099976, 0.6124997138977051)
	    radial_offset_curve_0_point_29.handle_type = 'AUTO_CLAMPED'
	    radial_offset_curve_0_point_30 = radial_offset_curve_0.points.new(0.6708858013153076, 0.7999997138977051)
	    radial_offset_curve_0_point_30.handle_type = 'AUTO'
	    radial_offset_curve_0_point_31 = radial_offset_curve_0.points.new(0.6919825077056885, 0.6624998450279236)
	    radial_offset_curve_0_point_31.handle_type = 'AUTO'
	    radial_offset_curve_0_point_32 = radial_offset_curve_0.points.new(0.7014766335487366, 0.8124997615814209)
	    radial_offset_curve_0_point_32.handle_type = 'AUTO_CLAMPED'
	    radial_offset_curve_0_point_33 = radial_offset_curve_0.points.new(0.7194092273712158, 0.8999999761581421)
	    radial_offset_curve_0_point_33.handle_type = 'AUTO_CLAMPED'
	    radial_offset_curve_0_point_34 = radial_offset_curve_0.points.new(0.7362868189811707, 0.9124998450279236)
	    radial_offset_curve_0_point_34.handle_type = 'AUTO'
	    radial_offset_curve_0_point_35 = radial_offset_curve_0.points.new(0.7552741765975952, 0.9687498807907104)
	    radial_offset_curve_0_point_35.handle_type = 'AUTO'
	    radial_offset_curve_0_point_36 = radial_offset_curve_0.points.new(0.7795358300209045, 0.9249999523162842)
	    radial_offset_curve_0_point_36.handle_type = 'AUTO_CLAMPED'
	    radial_offset_curve_0_point_37 = radial_offset_curve_0.points.new(0.8016877174377441, 0.8937497735023499)
	    radial_offset_curve_0_point_37.handle_type = 'AUTO'
	    radial_offset_curve_0_point_38 = radial_offset_curve_0.points.new(0.8185654878616333, 0.8312497735023499)
	    radial_offset_curve_0_point_38.handle_type = 'AUTO_CLAMPED'
	    radial_offset_curve_0_point_39 = radial_offset_curve_0.points.new(0.8364976644515991, 0.8687500953674316)
	    radial_offset_curve_0_point_39.handle_type = 'AUTO'
	    radial_offset_curve_0_point_40 = radial_offset_curve_0.points.new(0.8523208498954773, 0.6749997735023499)
	    radial_offset_curve_0_point_40.handle_type = 'AUTO'
	    radial_offset_curve_0_point_41 = radial_offset_curve_0.points.new(0.8797467947006226, 0.6437497138977051)
	    radial_offset_curve_0_point_41.handle_type = 'AUTO_CLAMPED'
	    radial_offset_curve_0_point_42 = radial_offset_curve_0.points.new(0.9050630331039429, 0.6000002026557922)
	    radial_offset_curve_0_point_42.handle_type = 'AUTO'
	    radial_offset_curve_0_point_43 = radial_offset_curve_0.points.new(0.9356541633605957, 0.42500004172325134)
	    radial_offset_curve_0_point_43.handle_type = 'AUTO'
	    radial_offset_curve_0_point_44 = radial_offset_curve_0.points.new(0.9672994613647461, 0.41874992847442627)
	    radial_offset_curve_0_point_44.handle_type = 'AUTO'
	    radial_offset_curve_0_point_45 = radial_offset_curve_0.points.new(1.0, 0.3874998688697815)
	    radial_offset_curve_0_point_45.handle_type = 'AUTO'
	    #update curve after changes
	    radial_offset.mapping.update()
	    radial_offset.inputs[0].hide = True
	    #Factor
	    radial_offset.inputs[0].default_value = 1.0
	
	    #node Spline Parameter
	    spline_parameter_1 = curve_extrude_profile.nodes.new("GeometryNodeSplineParameter")
	    spline_parameter_1.name = "Spline Parameter"
	    spline_parameter_1.outputs[1].hide = True
	    spline_parameter_1.outputs[2].hide = True
	
	    #node Set Position
	    set_position_1 = curve_extrude_profile.nodes.new("GeometryNodeSetPosition")
	    set_position_1.name = "Set Position"
	    set_position_1.hide = True
	    set_position_1.inputs[1].hide = True
	    set_position_1.inputs[3].hide = True
	    #Selection
	    set_position_1.inputs[1].default_value = True
	    #Offset
	    set_position_1.inputs[3].default_value = (0.0, 0.0, 0.0)
	
	    #node Position
	    position_2 = curve_extrude_profile.nodes.new("GeometryNodeInputPosition")
	    position_2.name = "Position"
	
	    #node Vector Math
	    vector_math_2 = curve_extrude_profile.nodes.new("ShaderNodeVectorMath")
	    vector_math_2.name = "Vector Math"
	    vector_math_2.hide = True
	    vector_math_2.operation = 'SCALE'
	
	    #node Transform Geometry
	    transform_geometry_1 = curve_extrude_profile.nodes.new("GeometryNodeTransform")
	    transform_geometry_1.name = "Transform Geometry"
	    transform_geometry_1.hide = True
	    transform_geometry_1.mode = 'COMPONENTS'
	
	    #node Group Input.001
	    group_input_001_5 = curve_extrude_profile.nodes.new("NodeGroupInput")
	    group_input_001_5.name = "Group Input.001"
	    group_input_001_5.outputs[0].hide = True
	    group_input_001_5.outputs[4].hide = True
	
	    #node Frame
	    frame_2 = curve_extrude_profile.nodes.new("NodeFrame")
	    frame_2.label = "Radial Offset"
	    frame_2.name = "Frame"
	    frame_2.label_size = 20
	    frame_2.shrink = True
	
	    #node Reroute
	    reroute_3 = curve_extrude_profile.nodes.new("NodeReroute")
	    reroute_3.name = "Reroute"
	    reroute_3.socket_idname = "NodeSocketVector"
	    #node Reroute.001
	    reroute_001_2 = curve_extrude_profile.nodes.new("NodeReroute")
	    reroute_001_2.name = "Reroute.001"
	    reroute_001_2.socket_idname = "NodeSocketVector"
	    #node Frame.001
	    frame_001_1 = curve_extrude_profile.nodes.new("NodeFrame")
	    frame_001_1.label = "X value is percantage of 360 deg from x positve."
	    frame_001_1.name = "Frame.001"
	    frame_001_1.label_size = 20
	    frame_001_1.shrink = True
	
	    #node Frame.002
	    frame_002_1 = curve_extrude_profile.nodes.new("NodeFrame")
	    frame_002_1.label = "Y value is the distance from origin. ([0,0,0])"
	    frame_002_1.name = "Frame.002"
	    frame_002_1.label_size = 20
	    frame_002_1.shrink = True
	
	
	
	
	    #Set parents
	    radial_offset.parent = frame_2
	    spline_parameter_1.parent = frame_2
	    position_2.parent = frame_2
	    vector_math_2.parent = frame_2
	
	    #Set locations
	    group_input_5.location = (-340.0, -22.570165634155273)
	    group_output_7.location = (362.9671936035156, -40.626277923583984)
	    curve_circle.location = (-166.6719512939453, -46.762123107910156)
	    radial_offset.location = (33.486419677734375, -129.11273193359375)
	    spline_parameter_1.location = (30.04144287109375, -424.0594482421875)
	    set_position_1.location = (4.4881591796875, -53.521385192871094)
	    position_2.location = (592.2982177734375, -74.47775268554688)
	    vector_math_2.location = (593.3895263671875, -44.6279296875)
	    transform_geometry_1.location = (185.82901000976562, -66.2401351928711)
	    group_input_001_5.location = (10.093160629272461, -81.2525405883789)
	    frame_2.location = (-352.0, -180.0)
	    reroute_3.location = (380.5245666503906, -181.39073181152344)
	    reroute_001_2.location = (5.314706802368164, -181.74554443359375)
	    frame_001_1.location = (422.1756591796875, -181.8056182861328)
	    frame_002_1.location = (422.1756591796875, -257.09149169921875)
	
	    #Set dimensions
	    group_input_5.width, group_input_5.height = 140.0, 100.0
	    group_output_7.width, group_output_7.height = 140.0, 100.0
	    curve_circle.width, curve_circle.height = 140.0, 100.0
	    radial_offset.width, radial_offset.height = 700.0, 100.0
	    spline_parameter_1.width, spline_parameter_1.height = 140.0, 100.0
	    set_position_1.width, set_position_1.height = 140.0, 100.0
	    position_2.width, position_2.height = 140.0, 100.0
	    vector_math_2.width, vector_math_2.height = 140.0, 100.0
	    transform_geometry_1.width, transform_geometry_1.height = 140.0, 100.0
	    group_input_001_5.width, group_input_001_5.height = 140.0, 100.0
	    frame_2.width, frame_2.height = 763.0, 506.0
	    reroute_3.width, reroute_3.height = 10.0, 100.0
	    reroute_001_2.width, reroute_001_2.height = 10.0, 100.0
	    frame_001_1.width, frame_001_1.height = 763.0001220703125, 58.84747314453125
	    frame_002_1.width, frame_002_1.height = 763.0001220703125, 58.84722900390625
	
	    #initialize curve_extrude_profile links
	    #spline_parameter_1.Factor -> radial_offset.Value
	    curve_extrude_profile.links.new(spline_parameter_1.outputs[0], radial_offset.inputs[1])
	    #curve_circle.Curve -> set_position_1.Geometry
	    curve_extrude_profile.links.new(curve_circle.outputs[0], set_position_1.inputs[0])
	    #position_2.Position -> vector_math_2.Vector
	    curve_extrude_profile.links.new(position_2.outputs[0], vector_math_2.inputs[0])
	    #radial_offset.Value -> vector_math_2.Scale
	    curve_extrude_profile.links.new(radial_offset.outputs[0], vector_math_2.inputs[3])
	    #reroute_001_2.Output -> set_position_1.Position
	    curve_extrude_profile.links.new(reroute_001_2.outputs[0], set_position_1.inputs[2])
	    #group_input_5.Resolution -> curve_circle.Resolution
	    curve_extrude_profile.links.new(group_input_5.outputs[0], curve_circle.inputs[0])
	    #set_position_1.Geometry -> transform_geometry_1.Geometry
	    curve_extrude_profile.links.new(set_position_1.outputs[0], transform_geometry_1.inputs[0])
	    #group_input_001_5.Translation -> transform_geometry_1.Translation
	    curve_extrude_profile.links.new(group_input_001_5.outputs[1], transform_geometry_1.inputs[1])
	    #group_input_001_5.Rotation -> transform_geometry_1.Rotation
	    curve_extrude_profile.links.new(group_input_001_5.outputs[2], transform_geometry_1.inputs[2])
	    #group_input_001_5.Scale -> transform_geometry_1.Scale
	    curve_extrude_profile.links.new(group_input_001_5.outputs[3], transform_geometry_1.inputs[3])
	    #transform_geometry_1.Geometry -> group_output_7.Geometry
	    curve_extrude_profile.links.new(transform_geometry_1.outputs[0], group_output_7.inputs[0])
	    #vector_math_2.Vector -> reroute_3.Input
	    curve_extrude_profile.links.new(vector_math_2.outputs[0], reroute_3.inputs[0])
	    #reroute_3.Output -> reroute_001_2.Input
	    curve_extrude_profile.links.new(reroute_3.outputs[0], reroute_001_2.inputs[0])
	    return curve_extrude_profile
	
	curve_extrude_profile = curve_extrude_profile_node_group()
	
	#initialize face_centers node group
	def face_centers_node_group():
	    face_centers = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "FACE_CENTERS")
	
	    face_centers.color_tag = 'NONE'
	    face_centers.description = ""
	    face_centers.default_group_node_width = 140
	    
	
	    face_centers.is_modifier = True
	
	    #face_centers interface
	    #Socket Geometry
	    geometry_socket_8 = face_centers.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_8.attribute_domain = 'POINT'
	
	    #Socket Geometry
	    geometry_socket_9 = face_centers.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_9.attribute_domain = 'POINT'
	
	
	    #initialize face_centers nodes
	    #node Group Output
	    group_output_8 = face_centers.nodes.new("NodeGroupOutput")
	    group_output_8.name = "Group Output"
	    group_output_8.is_active_output = True
	
	    #node Group Input
	    group_input_6 = face_centers.nodes.new("NodeGroupInput")
	    group_input_6.name = "Group Input"
	
	    #node For Each Geometry Element Input
	    for_each_geometry_element_input = face_centers.nodes.new("GeometryNodeForeachGeometryElementInput")
	    for_each_geometry_element_input.name = "For Each Geometry Element Input"
	    #node For Each Geometry Element Output
	    for_each_geometry_element_output = face_centers.nodes.new("GeometryNodeForeachGeometryElementOutput")
	    for_each_geometry_element_output.name = "For Each Geometry Element Output"
	    for_each_geometry_element_output.active_generation_index = 0
	    for_each_geometry_element_output.active_input_index = 0
	    for_each_geometry_element_output.active_main_index = 0
	    for_each_geometry_element_output.domain = 'FACE'
	    for_each_geometry_element_output.generation_items.clear()
	    for_each_geometry_element_output.generation_items.new('GEOMETRY', "Geometry")
	    for_each_geometry_element_output.generation_items[0].domain = 'POINT'
	    for_each_geometry_element_output.input_items.clear()
	    for_each_geometry_element_output.inspection_index = 0
	    for_each_geometry_element_output.main_items.clear()
	
	    #node Store Named Attribute
	    store_named_attribute_1 = face_centers.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_1.name = "Store Named Attribute"
	    store_named_attribute_1.data_type = 'FLOAT_VECTOR'
	    store_named_attribute_1.domain = 'FACE'
	    #Selection
	    store_named_attribute_1.inputs[1].default_value = True
	    #Name
	    store_named_attribute_1.inputs[2].default_value = "centers"
	
	    #node Named Attribute.001
	    named_attribute_001 = face_centers.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute_001.name = "Named Attribute.001"
	    named_attribute_001.data_type = 'INT'
	    #Name
	    named_attribute_001.inputs[0].default_value = "fidx"
	
	    #node Named Attribute.004
	    named_attribute_004 = face_centers.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute_004.name = "Named Attribute.004"
	    named_attribute_004.data_type = 'FLOAT_VECTOR'
	    #Name
	    named_attribute_004.inputs[0].default_value = "fco"
	
	    #node Compare.001
	    compare_001 = face_centers.nodes.new("FunctionNodeCompare")
	    compare_001.name = "Compare.001"
	    compare_001.hide = True
	    compare_001.data_type = 'INT'
	    compare_001.mode = 'ELEMENT'
	    compare_001.operation = 'EQUAL'
	
	    #node Attribute Statistic.002
	    attribute_statistic_002 = face_centers.nodes.new("GeometryNodeAttributeStatistic")
	    attribute_statistic_002.name = "Attribute Statistic.002"
	    attribute_statistic_002.data_type = 'FLOAT_VECTOR'
	    attribute_statistic_002.domain = 'CORNER'
	    attribute_statistic_002.outputs[1].hide = True
	    attribute_statistic_002.outputs[2].hide = True
	    attribute_statistic_002.outputs[3].hide = True
	    attribute_statistic_002.outputs[4].hide = True
	    attribute_statistic_002.outputs[5].hide = True
	    attribute_statistic_002.outputs[6].hide = True
	    attribute_statistic_002.outputs[7].hide = True
	
	    #node Reroute.010
	    reroute_010 = face_centers.nodes.new("NodeReroute")
	    reroute_010.name = "Reroute.010"
	    reroute_010.socket_idname = "NodeSocketGeometry"
	
	
	    #Process zone input For Each Geometry Element Input
	    for_each_geometry_element_input.pair_with_output(for_each_geometry_element_output)
	    #Selection
	    for_each_geometry_element_input.inputs[1].default_value = True
	
	
	
	
	    #Set locations
	    group_output_8.location = (659.57373046875, 0.0)
	    group_input_6.location = (-669.57373046875, 0.0)
	    for_each_geometry_element_input.location = (-369.873779296875, 251.74090576171875)
	    for_each_geometry_element_output.location = (469.57373046875, 251.74090576171875)
	    store_named_attribute_1.location = (250.197998046875, 248.50677490234375)
	    named_attribute_001.location = (-405.4127197265625, 37.06463623046875)
	    named_attribute_004.location = (-403.79931640625, -97.15411376953125)
	    compare_001.location = (-188.1004638671875, 84.72480773925781)
	    attribute_statistic_002.location = (-11.463111877441406, 110.92959594726562)
	    reroute_010.location = (-485.5649719238281, -34.71746826171875)
	
	    #Set dimensions
	    group_output_8.width, group_output_8.height = 140.0, 100.0
	    group_input_6.width, group_input_6.height = 140.0, 100.0
	    for_each_geometry_element_input.width, for_each_geometry_element_input.height = 140.0, 100.0
	    for_each_geometry_element_output.width, for_each_geometry_element_output.height = 140.0, 100.0
	    store_named_attribute_1.width, store_named_attribute_1.height = 140.0, 100.0
	    named_attribute_001.width, named_attribute_001.height = 140.0, 100.0
	    named_attribute_004.width, named_attribute_004.height = 140.0, 100.0
	    compare_001.width, compare_001.height = 140.0, 100.0
	    attribute_statistic_002.width, attribute_statistic_002.height = 140.0, 100.0
	    reroute_010.width, reroute_010.height = 100.0, 100.0
	
	    #initialize face_centers links
	    #reroute_010.Output -> attribute_statistic_002.Geometry
	    face_centers.links.new(reroute_010.outputs[0], attribute_statistic_002.inputs[0])
	    #compare_001.Result -> attribute_statistic_002.Selection
	    face_centers.links.new(compare_001.outputs[0], attribute_statistic_002.inputs[1])
	    #named_attribute_004.Attribute -> attribute_statistic_002.Attribute
	    face_centers.links.new(named_attribute_004.outputs[0], attribute_statistic_002.inputs[2])
	    #named_attribute_001.Attribute -> compare_001.B
	    face_centers.links.new(named_attribute_001.outputs[0], compare_001.inputs[3])
	    #store_named_attribute_1.Geometry -> for_each_geometry_element_output.Geometry
	    face_centers.links.new(store_named_attribute_1.outputs[0], for_each_geometry_element_output.inputs[1])
	    #attribute_statistic_002.Mean -> store_named_attribute_1.Value
	    face_centers.links.new(attribute_statistic_002.outputs[0], store_named_attribute_1.inputs[3])
	    #for_each_geometry_element_input.Element -> store_named_attribute_1.Geometry
	    face_centers.links.new(for_each_geometry_element_input.outputs[1], store_named_attribute_1.inputs[0])
	    #reroute_010.Output -> for_each_geometry_element_input.Geometry
	    face_centers.links.new(reroute_010.outputs[0], for_each_geometry_element_input.inputs[0])
	    #for_each_geometry_element_input.Index -> compare_001.A
	    face_centers.links.new(for_each_geometry_element_input.outputs[0], compare_001.inputs[2])
	    #group_input_6.Geometry -> reroute_010.Input
	    face_centers.links.new(group_input_6.outputs[0], reroute_010.inputs[0])
	    #for_each_geometry_element_output.Geometry -> group_output_8.Geometry
	    face_centers.links.new(for_each_geometry_element_output.outputs[2], group_output_8.inputs[0])
	    return face_centers
	
	face_centers = face_centers_node_group()
	
	#initialize ob_data node group
	def ob_data_node_group():
	    ob_data = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "OB_DATA")
	
	    ob_data.color_tag = 'NONE'
	    ob_data.description = "Extra data for mesh object."
	    ob_data.default_group_node_width = 140
	    
	
	    ob_data.is_modifier = True
	    ob_data.is_tool = True
	    ob_data.is_mode_object = False
	    ob_data.is_mode_edit = False
	    ob_data.is_mode_sculpt = False
	    ob_data.is_type_curve = False
	    ob_data.is_type_mesh = False
	    ob_data.is_type_point_cloud = False
	
	    #ob_data interface
	    #Socket Geometry
	    geometry_socket_10 = ob_data.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_10.attribute_domain = 'POINT'
	
	    #Socket Geometry
	    geometry_socket_11 = ob_data.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_11.attribute_domain = 'POINT'
	
	
	    #initialize ob_data nodes
	    #node Group Output
	    group_output_9 = ob_data.nodes.new("NodeGroupOutput")
	    group_output_9.name = "Group Output"
	    group_output_9.is_active_output = True
	    group_output_9.inputs[1].hide = True
	
	    #node Group Input
	    group_input_7 = ob_data.nodes.new("NodeGroupInput")
	    group_input_7.name = "Group Input"
	    group_input_7.outputs[1].hide = True
	
	    #node Store Named Attribute
	    store_named_attribute_2 = ob_data.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_2.name = "Store Named Attribute"
	    store_named_attribute_2.data_type = 'FLOAT'
	    store_named_attribute_2.domain = 'FACE'
	    #Selection
	    store_named_attribute_2.inputs[1].default_value = True
	    #Name
	    store_named_attribute_2.inputs[2].default_value = "area"
	
	    #node Face Area
	    face_area = ob_data.nodes.new("GeometryNodeInputMeshFaceArea")
	    face_area.name = "Face Area"
	
	    #node Corners of Face
	    corners_of_face = ob_data.nodes.new("GeometryNodeCornersOfFace")
	    corners_of_face.name = "Corners of Face"
	    corners_of_face.inputs[0].hide = True
	    corners_of_face.inputs[1].hide = True
	    corners_of_face.inputs[2].hide = True
	    corners_of_face.outputs[0].hide = True
	    #Face Index
	    corners_of_face.inputs[0].default_value = 0
	    #Weights
	    corners_of_face.inputs[1].default_value = 0.0
	    #Sort Index
	    corners_of_face.inputs[2].default_value = 0
	
	    #node Store Named Attribute.004
	    store_named_attribute_004 = ob_data.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_004.name = "Store Named Attribute.004"
	    store_named_attribute_004.data_type = 'INT'
	    store_named_attribute_004.domain = 'FACE'
	    #Selection
	    store_named_attribute_004.inputs[1].default_value = True
	    #Name
	    store_named_attribute_004.inputs[2].default_value = "fvct"
	
	    #node Edge Vertices.001
	    edge_vertices_001 = ob_data.nodes.new("GeometryNodeInputMeshEdgeVertices")
	    edge_vertices_001.name = "Edge Vertices.001"
	
	    #node Store Named Attribute.010
	    store_named_attribute_010 = ob_data.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_010.name = "Store Named Attribute.010"
	    store_named_attribute_010.data_type = 'FLOAT_VECTOR'
	    store_named_attribute_010.domain = 'EDGE'
	    #Selection
	    store_named_attribute_010.inputs[1].default_value = True
	    #Name
	    store_named_attribute_010.inputs[2].default_value = "evec"
	
	    #node Store Named Attribute.011
	    store_named_attribute_011 = ob_data.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_011.name = "Store Named Attribute.011"
	    store_named_attribute_011.data_type = 'FLOAT'
	    store_named_attribute_011.domain = 'EDGE'
	    #Selection
	    store_named_attribute_011.inputs[1].default_value = True
	    #Name
	    store_named_attribute_011.inputs[2].default_value = "elen"
	
	    #node Vector Math
	    vector_math_3 = ob_data.nodes.new("ShaderNodeVectorMath")
	    vector_math_3.name = "Vector Math"
	    vector_math_3.hide = True
	    vector_math_3.operation = 'SUBTRACT'
	
	    #node Vector Math.001
	    vector_math_001 = ob_data.nodes.new("ShaderNodeVectorMath")
	    vector_math_001.name = "Vector Math.001"
	    vector_math_001.hide = True
	    vector_math_001.operation = 'LENGTH'
	
	    #node Vertex Neighbors
	    vertex_neighbors = ob_data.nodes.new("GeometryNodeInputMeshVertexNeighbors")
	    vertex_neighbors.name = "Vertex Neighbors"
	
	    #node Store Named Attribute.002
	    store_named_attribute_002 = ob_data.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_002.name = "Store Named Attribute.002"
	    store_named_attribute_002.data_type = 'INT'
	    store_named_attribute_002.domain = 'POINT'
	    #Selection
	    store_named_attribute_002.inputs[1].default_value = True
	    #Name
	    store_named_attribute_002.inputs[2].default_value = "vct"
	
	    #node Store Named Attribute.003
	    store_named_attribute_003 = ob_data.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_003.name = "Store Named Attribute.003"
	    store_named_attribute_003.data_type = 'INT'
	    store_named_attribute_003.domain = 'POINT'
	    #Selection
	    store_named_attribute_003.inputs[1].default_value = True
	    #Name
	    store_named_attribute_003.inputs[2].default_value = "fct"
	
	    #node Corners of Vertex
	    corners_of_vertex = ob_data.nodes.new("GeometryNodeCornersOfVertex")
	    corners_of_vertex.name = "Corners of Vertex"
	    #Vertex Index
	    corners_of_vertex.inputs[0].default_value = 0
	    #Weights
	    corners_of_vertex.inputs[1].default_value = 0.0
	    #Sort Index
	    corners_of_vertex.inputs[2].default_value = 0
	
	    #node Store Named Attribute.006
	    store_named_attribute_006 = ob_data.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_006.name = "Store Named Attribute.006"
	    store_named_attribute_006.data_type = 'INT'
	    store_named_attribute_006.domain = 'POINT'
	    #Selection
	    store_named_attribute_006.inputs[1].default_value = True
	    #Name
	    store_named_attribute_006.inputs[2].default_value = "vi"
	
	    #node Face of Corner
	    face_of_corner = ob_data.nodes.new("GeometryNodeFaceOfCorner")
	    face_of_corner.name = "Face of Corner"
	    face_of_corner.inputs[0].hide = True
	    face_of_corner.outputs[1].hide = True
	    #Corner Index
	    face_of_corner.inputs[0].default_value = 0
	
	    #node Store Named Attribute.007
	    store_named_attribute_007 = ob_data.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_007.name = "Store Named Attribute.007"
	    store_named_attribute_007.data_type = 'INT'
	    store_named_attribute_007.domain = 'POINT'
	    #Selection
	    store_named_attribute_007.inputs[1].default_value = True
	    #Name
	    store_named_attribute_007.inputs[2].default_value = "iif"
	
	    #node Store Named Attribute.005
	    store_named_attribute_005 = ob_data.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_005.name = "Store Named Attribute.005"
	    store_named_attribute_005.data_type = 'INT'
	    store_named_attribute_005.domain = 'POINT'
	    #Selection
	    store_named_attribute_005.inputs[1].default_value = True
	    #Name
	    store_named_attribute_005.inputs[2].default_value = "vidx"
	
	    #node Index
	    index_2 = ob_data.nodes.new("GeometryNodeInputIndex")
	    index_2.name = "Index"
	
	    #node Store Named Attribute.012
	    store_named_attribute_012 = ob_data.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_012.name = "Store Named Attribute.012"
	    store_named_attribute_012.data_type = 'INT'
	    store_named_attribute_012.domain = 'EDGE'
	    #Selection
	    store_named_attribute_012.inputs[1].default_value = True
	    #Name
	    store_named_attribute_012.inputs[2].default_value = "e1"
	
	    #node Store Named Attribute.013
	    store_named_attribute_013 = ob_data.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_013.name = "Store Named Attribute.013"
	    store_named_attribute_013.data_type = 'INT'
	    store_named_attribute_013.domain = 'EDGE'
	    #Selection
	    store_named_attribute_013.inputs[1].default_value = True
	    #Name
	    store_named_attribute_013.inputs[2].default_value = "e2"
	
	    #node Frame
	    frame_3 = ob_data.nodes.new("NodeFrame")
	    frame_3.label = "Point"
	    frame_3.name = "Frame"
	    frame_3.label_size = 20
	    frame_3.shrink = True
	
	    #node Frame.001
	    frame_001_2 = ob_data.nodes.new("NodeFrame")
	    frame_001_2.label = "Edge"
	    frame_001_2.name = "Frame.001"
	    frame_001_2.label_size = 20
	    frame_001_2.shrink = True
	
	    #node Frame.002
	    frame_002_2 = ob_data.nodes.new("NodeFrame")
	    frame_002_2.label = "Face"
	    frame_002_2.name = "Frame.002"
	    frame_002_2.label_size = 20
	    frame_002_2.shrink = True
	
	    #node Store Named Attribute.008
	    store_named_attribute_008 = ob_data.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_008.name = "Store Named Attribute.008"
	    store_named_attribute_008.data_type = 'INT'
	    store_named_attribute_008.domain = 'CORNER'
	    #Selection
	    store_named_attribute_008.inputs[1].default_value = True
	    #Name
	    store_named_attribute_008.inputs[2].default_value = "fidx"
	
	    #node Index.001
	    index_001_2 = ob_data.nodes.new("GeometryNodeInputIndex")
	    index_001_2.name = "Index.001"
	
	    #node Face of Corner.001
	    face_of_corner_001 = ob_data.nodes.new("GeometryNodeFaceOfCorner")
	    face_of_corner_001.name = "Face of Corner.001"
	    face_of_corner_001.hide = True
	    #Corner Index
	    face_of_corner_001.inputs[0].default_value = 0
	
	    #node Store Named Attribute.009
	    store_named_attribute_009 = ob_data.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_009.name = "Store Named Attribute.009"
	    store_named_attribute_009.data_type = 'INT'
	    store_named_attribute_009.domain = 'CORNER'
	    #Selection
	    store_named_attribute_009.inputs[1].default_value = True
	    #Name
	    store_named_attribute_009.inputs[2].default_value = "iface"
	
	    #node Evaluate at Index.002
	    evaluate_at_index_002 = ob_data.nodes.new("GeometryNodeFieldAtIndex")
	    evaluate_at_index_002.name = "Evaluate at Index.002"
	    evaluate_at_index_002.hide = True
	    evaluate_at_index_002.data_type = 'FLOAT_VECTOR'
	    evaluate_at_index_002.domain = 'POINT'
	
	    #node Position
	    position_3 = ob_data.nodes.new("GeometryNodeInputPosition")
	    position_3.name = "Position"
	
	    #node Store Named Attribute.014
	    store_named_attribute_014 = ob_data.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_014.name = "Store Named Attribute.014"
	    store_named_attribute_014.data_type = 'FLOAT_VECTOR'
	    store_named_attribute_014.domain = 'CORNER'
	    #Selection
	    store_named_attribute_014.inputs[1].default_value = True
	    #Name
	    store_named_attribute_014.inputs[2].default_value = "fco"
	
	    #node Store Named Attribute.015
	    store_named_attribute_015 = ob_data.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_015.name = "Store Named Attribute.015"
	    store_named_attribute_015.data_type = 'INT'
	    store_named_attribute_015.domain = 'CORNER'
	    #Selection
	    store_named_attribute_015.inputs[1].default_value = True
	    #Name
	    store_named_attribute_015.inputs[2].default_value = "fvert"
	
	    #node Named Attribute.001
	    named_attribute_001_1 = ob_data.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute_001_1.name = "Named Attribute.001"
	    named_attribute_001_1.data_type = 'INT'
	    #Name
	    named_attribute_001_1.inputs[0].default_value = "vidx"
	
	    #node Frame.003
	    frame_003_1 = ob_data.nodes.new("NodeFrame")
	    frame_003_1.label = "UV"
	    frame_003_1.name = "Frame.003"
	    frame_003_1.label_size = 20
	    frame_003_1.shrink = True
	
	    #node Group
	    group_2 = ob_data.nodes.new("GeometryNodeGroup")
	    group_2.name = "Group"
	    group_2.node_tree = face_centers
	
	
	
	
	    #Set parents
	    store_named_attribute_2.parent = frame_002_2
	    face_area.parent = frame_002_2
	    corners_of_face.parent = frame_002_2
	    store_named_attribute_004.parent = frame_002_2
	    edge_vertices_001.parent = frame_001_2
	    store_named_attribute_010.parent = frame_001_2
	    store_named_attribute_011.parent = frame_001_2
	    vector_math_3.parent = frame_001_2
	    vector_math_001.parent = frame_001_2
	    vertex_neighbors.parent = frame_3
	    store_named_attribute_002.parent = frame_3
	    store_named_attribute_003.parent = frame_3
	    corners_of_vertex.parent = frame_3
	    store_named_attribute_006.parent = frame_3
	    face_of_corner.parent = frame_3
	    store_named_attribute_007.parent = frame_3
	    store_named_attribute_005.parent = frame_3
	    index_2.parent = frame_3
	    store_named_attribute_012.parent = frame_001_2
	    store_named_attribute_013.parent = frame_001_2
	    store_named_attribute_008.parent = frame_003_1
	    index_001_2.parent = frame_003_1
	    face_of_corner_001.parent = frame_003_1
	    store_named_attribute_009.parent = frame_003_1
	    evaluate_at_index_002.parent = frame_003_1
	    position_3.parent = frame_003_1
	    store_named_attribute_014.parent = frame_003_1
	    store_named_attribute_015.parent = frame_003_1
	    named_attribute_001_1.parent = frame_003_1
	
	    #Set locations
	    group_output_9.location = (2084.419677734375, 0.0)
	    group_input_7.location = (-1175.17578125, 0.0)
	    store_named_attribute_2.location = (31.557861328125, -39.91112518310547)
	    face_area.location = (30.0308837890625, -241.5736541748047)
	    corners_of_face.location = (207.884521484375, -240.56661987304688)
	    store_named_attribute_004.location = (211.1871337890625, -43.55321502685547)
	    edge_vertices_001.location = (30.059101104736328, -235.656494140625)
	    store_named_attribute_010.location = (379.56103515625, -39.92475128173828)
	    store_named_attribute_011.location = (559.666259765625, -39.92475128173828)
	    vector_math_3.location = (377.9259338378906, -247.12554931640625)
	    vector_math_001.location = (559.92236328125, -245.30450439453125)
	    vertex_neighbors.location = (225.6195068359375, -241.48486328125)
	    store_named_attribute_002.location = (230.421875, -42.65917205810547)
	    store_named_attribute_003.location = (424.875732421875, -42.65917205810547)
	    corners_of_vertex.location = (791.2051391601562, -243.86764526367188)
	    store_named_attribute_006.location = (614.2387084960938, -44.48021697998047)
	    face_of_corner.location = (609.9549560546875, -242.69467163085938)
	    store_named_attribute_007.location = (794.2388305664062, -44.48021697998047)
	    store_named_attribute_005.location = (32.19744873046875, -39.81938171386719)
	    index_2.location = (29.61065673828125, -237.67437744140625)
	    store_named_attribute_012.location = (30.58085823059082, -39.92475128173828)
	    store_named_attribute_013.location = (205.30517578125, -39.92475128173828)
	    frame_3.location = (-1011.0, 114.0)
	    frame_001_2.location = (-24.0, 111.0)
	    frame_002_2.location = (723.0, 113.0)
	    store_named_attribute_008.location = (30.084228515625, -39.91887664794922)
	    index_001_2.location = (399.0113525390625, -272.89666748046875)
	    face_of_corner_001.location = (31.023681640625, -240.24319458007812)
	    store_named_attribute_009.location = (210.18896484375, -39.91887664794922)
	    evaluate_at_index_002.location = (399.3846435546875, -241.97543334960938)
	    position_3.location = (395.73388671875, -329.0435791015625)
	    store_named_attribute_014.location = (396.99755859375, -39.91887664794922)
	    store_named_attribute_015.location = (589.268798828125, -39.91887664794922)
	    named_attribute_001_1.location = (590.27685546875, -237.64990234375)
	    frame_003_1.location = (1121.0, 117.0)
	    group_2.location = (1895.553466796875, -3.2612171173095703)
	
	    #Set dimensions
	    group_output_9.width, group_output_9.height = 140.0, 100.0
	    group_input_7.width, group_input_7.height = 140.0, 100.0
	    store_named_attribute_2.width, store_named_attribute_2.height = 140.0, 100.0
	    face_area.width, face_area.height = 140.0, 100.0
	    corners_of_face.width, corners_of_face.height = 140.0, 100.0
	    store_named_attribute_004.width, store_named_attribute_004.height = 140.0, 100.0
	    edge_vertices_001.width, edge_vertices_001.height = 140.0, 100.0
	    store_named_attribute_010.width, store_named_attribute_010.height = 140.0, 100.0
	    store_named_attribute_011.width, store_named_attribute_011.height = 140.0, 100.0
	    vector_math_3.width, vector_math_3.height = 140.0, 100.0
	    vector_math_001.width, vector_math_001.height = 140.0, 100.0
	    vertex_neighbors.width, vertex_neighbors.height = 140.0, 100.0
	    store_named_attribute_002.width, store_named_attribute_002.height = 140.0, 100.0
	    store_named_attribute_003.width, store_named_attribute_003.height = 140.0, 100.0
	    corners_of_vertex.width, corners_of_vertex.height = 140.0, 100.0
	    store_named_attribute_006.width, store_named_attribute_006.height = 140.0, 100.0
	    face_of_corner.width, face_of_corner.height = 140.0, 100.0
	    store_named_attribute_007.width, store_named_attribute_007.height = 140.0, 100.0
	    store_named_attribute_005.width, store_named_attribute_005.height = 140.0, 100.0
	    index_2.width, index_2.height = 140.0, 100.0
	    store_named_attribute_012.width, store_named_attribute_012.height = 140.0, 100.0
	    store_named_attribute_013.width, store_named_attribute_013.height = 140.0, 100.0
	    frame_3.width, frame_3.height = 964.0, 415.0
	    frame_001_2.width, frame_001_2.height = 730.0, 382.0
	    frame_002_2.width, frame_002_2.height = 381.0, 322.0
	    store_named_attribute_008.width, store_named_attribute_008.height = 140.0, 100.0
	    index_001_2.width, index_001_2.height = 140.0, 100.0
	    face_of_corner_001.width, face_of_corner_001.height = 140.0, 100.0
	    store_named_attribute_009.width, store_named_attribute_009.height = 140.0, 100.0
	    evaluate_at_index_002.width, evaluate_at_index_002.height = 140.0, 100.0
	    position_3.width, position_3.height = 140.0, 100.0
	    store_named_attribute_014.width, store_named_attribute_014.height = 140.0, 100.0
	    store_named_attribute_015.width, store_named_attribute_015.height = 140.0, 100.0
	    named_attribute_001_1.width, named_attribute_001_1.height = 140.0, 100.0
	    frame_003_1.width, frame_003_1.height = 760.0, 409.0
	    group_2.width, group_2.height = 140.0, 100.0
	
	    #initialize ob_data links
	    #store_named_attribute_010.Geometry -> store_named_attribute_011.Geometry
	    ob_data.links.new(store_named_attribute_010.outputs[0], store_named_attribute_011.inputs[0])
	    #edge_vertices_001.Position 2 -> vector_math_3.Vector
	    ob_data.links.new(edge_vertices_001.outputs[3], vector_math_3.inputs[0])
	    #edge_vertices_001.Position 1 -> vector_math_3.Vector
	    ob_data.links.new(edge_vertices_001.outputs[2], vector_math_3.inputs[1])
	    #vector_math_3.Vector -> store_named_attribute_010.Value
	    ob_data.links.new(vector_math_3.outputs[0], store_named_attribute_010.inputs[3])
	    #vector_math_3.Vector -> vector_math_001.Vector
	    ob_data.links.new(vector_math_3.outputs[0], vector_math_001.inputs[0])
	    #vector_math_001.Value -> store_named_attribute_011.Value
	    ob_data.links.new(vector_math_001.outputs[1], store_named_attribute_011.inputs[3])
	    #store_named_attribute_011.Geometry -> store_named_attribute_2.Geometry
	    ob_data.links.new(store_named_attribute_011.outputs[0], store_named_attribute_2.inputs[0])
	    #face_area.Area -> store_named_attribute_2.Value
	    ob_data.links.new(face_area.outputs[0], store_named_attribute_2.inputs[3])
	    #store_named_attribute_2.Geometry -> store_named_attribute_004.Geometry
	    ob_data.links.new(store_named_attribute_2.outputs[0], store_named_attribute_004.inputs[0])
	    #corners_of_face.Total -> store_named_attribute_004.Value
	    ob_data.links.new(corners_of_face.outputs[1], store_named_attribute_004.inputs[3])
	    #index_2.Index -> store_named_attribute_005.Value
	    ob_data.links.new(index_2.outputs[0], store_named_attribute_005.inputs[3])
	    #vertex_neighbors.Vertex Count -> store_named_attribute_002.Value
	    ob_data.links.new(vertex_neighbors.outputs[0], store_named_attribute_002.inputs[3])
	    #store_named_attribute_005.Geometry -> store_named_attribute_002.Geometry
	    ob_data.links.new(store_named_attribute_005.outputs[0], store_named_attribute_002.inputs[0])
	    #vertex_neighbors.Face Count -> store_named_attribute_003.Value
	    ob_data.links.new(vertex_neighbors.outputs[1], store_named_attribute_003.inputs[3])
	    #store_named_attribute_002.Geometry -> store_named_attribute_003.Geometry
	    ob_data.links.new(store_named_attribute_002.outputs[0], store_named_attribute_003.inputs[0])
	    #store_named_attribute_006.Geometry -> store_named_attribute_007.Geometry
	    ob_data.links.new(store_named_attribute_006.outputs[0], store_named_attribute_007.inputs[0])
	    #store_named_attribute_003.Geometry -> store_named_attribute_006.Geometry
	    ob_data.links.new(store_named_attribute_003.outputs[0], store_named_attribute_006.inputs[0])
	    #corners_of_vertex.Corner Index -> store_named_attribute_007.Value
	    ob_data.links.new(corners_of_vertex.outputs[0], store_named_attribute_007.inputs[3])
	    #face_of_corner.Face Index -> store_named_attribute_006.Value
	    ob_data.links.new(face_of_corner.outputs[0], store_named_attribute_006.inputs[3])
	    #group_input_7.Geometry -> store_named_attribute_005.Geometry
	    ob_data.links.new(group_input_7.outputs[0], store_named_attribute_005.inputs[0])
	    #store_named_attribute_013.Geometry -> store_named_attribute_010.Geometry
	    ob_data.links.new(store_named_attribute_013.outputs[0], store_named_attribute_010.inputs[0])
	    #store_named_attribute_007.Geometry -> store_named_attribute_012.Geometry
	    ob_data.links.new(store_named_attribute_007.outputs[0], store_named_attribute_012.inputs[0])
	    #store_named_attribute_012.Geometry -> store_named_attribute_013.Geometry
	    ob_data.links.new(store_named_attribute_012.outputs[0], store_named_attribute_013.inputs[0])
	    #edge_vertices_001.Vertex Index 1 -> store_named_attribute_012.Value
	    ob_data.links.new(edge_vertices_001.outputs[0], store_named_attribute_012.inputs[3])
	    #edge_vertices_001.Vertex Index 2 -> store_named_attribute_013.Value
	    ob_data.links.new(edge_vertices_001.outputs[1], store_named_attribute_013.inputs[3])
	    #face_of_corner_001.Index in Face -> store_named_attribute_009.Value
	    ob_data.links.new(face_of_corner_001.outputs[1], store_named_attribute_009.inputs[3])
	    #evaluate_at_index_002.Value -> store_named_attribute_014.Value
	    ob_data.links.new(evaluate_at_index_002.outputs[0], store_named_attribute_014.inputs[3])
	    #position_3.Position -> evaluate_at_index_002.Value
	    ob_data.links.new(position_3.outputs[0], evaluate_at_index_002.inputs[1])
	    #store_named_attribute_009.Geometry -> store_named_attribute_014.Geometry
	    ob_data.links.new(store_named_attribute_009.outputs[0], store_named_attribute_014.inputs[0])
	    #index_001_2.Index -> evaluate_at_index_002.Index
	    ob_data.links.new(index_001_2.outputs[0], evaluate_at_index_002.inputs[0])
	    #store_named_attribute_008.Geometry -> store_named_attribute_009.Geometry
	    ob_data.links.new(store_named_attribute_008.outputs[0], store_named_attribute_009.inputs[0])
	    #face_of_corner_001.Face Index -> store_named_attribute_008.Value
	    ob_data.links.new(face_of_corner_001.outputs[0], store_named_attribute_008.inputs[3])
	    #store_named_attribute_014.Geometry -> store_named_attribute_015.Geometry
	    ob_data.links.new(store_named_attribute_014.outputs[0], store_named_attribute_015.inputs[0])
	    #named_attribute_001_1.Attribute -> store_named_attribute_015.Value
	    ob_data.links.new(named_attribute_001_1.outputs[0], store_named_attribute_015.inputs[3])
	    #store_named_attribute_004.Geometry -> store_named_attribute_008.Geometry
	    ob_data.links.new(store_named_attribute_004.outputs[0], store_named_attribute_008.inputs[0])
	    #group_2.Geometry -> group_output_9.Geometry
	    ob_data.links.new(group_2.outputs[0], group_output_9.inputs[0])
	    #store_named_attribute_015.Geometry -> group_2.Geometry
	    ob_data.links.new(store_named_attribute_015.outputs[0], group_2.inputs[0])
	    return ob_data
	
	ob_data = ob_data_node_group()
	
	#initialize convex_curve_profile node group
	def convex_curve_profile_node_group():
	    convex_curve_profile = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "CONVEX_CURVE_PROFILE")
	
	    convex_curve_profile.color_tag = 'NONE'
	    convex_curve_profile.description = ""
	    convex_curve_profile.default_group_node_width = 140
	    
	
	
	    #convex_curve_profile interface
	    #Socket Geometry
	    geometry_socket_12 = convex_curve_profile.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_12.attribute_domain = 'POINT'
	
	    #Socket Geometry
	    geometry_socket_13 = convex_curve_profile.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_13.attribute_domain = 'POINT'
	
	    #Socket Surface
	    surface_socket = convex_curve_profile.interface.new_socket(name = "Surface", in_out='INPUT', socket_type = 'NodeSocketObject')
	    surface_socket.attribute_domain = 'POINT'
	
	
	    #initialize convex_curve_profile nodes
	    #node Group Output
	    group_output_10 = convex_curve_profile.nodes.new("NodeGroupOutput")
	    group_output_10.name = "Group Output"
	    group_output_10.is_active_output = True
	
	    #node Group Input
	    group_input_8 = convex_curve_profile.nodes.new("NodeGroupInput")
	    group_input_8.name = "Group Input"
	    group_input_8.outputs[0].hide = True
	    group_input_8.outputs[2].hide = True
	
	    #node Delete Geometry.001
	    delete_geometry_001 = convex_curve_profile.nodes.new("GeometryNodeDeleteGeometry")
	    delete_geometry_001.name = "Delete Geometry.001"
	    delete_geometry_001.hide = True
	    delete_geometry_001.domain = 'FACE'
	    delete_geometry_001.mode = 'ALL'
	
	    #node Sample Nearest
	    sample_nearest = convex_curve_profile.nodes.new("GeometryNodeSampleNearest")
	    sample_nearest.name = "Sample Nearest"
	    sample_nearest.hide = True
	    sample_nearest.domain = 'FACE'
	
	    #node Named Attribute.004
	    named_attribute_004_1 = convex_curve_profile.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute_004_1.name = "Named Attribute.004"
	    named_attribute_004_1.data_type = 'FLOAT_VECTOR'
	    #Name
	    named_attribute_004_1.inputs[0].default_value = "centers"
	
	    #node Sample Index
	    sample_index_2 = convex_curve_profile.nodes.new("GeometryNodeSampleIndex")
	    sample_index_2.name = "Sample Index"
	    sample_index_2.hide = True
	    sample_index_2.clamp = False
	    sample_index_2.data_type = 'FLOAT_VECTOR'
	    sample_index_2.domain = 'POINT'
	
	    #node Normal
	    normal = convex_curve_profile.nodes.new("GeometryNodeInputNormal")
	    normal.name = "Normal"
	    normal.legacy_corner_normals = False
	
	    #node Compare.001
	    compare_001_1 = convex_curve_profile.nodes.new("FunctionNodeCompare")
	    compare_001_1.name = "Compare.001"
	    compare_001_1.hide = True
	    compare_001_1.data_type = 'VECTOR'
	    compare_001_1.mode = 'DOT_PRODUCT'
	    compare_001_1.operation = 'LESS_THAN'
	    compare_001_1.inputs[0].hide = True
	    compare_001_1.inputs[1].hide = True
	    compare_001_1.inputs[2].hide = True
	    compare_001_1.inputs[3].hide = True
	    compare_001_1.inputs[6].hide = True
	    compare_001_1.inputs[7].hide = True
	    compare_001_1.inputs[8].hide = True
	    compare_001_1.inputs[9].hide = True
	    compare_001_1.inputs[10].hide = True
	    compare_001_1.inputs[11].hide = True
	    compare_001_1.inputs[12].hide = True
	    #C
	    compare_001_1.inputs[10].default_value = 0.0
	
	    #node Sample Index.001
	    sample_index_001_2 = convex_curve_profile.nodes.new("GeometryNodeSampleIndex")
	    sample_index_001_2.name = "Sample Index.001"
	    sample_index_001_2.hide = True
	    sample_index_001_2.clamp = False
	    sample_index_001_2.data_type = 'FLOAT_VECTOR'
	    sample_index_001_2.domain = 'FACE'
	
	    #node Normal.001
	    normal_001 = convex_curve_profile.nodes.new("GeometryNodeInputNormal")
	    normal_001.name = "Normal.001"
	    normal_001.legacy_corner_normals = False
	
	    #node Index
	    index_3 = convex_curve_profile.nodes.new("GeometryNodeInputIndex")
	    index_3.name = "Index"
	
	    #node Delete Geometry.002
	    delete_geometry_002 = convex_curve_profile.nodes.new("GeometryNodeDeleteGeometry")
	    delete_geometry_002.name = "Delete Geometry.002"
	    delete_geometry_002.hide = True
	    delete_geometry_002.domain = 'EDGE'
	    delete_geometry_002.mode = 'EDGE_FACE'
	
	    #node Compare.002
	    compare_002_2 = convex_curve_profile.nodes.new("FunctionNodeCompare")
	    compare_002_2.name = "Compare.002"
	    compare_002_2.hide = True
	    compare_002_2.data_type = 'INT'
	    compare_002_2.mode = 'ELEMENT'
	    compare_002_2.operation = 'GREATER_THAN'
	    compare_002_2.inputs[0].hide = True
	    compare_002_2.inputs[1].hide = True
	    compare_002_2.inputs[3].hide = True
	    compare_002_2.inputs[4].hide = True
	    compare_002_2.inputs[5].hide = True
	    compare_002_2.inputs[6].hide = True
	    compare_002_2.inputs[7].hide = True
	    compare_002_2.inputs[8].hide = True
	    compare_002_2.inputs[9].hide = True
	    compare_002_2.inputs[10].hide = True
	    compare_002_2.inputs[11].hide = True
	    compare_002_2.inputs[12].hide = True
	    #B_INT
	    compare_002_2.inputs[3].default_value = 1
	
	    #node Edge Neighbors
	    edge_neighbors = convex_curve_profile.nodes.new("GeometryNodeInputMeshEdgeNeighbors")
	    edge_neighbors.name = "Edge Neighbors"
	
	    #node Merge by Distance.001
	    merge_by_distance_001 = convex_curve_profile.nodes.new("GeometryNodeMergeByDistance")
	    merge_by_distance_001.name = "Merge by Distance.001"
	    merge_by_distance_001.hide = True
	    merge_by_distance_001.mode = 'ALL'
	    #Selection
	    merge_by_distance_001.inputs[1].default_value = True
	    #Distance
	    merge_by_distance_001.inputs[2].default_value = 0.0010000000474974513
	
	    #node Object Info.001
	    object_info_001 = convex_curve_profile.nodes.new("GeometryNodeObjectInfo")
	    object_info_001.name = "Object Info.001"
	    object_info_001.hide = True
	    object_info_001.transform_space = 'RELATIVE'
	    object_info_001.inputs[1].hide = True
	    object_info_001.outputs[0].hide = True
	    object_info_001.outputs[1].hide = True
	    object_info_001.outputs[2].hide = True
	    object_info_001.outputs[3].hide = True
	    #As Instance
	    object_info_001.inputs[1].default_value = False
	
	    #node Mesh to Curve
	    mesh_to_curve_2 = convex_curve_profile.nodes.new("GeometryNodeMeshToCurve")
	    mesh_to_curve_2.name = "Mesh to Curve"
	    mesh_to_curve_2.hide = True
	    mesh_to_curve_2.inputs[1].hide = True
	    #Selection
	    mesh_to_curve_2.inputs[1].default_value = True
	
	    #node Group Input.001
	    group_input_001_6 = convex_curve_profile.nodes.new("NodeGroupInput")
	    group_input_001_6.name = "Group Input.001"
	    group_input_001_6.outputs[1].hide = True
	    group_input_001_6.outputs[2].hide = True
	
	    #node Group Input.002
	    group_input_002_5 = convex_curve_profile.nodes.new("NodeGroupInput")
	    group_input_002_5.name = "Group Input.002"
	    group_input_002_5.outputs[1].hide = True
	    group_input_002_5.outputs[2].hide = True
	
	
	
	
	
	    #Set locations
	    group_output_10.location = (-131.0277099609375, -136.95811462402344)
	    group_input_8.location = (-1372.7032470703125, 0.0)
	    delete_geometry_001.location = (-493.7367858886719, -158.619873046875)
	    sample_nearest.location = (-1047.2716064453125, -74.38338470458984)
	    named_attribute_004_1.location = (-1049.729248046875, -104.1408462524414)
	    sample_index_2.location = (-867.6522827148438, -34.97990036010742)
	    normal.location = (-871.3107299804688, -66.765625)
	    compare_001_1.location = (-673.4129638671875, -168.19537353515625)
	    sample_index_001_2.location = (-858.5, -306.8774108886719)
	    normal_001.location = (-1051.0888671875, -297.31158447265625)
	    index_3.location = (-1051.08349609375, -356.73614501953125)
	    delete_geometry_002.location = (-313.3856201171875, -217.2752685546875)
	    compare_002_2.location = (-312.8627624511719, -254.32992553710938)
	    edge_neighbors.location = (-312.9332580566406, -286.8948669433594)
	    merge_by_distance_001.location = (-493.1096496582031, -211.0828094482422)
	    object_info_001.location = (-1184.5113525390625, -24.985580444335938)
	    mesh_to_curve_2.location = (-310.79290771484375, -162.5512237548828)
	    group_input_001_6.location = (-1051.9151611328125, -236.2948760986328)
	    group_input_002_5.location = (-496.93218994140625, -82.70318603515625)
	
	    #Set dimensions
	    group_output_10.width, group_output_10.height = 140.0, 100.0
	    group_input_8.width, group_input_8.height = 140.0, 100.0
	    delete_geometry_001.width, delete_geometry_001.height = 140.0, 100.0
	    sample_nearest.width, sample_nearest.height = 140.0, 100.0
	    named_attribute_004_1.width, named_attribute_004_1.height = 140.0, 100.0
	    sample_index_2.width, sample_index_2.height = 140.0, 100.0
	    normal.width, normal.height = 140.0, 100.0
	    compare_001_1.width, compare_001_1.height = 140.0, 100.0
	    sample_index_001_2.width, sample_index_001_2.height = 140.0, 100.0
	    normal_001.width, normal_001.height = 140.0, 100.0
	    index_3.width, index_3.height = 140.0, 100.0
	    delete_geometry_002.width, delete_geometry_002.height = 140.0, 100.0
	    compare_002_2.width, compare_002_2.height = 140.0, 100.0
	    edge_neighbors.width, edge_neighbors.height = 140.0, 100.0
	    merge_by_distance_001.width, merge_by_distance_001.height = 140.0, 100.0
	    object_info_001.width, object_info_001.height = 140.0, 100.0
	    mesh_to_curve_2.width, mesh_to_curve_2.height = 140.0, 100.0
	    group_input_001_6.width, group_input_001_6.height = 140.0, 100.0
	    group_input_002_5.width, group_input_002_5.height = 140.0, 100.0
	
	    #initialize convex_curve_profile links
	    #sample_index_2.Value -> compare_001_1.A
	    convex_curve_profile.links.new(sample_index_2.outputs[0], compare_001_1.inputs[4])
	    #compare_001_1.Result -> delete_geometry_001.Selection
	    convex_curve_profile.links.new(compare_001_1.outputs[0], delete_geometry_001.inputs[1])
	    #named_attribute_004_1.Attribute -> sample_nearest.Sample Position
	    convex_curve_profile.links.new(named_attribute_004_1.outputs[0], sample_nearest.inputs[1])
	    #sample_nearest.Index -> sample_index_2.Index
	    convex_curve_profile.links.new(sample_nearest.outputs[0], sample_index_2.inputs[2])
	    #object_info_001.Geometry -> sample_index_2.Geometry
	    convex_curve_profile.links.new(object_info_001.outputs[4], sample_index_2.inputs[0])
	    #normal_001.Normal -> sample_index_001_2.Value
	    convex_curve_profile.links.new(normal_001.outputs[0], sample_index_001_2.inputs[1])
	    #edge_neighbors.Face Count -> compare_002_2.A
	    convex_curve_profile.links.new(edge_neighbors.outputs[0], compare_002_2.inputs[2])
	    #index_3.Index -> sample_index_001_2.Index
	    convex_curve_profile.links.new(index_3.outputs[0], sample_index_001_2.inputs[2])
	    #compare_002_2.Result -> delete_geometry_002.Selection
	    convex_curve_profile.links.new(compare_002_2.outputs[0], delete_geometry_002.inputs[1])
	    #sample_index_001_2.Value -> compare_001_1.B
	    convex_curve_profile.links.new(sample_index_001_2.outputs[0], compare_001_1.inputs[5])
	    #merge_by_distance_001.Geometry -> delete_geometry_002.Geometry
	    convex_curve_profile.links.new(merge_by_distance_001.outputs[0], delete_geometry_002.inputs[0])
	    #object_info_001.Geometry -> sample_nearest.Geometry
	    convex_curve_profile.links.new(object_info_001.outputs[4], sample_nearest.inputs[0])
	    #normal.Normal -> sample_index_2.Value
	    convex_curve_profile.links.new(normal.outputs[0], sample_index_2.inputs[1])
	    #delete_geometry_001.Geometry -> merge_by_distance_001.Geometry
	    convex_curve_profile.links.new(delete_geometry_001.outputs[0], merge_by_distance_001.inputs[0])
	    #group_input_8.Surface -> object_info_001.Object
	    convex_curve_profile.links.new(group_input_8.outputs[1], object_info_001.inputs[0])
	    #delete_geometry_002.Geometry -> mesh_to_curve_2.Mesh
	    convex_curve_profile.links.new(delete_geometry_002.outputs[0], mesh_to_curve_2.inputs[0])
	    #mesh_to_curve_2.Curve -> group_output_10.Geometry
	    convex_curve_profile.links.new(mesh_to_curve_2.outputs[0], group_output_10.inputs[0])
	    #group_input_001_6.Geometry -> sample_index_001_2.Geometry
	    convex_curve_profile.links.new(group_input_001_6.outputs[0], sample_index_001_2.inputs[0])
	    #group_input_002_5.Geometry -> delete_geometry_001.Geometry
	    convex_curve_profile.links.new(group_input_002_5.outputs[0], delete_geometry_001.inputs[0])
	    return convex_curve_profile
	
	convex_curve_profile = convex_curve_profile_node_group()
	
	#initialize curve_from_centroids node group
	def curve_from_centroids_node_group():
	    curve_from_centroids = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "CURVE_FROM_CENTROIDS")
	
	    curve_from_centroids.color_tag = 'NONE'
	    curve_from_centroids.description = "Create new curve from centroids of multiple curves."
	    curve_from_centroids.default_group_node_width = 140
	    
	
	    curve_from_centroids.is_modifier = True
	
	    #curve_from_centroids interface
	    #Socket Geometry
	    geometry_socket_14 = curve_from_centroids.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_14.attribute_domain = 'POINT'
	    geometry_socket_14.description = "New curve along centroid."
	
	    #Socket Geometry
	    geometry_socket_15 = curve_from_centroids.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_15.attribute_domain = 'POINT'
	    geometry_socket_15.description = "Curve with multiple splines."
	
	
	    #initialize curve_from_centroids nodes
	    #node Group Output
	    group_output_11 = curve_from_centroids.nodes.new("NodeGroupOutput")
	    group_output_11.name = "Group Output"
	    group_output_11.is_active_output = True
	    group_output_11.inputs[1].hide = True
	
	    #node Group Input
	    group_input_9 = curve_from_centroids.nodes.new("NodeGroupInput")
	    group_input_9.name = "Group Input"
	    group_input_9.outputs[1].hide = True
	
	    #node Repeat Input
	    repeat_input = curve_from_centroids.nodes.new("GeometryNodeRepeatInput")
	    repeat_input.name = "Repeat Input"
	    #node Repeat Output
	    repeat_output = curve_from_centroids.nodes.new("GeometryNodeRepeatOutput")
	    repeat_output.name = "Repeat Output"
	    repeat_output.active_index = 0
	    repeat_output.inspection_index = 0
	    repeat_output.repeat_items.clear()
	    # Create item "Geometry"
	    repeat_output.repeat_items.new('GEOMETRY', "Geometry")
	
	    #node Domain Size
	    domain_size = curve_from_centroids.nodes.new("GeometryNodeAttributeDomainSize")
	    domain_size.name = "Domain Size"
	    domain_size.hide = True
	    domain_size.component = 'CURVE'
	
	    #node Math
	    math_3 = curve_from_centroids.nodes.new("ShaderNodeMath")
	    math_3.name = "Math"
	    math_3.hide = True
	    math_3.operation = 'DIVIDE'
	    math_3.use_clamp = False
	
	    #node Attribute Statistic
	    attribute_statistic_1 = curve_from_centroids.nodes.new("GeometryNodeAttributeStatistic")
	    attribute_statistic_1.name = "Attribute Statistic"
	    attribute_statistic_1.hide = True
	    attribute_statistic_1.data_type = 'FLOAT_VECTOR'
	    attribute_statistic_1.domain = 'POINT'
	    attribute_statistic_1.outputs[1].hide = True
	    attribute_statistic_1.outputs[2].hide = True
	    attribute_statistic_1.outputs[3].hide = True
	    attribute_statistic_1.outputs[4].hide = True
	    attribute_statistic_1.outputs[5].hide = True
	    attribute_statistic_1.outputs[6].hide = True
	    attribute_statistic_1.outputs[7].hide = True
	
	    #node Position
	    position_4 = curve_from_centroids.nodes.new("GeometryNodeInputPosition")
	    position_4.name = "Position"
	
	    #node Compare
	    compare_2 = curve_from_centroids.nodes.new("FunctionNodeCompare")
	    compare_2.name = "Compare"
	    compare_2.hide = True
	    compare_2.data_type = 'INT'
	    compare_2.mode = 'ELEMENT'
	    compare_2.operation = 'EQUAL'
	    compare_2.inputs[0].hide = True
	    compare_2.inputs[1].hide = True
	    compare_2.inputs[4].hide = True
	    compare_2.inputs[5].hide = True
	    compare_2.inputs[6].hide = True
	    compare_2.inputs[7].hide = True
	    compare_2.inputs[8].hide = True
	    compare_2.inputs[9].hide = True
	    compare_2.inputs[10].hide = True
	    compare_2.inputs[11].hide = True
	    compare_2.inputs[12].hide = True
	
	    #node Index
	    index_4 = curve_from_centroids.nodes.new("GeometryNodeInputIndex")
	    index_4.name = "Index"
	
	    #node Math.001
	    math_001_3 = curve_from_centroids.nodes.new("ShaderNodeMath")
	    math_001_3.name = "Math.001"
	    math_001_3.hide = True
	    math_001_3.operation = 'FLOORED_MODULO'
	    math_001_3.use_clamp = False
	
	    #node Join Geometry
	    join_geometry_2 = curve_from_centroids.nodes.new("GeometryNodeJoinGeometry")
	    join_geometry_2.name = "Join Geometry"
	    join_geometry_2.hide = True
	
	    #node Points
	    points = curve_from_centroids.nodes.new("GeometryNodePoints")
	    points.name = "Points"
	    points.hide = True
	    points.inputs[0].hide = True
	    points.inputs[2].hide = True
	    #Count
	    points.inputs[0].default_value = 1
	    #Radius
	    points.inputs[2].default_value = 0.10000000149011612
	
	    #node Points to Curves
	    points_to_curves = curve_from_centroids.nodes.new("GeometryNodePointsToCurves")
	    points_to_curves.name = "Points to Curves"
	    points_to_curves.inputs[1].hide = True
	    points_to_curves.inputs[2].hide = True
	    #Curve Group ID
	    points_to_curves.inputs[1].default_value = 0
	    #Weight
	    points_to_curves.inputs[2].default_value = 0.0
	
	    #node Group Input.001
	    group_input_001_7 = curve_from_centroids.nodes.new("NodeGroupInput")
	    group_input_001_7.name = "Group Input.001"
	    group_input_001_7.outputs[1].hide = True
	
	    #node Reroute
	    reroute_4 = curve_from_centroids.nodes.new("NodeReroute")
	    reroute_4.name = "Reroute"
	    reroute_4.socket_idname = "NodeSocketFloat"
	    #node Reroute.001
	    reroute_001_3 = curve_from_centroids.nodes.new("NodeReroute")
	    reroute_001_3.name = "Reroute.001"
	    reroute_001_3.socket_idname = "NodeSocketFloat"
	
	    #Process zone input Repeat Input
	    repeat_input.pair_with_output(repeat_output)
	
	
	
	
	
	    #Set locations
	    group_output_11.location = (1302.4775390625, -33.473915100097656)
	    group_input_9.location = (-200.0, 0.0)
	    repeat_input.location = (190.50888061523438, -15.57342529296875)
	    repeat_output.location = (960.9061279296875, -56.923553466796875)
	    domain_size.location = (-17.454999923706055, -24.502897262573242)
	    math_3.location = (-15.655715942382812, -60.950531005859375)
	    attribute_statistic_1.location = (601.8110961914062, -193.2510528564453)
	    position_4.location = (603.0748901367188, -224.40174865722656)
	    compare_2.location = (421.454833984375, -243.2841339111328)
	    index_4.location = (420.0198974609375, -145.9272918701172)
	    math_001_3.location = (419.6551513671875, -207.2341766357422)
	    join_geometry_2.location = (780.789794921875, -82.40153503417969)
	    points.location = (778.607666015625, -120.22016906738281)
	    points_to_curves.location = (1130.0872802734375, -31.979248046875)
	    group_input_001_7.location = (600.9574584960938, -131.9265899658203)
	    reroute_4.location = (162.4088134765625, -72.65477752685547)
	    reroute_001_3.location = (165.49166870117188, -227.18580627441406)
	
	    #Set dimensions
	    group_output_11.width, group_output_11.height = 140.0, 100.0
	    group_input_9.width, group_input_9.height = 140.0, 100.0
	    repeat_input.width, repeat_input.height = 140.0, 100.0
	    repeat_output.width, repeat_output.height = 140.0, 100.0
	    domain_size.width, domain_size.height = 140.0, 100.0
	    math_3.width, math_3.height = 140.0, 100.0
	    attribute_statistic_1.width, attribute_statistic_1.height = 140.0, 100.0
	    position_4.width, position_4.height = 140.0, 100.0
	    compare_2.width, compare_2.height = 140.0, 100.0
	    index_4.width, index_4.height = 140.0, 100.0
	    math_001_3.width, math_001_3.height = 140.0, 100.0
	    join_geometry_2.width, join_geometry_2.height = 140.0, 100.0
	    points.width, points.height = 140.0, 100.0
	    points_to_curves.width, points_to_curves.height = 140.0, 100.0
	    group_input_001_7.width, group_input_001_7.height = 140.0, 100.0
	    reroute_4.width, reroute_4.height = 100.0, 100.0
	    reroute_001_3.width, reroute_001_3.height = 100.0, 100.0
	
	    #initialize curve_from_centroids links
	    #group_input_9.Geometry -> domain_size.Geometry
	    curve_from_centroids.links.new(group_input_9.outputs[0], domain_size.inputs[0])
	    #domain_size.Point Count -> math_3.Value
	    curve_from_centroids.links.new(domain_size.outputs[0], math_3.inputs[0])
	    #domain_size.Spline Count -> math_3.Value
	    curve_from_centroids.links.new(domain_size.outputs[4], math_3.inputs[1])
	    #reroute_4.Output -> repeat_input.Iterations
	    curve_from_centroids.links.new(reroute_4.outputs[0], repeat_input.inputs[0])
	    #position_4.Position -> attribute_statistic_1.Attribute
	    curve_from_centroids.links.new(position_4.outputs[0], attribute_statistic_1.inputs[2])
	    #index_4.Index -> math_001_3.Value
	    curve_from_centroids.links.new(index_4.outputs[0], math_001_3.inputs[0])
	    #reroute_001_3.Output -> math_001_3.Value
	    curve_from_centroids.links.new(reroute_001_3.outputs[0], math_001_3.inputs[1])
	    #compare_2.Result -> attribute_statistic_1.Selection
	    curve_from_centroids.links.new(compare_2.outputs[0], attribute_statistic_1.inputs[1])
	    #repeat_input.Iteration -> compare_2.B
	    curve_from_centroids.links.new(repeat_input.outputs[0], compare_2.inputs[3])
	    #math_001_3.Value -> compare_2.A
	    curve_from_centroids.links.new(math_001_3.outputs[0], compare_2.inputs[2])
	    #join_geometry_2.Geometry -> repeat_output.Geometry
	    curve_from_centroids.links.new(join_geometry_2.outputs[0], repeat_output.inputs[0])
	    #attribute_statistic_1.Mean -> points.Position
	    curve_from_centroids.links.new(attribute_statistic_1.outputs[0], points.inputs[1])
	    #points.Points -> join_geometry_2.Geometry
	    curve_from_centroids.links.new(points.outputs[0], join_geometry_2.inputs[0])
	    #repeat_output.Geometry -> points_to_curves.Points
	    curve_from_centroids.links.new(repeat_output.outputs[0], points_to_curves.inputs[0])
	    #group_input_001_7.Geometry -> attribute_statistic_1.Geometry
	    curve_from_centroids.links.new(group_input_001_7.outputs[0], attribute_statistic_1.inputs[0])
	    #points_to_curves.Curves -> group_output_11.Geometry
	    curve_from_centroids.links.new(points_to_curves.outputs[0], group_output_11.inputs[0])
	    #math_3.Value -> reroute_4.Input
	    curve_from_centroids.links.new(math_3.outputs[0], reroute_4.inputs[0])
	    #reroute_4.Output -> reroute_001_3.Input
	    curve_from_centroids.links.new(reroute_4.outputs[0], reroute_001_3.inputs[0])
	    #repeat_input.Geometry -> join_geometry_2.Geometry
	    curve_from_centroids.links.new(repeat_input.outputs[1], join_geometry_2.inputs[0])
	    return curve_from_centroids
	
	curve_from_centroids = curve_from_centroids_node_group()
	
	#initialize curve_root_002 node group
	def curve_root_002_node_group():
	    curve_root_002 = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Curve Root.002")
	
	    curve_root_002.color_tag = 'INPUT'
	    curve_root_002.description = "Reads information about each curve's root point"
	    curve_root_002.default_group_node_width = 140
	    
	
	
	    #curve_root_002 interface
	    #Socket Root Selection
	    root_selection_socket_1 = curve_root_002.interface.new_socket(name = "Root Selection", in_out='OUTPUT', socket_type = 'NodeSocketBool')
	    root_selection_socket_1.default_value = False
	    root_selection_socket_1.attribute_domain = 'POINT'
	    root_selection_socket_1.description = "Boolean selection of curve root points"
	
	    #Socket Root Position
	    root_position_socket_1 = curve_root_002.interface.new_socket(name = "Root Position", in_out='OUTPUT', socket_type = 'NodeSocketVector')
	    root_position_socket_1.default_value = (0.0, 0.0, 0.0)
	    root_position_socket_1.min_value = -3.4028234663852886e+38
	    root_position_socket_1.max_value = 3.4028234663852886e+38
	    root_position_socket_1.subtype = 'NONE'
	    root_position_socket_1.attribute_domain = 'CURVE'
	    root_position_socket_1.description = "Position of the root point of a curve"
	
	    #Socket Root Direction
	    root_direction_socket_1 = curve_root_002.interface.new_socket(name = "Root Direction", in_out='OUTPUT', socket_type = 'NodeSocketVector')
	    root_direction_socket_1.default_value = (0.0, 0.0, 0.0)
	    root_direction_socket_1.min_value = -3.4028234663852886e+38
	    root_direction_socket_1.max_value = 3.4028234663852886e+38
	    root_direction_socket_1.subtype = 'NONE'
	    root_direction_socket_1.attribute_domain = 'CURVE'
	    root_direction_socket_1.description = "Direction of the root segment of a curve"
	
	    #Socket Root Index
	    root_index_socket_1 = curve_root_002.interface.new_socket(name = "Root Index", in_out='OUTPUT', socket_type = 'NodeSocketInt')
	    root_index_socket_1.default_value = 0
	    root_index_socket_1.min_value = -2147483648
	    root_index_socket_1.max_value = 2147483647
	    root_index_socket_1.subtype = 'NONE'
	    root_index_socket_1.attribute_domain = 'CURVE'
	    root_index_socket_1.description = "Index of the root point of a curve"
	
	
	    #initialize curve_root_002 nodes
	    #node Position.002
	    position_002_4 = curve_root_002.nodes.new("GeometryNodeInputPosition")
	    position_002_4.name = "Position.002"
	
	    #node Interpolate Domain
	    interpolate_domain_3 = curve_root_002.nodes.new("GeometryNodeFieldOnDomain")
	    interpolate_domain_3.name = "Interpolate Domain"
	    interpolate_domain_3.data_type = 'INT'
	    interpolate_domain_3.domain = 'CURVE'
	
	    #node Field at Index.003
	    field_at_index_003_1 = curve_root_002.nodes.new("GeometryNodeFieldAtIndex")
	    field_at_index_003_1.name = "Field at Index.003"
	    field_at_index_003_1.data_type = 'FLOAT_VECTOR'
	    field_at_index_003_1.domain = 'POINT'
	
	    #node Interpolate Domain.001
	    interpolate_domain_001_1 = curve_root_002.nodes.new("GeometryNodeFieldOnDomain")
	    interpolate_domain_001_1.name = "Interpolate Domain.001"
	    interpolate_domain_001_1.data_type = 'FLOAT_VECTOR'
	    interpolate_domain_001_1.domain = 'CURVE'
	
	    #node Curve Tangent
	    curve_tangent_2 = curve_root_002.nodes.new("GeometryNodeInputTangent")
	    curve_tangent_2.name = "Curve Tangent"
	
	    #node Endpoint Selection
	    endpoint_selection_2 = curve_root_002.nodes.new("GeometryNodeCurveEndpointSelection")
	    endpoint_selection_2.name = "Endpoint Selection"
	    #Start Size
	    endpoint_selection_2.inputs[0].default_value = 1
	    #End Size
	    endpoint_selection_2.inputs[1].default_value = 0
	
	    #node Field at Index.004
	    field_at_index_004_1 = curve_root_002.nodes.new("GeometryNodeFieldAtIndex")
	    field_at_index_004_1.name = "Field at Index.004"
	    field_at_index_004_1.data_type = 'FLOAT_VECTOR'
	    field_at_index_004_1.domain = 'POINT'
	
	    #node Interpolate Domain.002
	    interpolate_domain_002_2 = curve_root_002.nodes.new("GeometryNodeFieldOnDomain")
	    interpolate_domain_002_2.name = "Interpolate Domain.002"
	    interpolate_domain_002_2.data_type = 'FLOAT_VECTOR'
	    interpolate_domain_002_2.domain = 'CURVE'
	
	    #node Group Output
	    group_output_12 = curve_root_002.nodes.new("NodeGroupOutput")
	    group_output_12.name = "Group Output"
	    group_output_12.is_active_output = True
	
	    #node Points of Curve
	    points_of_curve_1 = curve_root_002.nodes.new("GeometryNodePointsOfCurve")
	    points_of_curve_1.name = "Points of Curve"
	    points_of_curve_1.inputs[0].hide = True
	    points_of_curve_1.inputs[1].hide = True
	    points_of_curve_1.outputs[1].hide = True
	    #Curve Index
	    points_of_curve_1.inputs[0].default_value = 0
	    #Weights
	    points_of_curve_1.inputs[1].default_value = 0.0
	    #Sort Index
	    points_of_curve_1.inputs[2].default_value = 0
	
	
	
	
	
	    #Set locations
	    position_002_4.location = (-608.1627807617188, -70.55814361572266)
	    interpolate_domain_3.location = (-608.1627807617188, 90.18604278564453)
	    field_at_index_003_1.location = (-407.2325439453125, 70.09302520751953)
	    interpolate_domain_001_1.location = (-206.30230712890625, 70.09302520751953)
	    curve_tangent_2.location = (-608.1627807617188, -271.4883728027344)
	    endpoint_selection_2.location = (-206.30230712890625, 190.65118408203125)
	    field_at_index_004_1.location = (-407.2325439453125, -130.83721923828125)
	    interpolate_domain_002_2.location = (-206.30230712890625, -130.83721923828125)
	    group_output_12.location = (75.0, 50.0)
	    points_of_curve_1.location = (-789.0, 50.0)
	
	    #Set dimensions
	    position_002_4.width, position_002_4.height = 140.0, 100.0
	    interpolate_domain_3.width, interpolate_domain_3.height = 140.0, 100.0
	    field_at_index_003_1.width, field_at_index_003_1.height = 140.0, 100.0
	    interpolate_domain_001_1.width, interpolate_domain_001_1.height = 140.0, 100.0
	    curve_tangent_2.width, curve_tangent_2.height = 140.0, 100.0
	    endpoint_selection_2.width, endpoint_selection_2.height = 140.0, 100.0
	    field_at_index_004_1.width, field_at_index_004_1.height = 140.0, 100.0
	    interpolate_domain_002_2.width, interpolate_domain_002_2.height = 140.0, 100.0
	    group_output_12.width, group_output_12.height = 140.0, 100.0
	    points_of_curve_1.width, points_of_curve_1.height = 140.0, 100.0
	
	    #initialize curve_root_002 links
	    #position_002_4.Position -> field_at_index_003_1.Value
	    curve_root_002.links.new(position_002_4.outputs[0], field_at_index_003_1.inputs[1])
	    #interpolate_domain_001_1.Value -> group_output_12.Root Position
	    curve_root_002.links.new(interpolate_domain_001_1.outputs[0], group_output_12.inputs[1])
	    #interpolate_domain_3.Value -> field_at_index_003_1.Index
	    curve_root_002.links.new(interpolate_domain_3.outputs[0], field_at_index_003_1.inputs[0])
	    #points_of_curve_1.Point Index -> interpolate_domain_3.Value
	    curve_root_002.links.new(points_of_curve_1.outputs[0], interpolate_domain_3.inputs[0])
	    #interpolate_domain_3.Value -> group_output_12.Root Index
	    curve_root_002.links.new(interpolate_domain_3.outputs[0], group_output_12.inputs[3])
	    #endpoint_selection_2.Selection -> group_output_12.Root Selection
	    curve_root_002.links.new(endpoint_selection_2.outputs[0], group_output_12.inputs[0])
	    #field_at_index_003_1.Value -> interpolate_domain_001_1.Value
	    curve_root_002.links.new(field_at_index_003_1.outputs[0], interpolate_domain_001_1.inputs[0])
	    #interpolate_domain_002_2.Value -> group_output_12.Root Direction
	    curve_root_002.links.new(interpolate_domain_002_2.outputs[0], group_output_12.inputs[2])
	    #interpolate_domain_3.Value -> field_at_index_004_1.Index
	    curve_root_002.links.new(interpolate_domain_3.outputs[0], field_at_index_004_1.inputs[0])
	    #curve_tangent_2.Tangent -> field_at_index_004_1.Value
	    curve_root_002.links.new(curve_tangent_2.outputs[0], field_at_index_004_1.inputs[1])
	    #field_at_index_004_1.Value -> interpolate_domain_002_2.Value
	    curve_root_002.links.new(field_at_index_004_1.outputs[0], interpolate_domain_002_2.inputs[0])
	    return curve_root_002
	
	curve_root_002 = curve_root_002_node_group()
	
	#initialize curve_segment_001 node group
	def curve_segment_001_node_group():
	    curve_segment_001 = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Curve Segment.001")
	
	    curve_segment_001.color_tag = 'INPUT'
	    curve_segment_001.description = ""
	    curve_segment_001.default_group_node_width = 140
	    
	
	
	    #curve_segment_001 interface
	    #Socket Segment Length
	    segment_length_socket_1 = curve_segment_001.interface.new_socket(name = "Segment Length", in_out='OUTPUT', socket_type = 'NodeSocketFloat')
	    segment_length_socket_1.default_value = 0.0
	    segment_length_socket_1.min_value = -3.4028234663852886e+38
	    segment_length_socket_1.max_value = 3.4028234663852886e+38
	    segment_length_socket_1.subtype = 'NONE'
	    segment_length_socket_1.attribute_domain = 'POINT'
	    segment_length_socket_1.description = "Distance to previous point on curve"
	
	    #Socket Segment Direction
	    segment_direction_socket_1 = curve_segment_001.interface.new_socket(name = "Segment Direction", in_out='OUTPUT', socket_type = 'NodeSocketVector')
	    segment_direction_socket_1.default_value = (0.0, 0.0, 0.0)
	    segment_direction_socket_1.min_value = -3.4028234663852886e+38
	    segment_direction_socket_1.max_value = 3.4028234663852886e+38
	    segment_direction_socket_1.subtype = 'NONE'
	    segment_direction_socket_1.attribute_domain = 'POINT'
	    segment_direction_socket_1.description = "Direction from previous neighboring point on segment"
	
	    #Socket Neighbor Index
	    neighbor_index_socket_1 = curve_segment_001.interface.new_socket(name = "Neighbor Index", in_out='OUTPUT', socket_type = 'NodeSocketInt')
	    neighbor_index_socket_1.default_value = 0
	    neighbor_index_socket_1.min_value = -2147483648
	    neighbor_index_socket_1.max_value = 2147483647
	    neighbor_index_socket_1.subtype = 'NONE'
	    neighbor_index_socket_1.attribute_domain = 'POINT'
	    neighbor_index_socket_1.description = "Index of previous neighboring point on segment"
	
	
	    #initialize curve_segment_001 nodes
	    #node Vector Math.009
	    vector_math_009_1 = curve_segment_001.nodes.new("ShaderNodeVectorMath")
	    vector_math_009_1.name = "Vector Math.009"
	    vector_math_009_1.operation = 'NORMALIZE'
	
	    #node Reroute.015
	    reroute_015_1 = curve_segment_001.nodes.new("NodeReroute")
	    reroute_015_1.name = "Reroute.015"
	    reroute_015_1.socket_idname = "NodeSocketVector"
	    #node Reroute.017
	    reroute_017_1 = curve_segment_001.nodes.new("NodeReroute")
	    reroute_017_1.name = "Reroute.017"
	    reroute_017_1.socket_idname = "NodeSocketVector"
	    #node Field at Index.001
	    field_at_index_001_1 = curve_segment_001.nodes.new("GeometryNodeFieldAtIndex")
	    field_at_index_001_1.name = "Field at Index.001"
	    field_at_index_001_1.data_type = 'FLOAT_VECTOR'
	    field_at_index_001_1.domain = 'POINT'
	
	    #node Vector Math.008
	    vector_math_008_1 = curve_segment_001.nodes.new("ShaderNodeVectorMath")
	    vector_math_008_1.name = "Vector Math.008"
	    vector_math_008_1.operation = 'SUBTRACT'
	
	    #node Reroute.018
	    reroute_018_1 = curve_segment_001.nodes.new("NodeReroute")
	    reroute_018_1.name = "Reroute.018"
	    reroute_018_1.socket_idname = "NodeSocketInt"
	    #node Interpolate Domain.002
	    interpolate_domain_002_3 = curve_segment_001.nodes.new("GeometryNodeFieldOnDomain")
	    interpolate_domain_002_3.name = "Interpolate Domain.002"
	    interpolate_domain_002_3.data_type = 'FLOAT_VECTOR'
	    interpolate_domain_002_3.domain = 'POINT'
	
	    #node Group Output
	    group_output_13 = curve_segment_001.nodes.new("NodeGroupOutput")
	    group_output_13.name = "Group Output"
	    group_output_13.is_active_output = True
	
	    #node Vector Math.007
	    vector_math_007_1 = curve_segment_001.nodes.new("ShaderNodeVectorMath")
	    vector_math_007_1.name = "Vector Math.007"
	    vector_math_007_1.operation = 'LENGTH'
	
	    #node Interpolate Domain.003
	    interpolate_domain_003_1 = curve_segment_001.nodes.new("GeometryNodeFieldOnDomain")
	    interpolate_domain_003_1.name = "Interpolate Domain.003"
	    interpolate_domain_003_1.data_type = 'INT'
	    interpolate_domain_003_1.domain = 'POINT'
	
	    #node Reroute
	    reroute_5 = curve_segment_001.nodes.new("NodeReroute")
	    reroute_5.name = "Reroute"
	    reroute_5.socket_idname = "NodeSocketBool"
	    #node Switch.004
	    switch_004_1 = curve_segment_001.nodes.new("GeometryNodeSwitch")
	    switch_004_1.name = "Switch.004"
	    switch_004_1.hide = True
	    switch_004_1.input_type = 'VECTOR'
	    #False
	    switch_004_1.inputs[1].default_value = (0.0, 0.0, 0.0)
	
	    #node Switch.003
	    switch_003_2 = curve_segment_001.nodes.new("GeometryNodeSwitch")
	    switch_003_2.name = "Switch.003"
	    switch_003_2.hide = True
	    switch_003_2.input_type = 'FLOAT'
	    #False
	    switch_003_2.inputs[1].default_value = 0.0
	
	    #node Boolean
	    boolean_1 = curve_segment_001.nodes.new("FunctionNodeInputBool")
	    boolean_1.name = "Boolean"
	    boolean_1.boolean = True
	
	    #node Interpolate Domain
	    interpolate_domain_4 = curve_segment_001.nodes.new("GeometryNodeFieldOnDomain")
	    interpolate_domain_4.name = "Interpolate Domain"
	    interpolate_domain_4.data_type = 'BOOLEAN'
	    interpolate_domain_4.domain = 'CURVE'
	
	    #node Switch.005
	    switch_005_1 = curve_segment_001.nodes.new("GeometryNodeSwitch")
	    switch_005_1.name = "Switch.005"
	    switch_005_1.hide = True
	    switch_005_1.input_type = 'INT'
	    #False
	    switch_005_1.inputs[1].default_value = 0
	
	    #node Index.002
	    index_002_1 = curve_segment_001.nodes.new("GeometryNodeInputIndex")
	    index_002_1.name = "Index.002"
	
	    #node Switch.001
	    switch_001_3 = curve_segment_001.nodes.new("GeometryNodeSwitch")
	    switch_001_3.name = "Switch.001"
	    switch_001_3.input_type = 'INT'
	
	    #node Offset Point in Curve
	    offset_point_in_curve_1 = curve_segment_001.nodes.new("GeometryNodeOffsetPointInCurve")
	    offset_point_in_curve_1.name = "Offset Point in Curve"
	    #Point Index
	    offset_point_in_curve_1.inputs[0].default_value = 0
	    #Offset
	    offset_point_in_curve_1.inputs[1].default_value = -1
	
	    #node Position.002
	    position_002_5 = curve_segment_001.nodes.new("GeometryNodeInputPosition")
	    position_002_5.name = "Position.002"
	
	
	
	
	
	    #Set locations
	    vector_math_009_1.location = (-389.8524169921875, 30.443286895751953)
	    reroute_015_1.location = (-456.8948974609375, 4.604297637939453)
	    reroute_017_1.location = (-1012.7362060546875, -9.742748260498047)
	    field_at_index_001_1.location = (-992.6431884765625, 70.62931823730469)
	    vector_math_008_1.location = (-811.805908203125, 70.62931823730469)
	    reroute_018_1.location = (-1032.8292236328125, 110.81541442871094)
	    interpolate_domain_002_3.location = (-630.9686279296875, 70.62931823730469)
	    group_output_13.location = (75.0, 50.0)
	    vector_math_007_1.location = (-389.8524169921875, 151.00144958496094)
	    interpolate_domain_003_1.location = (-390.85833740234375, -97.25408935546875)
	    reroute_5.location = (-342.979248046875, 193.345458984375)
	    switch_004_1.location = (-178.8756103515625, 10.35025405883789)
	    switch_003_2.location = (-178.8756103515625, 90.72234344482422)
	    boolean_1.location = (-781.6663208007812, 291.652587890625)
	    interpolate_domain_4.location = (-600.8291015625, 311.74560546875)
	    switch_005_1.location = (-178.8756103515625, -70.0218505859375)
	    index_002_1.location = (-1404.550048828125, 211.28048706054688)
	    switch_001_3.location = (-1223.712890625, 231.37350463867188)
	    offset_point_in_curve_1.location = (-1404.550048828125, 151.0014190673828)
	    position_002_5.location = (-1223.712890625, 30.44327163696289)
	
	    #Set dimensions
	    vector_math_009_1.width, vector_math_009_1.height = 140.0, 100.0
	    reroute_015_1.width, reroute_015_1.height = 100.0, 100.0
	    reroute_017_1.width, reroute_017_1.height = 100.0, 100.0
	    field_at_index_001_1.width, field_at_index_001_1.height = 140.0, 100.0
	    vector_math_008_1.width, vector_math_008_1.height = 140.0, 100.0
	    reroute_018_1.width, reroute_018_1.height = 100.0, 100.0
	    interpolate_domain_002_3.width, interpolate_domain_002_3.height = 140.0, 100.0
	    group_output_13.width, group_output_13.height = 140.0, 100.0
	    vector_math_007_1.width, vector_math_007_1.height = 140.0, 100.0
	    interpolate_domain_003_1.width, interpolate_domain_003_1.height = 140.0, 100.0
	    reroute_5.width, reroute_5.height = 100.0, 100.0
	    switch_004_1.width, switch_004_1.height = 140.0, 100.0
	    switch_003_2.width, switch_003_2.height = 140.0, 100.0
	    boolean_1.width, boolean_1.height = 140.0, 100.0
	    interpolate_domain_4.width, interpolate_domain_4.height = 140.0, 100.0
	    switch_005_1.width, switch_005_1.height = 140.0, 100.0
	    index_002_1.width, index_002_1.height = 140.0, 100.0
	    switch_001_3.width, switch_001_3.height = 140.0, 100.0
	    offset_point_in_curve_1.width, offset_point_in_curve_1.height = 140.0, 100.0
	    position_002_5.width, position_002_5.height = 140.0, 100.0
	
	    #initialize curve_segment_001 links
	    #reroute_015_1.Output -> vector_math_007_1.Vector
	    curve_segment_001.links.new(reroute_015_1.outputs[0], vector_math_007_1.inputs[0])
	    #reroute_018_1.Output -> field_at_index_001_1.Index
	    curve_segment_001.links.new(reroute_018_1.outputs[0], field_at_index_001_1.inputs[0])
	    #vector_math_008_1.Vector -> interpolate_domain_002_3.Value
	    curve_segment_001.links.new(vector_math_008_1.outputs[0], interpolate_domain_002_3.inputs[0])
	    #reroute_017_1.Output -> vector_math_008_1.Vector
	    curve_segment_001.links.new(reroute_017_1.outputs[0], vector_math_008_1.inputs[0])
	    #reroute_015_1.Output -> vector_math_009_1.Vector
	    curve_segment_001.links.new(reroute_015_1.outputs[0], vector_math_009_1.inputs[0])
	    #reroute_017_1.Output -> field_at_index_001_1.Value
	    curve_segment_001.links.new(reroute_017_1.outputs[0], field_at_index_001_1.inputs[1])
	    #field_at_index_001_1.Value -> vector_math_008_1.Vector
	    curve_segment_001.links.new(field_at_index_001_1.outputs[0], vector_math_008_1.inputs[1])
	    #position_002_5.Position -> reroute_017_1.Input
	    curve_segment_001.links.new(position_002_5.outputs[0], reroute_017_1.inputs[0])
	    #interpolate_domain_002_3.Value -> reroute_015_1.Input
	    curve_segment_001.links.new(interpolate_domain_002_3.outputs[0], reroute_015_1.inputs[0])
	    #switch_004_1.Output -> group_output_13.Segment Direction
	    curve_segment_001.links.new(switch_004_1.outputs[0], group_output_13.inputs[1])
	    #switch_005_1.Output -> group_output_13.Neighbor Index
	    curve_segment_001.links.new(switch_005_1.outputs[0], group_output_13.inputs[2])
	    #boolean_1.Boolean -> interpolate_domain_4.Value
	    curve_segment_001.links.new(boolean_1.outputs[0], interpolate_domain_4.inputs[0])
	    #reroute_018_1.Output -> interpolate_domain_003_1.Value
	    curve_segment_001.links.new(reroute_018_1.outputs[0], interpolate_domain_003_1.inputs[0])
	    #vector_math_007_1.Value -> switch_003_2.True
	    curve_segment_001.links.new(vector_math_007_1.outputs[1], switch_003_2.inputs[2])
	    #reroute_5.Output -> switch_003_2.Switch
	    curve_segment_001.links.new(reroute_5.outputs[0], switch_003_2.inputs[0])
	    #switch_003_2.Output -> group_output_13.Segment Length
	    curve_segment_001.links.new(switch_003_2.outputs[0], group_output_13.inputs[0])
	    #vector_math_009_1.Vector -> switch_004_1.True
	    curve_segment_001.links.new(vector_math_009_1.outputs[0], switch_004_1.inputs[2])
	    #interpolate_domain_4.Value -> reroute_5.Input
	    curve_segment_001.links.new(interpolate_domain_4.outputs[0], reroute_5.inputs[0])
	    #reroute_5.Output -> switch_004_1.Switch
	    curve_segment_001.links.new(reroute_5.outputs[0], switch_004_1.inputs[0])
	    #interpolate_domain_003_1.Value -> switch_005_1.True
	    curve_segment_001.links.new(interpolate_domain_003_1.outputs[0], switch_005_1.inputs[2])
	    #reroute_5.Output -> switch_005_1.Switch
	    curve_segment_001.links.new(reroute_5.outputs[0], switch_005_1.inputs[0])
	    #offset_point_in_curve_1.Is Valid Offset -> switch_001_3.Switch
	    curve_segment_001.links.new(offset_point_in_curve_1.outputs[0], switch_001_3.inputs[0])
	    #offset_point_in_curve_1.Point Index -> switch_001_3.True
	    curve_segment_001.links.new(offset_point_in_curve_1.outputs[1], switch_001_3.inputs[2])
	    #index_002_1.Index -> switch_001_3.False
	    curve_segment_001.links.new(index_002_1.outputs[0], switch_001_3.inputs[1])
	    #switch_001_3.Output -> reroute_018_1.Input
	    curve_segment_001.links.new(switch_001_3.outputs[0], reroute_018_1.inputs[0])
	    return curve_segment_001
	
	curve_segment_001 = curve_segment_001_node_group()
	
	#initialize restore_curve_segment_length_001 node group
	def restore_curve_segment_length_001_node_group():
	    restore_curve_segment_length_001 = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Restore Curve Segment Length.001")
	
	    restore_curve_segment_length_001.color_tag = 'GEOMETRY'
	    restore_curve_segment_length_001.description = "Restores the length of each curve segment using a previous state after deformation"
	    restore_curve_segment_length_001.default_group_node_width = 140
	    
	
	    restore_curve_segment_length_001.is_modifier = True
	
	    #restore_curve_segment_length_001 interface
	    #Socket Curves
	    curves_socket_2 = restore_curve_segment_length_001.interface.new_socket(name = "Curves", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    curves_socket_2.attribute_domain = 'POINT'
	
	    #Socket Curves
	    curves_socket_3 = restore_curve_segment_length_001.interface.new_socket(name = "Curves", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    curves_socket_3.attribute_domain = 'POINT'
	
	    #Socket Selection
	    selection_socket_1 = restore_curve_segment_length_001.interface.new_socket(name = "Selection", in_out='INPUT', socket_type = 'NodeSocketBool')
	    selection_socket_1.default_value = True
	    selection_socket_1.attribute_domain = 'POINT'
	    selection_socket_1.hide_value = True
	    selection_socket_1.description = "Only affect selected elements"
	
	    #Socket Factor
	    factor_socket_1 = restore_curve_segment_length_001.interface.new_socket(name = "Factor", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    factor_socket_1.default_value = 1.0
	    factor_socket_1.min_value = 0.0
	    factor_socket_1.max_value = 1.0
	    factor_socket_1.subtype = 'FACTOR'
	    factor_socket_1.attribute_domain = 'POINT'
	    factor_socket_1.description = "Factor to blend overall effect"
	
	    #Socket Reference Position
	    reference_position_socket_1 = restore_curve_segment_length_001.interface.new_socket(name = "Reference Position", in_out='INPUT', socket_type = 'NodeSocketVector')
	    reference_position_socket_1.default_value = (8.146539688110352, 4.969870090484619, 9.874540328979492)
	    reference_position_socket_1.min_value = -3.4028234663852886e+38
	    reference_position_socket_1.max_value = 3.4028234663852886e+38
	    reference_position_socket_1.subtype = 'NONE'
	    reference_position_socket_1.default_attribute_name = "rest_position"
	    reference_position_socket_1.attribute_domain = 'POINT'
	    reference_position_socket_1.hide_value = True
	    reference_position_socket_1.description = "Reference position before deformation"
	
	    #Socket Pin at Parameter
	    pin_at_parameter_socket_1 = restore_curve_segment_length_001.interface.new_socket(name = "Pin at Parameter", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    pin_at_parameter_socket_1.default_value = 0.0
	    pin_at_parameter_socket_1.min_value = 0.0
	    pin_at_parameter_socket_1.max_value = 1.0
	    pin_at_parameter_socket_1.subtype = 'FACTOR'
	    pin_at_parameter_socket_1.attribute_domain = 'POINT'
	    pin_at_parameter_socket_1.description = "Pin each curve at a certain point for the operation"
	
	
	    #initialize restore_curve_segment_length_001 nodes
	    #node Frame.001
	    frame_001_3 = restore_curve_segment_length_001.nodes.new("NodeFrame")
	    frame_001_3.label = "Pin at Parameter"
	    frame_001_3.name = "Frame.001"
	    frame_001_3.label_size = 20
	    frame_001_3.shrink = True
	
	    #node Frame
	    frame_4 = restore_curve_segment_length_001.nodes.new("NodeFrame")
	    frame_4.label = "Restore Segment Lengths"
	    frame_4.name = "Frame"
	    frame_4.label_size = 20
	    frame_4.shrink = True
	
	    #node Frame.002
	    frame_002_3 = restore_curve_segment_length_001.nodes.new("NodeFrame")
	    frame_002_3.label = "Default Fallback"
	    frame_002_3.name = "Frame.002"
	    frame_002_3.label_size = 20
	    frame_002_3.shrink = True
	
	    #node Reroute.009
	    reroute_009_2 = restore_curve_segment_length_001.nodes.new("NodeReroute")
	    reroute_009_2.name = "Reroute.009"
	    reroute_009_2.socket_idname = "NodeSocketVector"
	    #node Group Input.006
	    group_input_006_1 = restore_curve_segment_length_001.nodes.new("NodeGroupInput")
	    group_input_006_1.name = "Group Input.006"
	    group_input_006_1.outputs[0].hide = True
	    group_input_006_1.outputs[1].hide = True
	    group_input_006_1.outputs[2].hide = True
	    group_input_006_1.outputs[3].hide = True
	    group_input_006_1.outputs[5].hide = True
	
	    #node Reroute.013
	    reroute_013_1 = restore_curve_segment_length_001.nodes.new("NodeReroute")
	    reroute_013_1.name = "Reroute.013"
	    reroute_013_1.socket_idname = "NodeSocketGeometry"
	    #node Index
	    index_5 = restore_curve_segment_length_001.nodes.new("GeometryNodeInputIndex")
	    index_5.name = "Index"
	
	    #node Sample Curve.001
	    sample_curve_001_1 = restore_curve_segment_length_001.nodes.new("GeometryNodeSampleCurve")
	    sample_curve_001_1.name = "Sample Curve.001"
	    sample_curve_001_1.data_type = 'FLOAT_VECTOR'
	    sample_curve_001_1.mode = 'FACTOR'
	    sample_curve_001_1.use_all_curves = False
	
	    #node Group Input.003
	    group_input_003_4 = restore_curve_segment_length_001.nodes.new("NodeGroupInput")
	    group_input_003_4.name = "Group Input.003"
	    group_input_003_4.outputs[0].hide = True
	    group_input_003_4.outputs[1].hide = True
	    group_input_003_4.outputs[2].hide = True
	    group_input_003_4.outputs[3].hide = True
	    group_input_003_4.outputs[5].hide = True
	
	    #node Vector Math.006
	    vector_math_006_1 = restore_curve_segment_length_001.nodes.new("ShaderNodeVectorMath")
	    vector_math_006_1.name = "Vector Math.006"
	    vector_math_006_1.hide = True
	    vector_math_006_1.operation = 'SUBTRACT'
	
	    #node Interpolate Domain
	    interpolate_domain_5 = restore_curve_segment_length_001.nodes.new("GeometryNodeFieldOnDomain")
	    interpolate_domain_5.name = "Interpolate Domain"
	    interpolate_domain_5.hide = True
	    interpolate_domain_5.data_type = 'FLOAT_VECTOR'
	    interpolate_domain_5.domain = 'CURVE'
	
	    #node Group Input.005
	    group_input_005_2 = restore_curve_segment_length_001.nodes.new("NodeGroupInput")
	    group_input_005_2.name = "Group Input.005"
	    group_input_005_2.outputs[0].hide = True
	    group_input_005_2.outputs[2].hide = True
	    group_input_005_2.outputs[3].hide = True
	    group_input_005_2.outputs[4].hide = True
	    group_input_005_2.outputs[5].hide = True
	
	    #node Boolean Math.002
	    boolean_math_002_1 = restore_curve_segment_length_001.nodes.new("FunctionNodeBooleanMath")
	    boolean_math_002_1.name = "Boolean Math.002"
	    boolean_math_002_1.hide = True
	    boolean_math_002_1.operation = 'AND'
	
	    #node Field at Index.002
	    field_at_index_002_1 = restore_curve_segment_length_001.nodes.new("GeometryNodeFieldAtIndex")
	    field_at_index_002_1.name = "Field at Index.002"
	    field_at_index_002_1.data_type = 'FLOAT_VECTOR'
	    field_at_index_002_1.domain = 'POINT'
	
	    #node Vector Math.004
	    vector_math_004_1 = restore_curve_segment_length_001.nodes.new("ShaderNodeVectorMath")
	    vector_math_004_1.name = "Vector Math.004"
	    vector_math_004_1.operation = 'DISTANCE'
	
	    #node Accumulate Field
	    accumulate_field_1 = restore_curve_segment_length_001.nodes.new("GeometryNodeAccumulateField")
	    accumulate_field_1.name = "Accumulate Field"
	    accumulate_field_1.data_type = 'FLOAT_VECTOR'
	    accumulate_field_1.domain = 'POINT'
	    accumulate_field_1.outputs[1].hide = True
	    accumulate_field_1.outputs[2].hide = True
	
	    #node Curve of Point
	    curve_of_point_1 = restore_curve_segment_length_001.nodes.new("GeometryNodeCurveOfPoint")
	    curve_of_point_1.name = "Curve of Point"
	    curve_of_point_1.inputs[0].hide = True
	    curve_of_point_1.outputs[1].hide = True
	    #Point Index
	    curve_of_point_1.inputs[0].default_value = 0
	
	    #node Vector Math
	    vector_math_4 = restore_curve_segment_length_001.nodes.new("ShaderNodeVectorMath")
	    vector_math_4.name = "Vector Math"
	    vector_math_4.operation = 'SCALE'
	
	    #node Index.001
	    index_001_3 = restore_curve_segment_length_001.nodes.new("GeometryNodeInputIndex")
	    index_001_3.name = "Index.001"
	
	    #node Curve of Point.001
	    curve_of_point_001_1 = restore_curve_segment_length_001.nodes.new("GeometryNodeCurveOfPoint")
	    curve_of_point_001_1.name = "Curve of Point.001"
	    curve_of_point_001_1.inputs[0].hide = True
	    curve_of_point_001_1.outputs[0].hide = True
	    #Point Index
	    curve_of_point_001_1.inputs[0].default_value = 0
	
	    #node Switch
	    switch_2 = restore_curve_segment_length_001.nodes.new("GeometryNodeSwitch")
	    switch_2.name = "Switch"
	    switch_2.input_type = 'INT'
	
	    #node Math
	    math_4 = restore_curve_segment_length_001.nodes.new("ShaderNodeMath")
	    math_4.name = "Math"
	    math_4.hide = True
	    math_4.operation = 'SUBTRACT'
	    math_4.use_clamp = False
	    #Value_001
	    math_4.inputs[1].default_value = 1.0
	
	    #node Compare
	    compare_3 = restore_curve_segment_length_001.nodes.new("FunctionNodeCompare")
	    compare_3.name = "Compare"
	    compare_3.hide = True
	    compare_3.data_type = 'INT'
	    compare_3.mode = 'ELEMENT'
	    compare_3.operation = 'EQUAL'
	    #B_INT
	    compare_3.inputs[3].default_value = 0
	
	    #node Reroute.001
	    reroute_001_4 = restore_curve_segment_length_001.nodes.new("NodeReroute")
	    reroute_001_4.name = "Reroute.001"
	    reroute_001_4.socket_idname = "NodeSocketVector"
	    #node Set Position.001
	    set_position_001_3 = restore_curve_segment_length_001.nodes.new("GeometryNodeSetPosition")
	    set_position_001_3.name = "Set Position.001"
	
	    #node Boolean Math
	    boolean_math_3 = restore_curve_segment_length_001.nodes.new("FunctionNodeBooleanMath")
	    boolean_math_3.name = "Boolean Math"
	    boolean_math_3.operation = 'AND'
	
	    #node Compare.002
	    compare_002_3 = restore_curve_segment_length_001.nodes.new("FunctionNodeCompare")
	    compare_002_3.name = "Compare.002"
	    compare_002_3.data_type = 'FLOAT'
	    compare_002_3.mode = 'ELEMENT'
	    compare_002_3.operation = 'GREATER_THAN'
	    #B
	    compare_002_3.inputs[1].default_value = 0.0
	
	    #node Group Input.002
	    group_input_002_6 = restore_curve_segment_length_001.nodes.new("NodeGroupInput")
	    group_input_002_6.name = "Group Input.002"
	    group_input_002_6.outputs[0].hide = True
	    group_input_002_6.outputs[3].hide = True
	    group_input_002_6.outputs[4].hide = True
	    group_input_002_6.outputs[5].hide = True
	
	    #node Reroute.016
	    reroute_016_1 = restore_curve_segment_length_001.nodes.new("NodeReroute")
	    reroute_016_1.name = "Reroute.016"
	    reroute_016_1.socket_idname = "NodeSocketBool"
	    #node Reroute.014
	    reroute_014_1 = restore_curve_segment_length_001.nodes.new("NodeReroute")
	    reroute_014_1.name = "Reroute.014"
	    reroute_014_1.socket_idname = "NodeSocketGeometry"
	    #node Switch.001
	    switch_001_4 = restore_curve_segment_length_001.nodes.new("GeometryNodeSwitch")
	    switch_001_4.name = "Switch.001"
	    switch_001_4.input_type = 'GEOMETRY'
	
	    #node Group Output
	    group_output_14 = restore_curve_segment_length_001.nodes.new("NodeGroupOutput")
	    group_output_14.name = "Group Output"
	    group_output_14.is_active_output = True
	
	    #node Attribute Statistic
	    attribute_statistic_2 = restore_curve_segment_length_001.nodes.new("GeometryNodeAttributeStatistic")
	    attribute_statistic_2.name = "Attribute Statistic"
	    attribute_statistic_2.hide = True
	    attribute_statistic_2.data_type = 'FLOAT'
	    attribute_statistic_2.domain = 'CURVE'
	    attribute_statistic_2.inputs[1].hide = True
	    attribute_statistic_2.outputs[0].hide = True
	    attribute_statistic_2.outputs[1].hide = True
	    attribute_statistic_2.outputs[2].hide = True
	    attribute_statistic_2.outputs[3].hide = True
	    attribute_statistic_2.outputs[5].hide = True
	    attribute_statistic_2.outputs[6].hide = True
	    attribute_statistic_2.outputs[7].hide = True
	    #Selection
	    attribute_statistic_2.inputs[1].default_value = True
	
	    #node Group
	    group_3 = restore_curve_segment_length_001.nodes.new("GeometryNodeGroup")
	    group_3.name = "Group"
	    group_3.node_tree = curve_root_002
	    group_3.outputs[0].hide = True
	    group_3.outputs[2].hide = True
	    group_3.outputs[3].hide = True
	
	    #node Reroute.007
	    reroute_007_2 = restore_curve_segment_length_001.nodes.new("NodeReroute")
	    reroute_007_2.name = "Reroute.007"
	    reroute_007_2.socket_idname = "NodeSocketVector"
	    #node Reroute.004
	    reroute_004_2 = restore_curve_segment_length_001.nodes.new("NodeReroute")
	    reroute_004_2.name = "Reroute.004"
	    reroute_004_2.socket_idname = "NodeSocketGeometry"
	    #node Position.001
	    position_001_2 = restore_curve_segment_length_001.nodes.new("GeometryNodeInputPosition")
	    position_001_2.name = "Position.001"
	
	    #node Named Attribute
	    named_attribute_2 = restore_curve_segment_length_001.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute_2.name = "Named Attribute"
	    named_attribute_2.data_type = 'FLOAT_VECTOR'
	    #Name
	    named_attribute_2.inputs[0].default_value = "rest_position"
	
	    #node Switch.003
	    switch_003_3 = restore_curve_segment_length_001.nodes.new("GeometryNodeSwitch")
	    switch_003_3.name = "Switch.003"
	    switch_003_3.input_type = 'VECTOR'
	
	    #node Reroute.006
	    reroute_006_2 = restore_curve_segment_length_001.nodes.new("NodeReroute")
	    reroute_006_2.name = "Reroute.006"
	    reroute_006_2.socket_idname = "NodeSocketVector"
	    #node Switch.002
	    switch_002_1 = restore_curve_segment_length_001.nodes.new("GeometryNodeSwitch")
	    switch_002_1.name = "Switch.002"
	    switch_002_1.input_type = 'VECTOR'
	
	    #node Compare.004
	    compare_004_1 = restore_curve_segment_length_001.nodes.new("FunctionNodeCompare")
	    compare_004_1.name = "Compare.004"
	    compare_004_1.data_type = 'VECTOR'
	    compare_004_1.mode = 'ELEMENT'
	    compare_004_1.operation = 'EQUAL'
	    #B_VEC3
	    compare_004_1.inputs[5].default_value = (8.146539688110352, 4.969870090484619, 9.874540328979492)
	    #Epsilon
	    compare_004_1.inputs[12].default_value = 0.0
	
	    #node Group Input
	    group_input_10 = restore_curve_segment_length_001.nodes.new("NodeGroupInput")
	    group_input_10.name = "Group Input"
	    group_input_10.outputs[1].hide = True
	    group_input_10.outputs[2].hide = True
	    group_input_10.outputs[4].hide = True
	    group_input_10.outputs[5].hide = True
	
	    #node Reroute.011
	    reroute_011_1 = restore_curve_segment_length_001.nodes.new("NodeReroute")
	    reroute_011_1.name = "Reroute.011"
	    reroute_011_1.socket_idname = "NodeSocketGeometry"
	    #node Reroute.005
	    reroute_005_2 = restore_curve_segment_length_001.nodes.new("NodeReroute")
	    reroute_005_2.name = "Reroute.005"
	    reroute_005_2.socket_idname = "NodeSocketGeometry"
	    #node Reroute.008
	    reroute_008_2 = restore_curve_segment_length_001.nodes.new("NodeReroute")
	    reroute_008_2.name = "Reroute.008"
	    reroute_008_2.socket_idname = "NodeSocketVector"
	    #node Set Position.002
	    set_position_002_2 = restore_curve_segment_length_001.nodes.new("GeometryNodeSetPosition")
	    set_position_002_2.name = "Set Position.002"
	    set_position_002_2.inputs[2].hide = True
	    #Position
	    set_position_002_2.inputs[2].default_value = (0.0, 0.0, 0.0)
	
	    #node Reroute.012
	    reroute_012_1 = restore_curve_segment_length_001.nodes.new("NodeReroute")
	    reroute_012_1.name = "Reroute.012"
	    reroute_012_1.socket_idname = "NodeSocketGeometry"
	    #node Group Input.001
	    group_input_001_8 = restore_curve_segment_length_001.nodes.new("NodeGroupInput")
	    group_input_001_8.name = "Group Input.001"
	    group_input_001_8.outputs[0].hide = True
	    group_input_001_8.outputs[1].hide = True
	    group_input_001_8.outputs[3].hide = True
	    group_input_001_8.outputs[4].hide = True
	    group_input_001_8.outputs[5].hide = True
	
	    #node Mix
	    mix_1 = restore_curve_segment_length_001.nodes.new("ShaderNodeMix")
	    mix_1.name = "Mix"
	    mix_1.blend_type = 'MIX'
	    mix_1.clamp_factor = True
	    mix_1.clamp_result = False
	    mix_1.data_type = 'FLOAT'
	    mix_1.factor_mode = 'UNIFORM'
	
	    #node Group.001
	    group_001_2 = restore_curve_segment_length_001.nodes.new("GeometryNodeGroup")
	    group_001_2.name = "Group.001"
	    group_001_2.node_tree = curve_segment_001
	    group_001_2.outputs[2].hide = True
	
	    #node Compare.003
	    compare_003_1 = restore_curve_segment_length_001.nodes.new("FunctionNodeCompare")
	    compare_003_1.name = "Compare.003"
	    compare_003_1.hide = True
	    compare_003_1.data_type = 'FLOAT'
	    compare_003_1.mode = 'ELEMENT'
	    compare_003_1.operation = 'NOT_EQUAL'
	    #B
	    compare_003_1.inputs[1].default_value = 0.0
	    #Epsilon
	    compare_003_1.inputs[12].default_value = 0.0
	
	    #node Compare.005
	    compare_005_2 = restore_curve_segment_length_001.nodes.new("FunctionNodeCompare")
	    compare_005_2.name = "Compare.005"
	    compare_005_2.hide = True
	    compare_005_2.data_type = 'FLOAT'
	    compare_005_2.mode = 'ELEMENT'
	    compare_005_2.operation = 'GREATER_THAN'
	    #B
	    compare_005_2.inputs[1].default_value = 0.0
	
	
	
	
	    #Set parents
	    group_input_006_1.parent = frame_001_3
	    reroute_013_1.parent = frame_001_3
	    index_5.parent = frame_001_3
	    sample_curve_001_1.parent = frame_001_3
	    group_input_003_4.parent = frame_001_3
	    vector_math_006_1.parent = frame_001_3
	    interpolate_domain_5.parent = frame_001_3
	    group_input_005_2.parent = frame_001_3
	    boolean_math_002_1.parent = frame_001_3
	    field_at_index_002_1.parent = frame_4
	    vector_math_004_1.parent = frame_4
	    accumulate_field_1.parent = frame_4
	    curve_of_point_1.parent = frame_4
	    vector_math_4.parent = frame_4
	    index_001_3.parent = frame_4
	    curve_of_point_001_1.parent = frame_4
	    switch_2.parent = frame_4
	    math_4.parent = frame_4
	    compare_3.parent = frame_4
	    reroute_001_4.parent = frame_4
	    set_position_001_3.parent = frame_4
	    boolean_math_3.parent = frame_4
	    compare_002_3.parent = frame_4
	    group_input_002_6.parent = frame_4
	    reroute_016_1.parent = frame_001_3
	    reroute_014_1.parent = frame_001_3
	    switch_001_4.parent = frame_001_3
	    attribute_statistic_2.parent = frame_001_3
	    group_3.parent = frame_4
	    reroute_004_2.parent = frame_4
	    position_001_2.parent = frame_002_3
	    named_attribute_2.parent = frame_002_3
	    switch_003_3.parent = frame_002_3
	    reroute_006_2.parent = frame_002_3
	    switch_002_1.parent = frame_002_3
	    compare_004_1.parent = frame_002_3
	    reroute_005_2.parent = frame_4
	    set_position_002_2.parent = frame_001_3
	    reroute_012_1.parent = frame_001_3
	    group_input_001_8.parent = frame_4
	    mix_1.parent = frame_4
	    group_001_2.parent = frame_4
	    compare_003_1.parent = frame_001_3
	    compare_005_2.parent = frame_001_3
	
	    #Set locations
	    frame_001_3.location = (-1289.059814453125, 110.20000457763672)
	    frame_4.location = (-3492.00048828125, 57.61393737792969)
	    frame_002_3.location = (-4467.1064453125, -100.04000854492188)
	    reroute_009_2.location = (-1431.9771728515625, -673.348876953125)
	    group_input_006_1.location = (218.757080078125, -140.57211303710938)
	    reroute_013_1.location = (178.571044921875, -120.47908020019531)
	    index_5.location = (37.919921875, -482.15350341796875)
	    sample_curve_001_1.location = (218.757080078125, -220.94418334960938)
	    group_input_003_4.location = (37.919921875, -421.87445068359375)
	    vector_math_006_1.location = (399.5943603515625, -261.1302490234375)
	    interpolate_domain_5.location = (580.4315795898438, -261.1302490234375)
	    group_input_005_2.location = (399.5943603515625, -180.75814819335938)
	    boolean_math_002_1.location = (580.4315795898438, -180.75814819335938)
	    field_at_index_002_1.location = (653.51171875, -248.73023986816406)
	    vector_math_004_1.location = (834.348876953125, -228.63722229003906)
	    accumulate_field_1.location = (1557.69775390625, -409.47442626953125)
	    curve_of_point_1.location = (1356.767578125, -550.1256103515625)
	    vector_math_4.location = (1356.767578125, -389.38140869140625)
	    index_001_3.location = (30.6279296875, -469.75347900390625)
	    curve_of_point_001_1.location = (30.6279296875, -389.38140869140625)
	    switch_2.location = (412.3955078125, -369.28839111328125)
	    math_4.location = (211.46533203125, -469.75347900390625)
	    compare_3.location = (211.46533203125, -429.56744384765625)
	    reroute_001_4.location = (613.32568359375, -309.0093078613281)
	    set_position_001_3.location = (1798.8140869140625, -148.26512145996094)
	    boolean_math_3.location = (1494.958251953125, -96.33775329589844)
	    compare_002_3.location = (1294.0283203125, -116.43077850341797)
	    group_input_002_6.location = (1113.19140625, -136.5238037109375)
	    reroute_016_1.location = (801.454833984375, -160.66513061523438)
	    reroute_014_1.location = (801.454833984375, -120.47908020019531)
	    switch_001_4.location = (1082.757080078125, -40.10698699951172)
	    group_output_14.location = (75.0, 50.0)
	    attribute_statistic_2.location = (861.73388671875, -60.20000457763672)
	    group_3.location = (1557.69775390625, -268.8232421875)
	    reroute_007_2.location = (-3762.76806640625, -251.3953857421875)
	    reroute_004_2.location = (1638.06982421875, -47.80000305175781)
	    position_001_2.location = (60.265625, -241.41067504882812)
	    named_attribute_2.location = (60.265625, -301.6897277832031)
	    switch_003_3.location = (241.1025390625, -221.31765747070312)
	    reroute_006_2.location = (37.919921875, -72.88264465332031)
	    switch_002_1.location = (442.03271484375, -100.75950622558594)
	    compare_004_1.location = (60.26611328125, -40.480438232421875)
	    group_input_10.location = (-4707.1396484375, -30.37213134765625)
	    reroute_011_1.location = (-3581.9306640625, -70.55816650390625)
	    reroute_005_2.location = (50.72119140625, -47.80000305175781)
	    reroute_008_2.location = (-3561.83740234375, -673.348876953125)
	    set_position_002_2.location = (861.73388671875, -140.57211303710938)
	    reroute_012_1.location = (37.919921875, -241.0372314453125)
	    group_input_001_8.location = (834.348876953125, -168.358154296875)
	    mix_1.location = (1115.6513671875, -329.10235595703125)
	    group_001_2.location = (834.348876953125, -409.47442626953125)
	    compare_003_1.location = (399.5943603515625, -140.57211303710938)
	    compare_005_2.location = (861.73388671875, -100.38605499267578)
	
	    #Set dimensions
	    frame_001_3.width, frame_001_3.height = 1252.8997802734375, 561.8800659179688
	    frame_4.width, frame_4.height = 1968.80029296875, 632.1739501953125
	    frame_002_3.width, frame_002_3.height = 612.06640625, 452.4400329589844
	    reroute_009_2.width, reroute_009_2.height = 100.0, 100.0
	    group_input_006_1.width, group_input_006_1.height = 140.0, 100.0
	    reroute_013_1.width, reroute_013_1.height = 100.0, 100.0
	    index_5.width, index_5.height = 140.0, 100.0
	    sample_curve_001_1.width, sample_curve_001_1.height = 140.0, 100.0
	    group_input_003_4.width, group_input_003_4.height = 140.0, 100.0
	    vector_math_006_1.width, vector_math_006_1.height = 140.0, 100.0
	    interpolate_domain_5.width, interpolate_domain_5.height = 140.0, 100.0
	    group_input_005_2.width, group_input_005_2.height = 140.0, 100.0
	    boolean_math_002_1.width, boolean_math_002_1.height = 140.0, 100.0
	    field_at_index_002_1.width, field_at_index_002_1.height = 140.0, 100.0
	    vector_math_004_1.width, vector_math_004_1.height = 140.0, 100.0
	    accumulate_field_1.width, accumulate_field_1.height = 140.0, 100.0
	    curve_of_point_1.width, curve_of_point_1.height = 140.0, 100.0
	    vector_math_4.width, vector_math_4.height = 140.0, 100.0
	    index_001_3.width, index_001_3.height = 140.0, 100.0
	    curve_of_point_001_1.width, curve_of_point_001_1.height = 140.0, 100.0
	    switch_2.width, switch_2.height = 140.0, 100.0
	    math_4.width, math_4.height = 140.0, 100.0
	    compare_3.width, compare_3.height = 140.0, 100.0
	    reroute_001_4.width, reroute_001_4.height = 100.0, 100.0
	    set_position_001_3.width, set_position_001_3.height = 140.0, 100.0
	    boolean_math_3.width, boolean_math_3.height = 140.0, 100.0
	    compare_002_3.width, compare_002_3.height = 140.0, 100.0
	    group_input_002_6.width, group_input_002_6.height = 140.0, 100.0
	    reroute_016_1.width, reroute_016_1.height = 100.0, 100.0
	    reroute_014_1.width, reroute_014_1.height = 100.0, 100.0
	    switch_001_4.width, switch_001_4.height = 140.0, 100.0
	    group_output_14.width, group_output_14.height = 140.0, 100.0
	    attribute_statistic_2.width, attribute_statistic_2.height = 140.0, 100.0
	    group_3.width, group_3.height = 140.0, 100.0
	    reroute_007_2.width, reroute_007_2.height = 100.0, 100.0
	    reroute_004_2.width, reroute_004_2.height = 100.0, 100.0
	    position_001_2.width, position_001_2.height = 140.0, 100.0
	    named_attribute_2.width, named_attribute_2.height = 140.0, 100.0
	    switch_003_3.width, switch_003_3.height = 140.0, 100.0
	    reroute_006_2.width, reroute_006_2.height = 100.0, 100.0
	    switch_002_1.width, switch_002_1.height = 140.0, 100.0
	    compare_004_1.width, compare_004_1.height = 140.0, 100.0
	    group_input_10.width, group_input_10.height = 140.0, 100.0
	    reroute_011_1.width, reroute_011_1.height = 100.0, 100.0
	    reroute_005_2.width, reroute_005_2.height = 100.0, 100.0
	    reroute_008_2.width, reroute_008_2.height = 100.0, 100.0
	    set_position_002_2.width, set_position_002_2.height = 140.0, 100.0
	    reroute_012_1.width, reroute_012_1.height = 100.0, 100.0
	    group_input_001_8.width, group_input_001_8.height = 140.0, 100.0
	    mix_1.width, mix_1.height = 140.0, 100.0
	    group_001_2.width, group_001_2.height = 140.0, 100.0
	    compare_003_1.width, compare_003_1.height = 140.0, 100.0
	    compare_005_2.width, compare_005_2.height = 140.0, 100.0
	
	    #initialize restore_curve_segment_length_001 links
	    #reroute_004_2.Output -> set_position_001_3.Geometry
	    restore_curve_segment_length_001.links.new(reroute_004_2.outputs[0], set_position_001_3.inputs[0])
	    #curve_of_point_1.Curve Index -> accumulate_field_1.Group ID
	    restore_curve_segment_length_001.links.new(curve_of_point_1.outputs[0], accumulate_field_1.inputs[1])
	    #field_at_index_002_1.Value -> vector_math_004_1.Vector
	    restore_curve_segment_length_001.links.new(field_at_index_002_1.outputs[0], vector_math_004_1.inputs[0])
	    #reroute_001_4.Output -> vector_math_004_1.Vector
	    restore_curve_segment_length_001.links.new(reroute_001_4.outputs[0], vector_math_004_1.inputs[1])
	    #reroute_001_4.Output -> field_at_index_002_1.Value
	    restore_curve_segment_length_001.links.new(reroute_001_4.outputs[0], field_at_index_002_1.inputs[1])
	    #index_001_3.Index -> math_4.Value
	    restore_curve_segment_length_001.links.new(index_001_3.outputs[0], math_4.inputs[0])
	    #switch_2.Output -> field_at_index_002_1.Index
	    restore_curve_segment_length_001.links.new(switch_2.outputs[0], field_at_index_002_1.inputs[0])
	    #vector_math_4.Vector -> accumulate_field_1.Value
	    restore_curve_segment_length_001.links.new(vector_math_4.outputs[0], accumulate_field_1.inputs[0])
	    #curve_of_point_001_1.Index in Curve -> compare_3.A
	    restore_curve_segment_length_001.links.new(curve_of_point_001_1.outputs[1], compare_3.inputs[2])
	    #math_4.Value -> switch_2.False
	    restore_curve_segment_length_001.links.new(math_4.outputs[0], switch_2.inputs[1])
	    #compare_3.Result -> switch_2.Switch
	    restore_curve_segment_length_001.links.new(compare_3.outputs[0], switch_2.inputs[0])
	    #index_001_3.Index -> switch_2.True
	    restore_curve_segment_length_001.links.new(index_001_3.outputs[0], switch_2.inputs[2])
	    #reroute_006_2.Output -> switch_002_1.False
	    restore_curve_segment_length_001.links.new(reroute_006_2.outputs[0], switch_002_1.inputs[1])
	    #group_3.Root Position -> set_position_001_3.Position
	    restore_curve_segment_length_001.links.new(group_3.outputs[1], set_position_001_3.inputs[2])
	    #vector_math_004_1.Value -> mix_1.B
	    restore_curve_segment_length_001.links.new(vector_math_004_1.outputs[1], mix_1.inputs[3])
	    #mix_1.Result -> vector_math_4.Scale
	    restore_curve_segment_length_001.links.new(mix_1.outputs[0], vector_math_4.inputs[3])
	    #group_input_001_8.Factor -> mix_1.Factor
	    restore_curve_segment_length_001.links.new(group_input_001_8.outputs[2], mix_1.inputs[0])
	    #group_input_002_6.Factor -> compare_002_3.A
	    restore_curve_segment_length_001.links.new(group_input_002_6.outputs[2], compare_002_3.inputs[0])
	    #accumulate_field_1.Leading -> set_position_001_3.Offset
	    restore_curve_segment_length_001.links.new(accumulate_field_1.outputs[0], set_position_001_3.inputs[3])
	    #compare_002_3.Result -> boolean_math_3.Boolean
	    restore_curve_segment_length_001.links.new(compare_002_3.outputs[0], boolean_math_3.inputs[0])
	    #group_input_002_6.Selection -> boolean_math_3.Boolean
	    restore_curve_segment_length_001.links.new(group_input_002_6.outputs[1], boolean_math_3.inputs[1])
	    #reroute_005_2.Output -> reroute_004_2.Input
	    restore_curve_segment_length_001.links.new(reroute_005_2.outputs[0], reroute_004_2.inputs[0])
	    #reroute_012_1.Output -> sample_curve_001_1.Curves
	    restore_curve_segment_length_001.links.new(reroute_012_1.outputs[0], sample_curve_001_1.inputs[0])
	    #sample_curve_001_1.Position -> vector_math_006_1.Vector
	    restore_curve_segment_length_001.links.new(sample_curve_001_1.outputs[1], vector_math_006_1.inputs[1])
	    #sample_curve_001_1.Value -> vector_math_006_1.Vector
	    restore_curve_segment_length_001.links.new(sample_curve_001_1.outputs[0], vector_math_006_1.inputs[0])
	    #reroute_014_1.Output -> set_position_002_2.Geometry
	    restore_curve_segment_length_001.links.new(reroute_014_1.outputs[0], set_position_002_2.inputs[0])
	    #interpolate_domain_5.Value -> set_position_002_2.Offset
	    restore_curve_segment_length_001.links.new(interpolate_domain_5.outputs[0], set_position_002_2.inputs[3])
	    #index_5.Index -> sample_curve_001_1.Curve Index
	    restore_curve_segment_length_001.links.new(index_5.outputs[0], sample_curve_001_1.inputs[4])
	    #reroute_012_1.Output -> reroute_013_1.Input
	    restore_curve_segment_length_001.links.new(reroute_012_1.outputs[0], reroute_013_1.inputs[0])
	    #group_input_005_2.Selection -> boolean_math_002_1.Boolean
	    restore_curve_segment_length_001.links.new(group_input_005_2.outputs[1], boolean_math_002_1.inputs[1])
	    #compare_003_1.Result -> boolean_math_002_1.Boolean
	    restore_curve_segment_length_001.links.new(compare_003_1.outputs[0], boolean_math_002_1.inputs[0])
	    #reroute_011_1.Output -> reroute_005_2.Input
	    restore_curve_segment_length_001.links.new(reroute_011_1.outputs[0], reroute_005_2.inputs[0])
	    #group_input_003_4.Pin at Parameter -> sample_curve_001_1.Factor
	    restore_curve_segment_length_001.links.new(group_input_003_4.outputs[4], sample_curve_001_1.inputs[2])
	    #group_input_006_1.Pin at Parameter -> compare_003_1.A
	    restore_curve_segment_length_001.links.new(group_input_006_1.outputs[4], compare_003_1.inputs[0])
	    #reroute_006_2.Output -> compare_004_1.A
	    restore_curve_segment_length_001.links.new(reroute_006_2.outputs[0], compare_004_1.inputs[4])
	    #compare_004_1.Result -> switch_002_1.Switch
	    restore_curve_segment_length_001.links.new(compare_004_1.outputs[0], switch_002_1.inputs[0])
	    #named_attribute_2.Attribute -> switch_003_3.True
	    restore_curve_segment_length_001.links.new(named_attribute_2.outputs[0], switch_003_3.inputs[2])
	    #named_attribute_2.Exists -> switch_003_3.Switch
	    restore_curve_segment_length_001.links.new(named_attribute_2.outputs[1], switch_003_3.inputs[0])
	    #position_001_2.Position -> switch_003_3.False
	    restore_curve_segment_length_001.links.new(position_001_2.outputs[0], switch_003_3.inputs[1])
	    #switch_003_3.Output -> switch_002_1.True
	    restore_curve_segment_length_001.links.new(switch_003_3.outputs[0], switch_002_1.inputs[2])
	    #reroute_009_2.Output -> sample_curve_001_1.Value
	    restore_curve_segment_length_001.links.new(reroute_009_2.outputs[0], sample_curve_001_1.inputs[1])
	    #switch_002_1.Output -> reroute_007_2.Input
	    restore_curve_segment_length_001.links.new(switch_002_1.outputs[0], reroute_007_2.inputs[0])
	    #reroute_007_2.Output -> reroute_001_4.Input
	    restore_curve_segment_length_001.links.new(reroute_007_2.outputs[0], reroute_001_4.inputs[0])
	    #group_input_10.Reference Position -> reroute_006_2.Input
	    restore_curve_segment_length_001.links.new(group_input_10.outputs[3], reroute_006_2.inputs[0])
	    #reroute_007_2.Output -> reroute_008_2.Input
	    restore_curve_segment_length_001.links.new(reroute_007_2.outputs[0], reroute_008_2.inputs[0])
	    #reroute_008_2.Output -> reroute_009_2.Input
	    restore_curve_segment_length_001.links.new(reroute_008_2.outputs[0], reroute_009_2.inputs[0])
	    #group_input_10.Curves -> reroute_011_1.Input
	    restore_curve_segment_length_001.links.new(group_input_10.outputs[0], reroute_011_1.inputs[0])
	    #group_001_2.Segment Length -> mix_1.A
	    restore_curve_segment_length_001.links.new(group_001_2.outputs[0], mix_1.inputs[2])
	    #group_001_2.Segment Direction -> vector_math_4.Vector
	    restore_curve_segment_length_001.links.new(group_001_2.outputs[1], vector_math_4.inputs[0])
	    #vector_math_006_1.Vector -> interpolate_domain_5.Value
	    restore_curve_segment_length_001.links.new(vector_math_006_1.outputs[0], interpolate_domain_5.inputs[0])
	    #reroute_016_1.Output -> attribute_statistic_2.Attribute
	    restore_curve_segment_length_001.links.new(reroute_016_1.outputs[0], attribute_statistic_2.inputs[2])
	    #attribute_statistic_2.Max -> compare_005_2.A
	    restore_curve_segment_length_001.links.new(attribute_statistic_2.outputs[4], compare_005_2.inputs[0])
	    #set_position_002_2.Geometry -> switch_001_4.True
	    restore_curve_segment_length_001.links.new(set_position_002_2.outputs[0], switch_001_4.inputs[2])
	    #reroute_014_1.Output -> switch_001_4.False
	    restore_curve_segment_length_001.links.new(reroute_014_1.outputs[0], switch_001_4.inputs[1])
	    #reroute_016_1.Output -> set_position_002_2.Selection
	    restore_curve_segment_length_001.links.new(reroute_016_1.outputs[0], set_position_002_2.inputs[1])
	    #compare_005_2.Result -> switch_001_4.Switch
	    restore_curve_segment_length_001.links.new(compare_005_2.outputs[0], switch_001_4.inputs[0])
	    #reroute_014_1.Output -> attribute_statistic_2.Geometry
	    restore_curve_segment_length_001.links.new(reroute_014_1.outputs[0], attribute_statistic_2.inputs[0])
	    #boolean_math_3.Boolean -> set_position_001_3.Selection
	    restore_curve_segment_length_001.links.new(boolean_math_3.outputs[0], set_position_001_3.inputs[1])
	    #boolean_math_002_1.Boolean -> reroute_016_1.Input
	    restore_curve_segment_length_001.links.new(boolean_math_002_1.outputs[0], reroute_016_1.inputs[0])
	    #reroute_013_1.Output -> reroute_014_1.Input
	    restore_curve_segment_length_001.links.new(reroute_013_1.outputs[0], reroute_014_1.inputs[0])
	    #set_position_001_3.Geometry -> reroute_012_1.Input
	    restore_curve_segment_length_001.links.new(set_position_001_3.outputs[0], reroute_012_1.inputs[0])
	    #switch_001_4.Output -> group_output_14.Curves
	    restore_curve_segment_length_001.links.new(switch_001_4.outputs[0], group_output_14.inputs[0])
	    return restore_curve_segment_length_001
	
	restore_curve_segment_length_001 = restore_curve_segment_length_001_node_group()
	
	#initialize mesh_magic node group
	def mesh_magic_node_group():
	    mesh_magic = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "MESH_MAGIC")
	
	    mesh_magic.color_tag = 'NONE'
	    mesh_magic.description = "Convert a set of curves to a stylized mesh."
	    mesh_magic.default_group_node_width = 140
	    
	
	    mesh_magic.is_modifier = True
	
	    #mesh_magic interface
	    #Socket Geometry
	    geometry_socket_16 = mesh_magic.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_16.attribute_domain = 'POINT'
	    geometry_socket_16.description = "Curves converted to a stylized mesh."
	
	    #Socket Geometry
	    geometry_socket_17 = mesh_magic.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_17.attribute_domain = 'POINT'
	    geometry_socket_17.description = "Set of curves."
	
	    #Socket Surface
	    surface_socket_1 = mesh_magic.interface.new_socket(name = "Surface", in_out='INPUT', socket_type = 'NodeSocketObject')
	    surface_socket_1.attribute_domain = 'POINT'
	    surface_socket_1.description = "Surface mesh."
	
	    #Socket Radius
	    radius_socket = mesh_magic.interface.new_socket(name = "Radius", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    radius_socket.default_value = 0.09999999403953552
	    radius_socket.min_value = 0.0
	    radius_socket.max_value = 3.4028234663852886e+38
	    radius_socket.subtype = 'DISTANCE'
	    radius_socket.attribute_domain = 'POINT'
	    radius_socket.description = "Mesh Radius."
	
	    #Panel Enhancement Settings
	    enhancement_settings_panel = mesh_magic.interface.new_panel("Enhancement Settings", default_closed=True)
	    enhancement_settings_panel.description = "Settings for mesh enhancements."
	    #Socket Use Enhancements
	    use_enhancements_socket = mesh_magic.interface.new_socket(name = "Use Enhancements", in_out='INPUT', socket_type = 'NodeSocketBool', parent = enhancement_settings_panel)
	    use_enhancements_socket.default_value = True
	    use_enhancements_socket.attribute_domain = 'POINT'
	    use_enhancements_socket.description = "Use Enhancement settings."
	
	    #Socket Maintain Shape Factor
	    maintain_shape_factor_socket = mesh_magic.interface.new_socket(name = "Maintain Shape Factor", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = enhancement_settings_panel)
	    maintain_shape_factor_socket.default_value = 1.0
	    maintain_shape_factor_socket.min_value = 0.0
	    maintain_shape_factor_socket.max_value = 1.0
	    maintain_shape_factor_socket.subtype = 'FACTOR'
	    maintain_shape_factor_socket.attribute_domain = 'POINT'
	    maintain_shape_factor_socket.description = "Factor to blend overall effect"
	
	    #Socket Pin at Parameter
	    pin_at_parameter_socket_2 = mesh_magic.interface.new_socket(name = "Pin at Parameter", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = enhancement_settings_panel)
	    pin_at_parameter_socket_2.default_value = 0.0
	    pin_at_parameter_socket_2.min_value = 0.0
	    pin_at_parameter_socket_2.max_value = 1.0
	    pin_at_parameter_socket_2.subtype = 'FACTOR'
	    pin_at_parameter_socket_2.attribute_domain = 'POINT'
	    pin_at_parameter_socket_2.description = "Pin each curve at a certain point for the operation"
	
	    #Socket Snap to surface
	    snap_to_surface_socket = mesh_magic.interface.new_socket(name = "Snap to surface", in_out='INPUT', socket_type = 'NodeSocketBool', parent = enhancement_settings_panel)
	    snap_to_surface_socket.default_value = False
	    snap_to_surface_socket.attribute_domain = 'POINT'
	    snap_to_surface_socket.description = "Snap mesh roots to the nearest surface point."
	
	    #Panel Subdivision Settings
	    subdivision_settings_panel = mesh_magic.interface.new_panel("Subdivision Settings")
	    subdivision_settings_panel.description = "Settings for mesh subdivision."
	    #Socket Level
	    level_socket_1 = mesh_magic.interface.new_socket(name = "Level", in_out='INPUT', socket_type = 'NodeSocketInt', parent = subdivision_settings_panel)
	    level_socket_1.default_value = 1
	    level_socket_1.min_value = 0
	    level_socket_1.max_value = 6
	    level_socket_1.subtype = 'NONE'
	    level_socket_1.attribute_domain = 'POINT'
	    level_socket_1.description = "Subdivision level."
	
	    #Socket Edge Crease
	    edge_crease_socket = mesh_magic.interface.new_socket(name = "Edge Crease", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = subdivision_settings_panel)
	    edge_crease_socket.default_value = 0.0
	    edge_crease_socket.min_value = 0.0
	    edge_crease_socket.max_value = 1.0
	    edge_crease_socket.subtype = 'FACTOR'
	    edge_crease_socket.attribute_domain = 'POINT'
	    edge_crease_socket.description = "Edge crease factor for subdivision."
	
	    #Socket Vertex Crease
	    vertex_crease_socket = mesh_magic.interface.new_socket(name = "Vertex Crease", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = subdivision_settings_panel)
	    vertex_crease_socket.default_value = 0.0
	    vertex_crease_socket.min_value = 0.0
	    vertex_crease_socket.max_value = 1.0
	    vertex_crease_socket.subtype = 'FACTOR'
	    vertex_crease_socket.attribute_domain = 'POINT'
	    vertex_crease_socket.description = "Vertex crease factor for subdivision."
	
	    #Socket Limit Surface
	    limit_surface_socket = mesh_magic.interface.new_socket(name = "Limit Surface", in_out='INPUT', socket_type = 'NodeSocketBool', parent = subdivision_settings_panel)
	    limit_surface_socket.default_value = True
	    limit_surface_socket.attribute_domain = 'POINT'
	    limit_surface_socket.description = "Limit subdivision on surface."
	
	
	    mesh_magic.interface.move_to_parent(subdivision_settings_panel, enhancement_settings_panel, 9)
	    #Panel Merge Settings
	    merge_settings_panel = mesh_magic.interface.new_panel("Merge Settings", default_closed=True)
	    merge_settings_panel.description = "Settings for merging points."
	    #Socket Distance
	    distance_socket = mesh_magic.interface.new_socket(name = "Distance", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = merge_settings_panel)
	    distance_socket.default_value = 0.0010000000474974513
	    distance_socket.min_value = 0.0
	    distance_socket.max_value = 3.4028234663852886e+38
	    distance_socket.subtype = 'DISTANCE'
	    distance_socket.attribute_domain = 'POINT'
	    distance_socket.description = "Distance threshold to merge points."
	
	
	    mesh_magic.interface.move_to_parent(merge_settings_panel, enhancement_settings_panel, 14)
	
	
	    #initialize mesh_magic nodes
	    #node Group Output
	    group_output_15 = mesh_magic.nodes.new("NodeGroupOutput")
	    group_output_15.name = "Group Output"
	    group_output_15.is_active_output = True
	    group_output_15.inputs[1].hide = True
	
	    #node Group Input
	    group_input_11 = mesh_magic.nodes.new("NodeGroupInput")
	    group_input_11.name = "Group Input"
	    group_input_11.outputs[1].hide = True
	    group_input_11.outputs[2].hide = True
	    group_input_11.outputs[3].hide = True
	    group_input_11.outputs[4].hide = True
	    group_input_11.outputs[5].hide = True
	    group_input_11.outputs[6].hide = True
	    group_input_11.outputs[7].hide = True
	    group_input_11.outputs[8].hide = True
	    group_input_11.outputs[9].hide = True
	    group_input_11.outputs[10].hide = True
	    group_input_11.outputs[11].hide = True
	    group_input_11.outputs[12].hide = True
	
	    #node Group
	    group_4 = mesh_magic.nodes.new("GeometryNodeGroup")
	    group_4.name = "Group"
	    group_4.node_tree = ob_data
	
	    #node Group.004
	    group_004_1 = mesh_magic.nodes.new("GeometryNodeGroup")
	    group_004_1.name = "Group.004"
	    group_004_1.node_tree = convex_curve_profile
	
	    #node Group.005
	    group_005_1 = mesh_magic.nodes.new("GeometryNodeGroup")
	    group_005_1.name = "Group.005"
	    group_005_1.node_tree = curve_from_centroids
	
	    #node Curve to Mesh
	    curve_to_mesh_2 = mesh_magic.nodes.new("GeometryNodeCurveToMesh")
	    curve_to_mesh_2.name = "Curve to Mesh"
	    #Fill Caps
	    curve_to_mesh_2.inputs[2].default_value = True
	
	    #node Set Position.001
	    set_position_001_4 = mesh_magic.nodes.new("GeometryNodeSetPosition")
	    set_position_001_4.name = "Set Position.001"
	    set_position_001_4.inputs[1].hide = True
	    set_position_001_4.inputs[3].hide = True
	    #Selection
	    set_position_001_4.inputs[1].default_value = True
	    #Offset
	    set_position_001_4.inputs[3].default_value = (0.0, 0.0, 0.0)
	
	    #node Position.002
	    position_002_6 = mesh_magic.nodes.new("GeometryNodeInputPosition")
	    position_002_6.name = "Position.002"
	
	    #node Separate XYZ
	    separate_xyz_2 = mesh_magic.nodes.new("ShaderNodeSeparateXYZ")
	    separate_xyz_2.name = "Separate XYZ"
	    separate_xyz_2.hide = True
	    separate_xyz_2.outputs[2].hide = True
	
	    #node Combine XYZ
	    combine_xyz_1 = mesh_magic.nodes.new("ShaderNodeCombineXYZ")
	    combine_xyz_1.name = "Combine XYZ"
	    combine_xyz_1.hide = True
	    combine_xyz_1.inputs[2].hide = True
	    #Z
	    combine_xyz_1.inputs[2].default_value = 0.0
	
	    #node Set Curve Radius
	    set_curve_radius_2 = mesh_magic.nodes.new("GeometryNodeSetCurveRadius")
	    set_curve_radius_2.name = "Set Curve Radius"
	    set_curve_radius_2.inputs[1].hide = True
	    #Selection
	    set_curve_radius_2.inputs[1].default_value = True
	
	    #node Capture Attribute.001
	    capture_attribute_001 = mesh_magic.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_001.name = "Capture Attribute.001"
	    capture_attribute_001.hide = True
	    capture_attribute_001.active_index = 0
	    capture_attribute_001.capture_items.clear()
	    capture_attribute_001.capture_items.new('FLOAT', "Factor")
	    capture_attribute_001.capture_items["Factor"].data_type = 'FLOAT'
	    capture_attribute_001.domain = 'POINT'
	    capture_attribute_001.inputs[2].hide = True
	    capture_attribute_001.outputs[2].hide = True
	
	    #node Capture Attribute.002
	    capture_attribute_002_1 = mesh_magic.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_002_1.name = "Capture Attribute.002"
	    capture_attribute_002_1.hide = True
	    capture_attribute_002_1.active_index = 0
	    capture_attribute_002_1.capture_items.clear()
	    capture_attribute_002_1.capture_items.new('FLOAT', "Factor")
	    capture_attribute_002_1.capture_items["Factor"].data_type = 'FLOAT'
	    capture_attribute_002_1.domain = 'POINT'
	    capture_attribute_002_1.inputs[2].hide = True
	    capture_attribute_002_1.outputs[2].hide = True
	
	    #node Spline Parameter
	    spline_parameter_2 = mesh_magic.nodes.new("GeometryNodeSplineParameter")
	    spline_parameter_2.name = "Spline Parameter"
	    spline_parameter_2.outputs[1].hide = True
	    spline_parameter_2.outputs[2].hide = True
	
	    #node Store Named Attribute
	    store_named_attribute_3 = mesh_magic.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_3.name = "Store Named Attribute"
	    store_named_attribute_3.data_type = 'FLOAT2'
	    store_named_attribute_3.domain = 'CORNER'
	    #Selection
	    store_named_attribute_3.inputs[1].default_value = True
	    #Name
	    store_named_attribute_3.inputs[2].default_value = "UVMap"
	
	    #node Combine XYZ.001
	    combine_xyz_001_3 = mesh_magic.nodes.new("ShaderNodeCombineXYZ")
	    combine_xyz_001_3.name = "Combine XYZ.001"
	    combine_xyz_001_3.hide = True
	    combine_xyz_001_3.inputs[2].hide = True
	    #Z
	    combine_xyz_001_3.inputs[2].default_value = 0.0
	
	    #node Stylized Mesh Shape
	    stylized_mesh_shape = mesh_magic.nodes.new("ShaderNodeFloatCurve")
	    stylized_mesh_shape.label = "Stylized Mesh Shape"
	    stylized_mesh_shape.name = "Stylized Mesh Shape"
	    #mapping settings
	    stylized_mesh_shape.mapping.extend = 'EXTRAPOLATED'
	    stylized_mesh_shape.mapping.tone = 'STANDARD'
	    stylized_mesh_shape.mapping.black_level = (0.0, 0.0, 0.0)
	    stylized_mesh_shape.mapping.white_level = (1.0, 1.0, 1.0)
	    stylized_mesh_shape.mapping.clip_min_x = 0.0
	    stylized_mesh_shape.mapping.clip_min_y = 0.0
	    stylized_mesh_shape.mapping.clip_max_x = 1.0
	    stylized_mesh_shape.mapping.clip_max_y = 1.0
	    stylized_mesh_shape.mapping.use_clip = True
	    #curve 0
	    stylized_mesh_shape_curve_0 = stylized_mesh_shape.mapping.curves[0]
	    stylized_mesh_shape_curve_0_point_0 = stylized_mesh_shape_curve_0.points[0]
	    stylized_mesh_shape_curve_0_point_0.location = (0.00909090880304575, 1.0)
	    stylized_mesh_shape_curve_0_point_0.handle_type = 'AUTO'
	    stylized_mesh_shape_curve_0_point_1 = stylized_mesh_shape_curve_0.points[1]
	    stylized_mesh_shape_curve_0_point_1.location = (0.27272725105285645, 0.3750000596046448)
	    stylized_mesh_shape_curve_0_point_1.handle_type = 'AUTO'
	    stylized_mesh_shape_curve_0_point_2 = stylized_mesh_shape_curve_0.points.new(0.459090918302536, 0.3562501072883606)
	    stylized_mesh_shape_curve_0_point_2.handle_type = 'AUTO'
	    stylized_mesh_shape_curve_0_point_3 = stylized_mesh_shape_curve_0.points.new(1.0, 0.0)
	    stylized_mesh_shape_curve_0_point_3.handle_type = 'AUTO'
	    #update curve after changes
	    stylized_mesh_shape.mapping.update()
	    #Factor
	    stylized_mesh_shape.inputs[0].default_value = 1.0
	
	    #node Spline Parameter.001
	    spline_parameter_001_2 = mesh_magic.nodes.new("GeometryNodeSplineParameter")
	    spline_parameter_001_2.name = "Spline Parameter.001"
	    spline_parameter_001_2.outputs[1].hide = True
	    spline_parameter_001_2.outputs[2].hide = True
	
	    #node Map Range
	    map_range_2 = mesh_magic.nodes.new("ShaderNodeMapRange")
	    map_range_2.name = "Map Range"
	    map_range_2.hide = True
	    map_range_2.clamp = True
	    map_range_2.data_type = 'FLOAT'
	    map_range_2.interpolation_type = 'LINEAR'
	    map_range_2.inputs[1].hide = True
	    map_range_2.inputs[2].hide = True
	    map_range_2.inputs[3].hide = True
	    map_range_2.inputs[5].hide = True
	    map_range_2.inputs[6].hide = True
	    map_range_2.inputs[7].hide = True
	    map_range_2.inputs[8].hide = True
	    map_range_2.inputs[9].hide = True
	    map_range_2.inputs[10].hide = True
	    map_range_2.inputs[11].hide = True
	    map_range_2.outputs[1].hide = True
	    #From Min
	    map_range_2.inputs[1].default_value = 0.0
	    #From Max
	    map_range_2.inputs[2].default_value = 1.0
	    #To Min
	    map_range_2.inputs[3].default_value = 0.0
	
	    #node Group Input.001
	    group_input_001_9 = mesh_magic.nodes.new("NodeGroupInput")
	    group_input_001_9.name = "Group Input.001"
	    group_input_001_9.outputs[0].hide = True
	    group_input_001_9.outputs[1].hide = True
	    group_input_001_9.outputs[3].hide = True
	    group_input_001_9.outputs[4].hide = True
	    group_input_001_9.outputs[5].hide = True
	    group_input_001_9.outputs[6].hide = True
	    group_input_001_9.outputs[7].hide = True
	    group_input_001_9.outputs[8].hide = True
	    group_input_001_9.outputs[9].hide = True
	    group_input_001_9.outputs[10].hide = True
	    group_input_001_9.outputs[11].hide = True
	    group_input_001_9.outputs[12].hide = True
	
	    #node Group Input.002
	    group_input_002_7 = mesh_magic.nodes.new("NodeGroupInput")
	    group_input_002_7.name = "Group Input.002"
	    group_input_002_7.outputs[0].hide = True
	    group_input_002_7.outputs[2].hide = True
	    group_input_002_7.outputs[3].hide = True
	    group_input_002_7.outputs[4].hide = True
	    group_input_002_7.outputs[5].hide = True
	    group_input_002_7.outputs[6].hide = True
	    group_input_002_7.outputs[7].hide = True
	    group_input_002_7.outputs[8].hide = True
	    group_input_002_7.outputs[9].hide = True
	    group_input_002_7.outputs[10].hide = True
	    group_input_002_7.outputs[11].hide = True
	    group_input_002_7.outputs[12].hide = True
	
	    #node Group Input.003
	    group_input_003_5 = mesh_magic.nodes.new("NodeGroupInput")
	    group_input_003_5.name = "Group Input.003"
	    group_input_003_5.outputs[0].hide = True
	    group_input_003_5.outputs[2].hide = True
	    group_input_003_5.outputs[3].hide = True
	    group_input_003_5.outputs[4].hide = True
	    group_input_003_5.outputs[5].hide = True
	    group_input_003_5.outputs[6].hide = True
	    group_input_003_5.outputs[7].hide = True
	    group_input_003_5.outputs[8].hide = True
	    group_input_003_5.outputs[9].hide = True
	    group_input_003_5.outputs[10].hide = True
	    group_input_003_5.outputs[11].hide = True
	    group_input_003_5.outputs[12].hide = True
	
	    #node Set Position.002
	    set_position_002_3 = mesh_magic.nodes.new("GeometryNodeSetPosition")
	    set_position_002_3.name = "Set Position.002"
	    set_position_002_3.inputs[3].hide = True
	    #Offset
	    set_position_002_3.inputs[3].default_value = (0.0, 0.0, 0.0)
	
	    #node Geometry Proximity
	    geometry_proximity = mesh_magic.nodes.new("GeometryNodeProximity")
	    geometry_proximity.name = "Geometry Proximity"
	    geometry_proximity.hide = True
	    geometry_proximity.target_element = 'FACES'
	    geometry_proximity.inputs[1].hide = True
	    geometry_proximity.inputs[2].hide = True
	    geometry_proximity.inputs[3].hide = True
	    geometry_proximity.outputs[1].hide = True
	    geometry_proximity.outputs[2].hide = True
	    #Group ID
	    geometry_proximity.inputs[1].default_value = 0
	    #Source Position
	    geometry_proximity.inputs[2].default_value = (0.0, 0.0, 0.0)
	    #Sample Group ID
	    geometry_proximity.inputs[3].default_value = 0
	
	    #node Object Info
	    object_info = mesh_magic.nodes.new("GeometryNodeObjectInfo")
	    object_info.name = "Object Info"
	    object_info.hide = True
	    object_info.transform_space = 'RELATIVE'
	    object_info.inputs[1].hide = True
	    object_info.outputs[0].hide = True
	    object_info.outputs[1].hide = True
	    object_info.outputs[2].hide = True
	    object_info.outputs[3].hide = True
	    #As Instance
	    object_info.inputs[1].default_value = False
	
	    #node Named Attribute
	    named_attribute_3 = mesh_magic.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute_3.name = "Named Attribute"
	    named_attribute_3.data_type = 'FLOAT_VECTOR'
	    #Name
	    named_attribute_3.inputs[0].default_value = "UVMap"
	
	    #node Separate XYZ.001
	    separate_xyz_001_2 = mesh_magic.nodes.new("ShaderNodeSeparateXYZ")
	    separate_xyz_001_2.name = "Separate XYZ.001"
	    separate_xyz_001_2.hide = True
	    separate_xyz_001_2.outputs[1].hide = True
	    separate_xyz_001_2.outputs[2].hide = True
	
	    #node Compare
	    compare_4 = mesh_magic.nodes.new("FunctionNodeCompare")
	    compare_4.name = "Compare"
	    compare_4.hide = True
	    compare_4.data_type = 'FLOAT'
	    compare_4.mode = 'ELEMENT'
	    compare_4.operation = 'EQUAL'
	    compare_4.inputs[1].hide = True
	    compare_4.inputs[2].hide = True
	    compare_4.inputs[3].hide = True
	    compare_4.inputs[4].hide = True
	    compare_4.inputs[5].hide = True
	    compare_4.inputs[6].hide = True
	    compare_4.inputs[7].hide = True
	    compare_4.inputs[8].hide = True
	    compare_4.inputs[9].hide = True
	    compare_4.inputs[10].hide = True
	    compare_4.inputs[11].hide = True
	    compare_4.inputs[12].hide = True
	    #B
	    compare_4.inputs[1].default_value = 0.0
	    #Epsilon
	    compare_4.inputs[12].default_value = 0.0
	
	    #node Delete Geometry.001
	    delete_geometry_001_1 = mesh_magic.nodes.new("GeometryNodeDeleteGeometry")
	    delete_geometry_001_1.name = "Delete Geometry.001"
	    delete_geometry_001_1.domain = 'POINT'
	    delete_geometry_001_1.mode = 'ALL'
	
	    #node Vertex Neighbors
	    vertex_neighbors_1 = mesh_magic.nodes.new("GeometryNodeInputMeshVertexNeighbors")
	    vertex_neighbors_1.name = "Vertex Neighbors"
	    vertex_neighbors_1.outputs[0].hide = True
	
	    #node Compare.001
	    compare_001_2 = mesh_magic.nodes.new("FunctionNodeCompare")
	    compare_001_2.name = "Compare.001"
	    compare_001_2.hide = True
	    compare_001_2.data_type = 'INT'
	    compare_001_2.mode = 'ELEMENT'
	    compare_001_2.operation = 'EQUAL'
	    compare_001_2.inputs[0].hide = True
	    compare_001_2.inputs[1].hide = True
	    compare_001_2.inputs[3].hide = True
	    compare_001_2.inputs[4].hide = True
	    compare_001_2.inputs[5].hide = True
	    compare_001_2.inputs[6].hide = True
	    compare_001_2.inputs[7].hide = True
	    compare_001_2.inputs[8].hide = True
	    compare_001_2.inputs[9].hide = True
	    compare_001_2.inputs[10].hide = True
	    compare_001_2.inputs[11].hide = True
	    compare_001_2.inputs[12].hide = True
	    #B_INT
	    compare_001_2.inputs[3].default_value = 0
	
	    #node Raycast
	    raycast = mesh_magic.nodes.new("GeometryNodeRaycast")
	    raycast.name = "Raycast"
	    raycast.hide = True
	    raycast.data_type = 'FLOAT'
	    raycast.mapping = 'INTERPOLATED'
	    raycast.inputs[1].hide = True
	    raycast.inputs[2].hide = True
	    raycast.inputs[4].hide = True
	    raycast.outputs[0].hide = True
	    raycast.outputs[3].hide = True
	    raycast.outputs[4].hide = True
	    #Attribute
	    raycast.inputs[1].default_value = 0.0
	    #Source Position
	    raycast.inputs[2].default_value = (0.0, 0.0, 0.0)
	    #Ray Length
	    raycast.inputs[4].default_value = 100.0
	
	    #node Vector Math.001
	    vector_math_001_1 = mesh_magic.nodes.new("ShaderNodeVectorMath")
	    vector_math_001_1.name = "Vector Math.001"
	    vector_math_001_1.hide = True
	    vector_math_001_1.operation = 'SUBTRACT'
	
	    #node Position
	    position_5 = mesh_magic.nodes.new("GeometryNodeInputPosition")
	    position_5.name = "Position"
	
	    #node Vector Math.002
	    vector_math_002 = mesh_magic.nodes.new("ShaderNodeVectorMath")
	    vector_math_002.name = "Vector Math.002"
	    vector_math_002.hide = True
	    vector_math_002.operation = 'NORMALIZE'
	
	    #node Compare.003
	    compare_003_2 = mesh_magic.nodes.new("FunctionNodeCompare")
	    compare_003_2.name = "Compare.003"
	    compare_003_2.hide = True
	    compare_003_2.data_type = 'VECTOR'
	    compare_003_2.mode = 'DOT_PRODUCT'
	    compare_003_2.operation = 'GREATER_THAN'
	    compare_003_2.inputs[0].hide = True
	    compare_003_2.inputs[1].hide = True
	    compare_003_2.inputs[2].hide = True
	    compare_003_2.inputs[3].hide = True
	    compare_003_2.inputs[6].hide = True
	    compare_003_2.inputs[7].hide = True
	    compare_003_2.inputs[8].hide = True
	    compare_003_2.inputs[9].hide = True
	    compare_003_2.inputs[10].hide = True
	    compare_003_2.inputs[11].hide = True
	    compare_003_2.inputs[12].hide = True
	    #C
	    compare_003_2.inputs[10].default_value = 0.0
	
	    #node Merge by Distance
	    merge_by_distance_1 = mesh_magic.nodes.new("GeometryNodeMergeByDistance")
	    merge_by_distance_1.name = "Merge by Distance"
	    merge_by_distance_1.mode = 'ALL'
	
	    #node Subdivision Surface
	    subdivision_surface = mesh_magic.nodes.new("GeometryNodeSubdivisionSurface")
	    subdivision_surface.name = "Subdivision Surface"
	    subdivision_surface.boundary_smooth = 'ALL'
	    subdivision_surface.uv_smooth = 'PRESERVE_BOUNDARIES'
	
	    #node Frame
	    frame_5 = mesh_magic.nodes.new("NodeFrame")
	    frame_5.name = "Frame"
	    frame_5.label_size = 20
	    frame_5.shrink = True
	
	    #node Geometry Proximity.001
	    geometry_proximity_001 = mesh_magic.nodes.new("GeometryNodeProximity")
	    geometry_proximity_001.name = "Geometry Proximity.001"
	    geometry_proximity_001.target_element = 'POINTS'
	    geometry_proximity_001.inputs[1].hide = True
	    geometry_proximity_001.inputs[2].hide = True
	    geometry_proximity_001.inputs[3].hide = True
	    geometry_proximity_001.outputs[1].hide = True
	    geometry_proximity_001.outputs[2].hide = True
	    #Group ID
	    geometry_proximity_001.inputs[1].default_value = 0
	    #Source Position
	    geometry_proximity_001.inputs[2].default_value = (0.0, 0.0, 0.0)
	    #Sample Group ID
	    geometry_proximity_001.inputs[3].default_value = 0
	
	    #node Reroute
	    reroute_6 = mesh_magic.nodes.new("NodeReroute")
	    reroute_6.name = "Reroute"
	    reroute_6.socket_idname = "NodeSocketVector"
	    #node Curve to Mesh.001
	    curve_to_mesh_001 = mesh_magic.nodes.new("GeometryNodeCurveToMesh")
	    curve_to_mesh_001.name = "Curve to Mesh.001"
	    curve_to_mesh_001.hide = True
	    curve_to_mesh_001.inputs[1].hide = True
	    curve_to_mesh_001.inputs[2].hide = True
	    #Fill Caps
	    curve_to_mesh_001.inputs[2].default_value = False
	
	    #node Reroute.002
	    reroute_002_1 = mesh_magic.nodes.new("NodeReroute")
	    reroute_002_1.name = "Reroute.002"
	    reroute_002_1.socket_idname = "NodeSocketVector"
	    #node Attribute Statistic
	    attribute_statistic_3 = mesh_magic.nodes.new("GeometryNodeAttributeStatistic")
	    attribute_statistic_3.name = "Attribute Statistic"
	    attribute_statistic_3.hide = True
	    attribute_statistic_3.data_type = 'FLOAT_VECTOR'
	    attribute_statistic_3.domain = 'POINT'
	    attribute_statistic_3.inputs[1].hide = True
	    attribute_statistic_3.outputs[1].hide = True
	    attribute_statistic_3.outputs[2].hide = True
	    attribute_statistic_3.outputs[3].hide = True
	    attribute_statistic_3.outputs[4].hide = True
	    attribute_statistic_3.outputs[5].hide = True
	    attribute_statistic_3.outputs[6].hide = True
	    attribute_statistic_3.outputs[7].hide = True
	    #Selection
	    attribute_statistic_3.inputs[1].default_value = True
	
	    #node Position.003
	    position_003_1 = mesh_magic.nodes.new("GeometryNodeInputPosition")
	    position_003_1.name = "Position.003"
	
	    #node Vector Math.003
	    vector_math_003 = mesh_magic.nodes.new("ShaderNodeVectorMath")
	    vector_math_003.name = "Vector Math.003"
	    vector_math_003.hide = True
	    vector_math_003.operation = 'SCALE'
	    vector_math_003.inputs[1].hide = True
	    vector_math_003.inputs[2].hide = True
	    vector_math_003.inputs[3].hide = True
	    vector_math_003.outputs[1].hide = True
	    #Scale
	    vector_math_003.inputs[3].default_value = -1.0
	
	    #node Sample Index
	    sample_index_3 = mesh_magic.nodes.new("GeometryNodeSampleIndex")
	    sample_index_3.name = "Sample Index"
	    sample_index_3.hide = True
	    sample_index_3.clamp = True
	    sample_index_3.data_type = 'FLOAT_VECTOR'
	    sample_index_3.domain = 'POINT'
	
	    #node Reroute.003
	    reroute_003_1 = mesh_magic.nodes.new("NodeReroute")
	    reroute_003_1.name = "Reroute.003"
	    reroute_003_1.socket_idname = "NodeSocketGeometry"
	    #node Index
	    index_6 = mesh_magic.nodes.new("GeometryNodeInputIndex")
	    index_6.name = "Index"
	
	    #node Transform Geometry
	    transform_geometry_2 = mesh_magic.nodes.new("GeometryNodeTransform")
	    transform_geometry_2.name = "Transform Geometry"
	    transform_geometry_2.mode = 'COMPONENTS'
	    transform_geometry_2.inputs[2].hide = True
	    transform_geometry_2.inputs[3].hide = True
	    transform_geometry_2.inputs[4].hide = True
	    #Rotation
	    transform_geometry_2.inputs[2].default_value = (0.0, 0.0, 0.0)
	    #Scale
	    transform_geometry_2.inputs[3].default_value = (1.0, 1.0, 1.0)
	
	    #node Set Position.003
	    set_position_003_1 = mesh_magic.nodes.new("GeometryNodeSetPosition")
	    set_position_003_1.name = "Set Position.003"
	    set_position_003_1.inputs[3].hide = True
	    #Offset
	    set_position_003_1.inputs[3].default_value = (0.0, 0.0, 0.0)
	
	    #node Boolean Math.002
	    boolean_math_002_2 = mesh_magic.nodes.new("FunctionNodeBooleanMath")
	    boolean_math_002_2.name = "Boolean Math.002"
	    boolean_math_002_2.hide = True
	    boolean_math_002_2.operation = 'AND'
	
	    #node Reroute.001
	    reroute_001_5 = mesh_magic.nodes.new("NodeReroute")
	    reroute_001_5.name = "Reroute.001"
	    reroute_001_5.socket_idname = "NodeSocketVector"
	    #node Reroute.004
	    reroute_004_3 = mesh_magic.nodes.new("NodeReroute")
	    reroute_004_3.name = "Reroute.004"
	    reroute_004_3.socket_idname = "NodeSocketVector"
	    #node Switch
	    switch_3 = mesh_magic.nodes.new("GeometryNodeSwitch")
	    switch_3.name = "Switch"
	    switch_3.input_type = 'GEOMETRY'
	
	    #node Reroute.005
	    reroute_005_3 = mesh_magic.nodes.new("NodeReroute")
	    reroute_005_3.name = "Reroute.005"
	    reroute_005_3.socket_idname = "NodeSocketGeometry"
	    #node Reroute.006
	    reroute_006_3 = mesh_magic.nodes.new("NodeReroute")
	    reroute_006_3.name = "Reroute.006"
	    reroute_006_3.socket_idname = "NodeSocketGeometry"
	    #node Reroute.007
	    reroute_007_3 = mesh_magic.nodes.new("NodeReroute")
	    reroute_007_3.name = "Reroute.007"
	    reroute_007_3.socket_idname = "NodeSocketGeometry"
	    #node Switch.001
	    switch_001_5 = mesh_magic.nodes.new("GeometryNodeSwitch")
	    switch_001_5.name = "Switch.001"
	    switch_001_5.input_type = 'GEOMETRY'
	
	    #node Curve to Mesh.002
	    curve_to_mesh_002 = mesh_magic.nodes.new("GeometryNodeCurveToMesh")
	    curve_to_mesh_002.name = "Curve to Mesh.002"
	    curve_to_mesh_002.hide = True
	    curve_to_mesh_002.inputs[1].hide = True
	    curve_to_mesh_002.inputs[2].hide = True
	    #Fill Caps
	    curve_to_mesh_002.inputs[2].default_value = False
	
	    #node Geometry Proximity.002
	    geometry_proximity_002 = mesh_magic.nodes.new("GeometryNodeProximity")
	    geometry_proximity_002.name = "Geometry Proximity.002"
	    geometry_proximity_002.hide = True
	    geometry_proximity_002.target_element = 'EDGES'
	    geometry_proximity_002.inputs[1].hide = True
	    geometry_proximity_002.inputs[2].hide = True
	    geometry_proximity_002.inputs[3].hide = True
	    geometry_proximity_002.outputs[1].hide = True
	    geometry_proximity_002.outputs[2].hide = True
	    #Group ID
	    geometry_proximity_002.inputs[1].default_value = 0
	    #Source Position
	    geometry_proximity_002.inputs[2].default_value = (0.0, 0.0, 0.0)
	    #Sample Group ID
	    geometry_proximity_002.inputs[3].default_value = 0
	
	    #node Position.004
	    position_004 = mesh_magic.nodes.new("GeometryNodeInputPosition")
	    position_004.name = "Position.004"
	
	    #node Vector Math.004
	    vector_math_004_2 = mesh_magic.nodes.new("ShaderNodeVectorMath")
	    vector_math_004_2.name = "Vector Math.004"
	    vector_math_004_2.hide = True
	    vector_math_004_2.operation = 'SUBTRACT'
	
	    #node Compare.002
	    compare_002_4 = mesh_magic.nodes.new("FunctionNodeCompare")
	    compare_002_4.name = "Compare.002"
	    compare_002_4.hide = True
	    compare_002_4.data_type = 'VECTOR'
	    compare_002_4.mode = 'DOT_PRODUCT'
	    compare_002_4.operation = 'GREATER_THAN'
	    compare_002_4.inputs[0].hide = True
	    compare_002_4.inputs[1].hide = True
	    compare_002_4.inputs[2].hide = True
	    compare_002_4.inputs[3].hide = True
	    compare_002_4.inputs[6].hide = True
	    compare_002_4.inputs[7].hide = True
	    compare_002_4.inputs[8].hide = True
	    compare_002_4.inputs[9].hide = True
	    compare_002_4.inputs[10].hide = True
	    compare_002_4.inputs[11].hide = True
	    compare_002_4.inputs[12].hide = True
	    #C
	    compare_002_4.inputs[10].default_value = 0.0
	
	    #node Vector Math.005
	    vector_math_005 = mesh_magic.nodes.new("ShaderNodeVectorMath")
	    vector_math_005.name = "Vector Math.005"
	    vector_math_005.hide = True
	    vector_math_005.operation = 'NORMALIZE'
	
	    #node Normal
	    normal_1 = mesh_magic.nodes.new("GeometryNodeInputNormal")
	    normal_1.name = "Normal"
	    normal_1.legacy_corner_normals = False
	
	    #node Reroute.008
	    reroute_008_3 = mesh_magic.nodes.new("NodeReroute")
	    reroute_008_3.name = "Reroute.008"
	    reroute_008_3.socket_idname = "NodeSocketGeometry"
	    #node Reroute.009
	    reroute_009_3 = mesh_magic.nodes.new("NodeReroute")
	    reroute_009_3.name = "Reroute.009"
	    reroute_009_3.socket_idname = "NodeSocketGeometry"
	    #node Reroute.010
	    reroute_010_1 = mesh_magic.nodes.new("NodeReroute")
	    reroute_010_1.name = "Reroute.010"
	    reroute_010_1.socket_idname = "NodeSocketGeometry"
	    #node Group Input.005
	    group_input_005_3 = mesh_magic.nodes.new("NodeGroupInput")
	    group_input_005_3.name = "Group Input.005"
	    group_input_005_3.outputs[0].hide = True
	    group_input_005_3.outputs[1].hide = True
	    group_input_005_3.outputs[2].hide = True
	    group_input_005_3.outputs[3].hide = True
	    group_input_005_3.outputs[4].hide = True
	    group_input_005_3.outputs[5].hide = True
	    group_input_005_3.outputs[6].hide = True
	    group_input_005_3.outputs[11].hide = True
	    group_input_005_3.outputs[12].hide = True
	
	    #node Group Input.006
	    group_input_006_2 = mesh_magic.nodes.new("NodeGroupInput")
	    group_input_006_2.name = "Group Input.006"
	    group_input_006_2.outputs[0].hide = True
	    group_input_006_2.outputs[1].hide = True
	    group_input_006_2.outputs[2].hide = True
	    group_input_006_2.outputs[3].hide = True
	    group_input_006_2.outputs[4].hide = True
	    group_input_006_2.outputs[5].hide = True
	    group_input_006_2.outputs[7].hide = True
	    group_input_006_2.outputs[8].hide = True
	    group_input_006_2.outputs[9].hide = True
	    group_input_006_2.outputs[10].hide = True
	    group_input_006_2.outputs[11].hide = True
	    group_input_006_2.outputs[12].hide = True
	
	    #node Group Input.007
	    group_input_007 = mesh_magic.nodes.new("NodeGroupInput")
	    group_input_007.name = "Group Input.007"
	    group_input_007.outputs[0].hide = True
	    group_input_007.outputs[1].hide = True
	    group_input_007.outputs[2].hide = True
	    group_input_007.outputs[4].hide = True
	    group_input_007.outputs[5].hide = True
	    group_input_007.outputs[6].hide = True
	    group_input_007.outputs[7].hide = True
	    group_input_007.outputs[8].hide = True
	    group_input_007.outputs[9].hide = True
	    group_input_007.outputs[10].hide = True
	    group_input_007.outputs[11].hide = True
	    group_input_007.outputs[12].hide = True
	
	    #node Group Input.008
	    group_input_008 = mesh_magic.nodes.new("NodeGroupInput")
	    group_input_008.name = "Group Input.008"
	    group_input_008.outputs[0].hide = True
	    group_input_008.outputs[1].hide = True
	    group_input_008.outputs[2].hide = True
	    group_input_008.outputs[3].hide = True
	    group_input_008.outputs[4].hide = True
	    group_input_008.outputs[5].hide = True
	    group_input_008.outputs[6].hide = True
	    group_input_008.outputs[7].hide = True
	    group_input_008.outputs[8].hide = True
	    group_input_008.outputs[9].hide = True
	    group_input_008.outputs[10].hide = True
	    group_input_008.outputs[12].hide = True
	
	    #node Convex Hull
	    convex_hull = mesh_magic.nodes.new("GeometryNodeConvexHull")
	    convex_hull.name = "Convex Hull"
	    convex_hull.hide = True
	
	    #node Resample Curve
	    resample_curve_2 = mesh_magic.nodes.new("GeometryNodeResampleCurve")
	    resample_curve_2.name = "Resample Curve"
	    resample_curve_2.hide = True
	    resample_curve_2.keep_last_segment = True
	    resample_curve_2.mode = 'COUNT'
	    resample_curve_2.inputs[1].hide = True
	    resample_curve_2.inputs[2].hide = True
	    resample_curve_2.inputs[3].hide = True
	    #Selection
	    resample_curve_2.inputs[1].default_value = True
	    #Count
	    resample_curve_2.inputs[2].default_value = 1
	
	    #node Group Input.009
	    group_input_009 = mesh_magic.nodes.new("NodeGroupInput")
	    group_input_009.name = "Group Input.009"
	    group_input_009.outputs[1].hide = True
	    group_input_009.outputs[2].hide = True
	    group_input_009.outputs[3].hide = True
	    group_input_009.outputs[4].hide = True
	    group_input_009.outputs[5].hide = True
	    group_input_009.outputs[6].hide = True
	    group_input_009.outputs[7].hide = True
	    group_input_009.outputs[8].hide = True
	    group_input_009.outputs[9].hide = True
	    group_input_009.outputs[10].hide = True
	    group_input_009.outputs[11].hide = True
	    group_input_009.outputs[12].hide = True
	
	    #node Reroute.011
	    reroute_011_2 = mesh_magic.nodes.new("NodeReroute")
	    reroute_011_2.name = "Reroute.011"
	    reroute_011_2.socket_idname = "NodeSocketGeometry"
	    #node Reroute.012
	    reroute_012_2 = mesh_magic.nodes.new("NodeReroute")
	    reroute_012_2.name = "Reroute.012"
	    reroute_012_2.socket_idname = "NodeSocketGeometry"
	    #node Reroute.013
	    reroute_013_2 = mesh_magic.nodes.new("NodeReroute")
	    reroute_013_2.name = "Reroute.013"
	    reroute_013_2.socket_idname = "NodeSocketGeometry"
	    #node Group.002
	    group_002_1 = mesh_magic.nodes.new("GeometryNodeGroup")
	    group_002_1.name = "Group.002"
	    group_002_1.hide = True
	    group_002_1.node_tree = restore_curve_segment_length_001
	    group_002_1.inputs[1].hide = True
	    #Socket_2
	    group_002_1.inputs[1].default_value = True
	
	    #node Sample Index.003
	    sample_index_003 = mesh_magic.nodes.new("GeometryNodeSampleIndex")
	    sample_index_003.name = "Sample Index.003"
	    sample_index_003.hide = True
	    sample_index_003.clamp = False
	    sample_index_003.data_type = 'FLOAT_VECTOR'
	    sample_index_003.domain = 'POINT'
	
	    #node Index.001
	    index_001_4 = mesh_magic.nodes.new("GeometryNodeInputIndex")
	    index_001_4.name = "Index.001"
	
	    #node Position.006
	    position_006 = mesh_magic.nodes.new("GeometryNodeInputPosition")
	    position_006.name = "Position.006"
	
	    #node Group Input.004
	    group_input_004_2 = mesh_magic.nodes.new("NodeGroupInput")
	    group_input_004_2.name = "Group Input.004"
	    group_input_004_2.outputs[0].hide = True
	    group_input_004_2.outputs[1].hide = True
	    group_input_004_2.outputs[2].hide = True
	    group_input_004_2.outputs[3].hide = True
	    group_input_004_2.outputs[6].hide = True
	    group_input_004_2.outputs[7].hide = True
	    group_input_004_2.outputs[8].hide = True
	    group_input_004_2.outputs[9].hide = True
	    group_input_004_2.outputs[10].hide = True
	    group_input_004_2.outputs[11].hide = True
	    group_input_004_2.outputs[12].hide = True
	
	
	
	
	    #Set parents
	    merge_by_distance_1.parent = frame_5
	    subdivision_surface.parent = frame_5
	    curve_to_mesh_002.parent = frame_5
	    geometry_proximity_002.parent = frame_5
	    position_004.parent = frame_5
	    vector_math_004_2.parent = frame_5
	    compare_002_4.parent = frame_5
	    vector_math_005.parent = frame_5
	    normal_1.parent = frame_5
	    group_input_008.parent = frame_5
	
	    #Set locations
	    group_output_15.location = (1031.5587158203125, 81.62284851074219)
	    group_input_11.location = (-1337.7576904296875, 0.0)
	    group_4.location = (-1561.1627197265625, -444.97662353515625)
	    group_004_1.location = (-1387.1285400390625, -444.80096435546875)
	    group_005_1.location = (-1159.2635498046875, 48.164581298828125)
	    curve_to_mesh_2.location = (-312.4471435546875, -60.54876708984375)
	    set_position_001_4.location = (-788.6621704101562, -228.47361755371094)
	    position_002_6.location = (-792.6373901367188, -405.48309326171875)
	    separate_xyz_2.location = (-791.5325317382812, -374.3955078125)
	    combine_xyz_1.location = (-790.7725219726562, -337.9853515625)
	    set_curve_radius_2.location = (-975.1597900390625, 75.02672576904297)
	    capture_attribute_001.location = (-531.400146484375, -121.226318359375)
	    capture_attribute_002_1.location = (-533.6032104492188, -185.83802795410156)
	    spline_parameter_2.location = (-533.6025390625, -35.50511169433594)
	    store_named_attribute_3.location = (-132.1085205078125, -31.856613159179688)
	    combine_xyz_001_3.location = (-307.5316162109375, -196.94834899902344)
	    stylized_mesh_shape.location = (-1338.9588623046875, 386.1346435546875)
	    spline_parameter_001_2.location = (-1335.0230712890625, 69.11566925048828)
	    map_range_2.location = (-974.5907592773438, 125.018310546875)
	    group_input_001_9.location = (-977.0860595703125, 187.7188720703125)
	    group_input_002_7.location = (-1562.2896728515625, -548.21484375)
	    group_input_003_5.location = (-323.04083251953125, -284.2138671875)
	    set_position_002_3.location = (59.1375732421875, -6.6789703369140625)
	    geometry_proximity.location = (-124.21686553955078, -345.39385986328125)
	    object_info.location = (-317.07330322265625, -345.391845703125)
	    named_attribute_3.location = (63.2789306640625, -209.4910430908203)
	    separate_xyz_001_2.location = (63.2738037109375, -177.6759490966797)
	    compare_4.location = (63.2681884765625, -140.26284790039062)
	    delete_geometry_001_1.location = (410.6286315917969, 7.821929931640625)
	    vertex_neighbors_1.location = (412.1759948730469, -176.40525817871094)
	    compare_001_2.location = (412.1015319824219, -146.34869384765625)
	    raycast.location = (56.59661865234375, -342.426513671875)
	    vector_math_001_1.location = (-122.12775421142578, -379.99432373046875)
	    position_5.location = (-317.44903564453125, -374.13055419921875)
	    vector_math_002.location = (-120.57453155517578, -415.8165283203125)
	    compare_003_2.location = (63.36517333984375, -378.056884765625)
	    merge_by_distance_1.location = (344.03363037109375, -30.38555908203125)
	    subdivision_surface.location = (30.454833984375, -36.522369384765625)
	    frame_5.location = (621.0, -142.0)
	    geometry_proximity_001.location = (-983.087158203125, -543.2496948242188)
	    reroute_6.location = (28.21014404296875, -110.69659423828125)
	    curve_to_mesh_001.location = (-1194.0711669921875, -621.5685424804688)
	    reroute_002_1.location = (31.23211669921875, -243.04759216308594)
	    attribute_statistic_3.location = (-983.5204467773438, -440.9342041015625)
	    position_003_1.location = (-1198.7054443359375, -486.99920654296875)
	    vector_math_003.location = (-981.1094360351562, -384.22332763671875)
	    sample_index_3.location = (-982.5184936523438, -494.052734375)
	    reroute_003_1.location = (-1015.1716918945312, -474.0562744140625)
	    index_6.location = (-1197.283447265625, -541.866455078125)
	    transform_geometry_2.location = (-981.6549682617188, -253.2978057861328)
	    set_position_003_1.location = (244.274658203125, -105.82246398925781)
	    boolean_math_002_2.location = (244.3353271484375, -239.52256774902344)
	    reroute_001_5.location = (-389.7041015625, -577.631103515625)
	    reroute_004_3.location = (-390.2657775878906, -249.13380432128906)
	    switch_3.location = (833.3876953125, 80.71955871582031)
	    reroute_005_3.location = (601.5782470703125, -26.6990966796875)
	    reroute_006_3.location = (1102.367431640625, -101.81690979003906)
	    reroute_007_3.location = (833.978759765625, -102.31964111328125)
	    switch_001_5.location = (249.525634765625, 64.32618713378906)
	    curve_to_mesh_002.location = (36.904541015625, -387.6512451171875)
	    geometry_proximity_002.location = (347.34417724609375, -302.5712890625)
	    position_004.location = (36.405517578125, -311.45703125)
	    vector_math_004_2.location = (343.53411865234375, -249.55474853515625)
	    compare_002_4.location = (346.50726318359375, -180.98382568359375)
	    vector_math_005.location = (344.39007568359375, -215.7021484375)
	    normal_1.location = (35.951416015625, -253.07757568359375)
	    reroute_008_3.location = (606.60009765625, -287.90728759765625)
	    reroute_009_3.location = (-699.68603515625, 40.084739685058594)
	    reroute_010_1.location = (-571.5803833007812, -123.06626892089844)
	    group_input_005_3.location = (420.6587219238281, -276.055908203125)
	    group_input_006_2.location = (249.810546875, 120.62094116210938)
	    group_input_007.location = (834.636962890625, 135.9620361328125)
	    group_input_008.location = (188.27728271484375, -123.00439453125)
	    convex_hull.location = (-1747.9849853515625, -517.2109375)
	    resample_curve_2.location = (-1751.5504150390625, -566.2632446289062)
	    group_input_009.location = (-1751.3270263671875, -597.8270874023438)
	    reroute_011_2.location = (-571.0870361328125, 164.75799560546875)
	    reroute_012_2.location = (568.4801025390625, 178.11517333984375)
	    reroute_013_2.location = (589.6373291015625, -539.890625)
	    group_002_1.location = (-786.8271484375, -179.7821502685547)
	    sample_index_003.location = (-781.8150634765625, -108.58781433105469)
	    index_001_4.location = (-979.1199951171875, -89.25547790527344)
	    position_006.location = (-976.2593994140625, -34.26322937011719)
	    group_input_004_2.location = (-982.133056640625, -150.17100524902344)
	
	    #Set dimensions
	    group_output_15.width, group_output_15.height = 140.0, 100.0
	    group_input_11.width, group_input_11.height = 140.0, 100.0
	    group_4.width, group_4.height = 140.0, 100.0
	    group_004_1.width, group_004_1.height = 140.0, 100.0
	    group_005_1.width, group_005_1.height = 140.0, 100.0
	    curve_to_mesh_2.width, curve_to_mesh_2.height = 140.0, 100.0
	    set_position_001_4.width, set_position_001_4.height = 140.0, 100.0
	    position_002_6.width, position_002_6.height = 140.0, 100.0
	    separate_xyz_2.width, separate_xyz_2.height = 140.0, 100.0
	    combine_xyz_1.width, combine_xyz_1.height = 140.0, 100.0
	    set_curve_radius_2.width, set_curve_radius_2.height = 140.0, 100.0
	    capture_attribute_001.width, capture_attribute_001.height = 140.0, 100.0
	    capture_attribute_002_1.width, capture_attribute_002_1.height = 140.0, 100.0
	    spline_parameter_2.width, spline_parameter_2.height = 140.0, 100.0
	    store_named_attribute_3.width, store_named_attribute_3.height = 140.0, 100.0
	    combine_xyz_001_3.width, combine_xyz_001_3.height = 140.0, 100.0
	    stylized_mesh_shape.width, stylized_mesh_shape.height = 240.0, 100.0
	    spline_parameter_001_2.width, spline_parameter_001_2.height = 140.0, 100.0
	    map_range_2.width, map_range_2.height = 140.0, 100.0
	    group_input_001_9.width, group_input_001_9.height = 140.0, 100.0
	    group_input_002_7.width, group_input_002_7.height = 140.0, 100.0
	    group_input_003_5.width, group_input_003_5.height = 140.0, 100.0
	    set_position_002_3.width, set_position_002_3.height = 140.0, 100.0
	    geometry_proximity.width, geometry_proximity.height = 140.0, 100.0
	    object_info.width, object_info.height = 140.0, 100.0
	    named_attribute_3.width, named_attribute_3.height = 140.0, 100.0
	    separate_xyz_001_2.width, separate_xyz_001_2.height = 140.0, 100.0
	    compare_4.width, compare_4.height = 140.0, 100.0
	    delete_geometry_001_1.width, delete_geometry_001_1.height = 140.0, 100.0
	    vertex_neighbors_1.width, vertex_neighbors_1.height = 140.0, 100.0
	    compare_001_2.width, compare_001_2.height = 140.0, 100.0
	    raycast.width, raycast.height = 150.0, 100.0
	    vector_math_001_1.width, vector_math_001_1.height = 140.0, 100.0
	    position_5.width, position_5.height = 140.0, 100.0
	    vector_math_002.width, vector_math_002.height = 140.0, 100.0
	    compare_003_2.width, compare_003_2.height = 140.0, 100.0
	    merge_by_distance_1.width, merge_by_distance_1.height = 140.0, 100.0
	    subdivision_surface.width, subdivision_surface.height = 150.0, 100.0
	    frame_5.width, frame_5.height = 517.0, 443.0
	    geometry_proximity_001.width, geometry_proximity_001.height = 140.0, 100.0
	    reroute_6.width, reroute_6.height = 100.0, 100.0
	    curve_to_mesh_001.width, curve_to_mesh_001.height = 140.0, 100.0
	    reroute_002_1.width, reroute_002_1.height = 100.0, 100.0
	    attribute_statistic_3.width, attribute_statistic_3.height = 140.0, 100.0
	    position_003_1.width, position_003_1.height = 140.0, 100.0
	    vector_math_003.width, vector_math_003.height = 140.0, 100.0
	    sample_index_3.width, sample_index_3.height = 140.0, 100.0
	    reroute_003_1.width, reroute_003_1.height = 100.0, 100.0
	    index_6.width, index_6.height = 140.0, 100.0
	    transform_geometry_2.width, transform_geometry_2.height = 140.0, 100.0
	    set_position_003_1.width, set_position_003_1.height = 140.0, 100.0
	    boolean_math_002_2.width, boolean_math_002_2.height = 140.0, 100.0
	    reroute_001_5.width, reroute_001_5.height = 100.0, 100.0
	    reroute_004_3.width, reroute_004_3.height = 100.0, 100.0
	    switch_3.width, switch_3.height = 140.0, 100.0
	    reroute_005_3.width, reroute_005_3.height = 100.0, 100.0
	    reroute_006_3.width, reroute_006_3.height = 100.0, 100.0
	    reroute_007_3.width, reroute_007_3.height = 100.0, 100.0
	    switch_001_5.width, switch_001_5.height = 140.0, 100.0
	    curve_to_mesh_002.width, curve_to_mesh_002.height = 140.0, 100.0
	    geometry_proximity_002.width, geometry_proximity_002.height = 140.0, 100.0
	    position_004.width, position_004.height = 140.0, 100.0
	    vector_math_004_2.width, vector_math_004_2.height = 140.0, 100.0
	    compare_002_4.width, compare_002_4.height = 140.0, 100.0
	    vector_math_005.width, vector_math_005.height = 140.0, 100.0
	    normal_1.width, normal_1.height = 140.0, 100.0
	    reroute_008_3.width, reroute_008_3.height = 100.0, 100.0
	    reroute_009_3.width, reroute_009_3.height = 100.0, 100.0
	    reroute_010_1.width, reroute_010_1.height = 100.0, 100.0
	    group_input_005_3.width, group_input_005_3.height = 140.0, 100.0
	    group_input_006_2.width, group_input_006_2.height = 140.0, 100.0
	    group_input_007.width, group_input_007.height = 140.0, 100.0
	    group_input_008.width, group_input_008.height = 140.0, 100.0
	    convex_hull.width, convex_hull.height = 140.0, 100.0
	    resample_curve_2.width, resample_curve_2.height = 140.0, 100.0
	    group_input_009.width, group_input_009.height = 140.0, 100.0
	    reroute_011_2.width, reroute_011_2.height = 100.0, 100.0
	    reroute_012_2.width, reroute_012_2.height = 100.0, 100.0
	    reroute_013_2.width, reroute_013_2.height = 100.0, 100.0
	    group_002_1.width, group_002_1.height = 140.0, 100.0
	    sample_index_003.width, sample_index_003.height = 140.0, 100.0
	    index_001_4.width, index_001_4.height = 140.0, 100.0
	    position_006.width, position_006.height = 140.0, 100.0
	    group_input_004_2.width, group_input_004_2.height = 140.0, 100.0
	
	    #initialize mesh_magic links
	    #combine_xyz_1.Vector -> set_position_001_4.Position
	    mesh_magic.links.new(combine_xyz_1.outputs[0], set_position_001_4.inputs[2])
	    #position_002_6.Position -> separate_xyz_2.Vector
	    mesh_magic.links.new(position_002_6.outputs[0], separate_xyz_2.inputs[0])
	    #capture_attribute_001.Geometry -> curve_to_mesh_2.Curve
	    mesh_magic.links.new(capture_attribute_001.outputs[0], curve_to_mesh_2.inputs[0])
	    #separate_xyz_2.X -> combine_xyz_1.X
	    mesh_magic.links.new(separate_xyz_2.outputs[0], combine_xyz_1.inputs[0])
	    #group_005_1.Geometry -> set_curve_radius_2.Curve
	    mesh_magic.links.new(group_005_1.outputs[0], set_curve_radius_2.inputs[0])
	    #separate_xyz_2.Y -> combine_xyz_1.Y
	    mesh_magic.links.new(separate_xyz_2.outputs[1], combine_xyz_1.inputs[1])
	    #capture_attribute_002_1.Geometry -> curve_to_mesh_2.Profile Curve
	    mesh_magic.links.new(capture_attribute_002_1.outputs[0], curve_to_mesh_2.inputs[1])
	    #group_4.Geometry -> group_004_1.Geometry
	    mesh_magic.links.new(group_4.outputs[0], group_004_1.inputs[0])
	    #transform_geometry_2.Geometry -> set_position_001_4.Geometry
	    mesh_magic.links.new(transform_geometry_2.outputs[0], set_position_001_4.inputs[0])
	    #group_input_11.Geometry -> group_005_1.Geometry
	    mesh_magic.links.new(group_input_11.outputs[0], group_005_1.inputs[0])
	    #reroute_010_1.Output -> capture_attribute_001.Geometry
	    mesh_magic.links.new(reroute_010_1.outputs[0], capture_attribute_001.inputs[0])
	    #spline_parameter_2.Factor -> capture_attribute_001.Factor
	    mesh_magic.links.new(spline_parameter_2.outputs[0], capture_attribute_001.inputs[1])
	    #spline_parameter_2.Factor -> capture_attribute_002_1.Factor
	    mesh_magic.links.new(spline_parameter_2.outputs[0], capture_attribute_002_1.inputs[1])
	    #curve_to_mesh_2.Mesh -> store_named_attribute_3.Geometry
	    mesh_magic.links.new(curve_to_mesh_2.outputs[0], store_named_attribute_3.inputs[0])
	    #combine_xyz_001_3.Vector -> store_named_attribute_3.Value
	    mesh_magic.links.new(combine_xyz_001_3.outputs[0], store_named_attribute_3.inputs[3])
	    #capture_attribute_001.Factor -> combine_xyz_001_3.X
	    mesh_magic.links.new(capture_attribute_001.outputs[1], combine_xyz_001_3.inputs[0])
	    #capture_attribute_002_1.Factor -> combine_xyz_001_3.Y
	    mesh_magic.links.new(capture_attribute_002_1.outputs[1], combine_xyz_001_3.inputs[1])
	    #spline_parameter_001_2.Factor -> stylized_mesh_shape.Value
	    mesh_magic.links.new(spline_parameter_001_2.outputs[0], stylized_mesh_shape.inputs[1])
	    #stylized_mesh_shape.Value -> map_range_2.Value
	    mesh_magic.links.new(stylized_mesh_shape.outputs[0], map_range_2.inputs[0])
	    #map_range_2.Result -> set_curve_radius_2.Radius
	    mesh_magic.links.new(map_range_2.outputs[0], set_curve_radius_2.inputs[2])
	    #group_input_001_9.Radius -> map_range_2.To Max
	    mesh_magic.links.new(group_input_001_9.outputs[2], map_range_2.inputs[4])
	    #group_input_002_7.Surface -> group_004_1.Surface
	    mesh_magic.links.new(group_input_002_7.outputs[1], group_004_1.inputs[1])
	    #store_named_attribute_3.Geometry -> set_position_002_3.Geometry
	    mesh_magic.links.new(store_named_attribute_3.outputs[0], set_position_002_3.inputs[0])
	    #group_input_003_5.Surface -> object_info.Object
	    mesh_magic.links.new(group_input_003_5.outputs[1], object_info.inputs[0])
	    #object_info.Geometry -> geometry_proximity.Geometry
	    mesh_magic.links.new(object_info.outputs[4], geometry_proximity.inputs[0])
	    #named_attribute_3.Attribute -> separate_xyz_001_2.Vector
	    mesh_magic.links.new(named_attribute_3.outputs[0], separate_xyz_001_2.inputs[0])
	    #separate_xyz_001_2.X -> compare_4.A
	    mesh_magic.links.new(separate_xyz_001_2.outputs[0], compare_4.inputs[0])
	    #vertex_neighbors_1.Face Count -> compare_001_2.A
	    mesh_magic.links.new(vertex_neighbors_1.outputs[1], compare_001_2.inputs[2])
	    #compare_001_2.Result -> delete_geometry_001_1.Selection
	    mesh_magic.links.new(compare_001_2.outputs[0], delete_geometry_001_1.inputs[1])
	    #object_info.Geometry -> raycast.Target Geometry
	    mesh_magic.links.new(object_info.outputs[4], raycast.inputs[0])
	    #geometry_proximity.Position -> vector_math_001_1.Vector
	    mesh_magic.links.new(geometry_proximity.outputs[0], vector_math_001_1.inputs[0])
	    #position_5.Position -> vector_math_001_1.Vector
	    mesh_magic.links.new(position_5.outputs[0], vector_math_001_1.inputs[1])
	    #vector_math_001_1.Vector -> vector_math_002.Vector
	    mesh_magic.links.new(vector_math_001_1.outputs[0], vector_math_002.inputs[0])
	    #vector_math_002.Vector -> raycast.Ray Direction
	    mesh_magic.links.new(vector_math_002.outputs[0], raycast.inputs[3])
	    #vector_math_002.Vector -> compare_003_2.A
	    mesh_magic.links.new(vector_math_002.outputs[0], compare_003_2.inputs[4])
	    #raycast.Hit Normal -> compare_003_2.B
	    mesh_magic.links.new(raycast.outputs[2], compare_003_2.inputs[5])
	    #reroute_6.Output -> set_position_002_3.Position
	    mesh_magic.links.new(reroute_6.outputs[0], set_position_002_3.inputs[2])
	    #curve_to_mesh_001.Mesh -> geometry_proximity_001.Geometry
	    mesh_magic.links.new(curve_to_mesh_001.outputs[0], geometry_proximity_001.inputs[0])
	    #group_004_1.Geometry -> curve_to_mesh_001.Curve
	    mesh_magic.links.new(group_004_1.outputs[0], curve_to_mesh_001.inputs[0])
	    #reroute_004_3.Output -> reroute_002_1.Input
	    mesh_magic.links.new(reroute_004_3.outputs[0], reroute_002_1.inputs[0])
	    #reroute_002_1.Output -> reroute_6.Input
	    mesh_magic.links.new(reroute_002_1.outputs[0], reroute_6.inputs[0])
	    #reroute_003_1.Output -> attribute_statistic_3.Geometry
	    mesh_magic.links.new(reroute_003_1.outputs[0], attribute_statistic_3.inputs[0])
	    #attribute_statistic_3.Mean -> vector_math_003.Vector
	    mesh_magic.links.new(attribute_statistic_3.outputs[0], vector_math_003.inputs[0])
	    #group_004_1.Geometry -> reroute_003_1.Input
	    mesh_magic.links.new(group_004_1.outputs[0], reroute_003_1.inputs[0])
	    #reroute_003_1.Output -> sample_index_3.Geometry
	    mesh_magic.links.new(reroute_003_1.outputs[0], sample_index_3.inputs[0])
	    #index_6.Index -> sample_index_3.Index
	    mesh_magic.links.new(index_6.outputs[0], sample_index_3.inputs[2])
	    #position_003_1.Position -> sample_index_3.Value
	    mesh_magic.links.new(position_003_1.outputs[0], sample_index_3.inputs[1])
	    #sample_index_3.Value -> attribute_statistic_3.Attribute
	    mesh_magic.links.new(sample_index_3.outputs[0], attribute_statistic_3.inputs[2])
	    #group_004_1.Geometry -> transform_geometry_2.Geometry
	    mesh_magic.links.new(group_004_1.outputs[0], transform_geometry_2.inputs[0])
	    #vector_math_003.Vector -> transform_geometry_2.Translation
	    mesh_magic.links.new(vector_math_003.outputs[0], transform_geometry_2.inputs[1])
	    #compare_4.Result -> set_position_002_3.Selection
	    mesh_magic.links.new(compare_4.outputs[0], set_position_002_3.inputs[1])
	    #set_position_002_3.Geometry -> set_position_003_1.Geometry
	    mesh_magic.links.new(set_position_002_3.outputs[0], set_position_003_1.inputs[0])
	    #raycast.Hit Position -> set_position_003_1.Position
	    mesh_magic.links.new(raycast.outputs[1], set_position_003_1.inputs[2])
	    #compare_003_2.Result -> boolean_math_002_2.Boolean
	    mesh_magic.links.new(compare_003_2.outputs[0], boolean_math_002_2.inputs[1])
	    #compare_4.Result -> boolean_math_002_2.Boolean
	    mesh_magic.links.new(compare_4.outputs[0], boolean_math_002_2.inputs[0])
	    #boolean_math_002_2.Boolean -> set_position_003_1.Selection
	    mesh_magic.links.new(boolean_math_002_2.outputs[0], set_position_003_1.inputs[1])
	    #geometry_proximity_001.Position -> reroute_001_5.Input
	    mesh_magic.links.new(geometry_proximity_001.outputs[0], reroute_001_5.inputs[0])
	    #reroute_001_5.Output -> reroute_004_3.Input
	    mesh_magic.links.new(reroute_001_5.outputs[0], reroute_004_3.inputs[0])
	    #reroute_007_3.Output -> switch_3.True
	    mesh_magic.links.new(reroute_007_3.outputs[0], switch_3.inputs[2])
	    #reroute_005_3.Output -> switch_3.False
	    mesh_magic.links.new(reroute_005_3.outputs[0], switch_3.inputs[1])
	    #switch_3.Output -> group_output_15.Geometry
	    mesh_magic.links.new(switch_3.outputs[0], group_output_15.inputs[0])
	    #delete_geometry_001_1.Geometry -> reroute_005_3.Input
	    mesh_magic.links.new(delete_geometry_001_1.outputs[0], reroute_005_3.inputs[0])
	    #reroute_006_3.Output -> reroute_007_3.Input
	    mesh_magic.links.new(reroute_006_3.outputs[0], reroute_007_3.inputs[0])
	    #set_position_003_1.Geometry -> switch_001_5.True
	    mesh_magic.links.new(set_position_003_1.outputs[0], switch_001_5.inputs[2])
	    #set_position_002_3.Geometry -> switch_001_5.False
	    mesh_magic.links.new(set_position_002_3.outputs[0], switch_001_5.inputs[1])
	    #switch_001_5.Output -> delete_geometry_001_1.Geometry
	    mesh_magic.links.new(switch_001_5.outputs[0], delete_geometry_001_1.inputs[0])
	    #curve_to_mesh_002.Mesh -> geometry_proximity_002.Geometry
	    mesh_magic.links.new(curve_to_mesh_002.outputs[0], geometry_proximity_002.inputs[0])
	    #geometry_proximity_002.Position -> vector_math_004_2.Vector
	    mesh_magic.links.new(geometry_proximity_002.outputs[0], vector_math_004_2.inputs[0])
	    #vector_math_005.Vector -> compare_002_4.A
	    mesh_magic.links.new(vector_math_005.outputs[0], compare_002_4.inputs[4])
	    #subdivision_surface.Mesh -> merge_by_distance_1.Geometry
	    mesh_magic.links.new(subdivision_surface.outputs[0], merge_by_distance_1.inputs[0])
	    #merge_by_distance_1.Geometry -> reroute_006_3.Input
	    mesh_magic.links.new(merge_by_distance_1.outputs[0], reroute_006_3.inputs[0])
	    #reroute_008_3.Output -> subdivision_surface.Mesh
	    mesh_magic.links.new(reroute_008_3.outputs[0], subdivision_surface.inputs[0])
	    #position_004.Position -> vector_math_004_2.Vector
	    mesh_magic.links.new(position_004.outputs[0], vector_math_004_2.inputs[1])
	    #vector_math_004_2.Vector -> vector_math_005.Vector
	    mesh_magic.links.new(vector_math_004_2.outputs[0], vector_math_005.inputs[0])
	    #normal_1.Normal -> compare_002_4.B
	    mesh_magic.links.new(normal_1.outputs[0], compare_002_4.inputs[5])
	    #compare_002_4.Result -> merge_by_distance_1.Selection
	    mesh_magic.links.new(compare_002_4.outputs[0], merge_by_distance_1.inputs[1])
	    #reroute_005_3.Output -> reroute_008_3.Input
	    mesh_magic.links.new(reroute_005_3.outputs[0], reroute_008_3.inputs[0])
	    #set_curve_radius_2.Curve -> reroute_009_3.Input
	    mesh_magic.links.new(set_curve_radius_2.outputs[0], reroute_009_3.inputs[0])
	    #reroute_009_3.Output -> reroute_010_1.Input
	    mesh_magic.links.new(reroute_009_3.outputs[0], reroute_010_1.inputs[0])
	    #group_input_006_2.Snap to surface -> switch_001_5.Switch
	    mesh_magic.links.new(group_input_006_2.outputs[6], switch_001_5.inputs[0])
	    #group_input_007.Use Enhancements -> switch_3.Switch
	    mesh_magic.links.new(group_input_007.outputs[3], switch_3.inputs[0])
	    #group_input_005_3.Level -> subdivision_surface.Level
	    mesh_magic.links.new(group_input_005_3.outputs[7], subdivision_surface.inputs[1])
	    #group_input_005_3.Edge Crease -> subdivision_surface.Edge Crease
	    mesh_magic.links.new(group_input_005_3.outputs[8], subdivision_surface.inputs[2])
	    #group_input_005_3.Vertex Crease -> subdivision_surface.Vertex Crease
	    mesh_magic.links.new(group_input_005_3.outputs[9], subdivision_surface.inputs[3])
	    #group_input_005_3.Limit Surface -> subdivision_surface.Limit Surface
	    mesh_magic.links.new(group_input_005_3.outputs[10], subdivision_surface.inputs[4])
	    #group_input_008.Distance -> merge_by_distance_1.Distance
	    mesh_magic.links.new(group_input_008.outputs[11], merge_by_distance_1.inputs[2])
	    #resample_curve_2.Curve -> convex_hull.Geometry
	    mesh_magic.links.new(resample_curve_2.outputs[0], convex_hull.inputs[0])
	    #group_input_009.Geometry -> resample_curve_2.Curve
	    mesh_magic.links.new(group_input_009.outputs[0], resample_curve_2.inputs[0])
	    #convex_hull.Convex Hull -> group_4.Geometry
	    mesh_magic.links.new(convex_hull.outputs[0], group_4.inputs[0])
	    #reroute_011_2.Output -> reroute_012_2.Input
	    mesh_magic.links.new(reroute_011_2.outputs[0], reroute_012_2.inputs[0])
	    #reroute_013_2.Output -> curve_to_mesh_002.Curve
	    mesh_magic.links.new(reroute_013_2.outputs[0], curve_to_mesh_002.inputs[0])
	    #reroute_012_2.Output -> reroute_013_2.Input
	    mesh_magic.links.new(reroute_012_2.outputs[0], reroute_013_2.inputs[0])
	    #transform_geometry_2.Geometry -> sample_index_003.Geometry
	    mesh_magic.links.new(transform_geometry_2.outputs[0], sample_index_003.inputs[0])
	    #index_001_4.Index -> sample_index_003.Index
	    mesh_magic.links.new(index_001_4.outputs[0], sample_index_003.inputs[2])
	    #position_006.Position -> sample_index_003.Value
	    mesh_magic.links.new(position_006.outputs[0], sample_index_003.inputs[1])
	    #set_position_001_4.Geometry -> group_002_1.Curves
	    mesh_magic.links.new(set_position_001_4.outputs[0], group_002_1.inputs[0])
	    #sample_index_003.Value -> group_002_1.Reference Position
	    mesh_magic.links.new(sample_index_003.outputs[0], group_002_1.inputs[3])
	    #group_002_1.Curves -> capture_attribute_002_1.Geometry
	    mesh_magic.links.new(group_002_1.outputs[0], capture_attribute_002_1.inputs[0])
	    #group_input_004_2.Maintain Shape Factor -> group_002_1.Factor
	    mesh_magic.links.new(group_input_004_2.outputs[4], group_002_1.inputs[2])
	    #group_input_004_2.Pin at Parameter -> group_002_1.Pin at Parameter
	    mesh_magic.links.new(group_input_004_2.outputs[5], group_002_1.inputs[4])
	    #reroute_009_3.Output -> reroute_011_2.Input
	    mesh_magic.links.new(reroute_009_3.outputs[0], reroute_011_2.inputs[0])
	    return mesh_magic
	
	mesh_magic = mesh_magic_node_group()
	
	#initialize stylized_meshify_hair node group
	def stylized_meshify_hair_node_group():
	    stylized_meshify_hair = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "STYLIZED_MESHIFY_HAIR")
	
	    stylized_meshify_hair.color_tag = 'NONE'
	    stylized_meshify_hair.description = "Convert muiltiguided curves to stylized mesh."
	    stylized_meshify_hair.default_group_node_width = 140
	    
	
	    stylized_meshify_hair.is_modifier = True
	
	    #stylized_meshify_hair interface
	    #Socket Geometry
	    geometry_socket_18 = stylized_meshify_hair.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_18.attribute_domain = 'POINT'
	    geometry_socket_18.description = "Stylized mesh hair."
	
	    #Socket Geometry
	    geometry_socket_19 = stylized_meshify_hair.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_19.attribute_domain = 'POINT'
	    geometry_socket_19.description = "Multiguided curves."
	
	    #Socket Surface
	    surface_socket_2 = stylized_meshify_hair.interface.new_socket(name = "Surface", in_out='INPUT', socket_type = 'NodeSocketObject')
	    surface_socket_2.attribute_domain = 'POINT'
	    surface_socket_2.description = "Surface attached to hair."
	
	    #Socket Material
	    material_socket_2 = stylized_meshify_hair.interface.new_socket(name = "Material", in_out='INPUT', socket_type = 'NodeSocketMaterial')
	    material_socket_2.attribute_domain = 'POINT'
	    material_socket_2.description = "Mesh Material."
	
	    #Socket Control Points
	    control_points_socket_2 = stylized_meshify_hair.interface.new_socket(name = "Control Points", in_out='INPUT', socket_type = 'NodeSocketInt')
	    control_points_socket_2.default_value = 10
	    control_points_socket_2.min_value = 2
	    control_points_socket_2.max_value = 100000
	    control_points_socket_2.subtype = 'NONE'
	    control_points_socket_2.attribute_domain = 'POINT'
	    control_points_socket_2.description = "Amount of points to resample the curves. (Amount < 2  means no resampling)"
	
	    #Socket Radius
	    radius_socket_1 = stylized_meshify_hair.interface.new_socket(name = "Radius", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    radius_socket_1.default_value = 1.0
	    radius_socket_1.min_value = 0.0
	    radius_socket_1.max_value = 3.4028234663852886e+38
	    radius_socket_1.subtype = 'DISTANCE'
	    radius_socket_1.attribute_domain = 'POINT'
	    radius_socket_1.description = "Mesh Radius."
	
	    #Panel Enhancement Settings
	    enhancement_settings_panel_1 = stylized_meshify_hair.interface.new_panel("Enhancement Settings", default_closed=True)
	    enhancement_settings_panel_1.description = "Settings for mesh enhancements."
	    #Socket Use Enhancements
	    use_enhancements_socket_1 = stylized_meshify_hair.interface.new_socket(name = "Use Enhancements", in_out='INPUT', socket_type = 'NodeSocketBool', parent = enhancement_settings_panel_1)
	    use_enhancements_socket_1.default_value = True
	    use_enhancements_socket_1.attribute_domain = 'POINT'
	    use_enhancements_socket_1.description = "Use Enhancement settings."
	
	    #Socket Maintain Shape Factor
	    maintain_shape_factor_socket_1 = stylized_meshify_hair.interface.new_socket(name = "Maintain Shape Factor", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = enhancement_settings_panel_1)
	    maintain_shape_factor_socket_1.default_value = 1.0
	    maintain_shape_factor_socket_1.min_value = 0.0
	    maintain_shape_factor_socket_1.max_value = 1.0
	    maintain_shape_factor_socket_1.subtype = 'FACTOR'
	    maintain_shape_factor_socket_1.attribute_domain = 'POINT'
	    maintain_shape_factor_socket_1.description = "Factor to blend overall effect"
	
	    #Socket Pin at Parameter
	    pin_at_parameter_socket_3 = stylized_meshify_hair.interface.new_socket(name = "Pin at Parameter", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = enhancement_settings_panel_1)
	    pin_at_parameter_socket_3.default_value = 0.0
	    pin_at_parameter_socket_3.min_value = 0.0
	    pin_at_parameter_socket_3.max_value = 1.0
	    pin_at_parameter_socket_3.subtype = 'FACTOR'
	    pin_at_parameter_socket_3.attribute_domain = 'POINT'
	    pin_at_parameter_socket_3.description = "Pin each curve at a certain point for the operation"
	
	    #Socket Snap to surface
	    snap_to_surface_socket_1 = stylized_meshify_hair.interface.new_socket(name = "Snap to surface", in_out='INPUT', socket_type = 'NodeSocketBool', parent = enhancement_settings_panel_1)
	    snap_to_surface_socket_1.default_value = False
	    snap_to_surface_socket_1.attribute_domain = 'POINT'
	    snap_to_surface_socket_1.description = "Snap mesh roots to the nearest surface point."
	
	    #Panel Subdivision Settings
	    subdivision_settings_panel_1 = stylized_meshify_hair.interface.new_panel("Subdivision Settings", default_closed=True)
	    subdivision_settings_panel_1.description = "Settings for mesh subdivision."
	    #Socket Subdivison Level
	    subdivison_level_socket = stylized_meshify_hair.interface.new_socket(name = "Subdivison Level", in_out='INPUT', socket_type = 'NodeSocketInt', parent = subdivision_settings_panel_1)
	    subdivison_level_socket.default_value = 1
	    subdivison_level_socket.min_value = 0
	    subdivison_level_socket.max_value = 6
	    subdivison_level_socket.subtype = 'NONE'
	    subdivison_level_socket.attribute_domain = 'POINT'
	    subdivison_level_socket.description = "Subdivision level."
	
	    #Socket Edge Crease
	    edge_crease_socket_1 = stylized_meshify_hair.interface.new_socket(name = "Edge Crease", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = subdivision_settings_panel_1)
	    edge_crease_socket_1.default_value = 0.0
	    edge_crease_socket_1.min_value = 0.0
	    edge_crease_socket_1.max_value = 1.0
	    edge_crease_socket_1.subtype = 'FACTOR'
	    edge_crease_socket_1.attribute_domain = 'POINT'
	    edge_crease_socket_1.description = "Edge crease factor for subdivision."
	
	    #Socket Vertex Crease
	    vertex_crease_socket_1 = stylized_meshify_hair.interface.new_socket(name = "Vertex Crease", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = subdivision_settings_panel_1)
	    vertex_crease_socket_1.default_value = 0.0
	    vertex_crease_socket_1.min_value = 0.0
	    vertex_crease_socket_1.max_value = 1.0
	    vertex_crease_socket_1.subtype = 'FACTOR'
	    vertex_crease_socket_1.attribute_domain = 'POINT'
	    vertex_crease_socket_1.description = "Vertex crease factor for subdivision."
	
	    #Socket Limit Surface
	    limit_surface_socket_1 = stylized_meshify_hair.interface.new_socket(name = "Limit Surface", in_out='INPUT', socket_type = 'NodeSocketBool', parent = subdivision_settings_panel_1)
	    limit_surface_socket_1.default_value = True
	    limit_surface_socket_1.attribute_domain = 'POINT'
	    limit_surface_socket_1.description = "Limit subdivision on surface."
	
	
	    stylized_meshify_hair.interface.move_to_parent(subdivision_settings_panel_1, enhancement_settings_panel_1, 11)
	    #Panel Merge Settings
	    merge_settings_panel_1 = stylized_meshify_hair.interface.new_panel("Merge Settings", default_closed=True)
	    merge_settings_panel_1.description = "Settings for merging points."
	    #Socket Distance
	    distance_socket_1 = stylized_meshify_hair.interface.new_socket(name = "Distance", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = merge_settings_panel_1)
	    distance_socket_1.default_value = 0.0010000000474974513
	    distance_socket_1.min_value = 0.0
	    distance_socket_1.max_value = 3.4028234663852886e+38
	    distance_socket_1.subtype = 'DISTANCE'
	    distance_socket_1.attribute_domain = 'POINT'
	    distance_socket_1.description = "Distance threshold to merge points."
	
	
	    stylized_meshify_hair.interface.move_to_parent(merge_settings_panel_1, enhancement_settings_panel_1, 16)
	
	
	    #initialize stylized_meshify_hair nodes
	    #node Group Input
	    group_input_12 = stylized_meshify_hair.nodes.new("NodeGroupInput")
	    group_input_12.name = "Group Input"
	    group_input_12.outputs[1].hide = True
	    group_input_12.outputs[2].hide = True
	    group_input_12.outputs[3].hide = True
	    group_input_12.outputs[4].hide = True
	    group_input_12.outputs[5].hide = True
	    group_input_12.outputs[6].hide = True
	    group_input_12.outputs[7].hide = True
	    group_input_12.outputs[8].hide = True
	    group_input_12.outputs[9].hide = True
	    group_input_12.outputs[10].hide = True
	    group_input_12.outputs[11].hide = True
	    group_input_12.outputs[12].hide = True
	    group_input_12.outputs[13].hide = True
	    group_input_12.outputs[14].hide = True
	
	    #node Group Output
	    group_output_16 = stylized_meshify_hair.nodes.new("NodeGroupOutput")
	    group_output_16.name = "Group Output"
	    group_output_16.is_active_output = True
	    group_output_16.inputs[1].hide = True
	
	    #node Named Attribute
	    named_attribute_4 = stylized_meshify_hair.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute_4.name = "Named Attribute"
	    named_attribute_4.data_type = 'INT'
	    #Name
	    named_attribute_4.inputs[0].default_value = "closest_idx"
	
	    #node Compare
	    compare_5 = stylized_meshify_hair.nodes.new("FunctionNodeCompare")
	    compare_5.name = "Compare"
	    compare_5.hide = True
	    compare_5.data_type = 'INT'
	    compare_5.mode = 'ELEMENT'
	    compare_5.operation = 'EQUAL'
	
	    #node Separate Geometry
	    separate_geometry = stylized_meshify_hair.nodes.new("GeometryNodeSeparateGeometry")
	    separate_geometry.name = "Separate Geometry"
	    separate_geometry.domain = 'CURVE'
	    separate_geometry.outputs[1].hide = True
	
	    #node Attribute Statistic.001
	    attribute_statistic_001 = stylized_meshify_hair.nodes.new("GeometryNodeAttributeStatistic")
	    attribute_statistic_001.name = "Attribute Statistic.001"
	    attribute_statistic_001.hide = True
	    attribute_statistic_001.data_type = 'FLOAT'
	    attribute_statistic_001.domain = 'CURVE'
	    attribute_statistic_001.inputs[1].hide = True
	    attribute_statistic_001.outputs[0].hide = True
	    attribute_statistic_001.outputs[1].hide = True
	    attribute_statistic_001.outputs[2].hide = True
	    attribute_statistic_001.outputs[3].hide = True
	    attribute_statistic_001.outputs[5].hide = True
	    attribute_statistic_001.outputs[6].hide = True
	    attribute_statistic_001.outputs[7].hide = True
	    #Selection
	    attribute_statistic_001.inputs[1].default_value = True
	
	    #node Repeat Input
	    repeat_input_1 = stylized_meshify_hair.nodes.new("GeometryNodeRepeatInput")
	    repeat_input_1.name = "Repeat Input"
	    #node Repeat Output
	    repeat_output_1 = stylized_meshify_hair.nodes.new("GeometryNodeRepeatOutput")
	    repeat_output_1.name = "Repeat Output"
	    repeat_output_1.active_index = 1
	    repeat_output_1.inspection_index = 0
	    repeat_output_1.repeat_items.clear()
	    # Create item "Geometry"
	    repeat_output_1.repeat_items.new('GEOMETRY', "Geometry")
	    # Create item "Index"
	    repeat_output_1.repeat_items.new('INT', "Index")
	
	    #node Join Geometry.001
	    join_geometry_001 = stylized_meshify_hair.nodes.new("GeometryNodeJoinGeometry")
	    join_geometry_001.name = "Join Geometry.001"
	    join_geometry_001.hide = True
	
	    #node Math
	    math_5 = stylized_meshify_hair.nodes.new("ShaderNodeMath")
	    math_5.name = "Math"
	    math_5.hide = True
	    math_5.operation = 'ADD'
	    math_5.use_clamp = False
	    #Value_001
	    math_5.inputs[1].default_value = 1.0
	
	    #node Math.001
	    math_001_4 = stylized_meshify_hair.nodes.new("ShaderNodeMath")
	    math_001_4.name = "Math.001"
	    math_001_4.hide = True
	    math_001_4.operation = 'ADD'
	    math_001_4.use_clamp = False
	    #Value_001
	    math_001_4.inputs[1].default_value = 1.0
	
	    #node Named Attribute.003
	    named_attribute_003 = stylized_meshify_hair.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute_003.name = "Named Attribute.003"
	    named_attribute_003.data_type = 'INT'
	    #Name
	    named_attribute_003.inputs[0].default_value = "closest_idx"
	
	    #node Reroute.001
	    reroute_001_6 = stylized_meshify_hair.nodes.new("NodeReroute")
	    reroute_001_6.name = "Reroute.001"
	    reroute_001_6.socket_idname = "NodeSocketGeometry"
	    #node Reroute.002
	    reroute_002_2 = stylized_meshify_hair.nodes.new("NodeReroute")
	    reroute_002_2.name = "Reroute.002"
	    reroute_002_2.socket_idname = "NodeSocketGeometry"
	    #node Set Material
	    set_material_1 = stylized_meshify_hair.nodes.new("GeometryNodeSetMaterial")
	    set_material_1.name = "Set Material"
	    set_material_1.inputs[1].hide = True
	    #Selection
	    set_material_1.inputs[1].default_value = True
	
	    #node Group Input.008
	    group_input_008_1 = stylized_meshify_hair.nodes.new("NodeGroupInput")
	    group_input_008_1.name = "Group Input.008"
	    group_input_008_1.outputs[0].hide = True
	    group_input_008_1.outputs[1].hide = True
	    group_input_008_1.outputs[3].hide = True
	    group_input_008_1.outputs[4].hide = True
	    group_input_008_1.outputs[5].hide = True
	    group_input_008_1.outputs[6].hide = True
	    group_input_008_1.outputs[7].hide = True
	    group_input_008_1.outputs[8].hide = True
	    group_input_008_1.outputs[9].hide = True
	    group_input_008_1.outputs[10].hide = True
	    group_input_008_1.outputs[11].hide = True
	    group_input_008_1.outputs[12].hide = True
	    group_input_008_1.outputs[13].hide = True
	    group_input_008_1.outputs[14].hide = True
	
	    #node Group Input.010
	    group_input_010 = stylized_meshify_hair.nodes.new("NodeGroupInput")
	    group_input_010.name = "Group Input.010"
	    group_input_010.outputs[0].hide = True
	    group_input_010.outputs[1].hide = True
	    group_input_010.outputs[2].hide = True
	    group_input_010.outputs[3].hide = True
	    group_input_010.outputs[14].hide = True
	
	    #node Group Input.005
	    group_input_005_4 = stylized_meshify_hair.nodes.new("NodeGroupInput")
	    group_input_005_4.name = "Group Input.005"
	    group_input_005_4.outputs[0].hide = True
	    group_input_005_4.outputs[2].hide = True
	    group_input_005_4.outputs[3].hide = True
	    group_input_005_4.outputs[4].hide = True
	    group_input_005_4.outputs[5].hide = True
	    group_input_005_4.outputs[6].hide = True
	    group_input_005_4.outputs[7].hide = True
	    group_input_005_4.outputs[8].hide = True
	    group_input_005_4.outputs[9].hide = True
	    group_input_005_4.outputs[10].hide = True
	    group_input_005_4.outputs[11].hide = True
	    group_input_005_4.outputs[12].hide = True
	    group_input_005_4.outputs[13].hide = True
	    group_input_005_4.outputs[14].hide = True
	
	    #node Reroute.010
	    reroute_010_2 = stylized_meshify_hair.nodes.new("NodeReroute")
	    reroute_010_2.name = "Reroute.010"
	    reroute_010_2.socket_idname = "NodeSocketGeometry"
	    #node Group.007
	    group_007 = stylized_meshify_hair.nodes.new("GeometryNodeGroup")
	    group_007.name = "Group.007"
	    group_007.node_tree = mesh_magic
	
	    #node Stylized Mesh Bake
	    stylized_mesh_bake = stylized_meshify_hair.nodes.new("GeometryNodeBake")
	    stylized_mesh_bake.label = "Stylized Mesh Bake"
	    stylized_mesh_bake.name = "Stylized Mesh Bake"
	    stylized_mesh_bake.active_index = 0
	    stylized_mesh_bake.bake_items.clear()
	    stylized_mesh_bake.bake_items.new('GEOMETRY', "Geometry")
	    stylized_mesh_bake.bake_items[0].attribute_domain = 'POINT'
	    stylized_mesh_bake.inputs[1].hide = True
	    stylized_mesh_bake.outputs[1].hide = True
	
	    #node Resample Curve.001
	    resample_curve_001 = stylized_meshify_hair.nodes.new("GeometryNodeResampleCurve")
	    resample_curve_001.name = "Resample Curve.001"
	    resample_curve_001.hide = True
	    resample_curve_001.keep_last_segment = True
	    resample_curve_001.mode = 'COUNT'
	    resample_curve_001.inputs[1].hide = True
	    resample_curve_001.inputs[3].hide = True
	    #Selection
	    resample_curve_001.inputs[1].default_value = True
	
	    #node Group Input.001
	    group_input_001_10 = stylized_meshify_hair.nodes.new("NodeGroupInput")
	    group_input_001_10.name = "Group Input.001"
	    group_input_001_10.outputs[0].hide = True
	    group_input_001_10.outputs[1].hide = True
	    group_input_001_10.outputs[2].hide = True
	    group_input_001_10.outputs[4].hide = True
	    group_input_001_10.outputs[5].hide = True
	    group_input_001_10.outputs[6].hide = True
	    group_input_001_10.outputs[7].hide = True
	    group_input_001_10.outputs[8].hide = True
	    group_input_001_10.outputs[9].hide = True
	    group_input_001_10.outputs[10].hide = True
	    group_input_001_10.outputs[11].hide = True
	    group_input_001_10.outputs[12].hide = True
	    group_input_001_10.outputs[13].hide = True
	    group_input_001_10.outputs[14].hide = True
	
	    #node Switch
	    switch_4 = stylized_meshify_hair.nodes.new("GeometryNodeSwitch")
	    switch_4.name = "Switch"
	    switch_4.hide = True
	    switch_4.input_type = 'GEOMETRY'
	
	    #node Compare.001
	    compare_001_3 = stylized_meshify_hair.nodes.new("FunctionNodeCompare")
	    compare_001_3.name = "Compare.001"
	    compare_001_3.hide = True
	    compare_001_3.data_type = 'INT'
	    compare_001_3.mode = 'ELEMENT'
	    compare_001_3.operation = 'GREATER_EQUAL'
	    compare_001_3.inputs[0].hide = True
	    compare_001_3.inputs[1].hide = True
	    compare_001_3.inputs[3].hide = True
	    compare_001_3.inputs[4].hide = True
	    compare_001_3.inputs[5].hide = True
	    compare_001_3.inputs[6].hide = True
	    compare_001_3.inputs[7].hide = True
	    compare_001_3.inputs[8].hide = True
	    compare_001_3.inputs[9].hide = True
	    compare_001_3.inputs[10].hide = True
	    compare_001_3.inputs[11].hide = True
	    compare_001_3.inputs[12].hide = True
	    #B_INT
	    compare_001_3.inputs[3].default_value = 2
	
	
	    #Process zone input Repeat Input
	    repeat_input_1.pair_with_output(repeat_output_1)
	    #Item_2
	    repeat_input_1.inputs[2].default_value = 0
	
	
	
	
	
	    #Set locations
	    group_input_12.location = (-340.0, 0.0)
	    group_output_16.location = (1549.6400146484375, -34.82880401611328)
	    named_attribute_4.location = (237.794921875, -204.86949157714844)
	    compare_5.location = (237.99490356445312, -171.7650146484375)
	    separate_geometry.location = (434.56829833984375, -276.72552490234375)
	    attribute_statistic_001.location = (-71.79378509521484, -31.660974502563477)
	    repeat_input_1.location = (99.01121520996094, -41.19667053222656)
	    repeat_output_1.location = (1002.779296875, -61.759864807128906)
	    join_geometry_001.location = (823.139892578125, -84.95603942871094)
	    math_5.location = (834.5255126953125, -123.60336303710938)
	    math_001_4.location = (-73.19247436523438, -64.9359130859375)
	    named_attribute_003.location = (-71.07884216308594, 117.17273712158203)
	    reroute_001_6.location = (-154.91433715820312, -33.560951232910156)
	    reroute_002_2.location = (-149.08628845214844, -411.6916198730469)
	    set_material_1.location = (1374.4747314453125, -35.82680130004883)
	    group_input_008_1.location = (1367.4078369140625, -138.275390625)
	    group_input_010.location = (433.3647766113281, -466.8764953613281)
	    group_input_005_4.location = (431.66448974609375, -405.8486022949219)
	    reroute_010_2.location = (823.3209228515625, -266.45831298828125)
	    group_007.location = (646.2728881835938, -232.4287109375)
	    stylized_mesh_bake.location = (1187.839111328125, -13.576586723327637)
	    resample_curve_001.location = (-90.34358215332031, -409.5655517578125)
	    group_input_001_10.location = (-86.76141357421875, -258.945556640625)
	    switch_4.location = (-86.4659423828125, -359.3800048828125)
	    compare_001_3.location = (-88.06952667236328, -323.3353271484375)
	
	    #Set dimensions
	    group_input_12.width, group_input_12.height = 140.0, 100.0
	    group_output_16.width, group_output_16.height = 140.0, 100.0
	    named_attribute_4.width, named_attribute_4.height = 140.0, 100.0
	    compare_5.width, compare_5.height = 140.0, 100.0
	    separate_geometry.width, separate_geometry.height = 140.0, 100.0
	    attribute_statistic_001.width, attribute_statistic_001.height = 140.0, 100.0
	    repeat_input_1.width, repeat_input_1.height = 140.0, 100.0
	    repeat_output_1.width, repeat_output_1.height = 140.0, 100.0
	    join_geometry_001.width, join_geometry_001.height = 140.0, 100.0
	    math_5.width, math_5.height = 140.0, 100.0
	    math_001_4.width, math_001_4.height = 140.0, 100.0
	    named_attribute_003.width, named_attribute_003.height = 140.0, 100.0
	    reroute_001_6.width, reroute_001_6.height = 10.0, 100.0
	    reroute_002_2.width, reroute_002_2.height = 10.0, 100.0
	    set_material_1.width, set_material_1.height = 140.0, 100.0
	    group_input_008_1.width, group_input_008_1.height = 140.0, 100.0
	    group_input_010.width, group_input_010.height = 140.0, 100.0
	    group_input_005_4.width, group_input_005_4.height = 140.0, 100.0
	    reroute_010_2.width, reroute_010_2.height = 10.0, 100.0
	    group_007.width, group_007.height = 140.0, 100.0
	    stylized_mesh_bake.width, stylized_mesh_bake.height = 140.0, 100.0
	    resample_curve_001.width, resample_curve_001.height = 140.0, 100.0
	    group_input_001_10.width, group_input_001_10.height = 140.0, 100.0
	    switch_4.width, switch_4.height = 140.0, 100.0
	    compare_001_3.width, compare_001_3.height = 140.0, 100.0
	
	    #initialize stylized_meshify_hair links
	    #named_attribute_4.Attribute -> compare_5.A
	    stylized_meshify_hair.links.new(named_attribute_4.outputs[0], compare_5.inputs[2])
	    #compare_5.Result -> separate_geometry.Selection
	    stylized_meshify_hair.links.new(compare_5.outputs[0], separate_geometry.inputs[1])
	    #join_geometry_001.Geometry -> repeat_output_1.Geometry
	    stylized_meshify_hair.links.new(join_geometry_001.outputs[0], repeat_output_1.inputs[0])
	    #math_5.Value -> repeat_output_1.Index
	    stylized_meshify_hair.links.new(math_5.outputs[0], repeat_output_1.inputs[1])
	    #repeat_input_1.Index -> math_5.Value
	    stylized_meshify_hair.links.new(repeat_input_1.outputs[2], math_5.inputs[0])
	    #reroute_001_6.Output -> attribute_statistic_001.Geometry
	    stylized_meshify_hair.links.new(reroute_001_6.outputs[0], attribute_statistic_001.inputs[0])
	    #math_001_4.Value -> repeat_input_1.Iterations
	    stylized_meshify_hair.links.new(math_001_4.outputs[0], repeat_input_1.inputs[0])
	    #attribute_statistic_001.Max -> math_001_4.Value
	    stylized_meshify_hair.links.new(attribute_statistic_001.outputs[4], math_001_4.inputs[0])
	    #named_attribute_003.Attribute -> attribute_statistic_001.Attribute
	    stylized_meshify_hair.links.new(named_attribute_003.outputs[0], attribute_statistic_001.inputs[2])
	    #repeat_input_1.Index -> compare_5.B
	    stylized_meshify_hair.links.new(repeat_input_1.outputs[2], compare_5.inputs[3])
	    #group_input_12.Geometry -> reroute_001_6.Input
	    stylized_meshify_hair.links.new(group_input_12.outputs[0], reroute_001_6.inputs[0])
	    #reroute_001_6.Output -> reroute_002_2.Input
	    stylized_meshify_hair.links.new(reroute_001_6.outputs[0], reroute_002_2.inputs[0])
	    #set_material_1.Geometry -> group_output_16.Geometry
	    stylized_meshify_hair.links.new(set_material_1.outputs[0], group_output_16.inputs[0])
	    #stylized_mesh_bake.Geometry -> set_material_1.Geometry
	    stylized_meshify_hair.links.new(stylized_mesh_bake.outputs[0], set_material_1.inputs[0])
	    #group_input_008_1.Material -> set_material_1.Material
	    stylized_meshify_hair.links.new(group_input_008_1.outputs[2], set_material_1.inputs[2])
	    #reroute_010_2.Output -> join_geometry_001.Geometry
	    stylized_meshify_hair.links.new(reroute_010_2.outputs[0], join_geometry_001.inputs[0])
	    #group_007.Geometry -> reroute_010_2.Input
	    stylized_meshify_hair.links.new(group_007.outputs[0], reroute_010_2.inputs[0])
	    #group_input_005_4.Surface -> group_007.Surface
	    stylized_meshify_hair.links.new(group_input_005_4.outputs[1], group_007.inputs[1])
	    #separate_geometry.Selection -> group_007.Geometry
	    stylized_meshify_hair.links.new(separate_geometry.outputs[0], group_007.inputs[0])
	    #repeat_output_1.Geometry -> stylized_mesh_bake.Geometry
	    stylized_meshify_hair.links.new(repeat_output_1.outputs[0], stylized_mesh_bake.inputs[0])
	    #reroute_002_2.Output -> resample_curve_001.Curve
	    stylized_meshify_hair.links.new(reroute_002_2.outputs[0], resample_curve_001.inputs[0])
	    #group_input_001_10.Control Points -> resample_curve_001.Count
	    stylized_meshify_hair.links.new(group_input_001_10.outputs[3], resample_curve_001.inputs[2])
	    #group_input_010.Subdivison Level -> group_007.Level
	    stylized_meshify_hair.links.new(group_input_010.outputs[9], group_007.inputs[7])
	    #group_input_010.Radius -> group_007.Radius
	    stylized_meshify_hair.links.new(group_input_010.outputs[4], group_007.inputs[2])
	    #group_input_010.Use Enhancements -> group_007.Use Enhancements
	    stylized_meshify_hair.links.new(group_input_010.outputs[5], group_007.inputs[3])
	    #group_input_010.Maintain Shape Factor -> group_007.Maintain Shape Factor
	    stylized_meshify_hair.links.new(group_input_010.outputs[6], group_007.inputs[4])
	    #group_input_010.Pin at Parameter -> group_007.Pin at Parameter
	    stylized_meshify_hair.links.new(group_input_010.outputs[7], group_007.inputs[5])
	    #group_input_010.Snap to surface -> group_007.Snap to surface
	    stylized_meshify_hair.links.new(group_input_010.outputs[8], group_007.inputs[6])
	    #group_input_010.Edge Crease -> group_007.Edge Crease
	    stylized_meshify_hair.links.new(group_input_010.outputs[10], group_007.inputs[8])
	    #group_input_010.Vertex Crease -> group_007.Vertex Crease
	    stylized_meshify_hair.links.new(group_input_010.outputs[11], group_007.inputs[9])
	    #group_input_010.Limit Surface -> group_007.Limit Surface
	    stylized_meshify_hair.links.new(group_input_010.outputs[12], group_007.inputs[10])
	    #group_input_010.Distance -> group_007.Distance
	    stylized_meshify_hair.links.new(group_input_010.outputs[13], group_007.inputs[11])
	    #group_input_001_10.Control Points -> compare_001_3.A
	    stylized_meshify_hair.links.new(group_input_001_10.outputs[3], compare_001_3.inputs[2])
	    #compare_001_3.Result -> switch_4.Switch
	    stylized_meshify_hair.links.new(compare_001_3.outputs[0], switch_4.inputs[0])
	    #reroute_002_2.Output -> switch_4.False
	    stylized_meshify_hair.links.new(reroute_002_2.outputs[0], switch_4.inputs[1])
	    #resample_curve_001.Curve -> switch_4.True
	    stylized_meshify_hair.links.new(resample_curve_001.outputs[0], switch_4.inputs[2])
	    #switch_4.Output -> separate_geometry.Geometry
	    stylized_meshify_hair.links.new(switch_4.outputs[0], separate_geometry.inputs[0])
	    #repeat_input_1.Geometry -> join_geometry_001.Geometry
	    stylized_meshify_hair.links.new(repeat_input_1.outputs[1], join_geometry_001.inputs[0])
	    return stylized_meshify_hair
	
	stylized_meshify_hair = stylized_meshify_hair_node_group()
	
	#initialize curve_tip node group
	def curve_tip_node_group():
	    curve_tip = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Curve Tip")
	
	    curve_tip.color_tag = 'INPUT'
	    curve_tip.description = "Reads information about each curve's tip point"
	    curve_tip.default_group_node_width = 140
	    
	
	
	    #curve_tip interface
	    #Socket Tip Selection
	    tip_selection_socket = curve_tip.interface.new_socket(name = "Tip Selection", in_out='OUTPUT', socket_type = 'NodeSocketBool')
	    tip_selection_socket.default_value = False
	    tip_selection_socket.attribute_domain = 'POINT'
	    tip_selection_socket.description = "Boolean selection of curve tip points"
	
	    #Socket Tip Position
	    tip_position_socket = curve_tip.interface.new_socket(name = "Tip Position", in_out='OUTPUT', socket_type = 'NodeSocketVector')
	    tip_position_socket.default_value = (0.0, 0.0, 0.0)
	    tip_position_socket.min_value = -3.4028234663852886e+38
	    tip_position_socket.max_value = 3.4028234663852886e+38
	    tip_position_socket.subtype = 'NONE'
	    tip_position_socket.attribute_domain = 'CURVE'
	    tip_position_socket.description = "Position of the tip point of a curve"
	
	    #Socket Tip Direction
	    tip_direction_socket = curve_tip.interface.new_socket(name = "Tip Direction", in_out='OUTPUT', socket_type = 'NodeSocketVector')
	    tip_direction_socket.default_value = (0.0, 0.0, 0.0)
	    tip_direction_socket.min_value = -3.4028234663852886e+38
	    tip_direction_socket.max_value = 3.4028234663852886e+38
	    tip_direction_socket.subtype = 'NONE'
	    tip_direction_socket.attribute_domain = 'CURVE'
	    tip_direction_socket.description = "Direction of the tip segment of a curve"
	
	    #Socket Tip Index
	    tip_index_socket = curve_tip.interface.new_socket(name = "Tip Index", in_out='OUTPUT', socket_type = 'NodeSocketInt')
	    tip_index_socket.default_value = 0
	    tip_index_socket.min_value = -2147483648
	    tip_index_socket.max_value = 2147483647
	    tip_index_socket.subtype = 'NONE'
	    tip_index_socket.attribute_domain = 'CURVE'
	    tip_index_socket.description = "Index of the tip point of a curve"
	
	
	    #initialize curve_tip nodes
	    #node Position.002
	    position_002_7 = curve_tip.nodes.new("GeometryNodeInputPosition")
	    position_002_7.name = "Position.002"
	
	    #node Interpolate Domain
	    interpolate_domain_6 = curve_tip.nodes.new("GeometryNodeFieldOnDomain")
	    interpolate_domain_6.name = "Interpolate Domain"
	    interpolate_domain_6.data_type = 'INT'
	    interpolate_domain_6.domain = 'CURVE'
	
	    #node Interpolate Domain.001
	    interpolate_domain_001_2 = curve_tip.nodes.new("GeometryNodeFieldOnDomain")
	    interpolate_domain_001_2.name = "Interpolate Domain.001"
	    interpolate_domain_001_2.data_type = 'FLOAT_VECTOR'
	    interpolate_domain_001_2.domain = 'CURVE'
	
	    #node Field at Index.003
	    field_at_index_003_2 = curve_tip.nodes.new("GeometryNodeFieldAtIndex")
	    field_at_index_003_2.name = "Field at Index.003"
	    field_at_index_003_2.data_type = 'FLOAT_VECTOR'
	    field_at_index_003_2.domain = 'POINT'
	
	    #node Curve Tangent
	    curve_tangent_3 = curve_tip.nodes.new("GeometryNodeInputTangent")
	    curve_tangent_3.name = "Curve Tangent"
	
	    #node Endpoint Selection
	    endpoint_selection_3 = curve_tip.nodes.new("GeometryNodeCurveEndpointSelection")
	    endpoint_selection_3.name = "Endpoint Selection"
	    #Start Size
	    endpoint_selection_3.inputs[0].default_value = 0
	    #End Size
	    endpoint_selection_3.inputs[1].default_value = 1
	
	    #node Field at Index.004
	    field_at_index_004_2 = curve_tip.nodes.new("GeometryNodeFieldAtIndex")
	    field_at_index_004_2.name = "Field at Index.004"
	    field_at_index_004_2.data_type = 'FLOAT_VECTOR'
	    field_at_index_004_2.domain = 'POINT'
	
	    #node Interpolate Domain.002
	    interpolate_domain_002_4 = curve_tip.nodes.new("GeometryNodeFieldOnDomain")
	    interpolate_domain_002_4.name = "Interpolate Domain.002"
	    interpolate_domain_002_4.data_type = 'FLOAT_VECTOR'
	    interpolate_domain_002_4.domain = 'CURVE'
	
	    #node Group Output
	    group_output_17 = curve_tip.nodes.new("NodeGroupOutput")
	    group_output_17.name = "Group Output"
	    group_output_17.is_active_output = True
	
	    #node Points of Curve
	    points_of_curve_2 = curve_tip.nodes.new("GeometryNodePointsOfCurve")
	    points_of_curve_2.name = "Points of Curve"
	    points_of_curve_2.inputs[0].hide = True
	    points_of_curve_2.inputs[1].hide = True
	    points_of_curve_2.outputs[1].hide = True
	    #Curve Index
	    points_of_curve_2.inputs[0].default_value = 0
	    #Weights
	    points_of_curve_2.inputs[1].default_value = 0.0
	    #Sort Index
	    points_of_curve_2.inputs[2].default_value = -1
	
	
	
	
	
	    #Set locations
	    position_002_7.location = (-628.2557983398438, -70.55813598632812)
	    interpolate_domain_6.location = (-628.2557983398438, 90.18605041503906)
	    interpolate_domain_001_2.location = (-246.4883575439453, 90.18605041503906)
	    field_at_index_003_2.location = (-427.3255615234375, 90.18605041503906)
	    curve_tangent_3.location = (-628.2557983398438, -231.3023223876953)
	    endpoint_selection_3.location = (-246.4883575439453, 210.7441864013672)
	    field_at_index_004_2.location = (-427.3255615234375, -90.65116882324219)
	    interpolate_domain_002_4.location = (-246.4883575439453, -90.65116882324219)
	    group_output_17.location = (75.0, 50.0)
	    points_of_curve_2.location = (-829.18603515625, 50.0)
	
	    #Set dimensions
	    position_002_7.width, position_002_7.height = 140.0, 100.0
	    interpolate_domain_6.width, interpolate_domain_6.height = 140.0, 100.0
	    interpolate_domain_001_2.width, interpolate_domain_001_2.height = 140.0, 100.0
	    field_at_index_003_2.width, field_at_index_003_2.height = 140.0, 100.0
	    curve_tangent_3.width, curve_tangent_3.height = 140.0, 100.0
	    endpoint_selection_3.width, endpoint_selection_3.height = 140.0, 100.0
	    field_at_index_004_2.width, field_at_index_004_2.height = 140.0, 100.0
	    interpolate_domain_002_4.width, interpolate_domain_002_4.height = 140.0, 100.0
	    group_output_17.width, group_output_17.height = 140.0, 100.0
	    points_of_curve_2.width, points_of_curve_2.height = 140.0, 100.0
	
	    #initialize curve_tip links
	    #position_002_7.Position -> field_at_index_003_2.Value
	    curve_tip.links.new(position_002_7.outputs[0], field_at_index_003_2.inputs[1])
	    #interpolate_domain_6.Value -> field_at_index_003_2.Index
	    curve_tip.links.new(interpolate_domain_6.outputs[0], field_at_index_003_2.inputs[0])
	    #points_of_curve_2.Point Index -> interpolate_domain_6.Value
	    curve_tip.links.new(points_of_curve_2.outputs[0], interpolate_domain_6.inputs[0])
	    #interpolate_domain_001_2.Value -> group_output_17.Tip Position
	    curve_tip.links.new(interpolate_domain_001_2.outputs[0], group_output_17.inputs[1])
	    #interpolate_domain_6.Value -> group_output_17.Tip Index
	    curve_tip.links.new(interpolate_domain_6.outputs[0], group_output_17.inputs[3])
	    #endpoint_selection_3.Selection -> group_output_17.Tip Selection
	    curve_tip.links.new(endpoint_selection_3.outputs[0], group_output_17.inputs[0])
	    #field_at_index_003_2.Value -> interpolate_domain_001_2.Value
	    curve_tip.links.new(field_at_index_003_2.outputs[0], interpolate_domain_001_2.inputs[0])
	    #interpolate_domain_002_4.Value -> group_output_17.Tip Direction
	    curve_tip.links.new(interpolate_domain_002_4.outputs[0], group_output_17.inputs[2])
	    #curve_tangent_3.Tangent -> field_at_index_004_2.Value
	    curve_tip.links.new(curve_tangent_3.outputs[0], field_at_index_004_2.inputs[1])
	    #interpolate_domain_6.Value -> field_at_index_004_2.Index
	    curve_tip.links.new(interpolate_domain_6.outputs[0], field_at_index_004_2.inputs[0])
	    #field_at_index_004_2.Value -> interpolate_domain_002_4.Value
	    curve_tip.links.new(field_at_index_004_2.outputs[0], interpolate_domain_002_4.inputs[0])
	    return curve_tip
	
	curve_tip = curve_tip_node_group()
	
	#initialize curve_info node group
	def curve_info_node_group():
	    curve_info = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Curve Info")
	
	    curve_info.color_tag = 'INPUT'
	    curve_info.description = "Reads information about each curve"
	    curve_info.default_group_node_width = 140
	    
	
	
	    #curve_info interface
	    #Socket Curve Index
	    curve_index_socket = curve_info.interface.new_socket(name = "Curve Index", in_out='OUTPUT', socket_type = 'NodeSocketInt')
	    curve_index_socket.default_value = 0
	    curve_index_socket.min_value = -2147483648
	    curve_index_socket.max_value = 2147483647
	    curve_index_socket.subtype = 'NONE'
	    curve_index_socket.attribute_domain = 'CURVE'
	    curve_index_socket.description = "Index of each Curve"
	
	    #Socket Curve ID
	    curve_id_socket = curve_info.interface.new_socket(name = "Curve ID", in_out='OUTPUT', socket_type = 'NodeSocketInt')
	    curve_id_socket.default_value = 0
	    curve_id_socket.min_value = -2147483648
	    curve_id_socket.max_value = 2147483647
	    curve_id_socket.subtype = 'NONE'
	    curve_id_socket.attribute_domain = 'CURVE'
	    curve_id_socket.description = "ID of each curve"
	
	    #Socket Length
	    length_socket = curve_info.interface.new_socket(name = "Length", in_out='OUTPUT', socket_type = 'NodeSocketFloat')
	    length_socket.default_value = 0.0
	    length_socket.min_value = -3.4028234663852886e+38
	    length_socket.max_value = 3.4028234663852886e+38
	    length_socket.subtype = 'NONE'
	    length_socket.attribute_domain = 'CURVE'
	    length_socket.description = "Length of each curve"
	
	    #Socket Direction
	    direction_socket = curve_info.interface.new_socket(name = "Direction", in_out='OUTPUT', socket_type = 'NodeSocketVector')
	    direction_socket.default_value = (0.0, 0.0, 0.0)
	    direction_socket.min_value = -3.4028234663852886e+38
	    direction_socket.max_value = 3.4028234663852886e+38
	    direction_socket.subtype = 'NONE'
	    direction_socket.attribute_domain = 'CURVE'
	    direction_socket.description = "Direction from root to tip of each curve"
	
	    #Socket Random
	    random_socket = curve_info.interface.new_socket(name = "Random", in_out='OUTPUT', socket_type = 'NodeSocketFloat')
	    random_socket.default_value = 0.0
	    random_socket.min_value = -3.4028234663852886e+38
	    random_socket.max_value = 3.4028234663852886e+38
	    random_socket.subtype = 'NONE'
	    random_socket.attribute_domain = 'CURVE'
	    random_socket.description = "Random vector for each curve"
	
	    #Socket Surface UV
	    surface_uv_socket = curve_info.interface.new_socket(name = "Surface UV", in_out='OUTPUT', socket_type = 'NodeSocketVector')
	    surface_uv_socket.default_value = (0.0, 0.0, 0.0)
	    surface_uv_socket.min_value = -3.4028234663852886e+38
	    surface_uv_socket.max_value = 3.4028234663852886e+38
	    surface_uv_socket.subtype = 'NONE'
	    surface_uv_socket.attribute_domain = 'CURVE'
	    surface_uv_socket.description = "Attachment surface UV coordinates of each curve"
	
	
	    #initialize curve_info nodes
	    #node Frame
	    frame_6 = curve_info.nodes.new("NodeFrame")
	    frame_6.label = "ID per Curve"
	    frame_6.name = "Frame"
	    frame_6.label_size = 20
	    frame_6.shrink = True
	
	    #node Group Output
	    group_output_18 = curve_info.nodes.new("NodeGroupOutput")
	    group_output_18.name = "Group Output"
	    group_output_18.is_active_output = True
	
	    #node Named Attribute
	    named_attribute_5 = curve_info.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute_5.name = "Named Attribute"
	    named_attribute_5.data_type = 'FLOAT_VECTOR'
	    #Name
	    named_attribute_5.inputs[0].default_value = "surface_uv_coordinate"
	
	    #node Group.002
	    group_002_2 = curve_info.nodes.new("GeometryNodeGroup")
	    group_002_2.name = "Group.002"
	    group_002_2.node_tree = curve_tip
	    group_002_2.outputs[0].hide = True
	    group_002_2.outputs[2].hide = True
	    group_002_2.outputs[3].hide = True
	
	    #node Group.001
	    group_001_3 = curve_info.nodes.new("GeometryNodeGroup")
	    group_001_3.name = "Group.001"
	    group_001_3.node_tree = curve_root
	    group_001_3.outputs[0].hide = True
	    group_001_3.outputs[2].hide = True
	    group_001_3.outputs[3].hide = True
	
	    #node Evaluate at Index
	    evaluate_at_index_1 = curve_info.nodes.new("GeometryNodeFieldAtIndex")
	    evaluate_at_index_1.name = "Evaluate at Index"
	    evaluate_at_index_1.data_type = 'FLOAT'
	    evaluate_at_index_1.domain = 'POINT'
	
	    #node Evaluate on Domain.001
	    evaluate_on_domain_001 = curve_info.nodes.new("GeometryNodeFieldOnDomain")
	    evaluate_on_domain_001.name = "Evaluate on Domain.001"
	    evaluate_on_domain_001.data_type = 'FLOAT'
	    evaluate_on_domain_001.domain = 'CURVE'
	
	    #node Group.003
	    group_003 = curve_info.nodes.new("GeometryNodeGroup")
	    group_003.name = "Group.003"
	    group_003.node_tree = curve_root
	    group_003.outputs[0].hide = True
	    group_003.outputs[1].hide = True
	    group_003.outputs[2].hide = True
	
	    #node Random Value.002
	    random_value_002 = curve_info.nodes.new("FunctionNodeRandomValue")
	    random_value_002.name = "Random Value.002"
	    random_value_002.data_type = 'FLOAT'
	    #Min_001
	    random_value_002.inputs[2].default_value = 0.0
	    #Max_001
	    random_value_002.inputs[3].default_value = 1.0
	    #Seed
	    random_value_002.inputs[8].default_value = 0
	
	    #node Reroute
	    reroute_7 = curve_info.nodes.new("NodeReroute")
	    reroute_7.name = "Reroute"
	    reroute_7.socket_idname = "NodeSocketInt"
	    #node Vector Math
	    vector_math_5 = curve_info.nodes.new("ShaderNodeVectorMath")
	    vector_math_5.name = "Vector Math"
	    vector_math_5.operation = 'SUBTRACT'
	
	    #node Vector Math.001
	    vector_math_001_2 = curve_info.nodes.new("ShaderNodeVectorMath")
	    vector_math_001_2.name = "Vector Math.001"
	    vector_math_001_2.operation = 'NORMALIZE'
	
	    #node Evaluate on Domain
	    evaluate_on_domain = curve_info.nodes.new("GeometryNodeFieldOnDomain")
	    evaluate_on_domain.name = "Evaluate on Domain"
	    evaluate_on_domain.hide = True
	    evaluate_on_domain.data_type = 'INT'
	    evaluate_on_domain.domain = 'CURVE'
	
	    #node Index.001
	    index_001_5 = curve_info.nodes.new("GeometryNodeInputIndex")
	    index_001_5.name = "Index.001"
	
	    #node Spline Length
	    spline_length = curve_info.nodes.new("GeometryNodeSplineLength")
	    spline_length.name = "Spline Length"
	    spline_length.outputs[1].hide = True
	
	    #node Evaluate at Index.001
	    evaluate_at_index_001_1 = curve_info.nodes.new("GeometryNodeFieldAtIndex")
	    evaluate_at_index_001_1.name = "Evaluate at Index.001"
	    evaluate_at_index_001_1.data_type = 'INT'
	    evaluate_at_index_001_1.domain = 'POINT'
	
	    #node Evaluate on Domain.002
	    evaluate_on_domain_002 = curve_info.nodes.new("GeometryNodeFieldOnDomain")
	    evaluate_on_domain_002.name = "Evaluate on Domain.002"
	    evaluate_on_domain_002.data_type = 'INT'
	    evaluate_on_domain_002.domain = 'CURVE'
	
	    #node Group
	    group_5 = curve_info.nodes.new("GeometryNodeGroup")
	    group_5.name = "Group"
	    group_5.node_tree = curve_root
	    group_5.outputs[0].hide = True
	    group_5.outputs[1].hide = True
	    group_5.outputs[2].hide = True
	
	    #node ID
	    id = curve_info.nodes.new("GeometryNodeInputID")
	    id.name = "ID"
	
	
	
	
	    #Set parents
	    evaluate_at_index_001_1.parent = frame_6
	    evaluate_on_domain_002.parent = frame_6
	    group_5.parent = frame_6
	    id.parent = frame_6
	
	    #Set locations
	    frame_6.location = (-1201.4400634765625, 150.51998901367188)
	    group_output_18.location = (75.0, 50.0)
	    named_attribute_5.location = (-166.11627197265625, -371.9534912109375)
	    group_002_2.location = (-527.7907104492188, -90.65116882324219)
	    group_001_3.location = (-527.7907104492188, -171.02325439453125)
	    evaluate_at_index_1.location = (-346.9534912109375, -211.2093048095703)
	    evaluate_on_domain_001.location = (-166.11627197265625, -211.2093048095703)
	    group_003.location = (-527.7907104492188, -251.39535522460938)
	    random_value_002.location = (-527.7907104492188, -331.7674560546875)
	    reroute_7.location = (-608.162841796875, 29.906982421875)
	    vector_math_5.location = (-346.9534912109375, -70.55814361572266)
	    vector_math_001_2.location = (-166.11627197265625, -70.55814361572266)
	    evaluate_on_domain.location = (-166.11627197265625, 70.093017578125)
	    index_001_5.location = (-346.9534912109375, 110.27906799316406)
	    spline_length.location = (-166.11627197265625, -10.279067993164062)
	    evaluate_at_index_001_1.location = (211.50982666015625, -40.24092102050781)
	    evaluate_on_domain_002.location = (392.3470458984375, -40.24092102050781)
	    group_5.location = (30.672607421875, -60.333953857421875)
	    id.location = (30.672607421875, -140.70603942871094)
	
	    #Set dimensions
	    frame_6.width, frame_6.height = 562.4000244140625, 221.07998657226562
	    group_output_18.width, group_output_18.height = 140.0, 100.0
	    named_attribute_5.width, named_attribute_5.height = 140.0, 100.0
	    group_002_2.width, group_002_2.height = 140.0, 100.0
	    group_001_3.width, group_001_3.height = 140.0, 100.0
	    evaluate_at_index_1.width, evaluate_at_index_1.height = 140.0, 100.0
	    evaluate_on_domain_001.width, evaluate_on_domain_001.height = 140.0, 100.0
	    group_003.width, group_003.height = 140.0, 100.0
	    random_value_002.width, random_value_002.height = 140.0, 100.0
	    reroute_7.width, reroute_7.height = 16.0, 100.0
	    vector_math_5.width, vector_math_5.height = 140.0, 100.0
	    vector_math_001_2.width, vector_math_001_2.height = 140.0, 100.0
	    evaluate_on_domain.width, evaluate_on_domain.height = 140.0, 100.0
	    index_001_5.width, index_001_5.height = 140.0, 100.0
	    spline_length.width, spline_length.height = 140.0, 100.0
	    evaluate_at_index_001_1.width, evaluate_at_index_001_1.height = 140.0, 100.0
	    evaluate_on_domain_002.width, evaluate_on_domain_002.height = 140.0, 100.0
	    group_5.width, group_5.height = 140.0, 100.0
	    id.width, id.height = 140.0, 100.0
	
	    #initialize curve_info links
	    #index_001_5.Index -> evaluate_on_domain.Value
	    curve_info.links.new(index_001_5.outputs[0], evaluate_on_domain.inputs[0])
	    #evaluate_on_domain.Value -> group_output_18.Curve Index
	    curve_info.links.new(evaluate_on_domain.outputs[0], group_output_18.inputs[0])
	    #named_attribute_5.Attribute -> group_output_18.Surface UV
	    curve_info.links.new(named_attribute_5.outputs[0], group_output_18.inputs[5])
	    #evaluate_at_index_001_1.Value -> evaluate_on_domain_002.Value
	    curve_info.links.new(evaluate_at_index_001_1.outputs[0], evaluate_on_domain_002.inputs[0])
	    #group_5.Root Index -> evaluate_at_index_001_1.Index
	    curve_info.links.new(group_5.outputs[3], evaluate_at_index_001_1.inputs[0])
	    #reroute_7.Output -> group_output_18.Curve ID
	    curve_info.links.new(reroute_7.outputs[0], group_output_18.inputs[1])
	    #id.ID -> evaluate_at_index_001_1.Value
	    curve_info.links.new(id.outputs[0], evaluate_at_index_001_1.inputs[1])
	    #spline_length.Length -> group_output_18.Length
	    curve_info.links.new(spline_length.outputs[0], group_output_18.inputs[2])
	    #group_002_2.Tip Position -> vector_math_5.Vector
	    curve_info.links.new(group_002_2.outputs[1], vector_math_5.inputs[0])
	    #group_001_3.Root Position -> vector_math_5.Vector
	    curve_info.links.new(group_001_3.outputs[1], vector_math_5.inputs[1])
	    #vector_math_001_2.Vector -> group_output_18.Direction
	    curve_info.links.new(vector_math_001_2.outputs[0], group_output_18.inputs[3])
	    #vector_math_5.Vector -> vector_math_001_2.Vector
	    curve_info.links.new(vector_math_5.outputs[0], vector_math_001_2.inputs[0])
	    #reroute_7.Output -> random_value_002.ID
	    curve_info.links.new(reroute_7.outputs[0], random_value_002.inputs[7])
	    #evaluate_at_index_1.Value -> evaluate_on_domain_001.Value
	    curve_info.links.new(evaluate_at_index_1.outputs[0], evaluate_on_domain_001.inputs[0])
	    #evaluate_on_domain_001.Value -> group_output_18.Random
	    curve_info.links.new(evaluate_on_domain_001.outputs[0], group_output_18.inputs[4])
	    #random_value_002.Value -> evaluate_at_index_1.Value
	    curve_info.links.new(random_value_002.outputs[1], evaluate_at_index_1.inputs[1])
	    #group_003.Root Index -> evaluate_at_index_1.Index
	    curve_info.links.new(group_003.outputs[3], evaluate_at_index_1.inputs[0])
	    #evaluate_on_domain_002.Value -> reroute_7.Input
	    curve_info.links.new(evaluate_on_domain_002.outputs[0], reroute_7.inputs[0])
	    return curve_info
	
	curve_info = curve_info_node_group()
	
	#initialize duplicate_hair_curves node group
	def duplicate_hair_curves_node_group():
	    duplicate_hair_curves = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Duplicate Hair Curves")
	
	    duplicate_hair_curves.color_tag = 'GEOMETRY'
	    duplicate_hair_curves.description = "Duplicates hair curves a certain number of times within a radius"
	    duplicate_hair_curves.default_group_node_width = 140
	    
	
	    duplicate_hair_curves.is_modifier = True
	
	    #duplicate_hair_curves interface
	    #Socket Geometry
	    geometry_socket_20 = duplicate_hair_curves.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_20.attribute_domain = 'POINT'
	
	    #Socket Guide Index
	    guide_index_socket = duplicate_hair_curves.interface.new_socket(name = "Guide Index", in_out='OUTPUT', socket_type = 'NodeSocketInt')
	    guide_index_socket.default_value = 0
	    guide_index_socket.min_value = -2147483648
	    guide_index_socket.max_value = 2147483647
	    guide_index_socket.subtype = 'NONE'
	    guide_index_socket.attribute_domain = 'CURVE'
	    guide_index_socket.description = "Guide index map that was used for the operation"
	
	    #Socket Geometry
	    geometry_socket_21 = duplicate_hair_curves.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_21.attribute_domain = 'POINT'
	    geometry_socket_21.description = "Input Geometry (May include other than curves)"
	
	    #Socket Amount
	    amount_socket = duplicate_hair_curves.interface.new_socket(name = "Amount", in_out='INPUT', socket_type = 'NodeSocketInt')
	    amount_socket.default_value = 10
	    amount_socket.min_value = 0
	    amount_socket.max_value = 2147483647
	    amount_socket.subtype = 'NONE'
	    amount_socket.attribute_domain = 'POINT'
	    amount_socket.description = "Amount of duplicates per curve"
	
	    #Socket Viewport Amount
	    viewport_amount_socket = duplicate_hair_curves.interface.new_socket(name = "Viewport Amount", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    viewport_amount_socket.default_value = 1.0
	    viewport_amount_socket.min_value = 0.0
	    viewport_amount_socket.max_value = 1.0
	    viewport_amount_socket.subtype = 'FACTOR'
	    viewport_amount_socket.attribute_domain = 'POINT'
	    viewport_amount_socket.description = "Percentage of amount used for the viewport"
	
	    #Socket Radius
	    radius_socket_2 = duplicate_hair_curves.interface.new_socket(name = "Radius", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    radius_socket_2.default_value = 0.10000000149011612
	    radius_socket_2.min_value = 0.0
	    radius_socket_2.max_value = 3.4028234663852886e+38
	    radius_socket_2.subtype = 'DISTANCE'
	    radius_socket_2.attribute_domain = 'POINT'
	    radius_socket_2.description = "Radius in which the duplicate curves are offset from the guides"
	
	    #Socket Distribution Shape
	    distribution_shape_socket = duplicate_hair_curves.interface.new_socket(name = "Distribution Shape", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    distribution_shape_socket.default_value = 0.0
	    distribution_shape_socket.min_value = -10.0
	    distribution_shape_socket.max_value = 10.0
	    distribution_shape_socket.subtype = 'NONE'
	    distribution_shape_socket.attribute_domain = 'POINT'
	    distribution_shape_socket.description = "Shape of distribution from center to the edge around the guide"
	
	    #Socket Tip Roundness
	    tip_roundness_socket = duplicate_hair_curves.interface.new_socket(name = "Tip Roundness", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    tip_roundness_socket.default_value = 0.0
	    tip_roundness_socket.min_value = 0.0
	    tip_roundness_socket.max_value = 1.0
	    tip_roundness_socket.subtype = 'FACTOR'
	    tip_roundness_socket.attribute_domain = 'POINT'
	    tip_roundness_socket.description = "Offset of the curves to round the tip"
	
	    #Socket Even Thickness
	    even_thickness_socket = duplicate_hair_curves.interface.new_socket(name = "Even Thickness", in_out='INPUT', socket_type = 'NodeSocketBool')
	    even_thickness_socket.default_value = False
	    even_thickness_socket.attribute_domain = 'POINT'
	    even_thickness_socket.description = "Keep an even thickness of the distribution of duplicates"
	
	    #Socket Seed
	    seed_socket = duplicate_hair_curves.interface.new_socket(name = "Seed", in_out='INPUT', socket_type = 'NodeSocketInt')
	    seed_socket.default_value = 0
	    seed_socket.min_value = -10000
	    seed_socket.max_value = 10000
	    seed_socket.subtype = 'NONE'
	    seed_socket.attribute_domain = 'POINT'
	    seed_socket.description = "Random Seed for the operation"
	
	
	    #initialize duplicate_hair_curves nodes
	    #node Frame.002
	    frame_002_4 = duplicate_hair_curves.nodes.new("NodeFrame")
	    frame_002_4.label = "Random Disc Position"
	    frame_002_4.name = "Frame.002"
	    frame_002_4.label_size = 20
	    frame_002_4.shrink = True
	
	    #node Frame.001
	    frame_001_4 = duplicate_hair_curves.nodes.new("NodeFrame")
	    frame_001_4.label = "Tangent Space per Point"
	    frame_001_4.name = "Frame.001"
	    frame_001_4.label_size = 20
	    frame_001_4.shrink = True
	
	    #node Frame
	    frame_7 = duplicate_hair_curves.nodes.new("NodeFrame")
	    frame_7.label = "Tangent Space of Root Point"
	    frame_7.name = "Frame"
	    frame_7.label_size = 20
	    frame_7.shrink = True
	
	    #node Frame.004
	    frame_004 = duplicate_hair_curves.nodes.new("NodeFrame")
	    frame_004.label = "Duplicate Curves"
	    frame_004.name = "Frame.004"
	    frame_004.label_size = 20
	    frame_004.shrink = True
	
	    #node Frame.003
	    frame_003_2 = duplicate_hair_curves.nodes.new("NodeFrame")
	    frame_003_2.label = "Random Vector per Curve"
	    frame_003_2.name = "Frame.003"
	    frame_003_2.label_size = 20
	    frame_003_2.shrink = True
	
	    #node Reroute.016
	    reroute_016_2 = duplicate_hair_curves.nodes.new("NodeReroute")
	    reroute_016_2.name = "Reroute.016"
	    reroute_016_2.socket_idname = "NodeSocketGeometry"
	    #node Reroute.017
	    reroute_017_2 = duplicate_hair_curves.nodes.new("NodeReroute")
	    reroute_017_2.name = "Reroute.017"
	    reroute_017_2.socket_idname = "NodeSocketGeometry"
	    #node Reroute.019
	    reroute_019 = duplicate_hair_curves.nodes.new("NodeReroute")
	    reroute_019.name = "Reroute.019"
	    reroute_019.socket_idname = "NodeSocketGeometry"
	    #node Reroute.018
	    reroute_018_2 = duplicate_hair_curves.nodes.new("NodeReroute")
	    reroute_018_2.name = "Reroute.018"
	    reroute_018_2.socket_idname = "NodeSocketGeometry"
	    #node Group Input
	    group_input_13 = duplicate_hair_curves.nodes.new("NodeGroupInput")
	    group_input_13.name = "Group Input"
	    group_input_13.outputs[1].hide = True
	    group_input_13.outputs[2].hide = True
	    group_input_13.outputs[3].hide = True
	    group_input_13.outputs[4].hide = True
	    group_input_13.outputs[5].hide = True
	    group_input_13.outputs[6].hide = True
	    group_input_13.outputs[7].hide = True
	    group_input_13.outputs[8].hide = True
	
	    #node Group Output
	    group_output_19 = duplicate_hair_curves.nodes.new("NodeGroupOutput")
	    group_output_19.name = "Group Output"
	    group_output_19.is_active_output = True
	
	    #node Separate Components
	    separate_components_1 = duplicate_hair_curves.nodes.new("GeometryNodeSeparateComponents")
	    separate_components_1.name = "Separate Components"
	    separate_components_1.hide = True
	
	    #node Math.053
	    math_053 = duplicate_hair_curves.nodes.new("ShaderNodeMath")
	    math_053.name = "Math.053"
	    math_053.hide = True
	    math_053.operation = 'ARCCOSINE'
	    math_053.use_clamp = False
	
	    #node Math.055
	    math_055 = duplicate_hair_curves.nodes.new("ShaderNodeMath")
	    math_055.name = "Math.055"
	    math_055.hide = True
	    math_055.operation = 'DIVIDE'
	    math_055.use_clamp = False
	    #Value_001
	    math_055.inputs[1].default_value = 1.5707963705062866
	
	    #node Math.056
	    math_056 = duplicate_hair_curves.nodes.new("ShaderNodeMath")
	    math_056.name = "Math.056"
	    math_056.hide = True
	    math_056.operation = 'POWER'
	    math_056.use_clamp = False
	    #Value
	    math_056.inputs[0].default_value = 2.0
	
	    #node Group Input.006
	    group_input_006_3 = duplicate_hair_curves.nodes.new("NodeGroupInput")
	    group_input_006_3.name = "Group Input.006"
	    group_input_006_3.outputs[0].hide = True
	    group_input_006_3.outputs[1].hide = True
	    group_input_006_3.outputs[2].hide = True
	    group_input_006_3.outputs[3].hide = True
	    group_input_006_3.outputs[5].hide = True
	    group_input_006_3.outputs[6].hide = True
	    group_input_006_3.outputs[7].hide = True
	    group_input_006_3.outputs[8].hide = True
	
	    #node Separate XYZ.002
	    separate_xyz_002_1 = duplicate_hair_curves.nodes.new("ShaderNodeSeparateXYZ")
	    separate_xyz_002_1.name = "Separate XYZ.002"
	
	    #node Math.054
	    math_054 = duplicate_hair_curves.nodes.new("ShaderNodeMath")
	    math_054.name = "Math.054"
	    math_054.operation = 'POWER'
	    math_054.use_clamp = False
	
	    #node Math.052
	    math_052 = duplicate_hair_curves.nodes.new("ShaderNodeMath")
	    math_052.name = "Math.052"
	    math_052.hide = True
	    math_052.operation = 'MULTIPLY'
	    math_052.use_clamp = False
	    #Value_001
	    math_052.inputs[1].default_value = 6.2831854820251465
	
	    #node Combine XYZ.002
	    combine_xyz_002_1 = duplicate_hair_curves.nodes.new("ShaderNodeCombineXYZ")
	    combine_xyz_002_1.name = "Combine XYZ.002"
	    combine_xyz_002_1.inputs[1].hide = True
	    combine_xyz_002_1.inputs[2].hide = True
	    #Y
	    combine_xyz_002_1.inputs[1].default_value = 0.0
	    #Z
	    combine_xyz_002_1.inputs[2].default_value = 0.0
	
	    #node Math.059
	    math_059 = duplicate_hair_curves.nodes.new("ShaderNodeMath")
	    math_059.name = "Math.059"
	    math_059.hide = True
	    math_059.operation = 'SUBTRACT'
	    math_059.use_clamp = False
	    #Value_001
	    math_059.inputs[1].default_value = 0.5
	
	    #node Math.058
	    math_058 = duplicate_hair_curves.nodes.new("ShaderNodeMath")
	    math_058.name = "Math.058"
	    math_058.hide = True
	    math_058.operation = 'POWER'
	    math_058.use_clamp = False
	    #Value_001
	    math_058.inputs[1].default_value = 2.0
	
	    #node Vector Rotate
	    vector_rotate = duplicate_hair_curves.nodes.new("ShaderNodeVectorRotate")
	    vector_rotate.name = "Vector Rotate"
	    vector_rotate.invert = False
	    vector_rotate.rotation_type = 'Z_AXIS'
	    vector_rotate.inputs[1].hide = True
	    vector_rotate.inputs[2].hide = True
	    vector_rotate.inputs[4].hide = True
	    #Center
	    vector_rotate.inputs[1].default_value = (0.0, 0.0, 0.0)
	
	    #node Math.057
	    math_057 = duplicate_hair_curves.nodes.new("ShaderNodeMath")
	    math_057.name = "Math.057"
	    math_057.operation = 'ADD'
	    math_057.use_clamp = False
	
	    #node Group Input.007
	    group_input_007_1 = duplicate_hair_curves.nodes.new("NodeGroupInput")
	    group_input_007_1.name = "Group Input.007"
	    group_input_007_1.outputs[0].hide = True
	    group_input_007_1.outputs[1].hide = True
	    group_input_007_1.outputs[2].hide = True
	    group_input_007_1.outputs[3].hide = True
	    group_input_007_1.outputs[4].hide = True
	    group_input_007_1.outputs[6].hide = True
	    group_input_007_1.outputs[7].hide = True
	    group_input_007_1.outputs[8].hide = True
	
	    #node Combine XYZ
	    combine_xyz_2 = duplicate_hair_curves.nodes.new("ShaderNodeCombineXYZ")
	    combine_xyz_2.name = "Combine XYZ"
	    combine_xyz_2.inputs[0].hide = True
	    combine_xyz_2.inputs[1].hide = True
	    #X
	    combine_xyz_2.inputs[0].default_value = 0.0
	    #Y
	    combine_xyz_2.inputs[1].default_value = 0.0
	
	    #node Vector Math.014
	    vector_math_014 = duplicate_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_014.name = "Vector Math.014"
	    vector_math_014.operation = 'SCALE'
	
	    #node Vector Math.013
	    vector_math_013 = duplicate_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_013.name = "Vector Math.013"
	    vector_math_013.operation = 'SUBTRACT'
	
	    #node Reroute.001
	    reroute_001_7 = duplicate_hair_curves.nodes.new("NodeReroute")
	    reroute_001_7.name = "Reroute.001"
	    reroute_001_7.socket_idname = "NodeSocketGeometry"
	    #node Reroute.003
	    reroute_003_2 = duplicate_hair_curves.nodes.new("NodeReroute")
	    reroute_003_2.name = "Reroute.003"
	    reroute_003_2.socket_idname = "NodeSocketBool"
	    #node Set Position
	    set_position_2 = duplicate_hair_curves.nodes.new("GeometryNodeSetPosition")
	    set_position_2.name = "Set Position"
	    #Position
	    set_position_2.inputs[2].default_value = (0.0, 0.0, 0.0)
	
	    #node Set Position.001
	    set_position_001_5 = duplicate_hair_curves.nodes.new("GeometryNodeSetPosition")
	    set_position_001_5.name = "Set Position.001"
	    #Position
	    set_position_001_5.inputs[2].default_value = (0.0, 0.0, 0.0)
	
	    #node Normal
	    normal_2 = duplicate_hair_curves.nodes.new("GeometryNodeInputNormal")
	    normal_2.name = "Normal"
	    normal_2.legacy_corner_normals = True
	
	    #node Curve Tangent
	    curve_tangent_4 = duplicate_hair_curves.nodes.new("GeometryNodeInputTangent")
	    curve_tangent_4.name = "Curve Tangent"
	
	    #node Separate XYZ
	    separate_xyz_3 = duplicate_hair_curves.nodes.new("ShaderNodeSeparateXYZ")
	    separate_xyz_3.name = "Separate XYZ"
	
	    #node Vector Math.001
	    vector_math_001_3 = duplicate_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_001_3.name = "Vector Math.001"
	    vector_math_001_3.operation = 'SCALE'
	
	    #node Vector Math.003
	    vector_math_003_1 = duplicate_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_003_1.name = "Vector Math.003"
	    vector_math_003_1.operation = 'ADD'
	
	    #node Vector Math.002
	    vector_math_002_1 = duplicate_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_002_1.name = "Vector Math.002"
	    vector_math_002_1.operation = 'SCALE'
	
	    #node Vector Math.009
	    vector_math_009_2 = duplicate_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_009_2.name = "Vector Math.009"
	    vector_math_009_2.operation = 'ADD'
	
	    #node Vector Math.010
	    vector_math_010 = duplicate_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_010.name = "Vector Math.010"
	    vector_math_010.operation = 'SCALE'
	
	    #node Vector Math
	    vector_math_6 = duplicate_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_6.name = "Vector Math"
	    vector_math_6.operation = 'CROSS_PRODUCT'
	
	    #node Group.001
	    group_001_4 = duplicate_hair_curves.nodes.new("GeometryNodeGroup")
	    group_001_4.name = "Group.001"
	    group_001_4.node_tree = curve_root
	    group_001_4.outputs[0].hide = True
	    group_001_4.outputs[1].hide = True
	    group_001_4.outputs[2].hide = True
	
	    #node Evaluate on Domain.002
	    evaluate_on_domain_002_1 = duplicate_hair_curves.nodes.new("GeometryNodeFieldOnDomain")
	    evaluate_on_domain_002_1.name = "Evaluate on Domain.002"
	    evaluate_on_domain_002_1.data_type = 'FLOAT_VECTOR'
	    evaluate_on_domain_002_1.domain = 'CURVE'
	
	    #node Separate XYZ.001
	    separate_xyz_001_3 = duplicate_hair_curves.nodes.new("ShaderNodeSeparateXYZ")
	    separate_xyz_001_3.name = "Separate XYZ.001"
	
	    #node Vector Math.011
	    vector_math_011 = duplicate_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_011.name = "Vector Math.011"
	    vector_math_011.operation = 'ADD'
	
	    #node Vector Math.005
	    vector_math_005_1 = duplicate_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_005_1.name = "Vector Math.005"
	    vector_math_005_1.operation = 'ADD'
	
	    #node Vector Math.007
	    vector_math_007_2 = duplicate_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_007_2.name = "Vector Math.007"
	    vector_math_007_2.operation = 'SCALE'
	
	    #node Vector Math.008
	    vector_math_008_2 = duplicate_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_008_2.name = "Vector Math.008"
	    vector_math_008_2.operation = 'CROSS_PRODUCT'
	
	    #node Evaluate at Index
	    evaluate_at_index_2 = duplicate_hair_curves.nodes.new("GeometryNodeFieldAtIndex")
	    evaluate_at_index_2.name = "Evaluate at Index"
	    evaluate_at_index_2.data_type = 'FLOAT_VECTOR'
	    evaluate_at_index_2.domain = 'POINT'
	
	    #node Vector Math.012
	    vector_math_012 = duplicate_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_012.name = "Vector Math.012"
	    vector_math_012.operation = 'SCALE'
	
	    #node Vector Math.006
	    vector_math_006_2 = duplicate_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_006_2.name = "Vector Math.006"
	    vector_math_006_2.operation = 'SCALE'
	
	    #node Evaluate on Domain.001
	    evaluate_on_domain_001_1 = duplicate_hair_curves.nodes.new("GeometryNodeFieldOnDomain")
	    evaluate_on_domain_001_1.name = "Evaluate on Domain.001"
	    evaluate_on_domain_001_1.hide = True
	    evaluate_on_domain_001_1.data_type = 'FLOAT_VECTOR'
	    evaluate_on_domain_001_1.domain = 'POINT'
	
	    #node Curve Tangent.001
	    curve_tangent_001 = duplicate_hair_curves.nodes.new("GeometryNodeInputTangent")
	    curve_tangent_001.name = "Curve Tangent.001"
	
	    #node Normal.001
	    normal_001_1 = duplicate_hair_curves.nodes.new("GeometryNodeInputNormal")
	    normal_001_1.name = "Normal.001"
	    normal_001_1.legacy_corner_normals = True
	
	    #node Reroute.014
	    reroute_014_2 = duplicate_hair_curves.nodes.new("NodeReroute")
	    reroute_014_2.name = "Reroute.014"
	    reroute_014_2.socket_idname = "NodeSocketGeometry"
	    #node Reroute.015
	    reroute_015_2 = duplicate_hair_curves.nodes.new("NodeReroute")
	    reroute_015_2.name = "Reroute.015"
	    reroute_015_2.socket_idname = "NodeSocketGeometry"
	    #node Reroute.013
	    reroute_013_3 = duplicate_hair_curves.nodes.new("NodeReroute")
	    reroute_013_3.name = "Reroute.013"
	    reroute_013_3.socket_idname = "NodeSocketGeometry"
	    #node Reroute.012
	    reroute_012_3 = duplicate_hair_curves.nodes.new("NodeReroute")
	    reroute_012_3.name = "Reroute.012"
	    reroute_012_3.socket_idname = "NodeSocketGeometry"
	    #node Is Viewport
	    is_viewport = duplicate_hair_curves.nodes.new("GeometryNodeIsViewport")
	    is_viewport.name = "Is Viewport"
	
	    #node Switch
	    switch_5 = duplicate_hair_curves.nodes.new("GeometryNodeSwitch")
	    switch_5.name = "Switch"
	    switch_5.input_type = 'INT'
	
	    #node ID
	    id_1 = duplicate_hair_curves.nodes.new("GeometryNodeInputID")
	    id_1.name = "ID"
	
	    #node Reroute.004
	    reroute_004_4 = duplicate_hair_curves.nodes.new("NodeReroute")
	    reroute_004_4.name = "Reroute.004"
	    reroute_004_4.socket_idname = "NodeSocketInt"
	    #node Reroute.002
	    reroute_002_3 = duplicate_hair_curves.nodes.new("NodeReroute")
	    reroute_002_3.name = "Reroute.002"
	    reroute_002_3.socket_idname = "NodeSocketGeometry"
	    #node Join Geometry
	    join_geometry_3 = duplicate_hair_curves.nodes.new("GeometryNodeJoinGeometry")
	    join_geometry_3.name = "Join Geometry"
	
	    #node Set ID
	    set_id = duplicate_hair_curves.nodes.new("GeometryNodeSetID")
	    set_id.name = "Set ID"
	    #Selection
	    set_id.inputs[1].default_value = True
	
	    #node Store Named Attribute
	    store_named_attribute_4 = duplicate_hair_curves.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_4.name = "Store Named Attribute"
	    store_named_attribute_4.data_type = 'INT'
	    store_named_attribute_4.domain = 'CURVE'
	    #Selection
	    store_named_attribute_4.inputs[1].default_value = True
	    #Name
	    store_named_attribute_4.inputs[2].default_value = "guide_curve_index"
	
	    #node Math
	    math_6 = duplicate_hair_curves.nodes.new("ShaderNodeMath")
	    math_6.name = "Math"
	    math_6.hide = True
	    math_6.operation = 'MULTIPLY'
	    math_6.use_clamp = False
	
	    #node Group Input.002
	    group_input_002_8 = duplicate_hair_curves.nodes.new("NodeGroupInput")
	    group_input_002_8.name = "Group Input.002"
	    group_input_002_8.outputs[0].hide = True
	    group_input_002_8.outputs[1].hide = True
	    group_input_002_8.outputs[3].hide = True
	    group_input_002_8.outputs[4].hide = True
	    group_input_002_8.outputs[5].hide = True
	    group_input_002_8.outputs[6].hide = True
	    group_input_002_8.outputs[7].hide = True
	    group_input_002_8.outputs[8].hide = True
	
	    #node Group Input.004
	    group_input_004_3 = duplicate_hair_curves.nodes.new("NodeGroupInput")
	    group_input_004_3.name = "Group Input.004"
	    group_input_004_3.outputs[0].hide = True
	    group_input_004_3.outputs[2].hide = True
	    group_input_004_3.outputs[3].hide = True
	    group_input_004_3.outputs[4].hide = True
	    group_input_004_3.outputs[5].hide = True
	    group_input_004_3.outputs[6].hide = True
	    group_input_004_3.outputs[7].hide = True
	    group_input_004_3.outputs[8].hide = True
	
	    #node Capture Attribute.002
	    capture_attribute_002_2 = duplicate_hair_curves.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_002_2.name = "Capture Attribute.002"
	    capture_attribute_002_2.active_index = 0
	    capture_attribute_002_2.capture_items.clear()
	    capture_attribute_002_2.capture_items.new('FLOAT', "Value")
	    capture_attribute_002_2.capture_items["Value"].data_type = 'BOOLEAN'
	    capture_attribute_002_2.domain = 'POINT'
	    #Value
	    capture_attribute_002_2.inputs[1].default_value = True
	
	    #node Vector Math.004
	    vector_math_004_3 = duplicate_hair_curves.nodes.new("ShaderNodeVectorMath")
	    vector_math_004_3.name = "Vector Math.004"
	    vector_math_004_3.operation = 'SCALE'
	
	    #node Group Input.003
	    group_input_003_6 = duplicate_hair_curves.nodes.new("NodeGroupInput")
	    group_input_003_6.name = "Group Input.003"
	    group_input_003_6.outputs[0].hide = True
	    group_input_003_6.outputs[1].hide = True
	    group_input_003_6.outputs[2].hide = True
	    group_input_003_6.outputs[4].hide = True
	    group_input_003_6.outputs[5].hide = True
	    group_input_003_6.outputs[6].hide = True
	    group_input_003_6.outputs[7].hide = True
	    group_input_003_6.outputs[8].hide = True
	
	    #node Random Value.001
	    random_value_001 = duplicate_hair_curves.nodes.new("FunctionNodeRandomValue")
	    random_value_001.name = "Random Value.001"
	    random_value_001.data_type = 'FLOAT_VECTOR'
	    #Min
	    random_value_001.inputs[0].default_value = (0.0, 0.0, 0.0)
	    #Max
	    random_value_001.inputs[1].default_value = (1.0, 1.0, 1.0)
	
	    #node Capture Attribute
	    capture_attribute_1 = duplicate_hair_curves.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_1.name = "Capture Attribute"
	    capture_attribute_1.active_index = 0
	    capture_attribute_1.capture_items.clear()
	    capture_attribute_1.capture_items.new('FLOAT', "Value")
	    capture_attribute_1.capture_items["Value"].data_type = 'INT'
	    capture_attribute_1.domain = 'POINT'
	
	    #node Duplicate Elements
	    duplicate_elements_1 = duplicate_hair_curves.nodes.new("GeometryNodeDuplicateElements")
	    duplicate_elements_1.name = "Duplicate Elements"
	    duplicate_elements_1.domain = 'SPLINE'
	    #Selection
	    duplicate_elements_1.inputs[1].default_value = True
	
	    #node Join Geometry.001
	    join_geometry_001_1 = duplicate_hair_curves.nodes.new("GeometryNodeJoinGeometry")
	    join_geometry_001_1.name = "Join Geometry.001"
	
	    #node Random Value
	    random_value_1 = duplicate_hair_curves.nodes.new("FunctionNodeRandomValue")
	    random_value_1.name = "Random Value"
	    random_value_1.data_type = 'INT'
	    #Min_002
	    random_value_1.inputs[4].default_value = -1073741823
	    #Max_002
	    random_value_1.inputs[5].default_value = 1073741823
	
	    #node Reroute.020
	    reroute_020 = duplicate_hair_curves.nodes.new("NodeReroute")
	    reroute_020.name = "Reroute.020"
	    reroute_020.socket_idname = "NodeSocketGeometry"
	    #node Index
	    index_7 = duplicate_hair_curves.nodes.new("GeometryNodeInputIndex")
	    index_7.name = "Index"
	
	    #node Capture Attribute.001
	    capture_attribute_001_1 = duplicate_hair_curves.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_001_1.name = "Capture Attribute.001"
	    capture_attribute_001_1.active_index = 0
	    capture_attribute_001_1.capture_items.clear()
	    capture_attribute_001_1.capture_items.new('FLOAT', "Value")
	    capture_attribute_001_1.capture_items["Value"].data_type = 'INT'
	    capture_attribute_001_1.domain = 'CURVE'
	
	    #node Switch.001
	    switch_001_6 = duplicate_hair_curves.nodes.new("GeometryNodeSwitch")
	    switch_001_6.name = "Switch.001"
	    switch_001_6.input_type = 'GEOMETRY'
	
	    #node Group
	    group_6 = duplicate_hair_curves.nodes.new("GeometryNodeGroup")
	    group_6.name = "Group"
	    group_6.node_tree = curve_info
	    group_6.outputs[0].hide = True
	    group_6.outputs[2].hide = True
	    group_6.outputs[3].hide = True
	    group_6.outputs[4].hide = True
	    group_6.outputs[5].hide = True
	
	    #node Group Input.001
	    group_input_001_11 = duplicate_hair_curves.nodes.new("NodeGroupInput")
	    group_input_001_11.name = "Group Input.001"
	    group_input_001_11.outputs[0].hide = True
	    group_input_001_11.outputs[1].hide = True
	    group_input_001_11.outputs[2].hide = True
	    group_input_001_11.outputs[3].hide = True
	    group_input_001_11.outputs[4].hide = True
	    group_input_001_11.outputs[5].hide = True
	    group_input_001_11.outputs[6].hide = True
	    group_input_001_11.outputs[8].hide = True
	
	    #node Group Input.005
	    group_input_005_5 = duplicate_hair_curves.nodes.new("NodeGroupInput")
	    group_input_005_5.name = "Group Input.005"
	    group_input_005_5.outputs[0].hide = True
	    group_input_005_5.outputs[1].hide = True
	    group_input_005_5.outputs[2].hide = True
	    group_input_005_5.outputs[3].hide = True
	    group_input_005_5.outputs[4].hide = True
	    group_input_005_5.outputs[5].hide = True
	    group_input_005_5.outputs[7].hide = True
	    group_input_005_5.outputs[8].hide = True
	
	    #node Random Value.004
	    random_value_004 = duplicate_hair_curves.nodes.new("FunctionNodeRandomValue")
	    random_value_004.name = "Random Value.004"
	    random_value_004.data_type = 'INT'
	    #Min_002
	    random_value_004.inputs[4].default_value = -1073741823
	    #Max_002
	    random_value_004.inputs[5].default_value = 1073741823
	    #Seed
	    random_value_004.inputs[8].default_value = 296
	
	
	
	
	    #Set parents
	    math_053.parent = frame_002_4
	    math_055.parent = frame_002_4
	    math_056.parent = frame_002_4
	    group_input_006_3.parent = frame_002_4
	    separate_xyz_002_1.parent = frame_002_4
	    math_054.parent = frame_002_4
	    math_052.parent = frame_002_4
	    combine_xyz_002_1.parent = frame_002_4
	    math_059.parent = frame_002_4
	    math_058.parent = frame_002_4
	    vector_rotate.parent = frame_002_4
	    math_057.parent = frame_002_4
	    group_input_007_1.parent = frame_002_4
	    combine_xyz_2.parent = frame_002_4
	    vector_math_014.parent = frame_002_4
	    vector_math_013.parent = frame_002_4
	    normal_2.parent = frame_001_4
	    curve_tangent_4.parent = frame_001_4
	    separate_xyz_3.parent = frame_001_4
	    vector_math_001_3.parent = frame_001_4
	    vector_math_003_1.parent = frame_001_4
	    vector_math_002_1.parent = frame_001_4
	    vector_math_009_2.parent = frame_001_4
	    vector_math_010.parent = frame_001_4
	    vector_math_6.parent = frame_001_4
	    group_001_4.parent = frame_7
	    evaluate_on_domain_002_1.parent = frame_7
	    separate_xyz_001_3.parent = frame_7
	    vector_math_011.parent = frame_7
	    vector_math_005_1.parent = frame_7
	    vector_math_007_2.parent = frame_7
	    vector_math_008_2.parent = frame_7
	    evaluate_at_index_2.parent = frame_7
	    vector_math_012.parent = frame_7
	    vector_math_006_2.parent = frame_7
	    evaluate_on_domain_001_1.parent = frame_7
	    curve_tangent_001.parent = frame_7
	    normal_001_1.parent = frame_7
	    is_viewport.parent = frame_004
	    switch_5.parent = frame_004
	    id_1.parent = frame_004
	    reroute_004_4.parent = frame_004
	    reroute_002_3.parent = frame_004
	    join_geometry_3.parent = frame_004
	    set_id.parent = frame_004
	    store_named_attribute_4.parent = frame_004
	    math_6.parent = frame_004
	    group_input_002_8.parent = frame_004
	    group_input_004_3.parent = frame_004
	    capture_attribute_002_2.parent = frame_004
	    random_value_001.parent = frame_003_2
	    capture_attribute_1.parent = frame_004
	    duplicate_elements_1.parent = frame_004
	    random_value_1.parent = frame_004
	    group_6.parent = frame_003_2
	    group_input_001_11.parent = frame_003_2
	    random_value_004.parent = frame_003_2
	
	    #Set locations
	    frame_002_4.location = (-4255.2001953125, -612.6799926757812)
	    frame_001_4.location = (-1964.6400146484375, -733.6400146484375)
	    frame_7.location = (-2265.1201171875, -271.8800048828125)
	    frame_004.location = (-2910.239990234375, 227.31997680664062)
	    frame_003_2.location = (-4867.68017578125, -612.6799926757812)
	    reroute_016_2.location = (-431.521728515625, 395.1722106933594)
	    reroute_017_2.location = (-431.521728515625, 354.9861755371094)
	    reroute_019.location = (-431.521728515625, 314.8001403808594)
	    reroute_018_2.location = (-431.521728515625, 274.6141052246094)
	    group_input_13.location = (-3843.1396484375, 29.906982421875)
	    group_output_19.location = (75.0, 50.0)
	    separate_components_1.location = (-3652.255859375, 19.86041259765625)
	    math_053.location = (230.822998046875, -60.69171142578125)
	    math_055.location = (230.822998046875, -100.87774658203125)
	    math_056.location = (190.636962890625, -221.4359130859375)
	    group_input_006_3.location = (29.892578125, -221.4359130859375)
	    separate_xyz_002_1.location = (29.892578125, -60.69171142578125)
	    math_054.location = (411.66015625, -80.78472900390625)
	    math_052.location = (411.66015625, -201.3428955078125)
	    combine_xyz_002_1.location = (592.49755859375, -40.59869384765625)
	    math_059.location = (592.49755859375, -281.7149658203125)
	    math_058.location = (592.49755859375, -241.5289306640625)
	    vector_rotate.location = (773.33447265625, -60.69171142578125)
	    math_057.location = (773.33447265625, -201.3428955078125)
	    group_input_007_1.location = (954.171875, -301.8079833984375)
	    combine_xyz_2.location = (954.171875, -201.3428955078125)
	    vector_math_014.location = (1135.009033203125, -221.4359130859375)
	    vector_math_013.location = (1335.939208984375, -141.06378173828125)
	    reroute_001_7.location = (-839.232666015625, -160.97679138183594)
	    reroute_003_2.location = (-839.232666015625, -281.5349426269531)
	    set_position_2.location = (-738.7674560546875, -241.348876953125)
	    set_position_001_5.location = (-738.7674560546875, -80.60469055175781)
	    normal_2.location = (29.926513671875, -161.1331787109375)
	    curve_tangent_4.location = (29.926513671875, -100.8541259765625)
	    separate_xyz_3.location = (230.8568115234375, -221.41229248046875)
	    vector_math_001_3.location = (411.6939697265625, -40.5750732421875)
	    vector_math_003_1.location = (592.53125, -40.5750732421875)
	    vector_math_002_1.location = (411.6939697265625, -181.22625732421875)
	    vector_math_009_2.location = (793.46142578125, -40.5750732421875)
	    vector_math_010.location = (592.53125, -201.31927490234375)
	    vector_math_6.location = (230.8568115234375, -40.5750732421875)
	    group_001_4.location = (744.0943603515625, -60.23541259765625)
	    evaluate_on_domain_002_1.location = (1105.768798828125, -40.14239501953125)
	    separate_xyz_001_3.location = (201.58251953125, -261.1656494140625)
	    vector_math_011.location = (744.0943603515625, -140.6075439453125)
	    vector_math_005_1.location = (563.257080078125, -140.6075439453125)
	    vector_math_007_2.location = (382.419921875, -120.5145263671875)
	    vector_math_008_2.location = (201.58251953125, -120.5145263671875)
	    evaluate_at_index_2.location = (924.9315185546875, -40.14239501953125)
	    vector_math_012.location = (563.257080078125, -301.3516845703125)
	    vector_math_006_2.location = (382.419921875, -261.1656494140625)
	    evaluate_on_domain_001_1.location = (29.82666015625, -339.91510009765625)
	    curve_tangent_001.location = (29.82666015625, -118.89178466796875)
	    normal_001_1.location = (29.82666015625, -179.1708984375)
	    reroute_014_2.location = (-3230.302490234375, 341.3487854003906)
	    reroute_015_2.location = (-3230.302490234375, 301.1627502441406)
	    reroute_013_3.location = (-3230.302490234375, 260.9767150878906)
	    reroute_012_3.location = (-3230.302490234375, 381.5348815917969)
	    is_viewport.location = (280.9560546875, -275.0502624511719)
	    switch_5.location = (461.793212890625, -234.86422729492188)
	    id_1.location = (29.793212890625, -204.72470092773438)
	    reroute_004_4.location = (1375.686767578125, -240.71444702148438)
	    reroute_002_3.location = (571.9658203125, -100.06326293945312)
	    join_geometry_3.location = (1074.2913818359375, -59.877227783203125)
	    set_id.location = (1275.2216796875, -59.877227783203125)
	    store_named_attribute_4.location = (1476.15185546875, -39.7841796875)
	    math_6.location = (290.66357421875, -381.3656005859375)
	    group_input_002_8.location = (89.733154296875, -381.3656005859375)
	    group_input_004_3.location = (89.733154296875, -321.0865478515625)
	    capture_attribute_002_2.location = (843.528564453125, -130.4752197265625)
	    vector_math_004_3.location = (-2506.95361328125, -703.4884033203125)
	    group_input_003_6.location = (-2687.790771484375, -824.0465698242188)
	    random_value_001.location = (381.1650390625, -40.59869384765625)
	    capture_attribute_1.location = (225.0947265625, -50.538970947265625)
	    duplicate_elements_1.location = (652.337890625, -120.15631103515625)
	    join_geometry_001_1.location = (-130.127197265625, 53.59075927734375)
	    random_value_1.location = (1074.2913818359375, -160.34234619140625)
	    reroute_020.location = (-223.732666015625, -87.405517578125)
	    index_7.location = (-3431.232666015625, -100.69772338867188)
	    capture_attribute_001_1.location = (-3210.20947265625, 60.046478271484375)
	    switch_001_6.location = (-507.69775390625, -50.46514892578125)
	    group_6.location = (210.77294921875, -211.3665771484375)
	    group_input_001_11.location = (29.93603515625, -331.92474365234375)
	    group_input_005_5.location = (-738.7674560546875, -0.23260498046875)
	    random_value_004.location = (210.77294921875, -291.73870849609375)
	
	    #Set dimensions
	    frame_002_4.width, frame_002_4.height = 1506.080078125, 384.280029296875
	    frame_001_4.width, frame_001_4.height = 963.6799926757812, 370.840087890625
	    frame_7.width, frame_7.height = 1275.68017578125, 430.36004638671875
	    frame_004.width, frame_004.height = 1646.239990234375, 463.0
	    frame_003_2.width, frame_003_2.height = 551.84033203125, 464.92010498046875
	    reroute_016_2.width, reroute_016_2.height = 16.0, 100.0
	    reroute_017_2.width, reroute_017_2.height = 16.0, 100.0
	    reroute_019.width, reroute_019.height = 16.0, 100.0
	    reroute_018_2.width, reroute_018_2.height = 16.0, 100.0
	    group_input_13.width, group_input_13.height = 140.0, 100.0
	    group_output_19.width, group_output_19.height = 140.0, 100.0
	    separate_components_1.width, separate_components_1.height = 140.0, 100.0
	    math_053.width, math_053.height = 140.0, 100.0
	    math_055.width, math_055.height = 140.0, 100.0
	    math_056.width, math_056.height = 140.0, 100.0
	    group_input_006_3.width, group_input_006_3.height = 140.0, 100.0
	    separate_xyz_002_1.width, separate_xyz_002_1.height = 140.0, 100.0
	    math_054.width, math_054.height = 140.0, 100.0
	    math_052.width, math_052.height = 140.0, 100.0
	    combine_xyz_002_1.width, combine_xyz_002_1.height = 140.0, 100.0
	    math_059.width, math_059.height = 140.0, 100.0
	    math_058.width, math_058.height = 140.0, 100.0
	    vector_rotate.width, vector_rotate.height = 140.0, 100.0
	    math_057.width, math_057.height = 140.0, 100.0
	    group_input_007_1.width, group_input_007_1.height = 140.0, 100.0
	    combine_xyz_2.width, combine_xyz_2.height = 140.0, 100.0
	    vector_math_014.width, vector_math_014.height = 140.0, 100.0
	    vector_math_013.width, vector_math_013.height = 140.0, 100.0
	    reroute_001_7.width, reroute_001_7.height = 16.0, 100.0
	    reroute_003_2.width, reroute_003_2.height = 16.0, 100.0
	    set_position_2.width, set_position_2.height = 140.0, 100.0
	    set_position_001_5.width, set_position_001_5.height = 140.0, 100.0
	    normal_2.width, normal_2.height = 140.0, 100.0
	    curve_tangent_4.width, curve_tangent_4.height = 140.0, 100.0
	    separate_xyz_3.width, separate_xyz_3.height = 140.0, 100.0
	    vector_math_001_3.width, vector_math_001_3.height = 140.0, 100.0
	    vector_math_003_1.width, vector_math_003_1.height = 140.0, 100.0
	    vector_math_002_1.width, vector_math_002_1.height = 140.0, 100.0
	    vector_math_009_2.width, vector_math_009_2.height = 140.0, 100.0
	    vector_math_010.width, vector_math_010.height = 140.0, 100.0
	    vector_math_6.width, vector_math_6.height = 140.0, 100.0
	    group_001_4.width, group_001_4.height = 140.0, 100.0
	    evaluate_on_domain_002_1.width, evaluate_on_domain_002_1.height = 140.0, 100.0
	    separate_xyz_001_3.width, separate_xyz_001_3.height = 140.0, 100.0
	    vector_math_011.width, vector_math_011.height = 140.0, 100.0
	    vector_math_005_1.width, vector_math_005_1.height = 140.0, 100.0
	    vector_math_007_2.width, vector_math_007_2.height = 140.0, 100.0
	    vector_math_008_2.width, vector_math_008_2.height = 140.0, 100.0
	    evaluate_at_index_2.width, evaluate_at_index_2.height = 140.0, 100.0
	    vector_math_012.width, vector_math_012.height = 140.0, 100.0
	    vector_math_006_2.width, vector_math_006_2.height = 140.0, 100.0
	    evaluate_on_domain_001_1.width, evaluate_on_domain_001_1.height = 140.0, 100.0
	    curve_tangent_001.width, curve_tangent_001.height = 140.0, 100.0
	    normal_001_1.width, normal_001_1.height = 140.0, 100.0
	    reroute_014_2.width, reroute_014_2.height = 16.0, 100.0
	    reroute_015_2.width, reroute_015_2.height = 16.0, 100.0
	    reroute_013_3.width, reroute_013_3.height = 16.0, 100.0
	    reroute_012_3.width, reroute_012_3.height = 16.0, 100.0
	    is_viewport.width, is_viewport.height = 140.0, 100.0
	    switch_5.width, switch_5.height = 140.0, 100.0
	    id_1.width, id_1.height = 140.0, 100.0
	    reroute_004_4.width, reroute_004_4.height = 16.0, 100.0
	    reroute_002_3.width, reroute_002_3.height = 16.0, 100.0
	    join_geometry_3.width, join_geometry_3.height = 140.0, 100.0
	    set_id.width, set_id.height = 140.0, 100.0
	    store_named_attribute_4.width, store_named_attribute_4.height = 140.0, 100.0
	    math_6.width, math_6.height = 140.0, 100.0
	    group_input_002_8.width, group_input_002_8.height = 140.0, 100.0
	    group_input_004_3.width, group_input_004_3.height = 140.0, 100.0
	    capture_attribute_002_2.width, capture_attribute_002_2.height = 140.0, 100.0
	    vector_math_004_3.width, vector_math_004_3.height = 140.0, 100.0
	    group_input_003_6.width, group_input_003_6.height = 140.0, 100.0
	    random_value_001.width, random_value_001.height = 140.0, 100.0
	    capture_attribute_1.width, capture_attribute_1.height = 140.0, 100.0
	    duplicate_elements_1.width, duplicate_elements_1.height = 140.0, 100.0
	    join_geometry_001_1.width, join_geometry_001_1.height = 140.0, 100.0
	    random_value_1.width, random_value_1.height = 140.0, 100.0
	    reroute_020.width, reroute_020.height = 16.0, 100.0
	    index_7.width, index_7.height = 140.0, 100.0
	    capture_attribute_001_1.width, capture_attribute_001_1.height = 140.0, 100.0
	    switch_001_6.width, switch_001_6.height = 140.0, 100.0
	    group_6.width, group_6.height = 140.0, 100.0
	    group_input_001_11.width, group_input_001_11.height = 140.0, 100.0
	    group_input_005_5.width, group_input_005_5.height = 140.0, 100.0
	    random_value_004.width, random_value_004.height = 140.0, 100.0
	
	    #initialize duplicate_hair_curves links
	    #join_geometry_001_1.Geometry -> group_output_19.Geometry
	    duplicate_hair_curves.links.new(join_geometry_001_1.outputs[0], group_output_19.inputs[0])
	    #reroute_002_3.Output -> duplicate_elements_1.Geometry
	    duplicate_hair_curves.links.new(reroute_002_3.outputs[0], duplicate_elements_1.inputs[0])
	    #capture_attribute_001_1.Geometry -> capture_attribute_1.Geometry
	    duplicate_hair_curves.links.new(capture_attribute_001_1.outputs[0], capture_attribute_1.inputs[0])
	    #random_value_1.Value -> set_id.ID
	    duplicate_hair_curves.links.new(random_value_1.outputs[2], set_id.inputs[2])
	    #capture_attribute_1.Value -> random_value_1.ID
	    duplicate_hair_curves.links.new(capture_attribute_1.outputs[1], random_value_1.inputs[7])
	    #duplicate_elements_1.Duplicate Index -> random_value_1.Seed
	    duplicate_hair_curves.links.new(duplicate_elements_1.outputs[1], random_value_1.inputs[8])
	    #random_value_001.Value -> separate_xyz_002_1.Vector
	    duplicate_hair_curves.links.new(random_value_001.outputs[0], separate_xyz_002_1.inputs[0])
	    #math_052.Value -> vector_rotate.Angle
	    duplicate_hair_curves.links.new(math_052.outputs[0], vector_rotate.inputs[3])
	    #combine_xyz_002_1.Vector -> vector_rotate.Vector
	    duplicate_hair_curves.links.new(combine_xyz_002_1.outputs[0], vector_rotate.inputs[0])
	    #separate_xyz_002_1.Y -> math_052.Value
	    duplicate_hair_curves.links.new(separate_xyz_002_1.outputs[1], math_052.inputs[0])
	    #separate_xyz_002_1.X -> math_053.Value
	    duplicate_hair_curves.links.new(separate_xyz_002_1.outputs[0], math_053.inputs[0])
	    #math_054.Value -> combine_xyz_002_1.X
	    duplicate_hair_curves.links.new(math_054.outputs[0], combine_xyz_002_1.inputs[0])
	    #group_6.Curve ID -> random_value_001.ID
	    duplicate_hair_curves.links.new(group_6.outputs[1], random_value_001.inputs[7])
	    #vector_math_004_3.Vector -> separate_xyz_3.Vector
	    duplicate_hair_curves.links.new(vector_math_004_3.outputs[0], separate_xyz_3.inputs[0])
	    #reroute_001_7.Output -> set_position_2.Geometry
	    duplicate_hair_curves.links.new(reroute_001_7.outputs[0], set_position_2.inputs[0])
	    #curve_tangent_4.Tangent -> vector_math_6.Vector
	    duplicate_hair_curves.links.new(curve_tangent_4.outputs[0], vector_math_6.inputs[0])
	    #normal_2.Normal -> vector_math_6.Vector
	    duplicate_hair_curves.links.new(normal_2.outputs[0], vector_math_6.inputs[1])
	    #vector_math_6.Vector -> vector_math_001_3.Vector
	    duplicate_hair_curves.links.new(vector_math_6.outputs[0], vector_math_001_3.inputs[0])
	    #vector_math_001_3.Vector -> vector_math_003_1.Vector
	    duplicate_hair_curves.links.new(vector_math_001_3.outputs[0], vector_math_003_1.inputs[0])
	    #vector_math_002_1.Vector -> vector_math_003_1.Vector
	    duplicate_hair_curves.links.new(vector_math_002_1.outputs[0], vector_math_003_1.inputs[1])
	    #separate_xyz_3.X -> vector_math_001_3.Scale
	    duplicate_hair_curves.links.new(separate_xyz_3.outputs[0], vector_math_001_3.inputs[3])
	    #separate_xyz_3.Y -> vector_math_002_1.Scale
	    duplicate_hair_curves.links.new(separate_xyz_3.outputs[1], vector_math_002_1.inputs[3])
	    #normal_2.Normal -> vector_math_002_1.Vector
	    duplicate_hair_curves.links.new(normal_2.outputs[0], vector_math_002_1.inputs[0])
	    #index_7.Index -> capture_attribute_001_1.Value
	    duplicate_hair_curves.links.new(index_7.outputs[0], capture_attribute_001_1.inputs[1])
	    #set_id.Geometry -> store_named_attribute_4.Geometry
	    duplicate_hair_curves.links.new(set_id.outputs[0], store_named_attribute_4.inputs[0])
	    #capture_attribute_002_2.Geometry -> join_geometry_3.Geometry
	    duplicate_hair_curves.links.new(capture_attribute_002_2.outputs[0], join_geometry_3.inputs[0])
	    #reroute_004_4.Output -> store_named_attribute_4.Value
	    duplicate_hair_curves.links.new(reroute_004_4.outputs[0], store_named_attribute_4.inputs[3])
	    #group_input_004_3.Amount -> switch_5.False
	    duplicate_hair_curves.links.new(group_input_004_3.outputs[1], switch_5.inputs[1])
	    #switch_5.Output -> duplicate_elements_1.Amount
	    duplicate_hair_curves.links.new(switch_5.outputs[0], duplicate_elements_1.inputs[2])
	    #is_viewport.Is Viewport -> switch_5.Switch
	    duplicate_hair_curves.links.new(is_viewport.outputs[0], switch_5.inputs[0])
	    #group_input_004_3.Amount -> math_6.Value
	    duplicate_hair_curves.links.new(group_input_004_3.outputs[1], math_6.inputs[0])
	    #math_6.Value -> switch_5.True
	    duplicate_hair_curves.links.new(math_6.outputs[0], switch_5.inputs[2])
	    #group_input_002_8.Viewport Amount -> math_6.Value
	    duplicate_hair_curves.links.new(group_input_002_8.outputs[2], math_6.inputs[1])
	    #id_1.ID -> capture_attribute_1.Value
	    duplicate_hair_curves.links.new(id_1.outputs[0], capture_attribute_1.inputs[1])
	    #vector_math_009_2.Vector -> set_position_2.Offset
	    duplicate_hair_curves.links.new(vector_math_009_2.outputs[0], set_position_2.inputs[3])
	    #group_input_005_5.Even Thickness -> switch_001_6.Switch
	    duplicate_hair_curves.links.new(group_input_005_5.outputs[6], switch_001_6.inputs[0])
	    #vector_math_007_2.Vector -> vector_math_005_1.Vector
	    duplicate_hair_curves.links.new(vector_math_007_2.outputs[0], vector_math_005_1.inputs[0])
	    #vector_math_006_2.Vector -> vector_math_005_1.Vector
	    duplicate_hair_curves.links.new(vector_math_006_2.outputs[0], vector_math_005_1.inputs[1])
	    #separate_xyz_001_3.X -> vector_math_007_2.Scale
	    duplicate_hair_curves.links.new(separate_xyz_001_3.outputs[0], vector_math_007_2.inputs[3])
	    #separate_xyz_001_3.Y -> vector_math_006_2.Scale
	    duplicate_hair_curves.links.new(separate_xyz_001_3.outputs[1], vector_math_006_2.inputs[3])
	    #evaluate_on_domain_002_1.Value -> set_position_001_5.Offset
	    duplicate_hair_curves.links.new(evaluate_on_domain_002_1.outputs[0], set_position_001_5.inputs[3])
	    #curve_tangent_001.Tangent -> vector_math_008_2.Vector
	    duplicate_hair_curves.links.new(curve_tangent_001.outputs[0], vector_math_008_2.inputs[0])
	    #normal_001_1.Normal -> vector_math_008_2.Vector
	    duplicate_hair_curves.links.new(normal_001_1.outputs[0], vector_math_008_2.inputs[1])
	    #evaluate_at_index_2.Value -> evaluate_on_domain_002_1.Value
	    duplicate_hair_curves.links.new(evaluate_at_index_2.outputs[0], evaluate_on_domain_002_1.inputs[0])
	    #vector_math_008_2.Vector -> vector_math_007_2.Vector
	    duplicate_hair_curves.links.new(vector_math_008_2.outputs[0], vector_math_007_2.inputs[0])
	    #normal_001_1.Normal -> vector_math_006_2.Vector
	    duplicate_hair_curves.links.new(normal_001_1.outputs[0], vector_math_006_2.inputs[0])
	    #evaluate_on_domain_001_1.Value -> separate_xyz_001_3.Vector
	    duplicate_hair_curves.links.new(evaluate_on_domain_001_1.outputs[0], separate_xyz_001_3.inputs[0])
	    #store_named_attribute_4.Geometry -> reroute_001_7.Input
	    duplicate_hair_curves.links.new(store_named_attribute_4.outputs[0], reroute_001_7.inputs[0])
	    #reroute_001_7.Output -> set_position_001_5.Geometry
	    duplicate_hair_curves.links.new(reroute_001_7.outputs[0], set_position_001_5.inputs[0])
	    #vector_math_011.Vector -> evaluate_at_index_2.Value
	    duplicate_hair_curves.links.new(vector_math_011.outputs[0], evaluate_at_index_2.inputs[1])
	    #group_001_4.Root Index -> evaluate_at_index_2.Index
	    duplicate_hair_curves.links.new(group_001_4.outputs[3], evaluate_at_index_2.inputs[0])
	    #capture_attribute_1.Geometry -> reroute_002_3.Input
	    duplicate_hair_curves.links.new(capture_attribute_1.outputs[0], reroute_002_3.inputs[0])
	    #math_055.Value -> math_054.Value
	    duplicate_hair_curves.links.new(math_055.outputs[0], math_054.inputs[0])
	    #math_053.Value -> math_055.Value
	    duplicate_hair_curves.links.new(math_053.outputs[0], math_055.inputs[0])
	    #math_056.Value -> math_054.Value
	    duplicate_hair_curves.links.new(math_056.outputs[0], math_054.inputs[1])
	    #group_input_006_3.Distribution Shape -> math_056.Value
	    duplicate_hair_curves.links.new(group_input_006_3.outputs[4], math_056.inputs[1])
	    #vector_math_003_1.Vector -> vector_math_009_2.Vector
	    duplicate_hair_curves.links.new(vector_math_003_1.outputs[0], vector_math_009_2.inputs[0])
	    #separate_xyz_3.Z -> vector_math_010.Scale
	    duplicate_hair_curves.links.new(separate_xyz_3.outputs[2], vector_math_010.inputs[3])
	    #curve_tangent_4.Tangent -> vector_math_010.Vector
	    duplicate_hair_curves.links.new(curve_tangent_4.outputs[0], vector_math_010.inputs[0])
	    #vector_math_010.Vector -> vector_math_009_2.Vector
	    duplicate_hair_curves.links.new(vector_math_010.outputs[0], vector_math_009_2.inputs[1])
	    #vector_math_005_1.Vector -> vector_math_011.Vector
	    duplicate_hair_curves.links.new(vector_math_005_1.outputs[0], vector_math_011.inputs[0])
	    #vector_math_012.Vector -> vector_math_011.Vector
	    duplicate_hair_curves.links.new(vector_math_012.outputs[0], vector_math_011.inputs[1])
	    #separate_xyz_001_3.Z -> vector_math_012.Scale
	    duplicate_hair_curves.links.new(separate_xyz_001_3.outputs[2], vector_math_012.inputs[3])
	    #curve_tangent_001.Tangent -> vector_math_012.Vector
	    duplicate_hair_curves.links.new(curve_tangent_001.outputs[0], vector_math_012.inputs[0])
	    #vector_rotate.Vector -> vector_math_013.Vector
	    duplicate_hair_curves.links.new(vector_rotate.outputs[0], vector_math_013.inputs[0])
	    #vector_math_014.Vector -> vector_math_013.Vector
	    duplicate_hair_curves.links.new(vector_math_014.outputs[0], vector_math_013.inputs[1])
	    #math_057.Value -> combine_xyz_2.Z
	    duplicate_hair_curves.links.new(math_057.outputs[0], combine_xyz_2.inputs[2])
	    #vector_math_013.Vector -> vector_math_004_3.Vector
	    duplicate_hair_curves.links.new(vector_math_013.outputs[0], vector_math_004_3.inputs[0])
	    #group_input_003_6.Radius -> vector_math_004_3.Scale
	    duplicate_hair_curves.links.new(group_input_003_6.outputs[3], vector_math_004_3.inputs[3])
	    #math_058.Value -> math_057.Value
	    duplicate_hair_curves.links.new(math_058.outputs[0], math_057.inputs[0])
	    #math_059.Value -> math_057.Value
	    duplicate_hair_curves.links.new(math_059.outputs[0], math_057.inputs[1])
	    #math_054.Value -> math_058.Value
	    duplicate_hair_curves.links.new(math_054.outputs[0], math_058.inputs[0])
	    #combine_xyz_2.Vector -> vector_math_014.Vector
	    duplicate_hair_curves.links.new(combine_xyz_2.outputs[0], vector_math_014.inputs[0])
	    #group_input_007_1.Tip Roundness -> vector_math_014.Scale
	    duplicate_hair_curves.links.new(group_input_007_1.outputs[5], vector_math_014.inputs[3])
	    #separate_xyz_002_1.Z -> math_059.Value
	    duplicate_hair_curves.links.new(separate_xyz_002_1.outputs[2], math_059.inputs[0])
	    #set_position_001_5.Geometry -> switch_001_6.False
	    duplicate_hair_curves.links.new(set_position_001_5.outputs[0], switch_001_6.inputs[1])
	    #set_position_2.Geometry -> switch_001_6.True
	    duplicate_hair_curves.links.new(set_position_2.outputs[0], switch_001_6.inputs[2])
	    #reroute_003_2.Output -> set_position_2.Selection
	    duplicate_hair_curves.links.new(reroute_003_2.outputs[0], set_position_2.inputs[1])
	    #reroute_003_2.Output -> set_position_001_5.Selection
	    duplicate_hair_curves.links.new(reroute_003_2.outputs[0], set_position_001_5.inputs[1])
	    #capture_attribute_002_2.Value -> reroute_003_2.Input
	    duplicate_hair_curves.links.new(capture_attribute_002_2.outputs[1], reroute_003_2.inputs[0])
	    #capture_attribute_001_1.Value -> reroute_004_4.Input
	    duplicate_hair_curves.links.new(capture_attribute_001_1.outputs[1], reroute_004_4.inputs[0])
	    #join_geometry_3.Geometry -> set_id.Geometry
	    duplicate_hair_curves.links.new(join_geometry_3.outputs[0], set_id.inputs[0])
	    #duplicate_elements_1.Geometry -> capture_attribute_002_2.Geometry
	    duplicate_hair_curves.links.new(duplicate_elements_1.outputs[0], capture_attribute_002_2.inputs[0])
	    #group_input_001_11.Seed -> random_value_004.ID
	    duplicate_hair_curves.links.new(group_input_001_11.outputs[7], random_value_004.inputs[7])
	    #random_value_004.Value -> random_value_001.Seed
	    duplicate_hair_curves.links.new(random_value_004.outputs[2], random_value_001.inputs[8])
	    #vector_math_004_3.Vector -> evaluate_on_domain_001_1.Value
	    duplicate_hair_curves.links.new(vector_math_004_3.outputs[0], evaluate_on_domain_001_1.inputs[0])
	    #reroute_018_2.Output -> join_geometry_001_1.Geometry
	    duplicate_hair_curves.links.new(reroute_018_2.outputs[0], join_geometry_001_1.inputs[0])
	    #separate_components_1.Mesh -> reroute_012_3.Input
	    duplicate_hair_curves.links.new(separate_components_1.outputs[0], reroute_012_3.inputs[0])
	    #separate_components_1.Instances -> reroute_013_3.Input
	    duplicate_hair_curves.links.new(separate_components_1.outputs[5], reroute_013_3.inputs[0])
	    #separate_components_1.Point Cloud -> reroute_014_2.Input
	    duplicate_hair_curves.links.new(separate_components_1.outputs[3], reroute_014_2.inputs[0])
	    #separate_components_1.Volume -> reroute_015_2.Input
	    duplicate_hair_curves.links.new(separate_components_1.outputs[4], reroute_015_2.inputs[0])
	    #reroute_012_3.Output -> reroute_016_2.Input
	    duplicate_hair_curves.links.new(reroute_012_3.outputs[0], reroute_016_2.inputs[0])
	    #reroute_014_2.Output -> reroute_017_2.Input
	    duplicate_hair_curves.links.new(reroute_014_2.outputs[0], reroute_017_2.inputs[0])
	    #reroute_013_3.Output -> reroute_018_2.Input
	    duplicate_hair_curves.links.new(reroute_013_3.outputs[0], reroute_018_2.inputs[0])
	    #reroute_015_2.Output -> reroute_019.Input
	    duplicate_hair_curves.links.new(reroute_015_2.outputs[0], reroute_019.inputs[0])
	    #switch_001_6.Output -> reroute_020.Input
	    duplicate_hair_curves.links.new(switch_001_6.outputs[0], reroute_020.inputs[0])
	    #group_input_13.Geometry -> separate_components_1.Geometry
	    duplicate_hair_curves.links.new(group_input_13.outputs[0], separate_components_1.inputs[0])
	    #separate_components_1.Curve -> capture_attribute_001_1.Geometry
	    duplicate_hair_curves.links.new(separate_components_1.outputs[1], capture_attribute_001_1.inputs[0])
	    #reroute_004_4.Output -> group_output_19.Guide Index
	    duplicate_hair_curves.links.new(reroute_004_4.outputs[0], group_output_19.inputs[1])
	    #reroute_002_3.Output -> join_geometry_3.Geometry
	    duplicate_hair_curves.links.new(reroute_002_3.outputs[0], join_geometry_3.inputs[0])
	    #reroute_019.Output -> join_geometry_001_1.Geometry
	    duplicate_hair_curves.links.new(reroute_019.outputs[0], join_geometry_001_1.inputs[0])
	    #reroute_020.Output -> join_geometry_001_1.Geometry
	    duplicate_hair_curves.links.new(reroute_020.outputs[0], join_geometry_001_1.inputs[0])
	    #reroute_017_2.Output -> join_geometry_001_1.Geometry
	    duplicate_hair_curves.links.new(reroute_017_2.outputs[0], join_geometry_001_1.inputs[0])
	    #reroute_016_2.Output -> join_geometry_001_1.Geometry
	    duplicate_hair_curves.links.new(reroute_016_2.outputs[0], join_geometry_001_1.inputs[0])
	    return duplicate_hair_curves
	
	duplicate_hair_curves = duplicate_hair_curves_node_group()
	
	#initialize attach_hair_curves_to_surface node group
	def attach_hair_curves_to_surface_node_group():
	    attach_hair_curves_to_surface = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Attach Hair Curves to Surface")
	
	    attach_hair_curves_to_surface.color_tag = 'GEOMETRY'
	    attach_hair_curves_to_surface.description = "Attaches hair curves to a surface mesh"
	    attach_hair_curves_to_surface.default_group_node_width = 140
	    
	
	    attach_hair_curves_to_surface.is_modifier = True
	
	    #attach_hair_curves_to_surface interface
	    #Socket Geometry
	    geometry_socket_22 = attach_hair_curves_to_surface.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_22.attribute_domain = 'POINT'
	
	    #Socket Surface UV Coordinate
	    surface_uv_coordinate_socket = attach_hair_curves_to_surface.interface.new_socket(name = "Surface UV Coordinate", in_out='OUTPUT', socket_type = 'NodeSocketVector')
	    surface_uv_coordinate_socket.default_value = (0.0, 0.0, 0.0)
	    surface_uv_coordinate_socket.min_value = -3.4028234663852886e+38
	    surface_uv_coordinate_socket.max_value = 3.4028234663852886e+38
	    surface_uv_coordinate_socket.subtype = 'NONE'
	    surface_uv_coordinate_socket.attribute_domain = 'CURVE'
	    surface_uv_coordinate_socket.description = "Surface UV coordinates at the attachment point"
	
	    #Socket Surface Normal
	    surface_normal_socket = attach_hair_curves_to_surface.interface.new_socket(name = "Surface Normal", in_out='OUTPUT', socket_type = 'NodeSocketVector')
	    surface_normal_socket.default_value = (0.0, 0.0, 0.0)
	    surface_normal_socket.min_value = -3.4028234663852886e+38
	    surface_normal_socket.max_value = 3.4028234663852886e+38
	    surface_normal_socket.subtype = 'NONE'
	    surface_normal_socket.attribute_domain = 'CURVE'
	    surface_normal_socket.description = "Surface normal at the attachment point"
	
	    #Socket Geometry
	    geometry_socket_23 = attach_hair_curves_to_surface.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_23.attribute_domain = 'POINT'
	    geometry_socket_23.description = "Input Geometry (may include other than curves)"
	
	    #Socket Surface
	    surface_socket_3 = attach_hair_curves_to_surface.interface.new_socket(name = "Surface", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    surface_socket_3.attribute_domain = 'POINT'
	    surface_socket_3.description = "Surface geometry to attach hair curves to"
	
	    #Socket Surface
	    surface_socket_4 = attach_hair_curves_to_surface.interface.new_socket(name = "Surface", in_out='INPUT', socket_type = 'NodeSocketObject')
	    surface_socket_4.attribute_domain = 'POINT'
	    surface_socket_4.description = "Surface Object to attach to (needs to have matching transforms)"
	
	    #Socket Surface UV Map
	    surface_uv_map_socket = attach_hair_curves_to_surface.interface.new_socket(name = "Surface UV Map", in_out='INPUT', socket_type = 'NodeSocketVector')
	    surface_uv_map_socket.default_value = (0.0, 0.0, 0.0)
	    surface_uv_map_socket.min_value = -3.4028234663852886e+38
	    surface_uv_map_socket.max_value = 3.4028234663852886e+38
	    surface_uv_map_socket.subtype = 'NONE'
	    surface_uv_map_socket.default_attribute_name = "UVMap"
	    surface_uv_map_socket.attribute_domain = 'POINT'
	    surface_uv_map_socket.hide_value = True
	    surface_uv_map_socket.description = "Surface UV map used for attachment"
	
	    #Socket Surface Rest Position
	    surface_rest_position_socket = attach_hair_curves_to_surface.interface.new_socket(name = "Surface Rest Position", in_out='INPUT', socket_type = 'NodeSocketBool')
	    surface_rest_position_socket.default_value = False
	    surface_rest_position_socket.attribute_domain = 'POINT'
	    surface_rest_position_socket.description = "Set the surface mesh into its rest position before attachment"
	
	    #Socket Sample Attachment UV
	    sample_attachment_uv_socket = attach_hair_curves_to_surface.interface.new_socket(name = "Sample Attachment UV", in_out='INPUT', socket_type = 'NodeSocketBool')
	    sample_attachment_uv_socket.default_value = True
	    sample_attachment_uv_socket.attribute_domain = 'POINT'
	    sample_attachment_uv_socket.description = "Sample the surface UV map at the attachment point"
	
	    #Socket Snap to Surface
	    snap_to_surface_socket_2 = attach_hair_curves_to_surface.interface.new_socket(name = "Snap to Surface", in_out='INPUT', socket_type = 'NodeSocketBool')
	    snap_to_surface_socket_2.default_value = True
	    snap_to_surface_socket_2.attribute_domain = 'POINT'
	    snap_to_surface_socket_2.description = "Snap the root of each curve to the closest surface point"
	
	    #Socket Align to Surface Normal
	    align_to_surface_normal_socket = attach_hair_curves_to_surface.interface.new_socket(name = "Align to Surface Normal", in_out='INPUT', socket_type = 'NodeSocketBool')
	    align_to_surface_normal_socket.default_value = True
	    align_to_surface_normal_socket.attribute_domain = 'POINT'
	    align_to_surface_normal_socket.description = "Align the curve to the surface normal (needs a guide as reference)"
	
	    #Socket Blend along Curve
	    blend_along_curve_socket = attach_hair_curves_to_surface.interface.new_socket(name = "Blend along Curve", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    blend_along_curve_socket.default_value = 0.0
	    blend_along_curve_socket.min_value = 0.0
	    blend_along_curve_socket.max_value = 1.0
	    blend_along_curve_socket.subtype = 'FACTOR'
	    blend_along_curve_socket.attribute_domain = 'POINT'
	    blend_along_curve_socket.description = "Blend deformation along each curve from the root"
	
	
	    #initialize attach_hair_curves_to_surface nodes
	    #node Frame.004
	    frame_004_1 = attach_hair_curves_to_surface.nodes.new("NodeFrame")
	    frame_004_1.label = "Write Data"
	    frame_004_1.name = "Frame.004"
	    frame_004_1.label_size = 20
	    frame_004_1.shrink = True
	
	    #node Frame.005
	    frame_005 = attach_hair_curves_to_surface.nodes.new("NodeFrame")
	    frame_005.label = "Sample Surface"
	    frame_005.name = "Frame.005"
	    frame_005.label_size = 20
	    frame_005.shrink = True
	
	    #node Frame
	    frame_8 = attach_hair_curves_to_surface.nodes.new("NodeFrame")
	    frame_8.label = "Surface Geometry Input"
	    frame_8.name = "Frame"
	    frame_8.label_size = 20
	    frame_8.shrink = True
	
	    #node Frame.006
	    frame_006 = attach_hair_curves_to_surface.nodes.new("NodeFrame")
	    frame_006.label = "Geometry Socket with Priority"
	    frame_006.name = "Frame.006"
	    frame_006.label_size = 20
	    frame_006.shrink = True
	
	    #node Frame.007
	    frame_007 = attach_hair_curves_to_surface.nodes.new("NodeFrame")
	    frame_007.label = "Object in Local Space"
	    frame_007.name = "Frame.007"
	    frame_007.label_size = 20
	    frame_007.shrink = True
	
	    #node Frame.011
	    frame_011 = attach_hair_curves_to_surface.nodes.new("NodeFrame")
	    frame_011.label = "Sample Attachment UV"
	    frame_011.name = "Frame.011"
	    frame_011.label_size = 20
	    frame_011.shrink = True
	
	    #node Frame.001
	    frame_001_5 = attach_hair_curves_to_surface.nodes.new("NodeFrame")
	    frame_001_5.label = "Smooth Normals"
	    frame_001_5.name = "Frame.001"
	    frame_001_5.label_size = 20
	    frame_001_5.shrink = True
	
	    #node Frame.010
	    frame_010 = attach_hair_curves_to_surface.nodes.new("NodeFrame")
	    frame_010.label = "Calculate New Position"
	    frame_010.name = "Frame.010"
	    frame_010.use_custom_color = True
	    frame_010.color = (0.13328450918197632, 0.13328450918197632, 0.13328450918197632)
	    frame_010.label_size = 20
	    frame_010.shrink = True
	
	    #node Frame.003
	    frame_003_3 = attach_hair_curves_to_surface.nodes.new("NodeFrame")
	    frame_003_3.label = "Blend Deformation"
	    frame_003_3.name = "Frame.003"
	    frame_003_3.label_size = 20
	    frame_003_3.shrink = True
	
	    #node Frame.002
	    frame_002_5 = attach_hair_curves_to_surface.nodes.new("NodeFrame")
	    frame_002_5.label = "Align to Normal"
	    frame_002_5.name = "Frame.002"
	    frame_002_5.use_custom_color = True
	    frame_002_5.color = (0.08883915841579437, 0.08883915841579437, 0.08883915841579437)
	    frame_002_5.label_size = 20
	    frame_002_5.shrink = True
	
	    #node Frame.008
	    frame_008 = attach_hair_curves_to_surface.nodes.new("NodeFrame")
	    frame_008.label = "Optimize"
	    frame_008.name = "Frame.008"
	    frame_008.label_size = 20
	    frame_008.shrink = True
	
	    #node Frame.009
	    frame_009 = attach_hair_curves_to_surface.nodes.new("NodeFrame")
	    frame_009.label = "Sample from Guide"
	    frame_009.name = "Frame.009"
	    frame_009.label_size = 20
	    frame_009.shrink = True
	
	    #node Reroute.010
	    reroute_010_3 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_010_3.name = "Reroute.010"
	    reroute_010_3.socket_idname = "NodeSocketGeometry"
	    #node Reroute.013
	    reroute_013_4 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_013_4.name = "Reroute.013"
	    reroute_013_4.socket_idname = "NodeSocketBool"
	    #node Group Output
	    group_output_20 = attach_hair_curves_to_surface.nodes.new("NodeGroupOutput")
	    group_output_20.name = "Group Output"
	    group_output_20.is_active_output = True
	
	    #node Reroute.003
	    reroute_003_3 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_003_3.name = "Reroute.003"
	    reroute_003_3.socket_idname = "NodeSocketVector"
	    #node Switch
	    switch_6 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSwitch")
	    switch_6.name = "Switch"
	    switch_6.input_type = 'GEOMETRY'
	
	    #node Store Named Attribute
	    store_named_attribute_5 = attach_hair_curves_to_surface.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_5.name = "Store Named Attribute"
	    store_named_attribute_5.data_type = 'FLOAT2'
	    store_named_attribute_5.domain = 'CURVE'
	    #Selection
	    store_named_attribute_5.inputs[1].default_value = True
	    #Name
	    store_named_attribute_5.inputs[2].default_value = "surface_uv_coordinate"
	
	    #node Group Input.007
	    group_input_007_2 = attach_hair_curves_to_surface.nodes.new("NodeGroupInput")
	    group_input_007_2.name = "Group Input.007"
	    group_input_007_2.outputs[0].hide = True
	    group_input_007_2.outputs[1].hide = True
	    group_input_007_2.outputs[2].hide = True
	    group_input_007_2.outputs[3].hide = True
	    group_input_007_2.outputs[4].hide = True
	    group_input_007_2.outputs[6].hide = True
	    group_input_007_2.outputs[7].hide = True
	    group_input_007_2.outputs[8].hide = True
	    group_input_007_2.outputs[9].hide = True
	
	    #node Reroute.016
	    reroute_016_3 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_016_3.name = "Reroute.016"
	    reroute_016_3.socket_idname = "NodeSocketGeometry"
	    #node Reroute.005
	    reroute_005_4 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_005_4.name = "Reroute.005"
	    reroute_005_4.socket_idname = "NodeSocketVector"
	    #node Store Named Attribute.001
	    store_named_attribute_001 = attach_hair_curves_to_surface.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_001.name = "Store Named Attribute.001"
	    store_named_attribute_001.data_type = 'FLOAT_VECTOR'
	    store_named_attribute_001.domain = 'CURVE'
	    #Selection
	    store_named_attribute_001.inputs[1].default_value = True
	    #Name
	    store_named_attribute_001.inputs[2].default_value = "surface_normal"
	
	    #node Named Attribute.004
	    named_attribute_004_2 = attach_hair_curves_to_surface.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute_004_2.name = "Named Attribute.004"
	    named_attribute_004_2.data_type = 'FLOAT_VECTOR'
	    #Name
	    named_attribute_004_2.inputs[0].default_value = "surface_normal"
	
	    #node Reroute.012
	    reroute_012_4 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_012_4.name = "Reroute.012"
	    reroute_012_4.socket_idname = "NodeSocketBool"
	    #node Reroute.014
	    reroute_014_3 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_014_3.name = "Reroute.014"
	    reroute_014_3.socket_idname = "NodeSocketBool"
	    #node Reroute.006
	    reroute_006_4 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_006_4.name = "Reroute.006"
	    reroute_006_4.socket_idname = "NodeSocketGeometry"
	    #node Named Attribute.003
	    named_attribute_003_1 = attach_hair_curves_to_surface.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute_003_1.name = "Named Attribute.003"
	    named_attribute_003_1.data_type = 'FLOAT_VECTOR'
	    #Name
	    named_attribute_003_1.inputs[0].default_value = "surface_uv_coordinate"
	
	    #node Switch.008
	    switch_008 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSwitch")
	    switch_008.name = "Switch.008"
	    switch_008.input_type = 'GEOMETRY'
	
	    #node Switch.009
	    switch_009 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSwitch")
	    switch_009.name = "Switch.009"
	    switch_009.input_type = 'VECTOR'
	
	    #node Switch.010
	    switch_010 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSwitch")
	    switch_010.name = "Switch.010"
	    switch_010.input_type = 'VECTOR'
	
	    #node Set Position.001
	    set_position_001_6 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSetPosition")
	    set_position_001_6.name = "Set Position.001"
	    set_position_001_6.inputs[2].hide = True
	    #Position
	    set_position_001_6.inputs[2].default_value = (0.0, 0.0, 0.0)
	
	    #node Reroute.002
	    reroute_002_4 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_002_4.name = "Reroute.002"
	    reroute_002_4.socket_idname = "NodeSocketVector"
	    #node Reroute.018
	    reroute_018_3 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_018_3.name = "Reroute.018"
	    reroute_018_3.socket_idname = "NodeSocketVector"
	    #node Reroute.017
	    reroute_017_3 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_017_3.name = "Reroute.017"
	    reroute_017_3.socket_idname = "NodeSocketGeometry"
	    #node Group Input.009
	    group_input_009_1 = attach_hair_curves_to_surface.nodes.new("NodeGroupInput")
	    group_input_009_1.name = "Group Input.009"
	    group_input_009_1.outputs[0].hide = True
	    group_input_009_1.outputs[1].hide = True
	    group_input_009_1.outputs[2].hide = True
	    group_input_009_1.outputs[4].hide = True
	    group_input_009_1.outputs[5].hide = True
	    group_input_009_1.outputs[6].hide = True
	    group_input_009_1.outputs[7].hide = True
	    group_input_009_1.outputs[8].hide = True
	    group_input_009_1.outputs[9].hide = True
	
	    #node Position
	    position_6 = attach_hair_curves_to_surface.nodes.new("GeometryNodeInputPosition")
	    position_6.name = "Position"
	
	    #node Named Attribute.001
	    named_attribute_001_2 = attach_hair_curves_to_surface.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute_001_2.name = "Named Attribute.001"
	    named_attribute_001_2.data_type = 'FLOAT_VECTOR'
	    #Name
	    named_attribute_001_2.inputs[0].default_value = "surface_uv_coordinate"
	
	    #node Capture Attribute.001
	    capture_attribute_001_2 = attach_hair_curves_to_surface.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_001_2.name = "Capture Attribute.001"
	    capture_attribute_001_2.active_index = 0
	    capture_attribute_001_2.capture_items.clear()
	    capture_attribute_001_2.capture_items.new('FLOAT', "Value")
	    capture_attribute_001_2.capture_items["Value"].data_type = 'FLOAT_VECTOR'
	    capture_attribute_001_2.domain = 'CURVE'
	
	    #node Group Input.004
	    group_input_004_4 = attach_hair_curves_to_surface.nodes.new("NodeGroupInput")
	    group_input_004_4.name = "Group Input.004"
	    group_input_004_4.outputs[0].hide = True
	    group_input_004_4.outputs[2].hide = True
	    group_input_004_4.outputs[3].hide = True
	    group_input_004_4.outputs[4].hide = True
	    group_input_004_4.outputs[5].hide = True
	    group_input_004_4.outputs[6].hide = True
	    group_input_004_4.outputs[7].hide = True
	    group_input_004_4.outputs[8].hide = True
	    group_input_004_4.outputs[9].hide = True
	
	    #node Domain Size.002
	    domain_size_002 = attach_hair_curves_to_surface.nodes.new("GeometryNodeAttributeDomainSize")
	    domain_size_002.name = "Domain Size.002"
	    domain_size_002.component = 'MESH'
	    domain_size_002.outputs[0].hide = True
	    domain_size_002.outputs[1].hide = True
	    domain_size_002.outputs[3].hide = True
	    domain_size_002.outputs[4].hide = True
	    domain_size_002.outputs[5].hide = True
	
	    #node Compare.001
	    compare_001_4 = attach_hair_curves_to_surface.nodes.new("FunctionNodeCompare")
	    compare_001_4.name = "Compare.001"
	    compare_001_4.data_type = 'INT'
	    compare_001_4.mode = 'ELEMENT'
	    compare_001_4.operation = 'NOT_EQUAL'
	    #B_INT
	    compare_001_4.inputs[3].default_value = 0
	
	    #node Object Info.001
	    object_info_001_1 = attach_hair_curves_to_surface.nodes.new("GeometryNodeObjectInfo")
	    object_info_001_1.name = "Object Info.001"
	    object_info_001_1.transform_space = 'ORIGINAL'
	    object_info_001_1.inputs[1].hide = True
	    object_info_001_1.outputs[1].hide = True
	    object_info_001_1.outputs[3].hide = True
	    #As Instance
	    object_info_001_1.inputs[1].default_value = False
	
	    #node Group Input.002
	    group_input_002_9 = attach_hair_curves_to_surface.nodes.new("NodeGroupInput")
	    group_input_002_9.name = "Group Input.002"
	    group_input_002_9.outputs[0].hide = True
	    group_input_002_9.outputs[1].hide = True
	    group_input_002_9.outputs[3].hide = True
	    group_input_002_9.outputs[4].hide = True
	    group_input_002_9.outputs[5].hide = True
	    group_input_002_9.outputs[6].hide = True
	    group_input_002_9.outputs[7].hide = True
	    group_input_002_9.outputs[8].hide = True
	    group_input_002_9.outputs[9].hide = True
	
	    #node Switch.005
	    switch_005_2 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSwitch")
	    switch_005_2.name = "Switch.005"
	    switch_005_2.input_type = 'GEOMETRY'
	
	    #node Domain Size.003
	    domain_size_003 = attach_hair_curves_to_surface.nodes.new("GeometryNodeAttributeDomainSize")
	    domain_size_003.name = "Domain Size.003"
	    domain_size_003.component = 'MESH'
	    domain_size_003.outputs[0].hide = True
	    domain_size_003.outputs[1].hide = True
	    domain_size_003.outputs[3].hide = True
	    domain_size_003.outputs[4].hide = True
	    domain_size_003.outputs[5].hide = True
	
	    #node Compare.002
	    compare_002_5 = attach_hair_curves_to_surface.nodes.new("FunctionNodeCompare")
	    compare_002_5.name = "Compare.002"
	    compare_002_5.data_type = 'INT'
	    compare_002_5.mode = 'ELEMENT'
	    compare_002_5.operation = 'EQUAL'
	    #B_INT
	    compare_002_5.inputs[3].default_value = 0
	
	    #node Named Attribute
	    named_attribute_6 = attach_hair_curves_to_surface.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute_6.name = "Named Attribute"
	    named_attribute_6.data_type = 'FLOAT_VECTOR'
	    #Name
	    named_attribute_6.inputs[0].default_value = "rest_position"
	
	    #node Reroute
	    reroute_8 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_8.name = "Reroute"
	    reroute_8.socket_idname = "NodeSocketGeometry"
	    #node Group Input.005
	    group_input_005_6 = attach_hair_curves_to_surface.nodes.new("NodeGroupInput")
	    group_input_005_6.name = "Group Input.005"
	    group_input_005_6.outputs[0].hide = True
	    group_input_005_6.outputs[1].hide = True
	    group_input_005_6.outputs[2].hide = True
	    group_input_005_6.outputs[3].hide = True
	    group_input_005_6.outputs[5].hide = True
	    group_input_005_6.outputs[6].hide = True
	    group_input_005_6.outputs[7].hide = True
	    group_input_005_6.outputs[8].hide = True
	    group_input_005_6.outputs[9].hide = True
	
	    #node Set Position
	    set_position_3 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSetPosition")
	    set_position_3.name = "Set Position"
	    set_position_3.inputs[3].hide = True
	    #Offset
	    set_position_3.inputs[3].default_value = (0.0, 0.0, 0.0)
	
	    #node Switch.007
	    switch_007 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSwitch")
	    switch_007.name = "Switch.007"
	    switch_007.input_type = 'GEOMETRY'
	
	    #node Reroute.015
	    reroute_015_3 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_015_3.name = "Reroute.015"
	    reroute_015_3.socket_idname = "NodeSocketBool"
	    #node Reroute.011
	    reroute_011_3 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_011_3.name = "Reroute.011"
	    reroute_011_3.socket_idname = "NodeSocketGeometry"
	    #node Group Input
	    group_input_14 = attach_hair_curves_to_surface.nodes.new("NodeGroupInput")
	    group_input_14.name = "Group Input"
	    group_input_14.outputs[1].hide = True
	    group_input_14.outputs[2].hide = True
	    group_input_14.outputs[3].hide = True
	    group_input_14.outputs[4].hide = True
	    group_input_14.outputs[5].hide = True
	    group_input_14.outputs[6].hide = True
	    group_input_14.outputs[7].hide = True
	    group_input_14.outputs[8].hide = True
	    group_input_14.outputs[9].hide = True
	
	    #node Capture Attribute.002
	    capture_attribute_002_3 = attach_hair_curves_to_surface.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_002_3.name = "Capture Attribute.002"
	    capture_attribute_002_3.active_index = 0
	    capture_attribute_002_3.capture_items.clear()
	    capture_attribute_002_3.capture_items.new('FLOAT', "Value")
	    capture_attribute_002_3.capture_items["Value"].data_type = 'FLOAT_VECTOR'
	    capture_attribute_002_3.domain = 'CURVE'
	
	    #node Reroute.001
	    reroute_001_8 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_001_8.name = "Reroute.001"
	    reroute_001_8.socket_idname = "NodeSocketGeometry"
	    #node Sample Nearest Surface
	    sample_nearest_surface = attach_hair_curves_to_surface.nodes.new("GeometryNodeSampleNearestSurface")
	    sample_nearest_surface.name = "Sample Nearest Surface"
	    sample_nearest_surface.data_type = 'FLOAT_VECTOR'
	    #Group ID
	    sample_nearest_surface.inputs[2].default_value = 0
	    #Sample Group ID
	    sample_nearest_surface.inputs[4].default_value = 0
	
	    #node Group
	    group_7 = attach_hair_curves_to_surface.nodes.new("GeometryNodeGroup")
	    group_7.name = "Group"
	    group_7.node_tree = curve_root
	    group_7.outputs[0].hide = True
	    group_7.outputs[2].hide = True
	    group_7.outputs[3].hide = True
	
	    #node Group Input.001
	    group_input_001_12 = attach_hair_curves_to_surface.nodes.new("NodeGroupInput")
	    group_input_001_12.name = "Group Input.001"
	    group_input_001_12.outputs[0].hide = True
	    group_input_001_12.outputs[1].hide = True
	    group_input_001_12.outputs[2].hide = True
	    group_input_001_12.outputs[4].hide = True
	    group_input_001_12.outputs[5].hide = True
	    group_input_001_12.outputs[6].hide = True
	    group_input_001_12.outputs[7].hide = True
	    group_input_001_12.outputs[8].hide = True
	    group_input_001_12.outputs[9].hide = True
	
	    #node Reroute.020
	    reroute_020_1 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_020_1.name = "Reroute.020"
	    reroute_020_1.socket_idname = "NodeSocketGeometry"
	    #node Normal
	    normal_3 = attach_hair_curves_to_surface.nodes.new("GeometryNodeInputNormal")
	    normal_3.name = "Normal"
	    normal_3.legacy_corner_normals = True
	
	    #node Capture Attribute
	    capture_attribute_2 = attach_hair_curves_to_surface.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_2.name = "Capture Attribute"
	    capture_attribute_2.hide = True
	    capture_attribute_2.active_index = 0
	    capture_attribute_2.capture_items.clear()
	    capture_attribute_2.capture_items.new('FLOAT', "Value")
	    capture_attribute_2.capture_items["Value"].data_type = 'FLOAT_VECTOR'
	    capture_attribute_2.domain = 'POINT'
	
	    #node Sample UV Surface
	    sample_uv_surface = attach_hair_curves_to_surface.nodes.new("GeometryNodeSampleUVSurface")
	    sample_uv_surface.name = "Sample UV Surface"
	    sample_uv_surface.hide = True
	    sample_uv_surface.data_type = 'FLOAT_VECTOR'
	    sample_uv_surface.outputs[1].hide = True
	
	    #node Sample UV Surface.003
	    sample_uv_surface_003 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSampleUVSurface")
	    sample_uv_surface_003.name = "Sample UV Surface.003"
	    sample_uv_surface_003.hide = True
	    sample_uv_surface_003.data_type = 'FLOAT_VECTOR'
	    sample_uv_surface_003.outputs[1].hide = True
	
	    #node Reroute.004
	    reroute_004_5 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_004_5.name = "Reroute.004"
	    reroute_004_5.socket_idname = "NodeSocketVector"
	    #node Sample UV Surface.001
	    sample_uv_surface_001 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSampleUVSurface")
	    sample_uv_surface_001.name = "Sample UV Surface.001"
	    sample_uv_surface_001.hide = True
	    sample_uv_surface_001.data_type = 'FLOAT_VECTOR'
	    sample_uv_surface_001.outputs[1].hide = True
	
	    #node Group.001
	    group_001_5 = attach_hair_curves_to_surface.nodes.new("GeometryNodeGroup")
	    group_001_5.name = "Group.001"
	    group_001_5.node_tree = curve_root
	    group_001_5.outputs[0].hide = True
	    group_001_5.outputs[2].hide = True
	    group_001_5.outputs[3].hide = True
	
	    #node Position.001
	    position_001_3 = attach_hair_curves_to_surface.nodes.new("GeometryNodeInputPosition")
	    position_001_3.name = "Position.001"
	
	    #node Vector Math
	    vector_math_7 = attach_hair_curves_to_surface.nodes.new("ShaderNodeVectorMath")
	    vector_math_7.name = "Vector Math"
	    vector_math_7.operation = 'SUBTRACT'
	
	    #node Vector Math.001
	    vector_math_001_4 = attach_hair_curves_to_surface.nodes.new("ShaderNodeVectorMath")
	    vector_math_001_4.name = "Vector Math.001"
	    vector_math_001_4.operation = 'SUBTRACT'
	
	    #node Vector Math.004
	    vector_math_004_4 = attach_hair_curves_to_surface.nodes.new("ShaderNodeVectorMath")
	    vector_math_004_4.name = "Vector Math.004"
	    vector_math_004_4.operation = 'SUBTRACT'
	
	    #node Vector Math.003
	    vector_math_003_2 = attach_hair_curves_to_surface.nodes.new("ShaderNodeVectorMath")
	    vector_math_003_2.name = "Vector Math.003"
	    vector_math_003_2.operation = 'SUBTRACT'
	
	    #node Group Input.003
	    group_input_003_7 = attach_hair_curves_to_surface.nodes.new("NodeGroupInput")
	    group_input_003_7.name = "Group Input.003"
	    group_input_003_7.outputs[0].hide = True
	    group_input_003_7.outputs[1].hide = True
	    group_input_003_7.outputs[2].hide = True
	    group_input_003_7.outputs[3].hide = True
	    group_input_003_7.outputs[4].hide = True
	    group_input_003_7.outputs[5].hide = True
	    group_input_003_7.outputs[6].hide = True
	    group_input_003_7.outputs[8].hide = True
	    group_input_003_7.outputs[9].hide = True
	
	    #node Group Input.006
	    group_input_006_4 = attach_hair_curves_to_surface.nodes.new("NodeGroupInput")
	    group_input_006_4.name = "Group Input.006"
	    group_input_006_4.outputs[0].hide = True
	    group_input_006_4.outputs[1].hide = True
	    group_input_006_4.outputs[2].hide = True
	    group_input_006_4.outputs[3].hide = True
	    group_input_006_4.outputs[4].hide = True
	    group_input_006_4.outputs[5].hide = True
	    group_input_006_4.outputs[7].hide = True
	    group_input_006_4.outputs[8].hide = True
	    group_input_006_4.outputs[9].hide = True
	
	    #node Switch.003
	    switch_003_4 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSwitch")
	    switch_003_4.name = "Switch.003"
	    switch_003_4.hide = True
	    switch_003_4.input_type = 'VECTOR'
	    #False
	    switch_003_4.inputs[1].default_value = (0.0, 0.0, 0.0)
	
	    #node Switch.002
	    switch_002_2 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSwitch")
	    switch_002_2.name = "Switch.002"
	    switch_002_2.input_type = 'VECTOR'
	
	    #node Vector Math.002
	    vector_math_002_2 = attach_hair_curves_to_surface.nodes.new("ShaderNodeVectorMath")
	    vector_math_002_2.name = "Vector Math.002"
	    vector_math_002_2.operation = 'ADD'
	
	    #node Vector Math.005
	    vector_math_005_2 = attach_hair_curves_to_surface.nodes.new("ShaderNodeVectorMath")
	    vector_math_005_2.name = "Vector Math.005"
	    vector_math_005_2.operation = 'SCALE'
	
	    #node Boolean Math
	    boolean_math_4 = attach_hair_curves_to_surface.nodes.new("FunctionNodeBooleanMath")
	    boolean_math_4.name = "Boolean Math"
	    boolean_math_4.operation = 'OR'
	
	    #node Spline Parameter
	    spline_parameter_3 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSplineParameter")
	    spline_parameter_3.name = "Spline Parameter"
	    spline_parameter_3.outputs[1].hide = True
	    spline_parameter_3.outputs[2].hide = True
	
	    #node Group Input.008
	    group_input_008_2 = attach_hair_curves_to_surface.nodes.new("NodeGroupInput")
	    group_input_008_2.name = "Group Input.008"
	    group_input_008_2.outputs[0].hide = True
	    group_input_008_2.outputs[1].hide = True
	    group_input_008_2.outputs[2].hide = True
	    group_input_008_2.outputs[3].hide = True
	    group_input_008_2.outputs[4].hide = True
	    group_input_008_2.outputs[5].hide = True
	    group_input_008_2.outputs[6].hide = True
	    group_input_008_2.outputs[7].hide = True
	    group_input_008_2.outputs[9].hide = True
	
	    #node Map Range
	    map_range_3 = attach_hair_curves_to_surface.nodes.new("ShaderNodeMapRange")
	    map_range_3.name = "Map Range"
	    map_range_3.hide = True
	    map_range_3.clamp = True
	    map_range_3.data_type = 'FLOAT'
	    map_range_3.interpolation_type = 'SMOOTHSTEP'
	    #From Min
	    map_range_3.inputs[1].default_value = 0.0
	    #To Min
	    map_range_3.inputs[3].default_value = 1.0
	    #To Max
	    map_range_3.inputs[4].default_value = 0.0
	
	    #node Compare
	    compare_6 = attach_hair_curves_to_surface.nodes.new("FunctionNodeCompare")
	    compare_6.name = "Compare"
	    compare_6.data_type = 'FLOAT'
	    compare_6.mode = 'ELEMENT'
	    compare_6.operation = 'EQUAL'
	    #B
	    compare_6.inputs[1].default_value = 0.0
	    #Epsilon
	    compare_6.inputs[12].default_value = 0.0
	
	    #node Switch.004
	    switch_004_2 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSwitch")
	    switch_004_2.name = "Switch.004"
	    switch_004_2.input_type = 'FLOAT'
	    #True
	    switch_004_2.inputs[2].default_value = 1.0
	
	    #node Position.002
	    position_002_8 = attach_hair_curves_to_surface.nodes.new("GeometryNodeInputPosition")
	    position_002_8.name = "Position.002"
	
	    #node Evaluate on Domain
	    evaluate_on_domain_1 = attach_hair_curves_to_surface.nodes.new("GeometryNodeFieldOnDomain")
	    evaluate_on_domain_1.name = "Evaluate on Domain"
	    evaluate_on_domain_1.data_type = 'FLOAT_VECTOR'
	    evaluate_on_domain_1.domain = 'CURVE'
	
	    #node Reroute.009
	    reroute_009_4 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_009_4.name = "Reroute.009"
	    reroute_009_4.socket_idname = "NodeSocketVector"
	    #node Evaluate on Domain.002
	    evaluate_on_domain_002_2 = attach_hair_curves_to_surface.nodes.new("GeometryNodeFieldOnDomain")
	    evaluate_on_domain_002_2.name = "Evaluate on Domain.002"
	    evaluate_on_domain_002_2.hide = True
	    evaluate_on_domain_002_2.data_type = 'FLOAT_VECTOR'
	    evaluate_on_domain_002_2.domain = 'CURVE'
	
	    #node Switch.006
	    switch_006 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSwitch")
	    switch_006.name = "Switch.006"
	    switch_006.input_type = 'VECTOR'
	
	    #node Vector Rotate
	    vector_rotate_1 = attach_hair_curves_to_surface.nodes.new("ShaderNodeVectorRotate")
	    vector_rotate_1.name = "Vector Rotate"
	    vector_rotate_1.invert = False
	    vector_rotate_1.rotation_type = 'EULER_XYZ'
	    vector_rotate_1.inputs[1].hide = True
	    vector_rotate_1.inputs[2].hide = True
	    vector_rotate_1.inputs[3].hide = True
	    #Center
	    vector_rotate_1.inputs[1].default_value = (0.0, 0.0, 0.0)
	
	    #node Vector Rotate.003
	    vector_rotate_003 = attach_hair_curves_to_surface.nodes.new("ShaderNodeVectorRotate")
	    vector_rotate_003.name = "Vector Rotate.003"
	    vector_rotate_003.invert = True
	    vector_rotate_003.rotation_type = 'EULER_XYZ'
	    vector_rotate_003.inputs[1].hide = True
	    vector_rotate_003.inputs[2].hide = True
	    vector_rotate_003.inputs[3].hide = True
	    #Center
	    vector_rotate_003.inputs[1].default_value = (0.0, 0.0, 0.0)
	
	    #node Align Euler to Vector.003
	    align_euler_to_vector_003 = attach_hair_curves_to_surface.nodes.new("FunctionNodeAlignEulerToVector")
	    align_euler_to_vector_003.name = "Align Euler to Vector.003"
	    align_euler_to_vector_003.axis = 'Z'
	    align_euler_to_vector_003.pivot_axis = 'AUTO'
	    align_euler_to_vector_003.inputs[0].hide = True
	    align_euler_to_vector_003.inputs[1].hide = True
	    #Rotation
	    align_euler_to_vector_003.inputs[0].default_value = (0.0, 0.0, 0.0)
	    #Factor
	    align_euler_to_vector_003.inputs[1].default_value = 1.0
	
	    #node Align Euler to Vector.002
	    align_euler_to_vector_002 = attach_hair_curves_to_surface.nodes.new("FunctionNodeAlignEulerToVector")
	    align_euler_to_vector_002.name = "Align Euler to Vector.002"
	    align_euler_to_vector_002.axis = 'Z'
	    align_euler_to_vector_002.pivot_axis = 'AUTO'
	    align_euler_to_vector_002.inputs[0].hide = True
	    align_euler_to_vector_002.inputs[1].hide = True
	    #Rotation
	    align_euler_to_vector_002.inputs[0].default_value = (0.0, 0.0, 0.0)
	    #Factor
	    align_euler_to_vector_002.inputs[1].default_value = 1.0
	
	    #node Evaluate on Domain.003
	    evaluate_on_domain_003 = attach_hair_curves_to_surface.nodes.new("GeometryNodeFieldOnDomain")
	    evaluate_on_domain_003.name = "Evaluate on Domain.003"
	    evaluate_on_domain_003.hide = True
	    evaluate_on_domain_003.data_type = 'FLOAT_VECTOR'
	    evaluate_on_domain_003.domain = 'CURVE'
	
	    #node Switch.001
	    switch_001_7 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSwitch")
	    switch_001_7.name = "Switch.001"
	    switch_001_7.hide = True
	    switch_001_7.input_type = 'VECTOR'
	
	    #node Accumulate Field
	    accumulate_field_2 = attach_hair_curves_to_surface.nodes.new("GeometryNodeAccumulateField")
	    accumulate_field_2.name = "Accumulate Field"
	    accumulate_field_2.hide = True
	    accumulate_field_2.data_type = 'FLOAT'
	    accumulate_field_2.domain = 'POINT'
	    #Group Index
	    accumulate_field_2.inputs[1].default_value = 0
	
	    #node Sample Index.001
	    sample_index_001_3 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSampleIndex")
	    sample_index_001_3.name = "Sample Index.001"
	    sample_index_001_3.hide = True
	    sample_index_001_3.clamp = False
	    sample_index_001_3.data_type = 'BOOLEAN'
	    sample_index_001_3.domain = 'CURVE'
	    #Index
	    sample_index_001_3.inputs[2].default_value = 0
	
	    #node Reroute.019
	    reroute_019_1 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_019_1.name = "Reroute.019"
	    reroute_019_1.socket_idname = "NodeSocketVector"
	    #node Named Attribute.002
	    named_attribute_002 = attach_hair_curves_to_surface.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute_002.name = "Named Attribute.002"
	    named_attribute_002.data_type = 'INT'
	    #Name
	    named_attribute_002.inputs[0].default_value = "guide_curve_index"
	
	    #node Reroute.007
	    reroute_007_4 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_007_4.name = "Reroute.007"
	    reroute_007_4.socket_idname = "NodeSocketGeometry"
	    #node Reroute.008
	    reroute_008_4 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_008_4.name = "Reroute.008"
	    reroute_008_4.socket_idname = "NodeSocketVector"
	    #node Sample Index
	    sample_index_4 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSampleIndex")
	    sample_index_4.name = "Sample Index"
	    sample_index_4.hide = True
	    sample_index_4.clamp = False
	    sample_index_4.data_type = 'FLOAT_VECTOR'
	    sample_index_4.domain = 'CURVE'
	
	
	
	
	    #Set parents
	    frame_006.parent = frame_8
	    frame_007.parent = frame_8
	    frame_003_3.parent = frame_010
	    frame_002_5.parent = frame_010
	    frame_008.parent = frame_002_5
	    frame_009.parent = frame_002_5
	    reroute_003_3.parent = frame_004_1
	    switch_6.parent = frame_004_1
	    store_named_attribute_5.parent = frame_004_1
	    group_input_007_2.parent = frame_004_1
	    reroute_016_3.parent = frame_004_1
	    reroute_005_4.parent = frame_004_1
	    store_named_attribute_001.parent = frame_004_1
	    named_attribute_004_2.parent = frame_004_1
	    reroute_012_4.parent = frame_004_1
	    named_attribute_003_1.parent = frame_004_1
	    switch_008.parent = frame_004_1
	    switch_009.parent = frame_004_1
	    switch_010.parent = frame_004_1
	    reroute_002_4.parent = frame_005
	    reroute_018_3.parent = frame_005
	    reroute_017_3.parent = frame_005
	    group_input_009_1.parent = frame_005
	    position_6.parent = frame_005
	    named_attribute_001_2.parent = frame_005
	    group_input_004_4.parent = frame_006
	    domain_size_002.parent = frame_006
	    compare_001_4.parent = frame_006
	    object_info_001_1.parent = frame_007
	    group_input_002_9.parent = frame_007
	    switch_005_2.parent = frame_8
	    domain_size_003.parent = frame_8
	    compare_002_5.parent = frame_8
	    named_attribute_6.parent = frame_8
	    reroute_8.parent = frame_8
	    group_input_005_6.parent = frame_8
	    set_position_3.parent = frame_8
	    switch_007.parent = frame_8
	    sample_nearest_surface.parent = frame_011
	    group_7.parent = frame_011
	    group_input_001_12.parent = frame_011
	    normal_3.parent = frame_001_5
	    capture_attribute_2.parent = frame_001_5
	    sample_uv_surface.parent = frame_005
	    sample_uv_surface_003.parent = frame_005
	    reroute_004_5.parent = frame_005
	    sample_uv_surface_001.parent = frame_005
	    group_001_5.parent = frame_010
	    position_001_3.parent = frame_010
	    vector_math_7.parent = frame_010
	    vector_math_001_4.parent = frame_010
	    vector_math_004_4.parent = frame_010
	    vector_math_003_2.parent = frame_010
	    group_input_003_7.parent = frame_010
	    group_input_006_4.parent = frame_010
	    switch_003_4.parent = frame_010
	    switch_002_2.parent = frame_010
	    vector_math_002_2.parent = frame_010
	    vector_math_005_2.parent = frame_010
	    boolean_math_4.parent = frame_010
	    spline_parameter_3.parent = frame_003_3
	    group_input_008_2.parent = frame_003_3
	    map_range_3.parent = frame_003_3
	    compare_6.parent = frame_003_3
	    switch_004_2.parent = frame_003_3
	    position_002_8.parent = frame_010
	    evaluate_on_domain_1.parent = frame_010
	    reroute_009_4.parent = frame_002_5
	    evaluate_on_domain_002_2.parent = frame_002_5
	    switch_006.parent = frame_002_5
	    vector_rotate_1.parent = frame_002_5
	    vector_rotate_003.parent = frame_002_5
	    align_euler_to_vector_003.parent = frame_002_5
	    align_euler_to_vector_002.parent = frame_002_5
	    evaluate_on_domain_003.parent = frame_002_5
	    switch_001_7.parent = frame_008
	    accumulate_field_2.parent = frame_008
	    sample_index_001_3.parent = frame_008
	    reroute_019_1.parent = frame_002_5
	    named_attribute_002.parent = frame_009
	    reroute_007_4.parent = frame_009
	    reroute_008_4.parent = frame_009
	    sample_index_4.parent = frame_009
	
	    #Set locations
	    frame_004_1.location = (-1215.903076171875, 262.0)
	    frame_005.location = (-4968.0, -121.0)
	    frame_8.location = (-7319.0, 140.0)
	    frame_006.location = (30.0, -355.0)
	    frame_007.location = (207.0, -181.0)
	    frame_011.location = (-5752.0, 120.0)
	    frame_001_5.location = (-5510.0, -382.0)
	    frame_010.location = (-4110.3515625, 32.0)
	    frame_003_3.location = (1565.3515625, -503.0)
	    frame_002_5.location = (29.999755859375, -437.0)
	    frame_008.location = (219.351806640625, -40.0)
	    frame_009.location = (30.0, -217.5032958984375)
	    reroute_010_3.location = (-798.60986328125, 472.99615478515625)
	    reroute_013_4.location = (-789.0, 512.1389770507812)
	    group_output_20.location = (75.0, 50.0)
	    reroute_003_3.location = (35.0, -292.3721618652344)
	    switch_6.location = (320.95263671875, -40.143096923828125)
	    store_named_attribute_5.location = (115.3720703125, -151.72100830078125)
	    group_input_007_2.location = (122.9049072265625, -39.53450012207031)
	    reroute_016_3.location = (45.1358642578125, -151.72100830078125)
	    reroute_005_4.location = (406.810302734375, -272.2791442871094)
	    store_named_attribute_001.location = (527.368408203125, -51.255889892578125)
	    named_attribute_004_2.location = (607.740478515625, -513.3954467773438)
	    reroute_012_4.location = (768.484619140625, -252.18612670898438)
	    reroute_014_3.location = (-507.69775390625, 311.209228515625)
	    reroute_006_4.location = (-547.8837890625, 291.1162109375)
	    named_attribute_003_1.location = (607.740478515625, -352.6512451171875)
	    switch_008.location = (808.670654296875, -71.34890747070312)
	    switch_009.location = (808.670654296875, -212.00006103515625)
	    switch_010.location = (808.670654296875, -392.8372802734375)
	    set_position_001_6.location = (-1472.16259765625, 230.837158203125)
	    reroute_002_4.location = (220.65625, -190.25262451171875)
	    reroute_018_3.location = (220.65625, -150.06658935546875)
	    reroute_017_3.location = (220.65625, -109.88055419921875)
	    group_input_009_1.location = (29.99072265625, -180.322021484375)
	    position_6.location = (29.99072265625, -39.67083740234375)
	    named_attribute_001_2.location = (29.99072265625, -260.694091796875)
	    capture_attribute_001_2.location = (-4365.55810546875, 210.744140625)
	    group_input_004_4.location = (29.669921875, -178.9044189453125)
	    domain_size_002.location = (207.6806640625, -80.07354736328125)
	    compare_001_4.location = (388.517578125, -39.88751220703125)
	    object_info_001_1.location = (210.88330078125, -39.64691162109375)
	    group_input_002_9.location = (30.0458984375, -79.83294677734375)
	    switch_005_2.location = (640.525390625, -283.5823974609375)
	    domain_size_003.location = (938.8193359375, -79.91128540039062)
	    compare_002_5.location = (1119.65625, -39.725250244140625)
	    named_attribute_6.location = (820.7041015625, -432.90301513671875)
	    reroute_8.location = (961.35546875, -332.43792724609375)
	    group_input_005_6.location = (1021.63427734375, -252.0657958984375)
	    set_position_3.location = (1021.63427734375, -352.53094482421875)
	    switch_007.location = (1222.564453125, -231.9727783203125)
	    reroute_015_3.location = (-5129.0927734375, 532.2319946289062)
	    reroute_011_3.location = (-5109.0, 492.04595947265625)
	    group_input_14.location = (-5510.8603515625, 351.395263671875)
	    capture_attribute_002_3.location = (-5209.46484375, 230.837158203125)
	    reroute_001_8.location = (-4887.9765625, -653.2559814453125)
	    sample_nearest_surface.location = (210.7509765625, -40.199798583984375)
	    group_7.location = (29.9140625, -180.85098266601562)
	    group_input_001_12.location = (29.9140625, -100.4788818359375)
	    reroute_020_1.location = (-4526.30224609375, -10.2791748046875)
	    normal_3.location = (29.5712890625, -45.01953125)
	    capture_attribute_2.location = (230.50146484375, -45.01953125)
	    sample_uv_surface.location = (321.1396484375, -50.02386474609375)
	    sample_uv_surface_003.location = (321.1396484375, -130.39593505859375)
	    reroute_004_5.location = (220.6748046875, -230.86102294921875)
	    sample_uv_surface_001.location = (321.1396484375, -210.76800537109375)
	    group_001_5.location = (158.627685546875, -240.71258544921875)
	    position_001_3.location = (339.46484375, -321.08465576171875)
	    vector_math_7.location = (339.46484375, -140.2474365234375)
	    vector_math_001_4.location = (540.39501953125, -321.08465576171875)
	    vector_math_004_4.location = (1826.3486328125, -341.17767333984375)
	    vector_math_003_2.location = (2027.27880859375, -200.52651977539062)
	    group_input_003_7.location = (1424.48828125, -220.79666137695312)
	    group_input_006_4.location = (1424.48828125, -100.238525390625)
	    switch_003_4.location = (1625.41845703125, -180.61062622070312)
	    switch_002_2.location = (1625.41845703125, -220.79666137695312)
	    vector_math_002_2.location = (1826.3486328125, -140.424560546875)
	    vector_math_005_2.location = (2248.30224609375, -200.70364379882812)
	    boolean_math_4.location = (1625.41845703125, -39.959442138671875)
	    spline_parameter_3.location = (32.72265625, -81.9400634765625)
	    group_input_008_2.location = (30.322265625, -161.4296875)
	    map_range_3.location = (205.259765625, -190.3057861328125)
	    compare_6.location = (205.20068359375, -39.6795654296875)
	    switch_004_2.location = (386.037841796875, -59.772705078125)
	    position_002_8.location = (1625.41845703125, -371.6761474609375)
	    evaluate_on_domain_1.location = (531.248291015625, -115.30325317382812)
	    reroute_009_4.location = (731.747802734375, -64.921875)
	    evaluate_on_domain_002_2.location = (630.95361328125, -265.85211181640625)
	    switch_006.location = (992.6279296875, -64.921875)
	    vector_rotate_1.location = (1173.465087890625, -64.921875)
	    vector_rotate_003.location = (811.790771484375, -165.386962890625)
	    align_euler_to_vector_003.location = (630.95361328125, -165.386962890625)
	    align_euler_to_vector_002.location = (630.95361328125, -306.0382080078125)
	    evaluate_on_domain_003.location = (630.95361328125, -406.5032958984375)
	    switch_001_7.location = (210.67138671875, -105.2939453125)
	    accumulate_field_2.location = (29.834228515625, -45.014892578125)
	    sample_index_001_3.location = (29.834228515625, -85.200927734375)
	    reroute_019_1.location = (48.255859375, -185.48004150390625)
	    named_attribute_002.location = (35.0, -105.279052734375)
	    reroute_007_4.location = (35.0, -45.0)
	    reroute_008_4.location = (35.0, -85.18603515625)
	    sample_index_4.location = (215.837158203125, -65.093017578125)
	
	    #Set dimensions
	    frame_004_1.width, frame_004_1.height = 978.903076171875, 664.0
	    frame_005.width, frame_005.height = 491.0, 412.0
	    frame_8.width, frame_8.height = 1393.0, 646.0
	    frame_006.width, frame_006.height = 559.0, 261.0
	    frame_007.width, frame_007.height = 381.0, 215.0
	    frame_011.width, frame_011.height = 390.33642578125, 279.0
	    frame_001_5.width, frame_001_5.height = 401.0, 125.0
	    frame_010.width, frame_010.height = 2418.3515625, 971.0
	    frame_003_3.width, frame_003_3.height = 556.0, 250.0
	    frame_002_5.width, frame_002_5.height = 1343.351806640625, 504.0
	    frame_008.width, frame_008.height = 381.0, 160.0
	    frame_009.width, frame_009.height = 385.351806640625, 256.4967041015625
	    reroute_010_3.width, reroute_010_3.height = 10.0, 100.0
	    reroute_013_4.width, reroute_013_4.height = 10.0, 100.0
	    group_output_20.width, group_output_20.height = 140.0, 100.0
	    reroute_003_3.width, reroute_003_3.height = 10.0, 100.0
	    switch_6.width, switch_6.height = 140.0, 100.0
	    store_named_attribute_5.width, store_named_attribute_5.height = 140.0, 100.0
	    group_input_007_2.width, group_input_007_2.height = 140.0, 100.0
	    reroute_016_3.width, reroute_016_3.height = 10.0, 100.0
	    reroute_005_4.width, reroute_005_4.height = 10.0, 100.0
	    store_named_attribute_001.width, store_named_attribute_001.height = 140.0, 100.0
	    named_attribute_004_2.width, named_attribute_004_2.height = 140.0, 100.0
	    reroute_012_4.width, reroute_012_4.height = 10.0, 100.0
	    reroute_014_3.width, reroute_014_3.height = 10.0, 100.0
	    reroute_006_4.width, reroute_006_4.height = 10.0, 100.0
	    named_attribute_003_1.width, named_attribute_003_1.height = 140.0, 100.0
	    switch_008.width, switch_008.height = 140.0, 100.0
	    switch_009.width, switch_009.height = 140.0, 100.0
	    switch_010.width, switch_010.height = 140.0, 100.0
	    set_position_001_6.width, set_position_001_6.height = 140.0, 100.0
	    reroute_002_4.width, reroute_002_4.height = 10.0, 100.0
	    reroute_018_3.width, reroute_018_3.height = 10.0, 100.0
	    reroute_017_3.width, reroute_017_3.height = 10.0, 100.0
	    group_input_009_1.width, group_input_009_1.height = 140.0, 100.0
	    position_6.width, position_6.height = 140.0, 100.0
	    named_attribute_001_2.width, named_attribute_001_2.height = 140.0, 100.0
	    capture_attribute_001_2.width, capture_attribute_001_2.height = 140.0, 100.0
	    group_input_004_4.width, group_input_004_4.height = 140.0, 100.0
	    domain_size_002.width, domain_size_002.height = 140.0, 100.0
	    compare_001_4.width, compare_001_4.height = 140.0, 100.0
	    object_info_001_1.width, object_info_001_1.height = 140.0, 100.0
	    group_input_002_9.width, group_input_002_9.height = 140.0, 100.0
	    switch_005_2.width, switch_005_2.height = 140.0, 100.0
	    domain_size_003.width, domain_size_003.height = 140.0, 100.0
	    compare_002_5.width, compare_002_5.height = 140.0, 100.0
	    named_attribute_6.width, named_attribute_6.height = 140.0, 100.0
	    reroute_8.width, reroute_8.height = 10.0, 100.0
	    group_input_005_6.width, group_input_005_6.height = 140.0, 100.0
	    set_position_3.width, set_position_3.height = 140.0, 100.0
	    switch_007.width, switch_007.height = 140.0, 100.0
	    reroute_015_3.width, reroute_015_3.height = 10.0, 100.0
	    reroute_011_3.width, reroute_011_3.height = 10.0, 100.0
	    group_input_14.width, group_input_14.height = 140.0, 100.0
	    capture_attribute_002_3.width, capture_attribute_002_3.height = 140.0, 100.0
	    reroute_001_8.width, reroute_001_8.height = 10.0, 100.0
	    sample_nearest_surface.width, sample_nearest_surface.height = 149.33627319335938, 100.0
	    group_7.width, group_7.height = 140.0, 100.0
	    group_input_001_12.width, group_input_001_12.height = 140.0, 100.0
	    reroute_020_1.width, reroute_020_1.height = 10.0, 100.0
	    normal_3.width, normal_3.height = 140.0, 100.0
	    capture_attribute_2.width, capture_attribute_2.height = 140.0, 100.0
	    sample_uv_surface.width, sample_uv_surface.height = 140.0, 100.0
	    sample_uv_surface_003.width, sample_uv_surface_003.height = 140.0, 100.0
	    reroute_004_5.width, reroute_004_5.height = 10.0, 100.0
	    sample_uv_surface_001.width, sample_uv_surface_001.height = 140.0, 100.0
	    group_001_5.width, group_001_5.height = 140.0, 100.0
	    position_001_3.width, position_001_3.height = 140.0, 100.0
	    vector_math_7.width, vector_math_7.height = 140.0, 100.0
	    vector_math_001_4.width, vector_math_001_4.height = 140.0, 100.0
	    vector_math_004_4.width, vector_math_004_4.height = 140.0, 100.0
	    vector_math_003_2.width, vector_math_003_2.height = 140.0, 100.0
	    group_input_003_7.width, group_input_003_7.height = 140.0, 100.0
	    group_input_006_4.width, group_input_006_4.height = 140.0, 100.0
	    switch_003_4.width, switch_003_4.height = 140.0, 100.0
	    switch_002_2.width, switch_002_2.height = 140.0, 100.0
	    vector_math_002_2.width, vector_math_002_2.height = 140.0, 100.0
	    vector_math_005_2.width, vector_math_005_2.height = 140.0, 100.0
	    boolean_math_4.width, boolean_math_4.height = 140.0, 100.0
	    spline_parameter_3.width, spline_parameter_3.height = 140.0, 100.0
	    group_input_008_2.width, group_input_008_2.height = 140.0, 100.0
	    map_range_3.width, map_range_3.height = 140.0, 100.0
	    compare_6.width, compare_6.height = 140.0, 100.0
	    switch_004_2.width, switch_004_2.height = 140.0, 100.0
	    position_002_8.width, position_002_8.height = 140.0, 100.0
	    evaluate_on_domain_1.width, evaluate_on_domain_1.height = 140.0, 100.0
	    reroute_009_4.width, reroute_009_4.height = 10.0, 100.0
	    evaluate_on_domain_002_2.width, evaluate_on_domain_002_2.height = 140.0, 100.0
	    switch_006.width, switch_006.height = 140.0, 100.0
	    vector_rotate_1.width, vector_rotate_1.height = 140.0, 100.0
	    vector_rotate_003.width, vector_rotate_003.height = 140.0, 100.0
	    align_euler_to_vector_003.width, align_euler_to_vector_003.height = 140.0, 100.0
	    align_euler_to_vector_002.width, align_euler_to_vector_002.height = 140.0, 100.0
	    evaluate_on_domain_003.width, evaluate_on_domain_003.height = 140.0, 100.0
	    switch_001_7.width, switch_001_7.height = 140.0, 100.0
	    accumulate_field_2.width, accumulate_field_2.height = 140.0, 100.0
	    sample_index_001_3.width, sample_index_001_3.height = 140.0, 100.0
	    reroute_019_1.width, reroute_019_1.height = 10.0, 100.0
	    named_attribute_002.width, named_attribute_002.height = 140.0, 100.0
	    reroute_007_4.width, reroute_007_4.height = 10.0, 100.0
	    reroute_008_4.width, reroute_008_4.height = 10.0, 100.0
	    sample_index_4.width, sample_index_4.height = 140.0, 100.0
	
	    #initialize attach_hair_curves_to_surface links
	    #domain_size_002.Face Count -> compare_001_4.A
	    attach_hair_curves_to_surface.links.new(domain_size_002.outputs[2], compare_001_4.inputs[2])
	    #compare_001_4.Result -> switch_005_2.Switch
	    attach_hair_curves_to_surface.links.new(compare_001_4.outputs[0], switch_005_2.inputs[0])
	    #group_input_002_9.Surface -> object_info_001_1.Object
	    attach_hair_curves_to_surface.links.new(group_input_002_9.outputs[2], object_info_001_1.inputs[0])
	    #group_input_004_4.Surface -> domain_size_002.Geometry
	    attach_hair_curves_to_surface.links.new(group_input_004_4.outputs[1], domain_size_002.inputs[0])
	    #group_input_004_4.Surface -> switch_005_2.True
	    attach_hair_curves_to_surface.links.new(group_input_004_4.outputs[1], switch_005_2.inputs[2])
	    #group_input_001_12.Surface UV Map -> sample_nearest_surface.Value
	    attach_hair_curves_to_surface.links.new(group_input_001_12.outputs[3], sample_nearest_surface.inputs[1])
	    #reroute_8.Output -> set_position_3.Geometry
	    attach_hair_curves_to_surface.links.new(reroute_8.outputs[0], set_position_3.inputs[0])
	    #reroute_8.Output -> switch_007.False
	    attach_hair_curves_to_surface.links.new(reroute_8.outputs[0], switch_007.inputs[1])
	    #set_position_3.Geometry -> switch_007.True
	    attach_hair_curves_to_surface.links.new(set_position_3.outputs[0], switch_007.inputs[2])
	    #switch_005_2.Output -> reroute_8.Input
	    attach_hair_curves_to_surface.links.new(switch_005_2.outputs[0], reroute_8.inputs[0])
	    #group_input_005_6.Surface Rest Position -> switch_007.Switch
	    attach_hair_curves_to_surface.links.new(group_input_005_6.outputs[4], switch_007.inputs[0])
	    #named_attribute_6.Attribute -> set_position_3.Position
	    attach_hair_curves_to_surface.links.new(named_attribute_6.outputs[0], set_position_3.inputs[2])
	    #named_attribute_6.Exists -> set_position_3.Selection
	    attach_hair_curves_to_surface.links.new(named_attribute_6.outputs[1], set_position_3.inputs[1])
	    #switch_007.Output -> sample_nearest_surface.Mesh
	    attach_hair_curves_to_surface.links.new(switch_007.outputs[0], sample_nearest_surface.inputs[0])
	    #object_info_001_1.Geometry -> switch_005_2.False
	    attach_hair_curves_to_surface.links.new(object_info_001_1.outputs[4], switch_005_2.inputs[1])
	    #group_7.Root Position -> sample_nearest_surface.Sample Position
	    attach_hair_curves_to_surface.links.new(group_7.outputs[1], sample_nearest_surface.inputs[3])
	    #reroute_002_4.Output -> sample_uv_surface.UV Map
	    attach_hair_curves_to_surface.links.new(reroute_002_4.outputs[0], sample_uv_surface.inputs[2])
	    #position_6.Position -> sample_uv_surface.Value
	    attach_hair_curves_to_surface.links.new(position_6.outputs[0], sample_uv_surface.inputs[1])
	    #reroute_004_5.Output -> sample_uv_surface.Sample UV
	    attach_hair_curves_to_surface.links.new(reroute_004_5.outputs[0], sample_uv_surface.inputs[3])
	    #capture_attribute_001_2.Geometry -> set_position_001_6.Geometry
	    attach_hair_curves_to_surface.links.new(capture_attribute_001_2.outputs[0], set_position_001_6.inputs[0])
	    #reroute_017_3.Output -> sample_uv_surface_001.Mesh
	    attach_hair_curves_to_surface.links.new(reroute_017_3.outputs[0], sample_uv_surface_001.inputs[0])
	    #reroute_004_5.Output -> sample_uv_surface_001.Sample UV
	    attach_hair_curves_to_surface.links.new(reroute_004_5.outputs[0], sample_uv_surface_001.inputs[3])
	    #reroute_002_4.Output -> sample_uv_surface_001.UV Map
	    attach_hair_curves_to_surface.links.new(reroute_002_4.outputs[0], sample_uv_surface_001.inputs[2])
	    #normal_3.Normal -> capture_attribute_2.Value
	    attach_hair_curves_to_surface.links.new(normal_3.outputs[0], capture_attribute_2.inputs[1])
	    #reroute_018_3.Output -> sample_uv_surface_001.Value
	    attach_hair_curves_to_surface.links.new(reroute_018_3.outputs[0], sample_uv_surface_001.inputs[1])
	    #sample_uv_surface.Value -> vector_math_7.Vector
	    attach_hair_curves_to_surface.links.new(sample_uv_surface.outputs[0], vector_math_7.inputs[0])
	    #group_001_5.Root Position -> vector_math_7.Vector
	    attach_hair_curves_to_surface.links.new(group_001_5.outputs[1], vector_math_7.inputs[1])
	    #vector_math_7.Vector -> evaluate_on_domain_1.Value
	    attach_hair_curves_to_surface.links.new(vector_math_7.outputs[0], evaluate_on_domain_1.inputs[0])
	    #position_001_3.Position -> vector_math_001_4.Vector
	    attach_hair_curves_to_surface.links.new(position_001_3.outputs[0], vector_math_001_4.inputs[0])
	    #group_001_5.Root Position -> vector_math_001_4.Vector
	    attach_hair_curves_to_surface.links.new(group_001_5.outputs[1], vector_math_001_4.inputs[1])
	    #switch_006.Output -> vector_rotate_1.Vector
	    attach_hair_curves_to_surface.links.new(switch_006.outputs[0], vector_rotate_1.inputs[0])
	    #reroute_007_4.Output -> sample_index_4.Geometry
	    attach_hair_curves_to_surface.links.new(reroute_007_4.outputs[0], sample_index_4.inputs[0])
	    #named_attribute_002.Attribute -> sample_index_4.Index
	    attach_hair_curves_to_surface.links.new(named_attribute_002.outputs[0], sample_index_4.inputs[2])
	    #position_002_8.Position -> vector_math_004_4.Vector
	    attach_hair_curves_to_surface.links.new(position_002_8.outputs[0], vector_math_004_4.inputs[0])
	    #vector_math_002_2.Vector -> vector_math_003_2.Vector
	    attach_hair_curves_to_surface.links.new(vector_math_002_2.outputs[0], vector_math_003_2.inputs[0])
	    #switch_003_4.Output -> vector_math_002_2.Vector
	    attach_hair_curves_to_surface.links.new(switch_003_4.outputs[0], vector_math_002_2.inputs[0])
	    #switch_002_2.Output -> vector_math_002_2.Vector
	    attach_hair_curves_to_surface.links.new(switch_002_2.outputs[0], vector_math_002_2.inputs[1])
	    #reroute_009_4.Output -> vector_rotate_003.Vector
	    attach_hair_curves_to_surface.links.new(reroute_009_4.outputs[0], vector_rotate_003.inputs[0])
	    #evaluate_on_domain_002_2.Value -> vector_rotate_003.Rotation
	    attach_hair_curves_to_surface.links.new(evaluate_on_domain_002_2.outputs[0], vector_rotate_003.inputs[4])
	    #evaluate_on_domain_003.Value -> vector_rotate_1.Rotation
	    attach_hair_curves_to_surface.links.new(evaluate_on_domain_003.outputs[0], vector_rotate_1.inputs[4])
	    #group_001_5.Root Position -> vector_math_004_4.Vector
	    attach_hair_curves_to_surface.links.new(group_001_5.outputs[1], vector_math_004_4.inputs[1])
	    #vector_math_004_4.Vector -> vector_math_003_2.Vector
	    attach_hair_curves_to_surface.links.new(vector_math_004_4.outputs[0], vector_math_003_2.inputs[1])
	    #reroute_016_3.Output -> store_named_attribute_5.Geometry
	    attach_hair_curves_to_surface.links.new(reroute_016_3.outputs[0], store_named_attribute_5.inputs[0])
	    #group_input_14.Geometry -> capture_attribute_002_3.Geometry
	    attach_hair_curves_to_surface.links.new(group_input_14.outputs[0], capture_attribute_002_3.inputs[0])
	    #reroute_003_3.Output -> store_named_attribute_5.Value
	    attach_hair_curves_to_surface.links.new(reroute_003_3.outputs[0], store_named_attribute_5.inputs[3])
	    #sample_nearest_surface.Value -> capture_attribute_002_3.Value
	    attach_hair_curves_to_surface.links.new(sample_nearest_surface.outputs[0], capture_attribute_002_3.inputs[1])
	    #capture_attribute_002_3.Value -> reroute_004_5.Input
	    attach_hair_curves_to_surface.links.new(capture_attribute_002_3.outputs[1], reroute_004_5.inputs[0])
	    #switch_007.Output -> capture_attribute_2.Geometry
	    attach_hair_curves_to_surface.links.new(switch_007.outputs[0], capture_attribute_2.inputs[0])
	    #align_euler_to_vector_003.Rotation -> evaluate_on_domain_002_2.Value
	    attach_hair_curves_to_surface.links.new(align_euler_to_vector_003.outputs[0], evaluate_on_domain_002_2.inputs[0])
	    #align_euler_to_vector_002.Rotation -> evaluate_on_domain_003.Value
	    attach_hair_curves_to_surface.links.new(align_euler_to_vector_002.outputs[0], evaluate_on_domain_003.inputs[0])
	    #capture_attribute_2.Geometry -> reroute_001_8.Input
	    attach_hair_curves_to_surface.links.new(capture_attribute_2.outputs[0], reroute_001_8.inputs[0])
	    #reroute_018_3.Output -> sample_uv_surface_003.Value
	    attach_hair_curves_to_surface.links.new(reroute_018_3.outputs[0], sample_uv_surface_003.inputs[1])
	    #reroute_002_4.Output -> sample_uv_surface_003.UV Map
	    attach_hair_curves_to_surface.links.new(reroute_002_4.outputs[0], sample_uv_surface_003.inputs[2])
	    #reroute_017_3.Output -> sample_uv_surface_003.Mesh
	    attach_hair_curves_to_surface.links.new(reroute_017_3.outputs[0], sample_uv_surface_003.inputs[0])
	    #named_attribute_001_2.Attribute -> sample_uv_surface_003.Sample UV
	    attach_hair_curves_to_surface.links.new(named_attribute_001_2.outputs[0], sample_uv_surface_003.inputs[3])
	    #reroute_019_1.Output -> switch_001_7.True
	    attach_hair_curves_to_surface.links.new(reroute_019_1.outputs[0], switch_001_7.inputs[2])
	    #reroute_020_1.Output -> sample_index_001_3.Geometry
	    attach_hair_curves_to_surface.links.new(reroute_020_1.outputs[0], sample_index_001_3.inputs[0])
	    #named_attribute_001_2.Exists -> accumulate_field_2.Value
	    attach_hair_curves_to_surface.links.new(named_attribute_001_2.outputs[1], accumulate_field_2.inputs[0])
	    #accumulate_field_2.Total -> sample_index_001_3.Value
	    attach_hair_curves_to_surface.links.new(accumulate_field_2.outputs[2], sample_index_001_3.inputs[1])
	    #sample_index_001_3.Value -> switch_001_7.Switch
	    attach_hair_curves_to_surface.links.new(sample_index_001_3.outputs[0], switch_001_7.inputs[0])
	    #reroute_008_4.Output -> sample_index_4.Value
	    attach_hair_curves_to_surface.links.new(reroute_008_4.outputs[0], sample_index_4.inputs[1])
	    #vector_rotate_1.Vector -> switch_002_2.True
	    attach_hair_curves_to_surface.links.new(vector_rotate_1.outputs[0], switch_002_2.inputs[2])
	    #vector_math_001_4.Vector -> switch_002_2.False
	    attach_hair_curves_to_surface.links.new(vector_math_001_4.outputs[0], switch_002_2.inputs[1])
	    #group_input_003_7.Align to Surface Normal -> switch_002_2.Switch
	    attach_hair_curves_to_surface.links.new(group_input_003_7.outputs[7], switch_002_2.inputs[0])
	    #vector_math_005_2.Vector -> set_position_001_6.Offset
	    attach_hair_curves_to_surface.links.new(vector_math_005_2.outputs[0], set_position_001_6.inputs[3])
	    #evaluate_on_domain_1.Value -> switch_003_4.True
	    attach_hair_curves_to_surface.links.new(evaluate_on_domain_1.outputs[0], switch_003_4.inputs[2])
	    #group_input_006_4.Snap to Surface -> switch_003_4.Switch
	    attach_hair_curves_to_surface.links.new(group_input_006_4.outputs[6], switch_003_4.inputs[0])
	    #group_input_006_4.Snap to Surface -> boolean_math_4.Boolean
	    attach_hair_curves_to_surface.links.new(group_input_006_4.outputs[6], boolean_math_4.inputs[0])
	    #group_input_003_7.Align to Surface Normal -> boolean_math_4.Boolean
	    attach_hair_curves_to_surface.links.new(group_input_003_7.outputs[7], boolean_math_4.inputs[1])
	    #boolean_math_4.Boolean -> set_position_001_6.Selection
	    attach_hair_curves_to_surface.links.new(boolean_math_4.outputs[0], set_position_001_6.inputs[1])
	    #capture_attribute_002_3.Value -> reroute_003_3.Input
	    attach_hair_curves_to_surface.links.new(capture_attribute_002_3.outputs[1], reroute_003_3.inputs[0])
	    #switch_009.Output -> group_output_20.Surface UV Coordinate
	    attach_hair_curves_to_surface.links.new(switch_009.outputs[0], group_output_20.inputs[1])
	    #store_named_attribute_5.Geometry -> switch_6.True
	    attach_hair_curves_to_surface.links.new(store_named_attribute_5.outputs[0], switch_6.inputs[2])
	    #group_input_007_2.Sample Attachment UV -> switch_6.Switch
	    attach_hair_curves_to_surface.links.new(group_input_007_2.outputs[5], switch_6.inputs[0])
	    #reroute_016_3.Output -> switch_6.False
	    attach_hair_curves_to_surface.links.new(reroute_016_3.outputs[0], switch_6.inputs[1])
	    #switch_6.Output -> store_named_attribute_001.Geometry
	    attach_hair_curves_to_surface.links.new(switch_6.outputs[0], store_named_attribute_001.inputs[0])
	    #reroute_020_1.Output -> capture_attribute_001_2.Geometry
	    attach_hair_curves_to_surface.links.new(reroute_020_1.outputs[0], capture_attribute_001_2.inputs[0])
	    #reroute_005_4.Output -> store_named_attribute_001.Value
	    attach_hair_curves_to_surface.links.new(reroute_005_4.outputs[0], store_named_attribute_001.inputs[3])
	    #capture_attribute_001_2.Value -> reroute_005_4.Input
	    attach_hair_curves_to_surface.links.new(capture_attribute_001_2.outputs[1], reroute_005_4.inputs[0])
	    #switch_010.Output -> group_output_20.Surface Normal
	    attach_hair_curves_to_surface.links.new(switch_010.outputs[0], group_output_20.inputs[2])
	    #sample_uv_surface_001.Value -> capture_attribute_001_2.Value
	    attach_hair_curves_to_surface.links.new(sample_uv_surface_001.outputs[0], capture_attribute_001_2.inputs[1])
	    #vector_math_003_2.Vector -> vector_math_005_2.Vector
	    attach_hair_curves_to_surface.links.new(vector_math_003_2.outputs[0], vector_math_005_2.inputs[0])
	    #spline_parameter_3.Factor -> map_range_3.Value
	    attach_hair_curves_to_surface.links.new(spline_parameter_3.outputs[0], map_range_3.inputs[0])
	    #group_input_008_2.Blend along Curve -> map_range_3.From Max
	    attach_hair_curves_to_surface.links.new(group_input_008_2.outputs[8], map_range_3.inputs[2])
	    #group_input_008_2.Blend along Curve -> compare_6.A
	    attach_hair_curves_to_surface.links.new(group_input_008_2.outputs[8], compare_6.inputs[0])
	    #compare_6.Result -> switch_004_2.Switch
	    attach_hair_curves_to_surface.links.new(compare_6.outputs[0], switch_004_2.inputs[0])
	    #map_range_3.Result -> switch_004_2.False
	    attach_hair_curves_to_surface.links.new(map_range_3.outputs[0], switch_004_2.inputs[1])
	    #switch_004_2.Output -> vector_math_005_2.Scale
	    attach_hair_curves_to_surface.links.new(switch_004_2.outputs[0], vector_math_005_2.inputs[3])
	    #switch_001_7.Output -> align_euler_to_vector_003.Vector
	    attach_hair_curves_to_surface.links.new(switch_001_7.outputs[0], align_euler_to_vector_003.inputs[2])
	    #sample_index_4.Value -> switch_001_7.False
	    attach_hair_curves_to_surface.links.new(sample_index_4.outputs[0], switch_001_7.inputs[1])
	    #named_attribute_002.Exists -> switch_006.Switch
	    attach_hair_curves_to_surface.links.new(named_attribute_002.outputs[1], switch_006.inputs[0])
	    #reroute_009_4.Output -> switch_006.False
	    attach_hair_curves_to_surface.links.new(reroute_009_4.outputs[0], switch_006.inputs[1])
	    #vector_rotate_003.Vector -> switch_006.True
	    attach_hair_curves_to_surface.links.new(vector_rotate_003.outputs[0], switch_006.inputs[2])
	    #vector_math_001_4.Vector -> reroute_009_4.Input
	    attach_hair_curves_to_surface.links.new(vector_math_001_4.outputs[0], reroute_009_4.inputs[0])
	    #reroute_011_3.Output -> reroute_010_3.Input
	    attach_hair_curves_to_surface.links.new(reroute_011_3.outputs[0], reroute_010_3.inputs[0])
	    #group_input_14.Geometry -> reroute_011_3.Input
	    attach_hair_curves_to_surface.links.new(group_input_14.outputs[0], reroute_011_3.inputs[0])
	    #store_named_attribute_001.Geometry -> switch_008.False
	    attach_hair_curves_to_surface.links.new(store_named_attribute_001.outputs[0], switch_008.inputs[1])
	    #reroute_006_4.Output -> switch_008.True
	    attach_hair_curves_to_surface.links.new(reroute_006_4.outputs[0], switch_008.inputs[2])
	    #switch_008.Output -> group_output_20.Geometry
	    attach_hair_curves_to_surface.links.new(switch_008.outputs[0], group_output_20.inputs[0])
	    #reroute_003_3.Output -> switch_009.False
	    attach_hair_curves_to_surface.links.new(reroute_003_3.outputs[0], switch_009.inputs[1])
	    #reroute_005_4.Output -> switch_010.False
	    attach_hair_curves_to_surface.links.new(reroute_005_4.outputs[0], switch_010.inputs[1])
	    #domain_size_003.Face Count -> compare_002_5.A
	    attach_hair_curves_to_surface.links.new(domain_size_003.outputs[2], compare_002_5.inputs[2])
	    #switch_005_2.Output -> domain_size_003.Geometry
	    attach_hair_curves_to_surface.links.new(switch_005_2.outputs[0], domain_size_003.inputs[0])
	    #reroute_012_4.Output -> switch_008.Switch
	    attach_hair_curves_to_surface.links.new(reroute_012_4.outputs[0], switch_008.inputs[0])
	    #reroute_014_3.Output -> reroute_012_4.Input
	    attach_hair_curves_to_surface.links.new(reroute_014_3.outputs[0], reroute_012_4.inputs[0])
	    #reroute_012_4.Output -> switch_009.Switch
	    attach_hair_curves_to_surface.links.new(reroute_012_4.outputs[0], switch_009.inputs[0])
	    #reroute_012_4.Output -> switch_010.Switch
	    attach_hair_curves_to_surface.links.new(reroute_012_4.outputs[0], switch_010.inputs[0])
	    #named_attribute_003_1.Attribute -> switch_009.True
	    attach_hair_curves_to_surface.links.new(named_attribute_003_1.outputs[0], switch_009.inputs[2])
	    #named_attribute_004_2.Attribute -> switch_010.True
	    attach_hair_curves_to_surface.links.new(named_attribute_004_2.outputs[0], switch_010.inputs[2])
	    #reroute_015_3.Output -> reroute_013_4.Input
	    attach_hair_curves_to_surface.links.new(reroute_015_3.outputs[0], reroute_013_4.inputs[0])
	    #reroute_013_4.Output -> reroute_014_3.Input
	    attach_hair_curves_to_surface.links.new(reroute_013_4.outputs[0], reroute_014_3.inputs[0])
	    #compare_002_5.Result -> reroute_015_3.Input
	    attach_hair_curves_to_surface.links.new(compare_002_5.outputs[0], reroute_015_3.inputs[0])
	    #set_position_001_6.Geometry -> reroute_016_3.Input
	    attach_hair_curves_to_surface.links.new(set_position_001_6.outputs[0], reroute_016_3.inputs[0])
	    #capture_attribute_2.Geometry -> reroute_017_3.Input
	    attach_hair_curves_to_surface.links.new(capture_attribute_2.outputs[0], reroute_017_3.inputs[0])
	    #capture_attribute_2.Value -> reroute_018_3.Input
	    attach_hair_curves_to_surface.links.new(capture_attribute_2.outputs[1], reroute_018_3.inputs[0])
	    #reroute_010_3.Output -> reroute_006_4.Input
	    attach_hair_curves_to_surface.links.new(reroute_010_3.outputs[0], reroute_006_4.inputs[0])
	    #reroute_001_8.Output -> reroute_007_4.Input
	    attach_hair_curves_to_surface.links.new(reroute_001_8.outputs[0], reroute_007_4.inputs[0])
	    #sample_uv_surface_001.Value -> reroute_008_4.Input
	    attach_hair_curves_to_surface.links.new(sample_uv_surface_001.outputs[0], reroute_008_4.inputs[0])
	    #reroute_008_4.Output -> align_euler_to_vector_002.Vector
	    attach_hair_curves_to_surface.links.new(reroute_008_4.outputs[0], align_euler_to_vector_002.inputs[2])
	    #sample_uv_surface_003.Value -> reroute_019_1.Input
	    attach_hair_curves_to_surface.links.new(sample_uv_surface_003.outputs[0], reroute_019_1.inputs[0])
	    #reroute_017_3.Output -> sample_uv_surface.Mesh
	    attach_hair_curves_to_surface.links.new(reroute_017_3.outputs[0], sample_uv_surface.inputs[0])
	    #group_input_009_1.Surface UV Map -> reroute_002_4.Input
	    attach_hair_curves_to_surface.links.new(group_input_009_1.outputs[3], reroute_002_4.inputs[0])
	    #capture_attribute_002_3.Geometry -> reroute_020_1.Input
	    attach_hair_curves_to_surface.links.new(capture_attribute_002_3.outputs[0], reroute_020_1.inputs[0])
	    return attach_hair_curves_to_surface
	
	attach_hair_curves_to_surface = attach_hair_curves_to_surface_node_group()
	
	#initialize twist_bunz node group
	def twist_bunz_node_group():
	    twist_bunz = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "TWIST_BUNZ")
	
	    twist_bunz.color_tag = 'NONE'
	    twist_bunz.description = "Convert curves to twist buns."
	    twist_bunz.default_group_node_width = 140
	    
	
	    twist_bunz.is_modifier = True
	
	    #twist_bunz interface
	    #Socket Geometry
	    geometry_socket_24 = twist_bunz.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_24.attribute_domain = 'POINT'
	    geometry_socket_24.description = "Twist bun."
	
	    #Socket Geometry
	    geometry_socket_25 = twist_bunz.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_25.attribute_domain = 'POINT'
	    geometry_socket_25.description = "Curve guide."
	
	    #Socket Surface
	    surface_socket_5 = twist_bunz.interface.new_socket(name = "Surface", in_out='INPUT', socket_type = 'NodeSocketObject')
	    surface_socket_5.attribute_domain = 'POINT'
	    surface_socket_5.description = "Surface attached to hair."
	
	    #Socket Hair Style
	    hair_style_socket = twist_bunz.interface.new_socket(name = "Hair Style", in_out='INPUT', socket_type = 'NodeSocketMenu')
	    hair_style_socket.attribute_domain = 'POINT'
	    hair_style_socket.description = "Choose style of hair."
	
	    #Socket Control Points
	    control_points_socket_3 = twist_bunz.interface.new_socket(name = "Control Points", in_out='INPUT', socket_type = 'NodeSocketInt')
	    control_points_socket_3.default_value = 20
	    control_points_socket_3.min_value = 3
	    control_points_socket_3.max_value = 100000
	    control_points_socket_3.subtype = 'NONE'
	    control_points_socket_3.attribute_domain = 'POINT'
	    control_points_socket_3.description = "Amount of points for each curve."
	
	    #Socket Offset Scale
	    offset_scale_socket_2 = twist_bunz.interface.new_socket(name = "Offset Scale", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    offset_scale_socket_2.default_value = 1.0
	    offset_scale_socket_2.min_value = 0.0
	    offset_scale_socket_2.max_value = 3.4028234663852886e+38
	    offset_scale_socket_2.subtype = 'NONE'
	    offset_scale_socket_2.attribute_domain = 'POINT'
	    offset_scale_socket_2.description = "Overhang offset scale."
	
	    #Socket Tilt
	    tilt_socket = twist_bunz.interface.new_socket(name = "Tilt", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    tilt_socket.default_value = 0.0
	    tilt_socket.min_value = -3.4028234663852886e+38
	    tilt_socket.max_value = 3.4028234663852886e+38
	    tilt_socket.subtype = 'ANGLE'
	    tilt_socket.attribute_domain = 'POINT'
	    tilt_socket.description = "Set guide curve tilt"
	
	    #Socket Rotate
	    rotate_socket_2 = twist_bunz.interface.new_socket(name = "Rotate", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    rotate_socket_2.default_value = 0.0
	    rotate_socket_2.min_value = -3.1415927410125732
	    rotate_socket_2.max_value = 3.1415927410125732
	    rotate_socket_2.subtype = 'ANGLE'
	    rotate_socket_2.attribute_domain = 'POINT'
	    rotate_socket_2.description = "Rotate twist along guide curve tangent."
	
	    #Socket Scale
	    scale_socket_3 = twist_bunz.interface.new_socket(name = "Scale", in_out='INPUT', socket_type = 'NodeSocketVector')
	    scale_socket_3.default_value = (1.0, 1.0, 1.0)
	    scale_socket_3.min_value = -3.4028234663852886e+38
	    scale_socket_3.max_value = 3.4028234663852886e+38
	    scale_socket_3.subtype = 'XYZ'
	    scale_socket_3.attribute_domain = 'POINT'
	    scale_socket_3.description = "Scale of twist."
	
	    #Socket Flip X
	    flip_x_socket_1 = twist_bunz.interface.new_socket(name = "Flip X", in_out='INPUT', socket_type = 'NodeSocketBool')
	    flip_x_socket_1.default_value = True
	    flip_x_socket_1.attribute_domain = 'POINT'
	    flip_x_socket_1.description = "Flip directection of twist based on root position."
	
	    #Socket Flip Overhang
	    flip_overhang_socket_1 = twist_bunz.interface.new_socket(name = "Flip Overhang", in_out='INPUT', socket_type = 'NodeSocketBool')
	    flip_overhang_socket_1.default_value = False
	    flip_overhang_socket_1.attribute_domain = 'POINT'
	    flip_overhang_socket_1.description = "Flip overhang direction of twist that has Flip X."
	
	    #Socket Width
	    width_socket_1 = twist_bunz.interface.new_socket(name = "Width", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    width_socket_1.default_value = 0.10000000149011612
	    width_socket_1.min_value = 0.0
	    width_socket_1.max_value = 3.4028234663852886e+38
	    width_socket_1.subtype = 'DISTANCE'
	    width_socket_1.attribute_domain = 'POINT'
	    width_socket_1.description = "Width of mesh strip."
	
	    #Socket Level
	    level_socket_2 = twist_bunz.interface.new_socket(name = "Level", in_out='INPUT', socket_type = 'NodeSocketInt')
	    level_socket_2.default_value = 1
	    level_socket_2.min_value = 0
	    level_socket_2.max_value = 6
	    level_socket_2.subtype = 'NONE'
	    level_socket_2.attribute_domain = 'POINT'
	    level_socket_2.description = "Mesh subdivision level."
	
	    #Socket Material
	    material_socket_3 = twist_bunz.interface.new_socket(name = "Material", in_out='INPUT', socket_type = 'NodeSocketMaterial')
	    material_socket_3.attribute_domain = 'POINT'
	    material_socket_3.description = "Curve material."
	
	    #Socket Strand Radius
	    strand_radius_socket_1 = twist_bunz.interface.new_socket(name = "Strand Radius", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    strand_radius_socket_1.default_value = 0.003000000026077032
	    strand_radius_socket_1.min_value = 0.0
	    strand_radius_socket_1.max_value = 10000.0
	    strand_radius_socket_1.subtype = 'NONE'
	    strand_radius_socket_1.attribute_domain = 'POINT'
	    strand_radius_socket_1.description = "Radius for hair strands."
	
	    #Socket Trim Seed
	    trim_seed_socket_1 = twist_bunz.interface.new_socket(name = "Trim Seed", in_out='INPUT', socket_type = 'NodeSocketInt')
	    trim_seed_socket_1.default_value = 0
	    trim_seed_socket_1.min_value = -10000
	    trim_seed_socket_1.max_value = 10000
	    trim_seed_socket_1.subtype = 'NONE'
	    trim_seed_socket_1.attribute_domain = 'POINT'
	    trim_seed_socket_1.description = "Random seed for hair tip trimming."
	
	    #Socket Trim Factor
	    trim_factor_socket_1 = twist_bunz.interface.new_socket(name = "Trim Factor", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    trim_factor_socket_1.default_value = 0.7666666507720947
	    trim_factor_socket_1.min_value = 0.0
	    trim_factor_socket_1.max_value = 1.0
	    trim_factor_socket_1.subtype = 'FACTOR'
	    trim_factor_socket_1.attribute_domain = 'POINT'
	    trim_factor_socket_1.description = "Minumal percentage of hair strand length to remain after random trim. (1=no trim, 0=potential full trim)"
	
	    #Socket UV Map
	    uv_map_socket_1 = twist_bunz.interface.new_socket(name = "UV Map", in_out='INPUT', socket_type = 'NodeSocketString')
	    uv_map_socket_1.default_value = "UVMap"
	    uv_map_socket_1.subtype = 'NONE'
	    uv_map_socket_1.attribute_domain = 'POINT'
	    uv_map_socket_1.description = "UV Map used to detrmine strand direction."
	
	    #Panel Children Settings
	    children_settings_panel = twist_bunz.interface.new_panel("Children Settings", default_closed=True)
	    children_settings_panel.description = "Settings for duplicate hairs."
	    #Socket Amount
	    amount_socket_1 = twist_bunz.interface.new_socket(name = "Amount", in_out='INPUT', socket_type = 'NodeSocketInt', parent = children_settings_panel)
	    amount_socket_1.default_value = 0
	    amount_socket_1.min_value = 0
	    amount_socket_1.max_value = 2147483647
	    amount_socket_1.subtype = 'NONE'
	    amount_socket_1.attribute_domain = 'POINT'
	    amount_socket_1.description = "Amount of duplicates per curve"
	
	    #Socket Viewport Amount
	    viewport_amount_socket_1 = twist_bunz.interface.new_socket(name = "Viewport Amount", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = children_settings_panel)
	    viewport_amount_socket_1.default_value = 1.0
	    viewport_amount_socket_1.min_value = 0.0
	    viewport_amount_socket_1.max_value = 1.0
	    viewport_amount_socket_1.subtype = 'FACTOR'
	    viewport_amount_socket_1.attribute_domain = 'POINT'
	    viewport_amount_socket_1.description = "Percentage of amount used for the viewport"
	
	    #Socket Radius
	    radius_socket_3 = twist_bunz.interface.new_socket(name = "Radius", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = children_settings_panel)
	    radius_socket_3.default_value = 0.10000000149011612
	    radius_socket_3.min_value = 0.0
	    radius_socket_3.max_value = 3.4028234663852886e+38
	    radius_socket_3.subtype = 'DISTANCE'
	    radius_socket_3.attribute_domain = 'POINT'
	    radius_socket_3.description = "Radius in which the duplicate curves are offset from the guides"
	
	    #Socket Distribution Shape
	    distribution_shape_socket_1 = twist_bunz.interface.new_socket(name = "Distribution Shape", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = children_settings_panel)
	    distribution_shape_socket_1.default_value = 0.0
	    distribution_shape_socket_1.min_value = -10.0
	    distribution_shape_socket_1.max_value = 10.0
	    distribution_shape_socket_1.subtype = 'NONE'
	    distribution_shape_socket_1.attribute_domain = 'POINT'
	    distribution_shape_socket_1.description = "Shape of distribution from center to the edge around the guide"
	
	    #Socket Tip Roundness
	    tip_roundness_socket_1 = twist_bunz.interface.new_socket(name = "Tip Roundness", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = children_settings_panel)
	    tip_roundness_socket_1.default_value = 0.0
	    tip_roundness_socket_1.min_value = 0.0
	    tip_roundness_socket_1.max_value = 1.0
	    tip_roundness_socket_1.subtype = 'FACTOR'
	    tip_roundness_socket_1.attribute_domain = 'POINT'
	    tip_roundness_socket_1.description = "Offset of the curves to round the tip"
	
	    #Socket Even Thickness
	    even_thickness_socket_1 = twist_bunz.interface.new_socket(name = "Even Thickness", in_out='INPUT', socket_type = 'NodeSocketBool', parent = children_settings_panel)
	    even_thickness_socket_1.default_value = False
	    even_thickness_socket_1.attribute_domain = 'POINT'
	    even_thickness_socket_1.description = "Keep an even thickness of the distribution of duplicates"
	
	    #Socket Seed
	    seed_socket_1 = twist_bunz.interface.new_socket(name = "Seed", in_out='INPUT', socket_type = 'NodeSocketInt', parent = children_settings_panel)
	    seed_socket_1.default_value = 0
	    seed_socket_1.min_value = -10000
	    seed_socket_1.max_value = 10000
	    seed_socket_1.subtype = 'NONE'
	    seed_socket_1.attribute_domain = 'POINT'
	    seed_socket_1.description = "Random Seed for the operation"
	
	
	    #Panel Mesh Settings
	    mesh_settings_panel = twist_bunz.interface.new_panel("Mesh Settings", default_closed=True)
	    mesh_settings_panel.description = "Settings for mesh Hair Styles."
	    #Socket Mesh Material
	    mesh_material_socket = twist_bunz.interface.new_socket(name = "Mesh Material", in_out='INPUT', socket_type = 'NodeSocketMaterial', parent = mesh_settings_panel)
	    mesh_material_socket.attribute_domain = 'POINT'
	    mesh_material_socket.description = "Mesh Material."
	
	    #Panel Stylized Settings
	    stylized_settings_panel = twist_bunz.interface.new_panel("Stylized Settings", default_closed=True)
	    stylized_settings_panel.description = "Settings for Stylized Hair Style."
	    #Socket Radius
	    radius_socket_4 = twist_bunz.interface.new_socket(name = "Radius", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = stylized_settings_panel)
	    radius_socket_4.default_value = 1.0
	    radius_socket_4.min_value = 0.0
	    radius_socket_4.max_value = 3.4028234663852886e+38
	    radius_socket_4.subtype = 'DISTANCE'
	    radius_socket_4.attribute_domain = 'POINT'
	    radius_socket_4.description = "Mesh Radius."
	
	    #Socket Use Enhancements
	    use_enhancements_socket_2 = twist_bunz.interface.new_socket(name = "Use Enhancements", in_out='INPUT', socket_type = 'NodeSocketBool', parent = stylized_settings_panel)
	    use_enhancements_socket_2.default_value = True
	    use_enhancements_socket_2.attribute_domain = 'POINT'
	    use_enhancements_socket_2.description = "Use Enhancement settings."
	
	    #Socket Maintain Shape Factor
	    maintain_shape_factor_socket_2 = twist_bunz.interface.new_socket(name = "Maintain Shape Factor", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = stylized_settings_panel)
	    maintain_shape_factor_socket_2.default_value = 1.0
	    maintain_shape_factor_socket_2.min_value = 0.0
	    maintain_shape_factor_socket_2.max_value = 1.0
	    maintain_shape_factor_socket_2.subtype = 'FACTOR'
	    maintain_shape_factor_socket_2.attribute_domain = 'POINT'
	    maintain_shape_factor_socket_2.description = "Factor to blend overall effect"
	
	    #Socket Pin at Parameter
	    pin_at_parameter_socket_4 = twist_bunz.interface.new_socket(name = "Pin at Parameter", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = stylized_settings_panel)
	    pin_at_parameter_socket_4.default_value = 0.0
	    pin_at_parameter_socket_4.min_value = 0.0
	    pin_at_parameter_socket_4.max_value = 1.0
	    pin_at_parameter_socket_4.subtype = 'FACTOR'
	    pin_at_parameter_socket_4.attribute_domain = 'POINT'
	    pin_at_parameter_socket_4.description = "Pin each curve at a certain point for the operation"
	
	    #Socket Snap to surface
	    snap_to_surface_socket_3 = twist_bunz.interface.new_socket(name = "Snap to surface", in_out='INPUT', socket_type = 'NodeSocketBool', parent = stylized_settings_panel)
	    snap_to_surface_socket_3.default_value = False
	    snap_to_surface_socket_3.attribute_domain = 'POINT'
	    snap_to_surface_socket_3.description = "Snap mesh roots to the nearest surface point."
	
	    #Socket Subdivison Level
	    subdivison_level_socket_1 = twist_bunz.interface.new_socket(name = "Subdivison Level", in_out='INPUT', socket_type = 'NodeSocketInt', parent = stylized_settings_panel)
	    subdivison_level_socket_1.default_value = 1
	    subdivison_level_socket_1.min_value = 0
	    subdivison_level_socket_1.max_value = 6
	    subdivison_level_socket_1.subtype = 'NONE'
	    subdivison_level_socket_1.attribute_domain = 'POINT'
	    subdivison_level_socket_1.description = "Subdivision level."
	
	    #Socket Edge Crease
	    edge_crease_socket_2 = twist_bunz.interface.new_socket(name = "Edge Crease", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = stylized_settings_panel)
	    edge_crease_socket_2.default_value = 0.0
	    edge_crease_socket_2.min_value = 0.0
	    edge_crease_socket_2.max_value = 1.0
	    edge_crease_socket_2.subtype = 'FACTOR'
	    edge_crease_socket_2.attribute_domain = 'POINT'
	    edge_crease_socket_2.description = "Edge crease factor for subdivision."
	
	    #Socket Vertex Crease
	    vertex_crease_socket_2 = twist_bunz.interface.new_socket(name = "Vertex Crease", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = stylized_settings_panel)
	    vertex_crease_socket_2.default_value = 0.0
	    vertex_crease_socket_2.min_value = 0.0
	    vertex_crease_socket_2.max_value = 1.0
	    vertex_crease_socket_2.subtype = 'FACTOR'
	    vertex_crease_socket_2.attribute_domain = 'POINT'
	    vertex_crease_socket_2.description = "Vertex crease factor for subdivision."
	
	    #Socket Limit Surface
	    limit_surface_socket_2 = twist_bunz.interface.new_socket(name = "Limit Surface", in_out='INPUT', socket_type = 'NodeSocketBool', parent = stylized_settings_panel)
	    limit_surface_socket_2.default_value = True
	    limit_surface_socket_2.attribute_domain = 'POINT'
	    limit_surface_socket_2.description = "Limit subdivision on surface."
	
	    #Socket Distance
	    distance_socket_2 = twist_bunz.interface.new_socket(name = "Distance", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = stylized_settings_panel)
	    distance_socket_2.default_value = 0.0010000000474974513
	    distance_socket_2.min_value = 0.0
	    distance_socket_2.max_value = 3.4028234663852886e+38
	    distance_socket_2.subtype = 'DISTANCE'
	    distance_socket_2.attribute_domain = 'POINT'
	    distance_socket_2.description = "Distance threshold to merge points."
	
	
	    twist_bunz.interface.move_to_parent(stylized_settings_panel, mesh_settings_panel, 28)
	    #Panel Solid Mesh Settings
	    solid_mesh_settings_panel = twist_bunz.interface.new_panel("Solid Mesh Settings", default_closed=True)
	    solid_mesh_settings_panel.description = "Settings for Solid Mesh Hair Style."
	    #Socket Curve Profiile
	    curve_profiile_socket = twist_bunz.interface.new_socket(name = "Curve Profiile", in_out='INPUT', socket_type = 'NodeSocketObject', parent = solid_mesh_settings_panel)
	    curve_profiile_socket.attribute_domain = 'POINT'
	    curve_profiile_socket.description = "Curve Profile object used for Solid Mesh Hair Style. (Optional)"
	
	    #Socket Profile Height
	    profile_height_socket = twist_bunz.interface.new_socket(name = "Profile Height", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = solid_mesh_settings_panel)
	    profile_height_socket.default_value = 0.019999999552965164
	    profile_height_socket.min_value = 0.0
	    profile_height_socket.max_value = 10000.0
	    profile_height_socket.subtype = 'NONE'
	    profile_height_socket.attribute_domain = 'POINT'
	    profile_height_socket.description = "Height scale for profile object."
	
	    #Socket Profile Width
	    profile_width_socket = twist_bunz.interface.new_socket(name = "Profile Width", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = solid_mesh_settings_panel)
	    profile_width_socket.default_value = 0.05000000074505806
	    profile_width_socket.min_value = 0.0
	    profile_width_socket.max_value = 10000.0
	    profile_width_socket.subtype = 'NONE'
	    profile_width_socket.attribute_domain = 'POINT'
	    profile_width_socket.description = "Width scale for profile object."
	
	    #Socket Resolution
	    resolution_socket_1 = twist_bunz.interface.new_socket(name = "Resolution", in_out='INPUT', socket_type = 'NodeSocketInt', parent = solid_mesh_settings_panel)
	    resolution_socket_1.default_value = 32
	    resolution_socket_1.min_value = 3
	    resolution_socket_1.max_value = 512
	    resolution_socket_1.subtype = 'NONE'
	    resolution_socket_1.attribute_domain = 'POINT'
	    resolution_socket_1.description = "Curve resolution."
	
	
	    twist_bunz.interface.move_to_parent(solid_mesh_settings_panel, mesh_settings_panel, 39)
	
	
	    #initialize twist_bunz nodes
	    #node Group Input
	    group_input_15 = twist_bunz.nodes.new("NodeGroupInput")
	    group_input_15.name = "Group Input"
	    group_input_15.outputs[1].hide = True
	    group_input_15.outputs[2].hide = True
	    group_input_15.outputs[10].hide = True
	    group_input_15.outputs[11].hide = True
	    group_input_15.outputs[12].hide = True
	    group_input_15.outputs[13].hide = True
	    group_input_15.outputs[14].hide = True
	    group_input_15.outputs[15].hide = True
	    group_input_15.outputs[16].hide = True
	    group_input_15.outputs[17].hide = True
	    group_input_15.outputs[18].hide = True
	    group_input_15.outputs[19].hide = True
	    group_input_15.outputs[20].hide = True
	    group_input_15.outputs[21].hide = True
	    group_input_15.outputs[22].hide = True
	    group_input_15.outputs[23].hide = True
	    group_input_15.outputs[24].hide = True
	    group_input_15.outputs[25].hide = True
	    group_input_15.outputs[26].hide = True
	    group_input_15.outputs[27].hide = True
	    group_input_15.outputs[28].hide = True
	    group_input_15.outputs[29].hide = True
	    group_input_15.outputs[30].hide = True
	    group_input_15.outputs[31].hide = True
	    group_input_15.outputs[32].hide = True
	    group_input_15.outputs[33].hide = True
	    group_input_15.outputs[34].hide = True
	    group_input_15.outputs[35].hide = True
	    group_input_15.outputs[36].hide = True
	    group_input_15.outputs[37].hide = True
	    group_input_15.outputs[38].hide = True
	    group_input_15.outputs[39].hide = True
	
	    #node Group Output
	    group_output_21 = twist_bunz.nodes.new("NodeGroupOutput")
	    group_output_21.name = "Group Output"
	    group_output_21.is_active_output = True
	    group_output_21.inputs[1].hide = True
	
	    #node Group
	    group_8 = twist_bunz.nodes.new("GeometryNodeGroup")
	    group_8.name = "Group"
	    group_8.node_tree = twist_bun
	
	    #node Group.001
	    group_001_6 = twist_bunz.nodes.new("GeometryNodeGroup")
	    group_001_6.name = "Group.001"
	    group_001_6.node_tree = mesh_strip
	    group_001_6.inputs[2].hide = True
	    #Socket_3
	    group_001_6.inputs[2].default_value = True
	
	    #node Group.002
	    group_002_3 = twist_bunz.nodes.new("GeometryNodeGroup")
	    group_002_3.name = "Group.002"
	    group_002_3.node_tree = mesh_to_strands
	
	    #node Group.003
	    group_003_1 = twist_bunz.nodes.new("GeometryNodeGroup")
	    group_003_1.name = "Group.003"
	    group_003_1.node_tree = curve_extrude_profile
	    group_003_1.inputs[1].hide = True
	    group_003_1.inputs[2].hide = True
	    #Socket_2
	    group_003_1.inputs[1].default_value = (0.0, 0.0, 0.0)
	    #Socket_3
	    group_003_1.inputs[2].default_value = (0.0, 0.0, 0.0)
	
	    #node Curve to Mesh
	    curve_to_mesh_3 = twist_bunz.nodes.new("GeometryNodeCurveToMesh")
	    curve_to_mesh_3.name = "Curve to Mesh"
	    #Fill Caps
	    curve_to_mesh_3.inputs[2].default_value = True
	
	    #node Switch
	    switch_7 = twist_bunz.nodes.new("GeometryNodeSwitch")
	    switch_7.name = "Switch"
	    switch_7.input_type = 'GEOMETRY'
	
	    #node Object Info
	    object_info_1 = twist_bunz.nodes.new("GeometryNodeObjectInfo")
	    object_info_1.name = "Object Info"
	    object_info_1.hide = True
	    object_info_1.transform_space = 'RELATIVE'
	    object_info_1.inputs[1].hide = True
	    object_info_1.outputs[0].hide = True
	    object_info_1.outputs[1].hide = True
	    object_info_1.outputs[2].hide = True
	    object_info_1.outputs[3].hide = True
	    #As Instance
	    object_info_1.inputs[1].default_value = False
	
	    #node Domain Size
	    domain_size_1 = twist_bunz.nodes.new("GeometryNodeAttributeDomainSize")
	    domain_size_1.name = "Domain Size"
	    domain_size_1.hide = True
	    domain_size_1.component = 'CURVE'
	    domain_size_1.outputs[1].hide = True
	    domain_size_1.outputs[2].hide = True
	    domain_size_1.outputs[3].hide = True
	    domain_size_1.outputs[4].hide = True
	    domain_size_1.outputs[5].hide = True
	    domain_size_1.outputs[6].hide = True
	
	    #node Compare
	    compare_7 = twist_bunz.nodes.new("FunctionNodeCompare")
	    compare_7.name = "Compare"
	    compare_7.hide = True
	    compare_7.data_type = 'INT'
	    compare_7.mode = 'ELEMENT'
	    compare_7.operation = 'EQUAL'
	    compare_7.inputs[0].hide = True
	    compare_7.inputs[1].hide = True
	    compare_7.inputs[3].hide = True
	    compare_7.inputs[4].hide = True
	    compare_7.inputs[5].hide = True
	    compare_7.inputs[6].hide = True
	    compare_7.inputs[7].hide = True
	    compare_7.inputs[8].hide = True
	    compare_7.inputs[9].hide = True
	    compare_7.inputs[10].hide = True
	    compare_7.inputs[11].hide = True
	    compare_7.inputs[12].hide = True
	    #B_INT
	    compare_7.inputs[3].default_value = 0
	
	    #node Combine XYZ
	    combine_xyz_3 = twist_bunz.nodes.new("ShaderNodeCombineXYZ")
	    combine_xyz_3.name = "Combine XYZ"
	    combine_xyz_3.hide = True
	    combine_xyz_3.inputs[2].hide = True
	    #Z
	    combine_xyz_3.inputs[2].default_value = 1.0
	
	    #node Hair Style
	    hair_style = twist_bunz.nodes.new("GeometryNodeMenuSwitch")
	    hair_style.label = "Hair Style"
	    hair_style.name = "Hair Style"
	    hair_style.active_index = 1
	    hair_style.data_type = 'GEOMETRY'
	    hair_style.enum_items.clear()
	    hair_style.enum_items.new("Hair Curve")
	    hair_style.enum_items[0].description = "Hair Curve Hair Style."
	    hair_style.enum_items.new("Solid Hair Curve")
	    hair_style.enum_items[1].description = "Hair Curve Hair Style from Solid Mesh."
	    hair_style.enum_items.new("Mesh Strip")
	    hair_style.enum_items[2].description = "Mesh Strip Hair Style."
	    hair_style.enum_items.new("Solid Mesh")
	    hair_style.enum_items[3].description = "Solid Mesh Hair Style."
	    hair_style.enum_items.new("Stylized")
	    hair_style.enum_items[4].description = "Stylized mesh Hair Style."
	    hair_style.inputs[6].hide = True
	
	    #node Group.005
	    group_005_2 = twist_bunz.nodes.new("GeometryNodeGroup")
	    group_005_2.name = "Group.005"
	    group_005_2.node_tree = stylized_meshify_hair
	
	    #node Group.006
	    group_006 = twist_bunz.nodes.new("GeometryNodeGroup")
	    group_006.name = "Group.006"
	    group_006.node_tree = duplicate_hair_curves
	
	    #node Store Named Attribute
	    store_named_attribute_6 = twist_bunz.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_6.name = "Store Named Attribute"
	    store_named_attribute_6.data_type = 'INT'
	    store_named_attribute_6.domain = 'CURVE'
	    #Selection
	    store_named_attribute_6.inputs[1].default_value = True
	    #Name
	    store_named_attribute_6.inputs[2].default_value = "closest_idx"
	
	    #node Group Input.001
	    group_input_001_13 = twist_bunz.nodes.new("NodeGroupInput")
	    group_input_001_13.name = "Group Input.001"
	    group_input_001_13.outputs[0].hide = True
	    group_input_001_13.outputs[1].hide = True
	    group_input_001_13.outputs[2].hide = True
	    group_input_001_13.outputs[3].hide = True
	    group_input_001_13.outputs[4].hide = True
	    group_input_001_13.outputs[5].hide = True
	    group_input_001_13.outputs[6].hide = True
	    group_input_001_13.outputs[7].hide = True
	    group_input_001_13.outputs[8].hide = True
	    group_input_001_13.outputs[9].hide = True
	    group_input_001_13.outputs[10].hide = True
	    group_input_001_13.outputs[17].hide = True
	    group_input_001_13.outputs[18].hide = True
	    group_input_001_13.outputs[19].hide = True
	    group_input_001_13.outputs[20].hide = True
	    group_input_001_13.outputs[21].hide = True
	    group_input_001_13.outputs[22].hide = True
	    group_input_001_13.outputs[23].hide = True
	    group_input_001_13.outputs[24].hide = True
	    group_input_001_13.outputs[25].hide = True
	    group_input_001_13.outputs[26].hide = True
	    group_input_001_13.outputs[27].hide = True
	    group_input_001_13.outputs[28].hide = True
	    group_input_001_13.outputs[29].hide = True
	    group_input_001_13.outputs[30].hide = True
	    group_input_001_13.outputs[31].hide = True
	    group_input_001_13.outputs[32].hide = True
	    group_input_001_13.outputs[33].hide = True
	    group_input_001_13.outputs[34].hide = True
	    group_input_001_13.outputs[35].hide = True
	    group_input_001_13.outputs[36].hide = True
	    group_input_001_13.outputs[37].hide = True
	    group_input_001_13.outputs[38].hide = True
	    group_input_001_13.outputs[39].hide = True
	
	    #node Group Input.002
	    group_input_002_10 = twist_bunz.nodes.new("NodeGroupInput")
	    group_input_002_10.name = "Group Input.002"
	    group_input_002_10.outputs[0].hide = True
	    group_input_002_10.outputs[2].hide = True
	    group_input_002_10.outputs[4].hide = True
	    group_input_002_10.outputs[5].hide = True
	    group_input_002_10.outputs[6].hide = True
	    group_input_002_10.outputs[7].hide = True
	    group_input_002_10.outputs[8].hide = True
	    group_input_002_10.outputs[9].hide = True
	    group_input_002_10.outputs[10].hide = True
	    group_input_002_10.outputs[11].hide = True
	    group_input_002_10.outputs[12].hide = True
	    group_input_002_10.outputs[13].hide = True
	    group_input_002_10.outputs[14].hide = True
	    group_input_002_10.outputs[15].hide = True
	    group_input_002_10.outputs[16].hide = True
	    group_input_002_10.outputs[17].hide = True
	    group_input_002_10.outputs[18].hide = True
	    group_input_002_10.outputs[19].hide = True
	    group_input_002_10.outputs[20].hide = True
	    group_input_002_10.outputs[21].hide = True
	    group_input_002_10.outputs[22].hide = True
	    group_input_002_10.outputs[23].hide = True
	    group_input_002_10.outputs[35].hide = True
	    group_input_002_10.outputs[36].hide = True
	    group_input_002_10.outputs[37].hide = True
	    group_input_002_10.outputs[38].hide = True
	    group_input_002_10.outputs[39].hide = True
	
	    #node Group Input.003
	    group_input_003_8 = twist_bunz.nodes.new("NodeGroupInput")
	    group_input_003_8.name = "Group Input.003"
	    group_input_003_8.outputs[0].hide = True
	    group_input_003_8.outputs[1].hide = True
	    group_input_003_8.outputs[2].hide = True
	    group_input_003_8.outputs[3].hide = True
	    group_input_003_8.outputs[4].hide = True
	    group_input_003_8.outputs[5].hide = True
	    group_input_003_8.outputs[6].hide = True
	    group_input_003_8.outputs[7].hide = True
	    group_input_003_8.outputs[8].hide = True
	    group_input_003_8.outputs[9].hide = True
	    group_input_003_8.outputs[10].hide = True
	    group_input_003_8.outputs[11].hide = True
	    group_input_003_8.outputs[12].hide = True
	    group_input_003_8.outputs[13].hide = True
	    group_input_003_8.outputs[14].hide = True
	    group_input_003_8.outputs[15].hide = True
	    group_input_003_8.outputs[16].hide = True
	    group_input_003_8.outputs[24].hide = True
	    group_input_003_8.outputs[25].hide = True
	    group_input_003_8.outputs[26].hide = True
	    group_input_003_8.outputs[27].hide = True
	    group_input_003_8.outputs[28].hide = True
	    group_input_003_8.outputs[29].hide = True
	    group_input_003_8.outputs[30].hide = True
	    group_input_003_8.outputs[31].hide = True
	    group_input_003_8.outputs[32].hide = True
	    group_input_003_8.outputs[33].hide = True
	    group_input_003_8.outputs[34].hide = True
	    group_input_003_8.outputs[35].hide = True
	    group_input_003_8.outputs[36].hide = True
	    group_input_003_8.outputs[37].hide = True
	    group_input_003_8.outputs[38].hide = True
	    group_input_003_8.outputs[39].hide = True
	
	    #node Group Input.004
	    group_input_004_5 = twist_bunz.nodes.new("NodeGroupInput")
	    group_input_004_5.name = "Group Input.004"
	    group_input_004_5.outputs[0].hide = True
	    group_input_004_5.outputs[1].hide = True
	    group_input_004_5.outputs[3].hide = True
	    group_input_004_5.outputs[4].hide = True
	    group_input_004_5.outputs[5].hide = True
	    group_input_004_5.outputs[6].hide = True
	    group_input_004_5.outputs[7].hide = True
	    group_input_004_5.outputs[8].hide = True
	    group_input_004_5.outputs[9].hide = True
	    group_input_004_5.outputs[10].hide = True
	    group_input_004_5.outputs[11].hide = True
	    group_input_004_5.outputs[12].hide = True
	    group_input_004_5.outputs[13].hide = True
	    group_input_004_5.outputs[14].hide = True
	    group_input_004_5.outputs[15].hide = True
	    group_input_004_5.outputs[16].hide = True
	    group_input_004_5.outputs[17].hide = True
	    group_input_004_5.outputs[18].hide = True
	    group_input_004_5.outputs[19].hide = True
	    group_input_004_5.outputs[20].hide = True
	    group_input_004_5.outputs[21].hide = True
	    group_input_004_5.outputs[22].hide = True
	    group_input_004_5.outputs[23].hide = True
	    group_input_004_5.outputs[24].hide = True
	    group_input_004_5.outputs[25].hide = True
	    group_input_004_5.outputs[26].hide = True
	    group_input_004_5.outputs[27].hide = True
	    group_input_004_5.outputs[28].hide = True
	    group_input_004_5.outputs[29].hide = True
	    group_input_004_5.outputs[30].hide = True
	    group_input_004_5.outputs[31].hide = True
	    group_input_004_5.outputs[32].hide = True
	    group_input_004_5.outputs[33].hide = True
	    group_input_004_5.outputs[34].hide = True
	    group_input_004_5.outputs[35].hide = True
	    group_input_004_5.outputs[36].hide = True
	    group_input_004_5.outputs[37].hide = True
	    group_input_004_5.outputs[38].hide = True
	    group_input_004_5.outputs[39].hide = True
	
	    #node Group Input.005
	    group_input_005_7 = twist_bunz.nodes.new("NodeGroupInput")
	    group_input_005_7.name = "Group Input.005"
	    group_input_005_7.outputs[0].hide = True
	    group_input_005_7.outputs[1].hide = True
	    group_input_005_7.outputs[2].hide = True
	    group_input_005_7.outputs[3].hide = True
	    group_input_005_7.outputs[4].hide = True
	    group_input_005_7.outputs[5].hide = True
	    group_input_005_7.outputs[6].hide = True
	    group_input_005_7.outputs[7].hide = True
	    group_input_005_7.outputs[8].hide = True
	    group_input_005_7.outputs[9].hide = True
	    group_input_005_7.outputs[11].hide = True
	    group_input_005_7.outputs[12].hide = True
	    group_input_005_7.outputs[13].hide = True
	    group_input_005_7.outputs[14].hide = True
	    group_input_005_7.outputs[15].hide = True
	    group_input_005_7.outputs[16].hide = True
	    group_input_005_7.outputs[17].hide = True
	    group_input_005_7.outputs[18].hide = True
	    group_input_005_7.outputs[19].hide = True
	    group_input_005_7.outputs[20].hide = True
	    group_input_005_7.outputs[21].hide = True
	    group_input_005_7.outputs[22].hide = True
	    group_input_005_7.outputs[23].hide = True
	    group_input_005_7.outputs[25].hide = True
	    group_input_005_7.outputs[26].hide = True
	    group_input_005_7.outputs[27].hide = True
	    group_input_005_7.outputs[28].hide = True
	    group_input_005_7.outputs[29].hide = True
	    group_input_005_7.outputs[30].hide = True
	    group_input_005_7.outputs[31].hide = True
	    group_input_005_7.outputs[32].hide = True
	    group_input_005_7.outputs[33].hide = True
	    group_input_005_7.outputs[34].hide = True
	    group_input_005_7.outputs[35].hide = True
	    group_input_005_7.outputs[36].hide = True
	    group_input_005_7.outputs[37].hide = True
	    group_input_005_7.outputs[38].hide = True
	    group_input_005_7.outputs[39].hide = True
	
	    #node Group Input.006
	    group_input_006_5 = twist_bunz.nodes.new("NodeGroupInput")
	    group_input_006_5.name = "Group Input.006"
	    group_input_006_5.outputs[0].hide = True
	    group_input_006_5.outputs[1].hide = True
	    group_input_006_5.outputs[2].hide = True
	    group_input_006_5.outputs[3].hide = True
	    group_input_006_5.outputs[4].hide = True
	    group_input_006_5.outputs[5].hide = True
	    group_input_006_5.outputs[6].hide = True
	    group_input_006_5.outputs[7].hide = True
	    group_input_006_5.outputs[8].hide = True
	    group_input_006_5.outputs[9].hide = True
	    group_input_006_5.outputs[10].hide = True
	    group_input_006_5.outputs[11].hide = True
	    group_input_006_5.outputs[12].hide = True
	    group_input_006_5.outputs[13].hide = True
	    group_input_006_5.outputs[14].hide = True
	    group_input_006_5.outputs[15].hide = True
	    group_input_006_5.outputs[16].hide = True
	    group_input_006_5.outputs[17].hide = True
	    group_input_006_5.outputs[18].hide = True
	    group_input_006_5.outputs[19].hide = True
	    group_input_006_5.outputs[20].hide = True
	    group_input_006_5.outputs[21].hide = True
	    group_input_006_5.outputs[22].hide = True
	    group_input_006_5.outputs[23].hide = True
	    group_input_006_5.outputs[24].hide = True
	    group_input_006_5.outputs[25].hide = True
	    group_input_006_5.outputs[26].hide = True
	    group_input_006_5.outputs[27].hide = True
	    group_input_006_5.outputs[28].hide = True
	    group_input_006_5.outputs[29].hide = True
	    group_input_006_5.outputs[30].hide = True
	    group_input_006_5.outputs[31].hide = True
	    group_input_006_5.outputs[32].hide = True
	    group_input_006_5.outputs[33].hide = True
	    group_input_006_5.outputs[34].hide = True
	    group_input_006_5.outputs[39].hide = True
	
	    #node Final Bake
	    final_bake = twist_bunz.nodes.new("GeometryNodeBake")
	    final_bake.label = "Final Bake"
	    final_bake.name = "Final Bake"
	    final_bake.active_index = 0
	    final_bake.bake_items.clear()
	    final_bake.bake_items.new('GEOMETRY', "Geometry")
	    final_bake.bake_items[0].attribute_domain = 'POINT'
	    final_bake.inputs[1].hide = True
	    final_bake.outputs[1].hide = True
	
	    #node Separate Components
	    separate_components_2 = twist_bunz.nodes.new("GeometryNodeSeparateComponents")
	    separate_components_2.name = "Separate Components"
	    separate_components_2.hide = True
	
	    #node Join Geometry
	    join_geometry_4 = twist_bunz.nodes.new("GeometryNodeJoinGeometry")
	    join_geometry_4.name = "Join Geometry"
	    join_geometry_4.hide = True
	
	    #node Reroute
	    reroute_9 = twist_bunz.nodes.new("NodeReroute")
	    reroute_9.name = "Reroute"
	    reroute_9.socket_idname = "NodeSocketGeometry"
	    #node Reroute.001
	    reroute_001_9 = twist_bunz.nodes.new("NodeReroute")
	    reroute_001_9.name = "Reroute.001"
	    reroute_001_9.socket_idname = "NodeSocketGeometry"
	    #node Reroute.002
	    reroute_002_5 = twist_bunz.nodes.new("NodeReroute")
	    reroute_002_5.name = "Reroute.002"
	    reroute_002_5.socket_idname = "NodeSocketGeometry"
	    #node Reroute.003
	    reroute_003_4 = twist_bunz.nodes.new("NodeReroute")
	    reroute_003_4.name = "Reroute.003"
	    reroute_003_4.socket_idname = "NodeSocketGeometry"
	    #node Reroute.004
	    reroute_004_6 = twist_bunz.nodes.new("NodeReroute")
	    reroute_004_6.name = "Reroute.004"
	    reroute_004_6.socket_idname = "NodeSocketGeometry"
	    #node Reroute.005
	    reroute_005_5 = twist_bunz.nodes.new("NodeReroute")
	    reroute_005_5.name = "Reroute.005"
	    reroute_005_5.socket_idname = "NodeSocketGeometry"
	    #node Reroute.006
	    reroute_006_5 = twist_bunz.nodes.new("NodeReroute")
	    reroute_006_5.name = "Reroute.006"
	    reroute_006_5.socket_idname = "NodeSocketGeometry"
	    #node Reroute.007
	    reroute_007_5 = twist_bunz.nodes.new("NodeReroute")
	    reroute_007_5.name = "Reroute.007"
	    reroute_007_5.socket_idname = "NodeSocketGeometry"
	    #node Reroute.008
	    reroute_008_5 = twist_bunz.nodes.new("NodeReroute")
	    reroute_008_5.name = "Reroute.008"
	    reroute_008_5.socket_idname = "NodeSocketGeometry"
	    #node Reroute.009
	    reroute_009_5 = twist_bunz.nodes.new("NodeReroute")
	    reroute_009_5.name = "Reroute.009"
	    reroute_009_5.socket_idname = "NodeSocketGeometry"
	    #node Transform Geometry
	    transform_geometry_3 = twist_bunz.nodes.new("GeometryNodeTransform")
	    transform_geometry_3.name = "Transform Geometry"
	    transform_geometry_3.hide = True
	    transform_geometry_3.mode = 'COMPONENTS'
	    transform_geometry_3.inputs[1].hide = True
	    transform_geometry_3.inputs[2].hide = True
	    transform_geometry_3.inputs[4].hide = True
	    #Translation
	    transform_geometry_3.inputs[1].default_value = (0.0, 0.0, 0.0)
	    #Rotation
	    transform_geometry_3.inputs[2].default_value = (0.0, 0.0, 0.0)
	
	    #node Resample Curve
	    resample_curve_3 = twist_bunz.nodes.new("GeometryNodeResampleCurve")
	    resample_curve_3.name = "Resample Curve"
	    resample_curve_3.hide = True
	    resample_curve_3.keep_last_segment = True
	    resample_curve_3.mode = 'COUNT'
	    resample_curve_3.inputs[1].hide = True
	    resample_curve_3.inputs[3].hide = True
	    #Selection
	    resample_curve_3.inputs[1].default_value = True
	
	    #node Group Input.007
	    group_input_007_3 = twist_bunz.nodes.new("NodeGroupInput")
	    group_input_007_3.name = "Group Input.007"
	    group_input_007_3.outputs[0].hide = True
	    group_input_007_3.outputs[1].hide = True
	    group_input_007_3.outputs[2].hide = True
	    group_input_007_3.outputs[3].hide = True
	    group_input_007_3.outputs[4].hide = True
	    group_input_007_3.outputs[5].hide = True
	    group_input_007_3.outputs[6].hide = True
	    group_input_007_3.outputs[7].hide = True
	    group_input_007_3.outputs[8].hide = True
	    group_input_007_3.outputs[9].hide = True
	    group_input_007_3.outputs[10].hide = True
	    group_input_007_3.outputs[11].hide = True
	    group_input_007_3.outputs[12].hide = True
	    group_input_007_3.outputs[13].hide = True
	    group_input_007_3.outputs[14].hide = True
	    group_input_007_3.outputs[15].hide = True
	    group_input_007_3.outputs[16].hide = True
	    group_input_007_3.outputs[17].hide = True
	    group_input_007_3.outputs[18].hide = True
	    group_input_007_3.outputs[19].hide = True
	    group_input_007_3.outputs[20].hide = True
	    group_input_007_3.outputs[21].hide = True
	    group_input_007_3.outputs[22].hide = True
	    group_input_007_3.outputs[23].hide = True
	    group_input_007_3.outputs[24].hide = True
	    group_input_007_3.outputs[25].hide = True
	    group_input_007_3.outputs[26].hide = True
	    group_input_007_3.outputs[27].hide = True
	    group_input_007_3.outputs[28].hide = True
	    group_input_007_3.outputs[29].hide = True
	    group_input_007_3.outputs[30].hide = True
	    group_input_007_3.outputs[31].hide = True
	    group_input_007_3.outputs[32].hide = True
	    group_input_007_3.outputs[33].hide = True
	    group_input_007_3.outputs[34].hide = True
	    group_input_007_3.outputs[35].hide = True
	    group_input_007_3.outputs[36].hide = True
	    group_input_007_3.outputs[37].hide = True
	    group_input_007_3.outputs[39].hide = True
	
	    #node Reroute.010
	    reroute_010_4 = twist_bunz.nodes.new("NodeReroute")
	    reroute_010_4.name = "Reroute.010"
	    reroute_010_4.socket_idname = "NodeSocketGeometry"
	    #node Group.004
	    group_004_2 = twist_bunz.nodes.new("GeometryNodeGroup")
	    group_004_2.name = "Group.004"
	    group_004_2.node_tree = attach_hair_curves_to_surface
	    group_004_2.inputs[1].hide = True
	    group_004_2.inputs[4].hide = True
	    group_004_2.inputs[5].hide = True
	    group_004_2.inputs[6].hide = True
	    group_004_2.inputs[7].hide = True
	    group_004_2.inputs[8].hide = True
	    group_004_2.outputs[1].hide = True
	    group_004_2.outputs[2].hide = True
	    #Input_6
	    group_004_2.inputs[4].default_value = False
	    #Input_10
	    group_004_2.inputs[5].default_value = True
	    #Input_8
	    group_004_2.inputs[6].default_value = True
	    #Input_7
	    group_004_2.inputs[7].default_value = False
	    #Input_12
	    group_004_2.inputs[8].default_value = 0.0
	
	    #node Named Attribute
	    named_attribute_7 = twist_bunz.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute_7.name = "Named Attribute"
	    named_attribute_7.hide = True
	    named_attribute_7.data_type = 'FLOAT_VECTOR'
	
	    #node Group Input.008
	    group_input_008_3 = twist_bunz.nodes.new("NodeGroupInput")
	    group_input_008_3.name = "Group Input.008"
	    group_input_008_3.outputs[0].hide = True
	    group_input_008_3.outputs[2].hide = True
	    group_input_008_3.outputs[3].hide = True
	    group_input_008_3.outputs[4].hide = True
	    group_input_008_3.outputs[5].hide = True
	    group_input_008_3.outputs[6].hide = True
	    group_input_008_3.outputs[7].hide = True
	    group_input_008_3.outputs[8].hide = True
	    group_input_008_3.outputs[9].hide = True
	    group_input_008_3.outputs[10].hide = True
	    group_input_008_3.outputs[11].hide = True
	    group_input_008_3.outputs[12].hide = True
	    group_input_008_3.outputs[13].hide = True
	    group_input_008_3.outputs[14].hide = True
	    group_input_008_3.outputs[15].hide = True
	    group_input_008_3.outputs[17].hide = True
	    group_input_008_3.outputs[18].hide = True
	    group_input_008_3.outputs[19].hide = True
	    group_input_008_3.outputs[20].hide = True
	    group_input_008_3.outputs[21].hide = True
	    group_input_008_3.outputs[22].hide = True
	    group_input_008_3.outputs[23].hide = True
	    group_input_008_3.outputs[24].hide = True
	    group_input_008_3.outputs[25].hide = True
	    group_input_008_3.outputs[26].hide = True
	    group_input_008_3.outputs[27].hide = True
	    group_input_008_3.outputs[28].hide = True
	    group_input_008_3.outputs[29].hide = True
	    group_input_008_3.outputs[30].hide = True
	    group_input_008_3.outputs[31].hide = True
	    group_input_008_3.outputs[32].hide = True
	    group_input_008_3.outputs[33].hide = True
	    group_input_008_3.outputs[34].hide = True
	    group_input_008_3.outputs[35].hide = True
	    group_input_008_3.outputs[36].hide = True
	    group_input_008_3.outputs[37].hide = True
	    group_input_008_3.outputs[38].hide = True
	    group_input_008_3.outputs[39].hide = True
	
	    #node Set Curve Radius
	    set_curve_radius_3 = twist_bunz.nodes.new("GeometryNodeSetCurveRadius")
	    set_curve_radius_3.name = "Set Curve Radius"
	    #Selection
	    set_curve_radius_3.inputs[1].default_value = True
	
	    #node Solid Mesh Shape
	    solid_mesh_shape = twist_bunz.nodes.new("ShaderNodeFloatCurve")
	    solid_mesh_shape.label = "Solid Mesh Shape"
	    solid_mesh_shape.name = "Solid Mesh Shape"
	    #mapping settings
	    solid_mesh_shape.mapping.extend = 'EXTRAPOLATED'
	    solid_mesh_shape.mapping.tone = 'STANDARD'
	    solid_mesh_shape.mapping.black_level = (0.0, 0.0, 0.0)
	    solid_mesh_shape.mapping.white_level = (1.0, 1.0, 1.0)
	    solid_mesh_shape.mapping.clip_min_x = 0.0
	    solid_mesh_shape.mapping.clip_min_y = 0.0
	    solid_mesh_shape.mapping.clip_max_x = 1.0
	    solid_mesh_shape.mapping.clip_max_y = 1.0
	    solid_mesh_shape.mapping.use_clip = True
	    #curve 0
	    solid_mesh_shape_curve_0 = solid_mesh_shape.mapping.curves[0]
	    solid_mesh_shape_curve_0_point_0 = solid_mesh_shape_curve_0.points[0]
	    solid_mesh_shape_curve_0_point_0.location = (0.0, 1.0)
	    solid_mesh_shape_curve_0_point_0.handle_type = 'AUTO'
	    solid_mesh_shape_curve_0_point_1 = solid_mesh_shape_curve_0.points[1]
	    solid_mesh_shape_curve_0_point_1.location = (1.0, 1.0)
	    solid_mesh_shape_curve_0_point_1.handle_type = 'AUTO'
	    #update curve after changes
	    solid_mesh_shape.mapping.update()
	    solid_mesh_shape.inputs[0].hide = True
	    #Factor
	    solid_mesh_shape.inputs[0].default_value = 1.0
	
	    #node Spline Parameter
	    spline_parameter_4 = twist_bunz.nodes.new("GeometryNodeSplineParameter")
	    spline_parameter_4.name = "Spline Parameter"
	    spline_parameter_4.outputs[1].hide = True
	    spline_parameter_4.outputs[2].hide = True
	
	    #node Set Curve Tilt
	    set_curve_tilt = twist_bunz.nodes.new("GeometryNodeSetCurveTilt")
	    set_curve_tilt.name = "Set Curve Tilt"
	    set_curve_tilt.hide = True
	    set_curve_tilt.inputs[1].hide = True
	    #Selection
	    set_curve_tilt.inputs[1].default_value = True
	
	    #node Group.007
	    group_007_1 = twist_bunz.nodes.new("GeometryNodeGroup")
	    group_007_1.name = "Group.007"
	    group_007_1.node_tree = mesh_to_strands
	
	    #node Capture Attribute
	    capture_attribute_3 = twist_bunz.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_3.name = "Capture Attribute"
	    capture_attribute_3.hide = True
	    capture_attribute_3.active_index = 0
	    capture_attribute_3.capture_items.clear()
	    capture_attribute_3.capture_items.new('FLOAT', "Factor")
	    capture_attribute_3.capture_items["Factor"].data_type = 'FLOAT'
	    capture_attribute_3.domain = 'POINT'
	
	    #node Spline Parameter.001
	    spline_parameter_001_3 = twist_bunz.nodes.new("GeometryNodeSplineParameter")
	    spline_parameter_001_3.name = "Spline Parameter.001"
	    spline_parameter_001_3.outputs[1].hide = True
	    spline_parameter_001_3.outputs[2].hide = True
	
	    #node Capture Attribute.001
	    capture_attribute_001_3 = twist_bunz.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_001_3.name = "Capture Attribute.001"
	    capture_attribute_001_3.hide = True
	    capture_attribute_001_3.active_index = 0
	    capture_attribute_001_3.capture_items.clear()
	    capture_attribute_001_3.capture_items.new('FLOAT', "Factor")
	    capture_attribute_001_3.capture_items["Factor"].data_type = 'FLOAT'
	    capture_attribute_001_3.domain = 'POINT'
	
	    #node Store Named Attribute.001
	    store_named_attribute_001_1 = twist_bunz.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_001_1.name = "Store Named Attribute.001"
	    store_named_attribute_001_1.data_type = 'FLOAT2'
	    store_named_attribute_001_1.domain = 'CORNER'
	    #Selection
	    store_named_attribute_001_1.inputs[1].default_value = True
	    #Name
	    store_named_attribute_001_1.inputs[2].default_value = "UVMap"
	
	    #node Combine XYZ.001
	    combine_xyz_001_4 = twist_bunz.nodes.new("ShaderNodeCombineXYZ")
	    combine_xyz_001_4.name = "Combine XYZ.001"
	    combine_xyz_001_4.hide = True
	    combine_xyz_001_4.inputs[2].hide = True
	    #Z
	    combine_xyz_001_4.inputs[2].default_value = 0.0
	
	    #node Group Input.009
	    group_input_009_2 = twist_bunz.nodes.new("NodeGroupInput")
	    group_input_009_2.name = "Group Input.009"
	    group_input_009_2.outputs[0].hide = True
	    group_input_009_2.outputs[1].hide = True
	    group_input_009_2.outputs[2].hide = True
	    group_input_009_2.outputs[3].hide = True
	    group_input_009_2.outputs[4].hide = True
	    group_input_009_2.outputs[5].hide = True
	    group_input_009_2.outputs[6].hide = True
	    group_input_009_2.outputs[7].hide = True
	    group_input_009_2.outputs[8].hide = True
	    group_input_009_2.outputs[9].hide = True
	    group_input_009_2.outputs[10].hide = True
	    group_input_009_2.outputs[17].hide = True
	    group_input_009_2.outputs[18].hide = True
	    group_input_009_2.outputs[19].hide = True
	    group_input_009_2.outputs[20].hide = True
	    group_input_009_2.outputs[21].hide = True
	    group_input_009_2.outputs[22].hide = True
	    group_input_009_2.outputs[23].hide = True
	    group_input_009_2.outputs[24].hide = True
	    group_input_009_2.outputs[25].hide = True
	    group_input_009_2.outputs[26].hide = True
	    group_input_009_2.outputs[27].hide = True
	    group_input_009_2.outputs[28].hide = True
	    group_input_009_2.outputs[29].hide = True
	    group_input_009_2.outputs[30].hide = True
	    group_input_009_2.outputs[31].hide = True
	    group_input_009_2.outputs[32].hide = True
	    group_input_009_2.outputs[33].hide = True
	    group_input_009_2.outputs[34].hide = True
	    group_input_009_2.outputs[35].hide = True
	    group_input_009_2.outputs[36].hide = True
	    group_input_009_2.outputs[37].hide = True
	    group_input_009_2.outputs[38].hide = True
	    group_input_009_2.outputs[39].hide = True
	
	    #node Group.008
	    group_008 = twist_bunz.nodes.new("GeometryNodeGroup")
	    group_008.name = "Group.008"
	    group_008.node_tree = attach_hair_curves_to_surface
	    group_008.inputs[1].hide = True
	    group_008.inputs[4].hide = True
	    group_008.inputs[5].hide = True
	    group_008.inputs[6].hide = True
	    group_008.inputs[7].hide = True
	    group_008.inputs[8].hide = True
	    group_008.outputs[1].hide = True
	    group_008.outputs[2].hide = True
	    #Input_6
	    group_008.inputs[4].default_value = False
	    #Input_10
	    group_008.inputs[5].default_value = True
	    #Input_8
	    group_008.inputs[6].default_value = True
	    #Input_7
	    group_008.inputs[7].default_value = False
	    #Input_12
	    group_008.inputs[8].default_value = 0.0
	
	    #node Named Attribute.001
	    named_attribute_001_3 = twist_bunz.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute_001_3.name = "Named Attribute.001"
	    named_attribute_001_3.hide = True
	    named_attribute_001_3.data_type = 'FLOAT_VECTOR'
	
	    #node Group Input.010
	    group_input_010_1 = twist_bunz.nodes.new("NodeGroupInput")
	    group_input_010_1.name = "Group Input.010"
	    group_input_010_1.outputs[0].hide = True
	    group_input_010_1.outputs[2].hide = True
	    group_input_010_1.outputs[3].hide = True
	    group_input_010_1.outputs[4].hide = True
	    group_input_010_1.outputs[5].hide = True
	    group_input_010_1.outputs[6].hide = True
	    group_input_010_1.outputs[7].hide = True
	    group_input_010_1.outputs[8].hide = True
	    group_input_010_1.outputs[9].hide = True
	    group_input_010_1.outputs[10].hide = True
	    group_input_010_1.outputs[11].hide = True
	    group_input_010_1.outputs[12].hide = True
	    group_input_010_1.outputs[13].hide = True
	    group_input_010_1.outputs[14].hide = True
	    group_input_010_1.outputs[15].hide = True
	    group_input_010_1.outputs[17].hide = True
	    group_input_010_1.outputs[18].hide = True
	    group_input_010_1.outputs[19].hide = True
	    group_input_010_1.outputs[20].hide = True
	    group_input_010_1.outputs[21].hide = True
	    group_input_010_1.outputs[22].hide = True
	    group_input_010_1.outputs[23].hide = True
	    group_input_010_1.outputs[24].hide = True
	    group_input_010_1.outputs[25].hide = True
	    group_input_010_1.outputs[26].hide = True
	    group_input_010_1.outputs[27].hide = True
	    group_input_010_1.outputs[28].hide = True
	    group_input_010_1.outputs[29].hide = True
	    group_input_010_1.outputs[30].hide = True
	    group_input_010_1.outputs[31].hide = True
	    group_input_010_1.outputs[32].hide = True
	    group_input_010_1.outputs[33].hide = True
	    group_input_010_1.outputs[34].hide = True
	    group_input_010_1.outputs[35].hide = True
	    group_input_010_1.outputs[36].hide = True
	    group_input_010_1.outputs[37].hide = True
	    group_input_010_1.outputs[38].hide = True
	    group_input_010_1.outputs[39].hide = True
	
	    #node Set Material
	    set_material_2 = twist_bunz.nodes.new("GeometryNodeSetMaterial")
	    set_material_2.name = "Set Material"
	    set_material_2.hide = True
	    set_material_2.inputs[1].hide = True
	    #Selection
	    set_material_2.inputs[1].default_value = True
	
	    #node Group Input.011
	    group_input_011 = twist_bunz.nodes.new("NodeGroupInput")
	    group_input_011.name = "Group Input.011"
	    group_input_011.outputs[0].hide = True
	    group_input_011.outputs[1].hide = True
	    group_input_011.outputs[2].hide = True
	    group_input_011.outputs[3].hide = True
	    group_input_011.outputs[4].hide = True
	    group_input_011.outputs[5].hide = True
	    group_input_011.outputs[6].hide = True
	    group_input_011.outputs[7].hide = True
	    group_input_011.outputs[8].hide = True
	    group_input_011.outputs[9].hide = True
	    group_input_011.outputs[10].hide = True
	    group_input_011.outputs[11].hide = True
	    group_input_011.outputs[12].hide = True
	    group_input_011.outputs[13].hide = True
	    group_input_011.outputs[14].hide = True
	    group_input_011.outputs[15].hide = True
	    group_input_011.outputs[16].hide = True
	    group_input_011.outputs[17].hide = True
	    group_input_011.outputs[18].hide = True
	    group_input_011.outputs[19].hide = True
	    group_input_011.outputs[20].hide = True
	    group_input_011.outputs[21].hide = True
	    group_input_011.outputs[22].hide = True
	    group_input_011.outputs[23].hide = True
	    group_input_011.outputs[25].hide = True
	    group_input_011.outputs[26].hide = True
	    group_input_011.outputs[27].hide = True
	    group_input_011.outputs[28].hide = True
	    group_input_011.outputs[29].hide = True
	    group_input_011.outputs[30].hide = True
	    group_input_011.outputs[31].hide = True
	    group_input_011.outputs[32].hide = True
	    group_input_011.outputs[33].hide = True
	    group_input_011.outputs[34].hide = True
	    group_input_011.outputs[35].hide = True
	    group_input_011.outputs[36].hide = True
	    group_input_011.outputs[37].hide = True
	    group_input_011.outputs[38].hide = True
	    group_input_011.outputs[39].hide = True
	
	
	
	
	
	    #Set locations
	    group_input_15.location = (-340.0, 0.0)
	    group_output_21.location = (2289.21630859375, 8.625770568847656)
	    group_8.location = (-159.99998474121094, 46.0576171875)
	    group_001_6.location = (62.623985290527344, 215.7135009765625)
	    group_002_3.location = (390.5885009765625, 262.47113037109375)
	    group_003_1.location = (-162.7466278076172, -322.9830322265625)
	    curve_to_mesh_3.location = (686.344970703125, -130.87326049804688)
	    switch_7.location = (256.565185546875, -178.2811737060547)
	    object_info_1.location = (-161.4592742919922, -279.69940185546875)
	    domain_size_1.location = (-161.48036193847656, -245.139404296875)
	    compare_7.location = (-157.4217987060547, -193.76319885253906)
	    combine_xyz_3.location = (-165.40821838378906, -448.86993408203125)
	    hair_style.location = (1941.8690185546875, 7.645576477050781)
	    group_005_2.location = (1941.2120361328125, -205.94482421875)
	    group_006.location = (756.210205078125, 333.2106018066406)
	    store_named_attribute_6.location = (1640.4351806640625, -173.82113647460938)
	    group_input_001_13.location = (214.53564453125, 169.16622924804688)
	    group_input_002_10.location = (1640.5501708984375, -369.1543273925781)
	    group_input_003_8.location = (568.2277221679688, 218.10760498046875)
	    group_input_004_5.location = (1942.2857666015625, 64.08786010742188)
	    group_input_005_7.location = (-157.03494262695312, 169.21929931640625)
	    group_input_006_5.location = (-343.27020263671875, -304.11102294921875)
	    final_bake.location = (2119.08203125, 55.26063919067383)
	    separate_components_2.location = (-338.1353454589844, 40.44830322265625)
	    join_geometry_4.location = (1755.7232666015625, -60.351585388183594)
	    reroute_9.location = (-75.23052978515625, 427.626708984375)
	    reroute_001_9.location = (-75.15135192871094, 407.4405517578125)
	    reroute_002_5.location = (-75.23052978515625, 422.1715087890625)
	    reroute_003_4.location = (-75.23052978515625, 412.1715087890625)
	    reroute_004_6.location = (-75.23052978515625, 417.10284423828125)
	    reroute_005_5.location = (1565.0357666015625, 430.96295166015625)
	    reroute_006_5.location = (1565.7257080078125, 420.95989990234375)
	    reroute_007_5.location = (1565.7257080078125, 410.9633483886719)
	    reroute_008_5.location = (1565.7257080078125, 415.9605407714844)
	    reroute_009_5.location = (1565.7257080078125, 425.9605407714844)
	    transform_geometry_3.location = (29.532211303710938, -272.95660400390625)
	    resample_curve_3.location = (29.532272338867188, -308.2303161621094)
	    group_input_007_3.location = (28.878681182861328, -337.7432556152344)
	    reroute_010_4.location = (1239.0877685546875, 346.24102783203125)
	    group_004_2.location = (1075.4771728515625, 380.0903625488281)
	    named_attribute_7.location = (1075.740478515625, 214.59423828125)
	    group_input_008_3.location = (910.6787719726562, 283.5146789550781)
	    set_curve_radius_3.location = (257.1572570800781, -50.036102294921875)
	    solid_mesh_shape.location = (19.2242374420166, -401.6083679199219)
	    spline_parameter_4.location = (14.918487548828125, -697.124267578125)
	    set_curve_tilt.location = (-339.4072265625, 101.9073486328125)
	    group_007_1.location = (1044.25732421875, -228.792236328125)
	    capture_attribute_3.location = (447.7491455078125, -210.23956298828125)
	    spline_parameter_001_3.location = (447.82513427734375, -119.593017578125)
	    capture_attribute_001_3.location = (447.7491455078125, -82.2638931274414)
	    store_named_attribute_001_1.location = (871.3847045898438, -130.54653930664062)
	    combine_xyz_001_4.location = (687.110107421875, -259.8515625)
	    group_input_009_2.location = (867.7161865234375, -330.0544128417969)
	    group_008.location = (1353.3958740234375, -177.78274536132812)
	    named_attribute_001_3.location = (1353.6590576171875, -343.27886962890625)
	    group_input_010_1.location = (1188.597412109375, -274.3583984375)
	    set_material_2.location = (1197.0223388671875, -151.82687377929688)
	    group_input_011.location = (1195.8304443359375, -182.1947784423828)
	
	    #Set dimensions
	    group_input_15.width, group_input_15.height = 140.0, 100.0
	    group_output_21.width, group_output_21.height = 140.0, 100.0
	    group_8.width, group_8.height = 140.0, 100.0
	    group_001_6.width, group_001_6.height = 140.0, 100.0
	    group_002_3.width, group_002_3.height = 140.0, 100.0
	    group_003_1.width, group_003_1.height = 140.0, 100.0
	    curve_to_mesh_3.width, curve_to_mesh_3.height = 140.0, 100.0
	    switch_7.width, switch_7.height = 140.0, 100.0
	    object_info_1.width, object_info_1.height = 140.0, 100.0
	    domain_size_1.width, domain_size_1.height = 140.0, 100.0
	    compare_7.width, compare_7.height = 140.0, 100.0
	    combine_xyz_3.width, combine_xyz_3.height = 140.0, 100.0
	    hair_style.width, hair_style.height = 140.0, 100.0
	    group_005_2.width, group_005_2.height = 140.0, 100.0
	    group_006.width, group_006.height = 140.0, 100.0
	    store_named_attribute_6.width, store_named_attribute_6.height = 140.0, 100.0
	    group_input_001_13.width, group_input_001_13.height = 140.0, 100.0
	    group_input_002_10.width, group_input_002_10.height = 140.0, 100.0
	    group_input_003_8.width, group_input_003_8.height = 140.0, 100.0
	    group_input_004_5.width, group_input_004_5.height = 140.0, 100.0
	    group_input_005_7.width, group_input_005_7.height = 140.0, 100.0
	    group_input_006_5.width, group_input_006_5.height = 140.0, 100.0
	    final_bake.width, final_bake.height = 140.0, 100.0
	    separate_components_2.width, separate_components_2.height = 140.0, 100.0
	    join_geometry_4.width, join_geometry_4.height = 140.0, 100.0
	    reroute_9.width, reroute_9.height = 10.0, 100.0
	    reroute_001_9.width, reroute_001_9.height = 10.0, 100.0
	    reroute_002_5.width, reroute_002_5.height = 10.0, 100.0
	    reroute_003_4.width, reroute_003_4.height = 10.0, 100.0
	    reroute_004_6.width, reroute_004_6.height = 10.0, 100.0
	    reroute_005_5.width, reroute_005_5.height = 10.0, 100.0
	    reroute_006_5.width, reroute_006_5.height = 10.0, 100.0
	    reroute_007_5.width, reroute_007_5.height = 10.0, 100.0
	    reroute_008_5.width, reroute_008_5.height = 10.0, 100.0
	    reroute_009_5.width, reroute_009_5.height = 10.0, 100.0
	    transform_geometry_3.width, transform_geometry_3.height = 140.0, 100.0
	    resample_curve_3.width, resample_curve_3.height = 140.0, 100.0
	    group_input_007_3.width, group_input_007_3.height = 140.0, 100.0
	    reroute_010_4.width, reroute_010_4.height = 10.0, 100.0
	    group_004_2.width, group_004_2.height = 140.0, 100.0
	    named_attribute_7.width, named_attribute_7.height = 140.0, 100.0
	    group_input_008_3.width, group_input_008_3.height = 140.0, 100.0
	    set_curve_radius_3.width, set_curve_radius_3.height = 140.0, 100.0
	    solid_mesh_shape.width, solid_mesh_shape.height = 240.0, 100.0
	    spline_parameter_4.width, spline_parameter_4.height = 140.0, 100.0
	    set_curve_tilt.width, set_curve_tilt.height = 140.0, 100.0
	    group_007_1.width, group_007_1.height = 140.0, 100.0
	    capture_attribute_3.width, capture_attribute_3.height = 140.0, 100.0
	    spline_parameter_001_3.width, spline_parameter_001_3.height = 140.0, 100.0
	    capture_attribute_001_3.width, capture_attribute_001_3.height = 140.0, 100.0
	    store_named_attribute_001_1.width, store_named_attribute_001_1.height = 140.0, 100.0
	    combine_xyz_001_4.width, combine_xyz_001_4.height = 140.0, 100.0
	    group_input_009_2.width, group_input_009_2.height = 140.0, 100.0
	    group_008.width, group_008.height = 140.0, 100.0
	    named_attribute_001_3.width, named_attribute_001_3.height = 140.0, 100.0
	    group_input_010_1.width, group_input_010_1.height = 140.0, 100.0
	    set_material_2.width, set_material_2.height = 140.0, 100.0
	    group_input_011.width, group_input_011.height = 140.0, 100.0
	
	    #initialize twist_bunz links
	    #group_8.Geometry -> group_001_6.Geometry
	    twist_bunz.links.new(group_8.outputs[0], group_001_6.inputs[0])
	    #group_001_6.Geometry -> group_002_3.Geometry
	    twist_bunz.links.new(group_001_6.outputs[0], group_002_3.inputs[0])
	    #capture_attribute_001_3.Geometry -> curve_to_mesh_3.Curve
	    twist_bunz.links.new(capture_attribute_001_3.outputs[0], curve_to_mesh_3.inputs[0])
	    #object_info_1.Geometry -> domain_size_1.Geometry
	    twist_bunz.links.new(object_info_1.outputs[4], domain_size_1.inputs[0])
	    #domain_size_1.Point Count -> compare_7.A
	    twist_bunz.links.new(domain_size_1.outputs[0], compare_7.inputs[2])
	    #compare_7.Result -> switch_7.Switch
	    twist_bunz.links.new(compare_7.outputs[0], switch_7.inputs[0])
	    #combine_xyz_3.Vector -> group_003_1.Scale
	    twist_bunz.links.new(combine_xyz_3.outputs[0], group_003_1.inputs[3])
	    #group_001_6.Geometry -> hair_style.Mesh Strip
	    twist_bunz.links.new(group_001_6.outputs[0], hair_style.inputs[3])
	    #set_material_2.Geometry -> hair_style.Solid Mesh
	    twist_bunz.links.new(set_material_2.outputs[0], hair_style.inputs[4])
	    #final_bake.Geometry -> group_output_21.Geometry
	    twist_bunz.links.new(final_bake.outputs[0], group_output_21.inputs[0])
	    #group_002_3.Geometry -> group_006.Geometry
	    twist_bunz.links.new(group_002_3.outputs[0], group_006.inputs[0])
	    #store_named_attribute_6.Geometry -> group_005_2.Geometry
	    twist_bunz.links.new(store_named_attribute_6.outputs[0], group_005_2.inputs[0])
	    #group_005_2.Geometry -> hair_style.Stylized
	    twist_bunz.links.new(group_005_2.outputs[0], hair_style.inputs[5])
	    #reroute_010_4.Output -> store_named_attribute_6.Geometry
	    twist_bunz.links.new(reroute_010_4.outputs[0], store_named_attribute_6.inputs[0])
	    #group_006.Guide Index -> store_named_attribute_6.Value
	    twist_bunz.links.new(group_006.outputs[1], store_named_attribute_6.inputs[3])
	    #group_input_15.Control Points -> group_8.Control Points
	    twist_bunz.links.new(group_input_15.outputs[3], group_8.inputs[1])
	    #group_input_15.Offset Scale -> group_8.Offset Scale
	    twist_bunz.links.new(group_input_15.outputs[4], group_8.inputs[2])
	    #group_input_15.Rotate -> group_8.Rotate
	    twist_bunz.links.new(group_input_15.outputs[6], group_8.inputs[3])
	    #group_input_15.Scale -> group_8.Scale
	    twist_bunz.links.new(group_input_15.outputs[7], group_8.inputs[4])
	    #group_input_15.Flip X -> group_8.Flip X
	    twist_bunz.links.new(group_input_15.outputs[8], group_8.inputs[5])
	    #group_input_15.Flip Overhang -> group_8.Flip Overhang
	    twist_bunz.links.new(group_input_15.outputs[9], group_8.inputs[6])
	    #group_input_001_13.Level -> group_002_3.Level
	    twist_bunz.links.new(group_input_001_13.outputs[11], group_002_3.inputs[1])
	    #group_input_001_13.Material -> group_002_3.Material
	    twist_bunz.links.new(group_input_001_13.outputs[12], group_002_3.inputs[2])
	    #group_input_001_13.Strand Radius -> group_002_3.Strand Radius
	    twist_bunz.links.new(group_input_001_13.outputs[13], group_002_3.inputs[3])
	    #group_input_001_13.Trim Seed -> group_002_3.Trim Seed
	    twist_bunz.links.new(group_input_001_13.outputs[14], group_002_3.inputs[4])
	    #group_input_001_13.Trim Factor -> group_002_3.Trim Factor
	    twist_bunz.links.new(group_input_001_13.outputs[15], group_002_3.inputs[5])
	    #group_input_001_13.UV Map -> group_002_3.UV Map
	    twist_bunz.links.new(group_input_001_13.outputs[16], group_002_3.inputs[6])
	    #group_input_002_10.Surface -> group_005_2.Surface
	    twist_bunz.links.new(group_input_002_10.outputs[1], group_005_2.inputs[1])
	    #group_input_003_8.Amount -> group_006.Amount
	    twist_bunz.links.new(group_input_003_8.outputs[17], group_006.inputs[1])
	    #group_input_003_8.Viewport Amount -> group_006.Viewport Amount
	    twist_bunz.links.new(group_input_003_8.outputs[18], group_006.inputs[2])
	    #group_input_003_8.Radius -> group_006.Radius
	    twist_bunz.links.new(group_input_003_8.outputs[19], group_006.inputs[3])
	    #group_input_003_8.Distribution Shape -> group_006.Distribution Shape
	    twist_bunz.links.new(group_input_003_8.outputs[20], group_006.inputs[4])
	    #group_input_003_8.Tip Roundness -> group_006.Tip Roundness
	    twist_bunz.links.new(group_input_003_8.outputs[21], group_006.inputs[5])
	    #group_input_003_8.Even Thickness -> group_006.Even Thickness
	    twist_bunz.links.new(group_input_003_8.outputs[22], group_006.inputs[6])
	    #group_input_003_8.Seed -> group_006.Seed
	    twist_bunz.links.new(group_input_003_8.outputs[23], group_006.inputs[7])
	    #group_input_004_5.Hair Style -> hair_style.Menu
	    twist_bunz.links.new(group_input_004_5.outputs[2], hair_style.inputs[0])
	    #group_input_002_10.Mesh Material -> group_005_2.Material
	    twist_bunz.links.new(group_input_002_10.outputs[24], group_005_2.inputs[2])
	    #group_input_002_10.Control Points -> group_005_2.Control Points
	    twist_bunz.links.new(group_input_002_10.outputs[3], group_005_2.inputs[3])
	    #group_input_002_10.Radius -> group_005_2.Radius
	    twist_bunz.links.new(group_input_002_10.outputs[25], group_005_2.inputs[4])
	    #group_input_002_10.Use Enhancements -> group_005_2.Use Enhancements
	    twist_bunz.links.new(group_input_002_10.outputs[26], group_005_2.inputs[5])
	    #group_input_002_10.Maintain Shape Factor -> group_005_2.Maintain Shape Factor
	    twist_bunz.links.new(group_input_002_10.outputs[27], group_005_2.inputs[6])
	    #group_input_002_10.Pin at Parameter -> group_005_2.Pin at Parameter
	    twist_bunz.links.new(group_input_002_10.outputs[28], group_005_2.inputs[7])
	    #group_input_002_10.Snap to surface -> group_005_2.Snap to surface
	    twist_bunz.links.new(group_input_002_10.outputs[29], group_005_2.inputs[8])
	    #group_input_002_10.Subdivison Level -> group_005_2.Subdivison Level
	    twist_bunz.links.new(group_input_002_10.outputs[30], group_005_2.inputs[9])
	    #group_input_002_10.Edge Crease -> group_005_2.Edge Crease
	    twist_bunz.links.new(group_input_002_10.outputs[31], group_005_2.inputs[10])
	    #group_input_002_10.Vertex Crease -> group_005_2.Vertex Crease
	    twist_bunz.links.new(group_input_002_10.outputs[32], group_005_2.inputs[11])
	    #group_input_002_10.Limit Surface -> group_005_2.Limit Surface
	    twist_bunz.links.new(group_input_002_10.outputs[33], group_005_2.inputs[12])
	    #group_input_002_10.Distance -> group_005_2.Distance
	    twist_bunz.links.new(group_input_002_10.outputs[34], group_005_2.inputs[13])
	    #group_input_005_7.Mesh Material -> group_001_6.Material
	    twist_bunz.links.new(group_input_005_7.outputs[24], group_001_6.inputs[3])
	    #group_input_005_7.Width -> group_001_6.Width
	    twist_bunz.links.new(group_input_005_7.outputs[10], group_001_6.inputs[1])
	    #group_input_006_5.Curve Profiile -> object_info_1.Object
	    twist_bunz.links.new(group_input_006_5.outputs[35], object_info_1.inputs[0])
	    #group_input_006_5.Profile Height -> combine_xyz_3.X
	    twist_bunz.links.new(group_input_006_5.outputs[36], combine_xyz_3.inputs[0])
	    #group_input_006_5.Profile Width -> combine_xyz_3.Y
	    twist_bunz.links.new(group_input_006_5.outputs[37], combine_xyz_3.inputs[1])
	    #group_input_006_5.Resolution -> group_003_1.Resolution
	    twist_bunz.links.new(group_input_006_5.outputs[38], group_003_1.inputs[0])
	    #group_003_1.Geometry -> switch_7.True
	    twist_bunz.links.new(group_003_1.outputs[0], switch_7.inputs[2])
	    #capture_attribute_3.Geometry -> curve_to_mesh_3.Profile Curve
	    twist_bunz.links.new(capture_attribute_3.outputs[0], curve_to_mesh_3.inputs[1])
	    #hair_style.Output -> final_bake.Geometry
	    twist_bunz.links.new(hair_style.outputs[0], final_bake.inputs[0])
	    #group_input_15.Geometry -> separate_components_2.Geometry
	    twist_bunz.links.new(group_input_15.outputs[0], separate_components_2.inputs[0])
	    #reroute_007_5.Output -> join_geometry_4.Geometry
	    twist_bunz.links.new(reroute_007_5.outputs[0], join_geometry_4.inputs[0])
	    #separate_components_2.Mesh -> reroute_9.Input
	    twist_bunz.links.new(separate_components_2.outputs[0], reroute_9.inputs[0])
	    #separate_components_2.Instances -> reroute_001_9.Input
	    twist_bunz.links.new(separate_components_2.outputs[5], reroute_001_9.inputs[0])
	    #separate_components_2.Grease Pencil -> reroute_002_5.Input
	    twist_bunz.links.new(separate_components_2.outputs[2], reroute_002_5.inputs[0])
	    #separate_components_2.Volume -> reroute_003_4.Input
	    twist_bunz.links.new(separate_components_2.outputs[4], reroute_003_4.inputs[0])
	    #separate_components_2.Point Cloud -> reroute_004_6.Input
	    twist_bunz.links.new(separate_components_2.outputs[3], reroute_004_6.inputs[0])
	    #reroute_9.Output -> reroute_005_5.Input
	    twist_bunz.links.new(reroute_9.outputs[0], reroute_005_5.inputs[0])
	    #reroute_004_6.Output -> reroute_006_5.Input
	    twist_bunz.links.new(reroute_004_6.outputs[0], reroute_006_5.inputs[0])
	    #reroute_001_9.Output -> reroute_007_5.Input
	    twist_bunz.links.new(reroute_001_9.outputs[0], reroute_007_5.inputs[0])
	    #reroute_003_4.Output -> reroute_008_5.Input
	    twist_bunz.links.new(reroute_003_4.outputs[0], reroute_008_5.inputs[0])
	    #reroute_002_5.Output -> reroute_009_5.Input
	    twist_bunz.links.new(reroute_002_5.outputs[0], reroute_009_5.inputs[0])
	    #join_geometry_4.Geometry -> hair_style.Hair Curve
	    twist_bunz.links.new(join_geometry_4.outputs[0], hair_style.inputs[1])
	    #combine_xyz_3.Vector -> transform_geometry_3.Scale
	    twist_bunz.links.new(combine_xyz_3.outputs[0], transform_geometry_3.inputs[3])
	    #object_info_1.Geometry -> transform_geometry_3.Geometry
	    twist_bunz.links.new(object_info_1.outputs[4], transform_geometry_3.inputs[0])
	    #group_input_007_3.Resolution -> resample_curve_3.Count
	    twist_bunz.links.new(group_input_007_3.outputs[38], resample_curve_3.inputs[2])
	    #transform_geometry_3.Geometry -> resample_curve_3.Curve
	    twist_bunz.links.new(transform_geometry_3.outputs[0], resample_curve_3.inputs[0])
	    #resample_curve_3.Curve -> switch_7.False
	    twist_bunz.links.new(resample_curve_3.outputs[0], switch_7.inputs[1])
	    #group_004_2.Geometry -> reroute_010_4.Input
	    twist_bunz.links.new(group_004_2.outputs[0], reroute_010_4.inputs[0])
	    #group_006.Geometry -> group_004_2.Geometry
	    twist_bunz.links.new(group_006.outputs[0], group_004_2.inputs[0])
	    #named_attribute_7.Attribute -> group_004_2.Surface UV Map
	    twist_bunz.links.new(named_attribute_7.outputs[0], group_004_2.inputs[3])
	    #group_input_008_3.Surface -> group_004_2.Surface
	    twist_bunz.links.new(group_input_008_3.outputs[1], group_004_2.inputs[2])
	    #group_input_008_3.UV Map -> named_attribute_7.Name
	    twist_bunz.links.new(group_input_008_3.outputs[16], named_attribute_7.inputs[0])
	    #group_8.Geometry -> set_curve_radius_3.Curve
	    twist_bunz.links.new(group_8.outputs[0], set_curve_radius_3.inputs[0])
	    #solid_mesh_shape.Value -> set_curve_radius_3.Radius
	    twist_bunz.links.new(solid_mesh_shape.outputs[0], set_curve_radius_3.inputs[2])
	    #spline_parameter_4.Factor -> solid_mesh_shape.Value
	    twist_bunz.links.new(spline_parameter_4.outputs[0], solid_mesh_shape.inputs[1])
	    #separate_components_2.Curve -> set_curve_tilt.Curve
	    twist_bunz.links.new(separate_components_2.outputs[1], set_curve_tilt.inputs[0])
	    #set_curve_tilt.Curve -> group_8.Geometry
	    twist_bunz.links.new(set_curve_tilt.outputs[0], group_8.inputs[0])
	    #group_input_15.Tilt -> set_curve_tilt.Tilt
	    twist_bunz.links.new(group_input_15.outputs[5], set_curve_tilt.inputs[2])
	    #switch_7.Output -> capture_attribute_3.Geometry
	    twist_bunz.links.new(switch_7.outputs[0], capture_attribute_3.inputs[0])
	    #set_curve_radius_3.Curve -> capture_attribute_001_3.Geometry
	    twist_bunz.links.new(set_curve_radius_3.outputs[0], capture_attribute_001_3.inputs[0])
	    #spline_parameter_001_3.Factor -> capture_attribute_3.Factor
	    twist_bunz.links.new(spline_parameter_001_3.outputs[0], capture_attribute_3.inputs[1])
	    #spline_parameter_001_3.Factor -> capture_attribute_001_3.Factor
	    twist_bunz.links.new(spline_parameter_001_3.outputs[0], capture_attribute_001_3.inputs[1])
	    #curve_to_mesh_3.Mesh -> store_named_attribute_001_1.Geometry
	    twist_bunz.links.new(curve_to_mesh_3.outputs[0], store_named_attribute_001_1.inputs[0])
	    #combine_xyz_001_4.Vector -> store_named_attribute_001_1.Value
	    twist_bunz.links.new(combine_xyz_001_4.outputs[0], store_named_attribute_001_1.inputs[3])
	    #capture_attribute_001_3.Factor -> combine_xyz_001_4.X
	    twist_bunz.links.new(capture_attribute_001_3.outputs[1], combine_xyz_001_4.inputs[0])
	    #capture_attribute_3.Factor -> combine_xyz_001_4.Y
	    twist_bunz.links.new(capture_attribute_3.outputs[1], combine_xyz_001_4.inputs[1])
	    #store_named_attribute_001_1.Geometry -> group_007_1.Geometry
	    twist_bunz.links.new(store_named_attribute_001_1.outputs[0], group_007_1.inputs[0])
	    #group_input_009_2.Level -> group_007_1.Level
	    twist_bunz.links.new(group_input_009_2.outputs[11], group_007_1.inputs[1])
	    #group_input_009_2.Material -> group_007_1.Material
	    twist_bunz.links.new(group_input_009_2.outputs[12], group_007_1.inputs[2])
	    #group_input_009_2.Strand Radius -> group_007_1.Strand Radius
	    twist_bunz.links.new(group_input_009_2.outputs[13], group_007_1.inputs[3])
	    #group_input_009_2.Trim Seed -> group_007_1.Trim Seed
	    twist_bunz.links.new(group_input_009_2.outputs[14], group_007_1.inputs[4])
	    #group_input_009_2.Trim Factor -> group_007_1.Trim Factor
	    twist_bunz.links.new(group_input_009_2.outputs[15], group_007_1.inputs[5])
	    #group_input_009_2.UV Map -> group_007_1.UV Map
	    twist_bunz.links.new(group_input_009_2.outputs[16], group_007_1.inputs[6])
	    #named_attribute_001_3.Attribute -> group_008.Surface UV Map
	    twist_bunz.links.new(named_attribute_001_3.outputs[0], group_008.inputs[3])
	    #group_input_010_1.Surface -> group_008.Surface
	    twist_bunz.links.new(group_input_010_1.outputs[1], group_008.inputs[2])
	    #group_input_010_1.UV Map -> named_attribute_001_3.Name
	    twist_bunz.links.new(group_input_010_1.outputs[16], named_attribute_001_3.inputs[0])
	    #group_007_1.Geometry -> group_008.Geometry
	    twist_bunz.links.new(group_007_1.outputs[0], group_008.inputs[0])
	    #group_008.Geometry -> hair_style.Solid Hair Curve
	    twist_bunz.links.new(group_008.outputs[0], hair_style.inputs[2])
	    #store_named_attribute_001_1.Geometry -> set_material_2.Geometry
	    twist_bunz.links.new(store_named_attribute_001_1.outputs[0], set_material_2.inputs[0])
	    #group_input_011.Mesh Material -> set_material_2.Material
	    twist_bunz.links.new(group_input_011.outputs[24], set_material_2.inputs[2])
	    #reroute_008_5.Output -> join_geometry_4.Geometry
	    twist_bunz.links.new(reroute_008_5.outputs[0], join_geometry_4.inputs[0])
	    #reroute_006_5.Output -> join_geometry_4.Geometry
	    twist_bunz.links.new(reroute_006_5.outputs[0], join_geometry_4.inputs[0])
	    #reroute_009_5.Output -> join_geometry_4.Geometry
	    twist_bunz.links.new(reroute_009_5.outputs[0], join_geometry_4.inputs[0])
	    #reroute_005_5.Output -> join_geometry_4.Geometry
	    twist_bunz.links.new(reroute_005_5.outputs[0], join_geometry_4.inputs[0])
	    #reroute_010_4.Output -> join_geometry_4.Geometry
	    twist_bunz.links.new(reroute_010_4.outputs[0], join_geometry_4.inputs[0])
	    hair_style_socket.default_value = 'Solid Hair Curve'
	    return twist_bunz
	return twist_bunz_node_group()

	

	
