import bpy, mathutils

def node():
	#initialize curve_root_001 node group
	def curve_root_001_node_group():
	    curve_root_001 = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Curve Root.001")
	
	    curve_root_001.color_tag = 'INPUT'
	    curve_root_001.description = "Reads information about each curve's root point"
	    curve_root_001.default_group_node_width = 140
	    
	
	
	    #curve_root_001 interface
	    #Socket Root Selection
	    root_selection_socket = curve_root_001.interface.new_socket(name = "Root Selection", in_out='OUTPUT', socket_type = 'NodeSocketBool')
	    root_selection_socket.default_value = False
	    root_selection_socket.attribute_domain = 'POINT'
	    root_selection_socket.description = "Boolean selection of curve root points"
	
	    #Socket Root Position
	    root_position_socket = curve_root_001.interface.new_socket(name = "Root Position", in_out='OUTPUT', socket_type = 'NodeSocketVector')
	    root_position_socket.default_value = (0.0, 0.0, 0.0)
	    root_position_socket.min_value = -3.4028234663852886e+38
	    root_position_socket.max_value = 3.4028234663852886e+38
	    root_position_socket.subtype = 'NONE'
	    root_position_socket.attribute_domain = 'CURVE'
	    root_position_socket.description = "Position of the root point of a curve"
	
	    #Socket Root Direction
	    root_direction_socket = curve_root_001.interface.new_socket(name = "Root Direction", in_out='OUTPUT', socket_type = 'NodeSocketVector')
	    root_direction_socket.default_value = (0.0, 0.0, 0.0)
	    root_direction_socket.min_value = -3.4028234663852886e+38
	    root_direction_socket.max_value = 3.4028234663852886e+38
	    root_direction_socket.subtype = 'NONE'
	    root_direction_socket.attribute_domain = 'CURVE'
	    root_direction_socket.description = "Direction of the root segment of a curve"
	
	    #Socket Root Index
	    root_index_socket = curve_root_001.interface.new_socket(name = "Root Index", in_out='OUTPUT', socket_type = 'NodeSocketInt')
	    root_index_socket.default_value = 0
	    root_index_socket.min_value = -2147483648
	    root_index_socket.max_value = 2147483647
	    root_index_socket.subtype = 'NONE'
	    root_index_socket.attribute_domain = 'CURVE'
	    root_index_socket.description = "Index of the root point of a curve"
	
	
	    #initialize curve_root_001 nodes
	    #node Position.002
	    position_002 = curve_root_001.nodes.new("GeometryNodeInputPosition")
	    position_002.name = "Position.002"
	
	    #node Interpolate Domain
	    interpolate_domain = curve_root_001.nodes.new("GeometryNodeFieldOnDomain")
	    interpolate_domain.name = "Interpolate Domain"
	    interpolate_domain.data_type = 'INT'
	    interpolate_domain.domain = 'CURVE'
	
	    #node Field at Index.003
	    field_at_index_003 = curve_root_001.nodes.new("GeometryNodeFieldAtIndex")
	    field_at_index_003.name = "Field at Index.003"
	    field_at_index_003.data_type = 'FLOAT_VECTOR'
	    field_at_index_003.domain = 'POINT'
	
	    #node Interpolate Domain.001
	    interpolate_domain_001 = curve_root_001.nodes.new("GeometryNodeFieldOnDomain")
	    interpolate_domain_001.name = "Interpolate Domain.001"
	    interpolate_domain_001.data_type = 'FLOAT_VECTOR'
	    interpolate_domain_001.domain = 'CURVE'
	
	    #node Curve Tangent
	    curve_tangent = curve_root_001.nodes.new("GeometryNodeInputTangent")
	    curve_tangent.name = "Curve Tangent"
	
	    #node Endpoint Selection
	    endpoint_selection = curve_root_001.nodes.new("GeometryNodeCurveEndpointSelection")
	    endpoint_selection.name = "Endpoint Selection"
	    #Start Size
	    endpoint_selection.inputs[0].default_value = 1
	    #End Size
	    endpoint_selection.inputs[1].default_value = 0
	
	    #node Field at Index.004
	    field_at_index_004 = curve_root_001.nodes.new("GeometryNodeFieldAtIndex")
	    field_at_index_004.name = "Field at Index.004"
	    field_at_index_004.data_type = 'FLOAT_VECTOR'
	    field_at_index_004.domain = 'POINT'
	
	    #node Interpolate Domain.002
	    interpolate_domain_002 = curve_root_001.nodes.new("GeometryNodeFieldOnDomain")
	    interpolate_domain_002.name = "Interpolate Domain.002"
	    interpolate_domain_002.data_type = 'FLOAT_VECTOR'
	    interpolate_domain_002.domain = 'CURVE'
	
	    #node Group Output
	    group_output = curve_root_001.nodes.new("NodeGroupOutput")
	    group_output.name = "Group Output"
	    group_output.is_active_output = True
	
	    #node Points of Curve
	    points_of_curve = curve_root_001.nodes.new("GeometryNodePointsOfCurve")
	    points_of_curve.name = "Points of Curve"
	    points_of_curve.inputs[0].hide = True
	    points_of_curve.inputs[1].hide = True
	    points_of_curve.outputs[1].hide = True
	    #Curve Index
	    points_of_curve.inputs[0].default_value = 0
	    #Weights
	    points_of_curve.inputs[1].default_value = 0.0
	    #Sort Index
	    points_of_curve.inputs[2].default_value = 0
	
	
	
	
	
	    #Set locations
	    position_002.location = (-608.1627807617188, -70.55814361572266)
	    interpolate_domain.location = (-608.1627807617188, 90.18604278564453)
	    field_at_index_003.location = (-407.2325439453125, 70.09302520751953)
	    interpolate_domain_001.location = (-206.30230712890625, 70.09302520751953)
	    curve_tangent.location = (-608.1627807617188, -271.4883728027344)
	    endpoint_selection.location = (-206.30230712890625, 190.65118408203125)
	    field_at_index_004.location = (-407.2325439453125, -130.83721923828125)
	    interpolate_domain_002.location = (-206.30230712890625, -130.83721923828125)
	    group_output.location = (75.0, 50.0)
	    points_of_curve.location = (-789.0, 50.0)
	
	    #Set dimensions
	    position_002.width, position_002.height = 140.0, 100.0
	    interpolate_domain.width, interpolate_domain.height = 140.0, 100.0
	    field_at_index_003.width, field_at_index_003.height = 140.0, 100.0
	    interpolate_domain_001.width, interpolate_domain_001.height = 140.0, 100.0
	    curve_tangent.width, curve_tangent.height = 140.0, 100.0
	    endpoint_selection.width, endpoint_selection.height = 140.0, 100.0
	    field_at_index_004.width, field_at_index_004.height = 140.0, 100.0
	    interpolate_domain_002.width, interpolate_domain_002.height = 140.0, 100.0
	    group_output.width, group_output.height = 140.0, 100.0
	    points_of_curve.width, points_of_curve.height = 140.0, 100.0
	
	    #initialize curve_root_001 links
	    #position_002.Position -> field_at_index_003.Value
	    curve_root_001.links.new(position_002.outputs[0], field_at_index_003.inputs[1])
	    #interpolate_domain_001.Value -> group_output.Root Position
	    curve_root_001.links.new(interpolate_domain_001.outputs[0], group_output.inputs[1])
	    #interpolate_domain.Value -> field_at_index_003.Index
	    curve_root_001.links.new(interpolate_domain.outputs[0], field_at_index_003.inputs[0])
	    #points_of_curve.Point Index -> interpolate_domain.Value
	    curve_root_001.links.new(points_of_curve.outputs[0], interpolate_domain.inputs[0])
	    #interpolate_domain.Value -> group_output.Root Index
	    curve_root_001.links.new(interpolate_domain.outputs[0], group_output.inputs[3])
	    #endpoint_selection.Selection -> group_output.Root Selection
	    curve_root_001.links.new(endpoint_selection.outputs[0], group_output.inputs[0])
	    #field_at_index_003.Value -> interpolate_domain_001.Value
	    curve_root_001.links.new(field_at_index_003.outputs[0], interpolate_domain_001.inputs[0])
	    #interpolate_domain_002.Value -> group_output.Root Direction
	    curve_root_001.links.new(interpolate_domain_002.outputs[0], group_output.inputs[2])
	    #interpolate_domain.Value -> field_at_index_004.Index
	    curve_root_001.links.new(interpolate_domain.outputs[0], field_at_index_004.inputs[0])
	    #curve_tangent.Tangent -> field_at_index_004.Value
	    curve_root_001.links.new(curve_tangent.outputs[0], field_at_index_004.inputs[1])
	    #field_at_index_004.Value -> interpolate_domain_002.Value
	    curve_root_001.links.new(field_at_index_004.outputs[0], interpolate_domain_002.inputs[0])
	    return curve_root_001
	
	curve_root_001 = curve_root_001_node_group()
	
	#initialize attach_hair_curves_to_surface node group
	def attach_hair_curves_to_surface_node_group():
	    attach_hair_curves_to_surface = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Attach Hair Curves to Surface")
	
	    attach_hair_curves_to_surface.color_tag = 'GEOMETRY'
	    attach_hair_curves_to_surface.description = "Attaches hair curves to a surface mesh"
	    attach_hair_curves_to_surface.default_group_node_width = 140
	    
	
	    attach_hair_curves_to_surface.is_modifier = True
	
	    #attach_hair_curves_to_surface interface
	    #Socket Geometry
	    geometry_socket = attach_hair_curves_to_surface.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket.attribute_domain = 'POINT'
	
	    #Socket Surface UV Coordinate
	    surface_uv_coordinate_socket = attach_hair_curves_to_surface.interface.new_socket(name = "Surface UV Coordinate", in_out='OUTPUT', socket_type = 'NodeSocketVector')
	    surface_uv_coordinate_socket.default_value = (0.0, 0.0, 0.0)
	    surface_uv_coordinate_socket.min_value = -3.4028234663852886e+38
	    surface_uv_coordinate_socket.max_value = 3.4028234663852886e+38
	    surface_uv_coordinate_socket.subtype = 'NONE'
	    surface_uv_coordinate_socket.attribute_domain = 'CURVE'
	    surface_uv_coordinate_socket.description = "Surface UV coordinates at the attachment point"
	
	    #Socket Surface Normal
	    surface_normal_socket = attach_hair_curves_to_surface.interface.new_socket(name = "Surface Normal", in_out='OUTPUT', socket_type = 'NodeSocketVector')
	    surface_normal_socket.default_value = (0.0, 0.0, 0.0)
	    surface_normal_socket.min_value = -3.4028234663852886e+38
	    surface_normal_socket.max_value = 3.4028234663852886e+38
	    surface_normal_socket.subtype = 'NONE'
	    surface_normal_socket.attribute_domain = 'CURVE'
	    surface_normal_socket.description = "Surface normal at the attachment point"
	
	    #Socket Geometry
	    geometry_socket_1 = attach_hair_curves_to_surface.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_1.attribute_domain = 'POINT'
	    geometry_socket_1.description = "Input Geometry (may include other than curves)"
	
	    #Socket Surface
	    surface_socket = attach_hair_curves_to_surface.interface.new_socket(name = "Surface", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    surface_socket.attribute_domain = 'POINT'
	    surface_socket.description = "Surface geometry to attach hair curves to"
	
	    #Socket Surface
	    surface_socket_1 = attach_hair_curves_to_surface.interface.new_socket(name = "Surface", in_out='INPUT', socket_type = 'NodeSocketObject')
	    surface_socket_1.attribute_domain = 'POINT'
	    surface_socket_1.description = "Surface Object to attach to (needs to have matching transforms)"
	
	    #Socket Surface UV Map
	    surface_uv_map_socket = attach_hair_curves_to_surface.interface.new_socket(name = "Surface UV Map", in_out='INPUT', socket_type = 'NodeSocketVector')
	    surface_uv_map_socket.default_value = (0.0, 0.0, 0.0)
	    surface_uv_map_socket.min_value = -3.4028234663852886e+38
	    surface_uv_map_socket.max_value = 3.4028234663852886e+38
	    surface_uv_map_socket.subtype = 'NONE'
	    surface_uv_map_socket.default_attribute_name = "UVMap"
	    surface_uv_map_socket.attribute_domain = 'POINT'
	    surface_uv_map_socket.hide_value = True
	    surface_uv_map_socket.description = "Surface UV map used for attachment"
	
	    #Socket Surface Rest Position
	    surface_rest_position_socket = attach_hair_curves_to_surface.interface.new_socket(name = "Surface Rest Position", in_out='INPUT', socket_type = 'NodeSocketBool')
	    surface_rest_position_socket.default_value = False
	    surface_rest_position_socket.attribute_domain = 'POINT'
	    surface_rest_position_socket.description = "Set the surface mesh into its rest position before attachment"
	
	    #Socket Sample Attachment UV
	    sample_attachment_uv_socket = attach_hair_curves_to_surface.interface.new_socket(name = "Sample Attachment UV", in_out='INPUT', socket_type = 'NodeSocketBool')
	    sample_attachment_uv_socket.default_value = True
	    sample_attachment_uv_socket.attribute_domain = 'POINT'
	    sample_attachment_uv_socket.description = "Sample the surface UV map at the attachment point"
	
	    #Socket Snap to Surface
	    snap_to_surface_socket = attach_hair_curves_to_surface.interface.new_socket(name = "Snap to Surface", in_out='INPUT', socket_type = 'NodeSocketBool')
	    snap_to_surface_socket.default_value = True
	    snap_to_surface_socket.attribute_domain = 'POINT'
	    snap_to_surface_socket.description = "Snap the root of each curve to the closest surface point"
	
	    #Socket Align to Surface Normal
	    align_to_surface_normal_socket = attach_hair_curves_to_surface.interface.new_socket(name = "Align to Surface Normal", in_out='INPUT', socket_type = 'NodeSocketBool')
	    align_to_surface_normal_socket.default_value = True
	    align_to_surface_normal_socket.attribute_domain = 'POINT'
	    align_to_surface_normal_socket.description = "Align the curve to the surface normal (needs a guide as reference)"
	
	    #Socket Blend along Curve
	    blend_along_curve_socket = attach_hair_curves_to_surface.interface.new_socket(name = "Blend along Curve", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    blend_along_curve_socket.default_value = 0.0
	    blend_along_curve_socket.min_value = 0.0
	    blend_along_curve_socket.max_value = 1.0
	    blend_along_curve_socket.subtype = 'FACTOR'
	    blend_along_curve_socket.attribute_domain = 'POINT'
	    blend_along_curve_socket.description = "Blend deformation along each curve from the root"
	
	
	    #initialize attach_hair_curves_to_surface nodes
	    #node Frame.004
	    frame_004 = attach_hair_curves_to_surface.nodes.new("NodeFrame")
	    frame_004.label = "Write Data"
	    frame_004.name = "Frame.004"
	    frame_004.label_size = 20
	    frame_004.shrink = True
	
	    #node Frame.005
	    frame_005 = attach_hair_curves_to_surface.nodes.new("NodeFrame")
	    frame_005.label = "Sample Surface"
	    frame_005.name = "Frame.005"
	    frame_005.label_size = 20
	    frame_005.shrink = True
	
	    #node Frame
	    frame = attach_hair_curves_to_surface.nodes.new("NodeFrame")
	    frame.label = "Surface Geometry Input"
	    frame.name = "Frame"
	    frame.label_size = 20
	    frame.shrink = True
	
	    #node Frame.006
	    frame_006 = attach_hair_curves_to_surface.nodes.new("NodeFrame")
	    frame_006.label = "Geometry Socket with Priority"
	    frame_006.name = "Frame.006"
	    frame_006.label_size = 20
	    frame_006.shrink = True
	
	    #node Frame.007
	    frame_007 = attach_hair_curves_to_surface.nodes.new("NodeFrame")
	    frame_007.label = "Object in Local Space"
	    frame_007.name = "Frame.007"
	    frame_007.label_size = 20
	    frame_007.shrink = True
	
	    #node Frame.011
	    frame_011 = attach_hair_curves_to_surface.nodes.new("NodeFrame")
	    frame_011.label = "Sample Attachment UV"
	    frame_011.name = "Frame.011"
	    frame_011.label_size = 20
	    frame_011.shrink = True
	
	    #node Frame.001
	    frame_001 = attach_hair_curves_to_surface.nodes.new("NodeFrame")
	    frame_001.label = "Smooth Normals"
	    frame_001.name = "Frame.001"
	    frame_001.label_size = 20
	    frame_001.shrink = True
	
	    #node Frame.010
	    frame_010 = attach_hair_curves_to_surface.nodes.new("NodeFrame")
	    frame_010.label = "Calculate New Position"
	    frame_010.name = "Frame.010"
	    frame_010.use_custom_color = True
	    frame_010.color = (0.13328450918197632, 0.13328450918197632, 0.13328450918197632)
	    frame_010.label_size = 20
	    frame_010.shrink = True
	
	    #node Frame.003
	    frame_003 = attach_hair_curves_to_surface.nodes.new("NodeFrame")
	    frame_003.label = "Blend Deformation"
	    frame_003.name = "Frame.003"
	    frame_003.label_size = 20
	    frame_003.shrink = True
	
	    #node Frame.002
	    frame_002 = attach_hair_curves_to_surface.nodes.new("NodeFrame")
	    frame_002.label = "Align to Normal"
	    frame_002.name = "Frame.002"
	    frame_002.use_custom_color = True
	    frame_002.color = (0.08883915841579437, 0.08883915841579437, 0.08883915841579437)
	    frame_002.label_size = 20
	    frame_002.shrink = True
	
	    #node Frame.008
	    frame_008 = attach_hair_curves_to_surface.nodes.new("NodeFrame")
	    frame_008.label = "Optimize"
	    frame_008.name = "Frame.008"
	    frame_008.label_size = 20
	    frame_008.shrink = True
	
	    #node Frame.009
	    frame_009 = attach_hair_curves_to_surface.nodes.new("NodeFrame")
	    frame_009.label = "Sample from Guide"
	    frame_009.name = "Frame.009"
	    frame_009.label_size = 20
	    frame_009.shrink = True
	
	    #node Reroute.010
	    reroute_010 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_010.name = "Reroute.010"
	    reroute_010.socket_idname = "NodeSocketGeometry"
	    #node Reroute.013
	    reroute_013 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_013.name = "Reroute.013"
	    reroute_013.socket_idname = "NodeSocketBool"
	    #node Group Output
	    group_output_1 = attach_hair_curves_to_surface.nodes.new("NodeGroupOutput")
	    group_output_1.name = "Group Output"
	    group_output_1.is_active_output = True
	
	    #node Reroute.003
	    reroute_003 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_003.name = "Reroute.003"
	    reroute_003.socket_idname = "NodeSocketVector"
	    #node Switch
	    switch = attach_hair_curves_to_surface.nodes.new("GeometryNodeSwitch")
	    switch.name = "Switch"
	    switch.input_type = 'GEOMETRY'
	
	    #node Store Named Attribute
	    store_named_attribute = attach_hair_curves_to_surface.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute.name = "Store Named Attribute"
	    store_named_attribute.data_type = 'FLOAT2'
	    store_named_attribute.domain = 'CURVE'
	    #Selection
	    store_named_attribute.inputs[1].default_value = True
	    #Name
	    store_named_attribute.inputs[2].default_value = "surface_uv_coordinate"
	
	    #node Group Input.007
	    group_input_007 = attach_hair_curves_to_surface.nodes.new("NodeGroupInput")
	    group_input_007.name = "Group Input.007"
	    group_input_007.outputs[0].hide = True
	    group_input_007.outputs[1].hide = True
	    group_input_007.outputs[2].hide = True
	    group_input_007.outputs[3].hide = True
	    group_input_007.outputs[4].hide = True
	    group_input_007.outputs[6].hide = True
	    group_input_007.outputs[7].hide = True
	    group_input_007.outputs[8].hide = True
	    group_input_007.outputs[9].hide = True
	
	    #node Reroute.016
	    reroute_016 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_016.name = "Reroute.016"
	    reroute_016.socket_idname = "NodeSocketGeometry"
	    #node Reroute.005
	    reroute_005 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_005.name = "Reroute.005"
	    reroute_005.socket_idname = "NodeSocketVector"
	    #node Store Named Attribute.001
	    store_named_attribute_001 = attach_hair_curves_to_surface.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_001.name = "Store Named Attribute.001"
	    store_named_attribute_001.data_type = 'FLOAT_VECTOR'
	    store_named_attribute_001.domain = 'CURVE'
	    #Selection
	    store_named_attribute_001.inputs[1].default_value = True
	    #Name
	    store_named_attribute_001.inputs[2].default_value = "surface_normal"
	
	    #node Named Attribute.004
	    named_attribute_004 = attach_hair_curves_to_surface.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute_004.name = "Named Attribute.004"
	    named_attribute_004.data_type = 'FLOAT_VECTOR'
	    #Name
	    named_attribute_004.inputs[0].default_value = "surface_normal"
	
	    #node Reroute.012
	    reroute_012 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_012.name = "Reroute.012"
	    reroute_012.socket_idname = "NodeSocketBool"
	    #node Reroute.014
	    reroute_014 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_014.name = "Reroute.014"
	    reroute_014.socket_idname = "NodeSocketBool"
	    #node Reroute.006
	    reroute_006 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_006.name = "Reroute.006"
	    reroute_006.socket_idname = "NodeSocketGeometry"
	    #node Named Attribute.003
	    named_attribute_003 = attach_hair_curves_to_surface.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute_003.name = "Named Attribute.003"
	    named_attribute_003.data_type = 'FLOAT_VECTOR'
	    #Name
	    named_attribute_003.inputs[0].default_value = "surface_uv_coordinate"
	
	    #node Switch.008
	    switch_008 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSwitch")
	    switch_008.name = "Switch.008"
	    switch_008.input_type = 'GEOMETRY'
	
	    #node Switch.009
	    switch_009 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSwitch")
	    switch_009.name = "Switch.009"
	    switch_009.input_type = 'VECTOR'
	
	    #node Switch.010
	    switch_010 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSwitch")
	    switch_010.name = "Switch.010"
	    switch_010.input_type = 'VECTOR'
	
	    #node Set Position.001
	    set_position_001 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSetPosition")
	    set_position_001.name = "Set Position.001"
	    set_position_001.inputs[2].hide = True
	    #Position
	    set_position_001.inputs[2].default_value = (0.0, 0.0, 0.0)
	
	    #node Reroute.002
	    reroute_002 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_002.name = "Reroute.002"
	    reroute_002.socket_idname = "NodeSocketVector"
	    #node Reroute.018
	    reroute_018 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_018.name = "Reroute.018"
	    reroute_018.socket_idname = "NodeSocketVector"
	    #node Reroute.017
	    reroute_017 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_017.name = "Reroute.017"
	    reroute_017.socket_idname = "NodeSocketGeometry"
	    #node Group Input.009
	    group_input_009 = attach_hair_curves_to_surface.nodes.new("NodeGroupInput")
	    group_input_009.name = "Group Input.009"
	    group_input_009.outputs[0].hide = True
	    group_input_009.outputs[1].hide = True
	    group_input_009.outputs[2].hide = True
	    group_input_009.outputs[4].hide = True
	    group_input_009.outputs[5].hide = True
	    group_input_009.outputs[6].hide = True
	    group_input_009.outputs[7].hide = True
	    group_input_009.outputs[8].hide = True
	    group_input_009.outputs[9].hide = True
	
	    #node Position
	    position = attach_hair_curves_to_surface.nodes.new("GeometryNodeInputPosition")
	    position.name = "Position"
	
	    #node Named Attribute.001
	    named_attribute_001 = attach_hair_curves_to_surface.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute_001.name = "Named Attribute.001"
	    named_attribute_001.data_type = 'FLOAT_VECTOR'
	    #Name
	    named_attribute_001.inputs[0].default_value = "surface_uv_coordinate"
	
	    #node Capture Attribute.001
	    capture_attribute_001 = attach_hair_curves_to_surface.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_001.name = "Capture Attribute.001"
	    capture_attribute_001.active_index = 0
	    capture_attribute_001.capture_items.clear()
	    capture_attribute_001.capture_items.new('FLOAT', "Value")
	    capture_attribute_001.capture_items["Value"].data_type = 'FLOAT_VECTOR'
	    capture_attribute_001.domain = 'CURVE'
	
	    #node Group Input.004
	    group_input_004 = attach_hair_curves_to_surface.nodes.new("NodeGroupInput")
	    group_input_004.name = "Group Input.004"
	    group_input_004.outputs[0].hide = True
	    group_input_004.outputs[2].hide = True
	    group_input_004.outputs[3].hide = True
	    group_input_004.outputs[4].hide = True
	    group_input_004.outputs[5].hide = True
	    group_input_004.outputs[6].hide = True
	    group_input_004.outputs[7].hide = True
	    group_input_004.outputs[8].hide = True
	    group_input_004.outputs[9].hide = True
	
	    #node Domain Size.002
	    domain_size_002 = attach_hair_curves_to_surface.nodes.new("GeometryNodeAttributeDomainSize")
	    domain_size_002.name = "Domain Size.002"
	    domain_size_002.component = 'MESH'
	    domain_size_002.outputs[0].hide = True
	    domain_size_002.outputs[1].hide = True
	    domain_size_002.outputs[3].hide = True
	    domain_size_002.outputs[4].hide = True
	    domain_size_002.outputs[5].hide = True
	
	    #node Compare.001
	    compare_001 = attach_hair_curves_to_surface.nodes.new("FunctionNodeCompare")
	    compare_001.name = "Compare.001"
	    compare_001.data_type = 'INT'
	    compare_001.mode = 'ELEMENT'
	    compare_001.operation = 'NOT_EQUAL'
	    #B_INT
	    compare_001.inputs[3].default_value = 0
	
	    #node Object Info.001
	    object_info_001 = attach_hair_curves_to_surface.nodes.new("GeometryNodeObjectInfo")
	    object_info_001.name = "Object Info.001"
	    object_info_001.transform_space = 'ORIGINAL'
	    object_info_001.inputs[1].hide = True
	    object_info_001.outputs[1].hide = True
	    object_info_001.outputs[3].hide = True
	    #As Instance
	    object_info_001.inputs[1].default_value = False
	
	    #node Group Input.002
	    group_input_002 = attach_hair_curves_to_surface.nodes.new("NodeGroupInput")
	    group_input_002.name = "Group Input.002"
	    group_input_002.outputs[0].hide = True
	    group_input_002.outputs[1].hide = True
	    group_input_002.outputs[3].hide = True
	    group_input_002.outputs[4].hide = True
	    group_input_002.outputs[5].hide = True
	    group_input_002.outputs[6].hide = True
	    group_input_002.outputs[7].hide = True
	    group_input_002.outputs[8].hide = True
	    group_input_002.outputs[9].hide = True
	
	    #node Switch.005
	    switch_005 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSwitch")
	    switch_005.name = "Switch.005"
	    switch_005.input_type = 'GEOMETRY'
	
	    #node Domain Size.003
	    domain_size_003 = attach_hair_curves_to_surface.nodes.new("GeometryNodeAttributeDomainSize")
	    domain_size_003.name = "Domain Size.003"
	    domain_size_003.component = 'MESH'
	    domain_size_003.outputs[0].hide = True
	    domain_size_003.outputs[1].hide = True
	    domain_size_003.outputs[3].hide = True
	    domain_size_003.outputs[4].hide = True
	    domain_size_003.outputs[5].hide = True
	
	    #node Compare.002
	    compare_002 = attach_hair_curves_to_surface.nodes.new("FunctionNodeCompare")
	    compare_002.name = "Compare.002"
	    compare_002.data_type = 'INT'
	    compare_002.mode = 'ELEMENT'
	    compare_002.operation = 'EQUAL'
	    #B_INT
	    compare_002.inputs[3].default_value = 0
	
	    #node Named Attribute
	    named_attribute = attach_hair_curves_to_surface.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute.name = "Named Attribute"
	    named_attribute.data_type = 'FLOAT_VECTOR'
	    #Name
	    named_attribute.inputs[0].default_value = "rest_position"
	
	    #node Reroute
	    reroute = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute.name = "Reroute"
	    reroute.socket_idname = "NodeSocketGeometry"
	    #node Group Input.005
	    group_input_005 = attach_hair_curves_to_surface.nodes.new("NodeGroupInput")
	    group_input_005.name = "Group Input.005"
	    group_input_005.outputs[0].hide = True
	    group_input_005.outputs[1].hide = True
	    group_input_005.outputs[2].hide = True
	    group_input_005.outputs[3].hide = True
	    group_input_005.outputs[5].hide = True
	    group_input_005.outputs[6].hide = True
	    group_input_005.outputs[7].hide = True
	    group_input_005.outputs[8].hide = True
	    group_input_005.outputs[9].hide = True
	
	    #node Set Position
	    set_position = attach_hair_curves_to_surface.nodes.new("GeometryNodeSetPosition")
	    set_position.name = "Set Position"
	    set_position.inputs[3].hide = True
	    #Offset
	    set_position.inputs[3].default_value = (0.0, 0.0, 0.0)
	
	    #node Switch.007
	    switch_007 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSwitch")
	    switch_007.name = "Switch.007"
	    switch_007.input_type = 'GEOMETRY'
	
	    #node Reroute.015
	    reroute_015 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_015.name = "Reroute.015"
	    reroute_015.socket_idname = "NodeSocketBool"
	    #node Reroute.011
	    reroute_011 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_011.name = "Reroute.011"
	    reroute_011.socket_idname = "NodeSocketGeometry"
	    #node Group Input
	    group_input = attach_hair_curves_to_surface.nodes.new("NodeGroupInput")
	    group_input.name = "Group Input"
	    group_input.outputs[1].hide = True
	    group_input.outputs[2].hide = True
	    group_input.outputs[3].hide = True
	    group_input.outputs[4].hide = True
	    group_input.outputs[5].hide = True
	    group_input.outputs[6].hide = True
	    group_input.outputs[7].hide = True
	    group_input.outputs[8].hide = True
	    group_input.outputs[9].hide = True
	
	    #node Capture Attribute.002
	    capture_attribute_002 = attach_hair_curves_to_surface.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_002.name = "Capture Attribute.002"
	    capture_attribute_002.active_index = 0
	    capture_attribute_002.capture_items.clear()
	    capture_attribute_002.capture_items.new('FLOAT', "Value")
	    capture_attribute_002.capture_items["Value"].data_type = 'FLOAT_VECTOR'
	    capture_attribute_002.domain = 'CURVE'
	
	    #node Reroute.001
	    reroute_001 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_001.name = "Reroute.001"
	    reroute_001.socket_idname = "NodeSocketGeometry"
	    #node Sample Nearest Surface
	    sample_nearest_surface = attach_hair_curves_to_surface.nodes.new("GeometryNodeSampleNearestSurface")
	    sample_nearest_surface.name = "Sample Nearest Surface"
	    sample_nearest_surface.data_type = 'FLOAT_VECTOR'
	    #Group ID
	    sample_nearest_surface.inputs[2].default_value = 0
	    #Sample Group ID
	    sample_nearest_surface.inputs[4].default_value = 0
	
	    #node Group
	    group = attach_hair_curves_to_surface.nodes.new("GeometryNodeGroup")
	    group.name = "Group"
	    group.node_tree = curve_root_001
	    group.outputs[0].hide = True
	    group.outputs[2].hide = True
	    group.outputs[3].hide = True
	
	    #node Group Input.001
	    group_input_001 = attach_hair_curves_to_surface.nodes.new("NodeGroupInput")
	    group_input_001.name = "Group Input.001"
	    group_input_001.outputs[0].hide = True
	    group_input_001.outputs[1].hide = True
	    group_input_001.outputs[2].hide = True
	    group_input_001.outputs[4].hide = True
	    group_input_001.outputs[5].hide = True
	    group_input_001.outputs[6].hide = True
	    group_input_001.outputs[7].hide = True
	    group_input_001.outputs[8].hide = True
	    group_input_001.outputs[9].hide = True
	
	    #node Reroute.020
	    reroute_020 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_020.name = "Reroute.020"
	    reroute_020.socket_idname = "NodeSocketGeometry"
	    #node Normal
	    normal = attach_hair_curves_to_surface.nodes.new("GeometryNodeInputNormal")
	    normal.name = "Normal"
	    normal.legacy_corner_normals = True
	
	    #node Capture Attribute
	    capture_attribute = attach_hair_curves_to_surface.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute.name = "Capture Attribute"
	    capture_attribute.hide = True
	    capture_attribute.active_index = 0
	    capture_attribute.capture_items.clear()
	    capture_attribute.capture_items.new('FLOAT', "Value")
	    capture_attribute.capture_items["Value"].data_type = 'FLOAT_VECTOR'
	    capture_attribute.domain = 'POINT'
	
	    #node Sample UV Surface
	    sample_uv_surface = attach_hair_curves_to_surface.nodes.new("GeometryNodeSampleUVSurface")
	    sample_uv_surface.name = "Sample UV Surface"
	    sample_uv_surface.hide = True
	    sample_uv_surface.data_type = 'FLOAT_VECTOR'
	    sample_uv_surface.outputs[1].hide = True
	
	    #node Sample UV Surface.003
	    sample_uv_surface_003 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSampleUVSurface")
	    sample_uv_surface_003.name = "Sample UV Surface.003"
	    sample_uv_surface_003.hide = True
	    sample_uv_surface_003.data_type = 'FLOAT_VECTOR'
	    sample_uv_surface_003.outputs[1].hide = True
	
	    #node Reroute.004
	    reroute_004 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_004.name = "Reroute.004"
	    reroute_004.socket_idname = "NodeSocketVector"
	    #node Sample UV Surface.001
	    sample_uv_surface_001 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSampleUVSurface")
	    sample_uv_surface_001.name = "Sample UV Surface.001"
	    sample_uv_surface_001.hide = True
	    sample_uv_surface_001.data_type = 'FLOAT_VECTOR'
	    sample_uv_surface_001.outputs[1].hide = True
	
	    #node Group.001
	    group_001 = attach_hair_curves_to_surface.nodes.new("GeometryNodeGroup")
	    group_001.name = "Group.001"
	    group_001.node_tree = curve_root_001
	    group_001.outputs[0].hide = True
	    group_001.outputs[2].hide = True
	    group_001.outputs[3].hide = True
	
	    #node Position.001
	    position_001 = attach_hair_curves_to_surface.nodes.new("GeometryNodeInputPosition")
	    position_001.name = "Position.001"
	
	    #node Vector Math
	    vector_math = attach_hair_curves_to_surface.nodes.new("ShaderNodeVectorMath")
	    vector_math.name = "Vector Math"
	    vector_math.operation = 'SUBTRACT'
	
	    #node Vector Math.001
	    vector_math_001 = attach_hair_curves_to_surface.nodes.new("ShaderNodeVectorMath")
	    vector_math_001.name = "Vector Math.001"
	    vector_math_001.operation = 'SUBTRACT'
	
	    #node Vector Math.004
	    vector_math_004 = attach_hair_curves_to_surface.nodes.new("ShaderNodeVectorMath")
	    vector_math_004.name = "Vector Math.004"
	    vector_math_004.operation = 'SUBTRACT'
	
	    #node Vector Math.003
	    vector_math_003 = attach_hair_curves_to_surface.nodes.new("ShaderNodeVectorMath")
	    vector_math_003.name = "Vector Math.003"
	    vector_math_003.operation = 'SUBTRACT'
	
	    #node Group Input.003
	    group_input_003 = attach_hair_curves_to_surface.nodes.new("NodeGroupInput")
	    group_input_003.name = "Group Input.003"
	    group_input_003.outputs[0].hide = True
	    group_input_003.outputs[1].hide = True
	    group_input_003.outputs[2].hide = True
	    group_input_003.outputs[3].hide = True
	    group_input_003.outputs[4].hide = True
	    group_input_003.outputs[5].hide = True
	    group_input_003.outputs[6].hide = True
	    group_input_003.outputs[8].hide = True
	    group_input_003.outputs[9].hide = True
	
	    #node Group Input.006
	    group_input_006 = attach_hair_curves_to_surface.nodes.new("NodeGroupInput")
	    group_input_006.name = "Group Input.006"
	    group_input_006.outputs[0].hide = True
	    group_input_006.outputs[1].hide = True
	    group_input_006.outputs[2].hide = True
	    group_input_006.outputs[3].hide = True
	    group_input_006.outputs[4].hide = True
	    group_input_006.outputs[5].hide = True
	    group_input_006.outputs[7].hide = True
	    group_input_006.outputs[8].hide = True
	    group_input_006.outputs[9].hide = True
	
	    #node Switch.003
	    switch_003 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSwitch")
	    switch_003.name = "Switch.003"
	    switch_003.hide = True
	    switch_003.input_type = 'VECTOR'
	    #False
	    switch_003.inputs[1].default_value = (0.0, 0.0, 0.0)
	
	    #node Switch.002
	    switch_002 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSwitch")
	    switch_002.name = "Switch.002"
	    switch_002.input_type = 'VECTOR'
	
	    #node Vector Math.002
	    vector_math_002 = attach_hair_curves_to_surface.nodes.new("ShaderNodeVectorMath")
	    vector_math_002.name = "Vector Math.002"
	    vector_math_002.operation = 'ADD'
	
	    #node Vector Math.005
	    vector_math_005 = attach_hair_curves_to_surface.nodes.new("ShaderNodeVectorMath")
	    vector_math_005.name = "Vector Math.005"
	    vector_math_005.operation = 'SCALE'
	
	    #node Boolean Math
	    boolean_math = attach_hair_curves_to_surface.nodes.new("FunctionNodeBooleanMath")
	    boolean_math.name = "Boolean Math"
	    boolean_math.operation = 'OR'
	
	    #node Spline Parameter
	    spline_parameter = attach_hair_curves_to_surface.nodes.new("GeometryNodeSplineParameter")
	    spline_parameter.name = "Spline Parameter"
	    spline_parameter.outputs[1].hide = True
	    spline_parameter.outputs[2].hide = True
	
	    #node Group Input.008
	    group_input_008 = attach_hair_curves_to_surface.nodes.new("NodeGroupInput")
	    group_input_008.name = "Group Input.008"
	    group_input_008.outputs[0].hide = True
	    group_input_008.outputs[1].hide = True
	    group_input_008.outputs[2].hide = True
	    group_input_008.outputs[3].hide = True
	    group_input_008.outputs[4].hide = True
	    group_input_008.outputs[5].hide = True
	    group_input_008.outputs[6].hide = True
	    group_input_008.outputs[7].hide = True
	    group_input_008.outputs[9].hide = True
	
	    #node Map Range
	    map_range = attach_hair_curves_to_surface.nodes.new("ShaderNodeMapRange")
	    map_range.name = "Map Range"
	    map_range.hide = True
	    map_range.clamp = True
	    map_range.data_type = 'FLOAT'
	    map_range.interpolation_type = 'SMOOTHSTEP'
	    #From Min
	    map_range.inputs[1].default_value = 0.0
	    #To Min
	    map_range.inputs[3].default_value = 1.0
	    #To Max
	    map_range.inputs[4].default_value = 0.0
	
	    #node Compare
	    compare = attach_hair_curves_to_surface.nodes.new("FunctionNodeCompare")
	    compare.name = "Compare"
	    compare.data_type = 'FLOAT'
	    compare.mode = 'ELEMENT'
	    compare.operation = 'EQUAL'
	    #B
	    compare.inputs[1].default_value = 0.0
	    #Epsilon
	    compare.inputs[12].default_value = 0.0
	
	    #node Switch.004
	    switch_004 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSwitch")
	    switch_004.name = "Switch.004"
	    switch_004.input_type = 'FLOAT'
	    #True
	    switch_004.inputs[2].default_value = 1.0
	
	    #node Position.002
	    position_002_1 = attach_hair_curves_to_surface.nodes.new("GeometryNodeInputPosition")
	    position_002_1.name = "Position.002"
	
	    #node Evaluate on Domain
	    evaluate_on_domain = attach_hair_curves_to_surface.nodes.new("GeometryNodeFieldOnDomain")
	    evaluate_on_domain.name = "Evaluate on Domain"
	    evaluate_on_domain.data_type = 'FLOAT_VECTOR'
	    evaluate_on_domain.domain = 'CURVE'
	
	    #node Reroute.009
	    reroute_009 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_009.name = "Reroute.009"
	    reroute_009.socket_idname = "NodeSocketVector"
	    #node Evaluate on Domain.002
	    evaluate_on_domain_002 = attach_hair_curves_to_surface.nodes.new("GeometryNodeFieldOnDomain")
	    evaluate_on_domain_002.name = "Evaluate on Domain.002"
	    evaluate_on_domain_002.hide = True
	    evaluate_on_domain_002.data_type = 'FLOAT_VECTOR'
	    evaluate_on_domain_002.domain = 'CURVE'
	
	    #node Switch.006
	    switch_006 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSwitch")
	    switch_006.name = "Switch.006"
	    switch_006.input_type = 'VECTOR'
	
	    #node Vector Rotate
	    vector_rotate = attach_hair_curves_to_surface.nodes.new("ShaderNodeVectorRotate")
	    vector_rotate.name = "Vector Rotate"
	    vector_rotate.invert = False
	    vector_rotate.rotation_type = 'EULER_XYZ'
	    vector_rotate.inputs[1].hide = True
	    vector_rotate.inputs[2].hide = True
	    vector_rotate.inputs[3].hide = True
	    #Center
	    vector_rotate.inputs[1].default_value = (0.0, 0.0, 0.0)
	
	    #node Vector Rotate.003
	    vector_rotate_003 = attach_hair_curves_to_surface.nodes.new("ShaderNodeVectorRotate")
	    vector_rotate_003.name = "Vector Rotate.003"
	    vector_rotate_003.invert = True
	    vector_rotate_003.rotation_type = 'EULER_XYZ'
	    vector_rotate_003.inputs[1].hide = True
	    vector_rotate_003.inputs[2].hide = True
	    vector_rotate_003.inputs[3].hide = True
	    #Center
	    vector_rotate_003.inputs[1].default_value = (0.0, 0.0, 0.0)
	
	    #node Align Euler to Vector.003
	    align_euler_to_vector_003 = attach_hair_curves_to_surface.nodes.new("FunctionNodeAlignEulerToVector")
	    align_euler_to_vector_003.name = "Align Euler to Vector.003"
	    align_euler_to_vector_003.axis = 'Z'
	    align_euler_to_vector_003.pivot_axis = 'AUTO'
	    align_euler_to_vector_003.inputs[0].hide = True
	    align_euler_to_vector_003.inputs[1].hide = True
	    #Rotation
	    align_euler_to_vector_003.inputs[0].default_value = (0.0, 0.0, 0.0)
	    #Factor
	    align_euler_to_vector_003.inputs[1].default_value = 1.0
	
	    #node Align Euler to Vector.002
	    align_euler_to_vector_002 = attach_hair_curves_to_surface.nodes.new("FunctionNodeAlignEulerToVector")
	    align_euler_to_vector_002.name = "Align Euler to Vector.002"
	    align_euler_to_vector_002.axis = 'Z'
	    align_euler_to_vector_002.pivot_axis = 'AUTO'
	    align_euler_to_vector_002.inputs[0].hide = True
	    align_euler_to_vector_002.inputs[1].hide = True
	    #Rotation
	    align_euler_to_vector_002.inputs[0].default_value = (0.0, 0.0, 0.0)
	    #Factor
	    align_euler_to_vector_002.inputs[1].default_value = 1.0
	
	    #node Evaluate on Domain.003
	    evaluate_on_domain_003 = attach_hair_curves_to_surface.nodes.new("GeometryNodeFieldOnDomain")
	    evaluate_on_domain_003.name = "Evaluate on Domain.003"
	    evaluate_on_domain_003.hide = True
	    evaluate_on_domain_003.data_type = 'FLOAT_VECTOR'
	    evaluate_on_domain_003.domain = 'CURVE'
	
	    #node Switch.001
	    switch_001 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSwitch")
	    switch_001.name = "Switch.001"
	    switch_001.hide = True
	    switch_001.input_type = 'VECTOR'
	
	    #node Accumulate Field
	    accumulate_field = attach_hair_curves_to_surface.nodes.new("GeometryNodeAccumulateField")
	    accumulate_field.name = "Accumulate Field"
	    accumulate_field.hide = True
	    accumulate_field.data_type = 'FLOAT'
	    accumulate_field.domain = 'POINT'
	    #Group Index
	    accumulate_field.inputs[1].default_value = 0
	
	    #node Sample Index.001
	    sample_index_001 = attach_hair_curves_to_surface.nodes.new("GeometryNodeSampleIndex")
	    sample_index_001.name = "Sample Index.001"
	    sample_index_001.hide = True
	    sample_index_001.clamp = False
	    sample_index_001.data_type = 'BOOLEAN'
	    sample_index_001.domain = 'CURVE'
	    #Index
	    sample_index_001.inputs[2].default_value = 0
	
	    #node Reroute.019
	    reroute_019 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_019.name = "Reroute.019"
	    reroute_019.socket_idname = "NodeSocketVector"
	    #node Named Attribute.002
	    named_attribute_002 = attach_hair_curves_to_surface.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute_002.name = "Named Attribute.002"
	    named_attribute_002.data_type = 'INT'
	    #Name
	    named_attribute_002.inputs[0].default_value = "guide_curve_index"
	
	    #node Reroute.007
	    reroute_007 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_007.name = "Reroute.007"
	    reroute_007.socket_idname = "NodeSocketGeometry"
	    #node Reroute.008
	    reroute_008 = attach_hair_curves_to_surface.nodes.new("NodeReroute")
	    reroute_008.name = "Reroute.008"
	    reroute_008.socket_idname = "NodeSocketVector"
	    #node Sample Index
	    sample_index = attach_hair_curves_to_surface.nodes.new("GeometryNodeSampleIndex")
	    sample_index.name = "Sample Index"
	    sample_index.hide = True
	    sample_index.clamp = False
	    sample_index.data_type = 'FLOAT_VECTOR'
	    sample_index.domain = 'CURVE'
	
	
	
	
	    #Set parents
	    frame_006.parent = frame
	    frame_007.parent = frame
	    frame_003.parent = frame_010
	    frame_002.parent = frame_010
	    frame_008.parent = frame_002
	    frame_009.parent = frame_002
	    reroute_003.parent = frame_004
	    switch.parent = frame_004
	    store_named_attribute.parent = frame_004
	    group_input_007.parent = frame_004
	    reroute_016.parent = frame_004
	    reroute_005.parent = frame_004
	    store_named_attribute_001.parent = frame_004
	    named_attribute_004.parent = frame_004
	    reroute_012.parent = frame_004
	    named_attribute_003.parent = frame_004
	    switch_008.parent = frame_004
	    switch_009.parent = frame_004
	    switch_010.parent = frame_004
	    reroute_002.parent = frame_005
	    reroute_018.parent = frame_005
	    reroute_017.parent = frame_005
	    group_input_009.parent = frame_005
	    position.parent = frame_005
	    named_attribute_001.parent = frame_005
	    group_input_004.parent = frame_006
	    domain_size_002.parent = frame_006
	    compare_001.parent = frame_006
	    object_info_001.parent = frame_007
	    group_input_002.parent = frame_007
	    switch_005.parent = frame
	    domain_size_003.parent = frame
	    compare_002.parent = frame
	    named_attribute.parent = frame
	    reroute.parent = frame
	    group_input_005.parent = frame
	    set_position.parent = frame
	    switch_007.parent = frame
	    sample_nearest_surface.parent = frame_011
	    group.parent = frame_011
	    group_input_001.parent = frame_011
	    normal.parent = frame_001
	    capture_attribute.parent = frame_001
	    sample_uv_surface.parent = frame_005
	    sample_uv_surface_003.parent = frame_005
	    reroute_004.parent = frame_005
	    sample_uv_surface_001.parent = frame_005
	    group_001.parent = frame_010
	    position_001.parent = frame_010
	    vector_math.parent = frame_010
	    vector_math_001.parent = frame_010
	    vector_math_004.parent = frame_010
	    vector_math_003.parent = frame_010
	    group_input_003.parent = frame_010
	    group_input_006.parent = frame_010
	    switch_003.parent = frame_010
	    switch_002.parent = frame_010
	    vector_math_002.parent = frame_010
	    vector_math_005.parent = frame_010
	    boolean_math.parent = frame_010
	    spline_parameter.parent = frame_003
	    group_input_008.parent = frame_003
	    map_range.parent = frame_003
	    compare.parent = frame_003
	    switch_004.parent = frame_003
	    position_002_1.parent = frame_010
	    evaluate_on_domain.parent = frame_010
	    reroute_009.parent = frame_002
	    evaluate_on_domain_002.parent = frame_002
	    switch_006.parent = frame_002
	    vector_rotate.parent = frame_002
	    vector_rotate_003.parent = frame_002
	    align_euler_to_vector_003.parent = frame_002
	    align_euler_to_vector_002.parent = frame_002
	    evaluate_on_domain_003.parent = frame_002
	    switch_001.parent = frame_008
	    accumulate_field.parent = frame_008
	    sample_index_001.parent = frame_008
	    reroute_019.parent = frame_002
	    named_attribute_002.parent = frame_009
	    reroute_007.parent = frame_009
	    reroute_008.parent = frame_009
	    sample_index.parent = frame_009
	
	    #Set locations
	    frame_004.location = (-1215.903076171875, 262.0)
	    frame_005.location = (-4968.0, -121.0)
	    frame.location = (-7319.0, 140.0)
	    frame_006.location = (30.0, -355.0)
	    frame_007.location = (207.0, -181.0)
	    frame_011.location = (-5752.0, 120.0)
	    frame_001.location = (-5510.0, -382.0)
	    frame_010.location = (-4110.3515625, 32.0)
	    frame_003.location = (1565.3515625, -503.0)
	    frame_002.location = (29.999755859375, -437.0)
	    frame_008.location = (219.351806640625, -40.0)
	    frame_009.location = (30.0, -217.5032958984375)
	    reroute_010.location = (-798.60986328125, 472.99615478515625)
	    reroute_013.location = (-789.0, 512.1389770507812)
	    group_output_1.location = (75.0, 50.0)
	    reroute_003.location = (35.0, -292.3721618652344)
	    switch.location = (320.95263671875, -40.143096923828125)
	    store_named_attribute.location = (115.3720703125, -151.72100830078125)
	    group_input_007.location = (122.9049072265625, -39.53450012207031)
	    reroute_016.location = (45.1358642578125, -151.72100830078125)
	    reroute_005.location = (406.810302734375, -272.2791442871094)
	    store_named_attribute_001.location = (527.368408203125, -51.255889892578125)
	    named_attribute_004.location = (607.740478515625, -513.3954467773438)
	    reroute_012.location = (768.484619140625, -252.18612670898438)
	    reroute_014.location = (-507.69775390625, 311.209228515625)
	    reroute_006.location = (-547.8837890625, 291.1162109375)
	    named_attribute_003.location = (607.740478515625, -352.6512451171875)
	    switch_008.location = (808.670654296875, -71.34890747070312)
	    switch_009.location = (808.670654296875, -212.00006103515625)
	    switch_010.location = (808.670654296875, -392.8372802734375)
	    set_position_001.location = (-1472.16259765625, 230.837158203125)
	    reroute_002.location = (220.65625, -190.25262451171875)
	    reroute_018.location = (220.65625, -150.06658935546875)
	    reroute_017.location = (220.65625, -109.88055419921875)
	    group_input_009.location = (29.99072265625, -180.322021484375)
	    position.location = (29.99072265625, -39.67083740234375)
	    named_attribute_001.location = (29.99072265625, -260.694091796875)
	    capture_attribute_001.location = (-4365.55810546875, 210.744140625)
	    group_input_004.location = (29.669921875, -178.9044189453125)
	    domain_size_002.location = (207.6806640625, -80.07354736328125)
	    compare_001.location = (388.517578125, -39.88751220703125)
	    object_info_001.location = (210.88330078125, -39.64691162109375)
	    group_input_002.location = (30.0458984375, -79.83294677734375)
	    switch_005.location = (640.525390625, -283.5823974609375)
	    domain_size_003.location = (938.8193359375, -79.91128540039062)
	    compare_002.location = (1119.65625, -39.725250244140625)
	    named_attribute.location = (820.7041015625, -432.90301513671875)
	    reroute.location = (961.35546875, -332.43792724609375)
	    group_input_005.location = (1021.63427734375, -252.0657958984375)
	    set_position.location = (1021.63427734375, -352.53094482421875)
	    switch_007.location = (1222.564453125, -231.9727783203125)
	    reroute_015.location = (-5129.0927734375, 532.2319946289062)
	    reroute_011.location = (-5109.0, 492.04595947265625)
	    group_input.location = (-5510.8603515625, 351.395263671875)
	    capture_attribute_002.location = (-5209.46484375, 230.837158203125)
	    reroute_001.location = (-4887.9765625, -653.2559814453125)
	    sample_nearest_surface.location = (210.7509765625, -40.199798583984375)
	    group.location = (29.9140625, -180.85098266601562)
	    group_input_001.location = (29.9140625, -100.4788818359375)
	    reroute_020.location = (-4526.30224609375, -10.2791748046875)
	    normal.location = (29.5712890625, -45.01953125)
	    capture_attribute.location = (230.50146484375, -45.01953125)
	    sample_uv_surface.location = (321.1396484375, -50.02386474609375)
	    sample_uv_surface_003.location = (321.1396484375, -130.39593505859375)
	    reroute_004.location = (220.6748046875, -230.86102294921875)
	    sample_uv_surface_001.location = (321.1396484375, -210.76800537109375)
	    group_001.location = (158.627685546875, -240.71258544921875)
	    position_001.location = (339.46484375, -321.08465576171875)
	    vector_math.location = (339.46484375, -140.2474365234375)
	    vector_math_001.location = (540.39501953125, -321.08465576171875)
	    vector_math_004.location = (1826.3486328125, -341.17767333984375)
	    vector_math_003.location = (2027.27880859375, -200.52651977539062)
	    group_input_003.location = (1424.48828125, -220.79666137695312)
	    group_input_006.location = (1424.48828125, -100.238525390625)
	    switch_003.location = (1625.41845703125, -180.61062622070312)
	    switch_002.location = (1625.41845703125, -220.79666137695312)
	    vector_math_002.location = (1826.3486328125, -140.424560546875)
	    vector_math_005.location = (2248.30224609375, -200.70364379882812)
	    boolean_math.location = (1625.41845703125, -39.959442138671875)
	    spline_parameter.location = (32.72265625, -81.9400634765625)
	    group_input_008.location = (30.322265625, -161.4296875)
	    map_range.location = (205.259765625, -190.3057861328125)
	    compare.location = (205.20068359375, -39.6795654296875)
	    switch_004.location = (386.037841796875, -59.772705078125)
	    position_002_1.location = (1625.41845703125, -371.6761474609375)
	    evaluate_on_domain.location = (531.248291015625, -115.30325317382812)
	    reroute_009.location = (731.747802734375, -64.921875)
	    evaluate_on_domain_002.location = (630.95361328125, -265.85211181640625)
	    switch_006.location = (992.6279296875, -64.921875)
	    vector_rotate.location = (1173.465087890625, -64.921875)
	    vector_rotate_003.location = (811.790771484375, -165.386962890625)
	    align_euler_to_vector_003.location = (630.95361328125, -165.386962890625)
	    align_euler_to_vector_002.location = (630.95361328125, -306.0382080078125)
	    evaluate_on_domain_003.location = (630.95361328125, -406.5032958984375)
	    switch_001.location = (210.67138671875, -105.2939453125)
	    accumulate_field.location = (29.834228515625, -45.014892578125)
	    sample_index_001.location = (29.834228515625, -85.200927734375)
	    reroute_019.location = (48.255859375, -185.48004150390625)
	    named_attribute_002.location = (35.0, -105.279052734375)
	    reroute_007.location = (35.0, -45.0)
	    reroute_008.location = (35.0, -85.18603515625)
	    sample_index.location = (215.837158203125, -65.093017578125)
	
	    #Set dimensions
	    frame_004.width, frame_004.height = 978.903076171875, 664.0
	    frame_005.width, frame_005.height = 491.0, 412.0
	    frame.width, frame.height = 1393.0, 646.0
	    frame_006.width, frame_006.height = 559.0, 261.0
	    frame_007.width, frame_007.height = 381.0, 215.0
	    frame_011.width, frame_011.height = 390.33642578125, 279.0
	    frame_001.width, frame_001.height = 401.0, 125.0
	    frame_010.width, frame_010.height = 2418.3515625, 971.0
	    frame_003.width, frame_003.height = 556.0, 250.0
	    frame_002.width, frame_002.height = 1343.351806640625, 504.0
	    frame_008.width, frame_008.height = 381.0, 160.0
	    frame_009.width, frame_009.height = 385.351806640625, 256.4967041015625
	    reroute_010.width, reroute_010.height = 100.0, 100.0
	    reroute_013.width, reroute_013.height = 100.0, 100.0
	    group_output_1.width, group_output_1.height = 140.0, 100.0
	    reroute_003.width, reroute_003.height = 100.0, 100.0
	    switch.width, switch.height = 140.0, 100.0
	    store_named_attribute.width, store_named_attribute.height = 140.0, 100.0
	    group_input_007.width, group_input_007.height = 140.0, 100.0
	    reroute_016.width, reroute_016.height = 100.0, 100.0
	    reroute_005.width, reroute_005.height = 100.0, 100.0
	    store_named_attribute_001.width, store_named_attribute_001.height = 140.0, 100.0
	    named_attribute_004.width, named_attribute_004.height = 140.0, 100.0
	    reroute_012.width, reroute_012.height = 100.0, 100.0
	    reroute_014.width, reroute_014.height = 100.0, 100.0
	    reroute_006.width, reroute_006.height = 100.0, 100.0
	    named_attribute_003.width, named_attribute_003.height = 140.0, 100.0
	    switch_008.width, switch_008.height = 140.0, 100.0
	    switch_009.width, switch_009.height = 140.0, 100.0
	    switch_010.width, switch_010.height = 140.0, 100.0
	    set_position_001.width, set_position_001.height = 140.0, 100.0
	    reroute_002.width, reroute_002.height = 100.0, 100.0
	    reroute_018.width, reroute_018.height = 100.0, 100.0
	    reroute_017.width, reroute_017.height = 100.0, 100.0
	    group_input_009.width, group_input_009.height = 140.0, 100.0
	    position.width, position.height = 140.0, 100.0
	    named_attribute_001.width, named_attribute_001.height = 140.0, 100.0
	    capture_attribute_001.width, capture_attribute_001.height = 140.0, 100.0
	    group_input_004.width, group_input_004.height = 140.0, 100.0
	    domain_size_002.width, domain_size_002.height = 140.0, 100.0
	    compare_001.width, compare_001.height = 140.0, 100.0
	    object_info_001.width, object_info_001.height = 140.0, 100.0
	    group_input_002.width, group_input_002.height = 140.0, 100.0
	    switch_005.width, switch_005.height = 140.0, 100.0
	    domain_size_003.width, domain_size_003.height = 140.0, 100.0
	    compare_002.width, compare_002.height = 140.0, 100.0
	    named_attribute.width, named_attribute.height = 140.0, 100.0
	    reroute.width, reroute.height = 100.0, 100.0
	    group_input_005.width, group_input_005.height = 140.0, 100.0
	    set_position.width, set_position.height = 140.0, 100.0
	    switch_007.width, switch_007.height = 140.0, 100.0
	    reroute_015.width, reroute_015.height = 100.0, 100.0
	    reroute_011.width, reroute_011.height = 100.0, 100.0
	    group_input.width, group_input.height = 140.0, 100.0
	    capture_attribute_002.width, capture_attribute_002.height = 140.0, 100.0
	    reroute_001.width, reroute_001.height = 100.0, 100.0
	    sample_nearest_surface.width, sample_nearest_surface.height = 149.33627319335938, 100.0
	    group.width, group.height = 140.0, 100.0
	    group_input_001.width, group_input_001.height = 140.0, 100.0
	    reroute_020.width, reroute_020.height = 100.0, 100.0
	    normal.width, normal.height = 140.0, 100.0
	    capture_attribute.width, capture_attribute.height = 140.0, 100.0
	    sample_uv_surface.width, sample_uv_surface.height = 140.0, 100.0
	    sample_uv_surface_003.width, sample_uv_surface_003.height = 140.0, 100.0
	    reroute_004.width, reroute_004.height = 100.0, 100.0
	    sample_uv_surface_001.width, sample_uv_surface_001.height = 140.0, 100.0
	    group_001.width, group_001.height = 140.0, 100.0
	    position_001.width, position_001.height = 140.0, 100.0
	    vector_math.width, vector_math.height = 140.0, 100.0
	    vector_math_001.width, vector_math_001.height = 140.0, 100.0
	    vector_math_004.width, vector_math_004.height = 140.0, 100.0
	    vector_math_003.width, vector_math_003.height = 140.0, 100.0
	    group_input_003.width, group_input_003.height = 140.0, 100.0
	    group_input_006.width, group_input_006.height = 140.0, 100.0
	    switch_003.width, switch_003.height = 140.0, 100.0
	    switch_002.width, switch_002.height = 140.0, 100.0
	    vector_math_002.width, vector_math_002.height = 140.0, 100.0
	    vector_math_005.width, vector_math_005.height = 140.0, 100.0
	    boolean_math.width, boolean_math.height = 140.0, 100.0
	    spline_parameter.width, spline_parameter.height = 140.0, 100.0
	    group_input_008.width, group_input_008.height = 140.0, 100.0
	    map_range.width, map_range.height = 140.0, 100.0
	    compare.width, compare.height = 140.0, 100.0
	    switch_004.width, switch_004.height = 140.0, 100.0
	    position_002_1.width, position_002_1.height = 140.0, 100.0
	    evaluate_on_domain.width, evaluate_on_domain.height = 140.0, 100.0
	    reroute_009.width, reroute_009.height = 100.0, 100.0
	    evaluate_on_domain_002.width, evaluate_on_domain_002.height = 140.0, 100.0
	    switch_006.width, switch_006.height = 140.0, 100.0
	    vector_rotate.width, vector_rotate.height = 140.0, 100.0
	    vector_rotate_003.width, vector_rotate_003.height = 140.0, 100.0
	    align_euler_to_vector_003.width, align_euler_to_vector_003.height = 140.0, 100.0
	    align_euler_to_vector_002.width, align_euler_to_vector_002.height = 140.0, 100.0
	    evaluate_on_domain_003.width, evaluate_on_domain_003.height = 140.0, 100.0
	    switch_001.width, switch_001.height = 140.0, 100.0
	    accumulate_field.width, accumulate_field.height = 140.0, 100.0
	    sample_index_001.width, sample_index_001.height = 140.0, 100.0
	    reroute_019.width, reroute_019.height = 100.0, 100.0
	    named_attribute_002.width, named_attribute_002.height = 140.0, 100.0
	    reroute_007.width, reroute_007.height = 100.0, 100.0
	    reroute_008.width, reroute_008.height = 100.0, 100.0
	    sample_index.width, sample_index.height = 140.0, 100.0
	
	    #initialize attach_hair_curves_to_surface links
	    #domain_size_002.Face Count -> compare_001.A
	    attach_hair_curves_to_surface.links.new(domain_size_002.outputs[2], compare_001.inputs[2])
	    #compare_001.Result -> switch_005.Switch
	    attach_hair_curves_to_surface.links.new(compare_001.outputs[0], switch_005.inputs[0])
	    #group_input_002.Surface -> object_info_001.Object
	    attach_hair_curves_to_surface.links.new(group_input_002.outputs[2], object_info_001.inputs[0])
	    #group_input_004.Surface -> domain_size_002.Geometry
	    attach_hair_curves_to_surface.links.new(group_input_004.outputs[1], domain_size_002.inputs[0])
	    #group_input_004.Surface -> switch_005.True
	    attach_hair_curves_to_surface.links.new(group_input_004.outputs[1], switch_005.inputs[2])
	    #group_input_001.Surface UV Map -> sample_nearest_surface.Value
	    attach_hair_curves_to_surface.links.new(group_input_001.outputs[3], sample_nearest_surface.inputs[1])
	    #reroute.Output -> set_position.Geometry
	    attach_hair_curves_to_surface.links.new(reroute.outputs[0], set_position.inputs[0])
	    #reroute.Output -> switch_007.False
	    attach_hair_curves_to_surface.links.new(reroute.outputs[0], switch_007.inputs[1])
	    #set_position.Geometry -> switch_007.True
	    attach_hair_curves_to_surface.links.new(set_position.outputs[0], switch_007.inputs[2])
	    #switch_005.Output -> reroute.Input
	    attach_hair_curves_to_surface.links.new(switch_005.outputs[0], reroute.inputs[0])
	    #group_input_005.Surface Rest Position -> switch_007.Switch
	    attach_hair_curves_to_surface.links.new(group_input_005.outputs[4], switch_007.inputs[0])
	    #named_attribute.Attribute -> set_position.Position
	    attach_hair_curves_to_surface.links.new(named_attribute.outputs[0], set_position.inputs[2])
	    #named_attribute.Exists -> set_position.Selection
	    attach_hair_curves_to_surface.links.new(named_attribute.outputs[1], set_position.inputs[1])
	    #switch_007.Output -> sample_nearest_surface.Mesh
	    attach_hair_curves_to_surface.links.new(switch_007.outputs[0], sample_nearest_surface.inputs[0])
	    #object_info_001.Geometry -> switch_005.False
	    attach_hair_curves_to_surface.links.new(object_info_001.outputs[4], switch_005.inputs[1])
	    #group.Root Position -> sample_nearest_surface.Sample Position
	    attach_hair_curves_to_surface.links.new(group.outputs[1], sample_nearest_surface.inputs[3])
	    #reroute_002.Output -> sample_uv_surface.UV Map
	    attach_hair_curves_to_surface.links.new(reroute_002.outputs[0], sample_uv_surface.inputs[2])
	    #position.Position -> sample_uv_surface.Value
	    attach_hair_curves_to_surface.links.new(position.outputs[0], sample_uv_surface.inputs[1])
	    #reroute_004.Output -> sample_uv_surface.Sample UV
	    attach_hair_curves_to_surface.links.new(reroute_004.outputs[0], sample_uv_surface.inputs[3])
	    #capture_attribute_001.Geometry -> set_position_001.Geometry
	    attach_hair_curves_to_surface.links.new(capture_attribute_001.outputs[0], set_position_001.inputs[0])
	    #reroute_017.Output -> sample_uv_surface_001.Mesh
	    attach_hair_curves_to_surface.links.new(reroute_017.outputs[0], sample_uv_surface_001.inputs[0])
	    #reroute_004.Output -> sample_uv_surface_001.Sample UV
	    attach_hair_curves_to_surface.links.new(reroute_004.outputs[0], sample_uv_surface_001.inputs[3])
	    #reroute_002.Output -> sample_uv_surface_001.UV Map
	    attach_hair_curves_to_surface.links.new(reroute_002.outputs[0], sample_uv_surface_001.inputs[2])
	    #normal.Normal -> capture_attribute.Value
	    attach_hair_curves_to_surface.links.new(normal.outputs[0], capture_attribute.inputs[1])
	    #reroute_018.Output -> sample_uv_surface_001.Value
	    attach_hair_curves_to_surface.links.new(reroute_018.outputs[0], sample_uv_surface_001.inputs[1])
	    #sample_uv_surface.Value -> vector_math.Vector
	    attach_hair_curves_to_surface.links.new(sample_uv_surface.outputs[0], vector_math.inputs[0])
	    #group_001.Root Position -> vector_math.Vector
	    attach_hair_curves_to_surface.links.new(group_001.outputs[1], vector_math.inputs[1])
	    #vector_math.Vector -> evaluate_on_domain.Value
	    attach_hair_curves_to_surface.links.new(vector_math.outputs[0], evaluate_on_domain.inputs[0])
	    #position_001.Position -> vector_math_001.Vector
	    attach_hair_curves_to_surface.links.new(position_001.outputs[0], vector_math_001.inputs[0])
	    #group_001.Root Position -> vector_math_001.Vector
	    attach_hair_curves_to_surface.links.new(group_001.outputs[1], vector_math_001.inputs[1])
	    #switch_006.Output -> vector_rotate.Vector
	    attach_hair_curves_to_surface.links.new(switch_006.outputs[0], vector_rotate.inputs[0])
	    #reroute_007.Output -> sample_index.Geometry
	    attach_hair_curves_to_surface.links.new(reroute_007.outputs[0], sample_index.inputs[0])
	    #named_attribute_002.Attribute -> sample_index.Index
	    attach_hair_curves_to_surface.links.new(named_attribute_002.outputs[0], sample_index.inputs[2])
	    #position_002_1.Position -> vector_math_004.Vector
	    attach_hair_curves_to_surface.links.new(position_002_1.outputs[0], vector_math_004.inputs[0])
	    #vector_math_002.Vector -> vector_math_003.Vector
	    attach_hair_curves_to_surface.links.new(vector_math_002.outputs[0], vector_math_003.inputs[0])
	    #switch_003.Output -> vector_math_002.Vector
	    attach_hair_curves_to_surface.links.new(switch_003.outputs[0], vector_math_002.inputs[0])
	    #switch_002.Output -> vector_math_002.Vector
	    attach_hair_curves_to_surface.links.new(switch_002.outputs[0], vector_math_002.inputs[1])
	    #reroute_009.Output -> vector_rotate_003.Vector
	    attach_hair_curves_to_surface.links.new(reroute_009.outputs[0], vector_rotate_003.inputs[0])
	    #evaluate_on_domain_002.Value -> vector_rotate_003.Rotation
	    attach_hair_curves_to_surface.links.new(evaluate_on_domain_002.outputs[0], vector_rotate_003.inputs[4])
	    #evaluate_on_domain_003.Value -> vector_rotate.Rotation
	    attach_hair_curves_to_surface.links.new(evaluate_on_domain_003.outputs[0], vector_rotate.inputs[4])
	    #group_001.Root Position -> vector_math_004.Vector
	    attach_hair_curves_to_surface.links.new(group_001.outputs[1], vector_math_004.inputs[1])
	    #vector_math_004.Vector -> vector_math_003.Vector
	    attach_hair_curves_to_surface.links.new(vector_math_004.outputs[0], vector_math_003.inputs[1])
	    #reroute_016.Output -> store_named_attribute.Geometry
	    attach_hair_curves_to_surface.links.new(reroute_016.outputs[0], store_named_attribute.inputs[0])
	    #group_input.Geometry -> capture_attribute_002.Geometry
	    attach_hair_curves_to_surface.links.new(group_input.outputs[0], capture_attribute_002.inputs[0])
	    #reroute_003.Output -> store_named_attribute.Value
	    attach_hair_curves_to_surface.links.new(reroute_003.outputs[0], store_named_attribute.inputs[3])
	    #sample_nearest_surface.Value -> capture_attribute_002.Value
	    attach_hair_curves_to_surface.links.new(sample_nearest_surface.outputs[0], capture_attribute_002.inputs[1])
	    #capture_attribute_002.Value -> reroute_004.Input
	    attach_hair_curves_to_surface.links.new(capture_attribute_002.outputs[1], reroute_004.inputs[0])
	    #switch_007.Output -> capture_attribute.Geometry
	    attach_hair_curves_to_surface.links.new(switch_007.outputs[0], capture_attribute.inputs[0])
	    #align_euler_to_vector_003.Rotation -> evaluate_on_domain_002.Value
	    attach_hair_curves_to_surface.links.new(align_euler_to_vector_003.outputs[0], evaluate_on_domain_002.inputs[0])
	    #align_euler_to_vector_002.Rotation -> evaluate_on_domain_003.Value
	    attach_hair_curves_to_surface.links.new(align_euler_to_vector_002.outputs[0], evaluate_on_domain_003.inputs[0])
	    #capture_attribute.Geometry -> reroute_001.Input
	    attach_hair_curves_to_surface.links.new(capture_attribute.outputs[0], reroute_001.inputs[0])
	    #reroute_018.Output -> sample_uv_surface_003.Value
	    attach_hair_curves_to_surface.links.new(reroute_018.outputs[0], sample_uv_surface_003.inputs[1])
	    #reroute_002.Output -> sample_uv_surface_003.UV Map
	    attach_hair_curves_to_surface.links.new(reroute_002.outputs[0], sample_uv_surface_003.inputs[2])
	    #reroute_017.Output -> sample_uv_surface_003.Mesh
	    attach_hair_curves_to_surface.links.new(reroute_017.outputs[0], sample_uv_surface_003.inputs[0])
	    #named_attribute_001.Attribute -> sample_uv_surface_003.Sample UV
	    attach_hair_curves_to_surface.links.new(named_attribute_001.outputs[0], sample_uv_surface_003.inputs[3])
	    #reroute_019.Output -> switch_001.True
	    attach_hair_curves_to_surface.links.new(reroute_019.outputs[0], switch_001.inputs[2])
	    #reroute_020.Output -> sample_index_001.Geometry
	    attach_hair_curves_to_surface.links.new(reroute_020.outputs[0], sample_index_001.inputs[0])
	    #named_attribute_001.Exists -> accumulate_field.Value
	    attach_hair_curves_to_surface.links.new(named_attribute_001.outputs[1], accumulate_field.inputs[0])
	    #accumulate_field.Total -> sample_index_001.Value
	    attach_hair_curves_to_surface.links.new(accumulate_field.outputs[2], sample_index_001.inputs[1])
	    #sample_index_001.Value -> switch_001.Switch
	    attach_hair_curves_to_surface.links.new(sample_index_001.outputs[0], switch_001.inputs[0])
	    #reroute_008.Output -> sample_index.Value
	    attach_hair_curves_to_surface.links.new(reroute_008.outputs[0], sample_index.inputs[1])
	    #vector_rotate.Vector -> switch_002.True
	    attach_hair_curves_to_surface.links.new(vector_rotate.outputs[0], switch_002.inputs[2])
	    #vector_math_001.Vector -> switch_002.False
	    attach_hair_curves_to_surface.links.new(vector_math_001.outputs[0], switch_002.inputs[1])
	    #group_input_003.Align to Surface Normal -> switch_002.Switch
	    attach_hair_curves_to_surface.links.new(group_input_003.outputs[7], switch_002.inputs[0])
	    #vector_math_005.Vector -> set_position_001.Offset
	    attach_hair_curves_to_surface.links.new(vector_math_005.outputs[0], set_position_001.inputs[3])
	    #evaluate_on_domain.Value -> switch_003.True
	    attach_hair_curves_to_surface.links.new(evaluate_on_domain.outputs[0], switch_003.inputs[2])
	    #group_input_006.Snap to Surface -> switch_003.Switch
	    attach_hair_curves_to_surface.links.new(group_input_006.outputs[6], switch_003.inputs[0])
	    #group_input_006.Snap to Surface -> boolean_math.Boolean
	    attach_hair_curves_to_surface.links.new(group_input_006.outputs[6], boolean_math.inputs[0])
	    #group_input_003.Align to Surface Normal -> boolean_math.Boolean
	    attach_hair_curves_to_surface.links.new(group_input_003.outputs[7], boolean_math.inputs[1])
	    #boolean_math.Boolean -> set_position_001.Selection
	    attach_hair_curves_to_surface.links.new(boolean_math.outputs[0], set_position_001.inputs[1])
	    #capture_attribute_002.Value -> reroute_003.Input
	    attach_hair_curves_to_surface.links.new(capture_attribute_002.outputs[1], reroute_003.inputs[0])
	    #switch_009.Output -> group_output_1.Surface UV Coordinate
	    attach_hair_curves_to_surface.links.new(switch_009.outputs[0], group_output_1.inputs[1])
	    #store_named_attribute.Geometry -> switch.True
	    attach_hair_curves_to_surface.links.new(store_named_attribute.outputs[0], switch.inputs[2])
	    #group_input_007.Sample Attachment UV -> switch.Switch
	    attach_hair_curves_to_surface.links.new(group_input_007.outputs[5], switch.inputs[0])
	    #reroute_016.Output -> switch.False
	    attach_hair_curves_to_surface.links.new(reroute_016.outputs[0], switch.inputs[1])
	    #switch.Output -> store_named_attribute_001.Geometry
	    attach_hair_curves_to_surface.links.new(switch.outputs[0], store_named_attribute_001.inputs[0])
	    #reroute_020.Output -> capture_attribute_001.Geometry
	    attach_hair_curves_to_surface.links.new(reroute_020.outputs[0], capture_attribute_001.inputs[0])
	    #reroute_005.Output -> store_named_attribute_001.Value
	    attach_hair_curves_to_surface.links.new(reroute_005.outputs[0], store_named_attribute_001.inputs[3])
	    #capture_attribute_001.Value -> reroute_005.Input
	    attach_hair_curves_to_surface.links.new(capture_attribute_001.outputs[1], reroute_005.inputs[0])
	    #switch_010.Output -> group_output_1.Surface Normal
	    attach_hair_curves_to_surface.links.new(switch_010.outputs[0], group_output_1.inputs[2])
	    #sample_uv_surface_001.Value -> capture_attribute_001.Value
	    attach_hair_curves_to_surface.links.new(sample_uv_surface_001.outputs[0], capture_attribute_001.inputs[1])
	    #vector_math_003.Vector -> vector_math_005.Vector
	    attach_hair_curves_to_surface.links.new(vector_math_003.outputs[0], vector_math_005.inputs[0])
	    #spline_parameter.Factor -> map_range.Value
	    attach_hair_curves_to_surface.links.new(spline_parameter.outputs[0], map_range.inputs[0])
	    #group_input_008.Blend along Curve -> map_range.From Max
	    attach_hair_curves_to_surface.links.new(group_input_008.outputs[8], map_range.inputs[2])
	    #group_input_008.Blend along Curve -> compare.A
	    attach_hair_curves_to_surface.links.new(group_input_008.outputs[8], compare.inputs[0])
	    #compare.Result -> switch_004.Switch
	    attach_hair_curves_to_surface.links.new(compare.outputs[0], switch_004.inputs[0])
	    #map_range.Result -> switch_004.False
	    attach_hair_curves_to_surface.links.new(map_range.outputs[0], switch_004.inputs[1])
	    #switch_004.Output -> vector_math_005.Scale
	    attach_hair_curves_to_surface.links.new(switch_004.outputs[0], vector_math_005.inputs[3])
	    #switch_001.Output -> align_euler_to_vector_003.Vector
	    attach_hair_curves_to_surface.links.new(switch_001.outputs[0], align_euler_to_vector_003.inputs[2])
	    #sample_index.Value -> switch_001.False
	    attach_hair_curves_to_surface.links.new(sample_index.outputs[0], switch_001.inputs[1])
	    #named_attribute_002.Exists -> switch_006.Switch
	    attach_hair_curves_to_surface.links.new(named_attribute_002.outputs[1], switch_006.inputs[0])
	    #reroute_009.Output -> switch_006.False
	    attach_hair_curves_to_surface.links.new(reroute_009.outputs[0], switch_006.inputs[1])
	    #vector_rotate_003.Vector -> switch_006.True
	    attach_hair_curves_to_surface.links.new(vector_rotate_003.outputs[0], switch_006.inputs[2])
	    #vector_math_001.Vector -> reroute_009.Input
	    attach_hair_curves_to_surface.links.new(vector_math_001.outputs[0], reroute_009.inputs[0])
	    #reroute_011.Output -> reroute_010.Input
	    attach_hair_curves_to_surface.links.new(reroute_011.outputs[0], reroute_010.inputs[0])
	    #group_input.Geometry -> reroute_011.Input
	    attach_hair_curves_to_surface.links.new(group_input.outputs[0], reroute_011.inputs[0])
	    #store_named_attribute_001.Geometry -> switch_008.False
	    attach_hair_curves_to_surface.links.new(store_named_attribute_001.outputs[0], switch_008.inputs[1])
	    #reroute_006.Output -> switch_008.True
	    attach_hair_curves_to_surface.links.new(reroute_006.outputs[0], switch_008.inputs[2])
	    #switch_008.Output -> group_output_1.Geometry
	    attach_hair_curves_to_surface.links.new(switch_008.outputs[0], group_output_1.inputs[0])
	    #reroute_003.Output -> switch_009.False
	    attach_hair_curves_to_surface.links.new(reroute_003.outputs[0], switch_009.inputs[1])
	    #reroute_005.Output -> switch_010.False
	    attach_hair_curves_to_surface.links.new(reroute_005.outputs[0], switch_010.inputs[1])
	    #domain_size_003.Face Count -> compare_002.A
	    attach_hair_curves_to_surface.links.new(domain_size_003.outputs[2], compare_002.inputs[2])
	    #switch_005.Output -> domain_size_003.Geometry
	    attach_hair_curves_to_surface.links.new(switch_005.outputs[0], domain_size_003.inputs[0])
	    #reroute_012.Output -> switch_008.Switch
	    attach_hair_curves_to_surface.links.new(reroute_012.outputs[0], switch_008.inputs[0])
	    #reroute_014.Output -> reroute_012.Input
	    attach_hair_curves_to_surface.links.new(reroute_014.outputs[0], reroute_012.inputs[0])
	    #reroute_012.Output -> switch_009.Switch
	    attach_hair_curves_to_surface.links.new(reroute_012.outputs[0], switch_009.inputs[0])
	    #reroute_012.Output -> switch_010.Switch
	    attach_hair_curves_to_surface.links.new(reroute_012.outputs[0], switch_010.inputs[0])
	    #named_attribute_003.Attribute -> switch_009.True
	    attach_hair_curves_to_surface.links.new(named_attribute_003.outputs[0], switch_009.inputs[2])
	    #named_attribute_004.Attribute -> switch_010.True
	    attach_hair_curves_to_surface.links.new(named_attribute_004.outputs[0], switch_010.inputs[2])
	    #reroute_015.Output -> reroute_013.Input
	    attach_hair_curves_to_surface.links.new(reroute_015.outputs[0], reroute_013.inputs[0])
	    #reroute_013.Output -> reroute_014.Input
	    attach_hair_curves_to_surface.links.new(reroute_013.outputs[0], reroute_014.inputs[0])
	    #compare_002.Result -> reroute_015.Input
	    attach_hair_curves_to_surface.links.new(compare_002.outputs[0], reroute_015.inputs[0])
	    #set_position_001.Geometry -> reroute_016.Input
	    attach_hair_curves_to_surface.links.new(set_position_001.outputs[0], reroute_016.inputs[0])
	    #capture_attribute.Geometry -> reroute_017.Input
	    attach_hair_curves_to_surface.links.new(capture_attribute.outputs[0], reroute_017.inputs[0])
	    #capture_attribute.Value -> reroute_018.Input
	    attach_hair_curves_to_surface.links.new(capture_attribute.outputs[1], reroute_018.inputs[0])
	    #reroute_010.Output -> reroute_006.Input
	    attach_hair_curves_to_surface.links.new(reroute_010.outputs[0], reroute_006.inputs[0])
	    #reroute_001.Output -> reroute_007.Input
	    attach_hair_curves_to_surface.links.new(reroute_001.outputs[0], reroute_007.inputs[0])
	    #sample_uv_surface_001.Value -> reroute_008.Input
	    attach_hair_curves_to_surface.links.new(sample_uv_surface_001.outputs[0], reroute_008.inputs[0])
	    #reroute_008.Output -> align_euler_to_vector_002.Vector
	    attach_hair_curves_to_surface.links.new(reroute_008.outputs[0], align_euler_to_vector_002.inputs[2])
	    #sample_uv_surface_003.Value -> reroute_019.Input
	    attach_hair_curves_to_surface.links.new(sample_uv_surface_003.outputs[0], reroute_019.inputs[0])
	    #reroute_017.Output -> sample_uv_surface.Mesh
	    attach_hair_curves_to_surface.links.new(reroute_017.outputs[0], sample_uv_surface.inputs[0])
	    #group_input_009.Surface UV Map -> reroute_002.Input
	    attach_hair_curves_to_surface.links.new(group_input_009.outputs[3], reroute_002.inputs[0])
	    #capture_attribute_002.Geometry -> reroute_020.Input
	    attach_hair_curves_to_surface.links.new(capture_attribute_002.outputs[0], reroute_020.inputs[0])
	    return attach_hair_curves_to_surface
	
	attach_hair_curves_to_surface = attach_hair_curves_to_surface_node_group()
	
	#initialize attach_hair node group
	def attach_hair_node_group():
	    attach_hair = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "ATTACH_HAIR")
	
	    attach_hair.color_tag = 'NONE'
	    attach_hair.description = ""
	    attach_hair.default_group_node_width = 140
	    
	
	    attach_hair.is_modifier = True
	
	    #attach_hair interface
	    #Socket Geometry
	    geometry_socket_2 = attach_hair.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_2.attribute_domain = 'POINT'
	
	    #Socket Geometry
	    geometry_socket_3 = attach_hair.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_3.attribute_domain = 'POINT'
	
	    #Socket Surface
	    surface_socket_2 = attach_hair.interface.new_socket(name = "Surface", in_out='INPUT', socket_type = 'NodeSocketObject')
	    surface_socket_2.attribute_domain = 'POINT'
	    surface_socket_2.description = "Surface Object to attach to (needs to have matching transforms)"
	
	    #Socket UV Map
	    uv_map_socket = attach_hair.interface.new_socket(name = "UV Map", in_out='INPUT', socket_type = 'NodeSocketString')
	    uv_map_socket.default_value = "UVMap"
	    uv_map_socket.subtype = 'NONE'
	    uv_map_socket.attribute_domain = 'POINT'
	    uv_map_socket.description = "Surface UV Map used to attach hair."
	
	    #Socket Blend along Curve
	    blend_along_curve_socket_1 = attach_hair.interface.new_socket(name = "Blend along Curve", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    blend_along_curve_socket_1.default_value = 0.05000000074505806
	    blend_along_curve_socket_1.min_value = 0.0
	    blend_along_curve_socket_1.max_value = 1.0
	    blend_along_curve_socket_1.subtype = 'FACTOR'
	    blend_along_curve_socket_1.attribute_domain = 'POINT'
	    blend_along_curve_socket_1.description = "Blend deformation along each curve from the root"
	
	
	    #initialize attach_hair nodes
	    #node Group Input
	    group_input_1 = attach_hair.nodes.new("NodeGroupInput")
	    group_input_1.name = "Group Input"
	    group_input_1.outputs[4].hide = True
	
	    #node Group Output
	    group_output_2 = attach_hair.nodes.new("NodeGroupOutput")
	    group_output_2.name = "Group Output"
	    group_output_2.is_active_output = True
	    group_output_2.inputs[1].hide = True
	
	    #node Group
	    group_1 = attach_hair.nodes.new("GeometryNodeGroup")
	    group_1.name = "Group"
	    group_1.node_tree = attach_hair_curves_to_surface
	    group_1.inputs[1].hide = True
	    group_1.inputs[4].hide = True
	    group_1.inputs[5].hide = True
	    group_1.inputs[6].hide = True
	    group_1.inputs[7].hide = True
	    group_1.outputs[1].hide = True
	    group_1.outputs[2].hide = True
	    #Socket_7
	    group_1.inputs[4].default_value = False
	    #Socket_8
	    group_1.inputs[5].default_value = True
	    #Socket_9
	    group_1.inputs[6].default_value = True
	    #Socket_10
	    group_1.inputs[7].default_value = False
	
	    #node Named Attribute
	    named_attribute_1 = attach_hair.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute_1.name = "Named Attribute"
	    named_attribute_1.hide = True
	    named_attribute_1.data_type = 'FLOAT_VECTOR'
	
	
	
	
	
	    #Set locations
	    group_input_1.location = (-340.0, 0.0)
	    group_output_2.location = (82.01471710205078, 24.076622009277344)
	    group_1.location = (-156.17784118652344, 22.037841796875)
	    named_attribute_1.location = (-333.9075622558594, -146.13522338867188)
	
	    #Set dimensions
	    group_input_1.width, group_input_1.height = 140.0, 100.0
	    group_output_2.width, group_output_2.height = 140.0, 100.0
	    group_1.width, group_1.height = 197.8995361328125, 100.0
	    named_attribute_1.width, named_attribute_1.height = 140.0, 100.0
	
	    #initialize attach_hair links
	    #group_1.Geometry -> group_output_2.Geometry
	    attach_hair.links.new(group_1.outputs[0], group_output_2.inputs[0])
	    #group_input_1.Geometry -> group_1.Geometry
	    attach_hair.links.new(group_input_1.outputs[0], group_1.inputs[0])
	    #named_attribute_1.Attribute -> group_1.Surface UV Map
	    attach_hair.links.new(named_attribute_1.outputs[0], group_1.inputs[3])
	    #group_input_1.Surface -> group_1.Surface
	    attach_hair.links.new(group_input_1.outputs[1], group_1.inputs[2])
	    #group_input_1.UV Map -> named_attribute_1.Name
	    attach_hair.links.new(group_input_1.outputs[2], named_attribute_1.inputs[0])
	    #group_input_1.Blend along Curve -> group_1.Blend along Curve
	    attach_hair.links.new(group_input_1.outputs[3], group_1.inputs[8])
	    return attach_hair
	
	attach_hair = attach_hair_node_group()
	
	#initialize hair_from_mesh node group
	def hair_from_mesh_node_group():
	    hair_from_mesh = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "HAIR_FROM_MESH")
	
	    hair_from_mesh.color_tag = 'NONE'
	    hair_from_mesh.description = "Convert mesh to hair curves. Hair roots are created from Mark Sharp edges and follow along shape of the mesh."
	    hair_from_mesh.default_group_node_width = 140
	    
	
	    hair_from_mesh.is_modifier = True
	
	    #hair_from_mesh interface
	    #Socket Geometry
	    geometry_socket_4 = hair_from_mesh.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_4.attribute_domain = 'POINT'
	    geometry_socket_4.description = "New hair curve."
	
	    #Socket Geometry
	    geometry_socket_5 = hair_from_mesh.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_5.attribute_domain = 'POINT'
	    geometry_socket_5.description = "Mesh used for hair conversion."
	
	    #Socket Surface
	    surface_socket_3 = hair_from_mesh.interface.new_socket(name = "Surface", in_out='INPUT', socket_type = 'NodeSocketObject')
	    surface_socket_3.attribute_domain = 'POINT'
	    surface_socket_3.description = "Surface to attach hair."
	
	    #Socket Material
	    material_socket = hair_from_mesh.interface.new_socket(name = "Material", in_out='INPUT', socket_type = 'NodeSocketMaterial')
	    material_socket.attribute_domain = 'POINT'
	    material_socket.description = "Hair material."
	
	    #Socket Subdivide Level
	    subdivide_level_socket = hair_from_mesh.interface.new_socket(name = "Subdivide Level", in_out='INPUT', socket_type = 'NodeSocketInt')
	    subdivide_level_socket.default_value = 1
	    subdivide_level_socket.min_value = 0
	    subdivide_level_socket.max_value = 6
	    subdivide_level_socket.subtype = 'NONE'
	    subdivide_level_socket.attribute_domain = 'POINT'
	    subdivide_level_socket.description = "Subdivision level used for mesh. Increase the number of hair strands per edge."
	
	    #Socket Length Factor
	    length_factor_socket = hair_from_mesh.interface.new_socket(name = "Length Factor", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    length_factor_socket.default_value = 1.0
	    length_factor_socket.min_value = 0.0
	    length_factor_socket.max_value = 1.0
	    length_factor_socket.subtype = 'FACTOR'
	    length_factor_socket.attribute_domain = 'POINT'
	    length_factor_socket.description = "Potential minimum hair length percentage to remain after random hair trim."
	
	    #Socket Seed
	    seed_socket = hair_from_mesh.interface.new_socket(name = "Seed", in_out='INPUT', socket_type = 'NodeSocketInt')
	    seed_socket.default_value = 0
	    seed_socket.min_value = -10000
	    seed_socket.max_value = 10000
	    seed_socket.subtype = 'NONE'
	    seed_socket.attribute_domain = 'POINT'
	    seed_socket.description = "Random seed for hair trim."
	
	    #Socket UV Map
	    uv_map_socket_1 = hair_from_mesh.interface.new_socket(name = "UV Map", in_out='INPUT', socket_type = 'NodeSocketString')
	    uv_map_socket_1.default_value = "UVMap"
	    uv_map_socket_1.subtype = 'NONE'
	    uv_map_socket_1.attribute_domain = 'POINT'
	    uv_map_socket_1.description = "Surface UV Map used to attach hair."
	
	    #Socket Blend along Curve
	    blend_along_curve_socket_2 = hair_from_mesh.interface.new_socket(name = "Blend along Curve", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    blend_along_curve_socket_2.default_value = 0.05000000074505806
	    blend_along_curve_socket_2.min_value = 0.0
	    blend_along_curve_socket_2.max_value = 1.0
	    blend_along_curve_socket_2.subtype = 'FACTOR'
	    blend_along_curve_socket_2.attribute_domain = 'POINT'
	    blend_along_curve_socket_2.description = "Blend deformation along each curve from the root"
	
	
	    #initialize hair_from_mesh nodes
	    #node Group Input
	    group_input_2 = hair_from_mesh.nodes.new("NodeGroupInput")
	    group_input_2.name = "Group Input"
	    group_input_2.outputs[0].hide = True
	    group_input_2.outputs[1].hide = True
	    group_input_2.outputs[2].hide = True
	    group_input_2.outputs[4].hide = True
	    group_input_2.outputs[5].hide = True
	    group_input_2.outputs[6].hide = True
	    group_input_2.outputs[7].hide = True
	    group_input_2.outputs[8].hide = True
	
	    #node Group Output
	    group_output_3 = hair_from_mesh.nodes.new("NodeGroupOutput")
	    group_output_3.name = "Group Output"
	    group_output_3.is_active_output = True
	    group_output_3.inputs[1].hide = True
	
	    #node Capture Attribute
	    capture_attribute_1 = hair_from_mesh.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_1.name = "Capture Attribute"
	    capture_attribute_1.hide = True
	    capture_attribute_1.active_index = 0
	    capture_attribute_1.capture_items.clear()
	    capture_attribute_1.capture_items.new('FLOAT', "Value")
	    capture_attribute_1.capture_items["Value"].data_type = 'FLOAT'
	    capture_attribute_1.domain = 'EDGE'
	
	    #node Named Attribute
	    named_attribute_2 = hair_from_mesh.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute_2.name = "Named Attribute"
	    named_attribute_2.hide = True
	    named_attribute_2.data_type = 'FLOAT'
	    #Name
	    named_attribute_2.inputs[0].default_value = "sharp_edge"
	
	    #node Shortest Edge Paths
	    shortest_edge_paths = hair_from_mesh.nodes.new("GeometryNodeInputShortestEdgePaths")
	    shortest_edge_paths.name = "Shortest Edge Paths"
	    shortest_edge_paths.inputs[1].hide = True
	    shortest_edge_paths.outputs[0].hide = True
	    #Edge Cost
	    shortest_edge_paths.inputs[1].default_value = 1.0
	
	    #node Delete Geometry
	    delete_geometry = hair_from_mesh.nodes.new("GeometryNodeDeleteGeometry")
	    delete_geometry.name = "Delete Geometry"
	    delete_geometry.hide = True
	    delete_geometry.domain = 'EDGE'
	    delete_geometry.mode = 'ALL'
	
	    #node Edge Vertices
	    edge_vertices = hair_from_mesh.nodes.new("GeometryNodeInputMeshEdgeVertices")
	    edge_vertices.name = "Edge Vertices"
	    edge_vertices.outputs[2].hide = True
	    edge_vertices.outputs[3].hide = True
	
	    #node Evaluate at Index
	    evaluate_at_index = hair_from_mesh.nodes.new("GeometryNodeFieldAtIndex")
	    evaluate_at_index.name = "Evaluate at Index"
	    evaluate_at_index.data_type = 'INT'
	    evaluate_at_index.domain = 'POINT'
	
	    #node Evaluate at Index.001
	    evaluate_at_index_001 = hair_from_mesh.nodes.new("GeometryNodeFieldAtIndex")
	    evaluate_at_index_001.name = "Evaluate at Index.001"
	    evaluate_at_index_001.data_type = 'INT'
	    evaluate_at_index_001.domain = 'POINT'
	
	    #node Compare
	    compare_1 = hair_from_mesh.nodes.new("FunctionNodeCompare")
	    compare_1.name = "Compare"
	    compare_1.data_type = 'INT'
	    compare_1.mode = 'ELEMENT'
	    compare_1.operation = 'EQUAL'
	
	    #node Capture Attribute.001
	    capture_attribute_001_1 = hair_from_mesh.nodes.new("GeometryNodeCaptureAttribute")
	    capture_attribute_001_1.name = "Capture Attribute.001"
	    capture_attribute_001_1.hide = True
	    capture_attribute_001_1.active_index = 0
	    capture_attribute_001_1.capture_items.clear()
	    capture_attribute_001_1.capture_items.new('FLOAT', "Value")
	    capture_attribute_001_1.capture_items["Value"].data_type = 'FLOAT'
	    capture_attribute_001_1.domain = 'POINT'
	
	    #node Mesh to Curve
	    mesh_to_curve = hair_from_mesh.nodes.new("GeometryNodeMeshToCurve")
	    mesh_to_curve.name = "Mesh to Curve"
	    mesh_to_curve.hide = True
	    #Selection
	    mesh_to_curve.inputs[1].default_value = True
	
	    #node Reverse Curve
	    reverse_curve = hair_from_mesh.nodes.new("GeometryNodeReverseCurve")
	    reverse_curve.name = "Reverse Curve"
	
	    #node Math
	    math = hair_from_mesh.nodes.new("ShaderNodeMath")
	    math.name = "Math"
	    math.hide = True
	    math.operation = 'MULTIPLY'
	    math.use_clamp = False
	
	    #node Endpoint Selection
	    endpoint_selection_1 = hair_from_mesh.nodes.new("GeometryNodeCurveEndpointSelection")
	    endpoint_selection_1.name = "Endpoint Selection"
	    endpoint_selection_1.hide = True
	    #Start Size
	    endpoint_selection_1.inputs[0].default_value = 1
	    #End Size
	    endpoint_selection_1.inputs[1].default_value = 0
	
	    #node Boolean Math
	    boolean_math_1 = hair_from_mesh.nodes.new("FunctionNodeBooleanMath")
	    boolean_math_1.name = "Boolean Math"
	    boolean_math_1.hide = True
	    boolean_math_1.operation = 'NOT'
	
	    #node Trim Curve
	    trim_curve = hair_from_mesh.nodes.new("GeometryNodeTrimCurve")
	    trim_curve.name = "Trim Curve"
	    trim_curve.mode = 'FACTOR'
	    trim_curve.inputs[1].hide = True
	    trim_curve.inputs[2].hide = True
	    trim_curve.inputs[4].hide = True
	    trim_curve.inputs[5].hide = True
	    #Selection
	    trim_curve.inputs[1].default_value = True
	    #Start
	    trim_curve.inputs[2].default_value = 0.0
	
	    #node Set Curve Radius
	    set_curve_radius = hair_from_mesh.nodes.new("GeometryNodeSetCurveRadius")
	    set_curve_radius.name = "Set Curve Radius"
	    set_curve_radius.inputs[1].hide = True
	    #Selection
	    set_curve_radius.inputs[1].default_value = True
	
	    #node Set Material
	    set_material = hair_from_mesh.nodes.new("GeometryNodeSetMaterial")
	    set_material.name = "Set Material"
	    set_material.inputs[1].hide = True
	    #Selection
	    set_material.inputs[1].default_value = True
	
	    #node Evaluate on Domain
	    evaluate_on_domain_1 = hair_from_mesh.nodes.new("GeometryNodeFieldOnDomain")
	    evaluate_on_domain_1.name = "Evaluate on Domain"
	    evaluate_on_domain_1.hide = True
	    evaluate_on_domain_1.data_type = 'FLOAT'
	    evaluate_on_domain_1.domain = 'POINT'
	
	    #node Map Range
	    map_range_1 = hair_from_mesh.nodes.new("ShaderNodeMapRange")
	    map_range_1.name = "Map Range"
	    map_range_1.clamp = True
	    map_range_1.data_type = 'FLOAT'
	    map_range_1.interpolation_type = 'LINEAR'
	    map_range_1.inputs[1].hide = True
	    map_range_1.inputs[2].hide = True
	    map_range_1.inputs[4].hide = True
	    map_range_1.inputs[5].hide = True
	    map_range_1.inputs[6].hide = True
	    map_range_1.inputs[7].hide = True
	    map_range_1.inputs[8].hide = True
	    map_range_1.inputs[9].hide = True
	    map_range_1.inputs[10].hide = True
	    map_range_1.inputs[11].hide = True
	    map_range_1.outputs[1].hide = True
	    #From Min
	    map_range_1.inputs[1].default_value = 0.0
	    #From Max
	    map_range_1.inputs[2].default_value = 1.0
	    #To Max
	    map_range_1.inputs[4].default_value = 1.0
	
	    #node Tip Trim Shape
	    tip_trim_shape = hair_from_mesh.nodes.new("ShaderNodeFloatCurve")
	    tip_trim_shape.label = "Tip Trim Shape"
	    tip_trim_shape.name = "Tip Trim Shape"
	    #mapping settings
	    tip_trim_shape.mapping.extend = 'EXTRAPOLATED'
	    tip_trim_shape.mapping.tone = 'STANDARD'
	    tip_trim_shape.mapping.black_level = (0.0, 0.0, 0.0)
	    tip_trim_shape.mapping.white_level = (1.0, 1.0, 1.0)
	    tip_trim_shape.mapping.clip_min_x = 0.0
	    tip_trim_shape.mapping.clip_min_y = 0.0
	    tip_trim_shape.mapping.clip_max_x = 1.0
	    tip_trim_shape.mapping.clip_max_y = 1.0
	    tip_trim_shape.mapping.use_clip = True
	    #curve 0
	    tip_trim_shape_curve_0 = tip_trim_shape.mapping.curves[0]
	    tip_trim_shape_curve_0_point_0 = tip_trim_shape_curve_0.points[0]
	    tip_trim_shape_curve_0_point_0.location = (0.0, 0.0)
	    tip_trim_shape_curve_0_point_0.handle_type = 'AUTO'
	    tip_trim_shape_curve_0_point_1 = tip_trim_shape_curve_0.points[1]
	    tip_trim_shape_curve_0_point_1.location = (0.281818151473999, 0.16875001788139343)
	    tip_trim_shape_curve_0_point_1.handle_type = 'AUTO'
	    tip_trim_shape_curve_0_point_2 = tip_trim_shape_curve_0.points.new(0.7136364579200745, 0.8625001907348633)
	    tip_trim_shape_curve_0_point_2.handle_type = 'AUTO'
	    tip_trim_shape_curve_0_point_3 = tip_trim_shape_curve_0.points.new(1.0, 1.0)
	    tip_trim_shape_curve_0_point_3.handle_type = 'AUTO'
	    #update curve after changes
	    tip_trim_shape.mapping.update()
	    #Factor
	    tip_trim_shape.inputs[0].default_value = 1.0
	
	    #node Random Value
	    random_value = hair_from_mesh.nodes.new("FunctionNodeRandomValue")
	    random_value.name = "Random Value"
	    random_value.data_type = 'FLOAT'
	    random_value.inputs[0].hide = True
	    random_value.inputs[1].hide = True
	    random_value.inputs[2].hide = True
	    random_value.inputs[3].hide = True
	    random_value.inputs[4].hide = True
	    random_value.inputs[5].hide = True
	    random_value.inputs[6].hide = True
	    random_value.inputs[7].hide = True
	    random_value.outputs[0].hide = True
	    random_value.outputs[2].hide = True
	    random_value.outputs[3].hide = True
	    #Min_001
	    random_value.inputs[2].default_value = 0.0
	    #Max_001
	    random_value.inputs[3].default_value = 1.0
	    #ID
	    random_value.inputs[7].default_value = 0
	
	    #node Math.001
	    math_001 = hair_from_mesh.nodes.new("ShaderNodeMath")
	    math_001.name = "Math.001"
	    math_001.hide = True
	    math_001.operation = 'MULTIPLY'
	    math_001.use_clamp = False
	    math_001.inputs[1].hide = True
	    math_001.inputs[2].hide = True
	    #Value_001
	    math_001.inputs[1].default_value = 0.0010000000474974513
	
	    #node Hair Strand Shape
	    hair_strand_shape = hair_from_mesh.nodes.new("ShaderNodeFloatCurve")
	    hair_strand_shape.label = "Hair Strand Shape"
	    hair_strand_shape.name = "Hair Strand Shape"
	    #mapping settings
	    hair_strand_shape.mapping.extend = 'EXTRAPOLATED'
	    hair_strand_shape.mapping.tone = 'STANDARD'
	    hair_strand_shape.mapping.black_level = (0.0, 0.0, 0.0)
	    hair_strand_shape.mapping.white_level = (1.0, 1.0, 1.0)
	    hair_strand_shape.mapping.clip_min_x = 0.0
	    hair_strand_shape.mapping.clip_min_y = 0.0
	    hair_strand_shape.mapping.clip_max_x = 1.0
	    hair_strand_shape.mapping.clip_max_y = 1.0
	    hair_strand_shape.mapping.use_clip = True
	    #curve 0
	    hair_strand_shape_curve_0 = hair_strand_shape.mapping.curves[0]
	    hair_strand_shape_curve_0_point_0 = hair_strand_shape_curve_0.points[0]
	    hair_strand_shape_curve_0_point_0.location = (0.0, 1.0)
	    hair_strand_shape_curve_0_point_0.handle_type = 'AUTO'
	    hair_strand_shape_curve_0_point_1 = hair_strand_shape_curve_0.points[1]
	    hair_strand_shape_curve_0_point_1.location = (0.3227272033691406, 0.9187501072883606)
	    hair_strand_shape_curve_0_point_1.handle_type = 'AUTO'
	    hair_strand_shape_curve_0_point_2 = hair_strand_shape_curve_0.points.new(0.6772727966308594, 0.15000002086162567)
	    hair_strand_shape_curve_0_point_2.handle_type = 'AUTO'
	    hair_strand_shape_curve_0_point_3 = hair_strand_shape_curve_0.points.new(1.0, 0.0)
	    hair_strand_shape_curve_0_point_3.handle_type = 'AUTO'
	    #update curve after changes
	    hair_strand_shape.mapping.update()
	    #Factor
	    hair_strand_shape.inputs[0].default_value = 1.0
	
	    #node Hair Strand Feather
	    hair_strand_feather = hair_from_mesh.nodes.new("ShaderNodeValToRGB")
	    hair_strand_feather.label = "Hair Strand Feather"
	    hair_strand_feather.name = "Hair Strand Feather"
	    hair_strand_feather.color_ramp.color_mode = 'RGB'
	    hair_strand_feather.color_ramp.hue_interpolation = 'NEAR'
	    hair_strand_feather.color_ramp.interpolation = 'LINEAR'
	
	    #initialize color ramp elements
	    hair_strand_feather.color_ramp.elements.remove(hair_strand_feather.color_ramp.elements[0])
	    hair_strand_feather_cre_0 = hair_strand_feather.color_ramp.elements[0]
	    hair_strand_feather_cre_0.position = 0.0
	    hair_strand_feather_cre_0.alpha = 1.0
	    hair_strand_feather_cre_0.color = (1.0, 1.0, 1.0, 1.0)
	
	    hair_strand_feather_cre_1 = hair_strand_feather.color_ramp.elements.new(0.07727272063493729)
	    hair_strand_feather_cre_1.alpha = 1.0
	    hair_strand_feather_cre_1.color = (0.0, 0.0, 0.0, 1.0)
	
	    hair_strand_feather_cre_2 = hair_strand_feather.color_ramp.elements.new(0.9318180680274963)
	    hair_strand_feather_cre_2.alpha = 1.0
	    hair_strand_feather_cre_2.color = (0.0, 0.0, 0.0, 1.0)
	
	    hair_strand_feather_cre_3 = hair_strand_feather.color_ramp.elements.new(1.0)
	    hair_strand_feather_cre_3.alpha = 1.0
	    hair_strand_feather_cre_3.color = (1.0, 1.0, 1.0, 1.0)
	
	
	    #node Spline Parameter
	    spline_parameter_1 = hair_from_mesh.nodes.new("GeometryNodeSplineParameter")
	    spline_parameter_1.name = "Spline Parameter"
	    spline_parameter_1.outputs[1].hide = True
	    spline_parameter_1.outputs[2].hide = True
	
	    #node Group Input.002
	    group_input_002_1 = hair_from_mesh.nodes.new("NodeGroupInput")
	    group_input_002_1.name = "Group Input.002"
	    group_input_002_1.outputs[0].hide = True
	    group_input_002_1.outputs[1].hide = True
	    group_input_002_1.outputs[2].hide = True
	    group_input_002_1.outputs[3].hide = True
	    group_input_002_1.outputs[5].hide = True
	    group_input_002_1.outputs[6].hide = True
	    group_input_002_1.outputs[7].hide = True
	    group_input_002_1.outputs[8].hide = True
	
	    #node Group Input.003
	    group_input_003_1 = hair_from_mesh.nodes.new("NodeGroupInput")
	    group_input_003_1.name = "Group Input.003"
	    group_input_003_1.outputs[0].hide = True
	    group_input_003_1.outputs[1].hide = True
	    group_input_003_1.outputs[3].hide = True
	    group_input_003_1.outputs[4].hide = True
	    group_input_003_1.outputs[5].hide = True
	    group_input_003_1.outputs[6].hide = True
	    group_input_003_1.outputs[7].hide = True
	    group_input_003_1.outputs[8].hide = True
	
	    #node Group Input.004
	    group_input_004_1 = hair_from_mesh.nodes.new("NodeGroupInput")
	    group_input_004_1.name = "Group Input.004"
	    group_input_004_1.outputs[0].hide = True
	    group_input_004_1.outputs[1].hide = True
	    group_input_004_1.outputs[2].hide = True
	    group_input_004_1.outputs[3].hide = True
	    group_input_004_1.outputs[4].hide = True
	    group_input_004_1.outputs[6].hide = True
	    group_input_004_1.outputs[7].hide = True
	    group_input_004_1.outputs[8].hide = True
	
	    #node Subdivide Mesh
	    subdivide_mesh = hair_from_mesh.nodes.new("GeometryNodeSubdivideMesh")
	    subdivide_mesh.name = "Subdivide Mesh"
	    subdivide_mesh.hide = True
	
	    #node Frame
	    frame_1 = hair_from_mesh.nodes.new("NodeFrame")
	    frame_1.label = "Delete Edges Calculations"
	    frame_1.name = "Frame"
	    frame_1.label_size = 20
	    frame_1.shrink = True
	
	    #node Frame.001
	    frame_001_1 = hair_from_mesh.nodes.new("NodeFrame")
	    frame_001_1.label = "Random Length"
	    frame_001_1.name = "Frame.001"
	    frame_001_1.label_size = 20
	    frame_001_1.shrink = True
	
	    #node Group Input.005
	    group_input_005_1 = hair_from_mesh.nodes.new("NodeGroupInput")
	    group_input_005_1.name = "Group Input.005"
	    group_input_005_1.outputs[1].hide = True
	    group_input_005_1.outputs[2].hide = True
	    group_input_005_1.outputs[3].hide = True
	    group_input_005_1.outputs[4].hide = True
	    group_input_005_1.outputs[5].hide = True
	    group_input_005_1.outputs[6].hide = True
	    group_input_005_1.outputs[7].hide = True
	    group_input_005_1.outputs[8].hide = True
	
	    #node Group Input.006
	    group_input_006_1 = hair_from_mesh.nodes.new("NodeGroupInput")
	    group_input_006_1.name = "Group Input.006"
	    group_input_006_1.outputs[0].hide = True
	    group_input_006_1.outputs[2].hide = True
	    group_input_006_1.outputs[3].hide = True
	    group_input_006_1.outputs[4].hide = True
	    group_input_006_1.outputs[5].hide = True
	    group_input_006_1.outputs[8].hide = True
	
	    #node Group.001
	    group_001_1 = hair_from_mesh.nodes.new("GeometryNodeGroup")
	    group_001_1.name = "Group.001"
	    group_001_1.node_tree = attach_hair
	
	    #node Final Bake
	    final_bake = hair_from_mesh.nodes.new("GeometryNodeBake")
	    final_bake.label = "Final Bake"
	    final_bake.name = "Final Bake"
	    final_bake.active_index = 0
	    final_bake.bake_items.clear()
	    final_bake.bake_items.new('GEOMETRY', "Geometry")
	    final_bake.bake_items[0].attribute_domain = 'POINT'
	    final_bake.inputs[1].hide = True
	    final_bake.outputs[1].hide = True
	
	    #node Separate Components
	    separate_components = hair_from_mesh.nodes.new("GeometryNodeSeparateComponents")
	    separate_components.name = "Separate Components"
	    separate_components.hide = True
	
	    #node Join Geometry.001
	    join_geometry_001 = hair_from_mesh.nodes.new("GeometryNodeJoinGeometry")
	    join_geometry_001.name = "Join Geometry.001"
	
	    #node Reroute
	    reroute_1 = hair_from_mesh.nodes.new("NodeReroute")
	    reroute_1.name = "Reroute"
	    reroute_1.socket_idname = "NodeSocketGeometry"
	    #node Reroute.001
	    reroute_001_1 = hair_from_mesh.nodes.new("NodeReroute")
	    reroute_001_1.name = "Reroute.001"
	    reroute_001_1.socket_idname = "NodeSocketGeometry"
	    #node Reroute.002
	    reroute_002_1 = hair_from_mesh.nodes.new("NodeReroute")
	    reroute_002_1.name = "Reroute.002"
	    reroute_002_1.socket_idname = "NodeSocketGeometry"
	    #node Reroute.003
	    reroute_003_1 = hair_from_mesh.nodes.new("NodeReroute")
	    reroute_003_1.name = "Reroute.003"
	    reroute_003_1.socket_idname = "NodeSocketGeometry"
	    #node Reroute.004
	    reroute_004_1 = hair_from_mesh.nodes.new("NodeReroute")
	    reroute_004_1.name = "Reroute.004"
	    reroute_004_1.socket_idname = "NodeSocketGeometry"
	    #node Reroute.005
	    reroute_005_1 = hair_from_mesh.nodes.new("NodeReroute")
	    reroute_005_1.name = "Reroute.005"
	    reroute_005_1.socket_idname = "NodeSocketGeometry"
	    #node Reroute.006
	    reroute_006_1 = hair_from_mesh.nodes.new("NodeReroute")
	    reroute_006_1.name = "Reroute.006"
	    reroute_006_1.socket_idname = "NodeSocketGeometry"
	    #node Reroute.007
	    reroute_007_1 = hair_from_mesh.nodes.new("NodeReroute")
	    reroute_007_1.name = "Reroute.007"
	    reroute_007_1.socket_idname = "NodeSocketGeometry"
	    #node Reroute.008
	    reroute_008_1 = hair_from_mesh.nodes.new("NodeReroute")
	    reroute_008_1.name = "Reroute.008"
	    reroute_008_1.socket_idname = "NodeSocketGeometry"
	    #node Reroute.009
	    reroute_009_1 = hair_from_mesh.nodes.new("NodeReroute")
	    reroute_009_1.name = "Reroute.009"
	    reroute_009_1.socket_idname = "NodeSocketGeometry"
	
	
	
	    #Set parents
	    shortest_edge_paths.parent = frame_1
	    edge_vertices.parent = frame_1
	    evaluate_at_index.parent = frame_1
	    evaluate_at_index_001.parent = frame_1
	    compare_1.parent = frame_1
	    map_range_1.parent = frame_001_1
	    tip_trim_shape.parent = frame_001_1
	    random_value.parent = frame_001_1
	    hair_strand_shape.parent = frame_001_1
	    hair_strand_feather.parent = frame_001_1
	    spline_parameter_1.parent = frame_001_1
	    group_input_002_1.parent = frame_001_1
	    group_input_004_1.parent = frame_001_1
	
	    #Set locations
	    group_input_2.location = (77.9150390625, 500.2334899902344)
	    group_output_3.location = (2467.607421875, 552.161376953125)
	    capture_attribute_1.location = (-494.5246887207031, 398.6083068847656)
	    named_attribute_2.location = (-671.7517700195312, 298.69677734375)
	    shortest_edge_paths.location = (29.87646484375, -207.94241333007812)
	    delete_geometry.location = (364.6458740234375, 424.99432373046875)
	    edge_vertices.location = (31.66375732421875, -96.20223999023438)
	    evaluate_at_index.location = (225.266845703125, -39.7427978515625)
	    evaluate_at_index_001.location = (227.90087890625, -204.4878692626953)
	    compare_1.location = (418.86993408203125, -61.917510986328125)
	    capture_attribute_001_1.location = (-295.8027038574219, 305.547119140625)
	    mesh_to_curve.location = (641.755615234375, 415.3883056640625)
	    reverse_curve.location = (1004.1824951171875, 383.1394348144531)
	    math.location = (39.804443359375, 314.95477294921875)
	    endpoint_selection_1.location = (35.70556640625, 354.3894958496094)
	    boolean_math_1.location = (645.2139892578125, 311.2545166015625)
	    trim_curve.location = (1319.6658935546875, 430.75341796875)
	    set_curve_radius.location = (1522.131103515625, 457.5999755859375)
	    set_material.location = (1699.17529296875, 483.223876953125)
	    evaluate_on_domain_1.location = (377.5394287109375, 311.3511657714844)
	    map_range_1.location = (798.488037109375, -40.30073547363281)
	    tip_trim_shape.location = (496.98028564453125, -41.61871337890625)
	    random_value.location = (231.19561767578125, -302.1961669921875)
	    math_001.location = (1378.9735107421875, -112.95697021484375)
	    hair_strand_shape.location = (791.998046875, -327.62005615234375)
	    hair_strand_feather.location = (469.322021484375, -401.12091064453125)
	    spline_parameter_1.location = (226.89013671875, -550.9124145507812)
	    group_input_002_1.location = (799.263427734375, -223.1194610595703)
	    group_input_003_1.location = (1527.516845703125, 353.40423583984375)
	    group_input_004_1.location = (30.215576171875, -352.59039306640625)
	    subdivide_mesh.location = (78.64312744140625, 432.6531066894531)
	    frame_1.location = (-311.0, 243.0)
	    frame_001_1.location = (303.0, 240.0)
	    group_input_005_1.location = (-672.4871826171875, 438.1949157714844)
	    group_input_006_1.location = (1700.387939453125, 378.4978332519531)
	    group_001_1.location = (1885.40966796875, 530.3359985351562)
	    final_bake.location = (2287.1796875, 599.6317138671875)
	    separate_components.location = (-670.7841186523438, 481.8819580078125)
	    join_geometry_001.location = (2115.001708984375, 553.1250610351562)
	    reroute_1.location = (-363.739990234375, 581.5621337890625)
	    reroute_001_1.location = (-363.739990234375, 586.6482543945312)
	    reroute_002_1.location = (-363.739990234375, 576.5335693359375)
	    reroute_003_1.location = (-363.739990234375, 571.5792236328125)
	    reroute_004_1.location = (-363.739990234375, 591.7378540039062)
	    reroute_005_1.location = (2021.8946533203125, 592.9951782226562)
	    reroute_006_1.location = (2023.473876953125, 582.99560546875)
	    reroute_007_1.location = (2023.5782470703125, 577.9954833984375)
	    reroute_008_1.location = (2021.8946533203125, 587.9949340820312)
	    reroute_009_1.location = (2023.5782470703125, 572.99560546875)
	
	    #Set dimensions
	    group_input_2.width, group_input_2.height = 140.0, 100.0
	    group_output_3.width, group_output_3.height = 140.0, 100.0
	    capture_attribute_1.width, capture_attribute_1.height = 140.0, 100.0
	    named_attribute_2.width, named_attribute_2.height = 140.0, 100.0
	    shortest_edge_paths.width, shortest_edge_paths.height = 140.0, 100.0
	    delete_geometry.width, delete_geometry.height = 140.0, 100.0
	    edge_vertices.width, edge_vertices.height = 140.0, 100.0
	    evaluate_at_index.width, evaluate_at_index.height = 140.0, 100.0
	    evaluate_at_index_001.width, evaluate_at_index_001.height = 140.0, 100.0
	    compare_1.width, compare_1.height = 140.0, 100.0
	    capture_attribute_001_1.width, capture_attribute_001_1.height = 140.0, 100.0
	    mesh_to_curve.width, mesh_to_curve.height = 140.0, 100.0
	    reverse_curve.width, reverse_curve.height = 140.0, 100.0
	    math.width, math.height = 140.0, 100.0
	    endpoint_selection_1.width, endpoint_selection_1.height = 140.0, 100.0
	    boolean_math_1.width, boolean_math_1.height = 140.0, 100.0
	    trim_curve.width, trim_curve.height = 140.0, 100.0
	    set_curve_radius.width, set_curve_radius.height = 140.0, 100.0
	    set_material.width, set_material.height = 140.0, 100.0
	    evaluate_on_domain_1.width, evaluate_on_domain_1.height = 140.0, 100.0
	    map_range_1.width, map_range_1.height = 140.0, 100.0
	    tip_trim_shape.width, tip_trim_shape.height = 240.0, 100.0
	    random_value.width, random_value.height = 140.0, 100.0
	    math_001.width, math_001.height = 140.0, 100.0
	    hair_strand_shape.width, hair_strand_shape.height = 240.0, 100.0
	    hair_strand_feather.width, hair_strand_feather.height = 240.0, 100.0
	    spline_parameter_1.width, spline_parameter_1.height = 140.0, 100.0
	    group_input_002_1.width, group_input_002_1.height = 140.0, 100.0
	    group_input_003_1.width, group_input_003_1.height = 140.0, 100.0
	    group_input_004_1.width, group_input_004_1.height = 140.0, 100.0
	    subdivide_mesh.width, subdivide_mesh.height = 140.0, 100.0
	    frame_1.width, frame_1.height = 589.0, 380.0
	    frame_001_1.width, frame_001_1.height = 1062.0, 669.0
	    group_input_005_1.width, group_input_005_1.height = 140.0, 100.0
	    group_input_006_1.width, group_input_006_1.height = 140.0, 100.0
	    group_001_1.width, group_001_1.height = 140.0, 100.0
	    final_bake.width, final_bake.height = 140.0, 100.0
	    separate_components.width, separate_components.height = 140.0, 100.0
	    join_geometry_001.width, join_geometry_001.height = 140.0, 100.0
	    reroute_1.width, reroute_1.height = 10.0, 100.0
	    reroute_001_1.width, reroute_001_1.height = 10.0, 100.0
	    reroute_002_1.width, reroute_002_1.height = 10.0, 100.0
	    reroute_003_1.width, reroute_003_1.height = 10.0, 100.0
	    reroute_004_1.width, reroute_004_1.height = 10.0, 100.0
	    reroute_005_1.width, reroute_005_1.height = 10.0, 100.0
	    reroute_006_1.width, reroute_006_1.height = 10.0, 100.0
	    reroute_007_1.width, reroute_007_1.height = 10.0, 100.0
	    reroute_008_1.width, reroute_008_1.height = 10.0, 100.0
	    reroute_009_1.width, reroute_009_1.height = 10.0, 100.0
	
	    #initialize hair_from_mesh links
	    #named_attribute_2.Attribute -> capture_attribute_1.Value
	    hair_from_mesh.links.new(named_attribute_2.outputs[0], capture_attribute_1.inputs[1])
	    #capture_attribute_1.Value -> shortest_edge_paths.End Vertex
	    hair_from_mesh.links.new(capture_attribute_1.outputs[1], shortest_edge_paths.inputs[0])
	    #edge_vertices.Vertex Index 1 -> evaluate_at_index.Index
	    hair_from_mesh.links.new(edge_vertices.outputs[0], evaluate_at_index.inputs[0])
	    #edge_vertices.Vertex Index 2 -> evaluate_at_index_001.Index
	    hair_from_mesh.links.new(edge_vertices.outputs[1], evaluate_at_index_001.inputs[0])
	    #shortest_edge_paths.Total Cost -> evaluate_at_index.Value
	    hair_from_mesh.links.new(shortest_edge_paths.outputs[1], evaluate_at_index.inputs[1])
	    #shortest_edge_paths.Total Cost -> evaluate_at_index_001.Value
	    hair_from_mesh.links.new(shortest_edge_paths.outputs[1], evaluate_at_index_001.inputs[1])
	    #evaluate_at_index.Value -> compare_1.A
	    hair_from_mesh.links.new(evaluate_at_index.outputs[0], compare_1.inputs[2])
	    #evaluate_at_index_001.Value -> compare_1.B
	    hair_from_mesh.links.new(evaluate_at_index_001.outputs[0], compare_1.inputs[3])
	    #compare_1.Result -> delete_geometry.Selection
	    hair_from_mesh.links.new(compare_1.outputs[0], delete_geometry.inputs[1])
	    #capture_attribute_1.Geometry -> capture_attribute_001_1.Geometry
	    hair_from_mesh.links.new(capture_attribute_1.outputs[0], capture_attribute_001_1.inputs[0])
	    #named_attribute_2.Attribute -> capture_attribute_001_1.Value
	    hair_from_mesh.links.new(named_attribute_2.outputs[0], capture_attribute_001_1.inputs[1])
	    #delete_geometry.Geometry -> mesh_to_curve.Mesh
	    hair_from_mesh.links.new(delete_geometry.outputs[0], mesh_to_curve.inputs[0])
	    #mesh_to_curve.Curve -> reverse_curve.Curve
	    hair_from_mesh.links.new(mesh_to_curve.outputs[0], reverse_curve.inputs[0])
	    #capture_attribute_001_1.Value -> math.Value
	    hair_from_mesh.links.new(capture_attribute_001_1.outputs[1], math.inputs[1])
	    #endpoint_selection_1.Selection -> math.Value
	    hair_from_mesh.links.new(endpoint_selection_1.outputs[0], math.inputs[0])
	    #evaluate_on_domain_1.Value -> boolean_math_1.Boolean
	    hair_from_mesh.links.new(evaluate_on_domain_1.outputs[0], boolean_math_1.inputs[0])
	    #boolean_math_1.Boolean -> reverse_curve.Selection
	    hair_from_mesh.links.new(boolean_math_1.outputs[0], reverse_curve.inputs[1])
	    #reverse_curve.Curve -> trim_curve.Curve
	    hair_from_mesh.links.new(reverse_curve.outputs[0], trim_curve.inputs[0])
	    #trim_curve.Curve -> set_curve_radius.Curve
	    hair_from_mesh.links.new(trim_curve.outputs[0], set_curve_radius.inputs[0])
	    #set_curve_radius.Curve -> set_material.Geometry
	    hair_from_mesh.links.new(set_curve_radius.outputs[0], set_material.inputs[0])
	    #math.Value -> evaluate_on_domain_1.Value
	    hair_from_mesh.links.new(math.outputs[0], evaluate_on_domain_1.inputs[0])
	    #map_range_1.Result -> trim_curve.End
	    hair_from_mesh.links.new(map_range_1.outputs[0], trim_curve.inputs[3])
	    #tip_trim_shape.Value -> map_range_1.Value
	    hair_from_mesh.links.new(tip_trim_shape.outputs[0], map_range_1.inputs[0])
	    #random_value.Value -> tip_trim_shape.Value
	    hair_from_mesh.links.new(random_value.outputs[1], tip_trim_shape.inputs[1])
	    #math_001.Value -> set_curve_radius.Radius
	    hair_from_mesh.links.new(math_001.outputs[0], set_curve_radius.inputs[2])
	    #hair_strand_shape.Value -> math_001.Value
	    hair_from_mesh.links.new(hair_strand_shape.outputs[0], math_001.inputs[0])
	    #hair_strand_feather.Color -> hair_strand_shape.Value
	    hair_from_mesh.links.new(hair_strand_feather.outputs[0], hair_strand_shape.inputs[1])
	    #spline_parameter_1.Factor -> hair_strand_feather.Fac
	    hair_from_mesh.links.new(spline_parameter_1.outputs[0], hair_strand_feather.inputs[0])
	    #group_input_002_1.Length Factor -> map_range_1.To Min
	    hair_from_mesh.links.new(group_input_002_1.outputs[4], map_range_1.inputs[3])
	    #group_input_003_1.Material -> set_material.Material
	    hair_from_mesh.links.new(group_input_003_1.outputs[2], set_material.inputs[2])
	    #group_input_004_1.Seed -> random_value.Seed
	    hair_from_mesh.links.new(group_input_004_1.outputs[5], random_value.inputs[8])
	    #capture_attribute_001_1.Geometry -> subdivide_mesh.Mesh
	    hair_from_mesh.links.new(capture_attribute_001_1.outputs[0], subdivide_mesh.inputs[0])
	    #subdivide_mesh.Mesh -> delete_geometry.Geometry
	    hair_from_mesh.links.new(subdivide_mesh.outputs[0], delete_geometry.inputs[0])
	    #group_input_2.Subdivide Level -> subdivide_mesh.Level
	    hair_from_mesh.links.new(group_input_2.outputs[3], subdivide_mesh.inputs[1])
	    #set_material.Geometry -> group_001_1.Geometry
	    hair_from_mesh.links.new(set_material.outputs[0], group_001_1.inputs[0])
	    #group_input_006_1.Surface -> group_001_1.Surface
	    hair_from_mesh.links.new(group_input_006_1.outputs[1], group_001_1.inputs[1])
	    #final_bake.Geometry -> group_output_3.Geometry
	    hair_from_mesh.links.new(final_bake.outputs[0], group_output_3.inputs[0])
	    #group_input_006_1.UV Map -> group_001_1.UV Map
	    hair_from_mesh.links.new(group_input_006_1.outputs[6], group_001_1.inputs[2])
	    #group_input_006_1.Blend along Curve -> group_001_1.Blend along Curve
	    hair_from_mesh.links.new(group_input_006_1.outputs[7], group_001_1.inputs[3])
	    #group_input_005_1.Geometry -> separate_components.Geometry
	    hair_from_mesh.links.new(group_input_005_1.outputs[0], separate_components.inputs[0])
	    #separate_components.Mesh -> capture_attribute_1.Geometry
	    hair_from_mesh.links.new(separate_components.outputs[0], capture_attribute_1.inputs[0])
	    #reroute_009_1.Output -> join_geometry_001.Geometry
	    hair_from_mesh.links.new(reroute_009_1.outputs[0], join_geometry_001.inputs[0])
	    #separate_components.Point Cloud -> reroute_1.Input
	    hair_from_mesh.links.new(separate_components.outputs[3], reroute_1.inputs[0])
	    #separate_components.Grease Pencil -> reroute_001_1.Input
	    hair_from_mesh.links.new(separate_components.outputs[2], reroute_001_1.inputs[0])
	    #separate_components.Volume -> reroute_002_1.Input
	    hair_from_mesh.links.new(separate_components.outputs[4], reroute_002_1.inputs[0])
	    #separate_components.Instances -> reroute_003_1.Input
	    hair_from_mesh.links.new(separate_components.outputs[5], reroute_003_1.inputs[0])
	    #separate_components.Curve -> reroute_004_1.Input
	    hair_from_mesh.links.new(separate_components.outputs[1], reroute_004_1.inputs[0])
	    #reroute_004_1.Output -> reroute_005_1.Input
	    hair_from_mesh.links.new(reroute_004_1.outputs[0], reroute_005_1.inputs[0])
	    #reroute_1.Output -> reroute_006_1.Input
	    hair_from_mesh.links.new(reroute_1.outputs[0], reroute_006_1.inputs[0])
	    #reroute_002_1.Output -> reroute_007_1.Input
	    hair_from_mesh.links.new(reroute_002_1.outputs[0], reroute_007_1.inputs[0])
	    #reroute_001_1.Output -> reroute_008_1.Input
	    hair_from_mesh.links.new(reroute_001_1.outputs[0], reroute_008_1.inputs[0])
	    #reroute_003_1.Output -> reroute_009_1.Input
	    hair_from_mesh.links.new(reroute_003_1.outputs[0], reroute_009_1.inputs[0])
	    #join_geometry_001.Geometry -> final_bake.Geometry
	    hair_from_mesh.links.new(join_geometry_001.outputs[0], final_bake.inputs[0])
	    #reroute_007_1.Output -> join_geometry_001.Geometry
	    hair_from_mesh.links.new(reroute_007_1.outputs[0], join_geometry_001.inputs[0])
	    #reroute_006_1.Output -> join_geometry_001.Geometry
	    hair_from_mesh.links.new(reroute_006_1.outputs[0], join_geometry_001.inputs[0])
	    #reroute_008_1.Output -> join_geometry_001.Geometry
	    hair_from_mesh.links.new(reroute_008_1.outputs[0], join_geometry_001.inputs[0])
	    #reroute_005_1.Output -> join_geometry_001.Geometry
	    hair_from_mesh.links.new(reroute_005_1.outputs[0], join_geometry_001.inputs[0])
	    #group_001_1.Geometry -> join_geometry_001.Geometry
	    hair_from_mesh.links.new(group_001_1.outputs[0], join_geometry_001.inputs[0])
	    return hair_from_mesh
	return hair_from_mesh_node_group()

	

	
