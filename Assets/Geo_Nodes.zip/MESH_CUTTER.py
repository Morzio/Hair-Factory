import bpy, mathutils

def node():
	#initialize mesh_cutter node group
	def mesh_cutter_node_group():
	    mesh_cutter = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "MESH_CUTTER")
	
	    mesh_cutter.color_tag = 'NONE'
	    mesh_cutter.description = "Cut shape from mesh using another mesh."
	    mesh_cutter.default_group_node_width = 140
	    
	
	    mesh_cutter.is_modifier = True
	
	    #mesh_cutter interface
	    #Socket Geometry
	    geometry_socket = mesh_cutter.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket.attribute_domain = 'POINT'
	    geometry_socket.description = "Modified mesh."
	
	    #Socket Geometry
	    geometry_socket_1 = mesh_cutter.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_1.attribute_domain = 'POINT'
	    geometry_socket_1.description = "Mesh to be cut."
	
	    #Socket Geometry
	    geometry_socket_2 = mesh_cutter.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketObject')
	    geometry_socket_2.attribute_domain = 'POINT'
	    geometry_socket_2.description = "Mesh to be cut. Use if target object is another Object."
	
	    #Socket Cut Shape
	    cut_shape_socket = mesh_cutter.interface.new_socket(name = "Cut Shape", in_out='INPUT', socket_type = 'NodeSocketObject')
	    cut_shape_socket.attribute_domain = 'POINT'
	    cut_shape_socket.description = "Mesh used to cut out shape."
	
	
	    #initialize mesh_cutter nodes
	    #node Group Input
	    group_input = mesh_cutter.nodes.new("NodeGroupInput")
	    group_input.name = "Group Input"
	    group_input.outputs[3].hide = True
	
	    #node Object Info
	    object_info = mesh_cutter.nodes.new("GeometryNodeObjectInfo")
	    object_info.name = "Object Info"
	    object_info.hide = True
	    object_info.transform_space = 'RELATIVE'
	    object_info.inputs[1].hide = True
	    object_info.outputs[0].hide = True
	    object_info.outputs[1].hide = True
	    object_info.outputs[2].hide = True
	    object_info.outputs[3].hide = True
	    #As Instance
	    object_info.inputs[1].default_value = False
	
	    #node Object Info.001
	    object_info_001 = mesh_cutter.nodes.new("GeometryNodeObjectInfo")
	    object_info_001.name = "Object Info.001"
	    object_info_001.hide = True
	    object_info_001.transform_space = 'RELATIVE'
	    object_info_001.inputs[1].hide = True
	    object_info_001.outputs[0].hide = True
	    object_info_001.outputs[1].hide = True
	    object_info_001.outputs[2].hide = True
	    object_info_001.outputs[3].hide = True
	    #As Instance
	    object_info_001.inputs[1].default_value = False
	
	    #node Mesh Boolean
	    mesh_boolean = mesh_cutter.nodes.new("GeometryNodeMeshBoolean")
	    mesh_boolean.name = "Mesh Boolean"
	    mesh_boolean.hide = True
	    mesh_boolean.operation = 'INTERSECT'
	    mesh_boolean.solver = 'EXACT'
	    mesh_boolean.inputs[0].hide = True
	    mesh_boolean.inputs[2].hide = True
	    mesh_boolean.inputs[3].hide = True
	    #Self Intersection
	    mesh_boolean.inputs[2].default_value = False
	    #Hole Tolerant
	    mesh_boolean.inputs[3].default_value = False
	
	    #node Delete Geometry.003
	    delete_geometry_003 = mesh_cutter.nodes.new("GeometryNodeDeleteGeometry")
	    delete_geometry_003.name = "Delete Geometry.003"
	    delete_geometry_003.hide = True
	    delete_geometry_003.domain = 'POINT'
	    delete_geometry_003.mode = 'ALL'
	
	    #node Geometry Proximity
	    geometry_proximity = mesh_cutter.nodes.new("GeometryNodeProximity")
	    geometry_proximity.name = "Geometry Proximity"
	    geometry_proximity.hide = True
	    geometry_proximity.target_element = 'FACES'
	    geometry_proximity.inputs[1].hide = True
	    geometry_proximity.inputs[2].hide = True
	    geometry_proximity.inputs[3].hide = True
	    geometry_proximity.outputs[1].hide = True
	    geometry_proximity.outputs[2].hide = True
	    #Group ID
	    geometry_proximity.inputs[1].default_value = 0
	    #Source Position
	    geometry_proximity.inputs[2].default_value = (0.0, 0.0, 0.0)
	    #Sample Group ID
	    geometry_proximity.inputs[3].default_value = 0
	
	    #node Sample Nearest
	    sample_nearest = mesh_cutter.nodes.new("GeometryNodeSampleNearest")
	    sample_nearest.name = "Sample Nearest"
	    sample_nearest.hide = True
	    sample_nearest.domain = 'FACE'
	    #Sample Position
	    sample_nearest.inputs[1].default_value = (0.0, 0.0, 0.0)
	
	    #node Reroute
	    reroute = mesh_cutter.nodes.new("NodeReroute")
	    reroute.name = "Reroute"
	    reroute.socket_idname = "NodeSocketGeometry"
	    #node Sample Index
	    sample_index = mesh_cutter.nodes.new("GeometryNodeSampleIndex")
	    sample_index.name = "Sample Index"
	    sample_index.hide = True
	    sample_index.clamp = False
	    sample_index.data_type = 'FLOAT_VECTOR'
	    sample_index.domain = 'FACE'
	
	    #node Normal
	    normal = mesh_cutter.nodes.new("GeometryNodeInputNormal")
	    normal.name = "Normal"
	    normal.legacy_corner_normals = False
	
	    #node Position
	    position = mesh_cutter.nodes.new("GeometryNodeInputPosition")
	    position.name = "Position"
	
	    #node Vector Math.002
	    vector_math_002 = mesh_cutter.nodes.new("ShaderNodeVectorMath")
	    vector_math_002.name = "Vector Math.002"
	    vector_math_002.hide = True
	    vector_math_002.operation = 'SUBTRACT'
	
	    #node Vector Math.003
	    vector_math_003 = mesh_cutter.nodes.new("ShaderNodeVectorMath")
	    vector_math_003.name = "Vector Math.003"
	    vector_math_003.hide = True
	    vector_math_003.operation = 'NORMALIZE'
	
	    #node Compare.002
	    compare_002 = mesh_cutter.nodes.new("FunctionNodeCompare")
	    compare_002.name = "Compare.002"
	    compare_002.hide = True
	    compare_002.data_type = 'VECTOR'
	    compare_002.mode = 'DOT_PRODUCT'
	    compare_002.operation = 'GREATER_THAN'
	    compare_002.inputs[0].hide = True
	    compare_002.inputs[1].hide = True
	    compare_002.inputs[2].hide = True
	    compare_002.inputs[3].hide = True
	    compare_002.inputs[6].hide = True
	    compare_002.inputs[7].hide = True
	    compare_002.inputs[8].hide = True
	    compare_002.inputs[9].hide = True
	    compare_002.inputs[10].hide = True
	    compare_002.inputs[11].hide = True
	    compare_002.inputs[12].hide = True
	    #C
	    compare_002.inputs[10].default_value = 0.0
	
	    #node Boolean Math
	    boolean_math = mesh_cutter.nodes.new("FunctionNodeBooleanMath")
	    boolean_math.name = "Boolean Math"
	    boolean_math.hide = True
	    boolean_math.operation = 'NOT'
	
	    #node Boolean Math.001
	    boolean_math_001 = mesh_cutter.nodes.new("FunctionNodeBooleanMath")
	    boolean_math_001.name = "Boolean Math.001"
	    boolean_math_001.hide = True
	    boolean_math_001.operation = 'AND'
	
	    #node Group Output
	    group_output = mesh_cutter.nodes.new("NodeGroupOutput")
	    group_output.name = "Group Output"
	    group_output.is_active_output = True
	    group_output.inputs[1].hide = True
	
	    #node Reroute.001
	    reroute_001 = mesh_cutter.nodes.new("NodeReroute")
	    reroute_001.name = "Reroute.001"
	    reroute_001.socket_idname = "NodeSocketGeometry"
	    #node Domain Size
	    domain_size = mesh_cutter.nodes.new("GeometryNodeAttributeDomainSize")
	    domain_size.name = "Domain Size"
	    domain_size.hide = True
	    domain_size.component = 'MESH'
	    domain_size.outputs[1].hide = True
	    domain_size.outputs[2].hide = True
	    domain_size.outputs[3].hide = True
	    domain_size.outputs[4].hide = True
	    domain_size.outputs[5].hide = True
	    domain_size.outputs[6].hide = True
	
	    #node Compare
	    compare = mesh_cutter.nodes.new("FunctionNodeCompare")
	    compare.name = "Compare"
	    compare.hide = True
	    compare.data_type = 'INT'
	    compare.mode = 'ELEMENT'
	    compare.operation = 'NOT_EQUAL'
	    compare.inputs[0].hide = True
	    compare.inputs[1].hide = True
	    compare.inputs[3].hide = True
	    compare.inputs[4].hide = True
	    compare.inputs[5].hide = True
	    compare.inputs[6].hide = True
	    compare.inputs[7].hide = True
	    compare.inputs[8].hide = True
	    compare.inputs[9].hide = True
	    compare.inputs[10].hide = True
	    compare.inputs[11].hide = True
	    compare.inputs[12].hide = True
	    #B_INT
	    compare.inputs[3].default_value = 0
	
	    #node Switch
	    switch = mesh_cutter.nodes.new("GeometryNodeSwitch")
	    switch.name = "Switch"
	    switch.hide = True
	    switch.input_type = 'GEOMETRY'
	
	    #node Cutout Bake
	    cutout_bake = mesh_cutter.nodes.new("GeometryNodeBake")
	    cutout_bake.label = "Cutout Bake"
	    cutout_bake.name = "Cutout Bake"
	    cutout_bake.active_index = 0
	    cutout_bake.bake_items.clear()
	    cutout_bake.bake_items.new('GEOMETRY', "Geometry")
	    cutout_bake.bake_items[0].attribute_domain = 'POINT'
	    cutout_bake.inputs[1].hide = True
	    cutout_bake.outputs[1].hide = True
	
	
	
	
	
	    #Set locations
	    group_input.location = (-340.0, 0.0)
	    object_info.location = (-171.45750427246094, -70.039794921875)
	    object_info_001.location = (-169.64085388183594, -34.33897399902344)
	    mesh_boolean.location = (51.46909713745117, -70.76536560058594)
	    delete_geometry_003.location = (224.3767547607422, -76.21611022949219)
	    geometry_proximity.location = (46.169368743896484, 128.31826782226562)
	    sample_nearest.location = (48.053157806396484, 91.24264526367188)
	    reroute.location = (12.445343017578125, 87.76811218261719)
	    sample_index.location = (50.7850456237793, 38.34077453613281)
	    normal.location = (51.5206413269043, 4.5577545166015625)
	    position.location = (217.20179748535156, 178.30813598632812)
	    vector_math_002.location = (219.46315002441406, 120.08645629882812)
	    vector_math_003.location = (220.90357971191406, 84.39170837402344)
	    compare_002.location = (222.4218292236328, 46.24760818481445)
	    boolean_math.location = (222.5908660888672, -21.776222229003906)
	    boolean_math_001.location = (221.8768768310547, 11.792739868164062)
	    group_output.location = (572.503173828125, -50.47901916503906)
	    reroute_001.location = (13.312347412109375, -43.6197395324707)
	    domain_size.location = (-170.73828125, 1.2292022705078125)
	    compare.location = (-169.2977752685547, 86.26480102539062)
	    switch.location = (-170.73826599121094, 51.851966857910156)
	    cutout_bake.location = (403.9999694824219, -4.357978820800781)
	
	    #Set dimensions
	    group_input.width, group_input.height = 140.0, 100.0
	    object_info.width, object_info.height = 140.0, 100.0
	    object_info_001.width, object_info_001.height = 140.0, 100.0
	    mesh_boolean.width, mesh_boolean.height = 140.0, 100.0
	    delete_geometry_003.width, delete_geometry_003.height = 140.0, 100.0
	    geometry_proximity.width, geometry_proximity.height = 140.0, 100.0
	    sample_nearest.width, sample_nearest.height = 140.0, 100.0
	    reroute.width, reroute.height = 10.0, 100.0
	    sample_index.width, sample_index.height = 140.0, 100.0
	    normal.width, normal.height = 140.0, 100.0
	    position.width, position.height = 140.0, 100.0
	    vector_math_002.width, vector_math_002.height = 140.0, 100.0
	    vector_math_003.width, vector_math_003.height = 140.0, 100.0
	    compare_002.width, compare_002.height = 140.0, 100.0
	    boolean_math.width, boolean_math.height = 140.0, 100.0
	    boolean_math_001.width, boolean_math_001.height = 140.0, 100.0
	    group_output.width, group_output.height = 140.0, 100.0
	    reroute_001.width, reroute_001.height = 10.0, 100.0
	    domain_size.width, domain_size.height = 140.0, 100.0
	    compare.width, compare.height = 140.0, 100.0
	    switch.width, switch.height = 140.0, 100.0
	    cutout_bake.width, cutout_bake.height = 140.0, 100.0
	
	    #initialize mesh_cutter links
	    #object_info.Geometry -> mesh_boolean.Mesh
	    mesh_cutter.links.new(object_info.outputs[4], mesh_boolean.inputs[1])
	    #mesh_boolean.Mesh -> delete_geometry_003.Geometry
	    mesh_cutter.links.new(mesh_boolean.outputs[0], delete_geometry_003.inputs[0])
	    #reroute.Output -> geometry_proximity.Geometry
	    mesh_cutter.links.new(reroute.outputs[0], geometry_proximity.inputs[0])
	    #reroute_001.Output -> reroute.Input
	    mesh_cutter.links.new(reroute_001.outputs[0], reroute.inputs[0])
	    #reroute.Output -> sample_nearest.Geometry
	    mesh_cutter.links.new(reroute.outputs[0], sample_nearest.inputs[0])
	    #reroute.Output -> sample_index.Geometry
	    mesh_cutter.links.new(reroute.outputs[0], sample_index.inputs[0])
	    #sample_nearest.Index -> sample_index.Index
	    mesh_cutter.links.new(sample_nearest.outputs[0], sample_index.inputs[2])
	    #normal.Normal -> sample_index.Value
	    mesh_cutter.links.new(normal.outputs[0], sample_index.inputs[1])
	    #geometry_proximity.Position -> vector_math_002.Vector
	    mesh_cutter.links.new(geometry_proximity.outputs[0], vector_math_002.inputs[0])
	    #position.Position -> vector_math_002.Vector
	    mesh_cutter.links.new(position.outputs[0], vector_math_002.inputs[1])
	    #vector_math_002.Vector -> vector_math_003.Vector
	    mesh_cutter.links.new(vector_math_002.outputs[0], vector_math_003.inputs[0])
	    #vector_math_003.Vector -> compare_002.A
	    mesh_cutter.links.new(vector_math_003.outputs[0], compare_002.inputs[4])
	    #sample_index.Value -> compare_002.B
	    mesh_cutter.links.new(sample_index.outputs[0], compare_002.inputs[5])
	    #mesh_boolean.Intersecting Edges -> boolean_math.Boolean
	    mesh_cutter.links.new(mesh_boolean.outputs[1], boolean_math.inputs[0])
	    #boolean_math.Boolean -> boolean_math_001.Boolean
	    mesh_cutter.links.new(boolean_math.outputs[0], boolean_math_001.inputs[1])
	    #compare_002.Result -> boolean_math_001.Boolean
	    mesh_cutter.links.new(compare_002.outputs[0], boolean_math_001.inputs[0])
	    #boolean_math_001.Boolean -> delete_geometry_003.Selection
	    mesh_cutter.links.new(boolean_math_001.outputs[0], delete_geometry_003.inputs[1])
	    #cutout_bake.Geometry -> group_output.Geometry
	    mesh_cutter.links.new(cutout_bake.outputs[0], group_output.inputs[0])
	    #group_input.Geometry -> object_info_001.Object
	    mesh_cutter.links.new(group_input.outputs[1], object_info_001.inputs[0])
	    #group_input.Cut Shape -> object_info.Object
	    mesh_cutter.links.new(group_input.outputs[2], object_info.inputs[0])
	    #object_info_001.Geometry -> domain_size.Geometry
	    mesh_cutter.links.new(object_info_001.outputs[4], domain_size.inputs[0])
	    #domain_size.Point Count -> compare.A
	    mesh_cutter.links.new(domain_size.outputs[0], compare.inputs[2])
	    #compare.Result -> switch.Switch
	    mesh_cutter.links.new(compare.outputs[0], switch.inputs[0])
	    #object_info_001.Geometry -> switch.True
	    mesh_cutter.links.new(object_info_001.outputs[4], switch.inputs[2])
	    #group_input.Geometry -> switch.False
	    mesh_cutter.links.new(group_input.outputs[0], switch.inputs[1])
	    #switch.Output -> reroute_001.Input
	    mesh_cutter.links.new(switch.outputs[0], reroute_001.inputs[0])
	    #delete_geometry_003.Geometry -> cutout_bake.Geometry
	    mesh_cutter.links.new(delete_geometry_003.outputs[0], cutout_bake.inputs[0])
	    #reroute_001.Output -> mesh_boolean.Mesh
	    mesh_cutter.links.new(reroute_001.outputs[0], mesh_boolean.inputs[1])
	    return mesh_cutter
	return mesh_cutter_node_group()

	

	
