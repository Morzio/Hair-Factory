import bpy, mathutils

def node():
	#initialize beadz_config node group
	def beadz_config_node_group():
	    beadz_config = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "BEADZ_CONFIG")
	
	    beadz_config.color_tag = 'NONE'
	    beadz_config.description = "Configuration for hair bead object."
	    beadz_config.default_group_node_width = 140
	    
	
	    beadz_config.is_modifier = True
	
	    #beadz_config interface
	    #Socket Geometry
	    geometry_socket = beadz_config.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket.attribute_domain = 'POINT'
	
	    #Socket Geometry
	    geometry_socket_1 = beadz_config.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_1.attribute_domain = 'POINT'
	    geometry_socket_1.description = "Hair bead object."
	
	    #Socket Count
	    count_socket = beadz_config.interface.new_socket(name = "Count", in_out='INPUT', socket_type = 'NodeSocketInt')
	    count_socket.default_value = 2
	    count_socket.min_value = 1
	    count_socket.max_value = 10000
	    count_socket.subtype = 'NONE'
	    count_socket.attribute_domain = 'POINT'
	    count_socket.description = "Bead count."
	
	    #Socket Offset
	    offset_socket = beadz_config.interface.new_socket(name = "Offset", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    offset_socket.default_value = 1.0
	    offset_socket.min_value = 0.0
	    offset_socket.max_value = 10000.0
	    offset_socket.subtype = 'NONE'
	    offset_socket.attribute_domain = 'POINT'
	    offset_socket.description = "Bead stack offset."
	
	    #Socket Material
	    material_socket = beadz_config.interface.new_socket(name = "Material", in_out='INPUT', socket_type = 'NodeSocketMaterial')
	    material_socket.attribute_domain = 'POINT'
	    material_socket.description = "Bead material."
	
	    #Socket Subdivision Level
	    subdivision_level_socket = beadz_config.interface.new_socket(name = "Subdivision Level", in_out='INPUT', socket_type = 'NodeSocketInt')
	    subdivision_level_socket.default_value = 1
	    subdivision_level_socket.min_value = 0
	    subdivision_level_socket.max_value = 6
	    subdivision_level_socket.subtype = 'NONE'
	    subdivision_level_socket.attribute_domain = 'POINT'
	    subdivision_level_socket.description = "Level of subdivision to use."
	
	    #Socket Subdivision Edge Crease
	    subdivision_edge_crease_socket = beadz_config.interface.new_socket(name = "Subdivision Edge Crease", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    subdivision_edge_crease_socket.default_value = 0.0
	    subdivision_edge_crease_socket.min_value = 0.0
	    subdivision_edge_crease_socket.max_value = 1.0
	    subdivision_edge_crease_socket.subtype = 'FACTOR'
	    subdivision_edge_crease_socket.attribute_domain = 'POINT'
	    subdivision_edge_crease_socket.description = "Edge crease factor."
	
	    #Socket Subdivision Vertex Crease
	    subdivision_vertex_crease_socket = beadz_config.interface.new_socket(name = "Subdivision Vertex Crease", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    subdivision_vertex_crease_socket.default_value = 0.0
	    subdivision_vertex_crease_socket.min_value = 0.0
	    subdivision_vertex_crease_socket.max_value = 1.0
	    subdivision_vertex_crease_socket.subtype = 'FACTOR'
	    subdivision_vertex_crease_socket.attribute_domain = 'POINT'
	    subdivision_vertex_crease_socket.description = "Vertex crease factor."
	
	    #Socket Limit Surface
	    limit_surface_socket = beadz_config.interface.new_socket(name = "Limit Surface", in_out='INPUT', socket_type = 'NodeSocketBool')
	    limit_surface_socket.default_value = True
	    limit_surface_socket.attribute_domain = 'POINT'
	    limit_surface_socket.description = "Use smoothest surface possible."
	
	    #Socket Scale
	    scale_socket = beadz_config.interface.new_socket(name = "Scale", in_out='INPUT', socket_type = 'NodeSocketVector')
	    scale_socket.default_value = (0.5, 0.5, 1.0)
	    scale_socket.min_value = 0.0
	    scale_socket.max_value = 3.4028234663852886e+38
	    scale_socket.subtype = 'XYZ'
	    scale_socket.attribute_domain = 'POINT'
	    scale_socket.description = "Bead overall scale."
	
	
	    #initialize beadz_config nodes
	    #node Group Input
	    group_input = beadz_config.nodes.new("NodeGroupInput")
	    group_input.name = "Group Input"
	    group_input.outputs[1].hide = True
	    group_input.outputs[2].hide = True
	    group_input.outputs[3].hide = True
	    group_input.outputs[9].hide = True
	
	    #node Group Output
	    group_output = beadz_config.nodes.new("NodeGroupOutput")
	    group_output.name = "Group Output"
	    group_output.is_active_output = True
	    group_output.inputs[1].hide = True
	
	    #node Subdivision Surface
	    subdivision_surface = beadz_config.nodes.new("GeometryNodeSubdivisionSurface")
	    subdivision_surface.name = "Subdivision Surface"
	    subdivision_surface.boundary_smooth = 'ALL'
	    subdivision_surface.uv_smooth = 'PRESERVE_BOUNDARIES'
	
	    #node Transform Geometry
	    transform_geometry = beadz_config.nodes.new("GeometryNodeTransform")
	    transform_geometry.name = "Transform Geometry"
	    transform_geometry.mode = 'COMPONENTS'
	    #Translation
	    transform_geometry.inputs[1].default_value = (0.0, 0.0, 0.0)
	    #Rotation
	    transform_geometry.inputs[2].default_value = (0.0, 0.0, 0.0)
	
	    #node Mesh Line
	    mesh_line = beadz_config.nodes.new("GeometryNodeMeshLine")
	    mesh_line.name = "Mesh Line"
	    mesh_line.hide = True
	    mesh_line.count_mode = 'TOTAL'
	    mesh_line.mode = 'END_POINTS'
	    #Start Location
	    mesh_line.inputs[2].default_value = (0.0, 0.0, 0.0)
	
	    #node Bounding Box
	    bounding_box = beadz_config.nodes.new("GeometryNodeBoundBox")
	    bounding_box.name = "Bounding Box"
	    bounding_box.hide = True
	
	    #node Separate XYZ
	    separate_xyz = beadz_config.nodes.new("ShaderNodeSeparateXYZ")
	    separate_xyz.name = "Separate XYZ"
	    separate_xyz.hide = True
	
	    #node Separate XYZ.001
	    separate_xyz_001 = beadz_config.nodes.new("ShaderNodeSeparateXYZ")
	    separate_xyz_001.name = "Separate XYZ.001"
	    separate_xyz_001.hide = True
	
	    #node Math
	    math = beadz_config.nodes.new("ShaderNodeMath")
	    math.name = "Math"
	    math.hide = True
	    math.operation = 'SUBTRACT'
	    math.use_clamp = False
	
	    #node Math.002
	    math_002 = beadz_config.nodes.new("ShaderNodeMath")
	    math_002.name = "Math.002"
	    math_002.hide = True
	    math_002.operation = 'SUBTRACT'
	    math_002.use_clamp = False
	    #Value_001
	    math_002.inputs[1].default_value = 1.0
	
	    #node Group Input.001
	    group_input_001 = beadz_config.nodes.new("NodeGroupInput")
	    group_input_001.name = "Group Input.001"
	    group_input_001.outputs[0].hide = True
	    group_input_001.outputs[2].hide = True
	    group_input_001.outputs[3].hide = True
	    group_input_001.outputs[4].hide = True
	    group_input_001.outputs[5].hide = True
	    group_input_001.outputs[6].hide = True
	    group_input_001.outputs[7].hide = True
	    group_input_001.outputs[8].hide = True
	    group_input_001.outputs[9].hide = True
	
	    #node Math.003
	    math_003 = beadz_config.nodes.new("ShaderNodeMath")
	    math_003.name = "Math.003"
	    math_003.hide = True
	    math_003.operation = 'MULTIPLY'
	    math_003.use_clamp = False
	
	    #node Combine XYZ
	    combine_xyz = beadz_config.nodes.new("ShaderNodeCombineXYZ")
	    combine_xyz.name = "Combine XYZ"
	    combine_xyz.hide = True
	    #X
	    combine_xyz.inputs[0].default_value = 0.0
	    #Y
	    combine_xyz.inputs[1].default_value = 0.0
	
	    #node Group Input.002
	    group_input_002 = beadz_config.nodes.new("NodeGroupInput")
	    group_input_002.name = "Group Input.002"
	    group_input_002.outputs[0].hide = True
	    group_input_002.outputs[2].hide = True
	    group_input_002.outputs[3].hide = True
	    group_input_002.outputs[4].hide = True
	    group_input_002.outputs[5].hide = True
	    group_input_002.outputs[6].hide = True
	    group_input_002.outputs[7].hide = True
	    group_input_002.outputs[8].hide = True
	    group_input_002.outputs[9].hide = True
	
	    #node Frame
	    frame = beadz_config.nodes.new("NodeFrame")
	    frame.label = "Set Instances"
	    frame.name = "Frame"
	    frame.label_size = 20
	    frame.shrink = True
	
	    #node Instance on Points
	    instance_on_points = beadz_config.nodes.new("GeometryNodeInstanceOnPoints")
	    instance_on_points.name = "Instance on Points"
	    instance_on_points.inputs[1].hide = True
	    instance_on_points.inputs[3].hide = True
	    instance_on_points.inputs[4].hide = True
	    instance_on_points.inputs[5].hide = True
	    instance_on_points.inputs[6].hide = True
	    #Selection
	    instance_on_points.inputs[1].default_value = True
	    #Pick Instance
	    instance_on_points.inputs[3].default_value = False
	    #Instance Index
	    instance_on_points.inputs[4].default_value = 0
	    #Rotation
	    instance_on_points.inputs[5].default_value = (0.0, 0.0, 0.0)
	    #Scale
	    instance_on_points.inputs[6].default_value = (1.0, 1.0, 1.0)
	
	    #node Realize Instances
	    realize_instances = beadz_config.nodes.new("GeometryNodeRealizeInstances")
	    realize_instances.name = "Realize Instances"
	    realize_instances.inputs[1].hide = True
	    realize_instances.inputs[2].hide = True
	    realize_instances.inputs[3].hide = True
	    #Selection
	    realize_instances.inputs[1].default_value = True
	    #Realize All
	    realize_instances.inputs[2].default_value = True
	    #Depth
	    realize_instances.inputs[3].default_value = 0
	
	    #node Math.004
	    math_004 = beadz_config.nodes.new("ShaderNodeMath")
	    math_004.name = "Math.004"
	    math_004.hide = True
	    math_004.operation = 'MULTIPLY'
	    math_004.use_clamp = False
	
	    #node Group Input.003
	    group_input_003 = beadz_config.nodes.new("NodeGroupInput")
	    group_input_003.name = "Group Input.003"
	    group_input_003.outputs[0].hide = True
	    group_input_003.outputs[1].hide = True
	    group_input_003.outputs[3].hide = True
	    group_input_003.outputs[4].hide = True
	    group_input_003.outputs[5].hide = True
	    group_input_003.outputs[6].hide = True
	    group_input_003.outputs[7].hide = True
	    group_input_003.outputs[8].hide = True
	    group_input_003.outputs[9].hide = True
	
	    #node Set Material
	    set_material = beadz_config.nodes.new("GeometryNodeSetMaterial")
	    set_material.name = "Set Material"
	    set_material.inputs[1].hide = True
	    #Selection
	    set_material.inputs[1].default_value = True
	
	    #node Store Named Attribute.001
	    store_named_attribute_001 = beadz_config.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute_001.name = "Store Named Attribute.001"
	    store_named_attribute_001.data_type = 'FLOAT_COLOR'
	    store_named_attribute_001.domain = 'INSTANCE'
	    #Selection
	    store_named_attribute_001.inputs[1].default_value = True
	    #Name
	    store_named_attribute_001.inputs[2].default_value = "BEAD_col_id"
	
	    #node Random Value
	    random_value = beadz_config.nodes.new("FunctionNodeRandomValue")
	    random_value.name = "Random Value"
	    random_value.data_type = 'FLOAT_VECTOR'
	    random_value.inputs[0].hide = True
	    random_value.inputs[1].hide = True
	    random_value.inputs[2].hide = True
	    random_value.inputs[3].hide = True
	    random_value.inputs[4].hide = True
	    random_value.inputs[5].hide = True
	    random_value.inputs[6].hide = True
	    random_value.inputs[7].hide = True
	    random_value.inputs[8].hide = True
	    random_value.outputs[1].hide = True
	    random_value.outputs[2].hide = True
	    random_value.outputs[3].hide = True
	    #Min
	    random_value.inputs[0].default_value = (0.0, 0.0, 0.0)
	    #Max
	    random_value.inputs[1].default_value = (1.0, 1.0, 1.0)
	    #ID
	    random_value.inputs[7].default_value = 0
	    #Seed
	    random_value.inputs[8].default_value = 0
	
	    #node Set Shade Smooth
	    set_shade_smooth = beadz_config.nodes.new("GeometryNodeSetShadeSmooth")
	    set_shade_smooth.name = "Set Shade Smooth"
	    set_shade_smooth.domain = 'FACE'
	    set_shade_smooth.inputs[1].hide = True
	    set_shade_smooth.inputs[2].hide = True
	    #Selection
	    set_shade_smooth.inputs[1].default_value = True
	    #Shade Smooth
	    set_shade_smooth.inputs[2].default_value = True
	
	    #node Group Input.004
	    group_input_004 = beadz_config.nodes.new("NodeGroupInput")
	    group_input_004.name = "Group Input.004"
	    group_input_004.outputs[0].hide = True
	    group_input_004.outputs[1].hide = True
	    group_input_004.outputs[2].hide = True
	    group_input_004.outputs[4].hide = True
	    group_input_004.outputs[5].hide = True
	    group_input_004.outputs[6].hide = True
	    group_input_004.outputs[7].hide = True
	    group_input_004.outputs[8].hide = True
	    group_input_004.outputs[9].hide = True
	
	    #node Math.005
	    math_005 = beadz_config.nodes.new("ShaderNodeMath")
	    math_005.name = "Math.005"
	    math_005.hide = True
	    math_005.operation = 'MULTIPLY'
	    math_005.use_clamp = False
	
	    #node Group Input.005
	    group_input_005 = beadz_config.nodes.new("NodeGroupInput")
	    group_input_005.name = "Group Input.005"
	    group_input_005.outputs[0].hide = True
	    group_input_005.outputs[1].hide = True
	    group_input_005.outputs[2].hide = True
	    group_input_005.outputs[3].hide = True
	    group_input_005.outputs[4].hide = True
	    group_input_005.outputs[5].hide = True
	    group_input_005.outputs[6].hide = True
	    group_input_005.outputs[7].hide = True
	    group_input_005.outputs[9].hide = True
	
	    #node Separate XYZ.002
	    separate_xyz_002 = beadz_config.nodes.new("ShaderNodeSeparateXYZ")
	    separate_xyz_002.name = "Separate XYZ.002"
	    separate_xyz_002.hide = True
	
	
	
	
	    #Set parents
	    mesh_line.parent = frame
	    bounding_box.parent = frame
	    separate_xyz.parent = frame
	    separate_xyz_001.parent = frame
	    math.parent = frame
	    math_002.parent = frame
	    group_input_001.parent = frame
	    math_003.parent = frame
	    combine_xyz.parent = frame
	    group_input_002.parent = frame
	    math_004.parent = frame
	    group_input_003.parent = frame
	    math_005.parent = frame
	    group_input_005.parent = frame
	    separate_xyz_002.parent = frame
	
	    #Set locations
	    group_input.location = (-649.6470336914062, -1.7878496646881104)
	    group_output.location = (1442.277099609375, 287.36798095703125)
	    subdivision_surface.location = (-469.5293273925781, 72.42132568359375)
	    transform_geometry.location = (-279.5293273925781, 120.9879150390625)
	    mesh_line.location = (558.6182861328125, -186.37741088867188)
	    bounding_box.location = (30.295654296875, -58.888031005859375)
	    separate_xyz.location = (203.023681640625, -83.52310180664062)
	    separate_xyz_001.location = (202.62921142578125, -44.96820068359375)
	    math.location = (382.8663635253906, -89.73419189453125)
	    math_002.location = (377.5314636230469, -198.62103271484375)
	    group_input_001.location = (202.0562744140625, -233.49801635742188)
	    math_003.location = (381.0915222167969, -235.18930053710938)
	    combine_xyz.location = (559.04345703125, -224.52743530273438)
	    group_input_002.location = (554.7677001953125, -123.03399658203125)
	    frame.location = (-275.0, 468.0)
	    instance_on_points.location = (499.0562438964844, 165.4035186767578)
	    realize_instances.location = (856.4013671875, 262.1210632324219)
	    math_004.location = (377.5574645996094, -162.812744140625)
	    group_input_003.location = (200.24884033203125, -174.37033081054688)
	    set_material.location = (1261.9188232421875, 287.6769714355469)
	    store_named_attribute_001.location = (676.8567504882812, 238.4219970703125)
	    random_value.location = (498.18035888671875, 60.24660873413086)
	    set_shade_smooth.location = (1040.7132568359375, 311.0505676269531)
	    group_input_004.location = (1040.9853515625, 203.65728759765625)
	    math_005.location = (382.9903259277344, -126.44601440429688)
	    group_input_005.location = (35.73799133300781, -101.60177612304688)
	    separate_xyz_002.location = (202.62921142578125, -122.66055297851562)
	
	    #Set dimensions
	    group_input.width, group_input.height = 140.0, 100.0
	    group_output.width, group_output.height = 140.0, 100.0
	    subdivision_surface.width, subdivision_surface.height = 150.0, 100.0
	    transform_geometry.width, transform_geometry.height = 140.0, 100.0
	    mesh_line.width, mesh_line.height = 140.0, 100.0
	    bounding_box.width, bounding_box.height = 140.0, 100.0
	    separate_xyz.width, separate_xyz.height = 140.0, 100.0
	    separate_xyz_001.width, separate_xyz_001.height = 140.0, 100.0
	    math.width, math.height = 140.0, 100.0
	    math_002.width, math_002.height = 140.0, 100.0
	    group_input_001.width, group_input_001.height = 140.0, 100.0
	    math_003.width, math_003.height = 140.0, 100.0
	    combine_xyz.width, combine_xyz.height = 140.0, 100.0
	    group_input_002.width, group_input_002.height = 140.0, 100.0
	    frame.width, frame.height = 729.0, 315.0
	    instance_on_points.width, instance_on_points.height = 140.0, 100.0
	    realize_instances.width, realize_instances.height = 140.0, 100.0
	    math_004.width, math_004.height = 140.0, 100.0
	    group_input_003.width, group_input_003.height = 140.0, 100.0
	    set_material.width, set_material.height = 140.0, 100.0
	    store_named_attribute_001.width, store_named_attribute_001.height = 140.0, 100.0
	    random_value.width, random_value.height = 140.0, 100.0
	    set_shade_smooth.width, set_shade_smooth.height = 140.0, 100.0
	    group_input_004.width, group_input_004.height = 140.0, 100.0
	    math_005.width, math_005.height = 140.0, 100.0
	    group_input_005.width, group_input_005.height = 140.0, 100.0
	    separate_xyz_002.width, separate_xyz_002.height = 140.0, 100.0
	
	    #initialize beadz_config links
	    #set_material.Geometry -> group_output.Geometry
	    beadz_config.links.new(set_material.outputs[0], group_output.inputs[0])
	    #group_input.Geometry -> subdivision_surface.Mesh
	    beadz_config.links.new(group_input.outputs[0], subdivision_surface.inputs[0])
	    #subdivision_surface.Mesh -> transform_geometry.Geometry
	    beadz_config.links.new(subdivision_surface.outputs[0], transform_geometry.inputs[0])
	    #group_input.Subdivision Level -> subdivision_surface.Level
	    beadz_config.links.new(group_input.outputs[4], subdivision_surface.inputs[1])
	    #group_input.Subdivision Edge Crease -> subdivision_surface.Edge Crease
	    beadz_config.links.new(group_input.outputs[5], subdivision_surface.inputs[2])
	    #group_input.Subdivision Vertex Crease -> subdivision_surface.Vertex Crease
	    beadz_config.links.new(group_input.outputs[6], subdivision_surface.inputs[3])
	    #group_input.Scale -> transform_geometry.Scale
	    beadz_config.links.new(group_input.outputs[8], transform_geometry.inputs[3])
	    #bounding_box.Max -> separate_xyz.Vector
	    beadz_config.links.new(bounding_box.outputs[2], separate_xyz.inputs[0])
	    #bounding_box.Min -> separate_xyz_001.Vector
	    beadz_config.links.new(bounding_box.outputs[1], separate_xyz_001.inputs[0])
	    #separate_xyz.Z -> math.Value
	    beadz_config.links.new(separate_xyz.outputs[2], math.inputs[0])
	    #separate_xyz_001.Z -> math.Value
	    beadz_config.links.new(separate_xyz_001.outputs[2], math.inputs[1])
	    #group_input_001.Count -> math_002.Value
	    beadz_config.links.new(group_input_001.outputs[1], math_002.inputs[0])
	    #math_002.Value -> math_003.Value
	    beadz_config.links.new(math_002.outputs[0], math_003.inputs[1])
	    #combine_xyz.Vector -> mesh_line.Offset
	    beadz_config.links.new(combine_xyz.outputs[0], mesh_line.inputs[3])
	    #math_003.Value -> combine_xyz.Z
	    beadz_config.links.new(math_003.outputs[0], combine_xyz.inputs[2])
	    #group_input_002.Count -> mesh_line.Count
	    beadz_config.links.new(group_input_002.outputs[1], mesh_line.inputs[0])
	    #transform_geometry.Geometry -> instance_on_points.Instance
	    beadz_config.links.new(transform_geometry.outputs[0], instance_on_points.inputs[2])
	    #mesh_line.Mesh -> instance_on_points.Points
	    beadz_config.links.new(mesh_line.outputs[0], instance_on_points.inputs[0])
	    #store_named_attribute_001.Geometry -> realize_instances.Geometry
	    beadz_config.links.new(store_named_attribute_001.outputs[0], realize_instances.inputs[0])
	    #math_005.Value -> math_004.Value
	    beadz_config.links.new(math_005.outputs[0], math_004.inputs[0])
	    #math_004.Value -> math_003.Value
	    beadz_config.links.new(math_004.outputs[0], math_003.inputs[0])
	    #set_shade_smooth.Geometry -> set_material.Geometry
	    beadz_config.links.new(set_shade_smooth.outputs[0], set_material.inputs[0])
	    #instance_on_points.Instances -> store_named_attribute_001.Geometry
	    beadz_config.links.new(instance_on_points.outputs[0], store_named_attribute_001.inputs[0])
	    #random_value.Value -> store_named_attribute_001.Value
	    beadz_config.links.new(random_value.outputs[0], store_named_attribute_001.inputs[3])
	    #realize_instances.Geometry -> set_shade_smooth.Geometry
	    beadz_config.links.new(realize_instances.outputs[0], set_shade_smooth.inputs[0])
	    #group_input_004.Material -> set_material.Material
	    beadz_config.links.new(group_input_004.outputs[3], set_material.inputs[2])
	    #subdivision_surface.Mesh -> bounding_box.Geometry
	    beadz_config.links.new(subdivision_surface.outputs[0], bounding_box.inputs[0])
	    #math.Value -> math_005.Value
	    beadz_config.links.new(math.outputs[0], math_005.inputs[0])
	    #group_input_005.Scale -> separate_xyz_002.Vector
	    beadz_config.links.new(group_input_005.outputs[8], separate_xyz_002.inputs[0])
	    #separate_xyz_002.Z -> math_005.Value
	    beadz_config.links.new(separate_xyz_002.outputs[2], math_005.inputs[1])
	    #group_input_003.Offset -> math_004.Value
	    beadz_config.links.new(group_input_003.outputs[2], math_004.inputs[1])
	    #group_input.Limit Surface -> subdivision_surface.Limit Surface
	    beadz_config.links.new(group_input.outputs[7], subdivision_surface.inputs[4])
	    return beadz_config
	return beadz_config_node_group()

	

	
