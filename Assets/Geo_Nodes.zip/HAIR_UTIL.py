import bpy, mathutils

def node():
	#initialize align_to_surface node group
	def align_to_surface_node_group():
	    align_to_surface = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "ALIGN_TO_SURFACE")
	
	    align_to_surface.color_tag = 'NONE'
	    align_to_surface.description = "Align Curve tilt to match nearest surface normals."
	    align_to_surface.default_group_node_width = 140
	    
	
	
	    #align_to_surface interface
	    #Socket Geometry
	    geometry_socket = align_to_surface.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket.attribute_domain = 'POINT'
	    geometry_socket.description = "Curve hair geometry."
	
	    #Socket Tilt
	    tilt_socket = align_to_surface.interface.new_socket(name = "Tilt", in_out='OUTPUT', socket_type = 'NodeSocketFloat')
	    tilt_socket.default_value = 0.0
	    tilt_socket.min_value = -3.4028234663852886e+38
	    tilt_socket.max_value = 3.4028234663852886e+38
	    tilt_socket.subtype = 'NONE'
	    tilt_socket.attribute_domain = 'POINT'
	    tilt_socket.description = "Tilt angle per point."
	
	    #Socket Geometry
	    geometry_socket_1 = align_to_surface.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_1.attribute_domain = 'POINT'
	    geometry_socket_1.description = "Hair curve geometry."
	
	    #Socket Surface
	    surface_socket = align_to_surface.interface.new_socket(name = "Surface", in_out='INPUT', socket_type = 'NodeSocketObject')
	    surface_socket.attribute_domain = 'POINT'
	    surface_socket.description = "Surface mesh to align control points."
	
	    #Socket Surface Align Factor
	    surface_align_factor_socket = align_to_surface.interface.new_socket(name = "Surface Align Factor", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    surface_align_factor_socket.default_value = 1.0
	    surface_align_factor_socket.min_value = 0.0
	    surface_align_factor_socket.max_value = 1.0
	    surface_align_factor_socket.subtype = 'FACTOR'
	    surface_align_factor_socket.attribute_domain = 'POINT'
	    surface_align_factor_socket.description = "Percentage of alignment to use."
	
	
	    #initialize align_to_surface nodes
	    #node Group Output
	    group_output = align_to_surface.nodes.new("NodeGroupOutput")
	    group_output.name = "Group Output"
	    group_output.is_active_output = True
	    group_output.inputs[2].hide = True
	
	    #node Group Input
	    group_input = align_to_surface.nodes.new("NodeGroupInput")
	    group_input.name = "Group Input"
	    group_input.outputs[2].hide = True
	    group_input.outputs[3].hide = True
	
	    #node Sample Nearest.003
	    sample_nearest_003 = align_to_surface.nodes.new("GeometryNodeSampleNearest")
	    sample_nearest_003.name = "Sample Nearest.003"
	    sample_nearest_003.hide = True
	    sample_nearest_003.domain = 'POINT'
	    #Sample Position
	    sample_nearest_003.inputs[1].default_value = (0.0, 0.0, 0.0)
	
	    #node Sample Index.003
	    sample_index_003 = align_to_surface.nodes.new("GeometryNodeSampleIndex")
	    sample_index_003.name = "Sample Index.003"
	    sample_index_003.hide = True
	    sample_index_003.clamp = False
	    sample_index_003.data_type = 'FLOAT_VECTOR'
	    sample_index_003.domain = 'POINT'
	
	    #node Normal.006
	    normal_006 = align_to_surface.nodes.new("GeometryNodeInputNormal")
	    normal_006.name = "Normal.006"
	    normal_006.legacy_corner_normals = True
	
	    #node Reroute
	    reroute = align_to_surface.nodes.new("NodeReroute")
	    reroute.name = "Reroute"
	    reroute.socket_idname = "NodeSocketGeometry"
	    #node Map Range
	    map_range = align_to_surface.nodes.new("ShaderNodeMapRange")
	    map_range.name = "Map Range"
	    map_range.hide = True
	    map_range.clamp = False
	    map_range.data_type = 'FLOAT'
	    map_range.interpolation_type = 'LINEAR'
	    map_range.inputs[1].hide = True
	    map_range.inputs[2].hide = True
	    map_range.inputs[3].hide = True
	    map_range.inputs[5].hide = True
	    map_range.inputs[6].hide = True
	    map_range.inputs[7].hide = True
	    map_range.inputs[8].hide = True
	    map_range.inputs[9].hide = True
	    map_range.inputs[10].hide = True
	    map_range.inputs[11].hide = True
	    map_range.outputs[1].hide = True
	    #From Min
	    map_range.inputs[1].default_value = 0.0
	    #From Max
	    map_range.inputs[2].default_value = 1.0
	    #To Min
	    map_range.inputs[3].default_value = 0.0
	
	    #node Group Input.001
	    group_input_001 = align_to_surface.nodes.new("NodeGroupInput")
	    group_input_001.name = "Group Input.001"
	    group_input_001.outputs[0].hide = True
	    group_input_001.outputs[1].hide = True
	    group_input_001.outputs[3].hide = True
	
	    #node Object Info
	    object_info = align_to_surface.nodes.new("GeometryNodeObjectInfo")
	    object_info.name = "Object Info"
	    object_info.hide = True
	    object_info.transform_space = 'RELATIVE'
	    object_info.inputs[1].hide = True
	    object_info.outputs[0].hide = True
	    object_info.outputs[1].hide = True
	    object_info.outputs[2].hide = True
	    object_info.outputs[3].hide = True
	    #As Instance
	    object_info.inputs[1].default_value = False
	
	    #node Normal.007
	    normal_007 = align_to_surface.nodes.new("GeometryNodeInputNormal")
	    normal_007.name = "Normal.007"
	    normal_007.hide = True
	    normal_007.legacy_corner_normals = True
	
	    #node Curve Tangent.003
	    curve_tangent_003 = align_to_surface.nodes.new("GeometryNodeInputTangent")
	    curve_tangent_003.name = "Curve Tangent.003"
	    curve_tangent_003.hide = True
	
	    #node Vector Math
	    vector_math = align_to_surface.nodes.new("ShaderNodeVectorMath")
	    vector_math.name = "Vector Math"
	    vector_math.operation = 'CROSS_PRODUCT'
	
	    #node Set Spline Type
	    set_spline_type = align_to_surface.nodes.new("GeometryNodeCurveSplineType")
	    set_spline_type.name = "Set Spline Type"
	    set_spline_type.spline_type = 'POLY'
	    set_spline_type.inputs[1].hide = True
	    #Selection
	    set_spline_type.inputs[1].default_value = True
	
	    #node Vector Math.001
	    vector_math_001 = align_to_surface.nodes.new("ShaderNodeVectorMath")
	    vector_math_001.name = "Vector Math.001"
	    vector_math_001.operation = 'CROSS_PRODUCT'
	
	    #node Vector Math.002
	    vector_math_002 = align_to_surface.nodes.new("ShaderNodeVectorMath")
	    vector_math_002.name = "Vector Math.002"
	    vector_math_002.operation = 'DOT_PRODUCT'
	
	    #node Vector Math.003
	    vector_math_003 = align_to_surface.nodes.new("ShaderNodeVectorMath")
	    vector_math_003.name = "Vector Math.003"
	    vector_math_003.operation = 'DOT_PRODUCT'
	
	    #node Curve Tangent.004
	    curve_tangent_004 = align_to_surface.nodes.new("GeometryNodeInputTangent")
	    curve_tangent_004.name = "Curve Tangent.004"
	    curve_tangent_004.hide = True
	
	    #node Math
	    math = align_to_surface.nodes.new("ShaderNodeMath")
	    math.name = "Math"
	    math.operation = 'ARCTAN2'
	    math.use_clamp = False
	
	    #node Math.001
	    math_001 = align_to_surface.nodes.new("ShaderNodeMath")
	    math_001.name = "Math.001"
	    math_001.operation = 'ADD'
	    math_001.use_clamp = False
	
	    #node Curve Tilt
	    curve_tilt = align_to_surface.nodes.new("GeometryNodeInputCurveTilt")
	    curve_tilt.name = "Curve Tilt"
	
	    #node Frame
	    frame = align_to_surface.nodes.new("NodeFrame")
	    frame.label = "Surface Normals"
	    frame.name = "Frame"
	    frame.label_size = 20
	    frame.shrink = True
	
	    #node Frame.001
	    frame_001 = align_to_surface.nodes.new("NodeFrame")
	    frame_001.label = "Tilt Offset"
	    frame_001.name = "Frame.001"
	    frame_001.label_size = 20
	    frame_001.shrink = True
	
	    #node Reroute.001
	    reroute_001 = align_to_surface.nodes.new("NodeReroute")
	    reroute_001.name = "Reroute.001"
	    reroute_001.socket_idname = "NodeSocketVector"
	    #node Reroute.002
	    reroute_002 = align_to_surface.nodes.new("NodeReroute")
	    reroute_002.name = "Reroute.002"
	    reroute_002.socket_idname = "NodeSocketVector"
	    #node Reroute.003
	    reroute_003 = align_to_surface.nodes.new("NodeReroute")
	    reroute_003.name = "Reroute.003"
	    reroute_003.socket_idname = "NodeSocketVector"
	    #node Reroute.004
	    reroute_004 = align_to_surface.nodes.new("NodeReroute")
	    reroute_004.name = "Reroute.004"
	    reroute_004.socket_idname = "NodeSocketVector"
	    #node Reroute.005
	    reroute_005 = align_to_surface.nodes.new("NodeReroute")
	    reroute_005.name = "Reroute.005"
	    reroute_005.socket_idname = "NodeSocketVector"
	    #node Reroute.006
	    reroute_006 = align_to_surface.nodes.new("NodeReroute")
	    reroute_006.name = "Reroute.006"
	    reroute_006.socket_idname = "NodeSocketVector"
	
	
	
	    #Set parents
	    sample_nearest_003.parent = frame
	    sample_index_003.parent = frame
	    normal_006.parent = frame
	    reroute.parent = frame
	    object_info.parent = frame
	    normal_007.parent = frame_001
	    curve_tangent_003.parent = frame_001
	    vector_math.parent = frame_001
	    vector_math_001.parent = frame_001
	    vector_math_002.parent = frame_001
	    vector_math_003.parent = frame_001
	    curve_tangent_004.parent = frame_001
	    math.parent = frame_001
	    math_001.parent = frame_001
	    curve_tilt.parent = frame_001
	    reroute_001.parent = frame_001
	    reroute_003.parent = frame_001
	    reroute_004.parent = frame_001
	    reroute_005.parent = frame_001
	    reroute_006.parent = frame_001
	
	    #Set locations
	    group_output.location = (1190.9041748046875, 41.02642059326172)
	    group_input.location = (-531.6859130859375, 0.0)
	    sample_nearest_003.location = (226.60983276367188, -45.36302947998047)
	    sample_index_003.location = (226.49765014648438, -85.8040771484375)
	    normal_006.location = (224.42202758789062, -123.82649230957031)
	    reroute.location = (189.0732879638672, -74.14251708984375)
	    map_range.location = (948.035400390625, -359.7928466796875)
	    group_input_001.location = (944.666015625, -292.8227233886719)
	    object_info.location = (30.00262451171875, -63.75152587890625)
	    normal_007.location = (29.79510498046875, -319.975341796875)
	    curve_tangent_003.location = (29.79510498046875, -356.0633544921875)
	    vector_math.location = (209.37625122070312, -248.7354736328125)
	    set_spline_type.location = (16.94012451171875, 46.891204833984375)
	    vector_math_001.location = (535.6417236328125, -140.51602172851562)
	    vector_math_002.location = (742.26171875, -146.87136840820312)
	    vector_math_003.location = (750.4005126953125, -287.6363525390625)
	    curve_tangent_004.location = (534.1580810546875, -283.842041015625)
	    math.location = (938.2330932617188, -159.55422973632812)
	    math_001.location = (1118.5933837890625, -40.013885498046875)
	    curve_tilt.location = (936.494873046875, -93.68789672851562)
	    frame.location = (-381.0, -77.0)
	    frame_001.location = (-384.0, -300.0)
	    reroute_001.location = (428.298095703125, -393.26318359375)
	    reroute_002.location = (44.78921127319336, -173.88510131835938)
	    reroute_003.location = (388.9779968261719, -282.9173583984375)
	    reroute_004.location = (386.8365173339844, -227.5872802734375)
	    reroute_005.location = (390.8068542480469, -369.8052978515625)
	    reroute_006.location = (428.40765380859375, -250.347900390625)
	
	    #Set dimensions
	    group_output.width, group_output.height = 140.0, 100.0
	    group_input.width, group_input.height = 140.0, 100.0
	    sample_nearest_003.width, sample_nearest_003.height = 140.0, 100.0
	    sample_index_003.width, sample_index_003.height = 140.0, 100.0
	    normal_006.width, normal_006.height = 140.0, 100.0
	    reroute.width, reroute.height = 10.0, 100.0
	    map_range.width, map_range.height = 140.0, 100.0
	    group_input_001.width, group_input_001.height = 140.0, 100.0
	    object_info.width, object_info.height = 140.0, 100.0
	    normal_007.width, normal_007.height = 140.0, 100.0
	    curve_tangent_003.width, curve_tangent_003.height = 140.0, 100.0
	    vector_math.width, vector_math.height = 140.0, 100.0
	    set_spline_type.width, set_spline_type.height = 140.0, 100.0
	    vector_math_001.width, vector_math_001.height = 140.0, 100.0
	    vector_math_002.width, vector_math_002.height = 140.0, 100.0
	    vector_math_003.width, vector_math_003.height = 140.0, 100.0
	    curve_tangent_004.width, curve_tangent_004.height = 140.0, 100.0
	    math.width, math.height = 140.0, 100.0
	    math_001.width, math_001.height = 140.0, 100.0
	    curve_tilt.width, curve_tilt.height = 140.0, 100.0
	    frame.width, frame.height = 397.0, 204.0
	    frame_001.width, frame_001.height = 1289.0, 441.0
	    reroute_001.width, reroute_001.height = 10.0, 100.0
	    reroute_002.width, reroute_002.height = 10.0, 100.0
	    reroute_003.width, reroute_003.height = 10.0, 100.0
	    reroute_004.width, reroute_004.height = 10.0, 100.0
	    reroute_005.width, reroute_005.height = 10.0, 100.0
	    reroute_006.width, reroute_006.height = 10.0, 100.0
	
	    #initialize align_to_surface links
	    #reroute.Output -> sample_nearest_003.Geometry
	    align_to_surface.links.new(reroute.outputs[0], sample_nearest_003.inputs[0])
	    #normal_006.Normal -> sample_index_003.Value
	    align_to_surface.links.new(normal_006.outputs[0], sample_index_003.inputs[1])
	    #reroute.Output -> sample_index_003.Geometry
	    align_to_surface.links.new(reroute.outputs[0], sample_index_003.inputs[0])
	    #sample_nearest_003.Index -> sample_index_003.Index
	    align_to_surface.links.new(sample_nearest_003.outputs[0], sample_index_003.inputs[2])
	    #group_input_001.Surface Align Factor -> map_range.Value
	    align_to_surface.links.new(group_input_001.outputs[2], map_range.inputs[0])
	    #group_input.Surface -> object_info.Object
	    align_to_surface.links.new(group_input.outputs[1], object_info.inputs[0])
	    #object_info.Geometry -> reroute.Input
	    align_to_surface.links.new(object_info.outputs[4], reroute.inputs[0])
	    #group_input.Geometry -> set_spline_type.Curve
	    align_to_surface.links.new(group_input.outputs[0], set_spline_type.inputs[0])
	    #set_spline_type.Curve -> group_output.Geometry
	    align_to_surface.links.new(set_spline_type.outputs[0], group_output.inputs[0])
	    #normal_007.Normal -> vector_math.Vector
	    align_to_surface.links.new(normal_007.outputs[0], vector_math.inputs[0])
	    #curve_tangent_003.Tangent -> vector_math.Vector
	    align_to_surface.links.new(curve_tangent_003.outputs[0], vector_math.inputs[1])
	    #reroute_004.Output -> vector_math_001.Vector
	    align_to_surface.links.new(reroute_004.outputs[0], vector_math_001.inputs[0])
	    #vector_math_001.Vector -> vector_math_002.Vector
	    align_to_surface.links.new(vector_math_001.outputs[0], vector_math_002.inputs[0])
	    #curve_tangent_004.Tangent -> vector_math_002.Vector
	    align_to_surface.links.new(curve_tangent_004.outputs[0], vector_math_002.inputs[1])
	    #reroute_005.Output -> vector_math_003.Vector
	    align_to_surface.links.new(reroute_005.outputs[0], vector_math_003.inputs[0])
	    #reroute_001.Output -> vector_math_003.Vector
	    align_to_surface.links.new(reroute_001.outputs[0], vector_math_003.inputs[1])
	    #vector_math_002.Value -> math.Value
	    align_to_surface.links.new(vector_math_002.outputs[1], math.inputs[0])
	    #vector_math_003.Value -> math.Value
	    align_to_surface.links.new(vector_math_003.outputs[1], math.inputs[1])
	    #math.Value -> math_001.Value
	    align_to_surface.links.new(math.outputs[0], math_001.inputs[1])
	    #curve_tilt.Tilt -> math_001.Value
	    align_to_surface.links.new(curve_tilt.outputs[0], math_001.inputs[0])
	    #math_001.Value -> map_range.To Max
	    align_to_surface.links.new(math_001.outputs[0], map_range.inputs[4])
	    #map_range.Result -> group_output.Tilt
	    align_to_surface.links.new(map_range.outputs[0], group_output.inputs[1])
	    #reroute_006.Output -> reroute_001.Input
	    align_to_surface.links.new(reroute_006.outputs[0], reroute_001.inputs[0])
	    #sample_index_003.Value -> reroute_002.Input
	    align_to_surface.links.new(sample_index_003.outputs[0], reroute_002.inputs[0])
	    #vector_math.Vector -> reroute_003.Input
	    align_to_surface.links.new(vector_math.outputs[0], reroute_003.inputs[0])
	    #reroute_003.Output -> reroute_004.Input
	    align_to_surface.links.new(reroute_003.outputs[0], reroute_004.inputs[0])
	    #reroute_003.Output -> reroute_005.Input
	    align_to_surface.links.new(reroute_003.outputs[0], reroute_005.inputs[0])
	    #reroute_002.Output -> reroute_006.Input
	    align_to_surface.links.new(reroute_002.outputs[0], reroute_006.inputs[0])
	    #reroute_006.Output -> vector_math_001.Vector
	    align_to_surface.links.new(reroute_006.outputs[0], vector_math_001.inputs[1])
	    return align_to_surface
	
	align_to_surface = align_to_surface_node_group()
	
	#initialize hair_util node group
	def hair_util_node_group():
	    hair_util = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "HAIR_UTIL")
	
	    hair_util.color_tag = 'NONE'
	    hair_util.description = "Utility to resample points, add tangents attribute, set curve tilt, set curve radius, and | or add material."
	    hair_util.default_group_node_width = 140
	    
	
	    hair_util.is_modifier = True
	
	    #hair_util interface
	    #Socket Geometry
	    geometry_socket_2 = hair_util.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_2.attribute_domain = 'POINT'
	    geometry_socket_2.description = "Modified hair curve."
	
	    #Socket Geometry
	    geometry_socket_3 = hair_util.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_3.attribute_domain = 'POINT'
	    geometry_socket_3.description = "Hair curve geometry."
	
	    #Socket Surface
	    surface_socket_1 = hair_util.interface.new_socket(name = "Surface", in_out='INPUT', socket_type = 'NodeSocketObject')
	    surface_socket_1.attribute_domain = 'POINT'
	    surface_socket_1.description = "Surface object to align curve tilt to."
	
	    #Socket Control Points
	    control_points_socket = hair_util.interface.new_socket(name = "Control Points", in_out='INPUT', socket_type = 'NodeSocketInt')
	    control_points_socket.default_value = 10
	    control_points_socket.min_value = 1
	    control_points_socket.max_value = 100000
	    control_points_socket.subtype = 'NONE'
	    control_points_socket.attribute_domain = 'POINT'
	    control_points_socket.description = "Amount of points to reample to each curve. (0 means no resampling)"
	
	    #Socket Surface Align Factor
	    surface_align_factor_socket_1 = hair_util.interface.new_socket(name = "Surface Align Factor", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    surface_align_factor_socket_1.default_value = 0.0
	    surface_align_factor_socket_1.min_value = 0.0
	    surface_align_factor_socket_1.max_value = 1.0
	    surface_align_factor_socket_1.subtype = 'FACTOR'
	    surface_align_factor_socket_1.attribute_domain = 'POINT'
	    surface_align_factor_socket_1.description = "Percentage to align curve tilt to surfface."
	
	    #Socket Radius
	    radius_socket = hair_util.interface.new_socket(name = "Radius", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    radius_socket.default_value = 0.004999999888241291
	    radius_socket.min_value = 0.0
	    radius_socket.max_value = 3.4028234663852886e+38
	    radius_socket.subtype = 'DISTANCE'
	    radius_socket.attribute_domain = 'POINT'
	    radius_socket.description = "Curve radius."
	
	    #Socket Material
	    material_socket = hair_util.interface.new_socket(name = "Material", in_out='INPUT', socket_type = 'NodeSocketMaterial')
	    material_socket.attribute_domain = 'POINT'
	    material_socket.description = "Material for curve."
	
	
	    #initialize hair_util nodes
	    #node Group Input
	    group_input_1 = hair_util.nodes.new("NodeGroupInput")
	    group_input_1.name = "Group Input"
	    group_input_1.outputs[1].hide = True
	    group_input_1.outputs[3].hide = True
	    group_input_1.outputs[4].hide = True
	    group_input_1.outputs[5].hide = True
	    group_input_1.outputs[6].hide = True
	
	    #node Group Output
	    group_output_1 = hair_util.nodes.new("NodeGroupOutput")
	    group_output_1.name = "Group Output"
	    group_output_1.is_active_output = True
	    group_output_1.inputs[1].hide = True
	
	    #node Resample Curve
	    resample_curve = hair_util.nodes.new("GeometryNodeResampleCurve")
	    resample_curve.name = "Resample Curve"
	    resample_curve.keep_last_segment = False
	    resample_curve.mode = 'COUNT'
	    resample_curve.inputs[1].hide = True
	    resample_curve.inputs[3].hide = True
	    #Selection
	    resample_curve.inputs[1].default_value = True
	
	    #node Group Input.001
	    group_input_001_1 = hair_util.nodes.new("NodeGroupInput")
	    group_input_001_1.name = "Group Input.001"
	    group_input_001_1.outputs[0].hide = True
	    group_input_001_1.outputs[2].hide = True
	    group_input_001_1.outputs[4].hide = True
	    group_input_001_1.outputs[5].hide = True
	    group_input_001_1.outputs[6].hide = True
	
	    #node Set Curve Tilt
	    set_curve_tilt = hair_util.nodes.new("GeometryNodeSetCurveTilt")
	    set_curve_tilt.name = "Set Curve Tilt"
	    set_curve_tilt.inputs[1].hide = True
	    #Selection
	    set_curve_tilt.inputs[1].default_value = True
	
	    #node Set Curve Radius
	    set_curve_radius = hair_util.nodes.new("GeometryNodeSetCurveRadius")
	    set_curve_radius.name = "Set Curve Radius"
	    set_curve_radius.inputs[1].hide = True
	    #Selection
	    set_curve_radius.inputs[1].default_value = True
	
	    #node Store Named Attribute
	    store_named_attribute = hair_util.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute.name = "Store Named Attribute"
	    store_named_attribute.data_type = 'FLOAT_VECTOR'
	    store_named_attribute.domain = 'POINT'
	    store_named_attribute.inputs[1].hide = True
	    #Selection
	    store_named_attribute.inputs[1].default_value = True
	
	    #node Curve Tangent
	    curve_tangent = hair_util.nodes.new("GeometryNodeInputTangent")
	    curve_tangent.name = "Curve Tangent"
	
	    #node String
	    string = hair_util.nodes.new("FunctionNodeInputString")
	    string.name = "String"
	    string.string = "tangents"
	
	    #node Group.001
	    group_001 = hair_util.nodes.new("GeometryNodeGroup")
	    group_001.name = "Group.001"
	    group_001.node_tree = align_to_surface
	
	    #node Group Input.002
	    group_input_002 = hair_util.nodes.new("NodeGroupInput")
	    group_input_002.name = "Group Input.002"
	    group_input_002.outputs[0].hide = True
	    group_input_002.outputs[1].hide = True
	    group_input_002.outputs[2].hide = True
	    group_input_002.outputs[3].hide = True
	    group_input_002.outputs[5].hide = True
	    group_input_002.outputs[6].hide = True
	
	    #node Set Material
	    set_material = hair_util.nodes.new("GeometryNodeSetMaterial")
	    set_material.name = "Set Material"
	    #Selection
	    set_material.inputs[1].default_value = True
	
	    #node Group Input.003
	    group_input_003 = hair_util.nodes.new("NodeGroupInput")
	    group_input_003.name = "Group Input.003"
	    group_input_003.outputs[0].hide = True
	    group_input_003.outputs[1].hide = True
	    group_input_003.outputs[2].hide = True
	    group_input_003.outputs[3].hide = True
	    group_input_003.outputs[4].hide = True
	    group_input_003.outputs[6].hide = True
	
	    #node Resample Bypass
	    resample_bypass = hair_util.nodes.new("GeometryNodeSwitch")
	    resample_bypass.label = "Resample Bypass"
	    resample_bypass.name = "Resample Bypass"
	    resample_bypass.hide = True
	    resample_bypass.input_type = 'GEOMETRY'
	
	    #node Group Input.004
	    group_input_004 = hair_util.nodes.new("NodeGroupInput")
	    group_input_004.name = "Group Input.004"
	    group_input_004.outputs[0].hide = True
	    group_input_004.outputs[1].hide = True
	    group_input_004.outputs[3].hide = True
	    group_input_004.outputs[4].hide = True
	    group_input_004.outputs[5].hide = True
	    group_input_004.outputs[6].hide = True
	
	    #node Compare
	    compare = hair_util.nodes.new("FunctionNodeCompare")
	    compare.name = "Compare"
	    compare.hide = True
	    compare.data_type = 'INT'
	    compare.mode = 'ELEMENT'
	    compare.operation = 'EQUAL'
	    compare.inputs[0].hide = True
	    compare.inputs[1].hide = True
	    compare.inputs[3].hide = True
	    compare.inputs[4].hide = True
	    compare.inputs[5].hide = True
	    compare.inputs[6].hide = True
	    compare.inputs[7].hide = True
	    compare.inputs[8].hide = True
	    compare.inputs[9].hide = True
	    compare.inputs[10].hide = True
	    compare.inputs[11].hide = True
	    compare.inputs[12].hide = True
	    #B_INT
	    compare.inputs[3].default_value = 0
	
	    #node Group Input.005
	    group_input_005 = hair_util.nodes.new("NodeGroupInput")
	    group_input_005.name = "Group Input.005"
	    group_input_005.outputs[1].hide = True
	    group_input_005.outputs[2].hide = True
	    group_input_005.outputs[3].hide = True
	    group_input_005.outputs[4].hide = True
	    group_input_005.outputs[5].hide = True
	    group_input_005.outputs[6].hide = True
	
	    #node Separate Components
	    separate_components = hair_util.nodes.new("GeometryNodeSeparateComponents")
	    separate_components.name = "Separate Components"
	    separate_components.hide = True
	
	    #node Join Geometry
	    join_geometry = hair_util.nodes.new("GeometryNodeJoinGeometry")
	    join_geometry.name = "Join Geometry"
	
	    #node Reroute
	    reroute_1 = hair_util.nodes.new("NodeReroute")
	    reroute_1.name = "Reroute"
	    reroute_1.socket_idname = "NodeSocketGeometry"
	    #node Reroute.001
	    reroute_001_1 = hair_util.nodes.new("NodeReroute")
	    reroute_001_1.name = "Reroute.001"
	    reroute_001_1.socket_idname = "NodeSocketGeometry"
	    #node Reroute.002
	    reroute_002_1 = hair_util.nodes.new("NodeReroute")
	    reroute_002_1.name = "Reroute.002"
	    reroute_002_1.socket_idname = "NodeSocketGeometry"
	    #node Reroute.003
	    reroute_003_1 = hair_util.nodes.new("NodeReroute")
	    reroute_003_1.name = "Reroute.003"
	    reroute_003_1.socket_idname = "NodeSocketGeometry"
	    #node Reroute.004
	    reroute_004_1 = hair_util.nodes.new("NodeReroute")
	    reroute_004_1.name = "Reroute.004"
	    reroute_004_1.socket_idname = "NodeSocketGeometry"
	    #node Hair Util Bake
	    hair_util_bake = hair_util.nodes.new("GeometryNodeBake")
	    hair_util_bake.label = "Hair Util Bake"
	    hair_util_bake.name = "Hair Util Bake"
	    hair_util_bake.active_index = 0
	    hair_util_bake.bake_items.clear()
	    hair_util_bake.bake_items.new('GEOMETRY', "Geometry")
	    hair_util_bake.bake_items[0].attribute_domain = 'POINT'
	    hair_util_bake.inputs[1].hide = True
	    hair_util_bake.outputs[1].hide = True
	
	    #node Reroute.005
	    reroute_005_1 = hair_util.nodes.new("NodeReroute")
	    reroute_005_1.name = "Reroute.005"
	    reroute_005_1.socket_idname = "NodeSocketGeometry"
	    #node Reroute.006
	    reroute_006_1 = hair_util.nodes.new("NodeReroute")
	    reroute_006_1.name = "Reroute.006"
	    reroute_006_1.socket_idname = "NodeSocketGeometry"
	    #node Reroute.007
	    reroute_007 = hair_util.nodes.new("NodeReroute")
	    reroute_007.name = "Reroute.007"
	    reroute_007.socket_idname = "NodeSocketGeometry"
	    #node Reroute.008
	    reroute_008 = hair_util.nodes.new("NodeReroute")
	    reroute_008.name = "Reroute.008"
	    reroute_008.socket_idname = "NodeSocketGeometry"
	    #node Reroute.009
	    reroute_009 = hair_util.nodes.new("NodeReroute")
	    reroute_009.name = "Reroute.009"
	    reroute_009.socket_idname = "NodeSocketGeometry"
	
	
	
	
	    #Set locations
	    group_input_1.location = (-491.4117431640625, -1.0620012283325195)
	    group_output_1.location = (1482.2890625, 285.35235595703125)
	    resample_curve.location = (-305.46923828125, 46.93409729003906)
	    group_input_001_1.location = (73.41648864746094, -57.758602142333984)
	    set_curve_tilt.location = (550.9166870117188, 213.02505493164062)
	    set_curve_radius.location = (730.9487915039062, 238.1438751220703)
	    store_named_attribute.location = (71.62547302246094, 120.16132354736328)
	    curve_tangent.location = (-99.8661117553711, -75.67583465576172)
	    string.location = (-97.87051391601562, 212.61166381835938)
	    group_001.location = (282.4932861328125, 188.2352752685547)
	    group_input_002.location = (549.8389282226562, 110.16423034667969)
	    set_material.location = (911.3939819335938, 262.7181396484375)
	    group_input_003.location = (733.009033203125, 135.44296264648438)
	    resample_bypass.location = (-102.30951690673828, 19.861846923828125)
	    group_input_004.location = (-98.90421295166016, 117.20633697509766)
	    compare.location = (-98.70023345947266, 56.11247253417969)
	    group_input_005.location = (-103.41580963134766, -10.992935180664062)
	    separate_components.location = (-491.5304870605469, 33.033782958984375)
	    join_geometry.location = (1132.817626953125, 285.22216796875)
	    reroute_1.location = (-231.74180603027344, 343.2101135253906)
	    reroute_001_1.location = (-231.5958251953125, 332.94287109375)
	    reroute_002_1.location = (-233.00949096679688, 348.2896423339844)
	    reroute_003_1.location = (-230.6805877685547, 328.1274108886719)
	    reroute_004_1.location = (-231.5958251953125, 338.0973815917969)
	    hair_util_bake.location = (1302.5972900390625, 331.7893371582031)
	    reroute_005_1.location = (1030.9556884765625, 329.9912109375)
	    reroute_006_1.location = (1030.9556884765625, 344.9916687011719)
	    reroute_007.location = (1030.9556884765625, 334.99041748046875)
	    reroute_008.location = (1030.9556884765625, 349.9920959472656)
	    reroute_009.location = (1030.9556884765625, 339.9910888671875)
	
	    #Set dimensions
	    group_input_1.width, group_input_1.height = 140.0, 100.0
	    group_output_1.width, group_output_1.height = 140.0, 100.0
	    resample_curve.width, resample_curve.height = 140.0, 100.0
	    group_input_001_1.width, group_input_001_1.height = 140.0, 100.0
	    set_curve_tilt.width, set_curve_tilt.height = 140.0, 100.0
	    set_curve_radius.width, set_curve_radius.height = 140.0, 100.0
	    store_named_attribute.width, store_named_attribute.height = 140.0, 100.0
	    curve_tangent.width, curve_tangent.height = 140.0, 100.0
	    string.width, string.height = 140.0, 100.0
	    group_001.width, group_001.height = 193.53033447265625, 100.0
	    group_input_002.width, group_input_002.height = 140.0, 100.0
	    set_material.width, set_material.height = 140.0, 100.0
	    group_input_003.width, group_input_003.height = 140.0, 100.0
	    resample_bypass.width, resample_bypass.height = 140.0, 100.0
	    group_input_004.width, group_input_004.height = 140.0, 100.0
	    compare.width, compare.height = 140.0, 100.0
	    group_input_005.width, group_input_005.height = 140.0, 100.0
	    separate_components.width, separate_components.height = 140.0, 100.0
	    join_geometry.width, join_geometry.height = 140.0, 100.0
	    reroute_1.width, reroute_1.height = 10.0, 100.0
	    reroute_001_1.width, reroute_001_1.height = 10.0, 100.0
	    reroute_002_1.width, reroute_002_1.height = 10.0, 100.0
	    reroute_003_1.width, reroute_003_1.height = 10.0, 100.0
	    reroute_004_1.width, reroute_004_1.height = 10.0, 100.0
	    hair_util_bake.width, hair_util_bake.height = 140.0, 100.0
	    reroute_005_1.width, reroute_005_1.height = 10.0, 100.0
	    reroute_006_1.width, reroute_006_1.height = 10.0, 100.0
	    reroute_007.width, reroute_007.height = 10.0, 100.0
	    reroute_008.width, reroute_008.height = 10.0, 100.0
	    reroute_009.width, reroute_009.height = 10.0, 100.0
	
	    #initialize hair_util links
	    #group_input_1.Control Points -> resample_curve.Count
	    hair_util.links.new(group_input_1.outputs[2], resample_curve.inputs[2])
	    #set_curve_tilt.Curve -> set_curve_radius.Curve
	    hair_util.links.new(set_curve_tilt.outputs[0], set_curve_radius.inputs[0])
	    #curve_tangent.Tangent -> store_named_attribute.Value
	    hair_util.links.new(curve_tangent.outputs[0], store_named_attribute.inputs[3])
	    #string.String -> store_named_attribute.Name
	    hair_util.links.new(string.outputs[0], store_named_attribute.inputs[2])
	    #hair_util_bake.Geometry -> group_output_1.Geometry
	    hair_util.links.new(hair_util_bake.outputs[0], group_output_1.inputs[0])
	    #group_input_001_1.Surface -> group_001.Surface
	    hair_util.links.new(group_input_001_1.outputs[1], group_001.inputs[1])
	    #group_input_001_1.Surface Align Factor -> group_001.Surface Align Factor
	    hair_util.links.new(group_input_001_1.outputs[3], group_001.inputs[2])
	    #group_001.Geometry -> set_curve_tilt.Curve
	    hair_util.links.new(group_001.outputs[0], set_curve_tilt.inputs[0])
	    #group_001.Tilt -> set_curve_tilt.Tilt
	    hair_util.links.new(group_001.outputs[1], set_curve_tilt.inputs[2])
	    #store_named_attribute.Geometry -> group_001.Geometry
	    hair_util.links.new(store_named_attribute.outputs[0], group_001.inputs[0])
	    #group_input_002.Radius -> set_curve_radius.Radius
	    hair_util.links.new(group_input_002.outputs[4], set_curve_radius.inputs[2])
	    #set_curve_radius.Curve -> set_material.Geometry
	    hair_util.links.new(set_curve_radius.outputs[0], set_material.inputs[0])
	    #group_input_003.Material -> set_material.Material
	    hair_util.links.new(group_input_003.outputs[5], set_material.inputs[2])
	    #group_input_004.Control Points -> compare.A
	    hair_util.links.new(group_input_004.outputs[2], compare.inputs[2])
	    #compare.Result -> resample_bypass.Switch
	    hair_util.links.new(compare.outputs[0], resample_bypass.inputs[0])
	    #resample_curve.Curve -> resample_bypass.False
	    hair_util.links.new(resample_curve.outputs[0], resample_bypass.inputs[1])
	    #resample_bypass.Output -> store_named_attribute.Geometry
	    hair_util.links.new(resample_bypass.outputs[0], store_named_attribute.inputs[0])
	    #group_input_005.Geometry -> resample_bypass.True
	    hair_util.links.new(group_input_005.outputs[0], resample_bypass.inputs[2])
	    #group_input_1.Geometry -> separate_components.Geometry
	    hair_util.links.new(group_input_1.outputs[0], separate_components.inputs[0])
	    #separate_components.Curve -> resample_curve.Curve
	    hair_util.links.new(separate_components.outputs[1], resample_curve.inputs[0])
	    #reroute_005_1.Output -> join_geometry.Geometry
	    hair_util.links.new(reroute_005_1.outputs[0], join_geometry.inputs[0])
	    #separate_components.Grease Pencil -> reroute_1.Input
	    hair_util.links.new(separate_components.outputs[2], reroute_1.inputs[0])
	    #separate_components.Volume -> reroute_001_1.Input
	    hair_util.links.new(separate_components.outputs[4], reroute_001_1.inputs[0])
	    #separate_components.Mesh -> reroute_002_1.Input
	    hair_util.links.new(separate_components.outputs[0], reroute_002_1.inputs[0])
	    #separate_components.Instances -> reroute_003_1.Input
	    hair_util.links.new(separate_components.outputs[5], reroute_003_1.inputs[0])
	    #separate_components.Point Cloud -> reroute_004_1.Input
	    hair_util.links.new(separate_components.outputs[3], reroute_004_1.inputs[0])
	    #reroute_003_1.Output -> reroute_005_1.Input
	    hair_util.links.new(reroute_003_1.outputs[0], reroute_005_1.inputs[0])
	    #reroute_1.Output -> reroute_006_1.Input
	    hair_util.links.new(reroute_1.outputs[0], reroute_006_1.inputs[0])
	    #reroute_001_1.Output -> reroute_007.Input
	    hair_util.links.new(reroute_001_1.outputs[0], reroute_007.inputs[0])
	    #reroute_002_1.Output -> reroute_008.Input
	    hair_util.links.new(reroute_002_1.outputs[0], reroute_008.inputs[0])
	    #reroute_004_1.Output -> reroute_009.Input
	    hair_util.links.new(reroute_004_1.outputs[0], reroute_009.inputs[0])
	    #join_geometry.Geometry -> hair_util_bake.Geometry
	    hair_util.links.new(join_geometry.outputs[0], hair_util_bake.inputs[0])
	    #reroute_007.Output -> join_geometry.Geometry
	    hair_util.links.new(reroute_007.outputs[0], join_geometry.inputs[0])
	    #reroute_009.Output -> join_geometry.Geometry
	    hair_util.links.new(reroute_009.outputs[0], join_geometry.inputs[0])
	    #reroute_006_1.Output -> join_geometry.Geometry
	    hair_util.links.new(reroute_006_1.outputs[0], join_geometry.inputs[0])
	    #reroute_008.Output -> join_geometry.Geometry
	    hair_util.links.new(reroute_008.outputs[0], join_geometry.inputs[0])
	    #set_material.Geometry -> join_geometry.Geometry
	    hair_util.links.new(set_material.outputs[0], join_geometry.inputs[0])
	    return hair_util
	return hair_util_node_group()

	

	
