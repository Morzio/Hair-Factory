import bpy, mathutils

def node():
	#initialize physics_control node group
	def physics_control_node_group():
	    physics_control = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "PHYSICS_CONTROL")
	
	    physics_control.color_tag = 'NONE'
	    physics_control.description = "Use mesh vertices to control hair curves in physics simulations."
	    physics_control.default_group_node_width = 140
	    
	
	
	    #physics_control interface
	    #Socket Geometry
	    geometry_socket = physics_control.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket.attribute_domain = 'POINT'
	    geometry_socket.description = "Restructured curve made from mesh vertices."
	
	    #Socket Geometry
	    geometry_socket_1 = physics_control.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_1.attribute_domain = 'POINT'
	    geometry_socket_1.description = "Original hair curve."
	
	    #Socket Guide Mesh
	    guide_mesh_socket = physics_control.interface.new_socket(name = "Guide Mesh", in_out='INPUT', socket_type = 'NodeSocketObject')
	    guide_mesh_socket.attribute_domain = 'POINT'
	    guide_mesh_socket.description = "Mesh used to restructure hair curve."
	
	
	    #initialize physics_control nodes
	    #node Group Input
	    group_input = physics_control.nodes.new("NodeGroupInput")
	    group_input.name = "Group Input"
	    group_input.outputs[1].hide = True
	    group_input.outputs[2].hide = True
	
	    #node Group Output
	    group_output = physics_control.nodes.new("NodeGroupOutput")
	    group_output.name = "Group Output"
	    group_output.is_active_output = True
	    group_output.inputs[1].hide = True
	
	    #node Object Info
	    object_info = physics_control.nodes.new("GeometryNodeObjectInfo")
	    object_info.name = "Object Info"
	    object_info.hide = True
	    object_info.transform_space = 'RELATIVE'
	    object_info.inputs[1].hide = True
	    object_info.outputs[0].hide = True
	    object_info.outputs[1].hide = True
	    object_info.outputs[2].hide = True
	    object_info.outputs[3].hide = True
	    #As Instance
	    object_info.inputs[1].default_value = False
	
	    #node mesh_point_count
	    mesh_point_count = physics_control.nodes.new("GeometryNodeAttributeDomainSize")
	    mesh_point_count.label = "mesh_point_count"
	    mesh_point_count.name = "mesh_point_count"
	    mesh_point_count.hide = True
	    mesh_point_count.component = 'MESH'
	    mesh_point_count.outputs[1].hide = True
	    mesh_point_count.outputs[2].hide = True
	    mesh_point_count.outputs[3].hide = True
	    mesh_point_count.outputs[4].hide = True
	    mesh_point_count.outputs[5].hide = True
	    mesh_point_count.outputs[6].hide = True
	
	    #node hair_point_count
	    hair_point_count = physics_control.nodes.new("GeometryNodeAttributeDomainSize")
	    hair_point_count.label = "hair_point_count"
	    hair_point_count.name = "hair_point_count"
	    hair_point_count.hide = True
	    hair_point_count.component = 'CURVE'
	    hair_point_count.outputs[1].hide = True
	    hair_point_count.outputs[2].hide = True
	    hair_point_count.outputs[3].hide = True
	    hair_point_count.outputs[4].hide = True
	    hair_point_count.outputs[5].hide = True
	    hair_point_count.outputs[6].hide = True
	
	    #node modify_mesh_bypass
	    modify_mesh_bypass = physics_control.nodes.new("GeometryNodeSwitch")
	    modify_mesh_bypass.label = "modify_mesh_bypass"
	    modify_mesh_bypass.name = "modify_mesh_bypass"
	    modify_mesh_bypass.hide = True
	    modify_mesh_bypass.input_type = 'GEOMETRY'
	
	    #node mesh_has_points
	    mesh_has_points = physics_control.nodes.new("FunctionNodeCompare")
	    mesh_has_points.label = "mesh_has_points"
	    mesh_has_points.name = "mesh_has_points"
	    mesh_has_points.hide = True
	    mesh_has_points.data_type = 'INT'
	    mesh_has_points.mode = 'ELEMENT'
	    mesh_has_points.operation = 'NOT_EQUAL'
	    mesh_has_points.inputs[0].hide = True
	    mesh_has_points.inputs[1].hide = True
	    mesh_has_points.inputs[3].hide = True
	    mesh_has_points.inputs[4].hide = True
	    mesh_has_points.inputs[5].hide = True
	    mesh_has_points.inputs[6].hide = True
	    mesh_has_points.inputs[7].hide = True
	    mesh_has_points.inputs[8].hide = True
	    mesh_has_points.inputs[9].hide = True
	    mesh_has_points.inputs[10].hide = True
	    mesh_has_points.inputs[11].hide = True
	    mesh_has_points.inputs[12].hide = True
	    #B_INT
	    mesh_has_points.inputs[3].default_value = 0
	
	    #node Compare.001
	    compare_001 = physics_control.nodes.new("FunctionNodeCompare")
	    compare_001.name = "Compare.001"
	    compare_001.hide = True
	    compare_001.data_type = 'INT'
	    compare_001.mode = 'ELEMENT'
	    compare_001.operation = 'EQUAL'
	
	    #node main_bypass
	    main_bypass = physics_control.nodes.new("GeometryNodeSwitch")
	    main_bypass.label = "main_bypass"
	    main_bypass.name = "main_bypass"
	    main_bypass.hide = True
	    main_bypass.input_type = 'GEOMETRY'
	
	    #node Delete Geometry
	    delete_geometry = physics_control.nodes.new("GeometryNodeDeleteGeometry")
	    delete_geometry.name = "Delete Geometry"
	    delete_geometry.hide = True
	    delete_geometry.domain = 'POINT'
	    delete_geometry.mode = 'ALL'
	
	    #node Index
	    index = physics_control.nodes.new("GeometryNodeInputIndex")
	    index.name = "Index"
	
	    #node select_extra_points
	    select_extra_points = physics_control.nodes.new("FunctionNodeCompare")
	    select_extra_points.label = "select_extra_points"
	    select_extra_points.name = "select_extra_points"
	    select_extra_points.hide = True
	    select_extra_points.data_type = 'INT'
	    select_extra_points.mode = 'ELEMENT'
	    select_extra_points.operation = 'GREATER_EQUAL'
	
	    #node Group Input.001
	    group_input_001 = physics_control.nodes.new("NodeGroupInput")
	    group_input_001.name = "Group Input.001"
	    group_input_001.outputs[0].hide = True
	    group_input_001.outputs[2].hide = True
	
	    #node Object Info.001
	    object_info_001 = physics_control.nodes.new("GeometryNodeObjectInfo")
	    object_info_001.name = "Object Info.001"
	    object_info_001.hide = True
	    object_info_001.transform_space = 'RELATIVE'
	    object_info_001.inputs[1].hide = True
	    object_info_001.outputs[0].hide = True
	    object_info_001.outputs[1].hide = True
	    object_info_001.outputs[2].hide = True
	    object_info_001.outputs[3].hide = True
	    #As Instance
	    object_info_001.inputs[1].default_value = False
	
	    #node mesh_point_count.001
	    mesh_point_count_001 = physics_control.nodes.new("GeometryNodeAttributeDomainSize")
	    mesh_point_count_001.label = "mesh_point_count"
	    mesh_point_count_001.name = "mesh_point_count.001"
	    mesh_point_count_001.hide = True
	    mesh_point_count_001.component = 'MESH'
	    mesh_point_count_001.outputs[1].hide = True
	    mesh_point_count_001.outputs[2].hide = True
	    mesh_point_count_001.outputs[3].hide = True
	    mesh_point_count_001.outputs[4].hide = True
	    mesh_point_count_001.outputs[5].hide = True
	    mesh_point_count_001.outputs[6].hide = True
	
	    #node hair_point_count.001
	    hair_point_count_001 = physics_control.nodes.new("GeometryNodeAttributeDomainSize")
	    hair_point_count_001.label = "hair_point_count"
	    hair_point_count_001.name = "hair_point_count.001"
	    hair_point_count_001.hide = True
	    hair_point_count_001.component = 'CURVE'
	    hair_point_count_001.outputs[1].hide = True
	    hair_point_count_001.outputs[2].hide = True
	    hair_point_count_001.outputs[3].hide = True
	    hair_point_count_001.outputs[4].hide = True
	    hair_point_count_001.outputs[5].hide = True
	    hair_point_count_001.outputs[6].hide = True
	
	    #node unmodified_mesh_bypass.001
	    unmodified_mesh_bypass_001 = physics_control.nodes.new("GeometryNodeSwitch")
	    unmodified_mesh_bypass_001.label = "unmodified_mesh_bypass"
	    unmodified_mesh_bypass_001.name = "unmodified_mesh_bypass.001"
	    unmodified_mesh_bypass_001.input_type = 'GEOMETRY'
	
	    #node modified_mesh_bypass.001
	    modified_mesh_bypass_001 = physics_control.nodes.new("GeometryNodeSwitch")
	    modified_mesh_bypass_001.label = "modified_mesh_bypass"
	    modified_mesh_bypass_001.name = "modified_mesh_bypass.001"
	    modified_mesh_bypass_001.input_type = 'GEOMETRY'
	
	    #node mesh_has_points.001
	    mesh_has_points_001 = physics_control.nodes.new("FunctionNodeCompare")
	    mesh_has_points_001.label = "mesh_has_points"
	    mesh_has_points_001.name = "mesh_has_points.001"
	    mesh_has_points_001.hide = True
	    mesh_has_points_001.data_type = 'INT'
	    mesh_has_points_001.mode = 'ELEMENT'
	    mesh_has_points_001.operation = 'NOT_EQUAL'
	    mesh_has_points_001.inputs[0].hide = True
	    mesh_has_points_001.inputs[1].hide = True
	    mesh_has_points_001.inputs[3].hide = True
	    mesh_has_points_001.inputs[4].hide = True
	    mesh_has_points_001.inputs[5].hide = True
	    mesh_has_points_001.inputs[6].hide = True
	    mesh_has_points_001.inputs[7].hide = True
	    mesh_has_points_001.inputs[8].hide = True
	    mesh_has_points_001.inputs[9].hide = True
	    mesh_has_points_001.inputs[10].hide = True
	    mesh_has_points_001.inputs[11].hide = True
	    mesh_has_points_001.inputs[12].hide = True
	    #B_INT
	    mesh_has_points_001.inputs[3].default_value = 0
	
	    #node Compare.002
	    compare_002 = physics_control.nodes.new("FunctionNodeCompare")
	    compare_002.name = "Compare.002"
	    compare_002.hide = True
	    compare_002.data_type = 'INT'
	    compare_002.mode = 'ELEMENT'
	    compare_002.operation = 'EQUAL'
	
	    #node Boolean Math.001
	    boolean_math_001 = physics_control.nodes.new("FunctionNodeBooleanMath")
	    boolean_math_001.name = "Boolean Math.001"
	    boolean_math_001.operation = 'AND'
	
	    #node Switch.003
	    switch_003 = physics_control.nodes.new("GeometryNodeSwitch")
	    switch_003.name = "Switch.003"
	    switch_003.input_type = 'GEOMETRY'
	
	    #node point_inequality.001
	    point_inequality_001 = physics_control.nodes.new("FunctionNodeCompare")
	    point_inequality_001.label = "point_inequality"
	    point_inequality_001.name = "point_inequality.001"
	    point_inequality_001.data_type = 'INT'
	    point_inequality_001.mode = 'ELEMENT'
	    point_inequality_001.operation = 'NOT_EQUAL'
	
	    #node Delete Geometry.001
	    delete_geometry_001 = physics_control.nodes.new("GeometryNodeDeleteGeometry")
	    delete_geometry_001.name = "Delete Geometry.001"
	    delete_geometry_001.domain = 'POINT'
	    delete_geometry_001.mode = 'ALL'
	
	    #node Index.001
	    index_001 = physics_control.nodes.new("GeometryNodeInputIndex")
	    index_001.name = "Index.001"
	
	    #node select_extra_points.001
	    select_extra_points_001 = physics_control.nodes.new("FunctionNodeCompare")
	    select_extra_points_001.label = "select_extra_points"
	    select_extra_points_001.name = "select_extra_points.001"
	    select_extra_points_001.hide = True
	    select_extra_points_001.data_type = 'INT'
	    select_extra_points_001.mode = 'ELEMENT'
	    select_extra_points_001.operation = 'GREATER_EQUAL'
	
	    #node Reroute
	    reroute = physics_control.nodes.new("NodeReroute")
	    reroute.name = "Reroute"
	    reroute.socket_idname = "NodeSocketInt"
	    #node Reroute.001
	    reroute_001 = physics_control.nodes.new("NodeReroute")
	    reroute_001.name = "Reroute.001"
	    reroute_001.socket_idname = "NodeSocketInt"
	    #node Reroute.002
	    reroute_002 = physics_control.nodes.new("NodeReroute")
	    reroute_002.name = "Reroute.002"
	    reroute_002.socket_idname = "NodeSocketInt"
	    #node Reroute.003
	    reroute_003 = physics_control.nodes.new("NodeReroute")
	    reroute_003.name = "Reroute.003"
	    reroute_003.socket_idname = "NodeSocketInt"
	    #node Reroute.004
	    reroute_004 = physics_control.nodes.new("NodeReroute")
	    reroute_004.name = "Reroute.004"
	    reroute_004.socket_idname = "NodeSocketInt"
	    #node Reroute.005
	    reroute_005 = physics_control.nodes.new("NodeReroute")
	    reroute_005.name = "Reroute.005"
	    reroute_005.socket_idname = "NodeSocketInt"
	    #node Mesh to Curve
	    mesh_to_curve = physics_control.nodes.new("GeometryNodeMeshToCurve")
	    mesh_to_curve.name = "Mesh to Curve"
	    mesh_to_curve.hide = True
	    mesh_to_curve.inputs[1].hide = True
	    #Selection
	    mesh_to_curve.inputs[1].default_value = True
	
	
	
	
	
	    #Set locations
	    group_input.location = (-340.0, 0.0)
	    group_output.location = (556.557861328125, -6.81937313079834)
	    object_info.location = (-340.0, -280.0)
	    mesh_point_count.location = (-340.0, -340.0)
	    hair_point_count.location = (-335.9224853515625, 35.70637130737305)
	    modify_mesh_bypass.location = (222.81610107421875, -263.65447998046875)
	    mesh_has_points.location = (222.81610107421875, 7.7356109619140625)
	    compare_001.location = (30.05615234375, -79.06280517578125)
	    main_bypass.location = (376.0885009765625, -32.274871826171875)
	    delete_geometry.location = (30.05615234375, -248.2251739501953)
	    index.location = (30.05615234375, -148.2251739501953)
	    select_extra_points.location = (30.05615234375, -208.2251739501953)
	    group_input_001.location = (-340.0, -220.0)
	    object_info_001.location = (-335.60980224609375, 1826.9140625)
	    mesh_point_count_001.location = (-334.92620849609375, 1784.0362548828125)
	    hair_point_count_001.location = (-335.9224853515625, 2035.7064208984375)
	    unmodified_mesh_bypass_001.location = (402.7187194824219, 1886.233154296875)
	    modified_mesh_bypass_001.location = (1061.5872802734375, 2001.1416015625)
	    mesh_has_points_001.location = (47.159767150878906, 1748.91357421875)
	    compare_002.location = (62.54315185546875, 2237.32421875)
	    boolean_math_001.location = (259.784423828125, 2333.7568359375)
	    switch_003.location = (752.87109375, 1823.52587890625)
	    point_inequality_001.location = (38.394935607910156, 2110.60693359375)
	    delete_geometry_001.location = (742.7001953125, 2305.972412109375)
	    index_001.location = (177.88748168945312, 2615.57177734375)
	    select_extra_points_001.location = (178.33990478515625, 2555.23486328125)
	    reroute.location = (-144.27920532226562, 24.74791717529297)
	    reroute_001.location = (27.2850341796875, 25.62052345275879)
	    reroute_002.location = (-142.46005249023438, -224.1357879638672)
	    reroute_003.location = (-96.66082000732422, -349.5581970214844)
	    reroute_004.location = (-98.22047424316406, -97.74567413330078)
	    reroute_005.location = (-99.53742218017578, 0.36084556579589844)
	    mesh_to_curve.location = (244.0694580078125, -225.73092651367188)
	
	    #Set dimensions
	    group_input.width, group_input.height = 140.0, 100.0
	    group_output.width, group_output.height = 140.0, 100.0
	    object_info.width, object_info.height = 140.0, 100.0
	    mesh_point_count.width, mesh_point_count.height = 140.0, 100.0
	    hair_point_count.width, hair_point_count.height = 140.0, 100.0
	    modify_mesh_bypass.width, modify_mesh_bypass.height = 160.0, 100.0
	    mesh_has_points.width, mesh_has_points.height = 140.0, 100.0
	    compare_001.width, compare_001.height = 140.0, 100.0
	    main_bypass.width, main_bypass.height = 140.0, 100.0
	    delete_geometry.width, delete_geometry.height = 140.0, 100.0
	    index.width, index.height = 140.0, 100.0
	    select_extra_points.width, select_extra_points.height = 140.0, 100.0
	    group_input_001.width, group_input_001.height = 140.0, 100.0
	    object_info_001.width, object_info_001.height = 140.0, 100.0
	    mesh_point_count_001.width, mesh_point_count_001.height = 140.0, 100.0
	    hair_point_count_001.width, hair_point_count_001.height = 140.0, 100.0
	    unmodified_mesh_bypass_001.width, unmodified_mesh_bypass_001.height = 140.0, 100.0
	    modified_mesh_bypass_001.width, modified_mesh_bypass_001.height = 140.0, 100.0
	    mesh_has_points_001.width, mesh_has_points_001.height = 140.0, 100.0
	    compare_002.width, compare_002.height = 140.0, 100.0
	    boolean_math_001.width, boolean_math_001.height = 140.0, 100.0
	    switch_003.width, switch_003.height = 140.0, 100.0
	    point_inequality_001.width, point_inequality_001.height = 140.0, 100.0
	    delete_geometry_001.width, delete_geometry_001.height = 140.0, 100.0
	    index_001.width, index_001.height = 140.0, 100.0
	    select_extra_points_001.width, select_extra_points_001.height = 140.0, 100.0
	    reroute.width, reroute.height = 10.0, 100.0
	    reroute_001.width, reroute_001.height = 10.0, 100.0
	    reroute_002.width, reroute_002.height = 10.0, 100.0
	    reroute_003.width, reroute_003.height = 10.0, 100.0
	    reroute_004.width, reroute_004.height = 10.0, 100.0
	    reroute_005.width, reroute_005.height = 10.0, 100.0
	    mesh_to_curve.width, mesh_to_curve.height = 140.0, 100.0
	
	    #initialize physics_control links
	    #group_input.Geometry -> hair_point_count.Geometry
	    physics_control.links.new(group_input.outputs[0], hair_point_count.inputs[0])
	    #object_info.Geometry -> mesh_point_count.Geometry
	    physics_control.links.new(object_info.outputs[4], mesh_point_count.inputs[0])
	    #object_info.Geometry -> modify_mesh_bypass.True
	    physics_control.links.new(object_info.outputs[4], modify_mesh_bypass.inputs[2])
	    #reroute_001.Output -> compare_001.A
	    physics_control.links.new(reroute_001.outputs[0], compare_001.inputs[2])
	    #reroute_004.Output -> compare_001.B
	    physics_control.links.new(reroute_004.outputs[0], compare_001.inputs[3])
	    #index.Index -> select_extra_points.A
	    physics_control.links.new(index.outputs[0], select_extra_points.inputs[2])
	    #reroute_002.Output -> select_extra_points.B
	    physics_control.links.new(reroute_002.outputs[0], select_extra_points.inputs[3])
	    #select_extra_points.Result -> delete_geometry.Selection
	    physics_control.links.new(select_extra_points.outputs[0], delete_geometry.inputs[1])
	    #group_input_001.Guide Mesh -> object_info.Object
	    physics_control.links.new(group_input_001.outputs[1], object_info.inputs[0])
	    #object_info_001.Geometry -> mesh_point_count_001.Geometry
	    physics_control.links.new(object_info_001.outputs[4], mesh_point_count_001.inputs[0])
	    #mesh_point_count_001.Point Count -> mesh_has_points_001.A
	    physics_control.links.new(mesh_point_count_001.outputs[0], mesh_has_points_001.inputs[2])
	    #mesh_has_points_001.Result -> unmodified_mesh_bypass_001.Switch
	    physics_control.links.new(mesh_has_points_001.outputs[0], unmodified_mesh_bypass_001.inputs[0])
	    #object_info_001.Geometry -> unmodified_mesh_bypass_001.True
	    physics_control.links.new(object_info_001.outputs[4], unmodified_mesh_bypass_001.inputs[2])
	    #hair_point_count_001.Point Count -> compare_002.A
	    physics_control.links.new(hair_point_count_001.outputs[0], compare_002.inputs[2])
	    #mesh_point_count_001.Point Count -> compare_002.B
	    physics_control.links.new(mesh_point_count_001.outputs[0], compare_002.inputs[3])
	    #compare_002.Result -> boolean_math_001.Boolean
	    physics_control.links.new(compare_002.outputs[0], boolean_math_001.inputs[0])
	    #mesh_has_points_001.Result -> boolean_math_001.Boolean
	    physics_control.links.new(mesh_has_points_001.outputs[0], boolean_math_001.inputs[1])
	    #boolean_math_001.Boolean -> switch_003.Switch
	    physics_control.links.new(boolean_math_001.outputs[0], switch_003.inputs[0])
	    #object_info_001.Geometry -> switch_003.True
	    physics_control.links.new(object_info_001.outputs[4], switch_003.inputs[2])
	    #unmodified_mesh_bypass_001.Output -> switch_003.False
	    physics_control.links.new(unmodified_mesh_bypass_001.outputs[0], switch_003.inputs[1])
	    #hair_point_count_001.Point Count -> point_inequality_001.A
	    physics_control.links.new(hair_point_count_001.outputs[0], point_inequality_001.inputs[2])
	    #mesh_point_count_001.Point Count -> point_inequality_001.B
	    physics_control.links.new(mesh_point_count_001.outputs[0], point_inequality_001.inputs[3])
	    #unmodified_mesh_bypass_001.Output -> delete_geometry_001.Geometry
	    physics_control.links.new(unmodified_mesh_bypass_001.outputs[0], delete_geometry_001.inputs[0])
	    #index_001.Index -> select_extra_points_001.A
	    physics_control.links.new(index_001.outputs[0], select_extra_points_001.inputs[2])
	    #hair_point_count_001.Point Count -> select_extra_points_001.B
	    physics_control.links.new(hair_point_count_001.outputs[0], select_extra_points_001.inputs[3])
	    #select_extra_points_001.Result -> delete_geometry_001.Selection
	    physics_control.links.new(select_extra_points_001.outputs[0], delete_geometry_001.inputs[1])
	    #point_inequality_001.Result -> modified_mesh_bypass_001.Switch
	    physics_control.links.new(point_inequality_001.outputs[0], modified_mesh_bypass_001.inputs[0])
	    #delete_geometry_001.Geometry -> modified_mesh_bypass_001.True
	    physics_control.links.new(delete_geometry_001.outputs[0], modified_mesh_bypass_001.inputs[2])
	    #switch_003.Output -> modified_mesh_bypass_001.False
	    physics_control.links.new(switch_003.outputs[0], modified_mesh_bypass_001.inputs[1])
	    #compare_001.Result -> modify_mesh_bypass.Switch
	    physics_control.links.new(compare_001.outputs[0], modify_mesh_bypass.inputs[0])
	    #delete_geometry.Geometry -> modify_mesh_bypass.False
	    physics_control.links.new(delete_geometry.outputs[0], modify_mesh_bypass.inputs[1])
	    #object_info.Geometry -> delete_geometry.Geometry
	    physics_control.links.new(object_info.outputs[4], delete_geometry.inputs[0])
	    #mesh_has_points.Result -> main_bypass.Switch
	    physics_control.links.new(mesh_has_points.outputs[0], main_bypass.inputs[0])
	    #mesh_to_curve.Curve -> main_bypass.True
	    physics_control.links.new(mesh_to_curve.outputs[0], main_bypass.inputs[2])
	    #group_input.Geometry -> main_bypass.False
	    physics_control.links.new(group_input.outputs[0], main_bypass.inputs[1])
	    #hair_point_count.Point Count -> reroute.Input
	    physics_control.links.new(hair_point_count.outputs[0], reroute.inputs[0])
	    #reroute.Output -> reroute_001.Input
	    physics_control.links.new(reroute.outputs[0], reroute_001.inputs[0])
	    #reroute.Output -> reroute_002.Input
	    physics_control.links.new(reroute.outputs[0], reroute_002.inputs[0])
	    #mesh_point_count.Point Count -> reroute_003.Input
	    physics_control.links.new(mesh_point_count.outputs[0], reroute_003.inputs[0])
	    #reroute_003.Output -> reroute_004.Input
	    physics_control.links.new(reroute_003.outputs[0], reroute_004.inputs[0])
	    #reroute_005.Output -> mesh_has_points.A
	    physics_control.links.new(reroute_005.outputs[0], mesh_has_points.inputs[2])
	    #reroute_004.Output -> reroute_005.Input
	    physics_control.links.new(reroute_004.outputs[0], reroute_005.inputs[0])
	    #main_bypass.Output -> group_output.Geometry
	    physics_control.links.new(main_bypass.outputs[0], group_output.inputs[0])
	    #modify_mesh_bypass.Output -> mesh_to_curve.Mesh
	    physics_control.links.new(modify_mesh_bypass.outputs[0], mesh_to_curve.inputs[0])
	    return physics_control
	return physics_control_node_group()

	

	
