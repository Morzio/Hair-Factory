import bpy, mathutils

def node():
	#initialize duplicate_object node group
	def duplicate_object_node_group():
	    duplicate_object = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "DUPLICATE_OBJECT")
	
	    duplicate_object.color_tag = 'NONE'
	    duplicate_object.description = "Duplicate object data. (Object must be the same data type)"
	    duplicate_object.default_group_node_width = 140
	    
	
	    duplicate_object.is_modifier = True
	
	    #duplicate_object interface
	    #Socket Geometry
	    geometry_socket = duplicate_object.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket.attribute_domain = 'POINT'
	
	    #Socket Object
	    object_socket = duplicate_object.interface.new_socket(name = "Object", in_out='INPUT', socket_type = 'NodeSocketObject')
	    object_socket.attribute_domain = 'POINT'
	    object_socket.description = "Source object to duplicate. "
	
	
	    #initialize duplicate_object nodes
	    #node Group Input
	    group_input = duplicate_object.nodes.new("NodeGroupInput")
	    group_input.name = "Group Input"
	    group_input.outputs[1].hide = True
	
	    #node Group Output
	    group_output = duplicate_object.nodes.new("NodeGroupOutput")
	    group_output.name = "Group Output"
	    group_output.is_active_output = True
	    group_output.inputs[1].hide = True
	
	    #node Object Info
	    object_info = duplicate_object.nodes.new("GeometryNodeObjectInfo")
	    object_info.name = "Object Info"
	    object_info.hide = True
	    object_info.transform_space = 'RELATIVE'
	    object_info.inputs[1].hide = True
	    object_info.outputs[0].hide = True
	    object_info.outputs[1].hide = True
	    object_info.outputs[2].hide = True
	    object_info.outputs[3].hide = True
	    #As Instance
	    object_info.inputs[1].default_value = False
	
	
	
	
	
	    #Set locations
	    group_input.location = (-340.0, 0.0)
	    group_output.location = (6.4981231689453125, 1.2331843376159668)
	    object_info.location = (-169.2623291015625, -23.789337158203125)
	
	    #Set dimensions
	    group_input.width, group_input.height = 140.0, 100.0
	    group_output.width, group_output.height = 140.0, 100.0
	    object_info.width, object_info.height = 140.0, 100.0
	
	    #initialize duplicate_object links
	    #group_input.Object -> object_info.Object
	    duplicate_object.links.new(group_input.outputs[0], object_info.inputs[0])
	    #object_info.Geometry -> group_output.Geometry
	    duplicate_object.links.new(object_info.outputs[4], group_output.inputs[0])
	    return duplicate_object
	return duplicate_object_node_group()

	

	
