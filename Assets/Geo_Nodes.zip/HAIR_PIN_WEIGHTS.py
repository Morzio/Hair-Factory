import bpy, mathutils

def node():
	#initialize hair_pin_weights node group
	def hair_pin_weights_node_group():
	    hair_pin_weights = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "HAIR_PIN_WEIGHTS")
	
	    hair_pin_weights.color_tag = 'NONE'
	    hair_pin_weights.description = "Control Pin weights for Cloth Physics PHY_MESH."
	    hair_pin_weights.default_group_node_width = 140
	    
	
	    hair_pin_weights.is_modifier = True
	
	    #hair_pin_weights interface
	    #Socket Geometry
	    geometry_socket = hair_pin_weights.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket.attribute_domain = 'POINT'
	
	    #Socket Geometry
	    geometry_socket_1 = hair_pin_weights.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
	    geometry_socket_1.attribute_domain = 'POINT'
	
	
	    #initialize hair_pin_weights nodes
	    #node Group Input
	    group_input = hair_pin_weights.nodes.new("NodeGroupInput")
	    group_input.name = "Group Input"
	    group_input.outputs[1].hide = True
	
	    #node Group Output
	    group_output = hair_pin_weights.nodes.new("NodeGroupOutput")
	    group_output.name = "Group Output"
	    group_output.is_active_output = True
	    group_output.inputs[1].hide = True
	
	    #node Pin Weights
	    pin_weights = hair_pin_weights.nodes.new("ShaderNodeFloatCurve")
	    pin_weights.label = "Pin Weights"
	    pin_weights.name = "Pin Weights"
	    #mapping settings
	    pin_weights.mapping.extend = 'EXTRAPOLATED'
	    pin_weights.mapping.tone = 'STANDARD'
	    pin_weights.mapping.black_level = (0.0, 0.0, 0.0)
	    pin_weights.mapping.white_level = (1.0, 1.0, 1.0)
	    pin_weights.mapping.clip_min_x = 0.0
	    pin_weights.mapping.clip_min_y = 0.0
	    pin_weights.mapping.clip_max_x = 1.0
	    pin_weights.mapping.clip_max_y = 1.0
	    pin_weights.mapping.use_clip = True
	    #curve 0
	    pin_weights_curve_0 = pin_weights.mapping.curves[0]
	    pin_weights_curve_0_point_0 = pin_weights_curve_0.points[0]
	    pin_weights_curve_0_point_0.location = (0.0, 1.0)
	    pin_weights_curve_0_point_0.handle_type = 'AUTO'
	    pin_weights_curve_0_point_1 = pin_weights_curve_0.points[1]
	    pin_weights_curve_0_point_1.location = (1.0, 0.0)
	    pin_weights_curve_0_point_1.handle_type = 'AUTO'
	    #update curve after changes
	    pin_weights.mapping.update()
	    pin_weights.inputs[0].hide = True
	    #Factor
	    pin_weights.inputs[0].default_value = 1.0
	
	    #node Store Named Attribute
	    store_named_attribute = hair_pin_weights.nodes.new("GeometryNodeStoreNamedAttribute")
	    store_named_attribute.name = "Store Named Attribute"
	    store_named_attribute.data_type = 'FLOAT'
	    store_named_attribute.domain = 'POINT'
	    #Selection
	    store_named_attribute.inputs[1].default_value = True
	    #Name
	    store_named_attribute.inputs[2].default_value = "Pin"
	
	    #node Named Attribute
	    named_attribute = hair_pin_weights.nodes.new("GeometryNodeInputNamedAttribute")
	    named_attribute.name = "Named Attribute"
	    named_attribute.data_type = 'FLOAT'
	    #Name
	    named_attribute.inputs[0].default_value = "Pin_Factor"
	
	
	
	
	
	    #Set locations
	    group_input.location = (323.1495361328125, 0.0)
	    group_output.location = (668.084228515625, 75.19145202636719)
	    pin_weights.location = (222.9617919921875, -65.39970397949219)
	    store_named_attribute.location = (500.96636962890625, 74.51570129394531)
	    named_attribute.location = (50.732383728027344, -305.1344909667969)
	
	    #Set dimensions
	    group_input.width, group_input.height = 140.0, 100.0
	    group_output.width, group_output.height = 140.0, 100.0
	    pin_weights.width, pin_weights.height = 240.0, 100.0
	    store_named_attribute.width, store_named_attribute.height = 140.0, 100.0
	    named_attribute.width, named_attribute.height = 140.0, 100.0
	
	    #initialize hair_pin_weights links
	    #store_named_attribute.Geometry -> group_output.Geometry
	    hair_pin_weights.links.new(store_named_attribute.outputs[0], group_output.inputs[0])
	    #group_input.Geometry -> store_named_attribute.Geometry
	    hair_pin_weights.links.new(group_input.outputs[0], store_named_attribute.inputs[0])
	    #named_attribute.Attribute -> pin_weights.Value
	    hair_pin_weights.links.new(named_attribute.outputs[0], pin_weights.inputs[1])
	    #pin_weights.Value -> store_named_attribute.Value
	    hair_pin_weights.links.new(pin_weights.outputs[0], store_named_attribute.inputs[3])
	    return hair_pin_weights
	return hair_pin_weights_node_group()

	

	
