import bpy, mathutils



def node(mat):
	#initialize MESH_EEVEE_TOON_V2 node group
	def mesh_eevee_toon_v2_node_group():
	
	    mesh_eevee_toon_v2 = bpy.data.node_groups.new(type = 'ShaderNodeTree', name = "MESH_EEVEE_TOON_V2")
	
	    mesh_eevee_toon_v2.color_tag = 'NONE'
	    mesh_eevee_toon_v2.description = "Toon shader with hatch pattern."
	    mesh_eevee_toon_v2.default_group_node_width = 140
	    
	
	    #mesh_eevee_toon_v2 interface
	    #Socket Color
	    color_socket = mesh_eevee_toon_v2.interface.new_socket(name = "Color", in_out='OUTPUT', socket_type = 'NodeSocketColor')
	    color_socket.default_value = (0.800000011920929, 0.800000011920929, 0.800000011920929, 1.0)
	    color_socket.attribute_domain = 'POINT'
	    color_socket.description = "Final color."
	
	    #Socket Hatch Rotation
	    hatch_rotation_socket = mesh_eevee_toon_v2.interface.new_socket(name = "Hatch Rotation", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    hatch_rotation_socket.default_value = 0.0
	    hatch_rotation_socket.min_value = -10000.0
	    hatch_rotation_socket.max_value = 10000.0
	    hatch_rotation_socket.subtype = 'NONE'
	    hatch_rotation_socket.attribute_domain = 'POINT'
	    hatch_rotation_socket.description = "Rotatate the hatch pattern."
	
	    #Socket Light Depth
	    light_depth_socket = mesh_eevee_toon_v2.interface.new_socket(name = "Light Depth", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    light_depth_socket.default_value = 1.0
	    light_depth_socket.min_value = -10000.0
	    light_depth_socket.max_value = 10000.0
	    light_depth_socket.subtype = 'NONE'
	    light_depth_socket.attribute_domain = 'POINT'
	    light_depth_socket.description = "Control the depth of light passed to color."
	
	    #Socket Shadow Depth
	    shadow_depth_socket = mesh_eevee_toon_v2.interface.new_socket(name = "Shadow Depth", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    shadow_depth_socket.default_value = 0.30000001192092896
	    shadow_depth_socket.min_value = -10000.0
	    shadow_depth_socket.max_value = 10000.0
	    shadow_depth_socket.subtype = 'NONE'
	    shadow_depth_socket.attribute_domain = 'POINT'
	    shadow_depth_socket.description = "Control the depth of shadow passed to color."
	
	    #Socket Mix Factor
	    mix_factor_socket = mesh_eevee_toon_v2.interface.new_socket(name = "Mix Factor", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    mix_factor_socket.default_value = 0.5
	    mix_factor_socket.min_value = 0.0
	    mix_factor_socket.max_value = 1.0
	    mix_factor_socket.subtype = 'FACTOR'
	    mix_factor_socket.attribute_domain = 'POINT'
	    mix_factor_socket.description = "Mix color from flat to hatch."
	
	    #Socket Hatch Scale
	    hatch_scale_socket = mesh_eevee_toon_v2.interface.new_socket(name = "Hatch Scale", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    hatch_scale_socket.default_value = 35.0
	    hatch_scale_socket.min_value = -1000.0
	    hatch_scale_socket.max_value = 1000.0
	    hatch_scale_socket.subtype = 'NONE'
	    hatch_scale_socket.attribute_domain = 'POINT'
	    hatch_scale_socket.description = "Control hatch size."
	
	    #Socket Hatch Detail
	    hatch_detail_socket = mesh_eevee_toon_v2.interface.new_socket(name = "Hatch Detail", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    hatch_detail_socket.default_value = 0.0
	    hatch_detail_socket.min_value = 0.0
	    hatch_detail_socket.max_value = 15.0
	    hatch_detail_socket.subtype = 'NONE'
	    hatch_detail_socket.attribute_domain = 'POINT'
	    hatch_detail_socket.description = "Control the detail of the hatch pattern."
	
	    #Socket Hatch Randomness
	    hatch_randomness_socket = mesh_eevee_toon_v2.interface.new_socket(name = "Hatch Randomness", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    hatch_randomness_socket.default_value = 0.0
	    hatch_randomness_socket.min_value = 0.0
	    hatch_randomness_socket.max_value = 1.0
	    hatch_randomness_socket.subtype = 'FACTOR'
	    hatch_randomness_socket.attribute_domain = 'POINT'
	    hatch_randomness_socket.description = "Control the randomness of the hatch pattern."
	
	
	    #initialize mesh_eevee_toon_v2 nodes
	    #node Group Output
	    group_output = mesh_eevee_toon_v2.nodes.new("NodeGroupOutput")
	    group_output.name = "Group Output"
	    group_output.is_active_output = True
	
	    #node Group Input
	    group_input = mesh_eevee_toon_v2.nodes.new("NodeGroupInput")
	    group_input.name = "Group Input"
	    group_input.outputs[0].hide = True
	    group_input.outputs[3].hide = True
	    group_input.outputs[4].hide = True
	    group_input.outputs[5].hide = True
	    group_input.outputs[6].hide = True
	    group_input.outputs[7].hide = True
	
	    #node Principled BSDF
	    principled_bsdf = mesh_eevee_toon_v2.nodes.new("ShaderNodeBsdfPrincipled")
	    principled_bsdf.name = "Principled BSDF"
	    principled_bsdf.distribution = 'MULTI_GGX'
	    principled_bsdf.subsurface_method = 'RANDOM_WALK'
	    principled_bsdf.inputs[0].hide = True
	    principled_bsdf.inputs[1].hide = True
	    principled_bsdf.inputs[2].hide = True
	    principled_bsdf.inputs[3].hide = True
	    principled_bsdf.inputs[4].hide = True
	    principled_bsdf.inputs[5].hide = True
	    principled_bsdf.inputs[6].hide = True
	    principled_bsdf.inputs[7].hide = True
	    principled_bsdf.inputs[8].hide = True
	    principled_bsdf.inputs[9].hide = True
	    principled_bsdf.inputs[10].hide = True
	    principled_bsdf.inputs[11].hide = True
	    principled_bsdf.inputs[12].hide = True
	    principled_bsdf.inputs[13].hide = True
	    principled_bsdf.inputs[14].hide = True
	    principled_bsdf.inputs[15].hide = True
	    principled_bsdf.inputs[16].hide = True
	    principled_bsdf.inputs[17].hide = True
	    principled_bsdf.inputs[18].hide = True
	    principled_bsdf.inputs[19].hide = True
	    principled_bsdf.inputs[20].hide = True
	    principled_bsdf.inputs[21].hide = True
	    principled_bsdf.inputs[22].hide = True
	    principled_bsdf.inputs[23].hide = True
	    principled_bsdf.inputs[24].hide = True
	    principled_bsdf.inputs[25].hide = True
	    principled_bsdf.inputs[26].hide = True
	    principled_bsdf.inputs[27].hide = True
	    principled_bsdf.inputs[28].hide = True
	    principled_bsdf.inputs[29].hide = True
	    principled_bsdf.inputs[30].hide = True
	    #Base Color
	    principled_bsdf.inputs[0].default_value = (0.800000011920929, 0.800000011920929, 0.800000011920929, 1.0)
	    #Metallic
	    principled_bsdf.inputs[1].default_value = 0.0
	    #Roughness
	    principled_bsdf.inputs[2].default_value = 0.5
	    #IOR
	    principled_bsdf.inputs[3].default_value = 1.5
	    #Alpha
	    principled_bsdf.inputs[4].default_value = 1.0
	    #Normal
	    principled_bsdf.inputs[5].default_value = (0.0, 0.0, 0.0)
	    #Diffuse Roughness
	    principled_bsdf.inputs[7].default_value = 0.0
	    #Subsurface Weight
	    principled_bsdf.inputs[8].default_value = 0.0
	    #Subsurface Radius
	    principled_bsdf.inputs[9].default_value = (1.0, 0.20000000298023224, 0.10000000149011612)
	    #Subsurface Scale
	    principled_bsdf.inputs[10].default_value = 0.05000000074505806
	    #Subsurface Anisotropy
	    principled_bsdf.inputs[12].default_value = 0.0
	    #Specular IOR Level
	    principled_bsdf.inputs[13].default_value = 0.5
	    #Specular Tint
	    principled_bsdf.inputs[14].default_value = (1.0, 1.0, 1.0, 1.0)
	    #Anisotropic
	    principled_bsdf.inputs[15].default_value = 0.0
	    #Anisotropic Rotation
	    principled_bsdf.inputs[16].default_value = 0.0
	    #Tangent
	    principled_bsdf.inputs[17].default_value = (0.0, 0.0, 0.0)
	    #Transmission Weight
	    principled_bsdf.inputs[18].default_value = 0.0
	    #Coat Weight
	    principled_bsdf.inputs[19].default_value = 0.0
	    #Coat Roughness
	    principled_bsdf.inputs[20].default_value = 0.029999999329447746
	    #Coat IOR
	    principled_bsdf.inputs[21].default_value = 1.5
	    #Coat Tint
	    principled_bsdf.inputs[22].default_value = (1.0, 1.0, 1.0, 1.0)
	    #Coat Normal
	    principled_bsdf.inputs[23].default_value = (0.0, 0.0, 0.0)
	    #Sheen Weight
	    principled_bsdf.inputs[24].default_value = 0.0
	    #Sheen Roughness
	    principled_bsdf.inputs[25].default_value = 0.5
	    #Sheen Tint
	    principled_bsdf.inputs[26].default_value = (1.0, 1.0, 1.0, 1.0)
	    #Emission Color
	    principled_bsdf.inputs[27].default_value = (1.0, 1.0, 1.0, 1.0)
	    #Emission Strength
	    principled_bsdf.inputs[28].default_value = 0.0
	    #Thin Film Thickness
	    principled_bsdf.inputs[29].default_value = 0.0
	    #Thin Film IOR
	    principled_bsdf.inputs[30].default_value = 1.3300000429153442
	
	    #node Shader to RGB
	    shader_to_rgb = mesh_eevee_toon_v2.nodes.new("ShaderNodeShaderToRGB")
	    shader_to_rgb.name = "Shader to RGB"
	
	    #node Toon Color
	    toon_color = mesh_eevee_toon_v2.nodes.new("ShaderNodeValToRGB")
	    toon_color.label = "Toon Color"
	    toon_color.name = "Toon Color"
	    toon_color.color_ramp.color_mode = 'RGB'
	    toon_color.color_ramp.hue_interpolation = 'NEAR'
	    toon_color.color_ramp.interpolation = 'CONSTANT'
	
	    #initialize color ramp elements
	    toon_color.color_ramp.elements.remove(toon_color.color_ramp.elements[0])
	    toon_color_cre_0 = toon_color.color_ramp.elements[0]
	    toon_color_cre_0.position = 0.0
	    toon_color_cre_0.alpha = 1.0
	    toon_color_cre_0.color = (0.002485837321728468, 0.0, 1.0, 1.0)
	
	    toon_color_cre_1 = toon_color.color_ramp.elements.new(0.5477274656295776)
	    toon_color_cre_1.alpha = 1.0
	    toon_color_cre_1.color = (0.0, 1.0, 0.8697147965431213, 1.0)
	
	    toon_color_cre_2 = toon_color.color_ramp.elements.new(0.9636363983154297)
	    toon_color_cre_2.alpha = 1.0
	    toon_color_cre_2.color = (1.0, 1.0, 1.0, 1.0)
	
	
	    #node Voronoi Texture
	    voronoi_texture = mesh_eevee_toon_v2.nodes.new("ShaderNodeTexVoronoi")
	    voronoi_texture.name = "Voronoi Texture"
	    voronoi_texture.distance = 'EUCLIDEAN'
	    voronoi_texture.feature = 'F1'
	    voronoi_texture.normalize = False
	    voronoi_texture.voronoi_dimensions = '2D'
	    voronoi_texture.inputs[1].hide = True
	    voronoi_texture.inputs[4].hide = True
	    voronoi_texture.inputs[5].hide = True
	    voronoi_texture.inputs[6].hide = True
	    voronoi_texture.inputs[7].hide = True
	    voronoi_texture.outputs[1].hide = True
	    voronoi_texture.outputs[2].hide = True
	    voronoi_texture.outputs[3].hide = True
	    voronoi_texture.outputs[4].hide = True
	    #Roughness
	    voronoi_texture.inputs[4].default_value = 0.5
	    #Lacunarity
	    voronoi_texture.inputs[5].default_value = 2.0
	
	    #node Math
	    math = mesh_eevee_toon_v2.nodes.new("ShaderNodeMath")
	    math.name = "Math"
	    math.operation = 'GREATER_THAN'
	    math.use_clamp = False
	
	    #node Mix
	    mix = mesh_eevee_toon_v2.nodes.new("ShaderNodeMix")
	    mix.name = "Mix"
	    mix.blend_type = 'MIX'
	    mix.clamp_factor = True
	    mix.clamp_result = False
	    mix.data_type = 'FLOAT'
	    mix.factor_mode = 'UNIFORM'
	
	    #node Texture Coordinate
	    texture_coordinate = mesh_eevee_toon_v2.nodes.new("ShaderNodeTexCoord")
	    texture_coordinate.name = "Texture Coordinate"
	    texture_coordinate.hide = True
	    texture_coordinate.from_instancer = False
	    texture_coordinate.outputs[0].hide = True
	    texture_coordinate.outputs[1].hide = True
	    texture_coordinate.outputs[2].hide = True
	    texture_coordinate.outputs[3].hide = True
	    texture_coordinate.outputs[5].hide = True
	    texture_coordinate.outputs[6].hide = True
	
	    #node Vector Rotate
	    vector_rotate = mesh_eevee_toon_v2.nodes.new("ShaderNodeVectorRotate")
	    vector_rotate.name = "Vector Rotate"
	    vector_rotate.invert = False
	    vector_rotate.rotation_type = 'EULER_XYZ'
	    vector_rotate.inputs[1].hide = True
	    vector_rotate.inputs[2].hide = True
	    vector_rotate.inputs[3].hide = True
	    #Center
	    vector_rotate.inputs[1].default_value = (0.0, 0.0, 0.0)
	
	    #node Combine XYZ
	    combine_xyz = mesh_eevee_toon_v2.nodes.new("ShaderNodeCombineXYZ")
	    combine_xyz.name = "Combine XYZ"
	    combine_xyz.inputs[0].hide = True
	    combine_xyz.inputs[1].hide = True
	    #X
	    combine_xyz.inputs[0].default_value = 0.0
	    #Y
	    combine_xyz.inputs[1].default_value = 0.0
	
	    #node Mix.001
	    mix_001 = mesh_eevee_toon_v2.nodes.new("ShaderNodeMix")
	    mix_001.name = "Mix.001"
	    mix_001.blend_type = 'MIX'
	    mix_001.clamp_factor = True
	    mix_001.clamp_result = False
	    mix_001.data_type = 'RGBA'
	    mix_001.factor_mode = 'UNIFORM'
	
	    #node Group Input.001
	    group_input_001 = mesh_eevee_toon_v2.nodes.new("NodeGroupInput")
	    group_input_001.name = "Group Input.001"
	    group_input_001.outputs[1].hide = True
	    group_input_001.outputs[2].hide = True
	    group_input_001.outputs[3].hide = True
	    group_input_001.outputs[4].hide = True
	    group_input_001.outputs[5].hide = True
	    group_input_001.outputs[6].hide = True
	    group_input_001.outputs[7].hide = True
	
	    #node Group Input.002
	    group_input_002 = mesh_eevee_toon_v2.nodes.new("NodeGroupInput")
	    group_input_002.name = "Group Input.002"
	    group_input_002.outputs[0].hide = True
	    group_input_002.outputs[1].hide = True
	    group_input_002.outputs[2].hide = True
	    group_input_002.outputs[4].hide = True
	    group_input_002.outputs[5].hide = True
	    group_input_002.outputs[6].hide = True
	    group_input_002.outputs[7].hide = True
	
	    #node Group Input.003
	    group_input_003 = mesh_eevee_toon_v2.nodes.new("NodeGroupInput")
	    group_input_003.name = "Group Input.003"
	    group_input_003.outputs[0].hide = True
	    group_input_003.outputs[1].hide = True
	    group_input_003.outputs[2].hide = True
	    group_input_003.outputs[3].hide = True
	    group_input_003.outputs[7].hide = True
	
	
	    #Set locations
	    group_output.location = (665.333984375, 0.0)
	    group_input.location = (116.22659301757812, -180.377197265625)
	    principled_bsdf.location = (-406.0650939941406, 145.40895080566406)
	    shader_to_rgb.location = (-50.431976318359375, 144.1940460205078)
	    toon_color.location = (192.35635375976562, 297.7506408691406)
	    voronoi_texture.location = (-48.167144775390625, -22.931198120117188)
	    math.location = (287.2685852050781, 73.24774932861328)
	    mix.location = (287.2685241699219, -81.98865509033203)
	    texture_coordinate.location = (-407.70062255859375, 46.855926513671875)
	    vector_rotate.location = (-228.06509399414062, 64.23240661621094)
	    combine_xyz.location = (-230.8498992919922, -87.66514587402344)
	    mix_001.location = (475.33392333984375, 157.9212188720703)
	    group_input_001.location = (-407.3055419921875, -113.30650329589844)
	    group_input_002.location = (475.68536376953125, -72.68312072753906)
	    group_input_003.location = (-229.45492553710938, -173.40859985351562)
	
	    #Set dimensions
	    group_output.width, group_output.height = 140.0, 100.0
	    group_input.width, group_input.height = 140.0, 100.0
	    principled_bsdf.width, principled_bsdf.height = 240.0, 100.0
	    shader_to_rgb.width, shader_to_rgb.height = 140.0, 100.0
	    toon_color.width, toon_color.height = 240.0, 100.0
	    voronoi_texture.width, voronoi_texture.height = 140.0, 100.0
	    math.width, math.height = 140.0, 100.0
	    mix.width, mix.height = 140.0, 100.0
	    texture_coordinate.width, texture_coordinate.height = 140.0, 100.0
	    vector_rotate.width, vector_rotate.height = 140.0, 100.0
	    combine_xyz.width, combine_xyz.height = 140.0, 100.0
	    mix_001.width, mix_001.height = 140.0, 100.0
	    group_input_001.width, group_input_001.height = 140.0, 100.0
	    group_input_002.width, group_input_002.height = 140.0, 100.0
	    group_input_003.width, group_input_003.height = 140.0, 100.0
	
	    #initialize mesh_eevee_toon_v2 links
	    #mix.Result -> math.Value
	    mesh_eevee_toon_v2.links.new(mix.outputs[0], math.inputs[1])
	    #math.Value -> mix_001.B
	    mesh_eevee_toon_v2.links.new(math.outputs[0], mix_001.inputs[7])
	    #vector_rotate.Vector -> voronoi_texture.Vector
	    mesh_eevee_toon_v2.links.new(vector_rotate.outputs[0], voronoi_texture.inputs[0])
	    #shader_to_rgb.Color -> toon_color.Fac
	    mesh_eevee_toon_v2.links.new(shader_to_rgb.outputs[0], toon_color.inputs[0])
	    #combine_xyz.Vector -> vector_rotate.Rotation
	    mesh_eevee_toon_v2.links.new(combine_xyz.outputs[0], vector_rotate.inputs[4])
	    #texture_coordinate.Camera -> vector_rotate.Vector
	    mesh_eevee_toon_v2.links.new(texture_coordinate.outputs[4], vector_rotate.inputs[0])
	    #principled_bsdf.BSDF -> shader_to_rgb.Shader
	    mesh_eevee_toon_v2.links.new(principled_bsdf.outputs[0], shader_to_rgb.inputs[0])
	    #toon_color.Color -> mix_001.A
	    mesh_eevee_toon_v2.links.new(toon_color.outputs[0], mix_001.inputs[6])
	    #shader_to_rgb.Color -> math.Value
	    mesh_eevee_toon_v2.links.new(shader_to_rgb.outputs[0], math.inputs[0])
	    #voronoi_texture.Distance -> mix.Factor
	    mesh_eevee_toon_v2.links.new(voronoi_texture.outputs[0], mix.inputs[0])
	    #mix_001.Result -> group_output.Color
	    mesh_eevee_toon_v2.links.new(mix_001.outputs[2], group_output.inputs[0])
	    #group_input.Light Depth -> mix.A
	    mesh_eevee_toon_v2.links.new(group_input.outputs[1], mix.inputs[2])
	    #group_input.Shadow Depth -> mix.B
	    mesh_eevee_toon_v2.links.new(group_input.outputs[2], mix.inputs[3])
	    #group_input_001.Hatch Rotation -> combine_xyz.Z
	    mesh_eevee_toon_v2.links.new(group_input_001.outputs[0], combine_xyz.inputs[2])
	    #group_input_002.Mix Factor -> mix_001.Factor
	    mesh_eevee_toon_v2.links.new(group_input_002.outputs[3], mix_001.inputs[0])
	    #group_input_003.Hatch Scale -> voronoi_texture.Scale
	    mesh_eevee_toon_v2.links.new(group_input_003.outputs[4], voronoi_texture.inputs[2])
	    #group_input_003.Hatch Detail -> voronoi_texture.Detail
	    mesh_eevee_toon_v2.links.new(group_input_003.outputs[5], voronoi_texture.inputs[3])
	    #group_input_003.Hatch Randomness -> voronoi_texture.Randomness
	    mesh_eevee_toon_v2.links.new(group_input_003.outputs[6], voronoi_texture.inputs[8])
	    return mesh_eevee_toon_v2
	
	mesh_eevee_toon_v2 = mesh_eevee_toon_v2_node_group()
	
	#initialize MESH_EEVEE_TOON_V3 node group
	def mesh_eevee_toon_v3_node_group():
	
	    mesh_eevee_toon_v3 = bpy.data.node_groups.new(type = 'ShaderNodeTree', name = "MESH_EEVEE_TOON_V3")
	
	    mesh_eevee_toon_v3.color_tag = 'NONE'
	    mesh_eevee_toon_v3.description = "Toon shader with hatch pattern and outline shadow."
	    mesh_eevee_toon_v3.default_group_node_width = 140
	    
	
	    #mesh_eevee_toon_v3 interface
	    #Socket Color
	    color_socket_1 = mesh_eevee_toon_v3.interface.new_socket(name = "Color", in_out='OUTPUT', socket_type = 'NodeSocketColor')
	    color_socket_1.default_value = (0.800000011920929, 0.800000011920929, 0.800000011920929, 1.0)
	    color_socket_1.attribute_domain = 'POINT'
	    color_socket_1.description = "Output Color"
	
	    #Socket Hatch Rotation
	    hatch_rotation_socket_1 = mesh_eevee_toon_v3.interface.new_socket(name = "Hatch Rotation", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    hatch_rotation_socket_1.default_value = 0.0
	    hatch_rotation_socket_1.min_value = -10000.0
	    hatch_rotation_socket_1.max_value = 10000.0
	    hatch_rotation_socket_1.subtype = 'NONE'
	    hatch_rotation_socket_1.attribute_domain = 'POINT'
	    hatch_rotation_socket_1.description = "Rotatate the hatch pattern."
	
	    #Socket Light Depth
	    light_depth_socket_1 = mesh_eevee_toon_v3.interface.new_socket(name = "Light Depth", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    light_depth_socket_1.default_value = 1.0
	    light_depth_socket_1.min_value = -10000.0
	    light_depth_socket_1.max_value = 10000.0
	    light_depth_socket_1.subtype = 'NONE'
	    light_depth_socket_1.attribute_domain = 'POINT'
	    light_depth_socket_1.description = "Control the depth of light passed to color."
	
	    #Socket Shadow Depth
	    shadow_depth_socket_1 = mesh_eevee_toon_v3.interface.new_socket(name = "Shadow Depth", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    shadow_depth_socket_1.default_value = 0.30000001192092896
	    shadow_depth_socket_1.min_value = -10000.0
	    shadow_depth_socket_1.max_value = 10000.0
	    shadow_depth_socket_1.subtype = 'NONE'
	    shadow_depth_socket_1.attribute_domain = 'POINT'
	    shadow_depth_socket_1.description = "Control the depth of shadow passed to color."
	
	    #Socket Mix Factor
	    mix_factor_socket_1 = mesh_eevee_toon_v3.interface.new_socket(name = "Mix Factor", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    mix_factor_socket_1.default_value = 0.5
	    mix_factor_socket_1.min_value = 0.0
	    mix_factor_socket_1.max_value = 1.0
	    mix_factor_socket_1.subtype = 'FACTOR'
	    mix_factor_socket_1.attribute_domain = 'POINT'
	    mix_factor_socket_1.description = "Mix color from flat to hatch."
	
	    #Socket Hatch Scale
	    hatch_scale_socket_1 = mesh_eevee_toon_v3.interface.new_socket(name = "Hatch Scale", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    hatch_scale_socket_1.default_value = 35.0
	    hatch_scale_socket_1.min_value = -1000.0
	    hatch_scale_socket_1.max_value = 1000.0
	    hatch_scale_socket_1.subtype = 'NONE'
	    hatch_scale_socket_1.attribute_domain = 'POINT'
	    hatch_scale_socket_1.description = "Control hatch size."
	
	    #Socket Hatch Detail
	    hatch_detail_socket_1 = mesh_eevee_toon_v3.interface.new_socket(name = "Hatch Detail", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    hatch_detail_socket_1.default_value = 0.0
	    hatch_detail_socket_1.min_value = 0.0
	    hatch_detail_socket_1.max_value = 15.0
	    hatch_detail_socket_1.subtype = 'NONE'
	    hatch_detail_socket_1.attribute_domain = 'POINT'
	    hatch_detail_socket_1.description = "Control the detail of the hatch pattern."
	
	    #Socket Hatch Randomness
	    hatch_randomness_socket_1 = mesh_eevee_toon_v3.interface.new_socket(name = "Hatch Randomness", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    hatch_randomness_socket_1.default_value = 0.0
	    hatch_randomness_socket_1.min_value = 0.0
	    hatch_randomness_socket_1.max_value = 1.0
	    hatch_randomness_socket_1.subtype = 'FACTOR'
	    hatch_randomness_socket_1.attribute_domain = 'POINT'
	    hatch_randomness_socket_1.description = "Control the randomness of the hatch pattern."
	
	    #Socket Outline Control
	    outline_control_socket = mesh_eevee_toon_v3.interface.new_socket(name = "Outline Control", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    outline_control_socket.default_value = 0.5
	    outline_control_socket.min_value = 0.0
	    outline_control_socket.max_value = 1.0
	    outline_control_socket.subtype = 'NONE'
	    outline_control_socket.attribute_domain = 'POINT'
	    outline_control_socket.description = "Control the outline size."
	
	    #Socket Outline Threshold
	    outline_threshold_socket = mesh_eevee_toon_v3.interface.new_socket(name = "Outline Threshold", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    outline_threshold_socket.default_value = 0.5
	    outline_threshold_socket.min_value = -10000.0
	    outline_threshold_socket.max_value = 10000.0
	    outline_threshold_socket.subtype = 'NONE'
	    outline_threshold_socket.attribute_domain = 'POINT'
	    outline_threshold_socket.description = "Control the threshold for the outline."
	
	
	    #initialize mesh_eevee_toon_v3 nodes
	    #node Group Output
	    group_output_1 = mesh_eevee_toon_v3.nodes.new("NodeGroupOutput")
	    group_output_1.name = "Group Output"
	    group_output_1.is_active_output = True
	
	    #node Group Input
	    group_input_1 = mesh_eevee_toon_v3.nodes.new("NodeGroupInput")
	    group_input_1.name = "Group Input"
	    group_input_1.outputs[7].hide = True
	    group_input_1.outputs[8].hide = True
	    group_input_1.outputs[9].hide = True
	
	    #node Group
	    group = mesh_eevee_toon_v3.nodes.new("ShaderNodeGroup")
	    group.name = "Group"
	    group.node_tree = mesh_eevee_toon_v2
	
	    #node Mix
	    mix_1 = mesh_eevee_toon_v3.nodes.new("ShaderNodeMix")
	    mix_1.name = "Mix"
	    mix_1.blend_type = 'MULTIPLY'
	    mix_1.clamp_factor = True
	    mix_1.clamp_result = False
	    mix_1.data_type = 'RGBA'
	    mix_1.factor_mode = 'UNIFORM'
	    mix_1.inputs[0].hide = True
	    mix_1.inputs[1].hide = True
	    mix_1.inputs[2].hide = True
	    mix_1.inputs[3].hide = True
	    mix_1.inputs[4].hide = True
	    mix_1.inputs[5].hide = True
	    mix_1.inputs[8].hide = True
	    mix_1.inputs[9].hide = True
	    mix_1.outputs[0].hide = True
	    mix_1.outputs[1].hide = True
	    mix_1.outputs[3].hide = True
	    #Factor_Float
	    mix_1.inputs[0].default_value = 1.0
	
	    #node Layer Weight
	    layer_weight = mesh_eevee_toon_v3.nodes.new("ShaderNodeLayerWeight")
	    layer_weight.name = "Layer Weight"
	    layer_weight.inputs[1].hide = True
	    layer_weight.outputs[0].hide = True
	    #Normal
	    layer_weight.inputs[1].default_value = (0.0, 0.0, 0.0)
	
	    #node Math
	    math_1 = mesh_eevee_toon_v3.nodes.new("ShaderNodeMath")
	    math_1.name = "Math"
	    math_1.operation = 'LESS_THAN'
	    math_1.use_clamp = False
	
	    #node Group Input.001
	    group_input_001_1 = mesh_eevee_toon_v3.nodes.new("NodeGroupInput")
	    group_input_001_1.name = "Group Input.001"
	    group_input_001_1.outputs[0].hide = True
	    group_input_001_1.outputs[1].hide = True
	    group_input_001_1.outputs[2].hide = True
	    group_input_001_1.outputs[3].hide = True
	    group_input_001_1.outputs[4].hide = True
	    group_input_001_1.outputs[5].hide = True
	    group_input_001_1.outputs[6].hide = True
	    group_input_001_1.outputs[9].hide = True
	
	
	    #Set locations
	    group_output_1.location = (304.7950439453125, 0.0)
	    group_input_1.location = (-314.7950439453125, 88.12310791015625)
	    group.location = (-112.93692016601562, 134.77719116210938)
	    mix_1.location = (114.7950439453125, 134.1249542236328)
	    layer_weight.location = (-114.7950439453125, -121.11866760253906)
	    math_1.location = (111.99153137207031, -72.79229736328125)
	    group_input_001_1.location = (-314.7950439453125, -146.37396240234375)
	
	    #Set dimensions
	    group_output_1.width, group_output_1.height = 140.0, 100.0
	    group_input_1.width, group_input_1.height = 140.0, 100.0
	    group.width, group.height = 140.0, 100.0
	    mix_1.width, mix_1.height = 140.0, 100.0
	    layer_weight.width, layer_weight.height = 140.0, 100.0
	    math_1.width, math_1.height = 140.0, 100.0
	    group_input_001_1.width, group_input_001_1.height = 140.0, 100.0
	
	    #initialize mesh_eevee_toon_v3 links
	    #math_1.Value -> mix_1.A
	    mesh_eevee_toon_v3.links.new(math_1.outputs[0], mix_1.inputs[6])
	    #group.Color -> mix_1.B
	    mesh_eevee_toon_v3.links.new(group.outputs[0], mix_1.inputs[7])
	    #layer_weight.Facing -> math_1.Value
	    mesh_eevee_toon_v3.links.new(layer_weight.outputs[1], math_1.inputs[0])
	    #mix_1.Result -> group_output_1.Color
	    mesh_eevee_toon_v3.links.new(mix_1.outputs[2], group_output_1.inputs[0])
	    #group_input_1.Hatch Rotation -> group.Hatch Rotation
	    mesh_eevee_toon_v3.links.new(group_input_1.outputs[0], group.inputs[0])
	    #group_input_1.Light Depth -> group.Light Depth
	    mesh_eevee_toon_v3.links.new(group_input_1.outputs[1], group.inputs[1])
	    #group_input_1.Shadow Depth -> group.Shadow Depth
	    mesh_eevee_toon_v3.links.new(group_input_1.outputs[2], group.inputs[2])
	    #group_input_1.Mix Factor -> group.Mix Factor
	    mesh_eevee_toon_v3.links.new(group_input_1.outputs[3], group.inputs[3])
	    #group_input_1.Hatch Scale -> group.Hatch Scale
	    mesh_eevee_toon_v3.links.new(group_input_1.outputs[4], group.inputs[4])
	    #group_input_1.Hatch Detail -> group.Hatch Detail
	    mesh_eevee_toon_v3.links.new(group_input_1.outputs[5], group.inputs[5])
	    #group_input_1.Hatch Randomness -> group.Hatch Randomness
	    mesh_eevee_toon_v3.links.new(group_input_1.outputs[6], group.inputs[6])
	    #group_input_001_1.Outline Control -> layer_weight.Blend
	    mesh_eevee_toon_v3.links.new(group_input_001_1.outputs[7], layer_weight.inputs[0])
	    #group_input_001_1.Outline Threshold -> math_1.Value
	    mesh_eevee_toon_v3.links.new(group_input_001_1.outputs[8], math_1.inputs[1])
	    return mesh_eevee_toon_v3
	
	mesh_eevee_toon_v3 = mesh_eevee_toon_v3_node_group()
	
	#initialize MESH_EEVEE_TOON_V3 node group
	def mesh_eevee_toon_v3_1_node_group():
	
	    mesh_eevee_toon_v3_1 = mat.node_tree
	    #start with a clean node tree
	    for node in mesh_eevee_toon_v3_1.nodes:
	        mesh_eevee_toon_v3_1.nodes.remove(node)
	    mesh_eevee_toon_v3_1.color_tag = 'NONE'
	    mesh_eevee_toon_v3_1.description = ""
	    mesh_eevee_toon_v3_1.default_group_node_width = 140
	    
	
	    #mesh_eevee_toon_v3_1 interface
	
	    #initialize mesh_eevee_toon_v3_1 nodes
	    #node Material Output
	    material_output = mesh_eevee_toon_v3_1.nodes.new("ShaderNodeOutputMaterial")
	    material_output.name = "Material Output"
	    material_output.is_active_output = True
	    material_output.target = 'ALL'
	    #Displacement
	    material_output.inputs[2].default_value = (0.0, 0.0, 0.0)
	    #Thickness
	    material_output.inputs[3].default_value = 0.0
	
	    #node Group.001
	    group_001 = mesh_eevee_toon_v3_1.nodes.new("ShaderNodeGroup")
	    group_001.name = "Group.001"
	    group_001.node_tree = mesh_eevee_toon_v3
	    #Socket_1
	    group_001.inputs[0].default_value = 0.0
	    #Socket_2
	    group_001.inputs[1].default_value = 1.0
	    #Socket_3
	    group_001.inputs[2].default_value = 0.30000001192092896
	    #Socket_4
	    group_001.inputs[3].default_value = 0.5
	    #Socket_5
	    group_001.inputs[4].default_value = 35.0
	    #Socket_6
	    group_001.inputs[5].default_value = 0.0
	    #Socket_7
	    group_001.inputs[6].default_value = 0.0
	    #Socket_8
	    group_001.inputs[7].default_value = 0.5
	    #Socket_9
	    group_001.inputs[8].default_value = 0.5
	
	
	    #Set locations
	    material_output.location = (847.8958740234375, 45.71209716796875)
	    group_001.location = (529.0020141601562, 19.813854217529297)
	
	    #Set dimensions
	    material_output.width, material_output.height = 140.0, 100.0
	    group_001.width, group_001.height = 226.58197021484375, 100.0
	
	    #initialize mesh_eevee_toon_v3_1 links
	    #group_001.Color -> material_output.Surface
	    mesh_eevee_toon_v3_1.links.new(group_001.outputs[0], material_output.inputs[0])
	    return mesh_eevee_toon_v3_1
	return mesh_eevee_toon_v3_1_node_group()

	

	
