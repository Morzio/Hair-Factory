import bpy, mathutils



def node(mat):
	#initialize BEAD_GLOSS node group
	def bead_gloss_node_group():
	
	    bead_gloss = bpy.data.node_groups.new(type = 'ShaderNodeTree', name = "BEAD_GLOSS")
	
	    bead_gloss.color_tag = 'NONE'
	    bead_gloss.description = ""
	    bead_gloss.default_group_node_width = 140
	    
	
	    #bead_gloss interface
	    #Socket Shader
	    shader_socket = bead_gloss.interface.new_socket(name = "Shader", in_out='OUTPUT', socket_type = 'NodeSocketShader')
	    shader_socket.attribute_domain = 'POINT'
	
	    #Socket Color
	    color_socket = bead_gloss.interface.new_socket(name = "Color", in_out='INPUT', socket_type = 'NodeSocketColor')
	    color_socket.default_value = (0.800000011920929, 0.800000011920929, 0.800000011920929, 1.0)
	    color_socket.attribute_domain = 'POINT'
	
	
	    #initialize bead_gloss nodes
	    #node Group Output
	    group_output = bead_gloss.nodes.new("NodeGroupOutput")
	    group_output.name = "Group Output"
	    group_output.is_active_output = True
	
	    #node Group Input
	    group_input = bead_gloss.nodes.new("NodeGroupInput")
	    group_input.name = "Group Input"
	
	    #node Diffuse BSDF
	    diffuse_bsdf = bead_gloss.nodes.new("ShaderNodeBsdfDiffuse")
	    diffuse_bsdf.name = "Diffuse BSDF"
	    #Roughness
	    diffuse_bsdf.inputs[1].default_value = 0.0010000000474974513
	    #Normal
	    diffuse_bsdf.inputs[2].default_value = (0.0, 0.0, 0.0)
	
	    #node Glossy BSDF
	    glossy_bsdf = bead_gloss.nodes.new("ShaderNodeBsdfAnisotropic")
	    glossy_bsdf.name = "Glossy BSDF"
	    glossy_bsdf.distribution = 'GGX'
	    #Color
	    glossy_bsdf.inputs[0].default_value = (0.800000011920929, 0.800000011920929, 0.800000011920929, 1.0)
	    #Roughness
	    glossy_bsdf.inputs[1].default_value = 0.10000000149011612
	    #Anisotropy
	    glossy_bsdf.inputs[2].default_value = 0.0
	    #Rotation
	    glossy_bsdf.inputs[3].default_value = 0.0
	    #Normal
	    glossy_bsdf.inputs[4].default_value = (0.0, 0.0, 0.0)
	    #Tangent
	    glossy_bsdf.inputs[5].default_value = (0.0, 0.0, 0.0)
	
	    #node Mix Shader
	    mix_shader = bead_gloss.nodes.new("ShaderNodeMixShader")
	    mix_shader.name = "Mix Shader"
	    #Fac
	    mix_shader.inputs[0].default_value = 0.05000000074505806
	
	    #node Mix Shader.001
	    mix_shader_001 = bead_gloss.nodes.new("ShaderNodeMixShader")
	    mix_shader_001.name = "Mix Shader.001"
	
	    #node Glossy BSDF.001
	    glossy_bsdf_001 = bead_gloss.nodes.new("ShaderNodeBsdfAnisotropic")
	    glossy_bsdf_001.name = "Glossy BSDF.001"
	    glossy_bsdf_001.distribution = 'GGX'
	    #Color
	    glossy_bsdf_001.inputs[0].default_value = (0.800000011920929, 0.800000011920929, 0.800000011920929, 1.0)
	    #Roughness
	    glossy_bsdf_001.inputs[1].default_value = 0.009999999776482582
	    #Anisotropy
	    glossy_bsdf_001.inputs[2].default_value = 0.0
	    #Rotation
	    glossy_bsdf_001.inputs[3].default_value = 0.0
	    #Normal
	    glossy_bsdf_001.inputs[4].default_value = (0.0, 0.0, 0.0)
	    #Tangent
	    glossy_bsdf_001.inputs[5].default_value = (0.0, 0.0, 0.0)
	
	    #node Fresnel
	    fresnel = bead_gloss.nodes.new("ShaderNodeFresnel")
	    fresnel.name = "Fresnel"
	    #IOR
	    fresnel.inputs[0].default_value = 1.5
	    #Normal
	    fresnel.inputs[1].default_value = (0.0, 0.0, 0.0)
	
	
	    #Set locations
	    group_output.location = (398.5509033203125, 0.0)
	    group_input.location = (-408.5509338378906, 0.0)
	    diffuse_bsdf.location = (-208.55087280273438, 74.04916381835938)
	    glossy_bsdf.location = (-208.55093383789062, -56.67292785644531)
	    mix_shader.location = (3.115692138671875, 14.630157470703125)
	    mix_shader_001.location = (208.5509033203125, 44.339752197265625)
	    glossy_bsdf_001.location = (-1.14019775390625, -120.05335998535156)
	    fresnel.location = (4.89727783203125, 120.05337524414062)
	
	    #Set dimensions
	    group_output.width, group_output.height = 140.0, 100.0
	    group_input.width, group_input.height = 140.0, 100.0
	    diffuse_bsdf.width, diffuse_bsdf.height = 150.0, 100.0
	    glossy_bsdf.width, glossy_bsdf.height = 150.0, 100.0
	    mix_shader.width, mix_shader.height = 140.0, 100.0
	    mix_shader_001.width, mix_shader_001.height = 140.0, 100.0
	    glossy_bsdf_001.width, glossy_bsdf_001.height = 150.0, 100.0
	    fresnel.width, fresnel.height = 140.0, 100.0
	
	    #initialize bead_gloss links
	    #diffuse_bsdf.BSDF -> mix_shader.Shader
	    bead_gloss.links.new(diffuse_bsdf.outputs[0], mix_shader.inputs[1])
	    #fresnel.Fac -> mix_shader_001.Fac
	    bead_gloss.links.new(fresnel.outputs[0], mix_shader_001.inputs[0])
	    #mix_shader.Shader -> mix_shader_001.Shader
	    bead_gloss.links.new(mix_shader.outputs[0], mix_shader_001.inputs[1])
	    #glossy_bsdf_001.BSDF -> mix_shader_001.Shader
	    bead_gloss.links.new(glossy_bsdf_001.outputs[0], mix_shader_001.inputs[2])
	    #glossy_bsdf.BSDF -> mix_shader.Shader
	    bead_gloss.links.new(glossy_bsdf.outputs[0], mix_shader.inputs[2])
	    #group_input.Color -> diffuse_bsdf.Color
	    bead_gloss.links.new(group_input.outputs[0], diffuse_bsdf.inputs[0])
	    #mix_shader_001.Shader -> group_output.Shader
	    bead_gloss.links.new(mix_shader_001.outputs[0], group_output.inputs[0])
	    return bead_gloss
	
	bead_gloss = bead_gloss_node_group()
	
	#initialize BEAD_MAT node group
	def bead_mat_node_group():
	
	    bead_mat = mat.node_tree
	    #start with a clean node tree
	    for node in bead_mat.nodes:
	        bead_mat.nodes.remove(node)
	    bead_mat.color_tag = 'NONE'
	    bead_mat.description = ""
	    bead_mat.default_group_node_width = 140
	    
	
	    #bead_mat interface
	
	    #initialize bead_mat nodes
	    #node Material Output
	    material_output = bead_mat.nodes.new("ShaderNodeOutputMaterial")
	    material_output.name = "Material Output"
	    material_output.is_active_output = True
	    material_output.target = 'ALL'
	    #Displacement
	    material_output.inputs[2].default_value = (0.0, 0.0, 0.0)
	    #Thickness
	    material_output.inputs[3].default_value = 0.0
	
	    #node Attribute
	    attribute = bead_mat.nodes.new("ShaderNodeAttribute")
	    attribute.name = "Attribute"
	    attribute.attribute_name = "BEAD_col_id"
	    attribute.attribute_type = 'GEOMETRY'
	
	    #node Bead Colors
	    bead_colors = bead_mat.nodes.new("ShaderNodeValToRGB")
	    bead_colors.label = "Bead Colors"
	    bead_colors.name = "Bead Colors"
	    bead_colors.color_ramp.color_mode = 'RGB'
	    bead_colors.color_ramp.hue_interpolation = 'NEAR'
	    bead_colors.color_ramp.interpolation = 'CONSTANT'
	
	    #initialize color ramp elements
	    bead_colors.color_ramp.elements.remove(bead_colors.color_ramp.elements[0])
	    bead_colors_cre_0 = bead_colors.color_ramp.elements[0]
	    bead_colors_cre_0.position = 0.0
	    bead_colors_cre_0.alpha = 1.0
	    bead_colors_cre_0.color = (1.0, 0.0, 0.0, 1.0)
	
	    bead_colors_cre_1 = bead_colors.color_ramp.elements.new(0.30000001192092896)
	    bead_colors_cre_1.alpha = 1.0
	    bead_colors_cre_1.color = (0.0, 1.0, 0.0, 1.0)
	
	    bead_colors_cre_2 = bead_colors.color_ramp.elements.new(0.6699999570846558)
	    bead_colors_cre_2.alpha = 1.0
	    bead_colors_cre_2.color = (0.0, 0.0, 1.0, 1.0)
	
	
	    #node Group
	    group = bead_mat.nodes.new("ShaderNodeGroup")
	    group.name = "Group"
	    group.node_tree = bead_gloss
	
	
	    #Set locations
	    material_output.location = (-353.980712890625, 282.1742248535156)
	    attribute.location = (-1326.2467041015625, 293.05914306640625)
	    bead_colors.location = (-1005.4395141601562, 312.8655090332031)
	    group.location = (-641.6398315429688, 258.622802734375)
	
	    #Set dimensions
	    material_output.width, material_output.height = 140.0, 100.0
	    attribute.width, attribute.height = 140.0, 100.0
	    bead_colors.width, bead_colors.height = 240.0, 100.0
	    group.width, group.height = 140.0, 100.0
	
	    #initialize bead_mat links
	    #attribute.Color -> bead_colors.Fac
	    bead_mat.links.new(attribute.outputs[0], bead_colors.inputs[0])
	    #group.Shader -> material_output.Surface
	    bead_mat.links.new(group.outputs[0], material_output.inputs[0])
	    #bead_colors.Color -> group.Color
	    bead_mat.links.new(bead_colors.outputs[0], group.inputs[0])
	    return bead_mat
	return bead_mat_node_group()

	

	
