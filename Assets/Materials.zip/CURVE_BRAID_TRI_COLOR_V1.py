import bpy, mathutils



def node(mat):
	#initialize CURVE_BRAID_TRI_COLOR node group
	def curve_braid_tri_color_node_group():
	
	    curve_braid_tri_color = mat.node_tree
	    #start with a clean node tree
	    for node in curve_braid_tri_color.nodes:
	        curve_braid_tri_color.nodes.remove(node)
	    curve_braid_tri_color.color_tag = 'NONE'
	    curve_braid_tri_color.description = ""
	    curve_braid_tri_color.default_group_node_width = 140
	    
	
	    #curve_braid_tri_color interface
	
	    #initialize curve_braid_tri_color nodes
	    #node Material Output
	    material_output = curve_braid_tri_color.nodes.new("ShaderNodeOutputMaterial")
	    material_output.name = "Material Output"
	    material_output.is_active_output = True
	    material_output.target = 'ALL'
	    #Displacement
	    material_output.inputs[2].default_value = (0.0, 0.0, 0.0)
	    #Thickness
	    material_output.inputs[3].default_value = 0.0
	
	    #node Principled Hair BSDF
	    principled_hair_bsdf = curve_braid_tri_color.nodes.new("ShaderNodeBsdfHairPrincipled")
	    principled_hair_bsdf.name = "Principled Hair BSDF"
	    principled_hair_bsdf.model = 'CHIANG'
	    principled_hair_bsdf.parametrization = 'COLOR'
	    #Roughness
	    principled_hair_bsdf.inputs[6].default_value = 0.30000001192092896
	    #Radial Roughness
	    principled_hair_bsdf.inputs[7].default_value = 0.30000001192092896
	    #Coat
	    principled_hair_bsdf.inputs[8].default_value = 0.0
	    #IOR
	    principled_hair_bsdf.inputs[9].default_value = 1.5499999523162842
	    #Offset
	    principled_hair_bsdf.inputs[10].default_value = 0.03490658476948738
	    #Random Roughness
	    principled_hair_bsdf.inputs[12].default_value = 0.0
	    #Random
	    principled_hair_bsdf.inputs[13].default_value = 0.0
	
	    #node Attribute
	    attribute = curve_braid_tri_color.nodes.new("ShaderNodeAttribute")
	    attribute.name = "Attribute"
	    attribute.attribute_name = "BRAIDZ_col_id"
	    attribute.attribute_type = 'GEOMETRY'
	
	    #node Tri Color
	    tri_color = curve_braid_tri_color.nodes.new("ShaderNodeValToRGB")
	    tri_color.label = "Tri Color"
	    tri_color.name = "Tri Color"
	    tri_color.color_ramp.color_mode = 'RGB'
	    tri_color.color_ramp.hue_interpolation = 'NEAR'
	    tri_color.color_ramp.interpolation = 'CONSTANT'
	
	    #initialize color ramp elements
	    tri_color.color_ramp.elements.remove(tri_color.color_ramp.elements[0])
	    tri_color_cre_0 = tri_color.color_ramp.elements[0]
	    tri_color_cre_0.position = 0.0
	    tri_color_cre_0.alpha = 1.0
	    tri_color_cre_0.color = (1.0, 0.0, 0.0, 1.0)
	
	    tri_color_cre_1 = tri_color.color_ramp.elements.new(0.125)
	    tri_color_cre_1.alpha = 1.0
	    tri_color_cre_1.color = (0.0, 1.0, 0.0, 1.0)
	
	    tri_color_cre_2 = tri_color.color_ramp.elements.new(0.25)
	    tri_color_cre_2.alpha = 1.0
	    tri_color_cre_2.color = (0.0, 0.0, 1.0, 1.0)
	
	
	
	    #Set locations
	    material_output.location = (462.1377258300781, 479.5726013183594)
	    principled_hair_bsdf.location = (180.30996704101562, 454.1291198730469)
	    attribute.location = (-273.73150634765625, 231.23248291015625)
	    tri_color.location = (-94.23530578613281, 382.64324951171875)
	
	    #Set dimensions
	    material_output.width, material_output.height = 140.0, 100.0
	    principled_hair_bsdf.width, principled_hair_bsdf.height = 240.0, 100.0
	    attribute.width, attribute.height = 140.0, 100.0
	    tri_color.width, tri_color.height = 240.0, 100.0
	
	    #initialize curve_braid_tri_color links
	    #principled_hair_bsdf.BSDF -> material_output.Surface
	    curve_braid_tri_color.links.new(principled_hair_bsdf.outputs[0], material_output.inputs[0])
	    #attribute.Color -> tri_color.Fac
	    curve_braid_tri_color.links.new(attribute.outputs[0], tri_color.inputs[0])
	    #tri_color.Color -> principled_hair_bsdf.Color
	    curve_braid_tri_color.links.new(tri_color.outputs[0], principled_hair_bsdf.inputs[0])
	    return curve_braid_tri_color
	return curve_braid_tri_color_node_group()

	

	
