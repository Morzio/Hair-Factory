import bpy, mathutils



def node(mat):
	#initialize MESH_BRAID_TRI_COLOR_V1 node group
	def mesh_braid_tri_color_v1_node_group():
	
	    mesh_braid_tri_color_v1 = mat.node_tree
	    #start with a clean node tree
	    for node in mesh_braid_tri_color_v1.nodes:
	        mesh_braid_tri_color_v1.nodes.remove(node)
	    mesh_braid_tri_color_v1.color_tag = 'NONE'
	    mesh_braid_tri_color_v1.description = ""
	    mesh_braid_tri_color_v1.default_group_node_width = 140
	    
	
	    #mesh_braid_tri_color_v1 interface
	
	    #initialize mesh_braid_tri_color_v1 nodes
	    #node Material Output
	    material_output = mesh_braid_tri_color_v1.nodes.new("ShaderNodeOutputMaterial")
	    material_output.name = "Material Output"
	    material_output.is_active_output = True
	    material_output.target = 'ALL'
	    #Displacement
	    material_output.inputs[2].default_value = (0.0, 0.0, 0.0)
	    #Thickness
	    material_output.inputs[3].default_value = 0.0
	
	    #node Attribute
	    attribute = mesh_braid_tri_color_v1.nodes.new("ShaderNodeAttribute")
	    attribute.name = "Attribute"
	    attribute.attribute_name = "BRAIDZ_col_id"
	    attribute.attribute_type = 'GEOMETRY'
	
	    #node Mapping.001
	    mapping_001 = mesh_braid_tri_color_v1.nodes.new("ShaderNodeMapping")
	    mapping_001.name = "Mapping.001"
	    mapping_001.vector_type = 'POINT'
	    #Location
	    mapping_001.inputs[1].default_value = (0.09999999403953552, 0.0, 0.0)
	    #Rotation
	    mapping_001.inputs[2].default_value = (0.0, 0.0, 0.0)
	    #Scale
	    mapping_001.inputs[3].default_value = (0.5, 0.800000011920929, 1.0)
	
	    #node Alpha Texture
	    alpha_texture = mesh_braid_tri_color_v1.nodes.new("ShaderNodeTexImage")
	    alpha_texture.label = "Alpha Texture"
	    alpha_texture.name = "Alpha Texture"
	    alpha_texture.extension = 'REPEAT'
	    alpha_texture.image_user.frame_current = 0
	    alpha_texture.image_user.frame_duration = 1
	    alpha_texture.image_user.frame_offset = -1
	    alpha_texture.image_user.frame_start = 1
	    alpha_texture.image_user.tile = 0
	    alpha_texture.image_user.use_auto_refresh = False
	    alpha_texture.image_user.use_cyclic = False
	    alpha_texture.interpolation = 'Linear'
	    alpha_texture.projection = 'FLAT'
	    alpha_texture.projection_blend = 0.0
	
	    #node Math
	    math = mesh_braid_tri_color_v1.nodes.new("ShaderNodeMath")
	    math.name = "Math"
	    math.operation = 'MULTIPLY'
	    math.use_clamp = False
	    #Value_001
	    math.inputs[1].default_value = 2.0
	
	    #node Principled BSDF.001
	    principled_bsdf_001 = mesh_braid_tri_color_v1.nodes.new("ShaderNodeBsdfPrincipled")
	    principled_bsdf_001.name = "Principled BSDF.001"
	    principled_bsdf_001.distribution = 'MULTI_GGX'
	    principled_bsdf_001.subsurface_method = 'RANDOM_WALK'
	    #Metallic
	    principled_bsdf_001.inputs[1].default_value = 0.0
	    #IOR
	    principled_bsdf_001.inputs[3].default_value = 1.5
	    #Diffuse Roughness
	    principled_bsdf_001.inputs[7].default_value = 0.0
	    #Subsurface Weight
	    principled_bsdf_001.inputs[8].default_value = 0.0
	    #Subsurface Radius
	    principled_bsdf_001.inputs[9].default_value = (1.0, 0.20000000298023224, 0.10000000149011612)
	    #Subsurface Scale
	    principled_bsdf_001.inputs[10].default_value = 0.05000000074505806
	    #Subsurface Anisotropy
	    principled_bsdf_001.inputs[12].default_value = 0.0
	    #Specular IOR Level
	    principled_bsdf_001.inputs[13].default_value = 0.5
	    #Specular Tint
	    principled_bsdf_001.inputs[14].default_value = (1.0, 1.0, 1.0, 1.0)
	    #Anisotropic
	    principled_bsdf_001.inputs[15].default_value = 0.0
	    #Anisotropic Rotation
	    principled_bsdf_001.inputs[16].default_value = 0.0
	    #Tangent
	    principled_bsdf_001.inputs[17].default_value = (0.0, 0.0, 0.0)
	    #Transmission Weight
	    principled_bsdf_001.inputs[18].default_value = 0.0
	    #Coat Weight
	    principled_bsdf_001.inputs[19].default_value = 0.0
	    #Coat Roughness
	    principled_bsdf_001.inputs[20].default_value = 0.029999999329447746
	    #Coat IOR
	    principled_bsdf_001.inputs[21].default_value = 1.5
	    #Coat Tint
	    principled_bsdf_001.inputs[22].default_value = (1.0, 1.0, 1.0, 1.0)
	    #Coat Normal
	    principled_bsdf_001.inputs[23].default_value = (0.0, 0.0, 0.0)
	    #Sheen Weight
	    principled_bsdf_001.inputs[24].default_value = 0.0
	    #Sheen Roughness
	    principled_bsdf_001.inputs[25].default_value = 0.5
	    #Sheen Tint
	    principled_bsdf_001.inputs[26].default_value = (1.0, 1.0, 1.0, 1.0)
	    #Emission Color
	    principled_bsdf_001.inputs[27].default_value = (1.0, 1.0, 1.0, 1.0)
	    #Emission Strength
	    principled_bsdf_001.inputs[28].default_value = 0.0
	    #Thin Film Thickness
	    principled_bsdf_001.inputs[29].default_value = 0.0
	    #Thin Film IOR
	    principled_bsdf_001.inputs[30].default_value = 1.3300000429153442
	
	    #node Attribute.001
	    attribute_001 = mesh_braid_tri_color_v1.nodes.new("ShaderNodeAttribute")
	    attribute_001.name = "Attribute.001"
	    attribute_001.attribute_name = "UVMap"
	    attribute_001.attribute_type = 'GEOMETRY'
	
	    #node Noise Texture
	    noise_texture = mesh_braid_tri_color_v1.nodes.new("ShaderNodeTexNoise")
	    noise_texture.name = "Noise Texture"
	    noise_texture.noise_dimensions = '3D'
	    noise_texture.noise_type = 'FBM'
	    noise_texture.normalize = True
	    #Vector
	    noise_texture.inputs[0].default_value = (0.0, 0.0, 0.0)
	    #Scale
	    noise_texture.inputs[2].default_value = 200.0
	    #Detail
	    noise_texture.inputs[3].default_value = 10.0
	    #Roughness
	    noise_texture.inputs[4].default_value = 0.5
	    #Lacunarity
	    noise_texture.inputs[5].default_value = 2.0
	    #Distortion
	    noise_texture.inputs[8].default_value = 10.0
	
	    #node Mix
	    mix = mesh_braid_tri_color_v1.nodes.new("ShaderNodeMix")
	    mix.name = "Mix"
	    mix.blend_type = 'OVERLAY'
	    mix.clamp_factor = True
	    mix.clamp_result = False
	    mix.data_type = 'RGBA'
	    mix.factor_mode = 'UNIFORM'
	
	    #node Normal Texture
	    normal_texture = mesh_braid_tri_color_v1.nodes.new("ShaderNodeTexImage")
	    normal_texture.label = "Normal Texture"
	    normal_texture.name = "Normal Texture"
	    normal_texture.extension = 'REPEAT'
	    normal_texture.image_user.frame_current = 0
	    normal_texture.image_user.frame_duration = 1
	    normal_texture.image_user.frame_offset = -1
	    normal_texture.image_user.frame_start = 1
	    normal_texture.image_user.tile = 0
	    normal_texture.image_user.use_auto_refresh = False
	    normal_texture.image_user.use_cyclic = False
	    normal_texture.interpolation = 'Linear'
	    normal_texture.projection = 'FLAT'
	    normal_texture.projection_blend = 0.0
	
	    #node Math.001
	    math_001 = mesh_braid_tri_color_v1.nodes.new("ShaderNodeMath")
	    math_001.name = "Math.001"
	    math_001.operation = 'ARCTAN2'
	    math_001.use_clamp = False
	
	    #node Roughness
	    roughness = mesh_braid_tri_color_v1.nodes.new("ShaderNodeValToRGB")
	    roughness.label = "Roughness"
	    roughness.name = "Roughness"
	    roughness.color_ramp.color_mode = 'RGB'
	    roughness.color_ramp.hue_interpolation = 'NEAR'
	    roughness.color_ramp.interpolation = 'B_SPLINE'
	
	    #initialize color ramp elements
	    roughness.color_ramp.elements.remove(roughness.color_ramp.elements[0])
	    roughness_cre_0 = roughness.color_ramp.elements[0]
	    roughness_cre_0.position = 0.0
	    roughness_cre_0.alpha = 1.0
	    roughness_cre_0.color = (0.0, 0.0, 0.0, 1.0)
	
	    roughness_cre_1 = roughness.color_ramp.elements.new(0.10000000149011612)
	    roughness_cre_1.alpha = 1.0
	    roughness_cre_1.color = (1.0, 1.0, 1.0, 1.0)
	
	
	    #node Normal Map
	    normal_map = mesh_braid_tri_color_v1.nodes.new("ShaderNodeNormalMap")
	    normal_map.name = "Normal Map"
	    normal_map.space = 'TANGENT'
	    normal_map.uv_map = ""
	    #Strength
	    normal_map.inputs[0].default_value = 0.10000000149011612
	
	    #node Invert Color
	    invert_color = mesh_braid_tri_color_v1.nodes.new("ShaderNodeInvert")
	    invert_color.name = "Invert Color"
	    #Fac
	    invert_color.inputs[0].default_value = 1.0
	
	    #node Mix Shader
	    mix_shader = mesh_braid_tri_color_v1.nodes.new("ShaderNodeMixShader")
	    mix_shader.name = "Mix Shader"
	
	    #node Transparent BSDF
	    transparent_bsdf = mesh_braid_tri_color_v1.nodes.new("ShaderNodeBsdfTransparent")
	    transparent_bsdf.name = "Transparent BSDF"
	    #Color
	    transparent_bsdf.inputs[0].default_value = (1.0, 1.0, 1.0, 1.0)
	
	    #node Brightness/Contrast
	    brightness_contrast = mesh_braid_tri_color_v1.nodes.new("ShaderNodeBrightContrast")
	    brightness_contrast.name = "Brightness/Contrast"
	    #Bright
	    brightness_contrast.inputs[1].default_value = 0.15000000596046448
	    #Contrast
	    brightness_contrast.inputs[2].default_value = 0.1599999964237213
	
	    #node Hue/Saturation/Value
	    hue_saturation_value = mesh_braid_tri_color_v1.nodes.new("ShaderNodeHueSaturation")
	    hue_saturation_value.name = "Hue/Saturation/Value"
	    #Hue
	    hue_saturation_value.inputs[0].default_value = 0.5
	    #Saturation
	    hue_saturation_value.inputs[1].default_value = 1.0
	    #Value
	    hue_saturation_value.inputs[2].default_value = 1.0
	    #Fac
	    hue_saturation_value.inputs[3].default_value = 1.0
	
	    #node Tri Color
	    tri_color = mesh_braid_tri_color_v1.nodes.new("ShaderNodeValToRGB")
	    tri_color.label = "Tri Color"
	    tri_color.name = "Tri Color"
	    tri_color.color_ramp.color_mode = 'RGB'
	    tri_color.color_ramp.hue_interpolation = 'NEAR'
	    tri_color.color_ramp.interpolation = 'CONSTANT'
	
	    #initialize color ramp elements
	    tri_color.color_ramp.elements.remove(tri_color.color_ramp.elements[0])
	    tri_color_cre_0 = tri_color.color_ramp.elements[0]
	    tri_color_cre_0.position = 0.0
	    tri_color_cre_0.alpha = 1.0
	    tri_color_cre_0.color = (0.0908396989107132, 0.021219048649072647, 0.005181607790291309, 1.0)
	
	    tri_color_cre_1 = tri_color.color_ramp.elements.new(0.125)
	    tri_color_cre_1.alpha = 1.0
	    tri_color_cre_1.color = (0.09002328664064407, 0.021188443526625633, 0.005372246261686087, 1.0)
	
	    tri_color_cre_2 = tri_color.color_ramp.elements.new(0.25)
	    tri_color_cre_2.alpha = 1.0
	    tri_color_cre_2.color = (0.13866683840751648, 0.0, 0.2275710254907608, 1.0)
	
	
	
	    #Set locations
	    material_output.location = (1286.44140625, 322.9259338378906)
	    attribute.location = (-637.0400390625, 183.9042205810547)
	    mapping_001.location = (-268.7929382324219, 38.3319206237793)
	    alpha_texture.location = (-5.1221089363098145, 213.5727081298828)
	    math.location = (275.11212158203125, -25.074493408203125)
	    principled_bsdf_001.location = (707.5186767578125, 256.1741638183594)
	    attribute_001.location = (-637.0400390625, 6.578971862792969)
	    noise_texture.location = (-171.71595764160156, 565.3727416992188)
	    mix.location = (271.72845458984375, 417.0964050292969)
	    normal_texture.location = (-5.1221089363098145, -63.71808624267578)
	    math_001.location = (-452.9451599121094, 117.08235168457031)
	    roughness.location = (278.3168640136719, 189.15158081054688)
	    normal_map.location = (270.6690979003906, -183.8872528076172)
	    invert_color.location = (274.9986572265625, 528.3245849609375)
	    mix_shader.location = (1078.674560546875, 299.4745788574219)
	    transparent_bsdf.location = (1074.216552734375, 174.54249572753906)
	    brightness_contrast.location = (456.0156555175781, 448.8018493652344)
	    hue_saturation_value.location = (455.72802734375, 324.9081115722656)
	    tri_color.location = (-271.65655517578125, 271.427734375)
	
	    #Set dimensions
	    material_output.width, material_output.height = 140.0, 100.0
	    attribute.width, attribute.height = 140.0, 100.0
	    mapping_001.width, mapping_001.height = 140.0, 100.0
	    alpha_texture.width, alpha_texture.height = 240.0, 100.0
	    math.width, math.height = 140.0, 100.0
	    principled_bsdf_001.width, principled_bsdf_001.height = 240.0, 100.0
	    attribute_001.width, attribute_001.height = 140.0, 100.0
	    noise_texture.width, noise_texture.height = 140.0, 100.0
	    mix.width, mix.height = 140.0, 100.0
	    normal_texture.width, normal_texture.height = 240.0, 100.0
	    math_001.width, math_001.height = 140.0, 100.0
	    roughness.width, roughness.height = 140.0, 100.0
	    normal_map.width, normal_map.height = 150.0, 100.0
	    invert_color.width, invert_color.height = 140.0, 100.0
	    mix_shader.width, mix_shader.height = 140.0, 100.0
	    transparent_bsdf.width, transparent_bsdf.height = 140.0, 100.0
	    brightness_contrast.width, brightness_contrast.height = 140.0, 100.0
	    hue_saturation_value.width, hue_saturation_value.height = 150.0, 100.0
	    tri_color.width, tri_color.height = 240.0, 100.0
	
	    #initialize mesh_braid_tri_color_v1 links
	    #alpha_texture.Alpha -> math.Value
	    mesh_braid_tri_color_v1.links.new(alpha_texture.outputs[1], math.inputs[0])
	    #mapping_001.Vector -> alpha_texture.Vector
	    mesh_braid_tri_color_v1.links.new(mapping_001.outputs[0], alpha_texture.inputs[0])
	    #math.Value -> principled_bsdf_001.Alpha
	    mesh_braid_tri_color_v1.links.new(math.outputs[0], principled_bsdf_001.inputs[4])
	    #noise_texture.Color -> mix.B
	    mesh_braid_tri_color_v1.links.new(noise_texture.outputs[1], mix.inputs[7])
	    #noise_texture.Fac -> mix.Factor
	    mesh_braid_tri_color_v1.links.new(noise_texture.outputs[0], mix.inputs[0])
	    #mapping_001.Vector -> normal_texture.Vector
	    mesh_braid_tri_color_v1.links.new(mapping_001.outputs[0], normal_texture.inputs[0])
	    #attribute_001.Vector -> mapping_001.Vector
	    mesh_braid_tri_color_v1.links.new(attribute_001.outputs[1], mapping_001.inputs[0])
	    #attribute.Color -> math_001.Value
	    mesh_braid_tri_color_v1.links.new(attribute.outputs[0], math_001.inputs[1])
	    #attribute_001.Fac -> math_001.Value
	    mesh_braid_tri_color_v1.links.new(attribute_001.outputs[2], math_001.inputs[0])
	    #alpha_texture.Color -> roughness.Fac
	    mesh_braid_tri_color_v1.links.new(alpha_texture.outputs[0], roughness.inputs[0])
	    #roughness.Color -> principled_bsdf_001.Roughness
	    mesh_braid_tri_color_v1.links.new(roughness.outputs[0], principled_bsdf_001.inputs[2])
	    #normal_map.Normal -> principled_bsdf_001.Normal
	    mesh_braid_tri_color_v1.links.new(normal_map.outputs[0], principled_bsdf_001.inputs[5])
	    #normal_texture.Color -> normal_map.Color
	    mesh_braid_tri_color_v1.links.new(normal_texture.outputs[0], normal_map.inputs[1])
	    #alpha_texture.Color -> invert_color.Color
	    mesh_braid_tri_color_v1.links.new(alpha_texture.outputs[0], invert_color.inputs[1])
	    #invert_color.Color -> mix_shader.Fac
	    mesh_braid_tri_color_v1.links.new(invert_color.outputs[0], mix_shader.inputs[0])
	    #transparent_bsdf.BSDF -> mix_shader.Shader
	    mesh_braid_tri_color_v1.links.new(transparent_bsdf.outputs[0], mix_shader.inputs[2])
	    #principled_bsdf_001.BSDF -> mix_shader.Shader
	    mesh_braid_tri_color_v1.links.new(principled_bsdf_001.outputs[0], mix_shader.inputs[1])
	    #mix_shader.Shader -> material_output.Surface
	    mesh_braid_tri_color_v1.links.new(mix_shader.outputs[0], material_output.inputs[0])
	    #mix.Result -> brightness_contrast.Color
	    mesh_braid_tri_color_v1.links.new(mix.outputs[2], brightness_contrast.inputs[0])
	    #brightness_contrast.Color -> hue_saturation_value.Color
	    mesh_braid_tri_color_v1.links.new(brightness_contrast.outputs[0], hue_saturation_value.inputs[4])
	    #hue_saturation_value.Color -> principled_bsdf_001.Base Color
	    mesh_braid_tri_color_v1.links.new(hue_saturation_value.outputs[0], principled_bsdf_001.inputs[0])
	    #tri_color.Color -> mix.A
	    mesh_braid_tri_color_v1.links.new(tri_color.outputs[0], mix.inputs[6])
	    #attribute.Color -> tri_color.Fac
	    mesh_braid_tri_color_v1.links.new(attribute.outputs[0], tri_color.inputs[0])
	    return mesh_braid_tri_color_v1
	return mesh_braid_tri_color_v1_node_group()

	

	
