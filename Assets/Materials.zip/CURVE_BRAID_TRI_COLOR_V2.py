import bpy, mathutils



def node(mat):
	#initialize CURVE_BRAID_TRI_COLOR_V2 node group
	def curve_braid_tri_color_v2_node_group():
	
	    curve_braid_tri_color_v2 = mat.node_tree
	    #start with a clean node tree
	    for node in curve_braid_tri_color_v2.nodes:
	        curve_braid_tri_color_v2.nodes.remove(node)
	    curve_braid_tri_color_v2.color_tag = 'NONE'
	    curve_braid_tri_color_v2.description = ""
	    curve_braid_tri_color_v2.default_group_node_width = 140
	    
	
	    #curve_braid_tri_color_v2 interface
	
	    #initialize curve_braid_tri_color_v2 nodes
	    #node Material Output
	    material_output = curve_braid_tri_color_v2.nodes.new("ShaderNodeOutputMaterial")
	    material_output.name = "Material Output"
	    material_output.is_active_output = True
	    material_output.target = 'ALL'
	    #Displacement
	    material_output.inputs[2].default_value = (0.0, 0.0, 0.0)
	    #Thickness
	    material_output.inputs[3].default_value = 0.0
	
	    #node Principled Hair BSDF
	    principled_hair_bsdf = curve_braid_tri_color_v2.nodes.new("ShaderNodeBsdfHairPrincipled")
	    principled_hair_bsdf.name = "Principled Hair BSDF"
	    principled_hair_bsdf.model = 'CHIANG'
	    principled_hair_bsdf.parametrization = 'COLOR'
	    #Roughness
	    principled_hair_bsdf.inputs[6].default_value = 0.30000001192092896
	    #Radial Roughness
	    principled_hair_bsdf.inputs[7].default_value = 0.30000001192092896
	    #Coat
	    principled_hair_bsdf.inputs[8].default_value = 0.0
	    #IOR
	    principled_hair_bsdf.inputs[9].default_value = 1.5499999523162842
	    #Offset
	    principled_hair_bsdf.inputs[10].default_value = 0.03490658476948738
	    #Random Roughness
	    principled_hair_bsdf.inputs[12].default_value = 0.0
	    #Random
	    principled_hair_bsdf.inputs[13].default_value = 0.0
	
	    #node Attribute
	    attribute = curve_braid_tri_color_v2.nodes.new("ShaderNodeAttribute")
	    attribute.name = "Attribute"
	    attribute.attribute_name = "BRAIDZ_col_id"
	    attribute.attribute_type = 'GEOMETRY'
	
	    #node Color Ramp
	    color_ramp = curve_braid_tri_color_v2.nodes.new("ShaderNodeValToRGB")
	    color_ramp.name = "Color Ramp"
	    color_ramp.color_ramp.color_mode = 'RGB'
	    color_ramp.color_ramp.hue_interpolation = 'NEAR'
	    color_ramp.color_ramp.interpolation = 'B_SPLINE'
	
	    #initialize color ramp elements
	    color_ramp.color_ramp.elements.remove(color_ramp.color_ramp.elements[0])
	    color_ramp_cre_0 = color_ramp.color_ramp.elements[0]
	    color_ramp_cre_0.position = 0.15458935499191284
	    color_ramp_cre_0.alpha = 1.0
	    color_ramp_cre_0.color = (0.18906693160533905, 0.0, 0.258590430021286, 1.0)
	
	    color_ramp_cre_1 = color_ramp.color_ramp.elements.new(0.29408207535743713)
	    color_ramp_cre_1.alpha = 1.0
	    color_ramp_cre_1.color = (0.0289168618619442, 1.0, 0.0, 1.0)
	
	    color_ramp_cre_2 = color_ramp.color_ramp.elements.new(0.40458938479423523)
	    color_ramp_cre_2.alpha = 1.0
	    color_ramp_cre_2.color = (0.0, 0.0, 1.0, 1.0)
	
	
	    #node Curves Info
	    curves_info = curve_braid_tri_color_v2.nodes.new("ShaderNodeHairInfo")
	    curves_info.name = "Curves Info"
	
	    #node Math
	    math = curve_braid_tri_color_v2.nodes.new("ShaderNodeMath")
	    math.name = "Math"
	    math.hide = True
	    math.operation = 'MULTIPLY'
	    math.use_clamp = False
	
	
	    #Set locations
	    material_output.location = (462.1377258300781, 479.5726013183594)
	    principled_hair_bsdf.location = (180.30996704101562, 454.1291198730469)
	    attribute.location = (-433.67303466796875, 144.8729705810547)
	    color_ramp.location = (-94.23530578613281, 382.64324951171875)
	    curves_info.location = (-434.0669860839844, 314.36053466796875)
	    math.location = (-265.9233093261719, 204.6976776123047)
	
	    #Set dimensions
	    material_output.width, material_output.height = 140.0, 100.0
	    principled_hair_bsdf.width, principled_hair_bsdf.height = 240.0, 100.0
	    attribute.width, attribute.height = 140.0, 100.0
	    color_ramp.width, color_ramp.height = 240.0, 100.0
	    curves_info.width, curves_info.height = 140.0, 100.0
	    math.width, math.height = 140.0, 100.0
	
	    #initialize curve_braid_tri_color_v2 links
	    #principled_hair_bsdf.BSDF -> material_output.Surface
	    curve_braid_tri_color_v2.links.new(principled_hair_bsdf.outputs[0], material_output.inputs[0])
	    #color_ramp.Color -> principled_hair_bsdf.Color
	    curve_braid_tri_color_v2.links.new(color_ramp.outputs[0], principled_hair_bsdf.inputs[0])
	    #math.Value -> color_ramp.Fac
	    curve_braid_tri_color_v2.links.new(math.outputs[0], color_ramp.inputs[0])
	    #curves_info.Intercept -> math.Value
	    curve_braid_tri_color_v2.links.new(curves_info.outputs[1], math.inputs[0])
	    #attribute.Color -> math.Value
	    curve_braid_tri_color_v2.links.new(attribute.outputs[0], math.inputs[1])
	    #attribute.Fac -> math.Value
	    curve_braid_tri_color_v2.links.new(attribute.outputs[2], math.inputs[2])
	    return curve_braid_tri_color_v2
	return curve_braid_tri_color_v2_node_group()

	

	
