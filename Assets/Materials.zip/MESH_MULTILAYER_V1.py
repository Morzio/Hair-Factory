import bpy, mathutils



def node(mat):
	#initialize Procedural_hair node group
	def procedural_hair_node_group():
	
	    procedural_hair = bpy.data.node_groups.new(type = 'ShaderNodeTree', name = "Procedural_hair")
	
	    procedural_hair.color_tag = 'NONE'
	    procedural_hair.description = ""
	    procedural_hair.default_group_node_width = 140
	    
	
	    #procedural_hair interface
	    #Socket Shader
	    shader_socket = procedural_hair.interface.new_socket(name = "Shader", in_out='OUTPUT', socket_type = 'NodeSocketShader')
	    shader_socket.attribute_domain = 'POINT'
	
	    #Socket Alpha
	    alpha_socket = procedural_hair.interface.new_socket(name = "Alpha", in_out='OUTPUT', socket_type = 'NodeSocketColor')
	    alpha_socket.default_value = (0.800000011920929, 0.800000011920929, 0.800000011920929, 1.0)
	    alpha_socket.attribute_domain = 'POINT'
	
	    #Socket Normal
	    normal_socket = procedural_hair.interface.new_socket(name = "Normal", in_out='OUTPUT', socket_type = 'NodeSocketVector')
	    normal_socket.default_value = (0.0, 0.0, 0.0)
	    normal_socket.min_value = -3.4028234663852886e+38
	    normal_socket.max_value = 3.4028234663852886e+38
	    normal_socket.subtype = 'NONE'
	    normal_socket.attribute_domain = 'POINT'
	
	    #Socket noise
	    noise_socket = procedural_hair.interface.new_socket(name = "noise", in_out='OUTPUT', socket_type = 'NodeSocketColor')
	    noise_socket.default_value = (0.800000011920929, 0.800000011920929, 0.800000011920929, 1.0)
	    noise_socket.attribute_domain = 'POINT'
	
	    #Socket Base Color
	    base_color_socket = procedural_hair.interface.new_socket(name = "Base Color", in_out='INPUT', socket_type = 'NodeSocketColor')
	    base_color_socket.default_value = (0.800000011920929, 0.800000011920929, 0.800000011920929, 1.0)
	    base_color_socket.attribute_domain = 'POINT'
	
	    #Socket Vector
	    vector_socket = procedural_hair.interface.new_socket(name = "Vector", in_out='INPUT', socket_type = 'NodeSocketVector')
	    vector_socket.default_value = (0.0, 0.0, 0.0)
	    vector_socket.min_value = -3.4028234663852886e+38
	    vector_socket.max_value = 3.4028234663852886e+38
	    vector_socket.subtype = 'NONE'
	    vector_socket.attribute_domain = 'POINT'
	
	    #Socket Location
	    location_socket = procedural_hair.interface.new_socket(name = "Location", in_out='INPUT', socket_type = 'NodeSocketVector')
	    location_socket.default_value = (0.29999998211860657, 7.199999809265137, -3.299999713897705)
	    location_socket.min_value = -3.4028234663852886e+38
	    location_socket.max_value = 3.4028234663852886e+38
	    location_socket.subtype = 'TRANSLATION'
	    location_socket.attribute_domain = 'POINT'
	
	    #Socket Scale
	    scale_socket = procedural_hair.interface.new_socket(name = "Scale", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    scale_socket.default_value = 39.79999542236328
	    scale_socket.min_value = -1000.0
	    scale_socket.max_value = 1000.0
	    scale_socket.subtype = 'NONE'
	    scale_socket.attribute_domain = 'POINT'
	
	    #Socket Detail
	    detail_socket = procedural_hair.interface.new_socket(name = "Detail", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    detail_socket.default_value = 2.0
	    detail_socket.min_value = 0.0
	    detail_socket.max_value = 15.0
	    detail_socket.subtype = 'NONE'
	    detail_socket.attribute_domain = 'POINT'
	
	    #Socket Roughness
	    roughness_socket = procedural_hair.interface.new_socket(name = "Roughness", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    roughness_socket.default_value = 0.3761061728000641
	    roughness_socket.min_value = 0.0
	    roughness_socket.max_value = 1.0
	    roughness_socket.subtype = 'FACTOR'
	    roughness_socket.attribute_domain = 'POINT'
	
	    #Socket Lacunarity
	    lacunarity_socket = procedural_hair.interface.new_socket(name = "Lacunarity", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    lacunarity_socket.default_value = 2.0
	    lacunarity_socket.min_value = 0.0
	    lacunarity_socket.max_value = 1000.0
	    lacunarity_socket.subtype = 'NONE'
	    lacunarity_socket.attribute_domain = 'POINT'
	
	    #Socket Distortion
	    distortion_socket = procedural_hair.interface.new_socket(name = "Distortion", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    distortion_socket.default_value = 0.0
	    distortion_socket.min_value = -1000.0
	    distortion_socket.max_value = 1000.0
	    distortion_socket.subtype = 'NONE'
	    distortion_socket.attribute_domain = 'POINT'
	
	
	    #initialize procedural_hair nodes
	    #node Group Output
	    group_output = procedural_hair.nodes.new("NodeGroupOutput")
	    group_output.name = "Group Output"
	    group_output.is_active_output = True
	
	    #node Group Input
	    group_input = procedural_hair.nodes.new("NodeGroupInput")
	    group_input.name = "Group Input"
	    group_input.outputs[0].hide = True
	    group_input.outputs[8].hide = True
	
	    #node Principled BSDF
	    principled_bsdf = procedural_hair.nodes.new("ShaderNodeBsdfPrincipled")
	    principled_bsdf.name = "Principled BSDF"
	    principled_bsdf.distribution = 'GGX'
	    principled_bsdf.subsurface_method = 'RANDOM_WALK'
	    #Metallic
	    principled_bsdf.inputs[1].default_value = 0.0
	    #IOR
	    principled_bsdf.inputs[3].default_value = 1.5
	    #Diffuse Roughness
	    principled_bsdf.inputs[7].default_value = 0.0
	    #Subsurface Weight
	    principled_bsdf.inputs[8].default_value = 0.0
	    #Subsurface Radius
	    principled_bsdf.inputs[9].default_value = (1.0, 0.20000000298023224, 0.10000000149011612)
	    #Subsurface Scale
	    principled_bsdf.inputs[10].default_value = 0.05000000074505806
	    #Subsurface Anisotropy
	    principled_bsdf.inputs[12].default_value = 0.0
	    #Specular IOR Level
	    principled_bsdf.inputs[13].default_value = 0.5
	    #Anisotropic
	    principled_bsdf.inputs[15].default_value = 0.0
	    #Anisotropic Rotation
	    principled_bsdf.inputs[16].default_value = 0.0
	    #Tangent
	    principled_bsdf.inputs[17].default_value = (0.0, 0.0, 0.0)
	    #Transmission Weight
	    principled_bsdf.inputs[18].default_value = 0.0
	    #Coat Weight
	    principled_bsdf.inputs[19].default_value = 0.0
	    #Coat Roughness
	    principled_bsdf.inputs[20].default_value = 0.029999999329447746
	    #Coat IOR
	    principled_bsdf.inputs[21].default_value = 1.5
	    #Coat Tint
	    principled_bsdf.inputs[22].default_value = (1.0, 1.0, 1.0, 1.0)
	    #Coat Normal
	    principled_bsdf.inputs[23].default_value = (0.0, 0.0, 0.0)
	    #Sheen Weight
	    principled_bsdf.inputs[24].default_value = 0.0
	    #Sheen Roughness
	    principled_bsdf.inputs[25].default_value = 0.5
	    #Sheen Tint
	    principled_bsdf.inputs[26].default_value = (1.0, 1.0, 1.0, 1.0)
	    #Emission Color
	    principled_bsdf.inputs[27].default_value = (1.0, 1.0, 1.0, 1.0)
	    #Emission Strength
	    principled_bsdf.inputs[28].default_value = 0.0
	    #Thin Film Thickness
	    principled_bsdf.inputs[29].default_value = 0.0
	    #Thin Film IOR
	    principled_bsdf.inputs[30].default_value = 1.3300000429153442
	
	    #node Mapping
	    mapping = procedural_hair.nodes.new("ShaderNodeMapping")
	    mapping.name = "Mapping"
	    mapping.hide = True
	    mapping.vector_type = 'POINT'
	    mapping.inputs[2].hide = True
	    mapping.inputs[3].hide = True
	    #Rotation
	    mapping.inputs[2].default_value = (0.0, 0.0, 0.0)
	    #Scale
	    mapping.inputs[3].default_value = (0.05000000074505806, 20.0, 1.0)
	
	    #node Noise Texture
	    noise_texture = procedural_hair.nodes.new("ShaderNodeTexNoise")
	    noise_texture.name = "Noise Texture"
	    noise_texture.noise_dimensions = '3D'
	    noise_texture.noise_type = 'FBM'
	    noise_texture.normalize = True
	
	    #node Alpha Control
	    alpha_control = procedural_hair.nodes.new("ShaderNodeValToRGB")
	    alpha_control.label = "Alpha Control"
	    alpha_control.name = "Alpha Control"
	    alpha_control.color_ramp.color_mode = 'RGB'
	    alpha_control.color_ramp.hue_interpolation = 'NEAR'
	    alpha_control.color_ramp.interpolation = 'LINEAR'
	
	    #initialize color ramp elements
	    alpha_control.color_ramp.elements.remove(alpha_control.color_ramp.elements[0])
	    alpha_control_cre_0 = alpha_control.color_ramp.elements[0]
	    alpha_control_cre_0.position = 0.30000001192092896
	    alpha_control_cre_0.alpha = 1.0
	    alpha_control_cre_0.color = (0.0, 0.0, 0.0, 1.0)
	
	    alpha_control_cre_1 = alpha_control.color_ramp.elements.new(1.0)
	    alpha_control_cre_1.alpha = 1.0
	    alpha_control_cre_1.color = (1.0, 1.0, 1.0, 1.0)
	
	
	    #node Bump
	    bump = procedural_hair.nodes.new("ShaderNodeBump")
	    bump.name = "Bump"
	    bump.invert = False
	    bump.inputs[0].hide = True
	    bump.inputs[1].hide = True
	    bump.inputs[3].hide = True
	    #Strength
	    bump.inputs[0].default_value = 1.0
	    #Distance
	    bump.inputs[1].default_value = 1.0
	    #Normal
	    bump.inputs[3].default_value = (0.0, 0.0, 0.0)
	
	    #node Group Input.001
	    group_input_001 = procedural_hair.nodes.new("NodeGroupInput")
	    group_input_001.name = "Group Input.001"
	    group_input_001.outputs[1].hide = True
	    group_input_001.outputs[2].hide = True
	    group_input_001.outputs[3].hide = True
	    group_input_001.outputs[4].hide = True
	    group_input_001.outputs[5].hide = True
	    group_input_001.outputs[6].hide = True
	    group_input_001.outputs[7].hide = True
	    group_input_001.outputs[8].hide = True
	
	    #node Group Input.003
	    group_input_003 = procedural_hair.nodes.new("NodeGroupInput")
	    group_input_003.name = "Group Input.003"
	    group_input_003.outputs[0].hide = True
	    group_input_003.outputs[1].hide = True
	    group_input_003.outputs[2].hide = True
	    group_input_003.outputs[3].hide = True
	    group_input_003.outputs[4].hide = True
	    group_input_003.outputs[6].hide = True
	    group_input_003.outputs[7].hide = True
	    group_input_003.outputs[8].hide = True
	
	    #node Group Input.004
	    group_input_004 = procedural_hair.nodes.new("NodeGroupInput")
	    group_input_004.name = "Group Input.004"
	    group_input_004.outputs[1].hide = True
	    group_input_004.outputs[2].hide = True
	    group_input_004.outputs[3].hide = True
	    group_input_004.outputs[4].hide = True
	    group_input_004.outputs[5].hide = True
	    group_input_004.outputs[6].hide = True
	    group_input_004.outputs[7].hide = True
	    group_input_004.outputs[8].hide = True
	
	    #node Mix
	    mix = procedural_hair.nodes.new("ShaderNodeMix")
	    mix.name = "Mix"
	    mix.blend_type = 'MIX'
	    mix.clamp_factor = True
	    mix.clamp_result = True
	    mix.data_type = 'RGBA'
	    mix.factor_mode = 'UNIFORM'
	    #Factor_Float
	    mix.inputs[0].default_value = 0.5
	
	
	    #Set locations
	    group_output.location = (995.665771484375, 135.07635498046875)
	    group_input.location = (-1005.665771484375, 0.0)
	    principled_bsdf.location = (600.0736694335938, -61.74269104003906)
	    mapping.location = (-798.21728515625, -40.52863693237305)
	    noise_texture.location = (-607.0064086914062, 93.38096618652344)
	    alpha_control.location = (-282.6976623535156, 249.39878845214844)
	    bump.location = (-22.60857582092285, 140.4307403564453)
	    group_input_001.location = (438.4066467285156, -84.16943359375)
	    group_input_003.location = (414.8658752441406, -239.8295440673828)
	    group_input_004.location = (-11.417752265930176, -460.7171325683594)
	    mix.location = (241.13339233398438, -297.771240234375)
	
	    #Set dimensions
	    group_output.width, group_output.height = 140.0, 100.0
	    group_input.width, group_input.height = 140.0, 100.0
	    principled_bsdf.width, principled_bsdf.height = 240.0, 100.0
	    mapping.width, mapping.height = 140.0, 100.0
	    noise_texture.width, noise_texture.height = 140.0, 100.0
	    alpha_control.width, alpha_control.height = 240.0, 100.0
	    bump.width, bump.height = 140.0, 100.0
	    group_input_001.width, group_input_001.height = 140.0, 100.0
	    group_input_003.width, group_input_003.height = 140.0, 100.0
	    group_input_004.width, group_input_004.height = 140.0, 100.0
	    mix.width, mix.height = 140.0, 100.0
	
	    #initialize procedural_hair links
	    #mapping.Vector -> noise_texture.Vector
	    procedural_hair.links.new(mapping.outputs[0], noise_texture.inputs[0])
	    #bump.Normal -> principled_bsdf.Normal
	    procedural_hair.links.new(bump.outputs[0], principled_bsdf.inputs[5])
	    #alpha_control.Color -> bump.Height
	    procedural_hair.links.new(alpha_control.outputs[0], bump.inputs[2])
	    #group_input.Vector -> mapping.Vector
	    procedural_hair.links.new(group_input.outputs[1], mapping.inputs[0])
	    #principled_bsdf.BSDF -> group_output.Shader
	    procedural_hair.links.new(principled_bsdf.outputs[0], group_output.inputs[0])
	    #group_input.Location -> mapping.Location
	    procedural_hair.links.new(group_input.outputs[2], mapping.inputs[1])
	    #noise_texture.Fac -> alpha_control.Fac
	    procedural_hair.links.new(noise_texture.outputs[0], alpha_control.inputs[0])
	    #group_input.Detail -> noise_texture.Detail
	    procedural_hair.links.new(group_input.outputs[4], noise_texture.inputs[3])
	    #group_input.Roughness -> noise_texture.Roughness
	    procedural_hair.links.new(group_input.outputs[5], noise_texture.inputs[4])
	    #group_input.Lacunarity -> noise_texture.Lacunarity
	    procedural_hair.links.new(group_input.outputs[6], noise_texture.inputs[5])
	    #group_input.Distortion -> noise_texture.Distortion
	    procedural_hair.links.new(group_input.outputs[7], noise_texture.inputs[8])
	    #group_input_001.Base Color -> principled_bsdf.Base Color
	    procedural_hair.links.new(group_input_001.outputs[0], principled_bsdf.inputs[0])
	    #group_input.Scale -> noise_texture.Scale
	    procedural_hair.links.new(group_input.outputs[3], noise_texture.inputs[2])
	    #alpha_control.Color -> principled_bsdf.Alpha
	    procedural_hair.links.new(alpha_control.outputs[0], principled_bsdf.inputs[4])
	    #alpha_control.Color -> group_output.Alpha
	    procedural_hair.links.new(alpha_control.outputs[0], group_output.inputs[1])
	    #bump.Normal -> group_output.Normal
	    procedural_hair.links.new(bump.outputs[0], group_output.inputs[2])
	    #group_input_003.Roughness -> principled_bsdf.Roughness
	    procedural_hair.links.new(group_input_003.outputs[5], principled_bsdf.inputs[2])
	    #noise_texture.Color -> mix.A
	    procedural_hair.links.new(noise_texture.outputs[1], mix.inputs[6])
	    #group_input_004.Base Color -> mix.B
	    procedural_hair.links.new(group_input_004.outputs[0], mix.inputs[7])
	    #noise_texture.Color -> group_output.noise
	    procedural_hair.links.new(noise_texture.outputs[1], group_output.inputs[3])
	    #mix.Result -> principled_bsdf.Specular Tint
	    procedural_hair.links.new(mix.outputs[2], principled_bsdf.inputs[14])
	    return procedural_hair
	
	procedural_hair = procedural_hair_node_group()
	
	#initialize Procedural_Mesh_Hair_Shader_Plus node group
	def procedural_mesh_hair_shader_plus_node_group():
	
	    procedural_mesh_hair_shader_plus = bpy.data.node_groups.new(type = 'ShaderNodeTree', name = "Procedural_Mesh_Hair_Shader_Plus")
	
	    procedural_mesh_hair_shader_plus.color_tag = 'NONE'
	    procedural_mesh_hair_shader_plus.description = ""
	    procedural_mesh_hair_shader_plus.default_group_node_width = 140
	    
	
	    #procedural_mesh_hair_shader_plus interface
	    #Socket Shader
	    shader_socket_1 = procedural_mesh_hair_shader_plus.interface.new_socket(name = "Shader", in_out='OUTPUT', socket_type = 'NodeSocketShader')
	    shader_socket_1.attribute_domain = 'POINT'
	
	    #Socket Normal
	    normal_socket_1 = procedural_mesh_hair_shader_plus.interface.new_socket(name = "Normal", in_out='OUTPUT', socket_type = 'NodeSocketColor')
	    normal_socket_1.default_value = (0.800000011920929, 0.800000011920929, 0.800000011920929, 1.0)
	    normal_socket_1.attribute_domain = 'POINT'
	
	    #Socket Alpha Color
	    alpha_color_socket = procedural_mesh_hair_shader_plus.interface.new_socket(name = "Alpha Color", in_out='OUTPUT', socket_type = 'NodeSocketColor')
	    alpha_color_socket.default_value = (0.0, 0.0, 0.0, 1.0)
	    alpha_color_socket.attribute_domain = 'POINT'
	
	    #Socket Alpha Shader
	    alpha_shader_socket = procedural_mesh_hair_shader_plus.interface.new_socket(name = "Alpha Shader", in_out='OUTPUT', socket_type = 'NodeSocketShader')
	    alpha_shader_socket.attribute_domain = 'POINT'
	
	    #Socket Base Color
	    base_color_socket_1 = procedural_mesh_hair_shader_plus.interface.new_socket(name = "Base Color", in_out='INPUT', socket_type = 'NodeSocketColor')
	    base_color_socket_1.default_value = (0.5, 0.5, 0.5, 1.0)
	    base_color_socket_1.attribute_domain = 'POINT'
	
	    #Socket Alpha Visibility
	    alpha_visibility_socket = procedural_mesh_hair_shader_plus.interface.new_socket(name = "Alpha Visibility", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    alpha_visibility_socket.default_value = 1.0
	    alpha_visibility_socket.min_value = 0.0
	    alpha_visibility_socket.max_value = 1.0
	    alpha_visibility_socket.subtype = 'FACTOR'
	    alpha_visibility_socket.attribute_domain = 'POINT'
	
	    #Socket Vector
	    vector_socket_1 = procedural_mesh_hair_shader_plus.interface.new_socket(name = "Vector", in_out='INPUT', socket_type = 'NodeSocketVector')
	    vector_socket_1.default_value = (0.0, 0.0, 0.0)
	    vector_socket_1.min_value = -3.4028234663852886e+38
	    vector_socket_1.max_value = 3.4028234663852886e+38
	    vector_socket_1.subtype = 'NONE'
	    vector_socket_1.attribute_domain = 'POINT'
	
	    #Socket Minor Location
	    minor_location_socket = procedural_mesh_hair_shader_plus.interface.new_socket(name = "Minor Location", in_out='INPUT', socket_type = 'NodeSocketVector')
	    minor_location_socket.default_value = (0.29999998211860657, 7.199999809265137, -3.299999713897705)
	    minor_location_socket.min_value = -3.4028234663852886e+38
	    minor_location_socket.max_value = 3.4028234663852886e+38
	    minor_location_socket.subtype = 'TRANSLATION'
	    minor_location_socket.attribute_domain = 'POINT'
	
	    #Socket Minor Scale
	    minor_scale_socket = procedural_mesh_hair_shader_plus.interface.new_socket(name = "Minor Scale", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    minor_scale_socket.default_value = 5.0
	    minor_scale_socket.min_value = -1000.0
	    minor_scale_socket.max_value = 1000.0
	    minor_scale_socket.subtype = 'NONE'
	    minor_scale_socket.attribute_domain = 'POINT'
	
	    #Socket Minor Detail
	    minor_detail_socket = procedural_mesh_hair_shader_plus.interface.new_socket(name = "Minor Detail", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    minor_detail_socket.default_value = 2.0
	    minor_detail_socket.min_value = 0.0
	    minor_detail_socket.max_value = 15.0
	    minor_detail_socket.subtype = 'NONE'
	    minor_detail_socket.attribute_domain = 'POINT'
	
	    #Socket Minor Roughness
	    minor_roughness_socket = procedural_mesh_hair_shader_plus.interface.new_socket(name = "Minor Roughness", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    minor_roughness_socket.default_value = 0.10000000149011612
	    minor_roughness_socket.min_value = 0.0
	    minor_roughness_socket.max_value = 1.0
	    minor_roughness_socket.subtype = 'FACTOR'
	    minor_roughness_socket.attribute_domain = 'POINT'
	
	    #Socket Minor Lacunarity
	    minor_lacunarity_socket = procedural_mesh_hair_shader_plus.interface.new_socket(name = "Minor Lacunarity", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    minor_lacunarity_socket.default_value = 2.0
	    minor_lacunarity_socket.min_value = 0.0
	    minor_lacunarity_socket.max_value = 1000.0
	    minor_lacunarity_socket.subtype = 'NONE'
	    minor_lacunarity_socket.attribute_domain = 'POINT'
	
	    #Socket Minor Distortion
	    minor_distortion_socket = procedural_mesh_hair_shader_plus.interface.new_socket(name = "Minor Distortion", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    minor_distortion_socket.default_value = 0.0
	    minor_distortion_socket.min_value = -1000.0
	    minor_distortion_socket.max_value = 1000.0
	    minor_distortion_socket.subtype = 'NONE'
	    minor_distortion_socket.attribute_domain = 'POINT'
	
	    #Socket Major Location Offset
	    major_location_offset_socket = procedural_mesh_hair_shader_plus.interface.new_socket(name = "Major Location Offset", in_out='INPUT', socket_type = 'NodeSocketVector')
	    major_location_offset_socket.default_value = (0.0, 0.0, 5.0)
	    major_location_offset_socket.min_value = -10000.0
	    major_location_offset_socket.max_value = 10000.0
	    major_location_offset_socket.subtype = 'NONE'
	    major_location_offset_socket.attribute_domain = 'POINT'
	
	    #Socket Major Scale
	    major_scale_socket = procedural_mesh_hair_shader_plus.interface.new_socket(name = "Major Scale", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    major_scale_socket.default_value = 1.0
	    major_scale_socket.min_value = -1000.0
	    major_scale_socket.max_value = 1000.0
	    major_scale_socket.subtype = 'NONE'
	    major_scale_socket.attribute_domain = 'POINT'
	
	    #Socket Major Detail
	    major_detail_socket = procedural_mesh_hair_shader_plus.interface.new_socket(name = "Major Detail", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    major_detail_socket.default_value = 5.0
	    major_detail_socket.min_value = 0.0
	    major_detail_socket.max_value = 15.0
	    major_detail_socket.subtype = 'NONE'
	    major_detail_socket.attribute_domain = 'POINT'
	
	    #Socket Major Roughness
	    major_roughness_socket = procedural_mesh_hair_shader_plus.interface.new_socket(name = "Major Roughness", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    major_roughness_socket.default_value = 0.5
	    major_roughness_socket.min_value = 0.0
	    major_roughness_socket.max_value = 1.0
	    major_roughness_socket.subtype = 'FACTOR'
	    major_roughness_socket.attribute_domain = 'POINT'
	
	    #Socket Major Lacunarity
	    major_lacunarity_socket = procedural_mesh_hair_shader_plus.interface.new_socket(name = "Major Lacunarity", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    major_lacunarity_socket.default_value = 2.0
	    major_lacunarity_socket.min_value = 0.0
	    major_lacunarity_socket.max_value = 1000.0
	    major_lacunarity_socket.subtype = 'NONE'
	    major_lacunarity_socket.attribute_domain = 'POINT'
	
	    #Socket Major Distortion
	    major_distortion_socket = procedural_mesh_hair_shader_plus.interface.new_socket(name = "Major Distortion", in_out='INPUT', socket_type = 'NodeSocketFloat')
	    major_distortion_socket.default_value = 0.0
	    major_distortion_socket.min_value = -1000.0
	    major_distortion_socket.max_value = 1000.0
	    major_distortion_socket.subtype = 'NONE'
	    major_distortion_socket.attribute_domain = 'POINT'
	
	
	    #initialize procedural_mesh_hair_shader_plus nodes
	    #node Group Output
	    group_output_1 = procedural_mesh_hair_shader_plus.nodes.new("NodeGroupOutput")
	    group_output_1.name = "Group Output"
	    group_output_1.is_active_output = True
	    group_output_1.inputs[4].hide = True
	
	    #node Mix Shader.003
	    mix_shader_003 = procedural_mesh_hair_shader_plus.nodes.new("ShaderNodeMixShader")
	    mix_shader_003.name = "Mix Shader.003"
	
	    #node Transparent BSDF.001
	    transparent_bsdf_001 = procedural_mesh_hair_shader_plus.nodes.new("ShaderNodeBsdfTransparent")
	    transparent_bsdf_001.name = "Transparent BSDF.001"
	    #Color
	    transparent_bsdf_001.inputs[0].default_value = (1.0, 1.0, 1.0, 1.0)
	
	    #node Invert Color.001
	    invert_color_001 = procedural_mesh_hair_shader_plus.nodes.new("ShaderNodeInvert")
	    invert_color_001.name = "Invert Color.001"
	    #Fac
	    invert_color_001.inputs[0].default_value = 1.0
	
	    #node Mix Shader.004
	    mix_shader_004 = procedural_mesh_hair_shader_plus.nodes.new("ShaderNodeMixShader")
	    mix_shader_004.name = "Mix Shader.004"
	
	    #node Group Input.001
	    group_input_001_1 = procedural_mesh_hair_shader_plus.nodes.new("NodeGroupInput")
	    group_input_001_1.name = "Group Input.001"
	    group_input_001_1.outputs[1].hide = True
	    group_input_001_1.outputs[9].hide = True
	    group_input_001_1.outputs[10].hide = True
	    group_input_001_1.outputs[11].hide = True
	    group_input_001_1.outputs[12].hide = True
	    group_input_001_1.outputs[13].hide = True
	    group_input_001_1.outputs[14].hide = True
	    group_input_001_1.outputs[15].hide = True
	
	    #node Group Input.002
	    group_input_002 = procedural_mesh_hair_shader_plus.nodes.new("NodeGroupInput")
	    group_input_002.name = "Group Input.002"
	    group_input_002.outputs[0].hide = True
	    group_input_002.outputs[2].hide = True
	    group_input_002.outputs[3].hide = True
	    group_input_002.outputs[4].hide = True
	    group_input_002.outputs[5].hide = True
	    group_input_002.outputs[6].hide = True
	    group_input_002.outputs[7].hide = True
	    group_input_002.outputs[8].hide = True
	    group_input_002.outputs[9].hide = True
	    group_input_002.outputs[10].hide = True
	    group_input_002.outputs[11].hide = True
	    group_input_002.outputs[12].hide = True
	    group_input_002.outputs[13].hide = True
	    group_input_002.outputs[14].hide = True
	    group_input_002.outputs[15].hide = True
	
	    #node Group.002
	    group_002 = procedural_mesh_hair_shader_plus.nodes.new("ShaderNodeGroup")
	    group_002.name = "Group.002"
	    group_002.node_tree = procedural_hair
	    group_002.inputs[0].hide = True
	    group_002.outputs[0].hide = True
	    #Socket_4
	    group_002.inputs[0].default_value = (0.800000011920929, 0.800000011920929, 0.800000011920929, 1.0)
	
	    #node Principled BSDF.003
	    principled_bsdf_003 = procedural_mesh_hair_shader_plus.nodes.new("ShaderNodeBsdfPrincipled")
	    principled_bsdf_003.name = "Principled BSDF.003"
	    principled_bsdf_003.distribution = 'MULTI_GGX'
	    principled_bsdf_003.subsurface_method = 'RANDOM_WALK'
	    #Metallic
	    principled_bsdf_003.inputs[1].default_value = 0.0
	    #IOR
	    principled_bsdf_003.inputs[3].default_value = 1.5
	    #Diffuse Roughness
	    principled_bsdf_003.inputs[7].default_value = 0.0
	    #Subsurface Weight
	    principled_bsdf_003.inputs[8].default_value = 0.0
	    #Subsurface Radius
	    principled_bsdf_003.inputs[9].default_value = (1.0, 0.20000000298023224, 0.10000000149011612)
	    #Subsurface Scale
	    principled_bsdf_003.inputs[10].default_value = 0.05000000074505806
	    #Subsurface Anisotropy
	    principled_bsdf_003.inputs[12].default_value = 0.0
	    #Specular IOR Level
	    principled_bsdf_003.inputs[13].default_value = 0.5
	    #Anisotropic
	    principled_bsdf_003.inputs[15].default_value = -1.0
	    #Anisotropic Rotation
	    principled_bsdf_003.inputs[16].default_value = 0.0
	    #Transmission Weight
	    principled_bsdf_003.inputs[18].default_value = 0.0
	    #Coat Weight
	    principled_bsdf_003.inputs[19].default_value = 0.0
	    #Coat Roughness
	    principled_bsdf_003.inputs[20].default_value = 0.029999999329447746
	    #Coat IOR
	    principled_bsdf_003.inputs[21].default_value = 1.5
	    #Coat Tint
	    principled_bsdf_003.inputs[22].default_value = (1.0, 1.0, 1.0, 1.0)
	    #Coat Normal
	    principled_bsdf_003.inputs[23].default_value = (0.0, 0.0, 0.0)
	    #Sheen Weight
	    principled_bsdf_003.inputs[24].default_value = 0.0
	    #Sheen Roughness
	    principled_bsdf_003.inputs[25].default_value = 0.5
	    #Sheen Tint
	    principled_bsdf_003.inputs[26].default_value = (1.0, 1.0, 1.0, 1.0)
	    #Emission Color
	    principled_bsdf_003.inputs[27].default_value = (1.0, 1.0, 1.0, 1.0)
	    #Emission Strength
	    principled_bsdf_003.inputs[28].default_value = 0.0
	    #Thin Film Thickness
	    principled_bsdf_003.inputs[29].default_value = 0.0
	    #Thin Film IOR
	    principled_bsdf_003.inputs[30].default_value = 1.3300000429153442
	
	    #node Mapping.004
	    mapping_004 = procedural_mesh_hair_shader_plus.nodes.new("ShaderNodeMapping")
	    mapping_004.name = "Mapping.004"
	    mapping_004.vector_type = 'POINT'
	    mapping_004.inputs[1].hide = True
	    mapping_004.inputs[2].hide = True
	    mapping_004.inputs[3].hide = True
	    #Location
	    mapping_004.inputs[1].default_value = (0.0, 0.0, 0.0)
	    #Rotation
	    mapping_004.inputs[2].default_value = (0.0, 0.0, 0.0)
	    #Scale
	    mapping_004.inputs[3].default_value = (1.0, 2.0, 1.0)
	
	    #node Group.003
	    group_003 = procedural_mesh_hair_shader_plus.nodes.new("ShaderNodeGroup")
	    group_003.name = "Group.003"
	    group_003.node_tree = procedural_hair
	    group_003.outputs[0].hide = True
	    group_003.outputs[3].hide = True
	
	    #node Mix.004
	    mix_004 = procedural_mesh_hair_shader_plus.nodes.new("ShaderNodeMix")
	    mix_004.name = "Mix.004"
	    mix_004.blend_type = 'ADD'
	    mix_004.clamp_factor = False
	    mix_004.clamp_result = False
	    mix_004.data_type = 'RGBA'
	    mix_004.factor_mode = 'UNIFORM'
	    #Factor_Float
	    mix_004.inputs[0].default_value = 1.0
	
	    #node Alpha Blend
	    alpha_blend = procedural_mesh_hair_shader_plus.nodes.new("ShaderNodeValToRGB")
	    alpha_blend.label = "Alpha Blend"
	    alpha_blend.name = "Alpha Blend"
	    alpha_blend.color_ramp.color_mode = 'RGB'
	    alpha_blend.color_ramp.hue_interpolation = 'NEAR'
	    alpha_blend.color_ramp.interpolation = 'LINEAR'
	
	    #initialize color ramp elements
	    alpha_blend.color_ramp.elements.remove(alpha_blend.color_ramp.elements[0])
	    alpha_blend_cre_0 = alpha_blend.color_ramp.elements[0]
	    alpha_blend_cre_0.position = 0.3365701735019684
	    alpha_blend_cre_0.alpha = 1.0
	    alpha_blend_cre_0.color = (0.0, 0.0, 0.0, 1.0)
	
	    alpha_blend_cre_1 = alpha_blend.color_ramp.elements.new(1.0)
	    alpha_blend_cre_1.alpha = 1.0
	    alpha_blend_cre_1.color = (1.0, 1.0, 1.0, 1.0)
	
	
	    #node Mix.005
	    mix_005 = procedural_mesh_hair_shader_plus.nodes.new("ShaderNodeMix")
	    mix_005.name = "Mix.005"
	    mix_005.blend_type = 'ADD'
	    mix_005.clamp_factor = False
	    mix_005.clamp_result = False
	    mix_005.data_type = 'RGBA'
	    mix_005.factor_mode = 'UNIFORM'
	    #Factor_Float
	    mix_005.inputs[0].default_value = 1.0
	
	    #node Mix.006
	    mix_006 = procedural_mesh_hair_shader_plus.nodes.new("ShaderNodeMix")
	    mix_006.name = "Mix.006"
	    mix_006.blend_type = 'DODGE'
	    mix_006.clamp_factor = False
	    mix_006.clamp_result = False
	    mix_006.data_type = 'RGBA'
	    mix_006.factor_mode = 'UNIFORM'
	
	    #node Vector Math.001
	    vector_math_001 = procedural_mesh_hair_shader_plus.nodes.new("ShaderNodeVectorMath")
	    vector_math_001.name = "Vector Math.001"
	    vector_math_001.operation = 'ADD'
	
	    #node Invert Color.006
	    invert_color_006 = procedural_mesh_hair_shader_plus.nodes.new("ShaderNodeInvert")
	    invert_color_006.name = "Invert Color.006"
	    #Fac
	    invert_color_006.inputs[0].default_value = 1.0
	
	    #node Invert Color.007
	    invert_color_007 = procedural_mesh_hair_shader_plus.nodes.new("ShaderNodeInvert")
	    invert_color_007.name = "Invert Color.007"
	    #Fac
	    invert_color_007.inputs[0].default_value = 1.0
	
	    #node Mix.007
	    mix_007 = procedural_mesh_hair_shader_plus.nodes.new("ShaderNodeMix")
	    mix_007.name = "Mix.007"
	    mix_007.blend_type = 'ADD'
	    mix_007.clamp_factor = False
	    mix_007.clamp_result = False
	    mix_007.data_type = 'RGBA'
	    mix_007.factor_mode = 'UNIFORM'
	    #Factor_Float
	    mix_007.inputs[0].default_value = 1.0
	
	    #node Gradient Texture.001
	    gradient_texture_001 = procedural_mesh_hair_shader_plus.nodes.new("ShaderNodeTexGradient")
	    gradient_texture_001.name = "Gradient Texture.001"
	    gradient_texture_001.gradient_type = 'LINEAR'
	    gradient_texture_001.outputs[0].hide = True
	
	    #node Tip Mask
	    tip_mask = procedural_mesh_hair_shader_plus.nodes.new("ShaderNodeValToRGB")
	    tip_mask.label = "Tip Mask"
	    tip_mask.name = "Tip Mask"
	    tip_mask.color_ramp.color_mode = 'RGB'
	    tip_mask.color_ramp.hue_interpolation = 'NEAR'
	    tip_mask.color_ramp.interpolation = 'B_SPLINE'
	
	    #initialize color ramp elements
	    tip_mask.color_ramp.elements.remove(tip_mask.color_ramp.elements[0])
	    tip_mask_cre_0 = tip_mask.color_ramp.elements[0]
	    tip_mask_cre_0.position = 0.8999999761581421
	    tip_mask_cre_0.alpha = 1.0
	    tip_mask_cre_0.color = (0.0, 0.0, 0.0, 1.0)
	
	    tip_mask_cre_1 = tip_mask.color_ramp.elements.new(1.0)
	    tip_mask_cre_1.alpha = 1.0
	    tip_mask_cre_1.color = (1.0, 1.0, 1.0, 1.0)
	
	
	    #node Mix.008
	    mix_008 = procedural_mesh_hair_shader_plus.nodes.new("ShaderNodeMix")
	    mix_008.name = "Mix.008"
	    mix_008.blend_type = 'ADD'
	    mix_008.clamp_factor = False
	    mix_008.clamp_result = False
	    mix_008.data_type = 'RGBA'
	    mix_008.factor_mode = 'UNIFORM'
	    #Factor_Float
	    mix_008.inputs[0].default_value = 1.0
	
	    #node Base Mask
	    base_mask = procedural_mesh_hair_shader_plus.nodes.new("ShaderNodeValToRGB")
	    base_mask.label = "Base Mask"
	    base_mask.name = "Base Mask"
	    base_mask.color_ramp.color_mode = 'RGB'
	    base_mask.color_ramp.hue_interpolation = 'NEAR'
	    base_mask.color_ramp.interpolation = 'B_SPLINE'
	
	    #initialize color ramp elements
	    base_mask.color_ramp.elements.remove(base_mask.color_ramp.elements[0])
	    base_mask_cre_0 = base_mask.color_ramp.elements[0]
	    base_mask_cre_0.position = 0.0
	    base_mask_cre_0.alpha = 1.0
	    base_mask_cre_0.color = (1.0, 1.0, 1.0, 1.0)
	
	    base_mask_cre_1 = base_mask.color_ramp.elements.new(9.999999747378752e-05)
	    base_mask_cre_1.alpha = 1.0
	    base_mask_cre_1.color = (0.0, 0.0, 0.0, 1.0)
	
	
	    #node Mapping.005
	    mapping_005 = procedural_mesh_hair_shader_plus.nodes.new("ShaderNodeMapping")
	    mapping_005.name = "Mapping.005"
	    mapping_005.vector_type = 'POINT'
	    mapping_005.inputs[1].hide = True
	    mapping_005.inputs[2].hide = True
	    mapping_005.inputs[3].hide = True
	    #Location
	    mapping_005.inputs[1].default_value = (0.0, 0.0, 0.0)
	    #Rotation
	    mapping_005.inputs[2].default_value = (0.0, 0.0, 1.5707963705062866)
	    #Scale
	    mapping_005.inputs[3].default_value = (1.0, 1.0, 1.0)
	
	    #node Principled BSDF.004
	    principled_bsdf_004 = procedural_mesh_hair_shader_plus.nodes.new("ShaderNodeBsdfPrincipled")
	    principled_bsdf_004.name = "Principled BSDF.004"
	    principled_bsdf_004.distribution = 'GGX'
	    principled_bsdf_004.subsurface_method = 'RANDOM_WALK'
	    principled_bsdf_004.inputs[1].hide = True
	    principled_bsdf_004.inputs[3].hide = True
	    principled_bsdf_004.inputs[4].hide = True
	    principled_bsdf_004.inputs[6].hide = True
	    principled_bsdf_004.inputs[8].hide = True
	    principled_bsdf_004.inputs[9].hide = True
	    principled_bsdf_004.inputs[10].hide = True
	    principled_bsdf_004.inputs[11].hide = True
	    principled_bsdf_004.inputs[12].hide = True
	    principled_bsdf_004.inputs[13].hide = True
	    principled_bsdf_004.inputs[15].hide = True
	    principled_bsdf_004.inputs[16].hide = True
	    principled_bsdf_004.inputs[18].hide = True
	    principled_bsdf_004.inputs[19].hide = True
	    principled_bsdf_004.inputs[20].hide = True
	    principled_bsdf_004.inputs[21].hide = True
	    principled_bsdf_004.inputs[22].hide = True
	    principled_bsdf_004.inputs[23].hide = True
	    principled_bsdf_004.inputs[24].hide = True
	    principled_bsdf_004.inputs[25].hide = True
	    principled_bsdf_004.inputs[26].hide = True
	    principled_bsdf_004.inputs[27].hide = True
	    principled_bsdf_004.inputs[28].hide = True
	    principled_bsdf_004.inputs[29].hide = True
	    principled_bsdf_004.inputs[30].hide = True
	    #Metallic
	    principled_bsdf_004.inputs[1].default_value = 0.0
	    #IOR
	    principled_bsdf_004.inputs[3].default_value = 1.5
	    #Alpha
	    principled_bsdf_004.inputs[4].default_value = 1.0
	    #Diffuse Roughness
	    principled_bsdf_004.inputs[7].default_value = 0.0
	    #Subsurface Weight
	    principled_bsdf_004.inputs[8].default_value = 0.0
	    #Subsurface Radius
	    principled_bsdf_004.inputs[9].default_value = (1.0, 0.20000000298023224, 0.10000000149011612)
	    #Subsurface Scale
	    principled_bsdf_004.inputs[10].default_value = 0.05000000074505806
	    #Subsurface Anisotropy
	    principled_bsdf_004.inputs[12].default_value = 0.0
	    #Specular IOR Level
	    principled_bsdf_004.inputs[13].default_value = 0.5
	    #Anisotropic
	    principled_bsdf_004.inputs[15].default_value = -1.0
	    #Anisotropic Rotation
	    principled_bsdf_004.inputs[16].default_value = 0.0
	    #Transmission Weight
	    principled_bsdf_004.inputs[18].default_value = 0.0
	    #Coat Weight
	    principled_bsdf_004.inputs[19].default_value = 0.0
	    #Coat Roughness
	    principled_bsdf_004.inputs[20].default_value = 0.029999999329447746
	    #Coat IOR
	    principled_bsdf_004.inputs[21].default_value = 1.5
	    #Coat Tint
	    principled_bsdf_004.inputs[22].default_value = (1.0, 1.0, 1.0, 1.0)
	    #Coat Normal
	    principled_bsdf_004.inputs[23].default_value = (0.0, 0.0, 0.0)
	    #Sheen Weight
	    principled_bsdf_004.inputs[24].default_value = 0.0
	    #Sheen Roughness
	    principled_bsdf_004.inputs[25].default_value = 0.5
	    #Sheen Tint
	    principled_bsdf_004.inputs[26].default_value = (1.0, 1.0, 1.0, 1.0)
	    #Emission Color
	    principled_bsdf_004.inputs[27].default_value = (1.0, 1.0, 1.0, 1.0)
	    #Emission Strength
	    principled_bsdf_004.inputs[28].default_value = 0.0
	    #Thin Film Thickness
	    principled_bsdf_004.inputs[29].default_value = 0.0
	    #Thin Film IOR
	    principled_bsdf_004.inputs[30].default_value = 1.3300000429153442
	
	    #node Group Input.003
	    group_input_003_1 = procedural_mesh_hair_shader_plus.nodes.new("NodeGroupInput")
	    group_input_003_1.name = "Group Input.003"
	    group_input_003_1.outputs[1].hide = True
	    group_input_003_1.outputs[2].hide = True
	    group_input_003_1.outputs[3].hide = True
	    group_input_003_1.outputs[4].hide = True
	    group_input_003_1.outputs[5].hide = True
	    group_input_003_1.outputs[6].hide = True
	    group_input_003_1.outputs[7].hide = True
	    group_input_003_1.outputs[8].hide = True
	    group_input_003_1.outputs[9].hide = True
	    group_input_003_1.outputs[15].hide = True
	
	    #node Group Input.004
	    group_input_004_1 = procedural_mesh_hair_shader_plus.nodes.new("NodeGroupInput")
	    group_input_004_1.name = "Group Input.004"
	    group_input_004_1.outputs[0].hide = True
	    group_input_004_1.outputs[1].hide = True
	    group_input_004_1.outputs[4].hide = True
	    group_input_004_1.outputs[5].hide = True
	    group_input_004_1.outputs[6].hide = True
	    group_input_004_1.outputs[7].hide = True
	    group_input_004_1.outputs[8].hide = True
	    group_input_004_1.outputs[10].hide = True
	    group_input_004_1.outputs[11].hide = True
	    group_input_004_1.outputs[12].hide = True
	    group_input_004_1.outputs[13].hide = True
	    group_input_004_1.outputs[14].hide = True
	    group_input_004_1.outputs[15].hide = True
	
	    #node Group Input.005
	    group_input_005 = procedural_mesh_hair_shader_plus.nodes.new("NodeGroupInput")
	    group_input_005.name = "Group Input.005"
	    group_input_005.outputs[0].hide = True
	    group_input_005.outputs[1].hide = True
	    group_input_005.outputs[3].hide = True
	    group_input_005.outputs[4].hide = True
	    group_input_005.outputs[5].hide = True
	    group_input_005.outputs[6].hide = True
	    group_input_005.outputs[7].hide = True
	    group_input_005.outputs[8].hide = True
	    group_input_005.outputs[9].hide = True
	    group_input_005.outputs[10].hide = True
	    group_input_005.outputs[11].hide = True
	    group_input_005.outputs[12].hide = True
	    group_input_005.outputs[13].hide = True
	    group_input_005.outputs[14].hide = True
	    group_input_005.outputs[15].hide = True
	
	    #node Ambient Occlusion
	    ambient_occlusion = procedural_mesh_hair_shader_plus.nodes.new("ShaderNodeAmbientOcclusion")
	    ambient_occlusion.name = "Ambient Occlusion"
	    ambient_occlusion.inside = False
	    ambient_occlusion.only_local = False
	    ambient_occlusion.samples = 16
	    #Color
	    ambient_occlusion.inputs[0].default_value = (1.0, 1.0, 1.0, 1.0)
	    #Distance
	    ambient_occlusion.inputs[1].default_value = 1.0
	
	    #node Roughness Blend
	    roughness_blend = procedural_mesh_hair_shader_plus.nodes.new("ShaderNodeValToRGB")
	    roughness_blend.label = "Roughness Blend"
	    roughness_blend.name = "Roughness Blend"
	    roughness_blend.color_ramp.color_mode = 'RGB'
	    roughness_blend.color_ramp.hue_interpolation = 'NEAR'
	    roughness_blend.color_ramp.interpolation = 'B_SPLINE'
	
	    #initialize color ramp elements
	    roughness_blend.color_ramp.elements.remove(roughness_blend.color_ramp.elements[0])
	    roughness_blend_cre_0 = roughness_blend.color_ramp.elements[0]
	    roughness_blend_cre_0.position = 0.0
	    roughness_blend_cre_0.alpha = 1.0
	    roughness_blend_cre_0.color = (1.0, 1.0, 1.0, 1.0)
	
	    roughness_blend_cre_1 = roughness_blend.color_ramp.elements.new(0.6574879288673401)
	    roughness_blend_cre_1.alpha = 1.0
	    roughness_blend_cre_1.color = (0.0, 0.0, 0.0, 1.0)
	
	
	    #node Frame
	    frame = procedural_mesh_hair_shader_plus.nodes.new("NodeFrame")
	    frame.label = "Tip | Base Alphas"
	    frame.name = "Frame"
	    frame.label_size = 20
	    frame.shrink = True
	
	    #node Tint Blend
	    tint_blend = procedural_mesh_hair_shader_plus.nodes.new("ShaderNodeValToRGB")
	    tint_blend.label = "Tint Blend"
	    tint_blend.name = "Tint Blend"
	    tint_blend.color_ramp.color_mode = 'RGB'
	    tint_blend.color_ramp.hue_interpolation = 'NEAR'
	    tint_blend.color_ramp.interpolation = 'LINEAR'
	
	    #initialize color ramp elements
	    tint_blend.color_ramp.elements.remove(tint_blend.color_ramp.elements[0])
	    tint_blend_cre_0 = tint_blend.color_ramp.elements[0]
	    tint_blend_cre_0.position = 0.0
	    tint_blend_cre_0.alpha = 1.0
	    tint_blend_cre_0.color = (0.0, 0.0, 0.0, 1.0)
	
	    tint_blend_cre_1 = tint_blend.color_ramp.elements.new(0.05000000074505806)
	    tint_blend_cre_1.alpha = 1.0
	    tint_blend_cre_1.color = (1.0, 1.0, 1.0, 1.0)
	
	
	    #node Invert Color.009
	    invert_color_009 = procedural_mesh_hair_shader_plus.nodes.new("ShaderNodeInvert")
	    invert_color_009.name = "Invert Color.009"
	    #Fac
	    invert_color_009.inputs[0].default_value = 1.0
	
	    #node Reroute
	    reroute = procedural_mesh_hair_shader_plus.nodes.new("NodeReroute")
	    reroute.name = "Reroute"
	    reroute.socket_idname = "NodeSocketColor"
	    #node Reroute.001
	    reroute_001 = procedural_mesh_hair_shader_plus.nodes.new("NodeReroute")
	    reroute_001.name = "Reroute.001"
	    reroute_001.socket_idname = "NodeSocketVector"
	    #node Reroute.002
	    reroute_002 = procedural_mesh_hair_shader_plus.nodes.new("NodeReroute")
	    reroute_002.name = "Reroute.002"
	    reroute_002.socket_idname = "NodeSocketColor"
	    #node Reroute.003
	    reroute_003 = procedural_mesh_hair_shader_plus.nodes.new("NodeReroute")
	    reroute_003.name = "Reroute.003"
	    reroute_003.socket_idname = "NodeSocketColor"
	    #node Frame.001
	    frame_001 = procedural_mesh_hair_shader_plus.nodes.new("NodeFrame")
	    frame_001.label = "Shine"
	    frame_001.name = "Frame.001"
	    frame_001.label_size = 20
	    frame_001.shrink = True
	
	    #node Reroute.004
	    reroute_004 = procedural_mesh_hair_shader_plus.nodes.new("NodeReroute")
	    reroute_004.name = "Reroute.004"
	    reroute_004.socket_idname = "NodeSocketColor"
	    #node Reroute.005
	    reroute_005 = procedural_mesh_hair_shader_plus.nodes.new("NodeReroute")
	    reroute_005.name = "Reroute.005"
	    reroute_005.socket_idname = "NodeSocketColor"
	    #node Reroute.006
	    reroute_006 = procedural_mesh_hair_shader_plus.nodes.new("NodeReroute")
	    reroute_006.name = "Reroute.006"
	    reroute_006.socket_idname = "NodeSocketColor"
	    #node Reroute.007
	    reroute_007 = procedural_mesh_hair_shader_plus.nodes.new("NodeReroute")
	    reroute_007.name = "Reroute.007"
	    reroute_007.socket_idname = "NodeSocketColor"
	    #node Strand Thickness
	    strand_thickness = procedural_mesh_hair_shader_plus.nodes.new("ShaderNodeValToRGB")
	    strand_thickness.label = "Strand Thickness"
	    strand_thickness.name = "Strand Thickness"
	    strand_thickness.color_ramp.color_mode = 'RGB'
	    strand_thickness.color_ramp.hue_interpolation = 'NEAR'
	    strand_thickness.color_ramp.interpolation = 'LINEAR'
	
	    #initialize color ramp elements
	    strand_thickness.color_ramp.elements.remove(strand_thickness.color_ramp.elements[0])
	    strand_thickness_cre_0 = strand_thickness.color_ramp.elements[0]
	    strand_thickness_cre_0.position = 0.0
	    strand_thickness_cre_0.alpha = 1.0
	    strand_thickness_cre_0.color = (0.0, 0.0, 0.0, 1.0)
	
	    strand_thickness_cre_1 = strand_thickness.color_ramp.elements.new(1.0)
	    strand_thickness_cre_1.alpha = 1.0
	    strand_thickness_cre_1.color = (1.0, 1.0, 1.0, 1.0)
	
	
	    #node Map Range
	    map_range = procedural_mesh_hair_shader_plus.nodes.new("ShaderNodeMapRange")
	    map_range.name = "Map Range"
	    map_range.hide = True
	    map_range.clamp = True
	    map_range.data_type = 'FLOAT'
	    map_range.interpolation_type = 'LINEAR'
	    map_range.inputs[1].hide = True
	    map_range.inputs[2].hide = True
	    map_range.inputs[3].hide = True
	    map_range.inputs[5].hide = True
	    map_range.inputs[6].hide = True
	    map_range.inputs[7].hide = True
	    map_range.inputs[8].hide = True
	    map_range.inputs[9].hide = True
	    map_range.inputs[10].hide = True
	    map_range.inputs[11].hide = True
	    map_range.outputs[1].hide = True
	    #From Min
	    map_range.inputs[1].default_value = 0.0
	    #From Max
	    map_range.inputs[2].default_value = 1.0
	    #To Min
	    map_range.inputs[3].default_value = 0.0
	
	    #node Gradient Texture
	    gradient_texture = procedural_mesh_hair_shader_plus.nodes.new("ShaderNodeTexGradient")
	    gradient_texture.name = "Gradient Texture"
	    gradient_texture.gradient_type = 'LINEAR'
	    gradient_texture.outputs[0].hide = True
	
	    #node Alpha Fade
	    alpha_fade = procedural_mesh_hair_shader_plus.nodes.new("ShaderNodeValToRGB")
	    alpha_fade.label = "Alpha Fade"
	    alpha_fade.name = "Alpha Fade"
	    alpha_fade.color_ramp.color_mode = 'RGB'
	    alpha_fade.color_ramp.hue_interpolation = 'NEAR'
	    alpha_fade.color_ramp.interpolation = 'CARDINAL'
	
	    #initialize color ramp elements
	    alpha_fade.color_ramp.elements.remove(alpha_fade.color_ramp.elements[0])
	    alpha_fade_cre_0 = alpha_fade.color_ramp.elements[0]
	    alpha_fade_cre_0.position = 0.75
	    alpha_fade_cre_0.alpha = 1.0
	    alpha_fade_cre_0.color = (1.0, 1.0, 1.0, 1.0)
	
	    alpha_fade_cre_1 = alpha_fade.color_ramp.elements.new(0.824999988079071)
	    alpha_fade_cre_1.alpha = 1.0
	    alpha_fade_cre_1.color = (0.0, 0.0, 0.0, 1.0)
	
	    alpha_fade.outputs[1].hide = True
	
	    #node Group Input.006
	    group_input_006 = procedural_mesh_hair_shader_plus.nodes.new("NodeGroupInput")
	    group_input_006.name = "Group Input.006"
	    group_input_006.outputs[0].hide = True
	    group_input_006.outputs[1].hide = True
	    group_input_006.outputs[3].hide = True
	    group_input_006.outputs[4].hide = True
	    group_input_006.outputs[5].hide = True
	    group_input_006.outputs[6].hide = True
	    group_input_006.outputs[7].hide = True
	    group_input_006.outputs[8].hide = True
	    group_input_006.outputs[9].hide = True
	    group_input_006.outputs[10].hide = True
	    group_input_006.outputs[11].hide = True
	    group_input_006.outputs[12].hide = True
	    group_input_006.outputs[13].hide = True
	    group_input_006.outputs[14].hide = True
	    group_input_006.outputs[15].hide = True
	
	    #node Emission
	    emission = procedural_mesh_hair_shader_plus.nodes.new("ShaderNodeEmission")
	    emission.name = "Emission"
	    emission.inputs[1].hide = True
	    emission.inputs[2].hide = True
	    #Strength
	    emission.inputs[1].default_value = 1.0
	
	    #node Reroute.008
	    reroute_008 = procedural_mesh_hair_shader_plus.nodes.new("NodeReroute")
	    reroute_008.name = "Reroute.008"
	    reroute_008.socket_idname = "NodeSocketColor"
	    #Set parents
	    gradient_texture_001.parent = frame
	    tip_mask.parent = frame
	    base_mask.parent = frame
	    ambient_occlusion.parent = frame_001
	    roughness_blend.parent = frame_001
	    tint_blend.parent = frame_001
	    invert_color_009.parent = frame_001
	
	    #Set locations
	    group_output_1.location = (3133.062255859375, 0.0)
	    mix_shader_003.location = (2820.85791015625, -122.44743347167969)
	    transparent_bsdf_001.location = (2819.940185546875, -244.78338623046875)
	    invert_color_001.location = (2551.17236328125, -148.6897430419922)
	    mix_shader_004.location = (2815.621337890625, -0.4261726140975952)
	    group_input_001_1.location = (-764.8417358398438, -247.50888061523438)
	    group_input_002.location = (2614.617919921875, -30.32158660888672)
	    group_002.location = (-63.399452209472656, -187.8477020263672)
	    principled_bsdf_003.location = (2196.272705078125, -371.98095703125)
	    mapping_004.location = (-260.71337890625, -451.17205810546875)
	    group_003.location = (-63.84013366699219, -599.5425415039062)
	    mix_004.location = (203.5152130126953, -312.2414245605469)
	    alpha_blend.location = (512.0728759765625, -14.275829315185547)
	    mix_005.location = (203.5152130126953, -544.0851440429688)
	    mix_006.location = (865.0769653320312, -63.1557502746582)
	    vector_math_001.location = (-260.03857421875, -561.7272338867188)
	    invert_color_006.location = (412.10150146484375, -735.5791625976562)
	    invert_color_007.location = (1039.7294921875, -895.6447143554688)
	    mix_007.location = (668.8909301757812, -750.3211669921875)
	    gradient_texture_001.location = (30.17205810546875, -209.35888671875)
	    tip_mask.location = (215.17709350585938, -40.1392822265625)
	    mix_008.location = (668.8909301757812, -976.8273315429688)
	    base_mask.location = (215.17709350585938, -250.1292724609375)
	    mapping_005.location = (669.4089965820312, -636.447509765625)
	    principled_bsdf_004.location = (2193.831787109375, -57.96471405029297)
	    group_input_003_1.location = (-764.8417358398438, -675.0541381835938)
	    group_input_004_1.location = (-764.8417358398438, -497.1028747558594)
	    group_input_005.location = (-764.8417358398438, -1146.509521484375)
	    ambient_occlusion.location = (29.5281982421875, -234.5316162109375)
	    roughness_blend.location = (404.605224609375, -40.017333984375)
	    frame.location = (-593.0, -889.0)
	    tint_blend.location = (402.466064453125, -251.7279052734375)
	    invert_color_009.location = (206.3018798828125, -191.43505859375)
	    reroute.location = (2505.974365234375, -337.9835510253906)
	    reroute_001.location = (1044.55224609375, -669.5853271484375)
	    reroute_002.location = (413.0841979980469, -346.1207580566406)
	    reroute_003.location = (481.0604248046875, -577.9386596679688)
	    frame_001.location = (963.0, -1040.0)
	    reroute_004.location = (503.8161315917969, -1470.581787109375)
	    reroute_005.location = (1554.89990234375, -930.6466674804688)
	    reroute_006.location = (2908.086669921875, -926.4237060546875)
	    reroute_007.location = (2856.2861328125, -574.3522338867188)
	    strand_thickness.location = (1245.662109375, -791.5479736328125)
	    map_range.location = (2616.22216796875, 2.7437057495117188)
	    gradient_texture.location = (2023.9049072265625, 2.76422119140625)
	    alpha_fade.location = (2193.33837890625, 138.70892333984375)
	    group_input_006.location = (1854.099365234375, -46.594329833984375)
	    emission.location = (3134.121826171875, -126.06562805175781)
	    reroute_008.location = (2917.904052734375, -579.4513549804688)
	
	    #Set dimensions
	    group_output_1.width, group_output_1.height = 140.0, 100.0
	    mix_shader_003.width, mix_shader_003.height = 140.0, 100.0
	    transparent_bsdf_001.width, transparent_bsdf_001.height = 140.0, 100.0
	    invert_color_001.width, invert_color_001.height = 140.0, 100.0
	    mix_shader_004.width, mix_shader_004.height = 149.12149047851562, 100.0
	    group_input_001_1.width, group_input_001_1.height = 140.0, 100.0
	    group_input_002.width, group_input_002.height = 140.0, 100.0
	    group_002.width, group_002.height = 192.1226806640625, 100.0
	    principled_bsdf_003.width, principled_bsdf_003.height = 240.0, 100.0
	    mapping_004.width, mapping_004.height = 140.0, 100.0
	    group_003.width, group_003.height = 196.861083984375, 100.0
	    mix_004.width, mix_004.height = 140.0, 100.0
	    alpha_blend.width, alpha_blend.height = 240.0, 100.0
	    mix_005.width, mix_005.height = 140.0, 100.0
	    mix_006.width, mix_006.height = 140.0, 100.0
	    vector_math_001.width, vector_math_001.height = 140.0, 100.0
	    invert_color_006.width, invert_color_006.height = 140.0, 100.0
	    invert_color_007.width, invert_color_007.height = 140.0, 100.0
	    mix_007.width, mix_007.height = 140.0, 100.0
	    gradient_texture_001.width, gradient_texture_001.height = 140.0, 100.0
	    tip_mask.width, tip_mask.height = 240.0, 100.0
	    mix_008.width, mix_008.height = 140.0, 100.0
	    base_mask.width, base_mask.height = 240.0, 100.0
	    mapping_005.width, mapping_005.height = 140.0, 100.0
	    principled_bsdf_004.width, principled_bsdf_004.height = 240.0, 100.0
	    group_input_003_1.width, group_input_003_1.height = 140.0, 100.0
	    group_input_004_1.width, group_input_004_1.height = 140.0, 100.0
	    group_input_005.width, group_input_005.height = 140.0, 100.0
	    ambient_occlusion.width, ambient_occlusion.height = 140.0, 100.0
	    roughness_blend.width, roughness_blend.height = 240.0, 100.0
	    frame.width, frame.height = 485.0, 486.0
	    tint_blend.width, tint_blend.height = 240.0, 100.0
	    invert_color_009.width, invert_color_009.height = 140.0, 100.0
	    reroute.width, reroute.height = 100.0, 100.0
	    reroute_001.width, reroute_001.height = 100.0, 100.0
	    reroute_002.width, reroute_002.height = 100.0, 100.0
	    reroute_003.width, reroute_003.height = 100.0, 100.0
	    frame_001.width, frame_001.height = 675.0, 488.0
	    reroute_004.width, reroute_004.height = 100.0, 100.0
	    reroute_005.width, reroute_005.height = 100.0, 100.0
	    reroute_006.width, reroute_006.height = 100.0, 100.0
	    reroute_007.width, reroute_007.height = 100.0, 100.0
	    strand_thickness.width, strand_thickness.height = 240.0, 100.0
	    map_range.width, map_range.height = 140.0, 100.0
	    gradient_texture.width, gradient_texture.height = 140.0, 100.0
	    alpha_fade.width, alpha_fade.height = 240.0, 100.0
	    group_input_006.width, group_input_006.height = 140.0, 100.0
	    emission.width, emission.height = 140.0, 100.0
	    reroute_008.width, reroute_008.height = 100.0, 100.0
	
	    #initialize procedural_mesh_hair_shader_plus links
	    #mix_shader_003.Shader -> mix_shader_004.Shader
	    procedural_mesh_hair_shader_plus.links.new(mix_shader_003.outputs[0], mix_shader_004.inputs[1])
	    #invert_color_001.Color -> mix_shader_003.Fac
	    procedural_mesh_hair_shader_plus.links.new(invert_color_001.outputs[0], mix_shader_003.inputs[0])
	    #mix_shader_004.Shader -> group_output_1.Shader
	    procedural_mesh_hair_shader_plus.links.new(mix_shader_004.outputs[0], group_output_1.inputs[0])
	    #group_003.Alpha -> mix_004.B
	    procedural_mesh_hair_shader_plus.links.new(group_003.outputs[1], mix_004.inputs[7])
	    #group_003.Normal -> mix_005.B
	    procedural_mesh_hair_shader_plus.links.new(group_003.outputs[2], mix_005.inputs[7])
	    #mapping_004.Vector -> group_003.Vector
	    procedural_mesh_hair_shader_plus.links.new(mapping_004.outputs[0], group_003.inputs[1])
	    #mix_006.Result -> principled_bsdf_003.Base Color
	    procedural_mesh_hair_shader_plus.links.new(mix_006.outputs[2], principled_bsdf_003.inputs[0])
	    #group_002.Alpha -> mix_004.A
	    procedural_mesh_hair_shader_plus.links.new(group_002.outputs[1], mix_004.inputs[6])
	    #alpha_blend.Color -> mix_006.Factor
	    procedural_mesh_hair_shader_plus.links.new(alpha_blend.outputs[0], mix_006.inputs[0])
	    #group_002.noise -> mix_006.B
	    procedural_mesh_hair_shader_plus.links.new(group_002.outputs[3], mix_006.inputs[7])
	    #group_002.Normal -> mix_005.A
	    procedural_mesh_hair_shader_plus.links.new(group_002.outputs[2], mix_005.inputs[6])
	    #reroute_003.Output -> principled_bsdf_003.Normal
	    procedural_mesh_hair_shader_plus.links.new(reroute_003.outputs[0], principled_bsdf_003.inputs[5])
	    #reroute_002.Output -> alpha_blend.Fac
	    procedural_mesh_hair_shader_plus.links.new(reroute_002.outputs[0], alpha_blend.inputs[0])
	    #vector_math_001.Vector -> group_003.Location
	    procedural_mesh_hair_shader_plus.links.new(vector_math_001.outputs[0], group_003.inputs[2])
	    #reroute_002.Output -> invert_color_006.Color
	    procedural_mesh_hair_shader_plus.links.new(reroute_002.outputs[0], invert_color_006.inputs[1])
	    #invert_color_006.Color -> mix_007.A
	    procedural_mesh_hair_shader_plus.links.new(invert_color_006.outputs[0], mix_007.inputs[6])
	    #gradient_texture_001.Fac -> tip_mask.Fac
	    procedural_mesh_hair_shader_plus.links.new(gradient_texture_001.outputs[1], tip_mask.inputs[0])
	    #tip_mask.Color -> mix_007.B
	    procedural_mesh_hair_shader_plus.links.new(tip_mask.outputs[0], mix_007.inputs[7])
	    #reroute_005.Output -> principled_bsdf_003.Alpha
	    procedural_mesh_hair_shader_plus.links.new(reroute_005.outputs[0], principled_bsdf_003.inputs[4])
	    #gradient_texture_001.Fac -> base_mask.Fac
	    procedural_mesh_hair_shader_plus.links.new(gradient_texture_001.outputs[1], base_mask.inputs[0])
	    #base_mask.Color -> mix_008.B
	    procedural_mesh_hair_shader_plus.links.new(base_mask.outputs[0], mix_008.inputs[7])
	    #mix_007.Result -> mix_008.A
	    procedural_mesh_hair_shader_plus.links.new(mix_007.outputs[2], mix_008.inputs[6])
	    #mix_008.Result -> invert_color_007.Color
	    procedural_mesh_hair_shader_plus.links.new(mix_008.outputs[2], invert_color_007.inputs[1])
	    #reroute_001.Output -> principled_bsdf_003.Tangent
	    procedural_mesh_hair_shader_plus.links.new(reroute_001.outputs[0], principled_bsdf_003.inputs[17])
	    #reroute_003.Output -> mapping_005.Vector
	    procedural_mesh_hair_shader_plus.links.new(reroute_003.outputs[0], mapping_005.inputs[0])
	    #group_input_001_1.Vector -> group_002.Vector
	    procedural_mesh_hair_shader_plus.links.new(group_input_001_1.outputs[2], group_002.inputs[1])
	    #group_input_001_1.Minor Location -> group_002.Location
	    procedural_mesh_hair_shader_plus.links.new(group_input_001_1.outputs[3], group_002.inputs[2])
	    #group_input_001_1.Minor Scale -> group_002.Scale
	    procedural_mesh_hair_shader_plus.links.new(group_input_001_1.outputs[4], group_002.inputs[3])
	    #group_input_001_1.Minor Detail -> group_002.Detail
	    procedural_mesh_hair_shader_plus.links.new(group_input_001_1.outputs[5], group_002.inputs[4])
	    #group_input_001_1.Minor Roughness -> group_002.Roughness
	    procedural_mesh_hair_shader_plus.links.new(group_input_001_1.outputs[6], group_002.inputs[5])
	    #group_input_001_1.Minor Lacunarity -> group_002.Lacunarity
	    procedural_mesh_hair_shader_plus.links.new(group_input_001_1.outputs[7], group_002.inputs[6])
	    #group_input_001_1.Minor Distortion -> group_002.Distortion
	    procedural_mesh_hair_shader_plus.links.new(group_input_001_1.outputs[8], group_002.inputs[7])
	    #group_input_001_1.Base Color -> mix_006.A
	    procedural_mesh_hair_shader_plus.links.new(group_input_001_1.outputs[0], mix_006.inputs[6])
	    #principled_bsdf_003.BSDF -> mix_shader_003.Shader
	    procedural_mesh_hair_shader_plus.links.new(principled_bsdf_003.outputs[0], mix_shader_003.inputs[1])
	    #reroute_003.Output -> principled_bsdf_004.Normal
	    procedural_mesh_hair_shader_plus.links.new(reroute_003.outputs[0], principled_bsdf_004.inputs[5])
	    #reroute_001.Output -> principled_bsdf_004.Tangent
	    procedural_mesh_hair_shader_plus.links.new(reroute_001.outputs[0], principled_bsdf_004.inputs[17])
	    #reroute.Output -> invert_color_001.Color
	    procedural_mesh_hair_shader_plus.links.new(reroute.outputs[0], invert_color_001.inputs[1])
	    #principled_bsdf_004.BSDF -> mix_shader_004.Shader
	    procedural_mesh_hair_shader_plus.links.new(principled_bsdf_004.outputs[0], mix_shader_004.inputs[2])
	    #group_input_003_1.Base Color -> group_003.Base Color
	    procedural_mesh_hair_shader_plus.links.new(group_input_003_1.outputs[0], group_003.inputs[0])
	    #group_input_003_1.Major Scale -> group_003.Scale
	    procedural_mesh_hair_shader_plus.links.new(group_input_003_1.outputs[10], group_003.inputs[3])
	    #group_input_003_1.Major Detail -> group_003.Detail
	    procedural_mesh_hair_shader_plus.links.new(group_input_003_1.outputs[11], group_003.inputs[4])
	    #group_input_003_1.Major Roughness -> group_003.Roughness
	    procedural_mesh_hair_shader_plus.links.new(group_input_003_1.outputs[12], group_003.inputs[5])
	    #group_input_003_1.Major Lacunarity -> group_003.Lacunarity
	    procedural_mesh_hair_shader_plus.links.new(group_input_003_1.outputs[13], group_003.inputs[6])
	    #group_input_003_1.Major Distortion -> group_003.Distortion
	    procedural_mesh_hair_shader_plus.links.new(group_input_003_1.outputs[14], group_003.inputs[7])
	    #group_input_004_1.Vector -> mapping_004.Vector
	    procedural_mesh_hair_shader_plus.links.new(group_input_004_1.outputs[2], mapping_004.inputs[0])
	    #group_input_005.Vector -> gradient_texture_001.Vector
	    procedural_mesh_hair_shader_plus.links.new(group_input_005.outputs[2], gradient_texture_001.inputs[0])
	    #group_input_004_1.Minor Location -> vector_math_001.Vector
	    procedural_mesh_hair_shader_plus.links.new(group_input_004_1.outputs[3], vector_math_001.inputs[0])
	    #group_input_004_1.Major Location Offset -> vector_math_001.Vector
	    procedural_mesh_hair_shader_plus.links.new(group_input_004_1.outputs[9], vector_math_001.inputs[1])
	    #reroute_004.Output -> ambient_occlusion.Normal
	    procedural_mesh_hair_shader_plus.links.new(reroute_004.outputs[0], ambient_occlusion.inputs[2])
	    #invert_color_009.Color -> roughness_blend.Fac
	    procedural_mesh_hair_shader_plus.links.new(invert_color_009.outputs[0], roughness_blend.inputs[0])
	    #roughness_blend.Color -> principled_bsdf_003.Roughness
	    procedural_mesh_hair_shader_plus.links.new(roughness_blend.outputs[0], principled_bsdf_003.inputs[2])
	    #ambient_occlusion.AO -> tint_blend.Fac
	    procedural_mesh_hair_shader_plus.links.new(ambient_occlusion.outputs[1], tint_blend.inputs[0])
	    #tint_blend.Color -> principled_bsdf_004.Specular Tint
	    procedural_mesh_hair_shader_plus.links.new(tint_blend.outputs[0], principled_bsdf_004.inputs[14])
	    #ambient_occlusion.AO -> invert_color_009.Color
	    procedural_mesh_hair_shader_plus.links.new(ambient_occlusion.outputs[1], invert_color_009.inputs[1])
	    #mix_006.Result -> principled_bsdf_004.Base Color
	    procedural_mesh_hair_shader_plus.links.new(mix_006.outputs[2], principled_bsdf_004.inputs[0])
	    #roughness_blend.Color -> principled_bsdf_004.Roughness
	    procedural_mesh_hair_shader_plus.links.new(roughness_blend.outputs[0], principled_bsdf_004.inputs[2])
	    #tint_blend.Color -> principled_bsdf_003.Specular Tint
	    procedural_mesh_hair_shader_plus.links.new(tint_blend.outputs[0], principled_bsdf_003.inputs[14])
	    #transparent_bsdf_001.BSDF -> mix_shader_003.Shader
	    procedural_mesh_hair_shader_plus.links.new(transparent_bsdf_001.outputs[0], mix_shader_003.inputs[2])
	    #reroute_002.Output -> reroute.Input
	    procedural_mesh_hair_shader_plus.links.new(reroute_002.outputs[0], reroute.inputs[0])
	    #mapping_005.Vector -> reroute_001.Input
	    procedural_mesh_hair_shader_plus.links.new(mapping_005.outputs[0], reroute_001.inputs[0])
	    #mix_004.Result -> reroute_002.Input
	    procedural_mesh_hair_shader_plus.links.new(mix_004.outputs[2], reroute_002.inputs[0])
	    #mix_005.Result -> reroute_003.Input
	    procedural_mesh_hair_shader_plus.links.new(mix_005.outputs[2], reroute_003.inputs[0])
	    #reroute_003.Output -> reroute_004.Input
	    procedural_mesh_hair_shader_plus.links.new(reroute_003.outputs[0], reroute_004.inputs[0])
	    #reroute_007.Output -> group_output_1.Normal
	    procedural_mesh_hair_shader_plus.links.new(reroute_007.outputs[0], group_output_1.inputs[1])
	    #strand_thickness.Color -> reroute_005.Input
	    procedural_mesh_hair_shader_plus.links.new(strand_thickness.outputs[0], reroute_005.inputs[0])
	    #reroute_005.Output -> reroute_006.Input
	    procedural_mesh_hair_shader_plus.links.new(reroute_005.outputs[0], reroute_006.inputs[0])
	    #reroute_003.Output -> reroute_007.Input
	    procedural_mesh_hair_shader_plus.links.new(reroute_003.outputs[0], reroute_007.inputs[0])
	    #invert_color_007.Color -> strand_thickness.Fac
	    procedural_mesh_hair_shader_plus.links.new(invert_color_007.outputs[0], strand_thickness.inputs[0])
	    #gradient_texture.Fac -> alpha_fade.Fac
	    procedural_mesh_hair_shader_plus.links.new(gradient_texture.outputs[1], alpha_fade.inputs[0])
	    #group_input_002.Alpha Visibility -> map_range.To Max
	    procedural_mesh_hair_shader_plus.links.new(group_input_002.outputs[1], map_range.inputs[4])
	    #alpha_fade.Color -> map_range.Value
	    procedural_mesh_hair_shader_plus.links.new(alpha_fade.outputs[0], map_range.inputs[0])
	    #map_range.Result -> mix_shader_004.Fac
	    procedural_mesh_hair_shader_plus.links.new(map_range.outputs[0], mix_shader_004.inputs[0])
	    #group_input_006.Vector -> gradient_texture.Vector
	    procedural_mesh_hair_shader_plus.links.new(group_input_006.outputs[2], gradient_texture.inputs[0])
	    #reroute_008.Output -> emission.Color
	    procedural_mesh_hair_shader_plus.links.new(reroute_008.outputs[0], emission.inputs[0])
	    #emission.Emission -> group_output_1.Alpha Shader
	    procedural_mesh_hair_shader_plus.links.new(emission.outputs[0], group_output_1.inputs[3])
	    #reroute_006.Output -> reroute_008.Input
	    procedural_mesh_hair_shader_plus.links.new(reroute_006.outputs[0], reroute_008.inputs[0])
	    #reroute_008.Output -> group_output_1.Alpha Color
	    procedural_mesh_hair_shader_plus.links.new(reroute_008.outputs[0], group_output_1.inputs[2])
	    return procedural_mesh_hair_shader_plus
	
	procedural_mesh_hair_shader_plus = procedural_mesh_hair_shader_plus_node_group()
	
	#initialize MESH_MULTILAYER_V1 node group
	def mesh_multilayer_v1_node_group():
	
	    mesh_multilayer_v1 = mat.node_tree
	    #start with a clean node tree
	    for node in mesh_multilayer_v1.nodes:
	        mesh_multilayer_v1.nodes.remove(node)
	    mesh_multilayer_v1.color_tag = 'NONE'
	    mesh_multilayer_v1.description = ""
	    mesh_multilayer_v1.default_group_node_width = 140
	    
	
	    #mesh_multilayer_v1 interface
	
	    #initialize mesh_multilayer_v1 nodes
	    #node Material Output
	    material_output = mesh_multilayer_v1.nodes.new("ShaderNodeOutputMaterial")
	    material_output.name = "Material Output"
	    material_output.is_active_output = True
	    material_output.target = 'ALL'
	    #Displacement
	    material_output.inputs[2].default_value = (0.0, 0.0, 0.0)
	    #Thickness
	    material_output.inputs[3].default_value = 0.0
	
	    #node Group
	    group = mesh_multilayer_v1.nodes.new("ShaderNodeGroup")
	    group.name = "Group"
	    group.node_tree = procedural_mesh_hair_shader_plus
	    #Socket_5
	    group.inputs[1].default_value = 1.0
	    #Socket_7
	    group.inputs[3].default_value = (0.29999998211860657, 7.199999809265137, -3.299999713897705)
	    #Socket_8
	    group.inputs[4].default_value = 5.0
	    #Socket_9
	    group.inputs[5].default_value = 2.0
	    #Socket_10
	    group.inputs[6].default_value = 0.10000000149011612
	    #Socket_11
	    group.inputs[7].default_value = 2.0
	    #Socket_12
	    group.inputs[8].default_value = 0.0
	    #Socket_13
	    group.inputs[9].default_value = (0.0, 0.0, 5.0)
	    #Socket_14
	    group.inputs[10].default_value = 1.0
	    #Socket_15
	    group.inputs[11].default_value = 5.0
	    #Socket_16
	    group.inputs[12].default_value = 0.5
	    #Socket_17
	    group.inputs[13].default_value = 2.0
	    #Socket_18
	    group.inputs[14].default_value = 0.0
	
	    #node Root Map
	    root_map = mesh_multilayer_v1.nodes.new("ShaderNodeValToRGB")
	    root_map.label = "Root Map"
	    root_map.name = "Root Map"
	    root_map.color_ramp.color_mode = 'RGB'
	    root_map.color_ramp.hue_interpolation = 'NEAR'
	    root_map.color_ramp.interpolation = 'EASE'
	
	    #initialize color ramp elements
	    root_map.color_ramp.elements.remove(root_map.color_ramp.elements[0])
	    root_map_cre_0 = root_map.color_ramp.elements[0]
	    root_map_cre_0.position = 0.05000000074505806
	    root_map_cre_0.alpha = 1.0
	    root_map_cre_0.color = (0.0, 0.0, 0.0, 1.0)
	
	    root_map_cre_1 = root_map.color_ramp.elements.new(0.10000000149011612)
	    root_map_cre_1.alpha = 1.0
	    root_map_cre_1.color = (0.16504591703414917, 0.16504591703414917, 0.16504591703414917, 1.0)
	
	    root_map_cre_2 = root_map.color_ramp.elements.new(0.5)
	    root_map_cre_2.alpha = 1.0
	    root_map_cre_2.color = (1.0, 1.0, 1.0, 1.0)
	
	
	    #node Root Tint Blend
	    root_tint_blend = mesh_multilayer_v1.nodes.new("ShaderNodeMix")
	    root_tint_blend.label = "Root Tint Blend"
	    root_tint_blend.name = "Root Tint Blend"
	    root_tint_blend.blend_type = 'VALUE'
	    root_tint_blend.clamp_factor = True
	    root_tint_blend.clamp_result = False
	    root_tint_blend.data_type = 'RGBA'
	    root_tint_blend.factor_mode = 'UNIFORM'
	    #Factor_Float
	    root_tint_blend.inputs[0].default_value = 0.75
	
	    #node Multilayer Color
	    multilayer_color = mesh_multilayer_v1.nodes.new("ShaderNodeValToRGB")
	    multilayer_color.label = "Multilayer Color"
	    multilayer_color.name = "Multilayer Color"
	    multilayer_color.color_ramp.color_mode = 'RGB'
	    multilayer_color.color_ramp.hue_interpolation = 'NEAR'
	    multilayer_color.color_ramp.interpolation = 'EASE'
	
	    #initialize color ramp elements
	    multilayer_color.color_ramp.elements.remove(multilayer_color.color_ramp.elements[0])
	    multilayer_color_cre_0 = multilayer_color.color_ramp.elements[0]
	    multilayer_color_cre_0.position = 0.1852051317691803
	    multilayer_color_cre_0.alpha = 1.0
	    multilayer_color_cre_0.color = (0.7678143978118896, 0.05003742128610611, 0.1601339876651764, 1.0)
	
	    multilayer_color_cre_1 = multilayer_color.color_ramp.elements.new(0.3919806480407715)
	    multilayer_color_cre_1.alpha = 1.0
	    multilayer_color_cre_1.color = (0.35308605432510376, 0.004882563836872578, 0.8302404880523682, 1.0)
	
	    multilayer_color_cre_2 = multilayer_color.color_ramp.elements.new(0.5984296202659607)
	    multilayer_color_cre_2.alpha = 1.0
	    multilayer_color_cre_2.color = (0.008406860753893852, 1.0, 0.007624079007655382, 1.0)
	
	    multilayer_color_cre_3 = multilayer_color.color_ramp.elements.new(0.7927536368370056)
	    multilayer_color_cre_3.alpha = 1.0
	    multilayer_color_cre_3.color = (0.013692932203412056, 0.15974310040473938, 1.0, 1.0)
	
	    multilayer_color_cre_4 = multilayer_color.color_ramp.elements.new(0.9445288181304932)
	    multilayer_color_cre_4.alpha = 1.0
	    multilayer_color_cre_4.color = (0.5798678994178772, 0.002291931537911296, 0.5310531854629517, 1.0)
	
	
	    #node Separate XYZ
	    separate_xyz = mesh_multilayer_v1.nodes.new("ShaderNodeSeparateXYZ")
	    separate_xyz.name = "Separate XYZ"
	    separate_xyz.hide = True
	    separate_xyz.outputs[0].hide = True
	    separate_xyz.outputs[2].hide = True
	
	    #node Gradient Texture
	    gradient_texture_1 = mesh_multilayer_v1.nodes.new("ShaderNodeTexGradient")
	    gradient_texture_1.name = "Gradient Texture"
	    gradient_texture_1.gradient_type = 'LINEAR'
	
	    #node Reroute
	    reroute_1 = mesh_multilayer_v1.nodes.new("NodeReroute")
	    reroute_1.name = "Reroute"
	    reroute_1.socket_idname = "NodeSocketVector"
	    #node Texture Coordinate
	    texture_coordinate = mesh_multilayer_v1.nodes.new("ShaderNodeTexCoord")
	    texture_coordinate.name = "Texture Coordinate"
	    texture_coordinate.from_instancer = False
	
	
	    #Set locations
	    material_output.location = (117.8687973022461, 573.2313842773438)
	    group.location = (-382.7274475097656, 546.1285400390625)
	    root_map.location = (-910.8743896484375, 328.2369079589844)
	    root_tint_blend.location = (-573.2110595703125, 680.1982421875)
	    multilayer_color.location = (-912.0556030273438, 598.935791015625)
	    separate_xyz.location = (-1096.4566650390625, 416.2827453613281)
	    gradient_texture_1.location = (-1080.016845703125, 259.93170166015625)
	    reroute_1.location = (-1265.9949951171875, 340.3065490722656)
	    texture_coordinate.location = (-1502.0029296875, 418.9646301269531)
	
	    #Set dimensions
	    material_output.width, material_output.height = 140.0, 100.0
	    group.width, group.height = 252.53759765625, 100.0
	    root_map.width, root_map.height = 240.0, 100.0
	    root_tint_blend.width, root_tint_blend.height = 140.0, 100.0
	    multilayer_color.width, multilayer_color.height = 240.0, 100.0
	    separate_xyz.width, separate_xyz.height = 140.0, 100.0
	    gradient_texture_1.width, gradient_texture_1.height = 140.0, 100.0
	    reroute_1.width, reroute_1.height = 10.0, 100.0
	    texture_coordinate.width, texture_coordinate.height = 140.0, 100.0
	
	    #initialize mesh_multilayer_v1 links
	    #root_tint_blend.Result -> group.Base Color
	    mesh_multilayer_v1.links.new(root_tint_blend.outputs[2], group.inputs[0])
	    #root_map.Color -> root_tint_blend.B
	    mesh_multilayer_v1.links.new(root_map.outputs[0], root_tint_blend.inputs[7])
	    #group.Shader -> material_output.Surface
	    mesh_multilayer_v1.links.new(group.outputs[0], material_output.inputs[0])
	    #reroute_1.Output -> separate_xyz.Vector
	    mesh_multilayer_v1.links.new(reroute_1.outputs[0], separate_xyz.inputs[0])
	    #reroute_1.Output -> gradient_texture_1.Vector
	    mesh_multilayer_v1.links.new(reroute_1.outputs[0], gradient_texture_1.inputs[0])
	    #multilayer_color.Color -> root_tint_blend.A
	    mesh_multilayer_v1.links.new(multilayer_color.outputs[0], root_tint_blend.inputs[6])
	    #reroute_1.Output -> group.Vector
	    mesh_multilayer_v1.links.new(reroute_1.outputs[0], group.inputs[2])
	    #separate_xyz.Y -> multilayer_color.Fac
	    mesh_multilayer_v1.links.new(separate_xyz.outputs[1], multilayer_color.inputs[0])
	    #gradient_texture_1.Color -> root_map.Fac
	    mesh_multilayer_v1.links.new(gradient_texture_1.outputs[0], root_map.inputs[0])
	    #texture_coordinate.UV -> reroute_1.Input
	    mesh_multilayer_v1.links.new(texture_coordinate.outputs[2], reroute_1.inputs[0])
	    return mesh_multilayer_v1
	return mesh_multilayer_v1_node_group()

	

	
