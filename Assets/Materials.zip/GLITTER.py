import bpy, mathutils



def node(mat):
	#initialize GLITTER node group
	def glitter_node_group():
	
	    glitter = mat.node_tree
	    #start with a clean node tree
	    for node in glitter.nodes:
	        glitter.nodes.remove(node)
	    glitter.color_tag = 'NONE'
	    glitter.description = ""
	    glitter.default_group_node_width = 140
	    
	
	    #glitter interface
	
	    #initialize glitter nodes
	    #node Material Output
	    material_output = glitter.nodes.new("ShaderNodeOutputMaterial")
	    material_output.name = "Material Output"
	    material_output.is_active_output = True
	    material_output.target = 'ALL'
	    material_output.inputs[1].hide = True
	    material_output.inputs[2].hide = True
	    material_output.inputs[3].hide = True
	    #Displacement
	    material_output.inputs[2].default_value = (0.0, 0.0, 0.0)
	    #Thickness
	    material_output.inputs[3].default_value = 0.0
	
	    #node Voronoi Texture
	    voronoi_texture = glitter.nodes.new("ShaderNodeTexVoronoi")
	    voronoi_texture.name = "Voronoi Texture"
	    voronoi_texture.distance = 'EUCLIDEAN'
	    voronoi_texture.feature = 'F1'
	    voronoi_texture.normalize = False
	    voronoi_texture.voronoi_dimensions = '3D'
	    #Scale
	    voronoi_texture.inputs[2].default_value = 1024.0
	    #Detail
	    voronoi_texture.inputs[3].default_value = 0.5
	    #Roughness
	    voronoi_texture.inputs[4].default_value = 0.03333333134651184
	    #Lacunarity
	    voronoi_texture.inputs[5].default_value = 7.999999523162842
	    #Randomness
	    voronoi_texture.inputs[8].default_value = 1.0
	
	    #node Mapping
	    mapping = glitter.nodes.new("ShaderNodeMapping")
	    mapping.name = "Mapping"
	    mapping.vector_type = 'POINT'
	    mapping.inputs[1].hide = True
	    mapping.inputs[2].hide = True
	    mapping.inputs[3].hide = True
	    #Location
	    mapping.inputs[1].default_value = (0.0, 0.0, 0.0)
	    #Rotation
	    mapping.inputs[2].default_value = (0.0, 0.0, 0.0)
	    #Scale
	    mapping.inputs[3].default_value = (1.0, 1.0, 1.0)
	
	    #node Texture Coordinate
	    texture_coordinate = glitter.nodes.new("ShaderNodeTexCoord")
	    texture_coordinate.name = "Texture Coordinate"
	    texture_coordinate.from_instancer = False
	    texture_coordinate.outputs[1].hide = True
	    texture_coordinate.outputs[2].hide = True
	    texture_coordinate.outputs[3].hide = True
	    texture_coordinate.outputs[4].hide = True
	    texture_coordinate.outputs[5].hide = True
	    texture_coordinate.outputs[6].hide = True
	
	    #node Image Texture
	    image_texture = glitter.nodes.new("ShaderNodeTexImage")
	    image_texture.name = "Image Texture"
	    image_texture.extension = 'REPEAT'
	    if "Glitter" in bpy.data.images:
	        image_texture.image = bpy.data.images["Glitter"]
	    image_texture.image_user.frame_current = 0
	    image_texture.image_user.frame_duration = 100
	    image_texture.image_user.frame_offset = 0
	    image_texture.image_user.frame_start = 1
	    image_texture.image_user.tile = 0
	    image_texture.image_user.use_auto_refresh = False
	    image_texture.image_user.use_cyclic = False
	    image_texture.interpolation = 'Linear'
	    image_texture.projection = 'FLAT'
	    image_texture.projection_blend = 0.0
	    #Vector
	    image_texture.inputs[0].default_value = (0.0, 0.0, 0.0)
	
	    #node Diffuse BSDF
	    diffuse_bsdf = glitter.nodes.new("ShaderNodeBsdfDiffuse")
	    diffuse_bsdf.name = "Diffuse BSDF"
	    diffuse_bsdf.inputs[1].hide = True
	    diffuse_bsdf.inputs[2].hide = True
	    diffuse_bsdf.inputs[3].hide = True
	    #Roughness
	    diffuse_bsdf.inputs[1].default_value = 0.0
	    #Normal
	    diffuse_bsdf.inputs[2].default_value = (0.0, 0.0, 0.0)
	
	    #node Color Ramp
	    color_ramp = glitter.nodes.new("ShaderNodeValToRGB")
	    color_ramp.name = "Color Ramp"
	    color_ramp.color_ramp.color_mode = 'RGB'
	    color_ramp.color_ramp.hue_interpolation = 'NEAR'
	    color_ramp.color_ramp.interpolation = 'CONSTANT'
	
	    #initialize color ramp elements
	    color_ramp.color_ramp.elements.remove(color_ramp.color_ramp.elements[0])
	    color_ramp_cre_0 = color_ramp.color_ramp.elements[0]
	    color_ramp_cre_0.position = 0.0
	    color_ramp_cre_0.alpha = 1.0
	    color_ramp_cre_0.color = (0.5, 0.5, 1.0, 1.0)
	
	    color_ramp_cre_1 = color_ramp.color_ramp.elements.new(0.16363640129566193)
	    color_ramp_cre_1.alpha = 1.0
	    color_ramp_cre_1.color = (0.0, 1.0, 1.0, 1.0)
	
	    color_ramp_cre_2 = color_ramp.color_ramp.elements.new(0.42954540252685547)
	    color_ramp_cre_2.alpha = 1.0
	    color_ramp_cre_2.color = (0.0, 0.0, 1.0, 1.0)
	
	    color_ramp_cre_3 = color_ramp.color_ramp.elements.new(0.7045454978942871)
	    color_ramp_cre_3.alpha = 1.0
	    color_ramp_cre_3.color = (1.0, 0.0, 1.0, 1.0)
	
	    color_ramp_cre_4 = color_ramp.color_ramp.elements.new(0.9215909242630005)
	    color_ramp_cre_4.alpha = 1.0
	    color_ramp_cre_4.color = (1.0, 0.0, 0.0, 1.0)
	
	
	
	    #Set locations
	    material_output.location = (494.3033447265625, 276.6962585449219)
	    voronoi_texture.location = (-263.4949951171875, 243.28990173339844)
	    mapping.location = (-443.4949951171875, 203.28990173339844)
	    texture_coordinate.location = (-623.4949951171875, 203.28990173339844)
	    image_texture.location = (494.561767578125, 174.74951171875)
	    diffuse_bsdf.location = (267.41845703125, 252.8855438232422)
	    color_ramp.location = (-22.668380737304688, 227.64796447753906)
	
	    #Set dimensions
	    material_output.width, material_output.height = 140.0, 100.0
	    voronoi_texture.width, voronoi_texture.height = 140.0, 100.0
	    mapping.width, mapping.height = 140.0, 100.0
	    texture_coordinate.width, texture_coordinate.height = 140.0, 100.0
	    image_texture.width, image_texture.height = 240.0, 100.0
	    diffuse_bsdf.width, diffuse_bsdf.height = 150.0, 100.0
	    color_ramp.width, color_ramp.height = 240.0, 100.0
	
	    #initialize glitter links
	    #mapping.Vector -> voronoi_texture.Vector
	    glitter.links.new(mapping.outputs[0], voronoi_texture.inputs[0])
	    #texture_coordinate.Generated -> mapping.Vector
	    glitter.links.new(texture_coordinate.outputs[0], mapping.inputs[0])
	    #diffuse_bsdf.BSDF -> material_output.Surface
	    glitter.links.new(diffuse_bsdf.outputs[0], material_output.inputs[0])
	    #voronoi_texture.Color -> color_ramp.Fac
	    glitter.links.new(voronoi_texture.outputs[1], color_ramp.inputs[0])
	    #color_ramp.Color -> diffuse_bsdf.Color
	    glitter.links.new(color_ramp.outputs[0], diffuse_bsdf.inputs[0])
	    return glitter
	return glitter_node_group()

	

	
