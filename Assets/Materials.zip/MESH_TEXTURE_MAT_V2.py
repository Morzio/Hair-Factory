import bpy, mathutils



def node(mat):
	#initialize MESH_TEXTURE_MAT_V2 node group
	def mesh_texture_mat_v2_node_group():
	
	    mesh_texture_mat_v2 = mat.node_tree
	    #start with a clean node tree
	    for node in mesh_texture_mat_v2.nodes:
	        mesh_texture_mat_v2.nodes.remove(node)
	    mesh_texture_mat_v2.color_tag = 'NONE'
	    mesh_texture_mat_v2.description = ""
	    mesh_texture_mat_v2.default_group_node_width = 140
	    
	
	    #mesh_texture_mat_v2 interface
	
	    #initialize mesh_texture_mat_v2 nodes
	    #node Material Output
	    material_output = mesh_texture_mat_v2.nodes.new("ShaderNodeOutputMaterial")
	    material_output.name = "Material Output"
	    material_output.is_active_output = True
	    material_output.target = 'ALL'
	    #Displacement
	    material_output.inputs[2].default_value = (0.0, 0.0, 0.0)
	    #Thickness
	    material_output.inputs[3].default_value = 0.0
	
	    #node Alpha Texture.001
	    alpha_texture_001 = mesh_texture_mat_v2.nodes.new("ShaderNodeTexImage")
	    alpha_texture_001.label = "Alpha Texture"
	    alpha_texture_001.name = "Alpha Texture.001"
	    alpha_texture_001.extension = 'REPEAT'
	    alpha_texture_001.image_user.frame_current = 0
	    alpha_texture_001.image_user.frame_duration = 1
	    alpha_texture_001.image_user.frame_offset = -1
	    alpha_texture_001.image_user.frame_start = 1
	    alpha_texture_001.image_user.tile = 0
	    alpha_texture_001.image_user.use_auto_refresh = False
	    alpha_texture_001.image_user.use_cyclic = False
	    alpha_texture_001.interpolation = 'Linear'
	    alpha_texture_001.projection = 'FLAT'
	    alpha_texture_001.projection_blend = 0.0
	
	    #node Principled BSDF.002
	    principled_bsdf_002 = mesh_texture_mat_v2.nodes.new("ShaderNodeBsdfPrincipled")
	    principled_bsdf_002.name = "Principled BSDF.002"
	    principled_bsdf_002.distribution = 'MULTI_GGX'
	    principled_bsdf_002.subsurface_method = 'RANDOM_WALK'
	    #Metallic
	    principled_bsdf_002.inputs[1].default_value = 0.0
	    #IOR
	    principled_bsdf_002.inputs[3].default_value = 1.5
	    #Diffuse Roughness
	    principled_bsdf_002.inputs[7].default_value = 0.0
	    #Subsurface Weight
	    principled_bsdf_002.inputs[8].default_value = 0.0
	    #Subsurface Radius
	    principled_bsdf_002.inputs[9].default_value = (1.0, 0.20000000298023224, 0.10000000149011612)
	    #Subsurface Scale
	    principled_bsdf_002.inputs[10].default_value = 0.05000000074505806
	    #Subsurface Anisotropy
	    principled_bsdf_002.inputs[12].default_value = 0.0
	    #Specular IOR Level
	    principled_bsdf_002.inputs[13].default_value = 0.5
	    #Specular Tint
	    principled_bsdf_002.inputs[14].default_value = (1.0, 1.0, 1.0, 1.0)
	    #Anisotropic
	    principled_bsdf_002.inputs[15].default_value = 0.0
	    #Anisotropic Rotation
	    principled_bsdf_002.inputs[16].default_value = 0.0
	    #Tangent
	    principled_bsdf_002.inputs[17].default_value = (0.0, 0.0, 0.0)
	    #Transmission Weight
	    principled_bsdf_002.inputs[18].default_value = 0.0
	    #Coat Weight
	    principled_bsdf_002.inputs[19].default_value = 0.0
	    #Coat Roughness
	    principled_bsdf_002.inputs[20].default_value = 0.029999999329447746
	    #Coat IOR
	    principled_bsdf_002.inputs[21].default_value = 1.5
	    #Coat Tint
	    principled_bsdf_002.inputs[22].default_value = (1.0, 1.0, 1.0, 1.0)
	    #Coat Normal
	    principled_bsdf_002.inputs[23].default_value = (0.0, 0.0, 0.0)
	    #Sheen Weight
	    principled_bsdf_002.inputs[24].default_value = 0.0
	    #Sheen Roughness
	    principled_bsdf_002.inputs[25].default_value = 0.5
	    #Sheen Tint
	    principled_bsdf_002.inputs[26].default_value = (1.0, 1.0, 1.0, 1.0)
	    #Emission Color
	    principled_bsdf_002.inputs[27].default_value = (1.0, 1.0, 1.0, 1.0)
	    #Emission Strength
	    principled_bsdf_002.inputs[28].default_value = 0.0
	    #Thin Film Thickness
	    principled_bsdf_002.inputs[29].default_value = 0.0
	    #Thin Film IOR
	    principled_bsdf_002.inputs[30].default_value = 1.3300000429153442
	
	    #node Normal Texture.001
	    normal_texture_001 = mesh_texture_mat_v2.nodes.new("ShaderNodeTexImage")
	    normal_texture_001.label = "Normal Texture"
	    normal_texture_001.name = "Normal Texture.001"
	    normal_texture_001.extension = 'REPEAT'
	    normal_texture_001.image_user.frame_current = 0
	    normal_texture_001.image_user.frame_duration = 1
	    normal_texture_001.image_user.frame_offset = -1
	    normal_texture_001.image_user.frame_start = 1
	    normal_texture_001.image_user.tile = 0
	    normal_texture_001.image_user.use_auto_refresh = False
	    normal_texture_001.image_user.use_cyclic = False
	    normal_texture_001.interpolation = 'Linear'
	    normal_texture_001.projection = 'FLAT'
	    normal_texture_001.projection_blend = 0.0
	
	    #node Roughness
	    roughness = mesh_texture_mat_v2.nodes.new("ShaderNodeValToRGB")
	    roughness.label = "Roughness"
	    roughness.name = "Roughness"
	    roughness.color_ramp.color_mode = 'RGB'
	    roughness.color_ramp.hue_interpolation = 'NEAR'
	    roughness.color_ramp.interpolation = 'B_SPLINE'
	
	    #initialize color ramp elements
	    roughness.color_ramp.elements.remove(roughness.color_ramp.elements[0])
	    roughness_cre_0 = roughness.color_ramp.elements[0]
	    roughness_cre_0.position = 0.0
	    roughness_cre_0.alpha = 1.0
	    roughness_cre_0.color = (0.0, 0.0, 0.0, 1.0)
	
	    roughness_cre_1 = roughness.color_ramp.elements.new(0.14499999582767487)
	    roughness_cre_1.alpha = 1.0
	    roughness_cre_1.color = (1.0, 1.0, 1.0, 1.0)
	
	
	    #node Normal Map
	    normal_map = mesh_texture_mat_v2.nodes.new("ShaderNodeNormalMap")
	    normal_map.name = "Normal Map"
	    normal_map.space = 'TANGENT'
	    normal_map.uv_map = ""
	    #Strength
	    normal_map.inputs[0].default_value = 1.0
	
	    #node Invert Color
	    invert_color = mesh_texture_mat_v2.nodes.new("ShaderNodeInvert")
	    invert_color.name = "Invert Color"
	    #Fac
	    invert_color.inputs[0].default_value = 1.0
	
	    #node Mix Shader
	    mix_shader = mesh_texture_mat_v2.nodes.new("ShaderNodeMixShader")
	    mix_shader.name = "Mix Shader"
	
	    #node Transparent BSDF
	    transparent_bsdf = mesh_texture_mat_v2.nodes.new("ShaderNodeBsdfTransparent")
	    transparent_bsdf.name = "Transparent BSDF"
	    #Color
	    transparent_bsdf.inputs[0].default_value = (1.0, 1.0, 1.0, 1.0)
	
	    #node Brightness/Contrast
	    brightness_contrast = mesh_texture_mat_v2.nodes.new("ShaderNodeBrightContrast")
	    brightness_contrast.name = "Brightness/Contrast"
	    #Bright
	    brightness_contrast.inputs[1].default_value = 0.15000000596046448
	    #Contrast
	    brightness_contrast.inputs[2].default_value = 0.20000000298023224
	
	    #node Hue/Saturation/Value
	    hue_saturation_value = mesh_texture_mat_v2.nodes.new("ShaderNodeHueSaturation")
	    hue_saturation_value.name = "Hue/Saturation/Value"
	    #Hue
	    hue_saturation_value.inputs[0].default_value = 0.5
	    #Saturation
	    hue_saturation_value.inputs[1].default_value = 3.0
	    #Value
	    hue_saturation_value.inputs[2].default_value = 10.0
	    #Fac
	    hue_saturation_value.inputs[3].default_value = 1.0
	
	    #node Diffuse Texture
	    diffuse_texture = mesh_texture_mat_v2.nodes.new("ShaderNodeTexImage")
	    diffuse_texture.label = "Diffuse Texture"
	    diffuse_texture.name = "Diffuse Texture"
	    diffuse_texture.extension = 'REPEAT'
	    diffuse_texture.image_user.frame_current = 0
	    diffuse_texture.image_user.frame_duration = 1
	    diffuse_texture.image_user.frame_offset = 0
	    diffuse_texture.image_user.frame_start = 1
	    diffuse_texture.image_user.tile = 0
	    diffuse_texture.image_user.use_auto_refresh = False
	    diffuse_texture.image_user.use_cyclic = False
	    diffuse_texture.interpolation = 'Linear'
	    diffuse_texture.projection = 'FLAT'
	    diffuse_texture.projection_blend = 0.0
	
	    #node Texture Coordinate.001
	    texture_coordinate_001 = mesh_texture_mat_v2.nodes.new("ShaderNodeTexCoord")
	    texture_coordinate_001.name = "Texture Coordinate.001"
	    texture_coordinate_001.from_instancer = False
	    texture_coordinate_001.outputs[0].hide = True
	    texture_coordinate_001.outputs[1].hide = True
	    texture_coordinate_001.outputs[3].hide = True
	    texture_coordinate_001.outputs[4].hide = True
	    texture_coordinate_001.outputs[5].hide = True
	    texture_coordinate_001.outputs[6].hide = True
	
	
	    #Set locations
	    material_output.location = (1402.448974609375, 324.7462463378906)
	    alpha_texture_001.location = (36.850276947021484, 215.90325927734375)
	    principled_bsdf_002.location = (749.4910888671875, 258.5047607421875)
	    normal_texture_001.location = (36.850276947021484, -61.38746643066406)
	    roughness.location = (503.22845458984375, 158.74740600585938)
	    normal_map.location = (497.758544921875, -50.61741638183594)
	    invert_color.location = (499.91021728515625, 552.4783325195312)
	    mix_shader.location = (1120.64697265625, 301.8052062988281)
	    transparent_bsdf.location = (1116.18896484375, 176.87310791015625)
	    brightness_contrast.location = (497.9880065917969, 451.1324462890625)
	    hue_saturation_value.location = (497.7004089355469, 327.2387390136719)
	    diffuse_texture.location = (36.85057067871094, 490.73919677734375)
	    texture_coordinate_001.location = (-337.7208251953125, 241.66439819335938)
	
	    #Set dimensions
	    material_output.width, material_output.height = 140.0, 100.0
	    alpha_texture_001.width, alpha_texture_001.height = 240.0, 100.0
	    principled_bsdf_002.width, principled_bsdf_002.height = 240.0, 100.0
	    normal_texture_001.width, normal_texture_001.height = 240.0, 100.0
	    roughness.width, roughness.height = 140.0, 100.0
	    normal_map.width, normal_map.height = 150.0, 100.0
	    invert_color.width, invert_color.height = 140.0, 100.0
	    mix_shader.width, mix_shader.height = 140.0, 100.0
	    transparent_bsdf.width, transparent_bsdf.height = 140.0, 100.0
	    brightness_contrast.width, brightness_contrast.height = 140.0, 100.0
	    hue_saturation_value.width, hue_saturation_value.height = 150.0, 100.0
	    diffuse_texture.width, diffuse_texture.height = 240.0, 100.0
	    texture_coordinate_001.width, texture_coordinate_001.height = 140.0, 100.0
	
	    #initialize mesh_texture_mat_v2 links
	    #normal_map.Normal -> principled_bsdf_002.Normal
	    mesh_texture_mat_v2.links.new(normal_map.outputs[0], principled_bsdf_002.inputs[5])
	    #normal_texture_001.Color -> normal_map.Color
	    mesh_texture_mat_v2.links.new(normal_texture_001.outputs[0], normal_map.inputs[1])
	    #alpha_texture_001.Color -> invert_color.Color
	    mesh_texture_mat_v2.links.new(alpha_texture_001.outputs[0], invert_color.inputs[1])
	    #invert_color.Color -> mix_shader.Fac
	    mesh_texture_mat_v2.links.new(invert_color.outputs[0], mix_shader.inputs[0])
	    #transparent_bsdf.BSDF -> mix_shader.Shader
	    mesh_texture_mat_v2.links.new(transparent_bsdf.outputs[0], mix_shader.inputs[2])
	    #principled_bsdf_002.BSDF -> mix_shader.Shader
	    mesh_texture_mat_v2.links.new(principled_bsdf_002.outputs[0], mix_shader.inputs[1])
	    #mix_shader.Shader -> material_output.Surface
	    mesh_texture_mat_v2.links.new(mix_shader.outputs[0], material_output.inputs[0])
	    #roughness.Color -> principled_bsdf_002.Roughness
	    mesh_texture_mat_v2.links.new(roughness.outputs[0], principled_bsdf_002.inputs[2])
	    #hue_saturation_value.Color -> principled_bsdf_002.Base Color
	    mesh_texture_mat_v2.links.new(hue_saturation_value.outputs[0], principled_bsdf_002.inputs[0])
	    #brightness_contrast.Color -> hue_saturation_value.Color
	    mesh_texture_mat_v2.links.new(brightness_contrast.outputs[0], hue_saturation_value.inputs[4])
	    #diffuse_texture.Color -> brightness_contrast.Color
	    mesh_texture_mat_v2.links.new(diffuse_texture.outputs[0], brightness_contrast.inputs[0])
	    #invert_color.Color -> roughness.Fac
	    mesh_texture_mat_v2.links.new(invert_color.outputs[0], roughness.inputs[0])
	    #alpha_texture_001.Alpha -> principled_bsdf_002.Alpha
	    mesh_texture_mat_v2.links.new(alpha_texture_001.outputs[1], principled_bsdf_002.inputs[4])
	    #texture_coordinate_001.UV -> diffuse_texture.Vector
	    mesh_texture_mat_v2.links.new(texture_coordinate_001.outputs[2], diffuse_texture.inputs[0])
	    #texture_coordinate_001.UV -> alpha_texture_001.Vector
	    mesh_texture_mat_v2.links.new(texture_coordinate_001.outputs[2], alpha_texture_001.inputs[0])
	    #texture_coordinate_001.UV -> normal_texture_001.Vector
	    mesh_texture_mat_v2.links.new(texture_coordinate_001.outputs[2], normal_texture_001.inputs[0])
	    return mesh_texture_mat_v2
	return mesh_texture_mat_v2_node_group()

	

	
