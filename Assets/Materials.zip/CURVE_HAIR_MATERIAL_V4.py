import bpy, mathutils



def node(mat):
	#initialize CURVE_HAIR_MATERIAL_V4 node group
	def curve_hair_material_v4_node_group():
	
	    curve_hair_material_v4 = mat.node_tree
	    #start with a clean node tree
	    for node in curve_hair_material_v4.nodes:
	        curve_hair_material_v4.nodes.remove(node)
	    curve_hair_material_v4.color_tag = 'NONE'
	    curve_hair_material_v4.description = ""
	    curve_hair_material_v4.default_group_node_width = 140
	    
	
	    #curve_hair_material_v4 interface
	
	    #initialize curve_hair_material_v4 nodes
	    #node Material Output
	    material_output = curve_hair_material_v4.nodes.new("ShaderNodeOutputMaterial")
	    material_output.name = "Material Output"
	    material_output.is_active_output = True
	    material_output.target = 'ALL'
	    #Displacement
	    material_output.inputs[2].default_value = (0.0, 0.0, 0.0)
	    #Thickness
	    material_output.inputs[3].default_value = 0.0
	
	    #node Principled Hair BSDF
	    principled_hair_bsdf = curve_hair_material_v4.nodes.new("ShaderNodeBsdfHairPrincipled")
	    principled_hair_bsdf.name = "Principled Hair BSDF"
	    principled_hair_bsdf.model = 'CHIANG'
	    principled_hair_bsdf.parametrization = 'COLOR'
	    #Roughness
	    principled_hair_bsdf.inputs[6].default_value = 0.30000001192092896
	    #Radial Roughness
	    principled_hair_bsdf.inputs[7].default_value = 0.30000001192092896
	    #Coat
	    principled_hair_bsdf.inputs[8].default_value = 0.0
	    #IOR
	    principled_hair_bsdf.inputs[9].default_value = 1.5499999523162842
	    #Offset
	    principled_hair_bsdf.inputs[10].default_value = 0.03490658476948738
	    #Random Roughness
	    principled_hair_bsdf.inputs[12].default_value = 0.0
	    #Random
	    principled_hair_bsdf.inputs[13].default_value = 0.0
	
	    #node Base Color
	    base_color = curve_hair_material_v4.nodes.new("ShaderNodeValToRGB")
	    base_color.label = "Base Color"
	    base_color.name = "Base Color"
	    base_color.color_ramp.color_mode = 'RGB'
	    base_color.color_ramp.hue_interpolation = 'NEAR'
	    base_color.color_ramp.interpolation = 'EASE'
	
	    #initialize color ramp elements
	    base_color.color_ramp.elements.remove(base_color.color_ramp.elements[0])
	    base_color_cre_0 = base_color.color_ramp.elements[0]
	    base_color_cre_0.position = 0.30000001192092896
	    base_color_cre_0.alpha = 1.0
	    base_color_cre_0.color = (0.0176415853202343, 0.005605380982160568, 0.0021241612266749144, 1.0)
	
	    base_color_cre_1 = base_color.color_ramp.elements.new(0.800000011920929)
	    base_color_cre_1.alpha = 1.0
	    base_color_cre_1.color = (0.09774497151374817, 0.10102304816246033, 0.02086935192346573, 1.0)
	
	    base_color_cre_2 = base_color.color_ramp.elements.new(1.0)
	    base_color_cre_2.alpha = 1.0
	    base_color_cre_2.color = (1.0, 1.0, 1.0, 1.0)
	
	
	    #node Curves Info
	    curves_info = curve_hair_material_v4.nodes.new("ShaderNodeHairInfo")
	    curves_info.name = "Curves Info"
	    curves_info.outputs[0].hide = True
	    curves_info.outputs[2].hide = True
	    curves_info.outputs[3].hide = True
	    curves_info.outputs[4].hide = True
	
	    #node Random Factor Adjustment
	    random_factor_adjustment = curve_hair_material_v4.nodes.new("ShaderNodeValToRGB")
	    random_factor_adjustment.label = "Random Factor Adjustment"
	    random_factor_adjustment.name = "Random Factor Adjustment"
	    random_factor_adjustment.color_ramp.color_mode = 'RGB'
	    random_factor_adjustment.color_ramp.hue_interpolation = 'NEAR'
	    random_factor_adjustment.color_ramp.interpolation = 'LINEAR'
	
	    #initialize color ramp elements
	    random_factor_adjustment.color_ramp.elements.remove(random_factor_adjustment.color_ramp.elements[0])
	    random_factor_adjustment_cre_0 = random_factor_adjustment.color_ramp.elements[0]
	    random_factor_adjustment_cre_0.position = 0.1136360615491867
	    random_factor_adjustment_cre_0.alpha = 1.0
	    random_factor_adjustment_cre_0.color = (0.0, 0.0, 0.0, 1.0)
	
	    random_factor_adjustment_cre_1 = random_factor_adjustment.color_ramp.elements.new(1.0)
	    random_factor_adjustment_cre_1.alpha = 1.0
	    random_factor_adjustment_cre_1.color = (1.0, 1.0, 1.0, 1.0)
	
	    random_factor_adjustment.outputs[1].hide = True
	
	    #node Random Factor Location
	    random_factor_location = curve_hair_material_v4.nodes.new("ShaderNodeFloatCurve")
	    random_factor_location.label = "Random Factor Location"
	    random_factor_location.name = "Random Factor Location"
	    #mapping settings
	    random_factor_location.mapping.extend = 'EXTRAPOLATED'
	    random_factor_location.mapping.tone = 'STANDARD'
	    random_factor_location.mapping.black_level = (0.0, 0.0, 0.0)
	    random_factor_location.mapping.white_level = (1.0, 1.0, 1.0)
	    random_factor_location.mapping.clip_min_x = 0.0
	    random_factor_location.mapping.clip_min_y = 0.0
	    random_factor_location.mapping.clip_max_x = 1.0
	    random_factor_location.mapping.clip_max_y = 1.0
	    random_factor_location.mapping.use_clip = True
	    #curve 0
	    random_factor_location_curve_0 = random_factor_location.mapping.curves[0]
	    random_factor_location_curve_0_point_0 = random_factor_location_curve_0.points[0]
	    random_factor_location_curve_0_point_0.location = (0.0, 1.0)
	    random_factor_location_curve_0_point_0.handle_type = 'AUTO'
	    random_factor_location_curve_0_point_1 = random_factor_location_curve_0.points[1]
	    random_factor_location_curve_0_point_1.location = (0.09090906381607056, 0.0)
	    random_factor_location_curve_0_point_1.handle_type = 'AUTO'
	    random_factor_location_curve_0_point_2 = random_factor_location_curve_0.points.new(0.3181818127632141, 0.0)
	    random_factor_location_curve_0_point_2.handle_type = 'AUTO'
	    random_factor_location_curve_0_point_3 = random_factor_location_curve_0.points.new(0.5636365413665771, 0.65625)
	    random_factor_location_curve_0_point_3.handle_type = 'AUTO'
	    random_factor_location_curve_0_point_4 = random_factor_location_curve_0.points.new(0.7681818604469299, 0.9999999403953552)
	    random_factor_location_curve_0_point_4.handle_type = 'AUTO'
	    random_factor_location_curve_0_point_5 = random_factor_location_curve_0.points.new(0.9727272987365723, 0.0)
	    random_factor_location_curve_0_point_5.handle_type = 'AUTO'
	    #update curve after changes
	    random_factor_location.mapping.update()
	    random_factor_location.inputs[0].hide = True
	    #Factor
	    random_factor_location.inputs[0].default_value = 1.0
	
	    #node Mix
	    mix = curve_hair_material_v4.nodes.new("ShaderNodeMix")
	    mix.name = "Mix"
	    mix.hide = True
	    mix.blend_type = 'MIX'
	    mix.clamp_factor = True
	    mix.clamp_result = False
	    mix.data_type = 'FLOAT'
	    mix.factor_mode = 'UNIFORM'
	
	    #node Map Range
	    map_range = curve_hair_material_v4.nodes.new("ShaderNodeMapRange")
	    map_range.name = "Map Range"
	    map_range.hide = True
	    map_range.clamp = True
	    map_range.data_type = 'FLOAT'
	    map_range.interpolation_type = 'LINEAR'
	    map_range.inputs[1].hide = True
	    map_range.inputs[2].hide = True
	    map_range.inputs[3].hide = True
	    map_range.inputs[5].hide = True
	    map_range.inputs[6].hide = True
	    map_range.inputs[7].hide = True
	    map_range.inputs[8].hide = True
	    map_range.inputs[9].hide = True
	    map_range.inputs[10].hide = True
	    map_range.inputs[11].hide = True
	    map_range.outputs[1].hide = True
	    #From Min
	    map_range.inputs[1].default_value = 0.0
	    #From Max
	    map_range.inputs[2].default_value = 1.0
	    #To Min
	    map_range.inputs[3].default_value = 0.0
	
	    #node Color Cutoff
	    color_cutoff = curve_hair_material_v4.nodes.new("ShaderNodeValue")
	    color_cutoff.label = "Color Cutoff"
	    color_cutoff.name = "Color Cutoff"
	
	    color_cutoff.outputs[0].default_value = 0.800000011920929
	    #node Mix Factor Adjustment
	    mix_factor_adjustment = curve_hair_material_v4.nodes.new("ShaderNodeValToRGB")
	    mix_factor_adjustment.label = "Mix Factor Adjustment"
	    mix_factor_adjustment.name = "Mix Factor Adjustment"
	    mix_factor_adjustment.color_ramp.color_mode = 'RGB'
	    mix_factor_adjustment.color_ramp.hue_interpolation = 'NEAR'
	    mix_factor_adjustment.color_ramp.interpolation = 'LINEAR'
	
	    #initialize color ramp elements
	    mix_factor_adjustment.color_ramp.elements.remove(mix_factor_adjustment.color_ramp.elements[0])
	    mix_factor_adjustment_cre_0 = mix_factor_adjustment.color_ramp.elements[0]
	    mix_factor_adjustment_cre_0.position = 0.0
	    mix_factor_adjustment_cre_0.alpha = 1.0
	    mix_factor_adjustment_cre_0.color = (0.0, 0.0, 0.0, 1.0)
	
	    mix_factor_adjustment_cre_1 = mix_factor_adjustment.color_ramp.elements.new(0.9954546093940735)
	    mix_factor_adjustment_cre_1.alpha = 1.0
	    mix_factor_adjustment_cre_1.color = (1.0, 1.0, 1.0, 1.0)
	
	    mix_factor_adjustment.outputs[1].hide = True
	
	
	    #Set locations
	    material_output.location = (479.1377258300781, 477.5298767089844)
	    principled_hair_bsdf.location = (197.30996704101562, 454.1291198730469)
	    base_color.location = (-127.62903594970703, 379.65240478515625)
	    curves_info.location = (-890.8998413085938, 260.30340576171875)
	    random_factor_adjustment.location = (-693.9129638671875, 144.12075805664062)
	    random_factor_location.location = (-404.8375244140625, 148.08206176757812)
	    mix.location = (-309.04266357421875, 199.0979461669922)
	    map_range.location = (-570.4951782226562, 196.75425720214844)
	    color_cutoff.location = (-29.06591796875, 166.9862060546875)
	    mix_factor_adjustment.location = (-408.22039794921875, 398.53173828125)
	
	    #Set dimensions
	    material_output.width, material_output.height = 140.0, 100.0
	    principled_hair_bsdf.width, principled_hair_bsdf.height = 240.0, 100.0
	    base_color.width, base_color.height = 240.0, 100.0
	    curves_info.width, curves_info.height = 140.0, 100.0
	    random_factor_adjustment.width, random_factor_adjustment.height = 240.0, 100.0
	    random_factor_location.width, random_factor_location.height = 240.0, 100.0
	    mix.width, mix.height = 140.0, 100.0
	    map_range.width, map_range.height = 140.0, 100.0
	    color_cutoff.width, color_cutoff.height = 140.0, 100.0
	    mix_factor_adjustment.width, mix_factor_adjustment.height = 240.0, 100.0
	
	    #initialize curve_hair_material_v4 links
	    #principled_hair_bsdf.BSDF -> material_output.Surface
	    curve_hair_material_v4.links.new(principled_hair_bsdf.outputs[0], material_output.inputs[0])
	    #map_range.Result -> mix.A
	    curve_hair_material_v4.links.new(map_range.outputs[0], mix.inputs[2])
	    #base_color.Color -> principled_hair_bsdf.Color
	    curve_hair_material_v4.links.new(base_color.outputs[0], principled_hair_bsdf.inputs[0])
	    #mix.Result -> base_color.Fac
	    curve_hair_material_v4.links.new(mix.outputs[0], base_color.inputs[0])
	    #curves_info.Intercept -> map_range.Value
	    curve_hair_material_v4.links.new(curves_info.outputs[1], map_range.inputs[0])
	    #color_cutoff.Value -> map_range.To Max
	    curve_hair_material_v4.links.new(color_cutoff.outputs[0], map_range.inputs[4])
	    #random_factor_adjustment.Color -> random_factor_location.Value
	    curve_hair_material_v4.links.new(random_factor_adjustment.outputs[0], random_factor_location.inputs[1])
	    #curves_info.Random -> random_factor_adjustment.Fac
	    curve_hair_material_v4.links.new(curves_info.outputs[5], random_factor_adjustment.inputs[0])
	    #random_factor_location.Value -> mix.B
	    curve_hair_material_v4.links.new(random_factor_location.outputs[0], mix.inputs[3])
	    #mix_factor_adjustment.Color -> mix.Factor
	    curve_hair_material_v4.links.new(mix_factor_adjustment.outputs[0], mix.inputs[0])
	    #curves_info.Random -> mix_factor_adjustment.Fac
	    curve_hair_material_v4.links.new(curves_info.outputs[5], mix_factor_adjustment.inputs[0])
	    return curve_hair_material_v4
	return curve_hair_material_v4_node_group()

	

	
