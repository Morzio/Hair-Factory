import bpy, mathutils



def node(mat):
	#initialize CURVE_HAIR_MATERIAL_V3 node group
	def curve_hair_material_v3_node_group():
	
	    curve_hair_material_v3 = mat.node_tree
	    #start with a clean node tree
	    for node in curve_hair_material_v3.nodes:
	        curve_hair_material_v3.nodes.remove(node)
	    curve_hair_material_v3.color_tag = 'NONE'
	    curve_hair_material_v3.description = ""
	    curve_hair_material_v3.default_group_node_width = 140
	    
	
	    #curve_hair_material_v3 interface
	
	    #initialize curve_hair_material_v3 nodes
	    #node Material Output
	    material_output = curve_hair_material_v3.nodes.new("ShaderNodeOutputMaterial")
	    material_output.name = "Material Output"
	    material_output.is_active_output = True
	    material_output.target = 'ALL'
	    #Displacement
	    material_output.inputs[2].default_value = (0.0, 0.0, 0.0)
	    #Thickness
	    material_output.inputs[3].default_value = 0.0
	
	    #node Principled Hair BSDF
	    principled_hair_bsdf = curve_hair_material_v3.nodes.new("ShaderNodeBsdfHairPrincipled")
	    principled_hair_bsdf.name = "Principled Hair BSDF"
	    principled_hair_bsdf.model = 'CHIANG'
	    principled_hair_bsdf.parametrization = 'COLOR'
	    #Roughness
	    principled_hair_bsdf.inputs[6].default_value = 0.30000001192092896
	    #Radial Roughness
	    principled_hair_bsdf.inputs[7].default_value = 0.30000001192092896
	    #Coat
	    principled_hair_bsdf.inputs[8].default_value = 0.0
	    #IOR
	    principled_hair_bsdf.inputs[9].default_value = 1.5499999523162842
	    #Offset
	    principled_hair_bsdf.inputs[10].default_value = 0.03490658476948738
	    #Random Roughness
	    principled_hair_bsdf.inputs[12].default_value = 0.0
	    #Random
	    principled_hair_bsdf.inputs[13].default_value = 0.0
	
	    #node Base Color
	    base_color = curve_hair_material_v3.nodes.new("ShaderNodeValToRGB")
	    base_color.label = "Base Color"
	    base_color.name = "Base Color"
	    base_color.color_ramp.color_mode = 'RGB'
	    base_color.color_ramp.hue_interpolation = 'NEAR'
	    base_color.color_ramp.interpolation = 'EASE'
	
	    #initialize color ramp elements
	    base_color.color_ramp.elements.remove(base_color.color_ramp.elements[0])
	    base_color_cre_0 = base_color.color_ramp.elements[0]
	    base_color_cre_0.position = 0.6733332276344299
	    base_color_cre_0.alpha = 1.0
	    base_color_cre_0.color = (0.0176415853202343, 0.005605380982160568, 0.0021241612266749144, 1.0)
	
	    base_color_cre_1 = base_color.color_ramp.elements.new(0.9363635778427124)
	    base_color_cre_1.alpha = 1.0
	    base_color_cre_1.color = (0.09774497151374817, 0.10102304816246033, 0.02086935192346573, 1.0)
	
	
	    #node Curves Info
	    curves_info = curve_hair_material_v3.nodes.new("ShaderNodeHairInfo")
	    curves_info.name = "Curves Info"
	    curves_info.outputs[0].hide = True
	    curves_info.outputs[1].hide = True
	    curves_info.outputs[2].hide = True
	    curves_info.outputs[3].hide = True
	    curves_info.outputs[4].hide = True
	
	    #node Random Factor Adjustment
	    random_factor_adjustment = curve_hair_material_v3.nodes.new("ShaderNodeValToRGB")
	    random_factor_adjustment.label = "Random Factor Adjustment"
	    random_factor_adjustment.name = "Random Factor Adjustment"
	    random_factor_adjustment.color_ramp.color_mode = 'RGB'
	    random_factor_adjustment.color_ramp.hue_interpolation = 'NEAR'
	    random_factor_adjustment.color_ramp.interpolation = 'LINEAR'
	
	    #initialize color ramp elements
	    random_factor_adjustment.color_ramp.elements.remove(random_factor_adjustment.color_ramp.elements[0])
	    random_factor_adjustment_cre_0 = random_factor_adjustment.color_ramp.elements[0]
	    random_factor_adjustment_cre_0.position = 0.0
	    random_factor_adjustment_cre_0.alpha = 1.0
	    random_factor_adjustment_cre_0.color = (0.0, 0.0, 0.0, 1.0)
	
	    random_factor_adjustment_cre_1 = random_factor_adjustment.color_ramp.elements.new(1.0)
	    random_factor_adjustment_cre_1.alpha = 1.0
	    random_factor_adjustment_cre_1.color = (1.0, 1.0, 1.0, 1.0)
	
	
	    #node Color Blending
	    color_blending = curve_hair_material_v3.nodes.new("ShaderNodeFloatCurve")
	    color_blending.label = "Color Blending"
	    color_blending.name = "Color Blending"
	    #mapping settings
	    color_blending.mapping.extend = 'EXTRAPOLATED'
	    color_blending.mapping.tone = 'STANDARD'
	    color_blending.mapping.black_level = (0.0, 0.0, 0.0)
	    color_blending.mapping.white_level = (1.0, 1.0, 1.0)
	    color_blending.mapping.clip_min_x = 0.0
	    color_blending.mapping.clip_min_y = 0.0
	    color_blending.mapping.clip_max_x = 1.0
	    color_blending.mapping.clip_max_y = 1.0
	    color_blending.mapping.use_clip = True
	    #curve 0
	    color_blending_curve_0 = color_blending.mapping.curves[0]
	    color_blending_curve_0_point_0 = color_blending_curve_0.points[0]
	    color_blending_curve_0_point_0.location = (0.0, 1.0)
	    color_blending_curve_0_point_0.handle_type = 'AUTO'
	    color_blending_curve_0_point_1 = color_blending_curve_0.points[1]
	    color_blending_curve_0_point_1.location = (0.19545455276966095, 0.8375000357627869)
	    color_blending_curve_0_point_1.handle_type = 'AUTO'
	    color_blending_curve_0_point_2 = color_blending_curve_0.points.new(0.40909093618392944, 0.6624999046325684)
	    color_blending_curve_0_point_2.handle_type = 'AUTO'
	    color_blending_curve_0_point_3 = color_blending_curve_0.points.new(0.6000000238418579, 0.768750011920929)
	    color_blending_curve_0_point_3.handle_type = 'AUTO'
	    color_blending_curve_0_point_4 = color_blending_curve_0.points.new(0.7681818604469299, 0.925000011920929)
	    color_blending_curve_0_point_4.handle_type = 'AUTO'
	    color_blending_curve_0_point_5 = color_blending_curve_0.points.new(1.0, 1.0)
	    color_blending_curve_0_point_5.handle_type = 'AUTO'
	    #update curve after changes
	    color_blending.mapping.update()
	    #Factor
	    color_blending.inputs[0].default_value = 1.0
	
	
	    #Set locations
	    material_output.location = (462.1377258300781, 479.5726013183594)
	    principled_hair_bsdf.location = (180.30996704101562, 454.1291198730469)
	    base_color.location = (-144.6290283203125, 379.65240478515625)
	    curves_info.location = (-855.9600830078125, 311.8206481933594)
	    random_factor_adjustment.location = (-686.4949951171875, 465.82977294921875)
	    color_blending.location = (-409.65826416015625, 463.66290283203125)
	
	    #Set dimensions
	    material_output.width, material_output.height = 140.0, 100.0
	    principled_hair_bsdf.width, principled_hair_bsdf.height = 240.0, 100.0
	    base_color.width, base_color.height = 240.0, 100.0
	    curves_info.width, curves_info.height = 140.0, 100.0
	    random_factor_adjustment.width, random_factor_adjustment.height = 240.0, 100.0
	    color_blending.width, color_blending.height = 240.0, 100.0
	
	    #initialize curve_hair_material_v3 links
	    #principled_hair_bsdf.BSDF -> material_output.Surface
	    curve_hair_material_v3.links.new(principled_hair_bsdf.outputs[0], material_output.inputs[0])
	    #base_color.Color -> principled_hair_bsdf.Color
	    curve_hair_material_v3.links.new(base_color.outputs[0], principled_hair_bsdf.inputs[0])
	    #curves_info.Random -> random_factor_adjustment.Fac
	    curve_hair_material_v3.links.new(curves_info.outputs[5], random_factor_adjustment.inputs[0])
	    #random_factor_adjustment.Color -> color_blending.Value
	    curve_hair_material_v3.links.new(random_factor_adjustment.outputs[0], color_blending.inputs[1])
	    #color_blending.Value -> base_color.Fac
	    curve_hair_material_v3.links.new(color_blending.outputs[0], base_color.inputs[0])
	    return curve_hair_material_v3
	return curve_hair_material_v3_node_group()

	

	
