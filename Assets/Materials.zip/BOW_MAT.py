import bpy, mathutils



def node(mat):
	#initialize BOW_MAT node group
	def bow_mat_node_group():
	
	    bow_mat = mat.node_tree
	    #start with a clean node tree
	    for node in bow_mat.nodes:
	        bow_mat.nodes.remove(node)
	    bow_mat.color_tag = 'NONE'
	    bow_mat.description = ""
	    bow_mat.default_group_node_width = 140
	    
	
	    #bow_mat interface
	
	    #initialize bow_mat nodes
	    #node Principled BSDF
	    principled_bsdf = bow_mat.nodes.new("ShaderNodeBsdfPrincipled")
	    principled_bsdf.name = "Principled BSDF"
	    principled_bsdf.distribution = 'MULTI_GGX'
	    principled_bsdf.subsurface_method = 'RANDOM_WALK'
	    #Metallic
	    principled_bsdf.inputs[1].default_value = 0.0
	    #Roughness
	    principled_bsdf.inputs[2].default_value = 0.5
	    #IOR
	    principled_bsdf.inputs[3].default_value = 1.5
	    #Alpha
	    principled_bsdf.inputs[4].default_value = 1.0
	    #Normal
	    principled_bsdf.inputs[5].default_value = (0.0, 0.0, 0.0)
	    #Diffuse Roughness
	    principled_bsdf.inputs[7].default_value = 0.0
	    #Subsurface Weight
	    principled_bsdf.inputs[8].default_value = 0.0
	    #Subsurface Radius
	    principled_bsdf.inputs[9].default_value = (1.0, 0.20000000298023224, 0.10000000149011612)
	    #Subsurface Scale
	    principled_bsdf.inputs[10].default_value = 0.05000000074505806
	    #Subsurface Anisotropy
	    principled_bsdf.inputs[12].default_value = 0.0
	    #Specular IOR Level
	    principled_bsdf.inputs[13].default_value = 0.5
	    #Specular Tint
	    principled_bsdf.inputs[14].default_value = (1.0, 1.0, 1.0, 1.0)
	    #Anisotropic
	    principled_bsdf.inputs[15].default_value = 0.0
	    #Anisotropic Rotation
	    principled_bsdf.inputs[16].default_value = 0.0
	    #Tangent
	    principled_bsdf.inputs[17].default_value = (0.0, 0.0, 0.0)
	    #Transmission Weight
	    principled_bsdf.inputs[18].default_value = 0.0
	    #Coat Weight
	    principled_bsdf.inputs[19].default_value = 0.0
	    #Coat Roughness
	    principled_bsdf.inputs[20].default_value = 0.029999999329447746
	    #Coat IOR
	    principled_bsdf.inputs[21].default_value = 1.5
	    #Coat Tint
	    principled_bsdf.inputs[22].default_value = (1.0, 1.0, 1.0, 1.0)
	    #Coat Normal
	    principled_bsdf.inputs[23].default_value = (0.0, 0.0, 0.0)
	    #Sheen Weight
	    principled_bsdf.inputs[24].default_value = 0.0
	    #Sheen Roughness
	    principled_bsdf.inputs[25].default_value = 0.5
	    #Sheen Tint
	    principled_bsdf.inputs[26].default_value = (1.0, 1.0, 1.0, 1.0)
	    #Emission Color
	    principled_bsdf.inputs[27].default_value = (1.0, 1.0, 1.0, 1.0)
	    #Emission Strength
	    principled_bsdf.inputs[28].default_value = 0.0
	    #Thin Film Thickness
	    principled_bsdf.inputs[29].default_value = 0.0
	    #Thin Film IOR
	    principled_bsdf.inputs[30].default_value = 1.3300000429153442
	
	    #node Material Output
	    material_output = bow_mat.nodes.new("ShaderNodeOutputMaterial")
	    material_output.name = "Material Output"
	    material_output.is_active_output = True
	    material_output.target = 'ALL'
	    #Displacement
	    material_output.inputs[2].default_value = (0.0, 0.0, 0.0)
	    #Thickness
	    material_output.inputs[3].default_value = 0.0
	
	    #node Attribute
	    attribute = bow_mat.nodes.new("ShaderNodeAttribute")
	    attribute.name = "Attribute"
	    attribute.attribute_name = "bow_col"
	    attribute.attribute_type = 'GEOMETRY'
	
	    #node Frame
	    frame = bow_mat.nodes.new("NodeFrame")
	    frame.label = "Instance Colors"
	    frame.name = "Frame"
	    frame.label_size = 20
	    frame.shrink = True
	
	    #node Color Ramp.002
	    color_ramp_002 = bow_mat.nodes.new("ShaderNodeValToRGB")
	    color_ramp_002.name = "Color Ramp.002"
	    color_ramp_002.color_ramp.color_mode = 'RGB'
	    color_ramp_002.color_ramp.hue_interpolation = 'NEAR'
	    color_ramp_002.color_ramp.interpolation = 'CONSTANT'
	
	    #initialize color ramp elements
	    color_ramp_002.color_ramp.elements.remove(color_ramp_002.color_ramp.elements[0])
	    color_ramp_002_cre_0 = color_ramp_002.color_ramp.elements[0]
	    color_ramp_002_cre_0.position = 0.0
	    color_ramp_002_cre_0.alpha = 1.0
	    color_ramp_002_cre_0.color = (0.0, 0.0, 0.0, 1.0)
	
	    color_ramp_002_cre_1 = color_ramp_002.color_ramp.elements.new(0.25)
	    color_ramp_002_cre_1.alpha = 1.0
	    color_ramp_002_cre_1.color = (0.0, 0.0, 1.0, 1.0)
	
	    color_ramp_002_cre_2 = color_ramp_002.color_ramp.elements.new(0.49033814668655396)
	    color_ramp_002_cre_2.alpha = 1.0
	    color_ramp_002_cre_2.color = (1.0, 0.0, 0.0, 1.0)
	
	    color_ramp_002_cre_3 = color_ramp_002.color_ramp.elements.new(0.7391304969787598)
	    color_ramp_002_cre_3.alpha = 1.0
	    color_ramp_002_cre_3.color = (0.0, 1.0, 0.0, 1.0)
	
	
	    #Set parents
	    attribute.parent = frame
	    color_ramp_002.parent = frame
	
	    #Set locations
	    principled_bsdf.location = (183.64707946777344, 304.3290710449219)
	    material_output.location = (464.0830078125, 328.65789794921875)
	    attribute.location = (29.665374755859375, -147.2599639892578)
	    frame.location = (-304.0, 322.0)
	    color_ramp_002.location = (186.50942993164062, -39.685760498046875)
	
	    #Set dimensions
	    principled_bsdf.width, principled_bsdf.height = 240.0, 100.0
	    material_output.width, material_output.height = 140.0, 100.0
	    attribute.width, attribute.height = 140.0, 100.0
	    frame.width, frame.height = 457.0, 347.0
	    color_ramp_002.width, color_ramp_002.height = 240.0, 100.0
	
	    #initialize bow_mat links
	    #principled_bsdf.BSDF -> material_output.Surface
	    bow_mat.links.new(principled_bsdf.outputs[0], material_output.inputs[0])
	    #color_ramp_002.Color -> principled_bsdf.Base Color
	    bow_mat.links.new(color_ramp_002.outputs[0], principled_bsdf.inputs[0])
	    #attribute.Fac -> color_ramp_002.Fac
	    bow_mat.links.new(attribute.outputs[2], color_ramp_002.inputs[0])
	    return bow_mat
	return bow_mat_node_group()

	

	
