import bpy, mathutils



def node(mat):
	#initialize MESH_TEXTURE_MAT_V3 node group
	def mesh_texture_mat_v3_node_group():
	
	    mesh_texture_mat_v3 = mat.node_tree
	    #start with a clean node tree
	    for node in mesh_texture_mat_v3.nodes:
	        mesh_texture_mat_v3.nodes.remove(node)
	    mesh_texture_mat_v3.color_tag = 'NONE'
	    mesh_texture_mat_v3.description = ""
	    mesh_texture_mat_v3.default_group_node_width = 140
	    
	
	    #mesh_texture_mat_v3 interface
	
	    #initialize mesh_texture_mat_v3 nodes
	    #node Normal
	    normal = mesh_texture_mat_v3.nodes.new("ShaderNodeTexImage")
	    normal.label = "Normal"
	    normal.name = "Normal"
	    normal.extension = 'REPEAT'
	    normal.image_user.frame_current = 0
	    normal.image_user.frame_duration = 100
	    normal.image_user.frame_offset = 0
	    normal.image_user.frame_start = 1
	    normal.image_user.tile = 0
	    normal.image_user.use_auto_refresh = False
	    normal.image_user.use_cyclic = False
	    normal.interpolation = 'Linear'
	    normal.projection = 'FLAT'
	    normal.projection_blend = 0.0
	
	    #node Diffuse
	    diffuse = mesh_texture_mat_v3.nodes.new("ShaderNodeTexImage")
	    diffuse.label = "Diffuse"
	    diffuse.name = "Diffuse"
	    diffuse.extension = 'REPEAT'
	    diffuse.image_user.frame_current = 0
	    diffuse.image_user.frame_duration = 100
	    diffuse.image_user.frame_offset = 0
	    diffuse.image_user.frame_start = 1
	    diffuse.image_user.tile = 0
	    diffuse.image_user.use_auto_refresh = False
	    diffuse.image_user.use_cyclic = False
	    diffuse.interpolation = 'Linear'
	    diffuse.projection = 'FLAT'
	    diffuse.projection_blend = 0.0
	
	    #node Texture Coordinate.001
	    texture_coordinate_001 = mesh_texture_mat_v3.nodes.new("ShaderNodeTexCoord")
	    texture_coordinate_001.name = "Texture Coordinate.001"
	    texture_coordinate_001.from_instancer = False
	    texture_coordinate_001.outputs[0].hide = True
	    texture_coordinate_001.outputs[1].hide = True
	    texture_coordinate_001.outputs[3].hide = True
	    texture_coordinate_001.outputs[4].hide = True
	    texture_coordinate_001.outputs[5].hide = True
	    texture_coordinate_001.outputs[6].hide = True
	
	    #node Glitter
	    glitter = mesh_texture_mat_v3.nodes.new("ShaderNodeTexImage")
	    glitter.label = "Glitter"
	    glitter.name = "Glitter"
	    glitter.extension = 'REPEAT'
	    glitter.image_user.frame_current = 0
	    glitter.image_user.frame_duration = 100
	    glitter.image_user.frame_offset = 0
	    glitter.image_user.frame_start = 1
	    glitter.image_user.tile = 0
	    glitter.image_user.use_auto_refresh = False
	    glitter.image_user.use_cyclic = False
	    glitter.interpolation = 'Linear'
	    glitter.projection = 'FLAT'
	    glitter.projection_blend = 0.0
	
	    #node Principled BSDF
	    principled_bsdf = mesh_texture_mat_v3.nodes.new("ShaderNodeBsdfPrincipled")
	    principled_bsdf.name = "Principled BSDF"
	    principled_bsdf.distribution = 'MULTI_GGX'
	    principled_bsdf.subsurface_method = 'RANDOM_WALK'
	    #IOR
	    principled_bsdf.inputs[3].default_value = 1.5
	    #Diffuse Roughness
	    principled_bsdf.inputs[7].default_value = 0.0
	    #Subsurface Weight
	    principled_bsdf.inputs[8].default_value = 0.0
	    #Subsurface Radius
	    principled_bsdf.inputs[9].default_value = (1.0, 0.20000000298023224, 0.10000000149011612)
	    #Subsurface Scale
	    principled_bsdf.inputs[10].default_value = 0.05000000074505806
	    #Subsurface Anisotropy
	    principled_bsdf.inputs[12].default_value = 0.0
	    #Specular IOR Level
	    principled_bsdf.inputs[13].default_value = 0.5
	    #Specular Tint
	    principled_bsdf.inputs[14].default_value = (1.0, 1.0, 1.0, 1.0)
	    #Anisotropic
	    principled_bsdf.inputs[15].default_value = 0.0
	    #Anisotropic Rotation
	    principled_bsdf.inputs[16].default_value = 0.0
	    #Tangent
	    principled_bsdf.inputs[17].default_value = (0.0, 0.0, 0.0)
	    #Transmission Weight
	    principled_bsdf.inputs[18].default_value = 0.0
	    #Coat Weight
	    principled_bsdf.inputs[19].default_value = 0.0
	    #Coat Roughness
	    principled_bsdf.inputs[20].default_value = 0.029999999329447746
	    #Coat IOR
	    principled_bsdf.inputs[21].default_value = 1.5
	    #Coat Tint
	    principled_bsdf.inputs[22].default_value = (1.0, 1.0, 1.0, 1.0)
	    #Coat Normal
	    principled_bsdf.inputs[23].default_value = (0.0, 0.0, 0.0)
	    #Sheen Weight
	    principled_bsdf.inputs[24].default_value = 0.0
	    #Sheen Roughness
	    principled_bsdf.inputs[25].default_value = 0.5
	    #Sheen Tint
	    principled_bsdf.inputs[26].default_value = (1.0, 1.0, 1.0, 1.0)
	    #Emission Color
	    principled_bsdf.inputs[27].default_value = (1.0, 1.0, 1.0, 1.0)
	    #Emission Strength
	    principled_bsdf.inputs[28].default_value = 0.0
	    #Thin Film Thickness
	    principled_bsdf.inputs[29].default_value = 0.0
	    #Thin Film IOR
	    principled_bsdf.inputs[30].default_value = 1.3300000429153442
	
	    #node Separate Color
	    separate_color = mesh_texture_mat_v3.nodes.new("ShaderNodeSeparateColor")
	    separate_color.name = "Separate Color"
	    separate_color.mode = 'RGB'
	    separate_color.outputs[0].hide = True
	
	    #node Material Output.001
	    material_output_001 = mesh_texture_mat_v3.nodes.new("ShaderNodeOutputMaterial")
	    material_output_001.name = "Material Output.001"
	    material_output_001.is_active_output = True
	    material_output_001.target = 'ALL'
	    #Displacement
	    material_output_001.inputs[2].default_value = (0.0, 0.0, 0.0)
	    #Thickness
	    material_output_001.inputs[3].default_value = 0.0
	
	    #node Mix
	    mix = mesh_texture_mat_v3.nodes.new("ShaderNodeMix")
	    mix.name = "Mix"
	    mix.blend_type = 'MIX'
	    mix.clamp_factor = True
	    mix.clamp_result = False
	    mix.data_type = 'RGBA'
	    mix.factor_mode = 'UNIFORM'
	    #Factor_Float
	    mix.inputs[0].default_value = 0.10000002384185791
	
	    #node Normal Map
	    normal_map = mesh_texture_mat_v3.nodes.new("ShaderNodeNormalMap")
	    normal_map.name = "Normal Map"
	    normal_map.space = 'TANGENT'
	    normal_map.uv_map = ""
	    #Strength
	    normal_map.inputs[0].default_value = 1.0
	
	
	    #Set locations
	    normal.location = (-825.3021240234375, 371.7358093261719)
	    diffuse.location = (-826.6668090820312, 659.3126220703125)
	    texture_coordinate_001.location = (-1234.7554931640625, 323.1910705566406)
	    glitter.location = (-820.9412841796875, 82.15324401855469)
	    principled_bsdf.location = (-88.14254760742188, 420.815185546875)
	    separate_color.location = (-457.22216796875, 289.0557556152344)
	    material_output_001.location = (241.17686462402344, 443.1648254394531)
	    mix.location = (-458.389404296875, 150.22738647460938)
	    normal_map.location = (-278.0, 212.36680603027344)
	
	    #Set dimensions
	    normal.width, normal.height = 240.0, 100.0
	    diffuse.width, diffuse.height = 240.0, 100.0
	    texture_coordinate_001.width, texture_coordinate_001.height = 140.0, 100.0
	    glitter.width, glitter.height = 240.0, 100.0
	    principled_bsdf.width, principled_bsdf.height = 240.0, 100.0
	    separate_color.width, separate_color.height = 140.0, 100.0
	    material_output_001.width, material_output_001.height = 140.0, 100.0
	    mix.width, mix.height = 140.0, 100.0
	    normal_map.width, normal_map.height = 150.0, 100.0
	
	    #initialize mesh_texture_mat_v3 links
	    #texture_coordinate_001.UV -> glitter.Vector
	    mesh_texture_mat_v3.links.new(texture_coordinate_001.outputs[2], glitter.inputs[0])
	    #glitter.Color -> separate_color.Color
	    mesh_texture_mat_v3.links.new(glitter.outputs[0], separate_color.inputs[0])
	    #diffuse.Color -> principled_bsdf.Base Color
	    mesh_texture_mat_v3.links.new(diffuse.outputs[0], principled_bsdf.inputs[0])
	    #principled_bsdf.BSDF -> material_output_001.Surface
	    mesh_texture_mat_v3.links.new(principled_bsdf.outputs[0], material_output_001.inputs[0])
	    #diffuse.Alpha -> principled_bsdf.Alpha
	    mesh_texture_mat_v3.links.new(diffuse.outputs[1], principled_bsdf.inputs[4])
	    #separate_color.Green -> principled_bsdf.Roughness
	    mesh_texture_mat_v3.links.new(separate_color.outputs[1], principled_bsdf.inputs[2])
	    #separate_color.Blue -> principled_bsdf.Metallic
	    mesh_texture_mat_v3.links.new(separate_color.outputs[2], principled_bsdf.inputs[1])
	    #normal.Color -> mix.A
	    mesh_texture_mat_v3.links.new(normal.outputs[0], mix.inputs[6])
	    #glitter.Color -> mix.B
	    mesh_texture_mat_v3.links.new(glitter.outputs[0], mix.inputs[7])
	    #normal_map.Normal -> principled_bsdf.Normal
	    mesh_texture_mat_v3.links.new(normal_map.outputs[0], principled_bsdf.inputs[5])
	    #texture_coordinate_001.UV -> normal.Vector
	    mesh_texture_mat_v3.links.new(texture_coordinate_001.outputs[2], normal.inputs[0])
	    #mix.Result -> normal_map.Color
	    mesh_texture_mat_v3.links.new(mix.outputs[2], normal_map.inputs[1])
	    #texture_coordinate_001.UV -> diffuse.Vector
	    mesh_texture_mat_v3.links.new(texture_coordinate_001.outputs[2], diffuse.inputs[0])
	    return mesh_texture_mat_v3
	return mesh_texture_mat_v3_node_group()

	

	
