import bpy, mathutils



def node(mat):
	#initialize CURVE_BRAID_MULTILAYER_V3 node group
	def curve_braid_multilayer_v3_node_group():
	
	    curve_braid_multilayer_v3 = mat.node_tree
	    #start with a clean node tree
	    for node in curve_braid_multilayer_v3.nodes:
	        curve_braid_multilayer_v3.nodes.remove(node)
	    curve_braid_multilayer_v3.color_tag = 'NONE'
	    curve_braid_multilayer_v3.description = ""
	    curve_braid_multilayer_v3.default_group_node_width = 140
	    
	
	    #curve_braid_multilayer_v3 interface
	
	    #initialize curve_braid_multilayer_v3 nodes
	    #node Material Output
	    material_output = curve_braid_multilayer_v3.nodes.new("ShaderNodeOutputMaterial")
	    material_output.name = "Material Output"
	    material_output.is_active_output = True
	    material_output.target = 'ALL'
	    #Displacement
	    material_output.inputs[2].default_value = (0.0, 0.0, 0.0)
	    #Thickness
	    material_output.inputs[3].default_value = 0.0
	
	    #node Principled Hair BSDF
	    principled_hair_bsdf = curve_braid_multilayer_v3.nodes.new("ShaderNodeBsdfHairPrincipled")
	    principled_hair_bsdf.name = "Principled Hair BSDF"
	    principled_hair_bsdf.model = 'CHIANG'
	    principled_hair_bsdf.parametrization = 'COLOR'
	    #Roughness
	    principled_hair_bsdf.inputs[6].default_value = 0.30000001192092896
	    #Radial Roughness
	    principled_hair_bsdf.inputs[7].default_value = 0.30000001192092896
	    #Coat
	    principled_hair_bsdf.inputs[8].default_value = 0.0
	    #IOR
	    principled_hair_bsdf.inputs[9].default_value = 1.5499999523162842
	    #Offset
	    principled_hair_bsdf.inputs[10].default_value = 0.03490658476948738
	    #Random Roughness
	    principled_hair_bsdf.inputs[12].default_value = 0.0
	    #Random
	    principled_hair_bsdf.inputs[13].default_value = 0.0
	
	    #node Attribute
	    attribute = curve_braid_multilayer_v3.nodes.new("ShaderNodeAttribute")
	    attribute.name = "Attribute"
	    attribute.attribute_name = "BRAIDZ_col_id"
	    attribute.attribute_type = 'GEOMETRY'
	
	    #node Multilayer
	    multilayer = curve_braid_multilayer_v3.nodes.new("ShaderNodeValToRGB")
	    multilayer.label = "Multilayer"
	    multilayer.name = "Multilayer"
	    multilayer.color_ramp.color_mode = 'RGB'
	    multilayer.color_ramp.hue_interpolation = 'NEAR'
	    multilayer.color_ramp.interpolation = 'B_SPLINE'
	
	    #initialize color ramp elements
	    multilayer.color_ramp.elements.remove(multilayer.color_ramp.elements[0])
	    multilayer_cre_0 = multilayer.color_ramp.elements[0]
	    multilayer_cre_0.position = 0.15458935499191284
	    multilayer_cre_0.alpha = 1.0
	    multilayer_cre_0.color = (1.0, 0.0, 0.0, 1.0)
	
	    multilayer_cre_1 = multilayer.color_ramp.elements.new(0.29408207535743713)
	    multilayer_cre_1.alpha = 1.0
	    multilayer_cre_1.color = (0.0289168618619442, 1.0, 0.0, 1.0)
	
	    multilayer_cre_2 = multilayer.color_ramp.elements.new(0.40458938479423523)
	    multilayer_cre_2.alpha = 1.0
	    multilayer_cre_2.color = (0.0, 0.0, 1.0, 1.0)
	
	
	    #node Curves Info
	    curves_info = curve_braid_multilayer_v3.nodes.new("ShaderNodeHairInfo")
	    curves_info.name = "Curves Info"
	
	    #node Math
	    math = curve_braid_multilayer_v3.nodes.new("ShaderNodeMath")
	    math.name = "Math"
	    math.hide = True
	    math.operation = 'MULTIPLY_ADD'
	    math.use_clamp = False
	
	
	    #Set locations
	    material_output.location = (462.1377258300781, 479.5726013183594)
	    principled_hair_bsdf.location = (180.30996704101562, 454.1291198730469)
	    attribute.location = (-437.7742614746094, 146.24365234375)
	    multilayer.location = (-94.23530578613281, 382.64324951171875)
	    curves_info.location = (-434.0669860839844, 314.36053466796875)
	    math.location = (-259.0884094238281, 203.32691955566406)
	
	    #Set dimensions
	    material_output.width, material_output.height = 140.0, 100.0
	    principled_hair_bsdf.width, principled_hair_bsdf.height = 240.0, 100.0
	    attribute.width, attribute.height = 140.0, 100.0
	    multilayer.width, multilayer.height = 240.0, 100.0
	    curves_info.width, curves_info.height = 140.0, 100.0
	    math.width, math.height = 140.0, 100.0
	
	    #initialize curve_braid_multilayer_v3 links
	    #principled_hair_bsdf.BSDF -> material_output.Surface
	    curve_braid_multilayer_v3.links.new(principled_hair_bsdf.outputs[0], material_output.inputs[0])
	    #multilayer.Color -> principled_hair_bsdf.Color
	    curve_braid_multilayer_v3.links.new(multilayer.outputs[0], principled_hair_bsdf.inputs[0])
	    #math.Value -> multilayer.Fac
	    curve_braid_multilayer_v3.links.new(math.outputs[0], multilayer.inputs[0])
	    #curves_info.Intercept -> math.Value
	    curve_braid_multilayer_v3.links.new(curves_info.outputs[1], math.inputs[0])
	    #attribute.Color -> math.Value
	    curve_braid_multilayer_v3.links.new(attribute.outputs[0], math.inputs[1])
	    #attribute.Fac -> math.Value
	    curve_braid_multilayer_v3.links.new(attribute.outputs[2], math.inputs[2])
	    return curve_braid_multilayer_v3
	return curve_braid_multilayer_v3_node_group()

	

	
