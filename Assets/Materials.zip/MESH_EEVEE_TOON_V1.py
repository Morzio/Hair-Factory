import bpy, mathutils



def node(mat):
	#initialize MESH_EEVEE_TOON_V1 node group
	def mesh_eevee_toon_v1_node_group():
	
	    mesh_eevee_toon_v1 = mat.node_tree
	    #start with a clean node tree
	    for node in mesh_eevee_toon_v1.nodes:
	        mesh_eevee_toon_v1.nodes.remove(node)
	    mesh_eevee_toon_v1.color_tag = 'NONE'
	    mesh_eevee_toon_v1.description = ""
	    mesh_eevee_toon_v1.default_group_node_width = 140
	    
	
	    #mesh_eevee_toon_v1 interface
	
	    #initialize mesh_eevee_toon_v1 nodes
	    #node Principled BSDF
	    principled_bsdf = mesh_eevee_toon_v1.nodes.new("ShaderNodeBsdfPrincipled")
	    principled_bsdf.name = "Principled BSDF"
	    principled_bsdf.distribution = 'MULTI_GGX'
	    principled_bsdf.subsurface_method = 'RANDOM_WALK'
	    #Base Color
	    principled_bsdf.inputs[0].default_value = (0.800000011920929, 0.800000011920929, 0.800000011920929, 1.0)
	    #Metallic
	    principled_bsdf.inputs[1].default_value = 0.0
	    #Roughness
	    principled_bsdf.inputs[2].default_value = 0.5
	    #IOR
	    principled_bsdf.inputs[3].default_value = 1.5
	    #Alpha
	    principled_bsdf.inputs[4].default_value = 1.0
	    #Normal
	    principled_bsdf.inputs[5].default_value = (0.0, 0.0, 0.0)
	    #Diffuse Roughness
	    principled_bsdf.inputs[7].default_value = 0.0
	    #Subsurface Weight
	    principled_bsdf.inputs[8].default_value = 0.0
	    #Subsurface Radius
	    principled_bsdf.inputs[9].default_value = (1.0, 0.20000000298023224, 0.10000000149011612)
	    #Subsurface Scale
	    principled_bsdf.inputs[10].default_value = 0.05000000074505806
	    #Subsurface Anisotropy
	    principled_bsdf.inputs[12].default_value = 0.0
	    #Specular IOR Level
	    principled_bsdf.inputs[13].default_value = 0.5
	    #Specular Tint
	    principled_bsdf.inputs[14].default_value = (1.0, 1.0, 1.0, 1.0)
	    #Anisotropic
	    principled_bsdf.inputs[15].default_value = 0.0
	    #Anisotropic Rotation
	    principled_bsdf.inputs[16].default_value = 0.0
	    #Tangent
	    principled_bsdf.inputs[17].default_value = (0.0, 0.0, 0.0)
	    #Transmission Weight
	    principled_bsdf.inputs[18].default_value = 0.0
	    #Coat Weight
	    principled_bsdf.inputs[19].default_value = 0.0
	    #Coat Roughness
	    principled_bsdf.inputs[20].default_value = 0.029999999329447746
	    #Coat IOR
	    principled_bsdf.inputs[21].default_value = 1.5
	    #Coat Tint
	    principled_bsdf.inputs[22].default_value = (1.0, 1.0, 1.0, 1.0)
	    #Coat Normal
	    principled_bsdf.inputs[23].default_value = (0.0, 0.0, 0.0)
	    #Sheen Weight
	    principled_bsdf.inputs[24].default_value = 0.0
	    #Sheen Roughness
	    principled_bsdf.inputs[25].default_value = 0.5
	    #Sheen Tint
	    principled_bsdf.inputs[26].default_value = (1.0, 1.0, 1.0, 1.0)
	    #Emission Color
	    principled_bsdf.inputs[27].default_value = (1.0, 1.0, 1.0, 1.0)
	    #Emission Strength
	    principled_bsdf.inputs[28].default_value = 0.0
	    #Thin Film Thickness
	    principled_bsdf.inputs[29].default_value = 0.0
	    #Thin Film IOR
	    principled_bsdf.inputs[30].default_value = 1.3300000429153442
	
	    #node Material Output
	    material_output = mesh_eevee_toon_v1.nodes.new("ShaderNodeOutputMaterial")
	    material_output.name = "Material Output"
	    material_output.is_active_output = True
	    material_output.target = 'ALL'
	    #Displacement
	    material_output.inputs[2].default_value = (0.0, 0.0, 0.0)
	    #Thickness
	    material_output.inputs[3].default_value = 0.0
	
	    #node Shader to RGB
	    shader_to_rgb = mesh_eevee_toon_v1.nodes.new("ShaderNodeShaderToRGB")
	    shader_to_rgb.name = "Shader to RGB"
	
	    #node Toon Color
	    toon_color = mesh_eevee_toon_v1.nodes.new("ShaderNodeValToRGB")
	    toon_color.label = "Toon Color"
	    toon_color.name = "Toon Color"
	    toon_color.color_ramp.color_mode = 'RGB'
	    toon_color.color_ramp.hue_interpolation = 'NEAR'
	    toon_color.color_ramp.interpolation = 'CONSTANT'
	
	    #initialize color ramp elements
	    toon_color.color_ramp.elements.remove(toon_color.color_ramp.elements[0])
	    toon_color_cre_0 = toon_color.color_ramp.elements[0]
	    toon_color_cre_0.position = 0.0
	    toon_color_cre_0.alpha = 1.0
	    toon_color_cre_0.color = (0.002485837321728468, 0.0, 1.0, 1.0)
	
	    toon_color_cre_1 = toon_color.color_ramp.elements.new(0.5477274656295776)
	    toon_color_cre_1.alpha = 1.0
	    toon_color_cre_1.color = (0.0, 1.0, 0.8697147965431213, 1.0)
	
	    toon_color_cre_2 = toon_color.color_ramp.elements.new(0.9636363983154297)
	    toon_color_cre_2.alpha = 1.0
	    toon_color_cre_2.color = (1.0, 1.0, 1.0, 1.0)
	
	
	
	    #Set locations
	    principled_bsdf.location = (10.0, 300.0)
	    material_output.location = (763.98779296875, 300.0)
	    shader_to_rgb.location = (296.5771484375, 298.78509521484375)
	    toon_color.location = (456.57373046875, 315.6661682128906)
	
	    #Set dimensions
	    principled_bsdf.width, principled_bsdf.height = 240.0, 100.0
	    material_output.width, material_output.height = 140.0, 100.0
	    shader_to_rgb.width, shader_to_rgb.height = 140.0, 100.0
	    toon_color.width, toon_color.height = 240.0, 100.0
	
	    #initialize mesh_eevee_toon_v1 links
	    #toon_color.Color -> material_output.Surface
	    mesh_eevee_toon_v1.links.new(toon_color.outputs[0], material_output.inputs[0])
	    #principled_bsdf.BSDF -> shader_to_rgb.Shader
	    mesh_eevee_toon_v1.links.new(principled_bsdf.outputs[0], shader_to_rgb.inputs[0])
	    #shader_to_rgb.Color -> toon_color.Fac
	    mesh_eevee_toon_v1.links.new(shader_to_rgb.outputs[0], toon_color.inputs[0])
	    return mesh_eevee_toon_v1
	return mesh_eevee_toon_v1_node_group()

	

	
