import bpy, mathutils



def node(mat):
	#initialize Color_Rotation_Control node group
	def color_rotation_control_node_group():
	
	    color_rotation_control = bpy.data.node_groups.new(type = 'ShaderNodeTree', name = "Color_Rotation_Control")
	
	    color_rotation_control.color_tag = 'NONE'
	    color_rotation_control.description = "Control the rotation of the Color Ramp"
	    color_rotation_control.default_group_node_width = 140
	    
	
	    #color_rotation_control interface
	    #Socket Fac
	    fac_socket = color_rotation_control.interface.new_socket(name = "Fac", in_out='OUTPUT', socket_type = 'NodeSocketFloat')
	    fac_socket.default_value = 0.0
	    fac_socket.min_value = -3.4028234663852886e+38
	    fac_socket.max_value = 3.4028234663852886e+38
	    fac_socket.subtype = 'NONE'
	    fac_socket.attribute_domain = 'POINT'
	
	    #Socket Vector
	    vector_socket = color_rotation_control.interface.new_socket(name = "Vector", in_out='INPUT', socket_type = 'NodeSocketVector')
	    vector_socket.default_value = (0.0, 0.0, 0.0)
	    vector_socket.min_value = -3.4028234663852886e+38
	    vector_socket.max_value = 3.4028234663852886e+38
	    vector_socket.subtype = 'NONE'
	    vector_socket.attribute_domain = 'POINT'
	
	    #Socket Rotation
	    rotation_socket = color_rotation_control.interface.new_socket(name = "Rotation", in_out='INPUT', socket_type = 'NodeSocketInt')
	    rotation_socket.default_value = 0
	    rotation_socket.min_value = 0
	    rotation_socket.max_value = 90
	    rotation_socket.subtype = 'FACTOR'
	    rotation_socket.attribute_domain = 'POINT'
	
	
	    #initialize color_rotation_control nodes
	    #node Group Output
	    group_output = color_rotation_control.nodes.new("NodeGroupOutput")
	    group_output.name = "Group Output"
	    group_output.is_active_output = True
	    group_output.inputs[1].hide = True
	
	    #node Group Input
	    group_input = color_rotation_control.nodes.new("NodeGroupInput")
	    group_input.name = "Group Input"
	    group_input.outputs[2].hide = True
	
	    #node Gradient Texture
	    gradient_texture = color_rotation_control.nodes.new("ShaderNodeTexGradient")
	    gradient_texture.name = "Gradient Texture"
	    gradient_texture.gradient_type = 'LINEAR'
	    gradient_texture.outputs[0].hide = True
	
	    #node Mapping
	    mapping = color_rotation_control.nodes.new("ShaderNodeMapping")
	    mapping.name = "Mapping"
	    mapping.vector_type = 'TEXTURE'
	    mapping.inputs[1].hide = True
	    mapping.inputs[3].hide = True
	    #Location
	    mapping.inputs[1].default_value = (-1.0, -1.0, 0.0)
	    #Scale
	    mapping.inputs[3].default_value = (2.0, 1.0, 1.0)
	
	    #node Combine XYZ
	    combine_xyz = color_rotation_control.nodes.new("ShaderNodeCombineXYZ")
	    combine_xyz.name = "Combine XYZ"
	    combine_xyz.hide = True
	    combine_xyz.inputs[0].hide = True
	    combine_xyz.inputs[1].hide = True
	    #X
	    combine_xyz.inputs[0].default_value = 0.0
	    #Y
	    combine_xyz.inputs[1].default_value = 0.0
	
	    #node Math
	    math = color_rotation_control.nodes.new("ShaderNodeMath")
	    math.name = "Math"
	    math.hide = True
	    math.operation = 'RADIANS'
	    math.use_clamp = False
	
	
	    #Set locations
	    group_output.location = (583.1822509765625, 0.0)
	    group_input.location = (-290.0, -99.34418487548828)
	    gradient_texture.location = (393.1822204589844, -1.288037896156311)
	    mapping.location = (213.1822052001953, -50.158058166503906)
	    combine_xyz.location = (55.946292877197266, -143.20831298828125)
	    math.location = (-109.28814697265625, -144.53616333007812)
	
	    #Set dimensions
	    group_output.width, group_output.height = 140.0, 100.0
	    group_input.width, group_input.height = 140.0, 100.0
	    gradient_texture.width, gradient_texture.height = 140.0, 100.0
	    mapping.width, mapping.height = 140.0, 100.0
	    combine_xyz.width, combine_xyz.height = 140.0, 100.0
	    math.width, math.height = 140.0, 100.0
	
	    #initialize color_rotation_control links
	    #mapping.Vector -> gradient_texture.Vector
	    color_rotation_control.links.new(mapping.outputs[0], gradient_texture.inputs[0])
	    #group_input.Vector -> mapping.Vector
	    color_rotation_control.links.new(group_input.outputs[0], mapping.inputs[0])
	    #gradient_texture.Fac -> group_output.Fac
	    color_rotation_control.links.new(gradient_texture.outputs[1], group_output.inputs[0])
	    #combine_xyz.Vector -> mapping.Rotation
	    color_rotation_control.links.new(combine_xyz.outputs[0], mapping.inputs[2])
	    #math.Value -> combine_xyz.Z
	    color_rotation_control.links.new(math.outputs[0], combine_xyz.inputs[2])
	    #group_input.Rotation -> math.Value
	    color_rotation_control.links.new(group_input.outputs[1], math.inputs[0])
	    return color_rotation_control
	
	color_rotation_control = color_rotation_control_node_group()
	
	#initialize HAIR_TEXTURE_CREATOR_MATERIAL node group
	def hair_texture_creator_material_node_group():
	
	    hair_texture_creator_material = mat.node_tree
	    #start with a clean node tree
	    for node in hair_texture_creator_material.nodes:
	        hair_texture_creator_material.nodes.remove(node)
	    hair_texture_creator_material.color_tag = 'NONE'
	    hair_texture_creator_material.description = ""
	    hair_texture_creator_material.default_group_node_width = 140
	    
	
	    #hair_texture_creator_material interface
	
	    #initialize hair_texture_creator_material nodes
	    #node Alpha Output
	    alpha_output = hair_texture_creator_material.nodes.new("ShaderNodeOutputMaterial")
	    alpha_output.label = "Alpha Output"
	    alpha_output.name = "Alpha Output"
	    alpha_output.is_active_output = True
	    alpha_output.target = 'ALL'
	    alpha_output.inputs[1].hide = True
	    alpha_output.inputs[2].hide = True
	    alpha_output.inputs[3].hide = True
	    #Displacement
	    alpha_output.inputs[2].default_value = (0.0, 0.0, 0.0)
	    #Thickness
	    alpha_output.inputs[3].default_value = 0.0
	
	    #node Emission
	    emission = hair_texture_creator_material.nodes.new("ShaderNodeEmission")
	    emission.name = "Emission"
	    #Strength
	    emission.inputs[1].default_value = 1.0
	
	    #node Normal Output
	    normal_output = hair_texture_creator_material.nodes.new("ShaderNodeOutputMaterial")
	    normal_output.label = "Normal Output"
	    normal_output.name = "Normal Output"
	    normal_output.is_active_output = False
	    normal_output.target = 'ALL'
	    normal_output.inputs[1].hide = True
	    normal_output.inputs[2].hide = True
	    normal_output.inputs[3].hide = True
	    #Displacement
	    normal_output.inputs[2].default_value = (0.0, 0.0, 0.0)
	    #Thickness
	    normal_output.inputs[3].default_value = 0.0
	
	    #node Normal Map
	    normal_map = hair_texture_creator_material.nodes.new("ShaderNodeNormalMap")
	    normal_map.name = "Normal Map"
	    normal_map.space = 'TANGENT'
	    normal_map.uv_map = ""
	    normal_map.inputs[0].hide = True
	    normal_map.inputs[1].hide = True
	    #Strength
	    normal_map.inputs[0].default_value = 1.0
	    #Color
	    normal_map.inputs[1].default_value = (0.5, 0.5, 1.0, 1.0)
	
	    #node Color Ramp
	    color_ramp = hair_texture_creator_material.nodes.new("ShaderNodeValToRGB")
	    color_ramp.name = "Color Ramp"
	    color_ramp.color_ramp.color_mode = 'RGB'
	    color_ramp.color_ramp.hue_interpolation = 'NEAR'
	    color_ramp.color_ramp.interpolation = 'LINEAR'
	
	    #initialize color ramp elements
	    color_ramp.color_ramp.elements.remove(color_ramp.color_ramp.elements[0])
	    color_ramp_cre_0 = color_ramp.color_ramp.elements[0]
	    color_ramp_cre_0.position = 0.0
	    color_ramp_cre_0.alpha = 1.0
	    color_ramp_cre_0.color = (1.0, 1.0, 1.0, 1.0)
	
	    color_ramp_cre_1 = color_ramp.color_ramp.elements.new(1.0)
	    color_ramp_cre_1.alpha = 1.0
	    color_ramp_cre_1.color = (1.0, 1.0, 1.0, 1.0)
	
	    color_ramp.outputs[1].hide = True
	
	    #node Texture Coordinate
	    texture_coordinate = hair_texture_creator_material.nodes.new("ShaderNodeTexCoord")
	    texture_coordinate.name = "Texture Coordinate"
	    texture_coordinate.hide = True
	    texture_coordinate.from_instancer = False
	    texture_coordinate.outputs[1].hide = True
	    texture_coordinate.outputs[2].hide = True
	    texture_coordinate.outputs[3].hide = True
	    texture_coordinate.outputs[4].hide = True
	    texture_coordinate.outputs[5].hide = True
	    texture_coordinate.outputs[6].hide = True
	
	    #node Group
	    group = hair_texture_creator_material.nodes.new("ShaderNodeGroup")
	    group.name = "Group"
	    group.node_tree = color_rotation_control
	    #Socket_2
	    group.inputs[1].default_value = 0
	
	    #node Frame
	    frame = hair_texture_creator_material.nodes.new("NodeFrame")
	    frame.label = "Render Normal Map. (Normal Output Must be the Active Output)"
	    frame.name = "Frame"
	    frame.label_size = 20
	    frame.shrink = True
	
	    #node Frame.001
	    frame_001 = hair_texture_creator_material.nodes.new("NodeFrame")
	    frame_001.label = "Render Alpha | Color. (Alpha Output Must be the Active Output)"
	    frame_001.name = "Frame.001"
	    frame_001.label_size = 20
	    frame_001.shrink = True
	
	    #Set parents
	    alpha_output.parent = frame_001
	    emission.parent = frame_001
	    normal_output.parent = frame
	    normal_map.parent = frame
	    color_ramp.parent = frame_001
	    texture_coordinate.parent = frame_001
	    group.parent = frame_001
	
	    #Set locations
	    alpha_output.location = (887.0, -39.697509765625)
	    emission.location = (721.2476806640625, -64.36007690429688)
	    normal_output.location = (474.0, -40.110748291015625)
	    normal_map.location = (29.935165405273438, -64.48074340820312)
	    color_ramp.location = (462.9290771484375, -87.97677612304688)
	    texture_coordinate.location = (30.18865966796875, -289.4110107421875)
	    group.location = (208.00164794921875, -219.73890686035156)
	    frame.location = (-174.0, 49.0)
	    frame_001.location = (-587.0, 426.0)
	
	    #Set dimensions
	    alpha_output.width, alpha_output.height = 140.0, 100.0
	    emission.width, emission.height = 140.0, 100.0
	    normal_output.width, normal_output.height = 140.0, 100.0
	    normal_map.width, normal_map.height = 150.0, 100.0
	    color_ramp.width, color_ramp.height = 240.0, 100.0
	    texture_coordinate.width, texture_coordinate.height = 140.0, 100.0
	    group.width, group.height = 230.41415405273438, 100.0
	    frame.width, frame.height = 644.0, 198.0
	    frame_001.width, frame_001.height = 1057.0, 368.0
	
	    #initialize hair_texture_creator_material links
	    #emission.Emission -> alpha_output.Surface
	    hair_texture_creator_material.links.new(emission.outputs[0], alpha_output.inputs[0])
	    #normal_map.Normal -> normal_output.Surface
	    hair_texture_creator_material.links.new(normal_map.outputs[0], normal_output.inputs[0])
	    #group.Fac -> color_ramp.Fac
	    hair_texture_creator_material.links.new(group.outputs[0], color_ramp.inputs[0])
	    #texture_coordinate.Generated -> group.Vector
	    hair_texture_creator_material.links.new(texture_coordinate.outputs[0], group.inputs[0])
	    #color_ramp.Color -> emission.Color
	    hair_texture_creator_material.links.new(color_ramp.outputs[0], emission.inputs[0])
	    return hair_texture_creator_material
	return hair_texture_creator_material_node_group()

	

	
